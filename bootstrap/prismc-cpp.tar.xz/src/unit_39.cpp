// The module `Emit.Cpp.Templates.Items`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <emit/cpp/templates/items/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Emit.Cpp.Templates.Items`, from `target/bootstrap/cpp-src/prismc/emit/cpp/templates/items.prism`.
namespace crate::emit::cpp::templates::items {

/// ChoiceClass: fn Text, Text, Text, Text, Text, Text -> Text
Text choice_class(const Text& doc_p0, const Text& gens_p1, const Text& name_p2, const Text& cases_p3, const Text& names_p4, const Text& members_p5) {
    auto out = std::string();
    place(out, doc_p0, std::optional(0u));
    place(out, gens_p1, std::nullopt);
    out.append("class ");
    place(out, name_p2, std::nullopt);
    out.append(" {\npublic:\n    using prism_value = void;\n");
    place(out, cases_p3, std::optional(4u));
    out.append("    using Cases = std::variant<");
    place(out, names_p4, std::nullopt);
    out.append(">;\n    template <class C>\n        requires prism_rtl::one_of<C, ");
    place(out, names_p4, std::nullopt);
    out.append(">\n    ");
    place(out, name_p2, std::nullopt);
    out.append("(C c) : cases_(std::move(c)) {}\n    const Cases& cases() const { return cases_; }\n");
    place(out, members_p5, std::optional(4u));
    out.append("\nprivate:\n    Cases cases_;\n};\n");
    return Text(std::move(out));
}


/// CaseDecl: fn Text, Text -> Text
Text case_decl(const Text& name_p0, const Text& fields_p1) {
    auto out = std::string();
    out.append("struct ");
    place(out, name_p0, std::nullopt);
    out.append(" {\n");
    place(out, fields_p1, std::optional(4u));
    out.append("};\n");
    return Text(std::move(out));
}


/// ValueStruct: fn Text, Text, Text, Text, Text -> Text
Text value_struct(const Text& doc_p0, const Text& gens_p1, const Text& name_p2, const Text& fields_p3, const Text& members_p4) {
    auto out = std::string();
    place(out, doc_p0, std::optional(0u));
    place(out, gens_p1, std::nullopt);
    out.append("struct ");
    place(out, name_p2, std::nullopt);
    out.append(" {\n    using prism_value = void;\n");
    place(out, fields_p3, std::optional(4u));
    out.append("    const ");
    place(out, name_p2, std::nullopt);
    out.append("* operator->() const { return this; }\n    ");
    place(out, name_p2, std::nullopt);
    out.append("* operator->() { return this; }\n");
    place(out, members_p4, std::optional(4u));
    out.append("};\n");
    return Text(std::move(out));
}


/// CppTagStruct: fn Text, Text, Text, Text, Text -> Text
Text cpp_tag_struct(const Text& doc_p0, const Text& name_p1, const Text& fields_p2, const Text& tag_name_p3, const Text& members_p4) {
    auto out = std::string();
    place(out, doc_p0, std::optional(0u));
    out.append("struct ");
    place(out, name_p1, std::nullopt);
    out.append(" {\n    using prism_value = void;\n    /// The tag\'s qualified name, as its `Pod` carries it.\n    static constexpr const char* TAG = \"");
    place(out, tag_name_p3, std::nullopt);
    out.append("\";\n");
    place(out, fields_p2, std::optional(4u));
    out.append("    const ");
    place(out, name_p1, std::nullopt);
    out.append("* operator->() const { return this; }\n    ");
    place(out, name_p1, std::nullopt);
    out.append("* operator->() { return this; }\n    Pod to_pod() const;\n    void show(Printer& p) const;\n");
    place(out, members_p4, std::optional(4u));
    out.append("};\n");
    return Text(std::move(out));
}


/// CppFunction: fn Text, Text, Text -> Text
Text cpp_function(const Text& doc_p0, const Text& signature_p1, const Text& body_p2) {
    auto out = std::string();
    place(out, doc_p0, std::optional(0u));
    place(out, signature_p1, std::nullopt);
    out.append(" {\n");
    place(out, body_p2, std::optional(4u));
    out.append("}\n");
    return Text(std::move(out));
}


/// JobStruct: fn Text, Text, Text, Text, Text, Text -> Text
Text job_struct(const Text& doc_p0, const Text& gens_p1, const Text& name_p2, const Text& ret_p3, const Text& fields_p4, const Text& ctor_p5) {
    auto out = std::string();
    out.append("/// The step machine of `");
    place(out, name_p2, std::nullopt);
    out.append("`, stopped at a cycle point: the call about to be\n/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the\n/// callee\'s job, so the job\'s stack is its frames.\n///\n");
    place(out, doc_p0, std::optional(0u));
    place(out, gens_p1, std::nullopt);
    out.append("struct ");
    place(out, name_p2, std::nullopt);
    out.append(" : prism_rtl::Job<");
    place(out, ret_p3, std::nullopt);
    out.append("> {\n");
    place(out, fields_p4, std::optional(4u));
    place(out, ctor_p5, std::optional(4u));
    out.append("    prism_rtl::Turn<");
    place(out, ret_p3, std::nullopt);
    out.append("> cycle() const override;\n};\n");
    return Text(std::move(out));
}


/// TraitNamespace: fn Text, Text -> Text
Text trait_namespace(const Text& name_p0, const Text& body_p1) {
    auto out = std::string();
    out.append("namespace ");
    place(out, name_p0, std::nullopt);
    out.append(" {\n");
    place(out, body_p1, std::optional(0u));
    out.append("}  // namespace ");
    place(out, name_p0, std::nullopt);
    return Text(std::move(out));
}


/// NodeClass: fn Text, Text, Text, Text, Text, Text, Text -> Text
Text node_class(const Text& doc_p0, const Text& name_p1, const Text& base_p2, const Text& fields_p3, const Text& consts_p4, const Text& ctor_p5, const Text& decls_p6) {
    auto out = std::string();
    place(out, doc_p0, std::optional(0u));
    out.append("class ");
    place(out, name_p1, std::nullopt);
    out.append(" : public ");
    place(out, base_p2, std::nullopt);
    out.append(" {\npublic:\n    Path path;\n");
    place(out, fields_p3, std::optional(4u));
    place(out, consts_p4, std::optional(4u));
    place(out, ctor_p5, std::optional(4u));
    out.append("    ");
    place(out, name_p1, std::nullopt);
    out.append("(const ");
    place(out, name_p1, std::nullopt);
    out.append("&) = delete;\n");
    place(out, decls_p6, std::optional(4u));
    out.append("};\n");
    return Text(std::move(out));
}


/// NodeMake: fn Text, Text, Text, Text, Text -> Text
Text node_make(const Text& name_p0, const Text& signature_p1, const Text& lets_p2, const Text& args_p3, const Text& rest_p4) {
    auto out = std::string();
    out.append("/// Built after propagation: holds take their initial values, places go out with\n/// `cx.added`, and nothing fires.\n");
    place(out, signature_p1, std::nullopt);
    out.append(" {\n");
    place(out, lets_p2, std::optional(4u));
    out.append("    prism_rtl::RcPlace<");
    place(out, name_p0, std::nullopt);
    out.append("> _place;\n    auto node = _place.take(new (_place.at()) ");
    place(out, name_p0, std::nullopt);
    out.append("(");
    place(out, args_p3, std::nullopt);
    out.append("));\n");
    place(out, rest_p4, std::optional(4u));
    out.append("}\n");
    return Text(std::move(out));
}


/// ForBuildTemplate: fn Text, Text, Text, Text, Text, Text, Text, Text, Text, Text, Text, Text -> Text
Text for_build_template(const Text& owner_p0, const Text& name_p1, const Text& at_p2, const Text& key_ty_p3, const Text& value_ty_p4, const Text& row_make_p5, const Text& source_p6, const Text& parent_p7, const Text& passed_p8, const Text& moved_p9, const Text& from_pa, const Text& replaced_pb) {
    auto out = std::string();
    out.append("/// The rows of the `for` at `");
    place(out, at_p2, std::nullopt);
    out.append("`: rows whose key left are torn down, new keys are\n/// built under it at `[k]` from the values after the tick; kept rows keep reading their\n/// entry out of the source. Nothing to do when the source is the map last built from (one\n/// node, `same`: it has the same keys; Semantics ch. 11, sharing is invisible).\nDone ");
    place(out, owner_p0, std::nullopt);
    out.append("::");
    place(out, name_p1, std::nullopt);
    out.append("_build(Cx& cx) {\n    Map<");
    place(out, key_ty_p3, std::nullopt);
    out.append(", ");
    place(out, value_ty_p4, std::nullopt);
    out.append("> items = ");
    place(out, source_p6, std::nullopt);
    out.append("(cx);\n    if (this->");
    place(out, name_p1, std::nullopt);
    out.append("_from.same(items)) return {};\n");
    place(out, from_pa, std::optional(4u));
    out.append("    auto old = deref(this->");
    place(out, name_p1, std::nullopt);
    out.append(");\n    // the kept rows stay where they are: only the keys that left or came are touched\n    auto next = old;\n    for (auto&& [k, row] : old) {\n        if (!items.contains(k)) {\n            row->leave_row(cx);\n            cx.leave_later(row);\n            next.remove(k);\n        }");
    place(out, replaced_pb, std::nullopt);
    out.append("\n    }\n    for (auto&& [k, v] : items) {\n        if (!old.contains(k)) next.insert(k, TRY(");
    place(out, row_make_p5, std::nullopt);
    out.append("(");
    place(out, at_p2, std::nullopt);
    out.append(".child(Segment::key(prism_rtl::to_pod(k))), k, v, ");
    place(out, parent_p7, std::nullopt);
    place(out, passed_p8, std::nullopt);
    out.append(", cx)));\n    }\n    deref(this->");
    place(out, name_p1, std::nullopt);
    out.append(") = next;\n    // What the block reads of its rows (a `for` that gives a dynamic) moved.\n    cx.dirty(prism_rtl::share(this));");
    place(out, moved_p9, std::nullopt);
    out.append("\n    return {};\n}\n");
    return Text(std::move(out));
}


/// GenBuildTemplate: fn Text, Text, Text, Text, Text, Text, Text, Text -> Text
Text gen_build_template(const Text& owner_p0, const Text& name_p1, const Text& at_p2, const Text& path_p3, const Text& source_p4, const Text& value_ty_p5, const Text& select_p6, const Text& moved_p7) {
    auto out = std::string();
    out.append("/// The `rebuild` at `");
    place(out, at_p2, std::nullopt);
    out.append("`: the old generation torn down (it ran to the end of the\n/// tick), the next built at `");
    place(out, path_p3, std::nullopt);
    out.append("` from the source after the tick.\nDone ");
    place(out, owner_p0, std::nullopt);
    out.append("::");
    place(out, name_p1, std::nullopt);
    out.append("_build(Cx& cx) {\n    if (auto old = std::exchange(this->");
    place(out, name_p1, std::nullopt);
    out.append(", std::nullopt)) {\n        (*old)->leave_row(cx);\n        cx.leave_later(*old);\n    }\n    std::uint32_t g = this->");
    place(out, name_p1, std::nullopt);
    out.append("_count;\n    this->");
    place(out, name_p1, std::nullopt);
    out.append("_count = g + 1;\n    Path path = ");
    place(out, path_p3, std::nullopt);
    out.append(";\n    ");
    place(out, value_ty_p5, std::nullopt);
    out.append(" value = ");
    place(out, source_p4, std::nullopt);
    out.append(";\n    prism_rtl::Rc<Row> row = ");
    place(out, select_p6, std::nullopt);
    out.append(";\n    this->");
    place(out, name_p1, std::nullopt);
    out.append(" = row;");
    place(out, moved_p7, std::nullopt);
    out.append("\n    return {};\n}\n");
    return Text(std::move(out));
}


/// ProgramClass: fn Text, Text, Text, Text, Text -> Text
Text program_class(const Text& name_p0, const Text& prism_p1, const Text& node_p2, const Text& decode_p3, const Text& root_p4) {
    auto out = std::string();
    out.append("/// The program of `@");
    place(out, prism_p1, std::nullopt);
    out.append("`: the root node and the runtime.\nclass ");
    place(out, name_p0, std::nullopt);
    out.append(" : public Program {\npublic:\n    static Built<");
    place(out, name_p0, std::nullopt);
    out.append("> build(std::span<const Pod> args, const ReadyState& ready) {\n");
    place(out, decode_p3, std::optional(8u));
    out.append("        auto p = std::make_unique<");
    place(out, name_p0, std::nullopt);
    out.append(">();\n        Cx cx = p->rt.build(ready);\n        p->root = ");
    place(out, root_p4, std::nullopt);
    out.append(";\n        TickOut out = TRY(p->rt.close(std::move(cx)));\n        return std::pair<std::unique_ptr<");
    place(out, name_p0, std::nullopt);
    out.append(">, TickOut>(std::move(p), std::move(out));\n    }\n    Result<TickOut> tick(const TickIn& input, const ReadyState& ready) override {\n        return rt.tick(root, input, ready);\n    }\n    void compact() override { rt.compact(); }\n\n    Runtime rt;\n    prism_rtl::Rc<");
    place(out, node_p2, std::nullopt);
    out.append("> root;\n};\n");
    return Text(std::move(out));
}


/// StmtExpr: fn Text, Text -> Text
Text stmt_expr(const Text& stmts_p0, const Text& tail_p1) {
    auto out = std::string();
    out.append("({\n");
    place(out, stmts_p0, std::optional(4u));
    out.append("    ");
    place(out, tail_p1, std::nullopt);
    out.append(";\n})");
    return Text(std::move(out));
}


/// MatchExpr: fn Text, Text -> Text
Text match_expr(const Text& ty_p0, const Text& arms_p1) {
    auto out = std::string();
    out.append("({\n    __label__ _done;\n    prism_rtl::Slot<");
    place(out, ty_p0, std::nullopt);
    out.append("> _v;\n");
    place(out, arms_p1, std::optional(4u));
    out.append("_done:\n    _v.take();\n})");
    return Text(std::move(out));
}


/// LabeledExpr: fn Text, Text, Text -> Text
Text labeled_expr(const Text& label_p0, const Text& ty_p1, const Text& body_p2) {
    auto out = std::string();
    out.append("({\n    __label__ ");
    place(out, label_p0, std::nullopt);
    out.append(";\n    prism_rtl::Slot<");
    place(out, ty_p1, std::nullopt);
    out.append("> ");
    place(out, label_p0, std::nullopt);
    out.append("_v;\n    {\n");
    place(out, body_p2, std::optional(8u));
    out.append("    }\n");
    place(out, label_p0, std::nullopt);
    out.append(":\n    ");
    place(out, label_p0, std::nullopt);
    out.append("_v.take();\n})");
    return Text(std::move(out));
}


/// CondExpr: fn Text, Text, Text -> Text
Text cond_expr(const Text& cond_p0, const Text& then_x_p1, const Text& else_x_p2) {
    auto out = std::string();
    place(out, cond_p0, std::optional(0u));
    out.append("    ? ");
    place(out, then_x_p1, std::nullopt);
    out.append("\n    : ");
    place(out, else_x_p2, std::nullopt);
    return Text(std::move(out));
}


/// Lambda: fn Text, Text, Text -> Text
Text lambda(const Text& capture_p0, const Text& params_p1, const Text& body_p2) {
    auto out = std::string();
    out.append("[");
    place(out, capture_p0, std::nullopt);
    out.append("](");
    place(out, params_p1, std::nullopt);
    out.append(" {\n");
    place(out, body_p2, std::optional(4u));
    out.append("}");
    return Text(std::move(out));
}


/// Block: fn Text, Text -> Text
Text block(const Text& head_p0, const Text& body_p1) {
    auto out = std::string();
    place(out, head_p0, std::nullopt);
    out.append(" {\n");
    place(out, body_p1, std::optional(4u));
    out.append("}");
    return Text(std::move(out));
}


/// IfBlock: fn Text, Text -> Text
Text if_block(const Text& cond_p0, const Text& body_p1) {
    auto out = std::string();
    out.append("if (");
    place(out, cond_p0, std::nullopt);
    out.append(") {\n");
    place(out, body_p1, std::optional(4u));
    out.append("}");
    return Text(std::move(out));
}


/// Braced: fn Text -> Text
Text braced(const Text& body_p0) {
    auto out = std::string();
    out.append("{\n");
    place(out, body_p0, std::optional(4u));
    out.append("}");
    return Text(std::move(out));
}

}  // namespace crate::emit::cpp::templates::items
