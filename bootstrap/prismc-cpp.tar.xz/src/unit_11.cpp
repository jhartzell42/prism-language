// The module `Check.Expr.Calls`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/expr/calls/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Expr.Calls`, from `target/bootstrap/cpp-src/prismc/check/expr/calls.prism`.
namespace crate::check::expr::calls {

bool Peeled::operator==(const Peeled& o) const { return events == o.events && dyns == o.dyns && opts == o.opts && opt_args == o.opt_args && lifted == o.lifted && broken == o.broken; }

void Peeled::show(Printer& p) const {
    p.record("Peeled", {{"events", events}, {"dyns", dyns}, {"opts", opts}, {"opt_args", opt_args}, {"lifted", lifted}, {"broken", broken}});
}

Pod Peeled::to_pod() const {
    return Pod::record("Peeled", {{"events", prism_rtl::to_pod(events)}, {"dyns", prism_rtl::to_pod(dyns)}, {"opts", prism_rtl::to_pod(opts)}, {"opt_args", prism_rtl::to_pod(opt_args)}, {"lifted", prism_rtl::to_pod(lifted)}, {"broken", prism_rtl::to_pod(broken)}});
}

Result<Peeled> Peeled::from_pod(const Pod& whole) {
    return Peeled{.events = TRY(prism_rtl::from_pod<Array<crate::syntax::Range>>(TRY(crate::prelude::field(whole, "events")))), .dyns = TRY(prism_rtl::from_pod<Array<crate::syntax::Range>>(TRY(crate::prelude::field(whole, "dyns")))), .opts = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "opts")))), .opt_args = TRY(prism_rtl::from_pod<Array<crate::syntax::Range>>(TRY(crate::prelude::field(whole, "opt_args")))), .lifted = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "lifted")))), .broken = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "broken"))))};
}


/// InferCall: unbounded fn Env, St, Expr, [Arg], Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_call(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Expr& callee, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span) {
    auto&& _m = prism_rtl::val(callee.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        auto local = crate::check::env::sname_key(n);
        auto&& _m = crate::prelude::get(env.locals, local);
        if (prism_rtl::is_some(_m)) {
            auto&& sc = prism_rtl::some_of(_m);
            auto [t, st2] = crate::check::expr::instantiate_local(st, sc, callee.span, local);
            return apply_fn(env, crate::check::types::recording::note_ty(st2, callee.span, t), local, t, positional(args), span);
        }
        if (prism_rtl::is_none(_m)) {
            return call_global(env, st, n, args, span, Array<crate::check::types::Ty>{}, callee.span);
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m)) {
        auto&& target = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
        auto&& tys = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a1;
        auto&& _m = prism_rtl::val(prism_rtl::val(target).kind);
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            auto cx_ = crate::check::expr::env_cx(env);
            auto [given2, st2] = crate::check::env::reading::conv_types(cx_, st, tys);
            return call_global(env, st2, n, args, span, given2, callee.span);
        }
        {
            return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("mismatch"), callee.span, Text::lit("`<<T>>` applies to a function\'s name"))};
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return infer_call(env, st, prism_rtl::val(prism_rtl::val(x)), args, span);
    }
    {
        auto [t, st2] = crate::check::expr::infer(env, st, callee);
        return apply_fn(env, st2, crate::check::expr::src_text(env, callee.span), t, positional(args), span);
    }
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferCall::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& callee = this->callee;
    const auto& args = this->args;
    const auto& span = this->span;
    return ({
        auto&& _m = prism_rtl::val(prism_rtl::val(callee).kind);
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        ({
        auto local = crate::check::env::sname_key(n);
        ({
        auto&& _m = crate::prelude::get(prism_rtl::val(env).locals, local);
        prism_rtl::is_some(_m) ? ({
        auto&& sc = prism_rtl::some_of(_m);
        ({
        auto args_1 = args;
        auto callee_2 = callee;
        auto env_3 = env;
        auto span_4 = span;
        auto st_5 = st;
        call_then(crate::check::expr::start_instantiate_local(st_5, sc, prism_rtl::val(callee_2).span, local), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> instantiate_local_1491) {
        return ({
            auto [t, st2] = instantiate_local_1491;
            (prism_rtl::more(prism_rtl::rc(ApplyFn(env_3, crate::check::types::recording::note_ty(st2, prism_rtl::val(callee_2).span, t), local, t, positional(args_1), span_4))));
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(CallGlobal(env, st, n, args, span, Array<crate::check::types::Ty>{}, prism_rtl::val(callee).span)))
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m) ? ({
        auto&& target = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
        auto&& tys = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a1;
        ({
        auto&& _m = prism_rtl::val(prism_rtl::val(target).kind);
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        ({
        auto cx_ = crate::check::expr::env_cx(env);
        auto args_1 = args;
        auto callee_2 = callee;
        auto env_3 = env;
        auto n_4 = n;
        auto span_5 = span;
        auto st_6 = st;
        auto tys_7 = tys;
        call_then(crate::check::env::reading::start_conv_types(cx_, st_6, tys_7), [=](std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> conv_types_1826) {
        return ({
            auto [given2, st2] = conv_types_1826;
            (prism_rtl::more(prism_rtl::rc(CallGlobal(env_3, st2, n_4, args_1, span_5, given2, prism_rtl::val(callee_2).span))));
        });
    });
    });
    })
        : prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("mismatch"), prism_rtl::val(callee).span, Text::lit("`<<T>>` applies to a function\'s name"))});
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(InferCall(env, st, prism_rtl::val(prism_rtl::val(x)), args, span)));
    })
        : ({
        auto args_1 = args;
        auto callee_2 = callee;
        auto env_3 = env;
        auto span_4 = span;
        auto st_5 = st;
        call_then(crate::check::expr::start_infer(env_3, st_5, callee_2), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_2107) {
        return ({
            auto [t, st2] = infer_2107;
            (prism_rtl::more(prism_rtl::rc(ApplyFn(env_3, st2, crate::check::expr::src_text(env_3, prism_rtl::val(callee_2).span), t, positional(args_1), span_4))));
        });
    });
    });
    });
}


/// `Start InferCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_call(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr callee, Array<crate::syntax::Arg> args, crate::syntax::Range span) {
    return prism_rtl::make_rc<InferCall>(env, st, callee, args, span);
}


/// Positional: fn [Arg] -> [Arg]
Array<crate::syntax::Arg> positional(const Array<crate::syntax::Arg>& args) {
    return args;
}


/// CallGlobal: unbounded fn Env, St, SName, [Arg], Range, [Ty], Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> call_global(const crate::check::expr::Env& env, const crate::check::types::St& st0, const crate::syntax::SName& n, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span, const Array<crate::check::types::Ty>& explicit_, const crate::syntax::Range& cspan) {
    auto [qk_opt, why] = crate::check::env::names::resolve_value(env.g, env.home, n);
    auto name = crate::check::env::sname_key(n);
    auto st = crate::check::expr::collision_at(env, st0, why, name, n.span);
    if (prism_rtl::is_none(qk_opt)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unknown-name"), n.span, prism_rtl::cat("nothing declares `", name, "` here"))};
    }
    if (prism_rtl::is_some(qk_opt)) {
        auto&& qk = prism_rtl::some_of(qk_opt);
        return why == Text::lit("tag")
            ? tag_app(env, st, qk, args, span, cspan)
            : is_local_maker(qk) && (!env.in_update)
            ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), local_outside(st, qk, span)}
            : ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
            auto&& _m = crate::prelude::get(prism_rtl::val(env.g).vals, qk);
            if (prism_rtl::is_some(_m)) {
                auto&& v_ = prism_rtl::some_of(_m);
                _v.set(({
                    auto [t, st2i, inst] = crate::check::types::schemes::instantiate_with(st, prism_rtl::val(v_).scheme, span, explicit_);
                    auto [rigids, st2] = rank_two(st2i, prism_rtl::val(v_).scheme, inst, len(explicit_), span);
                    auto st3a = note_callee(note_method_use(st2, v_, span), n.span, cspan, t);
                    auto st3 = crate::check::types::bare_name(qk) == Text::lit("Min")
                        ? crate::check::types::recording::note_size_ty(st3a, span, crate::check::types::recording::walk(st3a, t))
                        : st3a;
                    (crate::check::types::bare_name(qk) == Text::lit("Fold")) && (prism_rtl::val(v_).home == Text::lit("Prelude"))
                    ? fold_app(env, st3, t, args, span)
                    : ({
                    auto [rt, st4] = apply_fn(env, st3, name, t, args, span);
                    std::tuple{rt, escaped(env, st4, rigids, rt, name, span)};
                });
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                    auto&& _m = crate::prelude::get(prism_rtl::val(env.g).ctors, qk);
                    if (prism_rtl::is_some(_m)) {
                        auto&& c = prism_rtl::some_of(_m);
                        _v.set(ctor_app(env, st, c, args, span, cspan));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unknown-name"), n.span, prism_rtl::cat("`", name, "` has no signature line"))});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> CallGlobal::cycle() const {
    const auto& env = this->env;
    const auto& st0 = this->st0;
    const auto& n = this->n;
    const auto& args = this->args;
    const auto& span = this->span;
    const auto& explicit_ = this->explicit_;
    const auto& cspan = this->cspan;
    auto [qk_opt, why] = crate::check::env::names::resolve_value(prism_rtl::val(env).g, prism_rtl::val(env).home, n);
    auto name = crate::check::env::sname_key(n);
    auto st = crate::check::expr::collision_at(env, st0, why, name, prism_rtl::val(n).span);
    return ({
        prism_rtl::is_none(qk_opt) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unknown-name"), prism_rtl::val(n).span, prism_rtl::cat("nothing declares `", name, "` here"))})
        : prism_rtl::is_some(qk_opt) ? ({
        auto&& qk = prism_rtl::some_of(qk_opt);
        why == Text::lit("tag")
        ? prism_rtl::more(prism_rtl::rc(TagApp(env, st, qk, args, span, cspan)))
        : is_local_maker(qk) && (!prism_rtl::val(env).in_update)
        ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), local_outside(st, qk, span)})
        : ({
        auto&& _m = crate::prelude::get(prism_rtl::val(prism_rtl::val(env).g).vals, qk);
        prism_rtl::is_some(_m) ? ({
        auto&& v_ = prism_rtl::some_of(_m);
        ({
        auto args_1 = args;
        auto cspan_2 = cspan;
        auto env_3 = env;
        auto explicit__4 = explicit_;
        auto n_5 = n;
        auto qk_6 = qk;
        auto span_7 = span;
        call_then(crate::check::types::schemes::start_instantiate_with(st, prism_rtl::val(v_).scheme, span_7, explicit__4), [=](std::tuple<crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst> instantiate_with_2931) {
        return ({
            auto [t, st2i, inst] = instantiate_with_2931;
            call_then(start_rank_two(st2i, prism_rtl::val(v_).scheme, inst, len(explicit__4), span_7), [=](std::tuple<Array<Text>, crate::check::types::St> rank_two_3018) {
            return ({
                auto [rigids, st2] = rank_two_3018;
                auto st3a = note_callee(note_method_use(st2, v_, span_7), prism_rtl::val(n_5).span, cspan_2, t);
                auto st3 = crate::check::types::bare_name(qk_6) == Text::lit("Min")
                    ? crate::check::types::recording::note_size_ty(st3a, span_7, crate::check::types::recording::walk(st3a, t))
                    : st3a;
                (crate::check::types::bare_name(qk_6) == Text::lit("Fold")) && (prism_rtl::val(v_).home == Text::lit("Prelude"))
                ? prism_rtl::more(prism_rtl::rc(FoldApp(env_3, st3, t, args_1, span_7)))
                : call_then(start_apply_fn(env_3, st3, name, t, args_1, span_7), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> apply_fn_3436) {
                return ({
                    auto [rt, st4] = apply_fn_3436;
                    call_then(start_escaped(env_3, st4, rigids, rt, name, span_7), [=](crate::check::types::St escaped_3505) { return prism_rtl::finished(std::tuple{rt, escaped_3505}); });
                });
            });
            });
        });
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto&& _m = crate::prelude::get(prism_rtl::val(prism_rtl::val(env).g).ctors, qk);
        prism_rtl::is_some(_m) ? ({
        auto&& c = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(CtorApp(env, st, c, args, span, cspan)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unknown-name"), prism_rtl::val(n).span, prism_rtl::cat("`", name, "` has no signature line"))})
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CallGlobal, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_call_global(crate::check::expr::Env env, crate::check::types::St st0, crate::syntax::SName n, Array<crate::syntax::Arg> args, crate::syntax::Range span, Array<crate::check::types::Ty> explicit_, crate::syntax::Range cspan) {
    return prism_rtl::make_rc<CallGlobal>(env, st0, n, args, span, explicit_, cspan);
}


/// RankTwo: unbounded fn St, Scheme, Inst, Nat, Range -> (([Text], St))
std::tuple<Array<Text>, crate::check::types::St> rank_two(const crate::check::types::St& st, const crate::check::types::Scheme& sc, const crate::check::types::schemes::Inst& inst, const Nat& n_explicit, const crate::syntax::Range& span) {
    auto qs = filter(crate::check::errors::range0(len(sc.qs)), [&](const Nat& i) { return (i >= n_explicit) && is_rank_two(or_(index(sc.qs, i), Text::lit("")), sc.ty); });
    return run_to_end(fold_job(qs, std::tuple{Array<Text>{}, st}, ({
        auto sc_1 = sc;
        auto inst_2 = inst;
        auto span_3 = span;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, crate::check::types::St>>(std::tuple<std::tuple<Array<Text>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Text>, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sc_1_4 = sc_1;
            auto inst_2_4 = inst_2;
            auto span_3_4 = span_3;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto i = p1;
                ({
                auto q = or_(index(sc_1_4.qs, i), Text::lit(""));
                auto rigid = prism_rtl::cat(q, "\'", prism_rtl::val(s).next);
                auto s2 = ({
                    crate::check::types::St this_ = s;
                    this_.next = this_.next + Nat(1u);
                    this_;
                });
                call_then(crate::check::types::unify::start_unify(s2, or_(crate::prelude::get(inst_2_4.tys, q), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), crate::check::types::Ty(crate::check::types::Ty::TyRigid{rigid}), span_3_4), [=](crate::check::types::St unify_4584) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc, rigid), unify_4584}); });
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Array<Text>, crate::check::types::St>> RankTwo::cycle() const {
    const auto& st = this->st;
    const auto& sc = this->sc;
    const auto& inst = this->inst;
    const auto& n_explicit = this->n_explicit;
    const auto& span = this->span;
    auto qs = filter(crate::check::errors::range0(len(prism_rtl::val(sc).qs)), [&](const Nat& i) { return (i >= n_explicit) && is_rank_two(or_(index(prism_rtl::val(sc).qs, i), Text::lit("")), prism_rtl::val(sc).ty); });
    return fold_job(qs, std::tuple{Array<Text>{}, st}, ({
        auto sc_1 = sc;
        auto inst_2 = inst;
        auto span_3 = span;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, crate::check::types::St>>(std::tuple<std::tuple<Array<Text>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Text>, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sc_1_4 = sc_1;
            auto inst_2_4 = inst_2;
            auto span_3_4 = span_3;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto i = p1;
                ({
                auto q = or_(index(prism_rtl::val(sc_1_4).qs, i), Text::lit(""));
                auto rigid = prism_rtl::cat(q, "\'", prism_rtl::val(s).next);
                auto s2 = ({
                    crate::check::types::St this_ = s;
                    this_.next = this_.next + Nat(1u);
                    this_;
                });
                call_then(crate::check::types::unify::start_unify(s2, or_(crate::prelude::get(prism_rtl::val(inst_2_4).tys, q), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), crate::check::types::Ty(crate::check::types::Ty::TyRigid{rigid}), span_3_4), [=](crate::check::types::St unify_4584) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc, rigid), unify_4584}); });
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start RankTwo, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<Text>, crate::check::types::St>> start_rank_two(crate::check::types::St st, crate::check::types::Scheme sc, crate::check::types::schemes::Inst inst, Nat n_explicit, crate::syntax::Range span) {
    return prism_rtl::make_rc<RankTwo>(st, sc, inst, n_explicit, span);
}


/// IsRankTwo: fn Text, Ty -> Bool
bool is_rank_two(const Text& q, const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t)) {
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        auto holding = filter(ps, [&](const crate::check::types::Ty& p_) { return qoccurs(q, p_); });
        return (len(holding) != Nat(1u)) || qoccurs(q, prism_rtl::val(prism_rtl::val(res)))
            ? false
            : ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = index(holding, Nat(0u));
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::check::types::Ty::TyFn>(prism_rtl::some_of(_m))) {
                _v.set(elem_out_q(q, or_(index(holding, Nat(0u)), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))));
                goto _done;
            }
            {
                _v.set(false);
                goto _done;
            }
        _done:
            _v.take();
        });
    }
    {
        return false;
    }
}


/// QOccurs: fn Text, Ty -> Bool
bool qoccurs(const Text& q, const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TyQ>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyQ>(t).a0;
        return n == q;
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        return fold(args, false, [&](const bool& seen, const crate::check::types::Ty& a) { return prism_rtl::val(seen) || qoccurs(q, a); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t)) {
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& r = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        return fold(ps, qoccurs(q, prism_rtl::val(prism_rtl::val(r))), [&](const bool& seen, const crate::check::types::Ty& a) { return prism_rtl::val(seen) || qoccurs(q, a); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        return fold(ts, false, [&](const bool& seen, const crate::check::types::Ty& a) { return prism_rtl::val(seen) || qoccurs(q, a); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        return qoccurs(q, prism_rtl::val(prism_rtl::val(e)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        return qoccurs(q, prism_rtl::val(prism_rtl::val(k))) || qoccurs(q, prism_rtl::val(prism_rtl::val(v_)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        return qoccurs(q, prism_rtl::val(prism_rtl::val(i)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a0;
        return qoccurs(q, prism_rtl::val(prism_rtl::val(i)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t)) {
        auto&& o = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a1;
        return qoccurs(q, prism_rtl::val(prism_rtl::val(o)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t).a1;
        return qoccurs(q, prism_rtl::val(prism_rtl::val(i)));
    }
    {
        return false;
    }
}


/// ElemOutQ: fn Text, Ty -> Bool
bool elem_out_q(const Text& q, const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t)) {
        auto&& o = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a1;
        return (prism_rtl::val(prism_rtl::val(o)) == crate::check::types::Ty(crate::check::types::Ty::TyQ{q})) || elem_out_q(q, prism_rtl::val(prism_rtl::val(o)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        return fold(args, false, [&](const bool& seen, const crate::check::types::Ty& a) { return prism_rtl::val(seen) || elem_out_q(q, a); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t)) {
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& r = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        return fold(ps, elem_out_q(q, prism_rtl::val(prism_rtl::val(r))), [&](const bool& seen, const crate::check::types::Ty& a) { return prism_rtl::val(seen) || elem_out_q(q, a); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        return fold(ts, false, [&](const bool& seen, const crate::check::types::Ty& a) { return prism_rtl::val(seen) || elem_out_q(q, a); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        return elem_out_q(q, prism_rtl::val(prism_rtl::val(e)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        return elem_out_q(q, prism_rtl::val(prism_rtl::val(k))) || elem_out_q(q, prism_rtl::val(prism_rtl::val(v_)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        return elem_out_q(q, prism_rtl::val(prism_rtl::val(i)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a0;
        return elem_out_q(q, prism_rtl::val(prism_rtl::val(i)));
    }
    {
        return false;
    }
}


/// Escaped: unbounded fn Env, St, [Text], Ty, Text, Range -> St
crate::check::types::St escaped(const crate::check::expr::Env& env, const crate::check::types::St& st, const Array<Text>& rigids, const crate::check::types::Ty& rt, const Text& fname, const crate::syntax::Range& span) {
    return run_to_end(fold_job(rigids, st, ({
        auto env_1 = env;
        auto rt_2 = rt;
        auto span_3 = span;
        auto fname_4 = fname;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Text>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_5 = env_1;
            auto rt_2_5 = rt_2;
            auto span_3_5 = span_3;
            auto fname_4_5 = fname_4;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto r = p1;
                call_value(filter_job(keys(env_1_5.locals), ({
                auto s_5 = s;
                auto r_6 = r;
                auto env_1_5_7 = env_1_5;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text p0) {
                return ({
                    auto s_5_7 = s_5;
                    auto r_6_7 = r_6;
                    auto env_1_5_7_7 = env_1_5_7;
                    entered(once_job([=]() {
                    return ({
                        auto k = p0;
                        (prism_rtl::more(prism_rtl::rc(HasRigid(s_5_7, r_6_7, prism_rtl::val(or_(crate::prelude::get(env_1_5_7_7.locals, k), crate::check::types::schemes::mono(crate::check::types::Ty(crate::check::types::Ty::TyErr{})))).ty))));
                    });
                }));
                });
            })));
            })), [=](Array<Text> filter_6547) {
                return ({
                    auto outside = filter_6547;
                    call_then(start_has_rigid(s, r, rt_2_5), [=](bool has_rigid_6636) {
                    return has_rigid_6636
                        ? prism_rtl::finished(crate::check::types::recording::err(s, Text::lit("refinement-escape"), span_3_5, prism_rtl::cat("the call\'s result takes the output of the element `", fname_4_5, "`\'s supplier answers, which is the supplier\'s alone (rank-2)")))
                        : ({
                        auto&& _m = index(outside, Nat(0u));
                        prism_rtl::is_some(_m) ? ({
                        auto&& k = prism_rtl::some_of(_m);
                        prism_rtl::finished(crate::check::types::recording::err(s, Text::lit("refinement-escape"), span_3_5, prism_rtl::cat("`", k, "`, outside the supplier `", fname_4_5, "` is given, takes the output of the element the supplier answers, which is the supplier\'s alone (rank-2)")));
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(s)
                        : throw prism_rtl::Panic("no arm matched");
                    });
                });
                });
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<crate::check::types::St> Escaped::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& rigids = this->rigids;
    const auto& rt = this->rt;
    const auto& fname = this->fname;
    const auto& span = this->span;
    return fold_job(rigids, st, ({
        auto env_1 = env;
        auto rt_2 = rt;
        auto span_3 = span;
        auto fname_4 = fname;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Text>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_5 = env_1;
            auto rt_2_5 = rt_2;
            auto span_3_5 = span_3;
            auto fname_4_5 = fname_4;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto r = p1;
                call_value(filter_job(keys(prism_rtl::val(env_1_5).locals), ({
                auto s_5 = s;
                auto r_6 = r;
                auto env_1_5_7 = env_1_5;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text p0) {
                return ({
                    auto s_5_7 = s_5;
                    auto r_6_7 = r_6;
                    auto env_1_5_7_7 = env_1_5_7;
                    entered(once_job([=]() {
                    return ({
                        auto k = p0;
                        (prism_rtl::more(prism_rtl::rc(HasRigid(s_5_7, r_6_7, prism_rtl::val(or_(crate::prelude::get(prism_rtl::val(env_1_5_7_7).locals, k), crate::check::types::schemes::mono(crate::check::types::Ty(crate::check::types::Ty::TyErr{})))).ty))));
                    });
                }));
                });
            })));
            })), [=](Array<Text> filter_6547) {
                return ({
                    auto outside = filter_6547;
                    call_then(start_has_rigid(s, r, rt_2_5), [=](bool has_rigid_6636) {
                    return has_rigid_6636
                        ? prism_rtl::finished(crate::check::types::recording::err(s, Text::lit("refinement-escape"), span_3_5, prism_rtl::cat("the call\'s result takes the output of the element `", fname_4_5, "`\'s supplier answers, which is the supplier\'s alone (rank-2)")))
                        : ({
                        auto&& _m = index(outside, Nat(0u));
                        prism_rtl::is_some(_m) ? ({
                        auto&& k = prism_rtl::some_of(_m);
                        prism_rtl::finished(crate::check::types::recording::err(s, Text::lit("refinement-escape"), span_3_5, prism_rtl::cat("`", k, "`, outside the supplier `", fname_4_5, "` is given, takes the output of the element the supplier answers, which is the supplier\'s alone (rank-2)")));
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(s)
                        : throw prism_rtl::Panic("no arm matched");
                    });
                });
                });
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start Escaped, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_escaped(crate::check::expr::Env env, crate::check::types::St st, Array<Text> rigids, crate::check::types::Ty rt, Text fname, crate::syntax::Range span) {
    return prism_rtl::make_rc<Escaped>(env, st, rigids, rt, fname, span);
}


/// HasRigid: unbounded fn St, Text, Ty -> Bool
bool has_rigid(const crate::check::types::St& st, const Text& r, const crate::check::types::Ty& t) {
    return rigid_in(r, crate::check::types::recording::zonk(st, t));
}


prism_rtl::Turn<bool> HasRigid::cycle() const {
    const auto& st = this->st;
    const auto& r = this->r;
    const auto& t = this->t;
    auto r_1 = r;
    auto st_2 = st;
    auto t_3 = t;
    return call_then(crate::check::types::recording::start_zonk(st_2, t_3), [=](crate::check::types::Ty zonk_7123) { return prism_rtl::finished(rigid_in(r_1, zonk_7123)); });
}


/// `Start HasRigid, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_has_rigid(crate::check::types::St st, Text r, crate::check::types::Ty t) {
    return prism_rtl::make_rc<HasRigid>(st, r, t);
}


/// RigidIn: fn Text, Ty -> Bool
bool rigid_in(const Text& r, const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TyRigid>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyRigid>(t).a0;
        return n == r;
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        return fold(args, false, [&](const bool& seen, const crate::check::types::Ty& a) { return prism_rtl::val(seen) || rigid_in(r, a); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t)) {
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        return fold(ps, rigid_in(r, prism_rtl::val(prism_rtl::val(res))), [&](const bool& seen, const crate::check::types::Ty& a) { return prism_rtl::val(seen) || rigid_in(r, a); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        return fold(ts, false, [&](const bool& seen, const crate::check::types::Ty& a) { return prism_rtl::val(seen) || rigid_in(r, a); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        return rigid_in(r, prism_rtl::val(prism_rtl::val(e)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        return rigid_in(r, prism_rtl::val(prism_rtl::val(k))) || rigid_in(r, prism_rtl::val(prism_rtl::val(v_)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        return rigid_in(r, prism_rtl::val(prism_rtl::val(i)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a0;
        return rigid_in(r, prism_rtl::val(prism_rtl::val(i)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t)) {
        auto&& o = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a1;
        return rigid_in(r, prism_rtl::val(prism_rtl::val(o)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t).a1;
        return rigid_in(r, prism_rtl::val(prism_rtl::val(i)));
    }
    {
        return false;
    }
}


/// IsLocalMaker: fn Text -> Bool
bool is_local_maker(const Text& qk) {
    return crate::check::types::has_text(Array(std::vector{Text::lit("Buffer.Numbered"), Text::lit("Buffer.Empty"), Text::lit("Table.Empty")}), qk);
}


/// LocalOutside: fn St, Text, Range -> St
crate::check::types::St local_outside(const crate::check::types::St& st, const Text& qk, const crate::syntax::Range& span) {
    return crate::check::types::recording::err_fix(st, Text::lit("local-escapes"), span, prism_rtl::cat("a `", or_(index(split_on(qk, Text::lit(".")), Nat(0u)), qk), "` lives only in an `&` block\'s local"), prism_rtl::cat("make it inside `update ...:` as `let &b = ", qk, " ...`, and `Freeze &b` for the plain value"));
}


/// NoteCallee: fn St, Range, Range, Ty -> St
crate::check::types::St note_callee(const crate::check::types::St& st, const crate::syntax::Range& at_, const crate::syntax::Range& cspan, const crate::check::types::Ty& t) {
    return at_ == cspan
        ? crate::check::types::recording::note_ty(st, at_, t)
        : crate::check::types::recording::note_ty(crate::check::types::recording::note_ty(st, at_, t), cspan, t);
}


/// NoteMethodUse: fn St, ValInfo, Range -> St
crate::check::types::St note_method_use(const crate::check::types::St& st, const crate::check::env::ValInfo& v_, const crate::syntax::Range& span) {
    return v_.sort != Text::lit("method")
        ? st
        : ({
        auto&& _cls = or_(index(prism_rtl::val(v_.scheme).bounds, Nat(0u)), std::tuple{Text::lit(""), Text::lit("")});
        auto&& cls = std::get<1>(_cls);
        (crate::check::types::recording::note_method(st, span, v_.qk, cls));
    });
}


/// FoldApp: unbounded fn Env, St, Ty, [Arg], Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> fold_app(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::check::types::Ty& t, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span) {
    auto lambda_arity_ = ({
        __label__ _done;
        prism_rtl::Slot<Nat> _v;
        auto&& _m = index(args, Nat(2u));
        if (prism_rtl::is_some(_m)) {
            auto&& a = prism_rtl::some_of(_m);
            _v.set(lambda_arity(a->value));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Nat(2u));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return lambda_arity_ == Nat(3u)
        ? ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
        auto&& _m = crate::check::types::recording::walk(st, t);
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& col = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0;
            auto&& params = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
            _v.set(({
                auto [k, st1] = crate::check::types::fresh_var(st, false, Text::lit(""));
                auto [v_, st2] = crate::check::types::fresh_var(st1, false, Text::lit(""));
                auto [b, st3] = crate::check::types::fresh_var(st2, false, Text::lit(""));
                auto step_col = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::check::types::Col> _v;
                    auto&& _m = index(params, Nat(2u));
                    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::check::types::Ty::TyFn>(prism_rtl::some_of(_m))) {
                        auto&& c = prism_rtl::as<crate::check::types::Ty::TyFn>(prism_rtl::some_of(_m)).a0;
                        _v.set(c);
                        goto _done;
                    }
                    {
                        _v.set(col);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto params2 = Array(std::vector{crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(k), prism_rtl::rc(v_)}), b, crate::check::types::Ty(crate::check::types::Ty::TyFn{step_col, Array(std::vector{b, k, v_}), prism_rtl::rc(b)})});
                apply_rule(env, st3, Text::lit("Fold"), col, params2, b, args, span);
            }));
            goto _done;
        }
        {
            _v.set(apply_fn(env, st, Text::lit("Fold"), t, args, span));
            goto _done;
        }
    _done:
        _v.take();
    })
        : apply_fn(env, st, Text::lit("Fold"), t, args, span);
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> FoldApp::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& t = this->t;
    const auto& args = this->args;
    const auto& span = this->span;
    auto lambda_arity_ = ({
        __label__ _done;
        prism_rtl::Slot<Nat> _v;
        auto&& _m = index(args, Nat(2u));
        if (prism_rtl::is_some(_m)) {
            auto&& a = prism_rtl::some_of(_m);
            _v.set(lambda_arity(a->value));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Nat(2u));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return lambda_arity_ == Nat(3u)
        ? ({
        auto args_1 = args;
        auto env_2 = env;
        auto span_3 = span;
        auto st_4 = st;
        auto t_5 = t;
        call_then(crate::check::types::recording::start_walk(st_4, t_5), [=](crate::check::types::Ty walk_9063) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyFn>(walk_9063) ? ({
            auto&& col = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_9063).a0;
            auto&& params = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_9063).a1;
            auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_9063).a2;
            ({
            auto [k, st1] = crate::check::types::fresh_var(st_4, false, Text::lit(""));
            auto [v_, st2] = crate::check::types::fresh_var(st1, false, Text::lit(""));
            auto [b, st3] = crate::check::types::fresh_var(st2, false, Text::lit(""));
            auto step_col = ({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::Col> _v;
                auto&& _m = index(params, Nat(2u));
                if (prism_rtl::is_some(_m) && prism_rtl::is<crate::check::types::Ty::TyFn>(prism_rtl::some_of(_m))) {
                    auto&& c = prism_rtl::as<crate::check::types::Ty::TyFn>(prism_rtl::some_of(_m)).a0;
                    _v.set(c);
                    goto _done;
                }
                {
                    _v.set(col);
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto params2 = Array(std::vector{crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(k), prism_rtl::rc(v_)}), b, crate::check::types::Ty(crate::check::types::Ty::TyFn{step_col, Array(std::vector{b, k, v_}), prism_rtl::rc(b)})});
            (prism_rtl::more(prism_rtl::rc(ApplyRule(env_2, st3, Text::lit("Fold"), col, params2, b, args_1, span_3))));
        });
        })
            : prism_rtl::more(prism_rtl::rc(ApplyFn(env_2, st_4, Text::lit("Fold"), t_5, args_1, span_3)));
        });
    });
    })
        : prism_rtl::more(prism_rtl::rc(ApplyFn(env, st, Text::lit("Fold"), t, args, span)));
}


/// `Start FoldApp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_fold_app(crate::check::expr::Env env, crate::check::types::St st, crate::check::types::Ty t, Array<crate::syntax::Arg> args, crate::syntax::Range span) {
    return prism_rtl::make_rc<FoldApp>(env, st, t, args, span);
}


/// ApplyFn: unbounded fn Env, St, Text, Ty, [Arg], Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> apply_fn(const crate::check::expr::Env& env, const crate::check::types::St& st, const Text& fname, const crate::check::types::Ty& fty, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span) {
    auto named_ = filter(args, [&](const crate::syntax::Arg& a) { return prism_rtl::val(a).name != std::optional<crate::syntax::Ident>{}; });
    auto st0 = len(named_) > Nat(0u)
        ? crate::check::types::recording::err(st, Text::lit("mismatch"), span, prism_rtl::cat("`", fname, "` takes its arguments by position; named arguments are a record\'s or a tag\'s"))
        : st;
    auto&& _m = crate::check::types::recording::walk(st0, fty);
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
        auto&& col = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0;
        auto&& params = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
        auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
        return len(params) != len(args)
            ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st0, Text::lit("mismatch"), span, prism_rtl::cat("`", fname, "` takes ", crate::check::errors::count_word(len(params)), " argument", len(params) == Nat(1u) ? Text::lit("") : Text::lit("s"), "; here it has ", crate::check::errors::count_word(len(args))))}
            : apply_rule(env, st0, fname, col, params, prism_rtl::val(res), args, span);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(_m)) {
        auto [params, st1] = fold(args, std::tuple{Array<crate::check::types::Ty>{}, st0}, [&](const std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>& _p0, const crate::syntax::Arg& _p1) {
            auto&& acc = std::get<0>(_p0);
            auto&& s = std::get<1>(_p0);
            return ({
                auto [v_, s2] = crate::check::types::fresh_var(s, false, Text::lit(""));
                std::tuple{crate::prelude::push(acc, v_), s2};
            });
        });
        auto [res, st2] = crate::check::types::fresh_var(st1, false, Text::lit(""));
        auto [col, st2b] = crate::check::types::fresh_col(st2);
        auto st3 = crate::check::types::unify::unify(st2b, fty, crate::check::types::Ty(crate::check::types::Ty::TyFn{col, params, prism_rtl::rc(res)}), span);
        return apply_rule(env, st3, fname, col, params, res, args, span);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyErr>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), st0};
    }
    {
        auto&& other = _m;
        return len(args) == Nat(0u)
            ? std::tuple{other, st0}
            : std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st0, Text::lit("mismatch"), span, prism_rtl::cat("`", fname, "` is a `", crate::check::types::show_ty(st0, other), "`, not a function"))};
    }
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> ApplyFn::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& fname = this->fname;
    const auto& fty = this->fty;
    const auto& args = this->args;
    const auto& span = this->span;
    auto named_ = filter(args, [&](const crate::syntax::Arg& a) { return prism_rtl::val(a).name != std::optional<crate::syntax::Ident>{}; });
    auto st0 = len(named_) > Nat(0u)
        ? crate::check::types::recording::err(st, Text::lit("mismatch"), span, prism_rtl::cat("`", fname, "` takes its arguments by position; named arguments are a record\'s or a tag\'s"))
        : st;
    auto args_1 = args;
    auto env_2 = env;
    auto fname_3 = fname;
    auto fty_4 = fty;
    auto span_5 = span;
    return call_then(crate::check::types::recording::start_walk(st0, fty_4), [=](crate::check::types::Ty walk_10097) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyFn>(walk_10097) ? ({
            auto&& col = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_10097).a0;
            auto&& params = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_10097).a1;
            auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_10097).a2;
            len(params) != len(args_1)
            ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st0, Text::lit("mismatch"), span_5, prism_rtl::cat("`", fname_3, "` takes ", crate::check::errors::count_word(len(params)), " argument", len(params) == Nat(1u) ? Text::lit("") : Text::lit("s"), "; here it has ", crate::check::errors::count_word(len(args_1))))})
            : prism_rtl::more(prism_rtl::rc(ApplyRule(env_2, st0, fname_3, col, params, prism_rtl::val(res), args_1, span_5)));
        })
            : prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_10097) ? ({
            auto [params, st1] = fold(args_1, std::tuple{Array<crate::check::types::Ty>{}, st0}, [&](const std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>& _p0, const crate::syntax::Arg& _p1) {
                auto&& acc = std::get<0>(_p0);
                auto&& s = std::get<1>(_p0);
                return ({
                    auto [v_, s2] = crate::check::types::fresh_var(s, false, Text::lit(""));
                    std::tuple{crate::prelude::push(acc, v_), s2};
                });
            });
            auto [res, st2] = crate::check::types::fresh_var(st1, false, Text::lit(""));
            auto [col, st2b] = crate::check::types::fresh_col(st2);
            call_then(crate::check::types::unify::start_unify(st2b, fty_4, crate::check::types::Ty(crate::check::types::Ty::TyFn{col, params, prism_rtl::rc(res)}), span_5), [=](crate::check::types::St unify_10759) {
            return ({
                auto st3 = unify_10759;
                (prism_rtl::more(prism_rtl::rc(ApplyRule(env_2, st3, fname_3, col, params, res, args_1, span_5))));
            });
        });
        })
            : prism_rtl::is<crate::check::types::Ty::TyErr>(walk_10097) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), st0})
            : ({
            auto&& other = walk_10097;
            len(args_1) == Nat(0u)
            ? prism_rtl::finished(std::tuple{other, st0})
            : call_then(crate::check::types::start_show_ty(st0, other), [=](Text show_ty_11039) { return prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st0, Text::lit("mismatch"), span_5, prism_rtl::cat("`", fname_3, "` is a `", show_ty_11039, "`, not a function"))}); });
        });
        });
    });
}


/// `Start ApplyFn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_apply_fn(crate::check::expr::Env env, crate::check::types::St st, Text fname, crate::check::types::Ty fty, Array<crate::syntax::Arg> args, crate::syntax::Range span) {
    return prism_rtl::make_rc<ApplyFn>(env, st, fname, fty, args, span);
}


/// Broken: fn Peeled, Bool -> Peeled
Peeled broken(const Peeled& p_, const bool& b) {
    return !prism_rtl::val(b)
        ? p_
        : ({
        Peeled this_ = p_;
        this_.broken = true;
        this_;
    });
}


/// ApplyRule: unbounded fn Env, St, Text, Col, [Ty], Ty, [Arg], Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> apply_rule(const crate::check::expr::Env& env, const crate::check::types::St& st, const Text& fname, const crate::check::types::Col& col, const Array<crate::check::types::Ty>& params, const crate::check::types::Ty& res, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span) {
    auto n = len(args);
    auto cmp = crate::check::expr::is_comparison(fname);
    auto [arg_tys, st1] = run_to_end(fold_job(crate::check::errors::range0(n), std::tuple{Array<crate::check::types::Ty>{}, st}, ({
        auto args_1 = args;
        auto span_2 = span;
        auto env_3 = env;
        auto params_4 = params;
        auto fname_5 = fname;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto args_1_6 = args_1;
            auto span_2_6 = span_2;
            auto env_3_6 = env_3;
            auto params_4_6 = params_4;
            auto fname_5_6 = fname_5;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto i = p1;
                ({
                auto a = or_(index(args_1_6, i), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span_2_6}, .span = span_2_6});
                (crate::check::expr::is_lambda(a->value)
                ? prism_rtl::finished(std::tuple{crate::prelude::push(acc, crate::check::types::Ty(crate::check::types::Ty::TyErr{})), s})
                : call_then(crate::check::expr::start_infer(env_3_6, s, a->value), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_12500) {
                return ({
                    auto [t, s2] = infer_12500;
                    call_then(crate::check::types::recording::start_walk(s2, or_(index(params_4_6, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::check::types::Ty walk_12543) {
                    return call_then(crate::check::types::recording::start_walk(s2, t), [=](crate::check::types::Ty walk_12577) {
                        return ({
                            auto&& _m = std::tuple{walk_12543, walk_12577};
                            prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<1>(_m)) ? ({
                            auto&& pc = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<0>(_m)).a0;
                            auto&& ac = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a0;
                            auto&& aps = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a1;
                            auto&& ar = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a2;
                            call_then(crate::check::types::colors::start_add_leq(s2, ac, pc, prism_rtl::val(a->value).span, Text::lit("arg"), fname_5_6, Text::lit("")), [=](crate::check::types::St add_leq_12694) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc, crate::check::types::Ty(crate::check::types::Ty::TyFn{pc, aps, prism_rtl::rc(prism_rtl::val(ar))})), add_leq_12694}); });
                        })
                            : prism_rtl::finished(std::tuple{crate::prelude::push(acc, t), s2});
                        });
                    });
                });
                });
            }));
            });
            });
        }));
        });
    }));
    })));
    auto [st2, whole] = run_to_end(fold_job(crate::check::errors::range0(n), std::tuple{st1, Array<Nat>{}}, ({
        auto args_1 = args;
        auto span_2 = span;
        auto arg_tys_3 = arg_tys;
        auto params_4 = params;
        auto env_5 = env;
        auto fname_6 = fname;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::types::St, Array<Nat>>>(std::tuple<std::tuple<crate::check::types::St, Array<Nat>>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::types::St, Array<Nat>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto args_1_7 = args_1;
            auto span_2_7 = span_2;
            auto arg_tys_3_7 = arg_tys_3;
            auto params_4_7 = params_4;
            auto env_5_7 = env_5;
            auto fname_6_7 = fname_6;
            entered(once_job([=]() {
            return ({
                auto [s, done] = p0;
                auto i = p1;
                ({
                auto a = or_(index(args_1_7, i), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span_2_7}, .span = span_2_7});
                auto at_ = or_(index(arg_tys_3_7, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
                call_then(crate::check::types::recording::start_walk(s, or_(index(params_4_7, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::check::types::Ty walk_13016) {
                return ({
                    auto pnow = walk_13016;
                    call_then(crate::check::types::start_head_sigil(s, pnow), [=](Text head_sigil_13083) {
                    return ({
                        auto whole_now = crate::check::expr::is_time_sigil(head_sigil_13083) || (crate::check::types::head_sigil(s, pnow) == Text::lit("@"));
                        (crate::check::expr::is_lambda(a->value)
                        ? prism_rtl::finished(std::tuple{s, done})
                        : whole_now && (crate::check::types::stack_of(s, at_) != Text::lit(""))
                        ? call_then(crate::check::types::unify::start_unify(s, pnow, at_, prism_rtl::val(a->value).span), [=](crate::check::types::St unify_13230) { return prism_rtl::finished(std::tuple{unify_13230, crate::prelude::push(done, i)}); })
                        : call_then(crate::check::types::start_stack_of(s, at_), [=](Text stack_of_13299) {
                        return (stack_of_13299 != Text::lit("")) || crate::check::types::is_free_headed(s, at_)
                            ? prism_rtl::finished(std::tuple{s, done})
                            : call_then(start_plain_arg(env_5_7, s, fname_6_7, or_(index(params_4_7, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), at_, a), [=](crate::check::types::St plain_arg_13374) { return prism_rtl::finished(std::tuple{plain_arg_13374, done}); });
                    }));
                    });
                });
                });
            });
            });
            });
        }));
        });
    }));
    })));
    auto&& _st3 = run_to_end(fold_job(crate::check::errors::range0(n), std::tuple{Map<Unit, Unit>{}, st2}, ({
        auto args_1 = args;
        auto span_2 = span;
        auto params_3 = params;
        auto env_4 = env;
        auto fname_5 = fname;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Unit, Unit>, crate::check::types::St>>(std::tuple<std::tuple<Map<Unit, Unit>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Map<Unit, Unit>, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto args_1_6 = args_1;
            auto span_2_6 = span_2;
            auto params_3_6 = params_3;
            auto env_4_6 = env_4;
            auto fname_5_6 = fname_5;
            entered(once_job([=]() {
            return ({
                auto [m, s] = p0;
                auto i = p1;
                ({
                auto a = or_(index(args_1_6, i), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span_2_6}, .span = span_2_6});
                (crate::check::expr::is_lambda(a->value)
                ? call_then(crate::check::types::recording::start_walk(s, or_(index(params_3_6, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::check::types::Ty walk_13645) {
                return ({
                    auto p_ = walk_13645;
                    call_then(start_infer_lambda(env_4_6, s, a->value, std::optional(p_)), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_lambda_13704) {
                    return ({
                        auto [lt, s2] = infer_lambda_13704;
                        auto s3 = ({
                            __label__ _done;
                            prism_rtl::Slot<crate::check::types::St> _v;
                            auto&& _m = std::tuple{p_, lt};
                            if (prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<1>(_m))) {
                                auto&& pc = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<0>(_m)).a0;
                                auto&& lc = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a0;
                                auto&& lps = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a1;
                                auto&& lr = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a2;
                                _v.set(crate::check::types::colors::add_leq(crate::check::types::unify::unify(crate::check::types::recording::note_ty(s2, prism_rtl::val(a->value).span, lt), p_, crate::check::types::Ty(crate::check::types::Ty::TyFn{pc, lps, prism_rtl::rc(prism_rtl::val(lr))}), prism_rtl::val(a->value).span), lc, pc, prism_rtl::val(a->value).span, Text::lit("arg"), fname_5_6, Text::lit("")));
                                goto _done;
                            }
                            {
                                _v.set(crate::check::types::unify::unify(crate::check::types::recording::note_ty(s2, prism_rtl::val(a->value).span, lt), p_, lt, prism_rtl::val(a->value).span));
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                        (prism_rtl::finished(std::tuple{m, s3}));
                    });
                });
                });
            })
                : prism_rtl::finished(std::tuple{m, s}));
            });
            });
        }));
        });
    }));
    })));
    auto&& st3 = std::get<1>(_st3);
    auto [pl, st4] = run_to_end(fold_job(crate::check::errors::range0(n), std::tuple{Peeled{.events = Array<crate::syntax::Range>{}, .dyns = Array<crate::syntax::Range>{}, .opts = Array<Text>{}, .opt_args = Array<crate::syntax::Range>{}, .lifted = Text::lit(""), .broken = false}, st3}, ({
        auto args_1 = args;
        auto span_2 = span;
        auto arg_tys_3 = arg_tys;
        auto whole_4 = whole;
        auto env_5 = env;
        auto fname_6 = fname;
        auto cmp_7 = cmp;
        auto params_8 = params;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Peeled, crate::check::types::St>>(std::tuple<std::tuple<Peeled, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Peeled, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto args_1_9 = args_1;
            auto span_2_9 = span_2;
            auto arg_tys_3_9 = arg_tys_3;
            auto whole_4_9 = whole_4;
            auto env_5_9 = env_5;
            auto fname_6_9 = fname_6;
            auto cmp_7_9 = cmp_7;
            auto params_8_9 = params_8;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto i = p1;
                ({
                auto a = or_(index(args_1_9, i), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span_2_9}, .span = span_2_9});
                auto at_ = or_(index(arg_tys_3_9, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
                (crate::check::expr::is_lambda(a->value) || crate::check::types::has_nat(whole_4_9, i)) || ((crate::check::types::stack_of(s, at_) == Text::lit("")) && (!crate::check::types::is_free_headed(s, at_)))
                ? prism_rtl::finished(std::tuple{acc, s})
                : ({
                auto before_ = len(prism_rtl::val(s).diags);
                call_then(start_layered_arg(env_5_9, s, acc, fname_6_9, cmp_7_9, or_(index(params_8_9, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), at_, a), [=](std::tuple<Peeled, crate::check::types::St> layered_arg_14569) {
                return ({
                    auto [acc2, s2] = layered_arg_14569;
                    auto broke = (len(prism_rtl::val(s2).diags) > before_) && fold(drop(prism_rtl::val(s2).diags, before_), false, [&](const bool& seen, const crate::check::errors::CDiag& d) { return prism_rtl::val(seen) || crate::check::types::has_text(Array(std::vector{Text::lit("two-layers"), Text::lit("layer-under-optional"), Text::lit("blueprint-operand")}), prism_rtl::val(d).code); });
                    (prism_rtl::finished(std::tuple{broken(acc2, broke), s2}));
                });
            });
            });
            });
            });
        }));
        });
    }));
    })));
    auto st5 = len(prism_rtl::val(pl).events) > Nat(1u)
        ? crate::check::types::recording::err_fix(st4, Text::lit("two-events"), or_(index(prism_rtl::val(pl).events, Nat(1u)), span), Text::lit("two events in one operation"), Text::lit("merge them with `<|`, or hold one first, `$last <- 0 then !b`"))
        : st4;
    auto st6 = len(pl->opts) > Nat(1u)
        ? crate::check::types::recording::err(st5, Text::lit("optional-and-fault"), span, Text::lit("`?` and `~` in one operation"))
        : st5;
    auto layer = len(prism_rtl::val(pl).events) > Nat(0u)
        ? Text::lit("!")
        : len(prism_rtl::val(pl).dyns) > Nat(0u) ? Text::lit("$") : Text::lit("");
    auto with_opt = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::Ty> _v;
        auto&& _m = index(pl->opts, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& o = prism_rtl::some_of(_m);
            _v.set(crate::check::types::Ty(crate::check::types::Ty::TySig{o, prism_rtl::rc(res)}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(res);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto result = prism_rtl::val(pl).broken
        ? crate::check::types::Ty(crate::check::types::Ty::TyErr{})
        : layer == Text::lit("")
        ? with_opt
        : crate::check::types::Ty(crate::check::types::Ty::TySig{layer, prism_rtl::rc(with_opt)});
    auto call_col = crate::check::types::colors::walk_col(st6, col);
    auto st7 = (layer != Text::lit("")) && crate::check::types::colors::is_flex_col(call_col)
        ? crate::check::types::colors::add_leq(st6, call_col, crate::check::types::Col(crate::check::types::Col::CBound{}), span, Text::lit("lifted"), fname, prism_rtl::val(pl).lifted)
        : st6;
    auto lifted_bad = ((layer != Text::lit("")) && (call_col != crate::check::types::Col(crate::check::types::Col::CBound{}))) && (!crate::check::types::colors::is_flex_col(call_col));
    auto st8 = lifted_bad
        ? crate::check::types::recording::err_fix(st7, Text::lit("lifted-unbounded"), span, prism_rtl::cat(crate::check::types::colors::col_word(call_col), " `", fname, "` lifted over `", prism_rtl::val(pl).lifted, "`; use `@Run`"), prism_rtl::cat("run it through `!done <- @Run ", fname, ", ...`"))
        : st7;
    auto st9 = crate::check::types::colors::use_color(st8, call_col, fname, span);
    auto kind = (layer == Text::lit("!")) && (len(prism_rtl::val(pl).dyns) > Nat(0u))
        ? Text::lit("sample")
        : layer != Text::lit("")
        ? Text::lit("map")
        : fname == Text::lit("$") ? Text::lit("const") : Text::lit("plain");
    auto peeled = append(prism_rtl::val(pl).events, prism_rtl::val(pl).dyns);
    auto lifted = filter(crate::check::errors::range0(n), [&](const Nat& i) { return has_range(peeled, prism_rtl::val(or_(index(args, i), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span}, .span = span})->value).span); });
    auto st10 = prism_rtl::val(pl).broken || (len(pl->opts) != Nat(1u))
        ? st9
        : crate::check::types::recording::note_lift(st9, span, or_(index(pl->opts, Nat(0u)), Text::lit("")), prism_rtl::val(pl).opt_args);
    return std::tuple{result, crate::check::types::recording::note_app(st10, span, fname, kind, layer, lifted, or_(index(pl->opts, Nat(0u)), Text::lit("")), call_col)};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> ApplyRule::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& fname = this->fname;
    const auto& col = this->col;
    const auto& params = this->params;
    const auto& res = this->res;
    const auto& args = this->args;
    const auto& span = this->span;
    auto n = len(args);
    auto cmp = crate::check::expr::is_comparison(fname);
    auto args_1 = args;
    auto col_2 = col;
    auto env_3 = env;
    auto fname_4 = fname;
    auto params_5 = params;
    auto res_6 = res;
    auto span_7 = span;
    auto st_8 = st;
    return call_value(fold_job(crate::check::errors::range0(n), std::tuple{Array<crate::check::types::Ty>{}, st_8}, ({
        auto args_1_9 = args_1;
        auto span_7_9 = span_7;
        auto env_3_9 = env_3;
        auto params_5_9 = params_5;
        auto fname_4_9 = fname_4;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto args_1_9_9 = args_1_9;
            auto span_7_9_9 = span_7_9;
            auto env_3_9_9 = env_3_9;
            auto params_5_9_9 = params_5_9;
            auto fname_4_9_9 = fname_4_9;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto i = p1;
                ({
                auto a = or_(index(args_1_9_9, i), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span_7_9_9}, .span = span_7_9_9});
                (crate::check::expr::is_lambda(a->value)
                ? prism_rtl::finished(std::tuple{crate::prelude::push(acc, crate::check::types::Ty(crate::check::types::Ty::TyErr{})), s})
                : call_then(crate::check::expr::start_infer(env_3_9_9, s, a->value), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_12500) {
                return ({
                    auto [t, s2] = infer_12500;
                    call_then(crate::check::types::recording::start_walk(s2, or_(index(params_5_9_9, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::check::types::Ty walk_12543) {
                    return call_then(crate::check::types::recording::start_walk(s2, t), [=](crate::check::types::Ty walk_12577) {
                        return ({
                            auto&& _m = std::tuple{walk_12543, walk_12577};
                            prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<1>(_m)) ? ({
                            auto&& pc = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<0>(_m)).a0;
                            auto&& ac = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a0;
                            auto&& aps = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a1;
                            auto&& ar = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a2;
                            call_then(crate::check::types::colors::start_add_leq(s2, ac, pc, prism_rtl::val(a->value).span, Text::lit("arg"), fname_4_9_9, Text::lit("")), [=](crate::check::types::St add_leq_12694) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc, crate::check::types::Ty(crate::check::types::Ty::TyFn{pc, aps, prism_rtl::rc(prism_rtl::val(ar))})), add_leq_12694}); });
                        })
                            : prism_rtl::finished(std::tuple{crate::prelude::push(acc, t), s2});
                        });
                    });
                });
                });
            }));
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> fold_12267) {
        return ({
            auto [arg_tys, st1] = fold_12267;
            call_value(fold_job(crate::check::errors::range0(n), std::tuple{st1, Array<Nat>{}}, ({
            auto args_1_9 = args_1;
            auto span_7_9 = span_7;
            auto arg_tys_9 = arg_tys;
            auto params_5_10 = params_5;
            auto env_3_10 = env_3;
            auto fname_4_10 = fname_4;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::types::St, Array<Nat>>>(std::tuple<std::tuple<crate::check::types::St, Array<Nat>>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::types::St, Array<Nat>>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto args_1_9_10 = args_1_9;
                auto span_7_9_10 = span_7_9;
                auto arg_tys_9_10 = arg_tys_9;
                auto params_5_10_10 = params_5_10;
                auto env_3_10_10 = env_3_10;
                auto fname_4_10_10 = fname_4_10;
                entered(once_job([=]() {
                return ({
                    auto [s, done] = p0;
                    auto i = p1;
                    ({
                    auto a = or_(index(args_1_9_10, i), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span_7_9_10}, .span = span_7_9_10});
                    auto at_ = or_(index(arg_tys_9_10, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
                    call_then(crate::check::types::recording::start_walk(s, or_(index(params_5_10_10, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::check::types::Ty walk_13016) {
                    return ({
                        auto pnow = walk_13016;
                        call_then(crate::check::types::start_head_sigil(s, pnow), [=](Text head_sigil_13083) {
                        return ({
                            auto whole_now = crate::check::expr::is_time_sigil(head_sigil_13083) || (crate::check::types::head_sigil(s, pnow) == Text::lit("@"));
                            (crate::check::expr::is_lambda(a->value)
                            ? prism_rtl::finished(std::tuple{s, done})
                            : whole_now && (crate::check::types::stack_of(s, at_) != Text::lit(""))
                            ? call_then(crate::check::types::unify::start_unify(s, pnow, at_, prism_rtl::val(a->value).span), [=](crate::check::types::St unify_13230) { return prism_rtl::finished(std::tuple{unify_13230, crate::prelude::push(done, i)}); })
                            : call_then(crate::check::types::start_stack_of(s, at_), [=](Text stack_of_13299) {
                            return (stack_of_13299 != Text::lit("")) || crate::check::types::is_free_headed(s, at_)
                                ? prism_rtl::finished(std::tuple{s, done})
                                : call_then(start_plain_arg(env_3_10_10, s, fname_4_10_10, or_(index(params_5_10_10, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), at_, a), [=](crate::check::types::St plain_arg_13374) { return prism_rtl::finished(std::tuple{plain_arg_13374, done}); });
                        }));
                        });
                    });
                    });
                });
                });
                });
            }));
            });
        }));
        })), [=](std::tuple<crate::check::types::St, Array<Nat>> fold_12821) {
            return ({
                auto [st2, whole] = fold_12821;
                call_value(fold_job(crate::check::errors::range0(n), std::tuple{Map<Unit, Unit>{}, st2}, ({
                auto args_1_9 = args_1;
                auto span_7_9 = span_7;
                auto params_5_9 = params_5;
                auto env_3_9 = env_3;
                auto fname_4_9 = fname_4;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Unit, Unit>, crate::check::types::St>>(std::tuple<std::tuple<Map<Unit, Unit>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Map<Unit, Unit>, crate::check::types::St>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto args_1_9_9 = args_1_9;
                    auto span_7_9_9 = span_7_9;
                    auto params_5_9_9 = params_5_9;
                    auto env_3_9_9 = env_3_9;
                    auto fname_4_9_9 = fname_4_9;
                    entered(once_job([=]() {
                    return ({
                        auto [m, s] = p0;
                        auto i = p1;
                        ({
                        auto a = or_(index(args_1_9_9, i), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span_7_9_9}, .span = span_7_9_9});
                        (crate::check::expr::is_lambda(a->value)
                        ? call_then(crate::check::types::recording::start_walk(s, or_(index(params_5_9_9, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::check::types::Ty walk_13645) {
                        return ({
                            auto p_ = walk_13645;
                            call_then(start_infer_lambda(env_3_9_9, s, a->value, std::optional(p_)), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_lambda_13704) {
                            return ({
                                auto [lt, s2] = infer_lambda_13704;
                                auto s3 = ({
                                    __label__ _done;
                                    prism_rtl::Slot<crate::check::types::St> _v;
                                    auto&& _m = std::tuple{p_, lt};
                                    if (prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<1>(_m))) {
                                        auto&& pc = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<0>(_m)).a0;
                                        auto&& lc = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a0;
                                        auto&& lps = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a1;
                                        auto&& lr = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a2;
                                        _v.set(crate::check::types::colors::add_leq(crate::check::types::unify::unify(crate::check::types::recording::note_ty(s2, prism_rtl::val(a->value).span, lt), p_, crate::check::types::Ty(crate::check::types::Ty::TyFn{pc, lps, prism_rtl::rc(prism_rtl::val(lr))}), prism_rtl::val(a->value).span), lc, pc, prism_rtl::val(a->value).span, Text::lit("arg"), fname_4_9_9, Text::lit("")));
                                        goto _done;
                                    }
                                    {
                                        _v.set(crate::check::types::unify::unify(crate::check::types::recording::note_ty(s2, prism_rtl::val(a->value).span, lt), p_, lt, prism_rtl::val(a->value).span));
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                });
                                (prism_rtl::finished(std::tuple{m, s3}));
                            });
                        });
                        });
                    })
                        : prism_rtl::finished(std::tuple{m, s}));
                    });
                    });
                }));
                });
            }));
            })), [=](std::tuple<Map<Unit, Unit>, crate::check::types::St> fold_13462) {
                return ({
                    auto&& _st3 = fold_13462;
                    auto&& st3 = std::get<1>(_st3);
                    call_value(fold_job(crate::check::errors::range0(n), std::tuple{Peeled{.events = Array<crate::syntax::Range>{}, .dyns = Array<crate::syntax::Range>{}, .opts = Array<Text>{}, .opt_args = Array<crate::syntax::Range>{}, .lifted = Text::lit(""), .broken = false}, st3}, ({
                    auto args_1_9 = args_1;
                    auto span_7_9 = span_7;
                    auto arg_tys_9 = arg_tys;
                    auto whole_10 = whole;
                    auto env_3_11 = env_3;
                    auto fname_4_11 = fname_4;
                    auto cmp_11 = cmp;
                    auto params_5_12 = params_5;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Peeled, crate::check::types::St>>(std::tuple<std::tuple<Peeled, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Peeled, crate::check::types::St>, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto args_1_9_12 = args_1_9;
                        auto span_7_9_12 = span_7_9;
                        auto arg_tys_9_12 = arg_tys_9;
                        auto whole_10_12 = whole_10;
                        auto env_3_11_12 = env_3_11;
                        auto fname_4_11_12 = fname_4_11;
                        auto cmp_11_12 = cmp_11;
                        auto params_5_12_12 = params_5_12;
                        entered(once_job([=]() {
                        return ({
                            auto [acc, s] = p0;
                            auto i = p1;
                            ({
                            auto a = or_(index(args_1_9_12, i), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span_7_9_12}, .span = span_7_9_12});
                            auto at_ = or_(index(arg_tys_9_12, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
                            (crate::check::expr::is_lambda(a->value) || crate::check::types::has_nat(whole_10_12, i)) || ((crate::check::types::stack_of(s, at_) == Text::lit("")) && (!crate::check::types::is_free_headed(s, at_)))
                            ? prism_rtl::finished(std::tuple{acc, s})
                            : ({
                            auto before_ = len(prism_rtl::val(s).diags);
                            call_then(start_layered_arg(env_3_11_12, s, acc, fname_4_11_12, cmp_11_12, or_(index(params_5_12_12, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), at_, a), [=](std::tuple<Peeled, crate::check::types::St> layered_arg_14569) {
                            return ({
                                auto [acc2, s2] = layered_arg_14569;
                                auto broke = (len(prism_rtl::val(s2).diags) > before_) && fold(drop(prism_rtl::val(s2).diags, before_), false, [&](const bool& seen, const crate::check::errors::CDiag& d) { return prism_rtl::val(seen) || crate::check::types::has_text(Array(std::vector{Text::lit("two-layers"), Text::lit("layer-under-optional"), Text::lit("blueprint-operand")}), prism_rtl::val(d).code); });
                                (prism_rtl::finished(std::tuple{broken(acc2, broke), s2}));
                            });
                        });
                        });
                        });
                        });
                    }));
                    });
                }));
                })), [=](std::tuple<Peeled, crate::check::types::St> fold_14117) {
                    return ({
                        auto [pl, st4] = fold_14117;
                        auto st5 = len(prism_rtl::val(pl).events) > Nat(1u)
                            ? crate::check::types::recording::err_fix(st4, Text::lit("two-events"), or_(index(prism_rtl::val(pl).events, Nat(1u)), span_7), Text::lit("two events in one operation"), Text::lit("merge them with `<|`, or hold one first, `$last <- 0 then !b`"))
                            : st4;
                        auto st6 = len(pl->opts) > Nat(1u)
                            ? crate::check::types::recording::err(st5, Text::lit("optional-and-fault"), span_7, Text::lit("`?` and `~` in one operation"))
                            : st5;
                        auto layer = len(prism_rtl::val(pl).events) > Nat(0u)
                            ? Text::lit("!")
                            : len(prism_rtl::val(pl).dyns) > Nat(0u) ? Text::lit("$") : Text::lit("");
                        auto with_opt = ({
                            __label__ _done;
                            prism_rtl::Slot<crate::check::types::Ty> _v;
                            auto&& _m = index(pl->opts, Nat(0u));
                            if (prism_rtl::is_some(_m)) {
                                auto&& o = prism_rtl::some_of(_m);
                                _v.set(crate::check::types::Ty(crate::check::types::Ty::TySig{o, prism_rtl::rc(res_6)}));
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(res_6);
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        });
                        auto result = prism_rtl::val(pl).broken
                            ? crate::check::types::Ty(crate::check::types::Ty::TyErr{})
                            : layer == Text::lit("")
                            ? with_opt
                            : crate::check::types::Ty(crate::check::types::Ty::TySig{layer, prism_rtl::rc(with_opt)});
                        call_then(crate::check::types::colors::start_walk_col(st6, col_2), [=](crate::check::types::Col walk_col_15617) {
                        return ({
                            auto call_col = walk_col_15617;
                            auto st7 = (layer != Text::lit("")) && crate::check::types::colors::is_flex_col(call_col)
                                ? crate::check::types::colors::add_leq(st6, call_col, crate::check::types::Col(crate::check::types::Col::CBound{}), span_7, Text::lit("lifted"), fname_4, prism_rtl::val(pl).lifted)
                                : st6;
                            auto lifted_bad = ((layer != Text::lit("")) && (call_col != crate::check::types::Col(crate::check::types::Col::CBound{}))) && (!crate::check::types::colors::is_flex_col(call_col));
                            auto st8 = lifted_bad
                                ? crate::check::types::recording::err_fix(st7, Text::lit("lifted-unbounded"), span_7, prism_rtl::cat(crate::check::types::colors::col_word(call_col), " `", fname_4, "` lifted over `", prism_rtl::val(pl).lifted, "`; use `@Run`"), prism_rtl::cat("run it through `!done <- @Run ", fname_4, ", ...`"))
                                : st7;
                            call_then(crate::check::types::colors::start_use_color(st8, call_col, fname_4, span_7), [=](crate::check::types::St use_color_16047) {
                            return ({
                                auto st9 = use_color_16047;
                                auto kind = (layer == Text::lit("!")) && (len(prism_rtl::val(pl).dyns) > Nat(0u))
                                    ? Text::lit("sample")
                                    : layer != Text::lit("")
                                    ? Text::lit("map")
                                    : fname_4 == Text::lit("$") ? Text::lit("const") : Text::lit("plain");
                                auto peeled = append(prism_rtl::val(pl).events, prism_rtl::val(pl).dyns);
                                auto lifted = filter(crate::check::errors::range0(n), [&](const Nat& i) { return has_range(peeled, prism_rtl::val(or_(index(args_1, i), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span_7}, .span = span_7})->value).span); });
                                auto st10 = prism_rtl::val(pl).broken || (len(pl->opts) != Nat(1u))
                                    ? st9
                                    : crate::check::types::recording::note_lift(st9, span_7, or_(index(pl->opts, Nat(0u)), Text::lit("")), prism_rtl::val(pl).opt_args);
                                (prism_rtl::finished(std::tuple{result, crate::check::types::recording::note_app(st10, span_7, fname_4, kind, layer, lifted, or_(index(pl->opts, Nat(0u)), Text::lit("")), call_col)}));
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start ApplyRule, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_apply_rule(crate::check::expr::Env env, crate::check::types::St st, Text fname, crate::check::types::Col col, Array<crate::check::types::Ty> params, crate::check::types::Ty res, Array<crate::syntax::Arg> args, crate::syntax::Range span) {
    return prism_rtl::make_rc<ApplyRule>(env, st, fname, col, params, res, args, span);
}


/// HasRange: fn [Range], Range -> Bool
bool has_range(const Array<crate::syntax::Range>& rs, const crate::syntax::Range& r) {
    return fold(rs, false, [&](const bool& seen, const crate::syntax::Range& x) { return prism_rtl::val(seen) || (x == r); });
}


/// Elab: fn St, Range, Text, Text, Text -> St
crate::check::types::St elab(const crate::check::types::St& st, const crate::syntax::Range& span, const Text& what, const Text& kind, const Text& layer) {
    return crate::check::types::recording::note_app(st, span, what, kind, layer, Array<Nat>{}, Text::lit(""), crate::check::types::Col(crate::check::types::Col::CBound{}));
}


/// PlainArg: unbounded fn Env, St, Text, Ty, Ty, Arg -> St
crate::check::types::St plain_arg(const crate::check::expr::Env& env, const crate::check::types::St& st, const Text& fname, const crate::check::types::Ty& param, const crate::check::types::Ty& at_, const crate::syntax::Arg& a) {
    auto p_ = crate::check::types::recording::walk(st, param);
    auto ph = crate::check::types::head_sigil(st, p_);
    return at_ == crate::check::types::Ty(crate::check::types::Ty::TyErr{})
        ? st
        : crate::check::expr::is_time_sigil(ph) || (ph == Text::lit("@"))
        ? ({
        auto shown = crate::check::types::is_flex_var(st, at_)
            ? crate::check::expr::src_text(env, prism_rtl::val(a.value).span)
            : crate::check::types::show_ty(st, at_);
        (crate::check::types::recording::err_fix(st, Text::lit("plain-for-sigiled"), prism_rtl::val(a.value).span, prism_rtl::cat("a plain `", shown, "` where `", fname, "` takes a `", crate::check::types::show_ty(st, p_), "`"), prism_rtl::cat("write `", ph, " ", crate::check::expr::src_text(env, prism_rtl::val(a.value).span), "`")));
    })
        : crate::check::types::unify::unify(st, p_, at_, prism_rtl::val(a.value).span);
}


prism_rtl::Turn<crate::check::types::St> PlainArg::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& fname = this->fname;
    const auto& param = this->param;
    const auto& at_ = this->at_;
    const auto& a = this->a;
    auto a_1 = a;
    auto at__2 = at_;
    auto env_3 = env;
    auto fname_4 = fname;
    auto param_5 = param;
    auto st_6 = st;
    return call_then(crate::check::types::recording::start_walk(st_6, param_5), [=](crate::check::types::Ty walk_17274) {
        return ({
            auto p_ = walk_17274;
            call_then(crate::check::types::start_head_sigil(st_6, p_), [=](Text head_sigil_17302) {
            return ({
                auto ph = head_sigil_17302;
                at__2 == crate::check::types::Ty(crate::check::types::Ty::TyErr{})
                ? prism_rtl::finished(st_6)
                : crate::check::expr::is_time_sigil(ph) || (ph == Text::lit("@"))
                ? call_then(crate::check::types::start_is_flex_var(st_6, at__2), [=](bool is_flex_var_17408) {
                return ({
                    auto shown = is_flex_var_17408
                        ? crate::check::expr::src_text(env_3, prism_rtl::val(a_1->value).span)
                        : crate::check::types::show_ty(st_6, at__2);
                    call_then(crate::check::types::start_show_ty(st_6, p_), [=](Text show_ty_17571) { return prism_rtl::finished(crate::check::types::recording::err_fix(st_6, Text::lit("plain-for-sigiled"), prism_rtl::val(a_1->value).span, prism_rtl::cat("a plain `", shown, "` where `", fname_4, "` takes a `", show_ty_17571, "`"), prism_rtl::cat("write `", ph, " ", crate::check::expr::src_text(env_3, prism_rtl::val(a_1->value).span), "`"))); });
                });
            })
                : prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st_6, p_, at__2, prism_rtl::val(a_1->value).span)));
            });
        });
        });
    });
}


/// `Start PlainArg, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_plain_arg(crate::check::expr::Env env, crate::check::types::St st, Text fname, crate::check::types::Ty param, crate::check::types::Ty at_, crate::syntax::Arg a) {
    return prism_rtl::make_rc<PlainArg>(env, st, fname, param, at_, a);
}


/// LayeredArg: unbounded fn Env, St, Peeled, Text, Bool, Ty, Ty, Arg -> ((Peeled, St))
std::tuple<Peeled, crate::check::types::St> layered_arg(const crate::check::expr::Env& env, const crate::check::types::St& st, const Peeled& acc, const Text& fname, const bool& cmp, const crate::check::types::Ty& param, const crate::check::types::Ty& at_, const crate::syntax::Arg& a) {
    auto p_ = crate::check::types::recording::walk(st, param);
    auto span = prism_rtl::val(a.value).span;
    auto ph = crate::check::types::head_sigil(st, p_);
    return crate::check::types::is_free_headed(st, at_)
        ? ({
        auto st2 = ((crate::check::expr::is_time_sigil(ph) || (ph == Text::lit("@"))) || (ph == Text::lit("&"))) || prism_rtl::val(cmp)
            ? st
            : crate::check::types::unify::ask_layer(st, at_, span, fname);
        std::tuple{acc, crate::check::types::unify::unify(st2, p_, at_, span)};
    })
        : (crate::check::expr::is_time_sigil(ph) || (ph == Text::lit("@"))) || (ph == Text::lit("&"))
        ? std::tuple{acc, crate::check::types::unify::unify(st, p_, at_, span)}
        : crate::check::expr::is_plain_sigil(ph)
        ? peel_time_only(env, st, acc, fname, p_, at_, a)
        : ({
        auto head = crate::check::types::head_sigil(st, at_);
        head == Text::lit("@")
        ? std::tuple{acc, crate::check::types::recording::err_fix(st, Text::lit("blueprint-operand"), span, prism_rtl::cat("`", fname, "` over a blueprint; bind it first"), prism_rtl::cat("bind it, `x <- ", crate::check::expr::src_text(env, span), "`, and use `x`"))}
        : crate::check::expr::is_time_sigil(head)
        ? ({
        auto inner = crate::check::expr::inner_of(st, at_);
        auto ih = crate::check::types::head_sigil(st, inner);
        auto acc2 = ({
            Peeled this_ = acc;
            if (head == Text::lit("!")) {
                this_.events = crate::prelude::push(this_.events, span);
            } else  {
                this_.dyns = crate::prelude::push(this_.dyns, span);
            }
            if (this_.lifted == Text::lit("")) {
                this_.lifted = crate::check::expr::src_text(env, span);
            }
            this_;
        });
        crate::check::expr::is_time_sigil(ih)
        ? ({
        auto what = ih == Text::lit("$") ? Text::lit("dynamic") : Text::lit("event");
        std::tuple{acc2, crate::check::types::recording::err_fix(st, Text::lit("two-layers"), span, prism_rtl::cat("`", fname, "` over a ", head == Text::lit("$") ? Text::lit("dynamic") : Text::lit("event"), " of ", what, "s"), Text::lit("take one layer off with a binding first: `@Flatten` or `@Switch`"))};
    })
        : crate::check::expr::is_plain_sigil(ih) && (!prism_rtl::val(cmp))
        ? ({
        auto inner2 = crate::check::expr::inner_of(st, inner);
        (crate::check::expr::is_time_sigil(crate::check::types::head_sigil(st, inner2)) || (crate::check::types::head_sigil(st, inner2) == Text::lit("@"))
        ? std::tuple{acc2, crate::check::types::recording::err(st, Text::lit("layer-under-optional"), span, prism_rtl::cat("`", fname, "` over an optional ", ih == Text::lit("?") ? Text::lit("") : Text::lit("fault "), "dynamic"))}
        : ({
        auto acc3 = ({
            Peeled this_ = acc2;
            this_.opts = crate::check::types::add_text(this_.opts, ih);
            this_.opt_args = crate::prelude::push(this_.opt_args, span);
            this_;
        });
        std::tuple{acc3, crate::check::types::unify::unify(st, p_, inner2, span)};
    }));
    })
        : std::tuple{acc2, crate::check::types::unify::unify(st, p_, inner, span)};
    })
        : crate::check::expr::is_plain_sigil(head) && (!prism_rtl::val(cmp))
        ? ({
        auto inner = crate::check::expr::inner_of(st, at_);
        auto ih = crate::check::types::head_sigil(st, inner);
        (crate::check::expr::is_time_sigil(ih) || (ih == Text::lit("@"))
        ? std::tuple{acc, crate::check::types::recording::err_fix(st, Text::lit("layer-under-optional"), span, prism_rtl::cat("`", fname, "` over an optional dynamic"), Text::lit("match the optional once, at build time, to find out whether there is a dynamic"))}
        : ({
        auto acc2 = ({
            Peeled this_ = acc;
            this_.opts = crate::check::types::add_text(this_.opts, head);
            this_.opt_args = crate::prelude::push(this_.opt_args, span);
            this_;
        });
        std::tuple{acc2, crate::check::types::unify::unify(st, p_, inner, span)};
    }));
    })
        : head == Text::lit("&")
        ? std::tuple{acc, crate::check::types::unify::unify(st, p_, crate::check::expr::inner_of(st, at_), span)}
        : std::tuple{acc, crate::check::types::unify::unify(st, p_, at_, span)};
    });
}


prism_rtl::Turn<std::tuple<Peeled, crate::check::types::St>> LayeredArg::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& acc = this->acc;
    const auto& fname = this->fname;
    const auto& cmp = this->cmp;
    const auto& param = this->param;
    const auto& at_ = this->at_;
    const auto& a = this->a;
    auto a_1 = a;
    auto acc_2 = acc;
    auto at__3 = at_;
    auto cmp_4 = prism_rtl::val(cmp);
    auto env_5 = env;
    auto fname_6 = fname;
    auto param_7 = param;
    auto st_8 = st;
    return call_then(crate::check::types::recording::start_walk(st_8, param_7), [=](crate::check::types::Ty walk_17883) {
        return ({
            auto p_ = walk_17883;
            auto span = prism_rtl::val(a_1->value).span;
            call_then(crate::check::types::start_head_sigil(st_8, p_), [=](Text head_sigil_17939) {
            return ({
                auto ph = head_sigil_17939;
                call_then(crate::check::types::start_is_free_headed(st_8, at__3), [=](bool is_free_headed_17962) {
                return is_free_headed_17962
                    ? ({
                    auto st2 = ((crate::check::expr::is_time_sigil(ph) || (ph == Text::lit("@"))) || (ph == Text::lit("&"))) || cmp_4
                        ? st_8
                        : crate::check::types::unify::ask_layer(st_8, at__3, span, fname_6);
                    call_then(crate::check::types::unify::start_unify(st2, p_, at__3, span), [=](crate::check::types::St unify_18109) { return prism_rtl::finished(std::tuple{acc_2, unify_18109}); });
                })
                    : (crate::check::expr::is_time_sigil(ph) || (ph == Text::lit("@"))) || (ph == Text::lit("&"))
                    ? call_then(crate::check::types::unify::start_unify(st_8, p_, at__3, span), [=](crate::check::types::St unify_18200) { return prism_rtl::finished(std::tuple{acc_2, unify_18200}); })
                    : crate::check::expr::is_plain_sigil(ph)
                    ? prism_rtl::more(prism_rtl::rc(PeelTimeOnly(env_5, st_8, acc_2, fname_6, p_, at__3, a_1)))
                    : call_then(crate::check::types::start_head_sigil(st_8, at__3), [=](Text head_sigil_18327) {
                    return ({
                        auto head = head_sigil_18327;
                        head == Text::lit("@")
                        ? prism_rtl::finished(std::tuple{acc_2, crate::check::types::recording::err_fix(st_8, Text::lit("blueprint-operand"), span, prism_rtl::cat("`", fname_6, "` over a blueprint; bind it first"), prism_rtl::cat("bind it, `x <- ", crate::check::expr::src_text(env_5, span), "`, and use `x`"))})
                        : crate::check::expr::is_time_sigil(head)
                        ? call_then(crate::check::expr::start_inner_of(st_8, at__3), [=](crate::check::types::Ty inner_of_18572) {
                        return ({
                            auto inner = inner_of_18572;
                            call_then(crate::check::types::start_head_sigil(st_8, inner), [=](Text head_sigil_18608) {
                            return ({
                                auto ih = head_sigil_18608;
                                auto acc2 = ({
                                    Peeled this_ = acc_2;
                                    if (head == Text::lit("!")) {
                                        this_.events = crate::prelude::push(this_.events, span);
                                    } else  {
                                        this_.dyns = crate::prelude::push(this_.dyns, span);
                                    }
                                    if (this_.lifted == Text::lit("")) {
                                        this_.lifted = crate::check::expr::src_text(env_5, span);
                                    }
                                    this_;
                                });
                                (crate::check::expr::is_time_sigil(ih)
                                ? ({
                                auto what = ih == Text::lit("$") ? Text::lit("dynamic") : Text::lit("event");
                                (prism_rtl::finished(std::tuple{acc2, crate::check::types::recording::err_fix(st_8, Text::lit("two-layers"), span, prism_rtl::cat("`", fname_6, "` over a ", head == Text::lit("$") ? Text::lit("dynamic") : Text::lit("event"), " of ", what, "s"), Text::lit("take one layer off with a binding first: `@Flatten` or `@Switch`"))}));
                            })
                                : crate::check::expr::is_plain_sigil(ih) && (!cmp_4)
                                ? call_then(crate::check::expr::start_inner_of(st_8, inner), [=](crate::check::types::Ty inner_of_19284) {
                                return ({
                                    auto inner2 = inner_of_19284;
                                    call_then(crate::check::types::start_head_sigil(st_8, inner2), [=](Text head_sigil_19335) {
                                    return crate::check::expr::is_time_sigil(head_sigil_19335) || (crate::check::types::head_sigil(st_8, inner2) == Text::lit("@"))
                                        ? prism_rtl::finished(std::tuple{acc2, crate::check::types::recording::err(st_8, Text::lit("layer-under-optional"), span, prism_rtl::cat("`", fname_6, "` over an optional ", ih == Text::lit("?") ? Text::lit("") : Text::lit("fault "), "dynamic"))})
                                        : ({
                                        auto acc3 = ({
                                            Peeled this_ = acc2;
                                            this_.opts = crate::check::types::add_text(this_.opts, ih);
                                            this_.opt_args = crate::prelude::push(this_.opt_args, span);
                                            this_;
                                        });
                                        call_then(crate::check::types::unify::start_unify(st_8, p_, inner2, span), [=](crate::check::types::St unify_19742) { return prism_rtl::finished(std::tuple{acc3, unify_19742}); });
                                    });
                                });
                                });
                            })
                                : call_then(crate::check::types::unify::start_unify(st_8, p_, inner, span), [=](crate::check::types::St unify_19798) { return prism_rtl::finished(std::tuple{acc2, unify_19798}); }));
                            });
                        });
                        });
                    })
                        : crate::check::expr::is_plain_sigil(head) && (!cmp_4)
                        ? call_then(crate::check::expr::start_inner_of(st_8, at__3), [=](crate::check::types::Ty inner_of_19900) {
                        return ({
                            auto inner = inner_of_19900;
                            call_then(crate::check::types::start_head_sigil(st_8, inner), [=](Text head_sigil_19936) {
                            return ({
                                auto ih = head_sigil_19936;
                                (crate::check::expr::is_time_sigil(ih) || (ih == Text::lit("@"))
                                ? prism_rtl::finished(std::tuple{acc_2, crate::check::types::recording::err_fix(st_8, Text::lit("layer-under-optional"), span, prism_rtl::cat("`", fname_6, "` over an optional dynamic"), Text::lit("match the optional once, at build time, to find out whether there is a dynamic"))})
                                : ({
                                auto acc2 = ({
                                    Peeled this_ = acc_2;
                                    this_.opts = crate::check::types::add_text(this_.opts, head);
                                    this_.opt_args = crate::prelude::push(this_.opt_args, span);
                                    this_;
                                });
                                call_then(crate::check::types::unify::start_unify(st_8, p_, inner, span), [=](crate::check::types::St unify_20380) { return prism_rtl::finished(std::tuple{acc2, unify_20380}); });
                            }));
                            });
                        });
                        });
                    })
                        : head == Text::lit("&")
                        ? call_then(crate::check::expr::start_inner_of(st_8, at__3), [=](crate::check::types::Ty inner_of_20460) { return call_then(crate::check::types::unify::start_unify(st_8, p_, inner_of_20460, span), [=](crate::check::types::St unify_20446) { return prism_rtl::finished(std::tuple{acc_2, unify_20446}); }); })
                        : call_then(crate::check::types::unify::start_unify(st_8, p_, at__3, span), [=](crate::check::types::St unify_20507) { return prism_rtl::finished(std::tuple{acc_2, unify_20507}); });
                    });
                });
            });
            });
        });
        });
    });
}


/// `Start LayeredArg, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Peeled, crate::check::types::St>> start_layered_arg(crate::check::expr::Env env, crate::check::types::St st, Peeled acc, Text fname, bool cmp, crate::check::types::Ty param, crate::check::types::Ty at_, crate::syntax::Arg a) {
    return prism_rtl::make_rc<LayeredArg>(env, st, acc, fname, cmp, param, at_, a);
}


/// PeelTimeOnly: unbounded fn Env, St, Peeled, Text, Ty, Ty, Arg -> ((Peeled, St))
std::tuple<Peeled, crate::check::types::St> peel_time_only(const crate::check::expr::Env& env, const crate::check::types::St& st, const Peeled& acc, const Text& fname, const crate::check::types::Ty& p_, const crate::check::types::Ty& at_, const crate::syntax::Arg& a) {
    auto span = prism_rtl::val(a.value).span;
    auto head = crate::check::types::head_sigil(st, at_);
    return head == Text::lit("@")
        ? std::tuple{acc, crate::check::types::recording::err_fix(st, Text::lit("blueprint-operand"), span, prism_rtl::cat("`", fname, "` over a blueprint; bind it first"), prism_rtl::cat("bind it, `x <- ", crate::check::expr::src_text(env, span), "`, and use `x`"))}
        : crate::check::expr::is_time_sigil(head)
        ? ({
        auto inner = crate::check::expr::inner_of(st, at_);
        auto acc2 = ({
            Peeled this_ = acc;
            if (head == Text::lit("!")) {
                this_.events = crate::prelude::push(this_.events, span);
            } else  {
                this_.dyns = crate::prelude::push(this_.dyns, span);
            }
            if (this_.lifted == Text::lit("")) {
                this_.lifted = crate::check::expr::src_text(env, span);
            }
            this_;
        });
        crate::check::expr::is_time_sigil(crate::check::types::head_sigil(st, inner))
        ? std::tuple{acc2, crate::check::types::recording::err_fix(st, Text::lit("two-layers"), span, prism_rtl::cat("`", fname, "` over a ", head == Text::lit("$") ? Text::lit("dynamic") : Text::lit("event"), " of ", crate::check::types::head_sigil(st, inner) == Text::lit("$")
        ? Text::lit("dynamic")
        : Text::lit("event"), "s"), Text::lit("take one layer off with a binding first: `@Flatten` or `@Switch`"))}
        : std::tuple{acc2, crate::check::types::unify::unify(st, p_, inner, span)};
    })
        : std::tuple{acc, crate::check::types::unify::unify(st, p_, at_, span)};
}


prism_rtl::Turn<std::tuple<Peeled, crate::check::types::St>> PeelTimeOnly::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& acc = this->acc;
    const auto& fname = this->fname;
    const auto& p_ = this->p_;
    const auto& at_ = this->at_;
    const auto& a = this->a;
    auto span = prism_rtl::val(a->value).span;
    auto a_1 = a;
    auto acc_2 = acc;
    auto at__3 = at_;
    auto env_4 = env;
    auto fname_5 = fname;
    auto p__6 = p_;
    auto st_7 = st;
    return call_then(crate::check::types::start_head_sigil(st_7, at__3), [=](Text head_sigil_20793) {
        return ({
            auto head = head_sigil_20793;
            head == Text::lit("@")
            ? prism_rtl::finished(std::tuple{acc_2, crate::check::types::recording::err_fix(st_7, Text::lit("blueprint-operand"), span, prism_rtl::cat("`", fname_5, "` over a blueprint; bind it first"), prism_rtl::cat("bind it, `x <- ", crate::check::expr::src_text(env_4, span), "`, and use `x`"))})
            : crate::check::expr::is_time_sigil(head)
            ? call_then(crate::check::expr::start_inner_of(st_7, at__3), [=](crate::check::types::Ty inner_of_21026) {
            return ({
                auto inner = inner_of_21026;
                auto acc2 = ({
                    Peeled this_ = acc_2;
                    if (head == Text::lit("!")) {
                        this_.events = crate::prelude::push(this_.events, span);
                    } else  {
                        this_.dyns = crate::prelude::push(this_.dyns, span);
                    }
                    if (this_.lifted == Text::lit("")) {
                        this_.lifted = crate::check::expr::src_text(env_4, span);
                    }
                    this_;
                });
                call_then(crate::check::types::start_head_sigil(st_7, inner), [=](Text head_sigil_21317) {
                return crate::check::expr::is_time_sigil(head_sigil_21317)
                    ? call_then(crate::check::types::start_head_sigil(st_7, inner), [=](Text head_sigil_21447) {
                    return prism_rtl::finished(std::tuple{acc2, crate::check::types::recording::err_fix(st_7, Text::lit("two-layers"), span, prism_rtl::cat("`", fname_5, "` over a ", head == Text::lit("$") ? Text::lit("dynamic") : Text::lit("event"), " of ", head_sigil_21447 == Text::lit("$")
                        ? Text::lit("dynamic")
                        : Text::lit("event"), "s"), Text::lit("take one layer off with a binding first: `@Flatten` or `@Switch`"))});
                })
                    : call_then(crate::check::types::unify::start_unify(st_7, p__6, inner, span), [=](crate::check::types::St unify_21597) { return prism_rtl::finished(std::tuple{acc2, unify_21597}); });
            });
            });
        })
            : call_then(crate::check::types::unify::start_unify(st_7, p__6, at__3, span), [=](crate::check::types::St unify_21643) { return prism_rtl::finished(std::tuple{acc_2, unify_21643}); });
        });
    });
}


/// `Start PeelTimeOnly, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Peeled, crate::check::types::St>> start_peel_time_only(crate::check::expr::Env env, crate::check::types::St st, Peeled acc, Text fname, crate::check::types::Ty p_, crate::check::types::Ty at_, crate::syntax::Arg a) {
    return prism_rtl::make_rc<PeelTimeOnly>(env, st, acc, fname, p_, at_, a);
}


/// CtorApp: unbounded fn Env, St, CtorInfo, [Arg], Range, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> ctor_app(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::check::env::CtorInfo& c, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span, const crate::syntax::Range& cspan) {
    auto [self_, st0, inst] = crate::check::types::schemes::instantiate_with(st, crate::check::types::Scheme{.qs = c.params, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = c.ty}, span, Array<crate::check::types::Ty>{});
    auto field_tys = run_to_end(each_job(c.args, ({
        auto inst_1 = inst;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return ({
            auto inst_1_2 = inst_1;
            entered(once_job([=]() {
            return ({
                auto t = p0;
                (prism_rtl::more(prism_rtl::rc(crate::check::types::schemes::SubstQ(inst_1_2, t))));
            });
        }));
        });
    })));
    })));
    auto st1 = crate::check::types::recording::note_ty(st0, cspan, crate::check::types::Ty(crate::check::types::Ty::TyFn{crate::check::types::Col(crate::check::types::Col::CBound{}), field_tys, prism_rtl::rc(self_)}));
    auto named_ = filter(args, [&](const crate::syntax::Arg& a) { return prism_rtl::val(a).name != std::optional<crate::syntax::Ident>{}; });
    return (len(named_) > Nat(0u)) && (len(c.fields) > Nat(0u))
        ? ({
        auto st2 = run_to_end(fold_job(named_, st1, ({
            auto c_1 = c;
            auto env_2 = env;
            auto field_tys_3 = field_tys;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Arg>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::Arg> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto c_1_4 = c_1;
                auto env_2_4 = env_2;
                auto field_tys_3_4 = field_tys_3;
                entered(once_job([=]() {
                return ({
                    auto s = p0;
                    auto a = p1;
                    ({
                    auto&& _m = prism_rtl::val(a).name;
                    prism_rtl::is_some(_m) ? ({
                    auto&& id = prism_rtl::some_of(_m);
                    ({
                    auto&& _m = crate::check::expr::operators::index_of(c_1_4.fields, prism_rtl::val(id).name);
                    prism_rtl::is_some(_m) ? ({
                    auto&& i = prism_rtl::some_of(_m);
                    prism_rtl::more(prism_rtl::rc(crate::check::expr::Check(env_2_4, s, a->value, or_(index(field_tys_3_4, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})))));
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::check::types::recording::err(s, Text::lit("mismatch"), prism_rtl::val(a).span, prism_rtl::cat("`", crate::check::types::bare_name(c_1_4.owner), "` has no field `", prism_rtl::val(id).name, "`")))
                    : throw prism_rtl::Panic("no arm matched");
                });
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(s)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        })));
        })));
        auto missing = filter(c.fields, [&](const Text& f) { return !fold(named_, false, [&](const bool& seen, const crate::syntax::Arg& a) { return prism_rtl::val(seen) || arg_named(a, f); }); });
        auto st3 = len(missing) > Nat(0u)
            ? crate::check::types::recording::err(st2, Text::lit("mismatch"), span, prism_rtl::cat("`", crate::check::types::bare_name(c.owner), "` needs ", crate::syntax::lexer::chars::join(each(missing, [&](const Text& f) { return prism_rtl::cat("`", f, "`"); }), Text::lit(", "))))
            : st2;
        std::tuple{self_, st3};
    })
        : len(args) != len(field_tys)
        ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st1, Text::lit("mismatch"), span, prism_rtl::cat("`", crate::check::types::bare_name(c.name), "` takes ", crate::check::errors::count_word(len(field_tys)), " argument", len(field_tys) == Nat(1u) ? Text::lit("") : Text::lit("s"), "; here it has ", crate::check::errors::count_word(len(args))))}
        : ({
        auto st2 = run_to_end(fold_job(crate::check::errors::range0(len(args)), st1, ({
            auto args_1 = args;
            auto env_2 = env;
            auto field_tys_3 = field_tys;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Nat>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto args_1_4 = args_1;
                auto env_2_4 = env_2;
                auto field_tys_3_4 = field_tys_3;
                entered(once_job([=]() {
                return ({
                    auto s = p0;
                    auto i = p1;
                    ({
                    auto&& _m = index(args_1_4, i);
                    prism_rtl::is_some(_m) ? ({
                    auto&& a = prism_rtl::some_of(_m);
                    prism_rtl::more(prism_rtl::rc(crate::check::expr::Check(env_2_4, s, a->value, or_(index(field_tys_3_4, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})))));
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(s)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        })));
        })));
        std::tuple{self_, st2};
    });
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> CtorApp::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& c = this->c;
    const auto& args = this->args;
    const auto& span = this->span;
    const auto& cspan = this->cspan;
    auto args_1 = args;
    auto c_2 = c;
    auto cspan_3 = cspan;
    auto env_4 = env;
    auto span_5 = span;
    auto st_6 = st;
    return call_then(crate::check::types::schemes::start_instantiate_with(st_6, crate::check::types::Scheme{.qs = prism_rtl::val(c_2).params, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = prism_rtl::val(c_2).ty}, span_5, Array<crate::check::types::Ty>{}), [=](std::tuple<crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst> instantiate_with_21905) {
        return ({
            auto [self_, st0, inst] = instantiate_with_21905;
            call_value(each_job(c_2->args, ({
            auto inst_7 = inst;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
            return ({
                auto inst_7_8 = inst_7;
                entered(once_job([=]() {
                return ({
                    auto t = p0;
                    (prism_rtl::more(prism_rtl::rc(crate::check::types::schemes::SubstQ(inst_7_8, t))));
                });
            }));
            });
        })));
        })), [=](Array<crate::check::types::Ty> each_22047) {
            return ({
                auto field_tys = each_22047;
                auto st1 = crate::check::types::recording::note_ty(st0, cspan_3, crate::check::types::Ty(crate::check::types::Ty::TyFn{crate::check::types::Col(crate::check::types::Col::CBound{}), field_tys, prism_rtl::rc(self_)}));
                auto named_ = filter(args_1, [&](const crate::syntax::Arg& a) { return prism_rtl::val(a).name != std::optional<crate::syntax::Ident>{}; });
                (len(named_) > Nat(0u)) && (len(prism_rtl::val(c_2).fields) > Nat(0u))
                ? call_value(fold_job(named_, st1, ({
                auto c_2_7 = c_2;
                auto env_4_7 = env_4;
                auto field_tys_7 = field_tys;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Arg>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::Arg> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto c_2_7_8 = c_2_7;
                    auto env_4_7_8 = env_4_7;
                    auto field_tys_7_8 = field_tys_7;
                    entered(once_job([=]() {
                    return ({
                        auto s = p0;
                        auto a = p1;
                        ({
                        auto&& _m = prism_rtl::val(a).name;
                        prism_rtl::is_some(_m) ? ({
                        auto&& id = prism_rtl::some_of(_m);
                        ({
                        auto&& _m = crate::check::expr::operators::index_of(prism_rtl::val(c_2_7_8).fields, prism_rtl::val(id).name);
                        prism_rtl::is_some(_m) ? ({
                        auto&& i = prism_rtl::some_of(_m);
                        prism_rtl::more(prism_rtl::rc(crate::check::expr::Check(env_4_7_8, s, a->value, or_(index(field_tys_7_8, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})))));
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::check::types::recording::err(s, Text::lit("mismatch"), prism_rtl::val(a).span, prism_rtl::cat("`", crate::check::types::bare_name(prism_rtl::val(c_2_7_8).owner), "` has no field `", prism_rtl::val(id).name, "`")))
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(s)
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                }));
                });
            })));
            })), [=](crate::check::types::St fold_22257) {
                return ({
                    auto st2 = fold_22257;
                    auto missing = filter(prism_rtl::val(c_2).fields, [&](const Text& f) { return !fold(named_, false, [&](const bool& seen, const crate::syntax::Arg& a) { return prism_rtl::val(seen) || arg_named(a, f); }); });
                    auto st3 = len(missing) > Nat(0u)
                        ? crate::check::types::recording::err(st2, Text::lit("mismatch"), span_5, prism_rtl::cat("`", crate::check::types::bare_name(prism_rtl::val(c_2).owner), "` needs ", crate::syntax::lexer::chars::join(each(missing, [&](const Text& f) { return prism_rtl::cat("`", f, "`"); }), Text::lit(", "))))
                        : st2;
                    (prism_rtl::finished(std::tuple{self_, st3}));
                });
            })
                : len(args_1) != len(field_tys)
                ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st1, Text::lit("mismatch"), span_5, prism_rtl::cat("`", crate::check::types::bare_name(prism_rtl::val(c_2).name), "` takes ", crate::check::errors::count_word(len(field_tys)), " argument", len(field_tys) == Nat(1u) ? Text::lit("") : Text::lit("s"), "; here it has ", crate::check::errors::count_word(len(args_1))))})
                : call_value(fold_job(crate::check::errors::range0(len(args_1)), st1, ({
                auto args_1_7 = args_1;
                auto env_4_7 = env_4;
                auto field_tys_7 = field_tys;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Nat>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto args_1_7_8 = args_1_7;
                    auto env_4_7_8 = env_4_7;
                    auto field_tys_7_8 = field_tys_7;
                    entered(once_job([=]() {
                    return ({
                        auto s = p0;
                        auto i = p1;
                        ({
                        auto&& _m = index(args_1_7_8, i);
                        prism_rtl::is_some(_m) ? ({
                        auto&& a = prism_rtl::some_of(_m);
                        prism_rtl::more(prism_rtl::rc(crate::check::expr::Check(env_4_7_8, s, a->value, or_(index(field_tys_7_8, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})))));
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(s)
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                }));
                });
            })));
            })), [=](crate::check::types::St fold_23063) {
                return ({
                    auto st2 = fold_23063;
                    (prism_rtl::finished(std::tuple{self_, st2}));
                });
            });
            });
        });
        });
    });
}


/// `Start CtorApp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_ctor_app(crate::check::expr::Env env, crate::check::types::St st, crate::check::env::CtorInfo c, Array<crate::syntax::Arg> args, crate::syntax::Range span, crate::syntax::Range cspan) {
    return prism_rtl::make_rc<CtorApp>(env, st, c, args, span, cspan);
}


/// TagApp: unbounded fn Env, St, Text, [Arg], Range, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> tag_app(const crate::check::expr::Env& env, const crate::check::types::St& st, const Text& name, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span, const crate::syntax::Range& cspan) {
    auto&& _m = crate::prelude::get(prism_rtl::val(env.g).tags, name);
    if (prism_rtl::is_none(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unknown-name"), span, prism_rtl::cat("no tag `", name, "`"))};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& tg = prism_rtl::some_of(_m);
        auto [out, st1, inst] = crate::check::types::schemes::instantiate_with(st, crate::check::types::Scheme{.qs = prism_rtl::val(tg).qs, .plain_qs = Array<Text>{}, .rqs = prism_rtl::val(tg).rqs, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = prism_rtl::val(tg).bounds, .ty = tg->out}, span, Array<crate::check::types::Ty>{});
        auto st2 = run_to_end(fold_job(args, st1, ({
            auto tg_1 = tg;
            auto env_2 = env;
            auto name_3 = name;
            auto inst_4 = inst;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Arg>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::Arg> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto tg_1_5 = tg_1;
                auto env_2_5 = env_2;
                auto name_3_5 = name_3;
                auto inst_4_5 = inst_4;
                entered(once_job([=]() {
                return ({
                    auto s = p0;
                    auto a = p1;
                    ({
                    auto&& _m = prism_rtl::val(a).name;
                    prism_rtl::is_some(_m) ? ({
                    auto&& id = prism_rtl::some_of(_m);
                    ({
                    auto&& _m = field_of_tag(tg_1_5, prism_rtl::val(id).name);
                    prism_rtl::is_some(_m) ? ({
                    auto&& ft = prism_rtl::some_of(_m);
                    ({
                    auto id_5 = id;
                    call_then(crate::check::types::schemes::start_subst_q(inst_4_5, ft), [=](crate::check::types::Ty subst_q_24017) { return prism_rtl::more(prism_rtl::rc(TagField(env_2_5, s, name_3_5, prism_rtl::val(id_5).name, subst_q_24017, a))); });
                });
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::check::types::recording::err(s, Text::lit("mismatch"), prism_rtl::val(a).span, prism_rtl::cat("`", name_3_5, "` has no field `", prism_rtl::val(id).name, "`")))
                    : throw prism_rtl::Panic("no arm matched");
                });
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::check::types::recording::err(s, Text::lit("mismatch"), prism_rtl::val(a).span, prism_rtl::cat("a tag\'s fields are named: `", name_3_5, "(field=...)`")))
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        })));
        })));
        auto missing = filter(prism_rtl::val(tg).fields, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
            auto&& f = std::get<0>(_p0);
            return !fold(args, false, [&](const bool& seen, const crate::syntax::Arg& a) { return prism_rtl::val(seen) || arg_named(a, f); });
        });
        auto st3 = (len(missing) > Nat(0u)) && (!fold(args, false, [&](const bool& seen, const crate::syntax::Arg& a) { return prism_rtl::val(seen) || (prism_rtl::val(prism_rtl::val(a->value).kind) == crate::syntax::ExprKind(crate::syntax::ExprKind::ERest{})); }))
            ? crate::check::types::recording::err(st2, Text::lit("mismatch"), span, prism_rtl::cat("`", name, "` needs ", crate::syntax::lexer::chars::join(each(missing, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
            auto&& f = std::get<0>(_p0);
            return prism_rtl::cat("`", f, "`");
        }), Text::lit(", "))))
            : st2;
        auto field_tys = run_to_end(each_job(prism_rtl::val(tg).fields, ({
            auto inst_1 = inst;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(std::tuple<Text, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Text, crate::check::types::Ty> p0) {
            return ({
                auto inst_1_2 = inst_1;
                entered(once_job([=]() {
                return ({
                    auto&& _ft = p0;
                    auto&& ft = std::get<1>(_ft);
                    (prism_rtl::more(prism_rtl::rc(crate::check::types::schemes::SubstQ(inst_1_2, ft))));
                });
            }));
            });
        })));
        })));
        return prism_rtl::val(tg).kind == Text::lit("Element")
            ? ({
            auto [rw, st4] = crate::check::types::recording::fresh_row(st3, Array(std::vector{prism_rtl::val(tg).family}));
            auto et = crate::check::types::Ty(crate::check::types::Ty::TyElem{crate::check::types::Rw{.fams = Array(std::vector{prism_rtl::val(tg).family}), .minus = Array<Text>{}, .tail = prism_rtl::val(rw).tail}, prism_rtl::rc(out)});
            std::tuple{et, crate::check::types::recording::note_ty(st4, cspan, crate::check::types::Ty(crate::check::types::Ty::TyFn{crate::check::types::Col(crate::check::types::Col::CBound{}), field_tys, prism_rtl::rc(et)}))};
        })
            : std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{prism_rtl::val(tg).kind, Array<crate::check::types::Ty>{}}), crate::check::types::recording::note_ty(st3, cspan, crate::check::types::Ty(crate::check::types::Ty::TyFn{crate::check::types::Col(crate::check::types::Col::CBound{}), field_tys, prism_rtl::rc(crate::check::types::Ty(crate::check::types::Ty::TyCon{prism_rtl::val(tg).kind, Array<crate::check::types::Ty>{}}))}))};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> TagApp::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& name = this->name;
    const auto& args = this->args;
    const auto& span = this->span;
    const auto& cspan = this->cspan;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::val(prism_rtl::val(env).g).tags, name);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unknown-name"), span, prism_rtl::cat("no tag `", name, "`"))})
        : prism_rtl::is_some(_m) ? ({
        auto&& tg = prism_rtl::some_of(_m);
        ({
        auto args_1 = args;
        auto cspan_2 = cspan;
        auto env_3 = env;
        auto name_4 = name;
        auto span_5 = span;
        auto st_6 = st;
        call_then(crate::check::types::schemes::start_instantiate_with(st_6, crate::check::types::Scheme{.qs = prism_rtl::val(tg).qs, .plain_qs = Array<Text>{}, .rqs = prism_rtl::val(tg).rqs, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = prism_rtl::val(tg).bounds, .ty = tg->out}, span_5, Array<crate::check::types::Ty>{}), [=](std::tuple<crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst> instantiate_with_23727) {
        return ({
            auto [out, st1, inst] = instantiate_with_23727;
            call_value(fold_job(args_1, st1, ({
            auto tg_7 = tg;
            auto env_3_8 = env_3;
            auto name_4_8 = name_4;
            auto inst_8 = inst;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Arg>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::Arg> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto tg_7_9 = tg_7;
                auto env_3_8_9 = env_3_8;
                auto name_4_8_9 = name_4_8;
                auto inst_8_9 = inst_8;
                entered(once_job([=]() {
                return ({
                    auto s = p0;
                    auto a = p1;
                    ({
                    auto&& _m = prism_rtl::val(a).name;
                    prism_rtl::is_some(_m) ? ({
                    auto&& id = prism_rtl::some_of(_m);
                    ({
                    auto&& _m = field_of_tag(tg_7_9, prism_rtl::val(id).name);
                    prism_rtl::is_some(_m) ? ({
                    auto&& ft = prism_rtl::some_of(_m);
                    ({
                    auto id_9 = id;
                    call_then(crate::check::types::schemes::start_subst_q(inst_8_9, ft), [=](crate::check::types::Ty subst_q_24017) { return prism_rtl::more(prism_rtl::rc(TagField(env_3_8_9, s, name_4_8_9, prism_rtl::val(id_9).name, subst_q_24017, a))); });
                });
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::check::types::recording::err(s, Text::lit("mismatch"), prism_rtl::val(a).span, prism_rtl::cat("`", name_4_8_9, "` has no field `", prism_rtl::val(id).name, "`")))
                    : throw prism_rtl::Panic("no arm matched");
                });
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::check::types::recording::err(s, Text::lit("mismatch"), prism_rtl::val(a).span, prism_rtl::cat("a tag\'s fields are named: `", name_4_8_9, "(field=...)`")))
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        })));
        })), [=](crate::check::types::St fold_23874) {
            return ({
                auto st2 = fold_23874;
                auto missing = filter(prism_rtl::val(tg).fields, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
                    auto&& f = std::get<0>(_p0);
                    return !fold(args_1, false, [&](const bool& seen, const crate::syntax::Arg& a) { return prism_rtl::val(seen) || arg_named(a, f); });
                });
                auto st3 = (len(missing) > Nat(0u)) && (!fold(args_1, false, [&](const bool& seen, const crate::syntax::Arg& a) { return prism_rtl::val(seen) || (prism_rtl::val(prism_rtl::val(a->value).kind) == crate::syntax::ExprKind(crate::syntax::ExprKind::ERest{})); }))
                    ? crate::check::types::recording::err(st2, Text::lit("mismatch"), span_5, prism_rtl::cat("`", name_4, "` needs ", crate::syntax::lexer::chars::join(each(missing, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
                    auto&& f = std::get<0>(_p0);
                    return prism_rtl::cat("`", f, "`");
                }), Text::lit(", "))))
                    : st2;
                call_value(each_job(prism_rtl::val(tg).fields, ({
                auto inst_7 = inst;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(std::tuple<Text, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Text, crate::check::types::Ty> p0) {
                return ({
                    auto inst_7_8 = inst_7;
                    entered(once_job([=]() {
                    return ({
                        auto&& _ft = p0;
                        auto&& ft = std::get<1>(_ft);
                        (prism_rtl::more(prism_rtl::rc(crate::check::types::schemes::SubstQ(inst_7_8, ft))));
                    });
                }));
                });
            })));
            })), [=](Array<crate::check::types::Ty> each_24569) {
                return ({
                    auto field_tys = each_24569;
                    (prism_rtl::val(tg).kind == Text::lit("Element")
                    ? ({
                    auto [rw, st4] = crate::check::types::recording::fresh_row(st3, Array(std::vector{prism_rtl::val(tg).family}));
                    auto et = crate::check::types::Ty(crate::check::types::Ty::TyElem{crate::check::types::Rw{.fams = Array(std::vector{prism_rtl::val(tg).family}), .minus = Array<Text>{}, .tail = prism_rtl::val(rw).tail}, prism_rtl::rc(out)});
                    (prism_rtl::finished(std::tuple{et, crate::check::types::recording::note_ty(st4, cspan_2, crate::check::types::Ty(crate::check::types::Ty::TyFn{crate::check::types::Col(crate::check::types::Col::CBound{}), field_tys, prism_rtl::rc(et)}))}));
                })
                    : prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{prism_rtl::val(tg).kind, Array<crate::check::types::Ty>{}}), crate::check::types::recording::note_ty(st3, cspan_2, crate::check::types::Ty(crate::check::types::Ty::TyFn{crate::check::types::Col(crate::check::types::Col::CBound{}), field_tys, prism_rtl::rc(crate::check::types::Ty(crate::check::types::Ty::TyCon{prism_rtl::val(tg).kind, Array<crate::check::types::Ty>{}}))}))}));
                });
            });
            });
        });
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TagApp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_tag_app(crate::check::expr::Env env, crate::check::types::St st, Text name, Array<crate::syntax::Arg> args, crate::syntax::Range span, crate::syntax::Range cspan) {
    return prism_rtl::make_rc<TagApp>(env, st, name, args, span, cspan);
}


/// ?FieldOfTag: fn TagInfo, Text -> ?Ty
std::optional<crate::check::types::Ty> field_of_tag(const crate::check::env::TagInfo& tg, const Text& f) {
    return fold(tg.fields, std::optional<crate::check::types::Ty>{}, [&](const std::optional<crate::check::types::Ty>& found_opt, const std::tuple<Text, crate::check::types::Ty>& _p1) {
        auto&& n = std::get<0>(_p1);
        auto&& t = std::get<1>(_p1);
        return ({
            __label__ _done;
            prism_rtl::Slot<std::optional<crate::check::types::Ty>> _v;
            if (prism_rtl::is_some(found_opt)) {
                auto&& x = prism_rtl::some_of(found_opt);
                _v.set(std::optional(x));
                goto _done;
            }
            if (prism_rtl::is_none(found_opt)) {
                _v.set(n == f ? std::optional(t) : std::optional<crate::check::types::Ty>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// TagField: unbounded fn Env, St, Text, Text, Ty, Arg -> St
crate::check::types::St tag_field(const crate::check::expr::Env& env, const crate::check::types::St& st, const Text& tag_name, const Text& field_, const crate::check::types::Ty& ft, const crate::syntax::Arg& a) {
    return crate::check::types::head_sigil(st, ft) != Text::lit("")
        ? crate::check::expr::check(env, st, a.value, ft)
        : ({
        auto [at_, st2] = crate::check::expr::infer(env, st, a.value);
        auto head = crate::check::types::head_sigil(st2, at_);
        head == Text::lit("$")
        ? crate::check::types::recording::err_fix(st2, Text::lit("identity-dynamic"), prism_rtl::val(a.value).span, prism_rtl::cat("a dynamic in the identity field `", field_, "`"), prism_rtl::cat("for a new element per value, write `rebuild ", crate::check::expr::src_text(env, prism_rtl::val(a.value).span), ":` with `", tag_name, "(", field_, "=_, ...)` inside"))
        : head == Text::lit("!")
        ? crate::check::types::recording::err(st2, Text::lit("two-events"), prism_rtl::val(a.value).span, prism_rtl::cat("an event in the plain field `", field_, "`"))
        : crate::check::types::unify::unify(st2, ft, at_, prism_rtl::val(a.value).span);
    });
}


prism_rtl::Turn<crate::check::types::St> TagField::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& tag_name = this->tag_name;
    const auto& field_ = this->field_;
    const auto& ft = this->ft;
    const auto& a = this->a;
    auto a_1 = a;
    auto env_2 = env;
    auto field__3 = field_;
    auto ft_4 = ft;
    auto st_5 = st;
    auto tag_name_6 = tag_name;
    return call_then(crate::check::types::start_head_sigil(st_5, ft_4), [=](Text head_sigil_25385) {
        return head_sigil_25385 != Text::lit("")
            ? prism_rtl::more(prism_rtl::rc(crate::check::expr::Check(env_2, st_5, a_1->value, ft_4)))
            : call_then(crate::check::expr::start_infer(env_2, st_5, a_1->value), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_25473) {
            return ({
                auto [at_, st2] = infer_25473;
                call_then(crate::check::types::start_head_sigil(st2, at_), [=](Text head_sigil_25515) {
                return ({
                    auto head = head_sigil_25515;
                    head == Text::lit("$")
                    ? prism_rtl::finished(crate::check::types::recording::err_fix(st2, Text::lit("identity-dynamic"), prism_rtl::val(a_1->value).span, prism_rtl::cat("a dynamic in the identity field `", field__3, "`"), prism_rtl::cat("for a new element per value, write `rebuild ", crate::check::expr::src_text(env_2, prism_rtl::val(a_1->value).span), ":` with `", tag_name_6, "(", field__3, "=_, ...)` inside")))
                    : head == Text::lit("!")
                    ? prism_rtl::finished(crate::check::types::recording::err(st2, Text::lit("two-events"), prism_rtl::val(a_1->value).span, prism_rtl::cat("an event in the plain field `", field__3, "`")))
                    : prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st2, ft_4, at_, prism_rtl::val(a_1->value).span)));
                });
            });
            });
        });
    });
}


/// `Start TagField, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_tag_field(crate::check::expr::Env env, crate::check::types::St st, Text tag_name, Text field_, crate::check::types::Ty ft, crate::syntax::Arg a) {
    return prism_rtl::make_rc<TagField>(env, st, tag_name, field_, ft, a);
}


/// LambdaArity: fn Expr -> Nat
Nat lambda_arity(const crate::syntax::Expr& e) {
    auto&& _m = prism_rtl::val(e.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0)) {
        auto&& ps = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0);
        return len(ps);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return lambda_arity(prism_rtl::val(prism_rtl::val(x)));
    }
    {
        return Nat(2u);
    }
}


/// InferLambda: unbounded fn Env, St, Expr, ?Ty -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_lambda(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Expr& e, const std::optional<crate::check::types::Ty>& expected_opt) {
    auto&& _m = prism_rtl::val(e.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        auto [t, st2] = infer_lambda(env, st, prism_rtl::val(prism_rtl::val(x)), expected_opt);
        return std::tuple{t, crate::check::types::recording::note_ty(st2, e.span, t)};
    }
    {
        return infer_bare_lambda(env, st, e, expected_opt);
    }
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferLambda::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& e = this->e;
    const auto& expected_opt = this->expected_opt;
    return ({
        auto&& _m = prism_rtl::val(prism_rtl::val(e).kind);
        prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        ({
        auto expected_opt_1 = expected_opt;
        auto e_2 = e;
        auto env_3 = env;
        auto st_4 = st;
        auto x_5 = prism_rtl::val(prism_rtl::val(x));
        call_then(start_infer_lambda(env_3, st_4, x_5, expected_opt_1), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_lambda_26743) {
        return ({
            auto [t, st2] = infer_lambda_26743;
            (prism_rtl::finished(std::tuple{t, crate::check::types::recording::note_ty(st2, prism_rtl::val(e_2).span, t)}));
        });
    });
    });
    })
        : prism_rtl::more(prism_rtl::rc(InferBareLambda(env, st, e, expected_opt)));
    });
}


/// `Start InferLambda, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_lambda(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr e, std::optional<crate::check::types::Ty> expected_opt) {
    return prism_rtl::make_rc<InferLambda>(env, st, e, expected_opt);
}


/// InferBareLambda: unbounded fn Env, St, Expr, ?Ty -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_bare_lambda(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Expr& e, const std::optional<crate::check::types::Ty>& expected_opt) {
    auto [params, body] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::syntax::Pattern_>, crate::syntax::LambdaBody>> _v;
        auto&& _m = prism_rtl::val(e.kind);
        if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0)) {
            auto&& ps = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0);
            auto&& b = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
            _v.set(std::tuple{ps, prism_rtl::val(prism_rtl::val(b))});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0)) {
            auto&& b = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
            _v.set(std::tuple{Array(std::vector{topic_pat(e.span)}), prism_rtl::val(prism_rtl::val(b))});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ETopicField>(_m)) {
            auto&& f = prism_rtl::as<crate::syntax::ExprKind::ETopicField>(_m).a0;
            _v.set(std::tuple{Array(std::vector{topic_pat(e.span)}), crate::syntax::LambdaBody(crate::syntax::LambdaBody::LbExpr{prism_rtl::rc(topic_field_expr(e.span, f))})});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ETopicIndex>(_m)) {
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::ETopicIndex>(_m).a0;
            _v.set(std::tuple{Array(std::vector{topic_pat(e.span)}), crate::syntax::LambdaBody(crate::syntax::LambdaBody::LbExpr{prism_rtl::rc(topic_index_expr(e.span, prism_rtl::val(prism_rtl::val(x))))})});
            goto _done;
        }
        {
            _v.set(std::tuple{Array<crate::syntax::Pattern_>{}, crate::syntax::LambdaBody(crate::syntax::LambdaBody::LbExpr{prism_rtl::rc(e)})});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [exp_params, exp_res_opt, st0] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::check::types::Ty>, std::optional<crate::check::types::Ty>, crate::check::types::St>> _v;
        if (prism_rtl::is_some(expected_opt)) {
            auto&& t = prism_rtl::some_of(expected_opt);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<crate::check::types::Ty>, std::optional<crate::check::types::Ty>, crate::check::types::St>> _v;
                auto&& _m = crate::check::types::recording::walk(st, t);
                if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
                    auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
                    auto&& r = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
                    _v.set(len(ps) == len(params)
                        ? std::tuple{ps, std::optional(prism_rtl::val(r)), st}
                        : std::tuple{Array<crate::check::types::Ty>{}, std::optional<crate::check::types::Ty>{}, crate::check::types::recording::err(st, Text::lit("mismatch"), e.span, prism_rtl::cat("this lambda takes ", crate::check::errors::count_word(len(params)), " parameter", len(params) == Nat(1u) ? Text::lit("") : Text::lit("s"), "; here ", crate::check::errors::count_word(len(ps)), " ", len(ps) == Nat(1u) ? Text::lit("is") : Text::lit("are"), " wanted"))});
                    goto _done;
                }
                {
                    _v.set(std::tuple{Array<crate::check::types::Ty>{}, std::optional<crate::check::types::Ty>{}, st});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(expected_opt)) {
            _v.set(std::tuple{Array<crate::check::types::Ty>{}, std::optional<crate::check::types::Ty>{}, st});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto [env2, ptys, st1] = run_to_end(fold_job(crate::check::errors::range0(len(params)), std::tuple{env, Array<crate::check::types::Ty>{}, st0}, ({
        auto params_1 = params;
        auto e_2 = e;
        auto exp_params_3 = exp_params;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, Array<crate::check::types::Ty>, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, Array<crate::check::types::Ty>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::expr::Env, Array<crate::check::types::Ty>, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto params_1_4 = params_1;
            auto e_2_4 = e_2;
            auto exp_params_3_4 = exp_params_3;
            entered(once_job([=]() {
            return ({
                auto [en, acc, s] = p0;
                auto i = p1;
                ({
                auto p_ = or_(index(params_1_4, i), crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span = e_2_4.span});
                auto [pt, s2] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                    auto&& _m = index(exp_params_3_4, i);
                    if (prism_rtl::is_some(_m)) {
                        auto&& t = prism_rtl::some_of(_m);
                        _v.set(std::tuple{t, s});
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(crate::check::types::fresh_var(s, true, Text::lit("")));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                call_then(crate::check::expr::patterns::start_bind_pattern(crate::check::expr::lets::unpend(en), s2, p_, pt, false), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> bind_pattern_28085) {
                return ({
                    auto [en2, s3] = bind_pattern_28085;
                    (prism_rtl::finished(std::tuple{en2, crate::prelude::push(acc, pt), s3}));
                });
            });
            });
            });
        }));
        });
    }));
    })));
    auto outer_color = prism_rtl::val(st1).color;
    auto outer_why = prism_rtl::val(st1).color_why;
    auto outer_flex = prism_rtl::val(st1).color_flex;
    auto [lcol, st1b] = crate::check::types::fresh_col(st1);
    auto st2 = ({
        crate::check::types::St this_ = st1b;
        this_.color = crate::check::types::Col(crate::check::types::Col::CBound{});
        this_.color_why = Text::lit("");
        this_.color_flex = Array<std::tuple<crate::check::types::Col, Text, crate::syntax::Range>>{};
        this_;
    });
    auto [rt, st3] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
        if (prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(body)) {
            auto&& x = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(body).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                if (prism_rtl::is_some(exp_res_opt)) {
                    auto&& r = prism_rtl::some_of(exp_res_opt);
                    _v.set(({
                        auto s4 = crate::check::expr::check(env2, st2, prism_rtl::val(prism_rtl::val(x)), r);
                        std::tuple{r, s4};
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(exp_res_opt)) {
                    _v.set(crate::check::expr::infer(env2, st2, prism_rtl::val(prism_rtl::val(x))));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(body)) {
            auto&& b = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(body).a0;
            _v.set(infer_body_block(env2, st2, b, exp_res_opt));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st3b = crate::check::types::colors::settle_body(st3, lcol, Text::lit(""));
    auto st3c = crate::check::types::colors::add_leq(st3b, prism_rtl::val(st3b).color, lcol, e.span, Text::lit("lambda"), Text::lit(""), prism_rtl::val(st3b).color_why);
    auto st4 = ({
        crate::check::types::St this_ = st3c;
        this_.color = outer_color;
        this_.color_why = outer_why;
        this_.color_flex = outer_flex;
        this_;
    });
    return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyFn{lcol, ptys, prism_rtl::rc(rt)}), crate::check::types::recording::note_fn(st4, e.span, Text::lit("lambda"), lcol, lcol)};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferBareLambda::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& e = this->e;
    const auto& expected_opt = this->expected_opt;
    auto [params, body] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::syntax::Pattern_>, crate::syntax::LambdaBody>> _v;
        auto&& _m = prism_rtl::val(prism_rtl::val(e).kind);
        if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0)) {
            auto&& ps = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0);
            auto&& b = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
            _v.set(std::tuple{ps, prism_rtl::val(prism_rtl::val(b))});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0)) {
            auto&& b = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
            _v.set(std::tuple{Array(std::vector{topic_pat(prism_rtl::val(e).span)}), prism_rtl::val(prism_rtl::val(b))});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ETopicField>(_m)) {
            auto&& f = prism_rtl::as<crate::syntax::ExprKind::ETopicField>(_m).a0;
            _v.set(std::tuple{Array(std::vector{topic_pat(prism_rtl::val(e).span)}), crate::syntax::LambdaBody(crate::syntax::LambdaBody::LbExpr{prism_rtl::rc(topic_field_expr(prism_rtl::val(e).span, f))})});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ETopicIndex>(_m)) {
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::ETopicIndex>(_m).a0;
            _v.set(std::tuple{Array(std::vector{topic_pat(prism_rtl::val(e).span)}), crate::syntax::LambdaBody(crate::syntax::LambdaBody::LbExpr{prism_rtl::rc(topic_index_expr(prism_rtl::val(e).span, prism_rtl::val(prism_rtl::val(x))))})});
            goto _done;
        }
        {
            _v.set(std::tuple{Array<crate::syntax::Pattern_>{}, crate::syntax::LambdaBody(crate::syntax::LambdaBody::LbExpr{prism_rtl::rc(e)})});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [exp_params, exp_res_opt, st0] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::check::types::Ty>, std::optional<crate::check::types::Ty>, crate::check::types::St>> _v;
        if (prism_rtl::is_some(expected_opt)) {
            auto&& t = prism_rtl::some_of(expected_opt);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<crate::check::types::Ty>, std::optional<crate::check::types::Ty>, crate::check::types::St>> _v;
                auto&& _m = crate::check::types::recording::walk(st, t);
                if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
                    auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
                    auto&& r = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
                    _v.set(len(ps) == len(params)
                        ? std::tuple{ps, std::optional(prism_rtl::val(r)), st}
                        : std::tuple{Array<crate::check::types::Ty>{}, std::optional<crate::check::types::Ty>{}, crate::check::types::recording::err(st, Text::lit("mismatch"), prism_rtl::val(e).span, prism_rtl::cat("this lambda takes ", crate::check::errors::count_word(len(params)), " parameter", len(params) == Nat(1u) ? Text::lit("") : Text::lit("s"), "; here ", crate::check::errors::count_word(len(ps)), " ", len(ps) == Nat(1u) ? Text::lit("is") : Text::lit("are"), " wanted"))});
                    goto _done;
                }
                {
                    _v.set(std::tuple{Array<crate::check::types::Ty>{}, std::optional<crate::check::types::Ty>{}, st});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(expected_opt)) {
            _v.set(std::tuple{Array<crate::check::types::Ty>{}, std::optional<crate::check::types::Ty>{}, st});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto e_1 = e;
    auto env_2 = env;
    return call_value(fold_job(crate::check::errors::range0(len(params)), std::tuple{env_2, Array<crate::check::types::Ty>{}, st0}, ({
        auto params_3 = params;
        auto e_1_4 = e_1;
        auto exp_params_4 = exp_params;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, Array<crate::check::types::Ty>, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, Array<crate::check::types::Ty>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::expr::Env, Array<crate::check::types::Ty>, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto params_3_5 = params_3;
            auto e_1_4_5 = e_1_4;
            auto exp_params_4_5 = exp_params_4;
            entered(once_job([=]() {
            return ({
                auto [en, acc, s] = p0;
                auto i = p1;
                ({
                auto p_ = or_(index(params_3_5, i), crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span = prism_rtl::val(e_1_4_5).span});
                auto [pt, s2] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                    auto&& _m = index(exp_params_4_5, i);
                    if (prism_rtl::is_some(_m)) {
                        auto&& t = prism_rtl::some_of(_m);
                        _v.set(std::tuple{t, s});
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(crate::check::types::fresh_var(s, true, Text::lit("")));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                call_then(crate::check::expr::patterns::start_bind_pattern(crate::check::expr::lets::unpend(en), s2, p_, pt, false), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> bind_pattern_28085) {
                return ({
                    auto [en2, s3] = bind_pattern_28085;
                    (prism_rtl::finished(std::tuple{en2, crate::prelude::push(acc, pt), s3}));
                });
            });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<crate::check::expr::Env, Array<crate::check::types::Ty>, crate::check::types::St> fold_27816) {
        return ({
            auto [env2, ptys, st1] = fold_27816;
            auto outer_color = prism_rtl::val(st1).color;
            auto outer_why = prism_rtl::val(st1).color_why;
            auto outer_flex = prism_rtl::val(st1).color_flex;
            auto [lcol, st1b] = crate::check::types::fresh_col(st1);
            auto st2 = ({
                crate::check::types::St this_ = st1b;
                this_.color = crate::check::types::Col(crate::check::types::Col::CBound{});
                this_.color_why = Text::lit("");
                this_.color_flex = Array<std::tuple<crate::check::types::Col, Text, crate::syntax::Range>>{};
                this_;
            });
            auto [rt, st3] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                if (prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(body)) {
                    auto&& x = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(body).a0;
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                        if (prism_rtl::is_some(exp_res_opt)) {
                            auto&& r = prism_rtl::some_of(exp_res_opt);
                            _v.set(({
                                auto s4 = crate::check::expr::check(env2, st2, prism_rtl::val(prism_rtl::val(x)), r);
                                std::tuple{r, s4};
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_none(exp_res_opt)) {
                            _v.set(crate::check::expr::infer(env2, st2, prism_rtl::val(prism_rtl::val(x))));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(body)) {
                    auto&& b = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(body).a0;
                    _v.set(infer_body_block(env2, st2, b, exp_res_opt));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            call_then(crate::check::types::colors::start_settle_body(st3, lcol, Text::lit("")), [=](crate::check::types::St settle_body_28671) {
            return ({
                auto st3b = settle_body_28671;
                call_then(crate::check::types::colors::start_add_leq(st3b, prism_rtl::val(st3b).color, lcol, prism_rtl::val(e_1).span, Text::lit("lambda"), Text::lit(""), prism_rtl::val(st3b).color_why), [=](crate::check::types::St add_leq_28711) {
                return ({
                    auto st3c = add_leq_28711;
                    auto st4 = ({
                        crate::check::types::St this_ = st3c;
                        this_.color = outer_color;
                        this_.color_why = outer_why;
                        this_.color_flex = outer_flex;
                        this_;
                    });
                    (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyFn{lcol, ptys, prism_rtl::rc(rt)}), crate::check::types::recording::note_fn(st4, prism_rtl::val(e_1).span, Text::lit("lambda"), lcol, lcol)}));
                });
            });
            });
        });
        });
    });
}


/// `Start InferBareLambda, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_bare_lambda(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr e, std::optional<crate::check::types::Ty> expected_opt) {
    return prism_rtl::make_rc<InferBareLambda>(env, st, e, expected_opt);
}


/// TopicPat: fn Range -> Pattern
crate::syntax::Pattern_ topic_pat(const crate::syntax::Range& span) {
    return crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PName{topic_sname(span)})), .span = span};
}


/// TopicSName: fn Range -> SName
crate::syntax::SName topic_sname(const crate::syntax::Range& span) {
    return crate::syntax::SName{.sigils = Text::lit(""), .path_ = Array(std::vector{Text::lit("_")}), .span = span};
}


/// TopicExpr: fn Range -> Expr
crate::syntax::Expr topic_expr(const crate::syntax::Range& span) {
    return crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{topic_sname(span)})), .span = span};
}


/// TopicFieldExpr: fn Range, Ident -> Expr
crate::syntax::Expr topic_field_expr(const crate::syntax::Range& span, const crate::syntax::Ident& f) {
    return crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EField{prism_rtl::rc(topic_expr(span)), Text::lit(""), f})), .span = span};
}


/// TopicIndexExpr: fn Range, Expr -> Expr
crate::syntax::Expr topic_index_expr(const crate::syntax::Range& span, const crate::syntax::Expr& x) {
    return crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EIndex{prism_rtl::rc(topic_expr(span)), prism_rtl::rc(x)})), .span = span};
}


/// ArgNamed: fn Arg, Text -> Bool
bool arg_named(const crate::syntax::Arg& a, const Text& f) {
    auto&& _m = a.name;
    if (prism_rtl::is_some(_m)) {
        auto&& id = prism_rtl::some_of(_m);
        return prism_rtl::val(id).name == f;
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// InferBodyBlock: unbounded fn Env, St, Block, ?Ty -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_body_block(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Block& b, const std::optional<crate::check::types::Ty>& expected_opt) {
    auto [t, st2] = crate::check::expr::lets::infer_expr_block(env, st, b);
    if (prism_rtl::is_some(expected_opt)) {
        auto&& r = prism_rtl::some_of(expected_opt);
        return std::tuple{r, crate::check::types::unify::unify(st2, r, t, b.span)};
    }
    if (prism_rtl::is_none(expected_opt)) {
        return std::tuple{t, st2};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferBodyBlock::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& b = this->b;
    const auto& expected_opt = this->expected_opt;
    auto expected_opt_1 = expected_opt;
    auto b_2 = b;
    auto env_3 = env;
    auto st_4 = st;
    return call_then(crate::check::expr::lets::start_infer_expr_block(env_3, st_4, b_2), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_expr_block_29966) {
        return ({
            auto [t, st2] = infer_expr_block_29966;
            ({
            prism_rtl::is_some(expected_opt_1) ? ({
            auto&& r = prism_rtl::some_of(expected_opt_1);
            ({
            auto r_5 = r;
            call_then(crate::check::types::unify::start_unify(st2, r_5, t, prism_rtl::val(b_2).span), [=](crate::check::types::St unify_30032) { return prism_rtl::finished(std::tuple{r_5, unify_30032}); });
        });
        })
            : prism_rtl::is_none(expected_opt_1) ? prism_rtl::finished(std::tuple{t, st2})
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
}


/// `Start InferBodyBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_body_block(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Block b, std::optional<crate::check::types::Ty> expected_opt) {
    return prism_rtl::make_rc<InferBodyBlock>(env, st, b, expected_opt);
}

}  // namespace crate::check::expr::calls
