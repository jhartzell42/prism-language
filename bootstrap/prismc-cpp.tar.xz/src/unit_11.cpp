// The module `Check.Expr.Calls`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/expr/calls/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Expr.Calls`, from `target/bootstrap/cpp-src/prismc/check/expr/calls.prism`.
namespace crate::check::expr::calls {

bool Peeled::operator==(const Peeled& o) const { return events == o.events && dyns == o.dyns && opts == o.opts && opt_args == o.opt_args && lifted == o.lifted && broken == o.broken; }

void Peeled::show(Printer& p) const {
    p.record("Peeled", {{"events", events}, {"dyns", dyns}, {"opts", opts}, {"opt_args", opt_args}, {"lifted", lifted}, {"broken", broken}});
}

Pod Peeled::to_pod() const {
    return Pod::record("Peeled", {{"events", prism_rtl::to_pod(events)}, {"dyns", prism_rtl::to_pod(dyns)}, {"opts", prism_rtl::to_pod(opts)}, {"opt_args", prism_rtl::to_pod(opt_args)}, {"lifted", prism_rtl::to_pod(lifted)}, {"broken", prism_rtl::to_pod(broken)}});
}

Result<Peeled> Peeled::from_pod(const Pod& whole) {
    return Peeled{.events = TRY(prism_rtl::from_pod<Array<crate::syntax::Range>>(TRY(crate::prelude::field(whole, "events")))), .dyns = TRY(prism_rtl::from_pod<Array<crate::syntax::Range>>(TRY(crate::prelude::field(whole, "dyns")))), .opts = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "opts")))), .opt_args = TRY(prism_rtl::from_pod<Array<crate::syntax::Range>>(TRY(crate::prelude::field(whole, "opt_args")))), .lifted = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "lifted")))), .broken = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "broken"))))};
}


/// InferCall: unbounded fn Env, St, Expr, [Arg], Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_call(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& callee_p2, const Array<crate::syntax::Arg>& args_p3, const crate::syntax::Range& span_p4) {
    auto&& _m = prism_rtl::deref(callee_p2.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p5 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        auto local_p6 = crate::check::env::sname_key(n_p5);
        auto&& _m = crate::prelude::get(env_p0.locals, local_p6);
        if (prism_rtl::is_some(_m)) {
            auto&& sc_p7 = prism_rtl::some_of(_m);
            auto [t_p8, st2_p9] = crate::check::expr::instantiate_local(st_p1, sc_p7, callee_p2.span, local_p6);
            return apply_fn(env_p0, crate::check::types::recording::note_ty(st2_p9, callee_p2.span, t_p8), local_p6, t_p8, positional(args_p3), span_p4);
        }
        if (prism_rtl::is_none(_m)) {
            return call_global(env_p0, st_p1, n_p5, args_p3, span_p4, Array<crate::check::types::Ty>{}, callee_p2.span);
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m)) {
        auto&& target_pa = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
        auto&& tys_pb = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a1;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(target_pa).kind);
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n_pc = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            auto cx_pd = crate::check::expr::env_cx(env_p0);
            auto [given2_pe, st2_pf] = crate::check::env::reading::conv_types(cx_pd, st_p1, tys_pb);
            return call_global(env_p0, st2_pf, n_pc, args_p3, span_p4, given2_pe, callee_p2.span);
        }
        {
            return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("mismatch"), callee_p2.span, Text::lit("`<<T>>` applies to a function\'s name"))};
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_pg = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return infer_call(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(x_pg)), args_p3, span_p4);
    }
    {
        auto [t_ph, st2_pi] = crate::check::expr::infer(env_p0, st_p1, callee_p2);
        return apply_fn(env_p0, st2_pi, crate::check::expr::src_text(env_p0, callee_p2.span), t_ph, positional(args_p3), span_p4);
    }
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferCall::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& callee_p2 = this->callee_p2;
    const auto& args_p3 = this->args_p3;
    const auto& span_p4 = this->span_p4;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(callee_p2).kind);
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n_p5 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        ({
        auto local_p6 = crate::check::env::sname_key(n_p5);
        ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0).locals, local_p6);
        prism_rtl::is_some(_m) ? ({
        auto&& sc_p7 = prism_rtl::some_of(_m);
        ({
        auto args_p3_1 = args_p3;
        auto callee_p2_2 = callee_p2;
        auto env_p0_3 = env_p0;
        auto span_p4_4 = span_p4;
        auto st_p1_5 = st_p1;
        call_then(crate::check::expr::start_instantiate_local(st_p1_5, sc_p7, prism_rtl::deref(callee_p2_2).span, local_p6), [=, args_p3_1 = std::move(args_p3_1), env_p0_3 = std::move(env_p0_3), span_p4_4 = std::move(span_p4_4)](std::tuple<crate::check::types::Ty, crate::check::types::St> instantiate_local_1491) {
        return ({
            auto [t_p8, st2_p9] = instantiate_local_1491;
            (prism_rtl::more(prism_rtl::rc(ApplyFn(env_p0_3, crate::check::types::recording::note_ty(st2_p9, prism_rtl::deref(callee_p2_2).span, t_p8), local_p6, t_p8, positional(args_p3_1), span_p4_4))));
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(CallGlobal(env_p0, st_p1, n_p5, args_p3, span_p4, Array<crate::check::types::Ty>{}, prism_rtl::deref(callee_p2).span)))
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m) ? ({
        auto&& target_pa = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
        auto&& tys_pb = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a1;
        ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(target_pa).kind);
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n_pc = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        ({
        auto cx_pd = crate::check::expr::env_cx(env_p0);
        auto args_p3_1 = args_p3;
        auto callee_p2_2 = callee_p2;
        auto env_p0_3 = env_p0;
        auto n_pc_4 = n_pc;
        auto span_p4_5 = span_p4;
        auto st_p1_6 = st_p1;
        auto tys_pb_7 = tys_pb;
        call_then(crate::check::env::reading::start_conv_types(cx_pd, st_p1_6, tys_pb_7), [=, args_p3_1 = std::move(args_p3_1), callee_p2_2 = std::move(callee_p2_2), env_p0_3 = std::move(env_p0_3), n_pc_4 = std::move(n_pc_4), span_p4_5 = std::move(span_p4_5)](std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> conv_types_1826) {
        return ({
            auto [given2_pe, st2_pf] = conv_types_1826;
            (prism_rtl::more(prism_rtl::rc(CallGlobal(env_p0_3, st2_pf, n_pc_4, args_p3_1, span_p4_5, given2_pe, prism_rtl::deref(callee_p2_2).span))));
        });
    });
    });
    })
        : prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("mismatch"), prism_rtl::deref(callee_p2).span, Text::lit("`<<T>>` applies to a function\'s name"))});
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x_pg = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(InferCall(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(x_pg)), args_p3, span_p4)));
    })
        : ({
        auto args_p3_1 = args_p3;
        auto callee_p2_2 = callee_p2;
        auto env_p0_3 = env_p0;
        auto span_p4_4 = span_p4;
        auto st_p1_5 = st_p1;
        call_then(crate::check::expr::start_infer(env_p0_3, st_p1_5, callee_p2_2), [=, args_p3_1 = std::move(args_p3_1), span_p4_4 = std::move(span_p4_4)](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_2107) {
        return ({
            auto [t_ph, st2_pi] = infer_2107;
            (prism_rtl::more(prism_rtl::rc(ApplyFn(env_p0_3, st2_pi, crate::check::expr::src_text(env_p0_3, prism_rtl::deref(callee_p2_2).span), t_ph, positional(args_p3_1), span_p4_4))));
        });
    });
    });
    });
}


/// `Start InferCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_call(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr callee_p2, Array<crate::syntax::Arg> args_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<InferCall>(env_p0, st_p1, callee_p2, args_p3, span_p4);
}


/// Positional: fn [Arg] -> [Arg]
Array<crate::syntax::Arg> positional(const Array<crate::syntax::Arg>& args_p0) {
    return args_p0;
}


/// CallGlobal: unbounded fn Env, St, SName, [Arg], Range, [Ty], Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> call_global(const crate::check::expr::Env& env_p0, const crate::check::types::St& st0_p1, const crate::syntax::SName& n_p2, const Array<crate::syntax::Arg>& args_p3, const crate::syntax::Range& span_p4, const Array<crate::check::types::Ty>& explicit_p5, const crate::syntax::Range& cspan_p6) {
    auto [qk_o9, why_pa] = crate::check::env::names::resolve_value(env_p0.g, env_p0.home, n_p2);
    auto name_p7 = crate::check::env::sname_key(n_p2);
    auto st_p8 = crate::check::expr::collision_at(env_p0, st0_p1, why_pa, name_p7, n_p2.span);
    if (prism_rtl::is_none(qk_o9)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p8, Text::lit("unknown-name"), n_p2.span, prism_rtl::cat("nothing declares `", name_p7, "` here"))};
    }
    if (prism_rtl::is_some(qk_o9)) {
        auto&& qk_pb = prism_rtl::some_of(qk_o9);
        return why_pa == Text::lit("tag")
            ? tag_app(env_p0, st_p8, qk_pb, args_p3, span_p4, cspan_p6)
            : is_local_maker(qk_pb) && (!env_p0.in_update)
            ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), local_outside(st_p8, qk_pb, span_p4)}
            : ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
            auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0.g).vals, qk_pb);
            if (prism_rtl::is_some(_m)) {
                auto&& v_pc = prism_rtl::some_of(_m);
                _v.set(({
                    auto [t_pf, st2i_pg, inst_ph] = crate::check::types::schemes::instantiate_with(st_p8, prism_rtl::deref(v_pc).scheme, span_p4, explicit_p5);
                    auto [rigids_pi, st2_pj] = rank_two(st2i_pg, prism_rtl::deref(v_pc).scheme, inst_ph, len(explicit_p5), span_p4);
                    auto st3a_pd = note_callee(note_method_use(st2_pj, v_pc, span_p4), n_p2.span, cspan_p6, t_pf);
                    auto st3_pe = crate::check::types::bare_name(qk_pb) == Text::lit("Min")
                        ? crate::check::types::recording::note_size_ty(st3a_pd, span_p4, crate::check::types::recording::walk(st3a_pd, t_pf))
                        : st3a_pd;
                    (crate::check::types::bare_name(qk_pb) == Text::lit("Fold")) && (prism_rtl::deref(v_pc).home == Text::lit("Prelude"))
                    ? fold_app(env_p0, st3_pe, t_pf, args_p3, span_p4)
                    : ({
                    auto [rt_pk, st4_pl] = apply_fn(env_p0, st3_pe, name_p7, t_pf, args_p3, span_p4);
                    std::tuple{rt_pk, escaped(env_p0, st4_pl, rigids_pi, rt_pk, name_p7, span_p4)};
                });
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                    auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0.g).ctors, qk_pb);
                    if (prism_rtl::is_some(_m)) {
                        auto&& c_pm = prism_rtl::some_of(_m);
                        _v.set(ctor_app(env_p0, st_p8, c_pm, args_p3, span_p4, cspan_p6));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p8, Text::lit("unknown-name"), n_p2.span, prism_rtl::cat("`", name_p7, "` has no signature line"))});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> CallGlobal::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st0_p1 = this->st0_p1;
    const auto& n_p2 = this->n_p2;
    const auto& args_p3 = this->args_p3;
    const auto& span_p4 = this->span_p4;
    const auto& explicit_p5 = this->explicit_p5;
    const auto& cspan_p6 = this->cspan_p6;
    auto [qk_o9, why_pa] = crate::check::env::names::resolve_value(prism_rtl::deref(env_p0).g, prism_rtl::deref(env_p0).home, n_p2);
    auto name_p7 = crate::check::env::sname_key(n_p2);
    auto st_p8 = crate::check::expr::collision_at(env_p0, st0_p1, why_pa, name_p7, prism_rtl::deref(n_p2).span);
    return ({
        prism_rtl::is_none(qk_o9) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p8, Text::lit("unknown-name"), prism_rtl::deref(n_p2).span, prism_rtl::cat("nothing declares `", name_p7, "` here"))})
        : prism_rtl::is_some(qk_o9) ? ({
        auto&& qk_pb = prism_rtl::some_of(qk_o9);
        why_pa == Text::lit("tag")
        ? prism_rtl::more(prism_rtl::rc(TagApp(env_p0, st_p8, qk_pb, args_p3, span_p4, cspan_p6)))
        : is_local_maker(qk_pb) && (!prism_rtl::deref(env_p0).in_update)
        ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), local_outside(st_p8, qk_pb, span_p4)})
        : ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env_p0).g).vals, qk_pb);
        prism_rtl::is_some(_m) ? ({
        auto&& v_pc = prism_rtl::some_of(_m);
        ({
        auto args_p3_1 = args_p3;
        auto cspan_p6_2 = cspan_p6;
        auto env_p0_3 = env_p0;
        auto explicit_p5_4 = explicit_p5;
        auto n_p2_5 = n_p2;
        auto qk_pb_6 = qk_pb;
        auto span_p4_7 = span_p4;
        call_then(crate::check::types::schemes::start_instantiate_with(st_p8, prism_rtl::deref(v_pc).scheme, span_p4_7, explicit_p5_4), [=, args_p3_1 = std::move(args_p3_1), cspan_p6_2 = std::move(cspan_p6_2), env_p0_3 = std::move(env_p0_3), n_p2_5 = std::move(n_p2_5), qk_pb_6 = std::move(qk_pb_6)](std::tuple<crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst> instantiate_with_2931) {
        return ({
            auto [t_pf, st2i_pg, inst_ph] = instantiate_with_2931;
            call_then(start_rank_two(st2i_pg, prism_rtl::deref(v_pc).scheme, inst_ph, len(explicit_p5_4), span_p4_7), [=](std::tuple<Array<Text>, crate::check::types::St> rank_two_3018) {
            return ({
                auto [rigids_pi, st2_pj] = rank_two_3018;
                auto st3a_pd = note_callee(note_method_use(st2_pj, v_pc, span_p4_7), prism_rtl::deref(n_p2_5).span, cspan_p6_2, t_pf);
                auto st3_pe = crate::check::types::bare_name(qk_pb_6) == Text::lit("Min")
                    ? crate::check::types::recording::note_size_ty(st3a_pd, span_p4_7, crate::check::types::recording::walk(st3a_pd, t_pf))
                    : st3a_pd;
                (crate::check::types::bare_name(qk_pb_6) == Text::lit("Fold")) && (prism_rtl::deref(v_pc).home == Text::lit("Prelude"))
                ? prism_rtl::more(prism_rtl::rc(FoldApp(env_p0_3, st3_pe, t_pf, args_p3_1, span_p4_7)))
                : call_then(start_apply_fn(env_p0_3, st3_pe, name_p7, t_pf, args_p3_1, span_p4_7), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> apply_fn_3436) {
                return ({
                    auto [rt_pk, st4_pl] = apply_fn_3436;
                    call_then(start_escaped(env_p0_3, st4_pl, rigids_pi, rt_pk, name_p7, span_p4_7), [=](crate::check::types::St escaped_3505) { return prism_rtl::finished(std::tuple{rt_pk, escaped_3505}); });
                });
            });
            });
        });
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env_p0).g).ctors, qk_pb);
        prism_rtl::is_some(_m) ? ({
        auto&& c_pm = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(CtorApp(env_p0, st_p8, c_pm, args_p3, span_p4, cspan_p6)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p8, Text::lit("unknown-name"), prism_rtl::deref(n_p2).span, prism_rtl::cat("`", name_p7, "` has no signature line"))})
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CallGlobal, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_call_global(crate::check::expr::Env env_p0, crate::check::types::St st0_p1, crate::syntax::SName n_p2, Array<crate::syntax::Arg> args_p3, crate::syntax::Range span_p4, Array<crate::check::types::Ty> explicit_p5, crate::syntax::Range cspan_p6) {
    return prism_rtl::make_rc<CallGlobal>(env_p0, st0_p1, n_p2, args_p3, span_p4, explicit_p5, cspan_p6);
}


/// RankTwo: unbounded fn St, Scheme, Inst, Nat, Range -> (([Text], St))
std::tuple<Array<Text>, crate::check::types::St> rank_two(const crate::check::types::St& st_p0, const crate::check::types::Scheme& sc_p1, const crate::check::types::schemes::Inst& inst_p2, const Nat& n_explicit_p3, const crate::syntax::Range& span_p4) {
    auto qs_p5 = filter(crate::check::errors::range0(len(sc_p1.qs)), [&](const Nat& i_p6) { return (i_p6 >= n_explicit_p3) && is_rank_two(or_(index(sc_p1.qs, i_p6), Text::lit("")), sc_p1.ty); });
    return run_to_end(fold_job(qs_p5, std::tuple{Array<Text>{}, st_p0}, ({
        auto sc_p1_1 = sc_p1;
        auto inst_p2_2 = inst_p2;
        auto span_p4_3 = span_p4;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, crate::check::types::St>>(std::tuple<std::tuple<Array<Text>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, sc_p1_1 = std::move(sc_p1_1), inst_p2_2 = std::move(inst_p2_2), span_p4_3 = std::move(span_p4_3)](std::tuple<std::tuple<Array<Text>, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sc_p1_1_4 = sc_p1_1;
            auto inst_p2_2_4 = inst_p2_2;
            auto span_p4_3_4 = span_p4_3;
            entered(once_job([=, sc_p1_1_4 = std::move(sc_p1_1_4), inst_p2_2_4 = std::move(inst_p2_2_4), span_p4_3_4 = std::move(span_p4_3_4)]() {
            return ({
                auto [acc_p7, s_p8] = p0;
                auto i_p9 = p1;
                ({
                auto q_pa = or_(index(sc_p1_1_4.qs, i_p9), Text::lit(""));
                auto rigid_pb = prism_rtl::cat(q_pa, "\'", prism_rtl::deref(s_p8).next);
                auto s2_pc = ({
                    crate::check::types::St this_ = s_p8;
                    this_.next = this_.next + Nat(1u);
                    (std::move(this_));
                });
                call_then(crate::check::types::unify::start_unify(s2_pc, or_(crate::prelude::get(inst_p2_2_4.tys, q_pa), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), crate::check::types::Ty(crate::check::types::Ty::TyRigid{rigid_pb}), span_p4_3_4), [=](crate::check::types::St unify_4584) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc_p7, rigid_pb), unify_4584}); });
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Array<Text>, crate::check::types::St>> RankTwo::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& sc_p1 = this->sc_p1;
    const auto& inst_p2 = this->inst_p2;
    const auto& n_explicit_p3 = this->n_explicit_p3;
    const auto& span_p4 = this->span_p4;
    auto qs_p5 = filter(crate::check::errors::range0(len(prism_rtl::deref(sc_p1).qs)), [&](const Nat& i_p6) { return (i_p6 >= n_explicit_p3) && is_rank_two(or_(index(prism_rtl::deref(sc_p1).qs, i_p6), Text::lit("")), prism_rtl::deref(sc_p1).ty); });
    return fold_job(qs_p5, std::tuple{Array<Text>{}, st_p0}, ({
        auto sc_p1_1 = sc_p1;
        auto inst_p2_2 = inst_p2;
        auto span_p4_3 = span_p4;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, crate::check::types::St>>(std::tuple<std::tuple<Array<Text>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, sc_p1_1 = std::move(sc_p1_1), inst_p2_2 = std::move(inst_p2_2), span_p4_3 = std::move(span_p4_3)](std::tuple<std::tuple<Array<Text>, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sc_p1_1_4 = sc_p1_1;
            auto inst_p2_2_4 = inst_p2_2;
            auto span_p4_3_4 = span_p4_3;
            entered(once_job([=, sc_p1_1_4 = std::move(sc_p1_1_4), inst_p2_2_4 = std::move(inst_p2_2_4), span_p4_3_4 = std::move(span_p4_3_4)]() {
            return ({
                auto [acc_p7, s_p8] = p0;
                auto i_p9 = p1;
                ({
                auto q_pa = or_(index(prism_rtl::deref(sc_p1_1_4).qs, i_p9), Text::lit(""));
                auto rigid_pb = prism_rtl::cat(q_pa, "\'", prism_rtl::deref(s_p8).next);
                auto s2_pc = ({
                    crate::check::types::St this_ = s_p8;
                    this_.next = this_.next + Nat(1u);
                    (std::move(this_));
                });
                call_then(crate::check::types::unify::start_unify(s2_pc, or_(crate::prelude::get(prism_rtl::deref(inst_p2_2_4).tys, q_pa), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), crate::check::types::Ty(crate::check::types::Ty::TyRigid{rigid_pb}), span_p4_3_4), [=](crate::check::types::St unify_4584) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc_p7, rigid_pb), unify_4584}); });
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start RankTwo, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<Text>, crate::check::types::St>> start_rank_two(crate::check::types::St st_p0, crate::check::types::Scheme sc_p1, crate::check::types::schemes::Inst inst_p2, Nat n_explicit_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<RankTwo>(st_p0, sc_p1, inst_p2, n_explicit_p3, span_p4);
}


/// IsRankTwo: fn Text, Ty -> Bool
bool is_rank_two(const Text& q_p0, const crate::check::types::Ty& t_p1) {
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p1)) {
        auto&& ps_p2 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a1;
        auto&& res_p3 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a2;
        auto holding_p4 = filter(ps_p2, [&](const crate::check::types::Ty& p_p5) { return qoccurs(q_p0, p_p5); });
        return (len(holding_p4) != Nat(1u)) || qoccurs(q_p0, prism_rtl::deref(prism_rtl::deref(res_p3)))
            ? false
            : ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = index(holding_p4, Nat(0u));
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::check::types::Ty::TyFn>(prism_rtl::some_of(_m))) {
                _v.set(elem_out_q(q_p0, or_(index(holding_p4, Nat(0u)), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))));
                goto _done;
            }
            {
                _v.set(false);
                goto _done;
            }
        _done:
            _v.take();
        });
    }
    {
        return false;
    }
}


/// QOccurs: fn Text, Ty -> Bool
bool qoccurs(const Text& q_p0, const crate::check::types::Ty& t_p1) {
    if (prism_rtl::is<crate::check::types::Ty::TyQ>(t_p1)) {
        auto&& n_p2 = prism_rtl::as<crate::check::types::Ty::TyQ>(t_p1).a0;
        return n_p2 == q_p0;
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1)) {
        auto&& args_p3 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        return fold(args_p3, false, [&](const bool& seen_p4, const crate::check::types::Ty& a_p5) { return prism_rtl::deref(seen_p4) || qoccurs(q_p0, a_p5); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p1)) {
        auto&& ps_p6 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a1;
        auto&& r_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a2;
        return fold(ps_p6, qoccurs(q_p0, prism_rtl::deref(prism_rtl::deref(r_p7))), [&](const bool& seen_p8, const crate::check::types::Ty& a_p9) { return prism_rtl::deref(seen_p8) || qoccurs(q_p0, a_p9); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p1)) {
        auto&& ts_pa = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p1).a0;
        return fold(ts_pa, false, [&](const bool& seen_pb, const crate::check::types::Ty& a_pc) { return prism_rtl::deref(seen_pb) || qoccurs(q_p0, a_pc); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p1)) {
        auto&& e_pd = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p1).a0;
        return qoccurs(q_p0, prism_rtl::deref(prism_rtl::deref(e_pd)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p1)) {
        auto&& k_pe = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a0;
        auto&& v_pf = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a1;
        return qoccurs(q_p0, prism_rtl::deref(prism_rtl::deref(k_pe))) || qoccurs(q_p0, prism_rtl::deref(prism_rtl::deref(v_pf)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p1)) {
        auto&& i_pg = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        return qoccurs(q_p0, prism_rtl::deref(prism_rtl::deref(i_pg)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p1)) {
        auto&& i_ph = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p1).a0;
        return qoccurs(q_p0, prism_rtl::deref(prism_rtl::deref(i_ph)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t_p1)) {
        auto&& o_pi = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p1).a1;
        return qoccurs(q_p0, prism_rtl::deref(prism_rtl::deref(o_pi)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p1)) {
        auto&& i_pj = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p1).a1;
        return qoccurs(q_p0, prism_rtl::deref(prism_rtl::deref(i_pj)));
    }
    {
        return false;
    }
}


/// ElemOutQ: fn Text, Ty -> Bool
bool elem_out_q(const Text& q_p0, const crate::check::types::Ty& t_p1) {
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t_p1)) {
        auto&& o_p2 = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p1).a1;
        return (prism_rtl::deref(prism_rtl::deref(o_p2)) == crate::check::types::Ty(crate::check::types::Ty::TyQ{q_p0})) || elem_out_q(q_p0, prism_rtl::deref(prism_rtl::deref(o_p2)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1)) {
        auto&& args_p3 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        return fold(args_p3, false, [&](const bool& seen_p4, const crate::check::types::Ty& a_p5) { return prism_rtl::deref(seen_p4) || elem_out_q(q_p0, a_p5); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p1)) {
        auto&& ps_p6 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a1;
        auto&& r_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a2;
        return fold(ps_p6, elem_out_q(q_p0, prism_rtl::deref(prism_rtl::deref(r_p7))), [&](const bool& seen_p8, const crate::check::types::Ty& a_p9) { return prism_rtl::deref(seen_p8) || elem_out_q(q_p0, a_p9); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p1)) {
        auto&& ts_pa = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p1).a0;
        return fold(ts_pa, false, [&](const bool& seen_pb, const crate::check::types::Ty& a_pc) { return prism_rtl::deref(seen_pb) || elem_out_q(q_p0, a_pc); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p1)) {
        auto&& e_pd = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p1).a0;
        return elem_out_q(q_p0, prism_rtl::deref(prism_rtl::deref(e_pd)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p1)) {
        auto&& k_pe = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a0;
        auto&& v_pf = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a1;
        return elem_out_q(q_p0, prism_rtl::deref(prism_rtl::deref(k_pe))) || elem_out_q(q_p0, prism_rtl::deref(prism_rtl::deref(v_pf)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p1)) {
        auto&& i_pg = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        return elem_out_q(q_p0, prism_rtl::deref(prism_rtl::deref(i_pg)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p1)) {
        auto&& i_ph = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p1).a0;
        return elem_out_q(q_p0, prism_rtl::deref(prism_rtl::deref(i_ph)));
    }
    {
        return false;
    }
}


/// Escaped: unbounded fn Env, St, [Text], Ty, Text, Range -> St
crate::check::types::St escaped(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Array<Text>& rigids_p2, const crate::check::types::Ty& rt_p3, const Text& fname_p4, const crate::syntax::Range& span_p5) {
    return run_to_end(fold_job(rigids_p2, st_p1, ({
        auto env_p0_1 = env_p0;
        auto rt_p3_2 = rt_p3;
        auto span_p5_3 = span_p5;
        auto fname_p4_4 = fname_p4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Text>)>>(prism_rtl::rc([=, env_p0_1 = std::move(env_p0_1), rt_p3_2 = std::move(rt_p3_2), span_p5_3 = std::move(span_p5_3), fname_p4_4 = std::move(fname_p4_4)](std::tuple<crate::check::types::St, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_p0_1_5 = env_p0_1;
            auto rt_p3_2_5 = rt_p3_2;
            auto span_p5_3_5 = span_p5_3;
            auto fname_p4_4_5 = fname_p4_4;
            entered(once_job([=, env_p0_1_5 = std::move(env_p0_1_5), rt_p3_2_5 = std::move(rt_p3_2_5), span_p5_3_5 = std::move(span_p5_3_5), fname_p4_4_5 = std::move(fname_p4_4_5)]() {
            return ({
                auto s_p6 = p0;
                auto r_p7 = p1;
                call_value(filter_job(keys(env_p0_1_5.locals), ({
                auto s_p6_5 = s_p6;
                auto r_p7_6 = r_p7;
                auto env_p0_1_5_7 = env_p0_1_5;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, s_p6_5 = std::move(s_p6_5), r_p7_6 = std::move(r_p7_6), env_p0_1_5_7 = std::move(env_p0_1_5_7)](Text p0) {
                return ({
                    auto s_p6_5_7 = s_p6_5;
                    auto r_p7_6_7 = r_p7_6;
                    auto env_p0_1_5_7_7 = env_p0_1_5_7;
                    entered(once_job([=, s_p6_5_7 = std::move(s_p6_5_7), r_p7_6_7 = std::move(r_p7_6_7), env_p0_1_5_7_7 = std::move(env_p0_1_5_7_7)]() {
                    return ({
                        auto k_p9 = p0;
                        (prism_rtl::more(prism_rtl::rc(HasRigid(s_p6_5_7, r_p7_6_7, prism_rtl::deref(or_(crate::prelude::get(env_p0_1_5_7_7.locals, k_p9), crate::check::types::schemes::mono(crate::check::types::Ty(crate::check::types::Ty::TyErr{})))).ty))));
                    });
                }));
                });
            })));
            })), [=](Array<Text> filter_6547) {
                return ({
                    auto outside_p8 = filter_6547;
                    call_then(start_has_rigid(s_p6, r_p7, rt_p3_2_5), [=, outside_p8 = std::move(outside_p8)](bool has_rigid_6636) {
                    return has_rigid_6636
                        ? prism_rtl::finished(crate::check::types::recording::err(s_p6, Text::lit("refinement-escape"), span_p5_3_5, prism_rtl::cat("the call\'s result takes the output of the element `", fname_p4_4_5, "`\'s supplier answers, which is the supplier\'s alone (rank-2)")))
                        : ({
                        auto&& _m = index(outside_p8, Nat(0u));
                        prism_rtl::is_some(_m) ? ({
                        auto&& k_pa = prism_rtl::some_of(_m);
                        prism_rtl::finished(crate::check::types::recording::err(s_p6, Text::lit("refinement-escape"), span_p5_3_5, prism_rtl::cat("`", k_pa, "`, outside the supplier `", fname_p4_4_5, "` is given, takes the output of the element the supplier answers, which is the supplier\'s alone (rank-2)")));
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(s_p6)
                        : throw prism_rtl::Panic("no arm matched");
                    });
                });
                });
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<crate::check::types::St> Escaped::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& rigids_p2 = this->rigids_p2;
    const auto& rt_p3 = this->rt_p3;
    const auto& fname_p4 = this->fname_p4;
    const auto& span_p5 = this->span_p5;
    return fold_job(rigids_p2, st_p1, ({
        auto env_p0_1 = env_p0;
        auto rt_p3_2 = rt_p3;
        auto span_p5_3 = span_p5;
        auto fname_p4_4 = fname_p4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Text>)>>(prism_rtl::rc([=, env_p0_1 = std::move(env_p0_1), rt_p3_2 = std::move(rt_p3_2), span_p5_3 = std::move(span_p5_3), fname_p4_4 = std::move(fname_p4_4)](std::tuple<crate::check::types::St, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_p0_1_5 = env_p0_1;
            auto rt_p3_2_5 = rt_p3_2;
            auto span_p5_3_5 = span_p5_3;
            auto fname_p4_4_5 = fname_p4_4;
            entered(once_job([=, env_p0_1_5 = std::move(env_p0_1_5), rt_p3_2_5 = std::move(rt_p3_2_5), span_p5_3_5 = std::move(span_p5_3_5), fname_p4_4_5 = std::move(fname_p4_4_5)]() {
            return ({
                auto s_p6 = p0;
                auto r_p7 = p1;
                call_value(filter_job(keys(prism_rtl::deref(env_p0_1_5).locals), ({
                auto s_p6_5 = s_p6;
                auto r_p7_6 = r_p7;
                auto env_p0_1_5_7 = env_p0_1_5;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, s_p6_5 = std::move(s_p6_5), r_p7_6 = std::move(r_p7_6), env_p0_1_5_7 = std::move(env_p0_1_5_7)](Text p0) {
                return ({
                    auto s_p6_5_7 = s_p6_5;
                    auto r_p7_6_7 = r_p7_6;
                    auto env_p0_1_5_7_7 = env_p0_1_5_7;
                    entered(once_job([=, s_p6_5_7 = std::move(s_p6_5_7), r_p7_6_7 = std::move(r_p7_6_7), env_p0_1_5_7_7 = std::move(env_p0_1_5_7_7)]() {
                    return ({
                        auto k_p9 = p0;
                        (prism_rtl::more(prism_rtl::rc(HasRigid(s_p6_5_7, r_p7_6_7, prism_rtl::deref(or_(crate::prelude::get(prism_rtl::deref(env_p0_1_5_7_7).locals, k_p9), crate::check::types::schemes::mono(crate::check::types::Ty(crate::check::types::Ty::TyErr{})))).ty))));
                    });
                }));
                });
            })));
            })), [=](Array<Text> filter_6547) {
                return ({
                    auto outside_p8 = filter_6547;
                    call_then(start_has_rigid(s_p6, r_p7, rt_p3_2_5), [=, outside_p8 = std::move(outside_p8)](bool has_rigid_6636) {
                    return has_rigid_6636
                        ? prism_rtl::finished(crate::check::types::recording::err(s_p6, Text::lit("refinement-escape"), span_p5_3_5, prism_rtl::cat("the call\'s result takes the output of the element `", fname_p4_4_5, "`\'s supplier answers, which is the supplier\'s alone (rank-2)")))
                        : ({
                        auto&& _m = index(outside_p8, Nat(0u));
                        prism_rtl::is_some(_m) ? ({
                        auto&& k_pa = prism_rtl::some_of(_m);
                        prism_rtl::finished(crate::check::types::recording::err(s_p6, Text::lit("refinement-escape"), span_p5_3_5, prism_rtl::cat("`", k_pa, "`, outside the supplier `", fname_p4_4_5, "` is given, takes the output of the element the supplier answers, which is the supplier\'s alone (rank-2)")));
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(s_p6)
                        : throw prism_rtl::Panic("no arm matched");
                    });
                });
                });
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start Escaped, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_escaped(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<Text> rigids_p2, crate::check::types::Ty rt_p3, Text fname_p4, crate::syntax::Range span_p5) {
    return prism_rtl::make_rc<Escaped>(env_p0, st_p1, rigids_p2, rt_p3, fname_p4, span_p5);
}


/// HasRigid: unbounded fn St, Text, Ty -> Bool
bool has_rigid(const crate::check::types::St& st_p0, const Text& r_p1, const crate::check::types::Ty& t_p2) {
    return rigid_in(r_p1, crate::check::types::recording::zonk(st_p0, t_p2));
}


prism_rtl::Turn<bool> HasRigid::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& r_p1 = this->r_p1;
    const auto& t_p2 = this->t_p2;
    auto r_p1_1 = r_p1;
    auto st_p0_2 = st_p0;
    auto t_p2_3 = t_p2;
    return call_then(crate::check::types::recording::start_zonk(st_p0_2, t_p2_3), [=](crate::check::types::Ty zonk_7123) { return prism_rtl::finished(rigid_in(r_p1_1, zonk_7123)); });
}


/// `Start HasRigid, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_has_rigid(crate::check::types::St st_p0, Text r_p1, crate::check::types::Ty t_p2) {
    return prism_rtl::make_rc<HasRigid>(st_p0, r_p1, t_p2);
}


/// RigidIn: fn Text, Ty -> Bool
bool rigid_in(const Text& r_p0, const crate::check::types::Ty& t_p1) {
    if (prism_rtl::is<crate::check::types::Ty::TyRigid>(t_p1)) {
        auto&& n_p2 = prism_rtl::as<crate::check::types::Ty::TyRigid>(t_p1).a0;
        return n_p2 == r_p0;
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1)) {
        auto&& args_p3 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        return fold(args_p3, false, [&](const bool& seen_p4, const crate::check::types::Ty& a_p5) { return prism_rtl::deref(seen_p4) || rigid_in(r_p0, a_p5); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p1)) {
        auto&& ps_p6 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a1;
        auto&& res_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a2;
        return fold(ps_p6, rigid_in(r_p0, prism_rtl::deref(prism_rtl::deref(res_p7))), [&](const bool& seen_p8, const crate::check::types::Ty& a_p9) { return prism_rtl::deref(seen_p8) || rigid_in(r_p0, a_p9); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p1)) {
        auto&& ts_pa = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p1).a0;
        return fold(ts_pa, false, [&](const bool& seen_pb, const crate::check::types::Ty& a_pc) { return prism_rtl::deref(seen_pb) || rigid_in(r_p0, a_pc); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p1)) {
        auto&& e_pd = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p1).a0;
        return rigid_in(r_p0, prism_rtl::deref(prism_rtl::deref(e_pd)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p1)) {
        auto&& k_pe = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a0;
        auto&& v_pf = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a1;
        return rigid_in(r_p0, prism_rtl::deref(prism_rtl::deref(k_pe))) || rigid_in(r_p0, prism_rtl::deref(prism_rtl::deref(v_pf)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p1)) {
        auto&& i_pg = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        return rigid_in(r_p0, prism_rtl::deref(prism_rtl::deref(i_pg)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p1)) {
        auto&& i_ph = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p1).a0;
        return rigid_in(r_p0, prism_rtl::deref(prism_rtl::deref(i_ph)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t_p1)) {
        auto&& o_pi = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p1).a1;
        return rigid_in(r_p0, prism_rtl::deref(prism_rtl::deref(o_pi)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p1)) {
        auto&& i_pj = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p1).a1;
        return rigid_in(r_p0, prism_rtl::deref(prism_rtl::deref(i_pj)));
    }
    {
        return false;
    }
}


/// IsLocalMaker: fn Text -> Bool
bool is_local_maker(const Text& qk_p0) {
    return crate::check::types::has_text(Array(std::vector{Text::lit("Buffer.Numbered"), Text::lit("Buffer.Empty"), Text::lit("Table.Empty")}), qk_p0);
}


/// LocalOutside: fn St, Text, Range -> St
crate::check::types::St local_outside(const crate::check::types::St& st_p0, const Text& qk_p1, const crate::syntax::Range& span_p2) {
    return crate::check::types::recording::err_fix(st_p0, Text::lit("local-escapes"), span_p2, prism_rtl::cat("a `", or_(index(split_on(qk_p1, Text::lit(".")), Nat(0u)), qk_p1), "` lives only in an `&` block\'s local"), prism_rtl::cat("make it inside `update ...:` as `let &b = ", qk_p1, " ...`, and `Freeze &b` for the plain value"));
}


/// NoteCallee: fn St, Range, Range, Ty -> St
crate::check::types::St note_callee(const crate::check::types::St& st_p0, const crate::syntax::Range& at_p1, const crate::syntax::Range& cspan_p2, const crate::check::types::Ty& t_p3) {
    return at_p1 == cspan_p2
        ? crate::check::types::recording::note_ty(st_p0, at_p1, t_p3)
        : crate::check::types::recording::note_ty(crate::check::types::recording::note_ty(st_p0, at_p1, t_p3), cspan_p2, t_p3);
}


/// NoteMethodUse: fn St, ValInfo, Range -> St
crate::check::types::St note_method_use(const crate::check::types::St& st_p0, const crate::check::env::ValInfo& v_p1, const crate::syntax::Range& span_p2) {
    return v_p1.sort != Text::lit("method")
        ? st_p0
        : ({
        auto&& _cls_p3 = or_(index(prism_rtl::deref(v_p1.scheme).bounds, Nat(0u)), std::tuple{Text::lit(""), Text::lit("")});
        auto&& cls_p3 = std::get<1>(_cls_p3);
        (crate::check::types::recording::note_method(st_p0, span_p2, v_p1.qk, cls_p3));
    });
}


/// FoldApp: unbounded fn Env, St, Ty, [Arg], Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> fold_app(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::check::types::Ty& t_p2, const Array<crate::syntax::Arg>& args_p3, const crate::syntax::Range& span_p4) {
    auto lambda_arity_p5 = ({
        __label__ _done;
        prism_rtl::Slot<Nat> _v;
        auto&& _m = index(args_p3, Nat(2u));
        if (prism_rtl::is_some(_m)) {
            auto&& a_p6 = prism_rtl::some_of(_m);
            _v.set(lambda_arity(a_p6->value));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Nat(2u));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return lambda_arity_p5 == Nat(3u)
        ? ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
        auto&& _m = crate::check::types::recording::walk(st_p1, t_p2);
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& col_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0;
            auto&& params_p8 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            auto&& res_p9 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
            _v.set(({
                auto [k_pc, st1_pd] = crate::check::types::fresh_var(st_p1, false, Text::lit(""));
                auto [v_pe, st2_pf] = crate::check::types::fresh_var(st1_pd, false, Text::lit(""));
                auto [b_pg, st3_ph] = crate::check::types::fresh_var(st2_pf, false, Text::lit(""));
                auto step_col_pa = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::check::types::Col> _v;
                    auto&& _m = index(params_p8, Nat(2u));
                    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::check::types::Ty::TyFn>(prism_rtl::some_of(_m))) {
                        auto&& c_pi = prism_rtl::as<crate::check::types::Ty::TyFn>(prism_rtl::some_of(_m)).a0;
                        _v.set(c_pi);
                        goto _done;
                    }
                    {
                        _v.set(col_p7);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto params2_pb = Array(std::vector{crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(k_pc), prism_rtl::rc(v_pe)}), b_pg, crate::check::types::Ty(crate::check::types::Ty::TyFn{step_col_pa, Array(std::vector{b_pg, k_pc, v_pe}), prism_rtl::rc(b_pg)})});
                apply_rule(env_p0, st3_ph, Text::lit("Fold"), col_p7, params2_pb, b_pg, args_p3, span_p4);
            }));
            goto _done;
        }
        {
            _v.set(apply_fn(env_p0, st_p1, Text::lit("Fold"), t_p2, args_p3, span_p4));
            goto _done;
        }
    _done:
        _v.take();
    })
        : apply_fn(env_p0, st_p1, Text::lit("Fold"), t_p2, args_p3, span_p4);
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> FoldApp::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& t_p2 = this->t_p2;
    const auto& args_p3 = this->args_p3;
    const auto& span_p4 = this->span_p4;
    auto lambda_arity_p5 = ({
        __label__ _done;
        prism_rtl::Slot<Nat> _v;
        auto&& _m = index(args_p3, Nat(2u));
        if (prism_rtl::is_some(_m)) {
            auto&& a_p6 = prism_rtl::some_of(_m);
            _v.set(lambda_arity(a_p6->value));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Nat(2u));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return lambda_arity_p5 == Nat(3u)
        ? ({
        auto args_p3_1 = args_p3;
        auto env_p0_2 = env_p0;
        auto span_p4_3 = span_p4;
        auto st_p1_4 = st_p1;
        auto t_p2_5 = t_p2;
        call_then(crate::check::types::recording::start_walk(st_p1_4, t_p2_5), [=, args_p3_1 = std::move(args_p3_1), env_p0_2 = std::move(env_p0_2), span_p4_3 = std::move(span_p4_3)](crate::check::types::Ty walk_9063) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyFn>(walk_9063) ? ({
            auto&& col_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_9063).a0;
            auto&& params_p8 = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_9063).a1;
            auto&& res_p9 = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_9063).a2;
            ({
            auto [k_pc, st1_pd] = crate::check::types::fresh_var(st_p1_4, false, Text::lit(""));
            auto [v_pe, st2_pf] = crate::check::types::fresh_var(st1_pd, false, Text::lit(""));
            auto [b_pg, st3_ph] = crate::check::types::fresh_var(st2_pf, false, Text::lit(""));
            auto step_col_pa = ({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::Col> _v;
                auto&& _m = index(params_p8, Nat(2u));
                if (prism_rtl::is_some(_m) && prism_rtl::is<crate::check::types::Ty::TyFn>(prism_rtl::some_of(_m))) {
                    auto&& c_pi = prism_rtl::as<crate::check::types::Ty::TyFn>(prism_rtl::some_of(_m)).a0;
                    _v.set(c_pi);
                    goto _done;
                }
                {
                    _v.set(col_p7);
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto params2_pb = Array(std::vector{crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(k_pc), prism_rtl::rc(v_pe)}), b_pg, crate::check::types::Ty(crate::check::types::Ty::TyFn{step_col_pa, Array(std::vector{b_pg, k_pc, v_pe}), prism_rtl::rc(b_pg)})});
            (prism_rtl::more(prism_rtl::rc(ApplyRule(env_p0_2, st3_ph, Text::lit("Fold"), col_p7, params2_pb, b_pg, args_p3_1, span_p4_3))));
        });
        })
            : prism_rtl::more(prism_rtl::rc(ApplyFn(env_p0_2, st_p1_4, Text::lit("Fold"), t_p2_5, args_p3_1, span_p4_3)));
        });
    });
    })
        : prism_rtl::more(prism_rtl::rc(ApplyFn(env_p0, st_p1, Text::lit("Fold"), t_p2, args_p3, span_p4)));
}


/// `Start FoldApp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_fold_app(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::types::Ty t_p2, Array<crate::syntax::Arg> args_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<FoldApp>(env_p0, st_p1, t_p2, args_p3, span_p4);
}


/// ApplyFn: unbounded fn Env, St, Text, Ty, [Arg], Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> apply_fn(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Text& fname_p2, const crate::check::types::Ty& fty_p3, const Array<crate::syntax::Arg>& args_p4, const crate::syntax::Range& span_p5) {
    auto named_p6 = filter(args_p4, [&](const crate::syntax::Arg& a_p8) { return prism_rtl::deref(a_p8).name != std::optional<crate::syntax::Ident>{}; });
    auto st0_p7 = len(named_p6) > Nat(0u)
        ? crate::check::types::recording::err(st_p1, Text::lit("mismatch"), span_p5, prism_rtl::cat("`", fname_p2, "` takes its arguments by position; named arguments are a record\'s or a tag\'s"))
        : st_p1;
    auto&& _m = crate::check::types::recording::walk(st0_p7, fty_p3);
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
        auto&& col_p9 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0;
        auto&& params_pa = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
        auto&& res_pb = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
        return len(params_pa) != len(args_p4)
            ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st0_p7, Text::lit("mismatch"), span_p5, prism_rtl::cat("`", fname_p2, "` takes ", crate::check::errors::count_word(len(params_pa)), " argument", len(params_pa) == Nat(1u) ? Text::lit("") : Text::lit("s"), "; here it has ", crate::check::errors::count_word(len(args_p4))))}
            : apply_rule(env_p0, st0_p7, fname_p2, col_p9, params_pa, prism_rtl::deref(res_pb), args_p4, span_p5);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(_m)) {
        auto [params_ph, st1_pi] = fold(args_p4, std::tuple{Array<crate::check::types::Ty>{}, st0_p7}, [&](const std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>& _p0, const crate::syntax::Arg& _p1) {
            auto&& acc_pd = std::get<0>(_p0);
            auto&& s_pe = std::get<1>(_p0);
            return ({
                auto [v_pf, s2_pg] = crate::check::types::fresh_var(s_pe, false, Text::lit(""));
                std::tuple{crate::prelude::push(acc_pd, v_pf), s2_pg};
            });
        });
        auto [res_pj, st2_pk] = crate::check::types::fresh_var(st1_pi, false, Text::lit(""));
        auto [col_pl, st2b_pm] = crate::check::types::fresh_col(st2_pk);
        auto st3_pc = crate::check::types::unify::unify(st2b_pm, fty_p3, crate::check::types::Ty(crate::check::types::Ty::TyFn{col_pl, params_ph, prism_rtl::rc(res_pj)}), span_p5);
        return apply_rule(env_p0, st3_pc, fname_p2, col_pl, params_ph, res_pj, args_p4, span_p5);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyErr>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), st0_p7};
    }
    {
        auto&& other_pn = _m;
        return len(args_p4) == Nat(0u)
            ? std::tuple{other_pn, st0_p7}
            : std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st0_p7, Text::lit("mismatch"), span_p5, prism_rtl::cat("`", fname_p2, "` is a `", crate::check::types::show_ty(st0_p7, other_pn), "`, not a function"))};
    }
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> ApplyFn::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& fname_p2 = this->fname_p2;
    const auto& fty_p3 = this->fty_p3;
    const auto& args_p4 = this->args_p4;
    const auto& span_p5 = this->span_p5;
    auto named_p6 = filter(args_p4, [&](const crate::syntax::Arg& a_p8) { return prism_rtl::deref(a_p8).name != std::optional<crate::syntax::Ident>{}; });
    auto st0_p7 = len(named_p6) > Nat(0u)
        ? crate::check::types::recording::err(st_p1, Text::lit("mismatch"), span_p5, prism_rtl::cat("`", fname_p2, "` takes its arguments by position; named arguments are a record\'s or a tag\'s"))
        : st_p1;
    auto args_p4_1 = args_p4;
    auto env_p0_2 = env_p0;
    auto fname_p2_3 = fname_p2;
    auto fty_p3_4 = fty_p3;
    auto span_p5_5 = span_p5;
    return call_then(crate::check::types::recording::start_walk(st0_p7, fty_p3_4), [=](crate::check::types::Ty walk_10097) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyFn>(walk_10097) ? ({
            auto&& col_p9 = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_10097).a0;
            auto&& params_pa = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_10097).a1;
            auto&& res_pb = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_10097).a2;
            len(params_pa) != len(args_p4_1)
            ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st0_p7, Text::lit("mismatch"), span_p5_5, prism_rtl::cat("`", fname_p2_3, "` takes ", crate::check::errors::count_word(len(params_pa)), " argument", len(params_pa) == Nat(1u) ? Text::lit("") : Text::lit("s"), "; here it has ", crate::check::errors::count_word(len(args_p4_1))))})
            : prism_rtl::more(prism_rtl::rc(ApplyRule(env_p0_2, st0_p7, fname_p2_3, col_p9, params_pa, prism_rtl::deref(res_pb), args_p4_1, span_p5_5)));
        })
            : prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_10097) ? ({
            auto [params_ph, st1_pi] = fold(args_p4_1, std::tuple{Array<crate::check::types::Ty>{}, st0_p7}, [&](const std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>& _p0, const crate::syntax::Arg& _p1) {
                auto&& acc_pd = std::get<0>(_p0);
                auto&& s_pe = std::get<1>(_p0);
                return ({
                    auto [v_pf, s2_pg] = crate::check::types::fresh_var(s_pe, false, Text::lit(""));
                    std::tuple{crate::prelude::push(acc_pd, v_pf), s2_pg};
                });
            });
            auto [res_pj, st2_pk] = crate::check::types::fresh_var(st1_pi, false, Text::lit(""));
            auto [col_pl, st2b_pm] = crate::check::types::fresh_col(st2_pk);
            call_then(crate::check::types::unify::start_unify(st2b_pm, fty_p3_4, crate::check::types::Ty(crate::check::types::Ty::TyFn{col_pl, params_ph, prism_rtl::rc(res_pj)}), span_p5_5), [=](crate::check::types::St unify_10759) {
            return ({
                auto st3_pc = unify_10759;
                (prism_rtl::more(prism_rtl::rc(ApplyRule(env_p0_2, st3_pc, fname_p2_3, col_pl, params_ph, res_pj, args_p4_1, span_p5_5))));
            });
        });
        })
            : prism_rtl::is<crate::check::types::Ty::TyErr>(walk_10097) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), st0_p7})
            : ({
            auto&& other_pn = walk_10097;
            len(args_p4_1) == Nat(0u)
            ? prism_rtl::finished(std::tuple{other_pn, st0_p7})
            : call_then(crate::check::types::start_show_ty(st0_p7, other_pn), [=](Text show_ty_11039) { return prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st0_p7, Text::lit("mismatch"), span_p5_5, prism_rtl::cat("`", fname_p2_3, "` is a `", show_ty_11039, "`, not a function"))}); });
        });
        });
    });
}


/// `Start ApplyFn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_apply_fn(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text fname_p2, crate::check::types::Ty fty_p3, Array<crate::syntax::Arg> args_p4, crate::syntax::Range span_p5) {
    return prism_rtl::make_rc<ApplyFn>(env_p0, st_p1, fname_p2, fty_p3, args_p4, span_p5);
}


/// Broken: fn Peeled, Bool -> Peeled
Peeled broken(const Peeled& p_p0, const bool& b_p1) {
    return !b_p1
        ? p_p0
        : ({
        Peeled this_ = p_p0;
        this_.broken = true;
        (std::move(this_));
    });
}


/// ApplyRule: unbounded fn Env, St, Text, Col, [Ty], Ty, [Arg], Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> apply_rule(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Text& fname_p2, const crate::check::types::Col& col_p3, const Array<crate::check::types::Ty>& params_p4, const crate::check::types::Ty& res_p5, const Array<crate::syntax::Arg>& args_p6, const crate::syntax::Range& span_p7) {
    auto n_p8 = len(args_p6);
    auto cmp_p9 = crate::check::expr::is_comparison(fname_p2);
    auto [arg_tys_p12, st1_p13] = run_to_end(fold_job(crate::check::errors::range0(n_p8), std::tuple{Array<crate::check::types::Ty>{}, st_p1}, ({
        auto args_p6_1 = args_p6;
        auto span_p7_2 = span_p7;
        auto env_p0_3 = env_p0;
        auto params_p4_4 = params_p4;
        auto fname_p2_5 = fname_p2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, args_p6_1 = std::move(args_p6_1), span_p7_2 = std::move(span_p7_2), env_p0_3 = std::move(env_p0_3), params_p4_4 = std::move(params_p4_4), fname_p2_5 = std::move(fname_p2_5)](std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto args_p6_1_6 = args_p6_1;
            auto span_p7_2_6 = span_p7_2;
            auto env_p0_3_6 = env_p0_3;
            auto params_p4_4_6 = params_p4_4;
            auto fname_p2_5_6 = fname_p2_5;
            entered(once_job([=, args_p6_1_6 = std::move(args_p6_1_6), span_p7_2_6 = std::move(span_p7_2_6), env_p0_3_6 = std::move(env_p0_3_6), params_p4_4_6 = std::move(params_p4_4_6), fname_p2_5_6 = std::move(fname_p2_5_6)]() {
            return ({
                auto [acc_po, s_pp] = p0;
                auto i_pq = p1;
                ({
                auto a_pr = or_(index(args_p6_1_6, i_pq), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span_p7_2_6}, .span = span_p7_2_6});
                (crate::check::expr::is_lambda(a_pr->value)
                ? prism_rtl::finished(std::tuple{crate::prelude::push(acc_po, crate::check::types::Ty(crate::check::types::Ty::TyErr{})), s_pp})
                : call_then(crate::check::expr::start_infer(env_p0_3_6, s_pp, a_pr->value), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_12500) {
                return ({
                    auto [t_ps, s2_pt] = infer_12500;
                    call_then(crate::check::types::recording::start_walk(s2_pt, or_(index(params_p4_4_6, i_pq), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::check::types::Ty walk_12543) {
                    return call_then(crate::check::types::recording::start_walk(s2_pt, t_ps), [=](crate::check::types::Ty walk_12577) {
                        return ({
                            auto&& _m = std::tuple{walk_12543, walk_12577};
                            prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<1>(_m)) ? ({
                            auto&& pc_pu = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<0>(_m)).a0;
                            auto&& ac_pv = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a0;
                            auto&& aps_p10 = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a1;
                            auto&& ar_p11 = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a2;
                            call_then(crate::check::types::colors::start_add_leq(s2_pt, ac_pv, pc_pu, prism_rtl::deref(a_pr->value).span, Text::lit("arg"), fname_p2_5_6, Text::lit("")), [=](crate::check::types::St add_leq_12694) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc_po, crate::check::types::Ty(crate::check::types::Ty::TyFn{pc_pu, aps_p10, prism_rtl::rc(prism_rtl::deref(ar_p11))})), add_leq_12694}); });
                        })
                            : prism_rtl::finished(std::tuple{crate::prelude::push(acc_po, t_ps), s2_pt});
                        });
                    });
                });
                });
            }));
            });
            });
        }));
        });
    }));
    })));
    auto [st2_p1b, whole_p1c] = run_to_end(fold_job(crate::check::errors::range0(n_p8), std::tuple{st1_p13, Array<Nat>{}}, ({
        auto args_p6_1 = args_p6;
        auto span_p7_2 = span_p7;
        auto arg_tys_p12_3 = arg_tys_p12;
        auto params_p4_4 = params_p4;
        auto env_p0_5 = env_p0;
        auto fname_p2_6 = fname_p2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::types::St, Array<Nat>>>(std::tuple<std::tuple<crate::check::types::St, Array<Nat>>, Nat>)>>(prism_rtl::rc([=, args_p6_1 = std::move(args_p6_1), span_p7_2 = std::move(span_p7_2), arg_tys_p12_3 = std::move(arg_tys_p12_3), params_p4_4 = std::move(params_p4_4), env_p0_5 = std::move(env_p0_5), fname_p2_6 = std::move(fname_p2_6)](std::tuple<std::tuple<crate::check::types::St, Array<Nat>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto args_p6_1_7 = args_p6_1;
            auto span_p7_2_7 = span_p7_2;
            auto arg_tys_p12_3_7 = arg_tys_p12_3;
            auto params_p4_4_7 = params_p4_4;
            auto env_p0_5_7 = env_p0_5;
            auto fname_p2_6_7 = fname_p2_6;
            entered(once_job([=, args_p6_1_7 = std::move(args_p6_1_7), span_p7_2_7 = std::move(span_p7_2_7), arg_tys_p12_3_7 = std::move(arg_tys_p12_3_7), params_p4_4_7 = std::move(params_p4_4_7), env_p0_5_7 = std::move(env_p0_5_7), fname_p2_6_7 = std::move(fname_p2_6_7)]() {
            return ({
                auto [s_p14, done_p15] = p0;
                auto i_p16 = p1;
                ({
                auto a_p17 = or_(index(args_p6_1_7, i_p16), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span_p7_2_7}, .span = span_p7_2_7});
                auto at_p18 = or_(index(arg_tys_p12_3_7, i_p16), crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
                call_then(crate::check::types::recording::start_walk(s_p14, or_(index(params_p4_4_7, i_p16), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=, a_p17 = std::move(a_p17), at_p18 = std::move(at_p18)](crate::check::types::Ty walk_13016) {
                return ({
                    auto pnow_p19 = walk_13016;
                    call_then(crate::check::types::start_head_sigil(s_p14, pnow_p19), [=](Text head_sigil_13083) {
                    return ({
                        auto whole_now_p1a = crate::check::expr::is_time_sigil(head_sigil_13083) || (crate::check::types::head_sigil(s_p14, pnow_p19) == Text::lit("@"));
                        (crate::check::expr::is_lambda(a_p17->value)
                        ? prism_rtl::finished(std::tuple{s_p14, done_p15})
                        : std::move(whole_now_p1a) && (crate::check::types::stack_of(s_p14, at_p18) != Text::lit(""))
                        ? call_then(crate::check::types::unify::start_unify(s_p14, pnow_p19, at_p18, prism_rtl::deref(a_p17->value).span), [=](crate::check::types::St unify_13230) { return prism_rtl::finished(std::tuple{unify_13230, crate::prelude::push(done_p15, i_p16)}); })
                        : call_then(crate::check::types::start_stack_of(s_p14, at_p18), [=](Text stack_of_13299) {
                        return (stack_of_13299 != Text::lit("")) || crate::check::types::is_free_headed(s_p14, at_p18)
                            ? prism_rtl::finished(std::tuple{s_p14, done_p15})
                            : call_then(start_plain_arg(env_p0_5_7, s_p14, fname_p2_6_7, or_(index(params_p4_4_7, i_p16), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), at_p18, a_p17), [=](crate::check::types::St plain_arg_13374) { return prism_rtl::finished(std::tuple{plain_arg_13374, done_p15}); });
                    }));
                    });
                });
                });
            });
            });
            });
        }));
        });
    }));
    })));
    auto&& _st3_p1p = run_to_end(fold_job(crate::check::errors::range0(n_p8), std::tuple{Map<Unit, Unit>{}, st2_p1b}, ({
        auto args_p6_1 = args_p6;
        auto span_p7_2 = span_p7;
        auto params_p4_3 = params_p4;
        auto env_p0_4 = env_p0;
        auto fname_p2_5 = fname_p2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Unit, Unit>, crate::check::types::St>>(std::tuple<std::tuple<Map<Unit, Unit>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, args_p6_1 = std::move(args_p6_1), span_p7_2 = std::move(span_p7_2), params_p4_3 = std::move(params_p4_3), env_p0_4 = std::move(env_p0_4), fname_p2_5 = std::move(fname_p2_5)](std::tuple<std::tuple<Map<Unit, Unit>, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto args_p6_1_6 = args_p6_1;
            auto span_p7_2_6 = span_p7_2;
            auto params_p4_3_6 = params_p4_3;
            auto env_p0_4_6 = env_p0_4;
            auto fname_p2_5_6 = fname_p2_5;
            entered(once_job([=, args_p6_1_6 = std::move(args_p6_1_6), span_p7_2_6 = std::move(span_p7_2_6), params_p4_3_6 = std::move(params_p4_3_6), env_p0_4_6 = std::move(env_p0_4_6), fname_p2_5_6 = std::move(fname_p2_5_6)]() {
            return ({
                auto [m_p1d, s_p1e] = p0;
                auto i_p1f = p1;
                ({
                auto a_p1g = or_(index(args_p6_1_6, i_p1f), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span_p7_2_6}, .span = span_p7_2_6});
                (crate::check::expr::is_lambda(a_p1g->value)
                ? call_then(crate::check::types::recording::start_walk(s_p1e, or_(index(params_p4_3_6, i_p1f), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::check::types::Ty walk_13645) {
                return ({
                    auto p_p1h = walk_13645;
                    call_then(start_infer_lambda(env_p0_4_6, s_p1e, a_p1g->value, std::optional(p_p1h)), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_lambda_13704) {
                    return ({
                        auto [lt_p1j, s2_p1k] = infer_lambda_13704;
                        auto s3_p1i = ({
                            __label__ _done;
                            prism_rtl::Slot<crate::check::types::St> _v;
                            auto&& _m = std::tuple{p_p1h, lt_p1j};
                            if (prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<1>(_m))) {
                                auto&& pc_p1l = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<0>(_m)).a0;
                                auto&& lc_p1m = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a0;
                                auto&& lps_p1n = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a1;
                                auto&& lr_p1o = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a2;
                                _v.set(crate::check::types::colors::add_leq(crate::check::types::unify::unify(crate::check::types::recording::note_ty(s2_p1k, prism_rtl::deref(a_p1g->value).span, lt_p1j), p_p1h, crate::check::types::Ty(crate::check::types::Ty::TyFn{pc_p1l, lps_p1n, prism_rtl::rc(prism_rtl::deref(lr_p1o))}), prism_rtl::deref(a_p1g->value).span), lc_p1m, pc_p1l, prism_rtl::deref(a_p1g->value).span, Text::lit("arg"), fname_p2_5_6, Text::lit("")));
                                goto _done;
                            }
                            {
                                _v.set(crate::check::types::unify::unify(crate::check::types::recording::note_ty(s2_p1k, prism_rtl::deref(a_p1g->value).span, lt_p1j), p_p1h, lt_p1j, prism_rtl::deref(a_p1g->value).span));
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                        (prism_rtl::finished(std::tuple{m_p1d, s3_p1i}));
                    });
                });
                });
            })
                : prism_rtl::finished(std::tuple{m_p1d, s_p1e}));
            });
            });
        }));
        });
    }));
    })));
    auto&& st3_p1p = std::get<1>(_st3_p1p);
    auto [pl_p25, st4_p26] = run_to_end(fold_job(crate::check::errors::range0(n_p8), std::tuple{Peeled{.events = Array<crate::syntax::Range>{}, .dyns = Array<crate::syntax::Range>{}, .opts = Array<Text>{}, .opt_args = Array<crate::syntax::Range>{}, .lifted = Text::lit(""), .broken = false}, st3_p1p}, ({
        auto args_p6_1 = args_p6;
        auto span_p7_2 = span_p7;
        auto arg_tys_p12_3 = arg_tys_p12;
        auto whole_p1c_4 = whole_p1c;
        auto env_p0_5 = env_p0;
        auto fname_p2_6 = fname_p2;
        auto cmp_p9_7 = std::move(cmp_p9);
        auto params_p4_8 = params_p4;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Peeled, crate::check::types::St>>(std::tuple<std::tuple<Peeled, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, args_p6_1 = std::move(args_p6_1), span_p7_2 = std::move(span_p7_2), arg_tys_p12_3 = std::move(arg_tys_p12_3), whole_p1c_4 = std::move(whole_p1c_4), env_p0_5 = std::move(env_p0_5), fname_p2_6 = std::move(fname_p2_6), cmp_p9_7 = std::move(cmp_p9_7), params_p4_8 = std::move(params_p4_8)](std::tuple<std::tuple<Peeled, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto args_p6_1_9 = args_p6_1;
            auto span_p7_2_9 = span_p7_2;
            auto arg_tys_p12_3_9 = arg_tys_p12_3;
            auto whole_p1c_4_9 = whole_p1c_4;
            auto env_p0_5_9 = env_p0_5;
            auto fname_p2_6_9 = fname_p2_6;
            auto cmp_p9_7_9 = cmp_p9_7;
            auto params_p4_8_9 = params_p4_8;
            entered(once_job([=, args_p6_1_9 = std::move(args_p6_1_9), span_p7_2_9 = std::move(span_p7_2_9), arg_tys_p12_3_9 = std::move(arg_tys_p12_3_9), whole_p1c_4_9 = std::move(whole_p1c_4_9), env_p0_5_9 = std::move(env_p0_5_9), fname_p2_6_9 = std::move(fname_p2_6_9), cmp_p9_7_9 = std::move(cmp_p9_7_9), params_p4_8_9 = std::move(params_p4_8_9)]() {
            return ({
                auto [acc_p1q, s_p1r] = p0;
                auto i_p1s = p1;
                ({
                auto a_p1t = or_(index(args_p6_1_9, i_p1s), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span_p7_2_9}, .span = span_p7_2_9});
                auto at_p1u = or_(index(arg_tys_p12_3_9, i_p1s), crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
                (crate::check::expr::is_lambda(a_p1t->value) || crate::check::types::has_nat(whole_p1c_4_9, i_p1s)) || ((crate::check::types::stack_of(s_p1r, at_p1u) == Text::lit("")) && (!crate::check::types::is_free_headed(s_p1r, at_p1u)))
                ? prism_rtl::finished(std::tuple{acc_p1q, s_p1r})
                : ({
                auto before_p1v = len(prism_rtl::deref(s_p1r).diags);
                call_then(start_layered_arg(env_p0_5_9, s_p1r, acc_p1q, fname_p2_6_9, cmp_p9_7_9, or_(index(params_p4_8_9, i_p1s), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), at_p1u, a_p1t), [=, before_p1v = std::move(before_p1v)](std::tuple<Peeled, crate::check::types::St> layered_arg_14569) {
                return ({
                    auto [acc2_p21, s2_p22] = layered_arg_14569;
                    auto broke_p20 = (len(prism_rtl::deref(s2_p22).diags) > before_p1v) && fold(drop(prism_rtl::deref(s2_p22).diags, before_p1v), false, [&](const bool& seen_p23, const crate::check::errors::CDiag& d_p24) { return prism_rtl::deref(seen_p23) || crate::check::types::has_text(Array(std::vector{Text::lit("two-layers"), Text::lit("layer-under-optional"), Text::lit("blueprint-operand")}), prism_rtl::deref(d_p24).code); });
                    (prism_rtl::finished(std::tuple{broken(acc2_p21, broke_p20), s2_p22}));
                });
            });
            });
            });
            });
        }));
        });
    }));
    })));
    auto st5_pa = len(prism_rtl::deref(pl_p25).events) > Nat(1u)
        ? crate::check::types::recording::err_fix(st4_p26, Text::lit("two-events"), or_(index(prism_rtl::deref(pl_p25).events, Nat(1u)), span_p7), Text::lit("two events in one operation"), Text::lit("merge them with `<|`, or hold one first, `$last <- 0 then !b`"))
        : st4_p26;
    auto st6_pb = len(pl_p25->opts) > Nat(1u)
        ? crate::check::types::recording::err(st5_pa, Text::lit("optional-and-fault"), span_p7, Text::lit("`?` and `~` in one operation"))
        : st5_pa;
    auto layer_pc = len(prism_rtl::deref(pl_p25).events) > Nat(0u)
        ? Text::lit("!")
        : len(prism_rtl::deref(pl_p25).dyns) > Nat(0u)
        ? Text::lit("$")
        : Text::lit("");
    auto with_opt_pd = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::Ty> _v;
        auto&& _m = index(pl_p25->opts, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& o_p27 = prism_rtl::some_of(_m);
            _v.set(crate::check::types::Ty(crate::check::types::Ty::TySig{o_p27, prism_rtl::rc(res_p5)}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(res_p5);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto result_pe = prism_rtl::deref(pl_p25).broken
        ? crate::check::types::Ty(crate::check::types::Ty::TyErr{})
        : layer_pc == Text::lit("")
        ? with_opt_pd
        : crate::check::types::Ty(crate::check::types::Ty::TySig{layer_pc, prism_rtl::rc(with_opt_pd)});
    auto call_col_pf = crate::check::types::colors::walk_col(st6_pb, col_p3);
    auto st7_pg = (layer_pc != Text::lit("")) && crate::check::types::colors::is_flex_col(call_col_pf)
        ? crate::check::types::colors::add_leq(st6_pb, call_col_pf, crate::check::types::Col(crate::check::types::Col::CBound{}), span_p7, Text::lit("lifted"), fname_p2, prism_rtl::deref(pl_p25).lifted)
        : st6_pb;
    auto lifted_bad_ph = ((layer_pc != Text::lit("")) && (call_col_pf != crate::check::types::Col(crate::check::types::Col::CBound{}))) && (!crate::check::types::colors::is_flex_col(call_col_pf));
    auto st8_pi = std::move(lifted_bad_ph)
        ? crate::check::types::recording::err_fix(st7_pg, Text::lit("lifted-unbounded"), span_p7, prism_rtl::cat(crate::check::types::colors::col_word(call_col_pf), " `", fname_p2, "` lifted over `", prism_rtl::deref(pl_p25).lifted, "`; use `@Run`"), prism_rtl::cat("run it through `!done <- @Run ", fname_p2, ", ...`"))
        : st7_pg;
    auto st9_pj = crate::check::types::colors::use_color(st8_pi, call_col_pf, fname_p2, span_p7);
    auto kind_pk = (layer_pc == Text::lit("!")) && (len(prism_rtl::deref(pl_p25).dyns) > Nat(0u))
        ? Text::lit("sample")
        : layer_pc != Text::lit("")
        ? Text::lit("map")
        : fname_p2 == Text::lit("$") ? Text::lit("const") : Text::lit("plain");
    auto peeled_pl = append(prism_rtl::deref(pl_p25).events, prism_rtl::deref(pl_p25).dyns);
    auto lifted_pm = filter(crate::check::errors::range0(n_p8), [&](const Nat& i_p28) { return has_range(peeled_pl, prism_rtl::deref(or_(index(args_p6, i_p28), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span_p7}, .span = span_p7})->value).span); });
    auto st10_pn = prism_rtl::deref(pl_p25).broken || (len(pl_p25->opts) != Nat(1u))
        ? st9_pj
        : crate::check::types::recording::note_lift(st9_pj, span_p7, or_(index(pl_p25->opts, Nat(0u)), Text::lit("")), prism_rtl::deref(pl_p25).opt_args);
    return std::tuple{result_pe, crate::check::types::recording::note_app(st10_pn, span_p7, fname_p2, kind_pk, layer_pc, lifted_pm, or_(index(pl_p25->opts, Nat(0u)), Text::lit("")), call_col_pf)};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> ApplyRule::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& fname_p2 = this->fname_p2;
    const auto& col_p3 = this->col_p3;
    const auto& params_p4 = this->params_p4;
    const auto& res_p5 = this->res_p5;
    const auto& args_p6 = this->args_p6;
    const auto& span_p7 = this->span_p7;
    auto n_p8 = len(args_p6);
    auto cmp_p9 = crate::check::expr::is_comparison(fname_p2);
    auto args_p6_1 = args_p6;
    auto col_p3_2 = col_p3;
    auto env_p0_3 = env_p0;
    auto fname_p2_4 = fname_p2;
    auto params_p4_5 = params_p4;
    auto res_p5_6 = res_p5;
    auto span_p7_7 = span_p7;
    auto st_p1_8 = st_p1;
    return call_value(fold_job(crate::check::errors::range0(n_p8), std::tuple{Array<crate::check::types::Ty>{}, st_p1_8}, ({
        auto args_p6_1_9 = args_p6_1;
        auto span_p7_7_9 = span_p7_7;
        auto env_p0_3_9 = env_p0_3;
        auto params_p4_5_9 = params_p4_5;
        auto fname_p2_4_9 = fname_p2_4;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, args_p6_1_9 = std::move(args_p6_1_9), span_p7_7_9 = std::move(span_p7_7_9), env_p0_3_9 = std::move(env_p0_3_9), params_p4_5_9 = std::move(params_p4_5_9), fname_p2_4_9 = std::move(fname_p2_4_9)](std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto args_p6_1_9_9 = args_p6_1_9;
            auto span_p7_7_9_9 = span_p7_7_9;
            auto env_p0_3_9_9 = env_p0_3_9;
            auto params_p4_5_9_9 = params_p4_5_9;
            auto fname_p2_4_9_9 = fname_p2_4_9;
            entered(once_job([=, args_p6_1_9_9 = std::move(args_p6_1_9_9), span_p7_7_9_9 = std::move(span_p7_7_9_9), env_p0_3_9_9 = std::move(env_p0_3_9_9), params_p4_5_9_9 = std::move(params_p4_5_9_9), fname_p2_4_9_9 = std::move(fname_p2_4_9_9)]() {
            return ({
                auto [acc_po, s_pp] = p0;
                auto i_pq = p1;
                ({
                auto a_pr = or_(index(args_p6_1_9_9, i_pq), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span_p7_7_9_9}, .span = span_p7_7_9_9});
                (crate::check::expr::is_lambda(a_pr->value)
                ? prism_rtl::finished(std::tuple{crate::prelude::push(acc_po, crate::check::types::Ty(crate::check::types::Ty::TyErr{})), s_pp})
                : call_then(crate::check::expr::start_infer(env_p0_3_9_9, s_pp, a_pr->value), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_12500) {
                return ({
                    auto [t_ps, s2_pt] = infer_12500;
                    call_then(crate::check::types::recording::start_walk(s2_pt, or_(index(params_p4_5_9_9, i_pq), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::check::types::Ty walk_12543) {
                    return call_then(crate::check::types::recording::start_walk(s2_pt, t_ps), [=](crate::check::types::Ty walk_12577) {
                        return ({
                            auto&& _m = std::tuple{walk_12543, walk_12577};
                            prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<1>(_m)) ? ({
                            auto&& pc_pu = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<0>(_m)).a0;
                            auto&& ac_pv = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a0;
                            auto&& aps_p10 = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a1;
                            auto&& ar_p11 = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a2;
                            call_then(crate::check::types::colors::start_add_leq(s2_pt, ac_pv, pc_pu, prism_rtl::deref(a_pr->value).span, Text::lit("arg"), fname_p2_4_9_9, Text::lit("")), [=](crate::check::types::St add_leq_12694) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc_po, crate::check::types::Ty(crate::check::types::Ty::TyFn{pc_pu, aps_p10, prism_rtl::rc(prism_rtl::deref(ar_p11))})), add_leq_12694}); });
                        })
                            : prism_rtl::finished(std::tuple{crate::prelude::push(acc_po, t_ps), s2_pt});
                        });
                    });
                });
                });
            }));
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> fold_12267) {
        return ({
            auto [arg_tys_p12, st1_p13] = fold_12267;
            call_value(fold_job(crate::check::errors::range0(n_p8), std::tuple{st1_p13, Array<Nat>{}}, ({
            auto args_p6_1_9 = args_p6_1;
            auto span_p7_7_9 = span_p7_7;
            auto arg_tys_p12_9 = arg_tys_p12;
            auto params_p4_5_10 = params_p4_5;
            auto env_p0_3_10 = env_p0_3;
            auto fname_p2_4_10 = fname_p2_4;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::types::St, Array<Nat>>>(std::tuple<std::tuple<crate::check::types::St, Array<Nat>>, Nat>)>>(prism_rtl::rc([=, args_p6_1_9 = std::move(args_p6_1_9), span_p7_7_9 = std::move(span_p7_7_9), arg_tys_p12_9 = std::move(arg_tys_p12_9), params_p4_5_10 = std::move(params_p4_5_10), env_p0_3_10 = std::move(env_p0_3_10), fname_p2_4_10 = std::move(fname_p2_4_10)](std::tuple<std::tuple<crate::check::types::St, Array<Nat>>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto args_p6_1_9_10 = args_p6_1_9;
                auto span_p7_7_9_10 = span_p7_7_9;
                auto arg_tys_p12_9_10 = arg_tys_p12_9;
                auto params_p4_5_10_10 = params_p4_5_10;
                auto env_p0_3_10_10 = env_p0_3_10;
                auto fname_p2_4_10_10 = fname_p2_4_10;
                entered(once_job([=, args_p6_1_9_10 = std::move(args_p6_1_9_10), span_p7_7_9_10 = std::move(span_p7_7_9_10), arg_tys_p12_9_10 = std::move(arg_tys_p12_9_10), params_p4_5_10_10 = std::move(params_p4_5_10_10), env_p0_3_10_10 = std::move(env_p0_3_10_10), fname_p2_4_10_10 = std::move(fname_p2_4_10_10)]() {
                return ({
                    auto [s_p14, done_p15] = p0;
                    auto i_p16 = p1;
                    ({
                    auto a_p17 = or_(index(args_p6_1_9_10, i_p16), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span_p7_7_9_10}, .span = span_p7_7_9_10});
                    auto at_p18 = or_(index(arg_tys_p12_9_10, i_p16), crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
                    call_then(crate::check::types::recording::start_walk(s_p14, or_(index(params_p4_5_10_10, i_p16), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=, a_p17 = std::move(a_p17), at_p18 = std::move(at_p18)](crate::check::types::Ty walk_13016) {
                    return ({
                        auto pnow_p19 = walk_13016;
                        call_then(crate::check::types::start_head_sigil(s_p14, pnow_p19), [=](Text head_sigil_13083) {
                        return ({
                            auto whole_now_p1a = crate::check::expr::is_time_sigil(head_sigil_13083) || (crate::check::types::head_sigil(s_p14, pnow_p19) == Text::lit("@"));
                            (crate::check::expr::is_lambda(a_p17->value)
                            ? prism_rtl::finished(std::tuple{s_p14, done_p15})
                            : std::move(whole_now_p1a) && (crate::check::types::stack_of(s_p14, at_p18) != Text::lit(""))
                            ? call_then(crate::check::types::unify::start_unify(s_p14, pnow_p19, at_p18, prism_rtl::deref(a_p17->value).span), [=](crate::check::types::St unify_13230) { return prism_rtl::finished(std::tuple{unify_13230, crate::prelude::push(done_p15, i_p16)}); })
                            : call_then(crate::check::types::start_stack_of(s_p14, at_p18), [=](Text stack_of_13299) {
                            return (stack_of_13299 != Text::lit("")) || crate::check::types::is_free_headed(s_p14, at_p18)
                                ? prism_rtl::finished(std::tuple{s_p14, done_p15})
                                : call_then(start_plain_arg(env_p0_3_10_10, s_p14, fname_p2_4_10_10, or_(index(params_p4_5_10_10, i_p16), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), at_p18, a_p17), [=](crate::check::types::St plain_arg_13374) { return prism_rtl::finished(std::tuple{plain_arg_13374, done_p15}); });
                        }));
                        });
                    });
                    });
                });
                });
                });
            }));
            });
        }));
        })), [=](std::tuple<crate::check::types::St, Array<Nat>> fold_12821) {
            return ({
                auto [st2_p1b, whole_p1c] = fold_12821;
                call_value(fold_job(crate::check::errors::range0(n_p8), std::tuple{Map<Unit, Unit>{}, st2_p1b}, ({
                auto args_p6_1_9 = args_p6_1;
                auto span_p7_7_9 = span_p7_7;
                auto params_p4_5_9 = params_p4_5;
                auto env_p0_3_9 = env_p0_3;
                auto fname_p2_4_9 = fname_p2_4;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Unit, Unit>, crate::check::types::St>>(std::tuple<std::tuple<Map<Unit, Unit>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, args_p6_1_9 = std::move(args_p6_1_9), span_p7_7_9 = std::move(span_p7_7_9), params_p4_5_9 = std::move(params_p4_5_9), env_p0_3_9 = std::move(env_p0_3_9), fname_p2_4_9 = std::move(fname_p2_4_9)](std::tuple<std::tuple<Map<Unit, Unit>, crate::check::types::St>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto args_p6_1_9_9 = args_p6_1_9;
                    auto span_p7_7_9_9 = span_p7_7_9;
                    auto params_p4_5_9_9 = params_p4_5_9;
                    auto env_p0_3_9_9 = env_p0_3_9;
                    auto fname_p2_4_9_9 = fname_p2_4_9;
                    entered(once_job([=, args_p6_1_9_9 = std::move(args_p6_1_9_9), span_p7_7_9_9 = std::move(span_p7_7_9_9), params_p4_5_9_9 = std::move(params_p4_5_9_9), env_p0_3_9_9 = std::move(env_p0_3_9_9), fname_p2_4_9_9 = std::move(fname_p2_4_9_9)]() {
                    return ({
                        auto [m_p1d, s_p1e] = p0;
                        auto i_p1f = p1;
                        ({
                        auto a_p1g = or_(index(args_p6_1_9_9, i_p1f), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span_p7_7_9_9}, .span = span_p7_7_9_9});
                        (crate::check::expr::is_lambda(a_p1g->value)
                        ? call_then(crate::check::types::recording::start_walk(s_p1e, or_(index(params_p4_5_9_9, i_p1f), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::check::types::Ty walk_13645) {
                        return ({
                            auto p_p1h = walk_13645;
                            call_then(start_infer_lambda(env_p0_3_9_9, s_p1e, a_p1g->value, std::optional(p_p1h)), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_lambda_13704) {
                            return ({
                                auto [lt_p1j, s2_p1k] = infer_lambda_13704;
                                auto s3_p1i = ({
                                    __label__ _done;
                                    prism_rtl::Slot<crate::check::types::St> _v;
                                    auto&& _m = std::tuple{p_p1h, lt_p1j};
                                    if (prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<1>(_m))) {
                                        auto&& pc_p1l = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<0>(_m)).a0;
                                        auto&& lc_p1m = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a0;
                                        auto&& lps_p1n = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a1;
                                        auto&& lr_p1o = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a2;
                                        _v.set(crate::check::types::colors::add_leq(crate::check::types::unify::unify(crate::check::types::recording::note_ty(s2_p1k, prism_rtl::deref(a_p1g->value).span, lt_p1j), p_p1h, crate::check::types::Ty(crate::check::types::Ty::TyFn{pc_p1l, lps_p1n, prism_rtl::rc(prism_rtl::deref(lr_p1o))}), prism_rtl::deref(a_p1g->value).span), lc_p1m, pc_p1l, prism_rtl::deref(a_p1g->value).span, Text::lit("arg"), fname_p2_4_9_9, Text::lit("")));
                                        goto _done;
                                    }
                                    {
                                        _v.set(crate::check::types::unify::unify(crate::check::types::recording::note_ty(s2_p1k, prism_rtl::deref(a_p1g->value).span, lt_p1j), p_p1h, lt_p1j, prism_rtl::deref(a_p1g->value).span));
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                });
                                (prism_rtl::finished(std::tuple{m_p1d, s3_p1i}));
                            });
                        });
                        });
                    })
                        : prism_rtl::finished(std::tuple{m_p1d, s_p1e}));
                    });
                    });
                }));
                });
            }));
            })), [=](std::tuple<Map<Unit, Unit>, crate::check::types::St> fold_13462) {
                return ({
                    auto&& _st3_p1p = fold_13462;
                    auto&& st3_p1p = std::get<1>(_st3_p1p);
                    call_value(fold_job(crate::check::errors::range0(n_p8), std::tuple{Peeled{.events = Array<crate::syntax::Range>{}, .dyns = Array<crate::syntax::Range>{}, .opts = Array<Text>{}, .opt_args = Array<crate::syntax::Range>{}, .lifted = Text::lit(""), .broken = false}, st3_p1p}, ({
                    auto args_p6_1_9 = args_p6_1;
                    auto span_p7_7_9 = span_p7_7;
                    auto arg_tys_p12_9 = arg_tys_p12;
                    auto whole_p1c_10 = whole_p1c;
                    auto env_p0_3_11 = env_p0_3;
                    auto fname_p2_4_11 = fname_p2_4;
                    auto cmp_p9_11 = cmp_p9;
                    auto params_p4_5_12 = params_p4_5;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Peeled, crate::check::types::St>>(std::tuple<std::tuple<Peeled, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, args_p6_1_9 = std::move(args_p6_1_9), span_p7_7_9 = std::move(span_p7_7_9), arg_tys_p12_9 = std::move(arg_tys_p12_9), whole_p1c_10 = std::move(whole_p1c_10), env_p0_3_11 = std::move(env_p0_3_11), fname_p2_4_11 = std::move(fname_p2_4_11), cmp_p9_11 = std::move(cmp_p9_11), params_p4_5_12 = std::move(params_p4_5_12)](std::tuple<std::tuple<Peeled, crate::check::types::St>, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto args_p6_1_9_12 = args_p6_1_9;
                        auto span_p7_7_9_12 = span_p7_7_9;
                        auto arg_tys_p12_9_12 = arg_tys_p12_9;
                        auto whole_p1c_10_12 = whole_p1c_10;
                        auto env_p0_3_11_12 = env_p0_3_11;
                        auto fname_p2_4_11_12 = fname_p2_4_11;
                        auto cmp_p9_11_12 = cmp_p9_11;
                        auto params_p4_5_12_12 = params_p4_5_12;
                        entered(once_job([=, args_p6_1_9_12 = std::move(args_p6_1_9_12), span_p7_7_9_12 = std::move(span_p7_7_9_12), arg_tys_p12_9_12 = std::move(arg_tys_p12_9_12), whole_p1c_10_12 = std::move(whole_p1c_10_12), env_p0_3_11_12 = std::move(env_p0_3_11_12), fname_p2_4_11_12 = std::move(fname_p2_4_11_12), cmp_p9_11_12 = std::move(cmp_p9_11_12), params_p4_5_12_12 = std::move(params_p4_5_12_12)]() {
                        return ({
                            auto [acc_p1q, s_p1r] = p0;
                            auto i_p1s = p1;
                            ({
                            auto a_p1t = or_(index(args_p6_1_9_12, i_p1s), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span_p7_7_9_12}, .span = span_p7_7_9_12});
                            auto at_p1u = or_(index(arg_tys_p12_9_12, i_p1s), crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
                            (crate::check::expr::is_lambda(a_p1t->value) || crate::check::types::has_nat(whole_p1c_10_12, i_p1s)) || ((crate::check::types::stack_of(s_p1r, at_p1u) == Text::lit("")) && (!crate::check::types::is_free_headed(s_p1r, at_p1u)))
                            ? prism_rtl::finished(std::tuple{acc_p1q, s_p1r})
                            : ({
                            auto before_p1v = len(prism_rtl::deref(s_p1r).diags);
                            call_then(start_layered_arg(env_p0_3_11_12, s_p1r, acc_p1q, fname_p2_4_11_12, cmp_p9_11_12, or_(index(params_p4_5_12_12, i_p1s), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), at_p1u, a_p1t), [=, before_p1v = std::move(before_p1v)](std::tuple<Peeled, crate::check::types::St> layered_arg_14569) {
                            return ({
                                auto [acc2_p21, s2_p22] = layered_arg_14569;
                                auto broke_p20 = (len(prism_rtl::deref(s2_p22).diags) > before_p1v) && fold(drop(prism_rtl::deref(s2_p22).diags, before_p1v), false, [&](const bool& seen_p23, const crate::check::errors::CDiag& d_p24) { return prism_rtl::deref(seen_p23) || crate::check::types::has_text(Array(std::vector{Text::lit("two-layers"), Text::lit("layer-under-optional"), Text::lit("blueprint-operand")}), prism_rtl::deref(d_p24).code); });
                                (prism_rtl::finished(std::tuple{broken(acc2_p21, broke_p20), s2_p22}));
                            });
                        });
                        });
                        });
                        });
                    }));
                    });
                }));
                })), [=](std::tuple<Peeled, crate::check::types::St> fold_14117) {
                    return ({
                        auto [pl_p25, st4_p26] = fold_14117;
                        auto st5_pa = len(prism_rtl::deref(pl_p25).events) > Nat(1u)
                            ? crate::check::types::recording::err_fix(st4_p26, Text::lit("two-events"), or_(index(prism_rtl::deref(pl_p25).events, Nat(1u)), span_p7_7), Text::lit("two events in one operation"), Text::lit("merge them with `<|`, or hold one first, `$last <- 0 then !b`"))
                            : st4_p26;
                        auto st6_pb = len(pl_p25->opts) > Nat(1u)
                            ? crate::check::types::recording::err(st5_pa, Text::lit("optional-and-fault"), span_p7_7, Text::lit("`?` and `~` in one operation"))
                            : st5_pa;
                        auto layer_pc = len(prism_rtl::deref(pl_p25).events) > Nat(0u)
                            ? Text::lit("!")
                            : len(prism_rtl::deref(pl_p25).dyns) > Nat(0u)
                            ? Text::lit("$")
                            : Text::lit("");
                        auto with_opt_pd = ({
                            __label__ _done;
                            prism_rtl::Slot<crate::check::types::Ty> _v;
                            auto&& _m = index(pl_p25->opts, Nat(0u));
                            if (prism_rtl::is_some(_m)) {
                                auto&& o_p27 = prism_rtl::some_of(_m);
                                _v.set(crate::check::types::Ty(crate::check::types::Ty::TySig{o_p27, prism_rtl::rc(res_p5_6)}));
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(res_p5_6);
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        });
                        auto result_pe = prism_rtl::deref(pl_p25).broken
                            ? crate::check::types::Ty(crate::check::types::Ty::TyErr{})
                            : layer_pc == Text::lit("")
                            ? with_opt_pd
                            : crate::check::types::Ty(crate::check::types::Ty::TySig{layer_pc, prism_rtl::rc(with_opt_pd)});
                        call_then(crate::check::types::colors::start_walk_col(st6_pb, col_p3_2), [=, layer_pc = std::move(layer_pc), result_pe = std::move(result_pe)](crate::check::types::Col walk_col_15617) {
                        return ({
                            auto call_col_pf = walk_col_15617;
                            auto st7_pg = (layer_pc != Text::lit("")) && crate::check::types::colors::is_flex_col(call_col_pf)
                                ? crate::check::types::colors::add_leq(st6_pb, call_col_pf, crate::check::types::Col(crate::check::types::Col::CBound{}), span_p7_7, Text::lit("lifted"), fname_p2_4, prism_rtl::deref(pl_p25).lifted)
                                : st6_pb;
                            auto lifted_bad_ph = ((layer_pc != Text::lit("")) && (call_col_pf != crate::check::types::Col(crate::check::types::Col::CBound{}))) && (!crate::check::types::colors::is_flex_col(call_col_pf));
                            auto st8_pi = std::move(lifted_bad_ph)
                                ? crate::check::types::recording::err_fix(st7_pg, Text::lit("lifted-unbounded"), span_p7_7, prism_rtl::cat(crate::check::types::colors::col_word(call_col_pf), " `", fname_p2_4, "` lifted over `", prism_rtl::deref(pl_p25).lifted, "`; use `@Run`"), prism_rtl::cat("run it through `!done <- @Run ", fname_p2_4, ", ...`"))
                                : st7_pg;
                            call_then(crate::check::types::colors::start_use_color(st8_pi, call_col_pf, fname_p2_4, span_p7_7), [=](crate::check::types::St use_color_16047) {
                            return ({
                                auto st9_pj = use_color_16047;
                                auto kind_pk = (layer_pc == Text::lit("!")) && (len(prism_rtl::deref(pl_p25).dyns) > Nat(0u))
                                    ? Text::lit("sample")
                                    : layer_pc != Text::lit("")
                                    ? Text::lit("map")
                                    : fname_p2_4 == Text::lit("$") ? Text::lit("const") : Text::lit("plain");
                                auto peeled_pl = append(prism_rtl::deref(pl_p25).events, prism_rtl::deref(pl_p25).dyns);
                                auto lifted_pm = filter(crate::check::errors::range0(n_p8), [&](const Nat& i_p28) { return has_range(peeled_pl, prism_rtl::deref(or_(index(args_p6_1, i_p28), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span_p7_7}, .span = span_p7_7})->value).span); });
                                auto st10_pn = prism_rtl::deref(pl_p25).broken || (len(pl_p25->opts) != Nat(1u))
                                    ? st9_pj
                                    : crate::check::types::recording::note_lift(st9_pj, span_p7_7, or_(index(pl_p25->opts, Nat(0u)), Text::lit("")), prism_rtl::deref(pl_p25).opt_args);
                                (prism_rtl::finished(std::tuple{result_pe, crate::check::types::recording::note_app(st10_pn, span_p7_7, fname_p2_4, kind_pk, layer_pc, lifted_pm, or_(index(pl_p25->opts, Nat(0u)), Text::lit("")), call_col_pf)}));
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start ApplyRule, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_apply_rule(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text fname_p2, crate::check::types::Col col_p3, Array<crate::check::types::Ty> params_p4, crate::check::types::Ty res_p5, Array<crate::syntax::Arg> args_p6, crate::syntax::Range span_p7) {
    return prism_rtl::make_rc<ApplyRule>(env_p0, st_p1, fname_p2, col_p3, params_p4, res_p5, args_p6, span_p7);
}


/// HasRange: fn [Range], Range -> Bool
bool has_range(const Array<crate::syntax::Range>& rs_p0, const crate::syntax::Range& r_p1) {
    return fold(rs_p0, false, [&](const bool& seen_p2, const crate::syntax::Range& x_p3) { return prism_rtl::deref(seen_p2) || (x_p3 == r_p1); });
}


/// Elab: fn St, Range, Text, Text, Text -> St
crate::check::types::St elab(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const Text& what_p2, const Text& kind_p3, const Text& layer_p4) {
    return crate::check::types::recording::note_app(st_p0, span_p1, what_p2, kind_p3, layer_p4, Array<Nat>{}, Text::lit(""), crate::check::types::Col(crate::check::types::Col::CBound{}));
}


/// PlainArg: unbounded fn Env, St, Text, Ty, Ty, Arg -> St
crate::check::types::St plain_arg(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Text& fname_p2, const crate::check::types::Ty& param_p3, const crate::check::types::Ty& at_p4, const crate::syntax::Arg& a_p5) {
    auto p_p6 = crate::check::types::recording::walk(st_p1, param_p3);
    auto ph_p7 = crate::check::types::head_sigil(st_p1, p_p6);
    return at_p4 == crate::check::types::Ty(crate::check::types::Ty::TyErr{})
        ? st_p1
        : crate::check::expr::is_time_sigil(ph_p7) || (ph_p7 == Text::lit("@"))
        ? ({
        auto shown_p8 = crate::check::types::is_flex_var(st_p1, at_p4)
            ? crate::check::expr::src_text(env_p0, prism_rtl::deref(a_p5.value).span)
            : crate::check::types::show_ty(st_p1, at_p4);
        (crate::check::types::recording::err_fix(st_p1, Text::lit("plain-for-sigiled"), prism_rtl::deref(a_p5.value).span, prism_rtl::cat("a plain `", shown_p8, "` where `", fname_p2, "` takes a `", crate::check::types::show_ty(st_p1, p_p6), "`"), prism_rtl::cat("write `", ph_p7, " ", crate::check::expr::src_text(env_p0, prism_rtl::deref(a_p5.value).span), "`")));
    })
        : crate::check::types::unify::unify(st_p1, p_p6, at_p4, prism_rtl::deref(a_p5.value).span);
}


prism_rtl::Turn<crate::check::types::St> PlainArg::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& fname_p2 = this->fname_p2;
    const auto& param_p3 = this->param_p3;
    const auto& at_p4 = this->at_p4;
    const auto& a_p5 = this->a_p5;
    auto a_p5_1 = a_p5;
    auto at_p4_2 = at_p4;
    auto env_p0_3 = env_p0;
    auto fname_p2_4 = fname_p2;
    auto param_p3_5 = param_p3;
    auto st_p1_6 = st_p1;
    return call_then(crate::check::types::recording::start_walk(st_p1_6, param_p3_5), [=](crate::check::types::Ty walk_17274) {
        return ({
            auto p_p6 = walk_17274;
            call_then(crate::check::types::start_head_sigil(st_p1_6, p_p6), [=](Text head_sigil_17302) {
            return ({
                auto ph_p7 = head_sigil_17302;
                at_p4_2 == crate::check::types::Ty(crate::check::types::Ty::TyErr{})
                ? prism_rtl::finished(st_p1_6)
                : crate::check::expr::is_time_sigil(ph_p7) || (ph_p7 == Text::lit("@"))
                ? call_then(crate::check::types::start_is_flex_var(st_p1_6, at_p4_2), [=](bool is_flex_var_17408) {
                return ({
                    auto shown_p8 = is_flex_var_17408
                        ? crate::check::expr::src_text(env_p0_3, prism_rtl::deref(a_p5_1->value).span)
                        : crate::check::types::show_ty(st_p1_6, at_p4_2);
                    call_then(crate::check::types::start_show_ty(st_p1_6, p_p6), [=, shown_p8 = std::move(shown_p8)](Text show_ty_17571) { return prism_rtl::finished(crate::check::types::recording::err_fix(st_p1_6, Text::lit("plain-for-sigiled"), prism_rtl::deref(a_p5_1->value).span, prism_rtl::cat("a plain `", shown_p8, "` where `", fname_p2_4, "` takes a `", show_ty_17571, "`"), prism_rtl::cat("write `", ph_p7, " ", crate::check::expr::src_text(env_p0_3, prism_rtl::deref(a_p5_1->value).span), "`"))); });
                });
            })
                : prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st_p1_6, p_p6, at_p4_2, prism_rtl::deref(a_p5_1->value).span)));
            });
        });
        });
    });
}


/// `Start PlainArg, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_plain_arg(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text fname_p2, crate::check::types::Ty param_p3, crate::check::types::Ty at_p4, crate::syntax::Arg a_p5) {
    return prism_rtl::make_rc<PlainArg>(env_p0, st_p1, fname_p2, param_p3, at_p4, a_p5);
}


/// LayeredArg: unbounded fn Env, St, Peeled, Text, Bool, Ty, Ty, Arg -> ((Peeled, St))
std::tuple<Peeled, crate::check::types::St> layered_arg(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Peeled& acc_p2, const Text& fname_p3, const bool& cmp_p4, const crate::check::types::Ty& param_p5, const crate::check::types::Ty& at_p6, const crate::syntax::Arg& a_p7) {
    auto p_p8 = crate::check::types::recording::walk(st_p1, param_p5);
    auto span_p9 = prism_rtl::deref(a_p7.value).span;
    auto ph_pa = crate::check::types::head_sigil(st_p1, p_p8);
    return crate::check::types::is_free_headed(st_p1, at_p6)
        ? ({
        auto st2_pb = ((crate::check::expr::is_time_sigil(ph_pa) || (ph_pa == Text::lit("@"))) || (ph_pa == Text::lit("&"))) || cmp_p4
            ? st_p1
            : crate::check::types::unify::ask_layer(st_p1, at_p6, span_p9, fname_p3);
        std::tuple{acc_p2, crate::check::types::unify::unify(st2_pb, p_p8, at_p6, span_p9)};
    })
        : (crate::check::expr::is_time_sigil(ph_pa) || (ph_pa == Text::lit("@"))) || (ph_pa == Text::lit("&"))
        ? std::tuple{acc_p2, crate::check::types::unify::unify(st_p1, p_p8, at_p6, span_p9)}
        : crate::check::expr::is_plain_sigil(ph_pa)
        ? peel_time_only(env_p0, st_p1, acc_p2, fname_p3, p_p8, at_p6, a_p7)
        : ({
        auto head_pc = crate::check::types::head_sigil(st_p1, at_p6);
        head_pc == Text::lit("@")
        ? std::tuple{acc_p2, crate::check::types::recording::err_fix(st_p1, Text::lit("blueprint-operand"), span_p9, prism_rtl::cat("`", fname_p3, "` over a blueprint; bind it first"), prism_rtl::cat("bind it, `x <- ", crate::check::expr::src_text(env_p0, span_p9), "`, and use `x`"))}
        : crate::check::expr::is_time_sigil(head_pc)
        ? ({
        auto inner_pd = crate::check::expr::inner_of(st_p1, at_p6);
        auto ih_pe = crate::check::types::head_sigil(st_p1, inner_pd);
        auto acc2_pf = ({
            Peeled this_ = acc_p2;
            if (head_pc == Text::lit("!")) {
                this_.events = crate::prelude::push(this_.events, span_p9);
            } else  {
                this_.dyns = crate::prelude::push(this_.dyns, span_p9);
            }
            if (this_.lifted == Text::lit("")) {
                this_.lifted = crate::check::expr::src_text(env_p0, span_p9);
            }
            (std::move(this_));
        });
        crate::check::expr::is_time_sigil(ih_pe)
        ? ({
        auto what_pg = ih_pe == Text::lit("$") ? Text::lit("dynamic") : Text::lit("event");
        std::tuple{acc2_pf, crate::check::types::recording::err_fix(st_p1, Text::lit("two-layers"), span_p9, prism_rtl::cat("`", fname_p3, "` over a ", head_pc == Text::lit("$") ? Text::lit("dynamic") : Text::lit("event"), " of ", what_pg, "s"), Text::lit("take one layer off with a binding first: `@Flatten` or `@Switch`"))};
    })
        : crate::check::expr::is_plain_sigil(ih_pe) && (!cmp_p4)
        ? ({
        auto inner2_ph = crate::check::expr::inner_of(st_p1, inner_pd);
        (crate::check::expr::is_time_sigil(crate::check::types::head_sigil(st_p1, inner2_ph)) || (crate::check::types::head_sigil(st_p1, inner2_ph) == Text::lit("@"))
        ? std::tuple{acc2_pf, crate::check::types::recording::err(st_p1, Text::lit("layer-under-optional"), span_p9, prism_rtl::cat("`", fname_p3, "` over an optional ", ih_pe == Text::lit("?") ? Text::lit("") : Text::lit("fault "), "dynamic"))}
        : ({
        auto acc3_pi = ({
            Peeled this_ = acc2_pf;
            this_.opts = crate::check::types::add_text(this_.opts, ih_pe);
            this_.opt_args = crate::prelude::push(this_.opt_args, span_p9);
            (std::move(this_));
        });
        std::tuple{acc3_pi, crate::check::types::unify::unify(st_p1, p_p8, inner2_ph, span_p9)};
    }));
    })
        : std::tuple{acc2_pf, crate::check::types::unify::unify(st_p1, p_p8, inner_pd, span_p9)};
    })
        : crate::check::expr::is_plain_sigil(head_pc) && (!cmp_p4)
        ? ({
        auto inner_pj = crate::check::expr::inner_of(st_p1, at_p6);
        auto ih_pk = crate::check::types::head_sigil(st_p1, inner_pj);
        (crate::check::expr::is_time_sigil(ih_pk) || (ih_pk == Text::lit("@"))
        ? std::tuple{acc_p2, crate::check::types::recording::err_fix(st_p1, Text::lit("layer-under-optional"), span_p9, prism_rtl::cat("`", fname_p3, "` over an optional dynamic"), Text::lit("match the optional once, at build time, to find out whether there is a dynamic"))}
        : ({
        auto acc2_pl = ({
            Peeled this_ = acc_p2;
            this_.opts = crate::check::types::add_text(this_.opts, head_pc);
            this_.opt_args = crate::prelude::push(this_.opt_args, span_p9);
            (std::move(this_));
        });
        std::tuple{acc2_pl, crate::check::types::unify::unify(st_p1, p_p8, inner_pj, span_p9)};
    }));
    })
        : head_pc == Text::lit("&")
        ? std::tuple{acc_p2, crate::check::types::unify::unify(st_p1, p_p8, crate::check::expr::inner_of(st_p1, at_p6), span_p9)}
        : std::tuple{acc_p2, crate::check::types::unify::unify(st_p1, p_p8, at_p6, span_p9)};
    });
}


prism_rtl::Turn<std::tuple<Peeled, crate::check::types::St>> LayeredArg::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& acc_p2 = this->acc_p2;
    const auto& fname_p3 = this->fname_p3;
    const auto& cmp_p4 = this->cmp_p4;
    const auto& param_p5 = this->param_p5;
    const auto& at_p6 = this->at_p6;
    const auto& a_p7 = this->a_p7;
    auto a_p7_1 = a_p7;
    auto acc_p2_2 = acc_p2;
    auto at_p6_3 = at_p6;
    auto cmp_p4_4 = prism_rtl::deref(cmp_p4);
    auto env_p0_5 = env_p0;
    auto fname_p3_6 = fname_p3;
    auto param_p5_7 = param_p5;
    auto st_p1_8 = st_p1;
    return call_then(crate::check::types::recording::start_walk(st_p1_8, param_p5_7), [=](crate::check::types::Ty walk_17883) {
        return ({
            auto p_p8 = walk_17883;
            auto span_p9 = prism_rtl::deref(a_p7_1->value).span;
            call_then(crate::check::types::start_head_sigil(st_p1_8, p_p8), [=, span_p9 = std::move(span_p9)](Text head_sigil_17939) {
            return ({
                auto ph_pa = head_sigil_17939;
                call_then(crate::check::types::start_is_free_headed(st_p1_8, at_p6_3), [=, ph_pa = std::move(ph_pa)](bool is_free_headed_17962) {
                return is_free_headed_17962
                    ? ({
                    auto st2_pb = ((crate::check::expr::is_time_sigil(ph_pa) || (ph_pa == Text::lit("@"))) || (ph_pa == Text::lit("&"))) || cmp_p4_4
                        ? st_p1_8
                        : crate::check::types::unify::ask_layer(st_p1_8, at_p6_3, span_p9, fname_p3_6);
                    call_then(crate::check::types::unify::start_unify(st2_pb, p_p8, at_p6_3, span_p9), [=](crate::check::types::St unify_18109) { return prism_rtl::finished(std::tuple{acc_p2_2, unify_18109}); });
                })
                    : (crate::check::expr::is_time_sigil(ph_pa) || (ph_pa == Text::lit("@"))) || (ph_pa == Text::lit("&"))
                    ? call_then(crate::check::types::unify::start_unify(st_p1_8, p_p8, at_p6_3, span_p9), [=](crate::check::types::St unify_18200) { return prism_rtl::finished(std::tuple{acc_p2_2, unify_18200}); })
                    : crate::check::expr::is_plain_sigil(ph_pa)
                    ? prism_rtl::more(prism_rtl::rc(PeelTimeOnly(env_p0_5, st_p1_8, acc_p2_2, fname_p3_6, p_p8, at_p6_3, a_p7_1)))
                    : call_then(crate::check::types::start_head_sigil(st_p1_8, at_p6_3), [=](Text head_sigil_18327) {
                    return ({
                        auto head_pc = head_sigil_18327;
                        head_pc == Text::lit("@")
                        ? prism_rtl::finished(std::tuple{acc_p2_2, crate::check::types::recording::err_fix(st_p1_8, Text::lit("blueprint-operand"), span_p9, prism_rtl::cat("`", fname_p3_6, "` over a blueprint; bind it first"), prism_rtl::cat("bind it, `x <- ", crate::check::expr::src_text(env_p0_5, span_p9), "`, and use `x`"))})
                        : crate::check::expr::is_time_sigil(head_pc)
                        ? call_then(crate::check::expr::start_inner_of(st_p1_8, at_p6_3), [=](crate::check::types::Ty inner_of_18572) {
                        return ({
                            auto inner_pd = inner_of_18572;
                            call_then(crate::check::types::start_head_sigil(st_p1_8, inner_pd), [=](Text head_sigil_18608) {
                            return ({
                                auto ih_pe = head_sigil_18608;
                                auto acc2_pf = ({
                                    Peeled this_ = acc_p2_2;
                                    if (head_pc == Text::lit("!")) {
                                        this_.events = crate::prelude::push(this_.events, span_p9);
                                    } else  {
                                        this_.dyns = crate::prelude::push(this_.dyns, span_p9);
                                    }
                                    if (this_.lifted == Text::lit("")) {
                                        this_.lifted = crate::check::expr::src_text(env_p0_5, span_p9);
                                    }
                                    (std::move(this_));
                                });
                                (crate::check::expr::is_time_sigil(ih_pe)
                                ? ({
                                auto what_pg = ih_pe == Text::lit("$") ? Text::lit("dynamic") : Text::lit("event");
                                (prism_rtl::finished(std::tuple{acc2_pf, crate::check::types::recording::err_fix(st_p1_8, Text::lit("two-layers"), span_p9, prism_rtl::cat("`", fname_p3_6, "` over a ", head_pc == Text::lit("$") ? Text::lit("dynamic") : Text::lit("event"), " of ", what_pg, "s"), Text::lit("take one layer off with a binding first: `@Flatten` or `@Switch`"))}));
                            })
                                : crate::check::expr::is_plain_sigil(ih_pe) && (!cmp_p4_4)
                                ? call_then(crate::check::expr::start_inner_of(st_p1_8, inner_pd), [=](crate::check::types::Ty inner_of_19284) {
                                return ({
                                    auto inner2_ph = inner_of_19284;
                                    call_then(crate::check::types::start_head_sigil(st_p1_8, inner2_ph), [=](Text head_sigil_19335) {
                                    return crate::check::expr::is_time_sigil(head_sigil_19335) || (crate::check::types::head_sigil(st_p1_8, inner2_ph) == Text::lit("@"))
                                        ? prism_rtl::finished(std::tuple{acc2_pf, crate::check::types::recording::err(st_p1_8, Text::lit("layer-under-optional"), span_p9, prism_rtl::cat("`", fname_p3_6, "` over an optional ", ih_pe == Text::lit("?") ? Text::lit("") : Text::lit("fault "), "dynamic"))})
                                        : ({
                                        auto acc3_pi = ({
                                            Peeled this_ = acc2_pf;
                                            this_.opts = crate::check::types::add_text(this_.opts, ih_pe);
                                            this_.opt_args = crate::prelude::push(this_.opt_args, span_p9);
                                            (std::move(this_));
                                        });
                                        call_then(crate::check::types::unify::start_unify(st_p1_8, p_p8, inner2_ph, span_p9), [=, acc3_pi = std::move(acc3_pi)](crate::check::types::St unify_19742) { return prism_rtl::finished(std::tuple{acc3_pi, unify_19742}); });
                                    });
                                });
                                });
                            })
                                : call_then(crate::check::types::unify::start_unify(st_p1_8, p_p8, inner_pd, span_p9), [=](crate::check::types::St unify_19798) { return prism_rtl::finished(std::tuple{acc2_pf, unify_19798}); }));
                            });
                        });
                        });
                    })
                        : crate::check::expr::is_plain_sigil(head_pc) && (!cmp_p4_4)
                        ? call_then(crate::check::expr::start_inner_of(st_p1_8, at_p6_3), [=](crate::check::types::Ty inner_of_19900) {
                        return ({
                            auto inner_pj = inner_of_19900;
                            call_then(crate::check::types::start_head_sigil(st_p1_8, inner_pj), [=](Text head_sigil_19936) {
                            return ({
                                auto ih_pk = head_sigil_19936;
                                (crate::check::expr::is_time_sigil(ih_pk) || (ih_pk == Text::lit("@"))
                                ? prism_rtl::finished(std::tuple{acc_p2_2, crate::check::types::recording::err_fix(st_p1_8, Text::lit("layer-under-optional"), span_p9, prism_rtl::cat("`", fname_p3_6, "` over an optional dynamic"), Text::lit("match the optional once, at build time, to find out whether there is a dynamic"))})
                                : ({
                                auto acc2_pl = ({
                                    Peeled this_ = acc_p2_2;
                                    this_.opts = crate::check::types::add_text(this_.opts, head_pc);
                                    this_.opt_args = crate::prelude::push(this_.opt_args, span_p9);
                                    (std::move(this_));
                                });
                                call_then(crate::check::types::unify::start_unify(st_p1_8, p_p8, inner_pj, span_p9), [=, acc2_pl = std::move(acc2_pl)](crate::check::types::St unify_20380) { return prism_rtl::finished(std::tuple{acc2_pl, unify_20380}); });
                            }));
                            });
                        });
                        });
                    })
                        : head_pc == Text::lit("&")
                        ? call_then(crate::check::expr::start_inner_of(st_p1_8, at_p6_3), [=](crate::check::types::Ty inner_of_20460) { return call_then(crate::check::types::unify::start_unify(st_p1_8, p_p8, inner_of_20460, span_p9), [=](crate::check::types::St unify_20446) { return prism_rtl::finished(std::tuple{acc_p2_2, unify_20446}); }); })
                        : call_then(crate::check::types::unify::start_unify(st_p1_8, p_p8, at_p6_3, span_p9), [=](crate::check::types::St unify_20507) { return prism_rtl::finished(std::tuple{acc_p2_2, unify_20507}); });
                    });
                });
            });
            });
        });
        });
    });
}


/// `Start LayeredArg, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Peeled, crate::check::types::St>> start_layered_arg(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Peeled acc_p2, Text fname_p3, bool cmp_p4, crate::check::types::Ty param_p5, crate::check::types::Ty at_p6, crate::syntax::Arg a_p7) {
    return prism_rtl::make_rc<LayeredArg>(env_p0, st_p1, acc_p2, fname_p3, cmp_p4, param_p5, at_p6, a_p7);
}


/// PeelTimeOnly: unbounded fn Env, St, Peeled, Text, Ty, Ty, Arg -> ((Peeled, St))
std::tuple<Peeled, crate::check::types::St> peel_time_only(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Peeled& acc_p2, const Text& fname_p3, const crate::check::types::Ty& p_p4, const crate::check::types::Ty& at_p5, const crate::syntax::Arg& a_p6) {
    auto span_p7 = prism_rtl::deref(a_p6.value).span;
    auto head_p8 = crate::check::types::head_sigil(st_p1, at_p5);
    return head_p8 == Text::lit("@")
        ? std::tuple{acc_p2, crate::check::types::recording::err_fix(st_p1, Text::lit("blueprint-operand"), span_p7, prism_rtl::cat("`", fname_p3, "` over a blueprint; bind it first"), prism_rtl::cat("bind it, `x <- ", crate::check::expr::src_text(env_p0, span_p7), "`, and use `x`"))}
        : crate::check::expr::is_time_sigil(head_p8)
        ? ({
        auto inner_p9 = crate::check::expr::inner_of(st_p1, at_p5);
        auto acc2_pa = ({
            Peeled this_ = acc_p2;
            if (head_p8 == Text::lit("!")) {
                this_.events = crate::prelude::push(this_.events, span_p7);
            } else  {
                this_.dyns = crate::prelude::push(this_.dyns, span_p7);
            }
            if (this_.lifted == Text::lit("")) {
                this_.lifted = crate::check::expr::src_text(env_p0, span_p7);
            }
            (std::move(this_));
        });
        crate::check::expr::is_time_sigil(crate::check::types::head_sigil(st_p1, inner_p9))
        ? std::tuple{acc2_pa, crate::check::types::recording::err_fix(st_p1, Text::lit("two-layers"), span_p7, prism_rtl::cat("`", fname_p3, "` over a ", head_p8 == Text::lit("$") ? Text::lit("dynamic") : Text::lit("event"), " of ", crate::check::types::head_sigil(st_p1, inner_p9) == Text::lit("$")
        ? Text::lit("dynamic")
        : Text::lit("event"), "s"), Text::lit("take one layer off with a binding first: `@Flatten` or `@Switch`"))}
        : std::tuple{acc2_pa, crate::check::types::unify::unify(st_p1, p_p4, inner_p9, span_p7)};
    })
        : std::tuple{acc_p2, crate::check::types::unify::unify(st_p1, p_p4, at_p5, span_p7)};
}


prism_rtl::Turn<std::tuple<Peeled, crate::check::types::St>> PeelTimeOnly::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& acc_p2 = this->acc_p2;
    const auto& fname_p3 = this->fname_p3;
    const auto& p_p4 = this->p_p4;
    const auto& at_p5 = this->at_p5;
    const auto& a_p6 = this->a_p6;
    auto span_p7 = prism_rtl::deref(a_p6->value).span;
    auto a_p6_1 = a_p6;
    auto acc_p2_2 = acc_p2;
    auto at_p5_3 = at_p5;
    auto env_p0_4 = env_p0;
    auto fname_p3_5 = fname_p3;
    auto p_p4_6 = p_p4;
    auto st_p1_7 = st_p1;
    return call_then(crate::check::types::start_head_sigil(st_p1_7, at_p5_3), [=](Text head_sigil_20793) {
        return ({
            auto head_p8 = head_sigil_20793;
            head_p8 == Text::lit("@")
            ? prism_rtl::finished(std::tuple{acc_p2_2, crate::check::types::recording::err_fix(st_p1_7, Text::lit("blueprint-operand"), span_p7, prism_rtl::cat("`", fname_p3_5, "` over a blueprint; bind it first"), prism_rtl::cat("bind it, `x <- ", crate::check::expr::src_text(env_p0_4, span_p7), "`, and use `x`"))})
            : crate::check::expr::is_time_sigil(head_p8)
            ? call_then(crate::check::expr::start_inner_of(st_p1_7, at_p5_3), [=](crate::check::types::Ty inner_of_21026) {
            return ({
                auto inner_p9 = inner_of_21026;
                auto acc2_pa = ({
                    Peeled this_ = acc_p2_2;
                    if (head_p8 == Text::lit("!")) {
                        this_.events = crate::prelude::push(this_.events, span_p7);
                    } else  {
                        this_.dyns = crate::prelude::push(this_.dyns, span_p7);
                    }
                    if (this_.lifted == Text::lit("")) {
                        this_.lifted = crate::check::expr::src_text(env_p0_4, span_p7);
                    }
                    (std::move(this_));
                });
                call_then(crate::check::types::start_head_sigil(st_p1_7, inner_p9), [=, acc2_pa = std::move(acc2_pa)](Text head_sigil_21317) {
                return crate::check::expr::is_time_sigil(head_sigil_21317)
                    ? call_then(crate::check::types::start_head_sigil(st_p1_7, inner_p9), [=](Text head_sigil_21447) {
                    return prism_rtl::finished(std::tuple{acc2_pa, crate::check::types::recording::err_fix(st_p1_7, Text::lit("two-layers"), span_p7, prism_rtl::cat("`", fname_p3_5, "` over a ", head_p8 == Text::lit("$") ? Text::lit("dynamic") : Text::lit("event"), " of ", head_sigil_21447 == Text::lit("$")
                        ? Text::lit("dynamic")
                        : Text::lit("event"), "s"), Text::lit("take one layer off with a binding first: `@Flatten` or `@Switch`"))});
                })
                    : call_then(crate::check::types::unify::start_unify(st_p1_7, p_p4_6, inner_p9, span_p7), [=](crate::check::types::St unify_21597) { return prism_rtl::finished(std::tuple{acc2_pa, unify_21597}); });
            });
            });
        })
            : call_then(crate::check::types::unify::start_unify(st_p1_7, p_p4_6, at_p5_3, span_p7), [=](crate::check::types::St unify_21643) { return prism_rtl::finished(std::tuple{acc_p2_2, unify_21643}); });
        });
    });
}


/// `Start PeelTimeOnly, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Peeled, crate::check::types::St>> start_peel_time_only(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Peeled acc_p2, Text fname_p3, crate::check::types::Ty p_p4, crate::check::types::Ty at_p5, crate::syntax::Arg a_p6) {
    return prism_rtl::make_rc<PeelTimeOnly>(env_p0, st_p1, acc_p2, fname_p3, p_p4, at_p5, a_p6);
}


/// CtorApp: unbounded fn Env, St, CtorInfo, [Arg], Range, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> ctor_app(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::check::env::CtorInfo& c_p2, const Array<crate::syntax::Arg>& args_p3, const crate::syntax::Range& span_p4, const crate::syntax::Range& cspan_p5) {
    auto [self_p9, st0_pa, inst_pb] = crate::check::types::schemes::instantiate_with(st_p1, crate::check::types::Scheme{.qs = c_p2.params, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = c_p2.ty}, span_p4, Array<crate::check::types::Ty>{});
    auto field_tys_p6 = run_to_end(each_job(c_p2.args, ({
        auto inst_pb_1 = inst_pb;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, inst_pb_1 = std::move(inst_pb_1)](crate::check::types::Ty p0) {
        return ({
            auto inst_pb_1_2 = inst_pb_1;
            entered(once_job([=, inst_pb_1_2 = std::move(inst_pb_1_2)]() {
            return ({
                auto t_pc = p0;
                (prism_rtl::more(prism_rtl::rc(crate::check::types::schemes::SubstQ(inst_pb_1_2, t_pc))));
            });
        }));
        });
    })));
    })));
    auto st1_p7 = crate::check::types::recording::note_ty(st0_pa, cspan_p5, crate::check::types::Ty(crate::check::types::Ty::TyFn{crate::check::types::Col(crate::check::types::Col::CBound{}), field_tys_p6, prism_rtl::rc(self_p9)}));
    auto named_p8 = filter(args_p3, [&](const crate::syntax::Arg& a_pd) { return prism_rtl::deref(a_pd).name != std::optional<crate::syntax::Ident>{}; });
    return (len(named_p8) > Nat(0u)) && (len(c_p2.fields) > Nat(0u))
        ? ({
        auto st2_pe = run_to_end(fold_job(named_p8, st1_p7, ({
            auto c_p2_1 = c_p2;
            auto env_p0_2 = env_p0;
            auto field_tys_p6_3 = field_tys_p6;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Arg>)>>(prism_rtl::rc([=, c_p2_1 = std::move(c_p2_1), env_p0_2 = std::move(env_p0_2), field_tys_p6_3 = std::move(field_tys_p6_3)](std::tuple<crate::check::types::St, crate::syntax::Arg> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto c_p2_1_4 = c_p2_1;
                auto env_p0_2_4 = env_p0_2;
                auto field_tys_p6_3_4 = field_tys_p6_3;
                entered(once_job([=, c_p2_1_4 = std::move(c_p2_1_4), env_p0_2_4 = std::move(env_p0_2_4), field_tys_p6_3_4 = std::move(field_tys_p6_3_4)]() {
                return ({
                    auto s_ph = p0;
                    auto a_pi = p1;
                    ({
                    auto&& _m = prism_rtl::deref(a_pi).name;
                    prism_rtl::is_some(_m) ? ({
                    auto&& id_pj = prism_rtl::some_of(_m);
                    ({
                    auto&& _m = crate::check::expr::operators::index_of(c_p2_1_4.fields, prism_rtl::deref(id_pj).name);
                    prism_rtl::is_some(_m) ? ({
                    auto&& i_pk = prism_rtl::some_of(_m);
                    prism_rtl::more(prism_rtl::rc(crate::check::expr::Check(env_p0_2_4, s_ph, a_pi->value, or_(index(field_tys_p6_3_4, i_pk), crate::check::types::Ty(crate::check::types::Ty::TyErr{})))));
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::check::types::recording::err(s_ph, Text::lit("mismatch"), prism_rtl::deref(a_pi).span, prism_rtl::cat("`", crate::check::types::bare_name(c_p2_1_4.owner), "` has no field `", prism_rtl::deref(id_pj).name, "`")))
                    : throw prism_rtl::Panic("no arm matched");
                });
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(s_ph)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        })));
        })));
        auto missing_pf = filter(c_p2.fields, [&](const Text& f_pl) { return !fold(named_p8, false, [&](const bool& seen_pm, const crate::syntax::Arg& a_pn) { return prism_rtl::deref(seen_pm) || arg_named(a_pn, f_pl); }); });
        auto st3_pg = len(missing_pf) > Nat(0u)
            ? crate::check::types::recording::err(st2_pe, Text::lit("mismatch"), span_p4, prism_rtl::cat("`", crate::check::types::bare_name(c_p2.owner), "` needs ", crate::syntax::lexer::chars::join(each(missing_pf, [&](const Text& f_po) { return prism_rtl::cat("`", f_po, "`"); }), Text::lit(", "))))
            : st2_pe;
        std::tuple{self_p9, st3_pg};
    })
        : len(args_p3) != len(field_tys_p6)
        ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st1_p7, Text::lit("mismatch"), span_p4, prism_rtl::cat("`", crate::check::types::bare_name(c_p2.name), "` takes ", crate::check::errors::count_word(len(field_tys_p6)), " argument", len(field_tys_p6) == Nat(1u) ? Text::lit("") : Text::lit("s"), "; here it has ", crate::check::errors::count_word(len(args_p3))))}
        : ({
        auto st2_pp = run_to_end(fold_job(crate::check::errors::range0(len(args_p3)), st1_p7, ({
            auto args_p3_1 = args_p3;
            auto env_p0_2 = env_p0;
            auto field_tys_p6_3 = field_tys_p6;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Nat>)>>(prism_rtl::rc([=, args_p3_1 = std::move(args_p3_1), env_p0_2 = std::move(env_p0_2), field_tys_p6_3 = std::move(field_tys_p6_3)](std::tuple<crate::check::types::St, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto args_p3_1_4 = args_p3_1;
                auto env_p0_2_4 = env_p0_2;
                auto field_tys_p6_3_4 = field_tys_p6_3;
                entered(once_job([=, args_p3_1_4 = std::move(args_p3_1_4), env_p0_2_4 = std::move(env_p0_2_4), field_tys_p6_3_4 = std::move(field_tys_p6_3_4)]() {
                return ({
                    auto s_pq = p0;
                    auto i_pr = p1;
                    ({
                    auto&& _m = index(args_p3_1_4, i_pr);
                    prism_rtl::is_some(_m) ? ({
                    auto&& a_ps = prism_rtl::some_of(_m);
                    prism_rtl::more(prism_rtl::rc(crate::check::expr::Check(env_p0_2_4, s_pq, a_ps->value, or_(index(field_tys_p6_3_4, i_pr), crate::check::types::Ty(crate::check::types::Ty::TyErr{})))));
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(s_pq)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        })));
        })));
        std::tuple{self_p9, st2_pp};
    });
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> CtorApp::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& c_p2 = this->c_p2;
    const auto& args_p3 = this->args_p3;
    const auto& span_p4 = this->span_p4;
    const auto& cspan_p5 = this->cspan_p5;
    auto args_p3_1 = args_p3;
    auto c_p2_2 = c_p2;
    auto cspan_p5_3 = cspan_p5;
    auto env_p0_4 = env_p0;
    auto span_p4_5 = span_p4;
    auto st_p1_6 = st_p1;
    return call_then(crate::check::types::schemes::start_instantiate_with(st_p1_6, crate::check::types::Scheme{.qs = prism_rtl::deref(c_p2_2).params, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = prism_rtl::deref(c_p2_2).ty}, span_p4_5, Array<crate::check::types::Ty>{}), [=](std::tuple<crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst> instantiate_with_21905) {
        return ({
            auto [self_p9, st0_pa, inst_pb] = instantiate_with_21905;
            call_value(each_job(c_p2_2->args, ({
            auto inst_pb_7 = inst_pb;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, inst_pb_7 = std::move(inst_pb_7)](crate::check::types::Ty p0) {
            return ({
                auto inst_pb_7_8 = inst_pb_7;
                entered(once_job([=, inst_pb_7_8 = std::move(inst_pb_7_8)]() {
                return ({
                    auto t_pc = p0;
                    (prism_rtl::more(prism_rtl::rc(crate::check::types::schemes::SubstQ(inst_pb_7_8, t_pc))));
                });
            }));
            });
        })));
        })), [=](Array<crate::check::types::Ty> each_22047) {
            return ({
                auto field_tys_p6 = each_22047;
                auto st1_p7 = crate::check::types::recording::note_ty(st0_pa, cspan_p5_3, crate::check::types::Ty(crate::check::types::Ty::TyFn{crate::check::types::Col(crate::check::types::Col::CBound{}), field_tys_p6, prism_rtl::rc(self_p9)}));
                auto named_p8 = filter(args_p3_1, [&](const crate::syntax::Arg& a_pd) { return prism_rtl::deref(a_pd).name != std::optional<crate::syntax::Ident>{}; });
                (len(named_p8) > Nat(0u)) && (len(prism_rtl::deref(c_p2_2).fields) > Nat(0u))
                ? call_value(fold_job(named_p8, st1_p7, ({
                auto c_p2_2_7 = c_p2_2;
                auto env_p0_4_7 = env_p0_4;
                auto field_tys_p6_7 = field_tys_p6;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Arg>)>>(prism_rtl::rc([=, c_p2_2_7 = std::move(c_p2_2_7), env_p0_4_7 = std::move(env_p0_4_7), field_tys_p6_7 = std::move(field_tys_p6_7)](std::tuple<crate::check::types::St, crate::syntax::Arg> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto c_p2_2_7_8 = c_p2_2_7;
                    auto env_p0_4_7_8 = env_p0_4_7;
                    auto field_tys_p6_7_8 = field_tys_p6_7;
                    entered(once_job([=, c_p2_2_7_8 = std::move(c_p2_2_7_8), env_p0_4_7_8 = std::move(env_p0_4_7_8), field_tys_p6_7_8 = std::move(field_tys_p6_7_8)]() {
                    return ({
                        auto s_ph = p0;
                        auto a_pi = p1;
                        ({
                        auto&& _m = prism_rtl::deref(a_pi).name;
                        prism_rtl::is_some(_m) ? ({
                        auto&& id_pj = prism_rtl::some_of(_m);
                        ({
                        auto&& _m = crate::check::expr::operators::index_of(prism_rtl::deref(c_p2_2_7_8).fields, prism_rtl::deref(id_pj).name);
                        prism_rtl::is_some(_m) ? ({
                        auto&& i_pk = prism_rtl::some_of(_m);
                        prism_rtl::more(prism_rtl::rc(crate::check::expr::Check(env_p0_4_7_8, s_ph, a_pi->value, or_(index(field_tys_p6_7_8, i_pk), crate::check::types::Ty(crate::check::types::Ty::TyErr{})))));
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::check::types::recording::err(s_ph, Text::lit("mismatch"), prism_rtl::deref(a_pi).span, prism_rtl::cat("`", crate::check::types::bare_name(prism_rtl::deref(c_p2_2_7_8).owner), "` has no field `", prism_rtl::deref(id_pj).name, "`")))
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(s_ph)
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                }));
                });
            })));
            })), [=](crate::check::types::St fold_22257) {
                return ({
                    auto st2_pe = fold_22257;
                    auto missing_pf = filter(prism_rtl::deref(c_p2_2).fields, [&](const Text& f_pl) { return !fold(named_p8, false, [&](const bool& seen_pm, const crate::syntax::Arg& a_pn) { return prism_rtl::deref(seen_pm) || arg_named(a_pn, f_pl); }); });
                    auto st3_pg = len(missing_pf) > Nat(0u)
                        ? crate::check::types::recording::err(st2_pe, Text::lit("mismatch"), span_p4_5, prism_rtl::cat("`", crate::check::types::bare_name(prism_rtl::deref(c_p2_2).owner), "` needs ", crate::syntax::lexer::chars::join(each(missing_pf, [&](const Text& f_po) { return prism_rtl::cat("`", f_po, "`"); }), Text::lit(", "))))
                        : st2_pe;
                    (prism_rtl::finished(std::tuple{self_p9, st3_pg}));
                });
            })
                : len(args_p3_1) != len(field_tys_p6)
                ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st1_p7, Text::lit("mismatch"), span_p4_5, prism_rtl::cat("`", crate::check::types::bare_name(prism_rtl::deref(c_p2_2).name), "` takes ", crate::check::errors::count_word(len(field_tys_p6)), " argument", len(field_tys_p6) == Nat(1u) ? Text::lit("") : Text::lit("s"), "; here it has ", crate::check::errors::count_word(len(args_p3_1))))})
                : call_value(fold_job(crate::check::errors::range0(len(args_p3_1)), st1_p7, ({
                auto args_p3_1_7 = args_p3_1;
                auto env_p0_4_7 = env_p0_4;
                auto field_tys_p6_7 = field_tys_p6;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Nat>)>>(prism_rtl::rc([=, args_p3_1_7 = std::move(args_p3_1_7), env_p0_4_7 = std::move(env_p0_4_7), field_tys_p6_7 = std::move(field_tys_p6_7)](std::tuple<crate::check::types::St, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto args_p3_1_7_8 = args_p3_1_7;
                    auto env_p0_4_7_8 = env_p0_4_7;
                    auto field_tys_p6_7_8 = field_tys_p6_7;
                    entered(once_job([=, args_p3_1_7_8 = std::move(args_p3_1_7_8), env_p0_4_7_8 = std::move(env_p0_4_7_8), field_tys_p6_7_8 = std::move(field_tys_p6_7_8)]() {
                    return ({
                        auto s_pq = p0;
                        auto i_pr = p1;
                        ({
                        auto&& _m = index(args_p3_1_7_8, i_pr);
                        prism_rtl::is_some(_m) ? ({
                        auto&& a_ps = prism_rtl::some_of(_m);
                        prism_rtl::more(prism_rtl::rc(crate::check::expr::Check(env_p0_4_7_8, s_pq, a_ps->value, or_(index(field_tys_p6_7_8, i_pr), crate::check::types::Ty(crate::check::types::Ty::TyErr{})))));
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(s_pq)
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                }));
                });
            })));
            })), [=](crate::check::types::St fold_23063) {
                return ({
                    auto st2_pp = fold_23063;
                    (prism_rtl::finished(std::tuple{self_p9, st2_pp}));
                });
            });
            });
        });
        });
    });
}


/// `Start CtorApp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_ctor_app(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::env::CtorInfo c_p2, Array<crate::syntax::Arg> args_p3, crate::syntax::Range span_p4, crate::syntax::Range cspan_p5) {
    return prism_rtl::make_rc<CtorApp>(env_p0, st_p1, c_p2, args_p3, span_p4, cspan_p5);
}


/// TagApp: unbounded fn Env, St, Text, [Arg], Range, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> tag_app(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Text& name_p2, const Array<crate::syntax::Arg>& args_p3, const crate::syntax::Range& span_p4, const crate::syntax::Range& cspan_p5) {
    auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0.g).tags, name_p2);
    if (prism_rtl::is_none(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("unknown-name"), span_p4, prism_rtl::cat("no tag `", name_p2, "`"))};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& tg_p6 = prism_rtl::some_of(_m);
        auto [out_pb, st1_pc, inst_pd] = crate::check::types::schemes::instantiate_with(st_p1, crate::check::types::Scheme{.qs = prism_rtl::deref(tg_p6).qs, .plain_qs = Array<Text>{}, .rqs = prism_rtl::deref(tg_p6).rqs, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = prism_rtl::deref(tg_p6).bounds, .ty = tg_p6->out}, span_p4, Array<crate::check::types::Ty>{});
        auto st2_p7 = run_to_end(fold_job(args_p3, st1_pc, ({
            auto tg_p6_1 = tg_p6;
            auto env_p0_2 = env_p0;
            auto name_p2_3 = name_p2;
            auto inst_pd_4 = inst_pd;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Arg>)>>(prism_rtl::rc([=, tg_p6_1 = std::move(tg_p6_1), env_p0_2 = std::move(env_p0_2), name_p2_3 = std::move(name_p2_3), inst_pd_4 = std::move(inst_pd_4)](std::tuple<crate::check::types::St, crate::syntax::Arg> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto tg_p6_1_5 = tg_p6_1;
                auto env_p0_2_5 = env_p0_2;
                auto name_p2_3_5 = name_p2_3;
                auto inst_pd_4_5 = inst_pd_4;
                entered(once_job([=, tg_p6_1_5 = std::move(tg_p6_1_5), env_p0_2_5 = std::move(env_p0_2_5), name_p2_3_5 = std::move(name_p2_3_5), inst_pd_4_5 = std::move(inst_pd_4_5)]() {
                return ({
                    auto s_pe = p0;
                    auto a_pf = p1;
                    ({
                    auto&& _m = prism_rtl::deref(a_pf).name;
                    prism_rtl::is_some(_m) ? ({
                    auto&& id_pg = prism_rtl::some_of(_m);
                    ({
                    auto&& _m = field_of_tag(tg_p6_1_5, prism_rtl::deref(id_pg).name);
                    prism_rtl::is_some(_m) ? ({
                    auto&& ft_ph = prism_rtl::some_of(_m);
                    ({
                    auto id_pg_5 = id_pg;
                    call_then(crate::check::types::schemes::start_subst_q(inst_pd_4_5, ft_ph), [=, id_pg_5 = std::move(id_pg_5)](crate::check::types::Ty subst_q_24017) { return prism_rtl::more(prism_rtl::rc(TagField(env_p0_2_5, s_pe, name_p2_3_5, prism_rtl::deref(id_pg_5).name, subst_q_24017, a_pf))); });
                });
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::check::types::recording::err(s_pe, Text::lit("mismatch"), prism_rtl::deref(a_pf).span, prism_rtl::cat("`", name_p2_3_5, "` has no field `", prism_rtl::deref(id_pg).name, "`")))
                    : throw prism_rtl::Panic("no arm matched");
                });
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::check::types::recording::err(s_pe, Text::lit("mismatch"), prism_rtl::deref(a_pf).span, prism_rtl::cat("a tag\'s fields are named: `", name_p2_3_5, "(field=...)`")))
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        })));
        })));
        auto missing_p8 = filter(prism_rtl::deref(tg_p6).fields, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
            auto&& f_pi = std::get<0>(_p0);
            return !fold(args_p3, false, [&](const bool& seen_pj, const crate::syntax::Arg& a_pk) { return prism_rtl::deref(seen_pj) || arg_named(a_pk, f_pi); });
        });
        auto st3_p9 = (len(missing_p8) > Nat(0u)) && (!fold(args_p3, false, [&](const bool& seen_pl, const crate::syntax::Arg& a_pm) { return prism_rtl::deref(seen_pl) || (prism_rtl::deref(prism_rtl::deref(a_pm->value).kind) == crate::syntax::ExprKind(crate::syntax::ExprKind::ERest{})); }))
            ? crate::check::types::recording::err(st2_p7, Text::lit("mismatch"), span_p4, prism_rtl::cat("`", name_p2, "` needs ", crate::syntax::lexer::chars::join(each(missing_p8, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
            auto&& f_pn = std::get<0>(_p0);
            return prism_rtl::cat("`", f_pn, "`");
        }), Text::lit(", "))))
            : st2_p7;
        auto field_tys_pa = run_to_end(each_job(prism_rtl::deref(tg_p6).fields, ({
            auto inst_pd_1 = inst_pd;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(std::tuple<Text, crate::check::types::Ty>)>>(prism_rtl::rc([=, inst_pd_1 = std::move(inst_pd_1)](std::tuple<Text, crate::check::types::Ty> p0) {
            return ({
                auto inst_pd_1_2 = inst_pd_1;
                entered(once_job([=, inst_pd_1_2 = std::move(inst_pd_1_2)]() {
                return ({
                    auto&& _ft_po = p0;
                    auto&& ft_po = std::get<1>(_ft_po);
                    (prism_rtl::more(prism_rtl::rc(crate::check::types::schemes::SubstQ(inst_pd_1_2, ft_po))));
                });
            }));
            });
        })));
        })));
        return prism_rtl::deref(tg_p6).kind == Text::lit("Element")
            ? ({
            auto [rw_pq, st4_pr] = crate::check::types::recording::fresh_row(st3_p9, Array(std::vector{prism_rtl::deref(tg_p6).family}));
            auto et_pp = crate::check::types::Ty(crate::check::types::Ty::TyElem{crate::check::types::Rw{.fams = Array(std::vector{prism_rtl::deref(tg_p6).family}), .minus = Array<Text>{}, .tail = prism_rtl::deref(rw_pq).tail}, prism_rtl::rc(out_pb)});
            std::tuple{et_pp, crate::check::types::recording::note_ty(st4_pr, cspan_p5, crate::check::types::Ty(crate::check::types::Ty::TyFn{crate::check::types::Col(crate::check::types::Col::CBound{}), field_tys_pa, prism_rtl::rc(et_pp)}))};
        })
            : std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{prism_rtl::deref(tg_p6).kind, Array<crate::check::types::Ty>{}}), crate::check::types::recording::note_ty(st3_p9, cspan_p5, crate::check::types::Ty(crate::check::types::Ty::TyFn{crate::check::types::Col(crate::check::types::Col::CBound{}), field_tys_pa, prism_rtl::rc(crate::check::types::Ty(crate::check::types::Ty::TyCon{prism_rtl::deref(tg_p6).kind, Array<crate::check::types::Ty>{}}))}))};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> TagApp::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& name_p2 = this->name_p2;
    const auto& args_p3 = this->args_p3;
    const auto& span_p4 = this->span_p4;
    const auto& cspan_p5 = this->cspan_p5;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env_p0).g).tags, name_p2);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("unknown-name"), span_p4, prism_rtl::cat("no tag `", name_p2, "`"))})
        : prism_rtl::is_some(_m) ? ({
        auto&& tg_p6 = prism_rtl::some_of(_m);
        ({
        auto args_p3_1 = args_p3;
        auto cspan_p5_2 = cspan_p5;
        auto env_p0_3 = env_p0;
        auto name_p2_4 = name_p2;
        auto span_p4_5 = span_p4;
        auto st_p1_6 = st_p1;
        call_then(crate::check::types::schemes::start_instantiate_with(st_p1_6, crate::check::types::Scheme{.qs = prism_rtl::deref(tg_p6).qs, .plain_qs = Array<Text>{}, .rqs = prism_rtl::deref(tg_p6).rqs, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = prism_rtl::deref(tg_p6).bounds, .ty = tg_p6->out}, span_p4_5, Array<crate::check::types::Ty>{}), [=, args_p3_1 = std::move(args_p3_1), cspan_p5_2 = std::move(cspan_p5_2), env_p0_3 = std::move(env_p0_3), name_p2_4 = std::move(name_p2_4)](std::tuple<crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst> instantiate_with_23727) {
        return ({
            auto [out_pb, st1_pc, inst_pd] = instantiate_with_23727;
            call_value(fold_job(args_p3_1, st1_pc, ({
            auto tg_p6_7 = tg_p6;
            auto env_p0_3_8 = env_p0_3;
            auto name_p2_4_8 = name_p2_4;
            auto inst_pd_8 = inst_pd;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Arg>)>>(prism_rtl::rc([=, tg_p6_7 = std::move(tg_p6_7), env_p0_3_8 = std::move(env_p0_3_8), name_p2_4_8 = std::move(name_p2_4_8), inst_pd_8 = std::move(inst_pd_8)](std::tuple<crate::check::types::St, crate::syntax::Arg> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto tg_p6_7_9 = tg_p6_7;
                auto env_p0_3_8_9 = env_p0_3_8;
                auto name_p2_4_8_9 = name_p2_4_8;
                auto inst_pd_8_9 = inst_pd_8;
                entered(once_job([=, tg_p6_7_9 = std::move(tg_p6_7_9), env_p0_3_8_9 = std::move(env_p0_3_8_9), name_p2_4_8_9 = std::move(name_p2_4_8_9), inst_pd_8_9 = std::move(inst_pd_8_9)]() {
                return ({
                    auto s_pe = p0;
                    auto a_pf = p1;
                    ({
                    auto&& _m = prism_rtl::deref(a_pf).name;
                    prism_rtl::is_some(_m) ? ({
                    auto&& id_pg = prism_rtl::some_of(_m);
                    ({
                    auto&& _m = field_of_tag(tg_p6_7_9, prism_rtl::deref(id_pg).name);
                    prism_rtl::is_some(_m) ? ({
                    auto&& ft_ph = prism_rtl::some_of(_m);
                    ({
                    auto id_pg_9 = id_pg;
                    call_then(crate::check::types::schemes::start_subst_q(inst_pd_8_9, ft_ph), [=, id_pg_9 = std::move(id_pg_9)](crate::check::types::Ty subst_q_24017) { return prism_rtl::more(prism_rtl::rc(TagField(env_p0_3_8_9, s_pe, name_p2_4_8_9, prism_rtl::deref(id_pg_9).name, subst_q_24017, a_pf))); });
                });
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::check::types::recording::err(s_pe, Text::lit("mismatch"), prism_rtl::deref(a_pf).span, prism_rtl::cat("`", name_p2_4_8_9, "` has no field `", prism_rtl::deref(id_pg).name, "`")))
                    : throw prism_rtl::Panic("no arm matched");
                });
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::check::types::recording::err(s_pe, Text::lit("mismatch"), prism_rtl::deref(a_pf).span, prism_rtl::cat("a tag\'s fields are named: `", name_p2_4_8_9, "(field=...)`")))
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        })));
        })), [=](crate::check::types::St fold_23874) {
            return ({
                auto st2_p7 = fold_23874;
                auto missing_p8 = filter(prism_rtl::deref(tg_p6).fields, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
                    auto&& f_pi = std::get<0>(_p0);
                    return !fold(args_p3_1, false, [&](const bool& seen_pj, const crate::syntax::Arg& a_pk) { return prism_rtl::deref(seen_pj) || arg_named(a_pk, f_pi); });
                });
                auto st3_p9 = (len(missing_p8) > Nat(0u)) && (!fold(args_p3_1, false, [&](const bool& seen_pl, const crate::syntax::Arg& a_pm) { return prism_rtl::deref(seen_pl) || (prism_rtl::deref(prism_rtl::deref(a_pm->value).kind) == crate::syntax::ExprKind(crate::syntax::ExprKind::ERest{})); }))
                    ? crate::check::types::recording::err(st2_p7, Text::lit("mismatch"), span_p4_5, prism_rtl::cat("`", name_p2_4, "` needs ", crate::syntax::lexer::chars::join(each(missing_p8, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
                    auto&& f_pn = std::get<0>(_p0);
                    return prism_rtl::cat("`", f_pn, "`");
                }), Text::lit(", "))))
                    : st2_p7;
                call_value(each_job(prism_rtl::deref(tg_p6).fields, ({
                auto inst_pd_7 = inst_pd;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(std::tuple<Text, crate::check::types::Ty>)>>(prism_rtl::rc([=, inst_pd_7 = std::move(inst_pd_7)](std::tuple<Text, crate::check::types::Ty> p0) {
                return ({
                    auto inst_pd_7_8 = inst_pd_7;
                    entered(once_job([=, inst_pd_7_8 = std::move(inst_pd_7_8)]() {
                    return ({
                        auto&& _ft_po = p0;
                        auto&& ft_po = std::get<1>(_ft_po);
                        (prism_rtl::more(prism_rtl::rc(crate::check::types::schemes::SubstQ(inst_pd_7_8, ft_po))));
                    });
                }));
                });
            })));
            })), [=, st3_p9 = std::move(st3_p9)](Array<crate::check::types::Ty> each_24569) {
                return ({
                    auto field_tys_pa = each_24569;
                    (prism_rtl::deref(tg_p6).kind == Text::lit("Element")
                    ? ({
                    auto [rw_pq, st4_pr] = crate::check::types::recording::fresh_row(st3_p9, Array(std::vector{prism_rtl::deref(tg_p6).family}));
                    auto et_pp = crate::check::types::Ty(crate::check::types::Ty::TyElem{crate::check::types::Rw{.fams = Array(std::vector{prism_rtl::deref(tg_p6).family}), .minus = Array<Text>{}, .tail = prism_rtl::deref(rw_pq).tail}, prism_rtl::rc(out_pb)});
                    (prism_rtl::finished(std::tuple{et_pp, crate::check::types::recording::note_ty(st4_pr, cspan_p5_2, crate::check::types::Ty(crate::check::types::Ty::TyFn{crate::check::types::Col(crate::check::types::Col::CBound{}), field_tys_pa, prism_rtl::rc(et_pp)}))}));
                })
                    : prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{prism_rtl::deref(tg_p6).kind, Array<crate::check::types::Ty>{}}), crate::check::types::recording::note_ty(st3_p9, cspan_p5_2, crate::check::types::Ty(crate::check::types::Ty::TyFn{crate::check::types::Col(crate::check::types::Col::CBound{}), field_tys_pa, prism_rtl::rc(crate::check::types::Ty(crate::check::types::Ty::TyCon{prism_rtl::deref(tg_p6).kind, Array<crate::check::types::Ty>{}}))}))}));
                });
            });
            });
        });
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TagApp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_tag_app(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text name_p2, Array<crate::syntax::Arg> args_p3, crate::syntax::Range span_p4, crate::syntax::Range cspan_p5) {
    return prism_rtl::make_rc<TagApp>(env_p0, st_p1, name_p2, args_p3, span_p4, cspan_p5);
}


/// ?FieldOfTag: fn TagInfo, Text -> ?Ty
std::optional<crate::check::types::Ty> field_of_tag(const crate::check::env::TagInfo& tg_p0, const Text& f_p1) {
    return fold(tg_p0.fields, std::optional<crate::check::types::Ty>{}, [&](const std::optional<crate::check::types::Ty>& found_o2, const std::tuple<Text, crate::check::types::Ty>& _p1) {
        auto&& n_p3 = std::get<0>(_p1);
        auto&& t_p4 = std::get<1>(_p1);
        return ({
            __label__ _done;
            prism_rtl::Slot<std::optional<crate::check::types::Ty>> _v;
            if (prism_rtl::is_some(found_o2)) {
                auto&& x_p5 = prism_rtl::some_of(found_o2);
                _v.set(std::optional(x_p5));
                goto _done;
            }
            if (prism_rtl::is_none(found_o2)) {
                _v.set(n_p3 == f_p1
                    ? std::optional(t_p4)
                    : std::optional<crate::check::types::Ty>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// TagField: unbounded fn Env, St, Text, Text, Ty, Arg -> St
crate::check::types::St tag_field(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Text& tag_name_p2, const Text& field_p3, const crate::check::types::Ty& ft_p4, const crate::syntax::Arg& a_p5) {
    return crate::check::types::head_sigil(st_p1, ft_p4) != Text::lit("")
        ? crate::check::expr::check(env_p0, st_p1, a_p5.value, ft_p4)
        : ({
        auto [at_p7, st2_p8] = crate::check::expr::infer(env_p0, st_p1, a_p5.value);
        auto head_p6 = crate::check::types::head_sigil(st2_p8, at_p7);
        head_p6 == Text::lit("$")
        ? crate::check::types::recording::err_fix(st2_p8, Text::lit("identity-dynamic"), prism_rtl::deref(a_p5.value).span, prism_rtl::cat("a dynamic in the identity field `", field_p3, "`"), prism_rtl::cat("for a new element per value, write `rebuild ", crate::check::expr::src_text(env_p0, prism_rtl::deref(a_p5.value).span), ":` with `", tag_name_p2, "(", field_p3, "=_, ...)` inside"))
        : head_p6 == Text::lit("!")
        ? crate::check::types::recording::err(st2_p8, Text::lit("two-events"), prism_rtl::deref(a_p5.value).span, prism_rtl::cat("an event in the plain field `", field_p3, "`"))
        : crate::check::types::unify::unify(st2_p8, ft_p4, at_p7, prism_rtl::deref(a_p5.value).span);
    });
}


prism_rtl::Turn<crate::check::types::St> TagField::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& tag_name_p2 = this->tag_name_p2;
    const auto& field_p3 = this->field_p3;
    const auto& ft_p4 = this->ft_p4;
    const auto& a_p5 = this->a_p5;
    auto a_p5_1 = a_p5;
    auto env_p0_2 = env_p0;
    auto field_p3_3 = field_p3;
    auto ft_p4_4 = ft_p4;
    auto st_p1_5 = st_p1;
    auto tag_name_p2_6 = tag_name_p2;
    return call_then(crate::check::types::start_head_sigil(st_p1_5, ft_p4_4), [=](Text head_sigil_25385) {
        return head_sigil_25385 != Text::lit("")
            ? prism_rtl::more(prism_rtl::rc(crate::check::expr::Check(env_p0_2, st_p1_5, a_p5_1->value, ft_p4_4)))
            : call_then(crate::check::expr::start_infer(env_p0_2, st_p1_5, a_p5_1->value), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_25473) {
            return ({
                auto [at_p7, st2_p8] = infer_25473;
                call_then(crate::check::types::start_head_sigil(st2_p8, at_p7), [=](Text head_sigil_25515) {
                return ({
                    auto head_p6 = head_sigil_25515;
                    head_p6 == Text::lit("$")
                    ? prism_rtl::finished(crate::check::types::recording::err_fix(st2_p8, Text::lit("identity-dynamic"), prism_rtl::deref(a_p5_1->value).span, prism_rtl::cat("a dynamic in the identity field `", field_p3_3, "`"), prism_rtl::cat("for a new element per value, write `rebuild ", crate::check::expr::src_text(env_p0_2, prism_rtl::deref(a_p5_1->value).span), ":` with `", tag_name_p2_6, "(", field_p3_3, "=_, ...)` inside")))
                    : head_p6 == Text::lit("!")
                    ? prism_rtl::finished(crate::check::types::recording::err(st2_p8, Text::lit("two-events"), prism_rtl::deref(a_p5_1->value).span, prism_rtl::cat("an event in the plain field `", field_p3_3, "`")))
                    : prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st2_p8, ft_p4_4, at_p7, prism_rtl::deref(a_p5_1->value).span)));
                });
            });
            });
        });
    });
}


/// `Start TagField, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_tag_field(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text tag_name_p2, Text field_p3, crate::check::types::Ty ft_p4, crate::syntax::Arg a_p5) {
    return prism_rtl::make_rc<TagField>(env_p0, st_p1, tag_name_p2, field_p3, ft_p4, a_p5);
}


/// LambdaArity: fn Expr -> Nat
Nat lambda_arity(const crate::syntax::Expr& e_p0) {
    auto&& _m = prism_rtl::deref(e_p0.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0)) {
        auto&& ps_p1 = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0);
        return len(ps_p1);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p2 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return lambda_arity(prism_rtl::deref(prism_rtl::deref(x_p2)));
    }
    {
        return Nat(2u);
    }
}


/// InferLambda: unbounded fn Env, St, Expr, ?Ty -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_lambda(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& e_p2, const std::optional<crate::check::types::Ty>& expected_o3) {
    auto&& _m = prism_rtl::deref(e_p2.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p4 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        auto [t_p5, st2_p6] = infer_lambda(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(x_p4)), expected_o3);
        return std::tuple{t_p5, crate::check::types::recording::note_ty(st2_p6, prism_rtl::deref(x_p4).span, t_p5)};
    }
    {
        return infer_bare_lambda(env_p0, st_p1, e_p2, expected_o3);
    }
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferLambda::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& e_p2 = this->e_p2;
    const auto& expected_o3 = this->expected_o3;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p2).kind);
        prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x_p4 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        ({
        auto expected_o3_1 = expected_o3;
        auto env_p0_2 = env_p0;
        auto st_p1_3 = st_p1;
        auto x_p4_4 = prism_rtl::deref(prism_rtl::deref(x_p4));
        call_then(start_infer_lambda(env_p0_2, st_p1_3, x_p4_4, expected_o3_1), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_lambda_26901) {
        return ({
            auto [t_p5, st2_p6] = infer_lambda_26901;
            (prism_rtl::finished(std::tuple{t_p5, crate::check::types::recording::note_ty(st2_p6, prism_rtl::deref(x_p4_4).span, t_p5)}));
        });
    });
    });
    })
        : prism_rtl::more(prism_rtl::rc(InferBareLambda(env_p0, st_p1, e_p2, expected_o3)));
    });
}


/// `Start InferLambda, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_lambda(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr e_p2, std::optional<crate::check::types::Ty> expected_o3) {
    return prism_rtl::make_rc<InferLambda>(env_p0, st_p1, e_p2, expected_o3);
}


/// InferBareLambda: unbounded fn Env, St, Expr, ?Ty -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_bare_lambda(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& e_p2, const std::optional<crate::check::types::Ty>& expected_o3) {
    auto [params_pg, body_ph] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::syntax::Pattern_>, crate::syntax::LambdaBody>> _v;
        auto&& _m = prism_rtl::deref(e_p2.kind);
        if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0)) {
            auto&& ps_pb = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0);
            auto&& b_pc = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
            _v.set(std::tuple{ps_pb, prism_rtl::deref(prism_rtl::deref(b_pc))});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0)) {
            auto&& b_pd = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
            _v.set(std::tuple{Array(std::vector{topic_pat(e_p2.span)}), prism_rtl::deref(prism_rtl::deref(b_pd))});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ETopicField>(_m)) {
            auto&& f_pe = prism_rtl::as<crate::syntax::ExprKind::ETopicField>(_m).a0;
            _v.set(std::tuple{Array(std::vector{topic_pat(e_p2.span)}), crate::syntax::LambdaBody(crate::syntax::LambdaBody::LbExpr{prism_rtl::rc(topic_field_expr(e_p2.span, f_pe))})});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ETopicIndex>(_m)) {
            auto&& x_pf = prism_rtl::as<crate::syntax::ExprKind::ETopicIndex>(_m).a0;
            _v.set(std::tuple{Array(std::vector{topic_pat(e_p2.span)}), crate::syntax::LambdaBody(crate::syntax::LambdaBody::LbExpr{prism_rtl::rc(topic_index_expr(e_p2.span, prism_rtl::deref(prism_rtl::deref(x_pf))))})});
            goto _done;
        }
        {
            _v.set(std::tuple{Array<crate::syntax::Pattern_>{}, crate::syntax::LambdaBody(crate::syntax::LambdaBody::LbExpr{prism_rtl::rc(e_p2)})});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [exp_params_pl, exp_res_om, st0_pn] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::check::types::Ty>, std::optional<crate::check::types::Ty>, crate::check::types::St>> _v;
        if (prism_rtl::is_some(expected_o3)) {
            auto&& t_pi = prism_rtl::some_of(expected_o3);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<crate::check::types::Ty>, std::optional<crate::check::types::Ty>, crate::check::types::St>> _v;
                auto&& _m = crate::check::types::recording::walk(st_p1, t_pi);
                if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
                    auto&& ps_pj = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
                    auto&& r_pk = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
                    _v.set(len(ps_pj) == len(params_pg)
                        ? std::tuple{ps_pj, std::optional(prism_rtl::deref(r_pk)), st_p1}
                        : std::tuple{Array<crate::check::types::Ty>{}, std::optional<crate::check::types::Ty>{}, crate::check::types::recording::err(st_p1, Text::lit("mismatch"), e_p2.span, prism_rtl::cat("this lambda takes ", crate::check::errors::count_word(len(params_pg)), " parameter", len(params_pg) == Nat(1u) ? Text::lit("") : Text::lit("s"), "; here ", crate::check::errors::count_word(len(ps_pj)), " ", len(ps_pj) == Nat(1u) ? Text::lit("is") : Text::lit("are"), " wanted"))});
                    goto _done;
                }
                {
                    _v.set(std::tuple{Array<crate::check::types::Ty>{}, std::optional<crate::check::types::Ty>{}, st_p1});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(expected_o3)) {
            _v.set(std::tuple{Array<crate::check::types::Ty>{}, std::optional<crate::check::types::Ty>{}, st_p1});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto [env2_p12, ptys_p13, st1_p14] = run_to_end(fold_job(crate::check::errors::range0(len(params_pg)), std::tuple{env_p0, Array<crate::check::types::Ty>{}, st0_pn}, ({
        auto params_pg_1 = params_pg;
        auto e_p2_2 = e_p2;
        auto exp_params_pl_3 = exp_params_pl;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, Array<crate::check::types::Ty>, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, Array<crate::check::types::Ty>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, params_pg_1 = std::move(params_pg_1), e_p2_2 = std::move(e_p2_2), exp_params_pl_3 = std::move(exp_params_pl_3)](std::tuple<std::tuple<crate::check::expr::Env, Array<crate::check::types::Ty>, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto params_pg_1_4 = params_pg_1;
            auto e_p2_2_4 = e_p2_2;
            auto exp_params_pl_3_4 = exp_params_pl_3;
            entered(once_job([=, params_pg_1_4 = std::move(params_pg_1_4), e_p2_2_4 = std::move(e_p2_2_4), exp_params_pl_3_4 = std::move(exp_params_pl_3_4)]() {
            return ({
                auto [en_po, acc_pp, s_pq] = p0;
                auto i_pr = p1;
                ({
                auto p_ps = or_(index(params_pg_1_4, i_pr), crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span = e_p2_2_4.span});
                auto [pt_pu, s2_pv] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                    auto&& _m = index(exp_params_pl_3_4, i_pr);
                    if (prism_rtl::is_some(_m)) {
                        auto&& t_pt = prism_rtl::some_of(_m);
                        _v.set(std::tuple{t_pt, s_pq});
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(crate::check::types::fresh_var(s_pq, true, Text::lit("")));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                call_then(crate::check::expr::patterns::start_bind_pattern(crate::check::expr::lets::unpend(en_po), s2_pv, p_ps, pt_pu, false), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> bind_pattern_28243) {
                return ({
                    auto [en2_p10, s3_p11] = bind_pattern_28243;
                    (prism_rtl::finished(std::tuple{en2_p10, crate::prelude::push(acc_pp, pt_pu), s3_p11}));
                });
            });
            });
            });
        }));
        });
    }));
    })));
    auto outer_color_p4 = prism_rtl::deref(st1_p14).color;
    auto outer_why_p5 = prism_rtl::deref(st1_p14).color_why;
    auto outer_flex_p6 = prism_rtl::deref(st1_p14).color_flex;
    auto [lcol_p15, st1b_p16] = crate::check::types::fresh_col(st1_p14);
    auto st2_p7 = ({
        crate::check::types::St this_ = st1b_p16;
        this_.color = crate::check::types::Col(crate::check::types::Col::CBound{});
        this_.color_why = Text::lit("");
        this_.color_flex = Array<std::tuple<crate::check::types::Col, Text, crate::syntax::Range>>{};
        (std::move(this_));
    });
    auto [rt_p1b, st3_p1c] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
        if (prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(body_ph)) {
            auto&& x_p17 = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(body_ph).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                if (prism_rtl::is_some(exp_res_om)) {
                    auto&& r_p18 = prism_rtl::some_of(exp_res_om);
                    _v.set(({
                        auto s4_p19 = crate::check::expr::check(env2_p12, st2_p7, prism_rtl::deref(prism_rtl::deref(x_p17)), r_p18);
                        std::tuple{r_p18, s4_p19};
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(exp_res_om)) {
                    _v.set(crate::check::expr::infer(env2_p12, st2_p7, prism_rtl::deref(prism_rtl::deref(x_p17))));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(body_ph)) {
            auto&& b_p1a = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(body_ph).a0;
            _v.set(infer_body_block(env2_p12, st2_p7, b_p1a, exp_res_om));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st3b_p8 = crate::check::types::colors::settle_body(st3_p1c, lcol_p15, Text::lit(""));
    auto st3c_p9 = crate::check::types::colors::add_leq(st3b_p8, prism_rtl::deref(st3b_p8).color, lcol_p15, e_p2.span, Text::lit("lambda"), Text::lit(""), prism_rtl::deref(st3b_p8).color_why);
    auto st4_pa = ({
        crate::check::types::St this_ = st3c_p9;
        this_.color = outer_color_p4;
        this_.color_why = outer_why_p5;
        this_.color_flex = outer_flex_p6;
        (std::move(this_));
    });
    return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyFn{lcol_p15, ptys_p13, prism_rtl::rc(rt_p1b)}), crate::check::types::recording::note_fn(st4_pa, e_p2.span, Text::lit("lambda"), lcol_p15, lcol_p15)};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferBareLambda::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& e_p2 = this->e_p2;
    const auto& expected_o3 = this->expected_o3;
    auto [params_pg, body_ph] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::syntax::Pattern_>, crate::syntax::LambdaBody>> _v;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p2).kind);
        if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0)) {
            auto&& ps_pb = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0);
            auto&& b_pc = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
            _v.set(std::tuple{ps_pb, prism_rtl::deref(prism_rtl::deref(b_pc))});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0)) {
            auto&& b_pd = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
            _v.set(std::tuple{Array(std::vector{topic_pat(prism_rtl::deref(e_p2).span)}), prism_rtl::deref(prism_rtl::deref(b_pd))});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ETopicField>(_m)) {
            auto&& f_pe = prism_rtl::as<crate::syntax::ExprKind::ETopicField>(_m).a0;
            _v.set(std::tuple{Array(std::vector{topic_pat(prism_rtl::deref(e_p2).span)}), crate::syntax::LambdaBody(crate::syntax::LambdaBody::LbExpr{prism_rtl::rc(topic_field_expr(prism_rtl::deref(e_p2).span, f_pe))})});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ETopicIndex>(_m)) {
            auto&& x_pf = prism_rtl::as<crate::syntax::ExprKind::ETopicIndex>(_m).a0;
            _v.set(std::tuple{Array(std::vector{topic_pat(prism_rtl::deref(e_p2).span)}), crate::syntax::LambdaBody(crate::syntax::LambdaBody::LbExpr{prism_rtl::rc(topic_index_expr(prism_rtl::deref(e_p2).span, prism_rtl::deref(prism_rtl::deref(x_pf))))})});
            goto _done;
        }
        {
            _v.set(std::tuple{Array<crate::syntax::Pattern_>{}, crate::syntax::LambdaBody(crate::syntax::LambdaBody::LbExpr{prism_rtl::rc(e_p2)})});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [exp_params_pl, exp_res_om, st0_pn] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::check::types::Ty>, std::optional<crate::check::types::Ty>, crate::check::types::St>> _v;
        if (prism_rtl::is_some(expected_o3)) {
            auto&& t_pi = prism_rtl::some_of(expected_o3);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<crate::check::types::Ty>, std::optional<crate::check::types::Ty>, crate::check::types::St>> _v;
                auto&& _m = crate::check::types::recording::walk(st_p1, t_pi);
                if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
                    auto&& ps_pj = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
                    auto&& r_pk = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
                    _v.set(len(ps_pj) == len(params_pg)
                        ? std::tuple{ps_pj, std::optional(prism_rtl::deref(r_pk)), st_p1}
                        : std::tuple{Array<crate::check::types::Ty>{}, std::optional<crate::check::types::Ty>{}, crate::check::types::recording::err(st_p1, Text::lit("mismatch"), prism_rtl::deref(e_p2).span, prism_rtl::cat("this lambda takes ", crate::check::errors::count_word(len(params_pg)), " parameter", len(params_pg) == Nat(1u) ? Text::lit("") : Text::lit("s"), "; here ", crate::check::errors::count_word(len(ps_pj)), " ", len(ps_pj) == Nat(1u) ? Text::lit("is") : Text::lit("are"), " wanted"))});
                    goto _done;
                }
                {
                    _v.set(std::tuple{Array<crate::check::types::Ty>{}, std::optional<crate::check::types::Ty>{}, st_p1});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(expected_o3)) {
            _v.set(std::tuple{Array<crate::check::types::Ty>{}, std::optional<crate::check::types::Ty>{}, st_p1});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto e_p2_1 = e_p2;
    auto env_p0_2 = env_p0;
    return call_value(fold_job(crate::check::errors::range0(len(params_pg)), std::tuple{env_p0_2, Array<crate::check::types::Ty>{}, st0_pn}, ({
        auto params_pg_3 = params_pg;
        auto e_p2_1_4 = e_p2_1;
        auto exp_params_pl_4 = exp_params_pl;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, Array<crate::check::types::Ty>, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, Array<crate::check::types::Ty>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, params_pg_3 = std::move(params_pg_3), e_p2_1_4 = std::move(e_p2_1_4), exp_params_pl_4 = std::move(exp_params_pl_4)](std::tuple<std::tuple<crate::check::expr::Env, Array<crate::check::types::Ty>, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto params_pg_3_5 = params_pg_3;
            auto e_p2_1_4_5 = e_p2_1_4;
            auto exp_params_pl_4_5 = exp_params_pl_4;
            entered(once_job([=, params_pg_3_5 = std::move(params_pg_3_5), e_p2_1_4_5 = std::move(e_p2_1_4_5), exp_params_pl_4_5 = std::move(exp_params_pl_4_5)]() {
            return ({
                auto [en_po, acc_pp, s_pq] = p0;
                auto i_pr = p1;
                ({
                auto p_ps = or_(index(params_pg_3_5, i_pr), crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span = prism_rtl::deref(e_p2_1_4_5).span});
                auto [pt_pu, s2_pv] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                    auto&& _m = index(exp_params_pl_4_5, i_pr);
                    if (prism_rtl::is_some(_m)) {
                        auto&& t_pt = prism_rtl::some_of(_m);
                        _v.set(std::tuple{t_pt, s_pq});
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(crate::check::types::fresh_var(s_pq, true, Text::lit("")));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                call_then(crate::check::expr::patterns::start_bind_pattern(crate::check::expr::lets::unpend(en_po), s2_pv, p_ps, pt_pu, false), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> bind_pattern_28243) {
                return ({
                    auto [en2_p10, s3_p11] = bind_pattern_28243;
                    (prism_rtl::finished(std::tuple{en2_p10, crate::prelude::push(acc_pp, pt_pu), s3_p11}));
                });
            });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<crate::check::expr::Env, Array<crate::check::types::Ty>, crate::check::types::St> fold_27974) {
        return ({
            auto [env2_p12, ptys_p13, st1_p14] = fold_27974;
            auto outer_color_p4 = prism_rtl::deref(st1_p14).color;
            auto outer_why_p5 = prism_rtl::deref(st1_p14).color_why;
            auto outer_flex_p6 = prism_rtl::deref(st1_p14).color_flex;
            auto [lcol_p15, st1b_p16] = crate::check::types::fresh_col(st1_p14);
            auto st2_p7 = ({
                crate::check::types::St this_ = st1b_p16;
                this_.color = crate::check::types::Col(crate::check::types::Col::CBound{});
                this_.color_why = Text::lit("");
                this_.color_flex = Array<std::tuple<crate::check::types::Col, Text, crate::syntax::Range>>{};
                (std::move(this_));
            });
            auto [rt_p1b, st3_p1c] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                if (prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(body_ph)) {
                    auto&& x_p17 = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(body_ph).a0;
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                        if (prism_rtl::is_some(exp_res_om)) {
                            auto&& r_p18 = prism_rtl::some_of(exp_res_om);
                            _v.set(({
                                auto s4_p19 = crate::check::expr::check(env2_p12, st2_p7, prism_rtl::deref(prism_rtl::deref(x_p17)), r_p18);
                                std::tuple{r_p18, s4_p19};
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_none(exp_res_om)) {
                            _v.set(crate::check::expr::infer(env2_p12, st2_p7, prism_rtl::deref(prism_rtl::deref(x_p17))));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(body_ph)) {
                    auto&& b_p1a = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(body_ph).a0;
                    _v.set(infer_body_block(env2_p12, st2_p7, b_p1a, exp_res_om));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            call_then(crate::check::types::colors::start_settle_body(st3_p1c, lcol_p15, Text::lit("")), [=, outer_color_p4 = std::move(outer_color_p4), outer_why_p5 = std::move(outer_why_p5), outer_flex_p6 = std::move(outer_flex_p6)](crate::check::types::St settle_body_28829) {
            return ({
                auto st3b_p8 = settle_body_28829;
                call_then(crate::check::types::colors::start_add_leq(st3b_p8, prism_rtl::deref(st3b_p8).color, lcol_p15, prism_rtl::deref(e_p2_1).span, Text::lit("lambda"), Text::lit(""), prism_rtl::deref(st3b_p8).color_why), [=](crate::check::types::St add_leq_28869) {
                return ({
                    auto st3c_p9 = add_leq_28869;
                    auto st4_pa = ({
                        crate::check::types::St this_ = st3c_p9;
                        this_.color = outer_color_p4;
                        this_.color_why = outer_why_p5;
                        this_.color_flex = outer_flex_p6;
                        (std::move(this_));
                    });
                    (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyFn{lcol_p15, ptys_p13, prism_rtl::rc(rt_p1b)}), crate::check::types::recording::note_fn(st4_pa, prism_rtl::deref(e_p2_1).span, Text::lit("lambda"), lcol_p15, lcol_p15)}));
                });
            });
            });
        });
        });
    });
}


/// `Start InferBareLambda, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_bare_lambda(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr e_p2, std::optional<crate::check::types::Ty> expected_o3) {
    return prism_rtl::make_rc<InferBareLambda>(env_p0, st_p1, e_p2, expected_o3);
}


/// TopicPat: fn Range -> Pattern
crate::syntax::Pattern_ topic_pat(const crate::syntax::Range& span_p0) {
    return crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PName{topic_sname(span_p0)})), .span = span_p0};
}


/// TopicSName: fn Range -> SName
crate::syntax::SName topic_sname(const crate::syntax::Range& span_p0) {
    return crate::syntax::SName{.sigils = Text::lit(""), .path_ = Array(std::vector{Text::lit("_")}), .span = span_p0};
}


/// TopicExpr: fn Range -> Expr
crate::syntax::Expr topic_expr(const crate::syntax::Range& span_p0) {
    return crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{topic_sname(span_p0)})), .span = span_p0};
}


/// TopicFieldExpr: fn Range, Ident -> Expr
crate::syntax::Expr topic_field_expr(const crate::syntax::Range& span_p0, const crate::syntax::Ident& f_p1) {
    return crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EField{prism_rtl::rc(topic_expr(span_p0)), Text::lit(""), f_p1})), .span = span_p0};
}


/// TopicIndexExpr: fn Range, Expr -> Expr
crate::syntax::Expr topic_index_expr(const crate::syntax::Range& span_p0, const crate::syntax::Expr& x_p1) {
    return crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EIndex{prism_rtl::rc(topic_expr(span_p0)), prism_rtl::rc(x_p1)})), .span = span_p0};
}


/// ArgNamed: fn Arg, Text -> Bool
bool arg_named(const crate::syntax::Arg& a_p0, const Text& f_p1) {
    auto&& _m = a_p0.name;
    if (prism_rtl::is_some(_m)) {
        auto&& id_p2 = prism_rtl::some_of(_m);
        return prism_rtl::deref(id_p2).name == f_p1;
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// InferBodyBlock: unbounded fn Env, St, Block, ?Ty -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_body_block(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Block& b_p2, const std::optional<crate::check::types::Ty>& expected_o3) {
    auto [t_p4, st2_p5] = crate::check::expr::lets::infer_expr_block(env_p0, st_p1, b_p2);
    if (prism_rtl::is_some(expected_o3)) {
        auto&& r_p6 = prism_rtl::some_of(expected_o3);
        return std::tuple{r_p6, crate::check::types::unify::unify(st2_p5, r_p6, t_p4, b_p2.span)};
    }
    if (prism_rtl::is_none(expected_o3)) {
        return std::tuple{t_p4, st2_p5};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferBodyBlock::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& b_p2 = this->b_p2;
    const auto& expected_o3 = this->expected_o3;
    auto expected_o3_1 = expected_o3;
    auto b_p2_2 = b_p2;
    auto env_p0_3 = env_p0;
    auto st_p1_4 = st_p1;
    return call_then(crate::check::expr::lets::start_infer_expr_block(env_p0_3, st_p1_4, b_p2_2), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_expr_block_30124) {
        return ({
            auto [t_p4, st2_p5] = infer_expr_block_30124;
            ({
            prism_rtl::is_some(expected_o3_1) ? ({
            auto&& r_p6 = prism_rtl::some_of(expected_o3_1);
            ({
            auto r_p6_5 = r_p6;
            call_then(crate::check::types::unify::start_unify(st2_p5, r_p6_5, t_p4, prism_rtl::deref(b_p2_2).span), [=](crate::check::types::St unify_30190) { return prism_rtl::finished(std::tuple{r_p6_5, unify_30190}); });
        });
        })
            : prism_rtl::is_none(expected_o3_1) ? prism_rtl::finished(std::tuple{t_p4, st2_p5})
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
}


/// `Start InferBodyBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_body_block(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Block b_p2, std::optional<crate::check::types::Ty> expected_o3) {
    return prism_rtl::make_rc<InferBodyBlock>(env_p0, st_p1, b_p2, expected_o3);
}

}  // namespace crate::check::expr::calls
