// The module `Check.Expr.Calls`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/expr/calls/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Check.Expr.Calls`, from `target/bootstrap/cpp-src/prismc/check/expr/calls.prism`.
namespace crate::check::expr::calls {

bool Peeled::operator==(const Peeled& o) const { return events_p == o.events_p && dyns_p == o.dyns_p && opts_p == o.opts_p && opt_args_p == o.opt_args_p && lifted_p == o.lifted_p && broken_p == o.broken_p; }

void Peeled::show(Printer& p) const {
    p.record("Peeled", {{"events", events_p}, {"dyns", dyns_p}, {"opts", opts_p}, {"optArgs", opt_args_p}, {"lifted", lifted_p}, {"broken", broken_p}});
}

Pod Peeled::to_pod() const {
    return Pod::record("Peeled", {{"events", prism_rtl::to_pod(events_p)}, {"dyns", prism_rtl::to_pod(dyns_p)}, {"opts", prism_rtl::to_pod(opts_p)}, {"optArgs", prism_rtl::to_pod(opt_args_p)}, {"lifted", prism_rtl::to_pod(lifted_p)}, {"broken", prism_rtl::to_pod(broken_p)}});
}

Result<Peeled> Peeled::from_pod(const Pod& whole) {
    return Peeled{.events_p = TRY(prism_rtl::from_pod<Array<crate::syntax::Range>>(TRY(crate::prelude::field(whole, "events")))), .dyns_p = TRY(prism_rtl::from_pod<Array<crate::syntax::Range>>(TRY(crate::prelude::field(whole, "dyns")))), .opts_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "opts")))), .opt_args_p = TRY(prism_rtl::from_pod<Array<crate::syntax::Range>>(TRY(crate::prelude::field(whole, "optArgs")))), .lifted_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "lifted")))), .broken_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "broken"))))};
}


/// InferCall: unbounded fn Env, St, Expr, [Arg], Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_call_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& callee_p2, const Array<crate::syntax::Arg>& args_p3, const crate::syntax::Range& span_p4) {
    auto&& _m = prism_rtl::deref(callee_p2.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p5 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        auto local_p6 = crate::check::env::sname_key_f(n_p5);
        auto&& _m = crate::prelude::get(env_p0.locals_p, local_p6);
        if (prism_rtl::is_some(_m)) {
            auto&& sc_p7 = prism_rtl::some_of(_m);
            auto [t_p8, st2_p9] = crate::check::expr::instantiate_local_f(st_p1, sc_p7, callee_p2.span_p, local_p6);
            return apply_fn_f(env_p0, crate::check::types::recording::note_ty_f(st2_p9, callee_p2.span_p, t_p8), local_p6, t_p8, positional_f(args_p3), span_p4);
        }
        if (prism_rtl::is_none(_m)) {
            return call_global_f(env_p0, st_p1, n_p5, args_p3, span_p4, Array<crate::check::types::Ty>{}, callee_p2.span_p);
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m)) {
        auto&& target_pa = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
        auto&& tys_pb = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a1;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(target_pa).kind_p);
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n_pc = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            auto cx_pd = crate::check::expr::env_cx_f(env_p0);
            auto [given2_pe, st2_pf] = crate::check::env::reading::conv_types_f(cx_pd, st_p1, tys_pb);
            return call_global_f(env_p0, st2_pf, n_pc, args_p3, span_p4, given2_pe, callee_p2.span_p);
        }
        {
            return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("mismatch"), callee_p2.span_p, Text::lit("`<<T>>` applies to a function\'s name"))};
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_pg = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return infer_call_f(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(x_pg)), args_p3, span_p4);
    }
    {
        auto [t_ph, st2_pi] = crate::check::expr::infer_f(env_p0, st_p1, callee_p2);
        return apply_fn_f(env_p0, st2_pi, crate::check::expr::src_text_f(env_p0, callee_p2.span_p), t_ph, positional_f(args_p3), span_p4);
    }
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferCall::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& callee_p2 = this->callee_p2;
    const auto& args_p3 = this->args_p3;
    const auto& span_p4 = this->span_p4;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(callee_p2).kind_p);
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n_p5 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        ({
        auto local_p6 = crate::check::env::sname_key_f(n_p5);
        ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0).locals_p, local_p6);
        prism_rtl::is_some(_m) ? ({
        auto&& sc_p7 = prism_rtl::some_of(_m);
        ({
        auto args_p3x = args_p3;
        auto callee_p2x = callee_p2;
        auto env_p0x = env_p0;
        auto span_p4x = span_p4;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(crate::check::expr::start_instantiate_local_f(st_p1x, sc_p7, prism_rtl::deref(callee_p2x).span_p, local_p6), [=, args_p3x = std::move(args_p3x), env_p0x = std::move(env_p0x), span_p4x = std::move(span_p4x)](std::tuple<crate::check::types::Ty, crate::check::types::St> instantiate_local_f_1491) {
        return ({
            auto [t_p8, st2_p9] = instantiate_local_f_1491;
            (prism_rtl::more(prism_rtl::rc(ApplyFn(env_p0x, crate::check::types::recording::note_ty_f(st2_p9, prism_rtl::deref(callee_p2x).span_p, t_p8), local_p6, t_p8, positional_f(args_p3x), span_p4x))));
        });
    }));
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(CallGlobal(env_p0, st_p1, n_p5, args_p3, span_p4, Array<crate::check::types::Ty>{}, prism_rtl::deref(callee_p2).span_p)))
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m) ? ({
        auto&& target_pa = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
        auto&& tys_pb = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a1;
        ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(target_pa).kind_p);
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n_pc = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        ({
        auto cx_pd = crate::check::expr::env_cx_f(env_p0);
        auto args_p3x = args_p3;
        auto callee_p2x = callee_p2;
        auto env_p0x = env_p0;
        auto n_pcx = n_pc;
        auto span_p4x = span_p4;
        auto st_p1x = st_p1;
        auto tys_pbx = tys_pb;
        (crate::prelude::call_then(crate::check::env::reading::start_conv_types_f(cx_pd, st_p1x, tys_pbx), [=, args_p3x = std::move(args_p3x), callee_p2x = std::move(callee_p2x), env_p0x = std::move(env_p0x), n_pcx = std::move(n_pcx), span_p4x = std::move(span_p4x)](std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> conv_types_f_1826) {
        return ({
            auto [given2_pe, st2_pf] = conv_types_f_1826;
            (prism_rtl::more(prism_rtl::rc(CallGlobal(env_p0x, st2_pf, n_pcx, args_p3x, span_p4x, given2_pe, prism_rtl::deref(callee_p2x).span_p))));
        });
    }));
    });
    })
        : prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("mismatch"), prism_rtl::deref(callee_p2).span_p, Text::lit("`<<T>>` applies to a function\'s name"))});
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x_pg = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(InferCall(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(x_pg)), args_p3, span_p4)));
    })
        : ({
        auto args_p3x = args_p3;
        auto callee_p2x = callee_p2;
        auto env_p0x = env_p0;
        auto span_p4x = span_p4;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x, st_p1x, callee_p2x), [=, args_p3x = std::move(args_p3x), span_p4x = std::move(span_p4x)](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_f_2107) {
        return ({
            auto [t_ph, st2_pi] = infer_f_2107;
            (prism_rtl::more(prism_rtl::rc(ApplyFn(env_p0x, st2_pi, crate::check::expr::src_text_f(env_p0x, prism_rtl::deref(callee_p2x).span_p), t_ph, positional_f(args_p3x), span_p4x))));
        });
    }));
    });
    });
}


/// `Start InferCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_call_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr callee_p2, Array<crate::syntax::Arg> args_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<InferCall>(env_p0, st_p1, callee_p2, args_p3, span_p4);
}


/// Positional: fn [Arg] -> [Arg]
Array<crate::syntax::Arg> positional_f(const Array<crate::syntax::Arg>& args_p0) {
    return args_p0;
}


/// CallGlobal: unbounded fn Env, St, SName, [Arg], Range, [Ty], Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> call_global_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st0_p1, const crate::syntax::SName& n_p2, const Array<crate::syntax::Arg>& args_p3, const crate::syntax::Range& span_p4, const Array<crate::check::types::Ty>& explicit_p5, const crate::syntax::Range& cspan_p6) {
    auto [qk_oa, why_pb] = crate::check::env::names::resolve_value_f(env_p0.g_p, env_p0.home_p, n_p2);
    auto name_p7 = crate::check::env::sname_key_f(n_p2);
    auto st1_p8 = crate::check::expr::collision_at_f(env_p0, st0_p1, why_pb, name_p7, n_p2.span_p);
    auto st_p9 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        if (prism_rtl::is_some(qk_oa)) {
            auto&& qk_pc = prism_rtl::some_of(qk_oa);
            _v.set(crate::check::types::recording::note_global_f(st1_p8, n_p2.span_p, qk_pc));
            goto _done;
        }
        if (prism_rtl::is_none(qk_oa)) {
            _v.set(st1_p8);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    if (prism_rtl::is_none(qk_oa)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p9, Text::lit("unknown-name"), n_p2.span_p, prism_rtl::cat("nothing declares `", name_p7, "` here"))};
    }
    if (prism_rtl::is_some(qk_oa)) {
        auto&& qk_pd = prism_rtl::some_of(qk_oa);
        return why_pb == Text::lit("tag")
            ? tag_app_f(env_p0, st_p9, qk_pd, args_p3, span_p4, cspan_p6)
            : is_local_maker_f(qk_pd) && (!env_p0.in_update_p)
            ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), local_outside_f(st_p9, qk_pd, span_p4)}
            : ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
            auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0.g_p).vals_p, qk_pd);
            if (prism_rtl::is_some(_m)) {
                auto&& v_pe = prism_rtl::some_of(_m);
                _v.set(({
                    auto [t_ph, st2i_pi, inst_pj] = crate::check::types::schemes::instantiate_with_f(st_p9, prism_rtl::deref(v_pe).scheme_p, span_p4, explicit_p5);
                    auto [rigids_pk, st2_pl] = rank_two_f(st2i_pi, prism_rtl::deref(v_pe).scheme_p, inst_pj, crate::prelude::len(explicit_p5), span_p4);
                    auto st3a_pf = note_callee_f(note_method_use_f(st2_pl, v_pe, span_p4), n_p2.span_p, cspan_p6, t_ph);
                    auto st3_pg = crate::check::types::bare_name_f(qk_pd) == Text::lit("Min")
                        ? crate::check::types::recording::note_size_ty_f(st3a_pf, span_p4, crate::check::types::recording::walk_f(st3a_pf, t_ph))
                        : st3a_pf;
                    (crate::check::types::bare_name_f(qk_pd) == Text::lit("Fold")) && (prism_rtl::deref(v_pe).home_p == Text::lit("Prelude"))
                    ? fold_app_f(env_p0, st3_pg, t_ph, args_p3, span_p4)
                    : ({
                    auto [rt_pm, st4_pn] = apply_fn_f(env_p0, st3_pg, name_p7, t_ph, args_p3, span_p4);
                    std::tuple{rt_pm, escaped_f(env_p0, st4_pn, rigids_pk, rt_pm, name_p7, span_p4)};
                });
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                    auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0.g_p).ctors_p, qk_pd);
                    if (prism_rtl::is_some(_m)) {
                        auto&& c_po = prism_rtl::some_of(_m);
                        _v.set(ctor_app_f(env_p0, st_p9, c_po, args_p3, span_p4, cspan_p6));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p9, Text::lit("unknown-name"), n_p2.span_p, prism_rtl::cat("`", name_p7, "` has no signature line"))});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> CallGlobal::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st0_p1 = this->st0_p1;
    const auto& n_p2 = this->n_p2;
    const auto& args_p3 = this->args_p3;
    const auto& span_p4 = this->span_p4;
    const auto& explicit_p5 = this->explicit_p5;
    const auto& cspan_p6 = this->cspan_p6;
    auto [qk_oa, why_pb] = crate::check::env::names::resolve_value_f(prism_rtl::deref(env_p0).g_p, prism_rtl::deref(env_p0).home_p, n_p2);
    auto name_p7 = crate::check::env::sname_key_f(n_p2);
    auto st1_p8 = crate::check::expr::collision_at_f(env_p0, st0_p1, why_pb, name_p7, prism_rtl::deref(n_p2).span_p);
    auto st_p9 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        if (prism_rtl::is_some(qk_oa)) {
            auto&& qk_pc = prism_rtl::some_of(qk_oa);
            _v.set(crate::check::types::recording::note_global_f(st1_p8, prism_rtl::deref(n_p2).span_p, qk_pc));
            goto _done;
        }
        if (prism_rtl::is_none(qk_oa)) {
            _v.set(st1_p8);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ({
        prism_rtl::is_none(qk_oa) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p9, Text::lit("unknown-name"), prism_rtl::deref(n_p2).span_p, prism_rtl::cat("nothing declares `", name_p7, "` here"))})
        : prism_rtl::is_some(qk_oa) ? ({
        auto&& qk_pd = prism_rtl::some_of(qk_oa);
        why_pb == Text::lit("tag")
        ? prism_rtl::more(prism_rtl::rc(TagApp(env_p0, st_p9, qk_pd, args_p3, span_p4, cspan_p6)))
        : is_local_maker_f(qk_pd) && (!prism_rtl::deref(env_p0).in_update_p)
        ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), local_outside_f(st_p9, qk_pd, span_p4)})
        : ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env_p0).g_p).vals_p, qk_pd);
        prism_rtl::is_some(_m) ? ({
        auto&& v_pe = prism_rtl::some_of(_m);
        ({
        auto args_p3x = args_p3;
        auto cspan_p6x = cspan_p6;
        auto env_p0x = env_p0;
        auto explicit_p5x = explicit_p5;
        auto n_p2x = n_p2;
        auto qk_pdx = qk_pd;
        auto span_p4x = span_p4;
        (crate::prelude::call_then(crate::check::types::schemes::start_instantiate_with_f(st_p9, prism_rtl::deref(v_pe).scheme_p, span_p4x, explicit_p5x), [=, args_p3x = std::move(args_p3x), cspan_p6x = std::move(cspan_p6x), env_p0x = std::move(env_p0x), n_p2x = std::move(n_p2x), qk_pdx = std::move(qk_pdx)](std::tuple<crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst> instantiate_with_f_3014) {
        return ({
            auto [t_ph, st2i_pi, inst_pj] = instantiate_with_f_3014;
            (crate::prelude::call_then(start_rank_two_f(st2i_pi, prism_rtl::deref(v_pe).scheme_p, inst_pj, crate::prelude::len(explicit_p5x), span_p4x), [=](std::tuple<Array<Text>, crate::check::types::St> rank_two_f_3101) {
            return ({
                auto [rigids_pk, st2_pl] = rank_two_f_3101;
                auto st3a_pf = note_callee_f(note_method_use_f(st2_pl, v_pe, span_p4x), prism_rtl::deref(n_p2x).span_p, cspan_p6x, t_ph);
                auto st3_pg = crate::check::types::bare_name_f(qk_pdx) == Text::lit("Min")
                    ? crate::check::types::recording::note_size_ty_f(st3a_pf, span_p4x, crate::check::types::recording::walk_f(st3a_pf, t_ph))
                    : st3a_pf;
                (crate::check::types::bare_name_f(qk_pdx) == Text::lit("Fold")) && (prism_rtl::deref(v_pe).home_p == Text::lit("Prelude"))
                ? prism_rtl::more(prism_rtl::rc(FoldApp(env_p0x, st3_pg, t_ph, args_p3x, span_p4x)))
                : crate::prelude::call_then(start_apply_fn_f(env_p0x, st3_pg, name_p7, t_ph, args_p3x, span_p4x), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> apply_fn_f_3519) {
                return ({
                    auto [rt_pm, st4_pn] = apply_fn_f_3519;
                    (crate::prelude::call_then(start_escaped_f(env_p0x, st4_pn, rigids_pk, rt_pm, name_p7, span_p4x), [=](crate::check::types::St escaped_f_3588) { return prism_rtl::finished(std::tuple{rt_pm, escaped_f_3588}); }));
                });
            });
            });
        }));
        });
    }));
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env_p0).g_p).ctors_p, qk_pd);
        prism_rtl::is_some(_m) ? ({
        auto&& c_po = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(CtorApp(env_p0, st_p9, c_po, args_p3, span_p4, cspan_p6)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p9, Text::lit("unknown-name"), prism_rtl::deref(n_p2).span_p, prism_rtl::cat("`", name_p7, "` has no signature line"))})
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CallGlobal, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_call_global_f(crate::check::expr::Env env_p0, crate::check::types::St st0_p1, crate::syntax::SName n_p2, Array<crate::syntax::Arg> args_p3, crate::syntax::Range span_p4, Array<crate::check::types::Ty> explicit_p5, crate::syntax::Range cspan_p6) {
    return prism_rtl::make_rc<CallGlobal>(env_p0, st0_p1, n_p2, args_p3, span_p4, explicit_p5, cspan_p6);
}


/// RankTwo: unbounded fn St, Scheme, Inst, Nat, Range -> (([Text], St))
std::tuple<Array<Text>, crate::check::types::St> rank_two_f(const crate::check::types::St& st_p0, const crate::check::types::Scheme& sc_p1, const crate::check::types::schemes::Inst& inst_p2, const Nat& n_explicit_p3, const crate::syntax::Range& span_p4) {
    auto qs_p5 = crate::prelude::filter(crate::check::errors::range0_f(crate::prelude::len(sc_p1.qs_p)), [&](const Nat& i_p6) { return (i_p6 >= n_explicit_p3) && is_rank_two_f(crate::prelude::or_(crate::prelude::index(sc_p1.qs_p, i_p6), Text::lit("")), sc_p1.ty_p); });
    return crate::prelude::run_to_end(crate::prelude::fold_job(qs_p5, std::tuple{Array<Text>{}, st_p0}, ({
        auto sc_p1x = sc_p1;
        auto inst_p2x = inst_p2;
        auto span_p4x = span_p4;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, crate::check::types::St>>(std::tuple<std::tuple<Array<Text>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, sc_p1x = std::move(sc_p1x), inst_p2x = std::move(inst_p2x), span_p4x = std::move(span_p4x)](std::tuple<std::tuple<Array<Text>, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sc_p1xy = sc_p1x;
            auto inst_p2xy = inst_p2x;
            auto span_p4xy = span_p4x;
            (crate::prelude::entered(crate::prelude::once_job([=, sc_p1xy = std::move(sc_p1xy), inst_p2xy = std::move(inst_p2xy), span_p4xy = std::move(span_p4xy)]() {
            return ({
                auto [acc_p7, s_p8] = p0;
                auto i_p9 = p1;
                ({
                auto q_pa = crate::prelude::or_(crate::prelude::index(prism_rtl::deref(sc_p1xy).qs_p, i_p9), Text::lit(""));
                auto rigid_pb = prism_rtl::cat(q_pa, "\'", prism_rtl::deref(s_p8).next_p);
                auto s2_pc = ({
                    crate::check::types::St this_ = s_p8;
                    this_.next_p = this_.next_p + Nat(1u);
                    (std::move(this_));
                });
                (crate::prelude::call_then(crate::check::types::unify::start_unify_f(s2_pc, crate::prelude::or_(crate::prelude::get(prism_rtl::deref(inst_p2xy).tys_p, q_pa), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), crate::check::types::Ty(crate::check::types::Ty::TyRigid{rigid_pb}), span_p4xy), [=](crate::check::types::St unify_f_4667) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc_p7, rigid_pb), unify_f_4667}); }));
            });
            });
        })));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Array<Text>, crate::check::types::St>> RankTwo::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& sc_p1 = this->sc_p1;
    const auto& inst_p2 = this->inst_p2;
    const auto& n_explicit_p3 = this->n_explicit_p3;
    const auto& span_p4 = this->span_p4;
    auto qs_p5 = crate::prelude::filter(crate::check::errors::range0_f(crate::prelude::len(prism_rtl::deref(sc_p1).qs_p)), [&](const Nat& i_p6) { return (i_p6 >= n_explicit_p3) && is_rank_two_f(crate::prelude::or_(crate::prelude::index(prism_rtl::deref(sc_p1).qs_p, i_p6), Text::lit("")), prism_rtl::deref(sc_p1).ty_p); });
    return crate::prelude::fold_job(qs_p5, std::tuple{Array<Text>{}, st_p0}, ({
        auto sc_p1x = sc_p1;
        auto inst_p2x = inst_p2;
        auto span_p4x = span_p4;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, crate::check::types::St>>(std::tuple<std::tuple<Array<Text>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, sc_p1x = std::move(sc_p1x), inst_p2x = std::move(inst_p2x), span_p4x = std::move(span_p4x)](std::tuple<std::tuple<Array<Text>, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sc_p1xy = sc_p1x;
            auto inst_p2xy = inst_p2x;
            auto span_p4xy = span_p4x;
            (crate::prelude::entered(crate::prelude::once_job([=, sc_p1xy = std::move(sc_p1xy), inst_p2xy = std::move(inst_p2xy), span_p4xy = std::move(span_p4xy)]() {
            return ({
                auto [acc_p7, s_p8] = p0;
                auto i_p9 = p1;
                ({
                auto q_pa = crate::prelude::or_(crate::prelude::index(prism_rtl::deref(sc_p1xy).qs_p, i_p9), Text::lit(""));
                auto rigid_pb = prism_rtl::cat(q_pa, "\'", prism_rtl::deref(s_p8).next_p);
                auto s2_pc = ({
                    crate::check::types::St this_ = s_p8;
                    this_.next_p = this_.next_p + Nat(1u);
                    (std::move(this_));
                });
                (crate::prelude::call_then(crate::check::types::unify::start_unify_f(s2_pc, crate::prelude::or_(crate::prelude::get(prism_rtl::deref(inst_p2xy).tys_p, q_pa), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), crate::check::types::Ty(crate::check::types::Ty::TyRigid{rigid_pb}), span_p4xy), [=](crate::check::types::St unify_f_4667) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc_p7, rigid_pb), unify_f_4667}); }));
            });
            });
        })));
        });
    }));
    }))->cycle();
}


/// `Start RankTwo, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<Text>, crate::check::types::St>> start_rank_two_f(crate::check::types::St st_p0, crate::check::types::Scheme sc_p1, crate::check::types::schemes::Inst inst_p2, Nat n_explicit_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<RankTwo>(st_p0, sc_p1, inst_p2, n_explicit_p3, span_p4);
}


/// IsRankTwo: fn Text, Ty -> Bool
bool is_rank_two_f(const Text& q_p0, const crate::check::types::Ty& t_p1) {
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p1)) {
        auto&& ps_p2 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a1;
        auto&& res_p3 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a2;
        auto holding_p4 = crate::prelude::filter(ps_p2, [&](const crate::check::types::Ty& p_p5) { return qoccurs_f(q_p0, p_p5); });
        return (crate::prelude::len(holding_p4) != Nat(1u)) || qoccurs_f(q_p0, prism_rtl::deref(prism_rtl::deref(res_p3)))
            ? false
            : ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = crate::prelude::index(holding_p4, Nat(0u));
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::check::types::Ty::TyFn>(prism_rtl::some_of(_m))) {
                _v.set(elem_out_q_f(q_p0, crate::prelude::or_(crate::prelude::index(holding_p4, Nat(0u)), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))));
                goto _done;
            }
            {
                _v.set(false);
                goto _done;
            }
        _done:
            _v.take();
        });
    }
    {
        return false;
    }
}


/// QOccurs: fn Text, Ty -> Bool
bool qoccurs_f(const Text& q_p0, const crate::check::types::Ty& t_p1) {
    if (prism_rtl::is<crate::check::types::Ty::TyQ>(t_p1)) {
        auto&& n_p2 = prism_rtl::as<crate::check::types::Ty::TyQ>(t_p1).a0;
        return n_p2 == q_p0;
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1)) {
        auto&& args_p3 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        return crate::prelude::fold(args_p3, false, [&](const bool& seen_p4, const crate::check::types::Ty& a_p5) { return prism_rtl::deref(seen_p4) || qoccurs_f(q_p0, a_p5); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p1)) {
        auto&& ps_p6 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a1;
        auto&& r_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a2;
        return crate::prelude::fold(ps_p6, qoccurs_f(q_p0, prism_rtl::deref(prism_rtl::deref(r_p7))), [&](const bool& seen_p8, const crate::check::types::Ty& a_p9) { return prism_rtl::deref(seen_p8) || qoccurs_f(q_p0, a_p9); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p1)) {
        auto&& ts_pa = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p1).a0;
        return crate::prelude::fold(ts_pa, false, [&](const bool& seen_pb, const crate::check::types::Ty& a_pc) { return prism_rtl::deref(seen_pb) || qoccurs_f(q_p0, a_pc); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p1)) {
        auto&& e_pd = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p1).a0;
        return qoccurs_f(q_p0, prism_rtl::deref(prism_rtl::deref(e_pd)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p1)) {
        auto&& k_pe = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a0;
        auto&& v_pf = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a1;
        return qoccurs_f(q_p0, prism_rtl::deref(prism_rtl::deref(k_pe))) || qoccurs_f(q_p0, prism_rtl::deref(prism_rtl::deref(v_pf)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p1)) {
        auto&& i_pg = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        return qoccurs_f(q_p0, prism_rtl::deref(prism_rtl::deref(i_pg)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p1)) {
        auto&& i_ph = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p1).a0;
        return qoccurs_f(q_p0, prism_rtl::deref(prism_rtl::deref(i_ph)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t_p1)) {
        auto&& o_pi = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p1).a1;
        return qoccurs_f(q_p0, prism_rtl::deref(prism_rtl::deref(o_pi)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p1)) {
        auto&& i_pj = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p1).a1;
        return qoccurs_f(q_p0, prism_rtl::deref(prism_rtl::deref(i_pj)));
    }
    {
        return false;
    }
}


/// ElemOutQ: fn Text, Ty -> Bool
bool elem_out_q_f(const Text& q_p0, const crate::check::types::Ty& t_p1) {
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t_p1)) {
        auto&& o_p2 = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p1).a1;
        return (prism_rtl::deref(prism_rtl::deref(o_p2)) == crate::check::types::Ty(crate::check::types::Ty::TyQ{q_p0})) || elem_out_q_f(q_p0, prism_rtl::deref(prism_rtl::deref(o_p2)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1)) {
        auto&& args_p3 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        return crate::prelude::fold(args_p3, false, [&](const bool& seen_p4, const crate::check::types::Ty& a_p5) { return prism_rtl::deref(seen_p4) || elem_out_q_f(q_p0, a_p5); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p1)) {
        auto&& ps_p6 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a1;
        auto&& r_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a2;
        return crate::prelude::fold(ps_p6, elem_out_q_f(q_p0, prism_rtl::deref(prism_rtl::deref(r_p7))), [&](const bool& seen_p8, const crate::check::types::Ty& a_p9) { return prism_rtl::deref(seen_p8) || elem_out_q_f(q_p0, a_p9); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p1)) {
        auto&& ts_pa = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p1).a0;
        return crate::prelude::fold(ts_pa, false, [&](const bool& seen_pb, const crate::check::types::Ty& a_pc) { return prism_rtl::deref(seen_pb) || elem_out_q_f(q_p0, a_pc); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p1)) {
        auto&& e_pd = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p1).a0;
        return elem_out_q_f(q_p0, prism_rtl::deref(prism_rtl::deref(e_pd)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p1)) {
        auto&& k_pe = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a0;
        auto&& v_pf = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a1;
        return elem_out_q_f(q_p0, prism_rtl::deref(prism_rtl::deref(k_pe))) || elem_out_q_f(q_p0, prism_rtl::deref(prism_rtl::deref(v_pf)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p1)) {
        auto&& i_pg = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        return elem_out_q_f(q_p0, prism_rtl::deref(prism_rtl::deref(i_pg)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p1)) {
        auto&& i_ph = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p1).a0;
        return elem_out_q_f(q_p0, prism_rtl::deref(prism_rtl::deref(i_ph)));
    }
    {
        return false;
    }
}


/// Escaped: unbounded fn Env, St, [Text], Ty, Text, Range -> St
crate::check::types::St escaped_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Array<Text>& rigids_p2, const crate::check::types::Ty& rt_p3, const Text& fname_p4, const crate::syntax::Range& span_p5) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(rigids_p2, st_p1, ({
        auto env_p0x = env_p0;
        auto rt_p3x = rt_p3;
        auto span_p5x = span_p5;
        auto fname_p4x = fname_p4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Text>)>>(prism_rtl::rc([=, env_p0x = std::move(env_p0x), rt_p3x = std::move(rt_p3x), span_p5x = std::move(span_p5x), fname_p4x = std::move(fname_p4x)](std::tuple<crate::check::types::St, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_p0xy = env_p0x;
            auto rt_p3xy = rt_p3x;
            auto span_p5xy = span_p5x;
            auto fname_p4xy = fname_p4x;
            (crate::prelude::entered(crate::prelude::once_job([=, env_p0xy = std::move(env_p0xy), rt_p3xy = std::move(rt_p3xy), span_p5xy = std::move(span_p5xy), fname_p4xy = std::move(fname_p4xy)]() {
            return ({
                auto s_p6 = p0;
                auto r_p7 = p1;
                (crate::prelude::call_value(crate::prelude::filter_job(crate::prelude::keys(prism_rtl::deref(env_p0xy).locals_p), ({
                auto s_p6x = s_p6;
                auto r_p7x = r_p7;
                auto env_p0xyx = env_p0xy;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, s_p6x = std::move(s_p6x), r_p7x = std::move(r_p7x), env_p0xyx = std::move(env_p0xyx)](Text p0) {
                return ({
                    auto s_p6xy = s_p6x;
                    auto r_p7xy = r_p7x;
                    auto env_p0xyxy = env_p0xyx;
                    (crate::prelude::entered(crate::prelude::once_job([=, s_p6xy = std::move(s_p6xy), r_p7xy = std::move(r_p7xy), env_p0xyxy = std::move(env_p0xyxy)]() {
                    return ({
                        auto k_p9 = p0;
                        (prism_rtl::more(prism_rtl::rc(HasRigid(s_p6xy, r_p7xy, prism_rtl::deref(crate::prelude::or_(crate::prelude::get(prism_rtl::deref(env_p0xyxy).locals_p, k_p9), crate::check::types::schemes::mono_f(crate::check::types::Ty(crate::check::types::Ty::TyErr{})))).ty_p))));
                    });
                })));
                });
            })));
            })), [=](Array<Text> filter_6630) {
                return ({
                    auto outside_p8 = filter_6630;
                    (crate::prelude::call_then(start_has_rigid_f(s_p6, r_p7, rt_p3xy), [=, outside_p8 = std::move(outside_p8)](bool has_rigid_f_6719) {
                    return has_rigid_f_6719
                        ? prism_rtl::finished(crate::check::types::recording::err_f(s_p6, Text::lit("refinement-escape"), span_p5xy, prism_rtl::cat("the call\'s result takes the output of the element `", fname_p4xy, "`\'s supplier answers, which is the supplier\'s alone (rank-2)")))
                        : ({
                        auto&& _m = crate::prelude::index(outside_p8, Nat(0u));
                        prism_rtl::is_some(_m) ? ({
                        auto&& k_pa = prism_rtl::some_of(_m);
                        prism_rtl::finished(crate::check::types::recording::err_f(s_p6, Text::lit("refinement-escape"), span_p5xy, prism_rtl::cat("`", k_pa, "`, outside the supplier `", fname_p4xy, "` is given, takes the output of the element the supplier answers, which is the supplier\'s alone (rank-2)")));
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(s_p6)
                        : throw prism_rtl::Panic("no arm matched");
                    });
                }));
                });
            }));
            });
        })));
        });
    })));
    })));
}


prism_rtl::Turn<crate::check::types::St> Escaped::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& rigids_p2 = this->rigids_p2;
    const auto& rt_p3 = this->rt_p3;
    const auto& fname_p4 = this->fname_p4;
    const auto& span_p5 = this->span_p5;
    return crate::prelude::fold_job(rigids_p2, st_p1, ({
        auto env_p0x = env_p0;
        auto rt_p3x = rt_p3;
        auto span_p5x = span_p5;
        auto fname_p4x = fname_p4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Text>)>>(prism_rtl::rc([=, env_p0x = std::move(env_p0x), rt_p3x = std::move(rt_p3x), span_p5x = std::move(span_p5x), fname_p4x = std::move(fname_p4x)](std::tuple<crate::check::types::St, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_p0xy = env_p0x;
            auto rt_p3xy = rt_p3x;
            auto span_p5xy = span_p5x;
            auto fname_p4xy = fname_p4x;
            (crate::prelude::entered(crate::prelude::once_job([=, env_p0xy = std::move(env_p0xy), rt_p3xy = std::move(rt_p3xy), span_p5xy = std::move(span_p5xy), fname_p4xy = std::move(fname_p4xy)]() {
            return ({
                auto s_p6 = p0;
                auto r_p7 = p1;
                (crate::prelude::call_value(crate::prelude::filter_job(crate::prelude::keys(prism_rtl::deref(env_p0xy).locals_p), ({
                auto s_p6x = s_p6;
                auto r_p7x = r_p7;
                auto env_p0xyx = env_p0xy;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, s_p6x = std::move(s_p6x), r_p7x = std::move(r_p7x), env_p0xyx = std::move(env_p0xyx)](Text p0) {
                return ({
                    auto s_p6xy = s_p6x;
                    auto r_p7xy = r_p7x;
                    auto env_p0xyxy = env_p0xyx;
                    (crate::prelude::entered(crate::prelude::once_job([=, s_p6xy = std::move(s_p6xy), r_p7xy = std::move(r_p7xy), env_p0xyxy = std::move(env_p0xyxy)]() {
                    return ({
                        auto k_p9 = p0;
                        (prism_rtl::more(prism_rtl::rc(HasRigid(s_p6xy, r_p7xy, prism_rtl::deref(crate::prelude::or_(crate::prelude::get(prism_rtl::deref(env_p0xyxy).locals_p, k_p9), crate::check::types::schemes::mono_f(crate::check::types::Ty(crate::check::types::Ty::TyErr{})))).ty_p))));
                    });
                })));
                });
            })));
            })), [=](Array<Text> filter_6630) {
                return ({
                    auto outside_p8 = filter_6630;
                    (crate::prelude::call_then(start_has_rigid_f(s_p6, r_p7, rt_p3xy), [=, outside_p8 = std::move(outside_p8)](bool has_rigid_f_6719) {
                    return has_rigid_f_6719
                        ? prism_rtl::finished(crate::check::types::recording::err_f(s_p6, Text::lit("refinement-escape"), span_p5xy, prism_rtl::cat("the call\'s result takes the output of the element `", fname_p4xy, "`\'s supplier answers, which is the supplier\'s alone (rank-2)")))
                        : ({
                        auto&& _m = crate::prelude::index(outside_p8, Nat(0u));
                        prism_rtl::is_some(_m) ? ({
                        auto&& k_pa = prism_rtl::some_of(_m);
                        prism_rtl::finished(crate::check::types::recording::err_f(s_p6, Text::lit("refinement-escape"), span_p5xy, prism_rtl::cat("`", k_pa, "`, outside the supplier `", fname_p4xy, "` is given, takes the output of the element the supplier answers, which is the supplier\'s alone (rank-2)")));
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(s_p6)
                        : throw prism_rtl::Panic("no arm matched");
                    });
                }));
                });
            }));
            });
        })));
        });
    })));
    }))->cycle();
}


/// `Start Escaped, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_escaped_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<Text> rigids_p2, crate::check::types::Ty rt_p3, Text fname_p4, crate::syntax::Range span_p5) {
    return prism_rtl::make_rc<Escaped>(env_p0, st_p1, rigids_p2, rt_p3, fname_p4, span_p5);
}


/// HasRigid: unbounded fn St, Text, Ty -> Bool
bool has_rigid_f(const crate::check::types::St& st_p0, const Text& r_p1, const crate::check::types::Ty& t_p2) {
    return rigid_in_f(r_p1, crate::check::types::recording::zonk_f(st_p0, t_p2));
}


prism_rtl::Turn<bool> HasRigid::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& r_p1 = this->r_p1;
    const auto& t_p2 = this->t_p2;
    auto r_p1x = r_p1;
    auto st_p0x = st_p0;
    auto t_p2x = t_p2;
    return crate::prelude::call_then(crate::check::types::recording::start_zonk_f(st_p0x, t_p2x), [=](crate::check::types::Ty zonk_f_7206) { return prism_rtl::finished(rigid_in_f(r_p1x, zonk_f_7206)); });
}


/// `Start HasRigid, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_has_rigid_f(crate::check::types::St st_p0, Text r_p1, crate::check::types::Ty t_p2) {
    return prism_rtl::make_rc<HasRigid>(st_p0, r_p1, t_p2);
}


/// RigidIn: fn Text, Ty -> Bool
bool rigid_in_f(const Text& r_p0, const crate::check::types::Ty& t_p1) {
    if (prism_rtl::is<crate::check::types::Ty::TyRigid>(t_p1)) {
        auto&& n_p2 = prism_rtl::as<crate::check::types::Ty::TyRigid>(t_p1).a0;
        return n_p2 == r_p0;
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1)) {
        auto&& args_p3 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        return crate::prelude::fold(args_p3, false, [&](const bool& seen_p4, const crate::check::types::Ty& a_p5) { return prism_rtl::deref(seen_p4) || rigid_in_f(r_p0, a_p5); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p1)) {
        auto&& ps_p6 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a1;
        auto&& res_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a2;
        return crate::prelude::fold(ps_p6, rigid_in_f(r_p0, prism_rtl::deref(prism_rtl::deref(res_p7))), [&](const bool& seen_p8, const crate::check::types::Ty& a_p9) { return prism_rtl::deref(seen_p8) || rigid_in_f(r_p0, a_p9); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p1)) {
        auto&& ts_pa = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p1).a0;
        return crate::prelude::fold(ts_pa, false, [&](const bool& seen_pb, const crate::check::types::Ty& a_pc) { return prism_rtl::deref(seen_pb) || rigid_in_f(r_p0, a_pc); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p1)) {
        auto&& e_pd = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p1).a0;
        return rigid_in_f(r_p0, prism_rtl::deref(prism_rtl::deref(e_pd)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p1)) {
        auto&& k_pe = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a0;
        auto&& v_pf = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a1;
        return rigid_in_f(r_p0, prism_rtl::deref(prism_rtl::deref(k_pe))) || rigid_in_f(r_p0, prism_rtl::deref(prism_rtl::deref(v_pf)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p1)) {
        auto&& i_pg = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        return rigid_in_f(r_p0, prism_rtl::deref(prism_rtl::deref(i_pg)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p1)) {
        auto&& i_ph = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p1).a0;
        return rigid_in_f(r_p0, prism_rtl::deref(prism_rtl::deref(i_ph)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t_p1)) {
        auto&& o_pi = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p1).a1;
        return rigid_in_f(r_p0, prism_rtl::deref(prism_rtl::deref(o_pi)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p1)) {
        auto&& i_pj = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p1).a1;
        return rigid_in_f(r_p0, prism_rtl::deref(prism_rtl::deref(i_pj)));
    }
    {
        return false;
    }
}


/// IsLocalMaker: fn Text -> Bool
bool is_local_maker_f(const Text& qk_p0) {
    return crate::check::types::has_text_f(Array(std::vector{Text::lit("Buffer.Numbered"), Text::lit("Buffer.Empty"), Text::lit("Table.Empty")}), qk_p0);
}


/// LocalOutside: fn St, Text, Range -> St
crate::check::types::St local_outside_f(const crate::check::types::St& st_p0, const Text& qk_p1, const crate::syntax::Range& span_p2) {
    return crate::check::types::recording::err_fix_f(st_p0, Text::lit("local-escapes"), span_p2, prism_rtl::cat("a `", crate::prelude::or_(crate::prelude::index(crate::prelude::split_on(qk_p1, Text::lit(".")), Nat(0u)), qk_p1), "` lives only in an `&` block\'s local"), prism_rtl::cat("make it inside `update ...:` as `let &b = ", qk_p1, " ...`, and `Freeze &b` for the plain value"));
}


/// NoteCallee: fn St, Range, Range, Ty -> St
crate::check::types::St note_callee_f(const crate::check::types::St& st_p0, const crate::syntax::Range& at_p1, const crate::syntax::Range& cspan_p2, const crate::check::types::Ty& t_p3) {
    return at_p1 == cspan_p2
        ? crate::check::types::recording::note_ty_f(st_p0, at_p1, t_p3)
        : crate::check::types::recording::note_ty_f(crate::check::types::recording::note_ty_f(st_p0, at_p1, t_p3), cspan_p2, t_p3);
}


/// NoteMethodUse: fn St, ValInfo, Range -> St
crate::check::types::St note_method_use_f(const crate::check::types::St& st_p0, const crate::check::env::ValInfo& v_p1, const crate::syntax::Range& span_p2) {
    return v_p1.sort_p != Text::lit("method")
        ? st_p0
        : ({
        auto&& _cls_p3 = crate::prelude::or_(crate::prelude::index(prism_rtl::deref(v_p1.scheme_p).bounds_p, Nat(0u)), std::tuple{Text::lit(""), Text::lit("")});
        auto&& cls_p3 = std::get<1>(_cls_p3);
        (crate::check::types::recording::note_method_f(st_p0, span_p2, v_p1.qk_p, cls_p3));
    });
}


/// FoldApp: unbounded fn Env, St, Ty, [Arg], Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> fold_app_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::check::types::Ty& t_p2, const Array<crate::syntax::Arg>& args_p3, const crate::syntax::Range& span_p4) {
    auto lambda_arity_p5 = ({
        __label__ _done;
        prism_rtl::Slot<Nat> _v;
        auto&& _m = crate::prelude::index(args_p3, Nat(2u));
        if (prism_rtl::is_some(_m)) {
            auto&& a_p6 = prism_rtl::some_of(_m);
            _v.set(lambda_arity_f(prism_rtl::deref(a_p6).value_p));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Nat(2u));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return lambda_arity_p5 == Nat(3u)
        ? ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
        auto&& _m = crate::check::types::recording::walk_f(st_p1, t_p2);
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& col_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0;
            auto&& params_p8 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            auto&& res_p9 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
            _v.set(({
                auto [k_pc, st1_pd] = crate::check::types::fresh_var_f(st_p1, false, Text::lit(""));
                auto [v_pe, st2_pf] = crate::check::types::fresh_var_f(st1_pd, false, Text::lit(""));
                auto [b_pg, st3_ph] = crate::check::types::fresh_var_f(st2_pf, false, Text::lit(""));
                auto step_col_pa = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::check::types::Col> _v;
                    auto&& _m = crate::prelude::index(params_p8, Nat(2u));
                    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::check::types::Ty::TyFn>(prism_rtl::some_of(_m))) {
                        auto&& c_pi = prism_rtl::as<crate::check::types::Ty::TyFn>(prism_rtl::some_of(_m)).a0;
                        _v.set(c_pi);
                        goto _done;
                    }
                    {
                        _v.set(col_p7);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto params2_pb = Array(std::vector{crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(k_pc), prism_rtl::rc(v_pe)}), b_pg, crate::check::types::Ty(crate::check::types::Ty::TyFn{step_col_pa, Array(std::vector{b_pg, k_pc, v_pe}), prism_rtl::rc(b_pg)})});
                apply_rule_f(env_p0, st3_ph, Text::lit("Fold"), col_p7, params2_pb, b_pg, args_p3, span_p4);
            }));
            goto _done;
        }
        {
            _v.set(apply_fn_f(env_p0, st_p1, Text::lit("Fold"), t_p2, args_p3, span_p4));
            goto _done;
        }
    _done:
        _v.take();
    })
        : apply_fn_f(env_p0, st_p1, Text::lit("Fold"), t_p2, args_p3, span_p4);
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> FoldApp::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& t_p2 = this->t_p2;
    const auto& args_p3 = this->args_p3;
    const auto& span_p4 = this->span_p4;
    auto lambda_arity_p5 = ({
        __label__ _done;
        prism_rtl::Slot<Nat> _v;
        auto&& _m = crate::prelude::index(args_p3, Nat(2u));
        if (prism_rtl::is_some(_m)) {
            auto&& a_p6 = prism_rtl::some_of(_m);
            _v.set(lambda_arity_f(prism_rtl::deref(a_p6).value_p));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Nat(2u));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return lambda_arity_p5 == Nat(3u)
        ? ({
        auto args_p3x = args_p3;
        auto env_p0x = env_p0;
        auto span_p4x = span_p4;
        auto st_p1x = st_p1;
        auto t_p2x = t_p2;
        (crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x, t_p2x), [=, args_p3x = std::move(args_p3x), env_p0x = std::move(env_p0x), span_p4x = std::move(span_p4x)](crate::check::types::Ty walk_f_9146) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyFn>(walk_f_9146) ? ({
            auto&& col_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_f_9146).a0;
            auto&& params_p8 = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_f_9146).a1;
            auto&& res_p9 = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_f_9146).a2;
            ({
            auto [k_pc, st1_pd] = crate::check::types::fresh_var_f(st_p1x, false, Text::lit(""));
            auto [v_pe, st2_pf] = crate::check::types::fresh_var_f(st1_pd, false, Text::lit(""));
            auto [b_pg, st3_ph] = crate::check::types::fresh_var_f(st2_pf, false, Text::lit(""));
            auto step_col_pa = ({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::Col> _v;
                auto&& _m = crate::prelude::index(params_p8, Nat(2u));
                if (prism_rtl::is_some(_m) && prism_rtl::is<crate::check::types::Ty::TyFn>(prism_rtl::some_of(_m))) {
                    auto&& c_pi = prism_rtl::as<crate::check::types::Ty::TyFn>(prism_rtl::some_of(_m)).a0;
                    _v.set(c_pi);
                    goto _done;
                }
                {
                    _v.set(col_p7);
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto params2_pb = Array(std::vector{crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(k_pc), prism_rtl::rc(v_pe)}), b_pg, crate::check::types::Ty(crate::check::types::Ty::TyFn{step_col_pa, Array(std::vector{b_pg, k_pc, v_pe}), prism_rtl::rc(b_pg)})});
            (prism_rtl::more(prism_rtl::rc(ApplyRule(env_p0x, st3_ph, Text::lit("Fold"), col_p7, params2_pb, b_pg, args_p3x, span_p4x))));
        });
        })
            : prism_rtl::more(prism_rtl::rc(ApplyFn(env_p0x, st_p1x, Text::lit("Fold"), t_p2x, args_p3x, span_p4x)));
        });
    }));
    })
        : prism_rtl::more(prism_rtl::rc(ApplyFn(env_p0, st_p1, Text::lit("Fold"), t_p2, args_p3, span_p4)));
}


/// `Start FoldApp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_fold_app_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::types::Ty t_p2, Array<crate::syntax::Arg> args_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<FoldApp>(env_p0, st_p1, t_p2, args_p3, span_p4);
}


/// ApplyFn: unbounded fn Env, St, Text, Ty, [Arg], Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> apply_fn_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Text& fname_p2, const crate::check::types::Ty& fty_p3, const Array<crate::syntax::Arg>& args_p4, const crate::syntax::Range& span_p5) {
    auto named_p6 = crate::prelude::filter(args_p4, [&](const crate::syntax::Arg& a_p8) { return prism_rtl::deref(a_p8).name_o != std::optional<crate::syntax::Ident>{}; });
    auto st0_p7 = crate::prelude::len(named_p6) > Nat(0u)
        ? crate::check::types::recording::err_f(st_p1, Text::lit("mismatch"), span_p5, prism_rtl::cat("`", fname_p2, "` takes its arguments by position; named arguments are a record\'s or a tag\'s"))
        : st_p1;
    auto&& _m = crate::check::types::recording::walk_f(st0_p7, fty_p3);
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
        auto&& col_p9 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0;
        auto&& params_pa = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
        auto&& res_pb = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
        return crate::prelude::len(params_pa) != crate::prelude::len(args_p4)
            ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st0_p7, Text::lit("mismatch"), span_p5, prism_rtl::cat("`", fname_p2, "` takes ", crate::check::errors::count_word_f(crate::prelude::len(params_pa)), " argument", crate::prelude::len(params_pa) == Nat(1u) ? Text::lit("") : Text::lit("s"), "; here it has ", crate::check::errors::count_word_f(crate::prelude::len(args_p4))))}
            : apply_rule_f(env_p0, st0_p7, fname_p2, col_p9, params_pa, prism_rtl::deref(res_pb), args_p4, span_p5);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(_m)) {
        auto [params_ph, st1_pi] = crate::prelude::fold(args_p4, std::tuple{Array<crate::check::types::Ty>{}, st0_p7}, [&](const std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>& _p0, const crate::syntax::Arg& _p1) {
            auto&& acc_pd = std::get<0>(_p0);
            auto&& s_pe = std::get<1>(_p0);
            return ({
                auto [v_pf, s2_pg] = crate::check::types::fresh_var_f(s_pe, false, Text::lit(""));
                std::tuple{crate::prelude::push(acc_pd, v_pf), s2_pg};
            });
        });
        auto [res_pj, st2_pk] = crate::check::types::fresh_var_f(st1_pi, false, Text::lit(""));
        auto [col_pl, st2b_pm] = crate::check::types::fresh_col_f(st2_pk);
        auto st3_pc = crate::check::types::unify::unify_f(st2b_pm, fty_p3, crate::check::types::Ty(crate::check::types::Ty::TyFn{col_pl, params_ph, prism_rtl::rc(res_pj)}), span_p5);
        return apply_rule_f(env_p0, st3_pc, fname_p2, col_pl, params_ph, res_pj, args_p4, span_p5);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyErr>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), st0_p7};
    }
    {
        auto&& other_pn = _m;
        return crate::prelude::len(args_p4) == Nat(0u)
            ? std::tuple{other_pn, st0_p7}
            : std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st0_p7, Text::lit("mismatch"), span_p5, prism_rtl::cat("`", fname_p2, "` is a `", crate::check::types::show_ty_f(st0_p7, other_pn), "`, not a function"))};
    }
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> ApplyFn::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& fname_p2 = this->fname_p2;
    const auto& fty_p3 = this->fty_p3;
    const auto& args_p4 = this->args_p4;
    const auto& span_p5 = this->span_p5;
    auto named_p6 = crate::prelude::filter(args_p4, [&](const crate::syntax::Arg& a_p8) { return prism_rtl::deref(a_p8).name_o != std::optional<crate::syntax::Ident>{}; });
    auto st0_p7 = crate::prelude::len(named_p6) > Nat(0u)
        ? crate::check::types::recording::err_f(st_p1, Text::lit("mismatch"), span_p5, prism_rtl::cat("`", fname_p2, "` takes its arguments by position; named arguments are a record\'s or a tag\'s"))
        : st_p1;
    auto args_p4x = args_p4;
    auto env_p0x = env_p0;
    auto fname_p2x = fname_p2;
    auto fty_p3x = fty_p3;
    auto span_p5x = span_p5;
    return crate::prelude::call_then(crate::check::types::recording::start_walk_f(st0_p7, fty_p3x), [=](crate::check::types::Ty walk_f_10180) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyFn>(walk_f_10180) ? ({
            auto&& col_p9 = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_f_10180).a0;
            auto&& params_pa = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_f_10180).a1;
            auto&& res_pb = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_f_10180).a2;
            crate::prelude::len(params_pa) != crate::prelude::len(args_p4x)
            ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st0_p7, Text::lit("mismatch"), span_p5x, prism_rtl::cat("`", fname_p2x, "` takes ", crate::check::errors::count_word_f(crate::prelude::len(params_pa)), " argument", crate::prelude::len(params_pa) == Nat(1u) ? Text::lit("") : Text::lit("s"), "; here it has ", crate::check::errors::count_word_f(crate::prelude::len(args_p4x))))})
            : prism_rtl::more(prism_rtl::rc(ApplyRule(env_p0x, st0_p7, fname_p2x, col_p9, params_pa, prism_rtl::deref(res_pb), args_p4x, span_p5x)));
        })
            : prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_f_10180) ? ({
            auto [params_ph, st1_pi] = crate::prelude::fold(args_p4x, std::tuple{Array<crate::check::types::Ty>{}, st0_p7}, [&](const std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>& _p0, const crate::syntax::Arg& _p1) {
                auto&& acc_pd = std::get<0>(_p0);
                auto&& s_pe = std::get<1>(_p0);
                return ({
                    auto [v_pf, s2_pg] = crate::check::types::fresh_var_f(s_pe, false, Text::lit(""));
                    std::tuple{crate::prelude::push(acc_pd, v_pf), s2_pg};
                });
            });
            auto [res_pj, st2_pk] = crate::check::types::fresh_var_f(st1_pi, false, Text::lit(""));
            auto [col_pl, st2b_pm] = crate::check::types::fresh_col_f(st2_pk);
            (crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2b_pm, fty_p3x, crate::check::types::Ty(crate::check::types::Ty::TyFn{col_pl, params_ph, prism_rtl::rc(res_pj)}), span_p5x), [=](crate::check::types::St unify_f_10842) {
            return ({
                auto st3_pc = unify_f_10842;
                (prism_rtl::more(prism_rtl::rc(ApplyRule(env_p0x, st3_pc, fname_p2x, col_pl, params_ph, res_pj, args_p4x, span_p5x))));
            });
        }));
        })
            : prism_rtl::is<crate::check::types::Ty::TyErr>(walk_f_10180) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), st0_p7})
            : ({
            auto&& other_pn = walk_f_10180;
            crate::prelude::len(args_p4x) == Nat(0u)
            ? prism_rtl::finished(std::tuple{other_pn, st0_p7})
            : crate::prelude::call_then(crate::check::types::start_show_ty_f(st0_p7, other_pn), [=](Text show_ty_f_11122) { return prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st0_p7, Text::lit("mismatch"), span_p5x, prism_rtl::cat("`", fname_p2x, "` is a `", show_ty_f_11122, "`, not a function"))}); });
        });
        });
    });
}


/// `Start ApplyFn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_apply_fn_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text fname_p2, crate::check::types::Ty fty_p3, Array<crate::syntax::Arg> args_p4, crate::syntax::Range span_p5) {
    return prism_rtl::make_rc<ApplyFn>(env_p0, st_p1, fname_p2, fty_p3, args_p4, span_p5);
}


/// Broken: fn Peeled, Bool -> Peeled
Peeled broken_f(const Peeled& p_p0, const bool& b_p1) {
    return !b_p1
        ? p_p0
        : ({
        Peeled this_ = p_p0;
        this_.broken_p = true;
        (std::move(this_));
    });
}


/// ApplyRule: unbounded fn Env, St, Text, Col, [Ty], Ty, [Arg], Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> apply_rule_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Text& fname_p2, const crate::check::types::Col& col_p3, const Array<crate::check::types::Ty>& params_p4, const crate::check::types::Ty& res_p5, const Array<crate::syntax::Arg>& args_p6, const crate::syntax::Range& span_p7) {
    auto n_p8 = crate::prelude::len(args_p6);
    auto cmp_p9 = crate::check::expr::is_comparison_f(fname_p2);
    auto [arg_tys_p12, st1_p13] = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(n_p8), std::tuple{Array<crate::check::types::Ty>{}, st_p1}, ({
        auto args_p6x = args_p6;
        auto span_p7x = span_p7;
        auto env_p0x = env_p0;
        auto params_p4x = params_p4;
        auto fname_p2x = fname_p2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, args_p6x = std::move(args_p6x), span_p7x = std::move(span_p7x), env_p0x = std::move(env_p0x), params_p4x = std::move(params_p4x), fname_p2x = std::move(fname_p2x)](std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto args_p6xy = args_p6x;
            auto span_p7xy = span_p7x;
            auto env_p0xy = env_p0x;
            auto params_p4xy = params_p4x;
            auto fname_p2xy = fname_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, args_p6xy = std::move(args_p6xy), span_p7xy = std::move(span_p7xy), env_p0xy = std::move(env_p0xy), params_p4xy = std::move(params_p4xy), fname_p2xy = std::move(fname_p2xy)]() {
            return ({
                auto [acc_po, s_pp] = p0;
                auto i_pq = p1;
                ({
                auto a_pr = crate::prelude::or_(crate::prelude::index(args_p6xy, i_pq), crate::syntax::Arg{.name_o = std::optional<crate::syntax::Ident>{}, .value_p = crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span_p = span_p7xy}, .span_p = span_p7xy});
                (crate::check::expr::is_lambda_f(prism_rtl::deref(a_pr).value_p)
                ? prism_rtl::finished(std::tuple{crate::prelude::push(acc_po, crate::check::types::Ty(crate::check::types::Ty::TyErr{})), s_pp})
                : crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0xy, s_pp, prism_rtl::deref(a_pr).value_p), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_f_12583) {
                return ({
                    auto [t_ps, s2_pt] = infer_f_12583;
                    (crate::prelude::call_then(crate::check::types::recording::start_walk_f(s2_pt, crate::prelude::or_(crate::prelude::index(params_p4xy, i_pq), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::check::types::Ty walk_f_12626) {
                    return crate::prelude::call_then(crate::check::types::recording::start_walk_f(s2_pt, t_ps), [=](crate::check::types::Ty walk_f_12660) {
                        return ({
                            auto&& _m = std::tuple{walk_f_12626, walk_f_12660};
                            prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<1>(_m)) ? ({
                            auto&& pc_pu = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<0>(_m)).a0;
                            auto&& ac_pv = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a0;
                            auto&& aps_p10 = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a1;
                            auto&& ar_p11 = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a2;
                            crate::prelude::call_then(crate::check::types::colors::start_add_leq_f(s2_pt, ac_pv, pc_pu, prism_rtl::deref(prism_rtl::deref(a_pr).value_p).span_p, Text::lit("arg"), fname_p2xy, Text::lit("")), [=](crate::check::types::St add_leq_f_12777) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc_po, crate::check::types::Ty(crate::check::types::Ty::TyFn{pc_pu, aps_p10, prism_rtl::rc(prism_rtl::deref(ar_p11))})), add_leq_f_12777}); });
                        })
                            : prism_rtl::finished(std::tuple{crate::prelude::push(acc_po, t_ps), s2_pt});
                        });
                    });
                }));
                });
            }));
            });
            });
        })));
        });
    }));
    })));
    auto [st2_p1b, whole_p1c] = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(n_p8), std::tuple{st1_p13, Array<Nat>{}}, ({
        auto args_p6x = args_p6;
        auto span_p7x = span_p7;
        auto arg_tys_p12x = arg_tys_p12;
        auto params_p4x = params_p4;
        auto env_p0x = env_p0;
        auto fname_p2x = fname_p2;
        auto res_p5x = res_p5;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::types::St, Array<Nat>>>(std::tuple<std::tuple<crate::check::types::St, Array<Nat>>, Nat>)>>(prism_rtl::rc([=, args_p6x = std::move(args_p6x), span_p7x = std::move(span_p7x), arg_tys_p12x = std::move(arg_tys_p12x), params_p4x = std::move(params_p4x), env_p0x = std::move(env_p0x), fname_p2x = std::move(fname_p2x), res_p5x = std::move(res_p5x)](std::tuple<std::tuple<crate::check::types::St, Array<Nat>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto args_p6xy = args_p6x;
            auto span_p7xy = span_p7x;
            auto arg_tys_p12xy = arg_tys_p12x;
            auto params_p4xy = params_p4x;
            auto env_p0xy = env_p0x;
            auto fname_p2xy = fname_p2x;
            auto res_p5xy = res_p5x;
            (crate::prelude::entered(crate::prelude::once_job([=, args_p6xy = std::move(args_p6xy), span_p7xy = std::move(span_p7xy), arg_tys_p12xy = std::move(arg_tys_p12xy), params_p4xy = std::move(params_p4xy), env_p0xy = std::move(env_p0xy), fname_p2xy = std::move(fname_p2xy), res_p5xy = std::move(res_p5xy)]() {
            return ({
                auto [s_p14, done_p15] = p0;
                auto i_p16 = p1;
                ({
                auto a_p17 = crate::prelude::or_(crate::prelude::index(args_p6xy, i_p16), crate::syntax::Arg{.name_o = std::optional<crate::syntax::Ident>{}, .value_p = crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span_p = span_p7xy}, .span_p = span_p7xy});
                auto at_p18 = crate::prelude::or_(crate::prelude::index(arg_tys_p12xy, i_p16), crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
                (crate::prelude::call_then(crate::check::types::recording::start_walk_f(s_p14, crate::prelude::or_(crate::prelude::index(params_p4xy, i_p16), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=, a_p17 = std::move(a_p17), at_p18 = std::move(at_p18)](crate::check::types::Ty walk_f_13099) {
                return ({
                    auto pnow_p19 = walk_f_13099;
                    (crate::prelude::call_then(crate::check::types::start_head_sigil_f(s_p14, pnow_p19), [=](Text head_sigil_f_13166) {
                    return ({
                        auto whole_now_p1a = crate::check::expr::is_time_sigil_f(head_sigil_f_13166) || (crate::check::types::head_sigil_f(s_p14, pnow_p19) == Text::lit("@"));
                        (crate::check::expr::is_lambda_f(prism_rtl::deref(a_p17).value_p)
                        ? prism_rtl::finished(std::tuple{s_p14, done_p15})
                        : std::move(whole_now_p1a) && (crate::check::types::stack_of_f(s_p14, at_p18) != Text::lit(""))
                        ? crate::prelude::call_then(crate::check::types::unify::start_unify_f(s_p14, pnow_p19, at_p18, prism_rtl::deref(prism_rtl::deref(a_p17).value_p).span_p), [=](crate::check::types::St unify_f_13313) { return prism_rtl::finished(std::tuple{unify_f_13313, crate::prelude::push(done_p15, i_p16)}); })
                        : crate::prelude::call_then(crate::check::types::start_stack_of_f(s_p14, at_p18), [=](Text stack_of_f_13382) {
                        return (stack_of_f_13382 != Text::lit("")) || crate::check::types::is_free_headed_f(s_p14, at_p18)
                            ? prism_rtl::finished(std::tuple{s_p14, done_p15})
                            : crate::prelude::call_then(start_arg_or_unpack_f(env_p0xy, s_p14, fname_p2xy, crate::prelude::or_(crate::prelude::index(params_p4xy, i_p16), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), pnow_p19, at_p18, a_p17, res_p5xy, span_p7xy), [=](crate::check::types::St arg_or_unpack_f_13457) { return prism_rtl::finished(std::tuple{arg_or_unpack_f_13457, done_p15}); });
                    }));
                    });
                }));
                });
            }));
            });
            });
        })));
        });
    }));
    })));
    auto&& _st3_p1p = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(n_p8), std::tuple{Map<Unit, Unit>{}, st2_p1b}, ({
        auto args_p6x = args_p6;
        auto span_p7x = span_p7;
        auto params_p4x = params_p4;
        auto env_p0x = env_p0;
        auto fname_p2x = fname_p2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Unit, Unit>, crate::check::types::St>>(std::tuple<std::tuple<Map<Unit, Unit>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, args_p6x = std::move(args_p6x), span_p7x = std::move(span_p7x), params_p4x = std::move(params_p4x), env_p0x = std::move(env_p0x), fname_p2x = std::move(fname_p2x)](std::tuple<std::tuple<Map<Unit, Unit>, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto args_p6xy = args_p6x;
            auto span_p7xy = span_p7x;
            auto params_p4xy = params_p4x;
            auto env_p0xy = env_p0x;
            auto fname_p2xy = fname_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, args_p6xy = std::move(args_p6xy), span_p7xy = std::move(span_p7xy), params_p4xy = std::move(params_p4xy), env_p0xy = std::move(env_p0xy), fname_p2xy = std::move(fname_p2xy)]() {
            return ({
                auto [m_p1d, s_p1e] = p0;
                auto i_p1f = p1;
                ({
                auto a_p1g = crate::prelude::or_(crate::prelude::index(args_p6xy, i_p1f), crate::syntax::Arg{.name_o = std::optional<crate::syntax::Ident>{}, .value_p = crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span_p = span_p7xy}, .span_p = span_p7xy});
                (crate::check::expr::is_lambda_f(prism_rtl::deref(a_p1g).value_p)
                ? crate::prelude::call_then(crate::check::types::recording::start_walk_f(s_p1e, crate::prelude::or_(crate::prelude::index(params_p4xy, i_p1f), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::check::types::Ty walk_f_13748) {
                return ({
                    auto p_p1h = walk_f_13748;
                    (crate::prelude::call_then(start_infer_lambda_f(env_p0xy, s_p1e, prism_rtl::deref(a_p1g).value_p, std::optional(p_p1h)), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_lambda_f_13807) {
                    return ({
                        auto [lt_p1j, s2_p1k] = infer_lambda_f_13807;
                        auto s3_p1i = ({
                            __label__ _done;
                            prism_rtl::Slot<crate::check::types::St> _v;
                            auto&& _m = std::tuple{p_p1h, lt_p1j};
                            if (prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<1>(_m))) {
                                auto&& pc_p1l = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<0>(_m)).a0;
                                auto&& lc_p1m = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a0;
                                auto&& lps_p1n = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a1;
                                auto&& lr_p1o = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a2;
                                _v.set(crate::check::types::colors::add_leq_f(crate::check::types::unify::unify_f(crate::check::types::recording::note_ty_f(s2_p1k, prism_rtl::deref(prism_rtl::deref(a_p1g).value_p).span_p, lt_p1j), p_p1h, crate::check::types::Ty(crate::check::types::Ty::TyFn{pc_p1l, lps_p1n, prism_rtl::rc(prism_rtl::deref(lr_p1o))}), prism_rtl::deref(prism_rtl::deref(a_p1g).value_p).span_p), lc_p1m, pc_p1l, prism_rtl::deref(prism_rtl::deref(a_p1g).value_p).span_p, Text::lit("arg"), fname_p2xy, Text::lit("")));
                                goto _done;
                            }
                            {
                                _v.set(crate::check::types::unify::unify_f(crate::check::types::recording::note_ty_f(s2_p1k, prism_rtl::deref(prism_rtl::deref(a_p1g).value_p).span_p, lt_p1j), p_p1h, lt_p1j, prism_rtl::deref(prism_rtl::deref(a_p1g).value_p).span_p));
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                        (prism_rtl::finished(std::tuple{m_p1d, s3_p1i}));
                    });
                }));
                });
            })
                : prism_rtl::finished(std::tuple{m_p1d, s_p1e}));
            });
            });
        })));
        });
    }));
    })));
    auto&& st3_p1p = std::get<1>(_st3_p1p);
    auto [pl_p25, st4_p26] = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(n_p8), std::tuple{Peeled{.events_p = Array<crate::syntax::Range>{}, .dyns_p = Array<crate::syntax::Range>{}, .opts_p = Array<Text>{}, .opt_args_p = Array<crate::syntax::Range>{}, .lifted_p = Text::lit(""), .broken_p = false}, st3_p1p}, ({
        auto args_p6x = args_p6;
        auto span_p7x = span_p7;
        auto arg_tys_p12x = arg_tys_p12;
        auto whole_p1cx = whole_p1c;
        auto env_p0x = env_p0;
        auto fname_p2x = fname_p2;
        auto cmp_p9x = std::move(cmp_p9);
        auto params_p4x = params_p4;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Peeled, crate::check::types::St>>(std::tuple<std::tuple<Peeled, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, args_p6x = std::move(args_p6x), span_p7x = std::move(span_p7x), arg_tys_p12x = std::move(arg_tys_p12x), whole_p1cx = std::move(whole_p1cx), env_p0x = std::move(env_p0x), fname_p2x = std::move(fname_p2x), cmp_p9x = std::move(cmp_p9x), params_p4x = std::move(params_p4x)](std::tuple<std::tuple<Peeled, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto args_p6xy = args_p6x;
            auto span_p7xy = span_p7x;
            auto arg_tys_p12xy = arg_tys_p12x;
            auto whole_p1cxy = whole_p1cx;
            auto env_p0xy = env_p0x;
            auto fname_p2xy = fname_p2x;
            auto cmp_p9xy = cmp_p9x;
            auto params_p4xy = params_p4x;
            (crate::prelude::entered(crate::prelude::once_job([=, args_p6xy = std::move(args_p6xy), span_p7xy = std::move(span_p7xy), arg_tys_p12xy = std::move(arg_tys_p12xy), whole_p1cxy = std::move(whole_p1cxy), env_p0xy = std::move(env_p0xy), fname_p2xy = std::move(fname_p2xy), cmp_p9xy = std::move(cmp_p9xy), params_p4xy = std::move(params_p4xy)]() {
            return ({
                auto [acc_p1q, s_p1r] = p0;
                auto i_p1s = p1;
                ({
                auto a_p1t = crate::prelude::or_(crate::prelude::index(args_p6xy, i_p1s), crate::syntax::Arg{.name_o = std::optional<crate::syntax::Ident>{}, .value_p = crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span_p = span_p7xy}, .span_p = span_p7xy});
                auto at_p1u = crate::prelude::or_(crate::prelude::index(arg_tys_p12xy, i_p1s), crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
                (crate::check::expr::is_lambda_f(prism_rtl::deref(a_p1t).value_p) || crate::check::types::has_nat_f(whole_p1cxy, i_p1s)) || ((crate::check::types::stack_of_f(s_p1r, at_p1u) == Text::lit("")) && (!crate::check::types::is_free_headed_f(s_p1r, at_p1u)))
                ? prism_rtl::finished(std::tuple{acc_p1q, s_p1r})
                : ({
                auto before_p1v = crate::prelude::len(prism_rtl::deref(s_p1r).diags_p);
                (crate::prelude::call_then(start_layered_arg_f(env_p0xy, s_p1r, acc_p1q, fname_p2xy, cmp_p9xy, crate::prelude::or_(crate::prelude::index(params_p4xy, i_p1s), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), at_p1u, a_p1t), [=, before_p1v = std::move(before_p1v)](std::tuple<Peeled, crate::check::types::St> layered_arg_f_14672) {
                return ({
                    auto [acc2_p21, s2_p22] = layered_arg_f_14672;
                    auto broke_p20 = (crate::prelude::len(prism_rtl::deref(s2_p22).diags_p) > before_p1v) && crate::prelude::fold(crate::prelude::drop(prism_rtl::deref(s2_p22).diags_p, before_p1v), false, [&](const bool& seen_p23, const crate::check::errors::CDiag& d_p24) { return prism_rtl::deref(seen_p23) || crate::check::types::has_text_f(Array(std::vector{Text::lit("two-layers"), Text::lit("layer-under-optional"), Text::lit("blueprint-operand")}), prism_rtl::deref(d_p24).code_p); });
                    (prism_rtl::finished(std::tuple{broken_f(acc2_p21, broke_p20), s2_p22}));
                });
            }));
            });
            });
            });
        })));
        });
    }));
    })));
    auto st5_pa = crate::prelude::len(prism_rtl::deref(pl_p25).events_p) > Nat(1u)
        ? crate::check::types::recording::err_fix_f(st4_p26, Text::lit("two-events"), crate::prelude::or_(crate::prelude::index(prism_rtl::deref(pl_p25).events_p, Nat(1u)), span_p7), Text::lit("two events in one operation"), Text::lit("merge them with `<|`, or hold one first, `$last <- 0 then !b`"))
        : st4_p26;
    auto st6_pb = crate::prelude::len(prism_rtl::deref(pl_p25).opts_p) > Nat(1u)
        ? crate::check::types::recording::err_f(st5_pa, Text::lit("optional-and-fault"), span_p7, Text::lit("`?` and `~` in one operation"))
        : st5_pa;
    auto layer_pc = crate::prelude::len(prism_rtl::deref(pl_p25).events_p) > Nat(0u)
        ? Text::lit("!")
        : crate::prelude::len(prism_rtl::deref(pl_p25).dyns_p) > Nat(0u)
        ? Text::lit("$")
        : Text::lit("");
    auto with_opt_pd = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::Ty> _v;
        auto&& _m = crate::prelude::index(prism_rtl::deref(pl_p25).opts_p, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& o_p27 = prism_rtl::some_of(_m);
            _v.set(crate::check::types::Ty(crate::check::types::Ty::TySig{o_p27, prism_rtl::rc(res_p5)}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(res_p5);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto result_pe = prism_rtl::deref(pl_p25).broken_p
        ? crate::check::types::Ty(crate::check::types::Ty::TyErr{})
        : layer_pc == Text::lit("")
        ? with_opt_pd
        : crate::check::types::Ty(crate::check::types::Ty::TySig{layer_pc, prism_rtl::rc(with_opt_pd)});
    auto call_col_pf = crate::check::types::colors::walk_col_f(st6_pb, col_p3);
    auto st7_pg = (layer_pc != Text::lit("")) && crate::check::types::colors::is_flex_col_f(call_col_pf)
        ? crate::check::types::colors::add_leq_f(st6_pb, call_col_pf, crate::check::types::Col(crate::check::types::Col::CBound{}), span_p7, Text::lit("lifted"), fname_p2, prism_rtl::deref(pl_p25).lifted_p)
        : st6_pb;
    auto lifted_bad_ph = ((layer_pc != Text::lit("")) && (call_col_pf != crate::check::types::Col(crate::check::types::Col::CBound{}))) && (!crate::check::types::colors::is_flex_col_f(call_col_pf));
    auto st8_pi = std::move(lifted_bad_ph)
        ? crate::check::types::recording::err_fix_f(st7_pg, Text::lit("lifted-unbounded"), span_p7, prism_rtl::cat(crate::check::types::colors::col_word_f(call_col_pf), " `", fname_p2, "` lifted over `", prism_rtl::deref(pl_p25).lifted_p, "`; use `@Run`"), prism_rtl::cat("run it through `!done <- @Run ", fname_p2, ", ...`"))
        : st7_pg;
    auto st9_pj = crate::check::types::colors::use_color_f(st8_pi, call_col_pf, fname_p2, span_p7);
    auto kind_pk = (layer_pc == Text::lit("!")) && (crate::prelude::len(prism_rtl::deref(pl_p25).dyns_p) > Nat(0u))
        ? Text::lit("sample")
        : layer_pc != Text::lit("")
        ? Text::lit("map")
        : fname_p2 == Text::lit("$") ? Text::lit("const") : Text::lit("plain");
    auto peeled_pl = crate::prelude::append(prism_rtl::deref(pl_p25).events_p, prism_rtl::deref(pl_p25).dyns_p);
    auto lifted_pm = crate::prelude::filter(crate::check::errors::range0_f(n_p8), [&](const Nat& i_p28) { return has_range_f(peeled_pl, prism_rtl::deref(prism_rtl::deref(crate::prelude::or_(crate::prelude::index(args_p6, i_p28), crate::syntax::Arg{.name_o = std::optional<crate::syntax::Ident>{}, .value_p = crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span_p = span_p7}, .span_p = span_p7})).value_p).span_p); });
    auto st10_pn = prism_rtl::deref(pl_p25).broken_p || (crate::prelude::len(prism_rtl::deref(pl_p25).opts_p) != Nat(1u))
        ? st9_pj
        : crate::check::types::recording::note_lift_f(st9_pj, span_p7, crate::prelude::or_(crate::prelude::index(prism_rtl::deref(pl_p25).opts_p, Nat(0u)), Text::lit("")), prism_rtl::deref(pl_p25).opt_args_p);
    return std::tuple{result_pe, crate::check::types::recording::note_app_f(st10_pn, span_p7, fname_p2, kind_pk, layer_pc, lifted_pm, crate::prelude::or_(crate::prelude::index(prism_rtl::deref(pl_p25).opts_p, Nat(0u)), Text::lit("")), call_col_pf)};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> ApplyRule::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& fname_p2 = this->fname_p2;
    const auto& col_p3 = this->col_p3;
    const auto& params_p4 = this->params_p4;
    const auto& res_p5 = this->res_p5;
    const auto& args_p6 = this->args_p6;
    const auto& span_p7 = this->span_p7;
    auto n_p8 = crate::prelude::len(args_p6);
    auto cmp_p9 = crate::check::expr::is_comparison_f(fname_p2);
    auto args_p6x = args_p6;
    auto col_p3x = col_p3;
    auto env_p0x = env_p0;
    auto fname_p2x = fname_p2;
    auto params_p4x = params_p4;
    auto res_p5x = res_p5;
    auto span_p7x = span_p7;
    auto st_p1x = st_p1;
    return crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(n_p8), std::tuple{Array<crate::check::types::Ty>{}, st_p1x}, ({
        auto args_p6xx = args_p6x;
        auto span_p7xx = span_p7x;
        auto env_p0xx = env_p0x;
        auto params_p4xx = params_p4x;
        auto fname_p2xx = fname_p2x;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, args_p6xx = std::move(args_p6xx), span_p7xx = std::move(span_p7xx), env_p0xx = std::move(env_p0xx), params_p4xx = std::move(params_p4xx), fname_p2xx = std::move(fname_p2xx)](std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto args_p6xxy = args_p6xx;
            auto span_p7xxy = span_p7xx;
            auto env_p0xxy = env_p0xx;
            auto params_p4xxy = params_p4xx;
            auto fname_p2xxy = fname_p2xx;
            (crate::prelude::entered(crate::prelude::once_job([=, args_p6xxy = std::move(args_p6xxy), span_p7xxy = std::move(span_p7xxy), env_p0xxy = std::move(env_p0xxy), params_p4xxy = std::move(params_p4xxy), fname_p2xxy = std::move(fname_p2xxy)]() {
            return ({
                auto [acc_po, s_pp] = p0;
                auto i_pq = p1;
                ({
                auto a_pr = crate::prelude::or_(crate::prelude::index(args_p6xxy, i_pq), crate::syntax::Arg{.name_o = std::optional<crate::syntax::Ident>{}, .value_p = crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span_p = span_p7xxy}, .span_p = span_p7xxy});
                (crate::check::expr::is_lambda_f(prism_rtl::deref(a_pr).value_p)
                ? prism_rtl::finished(std::tuple{crate::prelude::push(acc_po, crate::check::types::Ty(crate::check::types::Ty::TyErr{})), s_pp})
                : crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0xxy, s_pp, prism_rtl::deref(a_pr).value_p), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_f_12583) {
                return ({
                    auto [t_ps, s2_pt] = infer_f_12583;
                    (crate::prelude::call_then(crate::check::types::recording::start_walk_f(s2_pt, crate::prelude::or_(crate::prelude::index(params_p4xxy, i_pq), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::check::types::Ty walk_f_12626) {
                    return crate::prelude::call_then(crate::check::types::recording::start_walk_f(s2_pt, t_ps), [=](crate::check::types::Ty walk_f_12660) {
                        return ({
                            auto&& _m = std::tuple{walk_f_12626, walk_f_12660};
                            prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<1>(_m)) ? ({
                            auto&& pc_pu = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<0>(_m)).a0;
                            auto&& ac_pv = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a0;
                            auto&& aps_p10 = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a1;
                            auto&& ar_p11 = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a2;
                            crate::prelude::call_then(crate::check::types::colors::start_add_leq_f(s2_pt, ac_pv, pc_pu, prism_rtl::deref(prism_rtl::deref(a_pr).value_p).span_p, Text::lit("arg"), fname_p2xxy, Text::lit("")), [=](crate::check::types::St add_leq_f_12777) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc_po, crate::check::types::Ty(crate::check::types::Ty::TyFn{pc_pu, aps_p10, prism_rtl::rc(prism_rtl::deref(ar_p11))})), add_leq_f_12777}); });
                        })
                            : prism_rtl::finished(std::tuple{crate::prelude::push(acc_po, t_ps), s2_pt});
                        });
                    });
                }));
                });
            }));
            });
            });
        })));
        });
    }));
    })), [=](std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> fold_12350) {
        return ({
            auto [arg_tys_p12, st1_p13] = fold_12350;
            (crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(n_p8), std::tuple{st1_p13, Array<Nat>{}}, ({
            auto args_p6xx = args_p6x;
            auto span_p7xx = span_p7x;
            auto arg_tys_p12x = arg_tys_p12;
            auto params_p4xx = params_p4x;
            auto env_p0xx = env_p0x;
            auto fname_p2xx = fname_p2x;
            auto res_p5xx = res_p5x;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::types::St, Array<Nat>>>(std::tuple<std::tuple<crate::check::types::St, Array<Nat>>, Nat>)>>(prism_rtl::rc([=, args_p6xx = std::move(args_p6xx), span_p7xx = std::move(span_p7xx), arg_tys_p12x = std::move(arg_tys_p12x), params_p4xx = std::move(params_p4xx), env_p0xx = std::move(env_p0xx), fname_p2xx = std::move(fname_p2xx), res_p5xx = std::move(res_p5xx)](std::tuple<std::tuple<crate::check::types::St, Array<Nat>>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto args_p6xxy = args_p6xx;
                auto span_p7xxy = span_p7xx;
                auto arg_tys_p12xy = arg_tys_p12x;
                auto params_p4xxy = params_p4xx;
                auto env_p0xxy = env_p0xx;
                auto fname_p2xxy = fname_p2xx;
                auto res_p5xxy = res_p5xx;
                (crate::prelude::entered(crate::prelude::once_job([=, args_p6xxy = std::move(args_p6xxy), span_p7xxy = std::move(span_p7xxy), arg_tys_p12xy = std::move(arg_tys_p12xy), params_p4xxy = std::move(params_p4xxy), env_p0xxy = std::move(env_p0xxy), fname_p2xxy = std::move(fname_p2xxy), res_p5xxy = std::move(res_p5xxy)]() {
                return ({
                    auto [s_p14, done_p15] = p0;
                    auto i_p16 = p1;
                    ({
                    auto a_p17 = crate::prelude::or_(crate::prelude::index(args_p6xxy, i_p16), crate::syntax::Arg{.name_o = std::optional<crate::syntax::Ident>{}, .value_p = crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span_p = span_p7xxy}, .span_p = span_p7xxy});
                    auto at_p18 = crate::prelude::or_(crate::prelude::index(arg_tys_p12xy, i_p16), crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
                    (crate::prelude::call_then(crate::check::types::recording::start_walk_f(s_p14, crate::prelude::or_(crate::prelude::index(params_p4xxy, i_p16), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=, a_p17 = std::move(a_p17), at_p18 = std::move(at_p18)](crate::check::types::Ty walk_f_13099) {
                    return ({
                        auto pnow_p19 = walk_f_13099;
                        (crate::prelude::call_then(crate::check::types::start_head_sigil_f(s_p14, pnow_p19), [=](Text head_sigil_f_13166) {
                        return ({
                            auto whole_now_p1a = crate::check::expr::is_time_sigil_f(head_sigil_f_13166) || (crate::check::types::head_sigil_f(s_p14, pnow_p19) == Text::lit("@"));
                            (crate::check::expr::is_lambda_f(prism_rtl::deref(a_p17).value_p)
                            ? prism_rtl::finished(std::tuple{s_p14, done_p15})
                            : std::move(whole_now_p1a) && (crate::check::types::stack_of_f(s_p14, at_p18) != Text::lit(""))
                            ? crate::prelude::call_then(crate::check::types::unify::start_unify_f(s_p14, pnow_p19, at_p18, prism_rtl::deref(prism_rtl::deref(a_p17).value_p).span_p), [=](crate::check::types::St unify_f_13313) { return prism_rtl::finished(std::tuple{unify_f_13313, crate::prelude::push(done_p15, i_p16)}); })
                            : crate::prelude::call_then(crate::check::types::start_stack_of_f(s_p14, at_p18), [=](Text stack_of_f_13382) {
                            return (stack_of_f_13382 != Text::lit("")) || crate::check::types::is_free_headed_f(s_p14, at_p18)
                                ? prism_rtl::finished(std::tuple{s_p14, done_p15})
                                : crate::prelude::call_then(start_arg_or_unpack_f(env_p0xxy, s_p14, fname_p2xxy, crate::prelude::or_(crate::prelude::index(params_p4xxy, i_p16), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), pnow_p19, at_p18, a_p17, res_p5xxy, span_p7xxy), [=](crate::check::types::St arg_or_unpack_f_13457) { return prism_rtl::finished(std::tuple{arg_or_unpack_f_13457, done_p15}); });
                        }));
                        });
                    }));
                    });
                }));
                });
                });
            })));
            });
        }));
        })), [=](std::tuple<crate::check::types::St, Array<Nat>> fold_12904) {
            return ({
                auto [st2_p1b, whole_p1c] = fold_12904;
                (crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(n_p8), std::tuple{Map<Unit, Unit>{}, st2_p1b}, ({
                auto args_p6xx = args_p6x;
                auto span_p7xx = span_p7x;
                auto params_p4xx = params_p4x;
                auto env_p0xx = env_p0x;
                auto fname_p2xx = fname_p2x;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Unit, Unit>, crate::check::types::St>>(std::tuple<std::tuple<Map<Unit, Unit>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, args_p6xx = std::move(args_p6xx), span_p7xx = std::move(span_p7xx), params_p4xx = std::move(params_p4xx), env_p0xx = std::move(env_p0xx), fname_p2xx = std::move(fname_p2xx)](std::tuple<std::tuple<Map<Unit, Unit>, crate::check::types::St>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto args_p6xxy = args_p6xx;
                    auto span_p7xxy = span_p7xx;
                    auto params_p4xxy = params_p4xx;
                    auto env_p0xxy = env_p0xx;
                    auto fname_p2xxy = fname_p2xx;
                    (crate::prelude::entered(crate::prelude::once_job([=, args_p6xxy = std::move(args_p6xxy), span_p7xxy = std::move(span_p7xxy), params_p4xxy = std::move(params_p4xxy), env_p0xxy = std::move(env_p0xxy), fname_p2xxy = std::move(fname_p2xxy)]() {
                    return ({
                        auto [m_p1d, s_p1e] = p0;
                        auto i_p1f = p1;
                        ({
                        auto a_p1g = crate::prelude::or_(crate::prelude::index(args_p6xxy, i_p1f), crate::syntax::Arg{.name_o = std::optional<crate::syntax::Ident>{}, .value_p = crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span_p = span_p7xxy}, .span_p = span_p7xxy});
                        (crate::check::expr::is_lambda_f(prism_rtl::deref(a_p1g).value_p)
                        ? crate::prelude::call_then(crate::check::types::recording::start_walk_f(s_p1e, crate::prelude::or_(crate::prelude::index(params_p4xxy, i_p1f), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::check::types::Ty walk_f_13748) {
                        return ({
                            auto p_p1h = walk_f_13748;
                            (crate::prelude::call_then(start_infer_lambda_f(env_p0xxy, s_p1e, prism_rtl::deref(a_p1g).value_p, std::optional(p_p1h)), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_lambda_f_13807) {
                            return ({
                                auto [lt_p1j, s2_p1k] = infer_lambda_f_13807;
                                auto s3_p1i = ({
                                    __label__ _done;
                                    prism_rtl::Slot<crate::check::types::St> _v;
                                    auto&& _m = std::tuple{p_p1h, lt_p1j};
                                    if (prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<1>(_m))) {
                                        auto&& pc_p1l = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<0>(_m)).a0;
                                        auto&& lc_p1m = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a0;
                                        auto&& lps_p1n = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a1;
                                        auto&& lr_p1o = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a2;
                                        _v.set(crate::check::types::colors::add_leq_f(crate::check::types::unify::unify_f(crate::check::types::recording::note_ty_f(s2_p1k, prism_rtl::deref(prism_rtl::deref(a_p1g).value_p).span_p, lt_p1j), p_p1h, crate::check::types::Ty(crate::check::types::Ty::TyFn{pc_p1l, lps_p1n, prism_rtl::rc(prism_rtl::deref(lr_p1o))}), prism_rtl::deref(prism_rtl::deref(a_p1g).value_p).span_p), lc_p1m, pc_p1l, prism_rtl::deref(prism_rtl::deref(a_p1g).value_p).span_p, Text::lit("arg"), fname_p2xxy, Text::lit("")));
                                        goto _done;
                                    }
                                    {
                                        _v.set(crate::check::types::unify::unify_f(crate::check::types::recording::note_ty_f(s2_p1k, prism_rtl::deref(prism_rtl::deref(a_p1g).value_p).span_p, lt_p1j), p_p1h, lt_p1j, prism_rtl::deref(prism_rtl::deref(a_p1g).value_p).span_p));
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                });
                                (prism_rtl::finished(std::tuple{m_p1d, s3_p1i}));
                            });
                        }));
                        });
                    })
                        : prism_rtl::finished(std::tuple{m_p1d, s_p1e}));
                    });
                    });
                })));
                });
            }));
            })), [=](std::tuple<Map<Unit, Unit>, crate::check::types::St> fold_13565) {
                return ({
                    auto&& _st3_p1p = fold_13565;
                    auto&& st3_p1p = std::get<1>(_st3_p1p);
                    (crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(n_p8), std::tuple{Peeled{.events_p = Array<crate::syntax::Range>{}, .dyns_p = Array<crate::syntax::Range>{}, .opts_p = Array<Text>{}, .opt_args_p = Array<crate::syntax::Range>{}, .lifted_p = Text::lit(""), .broken_p = false}, st3_p1p}, ({
                    auto args_p6xx = args_p6x;
                    auto span_p7xx = span_p7x;
                    auto arg_tys_p12x = arg_tys_p12;
                    auto whole_p1cx = whole_p1c;
                    auto env_p0xx = env_p0x;
                    auto fname_p2xx = fname_p2x;
                    auto cmp_p9x = cmp_p9;
                    auto params_p4xx = params_p4x;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Peeled, crate::check::types::St>>(std::tuple<std::tuple<Peeled, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, args_p6xx = std::move(args_p6xx), span_p7xx = std::move(span_p7xx), arg_tys_p12x = std::move(arg_tys_p12x), whole_p1cx = std::move(whole_p1cx), env_p0xx = std::move(env_p0xx), fname_p2xx = std::move(fname_p2xx), cmp_p9x = std::move(cmp_p9x), params_p4xx = std::move(params_p4xx)](std::tuple<std::tuple<Peeled, crate::check::types::St>, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto args_p6xxy = args_p6xx;
                        auto span_p7xxy = span_p7xx;
                        auto arg_tys_p12xy = arg_tys_p12x;
                        auto whole_p1cxy = whole_p1cx;
                        auto env_p0xxy = env_p0xx;
                        auto fname_p2xxy = fname_p2xx;
                        auto cmp_p9xy = cmp_p9x;
                        auto params_p4xxy = params_p4xx;
                        (crate::prelude::entered(crate::prelude::once_job([=, args_p6xxy = std::move(args_p6xxy), span_p7xxy = std::move(span_p7xxy), arg_tys_p12xy = std::move(arg_tys_p12xy), whole_p1cxy = std::move(whole_p1cxy), env_p0xxy = std::move(env_p0xxy), fname_p2xxy = std::move(fname_p2xxy), cmp_p9xy = std::move(cmp_p9xy), params_p4xxy = std::move(params_p4xxy)]() {
                        return ({
                            auto [acc_p1q, s_p1r] = p0;
                            auto i_p1s = p1;
                            ({
                            auto a_p1t = crate::prelude::or_(crate::prelude::index(args_p6xxy, i_p1s), crate::syntax::Arg{.name_o = std::optional<crate::syntax::Ident>{}, .value_p = crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span_p = span_p7xxy}, .span_p = span_p7xxy});
                            auto at_p1u = crate::prelude::or_(crate::prelude::index(arg_tys_p12xy, i_p1s), crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
                            (crate::check::expr::is_lambda_f(prism_rtl::deref(a_p1t).value_p) || crate::check::types::has_nat_f(whole_p1cxy, i_p1s)) || ((crate::check::types::stack_of_f(s_p1r, at_p1u) == Text::lit("")) && (!crate::check::types::is_free_headed_f(s_p1r, at_p1u)))
                            ? prism_rtl::finished(std::tuple{acc_p1q, s_p1r})
                            : ({
                            auto before_p1v = crate::prelude::len(prism_rtl::deref(s_p1r).diags_p);
                            (crate::prelude::call_then(start_layered_arg_f(env_p0xxy, s_p1r, acc_p1q, fname_p2xxy, cmp_p9xy, crate::prelude::or_(crate::prelude::index(params_p4xxy, i_p1s), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), at_p1u, a_p1t), [=, before_p1v = std::move(before_p1v)](std::tuple<Peeled, crate::check::types::St> layered_arg_f_14672) {
                            return ({
                                auto [acc2_p21, s2_p22] = layered_arg_f_14672;
                                auto broke_p20 = (crate::prelude::len(prism_rtl::deref(s2_p22).diags_p) > before_p1v) && crate::prelude::fold(crate::prelude::drop(prism_rtl::deref(s2_p22).diags_p, before_p1v), false, [&](const bool& seen_p23, const crate::check::errors::CDiag& d_p24) { return prism_rtl::deref(seen_p23) || crate::check::types::has_text_f(Array(std::vector{Text::lit("two-layers"), Text::lit("layer-under-optional"), Text::lit("blueprint-operand")}), prism_rtl::deref(d_p24).code_p); });
                                (prism_rtl::finished(std::tuple{broken_f(acc2_p21, broke_p20), s2_p22}));
                            });
                        }));
                        });
                        });
                        });
                    })));
                    });
                }));
                })), [=](std::tuple<Peeled, crate::check::types::St> fold_14220) {
                    return ({
                        auto [pl_p25, st4_p26] = fold_14220;
                        auto st5_pa = crate::prelude::len(prism_rtl::deref(pl_p25).events_p) > Nat(1u)
                            ? crate::check::types::recording::err_fix_f(st4_p26, Text::lit("two-events"), crate::prelude::or_(crate::prelude::index(prism_rtl::deref(pl_p25).events_p, Nat(1u)), span_p7x), Text::lit("two events in one operation"), Text::lit("merge them with `<|`, or hold one first, `$last <- 0 then !b`"))
                            : st4_p26;
                        auto st6_pb = crate::prelude::len(prism_rtl::deref(pl_p25).opts_p) > Nat(1u)
                            ? crate::check::types::recording::err_f(st5_pa, Text::lit("optional-and-fault"), span_p7x, Text::lit("`?` and `~` in one operation"))
                            : st5_pa;
                        auto layer_pc = crate::prelude::len(prism_rtl::deref(pl_p25).events_p) > Nat(0u)
                            ? Text::lit("!")
                            : crate::prelude::len(prism_rtl::deref(pl_p25).dyns_p) > Nat(0u)
                            ? Text::lit("$")
                            : Text::lit("");
                        auto with_opt_pd = ({
                            __label__ _done;
                            prism_rtl::Slot<crate::check::types::Ty> _v;
                            auto&& _m = crate::prelude::index(prism_rtl::deref(pl_p25).opts_p, Nat(0u));
                            if (prism_rtl::is_some(_m)) {
                                auto&& o_p27 = prism_rtl::some_of(_m);
                                _v.set(crate::check::types::Ty(crate::check::types::Ty::TySig{o_p27, prism_rtl::rc(res_p5x)}));
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(res_p5x);
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        });
                        auto result_pe = prism_rtl::deref(pl_p25).broken_p
                            ? crate::check::types::Ty(crate::check::types::Ty::TyErr{})
                            : layer_pc == Text::lit("")
                            ? with_opt_pd
                            : crate::check::types::Ty(crate::check::types::Ty::TySig{layer_pc, prism_rtl::rc(with_opt_pd)});
                        (crate::prelude::call_then(crate::check::types::colors::start_walk_col_f(st6_pb, col_p3x), [=, layer_pc = std::move(layer_pc), result_pe = std::move(result_pe)](crate::check::types::Col walk_col_f_15720) {
                        return ({
                            auto call_col_pf = walk_col_f_15720;
                            auto st7_pg = (layer_pc != Text::lit("")) && crate::check::types::colors::is_flex_col_f(call_col_pf)
                                ? crate::check::types::colors::add_leq_f(st6_pb, call_col_pf, crate::check::types::Col(crate::check::types::Col::CBound{}), span_p7x, Text::lit("lifted"), fname_p2x, prism_rtl::deref(pl_p25).lifted_p)
                                : st6_pb;
                            auto lifted_bad_ph = ((layer_pc != Text::lit("")) && (call_col_pf != crate::check::types::Col(crate::check::types::Col::CBound{}))) && (!crate::check::types::colors::is_flex_col_f(call_col_pf));
                            auto st8_pi = std::move(lifted_bad_ph)
                                ? crate::check::types::recording::err_fix_f(st7_pg, Text::lit("lifted-unbounded"), span_p7x, prism_rtl::cat(crate::check::types::colors::col_word_f(call_col_pf), " `", fname_p2x, "` lifted over `", prism_rtl::deref(pl_p25).lifted_p, "`; use `@Run`"), prism_rtl::cat("run it through `!done <- @Run ", fname_p2x, ", ...`"))
                                : st7_pg;
                            (crate::prelude::call_then(crate::check::types::colors::start_use_color_f(st8_pi, call_col_pf, fname_p2x, span_p7x), [=](crate::check::types::St use_color_f_16150) {
                            return ({
                                auto st9_pj = use_color_f_16150;
                                auto kind_pk = (layer_pc == Text::lit("!")) && (crate::prelude::len(prism_rtl::deref(pl_p25).dyns_p) > Nat(0u))
                                    ? Text::lit("sample")
                                    : layer_pc != Text::lit("")
                                    ? Text::lit("map")
                                    : fname_p2x == Text::lit("$") ? Text::lit("const") : Text::lit("plain");
                                auto peeled_pl = crate::prelude::append(prism_rtl::deref(pl_p25).events_p, prism_rtl::deref(pl_p25).dyns_p);
                                auto lifted_pm = crate::prelude::filter(crate::check::errors::range0_f(n_p8), [&](const Nat& i_p28) { return has_range_f(peeled_pl, prism_rtl::deref(prism_rtl::deref(crate::prelude::or_(crate::prelude::index(args_p6x, i_p28), crate::syntax::Arg{.name_o = std::optional<crate::syntax::Ident>{}, .value_p = crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span_p = span_p7x}, .span_p = span_p7x})).value_p).span_p); });
                                auto st10_pn = prism_rtl::deref(pl_p25).broken_p || (crate::prelude::len(prism_rtl::deref(pl_p25).opts_p) != Nat(1u))
                                    ? st9_pj
                                    : crate::check::types::recording::note_lift_f(st9_pj, span_p7x, crate::prelude::or_(crate::prelude::index(prism_rtl::deref(pl_p25).opts_p, Nat(0u)), Text::lit("")), prism_rtl::deref(pl_p25).opt_args_p);
                                (prism_rtl::finished(std::tuple{result_pe, crate::check::types::recording::note_app_f(st10_pn, span_p7x, fname_p2x, kind_pk, layer_pc, lifted_pm, crate::prelude::or_(crate::prelude::index(prism_rtl::deref(pl_p25).opts_p, Nat(0u)), Text::lit("")), call_col_pf)}));
                            });
                        }));
                        });
                    }));
                    });
                }));
                });
            }));
            });
        }));
        });
    });
}


/// `Start ApplyRule, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_apply_rule_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text fname_p2, crate::check::types::Col col_p3, Array<crate::check::types::Ty> params_p4, crate::check::types::Ty res_p5, Array<crate::syntax::Arg> args_p6, crate::syntax::Range span_p7) {
    return prism_rtl::make_rc<ApplyRule>(env_p0, st_p1, fname_p2, col_p3, params_p4, res_p5, args_p6, span_p7);
}


/// ArgOrUnpack: unbounded fn Env, St, Text, Ty, Ty, Ty, Arg, Ty, Range -> St
crate::check::types::St arg_or_unpack_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Text& fname_p2, const crate::check::types::Ty& param_p3, const crate::check::types::Ty& pnow_p4, const crate::check::types::Ty& at_p5, const crate::syntax::Arg& a_p6, const crate::check::types::Ty& res_p7, const crate::syntax::Range& span_p8) {
    auto&& _m = crate::check::types::recording::walk_f(st_p1, at_p5);
    if (prism_rtl::is<crate::check::types::Ty::TyAny>(_m)) {
        auto&& bounds_p9 = prism_rtl::as<crate::check::types::Ty::TyAny>(_m).a0;
        if (prism_rtl::is<crate::check::types::Ty::TyFlex>(pnow_p4)) {
            auto&& n_pa = prism_rtl::as<crate::check::types::Ty::TyFlex>(pnow_p4).a0;
            auto hidden_pb = prism_rtl::cat("e\'", st_p1.next_p);
            auto st2_pc = ({
                crate::check::types::St this_ = st_p1;
                this_.next_p = this_.next_p + Nat(1u);
                this_.any_givens_p = crate::prelude::append(this_.any_givens_p, crate::prelude::each(bounds_p9, [&](const Text& b_pe) { return std::tuple{hidden_pb, b_pe}; }));
                (std::move(this_));
            });
            auto st3_pd = crate::check::types::unify::unify_f(st2_pc, pnow_p4, crate::check::types::Ty(crate::check::types::Ty::TyRigid{hidden_pb}), prism_rtl::deref(a_p6.value_p).span_p);
            return crate::check::types::has_nat_f(crate::check::types::recording::free_vars_f(st_p1, res_p7), n_pa)
                ? crate::check::types::recording::err_f(st3_pd, Text::lit("existential-escape"), span_p8, prism_rtl::cat("the type hidden in `", crate::check::types::show_ty_f(st_p1, at_p5), "` would leave it here"))
                : st3_pd;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyRigid>(pnow_p4)) {
            auto&& r_pf = prism_rtl::as<crate::check::types::Ty::TyRigid>(pnow_p4).a0;
            if (crate::syntax::lexer::chars::has_prefix_f(r_pf, Text::lit("e\'"))) {
                return crate::check::types::recording::err_f(st_p1, Text::lit("mismatch"), prism_rtl::deref(a_p6.value_p).span_p, prism_rtl::cat("two existentials meet here, each `", crate::check::types::show_ty_f(st_p1, at_p5), "` hiding a type of its own"));
            }
        }
        {
            return plain_arg_f(env_p0, st_p1, fname_p2, param_p3, at_p5, a_p6);
        }
    }
    {
        return plain_arg_f(env_p0, st_p1, fname_p2, param_p3, at_p5, a_p6);
    }
}


prism_rtl::Turn<crate::check::types::St> ArgOrUnpack::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& fname_p2 = this->fname_p2;
    const auto& param_p3 = this->param_p3;
    const auto& pnow_p4 = this->pnow_p4;
    const auto& at_p5 = this->at_p5;
    const auto& a_p6 = this->a_p6;
    const auto& res_p7 = this->res_p7;
    const auto& span_p8 = this->span_p8;
    auto a_p6x = a_p6;
    auto at_p5x = at_p5;
    auto env_p0x = env_p0;
    auto fname_p2x = fname_p2;
    auto param_p3x = param_p3;
    auto pnow_p4x = pnow_p4;
    auto res_p7x = res_p7;
    auto span_p8x = span_p8;
    auto st_p1x = st_p1;
    return crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x, at_p5x), [=](crate::check::types::Ty walk_f_17303) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyAny>(walk_f_17303) ? ({
            auto&& bounds_p9 = prism_rtl::as<crate::check::types::Ty::TyAny>(walk_f_17303).a0;
            ({
            prism_rtl::is<crate::check::types::Ty::TyFlex>(pnow_p4x) ? ({
            auto&& n_pa = prism_rtl::as<crate::check::types::Ty::TyFlex>(pnow_p4x).a0;
            ({
            auto hidden_pb = prism_rtl::cat("e\'", prism_rtl::deref(st_p1x).next_p);
            auto st2_pc = ({
                crate::check::types::St this_ = st_p1x;
                this_.next_p = this_.next_p + Nat(1u);
                this_.any_givens_p = crate::prelude::append(this_.any_givens_p, crate::prelude::each(bounds_p9, [&](const Text& b_pe) { return std::tuple{hidden_pb, b_pe}; }));
                (std::move(this_));
            });
            auto n_pax = n_pa;
            (crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_pc, pnow_p4x, crate::check::types::Ty(crate::check::types::Ty::TyRigid{hidden_pb}), prism_rtl::deref(prism_rtl::deref(a_p6x).value_p).span_p), [=, n_pax = std::move(n_pax)](crate::check::types::St unify_f_17574) {
            return ({
                auto st3_pd = unify_f_17574;
                (crate::prelude::call_then(crate::check::types::recording::start_free_vars_f(st_p1x, res_p7x), [=, st3_pd = std::move(st3_pd)](Array<Nat> free_vars_f_17645) {
                return crate::check::types::has_nat_f(free_vars_f_17645, n_pax)
                    ? crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x, at_p5x), [=](Text show_ty_f_17726) { return prism_rtl::finished(crate::check::types::recording::err_f(st3_pd, Text::lit("existential-escape"), span_p8x, prism_rtl::cat("the type hidden in `", show_ty_f_17726, "` would leave it here"))); })
                    : prism_rtl::finished(st3_pd);
            }));
            });
        }));
        });
        })
            : prism_rtl::is<crate::check::types::Ty::TyRigid>(pnow_p4x) && ({
            auto&& r_pf = prism_rtl::as<crate::check::types::Ty::TyRigid>(pnow_p4x).a0;
            crate::syntax::lexer::chars::has_prefix_f(r_pf, Text::lit("e\'"));
        }) ? ({
            auto&& r_pf = prism_rtl::as<crate::check::types::Ty::TyRigid>(pnow_p4x).a0;
            crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x, at_p5x), [=](Text show_ty_f_17895) { return prism_rtl::finished(crate::check::types::recording::err_f(st_p1x, Text::lit("mismatch"), prism_rtl::deref(prism_rtl::deref(a_p6x).value_p).span_p, prism_rtl::cat("two existentials meet here, each `", show_ty_f_17895, "` hiding a type of its own"))); });
        })
            : prism_rtl::more(prism_rtl::rc(PlainArg(env_p0x, st_p1x, fname_p2x, param_p3x, at_p5x, a_p6x)));
        });
        })
            : prism_rtl::more(prism_rtl::rc(PlainArg(env_p0x, st_p1x, fname_p2x, param_p3x, at_p5x, a_p6x)));
        });
    });
}


/// `Start ArgOrUnpack, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_arg_or_unpack_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text fname_p2, crate::check::types::Ty param_p3, crate::check::types::Ty pnow_p4, crate::check::types::Ty at_p5, crate::syntax::Arg a_p6, crate::check::types::Ty res_p7, crate::syntax::Range span_p8) {
    return prism_rtl::make_rc<ArgOrUnpack>(env_p0, st_p1, fname_p2, param_p3, pnow_p4, at_p5, a_p6, res_p7, span_p8);
}


/// HasRange: fn [Range], Range -> Bool
bool has_range_f(const Array<crate::syntax::Range>& rs_p0, const crate::syntax::Range& r_p1) {
    return crate::prelude::fold(rs_p0, false, [&](const bool& seen_p2, const crate::syntax::Range& x_p3) { return prism_rtl::deref(seen_p2) || (x_p3 == r_p1); });
}


/// Elab: fn St, Range, Text, Text, Text -> St
crate::check::types::St elab_f(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const Text& what_p2, const Text& kind_p3, const Text& layer_p4) {
    return crate::check::types::recording::note_app_f(st_p0, span_p1, what_p2, kind_p3, layer_p4, Array<Nat>{}, Text::lit(""), crate::check::types::Col(crate::check::types::Col::CBound{}));
}


/// PlainArg: unbounded fn Env, St, Text, Ty, Ty, Arg -> St
crate::check::types::St plain_arg_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Text& fname_p2, const crate::check::types::Ty& param_p3, const crate::check::types::Ty& at_p4, const crate::syntax::Arg& a_p5) {
    auto p_p6 = crate::check::types::recording::walk_f(st_p1, param_p3);
    auto ph_p7 = crate::check::types::head_sigil_f(st_p1, p_p6);
    return at_p4 == crate::check::types::Ty(crate::check::types::Ty::TyErr{})
        ? st_p1
        : crate::check::expr::is_time_sigil_f(ph_p7) || (ph_p7 == Text::lit("@"))
        ? ({
        auto shown_p8 = crate::check::types::is_flex_var_f(st_p1, at_p4)
            ? crate::check::expr::src_text_f(env_p0, prism_rtl::deref(a_p5.value_p).span_p)
            : crate::check::types::show_ty_f(st_p1, at_p4);
        (crate::check::types::recording::err_fix_f(st_p1, Text::lit("plain-for-sigiled"), prism_rtl::deref(a_p5.value_p).span_p, prism_rtl::cat("a plain `", shown_p8, "` where `", fname_p2, "` takes a `", crate::check::types::show_ty_f(st_p1, p_p6), "`"), prism_rtl::cat("write `", ph_p7, " ", crate::check::expr::src_text_f(env_p0, prism_rtl::deref(a_p5.value_p).span_p), "`")));
    })
        : crate::check::types::unify::unify_f(st_p1, p_p6, at_p4, prism_rtl::deref(a_p5.value_p).span_p);
}


prism_rtl::Turn<crate::check::types::St> PlainArg::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& fname_p2 = this->fname_p2;
    const auto& param_p3 = this->param_p3;
    const auto& at_p4 = this->at_p4;
    const auto& a_p5 = this->a_p5;
    auto a_p5x = a_p5;
    auto at_p4x = at_p4;
    auto env_p0x = env_p0;
    auto fname_p2x = fname_p2;
    auto param_p3x = param_p3;
    auto st_p1x = st_p1;
    return crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x, param_p3x), [=](crate::check::types::Ty walk_f_18708) {
        return ({
            auto p_p6 = walk_f_18708;
            (crate::prelude::call_then(crate::check::types::start_head_sigil_f(st_p1x, p_p6), [=](Text head_sigil_f_18736) {
            return ({
                auto ph_p7 = head_sigil_f_18736;
                at_p4x == crate::check::types::Ty(crate::check::types::Ty::TyErr{})
                ? prism_rtl::finished(st_p1x)
                : crate::check::expr::is_time_sigil_f(ph_p7) || (ph_p7 == Text::lit("@"))
                ? crate::prelude::call_then(crate::check::types::start_is_flex_var_f(st_p1x, at_p4x), [=](bool is_flex_var_f_18842) {
                return ({
                    auto shown_p8 = is_flex_var_f_18842
                        ? crate::check::expr::src_text_f(env_p0x, prism_rtl::deref(prism_rtl::deref(a_p5x).value_p).span_p)
                        : crate::check::types::show_ty_f(st_p1x, at_p4x);
                    (crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x, p_p6), [=, shown_p8 = std::move(shown_p8)](Text show_ty_f_19005) { return prism_rtl::finished(crate::check::types::recording::err_fix_f(st_p1x, Text::lit("plain-for-sigiled"), prism_rtl::deref(prism_rtl::deref(a_p5x).value_p).span_p, prism_rtl::cat("a plain `", shown_p8, "` where `", fname_p2x, "` takes a `", show_ty_f_19005, "`"), prism_rtl::cat("write `", ph_p7, " ", crate::check::expr::src_text_f(env_p0x, prism_rtl::deref(prism_rtl::deref(a_p5x).value_p).span_p), "`"))); }));
                });
            })
                : prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st_p1x, p_p6, at_p4x, prism_rtl::deref(prism_rtl::deref(a_p5x).value_p).span_p)));
            });
        }));
        });
    });
}


/// `Start PlainArg, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_plain_arg_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text fname_p2, crate::check::types::Ty param_p3, crate::check::types::Ty at_p4, crate::syntax::Arg a_p5) {
    return prism_rtl::make_rc<PlainArg>(env_p0, st_p1, fname_p2, param_p3, at_p4, a_p5);
}


/// LayeredArg: unbounded fn Env, St, Peeled, Text, Bool, Ty, Ty, Arg -> ((Peeled, St))
std::tuple<Peeled, crate::check::types::St> layered_arg_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Peeled& acc_p2, const Text& fname_p3, const bool& cmp_p4, const crate::check::types::Ty& param_p5, const crate::check::types::Ty& at_p6, const crate::syntax::Arg& a_p7) {
    auto p_p8 = crate::check::types::recording::walk_f(st_p1, param_p5);
    auto span_p9 = prism_rtl::deref(a_p7.value_p).span_p;
    auto ph_pa = crate::check::types::head_sigil_f(st_p1, p_p8);
    return crate::check::types::is_free_headed_f(st_p1, at_p6)
        ? ({
        auto st2_pb = ((crate::check::expr::is_time_sigil_f(ph_pa) || (ph_pa == Text::lit("@"))) || (ph_pa == Text::lit("&"))) || cmp_p4
            ? st_p1
            : crate::check::types::unify::ask_layer_f(st_p1, at_p6, span_p9, fname_p3);
        std::tuple{acc_p2, crate::check::types::unify::unify_f(st2_pb, p_p8, at_p6, span_p9)};
    })
        : (crate::check::expr::is_time_sigil_f(ph_pa) || (ph_pa == Text::lit("@"))) || (ph_pa == Text::lit("&"))
        ? std::tuple{acc_p2, crate::check::types::unify::unify_f(st_p1, p_p8, at_p6, span_p9)}
        : crate::check::expr::is_plain_sigil_f(ph_pa)
        ? peel_time_only_f(env_p0, st_p1, acc_p2, fname_p3, p_p8, at_p6, a_p7)
        : ({
        auto head_pc = crate::check::types::head_sigil_f(st_p1, at_p6);
        head_pc == Text::lit("@")
        ? std::tuple{acc_p2, crate::check::types::recording::err_fix_f(st_p1, Text::lit("blueprint-operand"), span_p9, prism_rtl::cat("`", fname_p3, "` over a blueprint; bind it first"), prism_rtl::cat("bind it, `x <- ", crate::check::expr::src_text_f(env_p0, span_p9), "`, and use `x`"))}
        : crate::check::expr::is_time_sigil_f(head_pc)
        ? ({
        auto inner_pd = crate::check::expr::inner_of_f(st_p1, at_p6);
        auto ih_pe = crate::check::types::head_sigil_f(st_p1, inner_pd);
        auto acc2_pf = ({
            Peeled this_ = acc_p2;
            if (head_pc == Text::lit("!")) {
                this_.events_p = crate::prelude::push(this_.events_p, span_p9);
            } else  {
                this_.dyns_p = crate::prelude::push(this_.dyns_p, span_p9);
            }
            if (this_.lifted_p == Text::lit("")) {
                this_.lifted_p = crate::check::expr::src_text_f(env_p0, span_p9);
            }
            (std::move(this_));
        });
        crate::check::expr::is_time_sigil_f(ih_pe)
        ? ({
        auto what_pg = ih_pe == Text::lit("$") ? Text::lit("dynamic") : Text::lit("event");
        std::tuple{acc2_pf, crate::check::types::recording::err_fix_f(st_p1, Text::lit("two-layers"), span_p9, prism_rtl::cat("`", fname_p3, "` over a ", head_pc == Text::lit("$") ? Text::lit("dynamic") : Text::lit("event"), " of ", what_pg, "s"), Text::lit("take one layer off with a binding first: `@Flatten` or `@Switch`"))};
    })
        : crate::check::expr::is_plain_sigil_f(ih_pe) && (!cmp_p4)
        ? ({
        auto inner2_ph = crate::check::expr::inner_of_f(st_p1, inner_pd);
        (crate::check::expr::is_time_sigil_f(crate::check::types::head_sigil_f(st_p1, inner2_ph)) || (crate::check::types::head_sigil_f(st_p1, inner2_ph) == Text::lit("@"))
        ? std::tuple{acc2_pf, crate::check::types::recording::err_f(st_p1, Text::lit("layer-under-optional"), span_p9, prism_rtl::cat("`", fname_p3, "` over an optional ", ih_pe == Text::lit("?") ? Text::lit("") : Text::lit("fault "), "dynamic"))}
        : ({
        auto acc3_pi = ({
            Peeled this_ = acc2_pf;
            this_.opts_p = crate::check::types::add_text_f(this_.opts_p, ih_pe);
            this_.opt_args_p = crate::prelude::push(this_.opt_args_p, span_p9);
            (std::move(this_));
        });
        std::tuple{acc3_pi, crate::check::types::unify::unify_f(st_p1, p_p8, inner2_ph, span_p9)};
    }));
    })
        : std::tuple{acc2_pf, crate::check::types::unify::unify_f(st_p1, p_p8, inner_pd, span_p9)};
    })
        : crate::check::expr::is_plain_sigil_f(head_pc) && (!cmp_p4)
        ? ({
        auto inner_pj = crate::check::expr::inner_of_f(st_p1, at_p6);
        auto ih_pk = crate::check::types::head_sigil_f(st_p1, inner_pj);
        (crate::check::expr::is_time_sigil_f(ih_pk) || (ih_pk == Text::lit("@"))
        ? std::tuple{acc_p2, crate::check::types::recording::err_fix_f(st_p1, Text::lit("layer-under-optional"), span_p9, prism_rtl::cat("`", fname_p3, "` over an optional dynamic"), Text::lit("match the optional once, at build time, to find out whether there is a dynamic"))}
        : ({
        auto acc2_pl = ({
            Peeled this_ = acc_p2;
            this_.opts_p = crate::check::types::add_text_f(this_.opts_p, head_pc);
            this_.opt_args_p = crate::prelude::push(this_.opt_args_p, span_p9);
            (std::move(this_));
        });
        std::tuple{acc2_pl, crate::check::types::unify::unify_f(st_p1, p_p8, inner_pj, span_p9)};
    }));
    })
        : head_pc == Text::lit("&")
        ? std::tuple{acc_p2, crate::check::types::unify::unify_f(st_p1, p_p8, crate::check::expr::inner_of_f(st_p1, at_p6), span_p9)}
        : std::tuple{acc_p2, crate::check::types::unify::unify_f(st_p1, p_p8, at_p6, span_p9)};
    });
}


prism_rtl::Turn<std::tuple<Peeled, crate::check::types::St>> LayeredArg::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& acc_p2 = this->acc_p2;
    const auto& fname_p3 = this->fname_p3;
    const auto& cmp_p4 = this->cmp_p4;
    const auto& param_p5 = this->param_p5;
    const auto& at_p6 = this->at_p6;
    const auto& a_p7 = this->a_p7;
    auto a_p7x = a_p7;
    auto acc_p2x = acc_p2;
    auto at_p6x = at_p6;
    auto cmp_p4x = prism_rtl::deref(cmp_p4);
    auto env_p0x = env_p0;
    auto fname_p3x = fname_p3;
    auto param_p5x = param_p5;
    auto st_p1x = st_p1;
    return crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x, param_p5x), [=](crate::check::types::Ty walk_f_19317) {
        return ({
            auto p_p8 = walk_f_19317;
            auto span_p9 = prism_rtl::deref(prism_rtl::deref(a_p7x).value_p).span_p;
            (crate::prelude::call_then(crate::check::types::start_head_sigil_f(st_p1x, p_p8), [=, span_p9 = std::move(span_p9)](Text head_sigil_f_19373) {
            return ({
                auto ph_pa = head_sigil_f_19373;
                (crate::prelude::call_then(crate::check::types::start_is_free_headed_f(st_p1x, at_p6x), [=, ph_pa = std::move(ph_pa)](bool is_free_headed_f_19396) {
                return is_free_headed_f_19396
                    ? ({
                    auto st2_pb = ((crate::check::expr::is_time_sigil_f(ph_pa) || (ph_pa == Text::lit("@"))) || (ph_pa == Text::lit("&"))) || cmp_p4x
                        ? st_p1x
                        : crate::check::types::unify::ask_layer_f(st_p1x, at_p6x, span_p9, fname_p3x);
                    (crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_pb, p_p8, at_p6x, span_p9), [=](crate::check::types::St unify_f_19543) { return prism_rtl::finished(std::tuple{acc_p2x, unify_f_19543}); }));
                })
                    : (crate::check::expr::is_time_sigil_f(ph_pa) || (ph_pa == Text::lit("@"))) || (ph_pa == Text::lit("&"))
                    ? crate::prelude::call_then(crate::check::types::unify::start_unify_f(st_p1x, p_p8, at_p6x, span_p9), [=](crate::check::types::St unify_f_19634) { return prism_rtl::finished(std::tuple{acc_p2x, unify_f_19634}); })
                    : crate::check::expr::is_plain_sigil_f(ph_pa)
                    ? prism_rtl::more(prism_rtl::rc(PeelTimeOnly(env_p0x, st_p1x, acc_p2x, fname_p3x, p_p8, at_p6x, a_p7x)))
                    : crate::prelude::call_then(crate::check::types::start_head_sigil_f(st_p1x, at_p6x), [=](Text head_sigil_f_19761) {
                    return ({
                        auto head_pc = head_sigil_f_19761;
                        head_pc == Text::lit("@")
                        ? prism_rtl::finished(std::tuple{acc_p2x, crate::check::types::recording::err_fix_f(st_p1x, Text::lit("blueprint-operand"), span_p9, prism_rtl::cat("`", fname_p3x, "` over a blueprint; bind it first"), prism_rtl::cat("bind it, `x <- ", crate::check::expr::src_text_f(env_p0x, span_p9), "`, and use `x`"))})
                        : crate::check::expr::is_time_sigil_f(head_pc)
                        ? crate::prelude::call_then(crate::check::expr::start_inner_of_f(st_p1x, at_p6x), [=](crate::check::types::Ty inner_of_f_20006) {
                        return ({
                            auto inner_pd = inner_of_f_20006;
                            (crate::prelude::call_then(crate::check::types::start_head_sigil_f(st_p1x, inner_pd), [=](Text head_sigil_f_20042) {
                            return ({
                                auto ih_pe = head_sigil_f_20042;
                                auto acc2_pf = ({
                                    Peeled this_ = acc_p2x;
                                    if (head_pc == Text::lit("!")) {
                                        this_.events_p = crate::prelude::push(this_.events_p, span_p9);
                                    } else  {
                                        this_.dyns_p = crate::prelude::push(this_.dyns_p, span_p9);
                                    }
                                    if (this_.lifted_p == Text::lit("")) {
                                        this_.lifted_p = crate::check::expr::src_text_f(env_p0x, span_p9);
                                    }
                                    (std::move(this_));
                                });
                                (crate::check::expr::is_time_sigil_f(ih_pe)
                                ? ({
                                auto what_pg = ih_pe == Text::lit("$") ? Text::lit("dynamic") : Text::lit("event");
                                (prism_rtl::finished(std::tuple{acc2_pf, crate::check::types::recording::err_fix_f(st_p1x, Text::lit("two-layers"), span_p9, prism_rtl::cat("`", fname_p3x, "` over a ", head_pc == Text::lit("$") ? Text::lit("dynamic") : Text::lit("event"), " of ", what_pg, "s"), Text::lit("take one layer off with a binding first: `@Flatten` or `@Switch`"))}));
                            })
                                : crate::check::expr::is_plain_sigil_f(ih_pe) && (!cmp_p4x)
                                ? crate::prelude::call_then(crate::check::expr::start_inner_of_f(st_p1x, inner_pd), [=](crate::check::types::Ty inner_of_f_20718) {
                                return ({
                                    auto inner2_ph = inner_of_f_20718;
                                    (crate::prelude::call_then(crate::check::types::start_head_sigil_f(st_p1x, inner2_ph), [=](Text head_sigil_f_20769) {
                                    return crate::check::expr::is_time_sigil_f(head_sigil_f_20769) || (crate::check::types::head_sigil_f(st_p1x, inner2_ph) == Text::lit("@"))
                                        ? prism_rtl::finished(std::tuple{acc2_pf, crate::check::types::recording::err_f(st_p1x, Text::lit("layer-under-optional"), span_p9, prism_rtl::cat("`", fname_p3x, "` over an optional ", ih_pe == Text::lit("?") ? Text::lit("") : Text::lit("fault "), "dynamic"))})
                                        : ({
                                        auto acc3_pi = ({
                                            Peeled this_ = acc2_pf;
                                            this_.opts_p = crate::check::types::add_text_f(this_.opts_p, ih_pe);
                                            this_.opt_args_p = crate::prelude::push(this_.opt_args_p, span_p9);
                                            (std::move(this_));
                                        });
                                        (crate::prelude::call_then(crate::check::types::unify::start_unify_f(st_p1x, p_p8, inner2_ph, span_p9), [=, acc3_pi = std::move(acc3_pi)](crate::check::types::St unify_f_21176) { return prism_rtl::finished(std::tuple{acc3_pi, unify_f_21176}); }));
                                    });
                                }));
                                });
                            })
                                : crate::prelude::call_then(crate::check::types::unify::start_unify_f(st_p1x, p_p8, inner_pd, span_p9), [=](crate::check::types::St unify_f_21232) { return prism_rtl::finished(std::tuple{acc2_pf, unify_f_21232}); }));
                            });
                        }));
                        });
                    })
                        : crate::check::expr::is_plain_sigil_f(head_pc) && (!cmp_p4x)
                        ? crate::prelude::call_then(crate::check::expr::start_inner_of_f(st_p1x, at_p6x), [=](crate::check::types::Ty inner_of_f_21334) {
                        return ({
                            auto inner_pj = inner_of_f_21334;
                            (crate::prelude::call_then(crate::check::types::start_head_sigil_f(st_p1x, inner_pj), [=](Text head_sigil_f_21370) {
                            return ({
                                auto ih_pk = head_sigil_f_21370;
                                (crate::check::expr::is_time_sigil_f(ih_pk) || (ih_pk == Text::lit("@"))
                                ? prism_rtl::finished(std::tuple{acc_p2x, crate::check::types::recording::err_fix_f(st_p1x, Text::lit("layer-under-optional"), span_p9, prism_rtl::cat("`", fname_p3x, "` over an optional dynamic"), Text::lit("match the optional once, at build time, to find out whether there is a dynamic"))})
                                : ({
                                auto acc2_pl = ({
                                    Peeled this_ = acc_p2x;
                                    this_.opts_p = crate::check::types::add_text_f(this_.opts_p, head_pc);
                                    this_.opt_args_p = crate::prelude::push(this_.opt_args_p, span_p9);
                                    (std::move(this_));
                                });
                                (crate::prelude::call_then(crate::check::types::unify::start_unify_f(st_p1x, p_p8, inner_pj, span_p9), [=, acc2_pl = std::move(acc2_pl)](crate::check::types::St unify_f_21814) { return prism_rtl::finished(std::tuple{acc2_pl, unify_f_21814}); }));
                            }));
                            });
                        }));
                        });
                    })
                        : head_pc == Text::lit("&")
                        ? crate::prelude::call_then(crate::check::expr::start_inner_of_f(st_p1x, at_p6x), [=](crate::check::types::Ty inner_of_f_21894) { return crate::prelude::call_then(crate::check::types::unify::start_unify_f(st_p1x, p_p8, inner_of_f_21894, span_p9), [=](crate::check::types::St unify_f_21880) { return prism_rtl::finished(std::tuple{acc_p2x, unify_f_21880}); }); })
                        : crate::prelude::call_then(crate::check::types::unify::start_unify_f(st_p1x, p_p8, at_p6x, span_p9), [=](crate::check::types::St unify_f_21941) { return prism_rtl::finished(std::tuple{acc_p2x, unify_f_21941}); });
                    });
                });
            }));
            });
        }));
        });
    });
}


/// `Start LayeredArg, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Peeled, crate::check::types::St>> start_layered_arg_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Peeled acc_p2, Text fname_p3, bool cmp_p4, crate::check::types::Ty param_p5, crate::check::types::Ty at_p6, crate::syntax::Arg a_p7) {
    return prism_rtl::make_rc<LayeredArg>(env_p0, st_p1, acc_p2, fname_p3, cmp_p4, param_p5, at_p6, a_p7);
}


/// PeelTimeOnly: unbounded fn Env, St, Peeled, Text, Ty, Ty, Arg -> ((Peeled, St))
std::tuple<Peeled, crate::check::types::St> peel_time_only_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Peeled& acc_p2, const Text& fname_p3, const crate::check::types::Ty& p_p4, const crate::check::types::Ty& at_p5, const crate::syntax::Arg& a_p6) {
    auto span_p7 = prism_rtl::deref(a_p6.value_p).span_p;
    auto head_p8 = crate::check::types::head_sigil_f(st_p1, at_p5);
    return head_p8 == Text::lit("@")
        ? std::tuple{acc_p2, crate::check::types::recording::err_fix_f(st_p1, Text::lit("blueprint-operand"), span_p7, prism_rtl::cat("`", fname_p3, "` over a blueprint; bind it first"), prism_rtl::cat("bind it, `x <- ", crate::check::expr::src_text_f(env_p0, span_p7), "`, and use `x`"))}
        : crate::check::expr::is_time_sigil_f(head_p8)
        ? ({
        auto inner_p9 = crate::check::expr::inner_of_f(st_p1, at_p5);
        auto acc2_pa = ({
            Peeled this_ = acc_p2;
            if (head_p8 == Text::lit("!")) {
                this_.events_p = crate::prelude::push(this_.events_p, span_p7);
            } else  {
                this_.dyns_p = crate::prelude::push(this_.dyns_p, span_p7);
            }
            if (this_.lifted_p == Text::lit("")) {
                this_.lifted_p = crate::check::expr::src_text_f(env_p0, span_p7);
            }
            (std::move(this_));
        });
        crate::check::expr::is_time_sigil_f(crate::check::types::head_sigil_f(st_p1, inner_p9))
        ? std::tuple{acc2_pa, crate::check::types::recording::err_fix_f(st_p1, Text::lit("two-layers"), span_p7, prism_rtl::cat("`", fname_p3, "` over a ", head_p8 == Text::lit("$") ? Text::lit("dynamic") : Text::lit("event"), " of ", crate::check::types::head_sigil_f(st_p1, inner_p9) == Text::lit("$")
        ? Text::lit("dynamic")
        : Text::lit("event"), "s"), Text::lit("take one layer off with a binding first: `@Flatten` or `@Switch`"))}
        : std::tuple{acc2_pa, crate::check::types::unify::unify_f(st_p1, p_p4, inner_p9, span_p7)};
    })
        : std::tuple{acc_p2, crate::check::types::unify::unify_f(st_p1, p_p4, at_p5, span_p7)};
}


prism_rtl::Turn<std::tuple<Peeled, crate::check::types::St>> PeelTimeOnly::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& acc_p2 = this->acc_p2;
    const auto& fname_p3 = this->fname_p3;
    const auto& p_p4 = this->p_p4;
    const auto& at_p5 = this->at_p5;
    const auto& a_p6 = this->a_p6;
    auto span_p7 = prism_rtl::deref(prism_rtl::deref(a_p6).value_p).span_p;
    auto a_p6x = a_p6;
    auto acc_p2x = acc_p2;
    auto at_p5x = at_p5;
    auto env_p0x = env_p0;
    auto fname_p3x = fname_p3;
    auto p_p4x = p_p4;
    auto st_p1x = st_p1;
    return crate::prelude::call_then(crate::check::types::start_head_sigil_f(st_p1x, at_p5x), [=](Text head_sigil_f_22227) {
        return ({
            auto head_p8 = head_sigil_f_22227;
            head_p8 == Text::lit("@")
            ? prism_rtl::finished(std::tuple{acc_p2x, crate::check::types::recording::err_fix_f(st_p1x, Text::lit("blueprint-operand"), span_p7, prism_rtl::cat("`", fname_p3x, "` over a blueprint; bind it first"), prism_rtl::cat("bind it, `x <- ", crate::check::expr::src_text_f(env_p0x, span_p7), "`, and use `x`"))})
            : crate::check::expr::is_time_sigil_f(head_p8)
            ? crate::prelude::call_then(crate::check::expr::start_inner_of_f(st_p1x, at_p5x), [=](crate::check::types::Ty inner_of_f_22460) {
            return ({
                auto inner_p9 = inner_of_f_22460;
                auto acc2_pa = ({
                    Peeled this_ = acc_p2x;
                    if (head_p8 == Text::lit("!")) {
                        this_.events_p = crate::prelude::push(this_.events_p, span_p7);
                    } else  {
                        this_.dyns_p = crate::prelude::push(this_.dyns_p, span_p7);
                    }
                    if (this_.lifted_p == Text::lit("")) {
                        this_.lifted_p = crate::check::expr::src_text_f(env_p0x, span_p7);
                    }
                    (std::move(this_));
                });
                (crate::prelude::call_then(crate::check::types::start_head_sigil_f(st_p1x, inner_p9), [=, acc2_pa = std::move(acc2_pa)](Text head_sigil_f_22751) {
                return crate::check::expr::is_time_sigil_f(head_sigil_f_22751)
                    ? crate::prelude::call_then(crate::check::types::start_head_sigil_f(st_p1x, inner_p9), [=](Text head_sigil_f_22881) {
                    return prism_rtl::finished(std::tuple{acc2_pa, crate::check::types::recording::err_fix_f(st_p1x, Text::lit("two-layers"), span_p7, prism_rtl::cat("`", fname_p3x, "` over a ", head_p8 == Text::lit("$") ? Text::lit("dynamic") : Text::lit("event"), " of ", head_sigil_f_22881 == Text::lit("$")
                        ? Text::lit("dynamic")
                        : Text::lit("event"), "s"), Text::lit("take one layer off with a binding first: `@Flatten` or `@Switch`"))});
                })
                    : crate::prelude::call_then(crate::check::types::unify::start_unify_f(st_p1x, p_p4x, inner_p9, span_p7), [=](crate::check::types::St unify_f_23031) { return prism_rtl::finished(std::tuple{acc2_pa, unify_f_23031}); });
            }));
            });
        })
            : crate::prelude::call_then(crate::check::types::unify::start_unify_f(st_p1x, p_p4x, at_p5x, span_p7), [=](crate::check::types::St unify_f_23077) { return prism_rtl::finished(std::tuple{acc_p2x, unify_f_23077}); });
        });
    });
}


/// `Start PeelTimeOnly, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Peeled, crate::check::types::St>> start_peel_time_only_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Peeled acc_p2, Text fname_p3, crate::check::types::Ty p_p4, crate::check::types::Ty at_p5, crate::syntax::Arg a_p6) {
    return prism_rtl::make_rc<PeelTimeOnly>(env_p0, st_p1, acc_p2, fname_p3, p_p4, at_p5, a_p6);
}


/// CtorApp: unbounded fn Env, St, CtorInfo, [Arg], Range, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> ctor_app_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::check::env::CtorInfo& c_p2, const Array<crate::syntax::Arg>& args_p3, const crate::syntax::Range& span_p4, const crate::syntax::Range& cspan_p5) {
    auto [self_p9, st0_pa, inst_pb] = crate::check::types::schemes::instantiate_with_f(st_p1, crate::check::types::Scheme{.qs_p = c_p2.params_p, .plain_qs_p = Array<Text>{}, .rqs_p = Array<Text>{}, .cqs_p = Array<Text>{}, .cjoins_p = Array<std::tuple<Text, Text>>{}, .bounds_p = Array<std::tuple<Text, Text>>{}, .ty_p = c_p2.ty_p}, span_p4, Array<crate::check::types::Ty>{});
    auto field_tys_p6 = crate::prelude::run_to_end(crate::prelude::each_job(c_p2.args_p, ({
        auto inst_pbx = inst_pb;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, inst_pbx = std::move(inst_pbx)](crate::check::types::Ty p0) {
        return ({
            auto inst_pbxy = inst_pbx;
            (crate::prelude::entered(crate::prelude::once_job([=, inst_pbxy = std::move(inst_pbxy)]() {
            return ({
                auto t_pc = p0;
                (prism_rtl::more(prism_rtl::rc(crate::check::types::schemes::SubstQ(inst_pbxy, t_pc))));
            });
        })));
        });
    })));
    })));
    auto st1_p7 = crate::check::types::recording::note_ty_f(st0_pa, cspan_p5, crate::check::types::Ty(crate::check::types::Ty::TyFn{crate::check::types::Col(crate::check::types::Col::CBound{}), field_tys_p6, prism_rtl::rc(self_p9)}));
    auto named_p8 = crate::prelude::filter(args_p3, [&](const crate::syntax::Arg& a_pd) { return prism_rtl::deref(a_pd).name_o != std::optional<crate::syntax::Ident>{}; });
    return (crate::prelude::len(named_p8) > Nat(0u)) && (crate::prelude::len(c_p2.fields_p) > Nat(0u))
        ? ({
        auto st2_pe = crate::prelude::run_to_end(crate::prelude::fold_job(named_p8, st1_p7, ({
            auto c_p2x = c_p2;
            auto env_p0x = env_p0;
            auto field_tys_p6x = field_tys_p6;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Arg>)>>(prism_rtl::rc([=, c_p2x = std::move(c_p2x), env_p0x = std::move(env_p0x), field_tys_p6x = std::move(field_tys_p6x)](std::tuple<crate::check::types::St, crate::syntax::Arg> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto c_p2xy = c_p2x;
                auto env_p0xy = env_p0x;
                auto field_tys_p6xy = field_tys_p6x;
                (crate::prelude::entered(crate::prelude::once_job([=, c_p2xy = std::move(c_p2xy), env_p0xy = std::move(env_p0xy), field_tys_p6xy = std::move(field_tys_p6xy)]() {
                return ({
                    auto s_ph = p0;
                    auto a_pi = p1;
                    ({
                    auto&& _m = prism_rtl::deref(a_pi).name_o;
                    prism_rtl::is_some(_m) ? ({
                    auto&& id_pj = prism_rtl::some_of(_m);
                    ({
                    auto&& _m = crate::check::expr::operators::index_of_o(prism_rtl::deref(c_p2xy).fields_p, prism_rtl::deref(id_pj).name_p);
                    prism_rtl::is_some(_m) ? ({
                    auto&& i_pk = prism_rtl::some_of(_m);
                    prism_rtl::more(prism_rtl::rc(crate::check::expr::Check(env_p0xy, s_ph, prism_rtl::deref(a_pi).value_p, crate::prelude::or_(crate::prelude::index(field_tys_p6xy, i_pk), crate::check::types::Ty(crate::check::types::Ty::TyErr{})))));
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::check::types::recording::err_f(s_ph, Text::lit("mismatch"), prism_rtl::deref(a_pi).span_p, prism_rtl::cat("`", crate::check::types::bare_name_f(prism_rtl::deref(c_p2xy).owner_p), "` has no field `", prism_rtl::deref(id_pj).name_p, "`")))
                    : throw prism_rtl::Panic("no arm matched");
                });
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(s_ph)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            })));
            });
        })));
        })));
        auto missing_pf = crate::prelude::filter(c_p2.fields_p, [&](const Text& f_pl) { return !crate::prelude::fold(named_p8, false, [&](const bool& seen_pm, const crate::syntax::Arg& a_pn) { return prism_rtl::deref(seen_pm) || arg_named_f(a_pn, f_pl); }); });
        auto st3_pg = crate::prelude::len(missing_pf) > Nat(0u)
            ? crate::check::types::recording::err_f(st2_pe, Text::lit("mismatch"), span_p4, prism_rtl::cat("`", crate::check::types::bare_name_f(c_p2.owner_p), "` needs ", crate::syntax::lexer::chars::join_f(crate::prelude::each(missing_pf, [&](const Text& f_po) { return prism_rtl::cat("`", f_po, "`"); }), Text::lit(", "))))
            : st2_pe;
        std::tuple{self_p9, st3_pg};
    })
        : crate::prelude::len(args_p3) != crate::prelude::len(field_tys_p6)
        ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st1_p7, Text::lit("mismatch"), span_p4, prism_rtl::cat("`", crate::check::types::bare_name_f(c_p2.name_p), "` takes ", crate::check::errors::count_word_f(crate::prelude::len(field_tys_p6)), " argument", crate::prelude::len(field_tys_p6) == Nat(1u)
        ? Text::lit("")
        : Text::lit("s"), "; here it has ", crate::check::errors::count_word_f(crate::prelude::len(args_p3))))}
        : ({
        auto st2_pp = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(args_p3)), st1_p7, ({
            auto args_p3x = args_p3;
            auto env_p0x = env_p0;
            auto field_tys_p6x = field_tys_p6;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Nat>)>>(prism_rtl::rc([=, args_p3x = std::move(args_p3x), env_p0x = std::move(env_p0x), field_tys_p6x = std::move(field_tys_p6x)](std::tuple<crate::check::types::St, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto args_p3xy = args_p3x;
                auto env_p0xy = env_p0x;
                auto field_tys_p6xy = field_tys_p6x;
                (crate::prelude::entered(crate::prelude::once_job([=, args_p3xy = std::move(args_p3xy), env_p0xy = std::move(env_p0xy), field_tys_p6xy = std::move(field_tys_p6xy)]() {
                return ({
                    auto s_pq = p0;
                    auto i_pr = p1;
                    ({
                    auto&& _m = crate::prelude::index(args_p3xy, i_pr);
                    prism_rtl::is_some(_m) ? ({
                    auto&& a_ps = prism_rtl::some_of(_m);
                    prism_rtl::more(prism_rtl::rc(crate::check::expr::Check(env_p0xy, s_pq, prism_rtl::deref(a_ps).value_p, crate::prelude::or_(crate::prelude::index(field_tys_p6xy, i_pr), crate::check::types::Ty(crate::check::types::Ty::TyErr{})))));
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(s_pq)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            })));
            });
        })));
        })));
        std::tuple{self_p9, st2_pp};
    });
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> CtorApp::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& c_p2 = this->c_p2;
    const auto& args_p3 = this->args_p3;
    const auto& span_p4 = this->span_p4;
    const auto& cspan_p5 = this->cspan_p5;
    auto args_p3x = args_p3;
    auto c_p2x = c_p2;
    auto cspan_p5x = cspan_p5;
    auto env_p0x = env_p0;
    auto span_p4x = span_p4;
    auto st_p1x = st_p1;
    return crate::prelude::call_then(crate::check::types::schemes::start_instantiate_with_f(st_p1x, crate::check::types::Scheme{.qs_p = prism_rtl::deref(c_p2x).params_p, .plain_qs_p = Array<Text>{}, .rqs_p = Array<Text>{}, .cqs_p = Array<Text>{}, .cjoins_p = Array<std::tuple<Text, Text>>{}, .bounds_p = Array<std::tuple<Text, Text>>{}, .ty_p = prism_rtl::deref(c_p2x).ty_p}, span_p4x, Array<crate::check::types::Ty>{}), [=](std::tuple<crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst> instantiate_with_f_23339) {
        return ({
            auto [self_p9, st0_pa, inst_pb] = instantiate_with_f_23339;
            (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(c_p2x).args_p, ({
            auto inst_pbx = inst_pb;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, inst_pbx = std::move(inst_pbx)](crate::check::types::Ty p0) {
            return ({
                auto inst_pbxy = inst_pbx;
                (crate::prelude::entered(crate::prelude::once_job([=, inst_pbxy = std::move(inst_pbxy)]() {
                return ({
                    auto t_pc = p0;
                    (prism_rtl::more(prism_rtl::rc(crate::check::types::schemes::SubstQ(inst_pbxy, t_pc))));
                });
            })));
            });
        })));
        })), [=](Array<crate::check::types::Ty> each_23481) {
            return ({
                auto field_tys_p6 = each_23481;
                auto st1_p7 = crate::check::types::recording::note_ty_f(st0_pa, cspan_p5x, crate::check::types::Ty(crate::check::types::Ty::TyFn{crate::check::types::Col(crate::check::types::Col::CBound{}), field_tys_p6, prism_rtl::rc(self_p9)}));
                auto named_p8 = crate::prelude::filter(args_p3x, [&](const crate::syntax::Arg& a_pd) { return prism_rtl::deref(a_pd).name_o != std::optional<crate::syntax::Ident>{}; });
                (crate::prelude::len(named_p8) > Nat(0u)) && (crate::prelude::len(prism_rtl::deref(c_p2x).fields_p) > Nat(0u))
                ? crate::prelude::call_value(crate::prelude::fold_job(named_p8, st1_p7, ({
                auto c_p2xx = c_p2x;
                auto env_p0xx = env_p0x;
                auto field_tys_p6x = field_tys_p6;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Arg>)>>(prism_rtl::rc([=, c_p2xx = std::move(c_p2xx), env_p0xx = std::move(env_p0xx), field_tys_p6x = std::move(field_tys_p6x)](std::tuple<crate::check::types::St, crate::syntax::Arg> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto c_p2xxy = c_p2xx;
                    auto env_p0xxy = env_p0xx;
                    auto field_tys_p6xy = field_tys_p6x;
                    (crate::prelude::entered(crate::prelude::once_job([=, c_p2xxy = std::move(c_p2xxy), env_p0xxy = std::move(env_p0xxy), field_tys_p6xy = std::move(field_tys_p6xy)]() {
                    return ({
                        auto s_ph = p0;
                        auto a_pi = p1;
                        ({
                        auto&& _m = prism_rtl::deref(a_pi).name_o;
                        prism_rtl::is_some(_m) ? ({
                        auto&& id_pj = prism_rtl::some_of(_m);
                        ({
                        auto&& _m = crate::check::expr::operators::index_of_o(prism_rtl::deref(c_p2xxy).fields_p, prism_rtl::deref(id_pj).name_p);
                        prism_rtl::is_some(_m) ? ({
                        auto&& i_pk = prism_rtl::some_of(_m);
                        prism_rtl::more(prism_rtl::rc(crate::check::expr::Check(env_p0xxy, s_ph, prism_rtl::deref(a_pi).value_p, crate::prelude::or_(crate::prelude::index(field_tys_p6xy, i_pk), crate::check::types::Ty(crate::check::types::Ty::TyErr{})))));
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::check::types::recording::err_f(s_ph, Text::lit("mismatch"), prism_rtl::deref(a_pi).span_p, prism_rtl::cat("`", crate::check::types::bare_name_f(prism_rtl::deref(c_p2xxy).owner_p), "` has no field `", prism_rtl::deref(id_pj).name_p, "`")))
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(s_ph)
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                })));
                });
            })));
            })), [=](crate::check::types::St fold_23691) {
                return ({
                    auto st2_pe = fold_23691;
                    auto missing_pf = crate::prelude::filter(prism_rtl::deref(c_p2x).fields_p, [&](const Text& f_pl) { return !crate::prelude::fold(named_p8, false, [&](const bool& seen_pm, const crate::syntax::Arg& a_pn) { return prism_rtl::deref(seen_pm) || arg_named_f(a_pn, f_pl); }); });
                    auto st3_pg = crate::prelude::len(missing_pf) > Nat(0u)
                        ? crate::check::types::recording::err_f(st2_pe, Text::lit("mismatch"), span_p4x, prism_rtl::cat("`", crate::check::types::bare_name_f(prism_rtl::deref(c_p2x).owner_p), "` needs ", crate::syntax::lexer::chars::join_f(crate::prelude::each(missing_pf, [&](const Text& f_po) { return prism_rtl::cat("`", f_po, "`"); }), Text::lit(", "))))
                        : st2_pe;
                    (prism_rtl::finished(std::tuple{self_p9, st3_pg}));
                });
            })
                : crate::prelude::len(args_p3x) != crate::prelude::len(field_tys_p6)
                ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st1_p7, Text::lit("mismatch"), span_p4x, prism_rtl::cat("`", crate::check::types::bare_name_f(prism_rtl::deref(c_p2x).name_p), "` takes ", crate::check::errors::count_word_f(crate::prelude::len(field_tys_p6)), " argument", crate::prelude::len(field_tys_p6) == Nat(1u)
                ? Text::lit("")
                : Text::lit("s"), "; here it has ", crate::check::errors::count_word_f(crate::prelude::len(args_p3x))))})
                : crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(args_p3x)), st1_p7, ({
                auto args_p3xx = args_p3x;
                auto env_p0xx = env_p0x;
                auto field_tys_p6x = field_tys_p6;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Nat>)>>(prism_rtl::rc([=, args_p3xx = std::move(args_p3xx), env_p0xx = std::move(env_p0xx), field_tys_p6x = std::move(field_tys_p6x)](std::tuple<crate::check::types::St, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto args_p3xxy = args_p3xx;
                    auto env_p0xxy = env_p0xx;
                    auto field_tys_p6xy = field_tys_p6x;
                    (crate::prelude::entered(crate::prelude::once_job([=, args_p3xxy = std::move(args_p3xxy), env_p0xxy = std::move(env_p0xxy), field_tys_p6xy = std::move(field_tys_p6xy)]() {
                    return ({
                        auto s_pq = p0;
                        auto i_pr = p1;
                        ({
                        auto&& _m = crate::prelude::index(args_p3xxy, i_pr);
                        prism_rtl::is_some(_m) ? ({
                        auto&& a_ps = prism_rtl::some_of(_m);
                        prism_rtl::more(prism_rtl::rc(crate::check::expr::Check(env_p0xxy, s_pq, prism_rtl::deref(a_ps).value_p, crate::prelude::or_(crate::prelude::index(field_tys_p6xy, i_pr), crate::check::types::Ty(crate::check::types::Ty::TyErr{})))));
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(s_pq)
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                })));
                });
            })));
            })), [=](crate::check::types::St fold_24497) {
                return ({
                    auto st2_pp = fold_24497;
                    (prism_rtl::finished(std::tuple{self_p9, st2_pp}));
                });
            });
            });
        }));
        });
    });
}


/// `Start CtorApp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_ctor_app_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::env::CtorInfo c_p2, Array<crate::syntax::Arg> args_p3, crate::syntax::Range span_p4, crate::syntax::Range cspan_p5) {
    return prism_rtl::make_rc<CtorApp>(env_p0, st_p1, c_p2, args_p3, span_p4, cspan_p5);
}


/// TagApp: unbounded fn Env, St, Text, [Arg], Range, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> tag_app_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Text& name_p2, const Array<crate::syntax::Arg>& args_p3, const crate::syntax::Range& span_p4, const crate::syntax::Range& cspan_p5) {
    auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0.g_p).tags_p, name_p2);
    if (prism_rtl::is_none(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("unknown-name"), span_p4, prism_rtl::cat("no tag `", name_p2, "`"))};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& tg_p6 = prism_rtl::some_of(_m);
        auto [out_pb, st1_pc, inst_pd] = crate::check::types::schemes::instantiate_with_f(st_p1, crate::check::types::Scheme{.qs_p = prism_rtl::deref(tg_p6).qs_p, .plain_qs_p = Array<Text>{}, .rqs_p = prism_rtl::deref(tg_p6).rqs_p, .cqs_p = Array<Text>{}, .cjoins_p = Array<std::tuple<Text, Text>>{}, .bounds_p = prism_rtl::deref(tg_p6).bounds_p, .ty_p = prism_rtl::deref(tg_p6).out_p}, span_p4, Array<crate::check::types::Ty>{});
        auto st2_p7 = crate::prelude::run_to_end(crate::prelude::fold_job(args_p3, st1_pc, ({
            auto tg_p6x = tg_p6;
            auto env_p0x = env_p0;
            auto name_p2x = name_p2;
            auto inst_pdx = inst_pd;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Arg>)>>(prism_rtl::rc([=, tg_p6x = std::move(tg_p6x), env_p0x = std::move(env_p0x), name_p2x = std::move(name_p2x), inst_pdx = std::move(inst_pdx)](std::tuple<crate::check::types::St, crate::syntax::Arg> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto tg_p6xy = tg_p6x;
                auto env_p0xy = env_p0x;
                auto name_p2xy = name_p2x;
                auto inst_pdxy = inst_pdx;
                (crate::prelude::entered(crate::prelude::once_job([=, tg_p6xy = std::move(tg_p6xy), env_p0xy = std::move(env_p0xy), name_p2xy = std::move(name_p2xy), inst_pdxy = std::move(inst_pdxy)]() {
                return ({
                    auto s_pe = p0;
                    auto a_pf = p1;
                    ({
                    auto&& _m = prism_rtl::deref(a_pf).name_o;
                    prism_rtl::is_some(_m) ? ({
                    auto&& id_pg = prism_rtl::some_of(_m);
                    ({
                    auto&& _m = field_of_tag_o(tg_p6xy, prism_rtl::deref(id_pg).name_p);
                    prism_rtl::is_some(_m) ? ({
                    auto&& ft_ph = prism_rtl::some_of(_m);
                    ({
                    auto id_pgx = id_pg;
                    (crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(inst_pdxy, ft_ph), [=, id_pgx = std::move(id_pgx)](crate::check::types::Ty subst_q_f_25451) { return prism_rtl::more(prism_rtl::rc(TagField(env_p0xy, s_pe, name_p2xy, prism_rtl::deref(id_pgx).name_p, subst_q_f_25451, a_pf))); }));
                });
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::check::types::recording::err_f(s_pe, Text::lit("mismatch"), prism_rtl::deref(a_pf).span_p, prism_rtl::cat("`", name_p2xy, "` has no field `", prism_rtl::deref(id_pg).name_p, "`")))
                    : throw prism_rtl::Panic("no arm matched");
                });
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::check::types::recording::err_f(s_pe, Text::lit("mismatch"), prism_rtl::deref(a_pf).span_p, prism_rtl::cat("a tag\'s fields are named: `", name_p2xy, "(field=...)`")))
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            })));
            });
        })));
        })));
        auto missing_p8 = crate::prelude::filter(prism_rtl::deref(tg_p6).fields_p, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
            auto&& f_pi = std::get<0>(_p0);
            return !crate::prelude::fold(args_p3, false, [&](const bool& seen_pj, const crate::syntax::Arg& a_pk) { return prism_rtl::deref(seen_pj) || arg_named_f(a_pk, f_pi); });
        });
        auto st3_p9 = (crate::prelude::len(missing_p8) > Nat(0u)) && (!crate::prelude::fold(args_p3, false, [&](const bool& seen_pl, const crate::syntax::Arg& a_pm) { return prism_rtl::deref(seen_pl) || (prism_rtl::deref(prism_rtl::deref(prism_rtl::deref(a_pm).value_p).kind_p) == crate::syntax::ExprKind(crate::syntax::ExprKind::ERest{})); }))
            ? crate::check::types::recording::err_f(st2_p7, Text::lit("mismatch"), span_p4, prism_rtl::cat("`", name_p2, "` needs ", crate::syntax::lexer::chars::join_f(crate::prelude::each(missing_p8, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
            auto&& f_pn = std::get<0>(_p0);
            return prism_rtl::cat("`", f_pn, "`");
        }), Text::lit(", "))))
            : st2_p7;
        auto field_tys_pa = crate::prelude::run_to_end(crate::prelude::each_job(prism_rtl::deref(tg_p6).fields_p, ({
            auto inst_pdx = inst_pd;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(std::tuple<Text, crate::check::types::Ty>)>>(prism_rtl::rc([=, inst_pdx = std::move(inst_pdx)](std::tuple<Text, crate::check::types::Ty> p0) {
            return ({
                auto inst_pdxy = inst_pdx;
                (crate::prelude::entered(crate::prelude::once_job([=, inst_pdxy = std::move(inst_pdxy)]() {
                return ({
                    auto&& _ft_po = p0;
                    auto&& ft_po = std::get<1>(_ft_po);
                    (prism_rtl::more(prism_rtl::rc(crate::check::types::schemes::SubstQ(inst_pdxy, ft_po))));
                });
            })));
            });
        })));
        })));
        return prism_rtl::deref(tg_p6).kind_p == Text::lit("Element")
            ? ({
            auto [rw_pq, st4_pr] = crate::check::types::recording::fresh_row_f(st3_p9, Array(std::vector{prism_rtl::deref(tg_p6).family_p}));
            auto et_pp = crate::check::types::Ty(crate::check::types::Ty::TyElem{crate::check::types::Rw{.fams_p = Array(std::vector{prism_rtl::deref(tg_p6).family_p}), .minus_p = Array<Text>{}, .tail_p = prism_rtl::deref(rw_pq).tail_p}, prism_rtl::rc(out_pb)});
            std::tuple{et_pp, crate::check::types::recording::note_ty_f(st4_pr, cspan_p5, crate::check::types::Ty(crate::check::types::Ty::TyFn{crate::check::types::Col(crate::check::types::Col::CBound{}), field_tys_pa, prism_rtl::rc(et_pp)}))};
        })
            : std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{prism_rtl::deref(tg_p6).kind_p, Array<crate::check::types::Ty>{}}), crate::check::types::recording::note_ty_f(st3_p9, cspan_p5, crate::check::types::Ty(crate::check::types::Ty::TyFn{crate::check::types::Col(crate::check::types::Col::CBound{}), field_tys_pa, prism_rtl::rc(crate::check::types::Ty(crate::check::types::Ty::TyCon{prism_rtl::deref(tg_p6).kind_p, Array<crate::check::types::Ty>{}}))}))};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> TagApp::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& name_p2 = this->name_p2;
    const auto& args_p3 = this->args_p3;
    const auto& span_p4 = this->span_p4;
    const auto& cspan_p5 = this->cspan_p5;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env_p0).g_p).tags_p, name_p2);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("unknown-name"), span_p4, prism_rtl::cat("no tag `", name_p2, "`"))})
        : prism_rtl::is_some(_m) ? ({
        auto&& tg_p6 = prism_rtl::some_of(_m);
        ({
        auto args_p3x = args_p3;
        auto cspan_p5x = cspan_p5;
        auto env_p0x = env_p0;
        auto name_p2x = name_p2;
        auto span_p4x = span_p4;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(crate::check::types::schemes::start_instantiate_with_f(st_p1x, crate::check::types::Scheme{.qs_p = prism_rtl::deref(tg_p6).qs_p, .plain_qs_p = Array<Text>{}, .rqs_p = prism_rtl::deref(tg_p6).rqs_p, .cqs_p = Array<Text>{}, .cjoins_p = Array<std::tuple<Text, Text>>{}, .bounds_p = prism_rtl::deref(tg_p6).bounds_p, .ty_p = prism_rtl::deref(tg_p6).out_p}, span_p4x, Array<crate::check::types::Ty>{}), [=, args_p3x = std::move(args_p3x), cspan_p5x = std::move(cspan_p5x), env_p0x = std::move(env_p0x), name_p2x = std::move(name_p2x)](std::tuple<crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst> instantiate_with_f_25161) {
        return ({
            auto [out_pb, st1_pc, inst_pd] = instantiate_with_f_25161;
            (crate::prelude::call_value(crate::prelude::fold_job(args_p3x, st1_pc, ({
            auto tg_p6x = tg_p6;
            auto env_p0xx = env_p0x;
            auto name_p2xx = name_p2x;
            auto inst_pdx = inst_pd;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Arg>)>>(prism_rtl::rc([=, tg_p6x = std::move(tg_p6x), env_p0xx = std::move(env_p0xx), name_p2xx = std::move(name_p2xx), inst_pdx = std::move(inst_pdx)](std::tuple<crate::check::types::St, crate::syntax::Arg> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto tg_p6xy = tg_p6x;
                auto env_p0xxy = env_p0xx;
                auto name_p2xxy = name_p2xx;
                auto inst_pdxy = inst_pdx;
                (crate::prelude::entered(crate::prelude::once_job([=, tg_p6xy = std::move(tg_p6xy), env_p0xxy = std::move(env_p0xxy), name_p2xxy = std::move(name_p2xxy), inst_pdxy = std::move(inst_pdxy)]() {
                return ({
                    auto s_pe = p0;
                    auto a_pf = p1;
                    ({
                    auto&& _m = prism_rtl::deref(a_pf).name_o;
                    prism_rtl::is_some(_m) ? ({
                    auto&& id_pg = prism_rtl::some_of(_m);
                    ({
                    auto&& _m = field_of_tag_o(tg_p6xy, prism_rtl::deref(id_pg).name_p);
                    prism_rtl::is_some(_m) ? ({
                    auto&& ft_ph = prism_rtl::some_of(_m);
                    ({
                    auto id_pgx = id_pg;
                    (crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(inst_pdxy, ft_ph), [=, id_pgx = std::move(id_pgx)](crate::check::types::Ty subst_q_f_25451) { return prism_rtl::more(prism_rtl::rc(TagField(env_p0xxy, s_pe, name_p2xxy, prism_rtl::deref(id_pgx).name_p, subst_q_f_25451, a_pf))); }));
                });
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::check::types::recording::err_f(s_pe, Text::lit("mismatch"), prism_rtl::deref(a_pf).span_p, prism_rtl::cat("`", name_p2xxy, "` has no field `", prism_rtl::deref(id_pg).name_p, "`")))
                    : throw prism_rtl::Panic("no arm matched");
                });
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::check::types::recording::err_f(s_pe, Text::lit("mismatch"), prism_rtl::deref(a_pf).span_p, prism_rtl::cat("a tag\'s fields are named: `", name_p2xxy, "(field=...)`")))
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            })));
            });
        })));
        })), [=](crate::check::types::St fold_25308) {
            return ({
                auto st2_p7 = fold_25308;
                auto missing_p8 = crate::prelude::filter(prism_rtl::deref(tg_p6).fields_p, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
                    auto&& f_pi = std::get<0>(_p0);
                    return !crate::prelude::fold(args_p3x, false, [&](const bool& seen_pj, const crate::syntax::Arg& a_pk) { return prism_rtl::deref(seen_pj) || arg_named_f(a_pk, f_pi); });
                });
                auto st3_p9 = (crate::prelude::len(missing_p8) > Nat(0u)) && (!crate::prelude::fold(args_p3x, false, [&](const bool& seen_pl, const crate::syntax::Arg& a_pm) { return prism_rtl::deref(seen_pl) || (prism_rtl::deref(prism_rtl::deref(prism_rtl::deref(a_pm).value_p).kind_p) == crate::syntax::ExprKind(crate::syntax::ExprKind::ERest{})); }))
                    ? crate::check::types::recording::err_f(st2_p7, Text::lit("mismatch"), span_p4x, prism_rtl::cat("`", name_p2x, "` needs ", crate::syntax::lexer::chars::join_f(crate::prelude::each(missing_p8, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
                    auto&& f_pn = std::get<0>(_p0);
                    return prism_rtl::cat("`", f_pn, "`");
                }), Text::lit(", "))))
                    : st2_p7;
                (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(tg_p6).fields_p, ({
                auto inst_pdx = inst_pd;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(std::tuple<Text, crate::check::types::Ty>)>>(prism_rtl::rc([=, inst_pdx = std::move(inst_pdx)](std::tuple<Text, crate::check::types::Ty> p0) {
                return ({
                    auto inst_pdxy = inst_pdx;
                    (crate::prelude::entered(crate::prelude::once_job([=, inst_pdxy = std::move(inst_pdxy)]() {
                    return ({
                        auto&& _ft_po = p0;
                        auto&& ft_po = std::get<1>(_ft_po);
                        (prism_rtl::more(prism_rtl::rc(crate::check::types::schemes::SubstQ(inst_pdxy, ft_po))));
                    });
                })));
                });
            })));
            })), [=, st3_p9 = std::move(st3_p9)](Array<crate::check::types::Ty> each_26003) {
                return ({
                    auto field_tys_pa = each_26003;
                    (prism_rtl::deref(tg_p6).kind_p == Text::lit("Element")
                    ? ({
                    auto [rw_pq, st4_pr] = crate::check::types::recording::fresh_row_f(st3_p9, Array(std::vector{prism_rtl::deref(tg_p6).family_p}));
                    auto et_pp = crate::check::types::Ty(crate::check::types::Ty::TyElem{crate::check::types::Rw{.fams_p = Array(std::vector{prism_rtl::deref(tg_p6).family_p}), .minus_p = Array<Text>{}, .tail_p = prism_rtl::deref(rw_pq).tail_p}, prism_rtl::rc(out_pb)});
                    (prism_rtl::finished(std::tuple{et_pp, crate::check::types::recording::note_ty_f(st4_pr, cspan_p5x, crate::check::types::Ty(crate::check::types::Ty::TyFn{crate::check::types::Col(crate::check::types::Col::CBound{}), field_tys_pa, prism_rtl::rc(et_pp)}))}));
                })
                    : prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{prism_rtl::deref(tg_p6).kind_p, Array<crate::check::types::Ty>{}}), crate::check::types::recording::note_ty_f(st3_p9, cspan_p5x, crate::check::types::Ty(crate::check::types::Ty::TyFn{crate::check::types::Col(crate::check::types::Col::CBound{}), field_tys_pa, prism_rtl::rc(crate::check::types::Ty(crate::check::types::Ty::TyCon{prism_rtl::deref(tg_p6).kind_p, Array<crate::check::types::Ty>{}}))}))}));
                });
            }));
            });
        }));
        });
    }));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TagApp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_tag_app_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text name_p2, Array<crate::syntax::Arg> args_p3, crate::syntax::Range span_p4, crate::syntax::Range cspan_p5) {
    return prism_rtl::make_rc<TagApp>(env_p0, st_p1, name_p2, args_p3, span_p4, cspan_p5);
}


/// ?FieldOfTag: fn TagInfo, Text -> ?Ty
std::optional<crate::check::types::Ty> field_of_tag_o(const crate::check::env::TagInfo& tg_p0, const Text& f_p1) {
    return crate::prelude::fold(tg_p0.fields_p, std::optional<crate::check::types::Ty>{}, [&](const std::optional<crate::check::types::Ty>& found_o2, const std::tuple<Text, crate::check::types::Ty>& _p1) {
        auto&& n_p3 = std::get<0>(_p1);
        auto&& t_p4 = std::get<1>(_p1);
        return ({
            __label__ _done;
            prism_rtl::Slot<std::optional<crate::check::types::Ty>> _v;
            if (prism_rtl::is_some(found_o2)) {
                auto&& x_p5 = prism_rtl::some_of(found_o2);
                _v.set(std::optional(x_p5));
                goto _done;
            }
            if (prism_rtl::is_none(found_o2)) {
                _v.set(n_p3 == f_p1
                    ? std::optional(t_p4)
                    : std::optional<crate::check::types::Ty>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// TagField: unbounded fn Env, St, Text, Text, Ty, Arg -> St
crate::check::types::St tag_field_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Text& tag_name_p2, const Text& field_p3, const crate::check::types::Ty& ft_p4, const crate::syntax::Arg& a_p5) {
    return crate::check::types::head_sigil_f(st_p1, ft_p4) != Text::lit("")
        ? crate::check::expr::check_f(env_p0, st_p1, a_p5.value_p, ft_p4)
        : ({
        auto [at_p7, st2_p8] = crate::check::expr::infer_f(env_p0, st_p1, a_p5.value_p);
        auto head_p6 = crate::check::types::head_sigil_f(st2_p8, at_p7);
        head_p6 == Text::lit("$")
        ? crate::check::types::recording::err_fix_f(st2_p8, Text::lit("identity-dynamic"), prism_rtl::deref(a_p5.value_p).span_p, prism_rtl::cat("a dynamic in the identity field `", field_p3, "`"), prism_rtl::cat("for a new element per value, write `rebuild ", crate::check::expr::src_text_f(env_p0, prism_rtl::deref(a_p5.value_p).span_p), ":` with `", tag_name_p2, "(", field_p3, "=_, ...)` inside"))
        : head_p6 == Text::lit("!")
        ? crate::check::types::recording::err_f(st2_p8, Text::lit("two-events"), prism_rtl::deref(a_p5.value_p).span_p, prism_rtl::cat("an event in the plain field `", field_p3, "`"))
        : crate::check::types::unify::unify_f(st2_p8, ft_p4, at_p7, prism_rtl::deref(a_p5.value_p).span_p);
    });
}


prism_rtl::Turn<crate::check::types::St> TagField::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& tag_name_p2 = this->tag_name_p2;
    const auto& field_p3 = this->field_p3;
    const auto& ft_p4 = this->ft_p4;
    const auto& a_p5 = this->a_p5;
    auto a_p5x = a_p5;
    auto env_p0x = env_p0;
    auto field_p3x = field_p3;
    auto ft_p4x = ft_p4;
    auto st_p1x = st_p1;
    auto tag_name_p2x = tag_name_p2;
    return crate::prelude::call_then(crate::check::types::start_head_sigil_f(st_p1x, ft_p4x), [=](Text head_sigil_f_26819) {
        return head_sigil_f_26819 != Text::lit("")
            ? prism_rtl::more(prism_rtl::rc(crate::check::expr::Check(env_p0x, st_p1x, prism_rtl::deref(a_p5x).value_p, ft_p4x)))
            : crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x, st_p1x, prism_rtl::deref(a_p5x).value_p), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_f_26907) {
            return ({
                auto [at_p7, st2_p8] = infer_f_26907;
                (crate::prelude::call_then(crate::check::types::start_head_sigil_f(st2_p8, at_p7), [=](Text head_sigil_f_26949) {
                return ({
                    auto head_p6 = head_sigil_f_26949;
                    head_p6 == Text::lit("$")
                    ? prism_rtl::finished(crate::check::types::recording::err_fix_f(st2_p8, Text::lit("identity-dynamic"), prism_rtl::deref(prism_rtl::deref(a_p5x).value_p).span_p, prism_rtl::cat("a dynamic in the identity field `", field_p3x, "`"), prism_rtl::cat("for a new element per value, write `rebuild ", crate::check::expr::src_text_f(env_p0x, prism_rtl::deref(prism_rtl::deref(a_p5x).value_p).span_p), ":` with `", tag_name_p2x, "(", field_p3x, "=_, ...)` inside")))
                    : head_p6 == Text::lit("!")
                    ? prism_rtl::finished(crate::check::types::recording::err_f(st2_p8, Text::lit("two-events"), prism_rtl::deref(prism_rtl::deref(a_p5x).value_p).span_p, prism_rtl::cat("an event in the plain field `", field_p3x, "`")))
                    : prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st2_p8, ft_p4x, at_p7, prism_rtl::deref(prism_rtl::deref(a_p5x).value_p).span_p)));
                });
            }));
            });
        });
    });
}


/// `Start TagField, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_tag_field_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text tag_name_p2, Text field_p3, crate::check::types::Ty ft_p4, crate::syntax::Arg a_p5) {
    return prism_rtl::make_rc<TagField>(env_p0, st_p1, tag_name_p2, field_p3, ft_p4, a_p5);
}


/// LambdaArity: fn Expr -> Nat
Nat lambda_arity_f(const crate::syntax::Expr& e_p0) {
    auto&& _m = prism_rtl::deref(e_p0.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0)) {
        auto&& ps_p1 = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0);
        return crate::prelude::len(ps_p1);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p2 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return lambda_arity_f(prism_rtl::deref(prism_rtl::deref(x_p2)));
    }
    {
        return Nat(2u);
    }
}


/// InferLambda: unbounded fn Env, St, Expr, ?Ty -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_lambda_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& e_p2, const std::optional<crate::check::types::Ty>& expected_o3) {
    auto&& _m = prism_rtl::deref(e_p2.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p4 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        auto [t_p5, st2_p6] = infer_lambda_f(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(x_p4)), expected_o3);
        return std::tuple{t_p5, crate::check::types::recording::note_ty_f(st2_p6, prism_rtl::deref(x_p4).span_p, t_p5)};
    }
    {
        return infer_bare_lambda_f(env_p0, st_p1, e_p2, expected_o3);
    }
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferLambda::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& e_p2 = this->e_p2;
    const auto& expected_o3 = this->expected_o3;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p2).kind_p);
        prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x_p4 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        ({
        auto expected_o3x = expected_o3;
        auto env_p0x = env_p0;
        auto st_p1x = st_p1;
        auto x_p4x = prism_rtl::deref(prism_rtl::deref(x_p4));
        (crate::prelude::call_then(start_infer_lambda_f(env_p0x, st_p1x, x_p4x, expected_o3x), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_lambda_f_28335) {
        return ({
            auto [t_p5, st2_p6] = infer_lambda_f_28335;
            (prism_rtl::finished(std::tuple{t_p5, crate::check::types::recording::note_ty_f(st2_p6, prism_rtl::deref(x_p4x).span_p, t_p5)}));
        });
    }));
    });
    })
        : prism_rtl::more(prism_rtl::rc(InferBareLambda(env_p0, st_p1, e_p2, expected_o3)));
    });
}


/// `Start InferLambda, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_lambda_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr e_p2, std::optional<crate::check::types::Ty> expected_o3) {
    return prism_rtl::make_rc<InferLambda>(env_p0, st_p1, e_p2, expected_o3);
}


/// InferBareLambda: unbounded fn Env, St, Expr, ?Ty -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_bare_lambda_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& e_p2, const std::optional<crate::check::types::Ty>& expected_o3) {
    auto [params_pg, body_ph] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::syntax::Pattern_>, crate::syntax::LambdaBody>> _v;
        auto&& _m = prism_rtl::deref(e_p2.kind_p);
        if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0)) {
            auto&& ps_pb = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0);
            auto&& b_pc = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
            _v.set(std::tuple{ps_pb, prism_rtl::deref(prism_rtl::deref(b_pc))});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0)) {
            auto&& b_pd = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
            _v.set(std::tuple{Array(std::vector{topic_pat_f(e_p2.span_p)}), prism_rtl::deref(prism_rtl::deref(b_pd))});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ETopicField>(_m)) {
            auto&& f_pe = prism_rtl::as<crate::syntax::ExprKind::ETopicField>(_m).a0;
            _v.set(std::tuple{Array(std::vector{topic_pat_f(e_p2.span_p)}), crate::syntax::LambdaBody(crate::syntax::LambdaBody::LbExpr{prism_rtl::rc(topic_field_expr_f(e_p2.span_p, f_pe))})});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ETopicIndex>(_m)) {
            auto&& x_pf = prism_rtl::as<crate::syntax::ExprKind::ETopicIndex>(_m).a0;
            _v.set(std::tuple{Array(std::vector{topic_pat_f(e_p2.span_p)}), crate::syntax::LambdaBody(crate::syntax::LambdaBody::LbExpr{prism_rtl::rc(topic_index_expr_f(e_p2.span_p, prism_rtl::deref(prism_rtl::deref(x_pf))))})});
            goto _done;
        }
        {
            _v.set(std::tuple{Array<crate::syntax::Pattern_>{}, crate::syntax::LambdaBody(crate::syntax::LambdaBody::LbExpr{prism_rtl::rc(e_p2)})});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [exp_params_pl, exp_res_om, st0_pn] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::check::types::Ty>, std::optional<crate::check::types::Ty>, crate::check::types::St>> _v;
        if (prism_rtl::is_some(expected_o3)) {
            auto&& t_pi = prism_rtl::some_of(expected_o3);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<crate::check::types::Ty>, std::optional<crate::check::types::Ty>, crate::check::types::St>> _v;
                auto&& _m = crate::check::types::recording::walk_f(st_p1, t_pi);
                if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
                    auto&& ps_pj = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
                    auto&& r_pk = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
                    _v.set(crate::prelude::len(ps_pj) == crate::prelude::len(params_pg)
                        ? std::tuple{ps_pj, std::optional(prism_rtl::deref(r_pk)), st_p1}
                        : std::tuple{Array<crate::check::types::Ty>{}, std::optional<crate::check::types::Ty>{}, crate::check::types::recording::err_f(st_p1, Text::lit("mismatch"), e_p2.span_p, prism_rtl::cat("this lambda takes ", crate::check::errors::count_word_f(crate::prelude::len(params_pg)), " parameter", crate::prelude::len(params_pg) == Nat(1u) ? Text::lit("") : Text::lit("s"), "; here ", crate::check::errors::count_word_f(crate::prelude::len(ps_pj)), " ", crate::prelude::len(ps_pj) == Nat(1u) ? Text::lit("is") : Text::lit("are"), " wanted"))});
                    goto _done;
                }
                {
                    _v.set(std::tuple{Array<crate::check::types::Ty>{}, std::optional<crate::check::types::Ty>{}, st_p1});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(expected_o3)) {
            _v.set(std::tuple{Array<crate::check::types::Ty>{}, std::optional<crate::check::types::Ty>{}, st_p1});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto [env2_p12, ptys_p13, st1_p14] = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(params_pg)), std::tuple{env_p0, Array<crate::check::types::Ty>{}, st0_pn}, ({
        auto params_pgx = params_pg;
        auto e_p2x = e_p2;
        auto exp_params_plx = exp_params_pl;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, Array<crate::check::types::Ty>, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, Array<crate::check::types::Ty>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, params_pgx = std::move(params_pgx), e_p2x = std::move(e_p2x), exp_params_plx = std::move(exp_params_plx)](std::tuple<std::tuple<crate::check::expr::Env, Array<crate::check::types::Ty>, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto params_pgxy = params_pgx;
            auto e_p2xy = e_p2x;
            auto exp_params_plxy = exp_params_plx;
            (crate::prelude::entered(crate::prelude::once_job([=, params_pgxy = std::move(params_pgxy), e_p2xy = std::move(e_p2xy), exp_params_plxy = std::move(exp_params_plxy)]() {
            return ({
                auto [en_po, acc_pp, s_pq] = p0;
                auto i_pr = p1;
                ({
                auto p_ps = crate::prelude::or_(crate::prelude::index(params_pgxy, i_pr), crate::syntax::Pattern_{.kind_p = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span_p = prism_rtl::deref(e_p2xy).span_p});
                auto [pt_pu, s2_pv] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                    auto&& _m = crate::prelude::index(exp_params_plxy, i_pr);
                    if (prism_rtl::is_some(_m)) {
                        auto&& t_pt = prism_rtl::some_of(_m);
                        _v.set(std::tuple{t_pt, s_pq});
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(crate::check::types::fresh_var_f(s_pq, true, Text::lit("")));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                (crate::prelude::call_then(crate::check::expr::patterns::start_bind_pattern_f(crate::check::expr::lets::unpend_f(en_po), s2_pv, p_ps, pt_pu, false), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> bind_pattern_f_29677) {
                return ({
                    auto [en2_p10, s3_p11] = bind_pattern_f_29677;
                    (prism_rtl::finished(std::tuple{en2_p10, crate::prelude::push(acc_pp, pt_pu), s3_p11}));
                });
            }));
            });
            });
        })));
        });
    }));
    })));
    auto outer_color_p4 = prism_rtl::deref(st1_p14).color_p;
    auto outer_why_p5 = prism_rtl::deref(st1_p14).color_why_p;
    auto outer_flex_p6 = prism_rtl::deref(st1_p14).color_flex_p;
    auto [lcol_p15, st1b_p16] = crate::check::types::fresh_col_f(st1_p14);
    auto st2_p7 = ({
        crate::check::types::St this_ = st1b_p16;
        this_.color_p = crate::check::types::Col(crate::check::types::Col::CBound{});
        this_.color_why_p = Text::lit("");
        this_.color_flex_p = Array<std::tuple<crate::check::types::Col, Text, crate::syntax::Range>>{};
        (std::move(this_));
    });
    auto [rt_p1b, st3_p1c] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
        if (prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(body_ph)) {
            auto&& x_p17 = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(body_ph).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                if (prism_rtl::is_some(exp_res_om)) {
                    auto&& r_p18 = prism_rtl::some_of(exp_res_om);
                    _v.set(({
                        auto s4_p19 = crate::check::expr::check_f(env2_p12, st2_p7, prism_rtl::deref(prism_rtl::deref(x_p17)), r_p18);
                        std::tuple{r_p18, s4_p19};
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(exp_res_om)) {
                    _v.set(crate::check::expr::infer_f(env2_p12, st2_p7, prism_rtl::deref(prism_rtl::deref(x_p17))));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(body_ph)) {
            auto&& b_p1a = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(body_ph).a0;
            _v.set(infer_body_block_f(env2_p12, st2_p7, b_p1a, exp_res_om));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st3b_p8 = crate::check::types::colors::settle_body_f(st3_p1c, lcol_p15, Text::lit(""));
    auto st3c_p9 = crate::check::types::colors::add_leq_f(st3b_p8, prism_rtl::deref(st3b_p8).color_p, lcol_p15, e_p2.span_p, Text::lit("lambda"), Text::lit(""), prism_rtl::deref(st3b_p8).color_why_p);
    auto st4_pa = ({
        crate::check::types::St this_ = st3c_p9;
        this_.color_p = outer_color_p4;
        this_.color_why_p = outer_why_p5;
        this_.color_flex_p = outer_flex_p6;
        (std::move(this_));
    });
    return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyFn{lcol_p15, ptys_p13, prism_rtl::rc(rt_p1b)}), crate::check::types::recording::note_fn_f(st4_pa, e_p2.span_p, Text::lit("lambda"), lcol_p15, lcol_p15)};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferBareLambda::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& e_p2 = this->e_p2;
    const auto& expected_o3 = this->expected_o3;
    auto [params_pg, body_ph] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::syntax::Pattern_>, crate::syntax::LambdaBody>> _v;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p2).kind_p);
        if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0)) {
            auto&& ps_pb = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0);
            auto&& b_pc = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
            _v.set(std::tuple{ps_pb, prism_rtl::deref(prism_rtl::deref(b_pc))});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0)) {
            auto&& b_pd = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
            _v.set(std::tuple{Array(std::vector{topic_pat_f(prism_rtl::deref(e_p2).span_p)}), prism_rtl::deref(prism_rtl::deref(b_pd))});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ETopicField>(_m)) {
            auto&& f_pe = prism_rtl::as<crate::syntax::ExprKind::ETopicField>(_m).a0;
            _v.set(std::tuple{Array(std::vector{topic_pat_f(prism_rtl::deref(e_p2).span_p)}), crate::syntax::LambdaBody(crate::syntax::LambdaBody::LbExpr{prism_rtl::rc(topic_field_expr_f(prism_rtl::deref(e_p2).span_p, f_pe))})});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ETopicIndex>(_m)) {
            auto&& x_pf = prism_rtl::as<crate::syntax::ExprKind::ETopicIndex>(_m).a0;
            _v.set(std::tuple{Array(std::vector{topic_pat_f(prism_rtl::deref(e_p2).span_p)}), crate::syntax::LambdaBody(crate::syntax::LambdaBody::LbExpr{prism_rtl::rc(topic_index_expr_f(prism_rtl::deref(e_p2).span_p, prism_rtl::deref(prism_rtl::deref(x_pf))))})});
            goto _done;
        }
        {
            _v.set(std::tuple{Array<crate::syntax::Pattern_>{}, crate::syntax::LambdaBody(crate::syntax::LambdaBody::LbExpr{prism_rtl::rc(e_p2)})});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [exp_params_pl, exp_res_om, st0_pn] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::check::types::Ty>, std::optional<crate::check::types::Ty>, crate::check::types::St>> _v;
        if (prism_rtl::is_some(expected_o3)) {
            auto&& t_pi = prism_rtl::some_of(expected_o3);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<crate::check::types::Ty>, std::optional<crate::check::types::Ty>, crate::check::types::St>> _v;
                auto&& _m = crate::check::types::recording::walk_f(st_p1, t_pi);
                if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
                    auto&& ps_pj = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
                    auto&& r_pk = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
                    _v.set(crate::prelude::len(ps_pj) == crate::prelude::len(params_pg)
                        ? std::tuple{ps_pj, std::optional(prism_rtl::deref(r_pk)), st_p1}
                        : std::tuple{Array<crate::check::types::Ty>{}, std::optional<crate::check::types::Ty>{}, crate::check::types::recording::err_f(st_p1, Text::lit("mismatch"), prism_rtl::deref(e_p2).span_p, prism_rtl::cat("this lambda takes ", crate::check::errors::count_word_f(crate::prelude::len(params_pg)), " parameter", crate::prelude::len(params_pg) == Nat(1u) ? Text::lit("") : Text::lit("s"), "; here ", crate::check::errors::count_word_f(crate::prelude::len(ps_pj)), " ", crate::prelude::len(ps_pj) == Nat(1u) ? Text::lit("is") : Text::lit("are"), " wanted"))});
                    goto _done;
                }
                {
                    _v.set(std::tuple{Array<crate::check::types::Ty>{}, std::optional<crate::check::types::Ty>{}, st_p1});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(expected_o3)) {
            _v.set(std::tuple{Array<crate::check::types::Ty>{}, std::optional<crate::check::types::Ty>{}, st_p1});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto e_p2x = e_p2;
    auto env_p0x = env_p0;
    return crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(params_pg)), std::tuple{env_p0x, Array<crate::check::types::Ty>{}, st0_pn}, ({
        auto params_pgx = params_pg;
        auto e_p2xx = e_p2x;
        auto exp_params_plx = exp_params_pl;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, Array<crate::check::types::Ty>, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, Array<crate::check::types::Ty>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, params_pgx = std::move(params_pgx), e_p2xx = std::move(e_p2xx), exp_params_plx = std::move(exp_params_plx)](std::tuple<std::tuple<crate::check::expr::Env, Array<crate::check::types::Ty>, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto params_pgxy = params_pgx;
            auto e_p2xxy = e_p2xx;
            auto exp_params_plxy = exp_params_plx;
            (crate::prelude::entered(crate::prelude::once_job([=, params_pgxy = std::move(params_pgxy), e_p2xxy = std::move(e_p2xxy), exp_params_plxy = std::move(exp_params_plxy)]() {
            return ({
                auto [en_po, acc_pp, s_pq] = p0;
                auto i_pr = p1;
                ({
                auto p_ps = crate::prelude::or_(crate::prelude::index(params_pgxy, i_pr), crate::syntax::Pattern_{.kind_p = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span_p = prism_rtl::deref(e_p2xxy).span_p});
                auto [pt_pu, s2_pv] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                    auto&& _m = crate::prelude::index(exp_params_plxy, i_pr);
                    if (prism_rtl::is_some(_m)) {
                        auto&& t_pt = prism_rtl::some_of(_m);
                        _v.set(std::tuple{t_pt, s_pq});
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(crate::check::types::fresh_var_f(s_pq, true, Text::lit("")));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                (crate::prelude::call_then(crate::check::expr::patterns::start_bind_pattern_f(crate::check::expr::lets::unpend_f(en_po), s2_pv, p_ps, pt_pu, false), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> bind_pattern_f_29677) {
                return ({
                    auto [en2_p10, s3_p11] = bind_pattern_f_29677;
                    (prism_rtl::finished(std::tuple{en2_p10, crate::prelude::push(acc_pp, pt_pu), s3_p11}));
                });
            }));
            });
            });
        })));
        });
    }));
    })), [=](std::tuple<crate::check::expr::Env, Array<crate::check::types::Ty>, crate::check::types::St> fold_29408) {
        return ({
            auto [env2_p12, ptys_p13, st1_p14] = fold_29408;
            auto outer_color_p4 = prism_rtl::deref(st1_p14).color_p;
            auto outer_why_p5 = prism_rtl::deref(st1_p14).color_why_p;
            auto outer_flex_p6 = prism_rtl::deref(st1_p14).color_flex_p;
            auto [lcol_p15, st1b_p16] = crate::check::types::fresh_col_f(st1_p14);
            auto st2_p7 = ({
                crate::check::types::St this_ = st1b_p16;
                this_.color_p = crate::check::types::Col(crate::check::types::Col::CBound{});
                this_.color_why_p = Text::lit("");
                this_.color_flex_p = Array<std::tuple<crate::check::types::Col, Text, crate::syntax::Range>>{};
                (std::move(this_));
            });
            auto [rt_p1b, st3_p1c] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                if (prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(body_ph)) {
                    auto&& x_p17 = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(body_ph).a0;
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                        if (prism_rtl::is_some(exp_res_om)) {
                            auto&& r_p18 = prism_rtl::some_of(exp_res_om);
                            _v.set(({
                                auto s4_p19 = crate::check::expr::check_f(env2_p12, st2_p7, prism_rtl::deref(prism_rtl::deref(x_p17)), r_p18);
                                std::tuple{r_p18, s4_p19};
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_none(exp_res_om)) {
                            _v.set(crate::check::expr::infer_f(env2_p12, st2_p7, prism_rtl::deref(prism_rtl::deref(x_p17))));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(body_ph)) {
                    auto&& b_p1a = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(body_ph).a0;
                    _v.set(infer_body_block_f(env2_p12, st2_p7, b_p1a, exp_res_om));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (crate::prelude::call_then(crate::check::types::colors::start_settle_body_f(st3_p1c, lcol_p15, Text::lit("")), [=, outer_color_p4 = std::move(outer_color_p4), outer_why_p5 = std::move(outer_why_p5), outer_flex_p6 = std::move(outer_flex_p6)](crate::check::types::St settle_body_f_30263) {
            return ({
                auto st3b_p8 = settle_body_f_30263;
                (crate::prelude::call_then(crate::check::types::colors::start_add_leq_f(st3b_p8, prism_rtl::deref(st3b_p8).color_p, lcol_p15, prism_rtl::deref(e_p2x).span_p, Text::lit("lambda"), Text::lit(""), prism_rtl::deref(st3b_p8).color_why_p), [=](crate::check::types::St add_leq_f_30303) {
                return ({
                    auto st3c_p9 = add_leq_f_30303;
                    auto st4_pa = ({
                        crate::check::types::St this_ = st3c_p9;
                        this_.color_p = outer_color_p4;
                        this_.color_why_p = outer_why_p5;
                        this_.color_flex_p = outer_flex_p6;
                        (std::move(this_));
                    });
                    (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyFn{lcol_p15, ptys_p13, prism_rtl::rc(rt_p1b)}), crate::check::types::recording::note_fn_f(st4_pa, prism_rtl::deref(e_p2x).span_p, Text::lit("lambda"), lcol_p15, lcol_p15)}));
                });
            }));
            });
        }));
        });
    });
}


/// `Start InferBareLambda, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_bare_lambda_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr e_p2, std::optional<crate::check::types::Ty> expected_o3) {
    return prism_rtl::make_rc<InferBareLambda>(env_p0, st_p1, e_p2, expected_o3);
}


/// TopicPat: fn Range -> Pattern
crate::syntax::Pattern_ topic_pat_f(const crate::syntax::Range& span_p0) {
    return crate::syntax::Pattern_{.kind_p = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PName{topic_sname_f(span_p0)})), .span_p = span_p0};
}


/// TopicSName: fn Range -> SName
crate::syntax::SName topic_sname_f(const crate::syntax::Range& span_p0) {
    return crate::syntax::SName{.sigils_p = Text::lit(""), .path_p = Array(std::vector{Text::lit("_")}), .span_p = span_p0};
}


/// TopicExpr: fn Range -> Expr
crate::syntax::Expr topic_expr_f(const crate::syntax::Range& span_p0) {
    return crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{topic_sname_f(span_p0)})), .span_p = span_p0};
}


/// TopicFieldExpr: fn Range, Ident -> Expr
crate::syntax::Expr topic_field_expr_f(const crate::syntax::Range& span_p0, const crate::syntax::Ident& f_p1) {
    return crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EField{prism_rtl::rc(topic_expr_f(span_p0)), Text::lit(""), f_p1})), .span_p = span_p0};
}


/// TopicIndexExpr: fn Range, Expr -> Expr
crate::syntax::Expr topic_index_expr_f(const crate::syntax::Range& span_p0, const crate::syntax::Expr& x_p1) {
    return crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EIndex{prism_rtl::rc(topic_expr_f(span_p0)), prism_rtl::rc(x_p1)})), .span_p = span_p0};
}


/// ArgNamed: fn Arg, Text -> Bool
bool arg_named_f(const crate::syntax::Arg& a_p0, const Text& f_p1) {
    auto&& _m = a_p0.name_o;
    if (prism_rtl::is_some(_m)) {
        auto&& id_p2 = prism_rtl::some_of(_m);
        return prism_rtl::deref(id_p2).name_p == f_p1;
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// InferBodyBlock: unbounded fn Env, St, Block, ?Ty -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_body_block_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Block& b_p2, const std::optional<crate::check::types::Ty>& expected_o3) {
    auto [t_p4, st2_p5] = crate::check::expr::lets::infer_expr_block_f(env_p0, st_p1, b_p2);
    if (prism_rtl::is_some(expected_o3)) {
        auto&& r_p6 = prism_rtl::some_of(expected_o3);
        return std::tuple{r_p6, crate::check::types::unify::unify_f(st2_p5, r_p6, t_p4, b_p2.span_p)};
    }
    if (prism_rtl::is_none(expected_o3)) {
        return std::tuple{t_p4, st2_p5};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferBodyBlock::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& b_p2 = this->b_p2;
    const auto& expected_o3 = this->expected_o3;
    auto expected_o3x = expected_o3;
    auto b_p2x = b_p2;
    auto env_p0x = env_p0;
    auto st_p1x = st_p1;
    return crate::prelude::call_then(crate::check::expr::lets::start_infer_expr_block_f(env_p0x, st_p1x, b_p2x), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_expr_block_f_31558) {
        return ({
            auto [t_p4, st2_p5] = infer_expr_block_f_31558;
            ({
            prism_rtl::is_some(expected_o3x) ? ({
            auto&& r_p6 = prism_rtl::some_of(expected_o3x);
            ({
            auto r_p6x = r_p6;
            (crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_p5, r_p6x, t_p4, prism_rtl::deref(b_p2x).span_p), [=](crate::check::types::St unify_f_31624) { return prism_rtl::finished(std::tuple{r_p6x, unify_f_31624}); }));
        });
        })
            : prism_rtl::is_none(expected_o3x) ? prism_rtl::finished(std::tuple{t_p4, st2_p5})
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
}


/// `Start InferBodyBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_body_block_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Block b_p2, std::optional<crate::check::types::Ty> expected_o3) {
    return prism_rtl::make_rc<InferBodyBlock>(env_p0, st_p1, b_p2, expected_o3);
}

}  // namespace crate::check::expr::calls
