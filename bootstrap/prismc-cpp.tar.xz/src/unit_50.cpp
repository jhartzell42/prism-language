// The modules `Lower.Node.Dynamics`, `Lower.Node.Elements`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <lower/node_/dynamics/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Lower.Node.Dynamics`, from `target/bootstrap/cpp-src/prismc/lower/node/dynamics.prism`.
namespace crate::lower::node_::dynamics {

/// DynamicExpr: unbounded fn Wx, Env, Expr -> ((Ex, [Read]))
std::tuple<crate::lower::model::Ex, Array<crate::lower::node_::Read>> dynamic_expr(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const crate::syntax::Expr& e_p2) {
    auto v_p3 = crate::lower::expr::value_of(wx_p0.lx, menv_p1, e_p2);
    auto reads_p4 = fold(crate::check::typed::print::exprs_in(e_p2), Array<crate::lower::node_::Read>{}, [&](const Array<crate::lower::node_::Read>& acc_p5, const crate::syntax::Expr& x_p6) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::node_::Read>> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(x_p6).kind);
            if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                auto&& n_p7 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::lower::node_::Read>> _v;
                    auto&& _m = crate::prelude::get(menv_p1.names, crate::check::env::sname_key(n_p7));
                    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(_m))) {
                        auto&& f_p8 = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(_m)).a0;
                        _v.set(crate::lower::node_::add_read(acc_p5, crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{f_p8})));
                        goto _done;
                    }
                    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m))) {
                        auto&& rs_p9 = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a1;
                        _v.set(crate::lower::node_::union_reads(acc_p5, rs_p9));
                        goto _done;
                    }
                    {
                        _v.set(acc_p5);
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(acc_p5);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return std::tuple{crate::lower::types::own(v_p3), reads_p4};
}


prism_rtl::Turn<std::tuple<crate::lower::model::Ex, Array<crate::lower::node_::Read>>> DynamicExpr::cycle() const {
    const auto& wx_p0 = this->wx_p0;
    const auto& menv_p1 = this->menv_p1;
    const auto& e_p2 = this->e_p2;
    auto e_p2_1 = e_p2;
    auto menv_p1_2 = menv_p1;
    auto wx_p0_3 = wx_p0;
    return call_then(crate::lower::expr::start_value_of(prism_rtl::deref(wx_p0_3).lx, menv_p1_2, e_p2_1), [=](crate::lower::types::Vl value_of_1581) {
        return ({
            auto v_p3 = value_of_1581;
            call_then(crate::check::typed::print::start_exprs_in(e_p2_1), [=, v_p3 = std::move(v_p3)](Array<crate::syntax::Expr> exprs_in_1626) {
            return ({
                auto reads_p4 = fold(exprs_in_1626, Array<crate::lower::node_::Read>{}, [&](const Array<crate::lower::node_::Read>& acc_p5, const crate::syntax::Expr& x_p6) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<crate::lower::node_::Read>> _v;
                        auto&& _m = prism_rtl::deref(prism_rtl::deref(x_p6).kind);
                        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                            auto&& n_p7 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                            _v.set(({
                                __label__ _done;
                                prism_rtl::Slot<Array<crate::lower::node_::Read>> _v;
                                auto&& _m = crate::prelude::get(menv_p1_2->names, crate::check::env::sname_key(n_p7));
                                if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(_m))) {
                                    auto&& f_p8 = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(_m)).a0;
                                    _v.set(crate::lower::node_::add_read(acc_p5, crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{f_p8})));
                                    goto _done;
                                }
                                if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m))) {
                                    auto&& rs_p9 = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a1;
                                    _v.set(crate::lower::node_::union_reads(acc_p5, rs_p9));
                                    goto _done;
                                }
                                {
                                    _v.set(acc_p5);
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        {
                            _v.set(acc_p5);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                });
                (prism_rtl::finished(std::tuple{crate::lower::types::own(v_p3), reads_p4}));
            });
        });
        });
    });
}


/// `Start DynamicExpr, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::model::Ex, Array<crate::lower::node_::Read>>> start_dynamic_expr(crate::lower::node_::Wx wx_p0, crate::lower::types::Env menv_p1, crate::syntax::Expr e_p2) {
    return prism_rtl::make_rc<DynamicExpr>(wx_p0, menv_p1, e_p2);
}


/// NeverEvent: fn Wx, OutTy -> ((EvRef, Wx))
std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> never_event_(const crate::lower::node_::Wx& wx_p0, const crate::lower::model::OutTy& t_p1) {
    auto [id_p2, wx2_p3] = crate::lower::node_::add_gn(wx_p0, Text::lit("never"), t_p1, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnNever{}), Nat(0u));
    return std::tuple{crate::lower::node_::ev_ref_of(wx2_p3, id_p2), wx2_p3};
}


/// EventRef: unbounded fn Wx, Env, Expr -> ((EvRef, Wx))
std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> event_ref(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const crate::syntax::Expr& e_p2) {
    auto lx_p3 = wx_p0.lx;
    auto t_p4 = crate::lower::types::out_ty_of(lx_p3, crate::lower::types::peel(crate::lower::type_at(lx_p3, e_p2.span)));
    auto&& _m = prism_rtl::deref(e_p2.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p5 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return event_ref(wx_p0, menv_p1, prism_rtl::deref(prism_rtl::deref(x_p5)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p6 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        auto&& _m = crate::prelude::get(menv_p1.names, crate::check::env::sname_key(n_p6));
        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(_m))) {
            auto&& r_p7 = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(_m)).a0;
            return prism_rtl::deref(r_p7).owner == wx_p0.node_
                ? std::tuple{r_p7, wx_p0}
                : never_event_(crate::lower::node_::crossed(wx_p0, prism_rtl::cat("the event `", crate::check::env::sname_key(n_p6), "`, of node `", prism_rtl::deref(r_p7).owner, "`,")), t_p4);
        }
        {
            return never_event_(wx_p0, t_p4);
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
        auto&& m2490_2_0 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& l_p8 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r_p9 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        if (m2490_2_0 == Text::lit("<|")) {
            auto [lr_pa, w1_pb] = event_ref(wx_p0, menv_p1, prism_rtl::deref(prism_rtl::deref(l_p8)));
            auto [rr_pc, w2_pd] = event_ref(w1_pb, menv_p1, prism_rtl::deref(prism_rtl::deref(r_p9)));
            auto [nm_pe, w3_pf] = crate::lower::node_::fresh_name(w2_pd, Text::lit("anon"));
            auto [id_pg, w4_ph] = crate::lower::node_::dynamics::merge(w3_pf, nm_pe, t_p4, lr_pa, rr_pc);
            return std::tuple{crate::lower::node_::ev_ref_of(w4_ph, id_pg), w4_ph};
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
        auto&& m2490_3_0 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& l_pi = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r_pj = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        if (m2490_3_0 == Text::lit("on")) {
            auto [rr_pl, w1_pm] = event_ref(wx_p0, menv_p1, prism_rtl::deref(prism_rtl::deref(r_pj)));
            auto value_pk = crate::lower::types::own(crate::lower::expr::value_of(lx_p3, menv_p1, prism_rtl::deref(prism_rtl::deref(l_pi))));
            return std::tuple{crate::lower::node_::EvRef{.node_ = prism_rtl::deref(rr_pl).node_, .owner = prism_rtl::deref(rr_pl).owner, .pipe = ({
                auto rr_pl_1 = rr_pl;
                auto value_pk_2 = value_pk;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>)>>(prism_rtl::rc([=, rr_pl_1 = std::move(rr_pl_1), value_pk_2 = std::move(value_pk_2)](std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto rr_pl_1_3 = rr_pl_1;
                    auto value_pk_2_3 = value_pk_2;
                    entered(once_job([=, rr_pl_1_3 = std::move(rr_pl_1_3), value_pk_2_3 = std::move(value_pk_2_3)]() {
                    return ({
                        auto x_pn = p0;
                        auto k_fo = p1;
                        (prism_rtl::deref(rr_pl_1_3).pipe(std::tuple{x_pn, ({
                        auto k_fo_3 = k_fo;
                        auto value_pk_2_3_4 = value_pk_2_3;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>(prism_rtl::rc([=, k_fo_3 = std::move(k_fo_3), value_pk_2_3_4 = std::move(value_pk_2_3_4)](crate::lower::model::Ex p0) {
                        return ({
                            auto k_fo_3_4 = k_fo_3;
                            auto value_pk_2_3_4_4 = value_pk_2_3_4;
                            entered(once_job([=, k_fo_3_4 = std::move(k_fo_3_4), value_pk_2_3_4_4 = std::move(value_pk_2_3_4_4)]() {
                            return ({
                                static_cast<void>(p0);
                                k_fo_3_4(value_pk_2_3_4_4)->cycle();
                            });
                        }));
                        });
                    })));
                    })})->cycle());
                    });
                }));
                });
            })));
            })}, w1_pm};
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c_pp = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args_pq = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        auto&& _m = callee_key(lx_p3, prism_rtl::deref(prism_rtl::deref(c_pp)));
        {
            auto&& m3346_0 = _m;
            if (m3346_0 == Text::lit("Prelude.!Filter")) {
                return filter_event(wx_p0, menv_p1, args_pq, false);
            }
        }
        {
            auto&& m3346_1 = _m;
            if (m3346_1 == Text::lit("Prelude.!Present")) {
                return filter_event(wx_p0, menv_p1, args_pq, true);
            }
        }
        {
            auto&& m3346_2 = _m;
            if (m3346_2 == Text::lit("Prelude.!Gate")) {
                return gate_event(wx_p0, menv_p1, args_pq);
            }
        }
        {
            auto&& m3346_3 = _m;
            if (m3346_3 == Text::lit("Prelude.!Union")) {
                return pair_event(wx_p0, menv_p1, args_pq, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnUnion{}), t_p4);
            }
        }
        {
            auto&& m3346_4 = _m;
            if (m3346_4 == Text::lit("Prelude.!Both")) {
                return pair_event(wx_p0, menv_p1, args_pq, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnBoth{}), t_p4);
            }
        }
        {
            auto&& m3346_5 = _m;
            if (m3346_5 == Text::lit("Prelude.!Except")) {
                return pair_event(wx_p0, menv_p1, args_pq, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnExcept{}), t_p4);
            }
        }
        {
            auto&& m3346_6 = _m;
            if (m3346_6 == Text::lit("Prelude.!MergeAll")) {
                return merge_all_event(wx_p0, menv_p1, args_pq, t_p4);
            }
        }
        {
            auto&& m3346_7 = _m;
            if (m3346_7 == Text::lit("Prelude.!Updated")) {
                return updated_event(wx_p0, menv_p1, args_pq, t_p4);
            }
        }
        {
            return event_map(wx_p0, menv_p1, e_p2);
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2)) {
        auto&& m2490_5_0 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b_ps = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b_pt = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
        if (prism_rtl::is<crate::syntax::Cond::CondExpr>(prism_rtl::deref(prism_rtl::deref(m2490_5_0)))) {
            auto&& c_pr = prism_rtl::as<crate::syntax::Cond::CondExpr>(prism_rtl::deref(prism_rtl::deref(m2490_5_0))).a0;
            auto&& _m = std::tuple{block_expr(then_b_ps), block_expr(else_b_pt)};
            if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                auto&& a_pu = prism_rtl::some_of(std::get<0>(_m));
                auto&& b_pv = prism_rtl::some_of(std::get<1>(_m));
                return event_if(wx_p0, menv_p1, prism_rtl::deref(prism_rtl::deref(c_pr)), a_pu, b_pv, t_p4);
            }
            {
                return event_map(wx_p0, menv_p1, e_p2);
            }
        }
    }
    {
        return event_map(wx_p0, menv_p1, e_p2);
    }
}


prism_rtl::Turn<std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx>> EventRef::cycle() const {
    const auto& wx_p0 = this->wx_p0;
    const auto& menv_p1 = this->menv_p1;
    const auto& e_p2 = this->e_p2;
    auto lx_p3 = prism_rtl::deref(wx_p0).lx;
    auto e_p2_1 = e_p2;
    auto menv_p1_2 = menv_p1;
    auto wx_p0_3 = wx_p0;
    return call_then(crate::lower::types::start_out_ty_of(lx_p3, crate::lower::types::peel(crate::lower::type_at(lx_p3, prism_rtl::deref(e_p2_1).span))), [=](crate::lower::model::OutTy out_ty_of_2447) {
        return ({
            auto t_p4 = out_ty_of_2447;
            ({
            auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p2_1).kind);
            prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
            auto&& x_p5 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
            prism_rtl::more(prism_rtl::rc(EventRef(wx_p0_3, menv_p1_2, prism_rtl::deref(prism_rtl::deref(x_p5)))));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
            auto&& n_p6 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            ({
            auto&& _m = crate::prelude::get(menv_p1_2->names, crate::check::env::sname_key(n_p6));
            prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(_m)) ? ({
            auto&& r_p7 = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(_m)).a0;
            prism_rtl::deref(r_p7).owner == prism_rtl::deref(wx_p0_3).node_
            ? prism_rtl::finished(std::tuple{r_p7, wx_p0_3})
            : prism_rtl::finished(never_event_(crate::lower::node_::crossed(wx_p0_3, prism_rtl::cat("the event `", crate::check::env::sname_key(n_p6), "`, of node `", prism_rtl::deref(r_p7).owner, "`,")), t_p4));
        })
            : prism_rtl::finished(never_event_(wx_p0_3, t_p4));
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m) && ({
            auto&& m2490_2_0 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
            auto&& l_p8 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
            auto&& r_p9 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
            (m2490_2_0 == Text::lit("<|"));
        }) ? ({
            auto&& m2490_2_0 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
            auto&& l_p8 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
            auto&& r_p9 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
            ({
            auto l_p8_4 = prism_rtl::deref(prism_rtl::deref(l_p8));
            auto r_p9_5 = prism_rtl::deref(prism_rtl::deref(r_p9));
            call_then(start_event_ref(wx_p0_3, menv_p1_2, l_p8_4), [=, r_p9_5 = std::move(r_p9_5)](std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> event_ref_2867) {
            return ({
                auto [lr_pa, w1_pb] = event_ref_2867;
                call_then(start_event_ref(w1_pb, menv_p1_2, r_p9_5), [=](std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> event_ref_2917) {
                return ({
                    auto [rr_pc, w2_pd] = event_ref_2917;
                    auto [nm_pe, w3_pf] = crate::lower::node_::fresh_name(w2_pd, Text::lit("anon"));
                    auto [id_pg, w4_ph] = crate::lower::node_::dynamics::merge(w3_pf, nm_pe, t_p4, lr_pa, rr_pc);
                    (prism_rtl::finished(std::tuple{crate::lower::node_::ev_ref_of(w4_ph, id_pg), w4_ph}));
                });
            });
            });
        });
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m) && ({
            auto&& m2490_3_0 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
            auto&& l_pi = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
            auto&& r_pj = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
            (m2490_3_0 == Text::lit("on"));
        }) ? ({
            auto&& m2490_3_0 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
            auto&& l_pi = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
            auto&& r_pj = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
            ({
            auto l_pi_4 = prism_rtl::deref(prism_rtl::deref(l_pi));
            auto r_pj_5 = prism_rtl::deref(prism_rtl::deref(r_pj));
            call_then(start_event_ref(wx_p0_3, menv_p1_2, r_pj_5), [=, l_pi_4 = std::move(l_pi_4)](std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> event_ref_3135) {
            return ({
                auto [rr_pl, w1_pm] = event_ref_3135;
                call_then(crate::lower::expr::start_value_of(lx_p3, menv_p1_2, l_pi_4), [=](crate::lower::types::Vl value_of_3185) {
                return ({
                    auto value_pk = crate::lower::types::own(value_of_3185);
                    (prism_rtl::finished(std::tuple{crate::lower::node_::EvRef{.node_ = prism_rtl::deref(rr_pl).node_, .owner = prism_rtl::deref(rr_pl).owner, .pipe = ({
                    auto rr_pl_6 = rr_pl;
                    auto value_pk_7 = value_pk;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>)>>(prism_rtl::rc([=, rr_pl_6 = std::move(rr_pl_6), value_pk_7 = std::move(value_pk_7)](std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto rr_pl_6_8 = rr_pl_6;
                        auto value_pk_7_8 = value_pk_7;
                        entered(once_job([=, rr_pl_6_8 = std::move(rr_pl_6_8), value_pk_7_8 = std::move(value_pk_7_8)]() {
                        return ({
                            auto x_pn = p0;
                            auto k_fo = p1;
                            (prism_rtl::deref(rr_pl_6_8).pipe(std::tuple{x_pn, ({
                            auto k_fo_8 = k_fo;
                            auto value_pk_7_8_9 = value_pk_7_8;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>(prism_rtl::rc([=, k_fo_8 = std::move(k_fo_8), value_pk_7_8_9 = std::move(value_pk_7_8_9)](crate::lower::model::Ex p0) {
                            return ({
                                auto k_fo_8_9 = k_fo_8;
                                auto value_pk_7_8_9_9 = value_pk_7_8_9;
                                entered(once_job([=, k_fo_8_9 = std::move(k_fo_8_9), value_pk_7_8_9_9 = std::move(value_pk_7_8_9_9)]() {
                                return ({
                                    static_cast<void>(p0);
                                    k_fo_8_9(value_pk_7_8_9_9)->cycle();
                                });
                            }));
                            });
                        })));
                        })})->cycle());
                        });
                    }));
                    });
                })));
                })}, w1_pm}));
                });
            });
            });
        });
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::ECall>(_m) ? ({
            auto&& c_pp = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
            auto&& args_pq = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
            ({
            auto&& _m = callee_key(lx_p3, prism_rtl::deref(prism_rtl::deref(c_pp)));
            ({
            auto&& m3346_0 = _m;
            (m3346_0 == Text::lit("Prelude.!Filter"));
        }) ? ({
            auto&& m3346_0 = _m;
            prism_rtl::finished(filter_event(wx_p0_3, menv_p1_2, args_pq, false));
        })
            : ({
            auto&& m3346_1 = _m;
            (m3346_1 == Text::lit("Prelude.!Present"));
        }) ? ({
            auto&& m3346_1 = _m;
            prism_rtl::finished(filter_event(wx_p0_3, menv_p1_2, args_pq, true));
        })
            : ({
            auto&& m3346_2 = _m;
            (m3346_2 == Text::lit("Prelude.!Gate"));
        }) ? ({
            auto&& m3346_2 = _m;
            prism_rtl::finished(gate_event(wx_p0_3, menv_p1_2, args_pq));
        })
            : ({
            auto&& m3346_3 = _m;
            (m3346_3 == Text::lit("Prelude.!Union"));
        }) ? ({
            auto&& m3346_3 = _m;
            prism_rtl::finished(pair_event(wx_p0_3, menv_p1_2, args_pq, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnUnion{}), t_p4));
        })
            : ({
            auto&& m3346_4 = _m;
            (m3346_4 == Text::lit("Prelude.!Both"));
        }) ? ({
            auto&& m3346_4 = _m;
            prism_rtl::finished(pair_event(wx_p0_3, menv_p1_2, args_pq, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnBoth{}), t_p4));
        })
            : ({
            auto&& m3346_5 = _m;
            (m3346_5 == Text::lit("Prelude.!Except"));
        }) ? ({
            auto&& m3346_5 = _m;
            prism_rtl::finished(pair_event(wx_p0_3, menv_p1_2, args_pq, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnExcept{}), t_p4));
        })
            : ({
            auto&& m3346_6 = _m;
            (m3346_6 == Text::lit("Prelude.!MergeAll"));
        }) ? ({
            auto&& m3346_6 = _m;
            prism_rtl::finished(merge_all_event(wx_p0_3, menv_p1_2, args_pq, t_p4));
        })
            : ({
            auto&& m3346_7 = _m;
            (m3346_7 == Text::lit("Prelude.!Updated"));
        }) ? ({
            auto&& m3346_7 = _m;
            prism_rtl::finished(updated_event(wx_p0_3, menv_p1_2, args_pq, t_p4));
        })
            : prism_rtl::finished(event_map(wx_p0_3, menv_p1_2, e_p2_1));
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2) && ({
            auto&& m2490_5_0 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
            auto&& then_b_ps = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
            auto&& else_b_pt = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
            prism_rtl::is<crate::syntax::Cond::CondExpr>(prism_rtl::deref(prism_rtl::deref(m2490_5_0)));
        }) ? ({
            auto&& m2490_5_0 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
            auto&& then_b_ps = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
            auto&& else_b_pt = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
            auto&& c_pr = prism_rtl::as<crate::syntax::Cond::CondExpr>(prism_rtl::deref(prism_rtl::deref(m2490_5_0))).a0;
            ({
            auto&& _m = std::tuple{block_expr(then_b_ps), block_expr(else_b_pt)};
            prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m)) ? ({
            auto&& a_pu = prism_rtl::some_of(std::get<0>(_m));
            auto&& b_pv = prism_rtl::some_of(std::get<1>(_m));
            prism_rtl::finished(event_if(wx_p0_3, menv_p1_2, prism_rtl::deref(prism_rtl::deref(c_pr)), a_pu, b_pv, t_p4));
        })
            : prism_rtl::finished(event_map(wx_p0_3, menv_p1_2, e_p2_1));
        });
        })
            : prism_rtl::finished(event_map(wx_p0_3, menv_p1_2, e_p2_1));
        });
        });
    });
}


/// `Start EventRef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx>> start_event_ref(crate::lower::node_::Wx wx_p0, crate::lower::types::Env menv_p1, crate::syntax::Expr e_p2) {
    return prism_rtl::make_rc<EventRef>(wx_p0, menv_p1, e_p2);
}


/// EventIf: unbounded fn Wx, Env, Expr, Expr, Expr, OutTy -> ((EvRef, Wx))
std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> event_if(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const crate::syntax::Expr& c_p2, const crate::syntax::Expr& a_p3, const crate::syntax::Expr& b_p4, const crate::lower::model::OutTy& t_p5) {
    auto cond_p6 = crate::lower::types::as_bool(crate::lower::expr::value_of(wx_p0.lx, menv_p1, c_p2));
    auto [ra_p9, w1_pa] = event_ref(wx_p0, menv_p1, a_p3);
    auto [rb_pb, w2_pc] = event_ref(w1_pa, menv_p1, b_p4);
    auto ga_p7 = crate::lower::node_::EvRef{.node_ = prism_rtl::deref(ra_p9).node_, .owner = prism_rtl::deref(ra_p9).owner, .pipe = ({
        auto ra_p9_1 = ra_p9;
        auto cond_p6_2 = cond_p6;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>)>>(prism_rtl::rc([=, ra_p9_1 = std::move(ra_p9_1), cond_p6_2 = std::move(cond_p6_2)](std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto ra_p9_1_3 = ra_p9_1;
            auto cond_p6_2_3 = cond_p6_2;
            entered(once_job([=, ra_p9_1_3 = std::move(ra_p9_1_3), cond_p6_2_3 = std::move(cond_p6_2_3)]() {
            return ({
                auto x_pd = p0;
                auto k_fe = p1;
                (prism_rtl::deref(ra_p9_1_3).pipe(std::tuple{x_pd, ({
                auto cond_p6_2_3_3 = cond_p6_2_3;
                auto k_fe_3 = k_fe;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>(prism_rtl::rc([=, cond_p6_2_3_3 = std::move(cond_p6_2_3_3), k_fe_3 = std::move(k_fe_3)](crate::lower::model::Ex p0) {
                return ({
                    auto cond_p6_2_3_3_4 = cond_p6_2_3_3;
                    auto k_fe_3_4 = k_fe_3;
                    entered(once_job([=, cond_p6_2_3_3_4 = std::move(cond_p6_2_3_3_4), k_fe_3_4 = std::move(k_fe_3_4)]() {
                    return ({
                        auto y_pf = p0;
                        call_value(k_fe_3_4(y_pf), [=](Array<crate::lower::model::Do> k_4624) { return prism_rtl::finished(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIf{cond_p6_2_3_3_4, k_4624, Array<crate::lower::model::Do>{}})})); });
                    });
                }));
                });
            })));
            })})->cycle());
            });
        }));
        });
    })));
    })};
    auto gb_p8 = crate::lower::node_::EvRef{.node_ = prism_rtl::deref(rb_pb).node_, .owner = prism_rtl::deref(rb_pb).owner, .pipe = ({
        auto rb_pb_1 = rb_pb;
        auto cond_p6_2 = cond_p6;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>)>>(prism_rtl::rc([=, rb_pb_1 = std::move(rb_pb_1), cond_p6_2 = std::move(cond_p6_2)](std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto rb_pb_1_3 = rb_pb_1;
            auto cond_p6_2_3 = cond_p6_2;
            entered(once_job([=, rb_pb_1_3 = std::move(rb_pb_1_3), cond_p6_2_3 = std::move(cond_p6_2_3)]() {
            return ({
                auto x_pg = p0;
                auto k_fh = p1;
                (prism_rtl::deref(rb_pb_1_3).pipe(std::tuple{x_pg, ({
                auto cond_p6_2_3_3 = cond_p6_2_3;
                auto k_fh_3 = k_fh;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>(prism_rtl::rc([=, cond_p6_2_3_3 = std::move(cond_p6_2_3_3), k_fh_3 = std::move(k_fh_3)](crate::lower::model::Ex p0) {
                return ({
                    auto cond_p6_2_3_3_4 = cond_p6_2_3_3;
                    auto k_fh_3_4 = k_fh_3;
                    entered(once_job([=, cond_p6_2_3_3_4 = std::move(cond_p6_2_3_3_4), k_fh_3_4 = std::move(k_fh_3_4)]() {
                    return ({
                        auto y_pi = p0;
                        call_value(k_fh_3_4(y_pi), [=](Array<crate::lower::model::Do> k_4762) { return prism_rtl::finished(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("=="), prism_rtl::rc(cond_p6_2_3_3_4), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XBool{false}))}), k_4762, Array<crate::lower::model::Do>{}})})); });
                    });
                }));
                });
            })));
            })})->cycle());
            });
        }));
        });
    })));
    })};
    auto [nm_pj, w3_pk] = crate::lower::node_::fresh_name(w2_pc, Text::lit("chosen"));
    auto [id_pl, w4_pm] = crate::lower::node_::dynamics::merge(w3_pk, nm_pj, t_p5, ga_p7, gb_p8);
    return std::tuple{crate::lower::node_::ev_ref_of(w4_pm, id_pl), w4_pm};
}


/// ?BlockExpr: fn Block -> ?Expr
std::optional<crate::syntax::Expr> block_expr(const crate::syntax::Block& b_p0) {
    auto&& _m = b_p0.stmts;
    {
        auto&& m4996_0 = _m;
        if (m4996_0.size() == 1u) {
            {
                auto&& _c1 = index(m4996_0, Nat(0u));
                if (prism_rtl::is_some(_c1)) {
                    auto&& st_p1 = prism_rtl::some_of(_c1);
                    auto&& _m = prism_rtl::deref(st_p1).kind;
                    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
                        auto&& x_p2 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                        return std::optional(x_p2);
                    }
                    {
                        return std::optional<crate::syntax::Expr>{};
                    }
                }
            }
        }
    }
    {
        return std::optional<crate::syntax::Expr>{};
    }
}


/// CalleeKey: fn Lx, Expr -> Text
Text callee_key(const crate::lower::Lx& lx_p0, const crate::syntax::Expr& c_p1) {
    auto&& _m = prism_rtl::deref(c_p1.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p2 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        auto&& _q_o3 = crate::check::env::names::resolve_value(lx_p0.g, lx_p0.home, n_p2);
        auto&& q_o3 = std::get<0>(_q_o3);
        return or_(q_o3, Text::lit(""));
    }
    {
        return Text::lit("");
    }
}


/// PairEvent: unbounded fn Wx, Env, [Arg], GnKind, OutTy -> ((EvRef, Wx))
std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> pair_event(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const Array<crate::syntax::Arg>& args_p2, const crate::lower::node_::GnKind& kind_p3, const crate::lower::model::OutTy& t_p4) {
    auto&& _m = std::tuple{index(args_p2, Nat(0u)), index(args_p2, Nat(1u))};
    if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
        auto&& a_p5 = prism_rtl::some_of(std::get<0>(_m));
        auto&& b_p6 = prism_rtl::some_of(std::get<1>(_m));
        auto [ra_p9, w1_pa] = event_ref(wx_p0, menv_p1, a_p5->value);
        auto [rb_pb, w2_pc] = event_ref(w1_pa, menv_p1, b_p6->value);
        auto lt_p7 = crate::lower::types::out_ty_of(wx_p0.lx, crate::lower::types::peel(crate::lower::type_at(wx_p0.lx, prism_rtl::deref(a_p5->value).span)));
        auto rt_p8 = crate::lower::types::out_ty_of(wx_p0.lx, crate::lower::types::peel(crate::lower::type_at(wx_p0.lx, prism_rtl::deref(b_p6->value).span)));
        auto [nm_pd, w3_pe] = crate::lower::node_::fresh_name(w2_pc, crate::lower::node_::kind_word(kind_p3));
        auto [id_pf, w4_pg] = combinator(w3_pe, nm_pd, t_p4, kind_p3, ra_p9, rb_pb, lt_p7, rt_p8);
        return std::tuple{crate::lower::node_::ev_ref_of(w4_pg, id_pf), w4_pg};
    }
    {
        return never_event_(wx_p0, t_p4);
    }
}


/// MergeAllEvent: unbounded fn Wx, Env, [Arg], OutTy -> ((EvRef, Wx))
std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> merge_all_event(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const Array<crate::syntax::Arg>& args_p2, const crate::lower::model::OutTy& t_p3) {
    auto&& _m = index(args_p2, Nat(0u));
    if (prism_rtl::is_some(_m)) {
        auto&& a_p4 = prism_rtl::some_of(_m);
        auto&& _m = prism_rtl::deref(prism_rtl::deref(a_p4->value).kind);
        if (prism_rtl::is<crate::syntax::ExprKind::EArray>(_m)) {
            auto&& es_p5 = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
            auto et_p6 = ({
                __label__ _done;
                prism_rtl::Slot<crate::lower::model::OutTy> _v;
                if (prism_rtl::is<crate::lower::model::OutTy::OutArray>(t_p3)) {
                    auto&& x_pb = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t_p3).a0;
                    _v.set(prism_rtl::deref(prism_rtl::deref(x_pb)));
                    goto _done;
                }
                {
                    _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto [nm_pc, w1_pd] = crate::lower::node_::fresh_name(wx_p0, Text::lit("merged"));
            auto [id_pe, w2_pf] = crate::lower::node_::add_gn(w1_pd, nm_pc, t_p3, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnMergeAll{}), Nat(1u));
            auto ins_p7 = each(crate::check::errors::range0(len(es_p5)), [&](const Nat& i_pg) { return prism_rtl::cat(nm_pc, "_", i_pg); });
            auto w3_p8 = fold(ins_p7, w2_pf, [&](const crate::lower::node_::Wx& w_ph, const Text& f_pi) { return crate::lower::node_::add_field_last(w_ph, f_pi, crate::lower::model::OutTy(crate::lower::model::OutTy::OutStamped{prism_rtl::rc(et_p6)}), Text::lit("an input of `!MergeAll`"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Stamped::new"), Array<crate::lower::model::Ex>{}})); });
            auto w4_p9 = ({
                crate::lower::node_::Wx this_ = w3_p8;
                this_.gns = each(this_.gns, [&](const crate::lower::node_::Gn& n_pj) { return prism_rtl::deref(n_pj).id == id_pe ? with_inputs(n_pj, ins_p7) : n_pj; });
                (std::move(this_));
            });
            auto w5_pa = run_to_end(fold_job(crate::check::errors::range0(len(es_p5)), w4_p9, ({
                auto menv_p1_1 = menv_p1;
                auto es_p5_2 = es_p5;
                auto a_p4_3 = a_p4;
                auto id_pe_4 = id_pe;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::node_::Wx>(std::tuple<crate::lower::node_::Wx, Nat>)>>(prism_rtl::rc([=, menv_p1_1 = std::move(menv_p1_1), es_p5_2 = std::move(es_p5_2), a_p4_3 = std::move(a_p4_3), id_pe_4 = std::move(id_pe_4)](std::tuple<crate::lower::node_::Wx, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto menv_p1_1_5 = menv_p1_1;
                    auto es_p5_2_5 = es_p5_2;
                    auto a_p4_3_5 = a_p4_3;
                    auto id_pe_4_5 = id_pe_4;
                    entered(once_job([=, menv_p1_1_5 = std::move(menv_p1_1_5), es_p5_2_5 = std::move(es_p5_2_5), a_p4_3_5 = std::move(a_p4_3_5), id_pe_4_5 = std::move(id_pe_4_5)]() {
                    return ({
                        auto w_pk = p0;
                        auto i_pl = p1;
                        call_then(start_event_ref(w_pk, menv_p1_1_5, or_(index(es_p5_2_5, i_pl), a_p4_3_5->value)), [=](std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> event_ref_6930) {
                        return ({
                            auto [r_pm, w6_pn] = event_ref_6930;
                            (prism_rtl::finished(crate::lower::node_::connect(w6_pn, r_pm, crate::lower::node_::Sk(crate::lower::node_::Sk::SkIn{id_pe_4_5, i_pl}))));
                        });
                    });
                    });
                }));
                });
            })));
            })));
            return std::tuple{crate::lower::node_::ev_ref_of(w5_pa, id_pe), w5_pa};
        }
        {
            auto [r_pp, w1_pq] = never_event_(wx_p0, t_p3);
            auto w2_po = ({
                crate::lower::node_::Wx this_ = w1_pq;
                this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("`!MergeAll` of a list that is not a literal")));
                (std::move(this_));
            });
            return std::tuple{r_pp, w2_po};
        }
    }
    if (prism_rtl::is_none(_m)) {
        return never_event_(wx_p0, t_p3);
    }
    prism_rtl::unreachable("no arm matched");
}


/// UpdatedEvent: unbounded fn Wx, Env, [Arg], OutTy -> ((EvRef, Wx))
std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> updated_event(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const Array<crate::syntax::Arg>& args_p2, const crate::lower::model::OutTy& t_p3) {
    auto&& _m = index(args_p2, Nat(0u));
    if (prism_rtl::is_some(_m)) {
        auto&& a_p4 = prism_rtl::some_of(_m);
        auto [ex_p7, reads_p8] = dynamic_expr(wx_p0, menv_p1, a_p4->value);
        auto [nm_p9, w1_pa] = crate::lower::node_::fresh_name(wx_p0, Text::lit("updated"));
        auto [id_pb, w2_pc] = crate::lower::node_::add_gn(w1_pa, nm_p9, t_p3, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnUpdated{}), Nat(1u));
        auto w3_p5 = crate::lower::node_::add_field_last(w2_pc, prism_rtl::cat(nm_p9, "_moved"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Cell"), Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})})}), prism_rtl::cat("a hold `!", nm_p9, "`\'s dynamic reads was written this tick"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Cell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XBool{false})})}));
        auto w4_p6 = ({
            crate::lower::node_::Wx this_ = w3_p5;
            this_.gns = each(this_.gns, [&](const crate::lower::node_::Gn& n_pd) { return prism_rtl::deref(n_pd).id == id_pb ? with_reads(n_pd, reads_p8) : n_pd; });
            this_.getters = crate::prelude::push(this_.getters, crate::lower::model::MethDef{.name = prism_rtl::cat(nm_p9, "_value"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = t_p3, .body = Array<crate::lower::model::Do>{}, .tail = ex_p7, .doc = prism_rtl::cat("The dynamic `!", nm_p9, "` is the event half of, which the wake reads after the tick.")});
            (std::move(this_));
        });
        return std::tuple{crate::lower::node_::ev_ref_of(w4_p6, id_pb), w4_p6};
    }
    if (prism_rtl::is_none(_m)) {
        return never_event_(wx_p0, t_p3);
    }
    prism_rtl::unreachable("no arm matched");
}


/// FilterEvent: unbounded fn Wx, Env, [Arg], Bool -> ((EvRef, Wx))
std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> filter_event(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const Array<crate::syntax::Arg>& args_p2, const bool& is_unit_p3) {
    auto&& _m = index(args_p2, Nat(0u));
    if (prism_rtl::is_none(_m)) {
        return never_event_(wx_p0, crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
    }
    if (prism_rtl::is_some(_m)) {
        auto&& a_p4 = prism_rtl::some_of(_m);
        auto [r_p7, w1_p8] = event_ref(wx_p0, menv_p1, a_p4->value);
        auto bound_p5 = is_unit_p3
            ? crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})
            : crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("w")});
        auto pipe_f6 = ({
            auto r_p7_1 = r_p7;
            auto bound_p5_2 = bound_p5;
            auto is_unit_p3_3 = is_unit_p3;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>)>>(prism_rtl::rc([=, r_p7_1 = std::move(r_p7_1), bound_p5_2 = std::move(bound_p5_2), is_unit_p3_3 = std::move(is_unit_p3_3)](std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto r_p7_1_4 = r_p7_1;
                auto bound_p5_2_4 = bound_p5_2;
                auto is_unit_p3_3_4 = is_unit_p3_3;
                entered(once_job([=, r_p7_1_4 = std::move(r_p7_1_4), bound_p5_2_4 = std::move(bound_p5_2_4), is_unit_p3_3_4 = std::move(is_unit_p3_3_4)]() {
                return ({
                    auto x_p9 = p0;
                    auto k_fa = p1;
                    (prism_rtl::deref(r_p7_1_4).pipe(std::tuple{x_p9, ({
                    auto bound_p5_2_4_4 = bound_p5_2_4;
                    auto k_fa_4 = k_fa;
                    auto is_unit_p3_3_4_5 = is_unit_p3_3_4;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>(prism_rtl::rc([=, bound_p5_2_4_4 = std::move(bound_p5_2_4_4), k_fa_4 = std::move(k_fa_4), is_unit_p3_3_4_5 = std::move(is_unit_p3_3_4_5)](crate::lower::model::Ex p0) {
                    return ({
                        auto bound_p5_2_4_4_5 = bound_p5_2_4_4;
                        auto k_fa_4_5 = k_fa_4;
                        auto is_unit_p3_3_4_5_5 = is_unit_p3_3_4_5;
                        entered(once_job([=, bound_p5_2_4_4_5 = std::move(bound_p5_2_4_4_5), k_fa_4_5 = std::move(k_fa_4_5), is_unit_p3_3_4_5_5 = std::move(is_unit_p3_3_4_5_5)]() {
                        return ({
                            auto y_pb = p0;
                            call_value(k_fa_4_5(is_unit_p3_3_4_5_5
                            ? crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})
                            : crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("w")})), [=, y_pb = std::move(y_pb)](Array<crate::lower::model::Do> k_9292) { return prism_rtl::finished(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{bound_p5_2_4_4_5})}), y_pb, k_9292, Array<crate::lower::model::Do>{}})})); });
                        });
                    }));
                    });
                })));
                })})->cycle());
                });
            }));
            });
        })));
        });
        return std::tuple{crate::lower::node_::EvRef{.node_ = prism_rtl::deref(r_p7).node_, .owner = prism_rtl::deref(r_p7).owner, .pipe = pipe_f6}, w1_p8};
    }
    prism_rtl::unreachable("no arm matched");
}


/// GateEvent: unbounded fn Wx, Env, [Arg] -> ((EvRef, Wx))
std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> gate_event(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const Array<crate::syntax::Arg>& args_p2) {
    auto&& _m = index(args_p2, Nat(1u));
    if (prism_rtl::is_none(_m)) {
        return never_event_(wx_p0, crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
    }
    if (prism_rtl::is_some(_m)) {
        auto&& a_p3 = prism_rtl::some_of(_m);
        auto [r_p6, w1_p7] = event_ref(wx_p0, menv_p1, a_p3->value);
        auto cond_p4 = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::Ex> _v;
            auto&& _m = index(args_p2, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& b_p8 = prism_rtl::some_of(_m);
                _v.set(crate::lower::types::as_bool(crate::lower::expr::value_of(wx_p0.lx, menv_p1, b_p8->value)));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XBool{false}));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto pipe_f5 = ({
            auto r_p6_1 = r_p6;
            auto cond_p4_2 = cond_p4;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>)>>(prism_rtl::rc([=, r_p6_1 = std::move(r_p6_1), cond_p4_2 = std::move(cond_p4_2)](std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto r_p6_1_3 = r_p6_1;
                auto cond_p4_2_3 = cond_p4_2;
                entered(once_job([=, r_p6_1_3 = std::move(r_p6_1_3), cond_p4_2_3 = std::move(cond_p4_2_3)]() {
                return ({
                    auto x_p9 = p0;
                    auto k_fa = p1;
                    (prism_rtl::deref(r_p6_1_3).pipe(std::tuple{x_p9, ({
                    auto cond_p4_2_3_3 = cond_p4_2_3;
                    auto k_fa_3 = k_fa;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>(prism_rtl::rc([=, cond_p4_2_3_3 = std::move(cond_p4_2_3_3), k_fa_3 = std::move(k_fa_3)](crate::lower::model::Ex p0) {
                    return ({
                        auto cond_p4_2_3_3_4 = cond_p4_2_3_3;
                        auto k_fa_3_4 = k_fa_3;
                        entered(once_job([=, cond_p4_2_3_3_4 = std::move(cond_p4_2_3_3_4), k_fa_3_4 = std::move(k_fa_3_4)]() {
                        return ({
                            auto y_pb = p0;
                            call_value(k_fa_3_4(y_pb), [=](Array<crate::lower::model::Do> k_9825) { return prism_rtl::finished(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIf{cond_p4_2_3_3_4, k_9825, Array<crate::lower::model::Do>{}})})); });
                        });
                    }));
                    });
                })));
                })})->cycle());
                });
            }));
            });
        })));
        });
        return std::tuple{crate::lower::node_::EvRef{.node_ = prism_rtl::deref(r_p6).node_, .owner = prism_rtl::deref(r_p6).owner, .pipe = pipe_f5}, w1_p7};
    }
    prism_rtl::unreachable("no arm matched");
}


/// EventMap: unbounded fn Wx, Env, Expr -> ((EvRef, Wx))
std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> event_map(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const crate::syntax::Expr& e_p2) {
    auto lx_p3 = wx_p0.lx;
    auto t_p4 = crate::lower::types::out_ty_of(lx_p3, crate::lower::types::peel(crate::lower::type_at(lx_p3, e_p2.span)));
    auto evs_p5 = filter(operands(e_p2), [&](const crate::syntax::Expr& x_p6) { return crate::lower::types::layer_of(crate::lower::type_at(lx_p3, prism_rtl::deref(x_p6).span)) == crate::lower::types::Layer(crate::lower::types::Layer::LyEv{}); });
    {
        auto&& m10307_0 = evs_p5;
        if (m10307_0.size() == 1u) {
            {
                auto&& _c1 = index(m10307_0, Nat(0u));
                if (prism_rtl::is_some(_c1)) {
                    auto&& one_p7 = prism_rtl::some_of(_c1);
                    auto [r_pb, w1_pc] = event_ref(wx_p0, menv_p1, one_p7);
                    auto et_p8 = crate::lower::types::out_ty_of(lx_p3, crate::lower::types::peel(crate::lower::type_at(lx_p3, prism_rtl::deref(one_p7).span)));
                    auto k_p9 = crate::lower::place_key(lx_p3, prism_rtl::deref(one_p7).span);
                    auto pipe_fa = ({
                        auto r_pb_1 = r_pb;
                        auto lx_p3_2 = lx_p3;
                        auto menv_p1_3 = menv_p1;
                        auto k_p9_4 = k_p9;
                        auto et_p8_5 = et_p8;
                        auto e_p2_6 = e_p2;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>)>>(prism_rtl::rc([=, r_pb_1 = std::move(r_pb_1), lx_p3_2 = std::move(lx_p3_2), menv_p1_3 = std::move(menv_p1_3), k_p9_4 = std::move(k_p9_4), et_p8_5 = std::move(et_p8_5), e_p2_6 = std::move(e_p2_6)](std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto r_pb_1_7 = r_pb_1;
                            auto lx_p3_2_7 = lx_p3_2;
                            auto menv_p1_3_7 = menv_p1_3;
                            auto k_p9_4_7 = k_p9_4;
                            auto et_p8_5_7 = et_p8_5;
                            auto e_p2_6_7 = e_p2_6;
                            entered(once_job([=, r_pb_1_7 = std::move(r_pb_1_7), lx_p3_2_7 = std::move(lx_p3_2_7), menv_p1_3_7 = std::move(menv_p1_3_7), k_p9_4_7 = std::move(k_p9_4_7), et_p8_5_7 = std::move(et_p8_5_7), e_p2_6_7 = std::move(e_p2_6_7)]() {
                            return ({
                                auto x_pd = p0;
                                auto k_fe = p1;
                                (prism_rtl::deref(r_pb_1_7).pipe(std::tuple{x_pd, ({
                                auto k_fe_7 = k_fe;
                                auto lx_p3_2_7_8 = lx_p3_2_7;
                                auto menv_p1_3_7_8 = menv_p1_3_7;
                                auto k_p9_4_7_8 = k_p9_4_7;
                                auto et_p8_5_7_8 = et_p8_5_7;
                                auto e_p2_6_7_8 = e_p2_6_7;
                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>(prism_rtl::rc([=, k_fe_7 = std::move(k_fe_7), lx_p3_2_7_8 = std::move(lx_p3_2_7_8), menv_p1_3_7_8 = std::move(menv_p1_3_7_8), k_p9_4_7_8 = std::move(k_p9_4_7_8), et_p8_5_7_8 = std::move(et_p8_5_7_8), e_p2_6_7_8 = std::move(e_p2_6_7_8)](crate::lower::model::Ex p0) {
                                return ({
                                    auto k_fe_7_8 = k_fe_7;
                                    auto lx_p3_2_7_8_8 = lx_p3_2_7_8;
                                    auto menv_p1_3_7_8_8 = menv_p1_3_7_8;
                                    auto k_p9_4_7_8_8 = k_p9_4_7_8;
                                    auto et_p8_5_7_8_8 = et_p8_5_7_8;
                                    auto e_p2_6_7_8_8 = e_p2_6_7_8;
                                    entered(once_job([=, k_fe_7_8 = std::move(k_fe_7_8), lx_p3_2_7_8_8 = std::move(lx_p3_2_7_8_8), menv_p1_3_7_8_8 = std::move(menv_p1_3_7_8_8), k_p9_4_7_8_8 = std::move(k_p9_4_7_8_8), et_p8_5_7_8_8 = std::move(et_p8_5_7_8_8), e_p2_6_7_8_8 = std::move(e_p2_6_7_8_8)]() {
                                    return ({
                                        auto y_pf = p0;
                                        call_then(crate::lower::expr::start_value_of(lx_p3_2_7_8_8, crate::lower::types::bind_span(menv_p1_3_7_8_8, k_p9_4_7_8_8, firing_value(y_pf, et_p8_5_7_8_8)), e_p2_6_7_8_8), [=](crate::lower::types::Vl value_of_10544) { return k_fe_7_8(crate::lower::types::own(value_of_10544))->cycle(); });
                                    });
                                }));
                                });
                            })));
                            })})->cycle());
                            });
                        }));
                        });
                    })));
                    });
                    return std::tuple{crate::lower::node_::EvRef{.node_ = prism_rtl::deref(r_pb).node_, .owner = prism_rtl::deref(r_pb).owner, .pipe = pipe_fa}, w1_pc};
                }
            }
        }
    }
    {
        return never_event_(wx_p0, t_p4);
    }
}


/// FiringValue: fn Ex, OutTy -> Vl
crate::lower::types::Vl firing_value(const crate::lower::model::Ex& ex0, const crate::lower::model::OutTy& t_p1) {
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(ex0)) {
        auto&& n_p0 = prism_rtl::as<crate::lower::model::Ex::XVar>(ex0).a0;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XVar{n_p0}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t_p1});
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUnit>(ex0)) {
        return crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t_p1});
    }
    {
        auto&& x_p3 = ex0;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{x_p3, t_p1});
    }
}


/// Operands: fn Expr -> [Expr]
Array<crate::syntax::Expr> operands(const crate::syntax::Expr& e_p0) {
    auto&& _m = prism_rtl::deref(e_p0.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c_p1 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args_p2 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        return append(Array(std::vector{prism_rtl::deref(prism_rtl::deref(c_p1))}), each(args_p2, [&](const crate::syntax::Arg& a_p3) { return a_p3->value; }));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m)) {
        auto&& r_p4 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
        auto&& args_p5 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
        return append(Array(std::vector{prism_rtl::deref(prism_rtl::deref(r_p4))}), each(args_p5, [&](const crate::syntax::Arg& a_p6) { return a_p6->value; }));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
        auto&& l_p7 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r_p8 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        return Array(std::vector{prism_rtl::deref(prism_rtl::deref(l_p7)), prism_rtl::deref(prism_rtl::deref(r_p8))});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m)) {
        auto&& x_p9 = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
        return Array(std::vector{prism_rtl::deref(prism_rtl::deref(x_p9))});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
        auto&& x_pa = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        return Array(std::vector{prism_rtl::deref(prism_rtl::deref(x_pa))});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_pb = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return Array(std::vector{prism_rtl::deref(prism_rtl::deref(x_pb))});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        auto&& r_pc = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        return Array(std::vector{prism_rtl::deref(prism_rtl::deref(r_pc))});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r_pd = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& i_pe = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        return Array(std::vector{prism_rtl::deref(prism_rtl::deref(r_pd)), prism_rtl::deref(prism_rtl::deref(i_pe))});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m)) {
        auto&& es_pf = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
        return es_pf;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EArray>(_m)) {
        auto&& es_pg = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
        return es_pg;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMap>(_m)) {
        auto&& kvs_ph = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
        return fold(kvs_ph, Array<crate::syntax::Expr>{}, [&](const Array<crate::syntax::Expr>& acc_pi, const std::tuple<crate::syntax::Expr, crate::syntax::Expr>& _p1) {
            auto&& k_pj = std::get<0>(_p1);
            auto&& v_pk = std::get<1>(_p1);
            return append(acc_pi, Array(std::vector{k_pj, v_pk}));
        });
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELit>(_m)) {
        auto&& l_pl = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
        auto&& _m = prism_rtl::deref(l_pl).kind;
        if (prism_rtl::is<crate::syntax::LitKind::LText>(_m)) {
            auto&& segs_pm = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
            return fold(segs_pm, Array<crate::syntax::Expr>{}, [&](const Array<crate::syntax::Expr>& acc_pn, const crate::syntax::TextSeg& sg_po) {
                return ({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
                    if (prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(sg_po)) {
                        auto&& x_pp = prism_rtl::as<crate::syntax::TextSeg::SegPlaceholder>(sg_po).a0;
                        _v.set(crate::prelude::push(acc_pn, x_pp));
                        goto _done;
                    }
                    {
                        _v.set(acc_pn);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            });
        }
        {
            return Array<crate::syntax::Expr>{};
        }
    }
    {
        return Array<crate::syntax::Expr>{};
    }
}


/// Merge: fn Wx, Text, OutTy, EvRef, EvRef -> ((Nat, Wx))
std::tuple<Nat, crate::lower::node_::Wx> merge(const crate::lower::node_::Wx& wx_p0, const Text& name_p1, const crate::lower::model::OutTy& t_p2, const crate::lower::node_::EvRef& l_p3, const crate::lower::node_::EvRef& r_p4) {
    return combinator(wx_p0, name_p1, t_p2, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnMerge{}), l_p3, r_p4, t_p2, t_p2);
}


/// Combinator: fn Wx, Text, OutTy, GnKind, EvRef, EvRef, OutTy, OutTy -> ((Nat, Wx))
std::tuple<Nat, crate::lower::node_::Wx> combinator(const crate::lower::node_::Wx& wx_p0, const Text& name_p1, const crate::lower::model::OutTy& t_p2, const crate::lower::node_::GnKind& kind_p3, const crate::lower::node_::EvRef& l_p4, const crate::lower::node_::EvRef& r_p5, const crate::lower::model::OutTy& lt_p6, const crate::lower::model::OutTy& rt_p7) {
    auto [id_pb, wx1_pc] = crate::lower::node_::add_gn(wx_p0, name_p1, t_p2, kind_p3, Nat(1u));
    auto wx2_p8 = crate::lower::node_::add_field_last(wx1_pc, prism_rtl::cat(name_p1, "_left"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutStamped{prism_rtl::rc(lt_p6)}), prism_rtl::cat("`", name_p1, "`\'s left input"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Stamped::new"), Array<crate::lower::model::Ex>{}}));
    auto wx3_p9 = crate::lower::node_::add_field_last(wx2_p8, prism_rtl::cat(name_p1, "_right"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutStamped{prism_rtl::rc(rt_p7)}), Text::lit("its right input"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Stamped::new"), Array<crate::lower::model::Ex>{}}));
    auto wx4_pa = ({
        crate::lower::node_::Wx this_ = wx3_p9;
        this_.gns = each(this_.gns, [&](const crate::lower::node_::Gn& n_pd) {
            return prism_rtl::deref(n_pd).id == id_pb
                ? with_inputs(n_pd, Array(std::vector{prism_rtl::cat(name_p1, "_left"), prism_rtl::cat(name_p1, "_right")}))
                : n_pd;
        });
        (std::move(this_));
    });
    return std::tuple{id_pb, crate::lower::node_::connect(crate::lower::node_::connect(wx4_pa, l_p4, crate::lower::node_::Sk(crate::lower::node_::Sk::SkIn{id_pb, Nat(0u)})), r_p5, crate::lower::node_::Sk(crate::lower::node_::Sk::SkIn{id_pb, Nat(1u)}))};
}


/// WithInputs: fn Gn, [Text] -> Gn
crate::lower::node_::Gn with_inputs(const crate::lower::node_::Gn& n_p0, const Array<Text>& ins_p1) {
    crate::lower::node_::Gn this_ = n_p0;
    this_.inputs = ins_p1;
    return this_;
}


/// WithReads: fn Gn, [Read] -> Gn
crate::lower::node_::Gn with_reads(const crate::lower::node_::Gn& n_p0, const Array<crate::lower::node_::Read>& reads_p1) {
    crate::lower::node_::Gn this_ = n_p0;
    this_.reads = reads_p1;
    return this_;
}

}  // namespace crate::lower::node_::dynamics


// The module `Lower.Node.Elements`, from `target/bootstrap/cpp-src/prismc/lower/node/elements.prism`.
namespace crate::lower::node_::elements {

/// ElementLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> element_line(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const crate::syntax::Expr& e_p3, const std::optional<crate::lower::types::Bn>& bound_o4) {
    auto lx_p5 = wx_p0.lx;
    auto [tag_name_pa, args_pb] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Text, Array<crate::syntax::Arg>>> _v;
        auto&& _m = prism_rtl::deref(e_p3.kind);
        if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
            auto&& c_p7 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
            auto&& xs_p8 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
            _v.set(std::tuple{tag_name_of(lx_p5, prism_rtl::deref(prism_rtl::deref(c_p7))), xs_p8});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n_p9 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            _v.set(std::tuple{tag_name_of(lx_p5, e_p3), Array<crate::syntax::Arg>{}});
            goto _done;
        }
        {
            _v.set(std::tuple{Text::lit(""), Array<crate::syntax::Arg>{}});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto full_p6 = crate::lower::type_at(lx_p5, e_p3.span);
    auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p5).g).tags, tag_name_pa);
    if (prism_rtl::is_none(_m)) {
        auto wx2_pc = ({
            crate::lower::node_::Wx this_ = wx_p0;
            this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("an element of an unknown tag")));
            (std::move(this_));
        });
        return std::tuple{wx2_pc, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& tg_pd = prism_rtl::some_of(_m);
        auto pos_pe = wx_p0.pos;
        auto wx1_pf = ({
            crate::lower::node_::Wx this_ = wx_p0;
            this_.pos = crate::lower::model::next_pos(this_.pos);
            (std::move(this_));
        });
        auto struct_path_pg = crate::lower::path_in(lx_p5, prism_rtl::deref(tg_pd).home, crate::lower::tag_struct(prism_rtl::deref(tg_pd).name));
        auto [live_fields_p1c, const_fields_p1d, method_consts_p1e, reads_p1f, wx2_p1g] = run_to_end(fold_job(prism_rtl::deref(tg_pd).fields, std::tuple{Array<std::tuple<Text, crate::lower::model::Ex>>{}, Array<std::tuple<Text, crate::lower::model::Ex>>{}, Array<std::tuple<Text, crate::lower::model::Ex>>{}, Array<crate::lower::node_::Read>{}, wx1_pf}, ({
            auto args_pb_1 = args_pb;
            auto menv_p2_2 = menv_p2;
            auto pos_pe_3 = pos_pe;
            auto tg_pd_4 = tg_pd;
            auto lx_p5_5 = lx_p5;
            auto benv_p1_6 = benv_p1;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::lower::model::Ex>>, Array<std::tuple<Text, crate::lower::model::Ex>>, Array<std::tuple<Text, crate::lower::model::Ex>>, Array<crate::lower::node_::Read>, crate::lower::node_::Wx>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::lower::model::Ex>>, Array<std::tuple<Text, crate::lower::model::Ex>>, Array<std::tuple<Text, crate::lower::model::Ex>>, Array<crate::lower::node_::Read>, crate::lower::node_::Wx>, std::tuple<Text, crate::check::types::Ty>>)>>(prism_rtl::rc([=, args_pb_1 = std::move(args_pb_1), menv_p2_2 = std::move(menv_p2_2), pos_pe_3 = std::move(pos_pe_3), tg_pd_4 = std::move(tg_pd_4), lx_p5_5 = std::move(lx_p5_5), benv_p1_6 = std::move(benv_p1_6)](std::tuple<std::tuple<Array<std::tuple<Text, crate::lower::model::Ex>>, Array<std::tuple<Text, crate::lower::model::Ex>>, Array<std::tuple<Text, crate::lower::model::Ex>>, Array<crate::lower::node_::Read>, crate::lower::node_::Wx>, std::tuple<Text, crate::check::types::Ty>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto args_pb_1_7 = args_pb_1;
                auto menv_p2_2_7 = menv_p2_2;
                auto pos_pe_3_7 = pos_pe_3;
                auto tg_pd_4_7 = tg_pd_4;
                auto lx_p5_5_7 = lx_p5_5;
                auto benv_p1_6_7 = benv_p1_6;
                entered(once_job([=, args_pb_1_7 = std::move(args_pb_1_7), menv_p2_2_7 = std::move(menv_p2_2_7), pos_pe_3_7 = std::move(pos_pe_3_7), tg_pd_4_7 = std::move(tg_pd_4_7), lx_p5_5_7 = std::move(lx_p5_5_7), benv_p1_6_7 = std::move(benv_p1_6_7)]() {
                return ({
                    auto [lf_pu, cf_pv, mf_p10, rd_p11, w_p12] = p0;
                    auto [fname_p13, fty_p14] = p1;
                    ({
                    auto&& _m = tag_arg(args_pb_1_7, fname_p13);
                    prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{lf_pu, cf_pv, mf_p10, rd_p11, w_p12})
                    : prism_rtl::is_some(_m) ? ({
                    auto&& arg_p15 = prism_rtl::some_of(_m);
                    ({
                    auto&& _m = crate::lower::types::layer_of(fty_p14);
                    prism_rtl::is<crate::lower::types::Layer::LyEv>(_m) ? call_then(crate::lower::node_::dynamics::start_event_ref(w_p12, menv_p2_2_7, arg_p15), [=](std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> event_ref_2608) {
                    return ({
                        auto [r_p16, w2_p17] = event_ref_2608;
                        (prism_rtl::finished(std::tuple{lf_pu, cf_pv, mf_p10, rd_p11, crate::lower::node_::connect(w2_p17, r_p16, crate::lower::node_::Sk(crate::lower::node_::Sk::SkRequest{pos_pe_3_7, request_field(tg_pd_4_7, fname_p13)}))}));
                    });
                })
                    : call_then(crate::lower::node_::dynamics::start_dynamic_expr(w_p12, menv_p2_2_7, arg_p15), [=](std::tuple<crate::lower::model::Ex, Array<crate::lower::node_::Read>> dynamic_expr_2830) {
                    return ({
                        auto [ex_p1a, rds_p1b] = dynamic_expr_2830;
                        call_then(crate::lower::expr::start_value_of(lx_p5_5_7, crate::lower::node_::def::init_env(benv_p1_6_7), arg_p15), [=](crate::lower::types::Vl value_of_3097) {
                        return ({
                            auto cv_p18 = crate::lower::types::own(value_of_3097);
                            call_then(crate::lower::expr::start_value_of(lx_p5_5_7, menv_p2_2_7, arg_p15), [=, cv_p18 = std::move(cv_p18)](crate::lower::types::Vl value_of_3176) {
                            return ({
                                auto mv_p19 = crate::lower::types::own(value_of_3176);
                                (prism_rtl::finished(std::tuple{crate::prelude::push(lf_pu, std::tuple{crate::lower::snake(fname_p13), ex_p1a}), crate::prelude::push(cf_pv, std::tuple{crate::lower::snake(fname_p13), cv_p18}), crate::prelude::push(mf_p10, std::tuple{crate::lower::snake(fname_p13), mv_p19}), crate::lower::node_::union_reads(rd_p11, rds_p1b), w_p12}));
                            });
                        });
                        });
                    });
                    });
                });
                });
                })
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        }));
        })));
        auto live_ph = len(reads_p1f) > Nat(0u);
        auto [getter_p1h, wx3_p1i] = std::move(live_ph)
            ? crate::lower::node_::fresh_name(wx2_p1g, crate::lower::snake(crate::check::types::bare_name(prism_rtl::deref(tg_pd).name)))
            : std::tuple{Text::lit(""), wx2_p1g};
        auto variant_pi = crate::lower::program::variant_of(lx_p5, tg_pd);
        auto level_pj = crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant_pi, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRecord{struct_path_pg, std::move(live_ph) ? live_fields_p1c : method_consts_p1e})})});
        auto at_build_pk = crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant_pi, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRecord{struct_path_pg, const_fields_p1d})})});
        auto added_pl = std::move(live_ph)
            ? crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), getter_p1h, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})
            : at_build_pk;
        auto emits_pm = crate::lower::node_::finish::emits(wx3_p1i, pos_pe);
        auto [entry_p1j, wx3e_p1k] = std::move(emits_pm)
            ? std::tuple{Text::lit(""), wx3_p1i}
            : crate::lower::node_::fresh_name(wx3_p1i, prism_rtl::cat("entry_", crate::lower::model::place_text(pos_pe)));
        auto deep_pn = std::move(emits_pm) && crate::lower::program::tag_holds_dyn(lx_p5, tg_pd);
        auto [watch_p1l, wx3w_p1m] = std::move(deep_pn)
            ? crate::lower::node_::fresh_name(wx3e_p1k, prism_rtl::cat("watch_", crate::lower::model::place_text(pos_pe)))
            : std::tuple{Text::lit(""), wx3e_p1k};
        auto what_po = prism_rtl::cat("place ", crate::lower::model::place_text(pos_pe), " (", prism_rtl::deref(tg_pd).name, ") of `", wx_p0.node_, "`");
        auto const_take_pp = std::move(live_ph)
            ? Array<crate::lower::model::Do>{}
            : Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{entry_p1j})), Text::lit("take"), Array(std::vector{at_build_pk, crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})});
        auto wx3h_pq = std::move(emits_pm)
            ? wx3w_p1m
            : ({
            crate::lower::node_::Wx this_ = wx3w_p1m;
            this_.lets = append(crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{entry_p1j})), crate::lower::types::entry_ty()}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::Entry::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{what_po})})})})), const_take_pp);
            this_.fields = crate::prelude::push(this_.fields, std::tuple{entry_p1j, crate::lower::types::entry_ty(), prism_rtl::cat(what_po, ", an entry of its host\'s document")});
            this_.moves = crate::prelude::push(this_.moves, std::tuple{entry_p1j, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{entry_p1j}))})});
            (std::move(this_));
        });
        auto wx3d_pr = std::move(deep_pn)
            ? crate::lower::node_::add_field_last(wx3h_pq, watch_p1l, crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("prism_rtl::Watch"), Array<crate::lower::model::OutTy>{}}), prism_rtl::cat("the dynamics place ", crate::lower::model::place_text(pos_pe), "\'s level holds, watched so a move sends it again (doubt WD)"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::Watch::new"), Array<crate::lower::model::Ex>{}}))
            : wx3h_pq;
        auto sent_ps = std::move(deep_pn)
            ? Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("sent")}), added_pl}), crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("added"), Array(std::vector{crate::lower::node_::finish::place_at(wx3_p1i, Text::lit("node"), pos_pe), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("sent")})), Text::lit("level_pod"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})})}), crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), watch_p1l})), Text::lit("renew"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("sent")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")}))})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutObj{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Node"), Array<crate::lower::model::OutTy>{}}))})}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})})
            : Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("added"), Array(std::vector{crate::lower::node_::finish::place_at(wx3_p1i, Text::lit("node"), pos_pe), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(added_pl), Text::lit("level_pod"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})})})});
        auto wx4_pt = ({
            crate::lower::node_::Wx this_ = wx3d_pr;
            this_.places = crate::prelude::push(this_.places, crate::lower::node_::Place{.pos = pos_pe, .level = level_pj, .getter = getter_p1h, .reads = reads_p1f, .entry = entry_p1j, .watch = watch_p1l});
            this_.build = std::move(emits_pm)
                ? std::move(deep_pn)
                ? crate::prelude::push(this_.build, crate::lower::model::Do(crate::lower::model::Do::DoScope{sent_ps}))
                : append(this_.build, sent_ps)
                : this_.build;
            (std::move(this_));
        });
        return element_output(wx4_pt, menv_p2, tg_pd, element_out(lx_p5, tg_pd, full_p6), pos_pe, bound_o4, at_build_pk);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> ElementLine::cycle() const {
    const auto& wx_p0 = this->wx_p0;
    const auto& benv_p1 = this->benv_p1;
    const auto& menv_p2 = this->menv_p2;
    const auto& e_p3 = this->e_p3;
    const auto& bound_o4 = this->bound_o4;
    auto lx_p5 = prism_rtl::deref(wx_p0).lx;
    auto [tag_name_pa, args_pb] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Text, Array<crate::syntax::Arg>>> _v;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p3).kind);
        if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
            auto&& c_p7 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
            auto&& xs_p8 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
            _v.set(std::tuple{tag_name_of(lx_p5, prism_rtl::deref(prism_rtl::deref(c_p7))), xs_p8});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n_p9 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            _v.set(std::tuple{tag_name_of(lx_p5, e_p3), Array<crate::syntax::Arg>{}});
            goto _done;
        }
        {
            _v.set(std::tuple{Text::lit(""), Array<crate::syntax::Arg>{}});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto full_p6 = crate::lower::type_at(lx_p5, prism_rtl::deref(e_p3).span);
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p5).g).tags, tag_name_pa);
        prism_rtl::is_none(_m) ? ({
        auto wx2_pc = ({
            crate::lower::node_::Wx this_ = wx_p0;
            this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("an element of an unknown tag")));
            (std::move(this_));
        });
        (prism_rtl::finished(std::tuple{wx2_pc, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})}));
    })
        : prism_rtl::is_some(_m) ? ({
        auto&& tg_pd = prism_rtl::some_of(_m);
        ({
        auto pos_pe = prism_rtl::deref(wx_p0).pos;
        auto wx1_pf = ({
            crate::lower::node_::Wx this_ = wx_p0;
            this_.pos = crate::lower::model::next_pos(this_.pos);
            (std::move(this_));
        });
        auto struct_path_pg = crate::lower::path_in(lx_p5, prism_rtl::deref(tg_pd).home, crate::lower::tag_struct(prism_rtl::deref(tg_pd).name));
        auto bound_o4_1 = bound_o4;
        auto benv_p1_2 = benv_p1;
        auto menv_p2_3 = menv_p2;
        auto wx_p0_4 = wx_p0;
        call_value(fold_job(prism_rtl::deref(tg_pd).fields, std::tuple{Array<std::tuple<Text, crate::lower::model::Ex>>{}, Array<std::tuple<Text, crate::lower::model::Ex>>{}, Array<std::tuple<Text, crate::lower::model::Ex>>{}, Array<crate::lower::node_::Read>{}, wx1_pf}, ({
        auto args_pb_5 = args_pb;
        auto menv_p2_3_6 = menv_p2_3;
        auto pos_pe_6 = pos_pe;
        auto tg_pd_7 = tg_pd;
        auto lx_p5_8 = lx_p5;
        auto benv_p1_2_9 = benv_p1_2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::lower::model::Ex>>, Array<std::tuple<Text, crate::lower::model::Ex>>, Array<std::tuple<Text, crate::lower::model::Ex>>, Array<crate::lower::node_::Read>, crate::lower::node_::Wx>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::lower::model::Ex>>, Array<std::tuple<Text, crate::lower::model::Ex>>, Array<std::tuple<Text, crate::lower::model::Ex>>, Array<crate::lower::node_::Read>, crate::lower::node_::Wx>, std::tuple<Text, crate::check::types::Ty>>)>>(prism_rtl::rc([=, args_pb_5 = std::move(args_pb_5), menv_p2_3_6 = std::move(menv_p2_3_6), pos_pe_6 = std::move(pos_pe_6), tg_pd_7 = std::move(tg_pd_7), lx_p5_8 = std::move(lx_p5_8), benv_p1_2_9 = std::move(benv_p1_2_9)](std::tuple<std::tuple<Array<std::tuple<Text, crate::lower::model::Ex>>, Array<std::tuple<Text, crate::lower::model::Ex>>, Array<std::tuple<Text, crate::lower::model::Ex>>, Array<crate::lower::node_::Read>, crate::lower::node_::Wx>, std::tuple<Text, crate::check::types::Ty>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto args_pb_5_9 = args_pb_5;
            auto menv_p2_3_6_9 = menv_p2_3_6;
            auto pos_pe_6_9 = pos_pe_6;
            auto tg_pd_7_9 = tg_pd_7;
            auto lx_p5_8_9 = lx_p5_8;
            auto benv_p1_2_9_9 = benv_p1_2_9;
            entered(once_job([=, args_pb_5_9 = std::move(args_pb_5_9), menv_p2_3_6_9 = std::move(menv_p2_3_6_9), pos_pe_6_9 = std::move(pos_pe_6_9), tg_pd_7_9 = std::move(tg_pd_7_9), lx_p5_8_9 = std::move(lx_p5_8_9), benv_p1_2_9_9 = std::move(benv_p1_2_9_9)]() {
            return ({
                auto [lf_pu, cf_pv, mf_p10, rd_p11, w_p12] = p0;
                auto [fname_p13, fty_p14] = p1;
                ({
                auto&& _m = tag_arg(args_pb_5_9, fname_p13);
                prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{lf_pu, cf_pv, mf_p10, rd_p11, w_p12})
                : prism_rtl::is_some(_m) ? ({
                auto&& arg_p15 = prism_rtl::some_of(_m);
                ({
                auto&& _m = crate::lower::types::layer_of(fty_p14);
                prism_rtl::is<crate::lower::types::Layer::LyEv>(_m) ? call_then(crate::lower::node_::dynamics::start_event_ref(w_p12, menv_p2_3_6_9, arg_p15), [=](std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> event_ref_2608) {
                return ({
                    auto [r_p16, w2_p17] = event_ref_2608;
                    (prism_rtl::finished(std::tuple{lf_pu, cf_pv, mf_p10, rd_p11, crate::lower::node_::connect(w2_p17, r_p16, crate::lower::node_::Sk(crate::lower::node_::Sk::SkRequest{pos_pe_6_9, request_field(tg_pd_7_9, fname_p13)}))}));
                });
            })
                : call_then(crate::lower::node_::dynamics::start_dynamic_expr(w_p12, menv_p2_3_6_9, arg_p15), [=](std::tuple<crate::lower::model::Ex, Array<crate::lower::node_::Read>> dynamic_expr_2830) {
                return ({
                    auto [ex_p1a, rds_p1b] = dynamic_expr_2830;
                    call_then(crate::lower::expr::start_value_of(lx_p5_8_9, crate::lower::node_::def::init_env(benv_p1_2_9_9), arg_p15), [=](crate::lower::types::Vl value_of_3097) {
                    return ({
                        auto cv_p18 = crate::lower::types::own(value_of_3097);
                        call_then(crate::lower::expr::start_value_of(lx_p5_8_9, menv_p2_3_6_9, arg_p15), [=, cv_p18 = std::move(cv_p18)](crate::lower::types::Vl value_of_3176) {
                        return ({
                            auto mv_p19 = crate::lower::types::own(value_of_3176);
                            (prism_rtl::finished(std::tuple{crate::prelude::push(lf_pu, std::tuple{crate::lower::snake(fname_p13), ex_p1a}), crate::prelude::push(cf_pv, std::tuple{crate::lower::snake(fname_p13), cv_p18}), crate::prelude::push(mf_p10, std::tuple{crate::lower::snake(fname_p13), mv_p19}), crate::lower::node_::union_reads(rd_p11, rds_p1b), w_p12}));
                        });
                    });
                    });
                });
                });
            });
            });
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })), [=, struct_path_pg = std::move(struct_path_pg), bound_o4_1 = std::move(bound_o4_1), wx_p0_4 = std::move(wx_p0_4)](std::tuple<Array<std::tuple<Text, crate::lower::model::Ex>>, Array<std::tuple<Text, crate::lower::model::Ex>>, Array<std::tuple<Text, crate::lower::model::Ex>>, Array<crate::lower::node_::Read>, crate::lower::node_::Wx> fold_2276) {
        return ({
            auto [live_fields_p1c, const_fields_p1d, method_consts_p1e, reads_p1f, wx2_p1g] = fold_2276;
            auto live_ph = len(reads_p1f) > Nat(0u);
            auto [getter_p1h, wx3_p1i] = std::move(live_ph)
                ? crate::lower::node_::fresh_name(wx2_p1g, crate::lower::snake(crate::check::types::bare_name(prism_rtl::deref(tg_pd).name)))
                : std::tuple{Text::lit(""), wx2_p1g};
            auto variant_pi = crate::lower::program::variant_of(lx_p5, tg_pd);
            auto level_pj = crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant_pi, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRecord{struct_path_pg, std::move(live_ph) ? live_fields_p1c : method_consts_p1e})})});
            auto at_build_pk = crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant_pi, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRecord{struct_path_pg, const_fields_p1d})})});
            auto added_pl = std::move(live_ph)
                ? crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), getter_p1h, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})
                : at_build_pk;
            auto emits_pm = crate::lower::node_::finish::emits(wx3_p1i, pos_pe);
            auto [entry_p1j, wx3e_p1k] = std::move(emits_pm)
                ? std::tuple{Text::lit(""), wx3_p1i}
                : crate::lower::node_::fresh_name(wx3_p1i, prism_rtl::cat("entry_", crate::lower::model::place_text(pos_pe)));
            auto deep_pn = std::move(emits_pm) && crate::lower::program::tag_holds_dyn(lx_p5, tg_pd);
            auto [watch_p1l, wx3w_p1m] = std::move(deep_pn)
                ? crate::lower::node_::fresh_name(wx3e_p1k, prism_rtl::cat("watch_", crate::lower::model::place_text(pos_pe)))
                : std::tuple{Text::lit(""), wx3e_p1k};
            auto what_po = prism_rtl::cat("place ", crate::lower::model::place_text(pos_pe), " (", prism_rtl::deref(tg_pd).name, ") of `", prism_rtl::deref(wx_p0_4).node_, "`");
            auto const_take_pp = std::move(live_ph)
                ? Array<crate::lower::model::Do>{}
                : Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{entry_p1j})), Text::lit("take"), Array(std::vector{at_build_pk, crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})});
            auto wx3h_pq = std::move(emits_pm)
                ? wx3w_p1m
                : ({
                crate::lower::node_::Wx this_ = wx3w_p1m;
                this_.lets = append(crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{entry_p1j})), crate::lower::types::entry_ty()}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::Entry::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{what_po})})})})), const_take_pp);
                this_.fields = crate::prelude::push(this_.fields, std::tuple{entry_p1j, crate::lower::types::entry_ty(), prism_rtl::cat(what_po, ", an entry of its host\'s document")});
                this_.moves = crate::prelude::push(this_.moves, std::tuple{entry_p1j, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{entry_p1j}))})});
                (std::move(this_));
            });
            auto wx3d_pr = std::move(deep_pn)
                ? crate::lower::node_::add_field_last(wx3h_pq, watch_p1l, crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("prism_rtl::Watch"), Array<crate::lower::model::OutTy>{}}), prism_rtl::cat("the dynamics place ", crate::lower::model::place_text(pos_pe), "\'s level holds, watched so a move sends it again (doubt WD)"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::Watch::new"), Array<crate::lower::model::Ex>{}}))
                : wx3h_pq;
            auto sent_ps = std::move(deep_pn)
                ? Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("sent")}), added_pl}), crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("added"), Array(std::vector{crate::lower::node_::finish::place_at(wx3_p1i, Text::lit("node"), pos_pe), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("sent")})), Text::lit("level_pod"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})})}), crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), watch_p1l})), Text::lit("renew"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("sent")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")}))})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutObj{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Node"), Array<crate::lower::model::OutTy>{}}))})}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})})
                : Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("added"), Array(std::vector{crate::lower::node_::finish::place_at(wx3_p1i, Text::lit("node"), pos_pe), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(added_pl), Text::lit("level_pod"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})})})});
            auto wx4_pt = ({
                crate::lower::node_::Wx this_ = wx3d_pr;
                this_.places = crate::prelude::push(this_.places, crate::lower::node_::Place{.pos = pos_pe, .level = level_pj, .getter = getter_p1h, .reads = reads_p1f, .entry = entry_p1j, .watch = watch_p1l});
                this_.build = std::move(emits_pm)
                    ? std::move(deep_pn)
                    ? crate::prelude::push(this_.build, crate::lower::model::Do(crate::lower::model::Do::DoScope{sent_ps}))
                    : append(this_.build, sent_ps)
                    : this_.build;
                (std::move(this_));
            });
            (prism_rtl::finished(element_output(wx4_pt, menv_p2_3, tg_pd, element_out(lx_p5, tg_pd, full_p6), pos_pe, bound_o4_1, at_build_pk)));
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ElementLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> start_element_line(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::Expr e_p3, std::optional<crate::lower::types::Bn> bound_o4) {
    return prism_rtl::make_rc<ElementLine>(wx_p0, benv_p1, menv_p2, e_p3, bound_o4);
}


/// ElementOut: unbounded fn Lx, TagInfo, Ty -> OutTy
crate::lower::model::OutTy element_out(const crate::lower::Lx& lx_p0, const crate::check::env::TagInfo& tg_p1, const crate::check::types::Ty& full_p2) {
    auto t_p3 = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::OutTy> _v;
        auto&& _m = crate::lower::types::peel(full_p2);
        if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
            auto&& o_p4 = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a1;
            _v.set(crate::lower::types::out_ty_of(lx_p0, crate::lower::types::peel(prism_rtl::deref(o_p4))));
            goto _done;
        }
        {
            _v.set(crate::lower::types::out_ty_of(lx_p0, crate::lower::types::peel(tg_p1.out)));
            goto _done;
        }
    _done:
        _v.take();
    });
    if (prism_rtl::is<crate::lower::model::OutTy::OutGen>(t_p3)) {
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutPod{});
    }
    {
        return t_p3;
    }
}


/// TagNameOf: fn Lx, Expr -> Text
Text tag_name_of(const crate::lower::Lx& lx_p0, const crate::syntax::Expr& c_p1) {
    auto&& _m = prism_rtl::deref(c_p1.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p2 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        auto&& _qk_o3 = crate::check::env::names::resolve_value(lx_p0.g, lx_p0.home, n_p2);
        auto&& qk_o3 = std::get<0>(_qk_o3);
        return or_(qk_o3, crate::check::env::dotted(n_p2->path_));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p4 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return tag_name_of(lx_p0, prism_rtl::deref(prism_rtl::deref(x_p4)));
    }
    {
        return Text::lit("");
    }
}


/// ?TagArg: fn [Arg], Text -> ?Expr
std::optional<crate::syntax::Expr> tag_arg(const Array<crate::syntax::Arg>& args_p0, const Text& fname_p1) {
    return fold(args_p0, std::optional<crate::syntax::Expr>{}, [&](const std::optional<crate::syntax::Expr>& found_o2, const crate::syntax::Arg& a_p3) {
        return ({
            __label__ _done;
            prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
            auto&& _m = prism_rtl::deref(a_p3).name;
            if (prism_rtl::is_some(_m)) {
                auto&& n_p4 = prism_rtl::some_of(_m);
                _v.set(prism_rtl::deref(n_p4).name == fname_p1
                    ? std::optional(a_p3->value)
                    : found_o2);
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(found_o2);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// RequestField: fn TagInfo, Text -> Text
Text request_field(const crate::check::env::TagInfo& tg_p0, const Text& fname_p1) {
    auto evs_p2 = filter(tg_p0.fields, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
        auto&& t_p3 = std::get<1>(_p0);
        return crate::lower::types::layer_of(t_p3) == crate::lower::types::Layer(crate::lower::types::Layer::LyEv{});
    });
    return len(evs_p2) > Nat(1u) ? fname_p1 : Text::lit("");
}


/// ElementOutput: unbounded fn Wx, Env, TagInfo, OutTy, Pos, ?Bn, Ex -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> element_output(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const crate::check::env::TagInfo& tg_p2, const crate::lower::model::OutTy& out_p3, const crate::lower::model::Pos_& pos_p4, const std::optional<crate::lower::types::Bn>& bound_o5, const crate::lower::model::Ex& level_p6) {
    auto lx_p7 = wx_p0.lx;
    if (prism_rtl::is_some(bound_o5) && prism_rtl::is<crate::lower::types::Bn::BnParts>(prism_rtl::some_of(bound_o5))) {
        auto&& parts_p8 = prism_rtl::as<crate::lower::types::Bn::BnParts>(prism_rtl::some_of(bound_o5)).a0;
        return bundle_output(wx_p0, tg_p2, out_p3, pos_p4, parts_p8, level_p6);
    }
    {
        return element_output_of(wx_p0, menv_p1, tg_p2, out_p3, pos_p4, bound_o5, level_p6);
    }
}


/// BundleOutput: unbounded fn Wx, TagInfo, OutTy, Pos, [?Bn], Ex -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> bundle_output(const crate::lower::node_::Wx& wx_p0, const crate::check::env::TagInfo& tg_p1, const crate::lower::model::OutTy& out_p2, const crate::lower::model::Pos_& pos_p3, const Array<std::optional<crate::lower::types::Bn>>& parts_p4, const crate::lower::model::Ex& level_p5) {
    return !crate::lower::node_::finish::emits(wx_p0, pos_p3)
        ? ({
        auto wx2_p6 = ({
            crate::lower::node_::Wx this_ = wx_p0;
            this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(prism_rtl::cat("a bundle (", tg_p1.name, ") in a hosted scope")));
            (std::move(this_));
        });
        std::tuple{wx2_p6, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
    })
        : bundle_output_of(wx_p0, tg_p1, out_p2, pos_p3, parts_p4, level_p5);
}


/// BundleOutputOf: unbounded fn Wx, TagInfo, OutTy, Pos, [?Bn], Ex -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> bundle_output_of(const crate::lower::node_::Wx& wx_p0, const crate::check::env::TagInfo& tg_p1, const crate::lower::model::OutTy& out_p2, const crate::lower::model::Pos_& pos_p3, const Array<std::optional<crate::lower::types::Bn>>& parts_p4, const crate::lower::model::Ex& level_p5) {
    auto layers_p6 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::types::Layer>> _v;
        auto&& _m = tg_p1.out;
        if (prism_rtl::is<crate::check::types::Ty::TyTuple>(_m)) {
            auto&& cs_pe = prism_rtl::as<crate::check::types::Ty::TyTuple>(_m).a0;
            _v.set(each(cs_pe, [&](const crate::check::types::Ty& c_pf) { return crate::lower::types::layer_of(c_pf); }));
            goto _done;
        }
        {
            _v.set(Array<crate::lower::types::Layer>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto tys_p7 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
        if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(out_p2)) {
            auto&& ts_pg = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(out_p2).a0;
            _v.set(ts_pg);
            goto _done;
        }
        {
            _v.set(Array<crate::lower::model::OutTy>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto idx_p8 = crate::check::errors::range0(len(layers_p6));
    auto plain_ix_p9 = filter(idx_p8, [&](const Nat& i_ph) { return or_(index(layers_p6, i_ph), crate::lower::types::Layer(crate::lower::types::Layer::LyPlain{})) == crate::lower::types::Layer(crate::lower::types::Layer::LyPlain{}); });
    auto ev_ix_pa = filter(idx_p8, [&](const Nat& i_pi) { return or_(index(layers_p6, i_pi), crate::lower::types::Layer(crate::lower::types::Layer::LyPlain{})) == crate::lower::types::Layer(crate::lower::types::Layer::LyEv{}); });
    auto dyn_ix_pb = filter(idx_p8, [&](const Nat& i_pj) { return or_(index(layers_p6, i_pj), crate::lower::types::Layer(crate::lower::types::Layer::LyPlain{})) == crate::lower::types::Layer(crate::lower::types::Layer::LyDyn{}); });
    auto wx1_pc = bundle_first(wx_p0, tg_p1, pos_p3, plain_ix_p9, tys_p7, parts_p4, level_p5);
    auto wx2_pd = fold(ev_ix_pa, wx1_pc, [&](const crate::lower::node_::Wx& w_pk, const Nat& i_pl) { return bundle_answer(w_pk, pos_p3, or_(index(tys_p7, i_pl), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})), or_(index(parts_p4, i_pl), std::optional<crate::lower::types::Bn>{})); });
    return (len(ev_ix_pa) > Nat(1u)) || (len(dyn_ix_pb) > Nat(0u))
        ? ({
        auto wx3_pm = ({
            crate::lower::node_::Wx this_ = wx2_pd;
            this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(prism_rtl::cat("a bundle with a `$` part or two event parts (", tg_p1.name, ")")));
            (std::move(this_));
        });
        std::tuple{wx3_pm, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
    })
        : std::tuple{wx2_pd, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
}


/// BundleFirst: unbounded fn Wx, TagInfo, Pos, [Nat], [OutTy], [?Bn], Ex -> Wx
crate::lower::node_::Wx bundle_first(const crate::lower::node_::Wx& wx_p0, const crate::check::env::TagInfo& tg_p1, const crate::lower::model::Pos_& pos_p2, const Array<Nat>& plain_ix_p3, const Array<crate::lower::model::OutTy>& tys_p4, const Array<std::optional<crate::lower::types::Bn>>& parts_p5, const crate::lower::model::Ex& level_p6) {
    {
        auto&& m10024_0 = plain_ix_p3;
        if (m10024_0.size() == 0u) {
            return wx_p0;
        }
    }
    {
        auto one_p7 = len(plain_ix_p3) == Nat(1u);
        auto plain_ty_p8 = std::move(one_p7)
            ? or_(index(tys_p4, or_(index(plain_ix_p3, Nat(0u)), Nat(0u))), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))
            : crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{each(plain_ix_p3, [&](const Nat& i_pa) { return or_(index(tys_p4, i_pa), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})); })});
        auto wx1_p9 = ({
            crate::lower::node_::Wx this_ = wx_p0;
            this_.lets = append(this_.lets, Array(std::vector{first_value_let(wx_p0, pos_p2, tg_p1, level_p6), crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat("bundle_", crate::lower::model::place_text(pos_p2))}), crate::lower::model::Ex(crate::lower::model::Ex::XDecode{plain_ty_p8, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("first_", crate::lower::model::place_text(pos_p2))}))}))})})}));
            this_.fallible = true;
            (std::move(this_));
        });
        return fold(crate::check::errors::range0(len(plain_ix_p3)), wx1_p9, [&](const crate::lower::node_::Wx& w_pb, const Nat& k_pc) {
            return ({
                auto i_pd = or_(index(plain_ix_p3, k_pc), Nat(0u));
                ({
                __label__ _done;
                prism_rtl::Slot<crate::lower::node_::Wx> _v;
                auto&& _m = index(parts_p5, i_pd);
                if (prism_rtl::is_some(_m) && prism_rtl::is_some(prism_rtl::some_of(_m)) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(prism_rtl::some_of(_m)))) {
                    auto&& rs_pe = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(prism_rtl::some_of(_m))).a0;
                    _v.set(({
                        auto f_pf = crate::lower::types::place_stem(rs_pe);
                        auto part_pg = one_p7
                            ? crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("bundle_", crate::lower::model::place_text(pos_p2))})
                            : crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XPart{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("bundle_", crate::lower::model::place_text(pos_p2))})), k_pc}))});
                        ({
                        crate::lower::node_::Wx this_ = w_pb;
                        this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{f_pf}), part_pg}));
                        this_.fields = crate::prelude::push(this_.fields, std::tuple{f_pf, or_(index(tys_p4, i_pd), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})), prism_rtl::cat("place ", crate::lower::model::place_text(pos_p2), "\'s answer, part ", i_pd, " of its first value")});
                        this_.inits = crate::prelude::push(this_.inits, std::tuple{f_pf, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{f_pf}))})});
                        (std::move(this_));
                    });
                    }));
                    goto _done;
                }
                {
                    _v.set(w_pb);
                    goto _done;
                }
            _done:
                _v.take();
            });
            });
        });
    }
}


/// BundleAnswer: fn Wx, Pos, OutTy, ?Bn -> Wx
crate::lower::node_::Wx bundle_answer(const crate::lower::node_::Wx& wx_p0, const crate::lower::model::Pos_& pos_p1, const crate::lower::model::OutTy& et_p2, const std::optional<crate::lower::types::Bn>& b_o3) {
    auto t_p4 = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::OutTy> _v;
        if (prism_rtl::is<crate::lower::model::OutTy::OutEvent>(et_p2)) {
            auto&& inner_p5 = prism_rtl::as<crate::lower::model::OutTy::OutEvent>(et_p2).a0;
            _v.set(prism_rtl::deref(prism_rtl::deref(inner_p5)));
            goto _done;
        }
        {
            _v.set(et_p2);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [id_p9, wx2_pa] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Nat, crate::lower::node_::Wx>> _v;
        if (prism_rtl::is_some(b_o3) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(b_o3))) {
            auto&& er_p6 = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(b_o3)).a0;
            _v.set(std::tuple{prism_rtl::deref(er_p6).node_, wx_p0});
            goto _done;
        }
        {
            _v.set(({
                auto [nm_p7, w_p8] = crate::lower::node_::fresh_name(wx_p0, prism_rtl::cat("place_", crate::lower::model::place_text(pos_p1)));
                (crate::lower::node_::add_gn(w_p8, nm_p7, t_p4, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnAnswer{}), Nat(0u)));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
    crate::lower::node_::Wx this_ = wx2_pa;
    this_.answers = crate::prelude::push(this_.answers, std::tuple{pos_p1, id_p9, t_p4, Text::lit("")});
    return this_;
}


/// FirstValueLet: fn Wx, Pos, TagInfo, Ex -> Do
crate::lower::model::Do first_value_let(const crate::lower::node_::Wx& wx_p0, const crate::lower::model::Pos_& pos_p1, const crate::check::env::TagInfo& tg_p2, const crate::lower::model::Ex& level_p3) {
    auto missing_p4 = crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Fault::answer"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{prism_rtl::cat("no first value for ", tg_p2.name)})})});
    return crate::lower::node_::finish::emits(wx_p0, pos_p1)
        ? ({
        auto asked_p5 = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("first_value"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(level_p3), Text::lit("to_pod"), Array<crate::lower::model::Ex>{}}))})})});
        (crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat("first_", crate::lower::model::place_text(pos_p1))}), crate::lower::expr::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(asked_p5), Text::lit("ok_or"), Array(std::vector{missing_p4})}))}));
    })
        : ({
        auto host_p6 = host_local(wx_p0, pos_p1);
        auto entry_p7 = or_(fold(wx_p0.places, std::optional<Text>{}, [&](const std::optional<Text>& e_o9, const crate::lower::node_::Place& pl_pa) { return prism_rtl::deref(pl_pa).pos == pos_p1 ? std::optional(pl_pa->entry) : e_o9; }), Text::lit(""));
        auto asked_p8 = crate::lower::expr::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{host_p6})), Text::lit("first_value"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::node_::finish::place_at(wx_p0, Text::lit(""), pos_p1))}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(level_p3)}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{entry_p7}))}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}));
        (crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat("first_", crate::lower::model::place_text(pos_p1))}), crate::lower::expr::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::expr::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(asked_p8), Text::lit("ok_or"), Array(std::vector{missing_p4})}))), answer_accessor(tg_p2), Array<crate::lower::model::Ex>{}}))}));
    });
}


/// HostLocal: fn Wx, Pos -> Text
Text host_local(const crate::lower::node_::Wx& wx_p0, const crate::lower::model::Pos_& pos_p1) {
    return pos_p1.scope == Nat(0u)
        ? Text::lit("enclosing")
        : or_(index(wx_p0.scopes, crate::syntax::lexer::chars::dec(pos_p1.scope)), Text::lit(""));
}


/// AnswerVariant: fn TagInfo -> Text
Text answer_variant(const crate::check::env::TagInfo& tg_p0) {
    return prism_rtl::cat("crate::Answer::", crate::lower::tag_struct(tg_p0.name));
}


/// AnswerAccessor: fn TagInfo -> Text
Text answer_accessor(const crate::check::env::TagInfo& tg_p0) {
    return crate::lower::snake(crate::lower::tag_struct(tg_p0.name));
}


/// ElementOutputOf: unbounded fn Wx, Env, TagInfo, OutTy, Pos, ?Bn, Ex -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> element_output_of(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const crate::check::env::TagInfo& tg_p2, const crate::lower::model::OutTy& out_p3, const crate::lower::model::Pos_& pos_p4, const std::optional<crate::lower::types::Bn>& bound_o5, const crate::lower::model::Ex& level_p6) {
    auto lx_p7 = wx_p0.lx;
    auto&& _m = crate::lower::types::layer_of(tg_p2.out);
    if (prism_rtl::is<crate::lower::types::Layer::LyEv>(_m)) {
        auto [id_pc, wx2_pd] = ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Nat, crate::lower::node_::Wx>> _v;
            if (prism_rtl::is_some(bound_o5) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_o5))) {
                auto&& er_p9 = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_o5)).a0;
                _v.set(std::tuple{prism_rtl::deref(er_p9).node_, wx_p0});
                goto _done;
            }
            {
                _v.set(({
                    auto [nm_pa, w_pb] = crate::lower::node_::fresh_name(wx_p0, prism_rtl::cat("place_", crate::lower::model::place_text(pos_p4)));
                    (crate::lower::node_::add_gn(w_pb, nm_pa, out_p3, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnAnswer{}), Nat(0u)));
                }));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto wx3_p8 = ({
            crate::lower::node_::Wx this_ = wx2_pd;
            this_.answers = crate::prelude::push(this_.answers, std::tuple{pos_p4, id_pc, out_p3, answer_accessor(tg_p2)});
            (std::move(this_));
        });
        return std::tuple{wx3_p8, crate::lower::node_::Wres(crate::lower::node_::Wres::WrEv{crate::lower::node_::ev_ref_of(wx3_p8, id_pc)})};
    }
    if (prism_rtl::is<crate::lower::types::Layer::LyDyn>(_m)) {
        auto [f_pj, wx1_pk] = ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Text, crate::lower::node_::Wx>> _v;
            if (prism_rtl::is_some(bound_o5) && prism_rtl::is<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(bound_o5))) {
                auto&& hf_pi = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(bound_o5)).a0;
                _v.set(std::tuple{hf_pi, wx_p0});
                goto _done;
            }
            {
                _v.set(crate::lower::node_::fresh_name(wx_p0, prism_rtl::cat("place_", crate::lower::model::place_text(pos_p4))));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto emits_pe = crate::lower::node_::finish::emits(wx_p0, pos_p4);
        auto first_pf = std::move(emits_pe)
            ? crate::lower::model::Ex(crate::lower::model::Ex::XDecode{out_p3, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("first_", crate::lower::model::place_text(pos_p4))}))}))})
            : crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("first_", crate::lower::model::place_text(pos_p4))});
        auto wx2_pg = ({
            crate::lower::node_::Wx this_ = wx1_pk;
            this_.lets = crate::prelude::push(this_.lets, first_value_let(wx_p0, pos_p4, tg_p2, level_p6));
            this_.fields = crate::prelude::push(this_.fields, std::tuple{f_pj, crate::lower::model::OutTy(crate::lower::model::OutTy::OutHold{prism_rtl::rc(out_p3)}), prism_rtl::cat("pushed to place ", crate::lower::model::place_text(pos_p4))});
            this_.inits = crate::prelude::push(this_.inits, std::tuple{f_pj, crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Hold::new"), Array(std::vector{first_pf, crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
            this_.dyn_places = crate::prelude::push(this_.dyn_places, std::tuple{pos_p4, f_pj, out_p3, answer_accessor(tg_p2)});
            this_.fallible = true;
            (std::move(this_));
        });
        auto wx3_ph = std::move(emits_pe)
            ? ({
            crate::lower::node_::Wx this_ = wx2_pg;
            this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat(f_pj, "_element")}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(level_p6), Text::lit("to_pod"), Array<crate::lower::model::Ex>{}})}));
            this_.fields = crate::prelude::push(this_.fields, std::tuple{prism_rtl::cat(f_pj, "_element"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutPod{}), prism_rtl::cat("place ", crate::lower::model::place_text(pos_p4), "\'s element, which pushes are keyed by")});
            this_.moves = crate::prelude::push(this_.moves, std::tuple{prism_rtl::cat(f_pj, "_element"), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat(f_pj, "_element")}))})});
            this_.build = crate::prelude::push(this_.build, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("listen"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), prism_rtl::cat(f_pj, "_element")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")}))})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutObj{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Node"), Array<crate::lower::model::OutTy>{}}))})}))})})})}));
            (std::move(this_));
        })
            : wx2_pg;
        return std::tuple{wx3_ph, crate::lower::node_::Wres(crate::lower::node_::Wres::WrDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f_pj)})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{f_pj})}), out_p3})};
    }
    {
        if (prism_rtl::is_some(bound_o5) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(bound_o5))) {
            auto&& rs_pl = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(bound_o5)).a0;
            auto f_pm = crate::lower::types::place_stem(rs_pl);
            auto first_pn = crate::lower::node_::finish::emits(wx_p0, pos_p4)
                ? crate::lower::model::Ex(crate::lower::model::Ex::XDecode{out_p3, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("first_", crate::lower::model::place_text(pos_p4))}))}))})
                : crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("first_", crate::lower::model::place_text(pos_p4))});
            auto wx2_po = ({
                crate::lower::node_::Wx this_ = wx_p0;
                this_.lets = append(this_.lets, Array(std::vector{first_value_let(wx_p0, pos_p4, tg_p2, level_p6), crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{f_pm}), first_pn})}));
                this_.fields = crate::prelude::push(this_.fields, std::tuple{f_pm, out_p3, prism_rtl::cat("place ", crate::lower::model::place_text(pos_p4), "\'s answer, its first value")});
                this_.inits = crate::prelude::push(this_.inits, std::tuple{f_pm, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{f_pm}))})});
                this_.fallible = true;
                (std::move(this_));
            });
            return std::tuple{wx2_po, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
        }
        {
            return std::tuple{wx_p0, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
        }
    }
}

}  // namespace crate::lower::node_::elements
