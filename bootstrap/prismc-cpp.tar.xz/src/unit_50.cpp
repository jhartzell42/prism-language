// The module `Lower.Node`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <lower/node_/module.hpp>
#include <lower/model/module.hpp>
#include <lower/types/module.hpp>
#include <lower/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Lower.Node`, from `target/bootstrap/cpp-src/prismc/lower/node/mod.prism`.
namespace crate::lower::node_ {



Pod FlatDef::to_pod() const {
    return Pod::record("FlatDef", {{"name", prism_rtl::to_pod(name_p)}, {"outer", prism_rtl::to_pod(outer_p)}, {"generation", prism_rtl::to_pod(generation_p)}, {"ty", prism_rtl::to_pod(ty_p)}});
}

Result<FlatDef> FlatDef::from_pod(const Pod& whole) {
    return FlatDef{.name_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .outer_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "outer")))), .generation_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "generation")))), .ty_p = TRY(prism_rtl::from_pod<crate::lower::model::OutTy>(TRY(crate::prelude::field(whole, "ty"))))};
}




void GnKind::show(Printer& p) const {
    if (auto c = std::get_if<GnNamed>(&cases())) p.choice("GnNamed", {});
    else if (auto c = std::get_if<GnAnswer>(&cases())) p.choice("GnAnswer", {});
    else if (auto c = std::get_if<GnStarted>(&cases())) p.choice("GnStarted", {});
    else if (auto c = std::get_if<GnDeferred>(&cases())) p.choice("GnDeferred", {});
    else if (auto c = std::get_if<GnPort>(&cases())) p.choice("GnPort", {});
    else if (auto c = std::get_if<GnMerge>(&cases())) p.choice("GnMerge", {});
    else if (auto c = std::get_if<GnUnion>(&cases())) p.choice("GnUnion", {});
    else if (auto c = std::get_if<GnBoth>(&cases())) p.choice("GnBoth", {});
    else if (auto c = std::get_if<GnExcept>(&cases())) p.choice("GnExcept", {});
    else if (auto c = std::get_if<GnMergeAll>(&cases())) p.choice("GnMergeAll", {});
    else if (auto c = std::get_if<GnGather>(&cases())) p.choice("GnGather", {});
    else if (auto c = std::get_if<GnUpdated>(&cases())) p.choice("GnUpdated", {});
    else if (auto c = std::get_if<GnNever>(&cases())) p.choice("GnNever", {});
}

Pod GnKind::to_pod() const {
    return std::holds_alternative<GnNamed>(cases()) ? Pod::choice("GnNamed", {})
        : std::holds_alternative<GnAnswer>(cases()) ? Pod::choice("GnAnswer", {})
        : std::holds_alternative<GnStarted>(cases()) ? Pod::choice("GnStarted", {})
        : std::holds_alternative<GnDeferred>(cases()) ? Pod::choice("GnDeferred", {})
        : std::holds_alternative<GnPort>(cases()) ? Pod::choice("GnPort", {})
        : std::holds_alternative<GnMerge>(cases()) ? Pod::choice("GnMerge", {})
        : std::holds_alternative<GnUnion>(cases()) ? Pod::choice("GnUnion", {})
        : std::holds_alternative<GnBoth>(cases()) ? Pod::choice("GnBoth", {})
        : std::holds_alternative<GnExcept>(cases()) ? Pod::choice("GnExcept", {})
        : std::holds_alternative<GnMergeAll>(cases()) ? Pod::choice("GnMergeAll", {})
        : std::holds_alternative<GnGather>(cases()) ? Pod::choice("GnGather", {})
        : std::holds_alternative<GnUpdated>(cases()) ? Pod::choice("GnUpdated", {})
        : std::holds_alternative<GnNever>(cases()) ? Pod::choice("GnNever", {})
        : Pod();
}

Result<GnKind> GnKind::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "GnNamed" && c->args.size() == 0) return GnKind(GnNamed{});
        if (c->ctor == "GnAnswer" && c->args.size() == 0) return GnKind(GnAnswer{});
        if (c->ctor == "GnStarted" && c->args.size() == 0) return GnKind(GnStarted{});
        if (c->ctor == "GnDeferred" && c->args.size() == 0) return GnKind(GnDeferred{});
        if (c->ctor == "GnPort" && c->args.size() == 0) return GnKind(GnPort{});
        if (c->ctor == "GnMerge" && c->args.size() == 0) return GnKind(GnMerge{});
        if (c->ctor == "GnUnion" && c->args.size() == 0) return GnKind(GnUnion{});
        if (c->ctor == "GnBoth" && c->args.size() == 0) return GnKind(GnBoth{});
        if (c->ctor == "GnExcept" && c->args.size() == 0) return GnKind(GnExcept{});
        if (c->ctor == "GnMergeAll" && c->args.size() == 0) return GnKind(GnMergeAll{});
        if (c->ctor == "GnGather" && c->args.size() == 0) return GnKind(GnGather{});
        if (c->ctor == "GnUpdated" && c->args.size() == 0) return GnKind(GnUpdated{});
        if (c->ctor == "GnNever" && c->args.size() == 0) return GnKind(GnNever{});
    }
    return mismatch<GnKind>("a GnKind", p);
}


Pod HostDef::to_pod() const {
    return Pod::record("HostDef", {{"pos", prism_rtl::to_pod(pos_p)}, {"name", prism_rtl::to_pod(name_p)}, {"scope", prism_rtl::to_pod(scope_p)}});
}

Result<HostDef> HostDef::from_pod(const Pod& whole) {
    return HostDef{.pos_p = TRY(prism_rtl::from_pod<crate::lower::model::Pos_>(TRY(crate::prelude::field(whole, "pos")))), .name_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .scope_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "scope"))))};
}






Pod Place::to_pod() const {
    return Pod::record("Place", {{"pos", prism_rtl::to_pod(pos_p)}, {"level", prism_rtl::to_pod(level_p)}, {"getter", prism_rtl::to_pod(getter_p)}, {"reads", prism_rtl::to_pod(reads_p)}, {"entry", prism_rtl::to_pod(entry_p)}, {"watch", prism_rtl::to_pod(watch_p)}});
}

Result<Place> Place::from_pod(const Pod& whole) {
    return Place{.pos_p = TRY(prism_rtl::from_pod<crate::lower::model::Pos_>(TRY(crate::prelude::field(whole, "pos")))), .level_p = TRY(prism_rtl::from_pod<crate::lower::model::Ex>(TRY(crate::prelude::field(whole, "level")))), .getter_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "getter")))), .reads_p = TRY(prism_rtl::from_pod<Array<Read>>(TRY(crate::prelude::field(whole, "reads")))), .entry_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "entry")))), .watch_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "watch"))))};
}


void Read::show(Printer& p) const {
    if (auto c = std::get_if<OwnRead>(&cases())) p.choice("OwnRead", {c->a0});
    else if (auto c = std::get_if<ParentRead>(&cases())) p.choice("ParentRead", {c->a0});
}

Pod Read::to_pod() const {
    return std::holds_alternative<OwnRead>(cases()) ? Pod::choice("OwnRead", {prism_rtl::to_pod(std::get<OwnRead>(cases()).a0)})
        : std::holds_alternative<ParentRead>(cases()) ? Pod::choice("ParentRead", {prism_rtl::to_pod(std::get<ParentRead>(cases()).a0)})
        : Pod();
}

Result<Read> Read::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "OwnRead" && c->args.size() == 1) return Read(OwnRead{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "ParentRead" && c->args.size() == 1) return Read(ParentRead{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
    }
    return mismatch<Read>("a Read", p);
}


Pod RowMarks::to_pod() const {
    return Pod::record("RowMarks", {{"builder", prism_rtl::to_pod(builder_p)}, {"reads", prism_rtl::to_pod(reads_p)}, {"wrote", prism_rtl::to_pod(wrote_p)}, {"kind", prism_rtl::to_pod(kind_p)}});
}

Result<RowMarks> RowMarks::from_pod(const Pod& whole) {
    return RowMarks{.builder_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "builder")))), .reads_p = TRY(prism_rtl::from_pod<Array<Read>>(TRY(crate::prelude::field(whole, "reads")))), .wrote_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "wrote")))), .kind_p = TRY(prism_rtl::from_pod<crate::lower::model::RowKind>(TRY(crate::prelude::field(whole, "kind"))))};
}


Pod Sk::to_pod() const {
    return std::holds_alternative<SkNode>(cases()) ? Pod::choice("SkNode", {prism_rtl::to_pod(std::get<SkNode>(cases()).a0)})
        : std::holds_alternative<SkIn>(cases()) ? Pod::choice("SkIn", {prism_rtl::to_pod(std::get<SkIn>(cases()).a0), prism_rtl::to_pod(std::get<SkIn>(cases()).a1)})
        : std::holds_alternative<SkHold>(cases()) ? Pod::choice("SkHold", {prism_rtl::to_pod(std::get<SkHold>(cases()).a0)})
        : std::holds_alternative<SkRequest>(cases()) ? Pod::choice("SkRequest", {prism_rtl::to_pod(std::get<SkRequest>(cases()).a0), prism_rtl::to_pod(std::get<SkRequest>(cases()).a1)})
        : std::holds_alternative<SkResult>(cases()) ? Pod::choice("SkResult", {})
        : std::holds_alternative<SkArm>(cases()) ? Pod::choice("SkArm", {prism_rtl::to_pod(std::get<SkArm>(cases()).a0)})
        : std::holds_alternative<SkCycle>(cases()) ? Pod::choice("SkCycle", {prism_rtl::to_pod(std::get<SkCycle>(cases()).a0), prism_rtl::to_pod(std::get<SkCycle>(cases()).a1), prism_rtl::to_pod(std::get<SkCycle>(cases()).a2)})
        : std::holds_alternative<SkUp>(cases()) ? Pod::choice("SkUp", {prism_rtl::to_pod(std::get<SkUp>(cases()).a0)})
        : std::holds_alternative<SkPort>(cases()) ? Pod::choice("SkPort", {prism_rtl::to_pod(std::get<SkPort>(cases()).a0)})
        : std::holds_alternative<SkMachine>(cases()) ? Pod::choice("SkMachine", {prism_rtl::to_pod(std::get<SkMachine>(cases()).a0), prism_rtl::to_pod(std::get<SkMachine>(cases()).a1), prism_rtl::to_pod(std::get<SkMachine>(cases()).a2)})
        : std::holds_alternative<SkDistinct>(cases()) ? Pod::choice("SkDistinct", {prism_rtl::to_pod(std::get<SkDistinct>(cases()).a0)})
        : std::holds_alternative<SkPerKey>(cases()) ? Pod::choice("SkPerKey", {prism_rtl::to_pod(std::get<SkPerKey>(cases()).a0)})
        : Pod();
}

Result<Sk> Sk::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "SkNode" && c->args.size() == 1) return Sk(SkNode{TRY(prism_rtl::from_pod<Nat>(c->args[0]))});
        if (c->ctor == "SkIn" && c->args.size() == 2) return Sk(SkIn{TRY(prism_rtl::from_pod<Nat>(c->args[0])), TRY(prism_rtl::from_pod<Nat>(c->args[1]))});
        if (c->ctor == "SkHold" && c->args.size() == 1) return Sk(SkHold{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "SkRequest" && c->args.size() == 2) return Sk(SkRequest{TRY(prism_rtl::from_pod<crate::lower::model::Pos_>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1]))});
        if (c->ctor == "SkResult" && c->args.size() == 0) return Sk(SkResult{});
        if (c->ctor == "SkArm" && c->args.size() == 1) return Sk(SkArm{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "SkCycle" && c->args.size() == 3) return Sk(SkCycle{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1])), TRY(prism_rtl::from_pod<Nat>(c->args[2]))});
        if (c->ctor == "SkUp" && c->args.size() == 1) return Sk(SkUp{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "SkPort" && c->args.size() == 1) return Sk(SkPort{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "SkMachine" && c->args.size() == 3) return Sk(SkMachine{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1])), TRY(prism_rtl::from_pod<Nat>(c->args[2]))});
        if (c->ctor == "SkDistinct" && c->args.size() == 1) return Sk(SkDistinct{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "SkPerKey" && c->args.size() == 1) return Sk(SkPerKey{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
    }
    return mismatch<Sk>("a Sk", p);
}


Pod SnapDef::to_pod() const {
    return Pod::record("SnapDef", {{"name", prism_rtl::to_pod(name_p)}, {"live", prism_rtl::to_pod(live_p)}, {"ty", prism_rtl::to_pod(ty_p)}, {"eq", prism_rtl::to_pod(eq_p)}, {"builder", prism_rtl::to_pod(builder_p)}, {"before", prism_rtl::to_pod(before_p)}, {"what", prism_rtl::to_pod(what_p)}});
}

Result<SnapDef> SnapDef::from_pod(const Pod& whole) {
    return SnapDef{.name_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .live_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "live")))), .ty_p = TRY(prism_rtl::from_pod<crate::lower::model::OutTy>(TRY(crate::prelude::field(whole, "ty")))), .eq_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "eq")))), .builder_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "builder")))), .before_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "before")))), .what_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "what"))))};
}






/// IdPipe: unbounded fn Ex, (unbounded fn Ex -> [Do]) -> [Do]
Array<crate::lower::model::Do> id_pipe_f(const crate::lower::model::Ex& x_p0, const prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>& k_f1) {
    return crate::prelude::run_to_end(k_f1(x_p0));
}


prism_rtl::Turn<Array<crate::lower::model::Do>> IdPipe::cycle() const {
    const auto& x_p0 = this->x_p0;
    const auto& k_f1 = this->k_f1;
    return k_f1(x_p0)->cycle();
}


/// `Start IdPipe, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::Do>> start_id_pipe_f(crate::lower::model::Ex x_p0, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)> k_f1) {
    return prism_rtl::make_rc<IdPipe>(x_p0, k_f1);
}


/// EvRefOf: fn Wx, Nat -> EvRef
EvRef ev_ref_of_f(const Wx& wx_p0, const Nat& n_p1) {
    return EvRef{.node_p = n_p1, .owner_p = wx_p0.node_p, .pipe_f = static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>)>>(prism_rtl::rc([&](std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>> _p0) {
        auto&& a0 = std::get<0>(_p0);
        auto&& a1 = std::get<1>(_p0);
        return crate::prelude::entered(start_id_pipe_f(a0, a1));
    }))};
}


/// KindWord: fn GnKind -> Text
Text kind_word_f(const GnKind& k_p0) {
    if (prism_rtl::is<GnKind::GnNamed>(k_p0)) {
        return Text::lit("named");
    }
    if (prism_rtl::is<GnKind::GnAnswer>(k_p0)) {
        return Text::lit("answer");
    }
    if (prism_rtl::is<GnKind::GnStarted>(k_p0)) {
        return Text::lit("started");
    }
    if (prism_rtl::is<GnKind::GnDeferred>(k_p0)) {
        return Text::lit("deferred");
    }
    if (prism_rtl::is<GnKind::GnPort>(k_p0)) {
        return Text::lit("port");
    }
    if (prism_rtl::is<GnKind::GnMerge>(k_p0)) {
        return Text::lit("merge");
    }
    if (prism_rtl::is<GnKind::GnUnion>(k_p0)) {
        return Text::lit("union");
    }
    if (prism_rtl::is<GnKind::GnBoth>(k_p0)) {
        return Text::lit("both");
    }
    if (prism_rtl::is<GnKind::GnExcept>(k_p0)) {
        return Text::lit("except");
    }
    if (prism_rtl::is<GnKind::GnMergeAll>(k_p0)) {
        return Text::lit("mergeall");
    }
    if (prism_rtl::is<GnKind::GnGather>(k_p0)) {
        return Text::lit("gather");
    }
    if (prism_rtl::is<GnKind::GnUpdated>(k_p0)) {
        return Text::lit("updated");
    }
    if (prism_rtl::is<GnKind::GnNever>(k_p0)) {
        return Text::lit("never");
    }
    prism_rtl::unreachable("no arm matched");
}


/// HasRead: fn [Read], Read -> Bool
bool has_read_f(const Array<Read>& rs_p0, const Read& r_p1) {
    return crate::prelude::fold(rs_p0, false, [&](const bool& seen_p2, const Read& x_p3) { return prism_rtl::deref(seen_p2) || (x_p3 == r_p1); });
}


/// AddRead: fn [Read], Read -> [Read]
Array<Read> add_read_f(const Array<Read>& rs_p0, const Read& r_p1) {
    return has_read_f(rs_p0, r_p1) ? rs_p0 : crate::prelude::push(rs_p0, r_p1);
}


/// UnionReads: fn [Read], [Read] -> [Read]
Array<Read> union_reads_f(const Array<Read>& xs_p0, const Array<Read>& ys_p1) {
    return crate::prelude::fold(ys_p1, xs_p0, [&](const Array<Read>& acc_p2, const Read& y_p3) { return add_read_f(acc_p2, y_p3); });
}


/// let nodeHooks
Array<Text> node_hooks_p() {
    return Array(std::vector{Text::lit("path"), Text::lit("build"), Text::lit("wake"), Text::lit("started"), Text::lit("deferred"), Text::lit("answer"), Text::lit("push"), Text::lit("swap"), Text::lit("leave"), Text::lit("patch"), Text::lit("clean_up"), Text::lit("edges"), Text::lit("release"), Text::lit("leave_row"), Text::lit("remove_places")});
}


/// NewWx: fn Lx, Text, [((Text, OutTy, Text))], [((Text, Ex))], [((Text, Ex))], [MethDef], (Text ==> [Read]), [Text], [Text], ?Text -> Wx
Wx new_wx_f(const crate::lower::Lx& lx_p0, const Text& name_p1, const Array<std::tuple<Text, crate::lower::model::OutTy, Text>>& fields_p2, const Array<std::tuple<Text, crate::lower::model::Ex>>& inits_p3, const Array<std::tuple<Text, crate::lower::model::Ex>>& moves_p4, const Array<crate::lower::model::MethDef>& getters_p5, const Map<Text, Array<Read>>& dyn_reads_p6, const Array<Text>& taken_p7, const Array<Text>& inlining_p8, const std::optional<Text>& hosted_by_o9) {
    auto hosted_fields_pa = ({
        __label__ _done;
        prism_rtl::Slot<Array<std::tuple<Text, crate::lower::model::OutTy, Text>>> _v;
        if (prism_rtl::is_some(hosted_by_o9)) {
            _v.set(Array(std::vector{std::tuple{Text::lit("enclosing"), crate::lower::types::host_of_ty_p(), Text::lit("the host whose document this row\'s places are entries of (pick HO)")}}));
            goto _done;
        }
        if (prism_rtl::is_none(hosted_by_o9)) {
            _v.set(Array<std::tuple<Text, crate::lower::model::OutTy, Text>>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto hosted_inits_pb = ({
        __label__ _done;
        prism_rtl::Slot<Array<std::tuple<Text, crate::lower::model::Ex>>> _v;
        if (prism_rtl::is_some(hosted_by_o9)) {
            _v.set(Array(std::vector{std::tuple{Text::lit("enclosing"), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("enclosing")})}}));
            goto _done;
        }
        if (prism_rtl::is_none(hosted_by_o9)) {
            _v.set(Array<std::tuple<Text, crate::lower::model::Ex>>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return Wx{.lx_p = lx_p0, .node_p = name_p1, .pos_p = crate::lower::model::pos0_p(), .gns_p = Array<Gn>{}, .fields_p = crate::prelude::append(fields_p2, hosted_fields_pa), .inits_p = inits_p3, .moves_p = crate::prelude::append(moves_p4, hosted_inits_pb), .lets_p = Array<crate::lower::model::Do>{}, .build_p = Array<crate::lower::model::Do>{}, .places_p = Array<Place>{}, .answers_p = Array<std::tuple<crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text>>{}, .started_p = Array<Nat>{}, .defers_p = Array<std::tuple<Text, Nat>>{}, .getters_p = getters_p5, .dyn_reads_p = dyn_reads_p6, .taken_p = crate::prelude::push(taken_p7, Text::lit("enclosing")), .fallible_p = false, .inlining_p = inlining_p8, .result_p = Wres(Wres::WrUnit{}), .rows_p = Array<crate::lower::model::NodeDef>{}, .builders_p = Array<crate::lower::model::ForDef>{}, .let_caches_p = Array<Text>{}, .build_holds_p = Array<Read>{}, .up_sink_p = Text::lit(""), .gens_p = Array<crate::lower::model::GenDef>{}, .gen_holds_p = Array<std::tuple<Text, Array<Read>>>{}, .ports_p = Array<Text>{}, .subs_p = Array<std::tuple<Text, Text, crate::lower::model::OutTy>>{}, .parent_env_p = crate::lower::types::empty_env_p(), .hosts_p = Array<HostDef>{}, .dyn_places_p = Array<std::tuple<crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text>>{}, .scopes_p = Array<Text>{}, .hosted_by_o = hosted_by_o9, .root_dyn_o = std::optional<std::tuple<crate::lower::model::Ex, Array<Read>, crate::lower::model::OutTy>>{}, .row_marks_p = Array<RowMarks>{}, .pending_p = Array<PendingRow>{}, .floors_p = Map<Text, Nat>{}, .snaps_p = Array<SnapDef>{}, .result_moved_o = std::optional<std::tuple<Text, Array<Read>>>{}, .dyn_answers_p = Array<std::tuple<Text, Array<Read>>>{}, .inited_p = Array<Text>{}, .flattens_p = Array<FlatDef>{}};
}


/// FreshName: fn Wx, Text -> ((Text, Wx))
std::tuple<Text, Wx> fresh_name_f(const Wx& wx_p0, const Text& base_p1) {
    auto pick_p2 = !crate::check::types::has_text_f(wx_p0.taken_p, base_p1)
        ? base_p1
        : prism_rtl::cat(base_p1, "_", first_free_f(wx_p0.taken_p, base_p1, Nat(2u)));
    auto wx2_p3 = ({
        Wx this_ = wx_p0;
        this_.taken_p = crate::prelude::push(this_.taken_p, pick_p2);
        (std::move(this_));
    });
    return std::tuple{pick_p2, wx2_p3};
}


/// FirstFree: fn [Text], Text, Nat -> Nat
Nat first_free_f(const Array<Text>& taken_p0, const Text& base_p1, const Nat& from_p2) {
    return crate::prelude::fold(crate::check::errors::range0_f(crate::prelude::len(taken_p0)), from_p2, [&](const Nat& n_p3, const Nat& _p1) {
        return crate::check::types::has_text_f(taken_p0, prism_rtl::cat(base_p1, "_", n_p3))
            ? n_p3 + Nat(1u)
            : n_p3;
    });
}


/// AddGn: fn Wx, Text, OutTy, GnKind, Nat -> ((Nat, Wx))
std::tuple<Nat, Wx> add_gn_f(const Wx& wx_p0, const Text& name_p1, const crate::lower::model::OutTy& ty_p2, const GnKind& kind_p3, const Nat& height_p4) {
    auto id_p5 = crate::prelude::len(wx_p0.gns_p);
    auto wx2_p6 = ({
        Wx this_ = wx_p0;
        this_.gns_p = crate::prelude::push(this_.gns_p, Gn{.id_p = id_p5, .name_p = name_p1, .ty_p = ty_p2, .kind_p = kind_p3, .height_p = height_p4, .inputs_p = Array<Text>{}, .reads_p = Array<Read>{}, .floor_p = Nat(0u), .outs_p = Array<Out>{}});
        (std::move(this_));
    });
    return std::tuple{id_p5, wx2_p6};
}


/// Connect: fn Wx, EvRef, Sk -> Wx
Wx connect_f(const Wx& wx_p0, const EvRef& r_p1, const Sk& sink_p2) {
    return r_p1.owner_p != wx_p0.node_p
        ? crossed_f(wx_p0, prism_rtl::cat("an event of node `", r_p1.owner_p, "` (its graph node ", r_p1.node_p, ")"))
        : ({
        Wx this_ = wx_p0;
        this_.gns_p = crate::prelude::each(this_.gns_p, [&](const Gn& n_p3) {
            return prism_rtl::deref(n_p3).id_p == r_p1.node_p
                ? add_out_f(n_p3, Out{.pipe_f = r_p1.pipe_f, .sink_p = sink_p2})
                : n_p3;
        });
        (std::move(this_));
    });
}


/// Crossed: fn Wx, Text -> Wx
Wx crossed_f(const Wx& wx_p0, const Text& what_p1) {
    Wx this_ = wx_p0;
    this_.build_p = crate::prelude::push(this_.build_p, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::expr::refusal_f(prism_rtl::cat(what_p1, " read in node `", wx_p0.node_p, "` without a port (a lowering bug)"))}));
    return this_;
}


/// AddOut: fn Gn, Out -> Gn
Gn add_out_f(const Gn& n_p0, const Out& o_p1) {
    Gn this_ = n_p0;
    this_.outs_p = crate::prelude::push(this_.outs_p, o_p1);
    return this_;
}


/// AddField: fn Wx, Text, OutTy, Text, Ex -> Wx
Wx add_field_f(const Wx& wx_p0, const Text& name_p1, const crate::lower::model::OutTy& t_p2, const Text& doc_p3, const crate::lower::model::Ex& init_p4) {
    Wx this_ = wx_p0;
    this_.fields_p = crate::prelude::push(this_.fields_p, std::tuple{name_p1, t_p2, doc_p3});
    this_.inits_p = crate::prelude::push(this_.inits_p, std::tuple{name_p1, init_p4});
    return this_;
}


/// AddFieldLast: fn Wx, Text, OutTy, Text, Ex -> Wx
Wx add_field_last_f(const Wx& wx_p0, const Text& name_p1, const crate::lower::model::OutTy& t_p2, const Text& doc_p3, const crate::lower::model::Ex& init_p4) {
    Wx this_ = wx_p0;
    this_.fields_p = crate::prelude::push(this_.fields_p, std::tuple{name_p1, t_p2, doc_p3});
    this_.moves_p = crate::prelude::push(this_.moves_p, std::tuple{name_p1, init_p4});
    return this_;
}


/// GnOf: fn Wx, Nat -> Gn
Gn gn_of_f(const Wx& wx_p0, const Nat& n_p1) {
    return crate::prelude::or_(crate::prelude::index(wx_p0.gns_p, n_p1), Gn{.id_p = n_p1, .name_p = Text::lit("never"), .ty_p = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .kind_p = GnKind(GnKind::GnNever{}), .height_p = Nat(0u), .inputs_p = Array<Text>{}, .reads_p = Array<Read>{}, .floor_p = Nat(0u), .outs_p = Array<Out>{}});
}


/// BindPlain: fn Env, Env, Text, Text, OutTy -> ((Env, Env))
std::tuple<crate::lower::types::Env, crate::lower::types::Env> bind_plain_f(const crate::lower::types::Env& benv_p0, const crate::lower::types::Env& menv_p1, const Text& nkey_p2, const Text& rs_p3, const crate::lower::model::OutTy& t_p4) {
    return std::tuple{crate::lower::types::bind_f(benv_p0, nkey_p2, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs_p3}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t_p4})), crate::lower::types::bind_f(menv_p1, nkey_p2, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), rs_p3}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t_p4}))};
}

}  // namespace crate::lower::node_
