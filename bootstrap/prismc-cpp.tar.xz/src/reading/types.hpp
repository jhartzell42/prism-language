// The module `Reading`: its records, tags and newtypes (each after the types it holds) and its
// choices' cases, emitted by prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <reading/decl.hpp>
#include "elem.decl.hpp"
#include <program/decl.hpp>
#include <check/decl.hpp>
#include <check/blocks/decl.hpp>
#include <check/blocks/borrows/decl.hpp>
#include <check/blocks/structure/decl.hpp>
#include <check/env/decl.hpp>
#include <check/env/decls/decl.hpp>
#include <check/env/names/decl.hpp>
#include <check/env/reading/decl.hpp>
#include <check/env/traits/decl.hpp>
#include <check/errors/decl.hpp>
#include <check/expr/decl.hpp>
#include <check/expr/calls/decl.hpp>
#include <check/expr/lets/decl.hpp>
#include <check/expr/lifting/decl.hpp>
#include <check/expr/operators/decl.hpp>
#include <check/expr/patterns/decl.hpp>
#include <check/passes/decl.hpp>
#include <check/passes/borrows/decl.hpp>
#include <check/passes/cycles/decl.hpp>
#include <check/shrink/decl.hpp>
#include <check/shrink/calls/decl.hpp>
#include <check/shrink/locals/decl.hpp>
#include <check/shrink/relations/decl.hpp>
#include <check/shrink/summaries/decl.hpp>
#include <check/shrink/types/decl.hpp>
#include <check/shrink/walk/decl.hpp>
#include <check/typed/decl.hpp>
#include <check/typed/print/decl.hpp>
#include <check/types/decl.hpp>
#include <check/types/colors/decl.hpp>
#include <check/types/recording/decl.hpp>
#include <check/types/schemes/decl.hpp>
#include <check/types/unify/decl.hpp>
#include <checking/decl.hpp>
#include <compile/decl.hpp>
#include <emit/decl.hpp>
#include <emit/cpp/decl.hpp>
#include <emit/cpp/expr/decl.hpp>
#include <emit/cpp/items/decl.hpp>
#include <emit/cpp/patterns/decl.hpp>
#include <emit/cpp/prelude/decl.hpp>
#include <emit/cpp/program/decl.hpp>
#include <emit/cpp/stmts/decl.hpp>
#include <emit/cpp/templates/decl.hpp>
#include <emit/cpp/templates/items/decl.hpp>
#include <emit/rust/decl.hpp>
#include <emit/rust/items/decl.hpp>
#include <emit/rust/prelude/decl.hpp>
#include <emit/rust/templates/decl.hpp>
#include <emit/rust/templates/items/decl.hpp>
#include <fs/decl.hpp>
#include <lower/decl.hpp>
#include <lower/expr/decl.hpp>
#include <lower/functions/decl.hpp>
#include <lower/jobs/decl.hpp>
#include <lower/model/decl.hpp>
#include <lower/node_/decl.hpp>
#include <lower/node_/def/decl.hpp>
#include <lower/node_/dynamics/decl.hpp>
#include <lower/node_/elements/decl.hpp>
#include <lower/node_/finish/decl.hpp>
#include <lower/node_/keyed/decl.hpp>
#include <lower/node_/static_/decl.hpp>
#include <lower/node_/switch_/decl.hpp>
#include <lower/patterns/decl.hpp>
#include <lower/program/decl.hpp>
#include <lower/templates/decl.hpp>
#include <lower/types/decl.hpp>
#include <process/decl.hpp>
#include <syntax/decls/decl.hpp>
#include <syntax/lexer/decl.hpp>
#include <syntax/lexer/chars/decl.hpp>
#include <syntax/lexer/corpus/decl.hpp>
#include <syntax/lexer/layout/decl.hpp>
#include <syntax/lexer/literals/decl.hpp>
#include <syntax/lexer/templates/decl.hpp>
#include <syntax/lexer/words/decl.hpp>
#include <syntax/parser/decl.hpp>
#include <syntax/parser/blocks/decl.hpp>
#include <syntax/parser/decls/decl.hpp>
#include <syntax/parser/expr/decl.hpp>
#include <syntax/parser/test_language/decl.hpp>
#include <syntax/parser/types/decl.hpp>
#include <syntax/sexp/decl.hpp>
#include <syntax/types.hpp>

namespace crate {

using namespace prelude;

namespace reading {

/// `Assembled`:
///
/// ```prism
/// type Assembled = record:
/// ```
struct Assembled {
    using prism_value = void;
    Array<ModFiles> units;
    Array<ModFiles> prelude;
    Array<Text> scripts;
    Array<TreeDiag> errors;
    const Assembled* operator->() const { return this; }
    Assembled* operator->() { return this; }
    bool operator==(const Assembled&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Assembled> from_pod(const Pod& whole);
};


}  // namespace reading

namespace reading {

/// `CheckOpts`:
///
/// ```prism
/// type CheckOpts = record:
/// ```
struct CheckOpts {
    using prism_value = void;
    Array<Text> world;
    std::optional<Text> out;
    bool typed;
    bool unused;
    const CheckOpts* operator->() const { return this; }
    CheckOpts* operator->() { return this; }
    bool operator==(const CheckOpts&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<CheckOpts> from_pod(const Pod& whole);
};


}  // namespace reading

namespace reading {

/// `CompileSettings`:
///
/// ```prism
/// type CompileSettings = record:
/// ```
struct CompileSettings {
    using prism_value = void;
    Text out;
    Text prelude;
    Text name;
    Text runtime;
    Text target;
    const CompileSettings* operator->() const { return this; }
    CompileSettings* operator->() { return this; }
    bool operator==(const CompileSettings&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<CompileSettings> from_pod(const Pod& whole);
};


}  // namespace reading

namespace reading {

/// `HeadLine`:
///
/// ```prism
/// type HeadLine = record:
/// ```
struct HeadLine {
    using prism_value = void;
    Text word;
    Text arg;
    crate::syntax::Range span;
    const HeadLine* operator->() const { return this; }
    HeadLine* operator->() { return this; }
    bool operator==(const HeadLine&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<HeadLine> from_pod(const Pod& whole);
};


}  // namespace reading

namespace reading {

/// `ModFiles`:
///
/// ```prism
/// type ModFiles = record:
/// ```
struct ModFiles {
    using prism_value = void;
    Text name;
    bool named;
    Array<Seg> segs;
    Text parent;
    const ModFiles* operator->() const { return this; }
    ModFiles* operator->() { return this; }
    bool operator==(const ModFiles&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ModFiles> from_pod(const Pod& whole);
};


}  // namespace reading

namespace reading {

/// `ParsedProgram`:
///
/// ```prism
/// type ParsedProgram = record:
/// ```
struct ParsedProgram {
    using prism_value = void;
    Array<crate::check::errors::Src> srcs;
    Array<crate::syntax::Module> trees;
    Nat shown;
    Array<Text> parents;
    Text errors;
    const ParsedProgram* operator->() const { return this; }
    ParsedProgram* operator->() { return this; }
    bool operator==(const ParsedProgram&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ParsedProgram> from_pod(const Pod& whole);
};


}  // namespace reading

namespace reading {

/// `ReadInput`:
///
/// ```prism
/// type ReadInput = record:
/// ```
struct ReadInput {
    using prism_value = void;
    Array<Text> args;
    Text prelude;
    Array<std::tuple<Text, Array<Text>>> listings;
    Array<Text> paths;
    Array<std::tuple<Text, Text>> texts;
    bool tests;
    bool compiling;
    const ReadInput* operator->() const { return this; }
    ReadInput* operator->() { return this; }
    bool operator==(const ReadInput&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ReadInput> from_pod(const Pod& whole);
};


}  // namespace reading

namespace reading {

/// `Seg`:
///
/// ```prism
/// type Seg = record:
/// ```
struct Seg {
    using prism_value = void;
    Text path_;
    Text text;
    Text role;
    const Seg* operator->() const { return this; }
    Seg* operator->() { return this; }
    bool operator==(const Seg&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Seg> from_pod(const Pod& whole);
};


}  // namespace reading

namespace reading {

/// `TreeAcc`:
///
/// ```prism
/// type TreeAcc = record:
/// ```
struct TreeAcc {
    using prism_value = void;
    Array<ModFiles> units;
    Map<Text, bool> declared;
    Array<TreeDiag> diags;
    const TreeAcc* operator->() const { return this; }
    TreeAcc* operator->() { return this; }
    bool operator==(const TreeAcc&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TreeAcc> from_pod(const Pod& whole);
};


}  // namespace reading

namespace reading {

/// `TreeDiag`:
///
/// ```prism
/// type TreeDiag = record:
/// ```
struct TreeDiag {
    using prism_value = void;
    Text path_;
    crate::syntax::Range span;
    Text code;
    Text message;
    Text fix;
    const TreeDiag* operator->() const { return this; }
    TreeDiag* operator->() { return this; }
    bool operator==(const TreeDiag&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TreeDiag> from_pod(const Pod& whole);
};


}  // namespace reading

namespace reading {

struct ReadMode::Checking {
    CheckOpts a0;
    bool operator==(const Checking&) const = default;
};


struct ReadMode::Compiling {
    CompileSettings a0;
    bool operator==(const Compiling&) const = default;
};


inline const ReadMode::Cases& ReadMode::cases() const { return *cases_; }

inline bool operator==(const ReadMode& a, const ReadMode& b) { return a.cases() == b.cases(); }

}  // namespace reading

}  // namespace crate
