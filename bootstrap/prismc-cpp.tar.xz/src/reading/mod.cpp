// The module `Reading`, from `target/bootstrap/cpp-src/prismc/reading.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate::reading {

void Assembled::show(Printer& p) const {
    p.record("Assembled", {{"units", units}, {"prelude", prelude}, {"scripts", scripts}, {"errors", errors}});
}

Pod Assembled::to_pod() const {
    return Pod::record("Assembled", {{"units", prism_rtl::to_pod(units)}, {"prelude", prism_rtl::to_pod(prelude)}, {"scripts", prism_rtl::to_pod(scripts)}, {"errors", prism_rtl::to_pod(errors)}});
}

Result<Assembled> Assembled::from_pod(const Pod& whole) {
    return Assembled{.units = TRY(prism_rtl::from_pod<Array<ModFiles>>(TRY(crate::prelude::field(whole, "units")))), .prelude = TRY(prism_rtl::from_pod<Array<ModFiles>>(TRY(crate::prelude::field(whole, "prelude")))), .scripts = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "scripts")))), .errors = TRY(prism_rtl::from_pod<Array<TreeDiag>>(TRY(crate::prelude::field(whole, "errors"))))};
}


void CheckOpts::show(Printer& p) const {
    p.record("CheckOpts", {{"world", world}, {"out", out}, {"typed", typed}, {"unused", unused}});
}

Pod CheckOpts::to_pod() const {
    return Pod::record("CheckOpts", {{"world", prism_rtl::to_pod(world)}, {"out", prism_rtl::to_pod(out)}, {"typed", prism_rtl::to_pod(typed)}, {"unused", prism_rtl::to_pod(unused)}});
}

Result<CheckOpts> CheckOpts::from_pod(const Pod& whole) {
    return CheckOpts{.world = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "world")))), .out = TRY(prism_rtl::from_pod<std::optional<Text>>(TRY(crate::prelude::field(whole, "out")))), .typed = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "typed")))), .unused = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "unused"))))};
}


void CompileSettings::show(Printer& p) const {
    p.record("CompileSettings", {{"out", out}, {"prelude", prelude}, {"name", name}, {"runtime", runtime}, {"target", target}});
}

Pod CompileSettings::to_pod() const {
    return Pod::record("CompileSettings", {{"out", prism_rtl::to_pod(out)}, {"prelude", prism_rtl::to_pod(prelude)}, {"name", prism_rtl::to_pod(name)}, {"runtime", prism_rtl::to_pod(runtime)}, {"target", prism_rtl::to_pod(target)}});
}

Result<CompileSettings> CompileSettings::from_pod(const Pod& whole) {
    return CompileSettings{.out = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "out")))), .prelude = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "prelude")))), .name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .runtime = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "runtime")))), .target = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "target"))))};
}


void HeadLine::show(Printer& p) const {
    p.record("HeadLine", {{"word", word}, {"arg", arg}, {"span", span}});
}

Pod HeadLine::to_pod() const {
    return Pod::record("HeadLine", {{"word", prism_rtl::to_pod(word)}, {"arg", prism_rtl::to_pod(arg)}, {"span", prism_rtl::to_pod(span)}});
}

Result<HeadLine> HeadLine::from_pod(const Pod& whole) {
    return HeadLine{.word = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "word")))), .arg = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "arg")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void ModFiles::show(Printer& p) const {
    p.record("ModFiles", {{"name", name}, {"named", named}, {"segs", segs}, {"parent", parent}});
}

Pod ModFiles::to_pod() const {
    return Pod::record("ModFiles", {{"name", prism_rtl::to_pod(name)}, {"named", prism_rtl::to_pod(named)}, {"segs", prism_rtl::to_pod(segs)}, {"parent", prism_rtl::to_pod(parent)}});
}

Result<ModFiles> ModFiles::from_pod(const Pod& whole) {
    return ModFiles{.name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .named = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "named")))), .segs = TRY(prism_rtl::from_pod<Array<Seg>>(TRY(crate::prelude::field(whole, "segs")))), .parent = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "parent"))))};
}


void ParsedProgram::show(Printer& p) const {
    p.record("ParsedProgram", {{"srcs", srcs}, {"trees", trees}, {"shown", shown}, {"parents", parents}, {"errors", errors}});
}

Pod ParsedProgram::to_pod() const {
    return Pod::record("ParsedProgram", {{"srcs", prism_rtl::to_pod(srcs)}, {"trees", prism_rtl::to_pod(trees)}, {"shown", prism_rtl::to_pod(shown)}, {"parents", prism_rtl::to_pod(parents)}, {"errors", prism_rtl::to_pod(errors)}});
}

Result<ParsedProgram> ParsedProgram::from_pod(const Pod& whole) {
    return ParsedProgram{.srcs = TRY(prism_rtl::from_pod<Array<crate::check::errors::Src>>(TRY(crate::prelude::field(whole, "srcs")))), .trees = TRY(prism_rtl::from_pod<Array<crate::syntax::Module>>(TRY(crate::prelude::field(whole, "trees")))), .shown = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "shown")))), .parents = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "parents")))), .errors = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "errors"))))};
}


void ReadInput::show(Printer& p) const {
    p.record("ReadInput", {{"args", args}, {"prelude", prelude}, {"listings", listings}, {"paths", paths}, {"texts", texts}, {"tests", tests}, {"compiling", compiling}});
}

Pod ReadInput::to_pod() const {
    return Pod::record("ReadInput", {{"args", prism_rtl::to_pod(args)}, {"prelude", prism_rtl::to_pod(prelude)}, {"listings", prism_rtl::to_pod(listings)}, {"paths", prism_rtl::to_pod(paths)}, {"texts", prism_rtl::to_pod(texts)}, {"tests", prism_rtl::to_pod(tests)}, {"compiling", prism_rtl::to_pod(compiling)}});
}

Result<ReadInput> ReadInput::from_pod(const Pod& whole) {
    return ReadInput{.args = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "args")))), .prelude = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "prelude")))), .listings = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Array<Text>>>>(TRY(crate::prelude::field(whole, "listings")))), .paths = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "paths")))), .texts = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text>>>(TRY(crate::prelude::field(whole, "texts")))), .tests = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "tests")))), .compiling = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "compiling"))))};
}


void ReadMode::show(Printer& p) const {
    if (auto c = std::get_if<Checking>(&cases())) p.choice("Checking", {c->a0});
    else if (auto c = std::get_if<Compiling>(&cases())) p.choice("Compiling", {c->a0});
}

Pod ReadMode::to_pod() const {
    return std::holds_alternative<Checking>(cases()) ? Pod::choice("Checking", {prism_rtl::to_pod(std::get<Checking>(cases()).a0)})
        : std::holds_alternative<Compiling>(cases()) ? Pod::choice("Compiling", {prism_rtl::to_pod(std::get<Compiling>(cases()).a0)})
        : Pod();
}

Result<ReadMode> ReadMode::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "Checking" && c->args.size() == 1) return ReadMode(Checking{TRY(prism_rtl::from_pod<CheckOpts>(c->args[0]))});
        if (c->ctor == "Compiling" && c->args.size() == 1) return ReadMode(Compiling{TRY(prism_rtl::from_pod<CompileSettings>(c->args[0]))});
    }
    return mismatch<ReadMode>("a ReadMode", p);
}


void Seg::show(Printer& p) const {
    p.record("Seg", {{"path", path_}, {"text", text}, {"role", role}});
}

Pod Seg::to_pod() const {
    return Pod::record("Seg", {{"path", prism_rtl::to_pod(path_)}, {"text", prism_rtl::to_pod(text)}, {"role", prism_rtl::to_pod(role)}});
}

Result<Seg> Seg::from_pod(const Pod& whole) {
    return Seg{.path_ = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "path")))), .text = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "text")))), .role = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "role"))))};
}


void TreeAcc::show(Printer& p) const {
    p.record("TreeAcc", {{"units", units}, {"declared", declared}, {"diags", diags}});
}

Pod TreeAcc::to_pod() const {
    return Pod::record("TreeAcc", {{"units", prism_rtl::to_pod(units)}, {"declared", prism_rtl::to_pod(declared)}, {"diags", prism_rtl::to_pod(diags)}});
}

Result<TreeAcc> TreeAcc::from_pod(const Pod& whole) {
    return TreeAcc{.units = TRY(prism_rtl::from_pod<Array<ModFiles>>(TRY(crate::prelude::field(whole, "units")))), .declared = TRY(prism_rtl::from_pod<Map<Text, bool>>(TRY(crate::prelude::field(whole, "declared")))), .diags = TRY(prism_rtl::from_pod<Array<TreeDiag>>(TRY(crate::prelude::field(whole, "diags"))))};
}


void TreeDiag::show(Printer& p) const {
    p.record("TreeDiag", {{"path", path_}, {"span", span}, {"code", code}, {"message", message}, {"fix", fix}});
}

Pod TreeDiag::to_pod() const {
    return Pod::record("TreeDiag", {{"path", prism_rtl::to_pod(path_)}, {"span", prism_rtl::to_pod(span)}, {"code", prism_rtl::to_pod(code)}, {"message", prism_rtl::to_pod(message)}, {"fix", prism_rtl::to_pod(fix)}});
}

Result<TreeDiag> TreeDiag::from_pod(const Pod& whole) {
    return TreeDiag{.path_ = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "path")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span")))), .code = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "code")))), .message = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "message")))), .fix = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "fix"))))};
}


/// IsCompiling: fn ReadMode -> Bool
bool is_compiling(const ReadMode& read_mode0) {
    if (prism_rtl::is<ReadMode::Compiling>(read_mode0)) {
        return true;
    }
    if (prism_rtl::is<ReadMode::Checking>(read_mode0)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


// `@ReadSources` is inlined where it is applied.

// `@ReadUp` is inlined where it is applied.

// `@ReadTexts` is inlined where it is applied.

// `@ReadRun` is inlined where it is applied.

// `@RunRead` is inlined where it is applied.

// `@CheckRun` is inlined where it is applied.

// `@CompileRun` is inlined where it is applied.

/// Pairs: fn [Text], (Nat ==> [Text]) -> [((Text, [Text]))]
Array<std::tuple<Text, Array<Text>>> pairs(const Array<Text>& ds, const Map<Nat, Array<Text>>& m) {
    return each(crate::check::errors::range0(len(ds)), [&](const Nat& i) { return std::tuple{or_(index(ds, i), Text::lit("")), or_(crate::prelude::get(m, i), Array<Text>{})}; });
}


/// ReadFailure: fn ?~Contents -> Text
Text read_failure(const std::optional<Fallible<crate::fs::Contents>>& opt0) {
    if (prism_rtl::is_some(opt0)) {
        auto&& c_try = prism_rtl::some_of(opt0);
        return contents_failure(c_try);
    }
    if (prism_rtl::is_none(opt0)) {
        return Text::lit("nothing was read");
    }
    prism_rtl::unreachable("no arm matched");
}


/// ContentsFailure: fn ~Contents -> Text
Text contents_failure(const Fallible<crate::fs::Contents>& arg0) {
    if (prism_rtl::is_ok(arg0)) {
        auto&& c = *arg0;
        return Text::lit("");
    }
    if (prism_rtl::is_err(arg0)) {
        auto&& c1_0 = arg0.error();
        return c1_0.message;
    }
    prism_rtl::unreachable("no arm matched");
}


/// ContentsText: fn ~Contents -> Text
Text contents_text(const Fallible<crate::fs::Contents>& arg0) {
    if (prism_rtl::is_ok(arg0)) {
        auto&& c = *arg0;
        return c->text;
    }
    if (prism_rtl::is_err(arg0)) {
        auto&& c1_0 = arg0.error();
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// IsSourcePath: fn Text -> Bool
bool is_source_path(const Text& f) {
    return crate::syntax::lexer::chars::has_suffix(f, Text::lit(".prism")) || crate::syntax::lexer::chars::has_suffix(f, Text::lit(".prismtest"));
}


/// DirOf: fn Text -> Text
Text dir_of(const Text& p_) {
    return crate::syntax::lexer::chars::join(crate::syntax::lexer::chars::pop(split(p_, Text::lit("/"))), Text::lit("/"));
}


/// BaseOf: fn Text -> Text
Text base_of(const Text& p_) {
    return or_(crate::syntax::lexer::chars::last(split(p_, Text::lit("/"))), p_);
}


/// Under: fn Text, Text -> Text
Text under(const Text& d, const Text& n) {
    return (d == Text::lit("")) || (d == Text::lit("."))
        ? n
        : prism_rtl::cat(d, "/", n);
}


/// Ancestors: fn Text -> [Text]
Array<Text> ancestors(const Text& d) {
    auto parts = split(d, Text::lit("/"));
    auto n = len(parts);
    return filter(each(crate::check::errors::range0(crate::syntax::lexer::chars::dec(n)), [&](const Nat& i) { return crate::syntax::lexer::chars::join(take(parts, or_(crate::syntax::lexer::chars::dec(n).checked_sub(i), Nat(0u))), Text::lit("/")); }), [&](const Text& a) { return (a != Text::lit("")) && (a != Text::lit(".")); });
}


/// DirName: fn Text -> Text
Text dir_name(const Text& name) {
    auto&& _out = crate::syntax::lexer::chars::fold_chars(name, std::tuple{Text::lit(""), Text::lit("")}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text>>(std::tuple<std::tuple<Text, Text>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Text, Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return once_job([=]() {
            return ({
                auto [acc, prev] = p0;
                auto c = p1;
                ({
                auto sep = crate::syntax::lexer::chars::is_upper(c) && (crate::syntax::lexer::chars::is_lower(prev) || crate::syntax::lexer::chars::is_digit(prev))
                    ? Text::lit("_")
                    : Text::lit("");
                (prism_rtl::finished(std::tuple{prism_rtl::cat(acc, sep, crate::syntax::lexer::chars::is_upper(c) ? crate::prelude::lower(c) : c), c}));
            });
            });
        });
    })));
    auto&& out = std::get<0>(_out);
    return out;
}


/// ModOfDir: fn Text -> Text
Text mod_of_dir(const Text& d) {
    return concat(each(split(d, Text::lit("_")), [&](const Text& w) { return prism_rtl::cat(upper(crate::syntax::lexer::chars::head(w)), crate::syntax::lexer::chars::after_first(w)); }));
}


/// HeaderLines: fn Text -> [HeadLine]
Array<HeadLine> header_lines(const Text& text_) {
    auto&& _lines = fold(split(text_, Text::lit("\n")), std::tuple{Array<HeadLine>{}, Nat(0u), true}, [&](const std::tuple<Array<HeadLine>, Nat, bool>& _p0, const Text& line) {
        auto&& acc = std::get<0>(_p0);
        auto&& at_ = std::get<1>(_p0);
        auto&& open = std::get<2>(_p0);
        return ({
            auto next = (at_ + len_text(line)) + Nat(1u);
            !open
            ? std::tuple{acc, next, false}
            : ((crate::syntax::lexer::chars::trim(line) == Text::lit("")) || crate::syntax::lexer::chars::has_prefix(line, Text::lit("#"))) || crate::syntax::lexer::chars::has_prefix(line, Text::lit(" "))
            ? std::tuple{acc, next, true}
            : ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Array<HeadLine>, Nat, bool>> _v;
            auto&& _m = head_line_of(line, at_);
            if (prism_rtl::is_some(_m)) {
                auto&& h = prism_rtl::some_of(_m);
                _v.set(std::tuple{crate::prelude::push(acc, h), next, true});
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(std::tuple{acc, next, false});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        });
    });
    auto&& lines = std::get<0>(_lines);
    return lines;
}


/// ?HeadLineOf: fn Text, Nat -> ?HeadLine
std::optional<HeadLine> head_line_of(const Text& line, const Nat& at_) {
    auto code = crate::syntax::lexer::chars::trim_end(or_(index(split(line, Text::lit(" #")), Nat(0u)), line));
    auto words = filter(split(code, Text::lit(" ")), [&](const Text& w) { return w != Text::lit(""); });
    auto first_ = or_(index(words, Nat(0u)), Text::lit(""));
    auto second = or_(index(words, Nat(1u)), Text::lit(""));
    auto span = crate::syntax::Range{.start = at_, .end = at_ + len_text(code)};
    return (first_ == Text::lit("test")) && (second == Text::lit("mod"))
        ? std::optional(HeadLine{.word = Text::lit("test mod"), .arg = or_(index(words, Nat(2u)), Text::lit("")), .span = span})
        : crate::check::types::has_text(Array(std::vector{Text::lit("module"), Text::lit("emit"), Text::lit("mod"), Text::lit("use")}), first_)
        ? std::optional(HeadLine{.word = first_, .arg = or_(crate::syntax::lexer::chars::before_suffix(second, Text::lit(".*")), second), .span = span})
        : std::optional<HeadLine>{};
}


/// ?FirstDeclLine: fn Text -> ?Range
std::optional<crate::syntax::Range> first_decl_line(const Text& text_) {
    auto&& _found_opt = fold(split(text_, Text::lit("\n")), std::tuple{std::optional<crate::syntax::Range>{}, Nat(0u)}, [&](const std::tuple<std::optional<crate::syntax::Range>, Nat>& _p0, const Text& line) {
        auto&& f_opt = std::get<0>(_p0);
        auto&& at_ = std::get<1>(_p0);
        return ({
            auto next = (at_ + len_text(line)) + Nat(1u);
            ((((f_opt != std::optional<crate::syntax::Range>{}) || (crate::syntax::lexer::chars::trim(line) == Text::lit(""))) || crate::syntax::lexer::chars::has_prefix(line, Text::lit("#"))) || crate::syntax::lexer::chars::has_prefix(line, Text::lit(" "))) || (head_line_of(line, at_) != std::optional<HeadLine>{})
            ? std::tuple{f_opt, next}
            : std::tuple{std::optional(crate::syntax::Range{.start = at_, .end = at_ + len_text(crate::syntax::lexer::chars::trim_end(line))}), next};
        });
    });
    auto&& found_opt = std::get<0>(_found_opt);
    return found_opt;
}


/// let noAssembly
Assembled no_assembly() {
    return Assembled{.units = Array<ModFiles>{}, .prelude = Array<ModFiles>{}, .scripts = Array<Text>{}, .errors = Array<TreeDiag>{}};
}


/// let noSpan
crate::syntax::Range no_span() {
    return crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)};
}


/// AddTreeDiag: fn TreeAcc, Text, Range, Text, Text, Text -> TreeAcc
TreeAcc add_tree_diag(const TreeAcc& acc, const Text& path_, const crate::syntax::Range& span, const Text& code, const Text& message, const Text& fix) {
    TreeAcc this_ = acc;
    this_.diags = crate::prelude::push(this_.diags, TreeDiag{.path_ = path_, .span = span, .code = code, .message = message, .fix = fix});
    return this_;
}


/// IsModuleDir: fn Text, [Text] -> Bool
bool is_module_dir(const Text& d, const Array<Text>& files) {
    return (crate::check::types::has_text(files, under(d, Text::lit("mod.prism"))) && (!crate::check::types::has_text(files, under(d, Text::lit("app.prism"))))) && (!crate::check::types::has_text(files, under(d, Text::lit("lib.prism"))));
}


/// IsRootDir: fn Text, [Text] -> Bool
bool is_root_dir(const Text& d, const Array<Text>& files) {
    return crate::check::types::has_text(files, under(d, Text::lit("app.prism"))) || crate::check::types::has_text(files, under(d, Text::lit("lib.prism")));
}


/// ?TreeRootOf: fn Text, (Text ==> [Text]) -> ?Text
std::optional<Text> tree_root_of(const Text& d, const Map<Text, Array<Text>>& listings) {
    auto files = or_(crate::prelude::get(listings, d), Array<Text>{});
    return is_root_dir(d, files)
        ? std::optional(d)
        : is_module_dir(d, files)
        ? fold(ancestors(d), std::optional<Text>{}, [&](const std::optional<Text>& found_opt, const Text& a) {
        return (found_opt == std::optional<Text>{}) && is_root_dir(a, or_(crate::prelude::get(listings, a), Array<Text>{}))
            ? std::optional(a)
            : found_opt;
    })
        : std::optional<Text>{};
}


/// ToRead: fn [Text], (Text ==> [Text]) -> [Text]
Array<Text> to_read(const Array<Text>& args, const Map<Text, Array<Text>>& listings) {
    return fold(args, Array<Text>{}, [&](const Array<Text>& acc, const Text& a) {
        return is_source_path(a)
            ? crate::check::types::add_text(acc, a)
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = tree_root_of(a, listings);
            if (prism_rtl::is_some(_m)) {
                auto&& root = prism_rtl::some_of(_m);
                _v.set(crate::check::types::union_texts(acc, or_(crate::prelude::get(listings, root), Array<Text>{})));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(acc);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// Assemble: unbounded fn ReadInput -> Assembled
Assembled assemble(const ReadInput& input) {
    auto listings = map(input->listings);
    auto texts = map(input->texts);
    auto progs = run_to_end(fold_job(input->args, no_assembly(), ({
        auto listings_1 = listings;
        auto texts_2 = texts;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Assembled>(std::tuple<Assembled, Text>)>>(prism_rtl::rc([=](std::tuple<Assembled, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto listings_1_3 = listings_1;
            auto texts_2_3 = texts_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto a = p1;
                (prism_rtl::more(prism_rtl::rc(AddArg(acc, listings_1_3, texts_2_3, a))));
            });
        }));
        });
    })));
    })));
    auto pre = add_arg(no_assembly(), listings, texts, input->prelude);
    auto units = filter(each(progs.units, [&](const ModFiles& u) { return kept_segs(u, input->tests); }), [&](const ModFiles& u) { return len(u.segs) > Nat(0u); });
    auto kept = fold(units, Array<Text>{}, [&](const Array<Text>& acc, const ModFiles& u) { return append(acc, each(u.segs, [&](const Seg& s) { return s->path_; })); });
    Assembled this_ = progs;
    this_.units = units;
    this_.prelude = filter(each(pre.units, [&](const ModFiles& u) { return kept_segs(u, false); }), [&](const ModFiles& u) { return len(u.segs) > Nat(0u); });
    this_.scripts = filter(this_.scripts, [&](const Text& p_) { return crate::check::types::has_text(kept, p_); });
    this_.errors = append(this_.errors, pre.errors);
    return this_;
}


prism_rtl::Turn<Assembled> Assemble::cycle() const {
    const auto& input = this->input;
    auto listings = map(input->listings);
    auto texts = map(input->texts);
    auto input_1 = input;
    return call_value(fold_job(input_1->args, no_assembly(), ({
        auto listings_2 = listings;
        auto texts_3 = texts;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Assembled>(std::tuple<Assembled, Text>)>>(prism_rtl::rc([=](std::tuple<Assembled, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto listings_2_4 = listings_2;
            auto texts_3_4 = texts_3;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto a = p1;
                (prism_rtl::more(prism_rtl::rc(AddArg(acc, listings_2_4, texts_3_4, a))));
            });
        }));
        });
    })));
    })), [=](Assembled fold_12090) {
        return ({
            auto progs = fold_12090;
            call_then(start_add_arg(no_assembly(), listings, texts, input_1->prelude), [=](Assembled add_arg_12174) {
            return ({
                auto pre = add_arg_12174;
                auto units = filter(each(progs.units, [&](const ModFiles& u) { return kept_segs(u, input_1->tests); }), [&](const ModFiles& u) { return len(u.segs) > Nat(0u); });
                auto kept = fold(units, Array<Text>{}, [&](const Array<Text>& acc, const ModFiles& u) { return append(acc, each(u.segs, [&](const Seg& s) { return s->path_; })); });
                (prism_rtl::finished(({
                Assembled this_ = progs;
                this_.units = units;
                this_.prelude = filter(each(pre.units, [&](const ModFiles& u) { return kept_segs(u, false); }), [&](const ModFiles& u) { return len(u.segs) > Nat(0u); });
                this_.scripts = filter(this_.scripts, [&](const Text& p_) { return crate::check::types::has_text(kept, p_); });
                this_.errors = append(this_.errors, pre.errors);
                this_;
            })));
            });
        });
        });
    });
}


/// `Start Assemble, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Assembled> start_assemble(ReadInput input) {
    return prism_rtl::make_rc<Assemble>(input);
}


/// KeptSegs: fn ModFiles, Bool -> ModFiles
ModFiles kept_segs(const ModFiles& u, const bool& tests) {
    ModFiles this_ = u;
    this_.segs = filter(this_.segs, [&](const Seg& s) { return (s.role != Text::lit("test")) || tests; });
    return this_;
}


/// AddArg: unbounded fn Assembled, (Text ==> [Text]), (Text ==> Text), Text -> Assembled
Assembled add_arg(const Assembled& acc, const Map<Text, Array<Text>>& listings, const Map<Text, Text>& texts, const Text& a) {
    return crate::syntax::lexer::chars::has_suffix(a, Text::lit(".prismtest"))
        ? ({
        Assembled this_ = acc;
        this_.errors = crate::prelude::push(this_.errors, TreeDiag{.path_ = a, .span = no_span(), .code = Text::lit("prismtest"), .message = prism_rtl::cat("`", a, "`: a `.prismtest` is not read: a module\'s tests are in its test modules, a loose file\'s inline"), .fix = Text::lit("move its declarations into a test module (`test mod tests`), or into the file it tests")});
        this_;
    })
        : crate::syntax::lexer::chars::has_suffix(a, Text::lit(".prism"))
        ? ({
        Assembled this_ = acc;
        this_.units = crate::prelude::push(this_.units, ModFiles{.name = Text::lit(""), .named = false, .segs = Array(std::vector{Seg{.path_ = a, .text = or_(crate::prelude::get(texts, a), Text::lit("")), .role = Text::lit("loose")}}), .parent = Text::lit("")});
        this_;
    })
        : ({
        __label__ _done;
        prism_rtl::Slot<Assembled> _v;
        auto&& _m = tree_root_of(a, listings);
        if (prism_rtl::is_some(_m)) {
            auto&& root = prism_rtl::some_of(_m);
            _v.set(({
                auto tree = walk_tree(root, or_(crate::prelude::get(listings, root), Array<Text>{}), texts);
                auto start = under(a, Text::lit("mod.prism"));
                auto units = root == a ? tree.units : reach_tree(tree.units, start);
                auto scripts = root == a
                    ? fold(units, Array<Text>{}, [&](const Array<Text>& s, const ModFiles& u) { return append(s, test_paths(u)); })
                    : fold(filter(units, [&](const ModFiles& u) { return (main_path(u) == start) || (u->parent == start); }), Array<Text>{}, [&](const Array<Text>& s, const ModFiles& u) { return append(s, test_paths(u)); });
                ({
                Assembled this_ = acc;
                this_.units = append(this_.units, units);
                this_.scripts = append(this_.scripts, scripts);
                this_.errors = append(this_.errors, tree.diags);
                this_;
            });
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(({
                Assembled this_ = acc;
                this_.errors = crate::prelude::push(this_.errors, TreeDiag{.path_ = a, .span = no_span(), .code = Text::lit("no-root"), .message = prism_rtl::cat("`", a, "` holds no app.prism, lib.prism or mod.prism, and a directory argument is a tree"), .fix = Text::lit("give it a root, or name its files")});
                this_;
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Assembled> AddArg::cycle() const {
    const auto& acc = this->acc;
    const auto& listings = this->listings;
    const auto& texts = this->texts;
    const auto& a = this->a;
    return crate::syntax::lexer::chars::has_suffix(a, Text::lit(".prismtest"))
        ? prism_rtl::finished(({
        Assembled this_ = acc;
        this_.errors = crate::prelude::push(this_.errors, TreeDiag{.path_ = a, .span = no_span(), .code = Text::lit("prismtest"), .message = prism_rtl::cat("`", a, "`: a `.prismtest` is not read: a module\'s tests are in its test modules, a loose file\'s inline"), .fix = Text::lit("move its declarations into a test module (`test mod tests`), or into the file it tests")});
        this_;
    }))
        : crate::syntax::lexer::chars::has_suffix(a, Text::lit(".prism"))
        ? prism_rtl::finished(({
        Assembled this_ = acc;
        this_.units = crate::prelude::push(this_.units, ModFiles{.name = Text::lit(""), .named = false, .segs = Array(std::vector{Seg{.path_ = a, .text = or_(crate::prelude::get(texts, a), Text::lit("")), .role = Text::lit("loose")}}), .parent = Text::lit("")});
        this_;
    }))
        : ({
        auto&& _m = tree_root_of(a, listings);
        prism_rtl::is_some(_m) ? ({
        auto&& root = prism_rtl::some_of(_m);
        ({
        auto a_1 = a;
        auto acc_2 = acc;
        auto listings_3 = listings;
        auto texts_4 = texts;
        call_then(start_walk_tree(root, or_(crate::prelude::get(listings_3, root), Array<Text>{}), texts_4), [=](TreeAcc walk_tree_13628) {
        return ({
            auto tree = walk_tree_13628;
            auto start = under(a_1, Text::lit("mod.prism"));
            auto units = root == a_1 ? tree.units : reach_tree(tree.units, start);
            auto scripts = root == a_1
                ? fold(units, Array<Text>{}, [&](const Array<Text>& s, const ModFiles& u) { return append(s, test_paths(u)); })
                : fold(filter(units, [&](const ModFiles& u) { return (main_path(u) == start) || (u->parent == start); }), Array<Text>{}, [&](const Array<Text>& s, const ModFiles& u) { return append(s, test_paths(u)); });
            (prism_rtl::finished(({
            Assembled this_ = acc_2;
            this_.units = append(this_.units, units);
            this_.scripts = append(this_.scripts, scripts);
            this_.errors = append(this_.errors, tree.diags);
            this_;
        })));
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(({
        Assembled this_ = acc;
        this_.errors = crate::prelude::push(this_.errors, TreeDiag{.path_ = a, .span = no_span(), .code = Text::lit("no-root"), .message = prism_rtl::cat("`", a, "` holds no app.prism, lib.prism or mod.prism, and a directory argument is a tree"), .fix = Text::lit("give it a root, or name its files")});
        this_;
    }))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start AddArg, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Assembled> start_add_arg(Assembled acc, Map<Text, Array<Text>> listings, Map<Text, Text> texts, Text a) {
    return prism_rtl::make_rc<AddArg>(acc, listings, texts, a);
}


/// MainPath: fn ModFiles -> Text
Text main_path(const ModFiles& u) {
    auto&& _m = index(u.segs, Nat(0u));
    if (prism_rtl::is_some(_m)) {
        auto&& s = prism_rtl::some_of(_m);
        return s->path_;
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// MainText: fn ModFiles -> Text
Text main_text(const ModFiles& u) {
    auto&& _m = index(u.segs, Nat(0u));
    if (prism_rtl::is_some(_m)) {
        auto&& s = prism_rtl::some_of(_m);
        return s->text;
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// TestPaths: fn ModFiles -> [Text]
Array<Text> test_paths(const ModFiles& u) {
    return each(filter(u.segs, [&](const Seg& s) { return s.role == Text::lit("test"); }), [&](const Seg& s) { return s->path_; });
}


/// WalkTree: unbounded fn Text, [Text], (Text ==> Text) -> TreeAcc
TreeAcc walk_tree(const Text& root, const Array<Text>& files, const Map<Text, Text>& texts) {
    auto has = fold(files, Map<Text, bool>{}, [&](const Map<Text, bool>& m, const Text& f) { return insert(m, f, true); });
    auto app_1 = under(root, Text::lit("app.prism"));
    auto lib_2 = under(root, Text::lit("lib.prism"));
    auto acc0 = TreeAcc{.units = Array<ModFiles>{}, .declared = Map<Text, bool>{}, .diags = Array<TreeDiag>{}};
    auto acc1 = crate::check::env::has_key(has, app_1) && crate::check::env::has_key(has, lib_2)
        ? add_tree_diag(acc0, lib_2, no_span(), Text::lit("two-roots"), Text::lit("`app.prism` and `lib.prism` in one directory: a tree has one root"), Text::lit("keep app.prism for a program or lib.prism for a library"))
        : acc0;
    auto acc2 = crate::check::env::has_key(has, app_1)
        ? walk_module(has, texts, acc1, app_1, Text::lit(""), Text::lit(""), false)
        : walk_lib(has, texts, acc1, lib_2);
    auto acc3 = ({
        TreeAcc this_ = acc2;
        this_.declared = insert(this_.declared, lib_2, true);
        this_;
    });
    return fold(files, acc3, [&](const TreeAcc& a, const Text& f) { return crate::check::env::has_key(a.declared, f) ? a : stray(has, texts, a, f); });
}


prism_rtl::Turn<TreeAcc> WalkTree::cycle() const {
    const auto& root = this->root;
    const auto& files = this->files;
    const auto& texts = this->texts;
    auto has = fold(files, Map<Text, bool>{}, [&](const Map<Text, bool>& m, const Text& f) { return insert(m, f, true); });
    auto app_1 = under(root, Text::lit("app.prism"));
    auto lib_2 = under(root, Text::lit("lib.prism"));
    auto acc0 = TreeAcc{.units = Array<ModFiles>{}, .declared = Map<Text, bool>{}, .diags = Array<TreeDiag>{}};
    auto acc1 = crate::check::env::has_key(has, app_1) && crate::check::env::has_key(has, lib_2)
        ? add_tree_diag(acc0, lib_2, no_span(), Text::lit("two-roots"), Text::lit("`app.prism` and `lib.prism` in one directory: a tree has one root"), Text::lit("keep app.prism for a program or lib.prism for a library"))
        : acc0;
    auto acc2 = crate::check::env::has_key(has, app_1)
        ? walk_module(has, texts, acc1, app_1, Text::lit(""), Text::lit(""), false)
        : walk_lib(has, texts, acc1, lib_2);
    auto acc3 = ({
        TreeAcc this_ = acc2;
        this_.declared = insert(this_.declared, lib_2, true);
        this_;
    });
    return prism_rtl::finished(fold(files, acc3, [&](const TreeAcc& a, const Text& f) { return crate::check::env::has_key(a.declared, f) ? a : stray(has, texts, a, f); }));
}


/// `Start WalkTree, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<TreeAcc> start_walk_tree(Text root, Array<Text> files, Map<Text, Text> texts) {
    return prism_rtl::make_rc<WalkTree>(root, files, texts);
}


/// WalkLib: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text -> TreeAcc
TreeAcc walk_lib(const Map<Text, bool>& has, const Map<Text, Text>& texts, const TreeAcc& acc, const Text& lib) {
    auto text_ = or_(crate::prelude::get(texts, lib), Text::lit(""));
    auto heads = header_lines(text_);
    auto bad = filter(heads, [&](const HeadLine& h) { return !((h.word == Text::lit("mod")) && crate::check::env::is_upper_text(h.arg)); });
    auto acc1 = fold(bad, acc, [&](const TreeAcc& a, const HeadLine& h) { return add_tree_diag(a, lib, h.span, Text::lit("lib-header"), prism_rtl::cat("lib.prism holds only `mod Name` lines, the library\'s modules: `", h.word, "` belongs in a module"), Text::lit("move the line to a module\'s mod.prism")); });
    auto acc2 = ({
        __label__ _done;
        prism_rtl::Slot<TreeAcc> _v;
        auto&& _m = first_decl_line(text_);
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(add_tree_diag(acc1, lib, r, Text::lit("lib-header"), Text::lit("lib.prism holds only `mod Name` lines, the library\'s modules"), Text::lit("move the declaration to a module")));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(acc1);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto dir = dir_of(lib);
    return run_to_end(fold_job(filter(heads, [&](const HeadLine& h) { return (h.word == Text::lit("mod")) && crate::check::env::is_upper_text(h.arg); }), acc2, ({
        auto has_1 = has;
        auto texts_2 = texts;
        auto lib_3 = lib;
        auto dir_4 = dir;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<TreeAcc>(std::tuple<TreeAcc, HeadLine>)>>(prism_rtl::rc([=](std::tuple<TreeAcc, HeadLine> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto has_1_5 = has_1;
            auto texts_2_5 = texts_2;
            auto lib_3_5 = lib_3;
            auto dir_4_5 = dir_4;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                auto h = p1;
                (prism_rtl::more(prism_rtl::rc(Child(has_1_5, texts_2_5, a, lib_3_5, dir_4_5, h, Text::lit(""), false))));
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<TreeAcc> WalkLib::cycle() const {
    const auto& has = this->has;
    const auto& texts = this->texts;
    const auto& acc = this->acc;
    const auto& lib = this->lib;
    auto text_ = or_(crate::prelude::get(texts, lib), Text::lit(""));
    auto heads = header_lines(text_);
    auto bad = filter(heads, [&](const HeadLine& h) { return !((h.word == Text::lit("mod")) && crate::check::env::is_upper_text(h.arg)); });
    auto acc1 = fold(bad, acc, [&](const TreeAcc& a, const HeadLine& h) { return add_tree_diag(a, lib, h.span, Text::lit("lib-header"), prism_rtl::cat("lib.prism holds only `mod Name` lines, the library\'s modules: `", h.word, "` belongs in a module"), Text::lit("move the line to a module\'s mod.prism")); });
    auto acc2 = ({
        __label__ _done;
        prism_rtl::Slot<TreeAcc> _v;
        auto&& _m = first_decl_line(text_);
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(add_tree_diag(acc1, lib, r, Text::lit("lib-header"), Text::lit("lib.prism holds only `mod Name` lines, the library\'s modules"), Text::lit("move the declaration to a module")));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(acc1);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto dir = dir_of(lib);
    return fold_job(filter(heads, [&](const HeadLine& h) { return (h.word == Text::lit("mod")) && crate::check::env::is_upper_text(h.arg); }), acc2, ({
        auto has_1 = has;
        auto texts_2 = texts;
        auto lib_3 = lib;
        auto dir_4 = dir;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<TreeAcc>(std::tuple<TreeAcc, HeadLine>)>>(prism_rtl::rc([=](std::tuple<TreeAcc, HeadLine> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto has_1_5 = has_1;
            auto texts_2_5 = texts_2;
            auto lib_3_5 = lib_3;
            auto dir_4_5 = dir_4;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                auto h = p1;
                (prism_rtl::more(prism_rtl::rc(Child(has_1_5, texts_2_5, a, lib_3_5, dir_4_5, h, Text::lit(""), false))));
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start WalkLib, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<TreeAcc> start_walk_lib(Map<Text, bool> has, Map<Text, Text> texts, TreeAcc acc, Text lib) {
    return prism_rtl::make_rc<WalkLib>(has, texts, acc, lib);
}


/// WalkModule: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text, Text, Text, Bool -> TreeAcc
TreeAcc walk_module(const Map<Text, bool>& has, const Map<Text, Text>& texts, const TreeAcc& acc, const Text& main, const Text& name, const Text& parent, const bool& in_test) {
    auto dir = dir_of(main);
    auto text_ = or_(crate::prelude::get(texts, main), Text::lit(""));
    auto heads = header_lines(text_);
    auto mods = filter(heads, [&](const HeadLine& h) { return (h.word == Text::lit("mod")) || (h.word == Text::lit("test mod")); });
    auto subs = filter(mods, [&](const HeadLine& h) { return crate::check::env::is_upper_text(h.arg); });
    auto lower_ = filter(mods, [&](const HeadLine& h) { return !crate::check::env::is_upper_text(h.arg); });
    auto named = name == Text::lit("")
        ? Text::lit("its path makes it the root")
        : prism_rtl::cat("its path names the module `", name, "`");
    auto acc1 = fold(filter(heads, [&](const HeadLine& h) { return h.word == Text::lit("module"); }), acc, [&](const TreeAcc& a, const HeadLine& h) { return add_tree_diag(a, main, h.span, Text::lit("module-line"), prism_rtl::cat("a module\'s file has no `module` line: ", named), Text::lit("delete the line")); });
    auto leaf = !crate::check::types::has_text(Array(std::vector{Text::lit("mod.prism"), Text::lit("app.prism"), Text::lit("lib.prism")}), base_of(main));
    auto stem = or_(crate::syntax::lexer::chars::before_suffix(base_of(main), Text::lit(".prism")), main);
    auto acc2 = leaf
        ? fold(mods, acc1, [&](const TreeAcc& a, const HeadLine& h) { return add_tree_diag(a, main, h.span, Text::lit("mod-leaf"), prism_rtl::cat("`", base_of(main), "` declares `", h.word, " ", h.arg, "`, and a module with children is a directory"), prism_rtl::cat("move ", base_of(main), " to ", stem, "/mod.prism")); })
        : acc1;
    auto acc3 = fold(lower_, acc2, [&](const TreeAcc& a, const HeadLine& h) { return lowercase(a, main, dir, h); });
    auto acc4 = ({
        TreeAcc this_ = acc3;
        this_.declared = insert(this_.declared, main, true);
        this_.units = crate::prelude::push(this_.units, ModFiles{.name = name, .named = true, .segs = Array(std::vector{Seg{.path_ = main, .text = text_, .role = in_test ? Text::lit("test") : Text::lit("main")}}), .parent = parent});
        this_;
    });
    return leaf
        ? acc4
        : run_to_end(fold_job(subs, acc4, ({
        auto has_1 = has;
        auto texts_2 = texts;
        auto main_3 = main;
        auto dir_4 = dir;
        auto name_5 = name;
        auto in_test_6 = in_test;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<TreeAcc>(std::tuple<TreeAcc, HeadLine>)>>(prism_rtl::rc([=](std::tuple<TreeAcc, HeadLine> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto has_1_7 = has_1;
            auto texts_2_7 = texts_2;
            auto main_3_7 = main_3;
            auto dir_4_7 = dir_4;
            auto name_5_7 = name_5;
            auto in_test_6_7 = in_test_6;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                auto h = p1;
                (prism_rtl::more(prism_rtl::rc(Child(has_1_7, texts_2_7, a, main_3_7, dir_4_7, h, name_5_7, in_test_6_7))));
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<TreeAcc> WalkModule::cycle() const {
    const auto& has = this->has;
    const auto& texts = this->texts;
    const auto& acc = this->acc;
    const auto& main = this->main;
    const auto& name = this->name;
    const auto& parent = this->parent;
    const auto& in_test = this->in_test;
    auto dir = dir_of(main);
    auto text_ = or_(crate::prelude::get(texts, main), Text::lit(""));
    auto heads = header_lines(text_);
    auto mods = filter(heads, [&](const HeadLine& h) { return (h.word == Text::lit("mod")) || (h.word == Text::lit("test mod")); });
    auto subs = filter(mods, [&](const HeadLine& h) { return crate::check::env::is_upper_text(h.arg); });
    auto lower_ = filter(mods, [&](const HeadLine& h) { return !crate::check::env::is_upper_text(h.arg); });
    auto named = name == Text::lit("")
        ? Text::lit("its path makes it the root")
        : prism_rtl::cat("its path names the module `", name, "`");
    auto acc1 = fold(filter(heads, [&](const HeadLine& h) { return h.word == Text::lit("module"); }), acc, [&](const TreeAcc& a, const HeadLine& h) { return add_tree_diag(a, main, h.span, Text::lit("module-line"), prism_rtl::cat("a module\'s file has no `module` line: ", named), Text::lit("delete the line")); });
    auto leaf = !crate::check::types::has_text(Array(std::vector{Text::lit("mod.prism"), Text::lit("app.prism"), Text::lit("lib.prism")}), base_of(main));
    auto stem = or_(crate::syntax::lexer::chars::before_suffix(base_of(main), Text::lit(".prism")), main);
    auto acc2 = leaf
        ? fold(mods, acc1, [&](const TreeAcc& a, const HeadLine& h) { return add_tree_diag(a, main, h.span, Text::lit("mod-leaf"), prism_rtl::cat("`", base_of(main), "` declares `", h.word, " ", h.arg, "`, and a module with children is a directory"), prism_rtl::cat("move ", base_of(main), " to ", stem, "/mod.prism")); })
        : acc1;
    auto acc3 = fold(lower_, acc2, [&](const TreeAcc& a, const HeadLine& h) { return lowercase(a, main, dir, h); });
    auto acc4 = ({
        TreeAcc this_ = acc3;
        this_.declared = insert(this_.declared, main, true);
        this_.units = crate::prelude::push(this_.units, ModFiles{.name = name, .named = true, .segs = Array(std::vector{Seg{.path_ = main, .text = text_, .role = in_test ? Text::lit("test") : Text::lit("main")}}), .parent = parent});
        this_;
    });
    return leaf
        ? prism_rtl::finished(acc4)
        : fold_job(subs, acc4, ({
        auto has_1 = has;
        auto texts_2 = texts;
        auto main_3 = main;
        auto dir_4 = dir;
        auto name_5 = name;
        auto in_test_6 = in_test;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<TreeAcc>(std::tuple<TreeAcc, HeadLine>)>>(prism_rtl::rc([=](std::tuple<TreeAcc, HeadLine> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto has_1_7 = has_1;
            auto texts_2_7 = texts_2;
            auto main_3_7 = main_3;
            auto dir_4_7 = dir_4;
            auto name_5_7 = name_5;
            auto in_test_6_7 = in_test_6;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                auto h = p1;
                (prism_rtl::more(prism_rtl::rc(Child(has_1_7, texts_2_7, a, main_3_7, dir_4_7, h, name_5_7, in_test_6_7))));
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start WalkModule, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<TreeAcc> start_walk_module(Map<Text, bool> has, Map<Text, Text> texts, TreeAcc acc, Text main, Text name, Text parent, bool in_test) {
    return prism_rtl::make_rc<WalkModule>(has, texts, acc, main, name, parent, in_test);
}


/// Lowercase: fn TreeAcc, Text, Text, HeadLine -> TreeAcc
TreeAcc lowercase(const TreeAcc& a, const Text& main, const Text& dir, const HeadLine& h) {
    auto up = prism_rtl::cat(upper(crate::syntax::lexer::chars::head(h.arg)), crate::syntax::lexer::chars::after_first(h.arg));
    auto marked = ({
        TreeAcc this_ = a;
        this_.declared = insert(this_.declared, under(dir, prism_rtl::cat(h.arg, ".prism")), true);
        this_;
    });
    return add_tree_diag(marked, main, h.span, Text::lit("mod-lowercase"), prism_rtl::cat("`", h.word, " ", h.arg, "`: a module\'s name is capitalised, and every `mod` line declares a module with a namespace of its own"), prism_rtl::cat("write `", h.word, " ", up, "` (its file ", h.arg, ".prism, with a header of its own)"));
}


/// Child: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text, Text, HeadLine, Text, Bool -> TreeAcc
TreeAcc child(const Map<Text, bool>& has, const Map<Text, Text>& texts, const TreeAcc& acc, const Text& main, const Text& dir, const HeadLine& h, const Text& parent, const bool& in_test) {
    auto snake = dir_name(h.arg);
    auto file = under(dir, prism_rtl::cat(snake, ".prism"));
    auto nested = under(dir, prism_rtl::cat(snake, "/mod.prism"));
    auto name = parent == Text::lit("") ? h.arg : prism_rtl::cat(parent, ".", h.arg);
    auto is_test = in_test || (h.word == Text::lit("test mod"));
    auto line = prism_rtl::cat(h.word, " ", h.arg);
    return (file == main) || (nested == main)
        ? add_tree_diag(acc, main, h.span, Text::lit("mod-self"), prism_rtl::cat("`", line, "` names `", base_of(main), "`, the file that declares it"), Text::lit("rename the module"))
        : crate::check::env::has_key(has, file) && crate::check::env::has_key(has, nested)
        ? ({
        auto both_ = ({
            TreeAcc this_ = acc;
            this_.declared = insert(insert(this_.declared, file, true), nested, true);
            this_;
        });
        add_tree_diag(both_, main, h.span, Text::lit("mod-both"), prism_rtl::cat("`", line, "` declares `", snake, ".prism` or `", snake, "/mod.prism`, and both are there"), prism_rtl::cat("keep one: ", snake, "/mod.prism when the module has children, else ", snake, ".prism"));
    })
        : crate::check::env::has_key(has, file)
        ? walk_module(has, texts, acc, file, name, main, is_test)
        : crate::check::env::has_key(has, nested)
        ? walk_module(has, texts, acc, nested, name, main, is_test)
        : add_tree_diag(acc, main, h.span, Text::lit("mod-missing"), prism_rtl::cat("`", line, "` declares `", snake, ".prism` or `", snake, "/mod.prism`, and neither is there"), prism_rtl::cat("create ", snake, ".prism, or delete the line"));
}


prism_rtl::Turn<TreeAcc> Child::cycle() const {
    const auto& has = this->has;
    const auto& texts = this->texts;
    const auto& acc = this->acc;
    const auto& main = this->main;
    const auto& dir = this->dir;
    const auto& h = this->h;
    const auto& parent = this->parent;
    const auto& in_test = this->in_test;
    auto snake = dir_name(h.arg);
    auto file = under(dir, prism_rtl::cat(snake, ".prism"));
    auto nested = under(dir, prism_rtl::cat(snake, "/mod.prism"));
    auto name = parent == Text::lit("") ? h.arg : prism_rtl::cat(parent, ".", h.arg);
    auto is_test = in_test || (h.word == Text::lit("test mod"));
    auto line = prism_rtl::cat(h.word, " ", h.arg);
    return (file == main) || (nested == main)
        ? prism_rtl::finished(add_tree_diag(acc, main, h.span, Text::lit("mod-self"), prism_rtl::cat("`", line, "` names `", base_of(main), "`, the file that declares it"), Text::lit("rename the module")))
        : crate::check::env::has_key(has, file) && crate::check::env::has_key(has, nested)
        ? ({
        auto both_ = ({
            TreeAcc this_ = acc;
            this_.declared = insert(insert(this_.declared, file, true), nested, true);
            this_;
        });
        (prism_rtl::finished(add_tree_diag(both_, main, h.span, Text::lit("mod-both"), prism_rtl::cat("`", line, "` declares `", snake, ".prism` or `", snake, "/mod.prism`, and both are there"), prism_rtl::cat("keep one: ", snake, "/mod.prism when the module has children, else ", snake, ".prism"))));
    })
        : crate::check::env::has_key(has, file)
        ? prism_rtl::more(prism_rtl::rc(WalkModule(has, texts, acc, file, name, main, is_test)))
        : crate::check::env::has_key(has, nested)
        ? prism_rtl::more(prism_rtl::rc(WalkModule(has, texts, acc, nested, name, main, is_test)))
        : prism_rtl::finished(add_tree_diag(acc, main, h.span, Text::lit("mod-missing"), prism_rtl::cat("`", line, "` declares `", snake, ".prism` or `", snake, "/mod.prism`, and neither is there"), prism_rtl::cat("create ", snake, ".prism, or delete the line")));
}


/// `Start Child, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<TreeAcc> start_child(Map<Text, bool> has, Map<Text, Text> texts, TreeAcc acc, Text main, Text dir, HeadLine h, Text parent, bool in_test) {
    return prism_rtl::make_rc<Child>(has, texts, acc, main, dir, h, parent, in_test);
}


/// Stray: fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text -> TreeAcc
TreeAcc stray(const Map<Text, bool>& has, const Map<Text, Text>& texts, const TreeAcc& acc, const Text& f) {
    auto text_ = or_(crate::prelude::get(texts, f), Text::lit(""));
    return crate::syntax::lexer::chars::has_suffix(f, Text::lit(".prismtest"))
        ? add_tree_diag(acc, f, no_span(), Text::lit("mod-stray"), prism_rtl::cat("`", base_of(f), "` is a test script in a tree, where tests are in test modules"), Text::lit("put its declarations in a test module, declared by `test mod Tests`"))
        : ({
        auto dir = dir_of(f);
        auto is_main = base_of(f) == Text::lit("mod.prism");
        auto home = is_main ? dir_of(dir) : dir;
        auto main = fold(Array(std::vector{Text::lit("mod.prism"), Text::lit("app.prism"), Text::lit("lib.prism")}), Text::lit(""), [&](const Text& m, const Text& n) {
            return (m == Text::lit("")) && crate::check::env::has_key(has, under(home, n))
                ? n
                : m;
        });
        auto line = is_main
            ? prism_rtl::cat("mod ", mod_of_dir(base_of(dir)))
            : prism_rtl::cat("mod ", mod_of_dir(or_(crate::syntax::lexer::chars::before_suffix(base_of(f), Text::lit(".prism")), f)));
        auto shown = is_main ? prism_rtl::cat(base_of(dir), "/mod.prism") : base_of(f);
        main == Text::lit("")
        ? add_tree_diag(acc, f, no_span(), Text::lit("mod-stray"), prism_rtl::cat("`", f, "` is in a tree, in no module\'s directory"), Text::lit("move it into a module\'s directory and declare it with a `mod` line"))
        : add_tree_diag(acc, f, no_span(), Text::lit("mod-stray"), prism_rtl::cat("`", shown, "` is in the directory of `", main, "`, which declares no `", line, "`"), prism_rtl::cat("declare it with `", line, "` in ", main, ", or move it out of the directory"));
    });
}


/// ReachTree: unbounded fn [ModFiles], Text -> [ModFiles]
Array<ModFiles> reach_tree(const Array<ModFiles>& units, const Text& main) {
    auto by_name = fold(units, Map<Text, ModFiles>{}, [&](const Map<Text, ModFiles>& m, const ModFiles& u) { return insert(m, unit_name(u), u); });
    auto start = fold(units, Array<Text>{}, [&](const Array<Text>& s, const ModFiles& u) {
        return (main_path(u) == main) || ((u->parent == main) && is_test_unit(u))
            ? crate::prelude::push(s, unit_name(u))
            : s;
    });
    auto reached = reach_names(by_name, start, start);
    return filter(units, [&](const ModFiles& u) { return crate::check::types::has_text(reached, unit_name(u)); });
}


prism_rtl::Turn<Array<ModFiles>> ReachTree::cycle() const {
    const auto& units = this->units;
    const auto& main = this->main;
    auto by_name = fold(units, Map<Text, ModFiles>{}, [&](const Map<Text, ModFiles>& m, const ModFiles& u) { return insert(m, unit_name(u), u); });
    auto start = fold(units, Array<Text>{}, [&](const Array<Text>& s, const ModFiles& u) {
        return (main_path(u) == main) || ((u->parent == main) && is_test_unit(u))
            ? crate::prelude::push(s, unit_name(u))
            : s;
    });
    auto units_1 = units;
    return call_then(start_reach_names(by_name, start, start), [=](Array<Text> reach_names_22442) {
        return ({
            auto reached = reach_names_22442;
            (prism_rtl::finished(filter(units_1, [&](const ModFiles& u) { return crate::check::types::has_text(reached, unit_name(u)); })));
        });
    });
}


/// `Start ReachTree, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<ModFiles>> start_reach_tree(Array<ModFiles> units, Text main) {
    return prism_rtl::make_rc<ReachTree>(units, main);
}


/// ReachNames: unbounded fn (Text ==> ModFiles), [Text], [Text] -> [Text]
Array<Text> reach_names(const Map<Text, ModFiles>& by_name, const Array<Text>& seen, const Array<Text>& todo) {
    auto&& _m = index(todo, Nat(0u));
    if (prism_rtl::is_none(_m)) {
        return seen;
    }
    if (prism_rtl::is_some(_m)) {
        auto&& n = prism_rtl::some_of(_m);
        auto uses = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = crate::prelude::get(by_name, n);
            if (prism_rtl::is_some(_m)) {
                auto&& u = prism_rtl::some_of(_m);
                _v.set(each(filter(header_lines(main_text(u)), [&](const HeadLine& h) { return h.word == Text::lit("use"); }), [&](const HeadLine& h) { return use_target(by_name, h.arg); }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto fresh = filter(uses, [&](const Text& x) { return (!crate::check::types::has_text(seen, x)) && crate::check::env::has_key(by_name, x); });
        return reach_names(by_name, crate::check::types::union_texts(seen, fresh), append(drop(todo, Nat(1u)), fresh));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> ReachNames::cycle() const {
    const auto& by_name = this->by_name;
    const auto& seen = this->seen;
    const auto& todo = this->todo;
    return ({
        auto&& _m = index(todo, Nat(0u));
        prism_rtl::is_none(_m) ? prism_rtl::finished(seen)
        : prism_rtl::is_some(_m) ? ({
        auto&& n = prism_rtl::some_of(_m);
        ({
        auto uses = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = crate::prelude::get(by_name, n);
            if (prism_rtl::is_some(_m)) {
                auto&& u = prism_rtl::some_of(_m);
                _v.set(each(filter(header_lines(main_text(u)), [&](const HeadLine& h) { return h.word == Text::lit("use"); }), [&](const HeadLine& h) { return use_target(by_name, h.arg); }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto fresh = filter(uses, [&](const Text& x) { return (!crate::check::types::has_text(seen, x)) && crate::check::env::has_key(by_name, x); });
        (prism_rtl::more(prism_rtl::rc(ReachNames(by_name, crate::check::types::union_texts(seen, fresh), append(drop(todo, Nat(1u)), fresh)))));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ReachNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_reach_names(Map<Text, ModFiles> by_name, Array<Text> seen, Array<Text> todo) {
    return prism_rtl::make_rc<ReachNames>(by_name, seen, todo);
}


/// UseTarget: fn (Text ==> ModFiles), Text -> Text
Text use_target(const Map<Text, ModFiles>& by_name, const Text& u) {
    return (u == Text::lit("App")) && (!crate::check::env::has_key(by_name, Text::lit("App")))
        ? Text::lit("")
        : u;
}


/// IsTestUnit: fn ModFiles -> Bool
bool is_test_unit(const ModFiles& u) {
    auto&& _m = index(u.segs, Nat(0u));
    if (prism_rtl::is_some(_m)) {
        auto&& s = prism_rtl::some_of(_m);
        return s.role == Text::lit("test");
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// UnitName: fn ModFiles -> Text
Text unit_name(const ModFiles& u) {
    return u.named
        ? u.name
        : fold(header_lines(main_text(u)), Text::lit(""), [&](const Text& n, const HeadLine& h) { return h.word == Text::lit("module") ? h.arg : n; });
}


/// RenderTreeDiag: fn (Text ==> Text), TreeDiag -> Text
Text render_tree_diag(const Map<Text, Text>& texts, const TreeDiag& d) {
    return crate::check::errors::render_cdiag(Array(std::vector{crate::check::errors::mk_src(d->path_, or_(crate::prelude::get(texts, d->path_), Text::lit("")))}), crate::check::errors::CDiag{.code = d.code, .file = Nat(0u), .span = d.span, .message = d.message, .fix = d.fix});
}


/// TreeReport: fn ReadInput, [TreeDiag] -> Text
Text tree_report(const ReadInput& input, const Array<TreeDiag>& ds) {
    auto texts = map(input->texts);
    auto n = len(ds);
    return prism_rtl::cat(concat(each(ds, [&](const TreeDiag& d) { return render_tree_diag(texts, d); })), n, " error", n == Nat(1u) ? Text::lit("") : Text::lit("s"));
}


/// ParseUnit: unbounded fn ModFiles -> ((Src, Parsed))
std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed> parse_unit(const ModFiles& u) {
    auto src = crate::check::errors::mk_joined_src(each(u.segs, [&](const Seg& s) { return std::tuple{s->path_, s->text, s.role}; }));
    auto parsed = crate::syntax::parser::parse_file(src->text);
    auto t0 = parsed.tree;
    auto tree = !u.named
        ? t0
        : ({
        crate::syntax::Module this_ = t0;
        this_.name = u.name == Text::lit("")
            ? std::optional<crate::syntax::QualName>{}
            : std::optional(crate::syntax::QualName{.path_ = split(u.name, Text::lit(".")), .span = no_span()});
        this_;
    });
    return std::tuple{src, crate::syntax::parser::Parsed{.tree = tree, .diags = parsed.diags}};
}


prism_rtl::Turn<std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>> ParseUnit::cycle() const {
    const auto& u = this->u;
    auto src = crate::check::errors::mk_joined_src(each(u.segs, [&](const Seg& s) { return std::tuple{s->path_, s->text, s.role}; }));
    auto u_1 = u;
    return call_then(crate::syntax::parser::start_parse_file(src->text), [=](crate::syntax::parser::Parsed parse_file_24455) {
        return ({
            auto parsed = parse_file_24455;
            auto t0 = parsed.tree;
            auto tree = !u_1.named
                ? t0
                : ({
                crate::syntax::Module this_ = t0;
                this_.name = u_1.name == Text::lit("")
                    ? std::optional<crate::syntax::QualName>{}
                    : std::optional(crate::syntax::QualName{.path_ = split(u_1.name, Text::lit(".")), .span = no_span()});
                this_;
            });
            (prism_rtl::finished(std::tuple{src, crate::syntax::parser::Parsed{.tree = tree, .diags = parsed.diags}}));
        });
    });
}


/// `Start ParseUnit, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>> start_parse_unit(ModFiles u) {
    return prism_rtl::make_rc<ParseUnit>(u);
}


/// ParseProgram: unbounded fn Assembled -> ParsedProgram
ParsedProgram parse_program(const Assembled& read) {
    auto parsed = run_to_end(each_job(read.units, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>>(ModFiles)>>(prism_rtl::rc([=](ModFiles p0) {
        return entered(once_job([=]() {
            return ({
                auto u = p0;
                (prism_rtl::more(prism_rtl::rc(ParseUnit(u))));
            });
        }));
    }))));
    auto user_mods = fold(parsed, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p1) {
        auto&& p_ = std::get<1>(_p1);
        return crate::prelude::push(acc, crate::check::env::mod_name(p_.tree));
    });
    auto user_fams = fold(parsed, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p1) {
        auto&& p_ = std::get<1>(_p1);
        return append(acc, tag_families(p_.tree));
    });
    auto pre_parsed = run_to_end(each_job(read->prelude, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>>(ModFiles)>>(prism_rtl::rc([=](ModFiles p0) {
        return entered(once_job([=]() {
            return ({
                auto u = p0;
                (prism_rtl::more(prism_rtl::rc(ParseUnit(u))));
            });
        }));
    }))));
    auto kept = filter(pre_parsed, [&](const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p0) {
        auto&& p_ = std::get<1>(_p0);
        return (!crate::check::types::has_text(user_mods, crate::check::env::mod_name(p_.tree))) && (!any_in(tag_families(p_.tree), user_fams));
    });
    auto all = append(parsed, kept);
    auto errors_1 = fold(all, Text::lit(""), [&](const Text& acc, const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p1) {
        auto&& src = std::get<0>(_p1);
        auto&& p_ = std::get<1>(_p1);
        return crate::program::any_errors(p_.diags)
            ? prism_rtl::cat(acc, render_parse(src, p_.diags))
            : acc;
    });
    return ParsedProgram{.srcs = each(all, [&](const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p0) {
        auto&& s = std::get<0>(_p0);
        return s;
    }), .trees = each(all, [&](const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p0) {
        auto&& p_ = std::get<1>(_p0);
        return p_.tree;
    }), .shown = len(parsed), .parents = each(read.units, [&](const ModFiles& u) { return u->parent; }), .errors = errors_1};
}


prism_rtl::Turn<ParsedProgram> ParseProgram::cycle() const {
    const auto& read = this->read;
    auto read_1 = read;
    return call_value(each_job(read_1.units, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>>(ModFiles)>>(prism_rtl::rc([=](ModFiles p0) {
        return entered(once_job([=]() {
            return ({
                auto u = p0;
                (prism_rtl::more(prism_rtl::rc(ParseUnit(u))));
            });
        }));
    }))), [=](Array<std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>> each_25137) {
        return ({
            auto parsed = each_25137;
            auto user_mods = fold(parsed, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p1) {
                auto&& p_ = std::get<1>(_p1);
                return crate::prelude::push(acc, crate::check::env::mod_name(p_.tree));
            });
            auto user_fams = fold(parsed, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p1) {
                auto&& p_ = std::get<1>(_p1);
                return append(acc, tag_families(p_.tree));
            });
            call_value(each_job(read_1->prelude, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>>(ModFiles)>>(prism_rtl::rc([=](ModFiles p0) {
            return entered(once_job([=]() {
                return ({
                    auto u = p0;
                    (prism_rtl::more(prism_rtl::rc(ParseUnit(u))));
                });
            }));
        }))), [=](Array<std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>> each_25371) {
            return ({
                auto pre_parsed = each_25371;
                auto kept = filter(pre_parsed, [&](const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p0) {
                    auto&& p_ = std::get<1>(_p0);
                    return (!crate::check::types::has_text(user_mods, crate::check::env::mod_name(p_.tree))) && (!any_in(tag_families(p_.tree), user_fams));
                });
                auto all = append(parsed, kept);
                auto errors_2 = fold(all, Text::lit(""), [&](const Text& acc, const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p1) {
                    auto&& src = std::get<0>(_p1);
                    auto&& p_ = std::get<1>(_p1);
                    return crate::program::any_errors(p_.diags)
                        ? prism_rtl::cat(acc, render_parse(src, p_.diags))
                        : acc;
                });
                (prism_rtl::finished(ParsedProgram{.srcs = each(all, [&](const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p0) {
                auto&& s = std::get<0>(_p0);
                return s;
            }), .trees = each(all, [&](const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p0) {
                auto&& p_ = std::get<1>(_p0);
                return p_.tree;
            }), .shown = len(parsed), .parents = each(read_1.units, [&](const ModFiles& u) { return u->parent; }), .errors = errors_2}));
            });
        });
        });
    });
}


/// `Start ParseProgram, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<ParsedProgram> start_parse_program(Assembled read) {
    return prism_rtl::make_rc<ParseProgram>(read);
}


/// TreeDeclDiags: fn ParsedProgram -> [CDiag]
Array<crate::check::errors::CDiag> tree_decl_diags(const ParsedProgram& pp) {
    return fold(crate::check::errors::range0(pp.shown), Array<crate::check::errors::CDiag>{}, [&](const Array<crate::check::errors::CDiag>& acc, const Nat& i) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::errors::CDiag>> _v;
            auto&& _m = index(pp.srcs, i);
            if (prism_rtl::is_some(_m)) {
                auto&& src = prism_rtl::some_of(_m);
                _v.set(fold(or_(index(pp.trees, i), crate::check::env::empty_module()).decls, acc, [&](const Array<crate::check::errors::CDiag>& a, const crate::syntax::decls::Decl& d) { return append(a, decl_role_diags(src, or_(index(pp.parents, i), Text::lit("")), i, d)); }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(acc);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// DeclRoleDiags: fn Src, Text, Nat, Decl -> [CDiag]
Array<crate::check::errors::CDiag> decl_role_diags(const crate::check::errors::Src& src, const Text& parent, const Nat& i, const crate::syntax::decls::Decl& d) {
    auto seg = crate::check::errors::seg_at(src, d.span.start);
    auto role = seg.role;
    auto main = base_of(src->path_);
    auto tested = (seg->path_ == src->path_) && (parent != Text::lit(""))
        ? base_of(parent)
        : main;
    auto what = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = d.kind;
        if (prism_rtl::is<crate::syntax::decls::DeclKind::DTest>(_m)) {
            _v.set(Text::lit("test"));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::decls::DeclKind::DCheck>(_m)) {
            _v.set(Text::lit("check"));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::decls::DeclKind::DTag>(_m)) {
            _v.set(Text::lit("tag"));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::decls::DeclKind::DTrait>(_m)) {
            _v.set(Text::lit("trait"));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::decls::DeclKind::DImpl>(_m)) {
            _v.set(Text::lit("impl"));
            goto _done;
        }
        {
            _v.set(Text::lit(""));
            goto _done;
        }
    _done:
        _v.take();
    });
    return (role == Text::lit("main")) && ((what == Text::lit("test")) || (what == Text::lit("check")))
        ? Array(std::vector{crate::check::errors::CDiag{.code = Text::lit("test-outside"), .file = i, .span = d.span, .message = prism_rtl::cat("a `", what, "` in a tree stands only in a test module"), .fix = prism_rtl::cat("move it to a test module: `test mod Tests` in ", main, ", and tests.prism")}})
        : (role == Text::lit("test")) && (((what == Text::lit("tag")) || (what == Text::lit("trait"))) || (what == Text::lit("impl")))
        ? Array(std::vector{crate::check::errors::CDiag{.code = Text::lit("test-declares"), .file = i, .span = d.span, .message = Text::lit("a test module declares no tag, trait or impl"), .fix = prism_rtl::cat("declare it in ", tested, ", the module the test module tests")}})
        : Array<crate::check::errors::CDiag>{};
}


/// TagFamilies: fn Module -> [Text]
Array<Text> tag_families(const crate::syntax::Module& m) {
    return fold(m.decls, Array<Text>{}, [&](const Array<Text>& acc, const crate::syntax::decls::Decl& d) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = d.kind;
            if (prism_rtl::is<crate::syntax::decls::DeclKind::DTag>(_m)) {
                auto&& t = prism_rtl::as<crate::syntax::decls::DeclKind::DTag>(_m).a0;
                _v.set(crate::prelude::push(acc, crate::syntax::lexer::chars::join(take(t.name->path_, crate::syntax::lexer::chars::dec(len(t.name->path_))), Text::lit("."))));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// AnyIn: fn [Text], [Text] -> Bool
bool any_in(const Array<Text>& xs, const Array<Text>& ys) {
    return fold(xs, false, [&](const bool& seen, const Text& x) { return seen || crate::check::types::has_text(ys, x); });
}


/// RenderParse: fn Src, [Diag] -> Text
Text render_parse(const crate::check::errors::Src& src, const Array<crate::syntax::Diag>& ds) {
    return concat(each(filter(ds, [&](const crate::syntax::Diag& d) { return d.stage != Text::lit("out"); }), [&](const crate::syntax::Diag& d) { return prism_rtl::cat(crate::check::errors::src_place(src, d.span.start), ":", crate::syntax::lexer::chars::column_of(src->text, or_(index(src.starts, crate::check::errors::cline_of(src.starts, d.span.start)), Nat(0u)), d.span.start) + Nat(1u), ": ", d.message, "\n"); }));
}

}  // namespace crate::reading
