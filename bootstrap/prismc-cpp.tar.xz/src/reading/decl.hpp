// The module `Reading`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace reading {

struct Assembled;

struct CheckOpts;

struct CompileSettings;

struct HeadLine;

struct ModFiles;

struct ParsedProgram;

struct ReadInput;

class ReadMode;

struct Seg;

struct TreeAcc;

struct TreeDiag;

struct Assemble;

struct AddArg;

struct WalkTree;

struct WalkLib;

struct WalkModule;

struct Child;

struct ReachTree;

struct ReachNames;

struct ParseUnit;

struct ParseProgram;

}  // namespace reading

namespace reading {

/// `ReadMode`:
///
/// ```prism
/// type ReadMode = choice:
/// ```
class ReadMode {
public:
    using prism_value = void;
    struct Checking;
    struct Compiling;
    using Cases = std::variant<Checking, Compiling>;
    template <class C>
        requires prism_rtl::one_of<C, Checking, Compiling>
    ReadMode(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ReadMode> from_pod(const Pod& whole);
    friend inline bool operator==(const ReadMode& a, const ReadMode& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


}  // namespace reading

}  // namespace crate
