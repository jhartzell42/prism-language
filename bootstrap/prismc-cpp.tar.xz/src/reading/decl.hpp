// The module `Reading`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace reading {

struct Assembled;

struct CheckOpts;

struct CompileSettings;

struct HeadLine;

struct ModFiles;

struct ParsedProgram;

struct ReadInput;

class ReadMode;

struct Seg;

struct TreeAcc;

struct TreeDiag;

struct Assemble;

struct AddArg;

struct WalkTree;

struct WalkLib;

struct WalkModule;

struct Child;

struct ReachTree;

struct ReachNames;

struct ParseUnit;

struct ParseProgram;

}  // namespace reading

}  // namespace crate
