// The module `Reading`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <reading/types.hpp>
#include "elem.types.hpp"
#include <syntax/types.hpp>
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace reading {

bool is_compiling(const ReadMode& read_mode0);

Array<std::tuple<Text, Array<Text>>> pairs(const Array<Text>& ds_p0, const Map<Nat, Array<Text>>& m_p1);

Text read_failure(const std::optional<Fallible<crate::fs::Contents>>& opt0);

Text contents_failure(const Fallible<crate::fs::Contents>& arg0);

Text contents_text(const Fallible<crate::fs::Contents>& arg0);

bool is_source_path(const Text& f_p0);

Text dir_of(const Text& p_p0);

Text base_of(const Text& p_p0);

Text under(const Text& d_p0, const Text& n_p1);

Array<Text> ancestors(const Text& d_p0);

Text dir_name(const Text& name_p0);

Text mod_of_dir(const Text& d_p0);

Array<HeadLine> header_lines(const Text& text_p0);

std::optional<HeadLine> head_line_of(const Text& line_p0, const Nat& at_p1);

std::optional<crate::syntax::Range> first_decl_line(const Text& text_p0);

Assembled no_assembly();

crate::syntax::Range no_span();

TreeAcc add_tree_diag(const TreeAcc& acc_p0, const Text& path_p1, const crate::syntax::Range& span_p2, const Text& code_p3, const Text& message_p4, const Text& fix_p5);

bool is_module_dir(const Text& d_p0, const Array<Text>& files_p1);

bool is_root_dir(const Text& d_p0, const Array<Text>& files_p1);

std::optional<Text> tree_root_of(const Text& d_p0, const Map<Text, Array<Text>>& listings_p1);

Array<Text> to_read(const Array<Text>& args_p0, const Map<Text, Array<Text>>& listings_p1);

Assembled assemble(const ReadInput& input_p0);

prism_rtl::JobRef<Assembled> start_assemble(ReadInput input_p0);

ModFiles kept_segs(const ModFiles& u_p0, const bool& tests_p1);

Assembled add_arg(const Assembled& acc_p0, const Map<Text, Array<Text>>& listings_p1, const Map<Text, Text>& texts_p2, const Text& a_p3);

prism_rtl::JobRef<Assembled> start_add_arg(Assembled acc_p0, Map<Text, Array<Text>> listings_p1, Map<Text, Text> texts_p2, Text a_p3);

Text main_path(const ModFiles& u_p0);

Text main_text(const ModFiles& u_p0);

Array<Text> test_paths(const ModFiles& u_p0);

TreeAcc walk_tree(const Text& root_p0, const Array<Text>& files_p1, const Map<Text, Text>& texts_p2);

prism_rtl::JobRef<TreeAcc> start_walk_tree(Text root_p0, Array<Text> files_p1, Map<Text, Text> texts_p2);

TreeAcc walk_lib(const Map<Text, bool>& has_p0, const Map<Text, Text>& texts_p1, const TreeAcc& acc_p2, const Text& lib_p3);

prism_rtl::JobRef<TreeAcc> start_walk_lib(Map<Text, bool> has_p0, Map<Text, Text> texts_p1, TreeAcc acc_p2, Text lib_p3);

TreeAcc walk_module(const Map<Text, bool>& has_p0, const Map<Text, Text>& texts_p1, const TreeAcc& acc_p2, const Text& main_p3, const Text& name_p4, const Text& parent_p5, const bool& in_test_p6);

prism_rtl::JobRef<TreeAcc> start_walk_module(Map<Text, bool> has_p0, Map<Text, Text> texts_p1, TreeAcc acc_p2, Text main_p3, Text name_p4, Text parent_p5, bool in_test_p6);

TreeAcc lowercase(const TreeAcc& a_p0, const Text& main_p1, const Text& dir_p2, const HeadLine& h_p3);

TreeAcc child(const Map<Text, bool>& has_p0, const Map<Text, Text>& texts_p1, const TreeAcc& acc_p2, const Text& main_p3, const Text& dir_p4, const HeadLine& h_p5, const Text& parent_p6, const bool& in_test_p7);

prism_rtl::JobRef<TreeAcc> start_child(Map<Text, bool> has_p0, Map<Text, Text> texts_p1, TreeAcc acc_p2, Text main_p3, Text dir_p4, HeadLine h_p5, Text parent_p6, bool in_test_p7);

TreeAcc stray(const Map<Text, bool>& has_p0, const Map<Text, Text>& texts_p1, const TreeAcc& acc_p2, const Text& f_p3);

Array<ModFiles> reach_tree(const Array<ModFiles>& units_p0, const Text& main_p1);

prism_rtl::JobRef<Array<ModFiles>> start_reach_tree(Array<ModFiles> units_p0, Text main_p1);

Array<Text> reach_names(const Map<Text, ModFiles>& by_name_p0, const Array<Text>& seen_p1, const Array<Text>& todo_p2);

prism_rtl::JobRef<Array<Text>> start_reach_names(Map<Text, ModFiles> by_name_p0, Array<Text> seen_p1, Array<Text> todo_p2);

Text use_target(const Map<Text, ModFiles>& by_name_p0, const Text& u_p1);

bool is_test_unit(const ModFiles& u_p0);

Text unit_name(const ModFiles& u_p0);

Text render_tree_diag(const Map<Text, Text>& texts_p0, const TreeDiag& d_p1);

Text tree_report(const ReadInput& input_p0, const Array<TreeDiag>& ds_p1);

std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed> parse_unit(const ModFiles& u_p0);

prism_rtl::JobRef<std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>> start_parse_unit(ModFiles u_p0);

ParsedProgram parse_program(const Assembled& read_p0);

prism_rtl::JobRef<ParsedProgram> start_parse_program(Assembled read_p0);

Array<crate::check::errors::CDiag> tree_decl_diags(const ParsedProgram& pp_p0);

Array<crate::check::errors::CDiag> decl_role_diags(const crate::check::errors::Src& src_p0, const Text& parent_p1, const Nat& i_p2, const crate::syntax::decls::Decl& d_p3);

Array<Text> tag_families(const crate::syntax::Module& m_p0);

bool any_in(const Array<Text>& xs_p0, const Array<Text>& ys_p1);

Text render_parse(const crate::check::errors::Src& src_p0, const Array<crate::syntax::Diag>& ds_p1);

}  // namespace reading


namespace reading {

/// The step machine of `Assemble`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Assemble: unbounded fn ReadInput -> Assembled
struct Assemble : prism_rtl::Job<Assembled> {
    ReadInput input_p0;
    Assemble(ReadInput input_p0) : input_p0(std::move(input_p0)) {}
    prism_rtl::Turn<Assembled> cycle() const override;
};


/// The step machine of `AddArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AddArg: unbounded fn Assembled, (Text ==> [Text]), (Text ==> Text), Text -> Assembled
struct AddArg : prism_rtl::Job<Assembled> {
    Assembled acc_p0;
    Map<Text, Array<Text>> listings_p1;
    Map<Text, Text> texts_p2;
    Text a_p3;
    AddArg(Assembled acc_p0, Map<Text, Array<Text>> listings_p1, Map<Text, Text> texts_p2, Text a_p3) : acc_p0(std::move(acc_p0)), listings_p1(std::move(listings_p1)), texts_p2(std::move(texts_p2)), a_p3(std::move(a_p3)) {}
    prism_rtl::Turn<Assembled> cycle() const override;
};


/// The step machine of `WalkTree`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WalkTree: unbounded fn Text, [Text], (Text ==> Text) -> TreeAcc
struct WalkTree : prism_rtl::Job<TreeAcc> {
    Text root_p0;
    Array<Text> files_p1;
    Map<Text, Text> texts_p2;
    WalkTree(Text root_p0, Array<Text> files_p1, Map<Text, Text> texts_p2) : root_p0(std::move(root_p0)), files_p1(std::move(files_p1)), texts_p2(std::move(texts_p2)) {}
    prism_rtl::Turn<TreeAcc> cycle() const override;
};


/// The step machine of `WalkLib`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WalkLib: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text -> TreeAcc
struct WalkLib : prism_rtl::Job<TreeAcc> {
    Map<Text, bool> has_p0;
    Map<Text, Text> texts_p1;
    TreeAcc acc_p2;
    Text lib_p3;
    WalkLib(Map<Text, bool> has_p0, Map<Text, Text> texts_p1, TreeAcc acc_p2, Text lib_p3) : has_p0(std::move(has_p0)), texts_p1(std::move(texts_p1)), acc_p2(std::move(acc_p2)), lib_p3(std::move(lib_p3)) {}
    prism_rtl::Turn<TreeAcc> cycle() const override;
};


/// The step machine of `WalkModule`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WalkModule: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text, Text, Text, Bool -> TreeAcc
struct WalkModule : prism_rtl::Job<TreeAcc> {
    Map<Text, bool> has_p0;
    Map<Text, Text> texts_p1;
    TreeAcc acc_p2;
    Text main_p3;
    Text name_p4;
    Text parent_p5;
    bool in_test_p6;
    WalkModule(Map<Text, bool> has_p0, Map<Text, Text> texts_p1, TreeAcc acc_p2, Text main_p3, Text name_p4, Text parent_p5, bool in_test_p6) : has_p0(std::move(has_p0)), texts_p1(std::move(texts_p1)), acc_p2(std::move(acc_p2)), main_p3(std::move(main_p3)), name_p4(std::move(name_p4)), parent_p5(std::move(parent_p5)), in_test_p6(std::move(in_test_p6)) {}
    prism_rtl::Turn<TreeAcc> cycle() const override;
};


/// The step machine of `Child`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Child: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text, Text, HeadLine, Text, Bool -> TreeAcc
struct Child : prism_rtl::Job<TreeAcc> {
    Map<Text, bool> has_p0;
    Map<Text, Text> texts_p1;
    TreeAcc acc_p2;
    Text main_p3;
    Text dir_p4;
    HeadLine h_p5;
    Text parent_p6;
    bool in_test_p7;
    Child(Map<Text, bool> has_p0, Map<Text, Text> texts_p1, TreeAcc acc_p2, Text main_p3, Text dir_p4, HeadLine h_p5, Text parent_p6, bool in_test_p7) : has_p0(std::move(has_p0)), texts_p1(std::move(texts_p1)), acc_p2(std::move(acc_p2)), main_p3(std::move(main_p3)), dir_p4(std::move(dir_p4)), h_p5(std::move(h_p5)), parent_p6(std::move(parent_p6)), in_test_p7(std::move(in_test_p7)) {}
    prism_rtl::Turn<TreeAcc> cycle() const override;
};


/// The step machine of `ReachTree`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ReachTree: unbounded fn [ModFiles], Text -> [ModFiles]
struct ReachTree : prism_rtl::Job<Array<ModFiles>> {
    Array<ModFiles> units_p0;
    Text main_p1;
    ReachTree(Array<ModFiles> units_p0, Text main_p1) : units_p0(std::move(units_p0)), main_p1(std::move(main_p1)) {}
    prism_rtl::Turn<Array<ModFiles>> cycle() const override;
};


/// The step machine of `ReachNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ReachNames: unbounded fn (Text ==> ModFiles), [Text], [Text] -> [Text]
struct ReachNames : prism_rtl::Job<Array<Text>> {
    Map<Text, ModFiles> by_name_p0;
    Array<Text> seen_p1;
    Array<Text> todo_p2;
    ReachNames(Map<Text, ModFiles> by_name_p0, Array<Text> seen_p1, Array<Text> todo_p2) : by_name_p0(std::move(by_name_p0)), seen_p1(std::move(seen_p1)), todo_p2(std::move(todo_p2)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `ParseUnit`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseUnit: unbounded fn ModFiles -> ((Src, Parsed))
struct ParseUnit : prism_rtl::Job<std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>> {
    ModFiles u_p0;
    ParseUnit(ModFiles u_p0) : u_p0(std::move(u_p0)) {}
    prism_rtl::Turn<std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>> cycle() const override;
};


/// The step machine of `ParseProgram`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseProgram: unbounded fn Assembled -> ParsedProgram
struct ParseProgram : prism_rtl::Job<ParsedProgram> {
    Assembled read_p0;
    ParseProgram(Assembled read_p0) : read_p0(std::move(read_p0)) {}
    prism_rtl::Turn<ParsedProgram> cycle() const override;
};


}  // namespace reading

}  // namespace crate
