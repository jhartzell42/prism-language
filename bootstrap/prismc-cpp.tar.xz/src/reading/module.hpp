// The module `Reading`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <reading/types.hpp>
#include "elem.types.hpp"
#include <syntax/types.hpp>
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace reading {

bool is_compiling(const ReadMode& read_mode0);

Array<std::tuple<Text, Array<Text>>> pairs(const Array<Text>& ds, const Map<Nat, Array<Text>>& m);

Text read_failure(const std::optional<Fallible<crate::fs::Contents>>& opt0);

Text contents_failure(const Fallible<crate::fs::Contents>& arg0);

Text contents_text(const Fallible<crate::fs::Contents>& arg0);

bool is_source_path(const Text& f);

Text dir_of(const Text& p_);

Text base_of(const Text& p_);

Text under(const Text& d, const Text& n);

Array<Text> ancestors(const Text& d);

Text dir_name(const Text& name);

Text mod_of_dir(const Text& d);

Array<HeadLine> header_lines(const Text& text_);

std::optional<HeadLine> head_line_of(const Text& line, const Nat& at_);

std::optional<crate::syntax::Range> first_decl_line(const Text& text_);

Assembled no_assembly();

crate::syntax::Range no_span();

TreeAcc add_tree_diag(const TreeAcc& acc, const Text& path_, const crate::syntax::Range& span, const Text& code, const Text& message, const Text& fix);

bool is_module_dir(const Text& d, const Array<Text>& files);

bool is_root_dir(const Text& d, const Array<Text>& files);

std::optional<Text> tree_root_of(const Text& d, const Map<Text, Array<Text>>& listings);

Array<Text> to_read(const Array<Text>& args, const Map<Text, Array<Text>>& listings);

Assembled assemble(const ReadInput& input);

prism_rtl::JobRef<Assembled> start_assemble(ReadInput input);

ModFiles kept_segs(const ModFiles& u, const bool& tests);

Assembled add_arg(const Assembled& acc, const Map<Text, Array<Text>>& listings, const Map<Text, Text>& texts, const Text& a);

prism_rtl::JobRef<Assembled> start_add_arg(Assembled acc, Map<Text, Array<Text>> listings, Map<Text, Text> texts, Text a);

Text main_path(const ModFiles& u);

Text main_text(const ModFiles& u);

Array<Text> test_paths(const ModFiles& u);

TreeAcc walk_tree(const Text& root, const Array<Text>& files, const Map<Text, Text>& texts);

prism_rtl::JobRef<TreeAcc> start_walk_tree(Text root, Array<Text> files, Map<Text, Text> texts);

TreeAcc walk_lib(const Map<Text, bool>& has, const Map<Text, Text>& texts, const TreeAcc& acc, const Text& lib);

prism_rtl::JobRef<TreeAcc> start_walk_lib(Map<Text, bool> has, Map<Text, Text> texts, TreeAcc acc, Text lib);

TreeAcc walk_module(const Map<Text, bool>& has, const Map<Text, Text>& texts, const TreeAcc& acc, const Text& main, const Text& name, const Text& parent, const bool& in_test);

prism_rtl::JobRef<TreeAcc> start_walk_module(Map<Text, bool> has, Map<Text, Text> texts, TreeAcc acc, Text main, Text name, Text parent, bool in_test);

TreeAcc lowercase(const TreeAcc& a, const Text& main, const Text& dir, const HeadLine& h);

TreeAcc child(const Map<Text, bool>& has, const Map<Text, Text>& texts, const TreeAcc& acc, const Text& main, const Text& dir, const HeadLine& h, const Text& parent, const bool& in_test);

prism_rtl::JobRef<TreeAcc> start_child(Map<Text, bool> has, Map<Text, Text> texts, TreeAcc acc, Text main, Text dir, HeadLine h, Text parent, bool in_test);

TreeAcc stray(const Map<Text, bool>& has, const Map<Text, Text>& texts, const TreeAcc& acc, const Text& f);

Array<ModFiles> reach_tree(const Array<ModFiles>& units, const Text& main);

prism_rtl::JobRef<Array<ModFiles>> start_reach_tree(Array<ModFiles> units, Text main);

Array<Text> reach_names(const Map<Text, ModFiles>& by_name, const Array<Text>& seen, const Array<Text>& todo);

prism_rtl::JobRef<Array<Text>> start_reach_names(Map<Text, ModFiles> by_name, Array<Text> seen, Array<Text> todo);

Text use_target(const Map<Text, ModFiles>& by_name, const Text& u);

bool is_test_unit(const ModFiles& u);

Text unit_name(const ModFiles& u);

Text render_tree_diag(const Map<Text, Text>& texts, const TreeDiag& d);

Text tree_report(const ReadInput& input, const Array<TreeDiag>& ds);

std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed> parse_unit(const ModFiles& u);

prism_rtl::JobRef<std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>> start_parse_unit(ModFiles u);

ParsedProgram parse_program(const Assembled& read);

prism_rtl::JobRef<ParsedProgram> start_parse_program(Assembled read);

Array<crate::check::errors::CDiag> tree_decl_diags(const ParsedProgram& pp);

Array<crate::check::errors::CDiag> decl_role_diags(const crate::check::errors::Src& src, const Text& parent, const Nat& i, const crate::syntax::decls::Decl& d);

Array<Text> tag_families(const crate::syntax::Module& m);

bool any_in(const Array<Text>& xs, const Array<Text>& ys);

Text render_parse(const crate::check::errors::Src& src, const Array<crate::syntax::Diag>& ds);

}  // namespace reading


namespace reading {

/// The step machine of `Assemble`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Assemble: unbounded fn ReadInput -> Assembled
struct Assemble : prism_rtl::Job<Assembled> {
    ReadInput input;
    Assemble(ReadInput input) : input(std::move(input)) {}
    prism_rtl::Turn<Assembled> cycle() const override;
};


/// The step machine of `AddArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AddArg: unbounded fn Assembled, (Text ==> [Text]), (Text ==> Text), Text -> Assembled
struct AddArg : prism_rtl::Job<Assembled> {
    Assembled acc;
    Map<Text, Array<Text>> listings;
    Map<Text, Text> texts;
    Text a;
    AddArg(Assembled acc, Map<Text, Array<Text>> listings, Map<Text, Text> texts, Text a) : acc(std::move(acc)), listings(std::move(listings)), texts(std::move(texts)), a(std::move(a)) {}
    prism_rtl::Turn<Assembled> cycle() const override;
};


/// The step machine of `WalkTree`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WalkTree: unbounded fn Text, [Text], (Text ==> Text) -> TreeAcc
struct WalkTree : prism_rtl::Job<TreeAcc> {
    Text root;
    Array<Text> files;
    Map<Text, Text> texts;
    WalkTree(Text root, Array<Text> files, Map<Text, Text> texts) : root(std::move(root)), files(std::move(files)), texts(std::move(texts)) {}
    prism_rtl::Turn<TreeAcc> cycle() const override;
};


/// The step machine of `WalkLib`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WalkLib: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text -> TreeAcc
struct WalkLib : prism_rtl::Job<TreeAcc> {
    Map<Text, bool> has;
    Map<Text, Text> texts;
    TreeAcc acc;
    Text lib;
    WalkLib(Map<Text, bool> has, Map<Text, Text> texts, TreeAcc acc, Text lib) : has(std::move(has)), texts(std::move(texts)), acc(std::move(acc)), lib(std::move(lib)) {}
    prism_rtl::Turn<TreeAcc> cycle() const override;
};


/// The step machine of `WalkModule`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WalkModule: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text, Text, Text, Bool -> TreeAcc
struct WalkModule : prism_rtl::Job<TreeAcc> {
    Map<Text, bool> has;
    Map<Text, Text> texts;
    TreeAcc acc;
    Text main;
    Text name;
    Text parent;
    bool in_test;
    WalkModule(Map<Text, bool> has, Map<Text, Text> texts, TreeAcc acc, Text main, Text name, Text parent, bool in_test) : has(std::move(has)), texts(std::move(texts)), acc(std::move(acc)), main(std::move(main)), name(std::move(name)), parent(std::move(parent)), in_test(std::move(in_test)) {}
    prism_rtl::Turn<TreeAcc> cycle() const override;
};


/// The step machine of `Child`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Child: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text, Text, HeadLine, Text, Bool -> TreeAcc
struct Child : prism_rtl::Job<TreeAcc> {
    Map<Text, bool> has;
    Map<Text, Text> texts;
    TreeAcc acc;
    Text main;
    Text dir;
    HeadLine h;
    Text parent;
    bool in_test;
    Child(Map<Text, bool> has, Map<Text, Text> texts, TreeAcc acc, Text main, Text dir, HeadLine h, Text parent, bool in_test) : has(std::move(has)), texts(std::move(texts)), acc(std::move(acc)), main(std::move(main)), dir(std::move(dir)), h(std::move(h)), parent(std::move(parent)), in_test(std::move(in_test)) {}
    prism_rtl::Turn<TreeAcc> cycle() const override;
};


/// The step machine of `ReachTree`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ReachTree: unbounded fn [ModFiles], Text -> [ModFiles]
struct ReachTree : prism_rtl::Job<Array<ModFiles>> {
    Array<ModFiles> units;
    Text main;
    ReachTree(Array<ModFiles> units, Text main) : units(std::move(units)), main(std::move(main)) {}
    prism_rtl::Turn<Array<ModFiles>> cycle() const override;
};


/// The step machine of `ReachNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ReachNames: unbounded fn (Text ==> ModFiles), [Text], [Text] -> [Text]
struct ReachNames : prism_rtl::Job<Array<Text>> {
    Map<Text, ModFiles> by_name;
    Array<Text> seen;
    Array<Text> todo;
    ReachNames(Map<Text, ModFiles> by_name, Array<Text> seen, Array<Text> todo) : by_name(std::move(by_name)), seen(std::move(seen)), todo(std::move(todo)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `ParseUnit`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseUnit: unbounded fn ModFiles -> ((Src, Parsed))
struct ParseUnit : prism_rtl::Job<std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>> {
    ModFiles u;
    ParseUnit(ModFiles u) : u(std::move(u)) {}
    prism_rtl::Turn<std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>> cycle() const override;
};


/// The step machine of `ParseProgram`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseProgram: unbounded fn Assembled -> ParsedProgram
struct ParseProgram : prism_rtl::Job<ParsedProgram> {
    Assembled read;
    ParseProgram(Assembled read) : read(std::move(read)) {}
    prism_rtl::Turn<ParsedProgram> cycle() const override;
};


}  // namespace reading

}  // namespace crate
