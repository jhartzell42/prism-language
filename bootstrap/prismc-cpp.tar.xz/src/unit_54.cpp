// The module `Lower.Node.Switch`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <lower/node_/switch_/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/model/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Lower.Node.Switch`, from `target/bootstrap/cpp-src/prismc/lower/node/switch.prism`.
namespace crate::lower::node_::switch_ {



Pod GenCase::to_pod() const {
    return Pod::record("GenCase", {{"node", prism_rtl::to_pod(node_)}, {"params", prism_rtl::to_pod(params)}, {"pat", prism_rtl::to_pod(pat)}, {"conds", prism_rtl::to_pod(conds)}, {"passed", prism_rtl::to_pod(passed)}});
}

Result<GenCase> GenCase::from_pod(const Pod& whole) {
    return GenCase{.node_ = TRY(prism_rtl::from_pod<crate::lower::model::NodeDef>(TRY(crate::prelude::field(whole, "node")))), .params = TRY(prism_rtl::from_pod<Array<std::tuple<Text, crate::lower::model::OutTy>>>(TRY(crate::prelude::field(whole, "params")))), .pat = TRY(prism_rtl::from_pod<crate::lower::model::Pa>(TRY(crate::prelude::field(whole, "pat")))), .conds = TRY(prism_rtl::from_pod<Array<crate::lower::model::Cc>>(TRY(crate::prelude::field(whole, "conds")))), .passed = TRY(prism_rtl::from_pod<Array<crate::lower::model::Ex>>(TRY(crate::prelude::field(whole, "passed"))))};
}




/// RowEnv: unbounded fn Wx, Wx, Env, Block -> ((Wx, Wx, Env))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env> row_env(const crate::lower::node_::Wx& parent_p0, const crate::lower::node_::Wx& row_wx_p1, const crate::lower::types::Env& menv_p2, const crate::syntax::Block& body_p3) {
    auto names_p4 = crate::lower::expr::read_names(crate::check::typed::print::block_exprs(body_p3));
    return fold(names_p4, std::tuple{parent_p0, row_wx_p1, crate::lower::types::empty_env()}, [&](const std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env>& _p0, const Text& n_p8) {
        auto&& p_p5 = std::get<0>(_p0);
        auto&& r_p6 = std::get<1>(_p0);
        auto&& env_p7 = std::get<2>(_p0);
        return ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env>> _v;
            auto&& _m = crate::prelude::get(menv_p2.names, n_p8);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs_p9 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& mode_pa = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                auto&& t_pb = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(std::tuple{p_p5, r_p6, crate::lower::types::bind(env_p7, n_p8, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{over_parent(rs_p9), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t_pb}))});
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(_m))) {
                auto&& er_pc = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(_m)).a0;
                auto&& t_pd = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(_m)).a1;
                _v.set(({
                    auto pname_pe = prism_rtl::deref(crate::lower::node_::gn_of(p_p5, prism_rtl::deref(er_pc).node_)).name;
                    auto [rs_ph, r1_pi] = crate::lower::node_::fresh_name(r_p6, crate::lower::snake(n_p8));
                    auto [id_pj, r2_pk] = crate::lower::node_::add_gn(r1_pi, rs_ph, t_pd, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnPort{}), Nat(0u));
                    auto r3_pf = ({
                        crate::lower::node_::Wx this_ = r2_pk;
                        this_.subs = crate::prelude::push(this_.subs, std::tuple{pname_pe, rs_ph, t_pd});
                        (std::move(this_));
                    });
                    auto p2_pg = crate::check::types::has_text(prism_rtl::deref(p_p5).ports, pname_pe)
                        ? p_p5
                        : crate::lower::node_::connect(with_port(p_p5, pname_pe), crate::lower::node_::ev_ref_of(p_p5, prism_rtl::deref(er_pc).node_), crate::lower::node_::Sk(crate::lower::node_::Sk::SkPort{pname_pe}));
                    std::tuple{p2_pg, r3_pf, crate::lower::types::bind(env_p7, n_p8, crate::lower::types::Bn(crate::lower::types::Bn::BnEv{crate::lower::node_::ev_ref_of(r3_pf, id_pj), t_pd}))};
                }));
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)) && prism_rtl::is<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0)) {
                auto&& recv_pl = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a0;
                auto&& m_pm = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a1;
                auto&& xs_pn = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a2;
                auto&& t_po = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a2;
                _v.set(prism_rtl::deref(recv_pl) == crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})
                    ? std::tuple{p_p5, r_p6, crate::lower::types::bind(env_p7, n_p8, crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(parent_ref()), m_pm, xs_pn}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{m_pm})}), t_po}))}
                    : row_param_env(p_p5, r_p6, env_p7, menv_p2, n_p8));
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m))) {
                _v.set(row_param_env(p_p5, r_p6, env_p7, menv_p2, n_p8));
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(_m))) {
                auto&& f_pp = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(_m)).a0;
                auto&& t_pq = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(_m)).a1;
                _v.set(std::tuple{p_p5, r_p6, crate::lower::types::bind(env_p7, n_p8, crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(parent_ref()), f_pp})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{f_pp})}), t_pq}))});
                goto _done;
            }
            {
                _v.set(std::tuple{p_p5, r_p6, env_p7});
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// RowParamEnv: fn Wx, Wx, Env, Env, Text -> ((Wx, Wx, Env))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env> row_param_env(const crate::lower::node_::Wx& p_p0, const crate::lower::node_::Wx& r_p1, const crate::lower::types::Env& env_p2, const crate::lower::types::Env& menv_p3, const Text& n_p4) {
    auto&& _m = crate::prelude::get(menv_p3.names, prism_rtl::cat(n_p4, "#row"));
    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)) && prism_rtl::is<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0)) {
        auto&& m_p5 = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a1;
        auto&& xs_p6 = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a2;
        auto&& t_p7 = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a2;
        return std::tuple{p_p0, r_p1, crate::lower::types::bind(env_p2, n_p4, crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(parent_ref()), m_p5, xs_p6}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{m_p5})}), t_p7}))};
    }
    {
        return std::tuple{p_p0, r_p1, env_p2};
    }
}


/// OverParent: fn Ex -> Ex
crate::lower::model::Ex over_parent(const crate::lower::model::Ex& x_p0) {
    if (prism_rtl::is<crate::lower::model::Ex::XSelf>(x_p0)) {
        return parent_ref();
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x_p0)) {
        auto&& y_p1 = prism_rtl::as<crate::lower::model::Ex::XField>(x_p0).a0;
        auto&& f_p2 = prism_rtl::as<crate::lower::model::Ex::XField>(x_p0).a1;
        return crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(over_parent(prism_rtl::deref(prism_rtl::deref(y_p1)))), f_p2});
    }
    if (prism_rtl::is<crate::lower::model::Ex::XPart>(x_p0)) {
        auto&& y_p3 = prism_rtl::as<crate::lower::model::Ex::XPart>(x_p0).a0;
        auto&& k_p4 = prism_rtl::as<crate::lower::model::Ex::XPart>(x_p0).a1;
        return crate::lower::model::Ex(crate::lower::model::Ex::XPart{prism_rtl::rc(over_parent(prism_rtl::deref(prism_rtl::deref(y_p3)))), k_p4});
    }
    if (prism_rtl::is<crate::lower::model::Ex::XMethod>(x_p0)) {
        auto&& y_p5 = prism_rtl::as<crate::lower::model::Ex::XMethod>(x_p0).a0;
        auto&& m_p6 = prism_rtl::as<crate::lower::model::Ex::XMethod>(x_p0).a1;
        auto&& xs_p7 = prism_rtl::as<crate::lower::model::Ex::XMethod>(x_p0).a2;
        return crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(over_parent(prism_rtl::deref(prism_rtl::deref(y_p5)))), m_p6, xs_p7});
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUpgrade>(x_p0)) {
        auto&& y_p8 = prism_rtl::as<crate::lower::model::Ex::XUpgrade>(x_p0).a0;
        return crate::lower::model::Ex(crate::lower::model::Ex::XUpgrade{prism_rtl::rc(over_parent(prism_rtl::deref(prism_rtl::deref(y_p8))))});
    }
    {
        return crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(parent_ref()), crate::lower::types::place_stem(x_p0)});
    }
}


/// let parentRef
crate::lower::model::Ex parent_ref() {
    return crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XUpgrade{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("parent")}))})), Text::lit("expect"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{Text::lit("the block outlives its rows")})})});
}


/// let parentArg
crate::lower::model::Ex parent_arg() {
    return crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XUpgrade{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("parent")}))})), Text::lit("expect"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{Text::lit("the block outlives its rows")})})});
}


/// WithPort: fn Wx, Text -> Wx
crate::lower::node_::Wx with_port(const crate::lower::node_::Wx& wx_p0, const Text& pname_p1) {
    crate::lower::node_::Wx this_ = wx_p0;
    this_.ports = crate::prelude::push(this_.ports, pname_p1);
    return this_;
}


/// RebuildLine: unbounded fn Wx, Env, Env, Expr, Block, Expr, ?Bn -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> rebuild_line(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const crate::syntax::Expr& scrut_p3, const crate::syntax::Block& body_p4, const crate::syntax::Expr& e_p5, const std::optional<crate::lower::types::Bn>& bound_o6) {
    auto lx_p7 = wx_p0.lx;
    auto pos_p8 = wx_p0.pos;
    auto wx1_p9 = ({
        crate::lower::node_::Wx this_ = wx_p0;
        this_.pos = crate::lower::model::next_pos(this_.pos);
        (std::move(this_));
    });
    auto [src_ex_pb, reads_pc] = crate::lower::node_::dynamics::dynamic_expr(wx1_p9, menv_p2, scrut_p3);
    auto vt_pa = crate::lower::types::out_ty_of(lx_p7, crate::lower::types::peel(crate::lower::type_at(lx_p7, scrut_p3.span)));
    auto [name_pd, wx2_pe] = crate::lower::node_::fresh_name(wx1_p9, Text::lit("generation"));
    return gives_dynamic(crate::lower::type_at(lx_p7, e_p5.span))
        ? rebuild_dynamic(wx2_pe, menv_p2, body_p4, src_ex_pb, reads_pc, vt_pa, name_pd, pos_p8)
        : ({
        auto [up_id_pj, wx3_pk] = ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Nat, crate::lower::node_::Wx>> _v;
            if (prism_rtl::is_some(bound_o6) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_o6))) {
                auto&& er_pi = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_o6)).a0;
                _v.set(std::tuple{prism_rtl::deref(er_pi).node_, wx2_pe});
                goto _done;
            }
            {
                _v.set(crate::lower::node_::add_gn(wx2_pe, prism_rtl::cat(name_pd, "_fired"), crate::lower::types::out_ty_of(lx_p7, crate::lower::types::peel(crate::lower::type_at(lx_p7, e_p5.span))), crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnNamed{}), Nat(0u)));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto [cases_pl, wx4_pm] = gen_cases(wx3_pk, menv_p2, body_p4, vt_pa, name_pd);
        auto row_defs_pf = each(cases_pl, [&](const GenCase& c_pn) { return prism_rtl::deref(c_pn).node_; });
        auto select_pg = gen_select(wx4_pm, menv_p2, body_p4, cases_pl, pos_p8);
        auto wx5_ph = ({
            crate::lower::node_::Wx this_ = wx4_pm;
            this_.gens = crate::prelude::push(this_.gens, crate::lower::model::GenDef{.name = name_pd, .pos = pos_p8, .at = crate::lower::node_::finish::place_at(wx_p0, Text::lit("self"), pos_p8), .source = src_ex_pb, .value_ty = vt_pa, .select = select_pg, .transparent = false, .width = Nat(0u), .moved = or_(crate::lower::node_::finish::hosted_rows(wx_p0), Text::lit(""))});
            this_.gen_holds = crate::prelude::push(this_.gen_holds, std::tuple{name_pd, reads_pc});
            this_.rows = fold(row_defs_pf, this_.rows, [&](const Array<crate::lower::model::NodeDef>& acc_po, const crate::lower::model::NodeDef& rd_pp) { return append(crate::prelude::push(acc_po, rd_pp), prism_rtl::deref(rd_pp).children); });
            this_.getters = crate::prelude::push(this_.getters, gen_up(name_pd, prism_rtl::deref(crate::lower::node_::gn_of(wx4_pm, up_id_pj)).name, prism_rtl::deref(crate::lower::node_::gn_of(wx4_pm, up_id_pj)).ty));
            (std::move(this_));
        });
        std::tuple{wx5_ph, crate::lower::node_::Wres(crate::lower::node_::Wres::WrEv{crate::lower::node_::ev_ref_of(wx5_ph, up_id_pj)})};
    });
}


prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> RebuildLine::cycle() const {
    const auto& wx_p0 = this->wx_p0;
    const auto& benv_p1 = this->benv_p1;
    const auto& menv_p2 = this->menv_p2;
    const auto& scrut_p3 = this->scrut_p3;
    const auto& body_p4 = this->body_p4;
    const auto& e_p5 = this->e_p5;
    const auto& bound_o6 = this->bound_o6;
    auto lx_p7 = prism_rtl::deref(wx_p0).lx;
    auto pos_p8 = prism_rtl::deref(wx_p0).pos;
    auto wx1_p9 = ({
        crate::lower::node_::Wx this_ = wx_p0;
        this_.pos = crate::lower::model::next_pos(this_.pos);
        (std::move(this_));
    });
    auto bound_o6_1 = bound_o6;
    auto body_p4_2 = body_p4;
    auto e_p5_3 = e_p5;
    auto menv_p2_4 = menv_p2;
    auto scrut_p3_5 = scrut_p3;
    auto wx_p0_6 = wx_p0;
    return call_then(crate::lower::node_::dynamics::start_dynamic_expr(wx1_p9, menv_p2_4, scrut_p3_5), [=](std::tuple<crate::lower::model::Ex, Array<crate::lower::node_::Read>> dynamic_expr_4431) {
        return ({
            auto [src_ex_pb, reads_pc] = dynamic_expr_4431;
            call_then(crate::lower::types::start_out_ty_of(lx_p7, crate::lower::types::peel(crate::lower::type_at(lx_p7, prism_rtl::deref(scrut_p3_5).span))), [=](crate::lower::model::OutTy out_ty_of_4473) {
            return ({
                auto vt_pa = out_ty_of_4473;
                auto [name_pd, wx2_pe] = crate::lower::node_::fresh_name(wx1_p9, Text::lit("generation"));
                gives_dynamic(crate::lower::type_at(lx_p7, prism_rtl::deref(e_p5_3).span))
                ? prism_rtl::finished(rebuild_dynamic(wx2_pe, menv_p2_4, body_p4_2, src_ex_pb, reads_pc, vt_pa, name_pd, pos_p8))
                : ({
                auto [up_id_pj, wx3_pk] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<Nat, crate::lower::node_::Wx>> _v;
                    if (prism_rtl::is_some(bound_o6_1) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_o6_1))) {
                        auto&& er_pi = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_o6_1)).a0;
                        _v.set(std::tuple{prism_rtl::deref(er_pi).node_, wx2_pe});
                        goto _done;
                    }
                    {
                        _v.set(crate::lower::node_::add_gn(wx2_pe, prism_rtl::cat(name_pd, "_fired"), crate::lower::types::out_ty_of(lx_p7, crate::lower::types::peel(crate::lower::type_at(lx_p7, prism_rtl::deref(e_p5_3).span))), crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnNamed{}), Nat(0u)));
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto [cases_pl, wx4_pm] = gen_cases(wx3_pk, menv_p2_4, body_p4_2, vt_pa, name_pd);
                auto row_defs_pf = each(cases_pl, [&](const GenCase& c_pn) { return prism_rtl::deref(c_pn).node_; });
                auto select_pg = gen_select(wx4_pm, menv_p2_4, body_p4_2, cases_pl, pos_p8);
                auto wx5_ph = ({
                    crate::lower::node_::Wx this_ = wx4_pm;
                    this_.gens = crate::prelude::push(this_.gens, crate::lower::model::GenDef{.name = name_pd, .pos = pos_p8, .at = crate::lower::node_::finish::place_at(wx_p0_6, Text::lit("self"), pos_p8), .source = src_ex_pb, .value_ty = vt_pa, .select = select_pg, .transparent = false, .width = Nat(0u), .moved = or_(crate::lower::node_::finish::hosted_rows(wx_p0_6), Text::lit(""))});
                    this_.gen_holds = crate::prelude::push(this_.gen_holds, std::tuple{name_pd, reads_pc});
                    this_.rows = fold(row_defs_pf, this_.rows, [&](const Array<crate::lower::model::NodeDef>& acc_po, const crate::lower::model::NodeDef& rd_pp) { return append(crate::prelude::push(acc_po, rd_pp), prism_rtl::deref(rd_pp).children); });
                    this_.getters = crate::prelude::push(this_.getters, gen_up(name_pd, prism_rtl::deref(crate::lower::node_::gn_of(wx4_pm, up_id_pj)).name, prism_rtl::deref(crate::lower::node_::gn_of(wx4_pm, up_id_pj)).ty));
                    (std::move(this_));
                });
                (prism_rtl::finished(std::tuple{wx5_ph, crate::lower::node_::Wres(crate::lower::node_::Wres::WrEv{crate::lower::node_::ev_ref_of(wx5_ph, up_id_pj)})}));
            });
            });
        });
        });
    });
}


/// `Start RebuildLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> start_rebuild_line(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::Expr scrut_p3, crate::syntax::Block body_p4, crate::syntax::Expr e_p5, std::optional<crate::lower::types::Bn> bound_o6) {
    return prism_rtl::make_rc<RebuildLine>(wx_p0, benv_p1, menv_p2, scrut_p3, body_p4, e_p5, bound_o6);
}


/// GivesDynamic: fn Ty -> Bool
bool gives_dynamic(const crate::check::types::Ty& t_p0) {
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& m5725_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a0;
        auto&& m5725_0_1 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        if (m5725_0_0 == Text::lit("$")) {
            if (prism_rtl::is<crate::check::types::Ty::TySig>(prism_rtl::deref(prism_rtl::deref(m5725_0_1)))) {
                auto&& m5725_0_1_r_0 = prism_rtl::as<crate::check::types::Ty::TySig>(prism_rtl::deref(prism_rtl::deref(m5725_0_1))).a0;
                if (m5725_0_1_r_0 == Text::lit("$")) {
                    return true;
                }
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p0)) {
        auto&& i_p1 = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p0).a0;
        return gives_dynamic(prism_rtl::deref(prism_rtl::deref(i_p1)));
    }
    {
        return false;
    }
}


/// RebuildDynamic: unbounded fn Wx, Env, Block, Ex, [Read], OutTy, Text, Pos -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> rebuild_dynamic(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const crate::syntax::Block& body_p2, const crate::lower::model::Ex& src_ex_p3, const Array<crate::lower::node_::Read>& reads_p4, const crate::lower::model::OutTy& vt_p5, const Text& name_p6, const crate::lower::model::Pos_& pos_p7) {
    auto row_name_p8 = prism_rtl::cat(wx_p0.node_, "Gen", crate::lower::node_::keyed::row_suffix(wx_p0));
    auto whole_p9 = gen_row_of(wx_p0, menv_p1, body_p2, vt_p5, row_name_p8, name_p6);
    auto&& _m = prism_rtl::deref(whole_p9).dyn_result;
    if (prism_rtl::is_none(_m)) {
        auto wx2_pa = ({
            crate::lower::node_::Wx this_ = whole_p9->parent;
            this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("a `rebuild` whose generation gives a dynamic it does not lower")));
            (std::move(this_));
        });
        return std::tuple{wx2_pa, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& rt_pb = prism_rtl::some_of(_m);
        auto dyn_ty_pc = crate::lower::model::OutTy(crate::lower::model::OutTy::OutDyn{prism_rtl::rc(rt_pb)});
        auto result_pd = prism_rtl::cat(name_p6, "_result");
        auto live_pe = prism_rtl::cat(result_pd, "_live");
        auto what_pf = prism_rtl::cat("the dynamic of the `rebuild` at place ", crate::lower::model::place_text(pos_p7));
        auto tail_pg = append(append(Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XWeak{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})}), crate::lower::node_::keyed::hosted_passed(wx_p0)), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})}));
        auto built_ph = crate::lower::expr::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XCall{prism_rtl::cat(prism_rtl::deref(prism_rtl::deref(whole_p9).node_).name, "::build"), append(Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("path")}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("value")})}), tail_pg)}));
        auto kept_pi = crate::lower::model::Do(crate::lower::model::Do::DoAssign{crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), live_pe})), Text::lit("borrow_mut"), Array<crate::lower::model::Ex>{}}))}), crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")})), Text::lit("result_dynamic"), Array<crate::lower::model::Ex>{}})})})});
        auto marked_pj = crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(result_pd, "_snap")})), Text::lit("mark"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
        auto select_pk = crate::lower::model::Ex(crate::lower::model::Ex::XBlock{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")}), built_ph}), kept_pi, marked_pj}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")}))});
        auto current_pl = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(live_pe)})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}}))})), Text::lit("expect"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{Text::lit("a `rebuild` has a generation from its build on")})})});
        auto wx2_pm = ({
            crate::lower::node_::Wx this_ = whole_p9->parent;
            this_.gens = crate::prelude::push(this_.gens, crate::lower::model::GenDef{.name = name_p6, .pos = pos_p7, .at = crate::lower::node_::finish::place_at(wx_p0, Text::lit("self"), pos_p7), .source = src_ex_p3, .value_ty = vt_p5, .select = select_pk, .transparent = false, .width = Nat(0u), .moved = or_(crate::lower::node_::finish::hosted_rows(wx_p0), Text::lit(""))});
            this_.gen_holds = crate::prelude::push(this_.gen_holds, std::tuple{name_p6, reads_p4});
            this_.rows = append(crate::prelude::push(this_.rows, prism_rtl::deref(whole_p9).node_), prism_rtl::deref(prism_rtl::deref(whole_p9).node_).children);
            this_.taken = append(this_.taken, Array(std::vector{result_pd, live_pe, prism_rtl::cat(result_pd, "_now"), prism_rtl::cat(result_pd, "_snap"), prism_rtl::cat(result_pd, "_publish"), prism_rtl::cat(result_pd, "_moved")}));
            this_.fields = append(this_.fields, Array(std::vector{std::tuple{live_pe, crate::lower::model::OutTy(crate::lower::model::OutTy::OutCell{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(dyn_ty_pc)}))}), Text::lit("the current generation\'s result, which the snapshot of the `rebuild`\'s dynamic is taken from")}, std::tuple{prism_rtl::cat(result_pd, "_snap"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutSnapshot{prism_rtl::rc(dyn_ty_pc)}), prism_rtl::cat("the `rebuild` at place ", crate::lower::model::place_text(pos_p7), "\'s dynamic, structural: its snapshots, the generations\' results and the lagged dynamic (pick ST)")}}));
            this_.moves = crate::prelude::push(this_.moves, std::tuple{live_pe, crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("RefCell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XNone{})})})});
            this_.inits = crate::prelude::push(this_.inits, std::tuple{prism_rtl::cat(result_pd, "_snap"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Snapshot::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{what_pf})})})});
            this_.getters = append(this_.getters, Array(std::vector{crate::lower::model::MethDef{.name = prism_rtl::cat(result_pd, "_now"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = dyn_ty_pc, .body = Array<crate::lower::model::Do>{}, .tail = current_pl, .doc = Text::lit("The current generation\'s result: what the snapshot of the `rebuild`\'s dynamic is taken from (pick ST).")}, crate::lower::node_::static_::snap_getter(result_pd, dyn_ty_pc, Text::lit("The `rebuild`\'s dynamic, its generation\'s result, a structural dynamic (pick ST): one tick behind the generations, the snapshot of the tick before the tick the read point is after."))}));
            this_.snaps = crate::prelude::push(this_.snaps, crate::lower::node_::SnapDef{.name = result_pd, .live = prism_rtl::cat(result_pd, "_now"), .ty = dyn_ty_pc, .eq = false, .builder = name_p6, .before = false, .what = what_pf});
            (std::move(this_));
        });
        return std::tuple{wx2_pm, crate::lower::node_::Wres(crate::lower::node_::Wres::WrDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), result_pd, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{result_pd})}), dyn_ty_pc})};
    }
    prism_rtl::unreachable("no arm matched");
}


/// ClauseWidgetLine: unbounded fn Wx, Env, Expr, Block, Text, ValInfo, Expr -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> clause_widget_line(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const crate::syntax::Expr& scrut_p2, const crate::syntax::Block& call_p3, const Text& qk_p4, const crate::check::env::ValInfo& v_p5, const crate::syntax::Expr& e_p6) {
    auto lx_p7 = wx_p0.lx;
    auto pos_p8 = wx_p0.pos;
    auto [src_ex_pe, reads_pf] = crate::lower::node_::dynamics::dynamic_expr(wx_p0, menv_p1, scrut_p2);
    auto vt_p9 = crate::lower::types::out_ty_of(lx_p7, crate::lower::types::peel(crate::lower::type_at(lx_p7, scrut_p2.span)));
    auto [name_pg, wx1_ph] = crate::lower::node_::fresh_name(wx_p0, Text::lit("generation"));
    auto [up_id_pi, wx2_pj] = crate::lower::node_::add_gn(wx1_ph, prism_rtl::cat(name_pg, "_fired"), crate::lower::types::out_ty_of(lx_p7, crate::lower::types::out_of(crate::lower::type_at(lx_p7, e_p6.span))), crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnNamed{}), Nat(0u));
    auto clauses_pa = crate::lower::jobs::clauses_of(prism_rtl::deref(lx_p7).g, qk_p4);
    auto row_name_pb = prism_rtl::cat(wx_p0.node_, "Gen", crate::lower::node_::keyed::row_suffix(wx_p0));
    auto [rows_pp, wx3_pq] = run_to_end(fold_job(crate::check::errors::range0(len(clauses_pa)), std::tuple{Array<ClauseRow>{}, wx2_pj}, ({
        auto clauses_pa_1 = clauses_pa;
        auto menv_p1_2 = menv_p1;
        auto v_p5_3 = v_p5;
        auto row_name_pb_4 = row_name_pb;
        auto name_pg_5 = name_pg;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<ClauseRow>, crate::lower::node_::Wx>>(std::tuple<std::tuple<Array<ClauseRow>, crate::lower::node_::Wx>, Nat>)>>(prism_rtl::rc([=, clauses_pa_1 = std::move(clauses_pa_1), menv_p1_2 = std::move(menv_p1_2), v_p5_3 = std::move(v_p5_3), row_name_pb_4 = std::move(row_name_pb_4), name_pg_5 = std::move(name_pg_5)](std::tuple<std::tuple<Array<ClauseRow>, crate::lower::node_::Wx>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto clauses_pa_1_6 = clauses_pa_1;
            auto menv_p1_2_6 = menv_p1_2;
            auto v_p5_3_6 = v_p5_3;
            auto row_name_pb_4_6 = row_name_pb_4;
            auto name_pg_5_6 = name_pg_5;
            entered(once_job([=, clauses_pa_1_6 = std::move(clauses_pa_1_6), menv_p1_2_6 = std::move(menv_p1_2_6), v_p5_3_6 = std::move(v_p5_3_6), row_name_pb_4_6 = std::move(row_name_pb_4_6), name_pg_5_6 = std::move(name_pg_5_6)]() {
            return ({
                auto [acc_pk, w_pl] = p0;
                auto i_pm = p1;
                ({
                auto c_pn = or_(index(clauses_pa_1_6, i_pm), crate::lower::functions::dummy_clause());
                auto cr_po = clause_row_of(w_pl, menv_p1_2_6, c_pn, v_p5_3_6, prism_rtl::cat(row_name_pb_4_6, i_pm), name_pg_5_6, true);
                (prism_rtl::finished(std::tuple{crate::prelude::push(acc_pk, cr_po), cr_po->parent}));
            });
            });
        }));
        });
    }));
    })));
    auto width_pc = fold(rows_pp, Nat(0u), [&](const Nat& acc_pr, const ClauseRow& cr_ps) { return crate::prelude::max(acc_pr, prism_rtl::deref(cr_ps).width); });
    auto cases_pd = each(rows_pp, [&](const ClauseRow& cr_pt) { return prism_rtl::deref(cr_pt).case_; });
    return is_hosted_scope(wx_p0)
        ? ({
        auto wx4_pu = ({
            crate::lower::node_::Wx this_ = wx3_pq;
            this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("a widget of several clauses in a static position of a hosted scope")));
            (std::move(this_));
        });
        std::tuple{wx4_pu, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
    })
        : ({
        auto select_pv = gen_select(wx3_pq, menv_p1, call_p3, cases_pd, pos_p8);
        auto wx4_p10 = ({
            crate::lower::node_::Wx this_ = wx3_pq;
            this_.pos = crate::lower::model::Pos_{.scope = prism_rtl::deref(pos_p8).scope, .at = prism_rtl::deref(pos_p8).at + width_pc};
            this_.gens = crate::prelude::push(this_.gens, crate::lower::model::GenDef{.name = name_pg, .pos = pos_p8, .at = crate::lower::node_::finish::place_at(wx_p0, Text::lit("self"), pos_p8), .source = src_ex_pe, .value_ty = vt_p9, .select = select_pv, .transparent = true, .width = width_pc, .moved = or_(crate::lower::node_::finish::hosted_rows(wx_p0), Text::lit(""))});
            this_.gen_holds = crate::prelude::push(this_.gen_holds, std::tuple{name_pg, reads_pf});
            this_.rows = fold(cases_pd, this_.rows, [&](const Array<crate::lower::model::NodeDef>& acc_p11, const GenCase& gc_p12) { return append(crate::prelude::push(acc_p11, prism_rtl::deref(gc_p12).node_), prism_rtl::deref(prism_rtl::deref(gc_p12).node_).children); });
            this_.getters = crate::prelude::push(this_.getters, gen_up(name_pg, prism_rtl::deref(crate::lower::node_::gn_of(wx3_pq, up_id_pi)).name, prism_rtl::deref(crate::lower::node_::gn_of(wx3_pq, up_id_pi)).ty));
            (std::move(this_));
        });
        std::tuple{wx4_p10, crate::lower::node_::Wres(crate::lower::node_::Wres::WrEv{crate::lower::node_::ev_ref_of(wx4_p10, up_id_pi)})};
    });
}


/// IsHostedScope: fn Wx -> Bool
bool is_hosted_scope(const crate::lower::node_::Wx& wx_p0) {
    return (prism_rtl::deref(wx_p0.pos).scope > Nat(0u)) || is_some_(wx_p0.hosted_by);
}


/// GenCases: unbounded fn Wx, Env, Block, OutTy, Text -> (([GenCase], Wx))
std::tuple<Array<GenCase>, crate::lower::node_::Wx> gen_cases(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const crate::syntax::Block& body_p2, const crate::lower::model::OutTy& vt_p3, const Text& name_p4) {
    auto lx_p5 = wx_p0.lx;
    auto row_name_p6 = prism_rtl::cat(wx_p0.node_, "Gen", crate::lower::node_::keyed::row_suffix(wx_p0));
    auto&& _m = clause_call(lx_p5, body_p2);
    if (prism_rtl::is_some(_m)) {
        auto&& qk_p7 = std::get<0>(prism_rtl::some_of(_m));
        auto&& args_p8 = std::get<1>(prism_rtl::some_of(_m));
        auto clauses_p9 = crate::lower::jobs::clauses_of(prism_rtl::deref(lx_p5).g, qk_p7);
        auto v_pa = crate::lower::program::val_of(lx_p5, qk_p7);
        return run_to_end(fold_job(crate::check::errors::range0(len(clauses_p9)), std::tuple{Array<GenCase>{}, wx_p0}, ({
            auto clauses_p9_1 = clauses_p9;
            auto menv_p1_2 = menv_p1;
            auto v_pa_3 = v_pa;
            auto row_name_p6_4 = row_name_p6;
            auto name_p4_5 = name_p4;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<GenCase>, crate::lower::node_::Wx>>(std::tuple<std::tuple<Array<GenCase>, crate::lower::node_::Wx>, Nat>)>>(prism_rtl::rc([=, clauses_p9_1 = std::move(clauses_p9_1), menv_p1_2 = std::move(menv_p1_2), v_pa_3 = std::move(v_pa_3), row_name_p6_4 = std::move(row_name_p6_4), name_p4_5 = std::move(name_p4_5)](std::tuple<std::tuple<Array<GenCase>, crate::lower::node_::Wx>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto clauses_p9_1_6 = clauses_p9_1;
                auto menv_p1_2_6 = menv_p1_2;
                auto v_pa_3_6 = v_pa_3;
                auto row_name_p6_4_6 = row_name_p6_4;
                auto name_p4_5_6 = name_p4_5;
                entered(once_job([=, clauses_p9_1_6 = std::move(clauses_p9_1_6), menv_p1_2_6 = std::move(menv_p1_2_6), v_pa_3_6 = std::move(v_pa_3_6), row_name_p6_4_6 = std::move(row_name_p6_4_6), name_p4_5_6 = std::move(name_p4_5_6)]() {
                return ({
                    auto [acc_pb, w_pc] = p0;
                    auto i_pd = p1;
                    ({
                    auto c_pe = or_(index(clauses_p9_1_6, i_pd), crate::lower::functions::dummy_clause());
                    auto cr_pf = clause_row_of(w_pc, menv_p1_2_6, c_pe, v_pa_3_6, prism_rtl::cat(row_name_p6_4_6, i_pd), name_p4_5_6, false);
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc_pb, prism_rtl::deref(cr_pf).case_), cr_pf->parent}));
                });
                });
            }));
            });
        }));
        })));
    }
    if (prism_rtl::is_none(_m)) {
        auto whole_pg = gen_row_of(wx_p0, menv_p1, body_p2, vt_p3, row_name_p6, name_p4);
        return std::tuple{Array(std::vector{GenCase{.node_ = prism_rtl::deref(whole_pg).node_, .params = Array(std::vector{std::tuple{Text::lit("value"), vt_p3}}), .pat = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .passed = Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("value")})})}}), whole_pg->parent};
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?ClauseCall: fn Lx, Block -> ?((Text, [Arg]))
std::optional<std::tuple<Text, Array<crate::syntax::Arg>>> clause_call(const crate::lower::Lx& lx_p0, const crate::syntax::Block& body_p1) {
    auto&& _m = body_p1.stmts;
    {
        auto&& m13740_0 = _m;
        if (m13740_0.size() == 1u) {
            {
                auto&& _c1 = index(m13740_0, Nat(0u));
                if (prism_rtl::is_some(_c1)) {
                    auto&& st_p2 = prism_rtl::some_of(_c1);
                    auto&& _m = prism_rtl::deref(st_p2).kind;
                    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
                        auto&& x_p3 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                        return clause_call_x(lx_p0, x_p3);
                    }
                    if (prism_rtl::is<crate::syntax::StmtKind::SIgnore>(_m)) {
                        auto&& x_p4 = prism_rtl::as<crate::syntax::StmtKind::SIgnore>(_m).a0;
                        return clause_call_x(lx_p0, x_p4);
                    }
                    {
                        return std::optional<std::tuple<Text, Array<crate::syntax::Arg>>>{};
                    }
                }
            }
        }
    }
    {
        return std::optional<std::tuple<Text, Array<crate::syntax::Arg>>>{};
    }
}


/// ?ClauseCallX: fn Lx, Expr -> ?((Text, [Arg]))
std::optional<std::tuple<Text, Array<crate::syntax::Arg>>> clause_call_x(const crate::lower::Lx& lx_p0, const crate::syntax::Expr& x_p1) {
    auto&& _m = prism_rtl::deref(x_p1.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c_p2 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args_p3 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        auto qk_p4 = crate::lower::program::blueprint_qk(lx_p0, prism_rtl::deref(prism_rtl::deref(c_p2)));
        return len(crate::lower::jobs::clauses_of(lx_p0.g, qk_p4)) > Nat(1u)
            ? std::optional(std::tuple{qk_p4, args_p3})
            : std::optional<std::tuple<Text, Array<crate::syntax::Arg>>>{};
    }
    {
        return std::optional<std::tuple<Text, Array<crate::syntax::Arg>>>{};
    }
}


/// ClauseRowOf: unbounded fn Wx, Env, FnClause, ValInfo, Text, Text, Bool -> ClauseRow
ClauseRow clause_row_of(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const crate::syntax::decls::FnClause& c_p2, const crate::check::env::ValInfo& v_p3, const Text& row_name_p4, const Text& gen_name_p5, const bool& transparent_p6) {
    auto up_name_p7 = prism_rtl::cat(gen_name_p5, "_up");
    auto lx_p8 = wx_p0.lx;
    auto lxc_p9 = crate::lower::program::in_module_at(lx_p8, v_p3.file, v_p3.home, prism_rtl::deref(lx_p8).site);
    auto ptys_pa = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
        auto&& _m = prism_rtl::deref(v_p3.scheme).ty;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& ps_pr = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            _v.set(ps_pr);
            goto _done;
        }
        {
            _v.set(Array<crate::check::types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto pos_pb = run_to_end(each_job(crate::check::errors::range0(len(c_p2.params)), ({
        auto lxc_p9_1 = lxc_p9;
        auto c_p2_2 = c_p2;
        auto ptys_pa_3 = ptys_pa;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::patterns::PatOut>(Nat)>>(prism_rtl::rc([=, lxc_p9_1 = std::move(lxc_p9_1), c_p2_2 = std::move(c_p2_2), ptys_pa_3 = std::move(ptys_pa_3)](Nat p0) {
        return ({
            auto lxc_p9_1_4 = lxc_p9_1;
            auto c_p2_2_4 = c_p2_2;
            auto ptys_pa_3_4 = ptys_pa_3;
            entered(once_job([=, lxc_p9_1_4 = std::move(lxc_p9_1_4), c_p2_2_4 = std::move(c_p2_2_4), ptys_pa_3_4 = std::move(ptys_pa_3_4)]() {
            return ({
                auto i_ps = p0;
                (prism_rtl::more(prism_rtl::rc(crate::lower::patterns::RustPat(lxc_p9_1_4, or_(index(c_p2_2_4.params, i_ps), crate::lower::patterns::dummy_pat()), or_(index(ptys_pa_3_4, i_ps), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), prism_rtl::cat("c", i_ps)))));
            });
        }));
        });
    })));
    })));
    auto pa_pc = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(pos_pb, [&](const crate::lower::patterns::PatOut& o_pt) { return prism_rtl::deref(o_pt).pa; })});
    auto binds_pd = fold(pos_pb, Map<Text, crate::lower::types::Bn>{}, [&](const Map<Text, crate::lower::types::Bn>& m_pu, const crate::lower::patterns::PatOut& o_pv) {
        return fold(prism_rtl::deref(o_pv).binds, m_pu, [&](const Map<Text, crate::lower::types::Bn>& m2_p10, const std::tuple<Text, crate::lower::types::Bn>& _p1) {
            auto&& n_p11 = std::get<0>(_p1);
            auto&& b_p12 = std::get<1>(_p1);
            return insert(m2_p10, n_p11, b_p12);
        });
    });
    auto binders_pe = filter(run_to_end(fold_job(c_p2.params, Array<std::tuple<Text, crate::syntax::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_p13 = p0;
                auto p_p14 = p1;
                call_then(crate::check::env::names::start_pattern_binders(p_p14), [=, acc_p13 = std::move(acc_p13)](Array<std::tuple<Text, crate::syntax::Range>> pattern_binders_15253) { return prism_rtl::finished(append(acc_p13, pattern_binders_15253)); });
            });
        }));
    })))), [&](const std::tuple<Text, crate::syntax::Range>& _p0) {
        auto&& bn_p15 = std::get<0>(_p0);
        return crate::check::env::has_key(binds_pd, bn_p15);
    });
    auto fields_pf = run_to_end(each_job(binders_pe, ({
        auto lxc_p9_1 = lxc_p9;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::lower::model::OutTy, Text>>(std::tuple<Text, crate::syntax::Range>)>>(prism_rtl::rc([=, lxc_p9_1 = std::move(lxc_p9_1)](std::tuple<Text, crate::syntax::Range> p0) {
        return ({
            auto lxc_p9_1_2 = lxc_p9_1;
            entered(once_job([=, lxc_p9_1_2 = std::move(lxc_p9_1_2)]() {
            return ({
                auto [bn_p16, r_p17] = p0;
                call_then(crate::lower::types::start_out_ty_of(lxc_p9_1_2, crate::lower::types::peel(crate::lower::binder_ty(lxc_p9_1_2, r_p17))), [=](crate::lower::model::OutTy out_ty_of_15367) { return prism_rtl::finished(std::tuple{crate::lower::snake(bn_p16), out_ty_of_15367, bn_p16}); });
            });
        }));
        });
    }));
    })));
    auto row_fields_pg = crate::prelude::push(each(fields_pf, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& f_p18 = std::get<0>(_p0);
        auto&& t_p19 = std::get<1>(_p0);
        auto&& bn_p1a = std::get<2>(_p0);
        return std::tuple{f_p18, t_p19, prism_rtl::cat("`", bn_p1a, "`")};
    }), std::tuple{Text::lit("parent"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutWeak{wx_p0.node_}), Text::lit("the node of the `rebuild`")});
    auto row_inits_ph = each(fields_pf, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& f_p1b = std::get<0>(_p0);
        return std::tuple{f_p1b, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{f_p1b}))})};
    });
    auto row_taken_pi = append(crate::lower::node_::node_hooks(), crate::prelude::push(each(fields_pf, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& f_p1c = std::get<0>(_p0);
        return f_p1c;
    }), Text::lit("parent")));
    auto r00_pj = crate::lower::node_::new_wx(lxc_p9, row_name_p4, row_fields_pg, row_inits_ph, Array(std::vector{std::tuple{Text::lit("parent"), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("parent")})}}), Array<crate::lower::model::MethDef>{}, Map<Text, Array<crate::lower::node_::Read>>{}, row_taken_pi, wx_p0.inlining, crate::lower::node_::finish::hosted_rows(wx_p0));
    auto r0_pk = transparent_p6
        ? ({
        crate::lower::node_::Wx this_ = r00_pj;
        this_.pos = wx_p0.pos;
        (std::move(this_));
    })
        : r00_pj;
    auto body_pl = ({
        __label__ _done;
        prism_rtl::Slot<crate::syntax::Block> _v;
        auto&& _m = c_p2.body;
        if (prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(_m)) {
            auto&& b_p1d = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(_m).a0;
            _v.set(b_p1d);
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(_m)) {
            auto&& x_p1e = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(_m).a0;
            _v.set(crate::syntax::Block{.stmts = Array(std::vector{crate::syntax::Stmt{.kind = crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{x_p1e}), .span = prism_rtl::deref(x_p1e).span}}), .inline_ = true, .span = prism_rtl::deref(x_p1e).span});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto [p1_p1f, r1_p1g, ports_p1h] = row_env(wx_p0, r0_pk, menv_p1, body_pl);
    auto [be_p1n, me_p1o] = fold(fields_pf, std::tuple{crate::lower::types::empty_env(), crate::lower::types::empty_env()}, [&](const std::tuple<crate::lower::types::Env, crate::lower::types::Env>& _p0, const std::tuple<Text, crate::lower::model::OutTy, Text>& _p1) {
        auto&& b_p1i = std::get<0>(_p0);
        auto&& m_p1j = std::get<1>(_p0);
        auto&& f_p1k = std::get<0>(_p1);
        auto&& t_p1l = std::get<1>(_p1);
        auto&& bn_p1m = std::get<2>(_p1);
        return crate::lower::node_::bind_plain(b_p1i, m_p1j, bn_p1m, f_p1k, t_p1l);
    });
    auto r2_pm = crate::lower::node_::def::block_into(r1_p1g, be_p1n, me_p1o, body_pl);
    auto r3_pn = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::node_::Wx> _v;
        auto&& _m = r2_pm->result;
        if (prism_rtl::is<crate::lower::node_::Wres::WrEv>(_m)) {
            auto&& r_p1p = prism_rtl::as<crate::lower::node_::Wres::WrEv>(_m).a0;
            _v.set(crate::lower::node_::connect(r2_pm, r_p1p, crate::lower::node_::Sk(crate::lower::node_::Sk::SkUp{up_name_p7})));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::node_::Wres::WrParts>(_m)) {
            _v.set(({
                crate::lower::node_::Wx this_ = r2_pm;
                this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("a widget of several clauses whose clause ends on a bundle")));
                (std::move(this_));
            }));
            goto _done;
        }
        {
            _v.set(r2_pm);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto node_po = crate::lower::node_::finish::finish_node(r3_pn, row_name_p4, append(crate::prelude::push(each(fields_pf, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& f_p1q = std::get<0>(_p0);
        auto&& t_p1r = std::get<1>(_p0);
        return std::tuple{f_p1q, t_p1r};
    }), std::tuple{Text::lit("parent"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutWeak{wx_p0.node_})}), crate::lower::node_::keyed::hosted_params(wx_p0)), true);
    auto p2_pp = gen_marked(p1_p1f, gen_name_p5, r3_pn);
    auto passed_pq = each(fields_pf, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& f_p1s = std::get<0>(_p0);
        auto&& t_p1t = std::get<1>(_p0);
        auto&& bn_p1u = std::get<2>(_p0);
        return ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::Ex> _v;
            auto&& _m = crate::prelude::get(binds_pd, bn_p1u);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs_p1v = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& mode_p20 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                auto&& bt_p21 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(crate::lower::types::own(crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{rs_p1v, mode_p20, bt_p21})));
                goto _done;
            }
            {
                _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{f_p1s}))}));
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return ClauseRow{.case_ = GenCase{.node_ = node_po, .params = each(fields_pf, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& f_p22 = std::get<0>(_p0);
        auto&& t_p23 = std::get<1>(_p0);
        return std::tuple{f_p22, t_p23};
    }), .pat = pa_pc, .conds = fold(pos_pb, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc_p24, const crate::lower::patterns::PatOut& o_p25) { return append(acc_p24, prism_rtl::deref(o_p25).conds); }), .passed = passed_pq}, .parent = p2_pp, .width = or_(prism_rtl::deref(prism_rtl::deref(r2_pm).pos).at.checked_sub(prism_rtl::deref(prism_rtl::deref(r0_pk).pos).at), Nat(0u))};
}


/// GenRowOf: unbounded fn Wx, Env, Block, OutTy, Text, Text -> GenRow
GenRow gen_row_of(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const crate::syntax::Block& body_p2, const crate::lower::model::OutTy& vt_p3, const Text& row_name_p4, const Text& gen_name_p5) {
    auto lx_p6 = wx_p0.lx;
    auto up_name_p7 = prism_rtl::cat(gen_name_p5, "_up");
    auto r0_p8 = crate::lower::node_::new_wx(lx_p6, row_name_p4, Array(std::vector{std::tuple{Text::lit("value"), vt_p3, Text::lit("the generation\'s value, `_`")}, std::tuple{Text::lit("parent"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutWeak{wx_p0.node_}), Text::lit("the node of the `rebuild`")}}), Array(std::vector{std::tuple{Text::lit("value"), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("value")}))})}}), Array(std::vector{std::tuple{Text::lit("parent"), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("parent")})}}), Array<crate::lower::model::MethDef>{}, Map<Text, Array<crate::lower::node_::Read>>{}, append(crate::lower::node_::node_hooks(), Array(std::vector{Text::lit("value"), Text::lit("parent"), Text::lit("result"), Text::lit("result_dynamic")})), wx_p0.inlining, crate::lower::node_::finish::hosted_rows(wx_p0));
    auto [p1_pc, r1_pd, ports_pe] = row_env(wx_p0, r0_p8, menv_p1, body_p2);
    auto be_p9 = crate::lower::types::bind(build_spelling(ports_pe), Text::lit("_"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("value")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), vt_p3}));
    auto me_pa = crate::lower::types::bind(ports_pe, Text::lit("_"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("value")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), vt_p3}));
    auto r2_pb = crate::lower::node_::def::block_into(r1_pd, be_p9, me_pa, body_p2);
    auto [r3_pk, dyn_result_ol] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::lower::node_::Wx, std::optional<crate::lower::model::OutTy>>> _v;
        auto&& _m = r2_pb->result;
        if (prism_rtl::is<crate::lower::node_::Wres::WrEv>(_m)) {
            auto&& r_pf = prism_rtl::as<crate::lower::node_::Wres::WrEv>(_m).a0;
            _v.set(std::tuple{crate::lower::node_::connect(r2_pb, r_pf, crate::lower::node_::Sk(crate::lower::node_::Sk::SkUp{up_name_p7})), std::optional<crate::lower::model::OutTy>{}});
            goto _done;
        }
        if (prism_rtl::is<crate::lower::node_::Wres::WrDyn>(_m)) {
            auto&& ex_pg = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(_m).a0;
            auto&& result_reads_ph = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(_m).a1;
            auto&& rt_pi = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(_m).a2;
            _v.set(std::tuple{gen_result(r2_pb, gen_name_p5, ex_pg, result_reads_ph, rt_pi), std::optional(rt_pi)});
            goto _done;
        }
        if (prism_rtl::is<crate::lower::node_::Wres::WrParts>(_m)) {
            _v.set(({
                auto r2b_pj = ({
                    crate::lower::node_::Wx this_ = r2_pb;
                    this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("a `rebuild` whose block ends on a bundle")));
                    (std::move(this_));
                });
                std::tuple{r2b_pj, std::optional<crate::lower::model::OutTy>{}};
            }));
            goto _done;
        }
        {
            _v.set(std::tuple{r2_pb, std::optional<crate::lower::model::OutTy>{}});
            goto _done;
        }
    _done:
        _v.take();
    });
    return GenRow{.node_ = crate::lower::node_::finish::finish_node(r3_pk, row_name_p4, append(Array(std::vector{std::tuple{Text::lit("value"), vt_p3}, std::tuple{Text::lit("parent"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutWeak{wx_p0.node_})}}), crate::lower::node_::keyed::hosted_params(wx_p0)), true), .parent = gen_marked(p1_pc, gen_name_p5, r3_pk), .dyn_result = dyn_result_ol};
}


/// GenResult: fn Wx, Text, Ex, [Read], OutTy -> Wx
crate::lower::node_::Wx gen_result(const crate::lower::node_::Wx& r_p0, const Text& gen_name_p1, const crate::lower::model::Ex& ex_p2, const Array<crate::lower::node_::Read>& result_reads_p3, const crate::lower::model::OutTy& rt_p4) {
    auto own_behind_p5 = filter(crate::lower::node_::finish::reads_closed(r_p0.dyn_reads, result_reads_p3), [&](const crate::lower::node_::Read& rd_p8) {
        return ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            if (prism_rtl::is<crate::lower::node_::Read::OwnRead>(rd_p8)) {
                _v.set(true);
                goto _done;
            }
            if (prism_rtl::is<crate::lower::node_::Read::ParentRead>(rd_p8)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    auto made_p6 = crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Dynamic::of"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("cx")})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("me")})), Text::lit("result"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Port::new"), Array<crate::lower::model::Ex>{}})})}))})})});
    auto doc_p7 = prism_rtl::cat("The generation\'s result as a dynamic, which the block keeps while the generation is current; the block hears it move through `", gen_name_p1, "_result_moved`, not through the dynamic\'s port.");
    crate::lower::node_::Wx this_ = r_p0;
    this_.getters = append(this_.getters, Array(std::vector{crate::lower::model::MethDef{.name = Text::lit("result"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = rt_p4, .body = Array<crate::lower::model::Do>{}, .tail = ex_p2, .doc = Text::lit("The generation\'s result, which the `rebuild` hands back.")}, crate::lower::model::MethDef{.name = Text::lit("result_dynamic"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxNone{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutDyn{prism_rtl::rc(rt_p4)}), .body = Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("me")}), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})})}), .tail = made_p6, .doc = doc_p7}}));
    this_.result_moved = len(own_behind_p5) > Nat(0u)
        ? std::optional(std::tuple{prism_rtl::cat(gen_name_p1, "_result_moved"), own_behind_p5})
        : std::optional<std::tuple<Text, Array<crate::lower::node_::Read>>>{};
    return this_;
}


/// GenMarked: fn Wx, Text, Wx -> Wx
crate::lower::node_::Wx gen_marked(const crate::lower::node_::Wx& parent_p0, const Text& gen_name_p1, const crate::lower::node_::Wx& row_wx_p2) {
    auto reads_p3 = crate::lower::node_::keyed::row_place_reads(row_wx_p2);
    return len(reads_p3) == Nat(0u)
        ? parent_p0
        : ({
        crate::lower::node_::Wx this_ = parent_p0;
        this_.row_marks = crate::prelude::push(this_.row_marks, crate::lower::node_::RowMarks{.builder = gen_name_p1, .reads = reads_p3, .wrote = Array<Text>{}, .kind = crate::lower::model::RowKind(crate::lower::model::RowKind::GenerationRow{})});
        (std::move(this_));
    });
}


/// BuildSpelling: fn Env -> Env
crate::lower::types::Env build_spelling(const crate::lower::types::Env& env_p0) {
    return fold(keys(env_p0.names), env_p0, [&](const crate::lower::types::Env& en_p1, const Text& k_p2) {
        return ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::types::Env> _v;
            auto&& _m = crate::prelude::get(env_p0.names, k_p2);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs_p3 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& mode_p4 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                auto&& t_p5 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<crate::lower::types::Env> _v;
                    auto&& _m = crate::lower::types::through_parent(rs_p3);
                    if (prism_rtl::is_some(_m)) {
                        auto&& x_p6 = prism_rtl::some_of(_m);
                        _v.set(crate::lower::types::bind(en_p1, k_p2, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{x_p6, mode_p4, t_p5})));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(en_p1);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)) && prism_rtl::is<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0)) {
                auto&& rs_p7 = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a0;
                auto&& m_p8 = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a1;
                auto&& xs_p9 = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a2;
                auto&& ds_pa = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a1;
                auto&& t_pb = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a2;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<crate::lower::types::Env> _v;
                    auto&& _m = crate::lower::types::through_parent(prism_rtl::deref(rs_p7));
                    if (prism_rtl::is_some(_m)) {
                        auto&& x_pc = prism_rtl::some_of(_m);
                        _v.set(crate::lower::types::bind(en_p1, k_p2, crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(x_pc), m_p8, xs_p9}), ds_pa, t_pb})));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(en_p1);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(en_p1);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// GenSelect: unbounded fn Wx, Env, Block, [GenCase], Pos -> Ex
crate::lower::model::Ex gen_select(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const crate::syntax::Block& body_p2, const Array<GenCase>& cases_p3, const crate::lower::model::Pos_& pos_p4) {
    auto tail_p5 = append(append(Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XWeak{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})}), crate::lower::node_::keyed::hosted_passed(wx_p0)), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})}));
    auto&& _m = clause_call(wx_p0.lx, body_p2);
    if (prism_rtl::is_none(_m)) {
        auto&& _m = index(cases_p3, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& c_p6 = prism_rtl::some_of(_m);
            return crate::lower::expr::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XCall{prism_rtl::cat(prism_rtl::deref(prism_rtl::deref(c_p6).node_).name, "::build"), append(Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("path")}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("value")})}), tail_p5)}));
        }
        if (prism_rtl::is_none(_m)) {
            return crate::lower::expr::refusal(Text::lit("a `rebuild` with no generation"));
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_some(_m)) {
        auto&& qk_p7 = std::get<0>(prism_rtl::some_of(_m));
        auto&& args_p8 = std::get<1>(prism_rtl::some_of(_m));
        auto env_p9 = crate::lower::types::bind(menv_p1, Text::lit("_"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("value")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}));
        auto scrut_pa = crate::lower::model::Ex(crate::lower::model::Ex::XTuple{run_to_end(each_job(args_p8, ({
            auto wx_p0_1 = wx_p0;
            auto env_p9_2 = env_p9;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=, wx_p0_1 = std::move(wx_p0_1), env_p9_2 = std::move(env_p9_2)](crate::syntax::Arg p0) {
            return ({
                auto wx_p0_1_3 = wx_p0_1;
                auto env_p9_2_3 = env_p9_2;
                entered(once_job([=, wx_p0_1_3 = std::move(wx_p0_1_3), env_p9_2_3 = std::move(env_p9_2_3)]() {
                return ({
                    auto a_pc = p0;
                    (prism_rtl::more(prism_rtl::rc(crate::lower::expr::Argument(wx_p0_1_3.lx, env_p9_2_3, a_pc->value))));
                });
            }));
            });
        })));
        })))});
        auto arms_pb = each(cases_p3, [&](const GenCase& c_pd) {
            return ({
                auto made_pe = crate::lower::expr::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XCall{prism_rtl::cat(prism_rtl::deref(prism_rtl::deref(c_pd).node_).name, "::build"), append(append(Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("path")}))})}), prism_rtl::deref(c_pd).passed), tail_p5)}));
                crate::lower::model::XArm{.pat = prism_rtl::deref(c_pd).pat, .conds = prism_rtl::deref(c_pd).conds, .body = crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(made_pe), crate::lower::model::OutTy(crate::lower::model::OutTy::OutObj{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Row"), Array<crate::lower::model::OutTy>{}}))})})};
            });
        });
        return crate::lower::types::own(crate::lower::expr::arms_value(scrut_pa, arms_pb, Text::lit("\'select"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutObj{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Row"), Array<crate::lower::model::OutTy>{}}))})));
    }
    prism_rtl::unreachable("no arm matched");
}


/// GenUp: fn Text, Text, OutTy -> MethDef
crate::lower::model::MethDef gen_up(const Text& name_p0, const Text& up_name_p1, const crate::lower::model::OutTy& t_p2) {
    return crate::lower::model::MethDef{.name = prism_rtl::cat(name_p0, "_up"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array(std::vector{std::tuple{Text::lit("v"), t_p2}}), .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = Array(std::vector{crate::lower::node_::finish::self_call(up_name_p1, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")})}))}), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = Text::lit("The current generation\'s result fires the `rebuild`\'s.")};
}


/// GenForwards: fn GenDef -> [((Pa, Ex))]
Array<std::tuple<crate::lower::model::Pa, crate::lower::model::Ex>> gen_forwards(const crate::lower::model::GenDef& gd_p0) {
    return gd_p0.transparent
        ? each(crate::check::errors::range0(gd_p0.width), [&](const Nat& i_p1) {
        return ({
            auto current_p2 = crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(gd_p0.name)})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}}))});
            auto body_p3 = crate::lower::model::Ex(crate::lower::model::Ex::XBlock{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")}), current_p2}), crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::expr::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")})), Text::lit("answer"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("at")}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))})}), Array<crate::lower::model::Do>{}})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}))});
            std::tuple{crate::lower::node_::finish::pos_pat(crate::lower::model::Pos_{.scope = prism_rtl::deref(gd_p0.pos).scope, .at = prism_rtl::deref(gd_p0.pos).at + i_p1}, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaRest{Text::lit("")})})), body_p3};
        });
    })
        : Array(std::vector{std::tuple{crate::lower::node_::finish::pos_pat(gd_p0.pos, crate::lower::node_::finish::gen_tail()), forward_gen(gd_p0)}});
}


/// ForwardGen: fn GenDef -> Ex
crate::lower::model::Ex forward_gen(const crate::lower::model::GenDef& gd_p0) {
    auto current_p1 = crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(gd_p0.name)})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}}))});
    auto is_current_p2 = crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("=="), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("+"), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("g")}))})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XIndex{Nat(1u)}))})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(gd_p0.name, "_count")})), Text::lit("get"), Array<crate::lower::model::Ex>{}}))});
    return crate::lower::model::Ex(crate::lower::model::Ex::XBlock{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")}), current_p1}), crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIf{is_current_p2, Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::expr::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")})), Text::lit("answer"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("rest")}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))})}), Array<crate::lower::model::Do>{}})}), Array<crate::lower::model::Do>{}})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}))});
}


/// FlattenLine: unbounded fn Wx, Env, [Arg], ?Bn -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> flatten_line(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const Array<crate::syntax::Arg>& args_p2, const std::optional<crate::lower::types::Bn>& bound_o3) {
    auto named_o4 = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<std::tuple<Text, crate::lower::model::OutTy>>> _v;
        auto&& _m = index(args_p2, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& a_p6 = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::optional<std::tuple<Text, crate::lower::model::OutTy>>> _v;
                auto&& _m = prism_rtl::deref(prism_rtl::deref(a_p6->value).kind);
                if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                    auto&& n_p7 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::optional<std::tuple<Text, crate::lower::model::OutTy>>> _v;
                        auto&& _m = crate::prelude::get(menv_p1.names, crate::check::env::sname_key(n_p7));
                        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)) && prism_rtl::is<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0) && prism_rtl::is<crate::lower::model::OutTy::OutDyn>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a2)) {
                            auto&& m24384_0_0_0 = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a0;
                            auto&& m_p8 = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a1;
                            auto&& t_p9 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a2).a0;
                            if (prism_rtl::is<crate::lower::model::Ex::XSelf>(prism_rtl::deref(prism_rtl::deref(m24384_0_0_0)))) {
                                _v.set(std::optional(std::tuple{m_p8, prism_rtl::deref(prism_rtl::deref(t_p9))}));
                                goto _done;
                            }
                        }
                        {
                            _v.set(std::optional<std::tuple<Text, crate::lower::model::OutTy>>{});
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                {
                    _v.set(std::optional<std::tuple<Text, crate::lower::model::OutTy>>{});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::optional<std::tuple<Text, crate::lower::model::OutTy>>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto outer_o5 = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<std::tuple<Text, Text, crate::lower::model::OutTy>>> _v;
        if (prism_rtl::is_some(named_o4)) {
            auto&& m_pa = std::get<0>(prism_rtl::some_of(named_o4));
            auto&& t_pb = std::get<1>(prism_rtl::some_of(named_o4));
            _v.set(fold(wx_p0.gens, std::optional<std::tuple<Text, Text, crate::lower::model::OutTy>>{}, [&](const std::optional<std::tuple<Text, Text, crate::lower::model::OutTy>>& acc_oc, const crate::lower::model::GenDef& gd_pd) {
                return prism_rtl::cat(prism_rtl::deref(gd_pd).name, "_result") == m_pa
                    ? std::optional(std::tuple{m_pa, prism_rtl::deref(gd_pd).name, t_pb})
                    : acc_oc;
            }));
            goto _done;
        }
        if (prism_rtl::is_none(named_o4)) {
            _v.set(std::optional<std::tuple<Text, Text, crate::lower::model::OutTy>>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    if (prism_rtl::is_none(outer_o5)) {
        auto wx2_pe = ({
            crate::lower::node_::Wx this_ = wx_p0;
            this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("`@Flatten` of a dynamic that is not a `rebuild`\'s (a `for` over a map of dynamics binds the value under the key, `for k, $v <- $each:`, ruling FV)")));
            (std::move(this_));
        });
        return std::tuple{wx2_pe, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
    }
    if (prism_rtl::is_some(outer_o5)) {
        auto&& m_pf = std::get<0>(prism_rtl::some_of(outer_o5));
        auto&& gen_pg = std::get<1>(prism_rtl::some_of(outer_o5));
        auto&& t_ph = std::get<2>(prism_rtl::some_of(outer_o5));
        auto [name_po, wx1_pp] = ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Text, crate::lower::node_::Wx>> _v;
            if (prism_rtl::is_some(bound_o3) && prism_rtl::is<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(bound_o3))) {
                auto&& f_pm = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(bound_o3)).a0;
                _v.set(std::tuple{f_pm, wx_p0});
                goto _done;
            }
            if (prism_rtl::is_some(bound_o3) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_o3)) && prism_rtl::is<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_o3)).a0)) {
                auto&& m25087_1_0_0 = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_o3)).a0).a0;
                auto&& f_pn = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_o3)).a0).a1;
                if (prism_rtl::is<crate::lower::model::Ex::XSelf>(prism_rtl::deref(prism_rtl::deref(m25087_1_0_0)))) {
                    _v.set(std::tuple{f_pn, wx_p0});
                    goto _done;
                }
            }
            {
                _v.set(crate::lower::node_::fresh_name(wx_p0, Text::lit("flatten")));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto inner_pi = prism_rtl::cat(name_po, "_inner");
        auto first_pj = crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), prism_rtl::cat(inner_pi)})), Text::lit("set"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), m_pf, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
        auto sample_pk = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(inner_pi)})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})), Text::lit("expect"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{Text::lit("`@Flatten` adopts its first inner at the build")})})})), Text::lit("sample"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})});
        auto wx2_pl = ({
            crate::lower::node_::Wx this_ = wx1_pp;
            this_.taken = append(this_.taken, Array(std::vector{inner_pi, prism_rtl::cat(name_po, "_adopt")}));
            this_.fields = crate::prelude::push(this_.fields, std::tuple{inner_pi, crate::lower::model::OutTy(crate::lower::model::OutTy::OutHold{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutDyn{prism_rtl::rc(t_ph)}))}))}), Text::lit("`@Flatten`\'s current inner: the dynamic of the generation it adopted")});
            this_.moves = crate::prelude::push(this_.moves, std::tuple{inner_pi, crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Hold::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XNone{}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
            this_.build = crate::prelude::push(this_.build, first_pj);
            this_.getters = crate::prelude::push(this_.getters, crate::lower::model::MethDef{.name = name_po, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = t_ph, .body = Array<crate::lower::model::Do>{}, .tail = sample_pk, .doc = Text::lit("`@Flatten`\'s dynamic: its current inner at the read point.")});
            this_.dyn_reads = insert(this_.dyn_reads, name_po, Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{inner_pi})}));
            this_.flattens = crate::prelude::push(this_.flattens, crate::lower::node_::FlatDef{.name = name_po, .outer = m_pf, .generation = gen_pg, .ty = t_ph});
            (std::move(this_));
        });
        return std::tuple{wx2_pl, crate::lower::node_::Wres(crate::lower::node_::Wres::WrDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), name_po, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{inner_pi})}), t_ph})};
    }
    prism_rtl::unreachable("no arm matched");
}


/// EntryFlatten: unbounded fn Wx, OutTy, ?Bn -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> entry_flatten(const crate::lower::node_::Wx& wx_p0, const crate::lower::model::OutTy& t_p1, const std::optional<crate::lower::types::Bn>& bound_o2) {
    auto [name_pa, wx1_pb] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Text, crate::lower::node_::Wx>> _v;
        if (prism_rtl::is_some(bound_o2) && prism_rtl::is<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(bound_o2))) {
            auto&& f_p8 = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(bound_o2)).a0;
            _v.set(std::tuple{f_p8, wx_p0});
            goto _done;
        }
        if (prism_rtl::is_some(bound_o2) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_o2)) && prism_rtl::is<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_o2)).a0)) {
            auto&& m27624_1_0_0 = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_o2)).a0).a0;
            auto&& f_p9 = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_o2)).a0).a1;
            if (prism_rtl::is<crate::lower::model::Ex::XSelf>(prism_rtl::deref(prism_rtl::deref(m27624_1_0_0)))) {
                _v.set(std::tuple{f_p9, wx_p0});
                goto _done;
            }
        }
        {
            _v.set(crate::lower::node_::fresh_name(wx_p0, Text::lit("flatten")));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto inner_p3 = prism_rtl::cat(name_pa, "_inner");
    auto follow_p4 = prism_rtl::cat(name_pa, "_follow");
    auto followed_p5 = crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), follow_p4})), Text::lit("follow"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), Text::lit("entry"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})), Text::lit("updates")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XPath{prism_rtl::cat(wx_p0.node_, "::", name_pa, "_moved")})})})});
    auto sample_p6 = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(inner_p3)})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})), Text::lit("expect"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{Text::lit("`@Flatten` adopts its first inner at the build")})})})), Text::lit("sample"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})});
    auto wx2_p7 = ({
        crate::lower::node_::Wx this_ = wx1_pb;
        this_.taken = append(this_.taken, Array(std::vector{inner_p3, follow_p4, prism_rtl::cat(name_pa, "_adopt"), prism_rtl::cat(name_pa, "_moved"), prism_rtl::cat(name_pa, "_replaced")}));
        this_.fields = append(this_.fields, Array(std::vector{std::tuple{inner_p3, crate::lower::model::OutTy(crate::lower::model::OutTy::OutHold{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutDyn{prism_rtl::rc(t_p1)}))}))}), Text::lit("`@Flatten`\'s current inner: the row\'s entry it adopted")}, std::tuple{follow_p4, crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("prism_rtl::Follow"), Array<crate::lower::model::OutTy>{}}), Text::lit("the subscription to the inner\'s update event")}}));
        this_.moves = append(this_.moves, Array(std::vector{std::tuple{inner_p3, crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Hold::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("value")}))})})}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})}, std::tuple{follow_p4, crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::Follow::new"), Array<crate::lower::model::Ex>{}})}}));
        this_.build = crate::prelude::push(this_.build, followed_p5);
        this_.getters = crate::prelude::push(this_.getters, crate::lower::model::MethDef{.name = name_pa, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = t_p1, .body = Array<crate::lower::model::Do>{}, .tail = sample_p6, .doc = Text::lit("`@Flatten`\'s dynamic: its current inner at the read point.")});
        this_.dyn_reads = insert(this_.dyn_reads, name_pa, Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{inner_p3})}));
        this_.flattens = crate::prelude::push(this_.flattens, crate::lower::node_::FlatDef{.name = name_pa, .outer = Text::lit("entry"), .generation = Text::lit(""), .ty = t_p1});
        (std::move(this_));
    });
    return std::tuple{wx2_p7, crate::lower::node_::Wres(crate::lower::node_::Wres::WrDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), name_pa, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{inner_p3})}), t_p1})};
}


/// SwitchLine: unbounded fn Wx, Env, [Arg] -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> switch_line(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const Array<crate::syntax::Arg>& args_p2) {
    auto&& _m = index(args_p2, Nat(0u));
    if (prism_rtl::is_some(_m)) {
        auto&& a_p3 = prism_rtl::some_of(_m);
        auto [r_p4, wx2_p5] = crate::lower::node_::dynamics::event_ref(wx_p0, menv_p1, a_p3->value);
        return std::tuple{wx2_p5, crate::lower::node_::Wres(crate::lower::node_::Wres::WrEv{r_p4})};
    }
    if (prism_rtl::is_none(_m)) {
        return std::tuple{wx_p0, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
    }
    prism_rtl::unreachable("no arm matched");
}

}  // namespace crate::lower::node_::switch_
