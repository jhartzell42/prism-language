// The root module: its functions' prototypes and its nodes and jobs, emitted by prismc
// (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include "program.types.hpp"
#include "elem.types.hpp"
#include "ast.types.hpp"
#include "check_blocks.types.hpp"
#include "check_env.types.hpp"
#include "check_errors.types.hpp"
#include "check_expr.types.hpp"
#include "check_passes.types.hpp"
#include "check_types.types.hpp"
#include "cpp_prelude_template.types.hpp"
#include "cpp_templates.types.hpp"
#include "emit.types.hpp"
#include "emit_cpp.types.hpp"
#include "fs.types.hpp"
#include "lexer.types.hpp"
#include "lower.types.hpp"
#include "parser.types.hpp"
#include "prelude_template.types.hpp"
#include "process.types.hpp"
#include "rust_templates.types.hpp"
#include "sexp.types.hpp"
#include "typed.types.hpp"

namespace crate {

using namespace prelude;

namespace program {

Outcome_ front_end(const Job_& job);

prism_rtl::JobRef<Outcome_> start_front_end(Job_ job);

bool any_errors(const Array<ast::Diag>& ds);

Text render_diags(const Text& text, const Array<ast::Diag>& ds);

Text render_diag(const Text& text, const Array<Nat>& starts, const ast::Diag& d);

Array<Nat> line_starts(const Text& text);

Nat line_of(const Array<Nat>& starts, const Nat& offset);

Array<Text> prelude_files();

std::optional<Text> option_value(const Array<Text>& args, const Text& name);

Array<Text> bad_options(const Array<Text>& args, const Array<Text>& flags, const Array<Text>& valued);

Array<Text> plain_args(const Array<Text>& args);

Outcome_ check_files(const CheckJob& job);

prism_rtl::JobRef<Outcome_> start_check_files(CheckJob job);

Text commented(const Text& t);

Array<Text> tag_families(const ast::Module& m);

bool any_in(const Array<Text>& xs, const Array<Text>& ys);

Text render_parse(const Text& path_, const Text& text, const Array<ast::Diag>& ds);

Text contents_text(const Fallible<fs::Contents>& arg0);

Array<Text> compile_valued();

bool is_source_path(const Text& f);

bool ends_with_text(const Text& t, const Text& suffix);

Text runtime_for(const Text& out);

Array<Text> compile_files(const Array<Text>& args);

Compiled compile_program(const CompileJob& job);

prism_rtl::JobRef<Compiled> start_compile_program(CompileJob job);

Array<Text> refusals(const Text& text);

ast::Module without_tests(const ast::Module& m);

ast::Decl without_patterns(const ast::Decl& d);

ast::CheckDecl check_without_patterns(const ast::CheckDecl& c);

ast::CheckLine line_without_pattern(const ast::CheckLine& l);

bool is_test_decl(const ast::Decl& d);

Text with_tests(const Text& path_, const Text& text, const Array<std::tuple<Text, Text>>& tests);

}  // namespace program


namespace program {

/// The step machine of `FrontEnd`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FrontEnd: unbounded fn Job -> Outcome
struct FrontEnd : prism_rtl::Job<Outcome_> {
    Job_ job;
    FrontEnd(Job_ job) : job(std::move(job)) {}
    prism_rtl::Turn<Outcome_> cycle() const override;
};


/// The step machine of `CheckFiles`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckFiles: unbounded fn CheckJob -> Outcome
struct CheckFiles : prism_rtl::Job<Outcome_> {
    CheckJob job;
    CheckFiles(CheckJob job) : job(std::move(job)) {}
    prism_rtl::Turn<Outcome_> cycle() const override;
};


/// `@main`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
/// @main:
///     args <- Process.Args
///     let checking = Fold args, False, \|seen, a| seen or a == "--check" or a == "--typed"
///     let compiling = (Or args[0], "") == "compile"
///     if compiling: @CompileMain (Drop args, 1)
///     else: if checking: @CheckMain args
///     else: @FrontMain args
/// ```
class Main : public Node {
public:
    Path path;
    /// place 0's answer, its first value
    Array<Text> args;
    /// `checking`
    bool checking;
    /// `compiling`
    bool compiling;
    /// the current generation of the `rebuild` at place 1
    std::optional<prism_rtl::Rc<Row>> arm;
    /// how many generations it has built
    std::uint32_t arm_count;
    /// its source changed since it was built
    bool arm_stale;
    Main(Path path, Array<Text> args, bool checking, bool compiling, std::optional<prism_rtl::Rc<Row>> arm, std::uint32_t arm_count, bool arm_stale) : path(std::move(path)), args(std::move(args)), checking(std::move(checking)), compiling(std::move(compiling)), arm(std::move(arm)), arm_count(std::move(arm_count)), arm_stale(std::move(arm_stale)) {}
    Main(const Main&) = delete;
    static Result<prism_rtl::Rc<Main>> make(Path path, Cx& cx);
    Unit arm_up(Unit v, Cx& cx);
    Done arm_build(Cx& cx);
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
};


/// `MainArmThen`: a node of its own (docs/backend.md, "A widget block").
class MainArmThen : public Row {
public:
    Path path;
    /// the generation's value, `_`
    Unit value;
    /// the node of the `rebuild`
    prism_rtl::Weak<Main> parent;
    /// `opts`
    Array<Text> opts;
    /// `bad`
    Array<Text> bad;
    /// `target`
    Text target;
    /// the current generation of the `rebuild` at place 0
    std::optional<prism_rtl::Rc<Row>> arm;
    /// how many generations it has built
    std::uint32_t arm_count;
    /// its source changed since it was built
    bool arm_stale;
    MainArmThen(Path path, Unit value, prism_rtl::Weak<Main> parent, Array<Text> opts, Array<Text> bad, Text target, std::optional<prism_rtl::Rc<Row>> arm, std::uint32_t arm_count, bool arm_stale) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), opts(std::move(opts)), bad(std::move(bad)), target(std::move(target)), arm(std::move(arm)), arm_count(std::move(arm_count)), arm_stale(std::move(arm_stale)) {}
    MainArmThen(const MainArmThen&) = delete;
    static Result<prism_rtl::Rc<MainArmThen>> make(Path path, Unit value, prism_rtl::Weak<Main> parent, Cx& cx);
    Unit arm_up(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done arm_build(Cx& cx);
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmThen`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmThen : public Row {
public:
    Path path;
    /// the generation's value, `_`
    Unit value;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmThen> parent;
    /// `why`
    Text why;
    /// `!started` as a value: the port it fires
    prism_rtl::Rc<Port<Unit>> started_2_v_port;
    /// `!~gaveUp` as a value: the port it fires
    prism_rtl::Rc<Port<Fallible<Unit>>> gave_up_v_port;
    MainArmThenArmThen(Path path, Unit value, prism_rtl::Weak<MainArmThen> parent, Text why, prism_rtl::Rc<Port<Unit>> started_2_v_port, prism_rtl::Rc<Port<Fallible<Unit>>> gave_up_v_port) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), why(std::move(why)), started_2_v_port(std::move(started_2_v_port)), gave_up_v_port(std::move(gave_up_v_port)) {}
    MainArmThenArmThen(const MainArmThenArmThen&) = delete;
    static Result<prism_rtl::Rc<MainArmThenArmThen>> make(Path path, Unit value, prism_rtl::Weak<MainArmThen> parent, Cx& cx);
    Unit started_2(Unit v, Cx& cx);
    Unit gave_up(Fallible<Unit> v, Cx& cx);
    Unit place_1(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done started(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmElse`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmElse : public Row {
public:
    Path path;
    /// the generation's value, `_`
    Unit value;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmThen> parent;
    /// the current generation of the `rebuild` at place 0
    std::optional<prism_rtl::Rc<Row>> arm;
    /// how many generations it has built
    std::uint32_t arm_count;
    /// its source changed since it was built
    bool arm_stale;
    MainArmThenArmElse(Path path, Unit value, prism_rtl::Weak<MainArmThen> parent, std::optional<prism_rtl::Rc<Row>> arm, std::uint32_t arm_count, bool arm_stale) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), arm(std::move(arm)), arm_count(std::move(arm_count)), arm_stale(std::move(arm_stale)) {}
    MainArmThenArmElse(const MainArmThenArmElse&) = delete;
    static Result<prism_rtl::Rc<MainArmThenArmElse>> make(Path path, Unit value, prism_rtl::Weak<MainArmThen> parent, Cx& cx);
    Unit arm_up(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done arm_build(Cx& cx);
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmElseArmThen`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmElseArmThen : public Row {
public:
    Path path;
    /// the generation's value, `_`
    Unit value;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmThenArmElse> parent;
    /// `why`
    Text why;
    /// `!started` as a value: the port it fires
    prism_rtl::Rc<Port<Unit>> started_2_v_port;
    /// `!~gaveUp` as a value: the port it fires
    prism_rtl::Rc<Port<Fallible<Unit>>> gave_up_v_port;
    MainArmThenArmElseArmThen(Path path, Unit value, prism_rtl::Weak<MainArmThenArmElse> parent, Text why, prism_rtl::Rc<Port<Unit>> started_2_v_port, prism_rtl::Rc<Port<Fallible<Unit>>> gave_up_v_port) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), why(std::move(why)), started_2_v_port(std::move(started_2_v_port)), gave_up_v_port(std::move(gave_up_v_port)) {}
    MainArmThenArmElseArmThen(const MainArmThenArmElseArmThen&) = delete;
    static Result<prism_rtl::Rc<MainArmThenArmElseArmThen>> make(Path path, Unit value, prism_rtl::Weak<MainArmThenArmElse> parent, Cx& cx);
    Unit started_2(Unit v, Cx& cx);
    Unit gave_up(Fallible<Unit> v, Cx& cx);
    Unit place_1(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done started(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmElseArmElse`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmElseArmElse : public Row {
public:
    Path path;
    /// the generation's value, `_`
    Unit value;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmThenArmElse> parent;
    /// `opts`
    Array<Text> opts;
    /// `named`
    Array<Text> named;
    /// `dirs`
    Array<Text> dirs;
    /// `files`
    Array<Text> files;
    /// `out`
    Text out;
    /// `settings`
    CompileSettings settings;
    /// the source of the `for` at place 0, cached (gap SR)
    Cache<Map<Nat, Text>> rows_source_cache;
    /// the rows of the `for` at place 0
    Map<Nat, prism_rtl::Rc<MainArmThenArmElseArmElseRow>> rows;
    /// the `for` at place 0's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    Snapshot<Map<Nat, Array<Text>>> rows_all_snap;
    /// the current generation of the `rebuild` at place 1
    std::optional<prism_rtl::Rc<Row>> generation;
    /// how many generations it has built
    std::uint32_t generation_count;
    /// its source changed since it was built
    bool generation_stale;
    MainArmThenArmElseArmElse(Path path, Unit value, prism_rtl::Weak<MainArmThenArmElse> parent, Array<Text> opts, Array<Text> named, Array<Text> dirs, Array<Text> files, Text out, CompileSettings settings, Cache<Map<Nat, Text>> rows_source_cache, Map<Nat, prism_rtl::Rc<MainArmThenArmElseArmElseRow>> rows, Snapshot<Map<Nat, Array<Text>>> rows_all_snap, std::optional<prism_rtl::Rc<Row>> generation, std::uint32_t generation_count, bool generation_stale) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), opts(std::move(opts)), named(std::move(named)), dirs(std::move(dirs)), files(std::move(files)), out(std::move(out)), settings(std::move(settings)), rows_source_cache(std::move(rows_source_cache)), rows(std::move(rows)), rows_all_snap(std::move(rows_all_snap)), generation(std::move(generation)), generation_count(std::move(generation_count)), generation_stale(std::move(generation_stale)) {}
    MainArmThenArmElseArmElse(const MainArmThenArmElseArmElse&) = delete;
    static Result<prism_rtl::Rc<MainArmThenArmElseArmElse>> make(Path path, Unit value, prism_rtl::Weak<MainArmThenArmElse> parent, Cx& cx);
    Unit generation_fired(Unit v, Cx& cx);
    Map<Nat, Text> rows_source(const Cx& cx) const;
    Map<Nat, Array<Text>> rows_all_now(const Cx& cx) const;
    Map<Nat, Array<Text>> rows_all(const Cx& cx) const;
    Unit generation_up(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Unit rows_all_moved(Cx& cx);
    Unit rows_all_publish(Cx& cx);
    Done rows_build(Cx& cx);
    Done generation_build(Cx& cx);
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmElseArmElseGen1`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmElseArmElseGen1 : public Row {
public:
    Path path;
    /// the generation's value, `_`
    Map<Nat, Array<Text>> value;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmThenArmElseArmElse> parent;
    /// `settings`
    CompileSettings settings;
    /// `files`
    Array<Text> files;
    /// `prelude`
    Array<Text> prelude;
    /// the source of the `for` at place 0, cached (gap SR)
    Cache<Map<Nat, Text>> rows_source_cache;
    /// the rows of the `for` at place 0
    Map<Nat, prism_rtl::Rc<MainArmThenArmElseArmElseGen1Row>> rows;
    /// the `for` at place 0's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    Snapshot<Map<Nat, Fallible<fs::Contents>>> rows_all_snap;
    /// the current generation of the `rebuild` at place 1
    std::optional<prism_rtl::Rc<Row>> generation;
    /// how many generations it has built
    std::uint32_t generation_count;
    /// its source changed since it was built
    bool generation_stale;
    MainArmThenArmElseArmElseGen1(Path path, Map<Nat, Array<Text>> value, prism_rtl::Weak<MainArmThenArmElseArmElse> parent, CompileSettings settings, Array<Text> files, Array<Text> prelude, Cache<Map<Nat, Text>> rows_source_cache, Map<Nat, prism_rtl::Rc<MainArmThenArmElseArmElseGen1Row>> rows, Snapshot<Map<Nat, Fallible<fs::Contents>>> rows_all_snap, std::optional<prism_rtl::Rc<Row>> generation, std::uint32_t generation_count, bool generation_stale) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), settings(std::move(settings)), files(std::move(files)), prelude(std::move(prelude)), rows_source_cache(std::move(rows_source_cache)), rows(std::move(rows)), rows_all_snap(std::move(rows_all_snap)), generation(std::move(generation)), generation_count(std::move(generation_count)), generation_stale(std::move(generation_stale)) {}
    MainArmThenArmElseArmElseGen1(const MainArmThenArmElseArmElseGen1&) = delete;
    static Result<prism_rtl::Rc<MainArmThenArmElseArmElseGen1>> make(Path path, Map<Nat, Array<Text>> value, prism_rtl::Weak<MainArmThenArmElseArmElse> parent, Cx& cx);
    Unit generation_fired(Unit v, Cx& cx);
    Map<Nat, Text> rows_source(const Cx& cx) const;
    Map<Nat, Fallible<fs::Contents>> rows_all_now(const Cx& cx) const;
    Map<Nat, Fallible<fs::Contents>> rows_all(const Cx& cx) const;
    Unit generation_up(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Unit rows_all_moved(Cx& cx);
    Unit rows_all_publish(Cx& cx);
    Done rows_build(Cx& cx);
    Done generation_build(Cx& cx);
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmElseArmElseGen1Gen1`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmElseArmElseGen1Gen1 : public Row {
public:
    Path path;
    /// the generation's value, `_`
    Map<Nat, Fallible<fs::Contents>> value;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmThenArmElseArmElseGen1> parent;
    /// `settings`
    CompileSettings settings;
    /// `files`
    Array<Text> files;
    /// `prelude`
    Array<Text> prelude;
    /// `contents`
    Map<Nat, Fallible<fs::Contents>> contents;
    /// `!done` as a value: the port it fires
    prism_rtl::Rc<Port<Compiled>> done_v_port;
    /// `n`
    Nat n;
    /// `texts`
    Array<Text> texts;
    /// `mine`
    Array<std::tuple<Text, Text>> mine;
    /// `theirs`
    Array<std::tuple<Text, Text>> theirs;
    /// `present`
    Array<std::tuple<Text, Text>> present;
    /// `@Run`'s job (`@Machine`'s state)
    Hold<prism_rtl::JobRef<Compiled>> run_job;
    /// `@Run`'s `!again`
    Defer<Unit> run_again;
    /// `run_turn`'s left input
    Stamped<Unit> run_turn_left;
    /// its right input
    Stamped<Unit> run_turn_right;
    /// `$?outcome`
    Hold<std::optional<Compiled>> outcome;
    /// the current generation of the `rebuild` at place 1
    std::optional<prism_rtl::Rc<Row>> generation;
    /// how many generations it has built
    std::uint32_t generation_count;
    /// its source changed since it was built
    bool generation_stale;
    /// The merges' height above the node's inputs.
    static constexpr std::uint32_t WAKE = 1;
    MainArmThenArmElseArmElseGen1Gen1(Path path, Map<Nat, Fallible<fs::Contents>> value, prism_rtl::Weak<MainArmThenArmElseArmElseGen1> parent, CompileSettings settings, Array<Text> files, Array<Text> prelude, Map<Nat, Fallible<fs::Contents>> contents, prism_rtl::Rc<Port<Compiled>> done_v_port, Nat n, Array<Text> texts, Array<std::tuple<Text, Text>> mine, Array<std::tuple<Text, Text>> theirs, Array<std::tuple<Text, Text>> present, Hold<prism_rtl::JobRef<Compiled>> run_job, Defer<Unit> run_again, Stamped<Unit> run_turn_left, Stamped<Unit> run_turn_right, Hold<std::optional<Compiled>> outcome, std::optional<prism_rtl::Rc<Row>> generation, std::uint32_t generation_count, bool generation_stale) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), settings(std::move(settings)), files(std::move(files)), prelude(std::move(prelude)), contents(std::move(contents)), done_v_port(std::move(done_v_port)), n(std::move(n)), texts(std::move(texts)), mine(std::move(mine)), theirs(std::move(theirs)), present(std::move(present)), run_job(std::move(run_job)), run_again(std::move(run_again)), run_turn_left(std::move(run_turn_left)), run_turn_right(std::move(run_turn_right)), outcome(std::move(outcome)), generation(std::move(generation)), generation_count(std::move(generation_count)), generation_stale(std::move(generation_stale)) {}
    MainArmThenArmElseArmElseGen1Gen1(const MainArmThenArmElseArmElseGen1Gen1&) = delete;
    static Result<prism_rtl::Rc<MainArmThenArmElseArmElseGen1Gen1>> make(Path path, Map<Nat, Fallible<fs::Contents>> value, prism_rtl::Weak<MainArmThenArmElseArmElseGen1> parent, Cx& cx);
    Unit done(Compiled v, Cx& cx);
    Unit run_started(Unit v, Cx& cx);
    Unit run_again_(Unit v, Cx& cx);
    Unit run_turn(Unit v, Cx& cx);
    Unit generation_fired(Unit v, Cx& cx);
    Unit generation_up(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done generation_build(Cx& cx);
    Done wake(Cx& cx) override;
    Done started(Cx& cx) override;
    Done deferred(Cx& cx) override;
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmElseArmElseGen1Gen1Gen0`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmElseArmElseGen1Gen1Gen0 : public Row {
public:
    Path path;
    /// `out`
    Text out;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1> parent;
    MainArmThenArmElseArmElseGen1Gen1Gen0(Path path, Text out, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1> parent) : path(std::move(path)), out(std::move(out)), parent(std::move(parent)) {}
    MainArmThenArmElseArmElseGen1Gen1Gen0(const MainArmThenArmElseArmElseGen1Gen1Gen0&) = delete;
    static Result<prism_rtl::Rc<MainArmThenArmElseArmElseGen1Gen1Gen0>> make(Path path, Text out, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1> parent, Cx& cx);
    Unit remove_places(Cx& cx) const;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmElseArmElseGen1Gen1Gen1`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmElseArmElseGen1Gen1Gen1 : public Row {
public:
    Path path;
    /// `out`
    Text out;
    /// `o`
    Compiled o;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1> parent;
    /// `!started` as a value: the port it fires
    prism_rtl::Rc<Port<Unit>> started_2_v_port;
    /// `!~verdict` as a value: the port it fires
    prism_rtl::Rc<Port<Fallible<Unit>>> verdict_v_port;
    /// the source of the `for` at place 0, cached (gap SR)
    Cache<Map<Nat, std::tuple<Text, Text>>> rows_source_cache;
    /// the rows of the `for` at place 0
    Map<Nat, prism_rtl::Rc<MainArmThenArmElseArmElseGen1Gen1Gen1Row>> rows;
    /// the `for` at place 0's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    Snapshot<Map<Nat, fs::WriteState>> rows_all_snap;
    MainArmThenArmElseArmElseGen1Gen1Gen1(Path path, Text out, Compiled o, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1> parent, prism_rtl::Rc<Port<Unit>> started_2_v_port, prism_rtl::Rc<Port<Fallible<Unit>>> verdict_v_port, Cache<Map<Nat, std::tuple<Text, Text>>> rows_source_cache, Map<Nat, prism_rtl::Rc<MainArmThenArmElseArmElseGen1Gen1Gen1Row>> rows, Snapshot<Map<Nat, fs::WriteState>> rows_all_snap) : path(std::move(path)), out(std::move(out)), o(std::move(o)), parent(std::move(parent)), started_2_v_port(std::move(started_2_v_port)), verdict_v_port(std::move(verdict_v_port)), rows_source_cache(std::move(rows_source_cache)), rows(std::move(rows)), rows_all_snap(std::move(rows_all_snap)) {}
    MainArmThenArmElseArmElseGen1Gen1Gen1(const MainArmThenArmElseArmElseGen1Gen1Gen1&) = delete;
    static Result<prism_rtl::Rc<MainArmThenArmElseArmElseGen1Gen1Gen1>> make(Path path, Text out, Compiled o, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1> parent, Cx& cx);
    Unit started_2(Unit v, Cx& cx);
    Unit verdict(Fallible<Unit> v, Cx& cx);
    Unit place_2(Unit v, Cx& cx);
    Map<Nat, std::tuple<Text, Text>> rows_source(const Cx& cx) const;
    Map<Nat, fs::WriteState> rows_all_now(const Cx& cx) const;
    Map<Nat, fs::WriteState> rows_all(const Cx& cx) const;
    Unit remove_places(Cx& cx) const;
    Unit rows_all_moved(Cx& cx);
    Unit rows_all_publish(Cx& cx);
    Done rows_build(Cx& cx);
    Done started(Cx& cx) override;
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmElseArmElseGen1Gen1Gen1Row`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmElseArmElseGen1Gen1Gen1Row : public Row {
public:
    Path path;
    /// the row's key
    Nat key;
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    std::optional<std::tuple<Text, Text>> left_entry;
    /// the node of the `for`
    prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1> parent;
    /// `out`, the block's
    Text out;
    /// pushed to place 0
    Hold<fs::WriteState> place_0;
    /// place 0's element, which pushes are keyed by
    Pod place_0_element;
    MainArmThenArmElseArmElseGen1Gen1Gen1Row(Path path, Nat key, std::optional<std::tuple<Text, Text>> left_entry, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1> parent, Text out, Hold<fs::WriteState> place_0, Pod place_0_element) : path(std::move(path)), key(std::move(key)), left_entry(std::move(left_entry)), parent(std::move(parent)), out(std::move(out)), place_0(std::move(place_0)), place_0_element(std::move(place_0_element)) {}
    MainArmThenArmElseArmElseGen1Gen1Gen1Row(const MainArmThenArmElseArmElseGen1Gen1Gen1Row&) = delete;
    static Result<prism_rtl::Rc<MainArmThenArmElseArmElseGen1Gen1Gen1Row>> make(Path path, Nat key, std::tuple<Text, Text> value, prism_rtl::Weak<MainArmThenArmElseArmElseGen1Gen1Gen1> parent, Text out, Cx& cx);
    crate::Elem output(const Cx& cx) const;
    std::tuple<Text, Text> entry(const Cx& cx) const;
    fs::WriteState result(const Cx& cx) const;
    Unit remove_places(Cx& cx) const;
    Done push(const Pod& element, const Pod& v, Cx& cx) override;
    Done patch(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmElseArmElseGen1Row`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmElseArmElseGen1Row : public Row {
public:
    Path path;
    /// the row's key
    Nat key;
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    std::optional<Text> left_entry;
    /// the node of the `for`
    prism_rtl::Weak<MainArmThenArmElseArmElseGen1> parent;
    /// pushed to place 0
    Hold<Fallible<fs::Contents>> place_0;
    /// place 0's element, which pushes are keyed by
    Pod place_0_element;
    MainArmThenArmElseArmElseGen1Row(Path path, Nat key, std::optional<Text> left_entry, prism_rtl::Weak<MainArmThenArmElseArmElseGen1> parent, Hold<Fallible<fs::Contents>> place_0, Pod place_0_element) : path(std::move(path)), key(std::move(key)), left_entry(std::move(left_entry)), parent(std::move(parent)), place_0(std::move(place_0)), place_0_element(std::move(place_0_element)) {}
    MainArmThenArmElseArmElseGen1Row(const MainArmThenArmElseArmElseGen1Row&) = delete;
    static Result<prism_rtl::Rc<MainArmThenArmElseArmElseGen1Row>> make(Path path, Nat key, Text value, prism_rtl::Weak<MainArmThenArmElseArmElseGen1> parent, Cx& cx);
    crate::Elem contents_(const Cx& cx) const;
    Text entry(const Cx& cx) const;
    Fallible<fs::Contents> result(const Cx& cx) const;
    Unit remove_places(Cx& cx) const;
    Done push(const Pod& element, const Pod& v, Cx& cx) override;
    Done patch(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmElseArmElseRow`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmElseArmElseRow : public Row {
public:
    Path path;
    /// the row's key
    Nat key;
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    std::optional<Text> left_entry;
    /// the node of the `for`
    prism_rtl::Weak<MainArmThenArmElseArmElse> parent;
    /// pushed to place 0
    Hold<Array<Text>> place_0;
    /// place 0's element, which pushes are keyed by
    Pod place_0_element;
    MainArmThenArmElseArmElseRow(Path path, Nat key, std::optional<Text> left_entry, prism_rtl::Weak<MainArmThenArmElseArmElse> parent, Hold<Array<Text>> place_0, Pod place_0_element) : path(std::move(path)), key(std::move(key)), left_entry(std::move(left_entry)), parent(std::move(parent)), place_0(std::move(place_0)), place_0_element(std::move(place_0_element)) {}
    MainArmThenArmElseArmElseRow(const MainArmThenArmElseArmElseRow&) = delete;
    static Result<prism_rtl::Rc<MainArmThenArmElseArmElseRow>> make(Path path, Nat key, Text value, prism_rtl::Weak<MainArmThenArmElseArmElse> parent, Cx& cx);
    crate::Elem list(const Cx& cx) const;
    Text entry(const Cx& cx) const;
    Array<Text> result(const Cx& cx) const;
    Unit remove_places(Cx& cx) const;
    Done push(const Pod& element, const Pod& v, Cx& cx) override;
    Done patch(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElse`: a node of its own (docs/backend.md, "A widget block").
class MainArmElse : public Row {
public:
    Path path;
    /// the generation's value, `_`
    Unit value;
    /// the node of the `rebuild`
    prism_rtl::Weak<Main> parent;
    /// the current generation of the `rebuild` at place 0
    std::optional<prism_rtl::Rc<Row>> arm;
    /// how many generations it has built
    std::uint32_t arm_count;
    /// its source changed since it was built
    bool arm_stale;
    MainArmElse(Path path, Unit value, prism_rtl::Weak<Main> parent, std::optional<prism_rtl::Rc<Row>> arm, std::uint32_t arm_count, bool arm_stale) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), arm(std::move(arm)), arm_count(std::move(arm_count)), arm_stale(std::move(arm_stale)) {}
    MainArmElse(const MainArmElse&) = delete;
    static Result<prism_rtl::Rc<MainArmElse>> make(Path path, Unit value, prism_rtl::Weak<Main> parent, Cx& cx);
    Unit arm_up(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done arm_build(Cx& cx);
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmThen`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmThen : public Row {
public:
    Path path;
    /// the generation's value, `_`
    Unit value;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmElse> parent;
    /// `args`
    Array<Text> args;
    /// `bad`
    Array<Text> bad;
    /// the current generation of the `rebuild` at place 0
    std::optional<prism_rtl::Rc<Row>> arm;
    /// how many generations it has built
    std::uint32_t arm_count;
    /// its source changed since it was built
    bool arm_stale;
    MainArmElseArmThen(Path path, Unit value, prism_rtl::Weak<MainArmElse> parent, Array<Text> args, Array<Text> bad, std::optional<prism_rtl::Rc<Row>> arm, std::uint32_t arm_count, bool arm_stale) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), args(std::move(args)), bad(std::move(bad)), arm(std::move(arm)), arm_count(std::move(arm_count)), arm_stale(std::move(arm_stale)) {}
    MainArmElseArmThen(const MainArmElseArmThen&) = delete;
    static Result<prism_rtl::Rc<MainArmElseArmThen>> make(Path path, Unit value, prism_rtl::Weak<MainArmElse> parent, Cx& cx);
    Unit arm_up(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done arm_build(Cx& cx);
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmThenArmThen`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmThenArmThen : public Row {
public:
    Path path;
    /// the generation's value, `_`
    Unit value;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmElseArmThen> parent;
    /// `why`
    Text why;
    /// `!started` as a value: the port it fires
    prism_rtl::Rc<Port<Unit>> started_2_v_port;
    /// `!~gaveUp` as a value: the port it fires
    prism_rtl::Rc<Port<Fallible<Unit>>> gave_up_v_port;
    MainArmElseArmThenArmThen(Path path, Unit value, prism_rtl::Weak<MainArmElseArmThen> parent, Text why, prism_rtl::Rc<Port<Unit>> started_2_v_port, prism_rtl::Rc<Port<Fallible<Unit>>> gave_up_v_port) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), why(std::move(why)), started_2_v_port(std::move(started_2_v_port)), gave_up_v_port(std::move(gave_up_v_port)) {}
    MainArmElseArmThenArmThen(const MainArmElseArmThenArmThen&) = delete;
    static Result<prism_rtl::Rc<MainArmElseArmThenArmThen>> make(Path path, Unit value, prism_rtl::Weak<MainArmElseArmThen> parent, Cx& cx);
    Unit started_2(Unit v, Cx& cx);
    Unit gave_up(Fallible<Unit> v, Cx& cx);
    Unit place_1(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done started(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmThenArmElse`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmThenArmElse : public Row {
public:
    Path path;
    /// the generation's value, `_`
    Unit value;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmElseArmThen> parent;
    /// `args`
    Array<Text> args;
    /// `files`
    Array<Text> files;
    /// `dir`
    Text dir;
    /// `?out`
    std::optional<Text> out;
    /// `world`
    Array<Text> world;
    /// `prelude`
    Array<Text> prelude;
    /// `paths`
    Array<Text> paths;
    /// the source of the `for` at place 0, cached (gap SR)
    Cache<Map<Nat, Text>> rows_source_cache;
    /// the rows of the `for` at place 0
    Map<Nat, prism_rtl::Rc<MainArmElseArmThenArmElseRow>> rows;
    /// the `for` at place 0's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    Snapshot<Map<Nat, Fallible<fs::Contents>>> rows_all_snap;
    /// the current generation of the `rebuild` at place 1
    std::optional<prism_rtl::Rc<Row>> generation;
    /// how many generations it has built
    std::uint32_t generation_count;
    /// its source changed since it was built
    bool generation_stale;
    MainArmElseArmThenArmElse(Path path, Unit value, prism_rtl::Weak<MainArmElseArmThen> parent, Array<Text> args, Array<Text> files, Text dir, std::optional<Text> out, Array<Text> world, Array<Text> prelude, Array<Text> paths, Cache<Map<Nat, Text>> rows_source_cache, Map<Nat, prism_rtl::Rc<MainArmElseArmThenArmElseRow>> rows, Snapshot<Map<Nat, Fallible<fs::Contents>>> rows_all_snap, std::optional<prism_rtl::Rc<Row>> generation, std::uint32_t generation_count, bool generation_stale) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), args(std::move(args)), files(std::move(files)), dir(std::move(dir)), out(std::move(out)), world(std::move(world)), prelude(std::move(prelude)), paths(std::move(paths)), rows_source_cache(std::move(rows_source_cache)), rows(std::move(rows)), rows_all_snap(std::move(rows_all_snap)), generation(std::move(generation)), generation_count(std::move(generation_count)), generation_stale(std::move(generation_stale)) {}
    MainArmElseArmThenArmElse(const MainArmElseArmThenArmElse&) = delete;
    static Result<prism_rtl::Rc<MainArmElseArmThenArmElse>> make(Path path, Unit value, prism_rtl::Weak<MainArmElseArmThen> parent, Cx& cx);
    Unit generation_fired(Unit v, Cx& cx);
    Map<Nat, Text> rows_source(const Cx& cx) const;
    Map<Nat, Fallible<fs::Contents>> rows_all_now(const Cx& cx) const;
    Map<Nat, Fallible<fs::Contents>> rows_all(const Cx& cx) const;
    Unit generation_up(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Unit rows_all_moved(Cx& cx);
    Unit rows_all_publish(Cx& cx);
    Done rows_build(Cx& cx);
    Done generation_build(Cx& cx);
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmThenArmElseGen1`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmThenArmElseGen1 : public Row {
public:
    Path path;
    /// the generation's value, `_`
    Map<Nat, Fallible<fs::Contents>> value;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmElseArmThenArmElse> parent;
    /// `files`
    Array<Text> files;
    /// `prelude`
    Array<Text> prelude;
    /// `world`
    Array<Text> world;
    /// `?out`
    std::optional<Text> out;
    /// `typed`
    bool typed;
    /// `unused`
    bool unused;
    /// `contents`
    Map<Nat, Fallible<fs::Contents>> contents;
    /// `!done` as a value: the port it fires
    prism_rtl::Rc<Port<Outcome_>> done_v_port;
    /// `n`
    Nat n;
    /// `texts`
    Array<Text> texts;
    /// `mine`
    Array<std::tuple<Text, Text>> mine;
    /// `theirs`
    Array<std::tuple<Text, Text>> theirs;
    /// `present`
    Array<std::tuple<Text, Text>> present;
    /// `job`
    CheckJob job;
    /// `@Run`'s job (`@Machine`'s state)
    Hold<prism_rtl::JobRef<Outcome_>> run_job;
    /// `@Run`'s `!again`
    Defer<Unit> run_again;
    /// `run_turn`'s left input
    Stamped<Unit> run_turn_left;
    /// its right input
    Stamped<Unit> run_turn_right;
    /// `$?outcome`
    Hold<std::optional<Outcome_>> outcome;
    /// the current generation of the `rebuild` at place 1
    std::optional<prism_rtl::Rc<Row>> generation;
    /// how many generations it has built
    std::uint32_t generation_count;
    /// its source changed since it was built
    bool generation_stale;
    /// The merges' height above the node's inputs.
    static constexpr std::uint32_t WAKE = 1;
    MainArmElseArmThenArmElseGen1(Path path, Map<Nat, Fallible<fs::Contents>> value, prism_rtl::Weak<MainArmElseArmThenArmElse> parent, Array<Text> files, Array<Text> prelude, Array<Text> world, std::optional<Text> out, bool typed, bool unused, Map<Nat, Fallible<fs::Contents>> contents, prism_rtl::Rc<Port<Outcome_>> done_v_port, Nat n, Array<Text> texts, Array<std::tuple<Text, Text>> mine, Array<std::tuple<Text, Text>> theirs, Array<std::tuple<Text, Text>> present, CheckJob job, Hold<prism_rtl::JobRef<Outcome_>> run_job, Defer<Unit> run_again, Stamped<Unit> run_turn_left, Stamped<Unit> run_turn_right, Hold<std::optional<Outcome_>> outcome, std::optional<prism_rtl::Rc<Row>> generation, std::uint32_t generation_count, bool generation_stale) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), files(std::move(files)), prelude(std::move(prelude)), world(std::move(world)), out(std::move(out)), typed(std::move(typed)), unused(std::move(unused)), contents(std::move(contents)), done_v_port(std::move(done_v_port)), n(std::move(n)), texts(std::move(texts)), mine(std::move(mine)), theirs(std::move(theirs)), present(std::move(present)), job(std::move(job)), run_job(std::move(run_job)), run_again(std::move(run_again)), run_turn_left(std::move(run_turn_left)), run_turn_right(std::move(run_turn_right)), outcome(std::move(outcome)), generation(std::move(generation)), generation_count(std::move(generation_count)), generation_stale(std::move(generation_stale)) {}
    MainArmElseArmThenArmElseGen1(const MainArmElseArmThenArmElseGen1&) = delete;
    static Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1>> make(Path path, Map<Nat, Fallible<fs::Contents>> value, prism_rtl::Weak<MainArmElseArmThenArmElse> parent, Cx& cx);
    Unit done(Outcome_ v, Cx& cx);
    Unit run_started(Unit v, Cx& cx);
    Unit run_again_(Unit v, Cx& cx);
    Unit run_turn(Unit v, Cx& cx);
    Unit generation_fired(Unit v, Cx& cx);
    Unit generation_up(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done generation_build(Cx& cx);
    Done wake(Cx& cx) override;
    Done started(Cx& cx) override;
    Done deferred(Cx& cx) override;
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmThenArmElseGen1Gen0`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmThenArmElseGen1Gen0 : public Row {
public:
    Path path;
    /// `?out`
    std::optional<Text> out;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmElseArmThenArmElseGen1> parent;
    MainArmElseArmThenArmElseGen1Gen0(Path path, std::optional<Text> out, prism_rtl::Weak<MainArmElseArmThenArmElseGen1> parent) : path(std::move(path)), out(std::move(out)), parent(std::move(parent)) {}
    MainArmElseArmThenArmElseGen1Gen0(const MainArmElseArmThenArmElseGen1Gen0&) = delete;
    static Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen0>> make(Path path, std::optional<Text> out, prism_rtl::Weak<MainArmElseArmThenArmElseGen1> parent, Cx& cx);
    Unit remove_places(Cx& cx) const;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmThenArmElseGen1Gen1`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmThenArmElseGen1Gen1 : public Row {
public:
    Path path;
    /// `?out`
    std::optional<Text> out;
    /// `o`
    Outcome_ o;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmElseArmThenArmElseGen1> parent;
    /// `!started` as a value: the port it fires
    prism_rtl::Rc<Port<Unit>> started_2_v_port;
    /// `!~verdict` as a value: the port it fires
    prism_rtl::Rc<Port<Fallible<Unit>>> verdict_v_port;
    /// the current generation of the `rebuild` at place 0
    std::optional<prism_rtl::Rc<Row>> generation;
    /// how many generations it has built
    std::uint32_t generation_count;
    /// its source changed since it was built
    bool generation_stale;
    MainArmElseArmThenArmElseGen1Gen1(Path path, std::optional<Text> out, Outcome_ o, prism_rtl::Weak<MainArmElseArmThenArmElseGen1> parent, prism_rtl::Rc<Port<Unit>> started_2_v_port, prism_rtl::Rc<Port<Fallible<Unit>>> verdict_v_port, std::optional<prism_rtl::Rc<Row>> generation, std::uint32_t generation_count, bool generation_stale) : path(std::move(path)), out(std::move(out)), o(std::move(o)), parent(std::move(parent)), started_2_v_port(std::move(started_2_v_port)), verdict_v_port(std::move(verdict_v_port)), generation(std::move(generation)), generation_count(std::move(generation_count)), generation_stale(std::move(generation_stale)) {}
    MainArmElseArmThenArmElseGen1Gen1(const MainArmElseArmThenArmElseGen1Gen1&) = delete;
    static Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1>> make(Path path, std::optional<Text> out, Outcome_ o, prism_rtl::Weak<MainArmElseArmThenArmElseGen1> parent, Cx& cx);
    Unit started_2(Unit v, Cx& cx);
    Unit verdict(Fallible<Unit> v, Cx& cx);
    Unit generation_fired(prism_rtl::Blueprint<crate::Elem, crate::Answer> v, Cx& cx);
    Unit place_2(Unit v, Cx& cx);
    Unit generation_up(prism_rtl::Blueprint<crate::Elem, crate::Answer> v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done generation_build(Cx& cx);
    Done started(Cx& cx) override;
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmThenArmElseGen1Gen1Gen0`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmThenArmElseGen1Gen1Gen0 : public Row {
public:
    Path path;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1> parent;
    MainArmElseArmThenArmElseGen1Gen1Gen0(Path path, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1> parent) : path(std::move(path)), parent(std::move(parent)) {}
    MainArmElseArmThenArmElseGen1Gen1Gen0(const MainArmElseArmThenArmElseGen1Gen1Gen0&) = delete;
    static Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Gen0>> make(Path path, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1> parent, Cx& cx);
    Unit remove_places(Cx& cx) const;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmThenArmElseGen1Gen1Gen1`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmThenArmElseGen1Gen1Gen1 : public Row {
public:
    Path path;
    /// `path`
    Text path_;
    /// `text`
    Text text;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1> parent;
    /// pushed to place 0
    Hold<fs::WriteState> place_0;
    /// place 0's element, which pushes are keyed by
    Pod place_0_element;
    MainArmElseArmThenArmElseGen1Gen1Gen1(Path path, Text path_, Text text, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1> parent, Hold<fs::WriteState> place_0, Pod place_0_element) : path(std::move(path)), path_(std::move(path_)), text(std::move(text)), parent(std::move(parent)), place_0(std::move(place_0)), place_0_element(std::move(place_0_element)) {}
    MainArmElseArmThenArmElseGen1Gen1Gen1(const MainArmElseArmThenArmElseGen1Gen1Gen1&) = delete;
    static Result<prism_rtl::Rc<MainArmElseArmThenArmElseGen1Gen1Gen1>> make(Path path, Text path_, Text text, prism_rtl::Weak<MainArmElseArmThenArmElseGen1Gen1> parent, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done push(const Pod& element, const Pod& v, Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmThenArmElseRow`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmThenArmElseRow : public Row {
public:
    Path path;
    /// the row's key
    Nat key;
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    std::optional<Text> left_entry;
    /// the node of the `for`
    prism_rtl::Weak<MainArmElseArmThenArmElse> parent;
    /// pushed to place 0
    Hold<Fallible<fs::Contents>> place_0;
    /// place 0's element, which pushes are keyed by
    Pod place_0_element;
    MainArmElseArmThenArmElseRow(Path path, Nat key, std::optional<Text> left_entry, prism_rtl::Weak<MainArmElseArmThenArmElse> parent, Hold<Fallible<fs::Contents>> place_0, Pod place_0_element) : path(std::move(path)), key(std::move(key)), left_entry(std::move(left_entry)), parent(std::move(parent)), place_0(std::move(place_0)), place_0_element(std::move(place_0_element)) {}
    MainArmElseArmThenArmElseRow(const MainArmElseArmThenArmElseRow&) = delete;
    static Result<prism_rtl::Rc<MainArmElseArmThenArmElseRow>> make(Path path, Nat key, Text value, prism_rtl::Weak<MainArmElseArmThenArmElse> parent, Cx& cx);
    crate::Elem contents_(const Cx& cx) const;
    Text entry(const Cx& cx) const;
    Fallible<fs::Contents> result(const Cx& cx) const;
    Unit remove_places(Cx& cx) const;
    Done push(const Pod& element, const Pod& v, Cx& cx) override;
    Done patch(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmElse`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmElse : public Row {
public:
    Path path;
    /// the generation's value, `_`
    Unit value;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmElse> parent;
    /// `args`
    Array<Text> args;
    /// `tokens`
    bool tokens;
    /// `fragment`
    bool fragment;
    /// `names`
    Array<Text> names;
    /// `file`
    Text file;
    /// `out`
    Text out;
    /// pushed to place 0
    Hold<Fallible<fs::Contents>> source;
    /// place 0's element, which pushes are keyed by
    Pod source_element;
    /// the current generation of the `rebuild` at place 1
    std::optional<prism_rtl::Rc<Row>> generation;
    /// how many generations it has built
    std::uint32_t generation_count;
    /// its source changed since it was built
    bool generation_stale;
    MainArmElseArmElse(Path path, Unit value, prism_rtl::Weak<MainArmElse> parent, Array<Text> args, bool tokens, bool fragment, Array<Text> names, Text file, Text out, Hold<Fallible<fs::Contents>> source, Pod source_element, std::optional<prism_rtl::Rc<Row>> generation, std::uint32_t generation_count, bool generation_stale) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), args(std::move(args)), tokens(std::move(tokens)), fragment(std::move(fragment)), names(std::move(names)), file(std::move(file)), out(std::move(out)), source(std::move(source)), source_element(std::move(source_element)), generation(std::move(generation)), generation_count(std::move(generation_count)), generation_stale(std::move(generation_stale)) {}
    MainArmElseArmElse(const MainArmElseArmElse&) = delete;
    static Result<prism_rtl::Rc<MainArmElseArmElse>> make(Path path, Unit value, prism_rtl::Weak<MainArmElse> parent, Cx& cx);
    Unit generation_fired(Unit v, Cx& cx);
    Unit generation_up(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done generation_build(Cx& cx);
    Done build(Cx& cx) override;
    Done push(const Pod& element, const Pod& v, Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmElseGen0`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmElseGen0 : public Row {
public:
    Path path;
    /// `job`
    Job_ job;
    /// `file`
    Text file;
    /// `out`
    Text out;
    /// `c`
    fs::Contents c;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmElseArmElse> parent;
    /// `!done` as a value: the port it fires
    prism_rtl::Rc<Port<Outcome_>> done_v_port;
    /// `full`
    Job_ full;
    /// `@Run`'s job (`@Machine`'s state)
    Hold<prism_rtl::JobRef<Outcome_>> run_job;
    /// `@Run`'s `!again`
    Defer<Unit> run_again;
    /// `run_turn`'s left input
    Stamped<Unit> run_turn_left;
    /// its right input
    Stamped<Unit> run_turn_right;
    /// `$?outcome`
    Hold<std::optional<Outcome_>> outcome;
    /// the current generation of the `rebuild` at place 1
    std::optional<prism_rtl::Rc<Row>> generation;
    /// how many generations it has built
    std::uint32_t generation_count;
    /// its source changed since it was built
    bool generation_stale;
    /// The merges' height above the node's inputs.
    static constexpr std::uint32_t WAKE = 1;
    MainArmElseArmElseGen0(Path path, Job_ job, Text file, Text out, fs::Contents c, prism_rtl::Weak<MainArmElseArmElse> parent, prism_rtl::Rc<Port<Outcome_>> done_v_port, Job_ full, Hold<prism_rtl::JobRef<Outcome_>> run_job, Defer<Unit> run_again, Stamped<Unit> run_turn_left, Stamped<Unit> run_turn_right, Hold<std::optional<Outcome_>> outcome, std::optional<prism_rtl::Rc<Row>> generation, std::uint32_t generation_count, bool generation_stale) : path(std::move(path)), job(std::move(job)), file(std::move(file)), out(std::move(out)), c(std::move(c)), parent(std::move(parent)), done_v_port(std::move(done_v_port)), full(std::move(full)), run_job(std::move(run_job)), run_again(std::move(run_again)), run_turn_left(std::move(run_turn_left)), run_turn_right(std::move(run_turn_right)), outcome(std::move(outcome)), generation(std::move(generation)), generation_count(std::move(generation_count)), generation_stale(std::move(generation_stale)) {}
    MainArmElseArmElseGen0(const MainArmElseArmElseGen0&) = delete;
    static Result<prism_rtl::Rc<MainArmElseArmElseGen0>> make(Path path, Job_ job, Text file, Text out, fs::Contents c, prism_rtl::Weak<MainArmElseArmElse> parent, Cx& cx);
    Unit done(Outcome_ v, Cx& cx);
    Unit run_started(Unit v, Cx& cx);
    Unit run_again_(Unit v, Cx& cx);
    Unit run_turn(Unit v, Cx& cx);
    Unit generation_fired(Unit v, Cx& cx);
    Unit generation_up(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done generation_build(Cx& cx);
    Done wake(Cx& cx) override;
    Done started(Cx& cx) override;
    Done deferred(Cx& cx) override;
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmElseGen0Gen0`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmElseGen0Gen0 : public Row {
public:
    Path path;
    /// `out`
    Text out;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmElseArmElseGen0> parent;
    MainArmElseArmElseGen0Gen0(Path path, Text out, prism_rtl::Weak<MainArmElseArmElseGen0> parent) : path(std::move(path)), out(std::move(out)), parent(std::move(parent)) {}
    MainArmElseArmElseGen0Gen0(const MainArmElseArmElseGen0Gen0&) = delete;
    static Result<prism_rtl::Rc<MainArmElseArmElseGen0Gen0>> make(Path path, Text out, prism_rtl::Weak<MainArmElseArmElseGen0> parent, Cx& cx);
    Unit remove_places(Cx& cx) const;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmElseGen0Gen1`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmElseGen0Gen1 : public Row {
public:
    Path path;
    /// `out`
    Text out;
    /// `o`
    Outcome_ o;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmElseArmElseGen0> parent;
    /// `!started` as a value: the port it fires
    prism_rtl::Rc<Port<Unit>> started_2_v_port;
    /// `!~verdict` as a value: the port it fires
    prism_rtl::Rc<Port<Fallible<Unit>>> verdict_v_port;
    /// pushed to place 0
    Hold<fs::WriteState> place_0;
    /// place 0's element, which pushes are keyed by
    Pod place_0_element;
    MainArmElseArmElseGen0Gen1(Path path, Text out, Outcome_ o, prism_rtl::Weak<MainArmElseArmElseGen0> parent, prism_rtl::Rc<Port<Unit>> started_2_v_port, prism_rtl::Rc<Port<Fallible<Unit>>> verdict_v_port, Hold<fs::WriteState> place_0, Pod place_0_element) : path(std::move(path)), out(std::move(out)), o(std::move(o)), parent(std::move(parent)), started_2_v_port(std::move(started_2_v_port)), verdict_v_port(std::move(verdict_v_port)), place_0(std::move(place_0)), place_0_element(std::move(place_0_element)) {}
    MainArmElseArmElseGen0Gen1(const MainArmElseArmElseGen0Gen1&) = delete;
    static Result<prism_rtl::Rc<MainArmElseArmElseGen0Gen1>> make(Path path, Text out, Outcome_ o, prism_rtl::Weak<MainArmElseArmElseGen0> parent, Cx& cx);
    Unit started_2(Unit v, Cx& cx);
    Unit verdict(Fallible<Unit> v, Cx& cx);
    Unit place_2(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done started(Cx& cx) override;
    Done push(const Pod& element, const Pod& v, Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmElseGen1`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmElseGen1 : public Row {
public:
    Path path;
    /// `job`
    Job_ job;
    /// `file`
    Text file;
    /// `out`
    Text out;
    /// `m`
    Text m;
    /// the node of the `rebuild`
    prism_rtl::Weak<MainArmElseArmElse> parent;
    /// `!started` as a value: the port it fires
    prism_rtl::Rc<Port<Unit>> started_2_v_port;
    /// `!~gaveUp` as a value: the port it fires
    prism_rtl::Rc<Port<Fallible<Unit>>> gave_up_v_port;
    MainArmElseArmElseGen1(Path path, Job_ job, Text file, Text out, Text m, prism_rtl::Weak<MainArmElseArmElse> parent, prism_rtl::Rc<Port<Unit>> started_2_v_port, prism_rtl::Rc<Port<Fallible<Unit>>> gave_up_v_port) : path(std::move(path)), job(std::move(job)), file(std::move(file)), out(std::move(out)), m(std::move(m)), parent(std::move(parent)), started_2_v_port(std::move(started_2_v_port)), gave_up_v_port(std::move(gave_up_v_port)) {}
    MainArmElseArmElseGen1(const MainArmElseArmElseGen1&) = delete;
    static Result<prism_rtl::Rc<MainArmElseArmElseGen1>> make(Path path, Job_ job, Text file, Text out, Text m, prism_rtl::Weak<MainArmElseArmElse> parent, Cx& cx);
    Unit started_2(Unit v, Cx& cx);
    Unit gave_up(Fallible<Unit> v, Cx& cx);
    Unit place_1(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done started(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// The step machine of `CompileProgram`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CompileProgram: unbounded fn CompileJob -> Compiled
struct CompileProgram : prism_rtl::Job<Compiled> {
    CompileJob job;
    CompileProgram(CompileJob job) : job(std::move(job)) {}
    prism_rtl::Turn<Compiled> cycle() const override;
};


}  // namespace program

}  // namespace crate
