// The root module: its functions' prototypes and its nodes and jobs, emitted by prismc
// (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include "program.types.hpp"
#include "elem.types.hpp"
#include "ast.types.hpp"
#include "check_blocks.types.hpp"
#include "check_env.types.hpp"
#include "check_errors.types.hpp"
#include "check_expr.types.hpp"
#include "check_passes.types.hpp"
#include "check_types.types.hpp"
#include "cpp_prelude_template.types.hpp"
#include "cpp_templates.types.hpp"
#include "emit.types.hpp"
#include "emit_cpp.types.hpp"
#include "fs.types.hpp"
#include "lexer.types.hpp"
#include "lower.types.hpp"
#include "parser.types.hpp"
#include "prelude_template.types.hpp"
#include "process.types.hpp"
#include "rust_templates.types.hpp"
#include "sexp.types.hpp"
#include "typed.types.hpp"

namespace crate {

using namespace prelude;

namespace program {

Outcome_ front_end(const Job_& job);

prism_rtl::JobRef<Outcome_> start_front_end(Job_ job);

bool any_errors(const Array<ast::Diag>& ds);

Text render_diags(const Text& text, const Array<ast::Diag>& ds);

Text render_diag(const Text& text, const Array<Nat>& starts, const ast::Diag& d);

Array<Nat> line_starts(const Text& text);

Nat line_of(const Array<Nat>& starts, const Nat& offset);

Array<Text> prelude_files();

std::optional<Text> option_value(const Array<Text>& args, const Text& name);

Array<Text> bad_options(const Array<Text>& args, const Array<Text>& flags, const Array<Text>& valued);

Array<Text> plain_args(const Array<Text>& args);

Outcome_ check_files(const CheckJob& job);

prism_rtl::JobRef<Outcome_> start_check_files(CheckJob job);

Text commented(const Text& t);

Array<Text> tag_families(const ast::Module& m);

bool any_in(const Array<Text>& xs, const Array<Text>& ys);

Text render_parse(const Text& path_, const Text& text, const Array<ast::Diag>& ds);

Text contents_text(const Fallible<fs::Contents>& arg0);

Array<Text> compile_valued();

bool is_source_path(const Text& f);

bool ends_with_text(const Text& t, const Text& suffix);

Text runtime_for(const Text& out);

Array<Text> compile_files(const Array<Text>& args);

Compiled compile_program(const CompileJob& job);

prism_rtl::JobRef<Compiled> start_compile_program(CompileJob job);

Array<Text> refusals(const Text& text);

ast::Module without_tests(const ast::Module& m);

ast::Decl without_patterns(const ast::Decl& d);

ast::CheckDecl check_without_patterns(const ast::CheckDecl& c);

ast::CheckLine line_without_pattern(const ast::CheckLine& l);

bool is_test_decl(const ast::Decl& d);

Text with_tests(const Text& path_, const Text& text, const Array<std::tuple<Text, Text>>& tests);

}  // namespace program


namespace program {

/// The step machine of `FrontEnd`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FrontEnd: unbounded fn Job -> Outcome
struct FrontEnd : prism_rtl::Job<Outcome_> {
    Job_ job;
    FrontEnd(Job_ job) : job(std::move(job)) {}
    prism_rtl::Turn<Outcome_> cycle() const override;
};


/// The step machine of `CheckFiles`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckFiles: unbounded fn CheckJob -> Outcome
struct CheckFiles : prism_rtl::Job<Outcome_> {
    CheckJob job;
    CheckFiles(CheckJob job) : job(std::move(job)) {}
    prism_rtl::Turn<Outcome_> cycle() const override;
};


/// `@main`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
/// @main:
///     args <- Process.Args
///     let checking = Fold args, False, \|seen, a| seen or a == "--check" or a == "--typed"
///     let compiling = (Or args[0], "") == "compile"
///     if compiling: @CompileMain (Drop args, 1)
///     else: if checking: @CheckMain args
///     else: @FrontMain args
/// ```
class Main : public Node {
public:
    Path path;
    /// place 0's answer, its first value
    mutable Array<Text> args;
    /// `checking`
    mutable bool checking;
    /// `compiling`
    mutable bool compiling;
    /// the current generation of the `rebuild` at place 1
    mutable std::optional<std::shared_ptr<Row>> arm;
    /// how many generations it has built
    mutable std::uint32_t arm_count;
    /// its source changed since it was built
    mutable bool arm_stale;
    Main(Path path, Array<Text> args, bool checking, bool compiling, std::optional<std::shared_ptr<Row>> arm, std::uint32_t arm_count, bool arm_stale) : path(std::move(path)), args(std::move(args)), checking(std::move(checking)), compiling(std::move(compiling)), arm(std::move(arm)), arm_count(std::move(arm_count)), arm_stale(std::move(arm_stale)) {}
    Main(const Main&) = delete;
    static Result<std::shared_ptr<Main>> make(Path path, Cx& cx);
    Unit arm_up(Unit v, Cx& cx);
    Done arm_build(Cx& cx);
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
};


/// `MainArmThen`: a node of its own (docs/backend.md, "A widget block").
class MainArmThen : public Row {
public:
    Path path;
    /// the generation's value, `_`
    mutable Unit value;
    /// the node of the `rebuild`
    mutable std::weak_ptr<Main> parent;
    /// `opts`
    mutable Array<Text> opts;
    /// `bad`
    mutable Array<Text> bad;
    /// `target`
    mutable Text target;
    /// the current generation of the `rebuild` at place 0
    mutable std::optional<std::shared_ptr<Row>> arm;
    /// how many generations it has built
    mutable std::uint32_t arm_count;
    /// its source changed since it was built
    mutable bool arm_stale;
    MainArmThen(Path path, Unit value, std::weak_ptr<Main> parent, Array<Text> opts, Array<Text> bad, Text target, std::optional<std::shared_ptr<Row>> arm, std::uint32_t arm_count, bool arm_stale) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), opts(std::move(opts)), bad(std::move(bad)), target(std::move(target)), arm(std::move(arm)), arm_count(std::move(arm_count)), arm_stale(std::move(arm_stale)) {}
    MainArmThen(const MainArmThen&) = delete;
    static Result<std::shared_ptr<MainArmThen>> make(Path path, Unit value, std::weak_ptr<Main> parent, Cx& cx);
    Unit arm_up(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done arm_build(Cx& cx);
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmThen`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmThen : public Row {
public:
    Path path;
    /// the generation's value, `_`
    mutable Unit value;
    /// the node of the `rebuild`
    mutable std::weak_ptr<MainArmThen> parent;
    /// `why`
    mutable Text why;
    /// `!started` as a value: the port it fires
    mutable std::shared_ptr<Port<Unit>> started_2_v_port;
    /// `!~gaveUp` as a value: the port it fires
    mutable std::shared_ptr<Port<Fallible<Unit>>> gave_up_v_port;
    MainArmThenArmThen(Path path, Unit value, std::weak_ptr<MainArmThen> parent, Text why, std::shared_ptr<Port<Unit>> started_2_v_port, std::shared_ptr<Port<Fallible<Unit>>> gave_up_v_port) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), why(std::move(why)), started_2_v_port(std::move(started_2_v_port)), gave_up_v_port(std::move(gave_up_v_port)) {}
    MainArmThenArmThen(const MainArmThenArmThen&) = delete;
    static Result<std::shared_ptr<MainArmThenArmThen>> make(Path path, Unit value, std::weak_ptr<MainArmThen> parent, Cx& cx);
    Unit started_2(Unit v, Cx& cx);
    Unit gave_up(Fallible<Unit> v, Cx& cx);
    Unit place_1(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done started(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmElse`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmElse : public Row {
public:
    Path path;
    /// the generation's value, `_`
    mutable Unit value;
    /// the node of the `rebuild`
    mutable std::weak_ptr<MainArmThen> parent;
    /// the current generation of the `rebuild` at place 0
    mutable std::optional<std::shared_ptr<Row>> arm;
    /// how many generations it has built
    mutable std::uint32_t arm_count;
    /// its source changed since it was built
    mutable bool arm_stale;
    MainArmThenArmElse(Path path, Unit value, std::weak_ptr<MainArmThen> parent, std::optional<std::shared_ptr<Row>> arm, std::uint32_t arm_count, bool arm_stale) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), arm(std::move(arm)), arm_count(std::move(arm_count)), arm_stale(std::move(arm_stale)) {}
    MainArmThenArmElse(const MainArmThenArmElse&) = delete;
    static Result<std::shared_ptr<MainArmThenArmElse>> make(Path path, Unit value, std::weak_ptr<MainArmThen> parent, Cx& cx);
    Unit arm_up(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done arm_build(Cx& cx);
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmElseArmThen`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmElseArmThen : public Row {
public:
    Path path;
    /// the generation's value, `_`
    mutable Unit value;
    /// the node of the `rebuild`
    mutable std::weak_ptr<MainArmThenArmElse> parent;
    /// `why`
    mutable Text why;
    /// `!started` as a value: the port it fires
    mutable std::shared_ptr<Port<Unit>> started_2_v_port;
    /// `!~gaveUp` as a value: the port it fires
    mutable std::shared_ptr<Port<Fallible<Unit>>> gave_up_v_port;
    MainArmThenArmElseArmThen(Path path, Unit value, std::weak_ptr<MainArmThenArmElse> parent, Text why, std::shared_ptr<Port<Unit>> started_2_v_port, std::shared_ptr<Port<Fallible<Unit>>> gave_up_v_port) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), why(std::move(why)), started_2_v_port(std::move(started_2_v_port)), gave_up_v_port(std::move(gave_up_v_port)) {}
    MainArmThenArmElseArmThen(const MainArmThenArmElseArmThen&) = delete;
    static Result<std::shared_ptr<MainArmThenArmElseArmThen>> make(Path path, Unit value, std::weak_ptr<MainArmThenArmElse> parent, Cx& cx);
    Unit started_2(Unit v, Cx& cx);
    Unit gave_up(Fallible<Unit> v, Cx& cx);
    Unit place_1(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done started(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmElseArmElse`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmElseArmElse : public Row {
public:
    Path path;
    /// the generation's value, `_`
    mutable Unit value;
    /// the node of the `rebuild`
    mutable std::weak_ptr<MainArmThenArmElse> parent;
    /// `opts`
    mutable Array<Text> opts;
    /// `named`
    mutable Array<Text> named;
    /// `dirs`
    mutable Array<Text> dirs;
    /// `files`
    mutable Array<Text> files;
    /// `out`
    mutable Text out;
    /// `settings`
    mutable CompileSettings settings;
    /// the source of the `for` at place 0, cached (gap SR)
    mutable Cache<Map<Nat, Text>> rows_source_cache;
    /// the rows of the `for` at place 0
    mutable Map<Nat, std::shared_ptr<MainArmThenArmElseArmElseRow>> rows;
    /// the `for` at place 0's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    mutable Snapshot<Map<Nat, Array<Text>>> rows_all_snap;
    /// the current generation of the `rebuild` at place 1
    mutable std::optional<std::shared_ptr<Row>> generation;
    /// how many generations it has built
    mutable std::uint32_t generation_count;
    /// its source changed since it was built
    mutable bool generation_stale;
    MainArmThenArmElseArmElse(Path path, Unit value, std::weak_ptr<MainArmThenArmElse> parent, Array<Text> opts, Array<Text> named, Array<Text> dirs, Array<Text> files, Text out, CompileSettings settings, Cache<Map<Nat, Text>> rows_source_cache, Map<Nat, std::shared_ptr<MainArmThenArmElseArmElseRow>> rows, Snapshot<Map<Nat, Array<Text>>> rows_all_snap, std::optional<std::shared_ptr<Row>> generation, std::uint32_t generation_count, bool generation_stale) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), opts(std::move(opts)), named(std::move(named)), dirs(std::move(dirs)), files(std::move(files)), out(std::move(out)), settings(std::move(settings)), rows_source_cache(std::move(rows_source_cache)), rows(std::move(rows)), rows_all_snap(std::move(rows_all_snap)), generation(std::move(generation)), generation_count(std::move(generation_count)), generation_stale(std::move(generation_stale)) {}
    MainArmThenArmElseArmElse(const MainArmThenArmElseArmElse&) = delete;
    static Result<std::shared_ptr<MainArmThenArmElseArmElse>> make(Path path, Unit value, std::weak_ptr<MainArmThenArmElse> parent, Cx& cx);
    Unit generation_fired(Unit v, Cx& cx);
    Map<Nat, Text> rows_source(const Cx& cx) const;
    Map<Nat, Array<Text>> rows_all_now(const Cx& cx) const;
    Map<Nat, Array<Text>> rows_all(const Cx& cx) const;
    Unit generation_up(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Unit rows_all_moved(Cx& cx);
    Unit rows_all_publish(Cx& cx);
    Done rows_build(Cx& cx);
    Done generation_build(Cx& cx);
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmElseArmElseGen1`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmElseArmElseGen1 : public Row {
public:
    Path path;
    /// the generation's value, `_`
    mutable Map<Nat, Array<Text>> value;
    /// the node of the `rebuild`
    mutable std::weak_ptr<MainArmThenArmElseArmElse> parent;
    /// `settings`
    mutable CompileSettings settings;
    /// `files`
    mutable Array<Text> files;
    /// `prelude`
    mutable Array<Text> prelude;
    /// the source of the `for` at place 0, cached (gap SR)
    mutable Cache<Map<Nat, Text>> rows_source_cache;
    /// the rows of the `for` at place 0
    mutable Map<Nat, std::shared_ptr<MainArmThenArmElseArmElseGen1Row>> rows;
    /// the `for` at place 0's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    mutable Snapshot<Map<Nat, Fallible<fs::Contents>>> rows_all_snap;
    /// the current generation of the `rebuild` at place 1
    mutable std::optional<std::shared_ptr<Row>> generation;
    /// how many generations it has built
    mutable std::uint32_t generation_count;
    /// its source changed since it was built
    mutable bool generation_stale;
    MainArmThenArmElseArmElseGen1(Path path, Map<Nat, Array<Text>> value, std::weak_ptr<MainArmThenArmElseArmElse> parent, CompileSettings settings, Array<Text> files, Array<Text> prelude, Cache<Map<Nat, Text>> rows_source_cache, Map<Nat, std::shared_ptr<MainArmThenArmElseArmElseGen1Row>> rows, Snapshot<Map<Nat, Fallible<fs::Contents>>> rows_all_snap, std::optional<std::shared_ptr<Row>> generation, std::uint32_t generation_count, bool generation_stale) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), settings(std::move(settings)), files(std::move(files)), prelude(std::move(prelude)), rows_source_cache(std::move(rows_source_cache)), rows(std::move(rows)), rows_all_snap(std::move(rows_all_snap)), generation(std::move(generation)), generation_count(std::move(generation_count)), generation_stale(std::move(generation_stale)) {}
    MainArmThenArmElseArmElseGen1(const MainArmThenArmElseArmElseGen1&) = delete;
    static Result<std::shared_ptr<MainArmThenArmElseArmElseGen1>> make(Path path, Map<Nat, Array<Text>> value, std::weak_ptr<MainArmThenArmElseArmElse> parent, Cx& cx);
    Unit generation_fired(Unit v, Cx& cx);
    Map<Nat, Text> rows_source(const Cx& cx) const;
    Map<Nat, Fallible<fs::Contents>> rows_all_now(const Cx& cx) const;
    Map<Nat, Fallible<fs::Contents>> rows_all(const Cx& cx) const;
    Unit generation_up(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Unit rows_all_moved(Cx& cx);
    Unit rows_all_publish(Cx& cx);
    Done rows_build(Cx& cx);
    Done generation_build(Cx& cx);
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmElseArmElseGen1Gen1`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmElseArmElseGen1Gen1 : public Row {
public:
    Path path;
    /// the generation's value, `_`
    mutable Map<Nat, Fallible<fs::Contents>> value;
    /// the node of the `rebuild`
    mutable std::weak_ptr<MainArmThenArmElseArmElseGen1> parent;
    /// `settings`
    mutable CompileSettings settings;
    /// `files`
    mutable Array<Text> files;
    /// `prelude`
    mutable Array<Text> prelude;
    /// `contents`
    mutable Map<Nat, Fallible<fs::Contents>> contents;
    /// `!done` as a value: the port it fires
    mutable std::shared_ptr<Port<Compiled>> done_v_port;
    /// `n`
    mutable Nat n;
    /// `texts`
    mutable Array<Text> texts;
    /// `mine`
    mutable Array<std::tuple<Text, Text>> mine;
    /// `theirs`
    mutable Array<std::tuple<Text, Text>> theirs;
    /// `present`
    mutable Array<std::tuple<Text, Text>> present;
    /// `@Run`'s job (`@Machine`'s state)
    mutable Hold<prism_rtl::JobRef<Compiled>> run_job;
    /// `@Run`'s `!again`
    mutable Defer<Unit> run_again;
    /// `run_turn`'s left input
    mutable Stamped<Unit> run_turn_left;
    /// its right input
    mutable Stamped<Unit> run_turn_right;
    /// `$?outcome`
    mutable Hold<std::optional<Compiled>> outcome;
    /// the current generation of the `rebuild` at place 1
    mutable std::optional<std::shared_ptr<Row>> generation;
    /// how many generations it has built
    mutable std::uint32_t generation_count;
    /// its source changed since it was built
    mutable bool generation_stale;
    /// The merges' height above the node's inputs.
    static constexpr std::uint32_t WAKE = 1;
    MainArmThenArmElseArmElseGen1Gen1(Path path, Map<Nat, Fallible<fs::Contents>> value, std::weak_ptr<MainArmThenArmElseArmElseGen1> parent, CompileSettings settings, Array<Text> files, Array<Text> prelude, Map<Nat, Fallible<fs::Contents>> contents, std::shared_ptr<Port<Compiled>> done_v_port, Nat n, Array<Text> texts, Array<std::tuple<Text, Text>> mine, Array<std::tuple<Text, Text>> theirs, Array<std::tuple<Text, Text>> present, Hold<prism_rtl::JobRef<Compiled>> run_job, Defer<Unit> run_again, Stamped<Unit> run_turn_left, Stamped<Unit> run_turn_right, Hold<std::optional<Compiled>> outcome, std::optional<std::shared_ptr<Row>> generation, std::uint32_t generation_count, bool generation_stale) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), settings(std::move(settings)), files(std::move(files)), prelude(std::move(prelude)), contents(std::move(contents)), done_v_port(std::move(done_v_port)), n(std::move(n)), texts(std::move(texts)), mine(std::move(mine)), theirs(std::move(theirs)), present(std::move(present)), run_job(std::move(run_job)), run_again(std::move(run_again)), run_turn_left(std::move(run_turn_left)), run_turn_right(std::move(run_turn_right)), outcome(std::move(outcome)), generation(std::move(generation)), generation_count(std::move(generation_count)), generation_stale(std::move(generation_stale)) {}
    MainArmThenArmElseArmElseGen1Gen1(const MainArmThenArmElseArmElseGen1Gen1&) = delete;
    static Result<std::shared_ptr<MainArmThenArmElseArmElseGen1Gen1>> make(Path path, Map<Nat, Fallible<fs::Contents>> value, std::weak_ptr<MainArmThenArmElseArmElseGen1> parent, Cx& cx);
    Unit done(Compiled v, Cx& cx);
    Unit run_started(Unit v, Cx& cx);
    Unit run_again_(Unit v, Cx& cx);
    Unit run_turn(Unit v, Cx& cx);
    Unit generation_fired(Unit v, Cx& cx);
    Unit generation_up(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done generation_build(Cx& cx);
    Done wake(Cx& cx) override;
    Done started(Cx& cx) override;
    Done deferred(Cx& cx) override;
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmElseArmElseGen1Gen1Gen0`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmElseArmElseGen1Gen1Gen0 : public Row {
public:
    Path path;
    /// `out`
    mutable Text out;
    /// the node of the `rebuild`
    mutable std::weak_ptr<MainArmThenArmElseArmElseGen1Gen1> parent;
    MainArmThenArmElseArmElseGen1Gen1Gen0(Path path, Text out, std::weak_ptr<MainArmThenArmElseArmElseGen1Gen1> parent) : path(std::move(path)), out(std::move(out)), parent(std::move(parent)) {}
    MainArmThenArmElseArmElseGen1Gen1Gen0(const MainArmThenArmElseArmElseGen1Gen1Gen0&) = delete;
    static Result<std::shared_ptr<MainArmThenArmElseArmElseGen1Gen1Gen0>> make(Path path, Text out, std::weak_ptr<MainArmThenArmElseArmElseGen1Gen1> parent, Cx& cx);
    Unit remove_places(Cx& cx) const;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmElseArmElseGen1Gen1Gen1`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmElseArmElseGen1Gen1Gen1 : public Row {
public:
    Path path;
    /// `out`
    mutable Text out;
    /// `o`
    mutable Compiled o;
    /// the node of the `rebuild`
    mutable std::weak_ptr<MainArmThenArmElseArmElseGen1Gen1> parent;
    /// `!started` as a value: the port it fires
    mutable std::shared_ptr<Port<Unit>> started_2_v_port;
    /// `!~verdict` as a value: the port it fires
    mutable std::shared_ptr<Port<Fallible<Unit>>> verdict_v_port;
    /// the source of the `for` at place 0, cached (gap SR)
    mutable Cache<Map<Nat, std::tuple<Text, Text>>> rows_source_cache;
    /// the rows of the `for` at place 0
    mutable Map<Nat, std::shared_ptr<MainArmThenArmElseArmElseGen1Gen1Gen1Row>> rows;
    /// the `for` at place 0's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    mutable Snapshot<Map<Nat, fs::WriteState>> rows_all_snap;
    MainArmThenArmElseArmElseGen1Gen1Gen1(Path path, Text out, Compiled o, std::weak_ptr<MainArmThenArmElseArmElseGen1Gen1> parent, std::shared_ptr<Port<Unit>> started_2_v_port, std::shared_ptr<Port<Fallible<Unit>>> verdict_v_port, Cache<Map<Nat, std::tuple<Text, Text>>> rows_source_cache, Map<Nat, std::shared_ptr<MainArmThenArmElseArmElseGen1Gen1Gen1Row>> rows, Snapshot<Map<Nat, fs::WriteState>> rows_all_snap) : path(std::move(path)), out(std::move(out)), o(std::move(o)), parent(std::move(parent)), started_2_v_port(std::move(started_2_v_port)), verdict_v_port(std::move(verdict_v_port)), rows_source_cache(std::move(rows_source_cache)), rows(std::move(rows)), rows_all_snap(std::move(rows_all_snap)) {}
    MainArmThenArmElseArmElseGen1Gen1Gen1(const MainArmThenArmElseArmElseGen1Gen1Gen1&) = delete;
    static Result<std::shared_ptr<MainArmThenArmElseArmElseGen1Gen1Gen1>> make(Path path, Text out, Compiled o, std::weak_ptr<MainArmThenArmElseArmElseGen1Gen1> parent, Cx& cx);
    Unit started_2(Unit v, Cx& cx);
    Unit verdict(Fallible<Unit> v, Cx& cx);
    Unit place_2(Unit v, Cx& cx);
    Map<Nat, std::tuple<Text, Text>> rows_source(const Cx& cx) const;
    Map<Nat, fs::WriteState> rows_all_now(const Cx& cx) const;
    Map<Nat, fs::WriteState> rows_all(const Cx& cx) const;
    Unit remove_places(Cx& cx) const;
    Unit rows_all_moved(Cx& cx);
    Unit rows_all_publish(Cx& cx);
    Done rows_build(Cx& cx);
    Done started(Cx& cx) override;
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmElseArmElseGen1Gen1Gen1Row`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmElseArmElseGen1Gen1Gen1Row : public Row {
public:
    Path path;
    /// the row's key
    mutable Nat key;
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    mutable std::optional<std::tuple<Text, Text>> left_entry;
    /// the node of the `for`
    mutable std::weak_ptr<MainArmThenArmElseArmElseGen1Gen1Gen1> parent;
    /// `out`, the block's
    mutable Text out;
    /// pushed to place 0
    mutable Hold<fs::WriteState> place_0;
    /// place 0's element, which pushes are keyed by
    mutable Pod place_0_element;
    MainArmThenArmElseArmElseGen1Gen1Gen1Row(Path path, Nat key, std::optional<std::tuple<Text, Text>> left_entry, std::weak_ptr<MainArmThenArmElseArmElseGen1Gen1Gen1> parent, Text out, Hold<fs::WriteState> place_0, Pod place_0_element) : path(std::move(path)), key(std::move(key)), left_entry(std::move(left_entry)), parent(std::move(parent)), out(std::move(out)), place_0(std::move(place_0)), place_0_element(std::move(place_0_element)) {}
    MainArmThenArmElseArmElseGen1Gen1Gen1Row(const MainArmThenArmElseArmElseGen1Gen1Gen1Row&) = delete;
    static Result<std::shared_ptr<MainArmThenArmElseArmElseGen1Gen1Gen1Row>> make(Path path, Nat key, std::tuple<Text, Text> value, std::weak_ptr<MainArmThenArmElseArmElseGen1Gen1Gen1> parent, Text out, Cx& cx);
    crate::Elem output(const Cx& cx) const;
    std::tuple<Text, Text> entry(const Cx& cx) const;
    fs::WriteState result(const Cx& cx) const;
    Unit remove_places(Cx& cx) const;
    Done push(const Pod& element, const Pod& v, Cx& cx) override;
    Done patch(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmElseArmElseGen1Row`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmElseArmElseGen1Row : public Row {
public:
    Path path;
    /// the row's key
    mutable Nat key;
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    mutable std::optional<Text> left_entry;
    /// the node of the `for`
    mutable std::weak_ptr<MainArmThenArmElseArmElseGen1> parent;
    /// pushed to place 0
    mutable Hold<Fallible<fs::Contents>> place_0;
    /// place 0's element, which pushes are keyed by
    mutable Pod place_0_element;
    MainArmThenArmElseArmElseGen1Row(Path path, Nat key, std::optional<Text> left_entry, std::weak_ptr<MainArmThenArmElseArmElseGen1> parent, Hold<Fallible<fs::Contents>> place_0, Pod place_0_element) : path(std::move(path)), key(std::move(key)), left_entry(std::move(left_entry)), parent(std::move(parent)), place_0(std::move(place_0)), place_0_element(std::move(place_0_element)) {}
    MainArmThenArmElseArmElseGen1Row(const MainArmThenArmElseArmElseGen1Row&) = delete;
    static Result<std::shared_ptr<MainArmThenArmElseArmElseGen1Row>> make(Path path, Nat key, Text value, std::weak_ptr<MainArmThenArmElseArmElseGen1> parent, Cx& cx);
    crate::Elem contents_(const Cx& cx) const;
    Text entry(const Cx& cx) const;
    Fallible<fs::Contents> result(const Cx& cx) const;
    Unit remove_places(Cx& cx) const;
    Done push(const Pod& element, const Pod& v, Cx& cx) override;
    Done patch(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmThenArmElseArmElseRow`: a node of its own (docs/backend.md, "A widget block").
class MainArmThenArmElseArmElseRow : public Row {
public:
    Path path;
    /// the row's key
    mutable Nat key;
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    mutable std::optional<Text> left_entry;
    /// the node of the `for`
    mutable std::weak_ptr<MainArmThenArmElseArmElse> parent;
    /// pushed to place 0
    mutable Hold<Array<Text>> place_0;
    /// place 0's element, which pushes are keyed by
    mutable Pod place_0_element;
    MainArmThenArmElseArmElseRow(Path path, Nat key, std::optional<Text> left_entry, std::weak_ptr<MainArmThenArmElseArmElse> parent, Hold<Array<Text>> place_0, Pod place_0_element) : path(std::move(path)), key(std::move(key)), left_entry(std::move(left_entry)), parent(std::move(parent)), place_0(std::move(place_0)), place_0_element(std::move(place_0_element)) {}
    MainArmThenArmElseArmElseRow(const MainArmThenArmElseArmElseRow&) = delete;
    static Result<std::shared_ptr<MainArmThenArmElseArmElseRow>> make(Path path, Nat key, Text value, std::weak_ptr<MainArmThenArmElseArmElse> parent, Cx& cx);
    crate::Elem list(const Cx& cx) const;
    Text entry(const Cx& cx) const;
    Array<Text> result(const Cx& cx) const;
    Unit remove_places(Cx& cx) const;
    Done push(const Pod& element, const Pod& v, Cx& cx) override;
    Done patch(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElse`: a node of its own (docs/backend.md, "A widget block").
class MainArmElse : public Row {
public:
    Path path;
    /// the generation's value, `_`
    mutable Unit value;
    /// the node of the `rebuild`
    mutable std::weak_ptr<Main> parent;
    /// the current generation of the `rebuild` at place 0
    mutable std::optional<std::shared_ptr<Row>> arm;
    /// how many generations it has built
    mutable std::uint32_t arm_count;
    /// its source changed since it was built
    mutable bool arm_stale;
    MainArmElse(Path path, Unit value, std::weak_ptr<Main> parent, std::optional<std::shared_ptr<Row>> arm, std::uint32_t arm_count, bool arm_stale) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), arm(std::move(arm)), arm_count(std::move(arm_count)), arm_stale(std::move(arm_stale)) {}
    MainArmElse(const MainArmElse&) = delete;
    static Result<std::shared_ptr<MainArmElse>> make(Path path, Unit value, std::weak_ptr<Main> parent, Cx& cx);
    Unit arm_up(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done arm_build(Cx& cx);
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmThen`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmThen : public Row {
public:
    Path path;
    /// the generation's value, `_`
    mutable Unit value;
    /// the node of the `rebuild`
    mutable std::weak_ptr<MainArmElse> parent;
    /// `args`
    mutable Array<Text> args;
    /// `bad`
    mutable Array<Text> bad;
    /// the current generation of the `rebuild` at place 0
    mutable std::optional<std::shared_ptr<Row>> arm;
    /// how many generations it has built
    mutable std::uint32_t arm_count;
    /// its source changed since it was built
    mutable bool arm_stale;
    MainArmElseArmThen(Path path, Unit value, std::weak_ptr<MainArmElse> parent, Array<Text> args, Array<Text> bad, std::optional<std::shared_ptr<Row>> arm, std::uint32_t arm_count, bool arm_stale) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), args(std::move(args)), bad(std::move(bad)), arm(std::move(arm)), arm_count(std::move(arm_count)), arm_stale(std::move(arm_stale)) {}
    MainArmElseArmThen(const MainArmElseArmThen&) = delete;
    static Result<std::shared_ptr<MainArmElseArmThen>> make(Path path, Unit value, std::weak_ptr<MainArmElse> parent, Cx& cx);
    Unit arm_up(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done arm_build(Cx& cx);
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmThenArmThen`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmThenArmThen : public Row {
public:
    Path path;
    /// the generation's value, `_`
    mutable Unit value;
    /// the node of the `rebuild`
    mutable std::weak_ptr<MainArmElseArmThen> parent;
    /// `why`
    mutable Text why;
    /// `!started` as a value: the port it fires
    mutable std::shared_ptr<Port<Unit>> started_2_v_port;
    /// `!~gaveUp` as a value: the port it fires
    mutable std::shared_ptr<Port<Fallible<Unit>>> gave_up_v_port;
    MainArmElseArmThenArmThen(Path path, Unit value, std::weak_ptr<MainArmElseArmThen> parent, Text why, std::shared_ptr<Port<Unit>> started_2_v_port, std::shared_ptr<Port<Fallible<Unit>>> gave_up_v_port) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), why(std::move(why)), started_2_v_port(std::move(started_2_v_port)), gave_up_v_port(std::move(gave_up_v_port)) {}
    MainArmElseArmThenArmThen(const MainArmElseArmThenArmThen&) = delete;
    static Result<std::shared_ptr<MainArmElseArmThenArmThen>> make(Path path, Unit value, std::weak_ptr<MainArmElseArmThen> parent, Cx& cx);
    Unit started_2(Unit v, Cx& cx);
    Unit gave_up(Fallible<Unit> v, Cx& cx);
    Unit place_1(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done started(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmThenArmElse`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmThenArmElse : public Row {
public:
    Path path;
    /// the generation's value, `_`
    mutable Unit value;
    /// the node of the `rebuild`
    mutable std::weak_ptr<MainArmElseArmThen> parent;
    /// `args`
    mutable Array<Text> args;
    /// `files`
    mutable Array<Text> files;
    /// `dir`
    mutable Text dir;
    /// `?out`
    mutable std::optional<Text> out;
    /// `world`
    mutable Array<Text> world;
    /// `prelude`
    mutable Array<Text> prelude;
    /// `paths`
    mutable Array<Text> paths;
    /// the source of the `for` at place 0, cached (gap SR)
    mutable Cache<Map<Nat, Text>> rows_source_cache;
    /// the rows of the `for` at place 0
    mutable Map<Nat, std::shared_ptr<MainArmElseArmThenArmElseRow>> rows;
    /// the `for` at place 0's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    mutable Snapshot<Map<Nat, Fallible<fs::Contents>>> rows_all_snap;
    /// the current generation of the `rebuild` at place 1
    mutable std::optional<std::shared_ptr<Row>> generation;
    /// how many generations it has built
    mutable std::uint32_t generation_count;
    /// its source changed since it was built
    mutable bool generation_stale;
    MainArmElseArmThenArmElse(Path path, Unit value, std::weak_ptr<MainArmElseArmThen> parent, Array<Text> args, Array<Text> files, Text dir, std::optional<Text> out, Array<Text> world, Array<Text> prelude, Array<Text> paths, Cache<Map<Nat, Text>> rows_source_cache, Map<Nat, std::shared_ptr<MainArmElseArmThenArmElseRow>> rows, Snapshot<Map<Nat, Fallible<fs::Contents>>> rows_all_snap, std::optional<std::shared_ptr<Row>> generation, std::uint32_t generation_count, bool generation_stale) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), args(std::move(args)), files(std::move(files)), dir(std::move(dir)), out(std::move(out)), world(std::move(world)), prelude(std::move(prelude)), paths(std::move(paths)), rows_source_cache(std::move(rows_source_cache)), rows(std::move(rows)), rows_all_snap(std::move(rows_all_snap)), generation(std::move(generation)), generation_count(std::move(generation_count)), generation_stale(std::move(generation_stale)) {}
    MainArmElseArmThenArmElse(const MainArmElseArmThenArmElse&) = delete;
    static Result<std::shared_ptr<MainArmElseArmThenArmElse>> make(Path path, Unit value, std::weak_ptr<MainArmElseArmThen> parent, Cx& cx);
    Unit generation_fired(Unit v, Cx& cx);
    Map<Nat, Text> rows_source(const Cx& cx) const;
    Map<Nat, Fallible<fs::Contents>> rows_all_now(const Cx& cx) const;
    Map<Nat, Fallible<fs::Contents>> rows_all(const Cx& cx) const;
    Unit generation_up(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Unit rows_all_moved(Cx& cx);
    Unit rows_all_publish(Cx& cx);
    Done rows_build(Cx& cx);
    Done generation_build(Cx& cx);
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmThenArmElseGen1`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmThenArmElseGen1 : public Row {
public:
    Path path;
    /// the generation's value, `_`
    mutable Map<Nat, Fallible<fs::Contents>> value;
    /// the node of the `rebuild`
    mutable std::weak_ptr<MainArmElseArmThenArmElse> parent;
    /// `files`
    mutable Array<Text> files;
    /// `prelude`
    mutable Array<Text> prelude;
    /// `world`
    mutable Array<Text> world;
    /// `?out`
    mutable std::optional<Text> out;
    /// `typed`
    mutable bool typed;
    /// `unused`
    mutable bool unused;
    /// `contents`
    mutable Map<Nat, Fallible<fs::Contents>> contents;
    /// `!done` as a value: the port it fires
    mutable std::shared_ptr<Port<Outcome_>> done_v_port;
    /// `n`
    mutable Nat n;
    /// `texts`
    mutable Array<Text> texts;
    /// `mine`
    mutable Array<std::tuple<Text, Text>> mine;
    /// `theirs`
    mutable Array<std::tuple<Text, Text>> theirs;
    /// `present`
    mutable Array<std::tuple<Text, Text>> present;
    /// `job`
    mutable CheckJob job;
    /// `@Run`'s job (`@Machine`'s state)
    mutable Hold<prism_rtl::JobRef<Outcome_>> run_job;
    /// `@Run`'s `!again`
    mutable Defer<Unit> run_again;
    /// `run_turn`'s left input
    mutable Stamped<Unit> run_turn_left;
    /// its right input
    mutable Stamped<Unit> run_turn_right;
    /// `$?outcome`
    mutable Hold<std::optional<Outcome_>> outcome;
    /// the current generation of the `rebuild` at place 1
    mutable std::optional<std::shared_ptr<Row>> generation;
    /// how many generations it has built
    mutable std::uint32_t generation_count;
    /// its source changed since it was built
    mutable bool generation_stale;
    /// The merges' height above the node's inputs.
    static constexpr std::uint32_t WAKE = 1;
    MainArmElseArmThenArmElseGen1(Path path, Map<Nat, Fallible<fs::Contents>> value, std::weak_ptr<MainArmElseArmThenArmElse> parent, Array<Text> files, Array<Text> prelude, Array<Text> world, std::optional<Text> out, bool typed, bool unused, Map<Nat, Fallible<fs::Contents>> contents, std::shared_ptr<Port<Outcome_>> done_v_port, Nat n, Array<Text> texts, Array<std::tuple<Text, Text>> mine, Array<std::tuple<Text, Text>> theirs, Array<std::tuple<Text, Text>> present, CheckJob job, Hold<prism_rtl::JobRef<Outcome_>> run_job, Defer<Unit> run_again, Stamped<Unit> run_turn_left, Stamped<Unit> run_turn_right, Hold<std::optional<Outcome_>> outcome, std::optional<std::shared_ptr<Row>> generation, std::uint32_t generation_count, bool generation_stale) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), files(std::move(files)), prelude(std::move(prelude)), world(std::move(world)), out(std::move(out)), typed(std::move(typed)), unused(std::move(unused)), contents(std::move(contents)), done_v_port(std::move(done_v_port)), n(std::move(n)), texts(std::move(texts)), mine(std::move(mine)), theirs(std::move(theirs)), present(std::move(present)), job(std::move(job)), run_job(std::move(run_job)), run_again(std::move(run_again)), run_turn_left(std::move(run_turn_left)), run_turn_right(std::move(run_turn_right)), outcome(std::move(outcome)), generation(std::move(generation)), generation_count(std::move(generation_count)), generation_stale(std::move(generation_stale)) {}
    MainArmElseArmThenArmElseGen1(const MainArmElseArmThenArmElseGen1&) = delete;
    static Result<std::shared_ptr<MainArmElseArmThenArmElseGen1>> make(Path path, Map<Nat, Fallible<fs::Contents>> value, std::weak_ptr<MainArmElseArmThenArmElse> parent, Cx& cx);
    Unit done(Outcome_ v, Cx& cx);
    Unit run_started(Unit v, Cx& cx);
    Unit run_again_(Unit v, Cx& cx);
    Unit run_turn(Unit v, Cx& cx);
    Unit generation_fired(Unit v, Cx& cx);
    Unit generation_up(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done generation_build(Cx& cx);
    Done wake(Cx& cx) override;
    Done started(Cx& cx) override;
    Done deferred(Cx& cx) override;
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmThenArmElseGen1Gen0`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmThenArmElseGen1Gen0 : public Row {
public:
    Path path;
    /// `?out`
    mutable std::optional<Text> out;
    /// the node of the `rebuild`
    mutable std::weak_ptr<MainArmElseArmThenArmElseGen1> parent;
    MainArmElseArmThenArmElseGen1Gen0(Path path, std::optional<Text> out, std::weak_ptr<MainArmElseArmThenArmElseGen1> parent) : path(std::move(path)), out(std::move(out)), parent(std::move(parent)) {}
    MainArmElseArmThenArmElseGen1Gen0(const MainArmElseArmThenArmElseGen1Gen0&) = delete;
    static Result<std::shared_ptr<MainArmElseArmThenArmElseGen1Gen0>> make(Path path, std::optional<Text> out, std::weak_ptr<MainArmElseArmThenArmElseGen1> parent, Cx& cx);
    Unit remove_places(Cx& cx) const;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmThenArmElseGen1Gen1`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmThenArmElseGen1Gen1 : public Row {
public:
    Path path;
    /// `?out`
    mutable std::optional<Text> out;
    /// `o`
    mutable Outcome_ o;
    /// the node of the `rebuild`
    mutable std::weak_ptr<MainArmElseArmThenArmElseGen1> parent;
    /// `!started` as a value: the port it fires
    mutable std::shared_ptr<Port<Unit>> started_2_v_port;
    /// `!~verdict` as a value: the port it fires
    mutable std::shared_ptr<Port<Fallible<Unit>>> verdict_v_port;
    /// the current generation of the `rebuild` at place 0
    mutable std::optional<std::shared_ptr<Row>> generation;
    /// how many generations it has built
    mutable std::uint32_t generation_count;
    /// its source changed since it was built
    mutable bool generation_stale;
    MainArmElseArmThenArmElseGen1Gen1(Path path, std::optional<Text> out, Outcome_ o, std::weak_ptr<MainArmElseArmThenArmElseGen1> parent, std::shared_ptr<Port<Unit>> started_2_v_port, std::shared_ptr<Port<Fallible<Unit>>> verdict_v_port, std::optional<std::shared_ptr<Row>> generation, std::uint32_t generation_count, bool generation_stale) : path(std::move(path)), out(std::move(out)), o(std::move(o)), parent(std::move(parent)), started_2_v_port(std::move(started_2_v_port)), verdict_v_port(std::move(verdict_v_port)), generation(std::move(generation)), generation_count(std::move(generation_count)), generation_stale(std::move(generation_stale)) {}
    MainArmElseArmThenArmElseGen1Gen1(const MainArmElseArmThenArmElseGen1Gen1&) = delete;
    static Result<std::shared_ptr<MainArmElseArmThenArmElseGen1Gen1>> make(Path path, std::optional<Text> out, Outcome_ o, std::weak_ptr<MainArmElseArmThenArmElseGen1> parent, Cx& cx);
    Unit started_2(Unit v, Cx& cx);
    Unit verdict(Fallible<Unit> v, Cx& cx);
    Unit generation_fired(prism_rtl::Blueprint<crate::Elem, crate::Answer> v, Cx& cx);
    Unit place_2(Unit v, Cx& cx);
    Unit generation_up(prism_rtl::Blueprint<crate::Elem, crate::Answer> v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done generation_build(Cx& cx);
    Done started(Cx& cx) override;
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmThenArmElseGen1Gen1Gen0`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmThenArmElseGen1Gen1Gen0 : public Row {
public:
    Path path;
    /// the node of the `rebuild`
    mutable std::weak_ptr<MainArmElseArmThenArmElseGen1Gen1> parent;
    MainArmElseArmThenArmElseGen1Gen1Gen0(Path path, std::weak_ptr<MainArmElseArmThenArmElseGen1Gen1> parent) : path(std::move(path)), parent(std::move(parent)) {}
    MainArmElseArmThenArmElseGen1Gen1Gen0(const MainArmElseArmThenArmElseGen1Gen1Gen0&) = delete;
    static Result<std::shared_ptr<MainArmElseArmThenArmElseGen1Gen1Gen0>> make(Path path, std::weak_ptr<MainArmElseArmThenArmElseGen1Gen1> parent, Cx& cx);
    Unit remove_places(Cx& cx) const;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmThenArmElseGen1Gen1Gen1`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmThenArmElseGen1Gen1Gen1 : public Row {
public:
    Path path;
    /// `path`
    mutable Text path_;
    /// `text`
    mutable Text text;
    /// the node of the `rebuild`
    mutable std::weak_ptr<MainArmElseArmThenArmElseGen1Gen1> parent;
    /// pushed to place 0
    mutable Hold<fs::WriteState> place_0;
    /// place 0's element, which pushes are keyed by
    mutable Pod place_0_element;
    MainArmElseArmThenArmElseGen1Gen1Gen1(Path path, Text path_, Text text, std::weak_ptr<MainArmElseArmThenArmElseGen1Gen1> parent, Hold<fs::WriteState> place_0, Pod place_0_element) : path(std::move(path)), path_(std::move(path_)), text(std::move(text)), parent(std::move(parent)), place_0(std::move(place_0)), place_0_element(std::move(place_0_element)) {}
    MainArmElseArmThenArmElseGen1Gen1Gen1(const MainArmElseArmThenArmElseGen1Gen1Gen1&) = delete;
    static Result<std::shared_ptr<MainArmElseArmThenArmElseGen1Gen1Gen1>> make(Path path, Text path_, Text text, std::weak_ptr<MainArmElseArmThenArmElseGen1Gen1> parent, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done push(const Pod& element, const Pod& v, Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmThenArmElseRow`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmThenArmElseRow : public Row {
public:
    Path path;
    /// the row's key
    mutable Nat key;
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    mutable std::optional<Text> left_entry;
    /// the node of the `for`
    mutable std::weak_ptr<MainArmElseArmThenArmElse> parent;
    /// pushed to place 0
    mutable Hold<Fallible<fs::Contents>> place_0;
    /// place 0's element, which pushes are keyed by
    mutable Pod place_0_element;
    MainArmElseArmThenArmElseRow(Path path, Nat key, std::optional<Text> left_entry, std::weak_ptr<MainArmElseArmThenArmElse> parent, Hold<Fallible<fs::Contents>> place_0, Pod place_0_element) : path(std::move(path)), key(std::move(key)), left_entry(std::move(left_entry)), parent(std::move(parent)), place_0(std::move(place_0)), place_0_element(std::move(place_0_element)) {}
    MainArmElseArmThenArmElseRow(const MainArmElseArmThenArmElseRow&) = delete;
    static Result<std::shared_ptr<MainArmElseArmThenArmElseRow>> make(Path path, Nat key, Text value, std::weak_ptr<MainArmElseArmThenArmElse> parent, Cx& cx);
    crate::Elem contents_(const Cx& cx) const;
    Text entry(const Cx& cx) const;
    Fallible<fs::Contents> result(const Cx& cx) const;
    Unit remove_places(Cx& cx) const;
    Done push(const Pod& element, const Pod& v, Cx& cx) override;
    Done patch(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmElse`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmElse : public Row {
public:
    Path path;
    /// the generation's value, `_`
    mutable Unit value;
    /// the node of the `rebuild`
    mutable std::weak_ptr<MainArmElse> parent;
    /// `args`
    mutable Array<Text> args;
    /// `tokens`
    mutable bool tokens;
    /// `fragment`
    mutable bool fragment;
    /// `names`
    mutable Array<Text> names;
    /// `file`
    mutable Text file;
    /// `out`
    mutable Text out;
    /// pushed to place 0
    mutable Hold<Fallible<fs::Contents>> source;
    /// place 0's element, which pushes are keyed by
    mutable Pod source_element;
    /// the current generation of the `rebuild` at place 1
    mutable std::optional<std::shared_ptr<Row>> generation;
    /// how many generations it has built
    mutable std::uint32_t generation_count;
    /// its source changed since it was built
    mutable bool generation_stale;
    MainArmElseArmElse(Path path, Unit value, std::weak_ptr<MainArmElse> parent, Array<Text> args, bool tokens, bool fragment, Array<Text> names, Text file, Text out, Hold<Fallible<fs::Contents>> source, Pod source_element, std::optional<std::shared_ptr<Row>> generation, std::uint32_t generation_count, bool generation_stale) : path(std::move(path)), value(std::move(value)), parent(std::move(parent)), args(std::move(args)), tokens(std::move(tokens)), fragment(std::move(fragment)), names(std::move(names)), file(std::move(file)), out(std::move(out)), source(std::move(source)), source_element(std::move(source_element)), generation(std::move(generation)), generation_count(std::move(generation_count)), generation_stale(std::move(generation_stale)) {}
    MainArmElseArmElse(const MainArmElseArmElse&) = delete;
    static Result<std::shared_ptr<MainArmElseArmElse>> make(Path path, Unit value, std::weak_ptr<MainArmElse> parent, Cx& cx);
    Unit generation_fired(Unit v, Cx& cx);
    Unit generation_up(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done generation_build(Cx& cx);
    Done build(Cx& cx) override;
    Done push(const Pod& element, const Pod& v, Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmElseGen0`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmElseGen0 : public Row {
public:
    Path path;
    /// `job`
    mutable Job_ job;
    /// `file`
    mutable Text file;
    /// `out`
    mutable Text out;
    /// `c`
    mutable fs::Contents c;
    /// the node of the `rebuild`
    mutable std::weak_ptr<MainArmElseArmElse> parent;
    /// `!done` as a value: the port it fires
    mutable std::shared_ptr<Port<Outcome_>> done_v_port;
    /// `full`
    mutable Job_ full;
    /// `@Run`'s job (`@Machine`'s state)
    mutable Hold<prism_rtl::JobRef<Outcome_>> run_job;
    /// `@Run`'s `!again`
    mutable Defer<Unit> run_again;
    /// `run_turn`'s left input
    mutable Stamped<Unit> run_turn_left;
    /// its right input
    mutable Stamped<Unit> run_turn_right;
    /// `$?outcome`
    mutable Hold<std::optional<Outcome_>> outcome;
    /// the current generation of the `rebuild` at place 1
    mutable std::optional<std::shared_ptr<Row>> generation;
    /// how many generations it has built
    mutable std::uint32_t generation_count;
    /// its source changed since it was built
    mutable bool generation_stale;
    /// The merges' height above the node's inputs.
    static constexpr std::uint32_t WAKE = 1;
    MainArmElseArmElseGen0(Path path, Job_ job, Text file, Text out, fs::Contents c, std::weak_ptr<MainArmElseArmElse> parent, std::shared_ptr<Port<Outcome_>> done_v_port, Job_ full, Hold<prism_rtl::JobRef<Outcome_>> run_job, Defer<Unit> run_again, Stamped<Unit> run_turn_left, Stamped<Unit> run_turn_right, Hold<std::optional<Outcome_>> outcome, std::optional<std::shared_ptr<Row>> generation, std::uint32_t generation_count, bool generation_stale) : path(std::move(path)), job(std::move(job)), file(std::move(file)), out(std::move(out)), c(std::move(c)), parent(std::move(parent)), done_v_port(std::move(done_v_port)), full(std::move(full)), run_job(std::move(run_job)), run_again(std::move(run_again)), run_turn_left(std::move(run_turn_left)), run_turn_right(std::move(run_turn_right)), outcome(std::move(outcome)), generation(std::move(generation)), generation_count(std::move(generation_count)), generation_stale(std::move(generation_stale)) {}
    MainArmElseArmElseGen0(const MainArmElseArmElseGen0&) = delete;
    static Result<std::shared_ptr<MainArmElseArmElseGen0>> make(Path path, Job_ job, Text file, Text out, fs::Contents c, std::weak_ptr<MainArmElseArmElse> parent, Cx& cx);
    Unit done(Outcome_ v, Cx& cx);
    Unit run_started(Unit v, Cx& cx);
    Unit run_again_(Unit v, Cx& cx);
    Unit run_turn(Unit v, Cx& cx);
    Unit generation_fired(Unit v, Cx& cx);
    Unit generation_up(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done generation_build(Cx& cx);
    Done wake(Cx& cx) override;
    Done started(Cx& cx) override;
    Done deferred(Cx& cx) override;
    Done build(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmElseGen0Gen0`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmElseGen0Gen0 : public Row {
public:
    Path path;
    /// `out`
    mutable Text out;
    /// the node of the `rebuild`
    mutable std::weak_ptr<MainArmElseArmElseGen0> parent;
    MainArmElseArmElseGen0Gen0(Path path, Text out, std::weak_ptr<MainArmElseArmElseGen0> parent) : path(std::move(path)), out(std::move(out)), parent(std::move(parent)) {}
    MainArmElseArmElseGen0Gen0(const MainArmElseArmElseGen0Gen0&) = delete;
    static Result<std::shared_ptr<MainArmElseArmElseGen0Gen0>> make(Path path, Text out, std::weak_ptr<MainArmElseArmElseGen0> parent, Cx& cx);
    Unit remove_places(Cx& cx) const;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmElseGen0Gen1`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmElseGen0Gen1 : public Row {
public:
    Path path;
    /// `out`
    mutable Text out;
    /// `o`
    mutable Outcome_ o;
    /// the node of the `rebuild`
    mutable std::weak_ptr<MainArmElseArmElseGen0> parent;
    /// `!started` as a value: the port it fires
    mutable std::shared_ptr<Port<Unit>> started_2_v_port;
    /// `!~verdict` as a value: the port it fires
    mutable std::shared_ptr<Port<Fallible<Unit>>> verdict_v_port;
    /// pushed to place 0
    mutable Hold<fs::WriteState> place_0;
    /// place 0's element, which pushes are keyed by
    mutable Pod place_0_element;
    MainArmElseArmElseGen0Gen1(Path path, Text out, Outcome_ o, std::weak_ptr<MainArmElseArmElseGen0> parent, std::shared_ptr<Port<Unit>> started_2_v_port, std::shared_ptr<Port<Fallible<Unit>>> verdict_v_port, Hold<fs::WriteState> place_0, Pod place_0_element) : path(std::move(path)), out(std::move(out)), o(std::move(o)), parent(std::move(parent)), started_2_v_port(std::move(started_2_v_port)), verdict_v_port(std::move(verdict_v_port)), place_0(std::move(place_0)), place_0_element(std::move(place_0_element)) {}
    MainArmElseArmElseGen0Gen1(const MainArmElseArmElseGen0Gen1&) = delete;
    static Result<std::shared_ptr<MainArmElseArmElseGen0Gen1>> make(Path path, Text out, Outcome_ o, std::weak_ptr<MainArmElseArmElseGen0> parent, Cx& cx);
    Unit started_2(Unit v, Cx& cx);
    Unit verdict(Fallible<Unit> v, Cx& cx);
    Unit place_2(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done started(Cx& cx) override;
    Done push(const Pod& element, const Pod& v, Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// `MainArmElseArmElseGen1`: a node of its own (docs/backend.md, "A widget block").
class MainArmElseArmElseGen1 : public Row {
public:
    Path path;
    /// `job`
    mutable Job_ job;
    /// `file`
    mutable Text file;
    /// `out`
    mutable Text out;
    /// `m`
    mutable Text m;
    /// the node of the `rebuild`
    mutable std::weak_ptr<MainArmElseArmElse> parent;
    /// `!started` as a value: the port it fires
    mutable std::shared_ptr<Port<Unit>> started_2_v_port;
    /// `!~gaveUp` as a value: the port it fires
    mutable std::shared_ptr<Port<Fallible<Unit>>> gave_up_v_port;
    MainArmElseArmElseGen1(Path path, Job_ job, Text file, Text out, Text m, std::weak_ptr<MainArmElseArmElse> parent, std::shared_ptr<Port<Unit>> started_2_v_port, std::shared_ptr<Port<Fallible<Unit>>> gave_up_v_port) : path(std::move(path)), job(std::move(job)), file(std::move(file)), out(std::move(out)), m(std::move(m)), parent(std::move(parent)), started_2_v_port(std::move(started_2_v_port)), gave_up_v_port(std::move(gave_up_v_port)) {}
    MainArmElseArmElseGen1(const MainArmElseArmElseGen1&) = delete;
    static Result<std::shared_ptr<MainArmElseArmElseGen1>> make(Path path, Job_ job, Text file, Text out, Text m, std::weak_ptr<MainArmElseArmElse> parent, Cx& cx);
    Unit started_2(Unit v, Cx& cx);
    Unit gave_up(Fallible<Unit> v, Cx& cx);
    Unit place_1(Unit v, Cx& cx);
    Unit remove_places(Cx& cx) const;
    Done started(Cx& cx) override;
    Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;
    void leave_row(Cx& cx) override;
};


/// The step machine of `CompileProgram`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CompileProgram: unbounded fn CompileJob -> Compiled
struct CompileProgram : prism_rtl::Job<Compiled> {
    CompileJob job;
    CompileProgram(CompileJob job) : job(std::move(job)) {}
    prism_rtl::Turn<Compiled> cycle() const override;
};


}  // namespace program

}  // namespace crate
