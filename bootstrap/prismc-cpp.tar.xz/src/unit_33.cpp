// The module `Emit.Cpp.Expr`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <emit/cpp/expr/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Emit.Cpp.Expr`, from `target/bootstrap/cpp-src/prismc/emit/cpp/expr.prism`.
namespace crate::emit::cpp::expr {

/// CppLoose: fn Ex -> Bool
bool cpp_loose_f(const crate::lower::model::Ex& x_p0) {
    if (prism_rtl::is<crate::lower::model::Ex::XBlock>(x_p0)) {
        auto&& m1173_0_0 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a0;
        auto&& inner_p1 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a1;
        if (m1173_0_0.size() == 0u) {
            return cpp_loose_f(prism_rtl::deref(prism_rtl::deref(inner_p1)));
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBin>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUnary>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XIf>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRef>(x_p0)) {
        auto&& y_p2 = prism_rtl::as<crate::lower::model::Ex::XRef>(x_p0).a0;
        return cpp_loose_f(prism_rtl::deref(prism_rtl::deref(y_p2)));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRefMut>(x_p0)) {
        auto&& y_p3 = prism_rtl::as<crate::lower::model::Ex::XRefMut>(x_p0).a0;
        return cpp_loose_f(prism_rtl::deref(prism_rtl::deref(y_p3)));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XClone>(x_p0)) {
        auto&& y_p4 = prism_rtl::as<crate::lower::model::Ex::XClone>(x_p0).a0;
        return cpp_loose_f(prism_rtl::deref(prism_rtl::deref(y_p4)));
    }
    {
        return false;
    }
}


/// CppTight: unbounded fn Cp, Ex -> Text
Text cpp_tight_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Ex& x_p1) {
    return cpp_loose_f(x_p1)
        ? prism_rtl::cat("(", cpp_expr_f(cp_p0, x_p1), ")")
        : starred_f(cpp_expr_f(cp_p0, x_p1));
}


prism_rtl::Turn<Text> CppTight::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& x_p1 = this->x_p1;
    return cpp_loose_f(x_p1)
        ? ({
        auto cp_p0x = cp_p0;
        auto x_p1x = x_p1;
        (crate::prelude::call_then(start_cpp_expr_f(cp_p0x, x_p1x), [=](Text cpp_expr_f_1500) { return prism_rtl::finished(prism_rtl::cat("(", cpp_expr_f_1500, ")")); }));
    })
        : ({
        auto cp_p0x = cp_p0;
        auto x_p1x = x_p1;
        (crate::prelude::call_then(start_cpp_expr_f(cp_p0x, x_p1x), [=](Text cpp_expr_f_1532) { return prism_rtl::finished(starred_f(cpp_expr_f_1532)); }));
    });
}


/// `Start CppTight, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_tight_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex x_p1) {
    return prism_rtl::make_rc<CppTight>(cp_p0, x_p1);
}


/// Starred: fn Text -> Text
Text starred_f(const Text& t_p0) {
    return crate::syntax::lexer::chars::has_prefix_f(t_p0, Text::lit("*"))
        ? prism_rtl::cat("(", t_p0, ")")
        : t_p0;
}


/// CppTightPlace: unbounded fn Cp, Ex -> Text
Text cpp_tight_place_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Ex& x_p1) {
    return cpp_loose_f(x_p1)
        ? prism_rtl::cat("(", cpp_place_f(cp_p0, x_p1), ")")
        : starred_f(cpp_place_f(cp_p0, x_p1));
}


prism_rtl::Turn<Text> CppTightPlace::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& x_p1 = this->x_p1;
    return cpp_loose_f(x_p1)
        ? ({
        auto cp_p0x = cp_p0;
        auto x_p1x = x_p1;
        (crate::prelude::call_then(start_cpp_place_f(cp_p0x, x_p1x), [=](Text cpp_place_f_1889) { return prism_rtl::finished(prism_rtl::cat("(", cpp_place_f_1889, ")")); }));
    })
        : ({
        auto cp_p0x = cp_p0;
        auto x_p1x = x_p1;
        (crate::prelude::call_then(start_cpp_place_f(cp_p0x, x_p1x), [=](Text cpp_place_f_1922) { return prism_rtl::finished(starred_f(cpp_place_f_1922)); }));
    });
}


/// `Start CppTightPlace, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_tight_place_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex x_p1) {
    return prism_rtl::make_rc<CppTightPlace>(cp_p0, x_p1);
}


/// CppPlace: unbounded fn Cp, Ex -> Text
Text cpp_place_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Ex& ex1) {
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(ex1)) {
        auto&& n_p1 = prism_rtl::as<crate::lower::model::Ex::XVar>(ex1).a0;
        return crate::emit::cpp::stmts::var_name_f(cp_p0, n_p1);
    }
    {
        auto&& x_p3 = ex1;
        return cpp_expr_f(cp_p0, x_p3);
    }
}


prism_rtl::Turn<Text> CppPlace::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& ex1 = this->ex1;
    return ({
        prism_rtl::is<crate::lower::model::Ex::XVar>(ex1) ? ({
        auto&& n_p1 = prism_rtl::as<crate::lower::model::Ex::XVar>(ex1).a0;
        prism_rtl::finished(crate::emit::cpp::stmts::var_name_f(cp_p0, n_p1));
    })
        : ({
        auto&& x_p3 = ex1;
        prism_rtl::more(prism_rtl::rc(CppExpr(cp_p0, x_p3)));
    });
    });
}


/// `Start CppPlace, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_place_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex ex1) {
    return prism_rtl::make_rc<CppPlace>(cp_p0, ex1);
}


/// CppVar: fn Cp, Text -> Text
Text cpp_var_f(const crate::emit::cpp::Cp& cp_p0, const Text& n_p1) {
    return crate::prelude::or_(crate::prelude::get(cp_p0.owned_p, n_p1), false)
        ? prism_rtl::cat("std::move(", crate::emit::cpp::stmts::var_name_f(cp_p0, n_p1), ")")
        : crate::emit::cpp::stmts::var_name_f(cp_p0, n_p1);
}


/// CppArgs: unbounded fn Cp, [Ex] -> Text
Text cpp_args_f(const crate::emit::cpp::Cp& cp_p0, const Array<crate::lower::model::Ex>& xs_p1) {
    return crate::syntax::lexer::chars::join_f(cpp_arg_list_f(cp_p0, xs_p1), Text::lit(", "));
}


prism_rtl::Turn<Text> CppArgs::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& xs_p1 = this->xs_p1;
    auto cp_p0x = cp_p0;
    auto xs_p1x = xs_p1;
    return crate::prelude::call_then(start_cpp_arg_list_f(cp_p0x, xs_p1x), [=](Array<Text> cpp_arg_list_f_2810) { return prism_rtl::finished(crate::syntax::lexer::chars::join_f(cpp_arg_list_f_2810, Text::lit(", "))); });
}


/// `Start CppArgs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_args_f(crate::emit::cpp::Cp cp_p0, Array<crate::lower::model::Ex> xs_p1) {
    return prism_rtl::make_rc<CppArgs>(cp_p0, xs_p1);
}


/// CppArgList: unbounded fn Cp, [Ex] -> [Text]
Array<Text> cpp_arg_list_f(const crate::emit::cpp::Cp& cp_p0, const Array<crate::lower::model::Ex>& xs_p1) {
    auto texts_p2 = crate::prelude::run_to_end(crate::prelude::each_job(xs_p1, ({
        auto cp_p0x = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x)](crate::lower::model::Ex p0) {
        return ({
            auto cp_p0xy = cp_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy)]() {
            return ({
                auto x_p3 = p0;
                (prism_rtl::more(prism_rtl::rc(CppExpr(cp_p0xy, x_p3))));
            });
        })));
        });
    })));
    })));
    return crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(xs_p1)), ({
        auto xs_p1x = xs_p1;
        auto cp_p0x = cp_p0;
        auto texts_p2x = texts_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=, xs_p1x = std::move(xs_p1x), cp_p0x = std::move(cp_p0x), texts_p2x = std::move(texts_p2x)](Nat p0) {
        return ({
            auto xs_p1xy = xs_p1x;
            auto cp_p0xy = cp_p0x;
            auto texts_p2xy = texts_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, xs_p1xy = std::move(xs_p1xy), cp_p0xy = std::move(cp_p0xy), texts_p2xy = std::move(texts_p2xy)]() {
            return ({
                auto i_p4 = p0;
                ({
                auto&& _m = crate::prelude::or_(crate::prelude::index(xs_p1xy, i_p4), crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}));
                prism_rtl::is<crate::lower::model::Ex::XVar>(_m) ? ({
                auto&& n_p5 = prism_rtl::as<crate::lower::model::Ex::XVar>(_m).a0;
                crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(xs_p1xy)), false, ({
                auto i_p4x = i_p4;
                auto xs_p1xyx = xs_p1xy;
                auto n_p5x = n_p5;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Nat>)>>(prism_rtl::rc([=, i_p4x = std::move(i_p4x), xs_p1xyx = std::move(xs_p1xyx), n_p5x = std::move(n_p5x)](std::tuple<bool, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto i_p4xy = i_p4x;
                    auto xs_p1xyxy = xs_p1xyx;
                    auto n_p5xy = n_p5x;
                    (crate::prelude::entered(crate::prelude::once_job([=, i_p4xy = std::move(i_p4xy), xs_p1xyxy = std::move(xs_p1xyxy), n_p5xy = std::move(n_p5xy)]() {
                    return ({
                        auto f_p6 = p0;
                        auto j_p7 = p1;
                        (prism_rtl::finished(std::move(f_p6) || ((j_p7 != i_p4xy) && crate::lower::model::ex_reads_f(crate::prelude::or_(crate::prelude::index(xs_p1xyxy, j_p7), crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})), n_p5xy))));
                    });
                })));
                });
            })));
            })), [=](bool fold_3021) {
                return fold_3021
                    ? prism_rtl::finished(crate::emit::cpp::stmts::var_name_f(cp_p0xy, n_p5))
                    : prism_rtl::finished(crate::prelude::or_(crate::prelude::index(texts_p2xy, i_p4), Text::lit("")));
            });
            })
                : prism_rtl::finished(crate::prelude::or_(crate::prelude::index(texts_p2xy, i_p4), Text::lit("")));
            });
            });
        })));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Text>> CppArgList::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& xs_p1 = this->xs_p1;
    auto cp_p0x = cp_p0;
    auto xs_p1x = xs_p1;
    return crate::prelude::call_value(crate::prelude::each_job(xs_p1x, ({
        auto cp_p0xx = cp_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx)](crate::lower::model::Ex p0) {
        return ({
            auto cp_p0xxy = cp_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy)]() {
            return ({
                auto x_p3 = p0;
                (prism_rtl::more(prism_rtl::rc(CppExpr(cp_p0xxy, x_p3))));
            });
        })));
        });
    })));
    })), [=](Array<Text> each_2918) {
        return ({
            auto texts_p2 = each_2918;
            (crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(xs_p1x)), ({
            auto xs_p1xx = xs_p1x;
            auto cp_p0xx = cp_p0x;
            auto texts_p2x = texts_p2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=, xs_p1xx = std::move(xs_p1xx), cp_p0xx = std::move(cp_p0xx), texts_p2x = std::move(texts_p2x)](Nat p0) {
            return ({
                auto xs_p1xxy = xs_p1xx;
                auto cp_p0xxy = cp_p0xx;
                auto texts_p2xy = texts_p2x;
                (crate::prelude::entered(crate::prelude::once_job([=, xs_p1xxy = std::move(xs_p1xxy), cp_p0xxy = std::move(cp_p0xxy), texts_p2xy = std::move(texts_p2xy)]() {
                return ({
                    auto i_p4 = p0;
                    ({
                    auto&& _m = crate::prelude::or_(crate::prelude::index(xs_p1xxy, i_p4), crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}));
                    prism_rtl::is<crate::lower::model::Ex::XVar>(_m) ? ({
                    auto&& n_p5 = prism_rtl::as<crate::lower::model::Ex::XVar>(_m).a0;
                    crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(xs_p1xxy)), false, ({
                    auto i_p4x = i_p4;
                    auto xs_p1xxyx = xs_p1xxy;
                    auto n_p5x = n_p5;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Nat>)>>(prism_rtl::rc([=, i_p4x = std::move(i_p4x), xs_p1xxyx = std::move(xs_p1xxyx), n_p5x = std::move(n_p5x)](std::tuple<bool, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto i_p4xy = i_p4x;
                        auto xs_p1xxyxy = xs_p1xxyx;
                        auto n_p5xy = n_p5x;
                        (crate::prelude::entered(crate::prelude::once_job([=, i_p4xy = std::move(i_p4xy), xs_p1xxyxy = std::move(xs_p1xxyxy), n_p5xy = std::move(n_p5xy)]() {
                        return ({
                            auto f_p6 = p0;
                            auto j_p7 = p1;
                            (prism_rtl::finished(std::move(f_p6) || ((j_p7 != i_p4xy) && crate::lower::model::ex_reads_f(crate::prelude::or_(crate::prelude::index(xs_p1xxyxy, j_p7), crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})), n_p5xy))));
                        });
                    })));
                    });
                })));
                })), [=](bool fold_3021) {
                    return fold_3021
                        ? prism_rtl::finished(crate::emit::cpp::stmts::var_name_f(cp_p0xxy, n_p5))
                        : prism_rtl::finished(crate::prelude::or_(crate::prelude::index(texts_p2xy, i_p4), Text::lit("")));
                });
                })
                    : prism_rtl::finished(crate::prelude::or_(crate::prelude::index(texts_p2xy, i_p4), Text::lit("")));
                });
                });
            })));
            });
        })));
        }))->cycle());
        });
    });
}


/// `Start CppArgList, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_cpp_arg_list_f(crate::emit::cpp::Cp cp_p0, Array<crate::lower::model::Ex> xs_p1) {
    return prism_rtl::make_rc<CppArgList>(cp_p0, xs_p1);
}


/// CppExpr: unbounded fn Cp, Ex -> Text
Text cpp_expr_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Ex& x_p1) {
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(x_p1)) {
        auto&& n_p2 = prism_rtl::as<crate::lower::model::Ex::XVar>(x_p1).a0;
        return cpp_var_f(cp_p0, n_p2);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XPath>(x_p1)) {
        auto&& p_p3 = prism_rtl::as<crate::lower::model::Ex::XPath>(x_p1).a0;
        return path_value_f(cp_p0, p_p3);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XSelf>(x_p1)) {
        return Text::lit("prism_rtl::share(this)");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XCx>(x_p1)) {
        return Text::lit("cx");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XConst>(x_p1)) {
        auto&& n_p4 = prism_rtl::as<crate::lower::model::Ex::XConst>(x_p1).a0;
        return n_p4;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUnit>(x_p1)) {
        return Text::lit("Unit{}");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XNone>(x_p1)) {
        return Text::lit("std::nullopt");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBool>(x_p1)) {
        auto&& b_p5 = prism_rtl::as<crate::lower::model::Ex::XBool>(x_p1).a0;
        return prism_rtl::deref(b_p5) ? Text::lit("true") : Text::lit("false");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XNat>(x_p1)) {
        auto&& d_p6 = prism_rtl::as<crate::lower::model::Ex::XNat>(x_p1).a0;
        return crate::prelude::len_text(d_p6) <= Nat(9u)
            ? prism_rtl::cat("Nat(", d_p6, "u)")
            : prism_rtl::cat("*Nat::from_int(", cpp_expr_f(cp_p0, crate::lower::model::Ex(crate::lower::model::Ex::XInt{d_p6})), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XInt>(x_p1)) {
        auto&& d_p7 = prism_rtl::as<crate::lower::model::Ex::XInt>(x_p1).a0;
        return crate::prelude::len_text(crate::syntax::lexer::chars::has_prefix_f(d_p7, Text::lit("-"))
            ? crate::syntax::lexer::chars::after_first_f(d_p7)
            : d_p7) <= Nat(18u)
            ? prism_rtl::cat("Int(", d_p7, "ll)")
            : prism_rtl::cat("*Int::parse(\"", d_p7, "\")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XByte>(x_p1)) {
        auto&& d_p8 = prism_rtl::as<crate::lower::model::Ex::XByte>(x_p1).a0;
        return prism_rtl::cat("std::uint8_t(", d_p8, ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XFloat>(x_p1)) {
        auto&& d_p9 = prism_rtl::as<crate::lower::model::Ex::XFloat>(x_p1).a0;
        return prism_rtl::cat("Float{", d_p9, "}");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XIndex>(x_p1)) {
        auto&& n_pa = prism_rtl::as<crate::lower::model::Ex::XIndex>(x_p1).a0;
        return prism_rtl::cat(n_pa, "u");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XChar>(x_p1)) {
        auto&& c_pb = prism_rtl::as<crate::lower::model::Ex::XChar>(x_p1).a0;
        return prism_rtl::cat("U\'", cpp_char_escape_f(c_pb), "\'");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XStr>(x_p1)) {
        auto&& t_pc = prism_rtl::as<crate::lower::model::Ex::XStr>(x_p1).a0;
        return cpp_string_f(t_pc);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRegex>(x_p1)) {
        auto&& p_pd = prism_rtl::as<crate::lower::model::Ex::XRegex>(x_p1).a0;
        auto&& f_pe = prism_rtl::as<crate::lower::model::Ex::XRegex>(x_p1).a1;
        return prism_rtl::cat("([]() -> const Regex& { static const Regex r = Regex::lit(", cpp_string_f(p_pd), ", ", cpp_string_f(f_pe), "); return r; }())");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XReplacement>(x_p1)) {
        auto&& p_pf = prism_rtl::as<crate::lower::model::Ex::XReplacement>(x_p1).a0;
        auto&& r_pg = prism_rtl::as<crate::lower::model::Ex::XReplacement>(x_p1).a1;
        auto&& f_ph = prism_rtl::as<crate::lower::model::Ex::XReplacement>(x_p1).a2;
        return prism_rtl::cat("([]() -> const RegexReplacement& { static const RegexReplacement r = RegexReplacement::lit(", cpp_string_f(p_pf), ", ", cpp_string_f(f_ph), ", ", cpp_string_f(r_pg), "); return r; }())");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRef>(x_p1)) {
        auto&& y_pi = prism_rtl::as<crate::lower::model::Ex::XRef>(x_p1).a0;
        return cpp_place_f(cp_p0, prism_rtl::deref(prism_rtl::deref(y_pi)));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRefMut>(x_p1)) {
        auto&& y_pj = prism_rtl::as<crate::lower::model::Ex::XRefMut>(x_p1).a0;
        return cpp_place_f(cp_p0, prism_rtl::deref(prism_rtl::deref(y_pj)));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XDeref>(x_p1)) {
        auto&& y_pk = prism_rtl::as<crate::lower::model::Ex::XDeref>(x_p1).a0;
        auto&& _m = ex_ty_o(cp_p0, prism_rtl::deref(prism_rtl::deref(y_pk)));
        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::model::OutTy::OutRc>(prism_rtl::some_of(_m))) {
            return prism_rtl::cat("*", cpp_tight_place_f(cp_p0, prism_rtl::deref(prism_rtl::deref(y_pk))));
        }
        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::model::OutTy::OutRef>(prism_rtl::some_of(_m))) {
            return cpp_place_f(cp_p0, prism_rtl::deref(prism_rtl::deref(y_pk)));
        }
        {
            return prism_rtl::cat("prism_rtl::deref(", cpp_place_f(cp_p0, prism_rtl::deref(prism_rtl::deref(y_pk))), ")");
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTarget>(x_p1)) {
        auto&& y_pl = prism_rtl::as<crate::lower::model::Ex::XTarget>(x_p1).a0;
        return cpp_place_f(cp_p0, prism_rtl::deref(prism_rtl::deref(y_pl)));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XClone>(x_p1)) {
        auto&& y_pm = prism_rtl::as<crate::lower::model::Ex::XClone>(x_p1).a0;
        return cpp_place_f(cp_p0, prism_rtl::deref(prism_rtl::deref(y_pm)));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XWeak>(x_p1)) {
        auto&& y_pn = prism_rtl::as<crate::lower::model::Ex::XWeak>(x_p1).a0;
        return prism_rtl::cat("prism_rtl::weaken(", cpp_expr_f(cp_p0, prism_rtl::deref(prism_rtl::deref(y_pn))), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUpgrade>(x_p1)) {
        auto&& y_po = prism_rtl::as<crate::lower::model::Ex::XUpgrade>(x_p1).a0;
        return prism_rtl::cat("prism_rtl::upgrade(", cpp_expr_f(cp_p0, prism_rtl::deref(prism_rtl::deref(y_po))), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBreak>(x_p1)) {
        auto&& l_pp = prism_rtl::as<crate::lower::model::Ex::XBreak>(x_p1).a0;
        auto&& y_pq = prism_rtl::as<crate::lower::model::Ex::XBreak>(x_p1).a1;
        return prism_rtl::cat("(", crate::emit::cpp::patterns::cpp_break_f(cp_p0, l_pp, prism_rtl::deref(prism_rtl::deref(y_pq))), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBreakLoop>(x_p1)) {
        return Text::lit("({ break; })");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XLater>(x_p1)) {
        auto&& y_pr = prism_rtl::as<crate::lower::model::Ex::XLater>(x_p1).a0;
        return prism_rtl::cat("[=](Cx& cx) -> Done { ", cpp_expr_f(crate::emit::cpp::stmts::captured_f(cp_p0), prism_rtl::deref(prism_rtl::deref(y_pr))), "; return {}; }");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XFormatStr>(x_p1)) {
        auto&& parts_ps = prism_rtl::as<crate::lower::model::Ex::XFormatStr>(x_p1).a0;
        return cpp_format_f(cp_p0, parts_ps, Text::lit("prism_rtl::str"));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XIsCase>(x_p1)) {
        auto&& y_pt = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x_p1).a0;
        auto&& m3236_28_1 = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x_p1).a1;
        if (m3236_28_1.size() == 0u) {
            return Text::lit("false");
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XIsCase>(x_p1)) {
        auto&& y_pu = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x_p1).a0;
        auto&& cs_pv = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x_p1).a1;
        return prism_rtl::cat("(", crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(cs_pv, ({
            auto cp_p0x = cp_p0;
            auto y_pux = prism_rtl::deref(prism_rtl::deref(y_pu));
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Text)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x), y_pux = std::move(y_pux)](Text p0) {
            return ({
                auto cp_p0xy = cp_p0x;
                auto y_puxy = y_pux;
                (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy), y_puxy = std::move(y_puxy)]() {
                return ({
                    auto c_p10 = p0;
                    (crate::prelude::call_then(start_cpp_tight_place_f(cp_p0xy, y_puxy), [=, c_p10 = std::move(c_p10)](Text cpp_tight_place_f_5390) { return prism_rtl::finished(case_test_f(cp_p0xy, c_p10, cpp_tight_place_f_5390)); }));
                });
            })));
            });
        })));
        }))), Text::lit(" || ")), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRefusal>(x_p1)) {
        auto&& what_p11 = prism_rtl::as<crate::lower::model::Ex::XRefusal>(x_p1).a0;
        return prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal_p(), crate::lower::expr::escape_f(what_p11), "\")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUnreachable>(x_p1)) {
        return Text::lit("throw prism_rtl::Panic(\"entered unreachable code\")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XCall>(x_p1)) {
        auto&& f_p12 = prism_rtl::as<crate::lower::model::Ex::XCall>(x_p1).a0;
        auto&& args_p13 = prism_rtl::as<crate::lower::model::Ex::XCall>(x_p1).a1;
        return cpp_call_f(cp_p0, f_p12, args_p13);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XApply>(x_p1)) {
        auto&& f_p14 = prism_rtl::as<crate::lower::model::Ex::XApply>(x_p1).a0;
        auto&& args_p15 = prism_rtl::as<crate::lower::model::Ex::XApply>(x_p1).a1;
        return prism_rtl::cat(cpp_tight_place_f(cp_p0, prism_rtl::deref(prism_rtl::deref(f_p14))), "(", cpp_args_f(cp_p0, args_p15), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XMethod>(x_p1)) {
        auto&& r_p16 = prism_rtl::as<crate::lower::model::Ex::XMethod>(x_p1).a0;
        auto&& m_p17 = prism_rtl::as<crate::lower::model::Ex::XMethod>(x_p1).a1;
        auto&& args_p18 = prism_rtl::as<crate::lower::model::Ex::XMethod>(x_p1).a2;
        return cpp_method_f(cp_p0, prism_rtl::deref(prism_rtl::deref(r_p16)), m_p17, args_p18);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBin>(x_p1)) {
        auto&& op_p19 = prism_rtl::as<crate::lower::model::Ex::XBin>(x_p1).a0;
        auto&& l_p1a = prism_rtl::as<crate::lower::model::Ex::XBin>(x_p1).a1;
        auto&& r_p1b = prism_rtl::as<crate::lower::model::Ex::XBin>(x_p1).a2;
        auto [lt_p1e, rt_p1f] = ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Text, Text>> _v;
            auto&& _m = cpp_arg_list_f(cp_p0, Array(std::vector{prism_rtl::deref(prism_rtl::deref(l_p1a)), prism_rtl::deref(prism_rtl::deref(r_p1b))}));
            {
                auto&& m5764_0 = _m;
                if (m5764_0.size() == 2u) {
                    {
                        auto&& _c2 = crate::prelude::index(m5764_0, Nat(0u));
                        if (prism_rtl::is_some(_c2)) {
                            auto&& a_p1c = prism_rtl::some_of(_c2);
                            {
                                auto&& _c1 = crate::prelude::index(m5764_0, Nat(1u));
                                if (prism_rtl::is_some(_c1)) {
                                    auto&& b_p1d = prism_rtl::some_of(_c1);
                                    _v.set(std::tuple{a_p1c, b_p1d});
                                    goto _done;
                                }
                            }
                        }
                    }
                }
            }
            {
                _v.set(std::tuple{Text::lit(""), Text::lit("")});
                goto _done;
            }
        _done:
            _v.take();
        });
        return prism_rtl::cat(cpp_loose_f(prism_rtl::deref(prism_rtl::deref(l_p1a)))
            ? prism_rtl::cat("(", lt_p1e, ")")
            : lt_p1e, " ", crate::lower::model::bin_op_text_f(op_p19), " ", cpp_loose_f(prism_rtl::deref(prism_rtl::deref(r_p1b)))
            ? prism_rtl::cat("(", rt_p1f, ")")
            : rt_p1f);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUnary>(x_p1)) {
        auto&& op_p1g = prism_rtl::as<crate::lower::model::Ex::XUnary>(x_p1).a0;
        auto&& y_p1h = prism_rtl::as<crate::lower::model::Ex::XUnary>(x_p1).a1;
        return prism_rtl::cat(crate::lower::model::un_op_text_f(op_p1g), cpp_tight_f(cp_p0, prism_rtl::deref(prism_rtl::deref(y_p1h))));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XCtor>(x_p1)) {
        auto&& p_p1i = prism_rtl::as<crate::lower::model::Ex::XCtor>(x_p1).a0;
        auto&& args_p1j = prism_rtl::as<crate::lower::model::Ex::XCtor>(x_p1).a1;
        return cpp_ctor_f(cp_p0, p_p1i, args_p1j);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRecord>(x_p1)) {
        auto&& p_p1k = prism_rtl::as<crate::lower::model::Ex::XRecord>(x_p1).a0;
        auto&& fs_p1l = prism_rtl::as<crate::lower::model::Ex::XRecord>(x_p1).a1;
        return cpp_record_f(cp_p0, p_p1k, fs_p1l);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTuple>(x_p1)) {
        auto&& xs_p1m = prism_rtl::as<crate::lower::model::Ex::XTuple>(x_p1).a0;
        return prism_rtl::cat("std::tuple{", cpp_args_f(cp_p0, xs_p1m), "}");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XVec>(x_p1)) {
        auto&& m3236_40_0 = prism_rtl::as<crate::lower::model::Ex::XVec>(x_p1).a0;
        if (m3236_40_0.size() == 0u) {
            return Text::lit("{}");
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XVec>(x_p1)) {
        auto&& xs_p1n = prism_rtl::as<crate::lower::model::Ex::XVec>(x_p1).a0;
        return prism_rtl::cat("std::vector{", cpp_args_f(cp_p0, xs_p1n), "}");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XText>(x_p1)) {
        auto&& t_p1o = prism_rtl::as<crate::lower::model::Ex::XText>(x_p1).a0;
        return prism_rtl::cat("Text::lit(", cpp_string_f(t_p1o), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XFormat>(x_p1)) {
        auto&& parts_p1p = prism_rtl::as<crate::lower::model::Ex::XFormat>(x_p1).a0;
        return crate::prelude::fold(parts_p1p, true, [&](const bool& f_p1q, const crate::lower::model::Ex& p_p1r) { return prism_rtl::deref(f_p1q) && is_text_piece_f(p_p1r); })
            ? prism_rtl::cat("Text::lit(", cpp_string_f(crate::prelude::concat(crate::prelude::each(parts_p1p, [&](const crate::lower::model::Ex& p_p1s) { return text_piece_f(p_p1s); }))), ")")
            : cpp_format_f(cp_p0, parts_p1p, Text::lit("prism_rtl::cat"));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XMatch>(x_p1)) {
        auto&& s_p1t = prism_rtl::as<crate::lower::model::Ex::XMatch>(x_p1).a0;
        auto&& arms_p1u = prism_rtl::as<crate::lower::model::Ex::XMatch>(x_p1).a1;
        auto&& fallback_p1v = prism_rtl::as<crate::lower::model::Ex::XMatch>(x_p1).a2;
        auto&& t_p20 = prism_rtl::as<crate::lower::model::Ex::XMatch>(x_p1).a3;
        return crate::emit::cpp::patterns::cpp_match_f(cp_p0, prism_rtl::deref(prism_rtl::deref(s_p1t)), arms_p1u, t_p20);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XChain>(x_p1)) {
        auto&& label_p21 = prism_rtl::as<crate::lower::model::Ex::XChain>(x_p1).a0;
        auto&& s_p22 = prism_rtl::as<crate::lower::model::Ex::XChain>(x_p1).a1;
        auto&& arms_p23 = prism_rtl::as<crate::lower::model::Ex::XChain>(x_p1).a2;
        auto&& t_p24 = prism_rtl::as<crate::lower::model::Ex::XChain>(x_p1).a3;
        return crate::emit::cpp::patterns::cpp_match_f(cp_p0, prism_rtl::deref(prism_rtl::deref(s_p22)), arms_p23, t_p24);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XIf>(x_p1)) {
        auto&& c_p25 = prism_rtl::as<crate::lower::model::Ex::XIf>(x_p1).a0;
        auto&& t_p26 = prism_rtl::as<crate::lower::model::Ex::XIf>(x_p1).a1;
        auto&& e_p27 = prism_rtl::as<crate::lower::model::Ex::XIf>(x_p1).a2;
        return cpp_if_f(cp_p0, prism_rtl::deref(prism_rtl::deref(c_p25)), prism_rtl::deref(prism_rtl::deref(t_p26)), prism_rtl::deref(prism_rtl::deref(e_p27)));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBlock>(x_p1)) {
        auto&& m3236_47_0 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p1).a0;
        auto&& e_p28 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p1).a1;
        if (m3236_47_0.size() == 0u) {
            return cpp_expr_f(cp_p0, prism_rtl::deref(prism_rtl::deref(e_p28)));
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBlock>(x_p1)) {
        auto&& dos_p29 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p1).a0;
        auto&& e_p2a = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p1).a1;
        auto [st_p2b, cp2_p2c] = crate::emit::cpp::stmts::cpp_statements_cp_f(cp_p0, dos_p29);
        return crate::emit::cpp::templates::items::stmt_expr_f(st_p2b, crate::emit::cpp::stmts::unvexed_f(cpp_expr_f(with_move_captures_f(cp2_p2c, dos_p29, prism_rtl::deref(prism_rtl::deref(e_p2a))), prism_rtl::deref(prism_rtl::deref(e_p2a)))));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XLabeled>(x_p1)) {
        auto&& label_p2d = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x_p1).a0;
        auto&& dos_p2e = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x_p1).a1;
        auto&& e_p2f = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x_p1).a2;
        auto&& t_p2g = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x_p1).a3;
        return crate::emit::cpp::patterns::cpp_labeled_f(cp_p0, label_p2d, dos_p2e, prism_rtl::deref(prism_rtl::deref(e_p2f)), t_p2g);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XClosure>(x_p1)) {
        auto&& mv_p2h = prism_rtl::as<crate::lower::model::Ex::XClosure>(x_p1).a0;
        auto&& ps_p2i = prism_rtl::as<crate::lower::model::Ex::XClosure>(x_p1).a1;
        auto&& body_p2j = prism_rtl::as<crate::lower::model::Ex::XClosure>(x_p1).a2;
        return cpp_closure_f(cp_p0, mv_p2h, ps_p2i, prism_rtl::deref(prism_rtl::deref(body_p2j)));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTry>(x_p1)) {
        auto&& y_p2k = prism_rtl::as<crate::lower::model::Ex::XTry>(x_p1).a0;
        return prism_rtl::cat("TRY(", cpp_expr_f(cp_p0, prism_rtl::deref(prism_rtl::deref(y_p2k))), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x_p1)) {
        auto&& r_p2l = prism_rtl::as<crate::lower::model::Ex::XField>(x_p1).a0;
        auto&& f_p2m = prism_rtl::as<crate::lower::model::Ex::XField>(x_p1).a1;
        return cpp_field_f(cp_p0, prism_rtl::deref(prism_rtl::deref(r_p2l)), f_p2m);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XPart>(x_p1)) {
        auto&& r_p2n = prism_rtl::as<crate::lower::model::Ex::XPart>(x_p1).a0;
        auto&& k_p2o = prism_rtl::as<crate::lower::model::Ex::XPart>(x_p1).a1;
        return prism_rtl::cat("std::get<", k_p2o, ">(", as_value_f(cp_p0, prism_rtl::deref(prism_rtl::deref(r_p2n))), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XDecode>(x_p1)) {
        auto&& t_p2p = prism_rtl::as<crate::lower::model::Ex::XDecode>(x_p1).a0;
        auto&& y_p2q = prism_rtl::as<crate::lower::model::Ex::XDecode>(x_p1).a1;
        return prism_rtl::cat("TRY(prism_rtl::from_pod<", crate::emit::cpp::cpp_type_f(cp_p0, t_p2p), ">(", cpp_expr_f(cp_p0, prism_rtl::deref(prism_rtl::deref(y_p2q))), "))");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XCast>(x_p1)) {
        auto&& y_p2r = prism_rtl::as<crate::lower::model::Ex::XCast>(x_p1).a0;
        auto&& t_p2s = prism_rtl::as<crate::lower::model::Ex::XCast>(x_p1).a1;
        return prism_rtl::cat("static_cast<", crate::emit::cpp::cpp_type_f(cp_p0, t_p2s), ">(", cpp_expr_f(cp_p0, prism_rtl::deref(prism_rtl::deref(y_p2r))), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTyped>(x_p1)) {
        auto&& y_p2t = prism_rtl::as<crate::lower::model::Ex::XTyped>(x_p1).a0;
        auto&& t_p2u = prism_rtl::as<crate::lower::model::Ex::XTyped>(x_p1).a1;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(y_p2t));
        if (prism_rtl::is<crate::lower::model::Ex::XCtor>(_m)) {
            auto&& p_p2v = prism_rtl::as<crate::lower::model::Ex::XCtor>(_m).a0;
            auto&& args_p30 = prism_rtl::as<crate::lower::model::Ex::XCtor>(_m).a1;
            if (is_generic_case_f(cp_p0, p_p2v)) {
                auto tt_p31 = crate::emit::cpp::cpp_type_f(cp_p0, t_p2u);
                return prism_rtl::cat(tt_p31, "(", tt_p31, "::", crate::emit::cpp::last_segment_f(crate::emit::cpp::type_path_f(p_p2v)), "{", cpp_args_f(cp_p0, args_p30), "})");
            }
        }
        if (prism_rtl::is<crate::lower::model::Ex::XPath>(_m)) {
            auto&& p_p32 = prism_rtl::as<crate::lower::model::Ex::XPath>(_m).a0;
            if (is_generic_case_f(cp_p0, p_p32)) {
                auto tt_p33 = crate::emit::cpp::cpp_type_f(cp_p0, t_p2u);
                return prism_rtl::cat(tt_p33, "(", tt_p33, "::", crate::emit::cpp::last_segment_f(crate::emit::cpp::type_path_f(p_p32)), "{})");
            }
        }
        {
            auto e_p34 = cpp_expr_f(cp_p0, prism_rtl::deref(prism_rtl::deref(y_p2t)));
            return (e_p34 == Text::lit("{}")) || (e_p34 == Text::lit("std::nullopt"))
                ? prism_rtl::cat(crate::emit::cpp::cpp_type_f(cp_p0, t_p2u), "{}")
                : is_ctor_f(prism_rtl::deref(prism_rtl::deref(y_p2t)), Text::lit("Ok")) || is_ctor_f(prism_rtl::deref(prism_rtl::deref(y_p2t)), Text::lit("Err"))
                ? prism_rtl::cat(crate::emit::cpp::cpp_type_f(cp_p0, t_p2u), "(", e_p34, ")")
                : e_p34;
        }
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> CppExpr::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& x_p1 = this->x_p1;
    return ({
        prism_rtl::is<crate::lower::model::Ex::XVar>(x_p1) ? ({
        auto&& n_p2 = prism_rtl::as<crate::lower::model::Ex::XVar>(x_p1).a0;
        prism_rtl::finished(cpp_var_f(cp_p0, n_p2));
    })
        : prism_rtl::is<crate::lower::model::Ex::XPath>(x_p1) ? ({
        auto&& p_p3 = prism_rtl::as<crate::lower::model::Ex::XPath>(x_p1).a0;
        prism_rtl::finished(path_value_f(cp_p0, p_p3));
    })
        : prism_rtl::is<crate::lower::model::Ex::XSelf>(x_p1) ? prism_rtl::finished(Text::lit("prism_rtl::share(this)"))
        : prism_rtl::is<crate::lower::model::Ex::XCx>(x_p1) ? prism_rtl::finished(Text::lit("cx"))
        : prism_rtl::is<crate::lower::model::Ex::XConst>(x_p1) ? ({
        auto&& n_p4 = prism_rtl::as<crate::lower::model::Ex::XConst>(x_p1).a0;
        prism_rtl::finished(n_p4);
    })
        : prism_rtl::is<crate::lower::model::Ex::XUnit>(x_p1) ? prism_rtl::finished(Text::lit("Unit{}"))
        : prism_rtl::is<crate::lower::model::Ex::XNone>(x_p1) ? prism_rtl::finished(Text::lit("std::nullopt"))
        : prism_rtl::is<crate::lower::model::Ex::XBool>(x_p1) ? ({
        auto&& b_p5 = prism_rtl::as<crate::lower::model::Ex::XBool>(x_p1).a0;
        prism_rtl::deref(b_p5)
        ? prism_rtl::finished(Text::lit("true"))
        : prism_rtl::finished(Text::lit("false"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XNat>(x_p1) ? ({
        auto&& d_p6 = prism_rtl::as<crate::lower::model::Ex::XNat>(x_p1).a0;
        crate::prelude::len_text(d_p6) <= Nat(9u)
        ? prism_rtl::finished(prism_rtl::cat("Nat(", d_p6, "u)"))
        : ({
        auto cp_p0x = cp_p0;
        auto d_p6x = d_p6;
        (crate::prelude::call_then(start_cpp_expr_f(cp_p0x, crate::lower::model::Ex(crate::lower::model::Ex::XInt{d_p6x})), [=](Text cpp_expr_f_3517) { return prism_rtl::finished(prism_rtl::cat("*Nat::from_int(", cpp_expr_f_3517, ")")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XInt>(x_p1) ? ({
        auto&& d_p7 = prism_rtl::as<crate::lower::model::Ex::XInt>(x_p1).a0;
        crate::prelude::len_text(crate::syntax::lexer::chars::has_prefix_f(d_p7, Text::lit("-"))
        ? crate::syntax::lexer::chars::after_first_f(d_p7)
        : d_p7) <= Nat(18u)
        ? prism_rtl::finished(prism_rtl::cat("Int(", d_p7, "ll)"))
        : prism_rtl::finished(prism_rtl::cat("*Int::parse(\"", d_p7, "\")"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XByte>(x_p1) ? ({
        auto&& d_p8 = prism_rtl::as<crate::lower::model::Ex::XByte>(x_p1).a0;
        prism_rtl::finished(prism_rtl::cat("std::uint8_t(", d_p8, ")"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XFloat>(x_p1) ? ({
        auto&& d_p9 = prism_rtl::as<crate::lower::model::Ex::XFloat>(x_p1).a0;
        prism_rtl::finished(prism_rtl::cat("Float{", d_p9, "}"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XIndex>(x_p1) ? ({
        auto&& n_pa = prism_rtl::as<crate::lower::model::Ex::XIndex>(x_p1).a0;
        prism_rtl::finished(prism_rtl::cat(n_pa, "u"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XChar>(x_p1) ? ({
        auto&& c_pb = prism_rtl::as<crate::lower::model::Ex::XChar>(x_p1).a0;
        prism_rtl::finished(prism_rtl::cat("U\'", cpp_char_escape_f(c_pb), "\'"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XStr>(x_p1) ? ({
        auto&& t_pc = prism_rtl::as<crate::lower::model::Ex::XStr>(x_p1).a0;
        prism_rtl::finished(cpp_string_f(t_pc));
    })
        : prism_rtl::is<crate::lower::model::Ex::XRegex>(x_p1) ? ({
        auto&& p_pd = prism_rtl::as<crate::lower::model::Ex::XRegex>(x_p1).a0;
        auto&& f_pe = prism_rtl::as<crate::lower::model::Ex::XRegex>(x_p1).a1;
        prism_rtl::finished(prism_rtl::cat("([]() -> const Regex& { static const Regex r = Regex::lit(", cpp_string_f(p_pd), ", ", cpp_string_f(f_pe), "); return r; }())"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XReplacement>(x_p1) ? ({
        auto&& p_pf = prism_rtl::as<crate::lower::model::Ex::XReplacement>(x_p1).a0;
        auto&& r_pg = prism_rtl::as<crate::lower::model::Ex::XReplacement>(x_p1).a1;
        auto&& f_ph = prism_rtl::as<crate::lower::model::Ex::XReplacement>(x_p1).a2;
        prism_rtl::finished(prism_rtl::cat("([]() -> const RegexReplacement& { static const RegexReplacement r = RegexReplacement::lit(", cpp_string_f(p_pf), ", ", cpp_string_f(f_ph), ", ", cpp_string_f(r_pg), "); return r; }())"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XRef>(x_p1) ? ({
        auto&& y_pi = prism_rtl::as<crate::lower::model::Ex::XRef>(x_p1).a0;
        prism_rtl::more(prism_rtl::rc(CppPlace(cp_p0, prism_rtl::deref(prism_rtl::deref(y_pi)))));
    })
        : prism_rtl::is<crate::lower::model::Ex::XRefMut>(x_p1) ? ({
        auto&& y_pj = prism_rtl::as<crate::lower::model::Ex::XRefMut>(x_p1).a0;
        prism_rtl::more(prism_rtl::rc(CppPlace(cp_p0, prism_rtl::deref(prism_rtl::deref(y_pj)))));
    })
        : prism_rtl::is<crate::lower::model::Ex::XDeref>(x_p1) ? ({
        auto&& y_pk = prism_rtl::as<crate::lower::model::Ex::XDeref>(x_p1).a0;
        ({
        auto&& _m = ex_ty_o(cp_p0, prism_rtl::deref(prism_rtl::deref(y_pk)));
        prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::model::OutTy::OutRc>(prism_rtl::some_of(_m)) ? ({
        auto cp_p0x = cp_p0;
        auto y_pkx = prism_rtl::deref(prism_rtl::deref(y_pk));
        (crate::prelude::call_then(start_cpp_tight_place_f(cp_p0x, y_pkx), [=](Text cpp_tight_place_f_4802) { return prism_rtl::finished(prism_rtl::cat("*", cpp_tight_place_f_4802)); }));
    })
        : prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::model::OutTy::OutRef>(prism_rtl::some_of(_m)) ? prism_rtl::more(prism_rtl::rc(CppPlace(cp_p0, prism_rtl::deref(prism_rtl::deref(y_pk)))))
        : ({
        auto cp_p0x = cp_p0;
        auto y_pkx = prism_rtl::deref(prism_rtl::deref(y_pk));
        (crate::prelude::call_then(start_cpp_place_f(cp_p0x, y_pkx), [=](Text cpp_place_f_4904) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::deref(", cpp_place_f_4904, ")")); }));
    });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XTarget>(x_p1) ? ({
        auto&& y_pl = prism_rtl::as<crate::lower::model::Ex::XTarget>(x_p1).a0;
        prism_rtl::more(prism_rtl::rc(CppPlace(cp_p0, prism_rtl::deref(prism_rtl::deref(y_pl)))));
    })
        : prism_rtl::is<crate::lower::model::Ex::XClone>(x_p1) ? ({
        auto&& y_pm = prism_rtl::as<crate::lower::model::Ex::XClone>(x_p1).a0;
        prism_rtl::more(prism_rtl::rc(CppPlace(cp_p0, prism_rtl::deref(prism_rtl::deref(y_pm)))));
    })
        : prism_rtl::is<crate::lower::model::Ex::XWeak>(x_p1) ? ({
        auto&& y_pn = prism_rtl::as<crate::lower::model::Ex::XWeak>(x_p1).a0;
        ({
        auto cp_p0x = cp_p0;
        auto y_pnx = prism_rtl::deref(prism_rtl::deref(y_pn));
        (crate::prelude::call_then(start_cpp_expr_f(cp_p0x, y_pnx), [=](Text cpp_expr_f_5014) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::weaken(", cpp_expr_f_5014, ")")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XUpgrade>(x_p1) ? ({
        auto&& y_po = prism_rtl::as<crate::lower::model::Ex::XUpgrade>(x_p1).a0;
        ({
        auto cp_p0x = cp_p0;
        auto y_pox = prism_rtl::deref(prism_rtl::deref(y_po));
        (crate::prelude::call_then(start_cpp_expr_f(cp_p0x, y_pox), [=](Text cpp_expr_f_5068) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::upgrade(", cpp_expr_f_5068, ")")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XBreak>(x_p1) ? ({
        auto&& l_pp = prism_rtl::as<crate::lower::model::Ex::XBreak>(x_p1).a0;
        auto&& y_pq = prism_rtl::as<crate::lower::model::Ex::XBreak>(x_p1).a1;
        ({
        auto cp_p0x = cp_p0;
        auto l_ppx = l_pp;
        auto y_pqx = prism_rtl::deref(prism_rtl::deref(y_pq));
        (crate::prelude::call_then(crate::emit::cpp::patterns::start_cpp_break_f(cp_p0x, l_ppx, y_pqx), [=](Text cpp_break_f_5105) { return prism_rtl::finished(prism_rtl::cat("(", cpp_break_f_5105, ")")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XBreakLoop>(x_p1) ? prism_rtl::finished(Text::lit("({ break; })"))
        : prism_rtl::is<crate::lower::model::Ex::XLater>(x_p1) ? ({
        auto&& y_pr = prism_rtl::as<crate::lower::model::Ex::XLater>(x_p1).a0;
        ({
        auto cp_p0x = cp_p0;
        auto y_prx = prism_rtl::deref(prism_rtl::deref(y_pr));
        (crate::prelude::call_then(start_cpp_expr_f(crate::emit::cpp::stmts::captured_f(cp_p0x), y_prx), [=](Text cpp_expr_f_5198) { return prism_rtl::finished(prism_rtl::cat("[=](Cx& cx) -> Done { ", cpp_expr_f_5198, "; return {}; }")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XFormatStr>(x_p1) ? ({
        auto&& parts_ps = prism_rtl::as<crate::lower::model::Ex::XFormatStr>(x_p1).a0;
        prism_rtl::more(prism_rtl::rc(CppFormat(cp_p0, parts_ps, Text::lit("prism_rtl::str"))));
    })
        : prism_rtl::is<crate::lower::model::Ex::XIsCase>(x_p1) && ({
        auto&& y_pt = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x_p1).a0;
        auto&& m3236_28_1 = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x_p1).a1;
        (m3236_28_1.size() == 0u);
    }) ? ({
        auto&& y_pt = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x_p1).a0;
        auto&& m3236_28_1 = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x_p1).a1;
        prism_rtl::finished(Text::lit("false"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XIsCase>(x_p1) ? ({
        auto&& y_pu = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x_p1).a0;
        auto&& cs_pv = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x_p1).a1;
        ({
        auto cp_p0x = cp_p0;
        auto cs_pvx = cs_pv;
        auto y_pux = prism_rtl::deref(prism_rtl::deref(y_pu));
        (crate::prelude::call_value(crate::prelude::each_job(cs_pvx, ({
        auto cp_p0xx = cp_p0x;
        auto y_puxx = y_pux;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Text)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx), y_puxx = std::move(y_puxx)](Text p0) {
        return ({
            auto cp_p0xxy = cp_p0xx;
            auto y_puxxy = y_puxx;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy), y_puxxy = std::move(y_puxxy)]() {
            return ({
                auto c_p10 = p0;
                (crate::prelude::call_then(start_cpp_tight_place_f(cp_p0xxy, y_puxxy), [=, c_p10 = std::move(c_p10)](Text cpp_tight_place_f_5390) { return prism_rtl::finished(case_test_f(cp_p0xxy, c_p10, cpp_tight_place_f_5390)); }));
            });
        })));
        });
    })));
    })), [=](Array<Text> each_5359) { return prism_rtl::finished(prism_rtl::cat("(", crate::syntax::lexer::chars::join_f(each_5359, Text::lit(" || ")), ")")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XRefusal>(x_p1) ? ({
        auto&& what_p11 = prism_rtl::as<crate::lower::model::Ex::XRefusal>(x_p1).a0;
        prism_rtl::finished(prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal_p(), crate::lower::expr::escape_f(what_p11), "\")"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XUnreachable>(x_p1) ? prism_rtl::finished(Text::lit("throw prism_rtl::Panic(\"entered unreachable code\")"))
        : prism_rtl::is<crate::lower::model::Ex::XCall>(x_p1) ? ({
        auto&& f_p12 = prism_rtl::as<crate::lower::model::Ex::XCall>(x_p1).a0;
        auto&& args_p13 = prism_rtl::as<crate::lower::model::Ex::XCall>(x_p1).a1;
        prism_rtl::more(prism_rtl::rc(CppCall(cp_p0, f_p12, args_p13)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XApply>(x_p1) ? ({
        auto&& f_p14 = prism_rtl::as<crate::lower::model::Ex::XApply>(x_p1).a0;
        auto&& args_p15 = prism_rtl::as<crate::lower::model::Ex::XApply>(x_p1).a1;
        ({
        auto args_p15x = args_p15;
        auto cp_p0x = cp_p0;
        auto f_p14x = prism_rtl::deref(prism_rtl::deref(f_p14));
        (crate::prelude::call_then(start_cpp_tight_place_f(cp_p0x, f_p14x), [=, args_p15x = std::move(args_p15x)](Text cpp_tight_place_f_5629) { return crate::prelude::call_then(start_cpp_args_f(cp_p0x, args_p15x), [=](Text cpp_args_f_5651) { return prism_rtl::finished(prism_rtl::cat(cpp_tight_place_f_5629, "(", cpp_args_f_5651, ")")); }); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XMethod>(x_p1) ? ({
        auto&& r_p16 = prism_rtl::as<crate::lower::model::Ex::XMethod>(x_p1).a0;
        auto&& m_p17 = prism_rtl::as<crate::lower::model::Ex::XMethod>(x_p1).a1;
        auto&& args_p18 = prism_rtl::as<crate::lower::model::Ex::XMethod>(x_p1).a2;
        prism_rtl::more(prism_rtl::rc(CppMethod(cp_p0, prism_rtl::deref(prism_rtl::deref(r_p16)), m_p17, args_p18)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XBin>(x_p1) ? ({
        auto&& op_p19 = prism_rtl::as<crate::lower::model::Ex::XBin>(x_p1).a0;
        auto&& l_p1a = prism_rtl::as<crate::lower::model::Ex::XBin>(x_p1).a1;
        auto&& r_p1b = prism_rtl::as<crate::lower::model::Ex::XBin>(x_p1).a2;
        ({
        auto cp_p0x = cp_p0;
        auto l_p1ax = prism_rtl::deref(prism_rtl::deref(l_p1a));
        auto op_p19x = op_p19;
        auto r_p1bx = prism_rtl::deref(prism_rtl::deref(r_p1b));
        (crate::prelude::call_then(start_cpp_arg_list_f(cp_p0x, Array(std::vector{l_p1ax, r_p1bx})), [=, op_p19x = std::move(op_p19x)](Array<Text> cpp_arg_list_f_5770) {
        return ({
            auto [lt_p1e, rt_p1f] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Text, Text>> _v;
                {
                    auto&& m5764_0 = cpp_arg_list_f_5770;
                    if (m5764_0.size() == 2u) {
                        {
                            auto&& _c2 = crate::prelude::index(m5764_0, Nat(0u));
                            if (prism_rtl::is_some(_c2)) {
                                auto&& a_p1c = prism_rtl::some_of(_c2);
                                {
                                    auto&& _c1 = crate::prelude::index(m5764_0, Nat(1u));
                                    if (prism_rtl::is_some(_c1)) {
                                        auto&& b_p1d = prism_rtl::some_of(_c1);
                                        _v.set(std::tuple{a_p1c, b_p1d});
                                        goto _done;
                                    }
                                }
                            }
                        }
                    }
                }
                {
                    _v.set(std::tuple{Text::lit(""), Text::lit("")});
                    goto _done;
                }
            _done:
                _v.take();
            });
            (prism_rtl::finished(prism_rtl::cat(cpp_loose_f(l_p1ax) ? prism_rtl::cat("(", lt_p1e, ")") : lt_p1e, " ", crate::lower::model::bin_op_text_f(op_p19x), " ", cpp_loose_f(r_p1bx) ? prism_rtl::cat("(", rt_p1f, ")") : rt_p1f)));
        });
    }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XUnary>(x_p1) ? ({
        auto&& op_p1g = prism_rtl::as<crate::lower::model::Ex::XUnary>(x_p1).a0;
        auto&& y_p1h = prism_rtl::as<crate::lower::model::Ex::XUnary>(x_p1).a1;
        ({
        auto cp_p0x = cp_p0;
        auto op_p1gx = op_p1g;
        auto y_p1hx = prism_rtl::deref(prism_rtl::deref(y_p1h));
        (crate::prelude::call_then(start_cpp_tight_f(cp_p0x, y_p1hx), [=, op_p1gx = std::move(op_p1gx)](Text cpp_tight_f_5988) { return prism_rtl::finished(prism_rtl::cat(crate::lower::model::un_op_text_f(op_p1gx), cpp_tight_f_5988)); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XCtor>(x_p1) ? ({
        auto&& p_p1i = prism_rtl::as<crate::lower::model::Ex::XCtor>(x_p1).a0;
        auto&& args_p1j = prism_rtl::as<crate::lower::model::Ex::XCtor>(x_p1).a1;
        prism_rtl::more(prism_rtl::rc(CppCtor(cp_p0, p_p1i, args_p1j)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XRecord>(x_p1) ? ({
        auto&& p_p1k = prism_rtl::as<crate::lower::model::Ex::XRecord>(x_p1).a0;
        auto&& fs_p1l = prism_rtl::as<crate::lower::model::Ex::XRecord>(x_p1).a1;
        prism_rtl::more(prism_rtl::rc(CppRecord(cp_p0, p_p1k, fs_p1l)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XTuple>(x_p1) ? ({
        auto&& xs_p1m = prism_rtl::as<crate::lower::model::Ex::XTuple>(x_p1).a0;
        ({
        auto cp_p0x = cp_p0;
        auto xs_p1mx = xs_p1m;
        (crate::prelude::call_then(start_cpp_args_f(cp_p0x, xs_p1mx), [=](Text cpp_args_f_6112) { return prism_rtl::finished(prism_rtl::cat("std::tuple{", cpp_args_f_6112, "}")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XVec>(x_p1) && ({
        auto&& m3236_40_0 = prism_rtl::as<crate::lower::model::Ex::XVec>(x_p1).a0;
        (m3236_40_0.size() == 0u);
    }) ? ({
        auto&& m3236_40_0 = prism_rtl::as<crate::lower::model::Ex::XVec>(x_p1).a0;
        prism_rtl::finished(Text::lit("{}"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XVec>(x_p1) ? ({
        auto&& xs_p1n = prism_rtl::as<crate::lower::model::Ex::XVec>(x_p1).a0;
        ({
        auto cp_p0x = cp_p0;
        auto xs_p1nx = xs_p1n;
        (crate::prelude::call_then(start_cpp_args_f(cp_p0x, xs_p1nx), [=](Text cpp_args_f_6181) { return prism_rtl::finished(prism_rtl::cat("std::vector{", cpp_args_f_6181, "}")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XText>(x_p1) ? ({
        auto&& t_p1o = prism_rtl::as<crate::lower::model::Ex::XText>(x_p1).a0;
        prism_rtl::finished(prism_rtl::cat("Text::lit(", cpp_string_f(t_p1o), ")"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XFormat>(x_p1) ? ({
        auto&& parts_p1p = prism_rtl::as<crate::lower::model::Ex::XFormat>(x_p1).a0;
        crate::prelude::fold(parts_p1p, true, [&](const bool& f_p1q, const crate::lower::model::Ex& p_p1r) { return prism_rtl::deref(f_p1q) && is_text_piece_f(p_p1r); })
        ? prism_rtl::finished(prism_rtl::cat("Text::lit(", cpp_string_f(crate::prelude::concat(crate::prelude::each(parts_p1p, [&](const crate::lower::model::Ex& p_p1s) { return text_piece_f(p_p1s); }))), ")"))
        : prism_rtl::more(prism_rtl::rc(CppFormat(cp_p0, parts_p1p, Text::lit("prism_rtl::cat"))));
    })
        : prism_rtl::is<crate::lower::model::Ex::XMatch>(x_p1) ? ({
        auto&& s_p1t = prism_rtl::as<crate::lower::model::Ex::XMatch>(x_p1).a0;
        auto&& arms_p1u = prism_rtl::as<crate::lower::model::Ex::XMatch>(x_p1).a1;
        auto&& fallback_p1v = prism_rtl::as<crate::lower::model::Ex::XMatch>(x_p1).a2;
        auto&& t_p20 = prism_rtl::as<crate::lower::model::Ex::XMatch>(x_p1).a3;
        prism_rtl::more(prism_rtl::rc(crate::emit::cpp::patterns::CppMatch(cp_p0, prism_rtl::deref(prism_rtl::deref(s_p1t)), arms_p1u, t_p20)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XChain>(x_p1) ? ({
        auto&& label_p21 = prism_rtl::as<crate::lower::model::Ex::XChain>(x_p1).a0;
        auto&& s_p22 = prism_rtl::as<crate::lower::model::Ex::XChain>(x_p1).a1;
        auto&& arms_p23 = prism_rtl::as<crate::lower::model::Ex::XChain>(x_p1).a2;
        auto&& t_p24 = prism_rtl::as<crate::lower::model::Ex::XChain>(x_p1).a3;
        prism_rtl::more(prism_rtl::rc(crate::emit::cpp::patterns::CppMatch(cp_p0, prism_rtl::deref(prism_rtl::deref(s_p22)), arms_p23, t_p24)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XIf>(x_p1) ? ({
        auto&& c_p25 = prism_rtl::as<crate::lower::model::Ex::XIf>(x_p1).a0;
        auto&& t_p26 = prism_rtl::as<crate::lower::model::Ex::XIf>(x_p1).a1;
        auto&& e_p27 = prism_rtl::as<crate::lower::model::Ex::XIf>(x_p1).a2;
        prism_rtl::more(prism_rtl::rc(CppIf(cp_p0, prism_rtl::deref(prism_rtl::deref(c_p25)), prism_rtl::deref(prism_rtl::deref(t_p26)), prism_rtl::deref(prism_rtl::deref(e_p27)))));
    })
        : prism_rtl::is<crate::lower::model::Ex::XBlock>(x_p1) && ({
        auto&& m3236_47_0 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p1).a0;
        auto&& e_p28 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p1).a1;
        (m3236_47_0.size() == 0u);
    }) ? ({
        auto&& m3236_47_0 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p1).a0;
        auto&& e_p28 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p1).a1;
        prism_rtl::more(prism_rtl::rc(CppExpr(cp_p0, prism_rtl::deref(prism_rtl::deref(e_p28)))));
    })
        : prism_rtl::is<crate::lower::model::Ex::XBlock>(x_p1) ? ({
        auto&& dos_p29 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p1).a0;
        auto&& e_p2a = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p1).a1;
        ({
        auto cp_p0x = cp_p0;
        auto dos_p29x = dos_p29;
        auto e_p2ax = prism_rtl::deref(prism_rtl::deref(e_p2a));
        (crate::prelude::call_then(crate::emit::cpp::stmts::start_cpp_statements_cp_f(cp_p0x, dos_p29x), [=, e_p2ax = std::move(e_p2ax)](std::tuple<Text, crate::emit::cpp::Cp> cpp_statements_cp_f_6643) {
        return ({
            auto [st_p2b, cp2_p2c] = cpp_statements_cp_f_6643;
            (crate::prelude::call_then(start_with_move_captures_f(cp2_p2c, dos_p29x, e_p2ax), [=](crate::emit::cpp::Cp with_move_captures_f_6707) { return crate::prelude::call_then(start_cpp_expr_f(with_move_captures_f_6707, e_p2ax), [=](Text cpp_expr_f_6698) { return prism_rtl::finished(crate::emit::cpp::templates::items::stmt_expr_f(st_p2b, crate::emit::cpp::stmts::unvexed_f(cpp_expr_f_6698))); }); }));
        });
    }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XLabeled>(x_p1) ? ({
        auto&& label_p2d = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x_p1).a0;
        auto&& dos_p2e = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x_p1).a1;
        auto&& e_p2f = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x_p1).a2;
        auto&& t_p2g = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x_p1).a3;
        prism_rtl::more(prism_rtl::rc(crate::emit::cpp::patterns::CppLabeled(cp_p0, label_p2d, dos_p2e, prism_rtl::deref(prism_rtl::deref(e_p2f)), t_p2g)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XClosure>(x_p1) ? ({
        auto&& mv_p2h = prism_rtl::as<crate::lower::model::Ex::XClosure>(x_p1).a0;
        auto&& ps_p2i = prism_rtl::as<crate::lower::model::Ex::XClosure>(x_p1).a1;
        auto&& body_p2j = prism_rtl::as<crate::lower::model::Ex::XClosure>(x_p1).a2;
        prism_rtl::more(prism_rtl::rc(CppClosure(cp_p0, prism_rtl::deref(mv_p2h), ps_p2i, prism_rtl::deref(prism_rtl::deref(body_p2j)))));
    })
        : prism_rtl::is<crate::lower::model::Ex::XTry>(x_p1) ? ({
        auto&& y_p2k = prism_rtl::as<crate::lower::model::Ex::XTry>(x_p1).a0;
        ({
        auto cp_p0x = cp_p0;
        auto y_p2kx = prism_rtl::deref(prism_rtl::deref(y_p2k));
        (crate::prelude::call_then(start_cpp_expr_f(cp_p0x, y_p2kx), [=](Text cpp_expr_f_6878) { return prism_rtl::finished(prism_rtl::cat("TRY(", cpp_expr_f_6878, ")")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XField>(x_p1) ? ({
        auto&& r_p2l = prism_rtl::as<crate::lower::model::Ex::XField>(x_p1).a0;
        auto&& f_p2m = prism_rtl::as<crate::lower::model::Ex::XField>(x_p1).a1;
        prism_rtl::more(prism_rtl::rc(CppField(cp_p0, prism_rtl::deref(prism_rtl::deref(r_p2l)), f_p2m)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XPart>(x_p1) ? ({
        auto&& r_p2n = prism_rtl::as<crate::lower::model::Ex::XPart>(x_p1).a0;
        auto&& k_p2o = prism_rtl::as<crate::lower::model::Ex::XPart>(x_p1).a1;
        ({
        auto cp_p0x = cp_p0;
        auto k_p2ox = k_p2o;
        auto r_p2nx = prism_rtl::deref(prism_rtl::deref(r_p2n));
        (crate::prelude::call_then(start_as_value_f(cp_p0x, r_p2nx), [=, k_p2ox = std::move(k_p2ox)](Text as_value_f_6962) { return prism_rtl::finished(prism_rtl::cat("std::get<", k_p2ox, ">(", as_value_f_6962, ")")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XDecode>(x_p1) ? ({
        auto&& t_p2p = prism_rtl::as<crate::lower::model::Ex::XDecode>(x_p1).a0;
        auto&& y_p2q = prism_rtl::as<crate::lower::model::Ex::XDecode>(x_p1).a1;
        ({
        auto cp_p0x = cp_p0;
        auto t_p2px = t_p2p;
        auto y_p2qx = prism_rtl::deref(prism_rtl::deref(y_p2q));
        (crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x, t_p2px), [=, y_p2qx = std::move(y_p2qx)](Text cpp_type_f_7023) { return crate::prelude::call_then(start_cpp_expr_f(cp_p0x, y_p2qx), [=](Text cpp_expr_f_7040) { return prism_rtl::finished(prism_rtl::cat("TRY(prism_rtl::from_pod<", cpp_type_f_7023, ">(", cpp_expr_f_7040, "))")); }); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XCast>(x_p1) ? ({
        auto&& y_p2r = prism_rtl::as<crate::lower::model::Ex::XCast>(x_p1).a0;
        auto&& t_p2s = prism_rtl::as<crate::lower::model::Ex::XCast>(x_p1).a1;
        ({
        auto cp_p0x = cp_p0;
        auto t_p2sx = t_p2s;
        auto y_p2rx = prism_rtl::deref(prism_rtl::deref(y_p2r));
        (crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x, t_p2sx), [=, y_p2rx = std::move(y_p2rx)](Text cpp_type_f_7088) { return crate::prelude::call_then(start_cpp_expr_f(cp_p0x, y_p2rx), [=](Text cpp_expr_f_7105) { return prism_rtl::finished(prism_rtl::cat("static_cast<", cpp_type_f_7088, ">(", cpp_expr_f_7105, ")")); }); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XTyped>(x_p1) ? ({
        auto&& y_p2t = prism_rtl::as<crate::lower::model::Ex::XTyped>(x_p1).a0;
        auto&& t_p2u = prism_rtl::as<crate::lower::model::Ex::XTyped>(x_p1).a1;
        ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(y_p2t));
        prism_rtl::is<crate::lower::model::Ex::XCtor>(_m) && ({
        auto&& p_p2v = prism_rtl::as<crate::lower::model::Ex::XCtor>(_m).a0;
        auto&& args_p30 = prism_rtl::as<crate::lower::model::Ex::XCtor>(_m).a1;
        is_generic_case_f(cp_p0, p_p2v);
    }) ? ({
        auto&& p_p2v = prism_rtl::as<crate::lower::model::Ex::XCtor>(_m).a0;
        auto&& args_p30 = prism_rtl::as<crate::lower::model::Ex::XCtor>(_m).a1;
        ({
        auto args_p30x = args_p30;
        auto cp_p0x = cp_p0;
        auto p_p2vx = p_p2v;
        auto t_p2ux = t_p2u;
        (crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x, t_p2ux), [=, args_p30x = std::move(args_p30x), p_p2vx = std::move(p_p2vx)](Text cpp_type_f_7215) {
        return ({
            auto tt_p31 = cpp_type_f_7215;
            (crate::prelude::call_then(start_cpp_args_f(cp_p0x, args_p30x), [=, tt_p31 = std::move(tt_p31)](Text cpp_args_f_7282) { return prism_rtl::finished(prism_rtl::cat(tt_p31, "(", tt_p31, "::", crate::emit::cpp::last_segment_f(crate::emit::cpp::type_path_f(p_p2vx)), "{", cpp_args_f_7282, "})")); }));
        });
    }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XPath>(_m) && ({
        auto&& p_p32 = prism_rtl::as<crate::lower::model::Ex::XPath>(_m).a0;
        is_generic_case_f(cp_p0, p_p32);
    }) ? ({
        auto&& p_p32 = prism_rtl::as<crate::lower::model::Ex::XPath>(_m).a0;
        ({
        auto cp_p0x = cp_p0;
        auto p_p32x = p_p32;
        auto t_p2ux = t_p2u;
        (crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x, t_p2ux), [=, p_p32x = std::move(p_p32x)](Text cpp_type_f_7365) {
        return ({
            auto tt_p33 = cpp_type_f_7365;
            (prism_rtl::finished(prism_rtl::cat(tt_p33, "(", tt_p33, "::", crate::emit::cpp::last_segment_f(crate::emit::cpp::type_path_f(p_p32x)), "{})")));
        });
    }));
    });
    })
        : ({
        auto cp_p0x = cp_p0;
        auto t_p2ux = t_p2u;
        auto y_p2tx = prism_rtl::deref(prism_rtl::deref(y_p2t));
        (crate::prelude::call_then(start_cpp_expr_f(cp_p0x, y_p2tx), [=, t_p2ux = std::move(t_p2ux)](Text cpp_expr_f_7475) {
        return ({
            auto e_p34 = cpp_expr_f_7475;
            (e_p34 == Text::lit("{}")) || (e_p34 == Text::lit("std::nullopt"))
            ? crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x, t_p2ux), [=](Text cpp_type_f_7542) { return prism_rtl::finished(prism_rtl::cat(cpp_type_f_7542, "{}")); })
            : is_ctor_f(y_p2tx, Text::lit("Ok")) || is_ctor_f(y_p2tx, Text::lit("Err"))
            ? crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x, t_p2ux), [=](Text cpp_type_f_7622) { return prism_rtl::finished(prism_rtl::cat(cpp_type_f_7622, "(", e_p34, ")")); })
            : prism_rtl::finished(e_p34);
        });
    }));
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CppExpr, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_expr_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex x_p1) {
    return prism_rtl::make_rc<CppExpr>(cp_p0, x_p1);
}


/// CppString: fn Text -> Text
Text cpp_string_f(const Text& t_p0) {
    return crate::syntax::lexer::chars::contains_f(t_p0, Text::lit("\000"sv))
        ? prism_rtl::cat("\"", cpp_escape_f(t_p0), "\"sv")
        : prism_rtl::cat("\"", cpp_escape_f(t_p0), "\"");
}


/// CppEscape: fn Text -> Text
Text cpp_escape_f(const Text& t_p0) {
    return crate::syntax::lexer::chars::map_chars_f(t_p0, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Text)>>(prism_rtl::rc([=](Text p0) {
        return crate::prelude::once_job([=]() {
            return ({
                auto c_p1 = p0;
                c_p1 == Text::lit("\000"sv)
                ? prism_rtl::finished(Text::lit("\\000"))
                : prism_rtl::finished(crate::lower::expr::char_escape_f(c_p1));
            });
        });
    })));
}


/// IsTextPiece: fn Ex -> Bool
bool is_text_piece_f(const crate::lower::model::Ex& ex0) {
    if (prism_rtl::is<crate::lower::model::Ex::XText>(ex0)) {
        return true;
    }
    {
        auto&& other_p0 = ex0;
        return false;
    }
}


/// TextPiece: fn Ex -> Text
Text text_piece_f(const crate::lower::model::Ex& ex0) {
    if (prism_rtl::is<crate::lower::model::Ex::XText>(ex0)) {
        auto&& t_p0 = prism_rtl::as<crate::lower::model::Ex::XText>(ex0).a0;
        return t_p0;
    }
    {
        auto&& other_p1 = ex0;
        return Text::lit("");
    }
}


/// CppFormat: unbounded fn Cp, [Ex], Text -> Text
Text cpp_format_f(const crate::emit::cpp::Cp& cp_p0, const Array<crate::lower::model::Ex>& parts_p1, const Text& how_p2) {
    return prism_rtl::cat(how_p2, "(", crate::syntax::lexer::chars::join_f(cpp_arg_list_f(cp_p0, crate::prelude::each(parts_p1, [&](const crate::lower::model::Ex& p_p3) { return format_arg_f(p_p3); })), Text::lit(", ")), ")");
}


prism_rtl::Turn<Text> CppFormat::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& parts_p1 = this->parts_p1;
    const auto& how_p2 = this->how_p2;
    auto cp_p0x = cp_p0;
    auto how_p2x = how_p2;
    auto parts_p1x = parts_p1;
    return crate::prelude::call_then(start_cpp_arg_list_f(cp_p0x, crate::prelude::each(parts_p1x, [&](const crate::lower::model::Ex& p_p3) { return format_arg_f(p_p3); })), [=](Array<Text> cpp_arg_list_f_8418) { return prism_rtl::finished(prism_rtl::cat(how_p2x, "(", crate::syntax::lexer::chars::join_f(cpp_arg_list_f_8418, Text::lit(", ")), ")")); });
}


/// `Start CppFormat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_format_f(crate::emit::cpp::Cp cp_p0, Array<crate::lower::model::Ex> parts_p1, Text how_p2) {
    return prism_rtl::make_rc<CppFormat>(cp_p0, parts_p1, how_p2);
}


/// FormatArg: fn Ex -> Ex
crate::lower::model::Ex format_arg_f(const crate::lower::model::Ex& ex0) {
    if (prism_rtl::is<crate::lower::model::Ex::XText>(ex0)) {
        auto&& t_p0 = prism_rtl::as<crate::lower::model::Ex::XText>(ex0).a0;
        return crate::lower::model::Ex(crate::lower::model::Ex::XStr{t_p0});
    }
    {
        auto&& x_p1 = ex0;
        return x_p1;
    }
}


/// CppCharEscape: fn Text -> Text
Text cpp_char_escape_f(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("\'")) {
            return Text::lit("\\\'");
        }
    }
    {
        auto&& c_p0 = text0;
        return crate::lower::expr::char_escape_f(c_p0);
    }
}


/// PathValue: fn Cp, Text -> Text
Text path_value_f(const crate::emit::cpp::Cp& cp_p0, const Text& p_p1) {
    return is_node_method_f(cp_p0, p_p1)
        ? prism_rtl::cat("&", crate::emit::cpp::type_path_f(crate::emit::cpp::parent_path_f(p_p1)), "::", node_method_name_f(cp_p0, crate::emit::cpp::last_segment_f(p_p1)))
        : ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = crate::emit::cpp::case_of_o(cp_p0, p_p1);
        if (prism_rtl::is_some(_m)) {
            auto&& ty_p2 = prism_rtl::some_of(_m);
            _v.set(prism_rtl::cat(crate::emit::cpp::type_path_f(ty_p2), "(", crate::emit::cpp::type_path_f(p_p1), "{})"));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = crate::emit::cpp::type_of_o(cp_p0, p_p1);
                if (prism_rtl::is_some(_m)) {
                    auto&& info_p3 = prism_rtl::some_of(_m);
                    _v.set(prism_rtl::deref(info_p3).kind_p == Text::lit("unit")
                        ? prism_rtl::cat(crate::emit::cpp::type_path_f(p_p1), "{}")
                        : crate::emit::cpp::type_path_f(p_p1));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(crate::emit::cpp::type_path_f(p_p1));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// IsNodeMethod: fn Cp, Text -> Bool
bool is_node_method_f(const crate::emit::cpp::Cp& cp_p0, const Text& p_p1) {
    auto named_p2 = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = crate::prelude::get(cp_p0.methods_p, crate::emit::cpp::last_segment_f(p_p1));
        if (prism_rtl::is_some(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return std::move(named_p2) && is_node_type_f(cp_p0, crate::emit::cpp::parent_path_f(p_p1));
}


/// IsNodeType: fn Cp, Text -> Bool
bool is_node_type_f(const crate::emit::cpp::Cp& cp_p0, const Text& p_p1) {
    auto&& _m = crate::emit::cpp::type_of_o(cp_p0, p_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& info_p2 = prism_rtl::some_of(_m);
        return prism_rtl::deref(info_p2).kind_p == Text::lit("node");
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// CppField: unbounded fn Cp, Ex, Text -> Text
Text cpp_field_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Ex& ex1, const Text& f_p1) {
    if (prism_rtl::is<crate::lower::model::Ex::XSelf>(ex1)) {
        return prism_rtl::cat("this->", crate::emit::cpp::field_id_f(f_p1));
    }
    {
        auto&& r_p3 = ex1;
        auto name_p5 = is_digits_f(f_p1)
            ? prism_rtl::cat("a", f_p1)
            : crate::emit::cpp::field_id_f(f_p1);
        auto&& _m = pointer_o(cp_p0, r_p3);
        if (prism_rtl::is_some(_m)) {
            auto&& b_p6 = prism_rtl::some_of(_m);
            return prism_rtl::cat(cpp_tight_place_f(cp_p0, r_p3), b_p6 ? Text::lit("->") : Text::lit("."), name_p5);
        }
        if (prism_rtl::is_none(_m)) {
            auto&& _m = crate::prelude::get(cp_p0.members_p, f_p1);
            if (prism_rtl::is_some(_m)) {
                return prism_rtl::cat(cpp_tight_place_f(cp_p0, r_p3), "->", name_p5);
            }
            if (prism_rtl::is_none(_m)) {
                return prism_rtl::cat(as_value_f(cp_p0, r_p3), ".", name_p5);
            }
            prism_rtl::unreachable("no arm matched");
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<Text> CppField::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& ex1 = this->ex1;
    const auto& f_p1 = this->f_p1;
    return ({
        prism_rtl::is<crate::lower::model::Ex::XSelf>(ex1) ? prism_rtl::finished(prism_rtl::cat("this->", crate::emit::cpp::field_id_f(f_p1)))
        : ({
        auto&& r_p3 = ex1;
        ({
        auto name_p5 = is_digits_f(f_p1)
            ? prism_rtl::cat("a", f_p1)
            : crate::emit::cpp::field_id_f(f_p1);
        ({
        auto&& _m = pointer_o(cp_p0, r_p3);
        prism_rtl::is_some(_m) ? ({
        auto&& b_p6 = prism_rtl::some_of(_m);
        ({
        auto cp_p0x = cp_p0;
        auto r_p3x = r_p3;
        (crate::prelude::call_then(start_cpp_tight_place_f(cp_p0x, r_p3x), [=](Text cpp_tight_place_f_10151) { return prism_rtl::finished(prism_rtl::cat(cpp_tight_place_f_10151, b_p6 ? Text::lit("->") : Text::lit("."), name_p5)); }));
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(cp_p0).members_p, f_p1);
        prism_rtl::is_some(_m) ? ({
        auto cp_p0x = cp_p0;
        auto r_p3x = r_p3;
        (crate::prelude::call_then(start_cpp_tight_place_f(cp_p0x, r_p3x), [=](Text cpp_tight_place_f_10259) { return prism_rtl::finished(prism_rtl::cat(cpp_tight_place_f_10259, "->", name_p5)); }));
    })
        : prism_rtl::is_none(_m) ? ({
        auto cp_p0x = cp_p0;
        auto r_p3x = r_p3;
        (crate::prelude::call_then(start_as_value_f(cp_p0x, r_p3x), [=](Text as_value_f_10308) { return prism_rtl::finished(prism_rtl::cat(as_value_f_10308, ".", name_p5)); }));
    })
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    });
    });
}


/// `Start CppField, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_field_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex ex1, Text f_p1) {
    return prism_rtl::make_rc<CppField>(cp_p0, ex1, f_p1);
}


/// AsValue: unbounded fn Cp, Ex -> Text
Text as_value_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Ex& r_p1) {
    auto&& _m = pointer_o(cp_p0, r_p1);
    if (prism_rtl::is_some(_m) && !prism_rtl::some_of(_m)) {
        return cpp_tight_place_f(cp_p0, r_p1);
    }
    {
        return prism_rtl::cat("prism_rtl::deref(", cpp_place_f(cp_p0, r_p1), ")");
    }
}


prism_rtl::Turn<Text> AsValue::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& r_p1 = this->r_p1;
    return ({
        auto&& _m = pointer_o(cp_p0, r_p1);
        prism_rtl::is_some(_m) && !prism_rtl::some_of(_m) ? prism_rtl::more(prism_rtl::rc(CppTightPlace(cp_p0, r_p1)))
        : ({
        auto cp_p0x = cp_p0;
        auto r_p1x = r_p1;
        (crate::prelude::call_then(start_cpp_place_f(cp_p0x, r_p1x), [=](Text cpp_place_f_10591) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::deref(", cpp_place_f_10591, ")")); }));
    });
    });
}


/// `Start AsValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_as_value_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex r_p1) {
    return prism_rtl::make_rc<AsValue>(cp_p0, r_p1);
}


/// ?ExTy: fn Cp, Ex -> ?OutTy
std::optional<crate::lower::model::OutTy> ex_ty_o(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Ex& x_p1) {
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(x_p1)) {
        auto&& n_p2 = prism_rtl::as<crate::lower::model::Ex::XVar>(x_p1).a0;
        return crate::prelude::get(cp_p0.local_types_p, n_p2);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x_p1)) {
        auto&& m10828_1_0 = prism_rtl::as<crate::lower::model::Ex::XField>(x_p1).a0;
        auto&& f_p3 = prism_rtl::as<crate::lower::model::Ex::XField>(x_p1).a1;
        if (prism_rtl::is<crate::lower::model::Ex::XSelf>(prism_rtl::deref(prism_rtl::deref(m10828_1_0)))) {
            return crate::prelude::get(cp_p0.fields_p, f_p3);
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x_p1)) {
        auto&& m10828_2_0 = prism_rtl::as<crate::lower::model::Ex::XField>(x_p1).a0;
        auto&& f_p4 = prism_rtl::as<crate::lower::model::Ex::XField>(x_p1).a1;
        if (prism_rtl::is<crate::lower::model::Ex::XVar>(prism_rtl::deref(prism_rtl::deref(m10828_2_0)))) {
            auto&& m10828_2_0_r_0 = prism_rtl::as<crate::lower::model::Ex::XVar>(prism_rtl::deref(prism_rtl::deref(m10828_2_0))).a0;
            if (m10828_2_0_r_0 == Text::lit("node")) {
                return crate::prelude::get(cp_p0.fields_p, f_p4);
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRef>(x_p1)) {
        auto&& y_p5 = prism_rtl::as<crate::lower::model::Ex::XRef>(x_p1).a0;
        auto&& _m = ex_ty_o(cp_p0, prism_rtl::deref(prism_rtl::deref(y_p5)));
        if (prism_rtl::is_some(_m)) {
            auto&& t_p6 = prism_rtl::some_of(_m);
            return std::optional(crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(t_p6)}));
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional<crate::lower::model::OutTy>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XDeref>(x_p1)) {
        auto&& y_p7 = prism_rtl::as<crate::lower::model::Ex::XDeref>(x_p1).a0;
        auto&& _m = ex_ty_o(cp_p0, prism_rtl::deref(prism_rtl::deref(y_p7)));
        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::model::OutTy::OutRef>(prism_rtl::some_of(_m))) {
            auto&& t_p8 = prism_rtl::as<crate::lower::model::OutTy::OutRef>(prism_rtl::some_of(_m)).a0;
            return std::optional(prism_rtl::deref(t_p8));
        }
        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::model::OutTy::OutRc>(prism_rtl::some_of(_m))) {
            auto&& t_p9 = prism_rtl::as<crate::lower::model::OutTy::OutRc>(prism_rtl::some_of(_m)).a0;
            return std::optional(prism_rtl::deref(t_p9));
        }
        {
            return std::optional<crate::lower::model::OutTy>{};
        }
    }
    {
        return std::optional<crate::lower::model::OutTy>{};
    }
}


/// IsDigits: fn Text -> Bool
bool is_digits_f(const Text& t_p0) {
    return (t_p0 != Text::lit("")) && crate::syntax::lexer::chars::fold_chars_f(t_p0, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Text>)>>(prism_rtl::rc([=](std::tuple<bool, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::once_job([=]() {
            return ({
                auto ok_p1 = p0;
                auto c_p2 = p1;
                (prism_rtl::finished(std::move(ok_p1) && crate::syntax::lexer::chars::contains_f(Text::lit("0123456789"), c_p2)));
            });
        });
    })));
}


/// CppCtor: unbounded fn Cp, Text, [Ex] -> Text
Text cpp_ctor_f(const crate::emit::cpp::Cp& cp_p0, const Text& p_p1, const Array<crate::lower::model::Ex>& args_p2) {
    {
        auto&& m11460_0 = p_p1;
        if (m11460_0 == Text::lit("Some")) {
            return prism_rtl::cat("std::optional(", cpp_args_f(cp_p0, args_p2), ")");
        }
    }
    {
        auto&& m11460_1 = p_p1;
        if (m11460_1 == Text::lit("Ok")) {
            return args_p2 == Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})})
                ? Text::lit("prism_rtl::ok()")
                : cpp_args_f(cp_p0, args_p2);
        }
    }
    {
        auto&& m11460_2 = p_p1;
        if (m11460_2 == Text::lit("Err")) {
            return prism_rtl::cat("unexpected(", cpp_args_f(cp_p0, args_p2), ")");
        }
    }
    {
        auto&& m11460_3 = p_p1;
        if (m11460_3 == Text::lit("prism_rtl::Turn::More")) {
            return prism_rtl::cat("prism_rtl::more(", cpp_args_f(cp_p0, args_p2), ")");
        }
    }
    {
        auto&& m11460_4 = p_p1;
        if (m11460_4 == Text::lit("prism_rtl::Turn::Finished")) {
            return prism_rtl::cat("prism_rtl::finished(", cpp_args_f(cp_p0, args_p2), ")");
        }
    }
    {
        auto&& m11460_5 = p_p1;
        if (m11460_5 == Text::lit("Outcome::Fired")) {
            return prism_rtl::cat("Outcome::fired(", cpp_args_f(cp_p0, args_p2), ")");
        }
    }
    {
        auto&& m11460_6 = p_p1;
        if (m11460_6 == Text::lit("Outcome::Value")) {
            return prism_rtl::cat("Outcome::value(", cpp_args_f(cp_p0, args_p2), ")");
        }
    }
    {
        auto&& m11460_7 = p_p1;
        if (m11460_7 == Text::lit("Segment::Pos")) {
            return prism_rtl::cat("Segment::pos(", cpp_args_f(cp_p0, args_p2), ")");
        }
    }
    {
        auto&& m11460_8 = p_p1;
        if (m11460_8 == Text::lit("Segment::Gen")) {
            return prism_rtl::cat("Segment::gen(", cpp_args_f(cp_p0, args_p2), ")");
        }
    }
    {
        auto&& m11460_9 = p_p1;
        if (m11460_9 == Text::lit("Segment::Key")) {
            return prism_rtl::cat("Segment::key(", cpp_args_f(cp_p0, args_p2), ")");
        }
    }
    {
        auto&& _m = crate::emit::cpp::case_of_o(cp_p0, p_p1);
        if (prism_rtl::is_some(_m)) {
            auto&& ty_p3 = prism_rtl::some_of(_m);
            return prism_rtl::cat(crate::emit::cpp::type_path_f(ty_p3), "(", crate::emit::cpp::type_path_f(p_p1), "{", cpp_args_f(cp_p0, args_p2), "})");
        }
        if (prism_rtl::is_none(_m)) {
            return prism_rtl::cat(crate::emit::cpp::type_path_f(p_p1), "{", cpp_args_f(cp_p0, args_p2), "}");
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<Text> CppCtor::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& p_p1 = this->p_p1;
    const auto& args_p2 = this->args_p2;
    return ({
        ({
        auto&& m11460_0 = p_p1;
        (m11460_0 == Text::lit("Some"));
    }) ? ({
        auto&& m11460_0 = p_p1;
        ({
        auto args_p2x = args_p2;
        auto cp_p0x = cp_p0;
        (crate::prelude::call_then(start_cpp_args_f(cp_p0x, args_p2x), [=](Text cpp_args_f_11497) { return prism_rtl::finished(prism_rtl::cat("std::optional(", cpp_args_f_11497, ")")); }));
    });
    })
        : ({
        auto&& m11460_1 = p_p1;
        (m11460_1 == Text::lit("Ok"));
    }) ? ({
        auto&& m11460_1 = p_p1;
        args_p2 == Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})})
        ? prism_rtl::finished(Text::lit("prism_rtl::ok()"))
        : prism_rtl::more(prism_rtl::rc(CppArgs(cp_p0, args_p2)));
    })
        : ({
        auto&& m11460_2 = p_p1;
        (m11460_2 == Text::lit("Err"));
    }) ? ({
        auto&& m11460_2 = p_p1;
        ({
        auto args_p2x = args_p2;
        auto cp_p0x = cp_p0;
        (crate::prelude::call_then(start_cpp_args_f(cp_p0x, args_p2x), [=](Text cpp_args_f_11614) { return prism_rtl::finished(prism_rtl::cat("unexpected(", cpp_args_f_11614, ")")); }));
    });
    })
        : ({
        auto&& m11460_3 = p_p1;
        (m11460_3 == Text::lit("prism_rtl::Turn::More"));
    }) ? ({
        auto&& m11460_3 = p_p1;
        ({
        auto args_p2x = args_p2;
        auto cp_p0x = cp_p0;
        (crate::prelude::call_then(start_cpp_args_f(cp_p0x, args_p2x), [=](Text cpp_args_f_11681) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::more(", cpp_args_f_11681, ")")); }));
    });
    })
        : ({
        auto&& m11460_4 = p_p1;
        (m11460_4 == Text::lit("prism_rtl::Turn::Finished"));
    }) ? ({
        auto&& m11460_4 = p_p1;
        ({
        auto args_p2x = args_p2;
        auto cp_p0x = cp_p0;
        (crate::prelude::call_then(start_cpp_args_f(cp_p0x, args_p2x), [=](Text cpp_args_f_11756) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::finished(", cpp_args_f_11756, ")")); }));
    });
    })
        : ({
        auto&& m11460_5 = p_p1;
        (m11460_5 == Text::lit("Outcome::Fired"));
    }) ? ({
        auto&& m11460_5 = p_p1;
        ({
        auto args_p2x = args_p2;
        auto cp_p0x = cp_p0;
        (crate::prelude::call_then(start_cpp_args_f(cp_p0x, args_p2x), [=](Text cpp_args_f_11815) { return prism_rtl::finished(prism_rtl::cat("Outcome::fired(", cpp_args_f_11815, ")")); }));
    });
    })
        : ({
        auto&& m11460_6 = p_p1;
        (m11460_6 == Text::lit("Outcome::Value"));
    }) ? ({
        auto&& m11460_6 = p_p1;
        ({
        auto args_p2x = args_p2;
        auto cp_p0x = cp_p0;
        (crate::prelude::call_then(start_cpp_args_f(cp_p0x, args_p2x), [=](Text cpp_args_f_11874) { return prism_rtl::finished(prism_rtl::cat("Outcome::value(", cpp_args_f_11874, ")")); }));
    });
    })
        : ({
        auto&& m11460_7 = p_p1;
        (m11460_7 == Text::lit("Segment::Pos"));
    }) ? ({
        auto&& m11460_7 = p_p1;
        ({
        auto args_p2x = args_p2;
        auto cp_p0x = cp_p0;
        (crate::prelude::call_then(start_cpp_args_f(cp_p0x, args_p2x), [=](Text cpp_args_f_11929) { return prism_rtl::finished(prism_rtl::cat("Segment::pos(", cpp_args_f_11929, ")")); }));
    });
    })
        : ({
        auto&& m11460_8 = p_p1;
        (m11460_8 == Text::lit("Segment::Gen"));
    }) ? ({
        auto&& m11460_8 = p_p1;
        ({
        auto args_p2x = args_p2;
        auto cp_p0x = cp_p0;
        (crate::prelude::call_then(start_cpp_args_f(cp_p0x, args_p2x), [=](Text cpp_args_f_11984) { return prism_rtl::finished(prism_rtl::cat("Segment::gen(", cpp_args_f_11984, ")")); }));
    });
    })
        : ({
        auto&& m11460_9 = p_p1;
        (m11460_9 == Text::lit("Segment::Key"));
    }) ? ({
        auto&& m11460_9 = p_p1;
        ({
        auto args_p2x = args_p2;
        auto cp_p0x = cp_p0;
        (crate::prelude::call_then(start_cpp_args_f(cp_p0x, args_p2x), [=](Text cpp_args_f_12039) { return prism_rtl::finished(prism_rtl::cat("Segment::key(", cpp_args_f_12039, ")")); }));
    });
    })
        : ({
        auto&& _m = crate::emit::cpp::case_of_o(cp_p0, p_p1);
        prism_rtl::is_some(_m) ? ({
        auto&& ty_p3 = prism_rtl::some_of(_m);
        ({
        auto args_p2x = args_p2;
        auto cp_p0x = cp_p0;
        auto p_p1x = p_p1;
        (crate::prelude::call_then(start_cpp_args_f(cp_p0x, args_p2x), [=, p_p1x = std::move(p_p1x)](Text cpp_args_f_12139) { return prism_rtl::finished(prism_rtl::cat(crate::emit::cpp::type_path_f(ty_p3), "(", crate::emit::cpp::type_path_f(p_p1x), "{", cpp_args_f_12139, "})")); }));
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto args_p2x = args_p2;
        auto cp_p0x = cp_p0;
        auto p_p1x = p_p1;
        (crate::prelude::call_then(start_cpp_args_f(cp_p0x, args_p2x), [=, p_p1x = std::move(p_p1x)](Text cpp_args_f_12190) { return prism_rtl::finished(prism_rtl::cat(crate::emit::cpp::type_path_f(p_p1x), "{", cpp_args_f_12190, "}")); }));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    });
}


/// `Start CppCtor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_ctor_f(crate::emit::cpp::Cp cp_p0, Text p_p1, Array<crate::lower::model::Ex> args_p2) {
    return prism_rtl::make_rc<CppCtor>(cp_p0, p_p1, args_p2);
}


/// CppRecord: unbounded fn Cp, Text, [((Text, Ex))] -> Text
Text cpp_record_f(const crate::emit::cpp::Cp& cp_p0, const Text& p_p1, const Array<std::tuple<Text, crate::lower::model::Ex>>& fs_p2) {
    auto ordered_p3 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
        auto&& _m = crate::emit::cpp::type_of_o(cp_p0, p_p1);
        if (prism_rtl::is_some(_m)) {
            auto&& info_p7 = prism_rtl::some_of(_m);
            _v.set(crate::prelude::each(prism_rtl::deref(info_p7).fields_p, [&](const Text& f_p8) {
                return crate::prelude::or_(crate::prelude::fold(fs_p2, std::optional<crate::lower::model::Ex>{}, [&](const std::optional<crate::lower::model::Ex>& found_o9, const std::tuple<Text, crate::lower::model::Ex>& _p1) {
                    auto&& g_pa = std::get<0>(_p1);
                    auto&& v_pb = std::get<1>(_p1);
                    return g_pa == f_p8 ? std::optional(v_pb) : found_o9;
                }), crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}));
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::prelude::each(fs_p2, [&](const std::tuple<Text, crate::lower::model::Ex>& _p0) {
                auto&& v_pc = std::get<1>(_p0);
                return v_pc;
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto names_p4 = ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = crate::emit::cpp::type_of_o(cp_p0, p_p1);
        if (prism_rtl::is_some(_m)) {
            auto&& info_pd = prism_rtl::some_of(_m);
            _v.set(prism_rtl::deref(info_pd).fields_p);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::prelude::each(fs_p2, [&](const std::tuple<Text, crate::lower::model::Ex>& _p0) {
                auto&& g_pe = std::get<0>(_p0);
                return g_pe;
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto kind_p5 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = crate::emit::cpp::type_of_o(cp_p0, p_p1);
        if (prism_rtl::is_some(_m)) {
            auto&& info_pf = prism_rtl::some_of(_m);
            _v.set(prism_rtl::deref(info_pf).kind_p);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto values_p6 = cpp_arg_list_f(cp_p0, ordered_p3);
    return kind_p5 == Text::lit("job")
        ? prism_rtl::cat(crate::emit::cpp::type_path_f(p_p1), "(", crate::syntax::lexer::chars::join_f(values_p6, Text::lit(", ")), ")")
        : prism_rtl::cat(crate::emit::cpp::type_path_f(p_p1), "{", crate::syntax::lexer::chars::join_f(crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(names_p4)), [&](const Nat& i_pg) { return prism_rtl::cat(".", crate::emit::cpp::field_id_f(crate::prelude::or_(crate::prelude::index(names_p4, i_pg), Text::lit(""))), " = ", crate::prelude::or_(crate::prelude::index(values_p6, i_pg), Text::lit(""))); }), Text::lit(", ")), "}");
}


prism_rtl::Turn<Text> CppRecord::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& p_p1 = this->p_p1;
    const auto& fs_p2 = this->fs_p2;
    auto ordered_p3 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
        auto&& _m = crate::emit::cpp::type_of_o(cp_p0, p_p1);
        if (prism_rtl::is_some(_m)) {
            auto&& info_p7 = prism_rtl::some_of(_m);
            _v.set(crate::prelude::each(prism_rtl::deref(info_p7).fields_p, [&](const Text& f_p8) {
                return crate::prelude::or_(crate::prelude::fold(fs_p2, std::optional<crate::lower::model::Ex>{}, [&](const std::optional<crate::lower::model::Ex>& found_o9, const std::tuple<Text, crate::lower::model::Ex>& _p1) {
                    auto&& g_pa = std::get<0>(_p1);
                    auto&& v_pb = std::get<1>(_p1);
                    return g_pa == f_p8 ? std::optional(v_pb) : found_o9;
                }), crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}));
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::prelude::each(fs_p2, [&](const std::tuple<Text, crate::lower::model::Ex>& _p0) {
                auto&& v_pc = std::get<1>(_p0);
                return v_pc;
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto names_p4 = ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = crate::emit::cpp::type_of_o(cp_p0, p_p1);
        if (prism_rtl::is_some(_m)) {
            auto&& info_pd = prism_rtl::some_of(_m);
            _v.set(prism_rtl::deref(info_pd).fields_p);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::prelude::each(fs_p2, [&](const std::tuple<Text, crate::lower::model::Ex>& _p0) {
                auto&& g_pe = std::get<0>(_p0);
                return g_pe;
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto kind_p5 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = crate::emit::cpp::type_of_o(cp_p0, p_p1);
        if (prism_rtl::is_some(_m)) {
            auto&& info_pf = prism_rtl::some_of(_m);
            _v.set(prism_rtl::deref(info_pf).kind_p);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto cp_p0x = cp_p0;
    auto p_p1x = p_p1;
    return crate::prelude::call_then(start_cpp_arg_list_f(cp_p0x, ordered_p3), [=](Array<Text> cpp_arg_list_f_12789) {
        return ({
            auto values_p6 = cpp_arg_list_f_12789;
            kind_p5 == Text::lit("job")
            ? prism_rtl::finished(prism_rtl::cat(crate::emit::cpp::type_path_f(p_p1x), "(", crate::syntax::lexer::chars::join_f(values_p6, Text::lit(", ")), ")"))
            : prism_rtl::finished(prism_rtl::cat(crate::emit::cpp::type_path_f(p_p1x), "{", crate::syntax::lexer::chars::join_f(crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(names_p4)), [&](const Nat& i_pg) { return prism_rtl::cat(".", crate::emit::cpp::field_id_f(crate::prelude::or_(crate::prelude::index(names_p4, i_pg), Text::lit(""))), " = ", crate::prelude::or_(crate::prelude::index(values_p6, i_pg), Text::lit(""))); }), Text::lit(", ")), "}"));
        });
    });
}


/// `Start CppRecord, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_record_f(crate::emit::cpp::Cp cp_p0, Text p_p1, Array<std::tuple<Text, crate::lower::model::Ex>> fs_p2) {
    return prism_rtl::make_rc<CppRecord>(cp_p0, p_p1, fs_p2);
}


/// CppCall: unbounded fn Cp, Text, [Ex] -> Text
Text cpp_call_f(const crate::emit::cpp::Cp& cp_p0, const Text& f_p1, const Array<crate::lower::model::Ex>& args_p2) {
    auto a_p3 = cpp_args_f(cp_p0, args_p2);
    auto&& _m = crate::syntax::lexer::chars::drop_prefix_f(f_p1, Text::lit("crate::prelude::"));
    {
        auto&& m13234_0 = _m;
        if (m13234_0 == Text::lit("Rc::new")) {
            return a_p3 == Text::lit("{}")
                ? Text::lit("prism_rtl::make_new()")
                : prism_rtl::cat("prism_rtl::rc(", a_p3, ")");
        }
    }
    {
        auto&& m13234_1 = _m;
        if (m13234_1 == Text::lit("is_some")) {
            return prism_rtl::cat("prism_rtl::is_some(", a_p3, ")");
        }
    }
    {
        auto&& m13234_2 = _m;
        if (m13234_2 == Text::lit("is_none")) {
            return prism_rtl::cat("prism_rtl::is_none(", a_p3, ")");
        }
    }
    {
        auto&& m13234_3 = _m;
        if (m13234_3 == Text::lit("RefCell::new")) {
            return a_p3;
        }
    }
    {
        auto&& m13234_4 = _m;
        if (m13234_4 == Text::lit("Cell::new")) {
            return a_p3;
        }
    }
    {
        auto&& m13234_5 = _m;
        if (m13234_5 == Text::lit("Hold::new")) {
            return prism_rtl::cat("{", a_p3, "}");
        }
    }
    {
        auto&& m13234_6 = _m;
        if (m13234_6 == Text::lit("Snapshot::new")) {
            return prism_rtl::cat("snapshot(", a_p3, ")");
        }
    }
    {
        auto&& m13234_7 = _m;
        if (m13234_7 == Text::lit("Path::root")) {
            return Text::lit("Path::root()");
        }
    }
    {
        auto&& m13234_8 = _m;
        if (m13234_8 == Text::lit("Fault::answer")) {
            return prism_rtl::cat("Fault::answer(", a_p3, ")");
        }
    }
    {
        auto&& m13234_9 = _m;
        if (m13234_9 == Text::lit("Fault::too_deep")) {
            return prism_rtl::cat("Fault::too_deep(", a_p3, ")");
        }
    }
    {
        auto&& m13234_10 = _m;
        if (m13234_10 == Text::lit("Error::new")) {
            return prism_rtl::cat("Error(", a_p3, ")");
        }
    }
    {
        auto&& m13234_11 = _m;
        if (m13234_11 == Text::lit("Text::from")) {
            return prism_rtl::cat("Text(", a_p3, ")");
        }
    }
    {
        auto&& m13234_12 = _m;
        if (m13234_12 == Text::lit("String::new")) {
            return Text::lit("std::string()");
        }
    }
    {
        auto&& m13234_13 = _m;
        if (m13234_13 == Text::lit("Array::from")) {
            return prism_rtl::cat("Array(", a_p3, ")");
        }
    }
    {
        auto&& m13234_14 = _m;
        if (m13234_14 == Text::lit("prism_rtl::Dynamic::of")) {
            return prism_rtl::cat("prism_rtl::dynamic_of(", a_p3, ")");
        }
    }
    {
        auto&& m13234_15 = _m;
        if (m13234_15 == Text::lit("Dynamic::of")) {
            return prism_rtl::cat("prism_rtl::dynamic_of(", a_p3, ")");
        }
    }
    {
        auto&& m13234_16 = _m;
        if (m13234_16 == Text::lit("prism_rtl::Event::of")) {
            return prism_rtl::cat("prism_rtl::event_of(", a_p3, ")");
        }
    }
    {
        auto&& m13234_17 = _m;
        if (m13234_17 == Text::lit("prism_rtl::Host::new")) {
            return prism_rtl::cat("host_new(", a_p3, ")");
        }
    }
    {
        auto&& m13234_18 = _m;
        if (m13234_18 == Text::lit("prism_rtl::Entry::new")) {
            return prism_rtl::cat("entry_new(", a_p3, ")");
        }
    }
    {
        auto&& m13234_19 = _m;
        if (m13234_19 == Text::lit("prism_rtl::forward_on_none")) {
            return prism_rtl::cat("prism_rtl::forward_on_none<crate::Elem, crate::Answer>(", a_p3, ")");
        }
    }
    {
        auto&& m13234_20 = _m;
        if (m13234_20 == Text::lit("Event::never")) {
            return Text::lit("prism_rtl::never_event()");
        }
    }
    {
        return is_fresh_f(f_p1)
            ? Text::lit("{}")
            : prism_rtl::cat(free_call_path_f(cp_p0, f_p1), "(", a_p3, ")");
    }
}


prism_rtl::Turn<Text> CppCall::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& f_p1 = this->f_p1;
    const auto& args_p2 = this->args_p2;
    auto args_p2x = args_p2;
    auto cp_p0x = cp_p0;
    auto f_p1x = f_p1;
    return crate::prelude::call_then(start_cpp_args_f(cp_p0x, args_p2x), [=](Text cpp_args_f_13213) {
        return ({
            auto a_p3 = cpp_args_f_13213;
            ({
            auto&& _m = crate::syntax::lexer::chars::drop_prefix_f(f_p1x, Text::lit("crate::prelude::"));
            ({
            auto&& m13234_0 = _m;
            (m13234_0 == Text::lit("Rc::new"));
        }) ? ({
            auto&& m13234_0 = _m;
            a_p3 == Text::lit("{}")
            ? prism_rtl::finished(Text::lit("prism_rtl::make_new()"))
            : prism_rtl::finished(prism_rtl::cat("prism_rtl::rc(", a_p3, ")"));
        })
            : ({
            auto&& m13234_1 = _m;
            (m13234_1 == Text::lit("is_some"));
        }) ? ({
            auto&& m13234_1 = _m;
            prism_rtl::finished(prism_rtl::cat("prism_rtl::is_some(", a_p3, ")"));
        })
            : ({
            auto&& m13234_2 = _m;
            (m13234_2 == Text::lit("is_none"));
        }) ? ({
            auto&& m13234_2 = _m;
            prism_rtl::finished(prism_rtl::cat("prism_rtl::is_none(", a_p3, ")"));
        })
            : ({
            auto&& m13234_3 = _m;
            (m13234_3 == Text::lit("RefCell::new"));
        }) ? ({
            auto&& m13234_3 = _m;
            prism_rtl::finished(a_p3);
        })
            : ({
            auto&& m13234_4 = _m;
            (m13234_4 == Text::lit("Cell::new"));
        }) ? ({
            auto&& m13234_4 = _m;
            prism_rtl::finished(a_p3);
        })
            : ({
            auto&& m13234_5 = _m;
            (m13234_5 == Text::lit("Hold::new"));
        }) ? ({
            auto&& m13234_5 = _m;
            prism_rtl::finished(prism_rtl::cat("{", a_p3, "}"));
        })
            : ({
            auto&& m13234_6 = _m;
            (m13234_6 == Text::lit("Snapshot::new"));
        }) ? ({
            auto&& m13234_6 = _m;
            prism_rtl::finished(prism_rtl::cat("snapshot(", a_p3, ")"));
        })
            : ({
            auto&& m13234_7 = _m;
            (m13234_7 == Text::lit("Path::root"));
        }) ? ({
            auto&& m13234_7 = _m;
            prism_rtl::finished(Text::lit("Path::root()"));
        })
            : ({
            auto&& m13234_8 = _m;
            (m13234_8 == Text::lit("Fault::answer"));
        }) ? ({
            auto&& m13234_8 = _m;
            prism_rtl::finished(prism_rtl::cat("Fault::answer(", a_p3, ")"));
        })
            : ({
            auto&& m13234_9 = _m;
            (m13234_9 == Text::lit("Fault::too_deep"));
        }) ? ({
            auto&& m13234_9 = _m;
            prism_rtl::finished(prism_rtl::cat("Fault::too_deep(", a_p3, ")"));
        })
            : ({
            auto&& m13234_10 = _m;
            (m13234_10 == Text::lit("Error::new"));
        }) ? ({
            auto&& m13234_10 = _m;
            prism_rtl::finished(prism_rtl::cat("Error(", a_p3, ")"));
        })
            : ({
            auto&& m13234_11 = _m;
            (m13234_11 == Text::lit("Text::from"));
        }) ? ({
            auto&& m13234_11 = _m;
            prism_rtl::finished(prism_rtl::cat("Text(", a_p3, ")"));
        })
            : ({
            auto&& m13234_12 = _m;
            (m13234_12 == Text::lit("String::new"));
        }) ? ({
            auto&& m13234_12 = _m;
            prism_rtl::finished(Text::lit("std::string()"));
        })
            : ({
            auto&& m13234_13 = _m;
            (m13234_13 == Text::lit("Array::from"));
        }) ? ({
            auto&& m13234_13 = _m;
            prism_rtl::finished(prism_rtl::cat("Array(", a_p3, ")"));
        })
            : ({
            auto&& m13234_14 = _m;
            (m13234_14 == Text::lit("prism_rtl::Dynamic::of"));
        }) ? ({
            auto&& m13234_14 = _m;
            prism_rtl::finished(prism_rtl::cat("prism_rtl::dynamic_of(", a_p3, ")"));
        })
            : ({
            auto&& m13234_15 = _m;
            (m13234_15 == Text::lit("Dynamic::of"));
        }) ? ({
            auto&& m13234_15 = _m;
            prism_rtl::finished(prism_rtl::cat("prism_rtl::dynamic_of(", a_p3, ")"));
        })
            : ({
            auto&& m13234_16 = _m;
            (m13234_16 == Text::lit("prism_rtl::Event::of"));
        }) ? ({
            auto&& m13234_16 = _m;
            prism_rtl::finished(prism_rtl::cat("prism_rtl::event_of(", a_p3, ")"));
        })
            : ({
            auto&& m13234_17 = _m;
            (m13234_17 == Text::lit("prism_rtl::Host::new"));
        }) ? ({
            auto&& m13234_17 = _m;
            prism_rtl::finished(prism_rtl::cat("host_new(", a_p3, ")"));
        })
            : ({
            auto&& m13234_18 = _m;
            (m13234_18 == Text::lit("prism_rtl::Entry::new"));
        }) ? ({
            auto&& m13234_18 = _m;
            prism_rtl::finished(prism_rtl::cat("entry_new(", a_p3, ")"));
        })
            : ({
            auto&& m13234_19 = _m;
            (m13234_19 == Text::lit("prism_rtl::forward_on_none"));
        }) ? ({
            auto&& m13234_19 = _m;
            prism_rtl::finished(prism_rtl::cat("prism_rtl::forward_on_none<crate::Elem, crate::Answer>(", a_p3, ")"));
        })
            : ({
            auto&& m13234_20 = _m;
            (m13234_20 == Text::lit("Event::never"));
        }) ? ({
            auto&& m13234_20 = _m;
            prism_rtl::finished(Text::lit("prism_rtl::never_event()"));
        })
            : is_fresh_f(f_p1x)
            ? prism_rtl::finished(Text::lit("{}"))
            : prism_rtl::finished(prism_rtl::cat(free_call_path_f(cp_p0x, f_p1x), "(", a_p3, ")"));
        });
        });
    });
}


/// `Start CppCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_call_f(crate::emit::cpp::Cp cp_p0, Text f_p1, Array<crate::lower::model::Ex> args_p2) {
    return prism_rtl::make_rc<CppCall>(cp_p0, f_p1, args_p2);
}


/// FreeCallPath: fn Cp, Text -> Text
Text free_call_path_f(const crate::emit::cpp::Cp& cp_p0, const Text& f_p1) {
    auto p_p2 = call_path_f(f_p1);
    auto hidden_p3 = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = crate::prelude::get(cp_p0.members_p, f_p1);
        if (prism_rtl::is_some(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::emit::cpp::in_list_f(std_names_p(), p_p2) || crate::emit::cpp::in_list_f(cp_p0.mods_p, p_p2));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return crate::syntax::lexer::chars::contains_f(p_p2, Text::lit(":"))
        ? p_p2
        : std::move(hidden_p3) ? qualified_call_f(cp_p0, f_p1, p_p2) : p_p2;
}


/// QualifiedCall: fn Cp, Text, Text -> Text
Text qualified_call_f(const crate::emit::cpp::Cp& cp_p0, const Text& f_p1, const Text& p_p2) {
    auto&& _m = crate::prelude::get(cp_p0.fns_p, prism_rtl::cat(cp_p0.home_p, "::", f_p1));
    if (prism_rtl::is_some(_m)) {
        return prism_rtl::cat("crate::", cp_p0.home_p, "::", p_p2);
    }
    if (prism_rtl::is_none(_m)) {
        return prism_rtl::cat("crate::prelude::", p_p2);
    }
    prism_rtl::unreachable("no arm matched");
}


/// let stdNames
Array<Text> std_names_p() {
    return Array(std::vector{Text::lit("apply"), Text::lit("begin"), Text::lit("end"), Text::lit("size"), Text::lit("empty"), Text::lit("data"), Text::lit("get"), Text::lit("swap"), Text::lit("move"), Text::lit("forward"), Text::lit("find"), Text::lit("count"), Text::lit("copy"), Text::lit("fill"), Text::lit("sort"), Text::lit("min"), Text::lit("max"), Text::lit("visit"), Text::lit("invoke"), Text::lit("merge"), Text::lit("remove"), Text::lit("replace"), Text::lit("reverse"), Text::lit("unique"), Text::lit("transform"), Text::lit("accumulate"), Text::lit("distance"), Text::lit("next"), Text::lit("prev"), Text::lit("exchange"), Text::lit("tie"), Text::lit("to_string"), Text::lit("clamp"), Text::lit("partition"), Text::lit("equal"), Text::lit("mismatch"), Text::lit("erase"), Text::lit("search"), Text::lit("rotate")});
}


/// IsFresh: fn Text -> Bool
bool is_fresh_f(const Text& f_p0) {
    return crate::emit::cpp::in_list_f(Array(std::vector{Text::lit("Stamped::new"), Text::lit("Cache::new"), Text::lit("Port::new"), Text::lit("Map::new"), Text::lit("Array::new"), Text::lit("Vec::new"), Text::lit("Default::default"), Text::lit("Wakes::default"), Text::lit("Defer::new"), Text::lit("prism_rtl::HostDoc::new"), Text::lit("prism_rtl::Watch::new"), Text::lit("prism_rtl::PerKey::new")}), f_p0);
}


/// CallPath: fn Text -> Text
Text call_path_f(const Text& f_p0) {
    auto last_p1 = crate::emit::cpp::last_segment_f(f_p0);
    auto owner_p2 = crate::emit::cpp::last_segment_f(crate::emit::cpp::parent_path_f(f_p0));
    auto is_type_p3 = (crate::emit::cpp::parent_path_f(f_p0) != Text::lit("")) && crate::syntax::lexer::chars::contains_f(Text::lit("ABCDEFGHIJKLMNOPQRSTUVWXYZ"), crate::syntax::lexer::chars::head_f(owner_p2));
    return (last_p1 == Text::lit("build")) && std::move(is_type_p3)
        ? prism_rtl::cat(crate::emit::cpp::type_path_f(crate::emit::cpp::parent_path_f(f_p0)), "::make")
        : last_p1 == Text::lit("new")
        ? crate::emit::cpp::type_path_f(crate::emit::cpp::parent_path_f(f_p0))
        : crate::emit::cpp::cpp_path_id_f(crate::emit::cpp::type_path_f(f_p0));
}


/// CppMethod: unbounded fn Cp, Ex, Text, [Ex] -> Text
Text cpp_method_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Ex& r_p1, const Text& m_p2, const Array<crate::lower::model::Ex>& args_p3) {
    auto recv_p4 = r_p1 == crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})
        ? Text::lit("this")
        : cpp_tight_place_f(cp_p0, r_p1);
    auto a_p5 = cpp_args_f(cp_p0, args_p3);
    auto n_p6 = crate::prelude::len(args_p3);
    auto sep_p7 = n_p6 == Nat(0u) ? Text::lit("") : Text::lit(", ");
    auto&& _m = method_form_f(m_p2, n_p6);
    {
        auto&& m16645_0 = _m;
        if (m16645_0 == Text::lit("id")) {
            return recv_p4;
        }
    }
    {
        auto&& m16645_1 = _m;
        if (m16645_1 == Text::lit("deref")) {
            auto&& _m = pointer_o(cp_p0, r_p1);
            if (prism_rtl::is_some(_m)) {
                auto&& b_p8 = prism_rtl::some_of(_m);
                return b_p8 ? prism_rtl::cat("(*", recv_p4, ")") : recv_p4;
            }
            if (prism_rtl::is_none(_m)) {
                return recv_p4;
            }
            prism_rtl::unreachable("no arm matched");
        }
    }
    {
        auto&& m16645_2 = _m;
        if (m16645_2 == Text::lit("assign")) {
            return prism_rtl::cat(recv_p4, " = ", a_p5);
        }
    }
    {
        auto&& m16645_3 = _m;
        if (m16645_3 == Text::lit("take")) {
            return prism_rtl::cat("std::exchange(", recv_p4, ", {})");
        }
    }
    {
        auto&& m16645_4 = _m;
        if (m16645_4 == Text::lit("free")) {
            return prism_rtl::cat(free_name_f(m_p2), "(", recv_p4, sep_p7, a_p5, ")");
        }
    }
    {
        auto&& m16645_5 = _m;
        if (m16645_5 == Text::lit("arrow")) {
            auto through_p9 = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = pointer_o(cp_p0, r_p1);
                if (prism_rtl::is_some(_m)) {
                    auto&& b_pa = prism_rtl::some_of(_m);
                    _v.set(b_pa ? Text::lit("->") : Text::lit("."));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Text::lit("->"));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            return prism_rtl::cat(recv_p4, through_p9, member_name_f(m_p2), "(", a_p5, ")");
        }
    }
    {
        auto&& m16645_6 = _m;
        if (m16645_6 == Text::lit("exchange")) {
            return prism_rtl::cat("std::exchange(", recv_p4, ", ", a_p5, ")");
        }
    }
    {
        auto through_pb = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            auto&& _m = pointer_o(cp_p0, r_p1);
            if (prism_rtl::is_some(_m)) {
                auto&& b_pc = prism_rtl::some_of(_m);
                _v.set(b_pc ? Text::lit("->") : Text::lit("."));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = crate::prelude::get(cp_p0.members_p, m_p2);
                    if (prism_rtl::is_some(_m)) {
                        _v.set(Text::lit("->"));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Text::lit("."));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return prism_rtl::cat(recv_p4, through_pb, node_method_name_f(cp_p0, m_p2), "(", a_p5, ")");
    }
}


prism_rtl::Turn<Text> CppMethod::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& r_p1 = this->r_p1;
    const auto& m_p2 = this->m_p2;
    const auto& args_p3 = this->args_p3;
    auto recv_p4 = r_p1 == crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})
        ? Text::lit("this")
        : cpp_tight_place_f(cp_p0, r_p1);
    auto args_p3x = args_p3;
    auto cp_p0x = cp_p0;
    auto m_p2x = m_p2;
    auto r_p1x = r_p1;
    return crate::prelude::call_then(start_cpp_args_f(cp_p0x, args_p3x), [=](Text cpp_args_f_16564) {
        return ({
            auto a_p5 = cpp_args_f_16564;
            auto n_p6 = crate::prelude::len(args_p3x);
            auto sep_p7 = n_p6 == Nat(0u) ? Text::lit("") : Text::lit(", ");
            ({
            auto&& _m = method_form_f(m_p2x, n_p6);
            ({
            auto&& m16645_0 = _m;
            (m16645_0 == Text::lit("id"));
        }) ? ({
            auto&& m16645_0 = _m;
            prism_rtl::finished(recv_p4);
        })
            : ({
            auto&& m16645_1 = _m;
            (m16645_1 == Text::lit("deref"));
        }) ? ({
            auto&& m16645_1 = _m;
            ({
            auto&& _m = pointer_o(cp_p0x, r_p1x);
            prism_rtl::is_some(_m) ? ({
            auto&& b_p8 = prism_rtl::some_of(_m);
            b_p8
            ? prism_rtl::finished(prism_rtl::cat("(*", recv_p4, ")"))
            : prism_rtl::finished(recv_p4);
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(recv_p4)
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : ({
            auto&& m16645_2 = _m;
            (m16645_2 == Text::lit("assign"));
        }) ? ({
            auto&& m16645_2 = _m;
            prism_rtl::finished(prism_rtl::cat(recv_p4, " = ", a_p5));
        })
            : ({
            auto&& m16645_3 = _m;
            (m16645_3 == Text::lit("take"));
        }) ? ({
            auto&& m16645_3 = _m;
            prism_rtl::finished(prism_rtl::cat("std::exchange(", recv_p4, ", {})"));
        })
            : ({
            auto&& m16645_4 = _m;
            (m16645_4 == Text::lit("free"));
        }) ? ({
            auto&& m16645_4 = _m;
            prism_rtl::finished(prism_rtl::cat(free_name_f(m_p2x), "(", recv_p4, sep_p7, a_p5, ")"));
        })
            : ({
            auto&& m16645_5 = _m;
            (m16645_5 == Text::lit("arrow"));
        }) ? ({
            auto&& m16645_5 = _m;
            ({
            auto through_p9 = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = pointer_o(cp_p0x, r_p1x);
                if (prism_rtl::is_some(_m)) {
                    auto&& b_pa = prism_rtl::some_of(_m);
                    _v.set(b_pa ? Text::lit("->") : Text::lit("."));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Text::lit("->"));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (prism_rtl::finished(prism_rtl::cat(recv_p4, through_p9, member_name_f(m_p2x), "(", a_p5, ")")));
        });
        })
            : ({
            auto&& m16645_6 = _m;
            (m16645_6 == Text::lit("exchange"));
        }) ? ({
            auto&& m16645_6 = _m;
            prism_rtl::finished(prism_rtl::cat("std::exchange(", recv_p4, ", ", a_p5, ")"));
        })
            : ({
            auto through_pb = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = pointer_o(cp_p0x, r_p1x);
                if (prism_rtl::is_some(_m)) {
                    auto&& b_pc = prism_rtl::some_of(_m);
                    _v.set(b_pc ? Text::lit("->") : Text::lit("."));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Text> _v;
                        auto&& _m = crate::prelude::get(prism_rtl::deref(cp_p0x).members_p, m_p2x);
                        if (prism_rtl::is_some(_m)) {
                            _v.set(Text::lit("->"));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(Text::lit("."));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (prism_rtl::finished(prism_rtl::cat(recv_p4, through_pb, node_method_name_f(cp_p0x, m_p2x), "(", a_p5, ")")));
        });
        });
        });
    });
}


/// `Start CppMethod, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_method_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex r_p1, Text m_p2, Array<crate::lower::model::Ex> args_p3) {
    return prism_rtl::make_rc<CppMethod>(cp_p0, r_p1, m_p2, args_p3);
}


/// NodeMethodName: fn Cp, Text -> Text
Text node_method_name_f(const crate::emit::cpp::Cp& cp_p0, const Text& m_p1) {
    auto&& _m = std::tuple{crate::prelude::get(cp_p0.methods_p, m_p1), crate::prelude::get(cp_p0.field_names_p, m_p1)};
    if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
        return prism_rtl::cat(crate::emit::cpp::cpp_id_f(m_p1), "_");
    }
    {
        return member_name_f(m_p1);
    }
}


/// ?Pointer: fn Cp, Ex -> ?Bool
std::optional<bool> pointer_o(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Ex& r_p1) {
    if (prism_rtl::is<crate::lower::model::Ex::XSelf>(r_p1)) {
        return std::optional(true);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XCx>(r_p1)) {
        return std::optional(false);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(r_p1)) {
        auto&& m18161_2_0 = prism_rtl::as<crate::lower::model::Ex::XVar>(r_p1).a0;
        if (m18161_2_0 == Text::lit("path")) {
            return std::optional(false);
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(r_p1)) {
        auto&& m18161_3_1 = prism_rtl::as<crate::lower::model::Ex::XField>(r_p1).a1;
        if (m18161_3_1 == Text::lit("path")) {
            return std::optional(false);
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XCall>(r_p1)) {
        auto&& m18161_4_0 = prism_rtl::as<crate::lower::model::Ex::XCall>(r_p1).a0;
        if (m18161_4_0 == Text::lit("Path::root")) {
            return std::optional(false);
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XMethod>(r_p1)) {
        auto&& y_p2 = prism_rtl::as<crate::lower::model::Ex::XMethod>(r_p1).a0;
        auto&& m_p3 = prism_rtl::as<crate::lower::model::Ex::XMethod>(r_p1).a1;
        if (((m_p3 == Text::lit("at")) || (m_p3 == Text::lit("child"))) || (m_p3 == Text::lit("join"))) {
            auto&& _m = pointer_o(cp_p0, prism_rtl::deref(prism_rtl::deref(y_p2)));
            if (prism_rtl::is_some(_m) && !prism_rtl::some_of(_m)) {
                return std::optional(false);
            }
            {
                return std::optional<bool>{};
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(r_p1)) {
        auto&& n_p4 = prism_rtl::as<crate::lower::model::Ex::XVar>(r_p1).a0;
        return crate::prelude::get(cp_p0.pointers_p, n_p4);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XClone>(r_p1)) {
        auto&& y_p5 = prism_rtl::as<crate::lower::model::Ex::XClone>(r_p1).a0;
        return pointer_o(cp_p0, prism_rtl::deref(prism_rtl::deref(y_p5)));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRef>(r_p1)) {
        auto&& y_p6 = prism_rtl::as<crate::lower::model::Ex::XRef>(r_p1).a0;
        return pointer_o(cp_p0, prism_rtl::deref(prism_rtl::deref(y_p6)));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XDeref>(r_p1)) {
        auto&& y_p7 = prism_rtl::as<crate::lower::model::Ex::XDeref>(r_p1).a0;
        auto&& _m = ex_ty_o(cp_p0, r_p1);
        if (prism_rtl::is_some(_m)) {
            auto&& t_p8 = prism_rtl::some_of(_m);
            return std::optional(is_pointer_ty_f(cp_p0, unref_f(t_p8)));
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional<bool>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(r_p1)) {
        auto&& m18161_10_0 = prism_rtl::as<crate::lower::model::Ex::XField>(r_p1).a0;
        auto&& f_p9 = prism_rtl::as<crate::lower::model::Ex::XField>(r_p1).a1;
        if (prism_rtl::is<crate::lower::model::Ex::XSelf>(prism_rtl::deref(prism_rtl::deref(m18161_10_0)))) {
            auto&& _m = crate::prelude::get(cp_p0.fields_p, f_p9);
            if (prism_rtl::is_some(_m)) {
                auto&& t_pa = prism_rtl::some_of(_m);
                return std::optional(is_pointer_ty_f(cp_p0, t_pa));
            }
            if (prism_rtl::is_none(_m)) {
                return std::optional<bool>{};
            }
            prism_rtl::unreachable("no arm matched");
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(r_p1)) {
        auto&& m18161_11_0 = prism_rtl::as<crate::lower::model::Ex::XField>(r_p1).a0;
        auto&& f_pb = prism_rtl::as<crate::lower::model::Ex::XField>(r_p1).a1;
        if (prism_rtl::is<crate::lower::model::Ex::XVar>(prism_rtl::deref(prism_rtl::deref(m18161_11_0)))) {
            auto&& m18161_11_0_r_0 = prism_rtl::as<crate::lower::model::Ex::XVar>(prism_rtl::deref(prism_rtl::deref(m18161_11_0))).a0;
            if (m18161_11_0_r_0 == Text::lit("node")) {
                auto&& _m = crate::prelude::get(cp_p0.fields_p, f_pb);
                if (prism_rtl::is_some(_m)) {
                    auto&& t_pc = prism_rtl::some_of(_m);
                    return std::optional(is_pointer_ty_f(cp_p0, t_pc));
                }
                if (prism_rtl::is_none(_m)) {
                    return std::optional<bool>{};
                }
                prism_rtl::unreachable("no arm matched");
            }
        }
    }
    {
        return std::optional<bool>{};
    }
}


/// IsPointerTy: fn Cp, OutTy -> Bool
bool is_pointer_ty_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::OutTy& t_p1) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p1)) {
        auto&& m19005_0_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        if (m19005_0_0 == Text::lit("prism_rtl::Rows")) {
            return true;
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutPort>(t_p1)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRc>(t_p1)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutObj>(t_p1)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutJob>(t_p1)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutShowAny>(t_p1)) {
        return true;
    }
    {
        return false;
    }
}


/// MethodForm: fn Text, Nat -> Text
Text method_form_f(const Text& m_p0, const Nat& n_p1) {
    auto&& _m = std::tuple{m_p0, n_p1};
    {
        auto&& m19532_0_0 = std::get<0>(_m);
        auto&& m19532_0_1 = std::get<1>(_m);
        if (m19532_0_0 == Text::lit("borrow")) {
            if (m19532_0_1 == Nat(0u)) {
                return Text::lit("deref");
            }
        }
    }
    {
        auto&& m19532_1_0 = std::get<0>(_m);
        auto&& m19532_1_1 = std::get<1>(_m);
        if (m19532_1_0 == Text::lit("borrow_mut")) {
            if (m19532_1_1 == Nat(0u)) {
                return Text::lit("deref");
            }
        }
    }
    {
        auto&& m19532_2_0 = std::get<0>(_m);
        auto&& m19532_2_1 = std::get<1>(_m);
        if (m19532_2_0 == Text::lit("clone")) {
            if (m19532_2_1 == Nat(0u)) {
                return Text::lit("id");
            }
        }
    }
    {
        auto&& m19532_3_0 = std::get<0>(_m);
        auto&& m19532_3_1 = std::get<1>(_m);
        if (m19532_3_0 == Text::lit("iter")) {
            if (m19532_3_1 == Nat(0u)) {
                return Text::lit("id");
            }
        }
    }
    {
        auto&& m19532_4_0 = std::get<0>(_m);
        auto&& m19532_4_1 = std::get<1>(_m);
        if (m19532_4_0 == Text::lit("collect")) {
            if (m19532_4_1 == Nat(0u)) {
                return Text::lit("id");
            }
        }
    }
    {
        auto&& m19532_5_0 = std::get<0>(_m);
        auto&& m19532_5_1 = std::get<1>(_m);
        if (m19532_5_0 == Text::lit("unwrap_or_default")) {
            if (m19532_5_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m19532_6_0 = std::get<0>(_m);
        auto&& m19532_6_1 = std::get<1>(_m);
        if (m19532_6_0 == Text::lit("for_each")) {
            if (m19532_6_1 == Nat(1u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m19532_7_0 = std::get<0>(_m);
        auto&& m19532_7_1 = std::get<1>(_m);
        if (m19532_7_0 == Text::lit("into_iter")) {
            if (m19532_7_1 == Nat(0u)) {
                return Text::lit("id");
            }
        }
    }
    {
        auto&& m19532_8_0 = std::get<0>(_m);
        auto&& m19532_8_1 = std::get<1>(_m);
        if (m19532_8_0 == Text::lit("as_ref")) {
            if (m19532_8_1 == Nat(0u)) {
                return Text::lit("id");
            }
        }
    }
    {
        auto&& m19532_9_0 = std::get<0>(_m);
        auto&& m19532_9_1 = std::get<1>(_m);
        if (m19532_9_0 == Text::lit("get")) {
            if (m19532_9_1 == Nat(0u)) {
                return Text::lit("id");
            }
        }
    }
    {
        auto&& m19532_10_0 = std::get<0>(_m);
        auto&& m19532_10_1 = std::get<1>(_m);
        if (m19532_10_0 == Text::lit("set")) {
            if (m19532_10_1 == Nat(1u)) {
                return Text::lit("assign");
            }
        }
    }
    {
        auto&& m19532_11_0 = std::get<0>(_m);
        auto&& m19532_11_1 = std::get<1>(_m);
        if (m19532_11_0 == Text::lit("take")) {
            if (m19532_11_1 == Nat(0u)) {
                return Text::lit("take");
            }
        }
    }
    {
        auto&& m19532_12_0 = std::get<0>(_m);
        auto&& m19532_12_1 = std::get<1>(_m);
        if (m19532_12_0 == Text::lit("replace")) {
            if (m19532_12_1 == Nat(1u)) {
                return Text::lit("exchange");
            }
        }
    }
    {
        auto&& m19532_13_0 = std::get<0>(_m);
        auto&& m19532_13_1 = std::get<1>(_m);
        if (m19532_13_0 == Text::lit("values")) {
            if (m19532_13_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m19532_14_0 = std::get<0>(_m);
        auto&& m19532_14_1 = std::get<1>(_m);
        if (m19532_14_0 == Text::lit("keys")) {
            if (m19532_14_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m19532_15_0 = std::get<0>(_m);
        auto&& m19532_15_1 = std::get<1>(_m);
        if (m19532_15_0 == Text::lit("enumerate")) {
            if (m19532_15_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m19532_16_0 = std::get<0>(_m);
        auto&& m19532_16_1 = std::get<1>(_m);
        if (m19532_16_0 == Text::lit("fire")) {
            if (m19532_16_1 == Nat(2u)) {
                return Text::lit("arrow");
            }
        }
    }
    {
        auto&& m19532_17_0 = std::get<0>(_m);
        auto&& m19532_17_1 = std::get<1>(_m);
        if (m19532_17_0 == Text::lit("subscribe")) {
            if (m19532_17_1 == Nat(1u)) {
                return Text::lit("arrow");
            }
        }
    }
    {
        auto&& m19532_18_0 = std::get<0>(_m);
        auto&& m19532_18_1 = std::get<1>(_m);
        if (m19532_18_0 == Text::lit("unsubscribe")) {
            if (m19532_18_1 == Nat(1u)) {
                return Text::lit("arrow");
            }
        }
    }
    {
        auto&& m19532_19_0 = std::get<0>(_m);
        auto&& m19532_19_1 = std::get<1>(_m);
        if (m19532_19_0 == Text::lit("cycle")) {
            if (m19532_19_1 == Nat(0u)) {
                return Text::lit("arrow");
            }
        }
    }
    {
        auto&& m19532_20_0 = std::get<0>(_m);
        auto&& m19532_20_1 = std::get<1>(_m);
        if (m19532_20_0 == Text::lit("upgrade")) {
            if (m19532_20_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m19532_21_0 = std::get<0>(_m);
        auto&& m19532_21_1 = std::get<1>(_m);
        if (m19532_21_0 == Text::lit("expect")) {
            if (m19532_21_1 == Nat(1u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m19532_22_0 = std::get<0>(_m);
        auto&& m19532_22_1 = std::get<1>(_m);
        if (m19532_22_0 == Text::lit("to_pod")) {
            if (m19532_22_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m19532_23_0 = std::get<0>(_m);
        auto&& m19532_23_1 = std::get<1>(_m);
        if (m19532_23_0 == Text::lit("cloned")) {
            if (m19532_23_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m19532_24_0 = std::get<0>(_m);
        auto&& m19532_24_1 = std::get<1>(_m);
        if (m19532_24_0 == Text::lit("ok")) {
            if (m19532_24_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m19532_25_0 = std::get<0>(_m);
        auto&& m19532_25_1 = std::get<1>(_m);
        if (m19532_25_0 == Text::lit("ok_or")) {
            if (m19532_25_1 == Nat(1u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m19532_26_0 = std::get<0>(_m);
        auto&& m19532_26_1 = std::get<1>(_m);
        if (m19532_26_0 == Text::lit("map")) {
            if (m19532_26_1 == Nat(1u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m19532_27_0 = std::get<0>(_m);
        auto&& m19532_27_1 = std::get<1>(_m);
        if (m19532_27_0 == Text::lit("iter_mut")) {
            if (m19532_27_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m19532_28_0 = std::get<0>(_m);
        auto&& m19532_28_1 = std::get<1>(_m);
        if (m19532_28_0 == Text::lit("to_vec")) {
            if (m19532_28_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m19532_29_0 = std::get<0>(_m);
        auto&& m19532_29_1 = std::get<1>(_m);
        if (m19532_29_0 == Text::lit("filter_some")) {
            if (m19532_29_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        return Text::lit("dot");
    }
}


/// FreeName: fn Text -> Text
Text free_name_f(const Text& m_p0) {
    {
        auto&& m20469_0 = m_p0;
        if (m20469_0 == Text::lit("to_pod")) {
            return Text::lit("prism_rtl::to_pod");
        }
    }
    {
        auto&& m20469_1 = m_p0;
        if (m20469_1 == Text::lit("ok")) {
            return Text::lit("prism_rtl::ignore");
        }
    }
    {
        auto&& m20469_2 = m_p0;
        if (m20469_2 == Text::lit("map")) {
            return Text::lit("prism_rtl::fmap");
        }
    }
    {
        auto&& m20469_3 = m_p0;
        if (m20469_3 == Text::lit("ok_or")) {
            return Text::lit("prism_rtl::ok_or");
        }
    }
    {
        auto&& m20469_4 = m_p0;
        if (m20469_4 == Text::lit("to_vec")) {
            return Text::lit("prism_rtl::path_of");
        }
    }
    {
        auto&& m20469_5 = m_p0;
        if (m20469_5 == Text::lit("values")) {
            return Text::lit("crate::prelude::values");
        }
    }
    {
        auto&& m20469_6 = m_p0;
        if (m20469_6 == Text::lit("keys")) {
            return Text::lit("crate::prelude::keys");
        }
    }
    {
        auto&& m20469_7 = m_p0;
        if (m20469_7 == Text::lit("enumerate")) {
            return Text::lit("prism_rtl::enumerate");
        }
    }
    {
        auto&& m20469_8 = m_p0;
        if (m20469_8 == Text::lit("unwrap_or_default")) {
            return Text::lit("prism_rtl::unwrap_or_default");
        }
    }
    {
        auto&& m20469_9 = m_p0;
        if (m20469_9 == Text::lit("for_each")) {
            return Text::lit("prism_rtl::for_each");
        }
    }
    {
        return m_p0;
    }
}


/// MemberName: fn Text -> Text
Text member_name_f(const Text& m_p0) {
    {
        auto&& m20910_0 = m_p0;
        if (m20910_0 == Text::lit("push_str")) {
            return Text::lit("append");
        }
    }
    {
        auto&& m20910_1 = m_p0;
        if (m20910_1 == Text::lit("len")) {
            return Text::lit("size");
        }
    }
    {
        auto&& m20910_2 = m_p0;
        if (m20910_2 == Text::lit("is_empty")) {
            return Text::lit("empty");
        }
    }
    {
        auto&& m20910_3 = m_p0;
        if (m20910_3 == Text::lit("push")) {
            return Text::lit("push_back");
        }
    }
    {
        auto&& m20910_4 = m_p0;
        if (m20910_4 == Text::lit("contains_key")) {
            return Text::lit("contains");
        }
    }
    {
        auto&& m20910_5 = m_p0;
        if (m20910_5 == Text::lit("build")) {
            return Text::lit("make");
        }
    }
    {
        return crate::emit::cpp::cpp_id_f(m_p0);
    }
}


/// CaseTest: fn Cp, Text, Text -> Text
Text case_test_f(const crate::emit::cpp::Cp& cp_p0, const Text& c_p1, const Text& v_p2) {
    {
        auto&& m21209_0 = c_p1;
        if (m21209_0 == Text::lit("Some")) {
            return prism_rtl::cat("prism_rtl::is_some(", v_p2, ")");
        }
    }
    {
        auto&& m21209_1 = c_p1;
        if (m21209_1 == Text::lit("None")) {
            return prism_rtl::cat("prism_rtl::is_none(", v_p2, ")");
        }
    }
    {
        auto&& m21209_2 = c_p1;
        if (m21209_2 == Text::lit("Ok")) {
            return prism_rtl::cat("prism_rtl::is_ok(", v_p2, ")");
        }
    }
    {
        auto&& m21209_3 = c_p1;
        if (m21209_3 == Text::lit("Err")) {
            return prism_rtl::cat("prism_rtl::is_err(", v_p2, ")");
        }
    }
    {
        auto&& m21209_4 = c_p1;
        if (m21209_4 == Text::lit("prism_rtl::Turn::More")) {
            return prism_rtl::cat(v_p2, ".if_more()");
        }
    }
    {
        auto&& m21209_5 = c_p1;
        if (m21209_5 == Text::lit("prism_rtl::Turn::Finished")) {
            return prism_rtl::cat(v_p2, ".if_finished()");
        }
    }
    {
        auto&& _m = crate::emit::cpp::case_of_o(cp_p0, c_p1);
        if (prism_rtl::is_some(_m)) {
            return prism_rtl::cat("prism_rtl::is<", case_type_of_f(cp_p0, c_p1, v_p2), ">(", v_p2, ")");
        }
        if (prism_rtl::is_none(_m)) {
            return is_runtime_case_f(c_p1)
                ? prism_rtl::cat("prism_rtl::is<", case_type_f(c_p1), ">(", v_p2, ")")
                : Text::lit("true");
        }
        prism_rtl::unreachable("no arm matched");
    }
}


/// CaseType: fn Text -> Text
Text case_type_f(const Text& c_p0) {
    {
        auto&& m21770_0 = c_p0;
        if (m21770_0 == Text::lit("Segment::Pos")) {
            return Text::lit("pat::Pos");
        }
    }
    {
        auto&& m21770_1 = c_p0;
        if (m21770_1 == Text::lit("Segment::Gen")) {
            return Text::lit("pat::Gen");
        }
    }
    {
        auto&& m21770_2 = c_p0;
        if (m21770_2 == Text::lit("Segment::Key")) {
            return Text::lit("pat::Key");
        }
    }
    {
        return crate::emit::cpp::type_path_f(c_p0);
    }
}


/// CaseTypeOf: fn Cp, Text, Text -> Text
Text case_type_of_f(const crate::emit::cpp::Cp& cp_p0, const Text& c_p1, const Text& v_p2) {
    return is_generic_case_f(cp_p0, c_p1)
        ? prism_rtl::cat("typename std::remove_cvref_t<decltype(", v_p2, ")>::", crate::emit::cpp::last_segment_f(crate::emit::cpp::type_path_f(c_p1)))
        : case_type_f(c_p1);
}


/// IsGenericCase: fn Cp, Text -> Bool
bool is_generic_case_f(const crate::emit::cpp::Cp& cp_p0, const Text& p_p1) {
    auto&& _m = crate::emit::cpp::case_of_o(cp_p0, p_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& ty_p2 = prism_rtl::some_of(_m);
        auto&& _m = crate::emit::cpp::type_of_o(cp_p0, ty_p2);
        if (prism_rtl::is_some(_m)) {
            auto&& info_p3 = prism_rtl::some_of(_m);
            return crate::prelude::len(prism_rtl::deref(info_p3).params_p) > Nat(0u);
        }
        if (prism_rtl::is_none(_m)) {
            return false;
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// Payload: fn Cp, Text, Text, Nat -> Text
Text payload_f(const crate::emit::cpp::Cp& cp_p0, const Text& c_p1, const Text& v_p2, const Nat& i_p3) {
    {
        auto&& m22630_0 = c_p1;
        if (m22630_0 == Text::lit("Some")) {
            return prism_rtl::cat("prism_rtl::some_of(", v_p2, ")");
        }
    }
    {
        auto&& m22630_1 = c_p1;
        if (m22630_1 == Text::lit("Ok")) {
            return prism_rtl::cat("*", v_p2);
        }
    }
    {
        auto&& m22630_2 = c_p1;
        if (m22630_2 == Text::lit("Err")) {
            return prism_rtl::cat(v_p2, ".error()");
        }
    }
    {
        auto&& m22630_3 = c_p1;
        if (m22630_3 == Text::lit("prism_rtl::Turn::More")) {
            return prism_rtl::cat(v_p2, ".if_more()->next");
        }
    }
    {
        auto&& m22630_4 = c_p1;
        if (m22630_4 == Text::lit("prism_rtl::Turn::Finished")) {
            return prism_rtl::cat(v_p2, ".if_finished()->value");
        }
    }
    {
        auto&& _m = crate::emit::cpp::case_of_o(cp_p0, c_p1);
        if (prism_rtl::is_some(_m)) {
            return prism_rtl::cat("prism_rtl::as<", case_type_of_f(cp_p0, c_p1, v_p2), ">(", v_p2, ").a", i_p3);
        }
        if (prism_rtl::is_none(_m)) {
            return is_runtime_case_f(c_p1)
                ? prism_rtl::cat("prism_rtl::as<", case_type_f(c_p1), ">(", v_p2, ").a", i_p3)
                : prism_rtl::cat(v_p2, ".a", i_p3);
        }
        prism_rtl::unreachable("no arm matched");
    }
}


/// IsRuntimeCase: fn Text -> Bool
bool is_runtime_case_f(const Text& c_p0) {
    return crate::syntax::lexer::chars::has_prefix_f(c_p0, Text::lit("Segment::"));
}


/// CppIf: unbounded fn Cp, Ex, Ex, Ex -> Text
Text cpp_if_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Ex& c_p1, const crate::lower::model::Ex& t_p2, const crate::lower::model::Ex& e_p3) {
    auto ct_p4 = cpp_expr_f(cp_p0, c_p1);
    auto err_o5 = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<crate::lower::model::Ex>> _v;
        auto&& _m = std::tuple{err_of_o(t_p2), err_of_o(e_p3)};
        if (prism_rtl::is_some(std::get<0>(_m))) {
            auto&& y_p9 = prism_rtl::some_of(std::get<0>(_m));
            _v.set(std::optional(y_p9));
            goto _done;
        }
        if (prism_rtl::is_none(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
            auto&& y_pa = prism_rtl::some_of(std::get<1>(_m));
            _v.set(std::optional(y_pa));
            goto _done;
        }
        {
            _v.set(std::optional<crate::lower::model::Ex>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto tt_p6 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is_some(err_o5)) {
            auto&& y_pb = prism_rtl::some_of(err_o5);
            _v.set(ok_branch_f(cp_p0, t_p2, y_pb));
            goto _done;
        }
        if (prism_rtl::is_none(err_o5)) {
            _v.set(cpp_expr_f(cp_p0, t_p2));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto et_p7 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is_some(err_o5)) {
            auto&& y_pc = prism_rtl::some_of(err_o5);
            _v.set(ok_branch_f(cp_p0, e_p3, y_pc));
            goto _done;
        }
        if (prism_rtl::is_none(err_o5)) {
            _v.set(cpp_expr_f(cp_p0, e_p3));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto short_p8 = (!crate::syntax::lexer::chars::contains_f(prism_rtl::cat(tt_p6, et_p7), Text::lit("\n"))) && (crate::prelude::len_text(prism_rtl::cat(ct_p4, tt_p6, et_p7)) < Nat(70u));
    return std::move(short_p8)
        ? prism_rtl::cat(ct_p4, " ? ", tt_p6, " : ", et_p7)
        : crate::emit::cpp::templates::items::cond_expr_f(ct_p4, tt_p6, et_p7);
}


prism_rtl::Turn<Text> CppIf::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& c_p1 = this->c_p1;
    const auto& t_p2 = this->t_p2;
    const auto& e_p3 = this->e_p3;
    auto c_p1x = c_p1;
    auto cp_p0x = cp_p0;
    auto e_p3x = e_p3;
    auto t_p2x = t_p2;
    return crate::prelude::call_then(start_cpp_expr_f(cp_p0x, c_p1x), [=](Text cpp_expr_f_23216) {
        return ({
            auto ct_p4 = cpp_expr_f_23216;
            auto err_o5 = ({
                __label__ _done;
                prism_rtl::Slot<std::optional<crate::lower::model::Ex>> _v;
                auto&& _m = std::tuple{err_of_o(t_p2x), err_of_o(e_p3x)};
                if (prism_rtl::is_some(std::get<0>(_m))) {
                    auto&& y_p9 = prism_rtl::some_of(std::get<0>(_m));
                    _v.set(std::optional(y_p9));
                    goto _done;
                }
                if (prism_rtl::is_none(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                    auto&& y_pa = prism_rtl::some_of(std::get<1>(_m));
                    _v.set(std::optional(y_pa));
                    goto _done;
                }
                {
                    _v.set(std::optional<crate::lower::model::Ex>{});
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto tt_p6 = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                if (prism_rtl::is_some(err_o5)) {
                    auto&& y_pb = prism_rtl::some_of(err_o5);
                    _v.set(ok_branch_f(cp_p0x, t_p2x, y_pb));
                    goto _done;
                }
                if (prism_rtl::is_none(err_o5)) {
                    _v.set(cpp_expr_f(cp_p0x, t_p2x));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto et_p7 = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                if (prism_rtl::is_some(err_o5)) {
                    auto&& y_pc = prism_rtl::some_of(err_o5);
                    _v.set(ok_branch_f(cp_p0x, e_p3x, y_pc));
                    goto _done;
                }
                if (prism_rtl::is_none(err_o5)) {
                    _v.set(cpp_expr_f(cp_p0x, e_p3x));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto short_p8 = (!crate::syntax::lexer::chars::contains_f(prism_rtl::cat(tt_p6, et_p7), Text::lit("\n"))) && (crate::prelude::len_text(prism_rtl::cat(ct_p4, tt_p6, et_p7)) < Nat(70u));
            (std::move(short_p8)
            ? prism_rtl::finished(prism_rtl::cat(ct_p4, " ? ", tt_p6, " : ", et_p7))
            : prism_rtl::finished(crate::emit::cpp::templates::items::cond_expr_f(ct_p4, tt_p6, et_p7)));
        });
    });
}


/// `Start CppIf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_if_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex c_p1, crate::lower::model::Ex t_p2, crate::lower::model::Ex e_p3) {
    return prism_rtl::make_rc<CppIf>(cp_p0, c_p1, t_p2, e_p3);
}


/// WithMoveCaptures: unbounded fn Cp, [Do], Ex -> Cp
crate::emit::cpp::Cp with_move_captures_f(const crate::emit::cpp::Cp& cp_p0, const Array<crate::lower::model::Do>& dos_p1, const crate::lower::model::Ex& e_p2) {
    auto lets_p3 = crate::prelude::fold(dos_p1, Array<Text>{}, [&](const Array<Text>& acc_p4, const crate::lower::model::Do& d_p5) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            if (prism_rtl::is<crate::lower::model::Do::DoLet>(d_p5)) {
                auto&& p_p6 = prism_rtl::as<crate::lower::model::Do::DoLet>(d_p5).a0;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    auto&& _m = crate::emit::cpp::stmts::let_name_o(p_p6);
                    if (prism_rtl::is_some(_m)) {
                        auto&& n_p7 = prism_rtl::some_of(_m);
                        _v.set(crate::emit::cpp::in_list_f(acc_p4, n_p7)
                            ? acc_p4
                            : crate::prelude::push(acc_p4, n_p7));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc_p4);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(acc_p4);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return crate::prelude::len(lets_p3) == Nat(0u)
        ? ({
        crate::emit::cpp::Cp this_ = cp_p0;
        this_.move_captures_p = Array<Text>{};
        (std::move(this_));
    })
        : ({
        auto [reads_p8, has_move_p9] = reads_of_f(e_p2, false, std::tuple{Array<Text>{}, false});
        ({
        crate::emit::cpp::Cp this_ = cp_p0;
        this_.move_captures_p = has_move_p9
            ? crate::prelude::filter(lets_p3, [&](const Text& n_pa) { return !crate::emit::cpp::in_list_f(reads_p8, n_pa); })
            : Array<Text>{};
        (std::move(this_));
    });
    });
}


prism_rtl::Turn<crate::emit::cpp::Cp> WithMoveCaptures::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& dos_p1 = this->dos_p1;
    const auto& e_p2 = this->e_p2;
    auto lets_p3 = crate::prelude::fold(dos_p1, Array<Text>{}, [&](const Array<Text>& acc_p4, const crate::lower::model::Do& d_p5) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            if (prism_rtl::is<crate::lower::model::Do::DoLet>(d_p5)) {
                auto&& p_p6 = prism_rtl::as<crate::lower::model::Do::DoLet>(d_p5).a0;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    auto&& _m = crate::emit::cpp::stmts::let_name_o(p_p6);
                    if (prism_rtl::is_some(_m)) {
                        auto&& n_p7 = prism_rtl::some_of(_m);
                        _v.set(crate::emit::cpp::in_list_f(acc_p4, n_p7)
                            ? acc_p4
                            : crate::prelude::push(acc_p4, n_p7));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc_p4);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(acc_p4);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return crate::prelude::len(lets_p3) == Nat(0u)
        ? prism_rtl::finished(({
        crate::emit::cpp::Cp this_ = cp_p0;
        this_.move_captures_p = Array<Text>{};
        (std::move(this_));
    }))
        : ({
        auto cp_p0x = cp_p0;
        auto e_p2x = e_p2;
        (crate::prelude::call_then(start_reads_of_f(e_p2x, false, std::tuple{Array<Text>{}, false}), [=, cp_p0x = std::move(cp_p0x)](std::tuple<Array<Text>, bool> reads_of_f_24465) {
        return ({
            auto [reads_p8, has_move_p9] = reads_of_f_24465;
            (prism_rtl::finished(({
            crate::emit::cpp::Cp this_ = cp_p0x;
            this_.move_captures_p = has_move_p9
                ? crate::prelude::filter(lets_p3, [&](const Text& n_pa) { return !crate::emit::cpp::in_list_f(reads_p8, n_pa); })
                : Array<Text>{};
            (std::move(this_));
        })));
        });
    }));
    });
}


/// `Start WithMoveCaptures, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::emit::cpp::Cp> start_with_move_captures_f(crate::emit::cpp::Cp cp_p0, Array<crate::lower::model::Do> dos_p1, crate::lower::model::Ex e_p2) {
    return prism_rtl::make_rc<WithMoveCaptures>(cp_p0, dos_p1, e_p2);
}


/// ReadsOf: unbounded fn Ex, Bool, (([Text], Bool)) -> (([Text], Bool))
std::tuple<Array<Text>, bool> reads_of_f(const crate::lower::model::Ex& x_p0, const bool& into_p1, const std::tuple<Array<Text>, bool>& acc_p2) {
    auto [reads_p3, has_move_p4] = acc_p2;
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(x_p0)) {
        auto&& n_p5 = prism_rtl::as<crate::lower::model::Ex::XVar>(x_p0).a0;
        return std::tuple{crate::prelude::push(reads_p3, n_p5), has_move_p4};
    }
    if (prism_rtl::is<crate::lower::model::Ex::XClosure>(x_p0) && prism_rtl::as<crate::lower::model::Ex::XClosure>(x_p0).a0) {
        auto&& ps_p6 = prism_rtl::as<crate::lower::model::Ex::XClosure>(x_p0).a1;
        auto&& body_p7 = prism_rtl::as<crate::lower::model::Ex::XClosure>(x_p0).a2;
        return into_p1
            ? reads_of_f(prism_rtl::deref(prism_rtl::deref(body_p7)), into_p1, std::tuple{reads_p3, true})
            : std::tuple{reads_p3, true};
    }
    if (prism_rtl::is<crate::lower::model::Ex::XClosure>(x_p0) && !prism_rtl::as<crate::lower::model::Ex::XClosure>(x_p0).a0) {
        auto&& ps_p8 = prism_rtl::as<crate::lower::model::Ex::XClosure>(x_p0).a1;
        auto&& body_p9 = prism_rtl::as<crate::lower::model::Ex::XClosure>(x_p0).a2;
        return reads_of_f(prism_rtl::deref(prism_rtl::deref(body_p9)), into_p1, acc_p2);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRef>(x_p0)) {
        auto&& y_pa = prism_rtl::as<crate::lower::model::Ex::XRef>(x_p0).a0;
        return reads_of_f(prism_rtl::deref(prism_rtl::deref(y_pa)), into_p1, acc_p2);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRefMut>(x_p0)) {
        auto&& y_pb = prism_rtl::as<crate::lower::model::Ex::XRefMut>(x_p0).a0;
        return reads_of_f(prism_rtl::deref(prism_rtl::deref(y_pb)), into_p1, acc_p2);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XDeref>(x_p0)) {
        auto&& y_pc = prism_rtl::as<crate::lower::model::Ex::XDeref>(x_p0).a0;
        return reads_of_f(prism_rtl::deref(prism_rtl::deref(y_pc)), into_p1, acc_p2);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTarget>(x_p0)) {
        auto&& y_pd = prism_rtl::as<crate::lower::model::Ex::XTarget>(x_p0).a0;
        return reads_of_f(prism_rtl::deref(prism_rtl::deref(y_pd)), into_p1, acc_p2);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XClone>(x_p0)) {
        auto&& y_pe = prism_rtl::as<crate::lower::model::Ex::XClone>(x_p0).a0;
        return reads_of_f(prism_rtl::deref(prism_rtl::deref(y_pe)), into_p1, acc_p2);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XWeak>(x_p0)) {
        auto&& y_pf = prism_rtl::as<crate::lower::model::Ex::XWeak>(x_p0).a0;
        return reads_of_f(prism_rtl::deref(prism_rtl::deref(y_pf)), into_p1, acc_p2);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUpgrade>(x_p0)) {
        auto&& y_pg = prism_rtl::as<crate::lower::model::Ex::XUpgrade>(x_p0).a0;
        return reads_of_f(prism_rtl::deref(prism_rtl::deref(y_pg)), into_p1, acc_p2);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBreak>(x_p0)) {
        auto&& y_ph = prism_rtl::as<crate::lower::model::Ex::XBreak>(x_p0).a1;
        return reads_of_f(prism_rtl::deref(prism_rtl::deref(y_ph)), into_p1, acc_p2);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XLater>(x_p0)) {
        auto&& y_pi = prism_rtl::as<crate::lower::model::Ex::XLater>(x_p0).a0;
        return reads_of_f(prism_rtl::deref(prism_rtl::deref(y_pi)), into_p1, acc_p2);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XFormatStr>(x_p0)) {
        auto&& xs_pj = prism_rtl::as<crate::lower::model::Ex::XFormatStr>(x_p0).a0;
        return reads_each_f(xs_pj, into_p1, acc_p2);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XIsCase>(x_p0)) {
        auto&& y_pk = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x_p0).a0;
        return reads_of_f(prism_rtl::deref(prism_rtl::deref(y_pk)), into_p1, acc_p2);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XCall>(x_p0)) {
        auto&& xs_pl = prism_rtl::as<crate::lower::model::Ex::XCall>(x_p0).a1;
        return reads_each_f(xs_pl, into_p1, acc_p2);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XApply>(x_p0)) {
        auto&& f_pm = prism_rtl::as<crate::lower::model::Ex::XApply>(x_p0).a0;
        auto&& xs_pn = prism_rtl::as<crate::lower::model::Ex::XApply>(x_p0).a1;
        return reads_each_f(crate::prelude::append(Array(std::vector{prism_rtl::deref(prism_rtl::deref(f_pm))}), xs_pn), into_p1, acc_p2);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XMethod>(x_p0)) {
        auto&& r_po = prism_rtl::as<crate::lower::model::Ex::XMethod>(x_p0).a0;
        auto&& xs_pp = prism_rtl::as<crate::lower::model::Ex::XMethod>(x_p0).a2;
        return reads_each_f(crate::prelude::append(Array(std::vector{prism_rtl::deref(prism_rtl::deref(r_po))}), xs_pp), into_p1, acc_p2);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBin>(x_p0)) {
        auto&& l_pq = prism_rtl::as<crate::lower::model::Ex::XBin>(x_p0).a1;
        auto&& r_pr = prism_rtl::as<crate::lower::model::Ex::XBin>(x_p0).a2;
        return reads_each_f(Array(std::vector{prism_rtl::deref(prism_rtl::deref(l_pq)), prism_rtl::deref(prism_rtl::deref(r_pr))}), into_p1, acc_p2);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUnary>(x_p0)) {
        auto&& y_ps = prism_rtl::as<crate::lower::model::Ex::XUnary>(x_p0).a1;
        return reads_of_f(prism_rtl::deref(prism_rtl::deref(y_ps)), into_p1, acc_p2);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XCtor>(x_p0)) {
        auto&& xs_pt = prism_rtl::as<crate::lower::model::Ex::XCtor>(x_p0).a1;
        return reads_each_f(xs_pt, into_p1, acc_p2);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRecord>(x_p0)) {
        auto&& fs_pu = prism_rtl::as<crate::lower::model::Ex::XRecord>(x_p0).a1;
        return reads_each_f(crate::prelude::each(fs_pu, [&](const std::tuple<Text, crate::lower::model::Ex>& _p0) {
            auto&& v_pv = std::get<1>(_p0);
            return v_pv;
        }), into_p1, acc_p2);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTuple>(x_p0)) {
        auto&& xs_p10 = prism_rtl::as<crate::lower::model::Ex::XTuple>(x_p0).a0;
        return reads_each_f(xs_p10, into_p1, acc_p2);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XVec>(x_p0)) {
        auto&& xs_p11 = prism_rtl::as<crate::lower::model::Ex::XVec>(x_p0).a0;
        return reads_each_f(xs_p11, into_p1, acc_p2);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XFormat>(x_p0)) {
        auto&& xs_p12 = prism_rtl::as<crate::lower::model::Ex::XFormat>(x_p0).a0;
        return reads_each_f(xs_p12, into_p1, acc_p2);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XMatch>(x_p0)) {
        auto&& s_p13 = prism_rtl::as<crate::lower::model::Ex::XMatch>(x_p0).a0;
        auto&& arms_p14 = prism_rtl::as<crate::lower::model::Ex::XMatch>(x_p0).a1;
        return reads_arms_f(arms_p14, into_p1, reads_of_f(prism_rtl::deref(prism_rtl::deref(s_p13)), into_p1, acc_p2));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XChain>(x_p0)) {
        auto&& s_p15 = prism_rtl::as<crate::lower::model::Ex::XChain>(x_p0).a1;
        auto&& arms_p16 = prism_rtl::as<crate::lower::model::Ex::XChain>(x_p0).a2;
        return reads_arms_f(arms_p16, into_p1, reads_of_f(prism_rtl::deref(prism_rtl::deref(s_p15)), into_p1, acc_p2));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XIf>(x_p0)) {
        auto&& c_p17 = prism_rtl::as<crate::lower::model::Ex::XIf>(x_p0).a0;
        auto&& t_p18 = prism_rtl::as<crate::lower::model::Ex::XIf>(x_p0).a1;
        auto&& e_p19 = prism_rtl::as<crate::lower::model::Ex::XIf>(x_p0).a2;
        return reads_each_f(Array(std::vector{prism_rtl::deref(prism_rtl::deref(c_p17)), prism_rtl::deref(prism_rtl::deref(t_p18)), prism_rtl::deref(prism_rtl::deref(e_p19))}), into_p1, acc_p2);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBlock>(x_p0)) {
        auto&& dos_p1a = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a0;
        auto&& e_p1b = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a1;
        return reads_of_f(prism_rtl::deref(prism_rtl::deref(e_p1b)), into_p1, reads_dos_f(dos_p1a, into_p1, acc_p2));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XLabeled>(x_p0)) {
        auto&& dos_p1c = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x_p0).a1;
        auto&& e_p1d = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x_p0).a2;
        return reads_of_f(prism_rtl::deref(prism_rtl::deref(e_p1d)), into_p1, reads_dos_f(dos_p1c, into_p1, acc_p2));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTry>(x_p0)) {
        auto&& y_p1e = prism_rtl::as<crate::lower::model::Ex::XTry>(x_p0).a0;
        return reads_of_f(prism_rtl::deref(prism_rtl::deref(y_p1e)), into_p1, acc_p2);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x_p0)) {
        auto&& r_p1f = prism_rtl::as<crate::lower::model::Ex::XField>(x_p0).a0;
        return reads_of_f(prism_rtl::deref(prism_rtl::deref(r_p1f)), into_p1, acc_p2);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XPart>(x_p0)) {
        auto&& r_p1g = prism_rtl::as<crate::lower::model::Ex::XPart>(x_p0).a0;
        return reads_of_f(prism_rtl::deref(prism_rtl::deref(r_p1g)), into_p1, acc_p2);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XDecode>(x_p0)) {
        auto&& y_p1h = prism_rtl::as<crate::lower::model::Ex::XDecode>(x_p0).a1;
        return reads_of_f(prism_rtl::deref(prism_rtl::deref(y_p1h)), into_p1, acc_p2);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XCast>(x_p0)) {
        auto&& y_p1i = prism_rtl::as<crate::lower::model::Ex::XCast>(x_p0).a0;
        return reads_of_f(prism_rtl::deref(prism_rtl::deref(y_p1i)), into_p1, acc_p2);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTyped>(x_p0)) {
        auto&& y_p1j = prism_rtl::as<crate::lower::model::Ex::XTyped>(x_p0).a0;
        return reads_of_f(prism_rtl::deref(prism_rtl::deref(y_p1j)), into_p1, acc_p2);
    }
    {
        return acc_p2;
    }
}


prism_rtl::Turn<std::tuple<Array<Text>, bool>> ReadsOf::cycle() const {
    const auto& x_p0 = this->x_p0;
    const auto& into_p1 = this->into_p1;
    const auto& acc_p2 = this->acc_p2;
    auto [reads_p3, has_move_p4] = acc_p2;
    return ({
        prism_rtl::is<crate::lower::model::Ex::XVar>(x_p0) ? ({
        auto&& n_p5 = prism_rtl::as<crate::lower::model::Ex::XVar>(x_p0).a0;
        prism_rtl::finished(std::tuple{crate::prelude::push(reads_p3, n_p5), has_move_p4});
    })
        : prism_rtl::is<crate::lower::model::Ex::XClosure>(x_p0) && prism_rtl::as<crate::lower::model::Ex::XClosure>(x_p0).a0 ? ({
        auto&& ps_p6 = prism_rtl::as<crate::lower::model::Ex::XClosure>(x_p0).a1;
        auto&& body_p7 = prism_rtl::as<crate::lower::model::Ex::XClosure>(x_p0).a2;
        prism_rtl::deref(into_p1)
        ? prism_rtl::more(prism_rtl::rc(ReadsOf(prism_rtl::deref(prism_rtl::deref(body_p7)), prism_rtl::deref(into_p1), std::tuple{reads_p3, true})))
        : prism_rtl::finished(std::tuple{reads_p3, true});
    })
        : prism_rtl::is<crate::lower::model::Ex::XClosure>(x_p0) && !prism_rtl::as<crate::lower::model::Ex::XClosure>(x_p0).a0 ? ({
        auto&& ps_p8 = prism_rtl::as<crate::lower::model::Ex::XClosure>(x_p0).a1;
        auto&& body_p9 = prism_rtl::as<crate::lower::model::Ex::XClosure>(x_p0).a2;
        prism_rtl::more(prism_rtl::rc(ReadsOf(prism_rtl::deref(prism_rtl::deref(body_p9)), prism_rtl::deref(into_p1), acc_p2)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XRef>(x_p0) ? ({
        auto&& y_pa = prism_rtl::as<crate::lower::model::Ex::XRef>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(ReadsOf(prism_rtl::deref(prism_rtl::deref(y_pa)), prism_rtl::deref(into_p1), acc_p2)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XRefMut>(x_p0) ? ({
        auto&& y_pb = prism_rtl::as<crate::lower::model::Ex::XRefMut>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(ReadsOf(prism_rtl::deref(prism_rtl::deref(y_pb)), prism_rtl::deref(into_p1), acc_p2)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XDeref>(x_p0) ? ({
        auto&& y_pc = prism_rtl::as<crate::lower::model::Ex::XDeref>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(ReadsOf(prism_rtl::deref(prism_rtl::deref(y_pc)), prism_rtl::deref(into_p1), acc_p2)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XTarget>(x_p0) ? ({
        auto&& y_pd = prism_rtl::as<crate::lower::model::Ex::XTarget>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(ReadsOf(prism_rtl::deref(prism_rtl::deref(y_pd)), prism_rtl::deref(into_p1), acc_p2)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XClone>(x_p0) ? ({
        auto&& y_pe = prism_rtl::as<crate::lower::model::Ex::XClone>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(ReadsOf(prism_rtl::deref(prism_rtl::deref(y_pe)), prism_rtl::deref(into_p1), acc_p2)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XWeak>(x_p0) ? ({
        auto&& y_pf = prism_rtl::as<crate::lower::model::Ex::XWeak>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(ReadsOf(prism_rtl::deref(prism_rtl::deref(y_pf)), prism_rtl::deref(into_p1), acc_p2)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XUpgrade>(x_p0) ? ({
        auto&& y_pg = prism_rtl::as<crate::lower::model::Ex::XUpgrade>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(ReadsOf(prism_rtl::deref(prism_rtl::deref(y_pg)), prism_rtl::deref(into_p1), acc_p2)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XBreak>(x_p0) ? ({
        auto&& y_ph = prism_rtl::as<crate::lower::model::Ex::XBreak>(x_p0).a1;
        prism_rtl::more(prism_rtl::rc(ReadsOf(prism_rtl::deref(prism_rtl::deref(y_ph)), prism_rtl::deref(into_p1), acc_p2)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XLater>(x_p0) ? ({
        auto&& y_pi = prism_rtl::as<crate::lower::model::Ex::XLater>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(ReadsOf(prism_rtl::deref(prism_rtl::deref(y_pi)), prism_rtl::deref(into_p1), acc_p2)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XFormatStr>(x_p0) ? ({
        auto&& xs_pj = prism_rtl::as<crate::lower::model::Ex::XFormatStr>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(ReadsEach(xs_pj, prism_rtl::deref(into_p1), acc_p2)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XIsCase>(x_p0) ? ({
        auto&& y_pk = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(ReadsOf(prism_rtl::deref(prism_rtl::deref(y_pk)), prism_rtl::deref(into_p1), acc_p2)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XCall>(x_p0) ? ({
        auto&& xs_pl = prism_rtl::as<crate::lower::model::Ex::XCall>(x_p0).a1;
        prism_rtl::more(prism_rtl::rc(ReadsEach(xs_pl, prism_rtl::deref(into_p1), acc_p2)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XApply>(x_p0) ? ({
        auto&& f_pm = prism_rtl::as<crate::lower::model::Ex::XApply>(x_p0).a0;
        auto&& xs_pn = prism_rtl::as<crate::lower::model::Ex::XApply>(x_p0).a1;
        prism_rtl::more(prism_rtl::rc(ReadsEach(crate::prelude::append(Array(std::vector{prism_rtl::deref(prism_rtl::deref(f_pm))}), xs_pn), prism_rtl::deref(into_p1), acc_p2)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XMethod>(x_p0) ? ({
        auto&& r_po = prism_rtl::as<crate::lower::model::Ex::XMethod>(x_p0).a0;
        auto&& xs_pp = prism_rtl::as<crate::lower::model::Ex::XMethod>(x_p0).a2;
        prism_rtl::more(prism_rtl::rc(ReadsEach(crate::prelude::append(Array(std::vector{prism_rtl::deref(prism_rtl::deref(r_po))}), xs_pp), prism_rtl::deref(into_p1), acc_p2)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XBin>(x_p0) ? ({
        auto&& l_pq = prism_rtl::as<crate::lower::model::Ex::XBin>(x_p0).a1;
        auto&& r_pr = prism_rtl::as<crate::lower::model::Ex::XBin>(x_p0).a2;
        prism_rtl::more(prism_rtl::rc(ReadsEach(Array(std::vector{prism_rtl::deref(prism_rtl::deref(l_pq)), prism_rtl::deref(prism_rtl::deref(r_pr))}), prism_rtl::deref(into_p1), acc_p2)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XUnary>(x_p0) ? ({
        auto&& y_ps = prism_rtl::as<crate::lower::model::Ex::XUnary>(x_p0).a1;
        prism_rtl::more(prism_rtl::rc(ReadsOf(prism_rtl::deref(prism_rtl::deref(y_ps)), prism_rtl::deref(into_p1), acc_p2)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XCtor>(x_p0) ? ({
        auto&& xs_pt = prism_rtl::as<crate::lower::model::Ex::XCtor>(x_p0).a1;
        prism_rtl::more(prism_rtl::rc(ReadsEach(xs_pt, prism_rtl::deref(into_p1), acc_p2)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XRecord>(x_p0) ? ({
        auto&& fs_pu = prism_rtl::as<crate::lower::model::Ex::XRecord>(x_p0).a1;
        prism_rtl::more(prism_rtl::rc(ReadsEach(crate::prelude::each(fs_pu, [&](const std::tuple<Text, crate::lower::model::Ex>& _p0) {
        auto&& v_pv = std::get<1>(_p0);
        return v_pv;
    }), prism_rtl::deref(into_p1), acc_p2)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XTuple>(x_p0) ? ({
        auto&& xs_p10 = prism_rtl::as<crate::lower::model::Ex::XTuple>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(ReadsEach(xs_p10, prism_rtl::deref(into_p1), acc_p2)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XVec>(x_p0) ? ({
        auto&& xs_p11 = prism_rtl::as<crate::lower::model::Ex::XVec>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(ReadsEach(xs_p11, prism_rtl::deref(into_p1), acc_p2)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XFormat>(x_p0) ? ({
        auto&& xs_p12 = prism_rtl::as<crate::lower::model::Ex::XFormat>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(ReadsEach(xs_p12, prism_rtl::deref(into_p1), acc_p2)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XMatch>(x_p0) ? ({
        auto&& s_p13 = prism_rtl::as<crate::lower::model::Ex::XMatch>(x_p0).a0;
        auto&& arms_p14 = prism_rtl::as<crate::lower::model::Ex::XMatch>(x_p0).a1;
        ({
        auto acc_p2x = acc_p2;
        auto arms_p14x = arms_p14;
        auto into_p1x = prism_rtl::deref(into_p1);
        auto s_p13x = prism_rtl::deref(prism_rtl::deref(s_p13));
        (crate::prelude::call_then(start_reads_of_f(s_p13x, std::move(into_p1x), acc_p2x), [=, arms_p14x = std::move(arms_p14x)](std::tuple<Array<Text>, bool> reads_of_f_26167) { return prism_rtl::more(prism_rtl::rc(ReadsArms(arms_p14x, into_p1x, reads_of_f_26167))); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XChain>(x_p0) ? ({
        auto&& s_p15 = prism_rtl::as<crate::lower::model::Ex::XChain>(x_p0).a1;
        auto&& arms_p16 = prism_rtl::as<crate::lower::model::Ex::XChain>(x_p0).a2;
        ({
        auto acc_p2x = acc_p2;
        auto arms_p16x = arms_p16;
        auto into_p1x = prism_rtl::deref(into_p1);
        auto s_p15x = prism_rtl::deref(prism_rtl::deref(s_p15));
        (crate::prelude::call_then(start_reads_of_f(s_p15x, std::move(into_p1x), acc_p2x), [=, arms_p16x = std::move(arms_p16x)](std::tuple<Array<Text>, bool> reads_of_f_26252) { return prism_rtl::more(prism_rtl::rc(ReadsArms(arms_p16x, into_p1x, reads_of_f_26252))); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XIf>(x_p0) ? ({
        auto&& c_p17 = prism_rtl::as<crate::lower::model::Ex::XIf>(x_p0).a0;
        auto&& t_p18 = prism_rtl::as<crate::lower::model::Ex::XIf>(x_p0).a1;
        auto&& e_p19 = prism_rtl::as<crate::lower::model::Ex::XIf>(x_p0).a2;
        prism_rtl::more(prism_rtl::rc(ReadsEach(Array(std::vector{prism_rtl::deref(prism_rtl::deref(c_p17)), prism_rtl::deref(prism_rtl::deref(t_p18)), prism_rtl::deref(prism_rtl::deref(e_p19))}), prism_rtl::deref(into_p1), acc_p2)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XBlock>(x_p0) ? ({
        auto&& dos_p1a = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a0;
        auto&& e_p1b = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a1;
        ({
        auto acc_p2x = acc_p2;
        auto dos_p1ax = dos_p1a;
        auto e_p1bx = prism_rtl::deref(prism_rtl::deref(e_p1b));
        auto into_p1x = prism_rtl::deref(into_p1);
        (crate::prelude::call_then(start_reads_dos_f(dos_p1ax, std::move(into_p1x), acc_p2x), [=, e_p1bx = std::move(e_p1bx)](std::tuple<Array<Text>, bool> reads_dos_f_26369) { return prism_rtl::more(prism_rtl::rc(ReadsOf(e_p1bx, into_p1x, reads_dos_f_26369))); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XLabeled>(x_p0) ? ({
        auto&& dos_p1c = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x_p0).a1;
        auto&& e_p1d = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x_p0).a2;
        ({
        auto acc_p2x = acc_p2;
        auto dos_p1cx = dos_p1c;
        auto e_p1dx = prism_rtl::deref(prism_rtl::deref(e_p1d));
        auto into_p1x = prism_rtl::deref(into_p1);
        (crate::prelude::call_then(start_reads_dos_f(dos_p1cx, std::move(into_p1x), acc_p2x), [=, e_p1dx = std::move(e_p1dx)](std::tuple<Array<Text>, bool> reads_dos_f_26453) { return prism_rtl::more(prism_rtl::rc(ReadsOf(e_p1dx, into_p1x, reads_dos_f_26453))); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XTry>(x_p0) ? ({
        auto&& y_p1e = prism_rtl::as<crate::lower::model::Ex::XTry>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(ReadsOf(prism_rtl::deref(prism_rtl::deref(y_p1e)), prism_rtl::deref(into_p1), acc_p2)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XField>(x_p0) ? ({
        auto&& r_p1f = prism_rtl::as<crate::lower::model::Ex::XField>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(ReadsOf(prism_rtl::deref(prism_rtl::deref(r_p1f)), prism_rtl::deref(into_p1), acc_p2)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XPart>(x_p0) ? ({
        auto&& r_p1g = prism_rtl::as<crate::lower::model::Ex::XPart>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(ReadsOf(prism_rtl::deref(prism_rtl::deref(r_p1g)), prism_rtl::deref(into_p1), acc_p2)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XDecode>(x_p0) ? ({
        auto&& y_p1h = prism_rtl::as<crate::lower::model::Ex::XDecode>(x_p0).a1;
        prism_rtl::more(prism_rtl::rc(ReadsOf(prism_rtl::deref(prism_rtl::deref(y_p1h)), prism_rtl::deref(into_p1), acc_p2)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XCast>(x_p0) ? ({
        auto&& y_p1i = prism_rtl::as<crate::lower::model::Ex::XCast>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(ReadsOf(prism_rtl::deref(prism_rtl::deref(y_p1i)), prism_rtl::deref(into_p1), acc_p2)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XTyped>(x_p0) ? ({
        auto&& y_p1j = prism_rtl::as<crate::lower::model::Ex::XTyped>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(ReadsOf(prism_rtl::deref(prism_rtl::deref(y_p1j)), prism_rtl::deref(into_p1), acc_p2)));
    })
        : prism_rtl::finished(acc_p2);
    });
}


/// `Start ReadsOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<Text>, bool>> start_reads_of_f(crate::lower::model::Ex x_p0, bool into_p1, std::tuple<Array<Text>, bool> acc_p2) {
    return prism_rtl::make_rc<ReadsOf>(x_p0, into_p1, acc_p2);
}


/// ReadsEach: unbounded fn [Ex], Bool, (([Text], Bool)) -> (([Text], Bool))
std::tuple<Array<Text>, bool> reads_each_f(const Array<crate::lower::model::Ex>& xs_p0, const bool& into_p1, const std::tuple<Array<Text>, bool>& acc_p2) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(xs_p0, acc_p2, ({
        auto into_p1x = into_p1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, bool>>(std::tuple<std::tuple<Array<Text>, bool>, crate::lower::model::Ex>)>>(prism_rtl::rc([=, into_p1x = std::move(into_p1x)](std::tuple<std::tuple<Array<Text>, bool>, crate::lower::model::Ex> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto into_p1xy = into_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, into_p1xy = std::move(into_p1xy)]() {
            return ({
                auto a_p3 = p0;
                auto x_p4 = p1;
                (prism_rtl::more(prism_rtl::rc(ReadsOf(x_p4, into_p1xy, a_p3))));
            });
        })));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Array<Text>, bool>> ReadsEach::cycle() const {
    const auto& xs_p0 = this->xs_p0;
    const auto& into_p1 = this->into_p1;
    const auto& acc_p2 = this->acc_p2;
    return crate::prelude::fold_job(xs_p0, acc_p2, ({
        auto into_p1x = prism_rtl::deref(into_p1);
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, bool>>(std::tuple<std::tuple<Array<Text>, bool>, crate::lower::model::Ex>)>>(prism_rtl::rc([=, into_p1x = std::move(into_p1x)](std::tuple<std::tuple<Array<Text>, bool>, crate::lower::model::Ex> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto into_p1xy = into_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, into_p1xy = std::move(into_p1xy)]() {
            return ({
                auto a_p3 = p0;
                auto x_p4 = p1;
                (prism_rtl::more(prism_rtl::rc(ReadsOf(x_p4, into_p1xy, a_p3))));
            });
        })));
        });
    }));
    }))->cycle();
}


/// `Start ReadsEach, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<Text>, bool>> start_reads_each_f(Array<crate::lower::model::Ex> xs_p0, bool into_p1, std::tuple<Array<Text>, bool> acc_p2) {
    return prism_rtl::make_rc<ReadsEach>(xs_p0, into_p1, acc_p2);
}


/// ReadsArms: unbounded fn [XArm], Bool, (([Text], Bool)) -> (([Text], Bool))
std::tuple<Array<Text>, bool> reads_arms_f(const Array<crate::lower::model::XArm>& arms_p0, const bool& into_p1, const std::tuple<Array<Text>, bool>& acc_p2) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(arms_p0, acc_p2, ({
        auto into_p1x = into_p1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, bool>>(std::tuple<std::tuple<Array<Text>, bool>, crate::lower::model::XArm>)>>(prism_rtl::rc([=, into_p1x = std::move(into_p1x)](std::tuple<std::tuple<Array<Text>, bool>, crate::lower::model::XArm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto into_p1xy = into_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, into_p1xy = std::move(into_p1xy)]() {
            return ({
                auto a_p3 = p0;
                auto arm_p4 = p1;
                (crate::prelude::call_value(crate::prelude::fold_job(prism_rtl::deref(arm_p4).conds_p, a_p3, ({
                auto into_p1xyx = into_p1xy;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, bool>>(std::tuple<std::tuple<Array<Text>, bool>, crate::lower::model::Cc>)>>(prism_rtl::rc([=, into_p1xyx = std::move(into_p1xyx)](std::tuple<std::tuple<Array<Text>, bool>, crate::lower::model::Cc> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto into_p1xyxy = into_p1xyx;
                    (crate::prelude::entered(crate::prelude::once_job([=, into_p1xyxy = std::move(into_p1xyxy)]() {
                    return ({
                        auto a2_p5 = p0;
                        auto c_p6 = p1;
                        (prism_rtl::more(prism_rtl::rc(ReadsCond(c_p6, into_p1xyxy, a2_p5))));
                    });
                })));
                });
            }));
            })), [=](std::tuple<Array<Text>, bool> fold_27074) { return prism_rtl::more(prism_rtl::rc(ReadsOf(prism_rtl::deref(arm_p4).body_p, into_p1xy, fold_27074))); }));
            });
        })));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Array<Text>, bool>> ReadsArms::cycle() const {
    const auto& arms_p0 = this->arms_p0;
    const auto& into_p1 = this->into_p1;
    const auto& acc_p2 = this->acc_p2;
    return crate::prelude::fold_job(arms_p0, acc_p2, ({
        auto into_p1x = prism_rtl::deref(into_p1);
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, bool>>(std::tuple<std::tuple<Array<Text>, bool>, crate::lower::model::XArm>)>>(prism_rtl::rc([=, into_p1x = std::move(into_p1x)](std::tuple<std::tuple<Array<Text>, bool>, crate::lower::model::XArm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto into_p1xy = into_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, into_p1xy = std::move(into_p1xy)]() {
            return ({
                auto a_p3 = p0;
                auto arm_p4 = p1;
                (crate::prelude::call_value(crate::prelude::fold_job(prism_rtl::deref(arm_p4).conds_p, a_p3, ({
                auto into_p1xyx = into_p1xy;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, bool>>(std::tuple<std::tuple<Array<Text>, bool>, crate::lower::model::Cc>)>>(prism_rtl::rc([=, into_p1xyx = std::move(into_p1xyx)](std::tuple<std::tuple<Array<Text>, bool>, crate::lower::model::Cc> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto into_p1xyxy = into_p1xyx;
                    (crate::prelude::entered(crate::prelude::once_job([=, into_p1xyxy = std::move(into_p1xyxy)]() {
                    return ({
                        auto a2_p5 = p0;
                        auto c_p6 = p1;
                        (prism_rtl::more(prism_rtl::rc(ReadsCond(c_p6, into_p1xyxy, a2_p5))));
                    });
                })));
                });
            }));
            })), [=](std::tuple<Array<Text>, bool> fold_27074) { return prism_rtl::more(prism_rtl::rc(ReadsOf(prism_rtl::deref(arm_p4).body_p, into_p1xy, fold_27074))); }));
            });
        })));
        });
    }));
    }))->cycle();
}


/// `Start ReadsArms, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<Text>, bool>> start_reads_arms_f(Array<crate::lower::model::XArm> arms_p0, bool into_p1, std::tuple<Array<Text>, bool> acc_p2) {
    return prism_rtl::make_rc<ReadsArms>(arms_p0, into_p1, acc_p2);
}


/// ReadsCond: unbounded fn Cc, Bool, (([Text], Bool)) -> (([Text], Bool))
std::tuple<Array<Text>, bool> reads_cond_f(const crate::lower::model::Cc& cc0, const bool& into_p1, const std::tuple<Array<Text>, bool>& acc_p2) {
    if (prism_rtl::is<crate::lower::model::Cc::CcLet>(cc0)) {
        auto&& x_p0 = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc0).a1;
        return reads_of_f(x_p0, into_p1, acc_p2);
    }
    if (prism_rtl::is<crate::lower::model::Cc::CcIf>(cc0)) {
        auto&& x_p3 = prism_rtl::as<crate::lower::model::Cc::CcIf>(cc0).a0;
        return reads_of_f(x_p3, into_p1, acc_p2);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<Array<Text>, bool>> ReadsCond::cycle() const {
    const auto& cc0 = this->cc0;
    const auto& into_p1 = this->into_p1;
    const auto& acc_p2 = this->acc_p2;
    return ({
        prism_rtl::is<crate::lower::model::Cc::CcLet>(cc0) ? ({
        auto&& x_p0 = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc0).a1;
        prism_rtl::more(prism_rtl::rc(ReadsOf(x_p0, prism_rtl::deref(into_p1), acc_p2)));
    })
        : prism_rtl::is<crate::lower::model::Cc::CcIf>(cc0) ? ({
        auto&& x_p3 = prism_rtl::as<crate::lower::model::Cc::CcIf>(cc0).a0;
        prism_rtl::more(prism_rtl::rc(ReadsOf(x_p3, prism_rtl::deref(into_p1), acc_p2)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ReadsCond, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<Text>, bool>> start_reads_cond_f(crate::lower::model::Cc cc0, bool into_p1, std::tuple<Array<Text>, bool> acc_p2) {
    return prism_rtl::make_rc<ReadsCond>(cc0, into_p1, acc_p2);
}


/// ReadsDos: unbounded fn [Do], Bool, (([Text], Bool)) -> (([Text], Bool))
std::tuple<Array<Text>, bool> reads_dos_f(const Array<crate::lower::model::Do>& dos_p0, const bool& into_p1, const std::tuple<Array<Text>, bool>& acc_p2) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(dos_p0, acc_p2, ({
        auto into_p1x = into_p1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, bool>>(std::tuple<std::tuple<Array<Text>, bool>, crate::lower::model::Do>)>>(prism_rtl::rc([=, into_p1x = std::move(into_p1x)](std::tuple<std::tuple<Array<Text>, bool>, crate::lower::model::Do> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto into_p1xy = into_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, into_p1xy = std::move(into_p1xy)]() {
            return ({
                auto a_p3 = p0;
                auto d_p4 = p1;
                ({
                prism_rtl::is<crate::lower::model::Do::DoLet>(d_p4) ? ({
                auto&& x_p5 = prism_rtl::as<crate::lower::model::Do::DoLet>(d_p4).a1;
                prism_rtl::more(prism_rtl::rc(ReadsOf(x_p5, into_p1xy, a_p3)));
            })
                : prism_rtl::is<crate::lower::model::Do::DoLetElse>(d_p4) ? ({
                auto&& x_p6 = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d_p4).a1;
                auto&& e_p7 = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d_p4).a2;
                prism_rtl::more(prism_rtl::rc(ReadsEach(Array(std::vector{x_p6, e_p7}), into_p1xy, a_p3)));
            })
                : prism_rtl::is<crate::lower::model::Do::DoAssign>(d_p4) ? ({
                auto&& p_p8 = prism_rtl::as<crate::lower::model::Do::DoAssign>(d_p4).a0;
                auto&& x_p9 = prism_rtl::as<crate::lower::model::Do::DoAssign>(d_p4).a1;
                prism_rtl::more(prism_rtl::rc(ReadsEach(Array(std::vector{p_p8, x_p9}), into_p1xy, a_p3)));
            })
                : prism_rtl::is<crate::lower::model::Do::DoWhile>(d_p4) ? ({
                auto&& c_pa = prism_rtl::as<crate::lower::model::Do::DoWhile>(d_p4).a0;
                auto&& body_pb = prism_rtl::as<crate::lower::model::Do::DoWhile>(d_p4).a1;
                ({
                auto body_pbx = body_pb;
                auto c_pax = c_pa;
                (crate::prelude::call_then(start_reads_of_f(c_pax, into_p1xy, a_p3), [=, body_pbx = std::move(body_pbx)](std::tuple<Array<Text>, bool> reads_of_f_27638) { return prism_rtl::more(prism_rtl::rc(ReadsDos(body_pbx, into_p1xy, reads_of_f_27638))); }));
            });
            })
                : prism_rtl::is<crate::lower::model::Do::DoWhileLet>(d_p4) ? ({
                auto&& x_pc = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d_p4).a1;
                auto&& body_pd = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d_p4).a2;
                ({
                auto body_pdx = body_pd;
                auto x_pcx = x_pc;
                (crate::prelude::call_then(start_reads_of_f(x_pcx, into_p1xy, a_p3), [=, body_pdx = std::move(body_pdx)](std::tuple<Array<Text>, bool> reads_of_f_27712) { return prism_rtl::more(prism_rtl::rc(ReadsDos(body_pdx, into_p1xy, reads_of_f_27712))); }));
            });
            })
                : prism_rtl::is<crate::lower::model::Do::DoFor>(d_p4) ? ({
                auto&& x_pe = prism_rtl::as<crate::lower::model::Do::DoFor>(d_p4).a1;
                auto&& body_pf = prism_rtl::as<crate::lower::model::Do::DoFor>(d_p4).a2;
                ({
                auto body_pfx = body_pf;
                auto x_pex = x_pe;
                (crate::prelude::call_then(start_reads_of_f(x_pex, into_p1xy, a_p3), [=, body_pfx = std::move(body_pfx)](std::tuple<Array<Text>, bool> reads_of_f_27781) { return prism_rtl::more(prism_rtl::rc(ReadsDos(body_pfx, into_p1xy, reads_of_f_27781))); }));
            });
            })
                : prism_rtl::is<crate::lower::model::Do::DoExpr>(d_p4) ? ({
                auto&& x_pg = prism_rtl::as<crate::lower::model::Do::DoExpr>(d_p4).a0;
                prism_rtl::more(prism_rtl::rc(ReadsOf(x_pg, into_p1xy, a_p3)));
            })
                : prism_rtl::is<crate::lower::model::Do::DoIf>(d_p4) ? ({
                auto&& c_ph = prism_rtl::as<crate::lower::model::Do::DoIf>(d_p4).a0;
                auto&& t_pi = prism_rtl::as<crate::lower::model::Do::DoIf>(d_p4).a1;
                auto&& e_pj = prism_rtl::as<crate::lower::model::Do::DoIf>(d_p4).a2;
                ({
                auto c_phx = c_ph;
                auto e_pjx = e_pj;
                auto t_pix = t_pi;
                (crate::prelude::call_then(start_reads_of_f(c_phx, into_p1xy, a_p3), [=, e_pjx = std::move(e_pjx), t_pix = std::move(t_pix)](std::tuple<Array<Text>, bool> reads_of_f_27890) { return crate::prelude::call_then(start_reads_dos_f(t_pix, into_p1xy, reads_of_f_27890), [=](std::tuple<Array<Text>, bool> reads_dos_f_27871) { return prism_rtl::more(prism_rtl::rc(ReadsDos(e_pjx, into_p1xy, reads_dos_f_27871))); }); }));
            });
            })
                : prism_rtl::is<crate::lower::model::Do::DoIfLet>(d_p4) ? ({
                auto&& x_pk = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d_p4).a1;
                auto&& t_pl = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d_p4).a2;
                auto&& e_pm = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d_p4).a3;
                ({
                auto e_pmx = e_pm;
                auto t_plx = t_pl;
                auto x_pkx = x_pk;
                (crate::prelude::call_then(start_reads_of_f(x_pkx, into_p1xy, a_p3), [=, e_pmx = std::move(e_pmx), t_plx = std::move(t_plx)](std::tuple<Array<Text>, bool> reads_of_f_27978) { return crate::prelude::call_then(start_reads_dos_f(t_plx, into_p1xy, reads_of_f_27978), [=](std::tuple<Array<Text>, bool> reads_dos_f_27959) { return prism_rtl::more(prism_rtl::rc(ReadsDos(e_pmx, into_p1xy, reads_dos_f_27959))); }); }));
            });
            })
                : prism_rtl::is<crate::lower::model::Do::DoMatch>(d_p4) ? ({
                auto&& x_pn = prism_rtl::as<crate::lower::model::Do::DoMatch>(d_p4).a0;
                auto&& cases_po = prism_rtl::as<crate::lower::model::Do::DoMatch>(d_p4).a1;
                ({
                auto cases_pox = cases_po;
                auto x_pnx = x_pn;
                (crate::prelude::call_then(start_reads_of_f(x_pnx, into_p1xy, a_p3), [=, cases_pox = std::move(cases_pox)](std::tuple<Array<Text>, bool> reads_of_f_28034) {
                return crate::prelude::fold_job(cases_pox, reads_of_f_28034, ({
                    auto into_p1xyx = into_p1xy;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, bool>>(std::tuple<std::tuple<Array<Text>, bool>, std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>>>)>>(prism_rtl::rc([=, into_p1xyx = std::move(into_p1xyx)](std::tuple<std::tuple<Array<Text>, bool>, std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>>> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto into_p1xyxy = into_p1xyx;
                        (crate::prelude::entered(crate::prelude::once_job([=, into_p1xyxy = std::move(into_p1xyxy)]() {
                        return ({
                            auto a2_pp = p0;
                            auto&& _body_pq = p1;
                            auto&& body_pq = std::get<1>(_body_pq);
                            (prism_rtl::more(prism_rtl::rc(ReadsDos(body_pq, into_p1xyxy, a2_pp))));
                        });
                    })));
                    });
                }));
                }))->cycle();
            }));
            });
            })
                : prism_rtl::is<crate::lower::model::Do::DoReturn>(d_p4) ? ({
                auto&& x_pr = prism_rtl::as<crate::lower::model::Do::DoReturn>(d_p4).a0;
                prism_rtl::more(prism_rtl::rc(ReadsOf(x_pr, into_p1xy, a_p3)));
            })
                : prism_rtl::is<crate::lower::model::Do::DoBlock>(d_p4) ? ({
                auto&& body_ps = prism_rtl::as<crate::lower::model::Do::DoBlock>(d_p4).a0;
                prism_rtl::more(prism_rtl::rc(ReadsDos(body_ps, into_p1xy, a_p3)));
            })
                : prism_rtl::is<crate::lower::model::Do::DoScope>(d_p4) ? ({
                auto&& body_pt = prism_rtl::as<crate::lower::model::Do::DoScope>(d_p4).a0;
                prism_rtl::more(prism_rtl::rc(ReadsDos(body_pt, into_p1xy, a_p3)));
            })
                : prism_rtl::is<crate::lower::model::Do::DoLine>(d_p4) ? ({
                auto&& body_pu = prism_rtl::as<crate::lower::model::Do::DoLine>(d_p4).a0;
                prism_rtl::more(prism_rtl::rc(ReadsDos(body_pu, into_p1xy, a_p3)));
            })
                : prism_rtl::is<crate::lower::model::Do::DoNote>(d_p4) ? prism_rtl::finished(a_p3)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        })));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Array<Text>, bool>> ReadsDos::cycle() const {
    const auto& dos_p0 = this->dos_p0;
    const auto& into_p1 = this->into_p1;
    const auto& acc_p2 = this->acc_p2;
    return crate::prelude::fold_job(dos_p0, acc_p2, ({
        auto into_p1x = prism_rtl::deref(into_p1);
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, bool>>(std::tuple<std::tuple<Array<Text>, bool>, crate::lower::model::Do>)>>(prism_rtl::rc([=, into_p1x = std::move(into_p1x)](std::tuple<std::tuple<Array<Text>, bool>, crate::lower::model::Do> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto into_p1xy = into_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, into_p1xy = std::move(into_p1xy)]() {
            return ({
                auto a_p3 = p0;
                auto d_p4 = p1;
                ({
                prism_rtl::is<crate::lower::model::Do::DoLet>(d_p4) ? ({
                auto&& x_p5 = prism_rtl::as<crate::lower::model::Do::DoLet>(d_p4).a1;
                prism_rtl::more(prism_rtl::rc(ReadsOf(x_p5, into_p1xy, a_p3)));
            })
                : prism_rtl::is<crate::lower::model::Do::DoLetElse>(d_p4) ? ({
                auto&& x_p6 = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d_p4).a1;
                auto&& e_p7 = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d_p4).a2;
                prism_rtl::more(prism_rtl::rc(ReadsEach(Array(std::vector{x_p6, e_p7}), into_p1xy, a_p3)));
            })
                : prism_rtl::is<crate::lower::model::Do::DoAssign>(d_p4) ? ({
                auto&& p_p8 = prism_rtl::as<crate::lower::model::Do::DoAssign>(d_p4).a0;
                auto&& x_p9 = prism_rtl::as<crate::lower::model::Do::DoAssign>(d_p4).a1;
                prism_rtl::more(prism_rtl::rc(ReadsEach(Array(std::vector{p_p8, x_p9}), into_p1xy, a_p3)));
            })
                : prism_rtl::is<crate::lower::model::Do::DoWhile>(d_p4) ? ({
                auto&& c_pa = prism_rtl::as<crate::lower::model::Do::DoWhile>(d_p4).a0;
                auto&& body_pb = prism_rtl::as<crate::lower::model::Do::DoWhile>(d_p4).a1;
                ({
                auto body_pbx = body_pb;
                auto c_pax = c_pa;
                (crate::prelude::call_then(start_reads_of_f(c_pax, into_p1xy, a_p3), [=, body_pbx = std::move(body_pbx)](std::tuple<Array<Text>, bool> reads_of_f_27638) { return prism_rtl::more(prism_rtl::rc(ReadsDos(body_pbx, into_p1xy, reads_of_f_27638))); }));
            });
            })
                : prism_rtl::is<crate::lower::model::Do::DoWhileLet>(d_p4) ? ({
                auto&& x_pc = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d_p4).a1;
                auto&& body_pd = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d_p4).a2;
                ({
                auto body_pdx = body_pd;
                auto x_pcx = x_pc;
                (crate::prelude::call_then(start_reads_of_f(x_pcx, into_p1xy, a_p3), [=, body_pdx = std::move(body_pdx)](std::tuple<Array<Text>, bool> reads_of_f_27712) { return prism_rtl::more(prism_rtl::rc(ReadsDos(body_pdx, into_p1xy, reads_of_f_27712))); }));
            });
            })
                : prism_rtl::is<crate::lower::model::Do::DoFor>(d_p4) ? ({
                auto&& x_pe = prism_rtl::as<crate::lower::model::Do::DoFor>(d_p4).a1;
                auto&& body_pf = prism_rtl::as<crate::lower::model::Do::DoFor>(d_p4).a2;
                ({
                auto body_pfx = body_pf;
                auto x_pex = x_pe;
                (crate::prelude::call_then(start_reads_of_f(x_pex, into_p1xy, a_p3), [=, body_pfx = std::move(body_pfx)](std::tuple<Array<Text>, bool> reads_of_f_27781) { return prism_rtl::more(prism_rtl::rc(ReadsDos(body_pfx, into_p1xy, reads_of_f_27781))); }));
            });
            })
                : prism_rtl::is<crate::lower::model::Do::DoExpr>(d_p4) ? ({
                auto&& x_pg = prism_rtl::as<crate::lower::model::Do::DoExpr>(d_p4).a0;
                prism_rtl::more(prism_rtl::rc(ReadsOf(x_pg, into_p1xy, a_p3)));
            })
                : prism_rtl::is<crate::lower::model::Do::DoIf>(d_p4) ? ({
                auto&& c_ph = prism_rtl::as<crate::lower::model::Do::DoIf>(d_p4).a0;
                auto&& t_pi = prism_rtl::as<crate::lower::model::Do::DoIf>(d_p4).a1;
                auto&& e_pj = prism_rtl::as<crate::lower::model::Do::DoIf>(d_p4).a2;
                ({
                auto c_phx = c_ph;
                auto e_pjx = e_pj;
                auto t_pix = t_pi;
                (crate::prelude::call_then(start_reads_of_f(c_phx, into_p1xy, a_p3), [=, e_pjx = std::move(e_pjx), t_pix = std::move(t_pix)](std::tuple<Array<Text>, bool> reads_of_f_27890) { return crate::prelude::call_then(start_reads_dos_f(t_pix, into_p1xy, reads_of_f_27890), [=](std::tuple<Array<Text>, bool> reads_dos_f_27871) { return prism_rtl::more(prism_rtl::rc(ReadsDos(e_pjx, into_p1xy, reads_dos_f_27871))); }); }));
            });
            })
                : prism_rtl::is<crate::lower::model::Do::DoIfLet>(d_p4) ? ({
                auto&& x_pk = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d_p4).a1;
                auto&& t_pl = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d_p4).a2;
                auto&& e_pm = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d_p4).a3;
                ({
                auto e_pmx = e_pm;
                auto t_plx = t_pl;
                auto x_pkx = x_pk;
                (crate::prelude::call_then(start_reads_of_f(x_pkx, into_p1xy, a_p3), [=, e_pmx = std::move(e_pmx), t_plx = std::move(t_plx)](std::tuple<Array<Text>, bool> reads_of_f_27978) { return crate::prelude::call_then(start_reads_dos_f(t_plx, into_p1xy, reads_of_f_27978), [=](std::tuple<Array<Text>, bool> reads_dos_f_27959) { return prism_rtl::more(prism_rtl::rc(ReadsDos(e_pmx, into_p1xy, reads_dos_f_27959))); }); }));
            });
            })
                : prism_rtl::is<crate::lower::model::Do::DoMatch>(d_p4) ? ({
                auto&& x_pn = prism_rtl::as<crate::lower::model::Do::DoMatch>(d_p4).a0;
                auto&& cases_po = prism_rtl::as<crate::lower::model::Do::DoMatch>(d_p4).a1;
                ({
                auto cases_pox = cases_po;
                auto x_pnx = x_pn;
                (crate::prelude::call_then(start_reads_of_f(x_pnx, into_p1xy, a_p3), [=, cases_pox = std::move(cases_pox)](std::tuple<Array<Text>, bool> reads_of_f_28034) {
                return crate::prelude::fold_job(cases_pox, reads_of_f_28034, ({
                    auto into_p1xyx = into_p1xy;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, bool>>(std::tuple<std::tuple<Array<Text>, bool>, std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>>>)>>(prism_rtl::rc([=, into_p1xyx = std::move(into_p1xyx)](std::tuple<std::tuple<Array<Text>, bool>, std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>>> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto into_p1xyxy = into_p1xyx;
                        (crate::prelude::entered(crate::prelude::once_job([=, into_p1xyxy = std::move(into_p1xyxy)]() {
                        return ({
                            auto a2_pp = p0;
                            auto&& _body_pq = p1;
                            auto&& body_pq = std::get<1>(_body_pq);
                            (prism_rtl::more(prism_rtl::rc(ReadsDos(body_pq, into_p1xyxy, a2_pp))));
                        });
                    })));
                    });
                }));
                }))->cycle();
            }));
            });
            })
                : prism_rtl::is<crate::lower::model::Do::DoReturn>(d_p4) ? ({
                auto&& x_pr = prism_rtl::as<crate::lower::model::Do::DoReturn>(d_p4).a0;
                prism_rtl::more(prism_rtl::rc(ReadsOf(x_pr, into_p1xy, a_p3)));
            })
                : prism_rtl::is<crate::lower::model::Do::DoBlock>(d_p4) ? ({
                auto&& body_ps = prism_rtl::as<crate::lower::model::Do::DoBlock>(d_p4).a0;
                prism_rtl::more(prism_rtl::rc(ReadsDos(body_ps, into_p1xy, a_p3)));
            })
                : prism_rtl::is<crate::lower::model::Do::DoScope>(d_p4) ? ({
                auto&& body_pt = prism_rtl::as<crate::lower::model::Do::DoScope>(d_p4).a0;
                prism_rtl::more(prism_rtl::rc(ReadsDos(body_pt, into_p1xy, a_p3)));
            })
                : prism_rtl::is<crate::lower::model::Do::DoLine>(d_p4) ? ({
                auto&& body_pu = prism_rtl::as<crate::lower::model::Do::DoLine>(d_p4).a0;
                prism_rtl::more(prism_rtl::rc(ReadsDos(body_pu, into_p1xy, a_p3)));
            })
                : prism_rtl::is<crate::lower::model::Do::DoNote>(d_p4) ? prism_rtl::finished(a_p3)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        })));
        });
    }));
    }))->cycle();
}


/// `Start ReadsDos, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<Text>, bool>> start_reads_dos_f(Array<crate::lower::model::Do> dos_p0, bool into_p1, std::tuple<Array<Text>, bool> acc_p2) {
    return prism_rtl::make_rc<ReadsDos>(dos_p0, into_p1, acc_p2);
}


/// IsCtor: fn Ex, Text -> Bool
bool is_ctor_f(const crate::lower::model::Ex& ex0, const Text& c_p1) {
    if (prism_rtl::is<crate::lower::model::Ex::XCtor>(ex0)) {
        auto&& p_p0 = prism_rtl::as<crate::lower::model::Ex::XCtor>(ex0).a0;
        return p_p0 == c_p1;
    }
    {
        auto&& x_p2 = ex0;
        return false;
    }
}


/// ?ErrOf: fn Ex -> ?Ex
std::optional<crate::lower::model::Ex> err_of_o(const crate::lower::model::Ex& x_p0) {
    if (prism_rtl::is<crate::lower::model::Ex::XCtor>(x_p0)) {
        auto&& m28478_0_0 = prism_rtl::as<crate::lower::model::Ex::XCtor>(x_p0).a0;
        auto&& m28478_0_1 = prism_rtl::as<crate::lower::model::Ex::XCtor>(x_p0).a1;
        if (m28478_0_0 == Text::lit("Err")) {
            if (m28478_0_1.size() == 1u) {
                {
                    auto&& _c1 = crate::prelude::index(m28478_0_1, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& y_p1 = prism_rtl::some_of(_c1);
                        return std::optional(y_p1);
                    }
                }
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBlock>(x_p0)) {
        auto&& tail_p2 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a1;
        return err_of_o(prism_rtl::deref(prism_rtl::deref(tail_p2)));
    }
    {
        return std::optional<crate::lower::model::Ex>{};
    }
}


/// OkBranch: unbounded fn Cp, Ex, Ex -> Text
Text ok_branch_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Ex& x_p1, const crate::lower::model::Ex& y_p2) {
    if (prism_rtl::is<crate::lower::model::Ex::XCtor>(x_p1)) {
        auto&& m28781_0_0 = prism_rtl::as<crate::lower::model::Ex::XCtor>(x_p1).a0;
        auto&& m28781_0_1 = prism_rtl::as<crate::lower::model::Ex::XCtor>(x_p1).a1;
        if (m28781_0_0 == Text::lit("Ok")) {
            if (m28781_0_1.size() == 1u) {
                {
                    auto&& _c1 = crate::prelude::index(m28781_0_1, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& v_p3 = prism_rtl::some_of(_c1);
                        return prism_rtl::cat("Expected<std::decay_t<decltype(", cpp_expr_f(cp_p0, v_p3), ")>, std::decay_t<decltype(", cpp_expr_f(cp_p0, y_p2), ")>>(", cpp_expr_f(cp_p0, v_p3), ")");
                    }
                }
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBlock>(x_p1)) {
        auto&& dos_p4 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p1).a0;
        auto&& m28781_1_1 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p1).a1;
        if (prism_rtl::is<crate::lower::model::Ex::XCtor>(prism_rtl::deref(prism_rtl::deref(m28781_1_1)))) {
            auto&& m28781_1_1_r_0 = prism_rtl::as<crate::lower::model::Ex::XCtor>(prism_rtl::deref(prism_rtl::deref(m28781_1_1))).a0;
            auto&& m28781_1_1_r_1 = prism_rtl::as<crate::lower::model::Ex::XCtor>(prism_rtl::deref(prism_rtl::deref(m28781_1_1))).a1;
            if (m28781_1_1_r_0 == Text::lit("Ok")) {
                if (m28781_1_1_r_1.size() == 1u) {
                    {
                        auto&& _c1 = crate::prelude::index(m28781_1_1_r_1, Nat(0u));
                        if (prism_rtl::is_some(_c1)) {
                            auto&& v_p5 = prism_rtl::some_of(_c1);
                            auto [st_p6, cp2_p7] = crate::emit::cpp::stmts::cpp_statements_cp_f(cp_p0, dos_p4);
                            return crate::emit::cpp::templates::items::stmt_expr_f(st_p6, prism_rtl::cat("Expected<std::decay_t<decltype(", cpp_expr_f(cp2_p7, v_p5), ")>, std::decay_t<decltype(", cpp_expr_f(cp2_p7, y_p2), ")>>(", cpp_expr_f(cp2_p7, v_p5), ")"));
                        }
                    }
                }
            }
        }
    }
    {
        return cpp_expr_f(cp_p0, x_p1);
    }
}


prism_rtl::Turn<Text> OkBranch::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& x_p1 = this->x_p1;
    const auto& y_p2 = this->y_p2;
    return ({
        prism_rtl::is<crate::lower::model::Ex::XCtor>(x_p1) && ({
        auto&& m28781_0_0 = prism_rtl::as<crate::lower::model::Ex::XCtor>(x_p1).a0;
        auto&& m28781_0_1 = prism_rtl::as<crate::lower::model::Ex::XCtor>(x_p1).a1;
        (m28781_0_0 == Text::lit("Ok")) && (m28781_0_1.size() == 1u) && ({
        auto&& _c1 = crate::prelude::index(m28781_0_1, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m28781_0_0 = prism_rtl::as<crate::lower::model::Ex::XCtor>(x_p1).a0;
        auto&& m28781_0_1 = prism_rtl::as<crate::lower::model::Ex::XCtor>(x_p1).a1;
        auto&& _c1 = crate::prelude::index(m28781_0_1, Nat(0u));
        auto&& v_p3 = prism_rtl::some_of(_c1);
        ({
        auto cp_p0x = cp_p0;
        auto y_p2x = y_p2;
        (crate::prelude::call_then(start_cpp_expr_f(cp_p0x, v_p3), [=, y_p2x = std::move(y_p2x)](Text cpp_expr_f_28846) { return crate::prelude::call_then(start_cpp_expr_f(cp_p0x, y_p2x), [=](Text cpp_expr_f_28887) { return crate::prelude::call_then(start_cpp_expr_f(cp_p0x, v_p3), [=](Text cpp_expr_f_28906) { return prism_rtl::finished(prism_rtl::cat("Expected<std::decay_t<decltype(", cpp_expr_f_28846, ")>, std::decay_t<decltype(", cpp_expr_f_28887, ")>>(", cpp_expr_f_28906, ")")); }); }); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XBlock>(x_p1) && ({
        auto&& dos_p4 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p1).a0;
        auto&& m28781_1_1 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p1).a1;
        prism_rtl::is<crate::lower::model::Ex::XCtor>(prism_rtl::deref(prism_rtl::deref(m28781_1_1))) && ({
        auto&& m28781_1_1_r_0 = prism_rtl::as<crate::lower::model::Ex::XCtor>(prism_rtl::deref(prism_rtl::deref(m28781_1_1))).a0;
        auto&& m28781_1_1_r_1 = prism_rtl::as<crate::lower::model::Ex::XCtor>(prism_rtl::deref(prism_rtl::deref(m28781_1_1))).a1;
        (m28781_1_1_r_0 == Text::lit("Ok")) && (m28781_1_1_r_1.size() == 1u) && ({
        auto&& _c1 = crate::prelude::index(m28781_1_1_r_1, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    });
    }) ? ({
        auto&& dos_p4 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p1).a0;
        auto&& m28781_1_1 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p1).a1;
        auto&& m28781_1_1_r_0 = prism_rtl::as<crate::lower::model::Ex::XCtor>(prism_rtl::deref(prism_rtl::deref(m28781_1_1))).a0;
        auto&& m28781_1_1_r_1 = prism_rtl::as<crate::lower::model::Ex::XCtor>(prism_rtl::deref(prism_rtl::deref(m28781_1_1))).a1;
        auto&& _c1 = crate::prelude::index(m28781_1_1_r_1, Nat(0u));
        auto&& v_p5 = prism_rtl::some_of(_c1);
        ({
        auto cp_p0x = cp_p0;
        auto dos_p4x = dos_p4;
        auto y_p2x = y_p2;
        (crate::prelude::call_then(crate::emit::cpp::stmts::start_cpp_statements_cp_f(cp_p0x, dos_p4x), [=, y_p2x = std::move(y_p2x)](std::tuple<Text, crate::emit::cpp::Cp> cpp_statements_cp_f_28986) {
        return ({
            auto [st_p6, cp2_p7] = cpp_statements_cp_f_28986;
            (crate::prelude::call_then(start_cpp_expr_f(cp2_p7, v_p5), [=](Text cpp_expr_f_29064) { return crate::prelude::call_then(start_cpp_expr_f(cp2_p7, y_p2x), [=](Text cpp_expr_f_29106) { return crate::prelude::call_then(start_cpp_expr_f(cp2_p7, v_p5), [=](Text cpp_expr_f_29126) { return prism_rtl::finished(crate::emit::cpp::templates::items::stmt_expr_f(st_p6, prism_rtl::cat("Expected<std::decay_t<decltype(", cpp_expr_f_29064, ")>, std::decay_t<decltype(", cpp_expr_f_29106, ")>>(", cpp_expr_f_29126, ")"))); }); }); }));
        });
    }));
    });
    })
        : prism_rtl::more(prism_rtl::rc(CppExpr(cp_p0, x_p1)));
    });
}


/// `Start OkBranch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_ok_branch_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex x_p1, crate::lower::model::Ex y_p2) {
    return prism_rtl::make_rc<OkBranch>(cp_p0, x_p1, y_p2);
}


/// CppClosure: unbounded fn Cp, Bool, [Pa], Ex -> Text
Text cpp_closure_f(const crate::emit::cpp::Cp& cp0_p0, const bool& mv_p1, const Array<crate::lower::model::Pa>& ps_p2, const crate::lower::model::Ex& body_p3) {
    auto names_p4 = crate::emit::cpp::patterns::concat2_f(crate::prelude::run_to_end(crate::prelude::each_job(ps_p2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto p_pb = p0;
                (prism_rtl::more(prism_rtl::rc(crate::emit::cpp::stmts::PatNames(p_pb))));
            });
        }));
    })))));
    auto cp_p5 = crate::prelude::fold(ps_p2, crate::emit::cpp::stmts::unbind_f(crate::emit::cpp::stmts::captured_f(cp0_p0), names_p4), [&](const crate::emit::cpp::Cp& c_pc, const crate::lower::model::Pa& p_pd) {
        return ({
            __label__ _done;
            prism_rtl::Slot<crate::emit::cpp::Cp> _v;
            if (prism_rtl::is<crate::lower::model::Pa::PaMut>(p_pd)) {
                auto&& n_pe = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_pd).a0;
                _v.set(crate::emit::cpp::stmts::owning_f(c_pc, n_pe));
                goto _done;
            }
            if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_pd)) {
                auto&& m29763_1_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_pd).a0;
                if (prism_rtl::is<crate::lower::model::Pa::PaMut>(prism_rtl::deref(prism_rtl::deref(m29763_1_0)))) {
                    auto&& n_pf = prism_rtl::as<crate::lower::model::Pa::PaMut>(prism_rtl::deref(prism_rtl::deref(m29763_1_0))).a0;
                    _v.set(crate::emit::cpp::stmts::owning_f(c_pc, n_pf));
                    goto _done;
                }
            }
            {
                _v.set(c_pc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto params_p6 = crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(ps_p2)), ({
        auto cp_p5x = cp_p5;
        auto ps_p2x = ps_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=, cp_p5x = std::move(cp_p5x), ps_p2x = std::move(ps_p2x)](Nat p0) {
        return ({
            auto cp_p5xy = cp_p5x;
            auto ps_p2xy = ps_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p5xy = std::move(cp_p5xy), ps_p2xy = std::move(ps_p2xy)]() {
            return ({
                auto i_pg = p0;
                (prism_rtl::more(prism_rtl::rc(ClosureParam(cp_p5xy, crate::prelude::or_(crate::prelude::index(ps_p2xy, i_pg), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), i_pg))));
            });
        })));
        });
    })));
    }))), Text::lit(", "));
    auto binds_p7 = crate::prelude::concat(crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(ps_p2)), ({
        auto cp_p5x = cp_p5;
        auto ps_p2x = ps_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=, cp_p5x = std::move(cp_p5x), ps_p2x = std::move(ps_p2x)](Nat p0) {
        return ({
            auto cp_p5xy = cp_p5x;
            auto ps_p2xy = ps_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p5xy = std::move(cp_p5xy), ps_p2xy = std::move(ps_p2xy)]() {
            return ({
                auto i_ph = p0;
                (prism_rtl::more(prism_rtl::rc(ClosureBinds(cp_p5xy, crate::prelude::or_(crate::prelude::index(ps_p2xy, i_ph), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), i_ph))));
            });
        })));
        });
    })));
    }))));
    auto b_p8 = cpp_expr_f(cp_p5, body_p3);
    auto moved_p9 = mv_p1
        ? crate::prelude::run_to_end(crate::prelude::filter_job(cp0_p0.move_captures_p, ({
        auto cp0_p0x = cp0_p0;
        auto names_p4x = names_p4;
        auto body_p3x = body_p3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, cp0_p0x = std::move(cp0_p0x), names_p4x = std::move(names_p4x), body_p3x = std::move(body_p3x)](Text p0) {
        return ({
            auto cp0_p0xy = cp0_p0x;
            auto names_p4xy = names_p4x;
            auto body_p3xy = body_p3x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp0_p0xy = std::move(cp0_p0xy), names_p4xy = std::move(names_p4xy), body_p3xy = std::move(body_p3xy)]() {
            return ({
                auto n_pi = p0;
                (prism_rtl::finished((crate::prelude::or_(crate::prelude::get(prism_rtl::deref(cp0_p0xy).owned_p, n_pi), false) && (!crate::emit::cpp::in_list_f(names_p4xy, n_pi))) && crate::lower::model::ex_reads_f(body_p3xy, n_pi)));
            });
        })));
        });
    })));
    })))
        : Array<Text>{};
    auto capture_pa = crate::syntax::lexer::chars::join_f(crate::prelude::append(Array(std::vector{mv_p1 ? Text::lit("=") : Text::lit("&")}), crate::prelude::each(moved_p9, [&](const Text& n_pj) { return prism_rtl::cat(crate::emit::cpp::stmts::var_name_f(cp0_p0, n_pj), " = std::move(", crate::emit::cpp::stmts::var_name_f(cp0_p0, n_pj), ")"); })), Text::lit(", "));
    auto [ret_pk, value_pl] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Text, Text>> _v;
        if (prism_rtl::is<crate::lower::model::Ex::XRef>(body_p3)) {
            _v.set(std::tuple{Text::lit(" -> decltype(auto)"), prism_rtl::cat("(", b_p8, ")")});
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::Ex::XRefMut>(body_p3)) {
            _v.set(std::tuple{Text::lit(" -> decltype(auto)"), prism_rtl::cat("(", b_p8, ")")});
            goto _done;
        }
        {
            _v.set(std::tuple{Text::lit(""), b_p8});
            goto _done;
        }
    _done:
        _v.take();
    });
    return (binds_p7 == Text::lit("")) && (!crate::syntax::lexer::chars::contains_f(b_p8, Text::lit("\n")))
        ? prism_rtl::cat("[", capture_pa, "](", params_p6, ")", ret_pk, " { return ", value_pl, "; }")
        : crate::emit::cpp::templates::items::lambda_f(capture_pa, prism_rtl::cat(params_p6, ")", ret_pk), prism_rtl::cat(binds_p7, "return ", value_pl, ";"));
}


prism_rtl::Turn<Text> CppClosure::cycle() const {
    const auto& cp0_p0 = this->cp0_p0;
    const auto& mv_p1 = this->mv_p1;
    const auto& ps_p2 = this->ps_p2;
    const auto& body_p3 = this->body_p3;
    auto body_p3x = body_p3;
    auto cp0_p0x = cp0_p0;
    auto mv_p1x = prism_rtl::deref(mv_p1);
    auto ps_p2x = ps_p2;
    return crate::prelude::call_value(crate::prelude::each_job(ps_p2x, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto p_pb = p0;
                (prism_rtl::more(prism_rtl::rc(crate::emit::cpp::stmts::PatNames(p_pb))));
            });
        }));
    }))), [=](Array<Array<Text>> each_29675) {
        return ({
            auto names_p4 = crate::emit::cpp::patterns::concat2_f(each_29675);
            auto cp_p5 = crate::prelude::fold(ps_p2x, crate::emit::cpp::stmts::unbind_f(crate::emit::cpp::stmts::captured_f(cp0_p0x), names_p4), [&](const crate::emit::cpp::Cp& c_pc, const crate::lower::model::Pa& p_pd) {
                return ({
                    __label__ _done;
                    prism_rtl::Slot<crate::emit::cpp::Cp> _v;
                    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(p_pd)) {
                        auto&& n_pe = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_pd).a0;
                        _v.set(crate::emit::cpp::stmts::owning_f(c_pc, n_pe));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_pd)) {
                        auto&& m29763_1_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_pd).a0;
                        if (prism_rtl::is<crate::lower::model::Pa::PaMut>(prism_rtl::deref(prism_rtl::deref(m29763_1_0)))) {
                            auto&& n_pf = prism_rtl::as<crate::lower::model::Pa::PaMut>(prism_rtl::deref(prism_rtl::deref(m29763_1_0))).a0;
                            _v.set(crate::emit::cpp::stmts::owning_f(c_pc, n_pf));
                            goto _done;
                        }
                    }
                    {
                        _v.set(c_pc);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            });
            (crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(ps_p2x)), ({
            auto cp_p5x = cp_p5;
            auto ps_p2xx = ps_p2x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=, cp_p5x = std::move(cp_p5x), ps_p2xx = std::move(ps_p2xx)](Nat p0) {
            return ({
                auto cp_p5xy = cp_p5x;
                auto ps_p2xxy = ps_p2xx;
                (crate::prelude::entered(crate::prelude::once_job([=, cp_p5xy = std::move(cp_p5xy), ps_p2xxy = std::move(ps_p2xxy)]() {
                return ({
                    auto i_pg = p0;
                    (prism_rtl::more(prism_rtl::rc(ClosureParam(cp_p5xy, crate::prelude::or_(crate::prelude::index(ps_p2xxy, i_pg), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), i_pg))));
                });
            })));
            });
        })));
        })), [=, names_p4 = std::move(names_p4)](Array<Text> each_29892) {
            return ({
                auto params_p6 = crate::syntax::lexer::chars::join_f(each_29892, Text::lit(", "));
                (crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(ps_p2x)), ({
                auto cp_p5x = cp_p5;
                auto ps_p2xx = ps_p2x;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=, cp_p5x = std::move(cp_p5x), ps_p2xx = std::move(ps_p2xx)](Nat p0) {
                return ({
                    auto cp_p5xy = cp_p5x;
                    auto ps_p2xxy = ps_p2xx;
                    (crate::prelude::entered(crate::prelude::once_job([=, cp_p5xy = std::move(cp_p5xy), ps_p2xxy = std::move(ps_p2xxy)]() {
                    return ({
                        auto i_ph = p0;
                        (prism_rtl::more(prism_rtl::rc(ClosureBinds(cp_p5xy, crate::prelude::or_(crate::prelude::index(ps_p2xxy, i_ph), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), i_ph))));
                    });
                })));
                });
            })));
            })), [=, params_p6 = std::move(params_p6)](Array<Text> each_29991) {
                return ({
                    auto binds_p7 = crate::prelude::concat(each_29991);
                    (crate::prelude::call_then(start_cpp_expr_f(cp_p5, body_p3x), [=, binds_p7 = std::move(binds_p7)](Text cpp_expr_f_30072) {
                    return ({
                        auto b_p8 = cpp_expr_f_30072;
                        auto moved_p9 = mv_p1x
                            ? crate::prelude::run_to_end(crate::prelude::filter_job(prism_rtl::deref(cp0_p0x).move_captures_p, ({
                            auto cp0_p0xx = cp0_p0x;
                            auto names_p4x = names_p4;
                            auto body_p3xx = body_p3x;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, cp0_p0xx = std::move(cp0_p0xx), names_p4x = std::move(names_p4x), body_p3xx = std::move(body_p3xx)](Text p0) {
                            return ({
                                auto cp0_p0xxy = cp0_p0xx;
                                auto names_p4xy = names_p4x;
                                auto body_p3xxy = body_p3xx;
                                (crate::prelude::entered(crate::prelude::once_job([=, cp0_p0xxy = std::move(cp0_p0xxy), names_p4xy = std::move(names_p4xy), body_p3xxy = std::move(body_p3xxy)]() {
                                return ({
                                    auto n_pi = p0;
                                    (prism_rtl::finished((crate::prelude::or_(crate::prelude::get(prism_rtl::deref(cp0_p0xxy).owned_p, n_pi), false) && (!crate::emit::cpp::in_list_f(names_p4xy, n_pi))) && crate::lower::model::ex_reads_f(body_p3xxy, n_pi)));
                                });
                            })));
                            });
                        })));
                        })))
                            : Array<Text>{};
                        auto capture_pa = crate::syntax::lexer::chars::join_f(crate::prelude::append(Array(std::vector{mv_p1x ? Text::lit("=") : Text::lit("&")}), crate::prelude::each(moved_p9, [&](const Text& n_pj) { return prism_rtl::cat(crate::emit::cpp::stmts::var_name_f(cp0_p0x, n_pj), " = std::move(", crate::emit::cpp::stmts::var_name_f(cp0_p0x, n_pj), ")"); })), Text::lit(", "));
                        auto [ret_pk, value_pl] = ({
                            __label__ _done;
                            prism_rtl::Slot<std::tuple<Text, Text>> _v;
                            if (prism_rtl::is<crate::lower::model::Ex::XRef>(body_p3x)) {
                                _v.set(std::tuple{Text::lit(" -> decltype(auto)"), prism_rtl::cat("(", b_p8, ")")});
                                goto _done;
                            }
                            if (prism_rtl::is<crate::lower::model::Ex::XRefMut>(body_p3x)) {
                                _v.set(std::tuple{Text::lit(" -> decltype(auto)"), prism_rtl::cat("(", b_p8, ")")});
                                goto _done;
                            }
                            {
                                _v.set(std::tuple{Text::lit(""), b_p8});
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                        (binds_p7 == Text::lit("")) && (!crate::syntax::lexer::chars::contains_f(b_p8, Text::lit("\n")))
                        ? prism_rtl::finished(prism_rtl::cat("[", capture_pa, "](", params_p6, ")", ret_pk, " { return ", value_pl, "; }"))
                        : prism_rtl::finished(crate::emit::cpp::templates::items::lambda_f(capture_pa, prism_rtl::cat(params_p6, ")", ret_pk), prism_rtl::cat(binds_p7, "return ", value_pl, ";")));
                    });
                }));
                });
            }));
            });
        }));
        });
    });
}


/// `Start CppClosure, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_closure_f(crate::emit::cpp::Cp cp0_p0, bool mv_p1, Array<crate::lower::model::Pa> ps_p2, crate::lower::model::Ex body_p3) {
    return prism_rtl::make_rc<CppClosure>(cp0_p0, mv_p1, ps_p2, body_p3);
}


/// ClosureParam: unbounded fn Cp, Pa, Nat -> Text
Text closure_param_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Pa& pa1, const Nat& i_p3) {
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(pa1)) {
        auto&& c0_1_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t_p2 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        if (prism_rtl::is<crate::lower::model::Pa::PaBind>(prism_rtl::deref(prism_rtl::deref(c0_1_0)))) {
            auto&& n_p1 = prism_rtl::as<crate::lower::model::Pa::PaBind>(prism_rtl::deref(prism_rtl::deref(c0_1_0))).a0;
            return prism_rtl::cat(param_type_f(cp_p0, t_p2), " ", crate::emit::cpp::cpp_id_f(n_p1));
        }
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(pa1)) {
        auto&& c1_1_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t_p6 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        if (prism_rtl::is<crate::lower::model::Pa::PaMut>(prism_rtl::deref(prism_rtl::deref(c1_1_0)))) {
            auto&& n_p5 = prism_rtl::as<crate::lower::model::Pa::PaMut>(prism_rtl::deref(prism_rtl::deref(c1_1_0))).a0;
            return prism_rtl::cat(crate::emit::cpp::cpp_type_f(cp_p0, unref_f(t_p6)), " ", crate::emit::cpp::cpp_id_f(n_p5));
        }
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(pa1)) {
        auto&& p_p9 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t_pa = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        return prism_rtl::cat(param_type_f(cp_p0, t_pa), " _p", i_p3);
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(pa1)) {
        auto&& n_pd = prism_rtl::as<crate::lower::model::Pa::PaBind>(pa1).a0;
        return prism_rtl::cat("auto&& ", crate::emit::cpp::cpp_id_f(n_pd));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(pa1)) {
        auto&& n_pg = prism_rtl::as<crate::lower::model::Pa::PaMut>(pa1).a0;
        return prism_rtl::cat("auto ", crate::emit::cpp::cpp_id_f(n_pg));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaWild>(pa1)) {
        return Text::lit("const auto&");
    }
    {
        auto&& p_pl = pa1;
        return prism_rtl::cat("const auto& _p", i_p3);
    }
}


prism_rtl::Turn<Text> ClosureParam::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& pa1 = this->pa1;
    const auto& i_p3 = this->i_p3;
    return ({
        prism_rtl::is<crate::lower::model::Pa::PaTyped>(pa1) && ({
        auto&& j0_1_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t_p2 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        prism_rtl::is<crate::lower::model::Pa::PaBind>(prism_rtl::deref(prism_rtl::deref(j0_1_0)));
    }) ? ({
        auto&& j0_1_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t_p2 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        auto&& n_p1 = prism_rtl::as<crate::lower::model::Pa::PaBind>(prism_rtl::deref(prism_rtl::deref(j0_1_0))).a0;
        ({
        auto cp_p0x = cp_p0;
        auto n_p1x = n_p1;
        auto t_p2x = t_p2;
        (crate::prelude::call_then(start_param_type_f(cp_p0x, t_p2x), [=, n_p1x = std::move(n_p1x)](Text param_type_f_30805) { return prism_rtl::finished(prism_rtl::cat(param_type_f_30805, " ", crate::emit::cpp::cpp_id_f(n_p1x))); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTyped>(pa1) && ({
        auto&& j1_1_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t_p6 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        prism_rtl::is<crate::lower::model::Pa::PaMut>(prism_rtl::deref(prism_rtl::deref(j1_1_0)));
    }) ? ({
        auto&& j1_1_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t_p6 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        auto&& n_p5 = prism_rtl::as<crate::lower::model::Pa::PaMut>(prism_rtl::deref(prism_rtl::deref(j1_1_0))).a0;
        ({
        auto cp_p0x = cp_p0;
        auto n_p5x = n_p5;
        auto t_p6x = t_p6;
        (crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x, unref_f(t_p6x)), [=, n_p5x = std::move(n_p5x)](Text cpp_type_f_30883) { return prism_rtl::finished(prism_rtl::cat(cpp_type_f_30883, " ", crate::emit::cpp::cpp_id_f(n_p5x))); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTyped>(pa1) ? ({
        auto&& p_p9 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t_pa = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        ({
        auto cp_p0x = cp_p0;
        auto i_p3x = i_p3;
        auto t_pax = t_pa;
        (crate::prelude::call_then(start_param_type_f(cp_p0x, t_pax), [=, i_p3x = std::move(i_p3x)](Text param_type_f_30959) { return prism_rtl::finished(prism_rtl::cat(param_type_f_30959, " _p", i_p3x)); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaBind>(pa1) ? ({
        auto&& n_pd = prism_rtl::as<crate::lower::model::Pa::PaBind>(pa1).a0;
        prism_rtl::finished(prism_rtl::cat("auto&& ", crate::emit::cpp::cpp_id_f(n_pd)));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaMut>(pa1) ? ({
        auto&& n_pg = prism_rtl::as<crate::lower::model::Pa::PaMut>(pa1).a0;
        prism_rtl::finished(prism_rtl::cat("auto ", crate::emit::cpp::cpp_id_f(n_pg)));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaWild>(pa1) ? prism_rtl::finished(Text::lit("const auto&"))
        : ({
        auto&& p_pl = pa1;
        prism_rtl::finished(prism_rtl::cat("const auto& _p", i_p3));
    });
    });
}


/// `Start ClosureParam, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_closure_param_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Pa pa1, Nat i_p3) {
    return prism_rtl::make_rc<ClosureParam>(cp_p0, pa1, i_p3);
}


/// ClosureBinds: unbounded fn Cp, Pa, Nat -> Text
Text closure_binds_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Pa& pa1, const Nat& i_p3) {
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(pa1)) {
        auto&& c0_1_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t_p2 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        if (prism_rtl::is<crate::lower::model::Pa::PaBind>(prism_rtl::deref(prism_rtl::deref(c0_1_0)))) {
            auto&& n_p1 = prism_rtl::as<crate::lower::model::Pa::PaBind>(prism_rtl::deref(prism_rtl::deref(c0_1_0))).a0;
            return Text::lit("");
        }
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(pa1)) {
        auto&& c1_1_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t_p6 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        if (prism_rtl::is<crate::lower::model::Pa::PaMut>(prism_rtl::deref(prism_rtl::deref(c1_1_0)))) {
            auto&& n_p5 = prism_rtl::as<crate::lower::model::Pa::PaMut>(prism_rtl::deref(prism_rtl::deref(c1_1_0))).a0;
            return Text::lit("");
        }
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(pa1)) {
        auto&& p_p9 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t_pa = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        return closure_binds_f(cp_p0, prism_rtl::deref(prism_rtl::deref(p_p9)), i_p3);
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(pa1)) {
        auto&& n_pd = prism_rtl::as<crate::lower::model::Pa::PaBind>(pa1).a0;
        return Text::lit("");
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(pa1)) {
        auto&& n_pg = prism_rtl::as<crate::lower::model::Pa::PaMut>(pa1).a0;
        return Text::lit("");
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaWild>(pa1)) {
        return Text::lit("");
    }
    {
        auto&& p_pl = pa1;
        return crate::prelude::concat(crate::prelude::each(crate::emit::cpp::patterns::pat_binds_f(cp_p0, p_pl, prism_rtl::cat("_p", i_p3)), [&](const Text& b_pn) { return prism_rtl::cat(b_pn, "\n"); }));
    }
}


prism_rtl::Turn<Text> ClosureBinds::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& pa1 = this->pa1;
    const auto& i_p3 = this->i_p3;
    return ({
        prism_rtl::is<crate::lower::model::Pa::PaTyped>(pa1) && ({
        auto&& j0_1_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t_p2 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        prism_rtl::is<crate::lower::model::Pa::PaBind>(prism_rtl::deref(prism_rtl::deref(j0_1_0)));
    }) ? ({
        auto&& j0_1_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t_p2 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        auto&& n_p1 = prism_rtl::as<crate::lower::model::Pa::PaBind>(prism_rtl::deref(prism_rtl::deref(j0_1_0))).a0;
        prism_rtl::finished(Text::lit(""));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTyped>(pa1) && ({
        auto&& j1_1_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t_p6 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        prism_rtl::is<crate::lower::model::Pa::PaMut>(prism_rtl::deref(prism_rtl::deref(j1_1_0)));
    }) ? ({
        auto&& j1_1_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t_p6 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        auto&& n_p5 = prism_rtl::as<crate::lower::model::Pa::PaMut>(prism_rtl::deref(prism_rtl::deref(j1_1_0))).a0;
        prism_rtl::finished(Text::lit(""));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTyped>(pa1) ? ({
        auto&& p_p9 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t_pa = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        prism_rtl::more(prism_rtl::rc(ClosureBinds(cp_p0, prism_rtl::deref(prism_rtl::deref(p_p9)), i_p3)));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaBind>(pa1) ? ({
        auto&& n_pd = prism_rtl::as<crate::lower::model::Pa::PaBind>(pa1).a0;
        prism_rtl::finished(Text::lit(""));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaMut>(pa1) ? ({
        auto&& n_pg = prism_rtl::as<crate::lower::model::Pa::PaMut>(pa1).a0;
        prism_rtl::finished(Text::lit(""));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaWild>(pa1) ? prism_rtl::finished(Text::lit(""))
        : ({
        auto&& p_pl = pa1;
        ({
        auto cp_p0x = cp_p0;
        auto i_p3x = i_p3;
        auto p_plx = p_pl;
        (crate::prelude::call_then(crate::emit::cpp::patterns::start_pat_binds_f(cp_p0x, p_plx, prism_rtl::cat("_p", i_p3x)), [=](Array<Text> pat_binds_f_31549) { return prism_rtl::finished(crate::prelude::concat(crate::prelude::each(pat_binds_f_31549, [&](const Text& b_pn) { return prism_rtl::cat(b_pn, "\n"); }))); }));
    });
    });
    });
}


/// `Start ClosureBinds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_closure_binds_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Pa pa1, Nat i_p3) {
    return prism_rtl::make_rc<ClosureBinds>(cp_p0, pa1, i_p3);
}


/// Unref: fn OutTy -> OutTy
crate::lower::model::OutTy unref_f(const crate::lower::model::OutTy& out_ty0) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutRef>(out_ty0)) {
        auto&& t_p0 = prism_rtl::as<crate::lower::model::OutTy::OutRef>(out_ty0).a0;
        return prism_rtl::deref(prism_rtl::deref(t_p0));
    }
    {
        auto&& t_p1 = out_ty0;
        return t_p1;
    }
}


/// ParamType: unbounded fn Cp, OutTy -> Text
Text param_type_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::OutTy& t_p1) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutRef>(t_p1)) {
        return crate::emit::cpp::cpp_type_f(cp_p0, t_p1);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutSlice>(t_p1)) {
        return crate::emit::cpp::cpp_type_f(cp_p0, t_p1);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutUnit>(t_p1)) {
        return Text::lit("Unit");
    }
    {
        return crate::emit::cpp::cpp_type_f(cp_p0, t_p1);
    }
}


prism_rtl::Turn<Text> ParamType::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& t_p1 = this->t_p1;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutRef>(t_p1) ? prism_rtl::more(prism_rtl::rc(crate::emit::cpp::CppType(cp_p0, t_p1)))
        : prism_rtl::is<crate::lower::model::OutTy::OutSlice>(t_p1) ? prism_rtl::more(prism_rtl::rc(crate::emit::cpp::CppType(cp_p0, t_p1)))
        : prism_rtl::is<crate::lower::model::OutTy::OutUnit>(t_p1) ? prism_rtl::finished(Text::lit("Unit"))
        : prism_rtl::more(prism_rtl::rc(crate::emit::cpp::CppType(cp_p0, t_p1)));
    });
}


/// `Start ParamType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_param_type_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::OutTy t_p1) {
    return prism_rtl::make_rc<ParamType>(cp_p0, t_p1);
}

}  // namespace crate::emit::cpp::expr
