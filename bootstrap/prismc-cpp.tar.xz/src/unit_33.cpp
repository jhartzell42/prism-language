// The module `Emit.Cpp.Program`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <emit/cpp/program/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Emit.Cpp.Program`, from `target/bootstrap/cpp-src/prismc/emit/cpp/program.prism`.
namespace crate::emit::cpp::program {

void Piece::show(Printer& p) const {
    p.record("Piece", {{"title", title}, {"prism", prism}, {"path", path_}, {"ns", ns}, {"needs", needs}, {"defs", defs}});
}

Pod Piece::to_pod() const {
    return Pod::record("Piece", {{"title", prism_rtl::to_pod(title)}, {"prism", prism_rtl::to_pod(prism)}, {"path", prism_rtl::to_pod(path_)}, {"ns", prism_rtl::to_pod(ns)}, {"needs", prism_rtl::to_pod(needs)}, {"defs", prism_rtl::to_pod(defs)}});
}

Result<Piece> Piece::from_pod(const Pod& whole) {
    return Piece{.title = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "title")))), .prism = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "prism")))), .path_ = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "path")))), .ns = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "ns")))), .needs = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "needs")))), .defs = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "defs"))))};
}


/// NodeParts: unbounded fn Cp, NodeDef -> Parts
crate::emit::cpp::items::Parts node_parts(const crate::emit::cpp::Cp& cp, const crate::lower::model::NodeDef& n) {
    auto ncp = crate::emit::cpp::with_fields(cp, each(n.fields, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& f = std::get<0>(_p0);
        auto&& t = std::get<1>(_p0);
        return std::tuple{f, t};
    }));
    auto base = (n.row_kind == crate::lower::model::RowKind(crate::lower::model::RowKind::NotARow{})) && (len(n.hosted) == Nat(0u))
        ? Text::lit("Node")
        : Text::lit("Row");
    auto fields = crate::syntax::lexer::chars::join(run_to_end(each_job(n.fields, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy, Text>)>>(prism_rtl::rc([=, cp_1 = std::move(cp_1)](std::tuple<Text, crate::lower::model::OutTy, Text> p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=, cp_1_2 = std::move(cp_1_2)]() {
            return ({
                auto [f, t, doc] = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_1_2, t), [=](Text cpp_type_1357) { return prism_rtl::finished(prism_rtl::cat(crate::emit::cpp::items::cpp_doc(doc), cpp_type_1357, " ", crate::emit::cpp::field_id(f), ";")); });
            });
        }));
        });
    })));
    }))), Text::lit("\n"));
    auto consts = crate::syntax::lexer::chars::join(each(n.consts, [&](const std::tuple<Text, Nat, Text>& _p0) {
        auto&& c = std::get<0>(_p0);
        auto&& h = std::get<1>(_p0);
        auto&& doc = std::get<2>(_p0);
        return prism_rtl::cat(crate::emit::cpp::items::cpp_doc(prism_rtl::cat("The ", doc, ".")), "static constexpr std::uint32_t ", c, " = ", h, ";");
    }), Text::lit("\n"));
    auto ctor_params = crate::syntax::lexer::chars::join(append(Array(std::vector{Text::lit("Path path")}), run_to_end(each_job(n.fields, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy, Text>)>>(prism_rtl::rc([=, cp_1 = std::move(cp_1)](std::tuple<Text, crate::lower::model::OutTy, Text> p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=, cp_1_2 = std::move(cp_1_2)]() {
            return ({
                auto&& _f = p0;
                auto&& f = std::get<0>(_f);
                auto&& t = std::get<1>(_f);
                call_then(crate::emit::cpp::start_cpp_type(cp_1_2, t), [=](Text cpp_type_1609) { return prism_rtl::finished(prism_rtl::cat(cpp_type_1609, " ", crate::emit::cpp::field_id(f))); });
            });
        }));
        });
    })));
    })))), Text::lit(", "));
    auto ctor_inits = crate::syntax::lexer::chars::join(append(Array(std::vector{Text::lit("path(std::move(path))")}), each(n.fields, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& f = std::get<0>(_p0);
        return prism_rtl::cat(crate::emit::cpp::field_id(f), "(std::move(", crate::emit::cpp::field_id(f), "))");
    })), Text::lit(", "));
    auto params = concat(run_to_end(each_job(n.params, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_1 = std::move(cp_1)](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=, cp_1_2 = std::move(cp_1_2)]() {
            return ({
                auto [p_, t] = p0;
                call_then(crate::emit::cpp::expr::start_param_type(cp_1_2, t), [=](Text param_type_1848) { return prism_rtl::finished(prism_rtl::cat(param_type_1848, " ", p_, ", ")); });
            });
        }));
        });
    })));
    }))));
    auto ret = n.fallible
        ? prism_rtl::cat("Result<prism_rtl::Rc<", n.name, ">>")
        : prism_rtl::cat("prism_rtl::Rc<", n.name, ">");
    auto make_decl = prism_rtl::cat("static ", ret, " make(Path path, ", params, "Cx& cx);");
    auto method_decls = run_to_end(each_job(append(n.methods, n.hosted), ({
        auto ncp_1 = ncp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::MethDef)>>(prism_rtl::rc([=, ncp_1 = std::move(ncp_1)](crate::lower::model::MethDef p0) {
        return ({
            auto ncp_1_2 = ncp_1;
            entered(once_job([=, ncp_1_2 = std::move(ncp_1_2)]() {
            return ({
                auto m = p0;
                call_then(start_method_sig(ncp_1_2, m, Text::lit("")), [=](Text method_sig_2099) { return prism_rtl::finished(prism_rtl::cat(method_sig_2099, ";")); });
            });
        }));
        });
    })));
    })));
    auto builder_decls = append(each(n.builders, [&](const crate::lower::model::ForDef& b) { return prism_rtl::cat("Done ", prism_rtl::deref(b).name, "_build(Cx& cx);"); }), each(n.gens, [&](const crate::lower::model::GenDef& g) { return prism_rtl::cat("Done ", prism_rtl::deref(g).name, "_build(Cx& cx);"); }));
    auto hook_decls = each(n.hooks, [&](const std::tuple<Text, Array<crate::lower::model::Do>>& _p0) {
        auto&& h = std::get<0>(_p0);
        return prism_rtl::cat(hook_sig(h, Text::lit("")), " override;");
    });
    auto answer_decl = len(n.answers) == Nat(0u)
        ? Array<Text>{}
        : Array(std::vector{Text::lit("Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;")});
    auto row_decl = n.row_kind == crate::lower::model::RowKind(crate::lower::model::RowKind::NotARow{})
        ? Array<Text>{}
        : Array(std::vector{Text::lit("void leave_row(Cx& cx) override;")});
    auto decls = crate::syntax::lexer::chars::join(append(append(append(append(append(Array(std::vector{make_decl}), method_decls), builder_decls), hook_decls), answer_decl), row_decl), Text::lit("\n"));
    auto doc = crate::emit::cpp::items::cpp_source_doc(prism_rtl::cat("`", n.prism, "`: a node of its own (claude/backend.md, \"A widget block\")."), n.doc);
    auto decl = crate::emit::cpp::templates::items::node_class(doc, n.name, base, fields, consts, prism_rtl::cat(n.name, "(", ctor_params, ") : ", ctor_inits, " {}"), decls);
    auto by_field = each(n.fields, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& f = std::get<0>(_p0);
        return or_(fold(n.inits, std::optional<crate::lower::model::Ex>{}, [&](const std::optional<crate::lower::model::Ex>& found_opt, const std::tuple<Text, crate::lower::model::Ex>& _p1) {
            auto&& g = std::get<0>(_p1);
            auto&& v_ = std::get<1>(_p1);
            return g == f ? std::optional(v_) : found_opt;
        }), crate::lower::model::Ex(crate::lower::model::Ex::XVar{f}));
    });
    auto [lets_text, lcp] = crate::emit::cpp::stmts::cpp_statements_cp(ncp, n.lets);
    auto args = crate::syntax::lexer::chars::join(append(Array(std::vector{Text::lit("path")}), run_to_end(each_job(by_field, ({
        auto lcp_1 = lcp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=, lcp_1 = std::move(lcp_1)](crate::lower::model::Ex p0) {
        return ({
            auto lcp_1_2 = lcp_1;
            entered(once_job([=, lcp_1_2 = std::move(lcp_1_2)]() {
            return ({
                auto v_ = p0;
                (prism_rtl::more(prism_rtl::rc(crate::emit::cpp::expr::CppExpr(lcp_1_2, v_))));
            });
        }));
        });
    })));
    })))), Text::lit(", "));
    auto tail = n.fallible ? Text::lit("return node;") : Text::lit("return node;");
    auto make_1 = crate::emit::cpp::templates::items::node_make(n.name, prism_rtl::cat(ret, " ", n.name, "::make(Path path, ", params, "Cx& cx)"), lets_text, args, crate::syntax::lexer::chars::join(filter(Array(std::vector{crate::emit::cpp::stmts::cpp_statements(crate::emit::cpp::stmts::pointing(lcp, Text::lit("node")), n.build), tail}), [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n")));
    auto methods = run_to_end(each_job(append(n.methods, n.hosted), ({
        auto ncp_2 = ncp;
        auto n_3 = n;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::MethDef)>>(prism_rtl::rc([=, ncp_2 = std::move(ncp_2), n_3 = std::move(n_3)](crate::lower::model::MethDef p0) {
        return ({
            auto ncp_2_4 = ncp_2;
            auto n_3_4 = n_3;
            entered(once_job([=, ncp_2_4 = std::move(ncp_2_4), n_3_4 = std::move(n_3_4)]() {
            return ({
                auto m = p0;
                (prism_rtl::more(prism_rtl::rc(MethodDef(ncp_2_4, n_3_4.name, m))));
            });
        }));
        });
    })));
    })));
    auto builders = append(run_to_end(each_job(n.builders, ({
        auto ncp_2 = ncp;
        auto n_3 = n;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::ForDef)>>(prism_rtl::rc([=, ncp_2 = std::move(ncp_2), n_3 = std::move(n_3)](crate::lower::model::ForDef p0) {
        return ({
            auto ncp_2_4 = ncp_2;
            auto n_3_4 = n_3;
            entered(once_job([=, ncp_2_4 = std::move(ncp_2_4), n_3_4 = std::move(n_3_4)]() {
            return ({
                auto b = p0;
                (prism_rtl::more(prism_rtl::rc(ForBuildCpp(ncp_2_4, n_3_4.name, b))));
            });
        }));
        });
    })));
    }))), run_to_end(each_job(n.gens, ({
        auto ncp_2 = ncp;
        auto n_3 = n;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::GenDef)>>(prism_rtl::rc([=, ncp_2 = std::move(ncp_2), n_3 = std::move(n_3)](crate::lower::model::GenDef p0) {
        return ({
            auto ncp_2_4 = ncp_2;
            auto n_3_4 = n_3;
            entered(once_job([=, ncp_2_4 = std::move(ncp_2_4), n_3_4 = std::move(n_3_4)]() {
            return ({
                auto g = p0;
                (prism_rtl::more(prism_rtl::rc(GenBuildCpp(ncp_2_4, n_3_4.name, g))));
            });
        }));
        });
    })));
    }))));
    auto hooks = run_to_end(each_job(n.hooks, ({
        auto n_2 = n;
        auto ncp_3 = ncp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Array<crate::lower::model::Do>>)>>(prism_rtl::rc([=, n_2 = std::move(n_2), ncp_3 = std::move(ncp_3)](std::tuple<Text, Array<crate::lower::model::Do>> p0) {
        return ({
            auto n_2_4 = n_2;
            auto ncp_3_4 = ncp_3;
            entered(once_job([=, n_2_4 = std::move(n_2_4), ncp_3_4 = std::move(ncp_3_4)]() {
            return ({
                auto [h, body] = p0;
                call_then(crate::emit::cpp::stmts::start_cpp_statements(ncp_3_4, body), [=](Text cpp_statements_3838) { return prism_rtl::finished(crate::emit::cpp::templates::items::cpp_function(Text::lit(""), hook_sig(h, prism_rtl::cat(n_2_4.name, "::")), prism_rtl::cat(cpp_statements_3838, "\nreturn {};"))); });
            });
        }));
        });
    })));
    })));
    auto answer = len(n.answers) == Nat(0u)
        ? Array<Text>{}
        : Array(std::vector{answer_def_cpp(ncp, n)});
    auto leaving = n.row_kind == crate::lower::model::RowKind(crate::lower::model::RowKind::NotARow{})
        ? Array<Text>{}
        : Array(std::vector{row_leaving(ncp, n)});
    auto defs = append(append(append(append(append(Array(std::vector{make_1}), methods), builders), hooks), answer), leaving);
    auto own = crate::emit::cpp::items::Parts{.forward = Array(std::vector{prism_rtl::cat("class ", n.name, ";")}), .values = Array<crate::emit::cpp::items::ValueDecl>{}, .protos = Array<Text>{}, .classes = Array(std::vector{decl}), .outer = Array<Text>{}, .generic = Array<Text>{}, .defs = defs};
    return own;
}


prism_rtl::Turn<crate::emit::cpp::items::Parts> NodeParts::cycle() const {
    const auto& cp = this->cp;
    const auto& n = this->n;
    auto ncp = crate::emit::cpp::with_fields(cp, each(prism_rtl::deref(n).fields, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& f = std::get<0>(_p0);
        auto&& t = std::get<1>(_p0);
        return std::tuple{f, t};
    }));
    auto base = (prism_rtl::deref(n).row_kind == crate::lower::model::RowKind(crate::lower::model::RowKind::NotARow{})) && (len(prism_rtl::deref(n).hosted) == Nat(0u))
        ? Text::lit("Node")
        : Text::lit("Row");
    auto cp_1 = cp;
    auto n_2 = n;
    return call_value(each_job(prism_rtl::deref(n_2).fields, ({
        auto cp_1_3 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy, Text>)>>(prism_rtl::rc([=, cp_1_3 = std::move(cp_1_3)](std::tuple<Text, crate::lower::model::OutTy, Text> p0) {
        return ({
            auto cp_1_3_3 = cp_1_3;
            entered(once_job([=, cp_1_3_3 = std::move(cp_1_3_3)]() {
            return ({
                auto [f, t, doc] = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_1_3_3, t), [=](Text cpp_type_1357) { return prism_rtl::finished(prism_rtl::cat(crate::emit::cpp::items::cpp_doc(doc), cpp_type_1357, " ", crate::emit::cpp::field_id(f), ";")); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_1311) {
        return ({
            auto fields = crate::syntax::lexer::chars::join(each_1311, Text::lit("\n"));
            auto consts = crate::syntax::lexer::chars::join(each(prism_rtl::deref(n_2).consts, [&](const std::tuple<Text, Nat, Text>& _p0) {
                auto&& c = std::get<0>(_p0);
                auto&& h = std::get<1>(_p0);
                auto&& doc = std::get<2>(_p0);
                return prism_rtl::cat(crate::emit::cpp::items::cpp_doc(prism_rtl::cat("The ", doc, ".")), "static constexpr std::uint32_t ", c, " = ", h, ";");
            }), Text::lit("\n"));
            call_value(each_job(prism_rtl::deref(n_2).fields, ({
            auto cp_1_3 = cp_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy, Text>)>>(prism_rtl::rc([=, cp_1_3 = std::move(cp_1_3)](std::tuple<Text, crate::lower::model::OutTy, Text> p0) {
            return ({
                auto cp_1_3_3 = cp_1_3;
                entered(once_job([=, cp_1_3_3 = std::move(cp_1_3_3)]() {
                return ({
                    auto&& _f = p0;
                    auto&& f = std::get<0>(_f);
                    auto&& t = std::get<1>(_f);
                    call_then(crate::emit::cpp::start_cpp_type(cp_1_3_3, t), [=](Text cpp_type_1609) { return prism_rtl::finished(prism_rtl::cat(cpp_type_1609, " ", crate::emit::cpp::field_id(f))); });
                });
            }));
            });
        })));
        })), [=, fields = std::move(fields), consts = std::move(consts)](Array<Text> each_1572) {
            return ({
                auto ctor_params = crate::syntax::lexer::chars::join(append(Array(std::vector{Text::lit("Path path")}), each_1572), Text::lit(", "));
                auto ctor_inits = crate::syntax::lexer::chars::join(append(Array(std::vector{Text::lit("path(std::move(path))")}), each(prism_rtl::deref(n_2).fields, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
                    auto&& f = std::get<0>(_p0);
                    return prism_rtl::cat(crate::emit::cpp::field_id(f), "(std::move(", crate::emit::cpp::field_id(f), "))");
                })), Text::lit(", "));
                call_value(each_job(prism_rtl::deref(n_2).params, ({
                auto cp_1_3 = cp_1;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_1_3 = std::move(cp_1_3)](std::tuple<Text, crate::lower::model::OutTy> p0) {
                return ({
                    auto cp_1_3_3 = cp_1_3;
                    entered(once_job([=, cp_1_3_3 = std::move(cp_1_3_3)]() {
                    return ({
                        auto [p_, t] = p0;
                        call_then(crate::emit::cpp::expr::start_param_type(cp_1_3_3, t), [=](Text param_type_1848) { return prism_rtl::finished(prism_rtl::cat(param_type_1848, " ", p_, ", ")); });
                    });
                }));
                });
            })));
            })), [=, ctor_params = std::move(ctor_params), ctor_inits = std::move(ctor_inits)](Array<Text> each_1819) {
                return ({
                    auto params = concat(each_1819);
                    auto ret = prism_rtl::deref(n_2).fallible
                        ? prism_rtl::cat("Result<prism_rtl::Rc<", prism_rtl::deref(n_2).name, ">>")
                        : prism_rtl::cat("prism_rtl::Rc<", prism_rtl::deref(n_2).name, ">");
                    auto make_decl = prism_rtl::cat("static ", ret, " make(Path path, ", params, "Cx& cx);");
                    call_value(each_job(append(prism_rtl::deref(n_2).methods, prism_rtl::deref(n_2).hosted), ({
                    auto ncp_3 = ncp;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::MethDef)>>(prism_rtl::rc([=, ncp_3 = std::move(ncp_3)](crate::lower::model::MethDef p0) {
                    return ({
                        auto ncp_3_4 = ncp_3;
                        entered(once_job([=, ncp_3_4 = std::move(ncp_3_4)]() {
                        return ({
                            auto m = p0;
                            call_then(start_method_sig(ncp_3_4, m, Text::lit("")), [=](Text method_sig_2099) { return prism_rtl::finished(prism_rtl::cat(method_sig_2099, ";")); });
                        });
                    }));
                    });
                })));
                })), [=, params = std::move(params), ret = std::move(ret), make_decl = std::move(make_decl)](Array<Text> each_2057) {
                    return ({
                        auto method_decls = each_2057;
                        auto builder_decls = append(each(prism_rtl::deref(n_2).builders, [&](const crate::lower::model::ForDef& b) { return prism_rtl::cat("Done ", prism_rtl::deref(b).name, "_build(Cx& cx);"); }), each(prism_rtl::deref(n_2).gens, [&](const crate::lower::model::GenDef& g) { return prism_rtl::cat("Done ", prism_rtl::deref(g).name, "_build(Cx& cx);"); }));
                        auto hook_decls = each(prism_rtl::deref(n_2).hooks, [&](const std::tuple<Text, Array<crate::lower::model::Do>>& _p0) {
                            auto&& h = std::get<0>(_p0);
                            return prism_rtl::cat(hook_sig(h, Text::lit("")), " override;");
                        });
                        auto answer_decl = len(prism_rtl::deref(n_2).answers) == Nat(0u)
                            ? Array<Text>{}
                            : Array(std::vector{Text::lit("Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;")});
                        auto row_decl = prism_rtl::deref(n_2).row_kind == crate::lower::model::RowKind(crate::lower::model::RowKind::NotARow{})
                            ? Array<Text>{}
                            : Array(std::vector{Text::lit("void leave_row(Cx& cx) override;")});
                        auto decls = crate::syntax::lexer::chars::join(append(append(append(append(append(Array(std::vector{make_decl}), method_decls), builder_decls), hook_decls), answer_decl), row_decl), Text::lit("\n"));
                        auto doc = crate::emit::cpp::items::cpp_source_doc(prism_rtl::cat("`", prism_rtl::deref(n_2).prism, "`: a node of its own (claude/backend.md, \"A widget block\")."), prism_rtl::deref(n_2).doc);
                        auto decl = crate::emit::cpp::templates::items::node_class(doc, prism_rtl::deref(n_2).name, base, fields, consts, prism_rtl::cat(prism_rtl::deref(n_2).name, "(", ctor_params, ") : ", ctor_inits, " {}"), decls);
                        auto by_field = each(prism_rtl::deref(n_2).fields, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
                            auto&& f = std::get<0>(_p0);
                            return or_(fold(prism_rtl::deref(n_2).inits, std::optional<crate::lower::model::Ex>{}, [&](const std::optional<crate::lower::model::Ex>& found_opt, const std::tuple<Text, crate::lower::model::Ex>& _p1) {
                                auto&& g = std::get<0>(_p1);
                                auto&& v_ = std::get<1>(_p1);
                                return g == f ? std::optional(v_) : found_opt;
                            }), crate::lower::model::Ex(crate::lower::model::Ex::XVar{f}));
                        });
                        call_then(crate::emit::cpp::stmts::start_cpp_statements_cp(ncp, prism_rtl::deref(n_2).lets), [=, decl = std::move(decl), by_field = std::move(by_field)](std::tuple<Text, crate::emit::cpp::Cp> cpp_statements_cp_3170) {
                        return ({
                            auto [lets_text, lcp] = cpp_statements_cp_3170;
                            call_value(each_job(by_field, ({
                            auto lcp_3 = lcp;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=, lcp_3 = std::move(lcp_3)](crate::lower::model::Ex p0) {
                            return ({
                                auto lcp_3_4 = lcp_3;
                                entered(once_job([=, lcp_3_4 = std::move(lcp_3_4)]() {
                                return ({
                                    auto v_ = p0;
                                    (prism_rtl::more(prism_rtl::rc(crate::emit::cpp::expr::CppExpr(lcp_3_4, v_))));
                                });
                            }));
                            });
                        })));
                        })), [=](Array<Text> each_3239) {
                            return ({
                                auto args = crate::syntax::lexer::chars::join(append(Array(std::vector{Text::lit("path")}), each_3239), Text::lit(", "));
                                auto tail = prism_rtl::deref(n_2).fallible
                                    ? Text::lit("return node;")
                                    : Text::lit("return node;");
                                call_then(crate::emit::cpp::stmts::start_cpp_statements(crate::emit::cpp::stmts::pointing(lcp, Text::lit("node")), n_2->build), [=, args = std::move(args), tail = std::move(tail)](Text cpp_statements_3463) {
                                return ({
                                    auto make_3 = crate::emit::cpp::templates::items::node_make(prism_rtl::deref(n_2).name, prism_rtl::cat(ret, " ", prism_rtl::deref(n_2).name, "::make(Path path, ", params, "Cx& cx)"), lets_text, args, crate::syntax::lexer::chars::join(filter(Array(std::vector{cpp_statements_3463, tail}), [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n")));
                                    call_value(each_job(append(prism_rtl::deref(n_2).methods, prism_rtl::deref(n_2).hosted), ({
                                    auto ncp_4 = ncp;
                                    auto n_2_5 = n_2;
                                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::MethDef)>>(prism_rtl::rc([=, ncp_4 = std::move(ncp_4), n_2_5 = std::move(n_2_5)](crate::lower::model::MethDef p0) {
                                    return ({
                                        auto ncp_4_5 = ncp_4;
                                        auto n_2_5_5 = n_2_5;
                                        entered(once_job([=, ncp_4_5 = std::move(ncp_4_5), n_2_5_5 = std::move(n_2_5_5)]() {
                                        return ({
                                            auto m = p0;
                                            (prism_rtl::more(prism_rtl::rc(MethodDef(ncp_4_5, prism_rtl::deref(n_2_5_5).name, m))));
                                        });
                                    }));
                                    });
                                })));
                                })), [=, make_3 = std::move(make_3)](Array<Text> each_3558) {
                                    return ({
                                        auto methods = each_3558;
                                        call_value(each_job(prism_rtl::deref(n_2).builders, ({
                                        auto ncp_4 = ncp;
                                        auto n_2_5 = n_2;
                                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::ForDef)>>(prism_rtl::rc([=, ncp_4 = std::move(ncp_4), n_2_5 = std::move(n_2_5)](crate::lower::model::ForDef p0) {
                                        return ({
                                            auto ncp_4_5 = ncp_4;
                                            auto n_2_5_5 = n_2_5;
                                            entered(once_job([=, ncp_4_5 = std::move(ncp_4_5), n_2_5_5 = std::move(n_2_5_5)]() {
                                            return ({
                                                auto b = p0;
                                                (prism_rtl::more(prism_rtl::rc(ForBuildCpp(ncp_4_5, prism_rtl::deref(n_2_5_5).name, b))));
                                            });
                                        }));
                                        });
                                    })));
                                    })), [=, methods = std::move(methods)](Array<Text> each_3650) {
                                        return call_value(each_job(prism_rtl::deref(n_2).gens, ({
                                            auto ncp_4 = ncp;
                                            auto n_2_5 = n_2;
                                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::GenDef)>>(prism_rtl::rc([=, ncp_4 = std::move(ncp_4), n_2_5 = std::move(n_2_5)](crate::lower::model::GenDef p0) {
                                            return ({
                                                auto ncp_4_5 = ncp_4;
                                                auto n_2_5_5 = n_2_5;
                                                entered(once_job([=, ncp_4_5 = std::move(ncp_4_5), n_2_5_5 = std::move(n_2_5_5)]() {
                                                return ({
                                                    auto g = p0;
                                                    (prism_rtl::more(prism_rtl::rc(GenBuildCpp(ncp_4_5, prism_rtl::deref(n_2_5_5).name, g))));
                                                });
                                            }));
                                            });
                                        })));
                                        })), [=](Array<Text> each_3702) {
                                            return ({
                                                auto builders = append(each_3650, each_3702);
                                                call_value(each_job(prism_rtl::deref(n_2).hooks, ({
                                                auto n_2_4 = n_2;
                                                auto ncp_4 = ncp;
                                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Array<crate::lower::model::Do>>)>>(prism_rtl::rc([=, n_2_4 = std::move(n_2_4), ncp_4 = std::move(ncp_4)](std::tuple<Text, Array<crate::lower::model::Do>> p0) {
                                                return ({
                                                    auto n_2_4_5 = n_2_4;
                                                    auto ncp_4_5 = ncp_4;
                                                    entered(once_job([=, n_2_4_5 = std::move(n_2_4_5), ncp_4_5 = std::move(ncp_4_5)]() {
                                                    return ({
                                                        auto [h, body] = p0;
                                                        call_then(crate::emit::cpp::stmts::start_cpp_statements(ncp_4_5, body), [=](Text cpp_statements_3838) { return prism_rtl::finished(crate::emit::cpp::templates::items::cpp_function(Text::lit(""), hook_sig(h, prism_rtl::cat(prism_rtl::deref(n_2_4_5).name, "::")), prism_rtl::cat(cpp_statements_3838, "\nreturn {};"))); });
                                                    });
                                                }));
                                                });
                                            })));
                                            })), [=, builders = std::move(builders)](Array<Text> each_3764) {
                                                return ({
                                                    auto hooks = each_3764;
                                                    auto answer = len(prism_rtl::deref(n_2).answers) == Nat(0u)
                                                        ? Array<Text>{}
                                                        : Array(std::vector{answer_def_cpp(ncp, n_2)});
                                                    auto leaving = prism_rtl::deref(n_2).row_kind == crate::lower::model::RowKind(crate::lower::model::RowKind::NotARow{})
                                                        ? Array<Text>{}
                                                        : Array(std::vector{row_leaving(ncp, n_2)});
                                                    auto defs = append(append(append(append(append(Array(std::vector{make_3}), methods), builders), hooks), answer), leaving);
                                                    auto own = crate::emit::cpp::items::Parts{.forward = Array(std::vector{prism_rtl::cat("class ", prism_rtl::deref(n_2).name, ";")}), .values = Array<crate::emit::cpp::items::ValueDecl>{}, .protos = Array<Text>{}, .classes = Array(std::vector{decl}), .outer = Array<Text>{}, .generic = Array<Text>{}, .defs = defs};
                                                    (prism_rtl::finished(own));
                                                });
                                            });
                                            });
                                        });
                                    });
                                    });
                                });
                                });
                            });
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start NodeParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::emit::cpp::items::Parts> start_node_parts(crate::emit::cpp::Cp cp, crate::lower::model::NodeDef n) {
    return prism_rtl::make_rc<NodeParts>(cp, n);
}


/// MethodSig: unbounded fn Cp, MethDef, Text -> Text
Text method_sig(const crate::emit::cpp::Cp& cp, const crate::lower::model::MethDef& m, const Text& owner) {
    auto cx_ = ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = m.cx_;
        if (prism_rtl::is<crate::lower::model::CxArg::CxMut>(_m)) {
            _v.set(Array(std::vector{Text::lit("Cx& cx")}));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::CxArg::CxRef>(_m)) {
            _v.set(Array(std::vector{Text::lit("const Cx& cx")}));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::CxArg::CxNone>(_m)) {
            _v.set(Array<Text>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto params = crate::syntax::lexer::chars::join(append(run_to_end(each_job(m.params, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_1 = std::move(cp_1)](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=, cp_1_2 = std::move(cp_1_2)]() {
            return ({
                auto [p_, t] = p0;
                call_then(crate::emit::cpp::expr::start_param_type(cp_1_2, t), [=](Text param_type_4531) { return prism_rtl::finished(prism_rtl::cat(param_type_4531, " ", p_)); });
            });
        }));
        });
    })));
    }))), cx_), Text::lit(", "));
    auto constness = m.recv == crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{})
        ? Text::lit(" const")
        : Text::lit("");
    return prism_rtl::cat(crate::emit::cpp::cpp_type(cp, m.ret), " ", owner, crate::emit::cpp::expr::node_method_name(cp, m.name), "(", params, ")", constness);
}


prism_rtl::Turn<Text> MethodSig::cycle() const {
    const auto& cp = this->cp;
    const auto& m = this->m;
    const auto& owner = this->owner;
    auto cx_ = ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = prism_rtl::deref(m).cx_;
        if (prism_rtl::is<crate::lower::model::CxArg::CxMut>(_m)) {
            _v.set(Array(std::vector{Text::lit("Cx& cx")}));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::CxArg::CxRef>(_m)) {
            _v.set(Array(std::vector{Text::lit("const Cx& cx")}));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::CxArg::CxNone>(_m)) {
            _v.set(Array<Text>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto cp_1 = cp;
    auto m_2 = m;
    auto owner_3 = owner;
    return call_value(each_job(prism_rtl::deref(m_2).params, ({
        auto cp_1_4 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_1_4 = std::move(cp_1_4)](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_1_4_4 = cp_1_4;
            entered(once_job([=, cp_1_4_4 = std::move(cp_1_4_4)]() {
            return ({
                auto [p_, t] = p0;
                call_then(crate::emit::cpp::expr::start_param_type(cp_1_4_4, t), [=](Text param_type_4531) { return prism_rtl::finished(prism_rtl::cat(param_type_4531, " ", p_)); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_4502) {
        return ({
            auto params = crate::syntax::lexer::chars::join(append(each_4502, cx_), Text::lit(", "));
            auto constness = prism_rtl::deref(m_2).recv == crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{})
                ? Text::lit(" const")
                : Text::lit("");
            call_then(crate::emit::cpp::start_cpp_type(cp_1, prism_rtl::deref(m_2).ret), [=, params = std::move(params), constness = std::move(constness)](Text cpp_type_4631) { return prism_rtl::finished(prism_rtl::cat(cpp_type_4631, " ", owner_3, crate::emit::cpp::expr::node_method_name(cp_1, prism_rtl::deref(m_2).name), "(", params, ")", constness)); });
        });
    });
}


/// `Start MethodSig, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_method_sig(crate::emit::cpp::Cp cp, crate::lower::model::MethDef m, Text owner) {
    return prism_rtl::make_rc<MethodSig>(cp, m, owner);
}


/// MethodDef: unbounded fn Cp, Text, MethDef -> Text
Text method_def(const crate::emit::cpp::Cp& cp, const Text& owner, const crate::lower::model::MethDef& m) {
    auto [st, cp2] = crate::emit::cpp::stmts::cpp_statements_cp(cp, m.body);
    auto body = m.ret == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})
        ? prism_rtl::cat(st, "\nreturn Unit{};")
        : len(m.body) == Nat(0u)
        ? crate::emit::cpp::stmts::cpp_body(cp, m.tail)
        : prism_rtl::cat(st, "\n", crate::emit::cpp::stmts::cpp_body(cp2, m.tail));
    return crate::emit::cpp::templates::items::cpp_function(crate::emit::cpp::items::cpp_doc(m.doc), method_sig(cp, m, prism_rtl::cat(owner, "::")), body);
}


prism_rtl::Turn<Text> MethodDef::cycle() const {
    const auto& cp = this->cp;
    const auto& owner = this->owner;
    const auto& m = this->m;
    auto cp_1 = cp;
    auto m_2 = m;
    auto owner_3 = owner;
    return call_then(crate::emit::cpp::stmts::start_cpp_statements_cp(cp_1, prism_rtl::deref(m_2).body), [=](std::tuple<Text, crate::emit::cpp::Cp> cpp_statements_cp_4807) {
        return ({
            auto [st, cp2] = cpp_statements_cp_4807;
            auto body = prism_rtl::deref(m_2).ret == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})
                ? prism_rtl::cat(st, "\nreturn Unit{};")
                : len(prism_rtl::deref(m_2).body) == Nat(0u)
                ? crate::emit::cpp::stmts::cpp_body(cp_1, prism_rtl::deref(m_2).tail)
                : prism_rtl::cat(st, "\n", crate::emit::cpp::stmts::cpp_body(cp2, prism_rtl::deref(m_2).tail));
            call_then(start_method_sig(cp_1, m_2, prism_rtl::cat(owner_3, "::")), [=, body = std::move(body)](Text method_sig_5011) { return prism_rtl::finished(crate::emit::cpp::templates::items::cpp_function(crate::emit::cpp::items::cpp_doc(prism_rtl::deref(m_2).doc), method_sig_5011, body)); });
        });
    });
}


/// `Start MethodDef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_method_def(crate::emit::cpp::Cp cp, Text owner, crate::lower::model::MethDef m) {
    return prism_rtl::make_rc<MethodDef>(cp, owner, m);
}


/// HookSig: fn Text, Text -> Text
Text hook_sig(const Text& text0, const Text& owner) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("push")) {
            return prism_rtl::cat("Done ", owner, "push(const Pod& element, const Pod& v, Cx& cx)");
        }
    }
    {
        auto&& h = text0;
        return prism_rtl::cat("Done ", owner, h, "(Cx& cx)");
    }
}


/// AnswerDefCpp: unbounded fn Cp, NodeDef -> Text
Text answer_def_cpp(const crate::emit::cpp::Cp& cp, const crate::lower::model::NodeDef& n) {
    auto arms = run_to_end(each_job(n.answers, ({
        auto cp_1 = cp;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Text>>(std::tuple<crate::lower::model::Pa, crate::lower::model::Ex>)>>(prism_rtl::rc([=, cp_1 = std::move(cp_1)](std::tuple<crate::lower::model::Pa, crate::lower::model::Ex> p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=, cp_1_2 = std::move(cp_1_2)]() {
            return ({
                auto [pat, call] = p0;
                call_then(crate::emit::cpp::patterns::start_pat_conds(cp_1_2, pat, Text::lit("at")), [=](Array<Text> pat_conds_5354) {
                return ({
                    auto tests = pat_conds_5354;
                    call_then(crate::emit::cpp::patterns::start_pat_binds(cp_1_2, pat, Text::lit("at")), [=, tests = std::move(tests)](Array<Text> pat_binds_5397) {
                    return ({
                        auto binds = pat_binds_5397;
                        call_then(crate::emit::cpp::expr::start_cpp_expr(cp_1_2, call), [=, binds = std::move(binds)](Text cpp_expr_5458) { return prism_rtl::finished(std::tuple{tests, crate::syntax::lexer::chars::join(crate::prelude::push(binds, prism_rtl::cat(cpp_expr_5458, ";")), Text::lit("\n"))}); });
                    });
                });
                });
            });
            });
        }));
        });
    }));
    })));
    auto blocks = each(crate::check::errors::range0(len(arms)), [&](const Nat& i) {
        return ({
            auto [tests, inner] = or_(index(arms, i), std::tuple{Array<Text>{}, Text::lit("")});
            (crate::emit::cpp::templates::items::block(prism_rtl::cat(i == Nat(0u) ? Text::lit("if") : Text::lit("else if"), " (", crate::emit::cpp::patterns::conds(tests), ")"), inner));
        });
    });
    return crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("Done ", n.name, "::answer(std::span<const Segment> at, const Pod& v, Cx& cx)"), prism_rtl::cat(crate::syntax::lexer::chars::join(blocks, Text::lit(" ")), " else {\n    return unexpected(Fault::answer(str(\"no answering place at \", path_of(at))));\n}\nreturn {};"));
}


prism_rtl::Turn<Text> AnswerDefCpp::cycle() const {
    const auto& cp = this->cp;
    const auto& n = this->n;
    auto cp_1 = cp;
    auto n_2 = n;
    return call_value(each_job(prism_rtl::deref(n_2).answers, ({
        auto cp_1_3 = cp_1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Text>>(std::tuple<crate::lower::model::Pa, crate::lower::model::Ex>)>>(prism_rtl::rc([=, cp_1_3 = std::move(cp_1_3)](std::tuple<crate::lower::model::Pa, crate::lower::model::Ex> p0) {
        return ({
            auto cp_1_3_3 = cp_1_3;
            entered(once_job([=, cp_1_3_3 = std::move(cp_1_3_3)]() {
            return ({
                auto [pat, call] = p0;
                call_then(crate::emit::cpp::patterns::start_pat_conds(cp_1_3_3, pat, Text::lit("at")), [=](Array<Text> pat_conds_5354) {
                return ({
                    auto tests = pat_conds_5354;
                    call_then(crate::emit::cpp::patterns::start_pat_binds(cp_1_3_3, pat, Text::lit("at")), [=, tests = std::move(tests)](Array<Text> pat_binds_5397) {
                    return ({
                        auto binds = pat_binds_5397;
                        call_then(crate::emit::cpp::expr::start_cpp_expr(cp_1_3_3, call), [=, binds = std::move(binds)](Text cpp_expr_5458) { return prism_rtl::finished(std::tuple{tests, crate::syntax::lexer::chars::join(crate::prelude::push(binds, prism_rtl::cat(cpp_expr_5458, ";")), Text::lit("\n"))}); });
                    });
                });
                });
            });
            });
        }));
        });
    }));
    })), [=](Array<std::tuple<Array<Text>, Text>> each_5301) {
        return ({
            auto arms = each_5301;
            auto blocks = each(crate::check::errors::range0(len(arms)), [&](const Nat& i) {
                return ({
                    auto [tests, inner] = or_(index(arms, i), std::tuple{Array<Text>{}, Text::lit("")});
                    (crate::emit::cpp::templates::items::block(prism_rtl::cat(i == Nat(0u) ? Text::lit("if") : Text::lit("else if"), " (", crate::emit::cpp::patterns::conds(tests), ")"), inner));
                });
            });
            (prism_rtl::finished(crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("Done ", prism_rtl::deref(n_2).name, "::answer(std::span<const Segment> at, const Pod& v, Cx& cx)"), prism_rtl::cat(crate::syntax::lexer::chars::join(blocks, Text::lit(" ")), " else {\n    return unexpected(Fault::answer(str(\"no answering place at \", path_of(at))));\n}\nreturn {};"))));
        });
    });
}


/// `Start AnswerDefCpp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_answer_def_cpp(crate::emit::cpp::Cp cp, crate::lower::model::NodeDef n) {
    return prism_rtl::make_rc<AnswerDefCpp>(cp, n);
}


/// RowLeaving: unbounded fn Cp, NodeDef -> Text
Text row_leaving(const crate::emit::cpp::Cp& cp, const crate::lower::model::NodeDef& n) {
    auto kept = n.row_kind == crate::lower::model::RowKind(crate::lower::model::RowKind::ForRow{})
        ? Array(std::vector{Text::lit("this->left_entry = entry(cx);")})
        : Array<Text>{};
    auto unsubscribe = each(n.subs, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& ev = std::get<0>(_p0);
        auto&& m = std::get<1>(_p0);
        return prism_rtl::cat("if (auto p = parent.lock(); p && ", m, "_sub) deref(p->", ev, "_port).unsubscribe(*std::exchange(", m, "_sub, std::nullopt));");
    });
    return crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("void ", n.name, "::leave_row(Cx& cx)"), crate::syntax::lexer::chars::join(append(crate::prelude::push(kept, Text::lit("remove_places(cx);")), unsubscribe), Text::lit("\n")));
}


prism_rtl::Turn<Text> RowLeaving::cycle() const {
    const auto& cp = this->cp;
    const auto& n = this->n;
    auto kept = prism_rtl::deref(n).row_kind == crate::lower::model::RowKind(crate::lower::model::RowKind::ForRow{})
        ? Array(std::vector{Text::lit("this->left_entry = entry(cx);")})
        : Array<Text>{};
    auto unsubscribe = each(prism_rtl::deref(n).subs, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& ev = std::get<0>(_p0);
        auto&& m = std::get<1>(_p0);
        return prism_rtl::cat("if (auto p = parent.lock(); p && ", m, "_sub) deref(p->", ev, "_port).unsubscribe(*std::exchange(", m, "_sub, std::nullopt));");
    });
    return prism_rtl::finished(crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("void ", prism_rtl::deref(n).name, "::leave_row(Cx& cx)"), crate::syntax::lexer::chars::join(append(crate::prelude::push(kept, Text::lit("remove_places(cx);")), unsubscribe), Text::lit("\n"))));
}


/// `Start RowLeaving, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_row_leaving(crate::emit::cpp::Cp cp, crate::lower::model::NodeDef n) {
    return prism_rtl::make_rc<RowLeaving>(cp, n);
}


/// ForBuildCpp: unbounded fn Cp, Text, ForDef -> Text
Text for_build_cpp(const crate::emit::cpp::Cp& cp, const Text& owner, const crate::lower::model::ForDef& b) {
    return crate::emit::cpp::templates::items::for_build_template(owner, b.name, crate::emit::cpp::expr::cpp_expr(cp, b.at), crate::emit::cpp::cpp_type(cp, b.key_ty), crate::emit::cpp::cpp_type(cp, b.value_ty), crate::emit::cpp::expr::call_path(prism_rtl::cat(b.row_node, "::build")), b.source, crate::emit::cpp::expr::cpp_expr(cp, b.parent), concat(run_to_end(each_job(b.passed, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=, cp_1 = std::move(cp_1)](crate::lower::model::Ex p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=, cp_1_2 = std::move(cp_1_2)]() {
            return ({
                auto x = p0;
                call_then(crate::emit::cpp::expr::start_cpp_expr(cp_1_2, x), [=](Text cpp_expr_6762) { return prism_rtl::finished(prism_rtl::cat(", ", cpp_expr_6762)); });
            });
        }));
        });
    })));
    })))), moved_call_cpp(b.moved), from_kept_cpp(b.name, b.replaced), replaced_call_cpp(b.replaced));
}


prism_rtl::Turn<Text> ForBuildCpp::cycle() const {
    const auto& cp = this->cp;
    const auto& owner = this->owner;
    const auto& b = this->b;
    auto b_1 = b;
    auto cp_2 = cp;
    auto owner_3 = owner;
    return call_then(crate::emit::cpp::expr::start_cpp_expr(cp_2, prism_rtl::deref(b_1).at), [=](Text cpp_expr_6595) {
        return call_then(crate::emit::cpp::start_cpp_type(cp_2, prism_rtl::deref(b_1).key_ty), [=](Text cpp_type_6615) {
            return call_then(crate::emit::cpp::start_cpp_type(cp_2, prism_rtl::deref(b_1).value_ty), [=](Text cpp_type_6638) {
                return call_then(crate::emit::cpp::expr::start_cpp_expr(cp_2, b_1->parent), [=](Text cpp_expr_6706) {
                    return call_value(each_job(prism_rtl::deref(b_1).passed, ({
                        auto cp_2_4 = cp_2;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=, cp_2_4 = std::move(cp_2_4)](crate::lower::model::Ex p0) {
                        return ({
                            auto cp_2_4_4 = cp_2_4;
                            entered(once_job([=, cp_2_4_4 = std::move(cp_2_4_4)]() {
                            return ({
                                auto x = p0;
                                call_then(crate::emit::cpp::expr::start_cpp_expr(cp_2_4_4, x), [=](Text cpp_expr_6762) { return prism_rtl::finished(prism_rtl::cat(", ", cpp_expr_6762)); });
                            });
                        }));
                        });
                    })));
                    })), [=](Array<Text> each_6738) { return prism_rtl::finished(crate::emit::cpp::templates::items::for_build_template(owner_3, prism_rtl::deref(b_1).name, cpp_expr_6595, cpp_type_6615, cpp_type_6638, crate::emit::cpp::expr::call_path(prism_rtl::cat(prism_rtl::deref(b_1).row_node, "::build")), b_1->source, cpp_expr_6706, concat(each_6738), moved_call_cpp(prism_rtl::deref(b_1).moved), from_kept_cpp(prism_rtl::deref(b_1).name, prism_rtl::deref(b_1).replaced), replaced_call_cpp(prism_rtl::deref(b_1).replaced))); });
                });
            });
        });
    });
}


/// `Start ForBuildCpp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_for_build_cpp(crate::emit::cpp::Cp cp, Text owner, crate::lower::model::ForDef b) {
    return prism_rtl::make_rc<ForBuildCpp>(cp, owner, b);
}


/// FromKeptCpp: fn Text, [Text] -> Text
Text from_kept_cpp(const Text& name, const Array<Text>& replaced) {
    return len(replaced) == Nat(0u)
        ? prism_rtl::cat("this->", name, "_from = items;")
        : prism_rtl::cat("auto from = std::exchange(this->", name, "_from, items);");
}


/// ReplacedCallCpp: fn [Text] -> Text
Text replaced_call_cpp(const Array<Text>& replaced) {
    return len(replaced) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" else if (auto was = from.get(k), is = items.get(k); !was || !is || !(*was == *is)) {\n            // the dynamic under a kept key was replaced: that row follows it from the next tick\n", concat(each(replaced, [&](const Text& m) { return prism_rtl::cat("            row->", m, "(cx);\n"); })), "        }");
}


/// MovedCallCpp: fn Text -> Text
Text moved_call_cpp(const Text& m) {
    return m == Text::lit("")
        ? Text::lit("")
        : prism_rtl::cat("\n    // the places of the host\'s child came or went: its document\'s outer moves\n    if (!prism_rtl::same_keys(next, old)) this->", m, "(cx);");
}


/// GenMovedCallCpp: fn Text -> Text
Text gen_moved_call_cpp(const Text& m) {
    return m == Text::lit("")
        ? Text::lit("")
        : prism_rtl::cat("\n    // the places of the host\'s child came or went: its document\'s outer moves\n    this->", m, "(cx);");
}


/// GenBuildCpp: unbounded fn Cp, Text, GenDef -> Text
Text gen_build_cpp(const crate::emit::cpp::Cp& cp, const Text& owner, const crate::lower::model::GenDef& gd) {
    auto path_ = gd.transparent
        ? Text::lit("this->path")
        : prism_rtl::cat(crate::emit::cpp::expr::cpp_expr(cp, gd.at), ".child(Segment::gen(g))");
    return crate::emit::cpp::templates::items::gen_build_template(owner, gd.name, crate::emit::cpp::expr::cpp_expr(cp, gd.at), path_, crate::emit::cpp::expr::cpp_expr(cp, gd.source), crate::emit::cpp::cpp_type(cp, gd.value_ty), crate::emit::cpp::expr::cpp_expr(cp, gd.select), gen_moved_call_cpp(gd.moved));
}


prism_rtl::Turn<Text> GenBuildCpp::cycle() const {
    const auto& cp = this->cp;
    const auto& owner = this->owner;
    const auto& gd = this->gd;
    auto path_ = prism_rtl::deref(gd).transparent
        ? Text::lit("this->path")
        : prism_rtl::cat(crate::emit::cpp::expr::cpp_expr(cp, prism_rtl::deref(gd).at), ".child(Segment::gen(g))");
    auto cp_1 = cp;
    auto gd_2 = gd;
    auto owner_3 = owner;
    return call_then(crate::emit::cpp::expr::start_cpp_expr(cp_1, prism_rtl::deref(gd_2).at), [=](Text cpp_expr_8647) { return call_then(crate::emit::cpp::expr::start_cpp_expr(cp_1, gd_2->source), [=](Text cpp_expr_8674) { return call_then(crate::emit::cpp::start_cpp_type(cp_1, prism_rtl::deref(gd_2).value_ty), [=](Text cpp_type_8699) { return call_then(crate::emit::cpp::expr::start_cpp_expr(cp_1, prism_rtl::deref(gd_2).select), [=](Text cpp_expr_8725) { return prism_rtl::finished(crate::emit::cpp::templates::items::gen_build_template(owner_3, prism_rtl::deref(gd_2).name, cpp_expr_8647, path_, cpp_expr_8674, cpp_type_8699, cpp_expr_8725, gen_moved_call_cpp(prism_rtl::deref(gd_2).moved))); }); }); }); });
}


/// `Start GenBuildCpp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_gen_build_cpp(crate::emit::cpp::Cp cp, Text owner, crate::lower::model::GenDef gd) {
    return prism_rtl::make_rc<GenBuildCpp>(cp, owner, gd);
}


/// ProgramCpp: unbounded fn Cp, ProgDef, Bool -> Text
Text program_cpp(const crate::emit::cpp::Cp& cp, const crate::lower::model::ProgDef& p_, const bool& fallible) {
    auto n = len(p_.params);
    auto names = each(p_.params, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
        auto&& a = std::get<0>(_p0);
        return a;
    });
    auto plural = n == Nat(1u) ? Text::lit("") : Text::lit("s");
    auto decode = n == Nat(0u)
        ? Text::lit("static_cast<void>(args);")
        : crate::syntax::lexer::chars::join(append(Array(std::vector{prism_rtl::cat("if (args.size() != ", n, ") return unexpected(Fault::answer(\"@", p_.prism, " takes ", n, " argument", plural, "\"));")}), run_to_end(each_job(crate::check::errors::range0(n), ({
        auto cp_1 = cp;
        auto p__2 = p_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=, cp_1 = std::move(cp_1), p__2 = std::move(p__2)](Nat p0) {
        return ({
            auto cp_1_3 = cp_1;
            auto p__2_3 = p__2;
            entered(once_job([=, cp_1_3 = std::move(cp_1_3), p__2_3 = std::move(p__2_3)]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(DecodeArg(cp_1_3, p__2_3.params, i))));
            });
        }));
        });
    })));
    })))), Text::lit("\n"));
    auto call = prism_rtl::cat(crate::emit::cpp::expr::call_path(prism_rtl::cat(p_.node_, "::build")), "(Path::root(), ", concat(each(names, [&](const Text& a) { return prism_rtl::cat(a, ", "); })), "cx)");
    auto root = fallible ? prism_rtl::cat("TRY(", call, ")") : call;
    return crate::emit::cpp::templates::items::program_class(p_.name, p_.prism, crate::emit::cpp::type_path(p_.node_), decode, root);
}


prism_rtl::Turn<Text> ProgramCpp::cycle() const {
    const auto& cp = this->cp;
    const auto& p_ = this->p_;
    const auto& fallible = this->fallible;
    auto n = len(prism_rtl::deref(p_).params);
    auto names = each(prism_rtl::deref(p_).params, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
        auto&& a = std::get<0>(_p0);
        return a;
    });
    auto plural = n == Nat(1u) ? Text::lit("") : Text::lit("s");
    auto decode = n == Nat(0u)
        ? Text::lit("static_cast<void>(args);")
        : crate::syntax::lexer::chars::join(append(Array(std::vector{prism_rtl::cat("if (args.size() != ", n, ") return unexpected(Fault::answer(\"@", prism_rtl::deref(p_).prism, " takes ", n, " argument", plural, "\"));")}), run_to_end(each_job(crate::check::errors::range0(n), ({
        auto cp_1 = cp;
        auto p__2 = p_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=, cp_1 = std::move(cp_1), p__2 = std::move(p__2)](Nat p0) {
        return ({
            auto cp_1_3 = cp_1;
            auto p__2_3 = p__2;
            entered(once_job([=, cp_1_3 = std::move(cp_1_3), p__2_3 = std::move(p__2_3)]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(DecodeArg(cp_1_3, prism_rtl::deref(p__2_3).params, i))));
            });
        }));
        });
    })));
    })))), Text::lit("\n"));
    auto call = prism_rtl::cat(crate::emit::cpp::expr::call_path(prism_rtl::cat(prism_rtl::deref(p_).node_, "::build")), "(Path::root(), ", concat(each(names, [&](const Text& a) { return prism_rtl::cat(a, ", "); })), "cx)");
    auto root = prism_rtl::deref(fallible) ? prism_rtl::cat("TRY(", call, ")") : call;
    return prism_rtl::finished(crate::emit::cpp::templates::items::program_class(prism_rtl::deref(p_).name, prism_rtl::deref(p_).prism, crate::emit::cpp::type_path(prism_rtl::deref(p_).node_), decode, root));
}


/// `Start ProgramCpp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_program_cpp(crate::emit::cpp::Cp cp, crate::lower::model::ProgDef p_, bool fallible) {
    return prism_rtl::make_rc<ProgramCpp>(cp, p_, fallible);
}


/// DecodeArg: unbounded fn Cp, [((Text, OutTy))], Nat -> Text
Text decode_arg(const crate::emit::cpp::Cp& cp, const Array<std::tuple<Text, crate::lower::model::OutTy>>& ps, const Nat& i) {
    auto&& _m = index(ps, i);
    if (prism_rtl::is_some(_m)) {
        auto&& a = std::get<0>(prism_rtl::some_of(_m));
        auto&& t = std::get<1>(prism_rtl::some_of(_m));
        return prism_rtl::cat("auto ", a, " = TRY(prism_rtl::from_pod<", crate::emit::cpp::cpp_type(cp, t), ">(args[", i, "]));");
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> DecodeArg::cycle() const {
    const auto& cp = this->cp;
    const auto& ps = this->ps;
    const auto& i = this->i;
    return ({
        auto&& _m = index(ps, i);
        prism_rtl::is_some(_m) ? ({
        auto&& a = std::get<0>(prism_rtl::some_of(_m));
        auto&& t = std::get<1>(prism_rtl::some_of(_m));
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(crate::emit::cpp::start_cpp_type(cp_1, t), [=, i_2 = std::move(i_2)](Text cpp_type_9583) { return prism_rtl::finished(prism_rtl::cat("auto ", a, " = TRY(prism_rtl::from_pod<", cpp_type_9583, ">(args[", i_2, "]));")); });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(Text::lit(""))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start DecodeArg, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_decode_arg(crate::emit::cpp::Cp cp, Array<std::tuple<Text, crate::lower::model::OutTy>> ps, Nat i) {
    return prism_rtl::make_rc<DecodeArg>(cp, ps, i);
}


/// ModuleParts: unbounded fn Cp, ModDef -> Parts
crate::emit::cpp::items::Parts module_parts(const crate::emit::cpp::Cp& cp, const crate::lower::model::ModDef& m) {
    auto mcp = crate::emit::cpp::in_home(cp, m.name);
    auto all = run_to_end(fold_job(m.items, crate::emit::cpp::items::no_parts(), ({
        auto mcp_1 = mcp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::emit::cpp::items::Parts>(std::tuple<crate::emit::cpp::items::Parts, crate::lower::model::Item>)>>(prism_rtl::rc([=, mcp_1 = std::move(mcp_1)](std::tuple<crate::emit::cpp::items::Parts, crate::lower::model::Item> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto mcp_1_2 = mcp_1;
            entered(once_job([=, mcp_1_2 = std::move(mcp_1_2)]() {
            return ({
                auto acc = p0;
                auto it = p1;
                call_then(crate::emit::cpp::items::start_item_parts(mcp_1_2, it), [=, acc = std::move(acc)](crate::emit::cpp::items::Parts item_parts_10032) { return prism_rtl::finished(crate::emit::cpp::items::join_parts(acc, item_parts_10032)); });
            });
        }));
        });
    })));
    })));
    return crate::emit::cpp::items::Parts{.forward = in_ns(m.name, prism_rtl::deref(all).forward), .values = each(prism_rtl::deref(all).values, [&](const crate::emit::cpp::items::ValueDecl& v_) { return in_ns_value(m.name, v_); }), .protos = in_ns(m.name, prism_rtl::deref(all).protos), .classes = in_ns(m.name, prism_rtl::deref(all).classes), .outer = prism_rtl::deref(all).outer, .generic = in_ns(m.name, prism_rtl::deref(all).generic), .defs = prism_rtl::deref(all).defs};
}


prism_rtl::Turn<crate::emit::cpp::items::Parts> ModuleParts::cycle() const {
    const auto& cp = this->cp;
    const auto& m = this->m;
    auto mcp = crate::emit::cpp::in_home(cp, prism_rtl::deref(m).name);
    auto m_1 = m;
    return call_value(fold_job(prism_rtl::deref(m_1).items, crate::emit::cpp::items::no_parts(), ({
        auto mcp_2 = mcp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::emit::cpp::items::Parts>(std::tuple<crate::emit::cpp::items::Parts, crate::lower::model::Item>)>>(prism_rtl::rc([=, mcp_2 = std::move(mcp_2)](std::tuple<crate::emit::cpp::items::Parts, crate::lower::model::Item> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto mcp_2_3 = mcp_2;
            entered(once_job([=, mcp_2_3 = std::move(mcp_2_3)]() {
            return ({
                auto acc = p0;
                auto it = p1;
                call_then(crate::emit::cpp::items::start_item_parts(mcp_2_3, it), [=, acc = std::move(acc)](crate::emit::cpp::items::Parts item_parts_10032) { return prism_rtl::finished(crate::emit::cpp::items::join_parts(acc, item_parts_10032)); });
            });
        }));
        });
    })));
    })), [=](crate::emit::cpp::items::Parts fold_9982) {
        return ({
            auto all = fold_9982;
            (prism_rtl::finished(crate::emit::cpp::items::Parts{.forward = in_ns(prism_rtl::deref(m_1).name, prism_rtl::deref(all).forward), .values = each(prism_rtl::deref(all).values, [&](const crate::emit::cpp::items::ValueDecl& v_) { return in_ns_value(prism_rtl::deref(m_1).name, v_); }), .protos = in_ns(prism_rtl::deref(m_1).name, prism_rtl::deref(all).protos), .classes = in_ns(prism_rtl::deref(m_1).name, prism_rtl::deref(all).classes), .outer = prism_rtl::deref(all).outer, .generic = in_ns(prism_rtl::deref(m_1).name, prism_rtl::deref(all).generic), .defs = prism_rtl::deref(all).defs}));
        });
    });
}


/// `Start ModuleParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::emit::cpp::items::Parts> start_module_parts(crate::emit::cpp::Cp cp, crate::lower::model::ModDef m) {
    return prism_rtl::make_rc<ModuleParts>(cp, m);
}


/// InNsValue: fn Text, ValueDecl -> ValueDecl
crate::emit::cpp::items::ValueDecl in_ns_value(const Text& ns, const crate::emit::cpp::items::ValueDecl& v_) {
    crate::emit::cpp::items::ValueDecl this_ = v_;
    this_.text = prism_rtl::cat("namespace ", ns, " {\n\n", this_.text, "\n\n}  // namespace ", ns);
    return this_;
}


/// InNs: fn Text, [Text] -> [Text]
Array<Text> in_ns(const Text& ns, const Array<Text>& xs1) {
    {
        auto&& c0_1 = xs1;
        if (c0_1.size() == 0u) {
            return Array<Text>{};
        }
    }
    {
        auto&& xs = xs1;
        return Array(std::vector{prism_rtl::cat("namespace ", ns, " {\n\n", crate::syntax::lexer::chars::join(xs, Text::lit("\n\n")), "\n\n}  // namespace ", ns)});
    }
}


/// NodeFallibleCpp: fn Model, Text -> Bool
bool node_fallible_cpp(const crate::lower::model::Model& model, const Text& path_) {
    return fold(model.mods, false, [&](const bool& f, const crate::lower::model::ModDef& m) {
        return fold(prism_rtl::deref(m).items, f, [&](const bool& f2, const crate::lower::model::Item& it) {
            return ({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                if (prism_rtl::is<crate::lower::model::Item::ItNode>(it)) {
                    auto&& n = prism_rtl::as<crate::lower::model::Item::ItNode>(it).a0;
                    _v.set(prism_rtl::deref(f2) || ((prism_rtl::cat(prism_rtl::deref(m).name, "::", prism_rtl::deref(n).name) == path_) && prism_rtl::deref(n).fallible));
                    goto _done;
                }
                {
                    _v.set(prism_rtl::deref(f2));
                    goto _done;
                }
            _done:
                _v.take();
            });
        });
    });
}


/// EmitCpp: unbounded fn Model, Text, [Text] -> [((Text, Text))]
Array<std::tuple<Text, Text>> emit_cpp(const crate::lower::model::Model& model, const Text& runtime, const Array<Text>& scripts) {
    auto cp = crate::emit::cpp::context(model);
    auto crate_ = crate::emit::cpp::in_home(cp, Text::lit(""));
    auto elem = crate::emit::cpp::items::row_parts(crate_, Text::lit(""), model.elem);
    auto answer = crate::emit::cpp::items::answer_parts(crate_, model.answer);
    auto mods = run_to_end(each_job(model.mods, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::emit::cpp::items::Parts>(crate::lower::model::ModDef)>>(prism_rtl::rc([=, cp_1 = std::move(cp_1)](crate::lower::model::ModDef p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=, cp_1_2 = std::move(cp_1_2)]() {
            return ({
                auto m = p0;
                (prism_rtl::more(prism_rtl::rc(ModuleParts(cp_1_2, m))));
            });
        }));
        });
    })));
    })));
    auto programs = crate::syntax::lexer::chars::join(run_to_end(each_job(all_programs_cpp(model), ({
        auto crate__1 = crate_;
        auto model_2 = model;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::ProgDef)>>(prism_rtl::rc([=, crate__1 = std::move(crate__1), model_2 = std::move(model_2)](crate::lower::model::ProgDef p0) {
        return ({
            auto crate__1_3 = crate__1;
            auto model_2_3 = model_2;
            entered(once_job([=, crate__1_3 = std::move(crate__1_3), model_2_3 = std::move(model_2_3)]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(ProgramCpp(crate__1_3, p_, node_fallible_cpp(model_2_3, prism_rtl::deref(p_).node_)))));
            });
        }));
        });
    })));
    }))), Text::lit("\n\n"));
    auto regs = concat(each(model.programs, [&](const crate::lower::model::ProgDef& p_) { return prism_rtl::cat("\n.program<", prism_rtl::deref(p_).name, ">(\"", prism_rtl::deref(p_).prism, "\")"); }));
    auto checks = concat(run_to_end(each_job(model.checks, ({
        auto crate__1 = crate_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CheckDef)>>(prism_rtl::rc([=, crate__1 = std::move(crate__1)](crate::lower::model::CheckDef p0) {
        return ({
            auto crate__1_2 = crate__1;
            entered(once_job([=, crate__1_2 = std::move(crate__1_2)]() {
            return ({
                auto c = p0;
                call_value(each_job(prism_rtl::deref(c).lines, ({
                auto crate__1_2_2 = crate__1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=, crate__1_2_2 = std::move(crate__1_2_2)](crate::lower::model::Ex p0) {
                return ({
                    auto crate__1_2_2_2 = crate__1_2_2;
                    entered(once_job([=, crate__1_2_2_2 = std::move(crate__1_2_2_2)]() {
                    return ({
                        auto l = p0;
                        (prism_rtl::more(prism_rtl::rc(crate::emit::cpp::expr::CppExpr(crate__1_2_2_2, l))));
                    });
                }));
                });
            })));
            })), [=](Array<Text> each_11535) { return prism_rtl::finished(prism_rtl::cat("\n.check(\"", prism_rtl::deref(c).name, "\", [] { return std::vector<Result<Pod>>{", crate::syntax::lexer::chars::join(each_11535, Text::lit(", ")), "}; })")); });
            });
        }));
        });
    })));
    }))));
    auto script_list = crate::syntax::lexer::chars::join(each(scripts, [&](const Text& s) { return prism_rtl::cat("\"", crate::lower::expr::escape(s), "\","); }), Text::lit("\n"));
    auto world = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = model.root;
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(r->world);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit("test"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto canvas_1 = world == Text::lit("canvas");
    auto run_root = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = model.root;
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(crate::emit::cpp::templates::cpp_run_root(prism_rtl::deref(r).name, std::move(canvas_1)
                ? crate::emit::cpp::templates::cpp_canvas_run(prism_rtl::deref(r).name)
                : crate::emit::cpp::templates::cpp_no_canvas(prism_rtl::deref(r).name)));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::emit::cpp::templates::cpp_no_root(model.name));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto both_ = crate::emit::cpp::items::join_parts(elem, answer);
    auto elem_decl = crate::emit::cpp::templates::cpp_elem_decl(includes(Text::lit("decl"), append(model.elem_complete, model.elem_declared)), crate::syntax::lexer::chars::join(prism_rtl::deref(both_).forward, Text::lit("\n\n")), crate::emit::cpp::prelude::cpp_prelude_rows(Text::lit("")));
    auto elem_types = crate::emit::cpp::templates::cpp_elem_types(crate::syntax::lexer::chars::join(filter(Array(std::vector{includes(Text::lit("types"), model.elem_complete), includes(Text::lit("decl"), model.elem_declared)}), [&](const Text& t) { return t != Text::lit(""); }), Text::lit("\n")), crate::syntax::lexer::chars::join(each(prism_rtl::deref(both_).values, [&](const crate::emit::cpp::items::ValueDecl& v_) { return v_->text; }), Text::lit("\n\n")));
    auto pairs = each(crate::check::errors::range0(len(model.mods)), [&](const Nat& i) { return std::tuple{or_(index(model.mods, i), no_mod()), or_(index(mods, i), crate::emit::cpp::items::no_parts())}; });
    auto generics = fold(pairs, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>& _p1) {
        auto&& m = std::get<0>(_p1);
        auto&& p_ = std::get<1>(_p1);
        return len(prism_rtl::deref(p_).generic) > Nat(0u)
            ? crate::prelude::push(acc, prism_rtl::deref(m).name)
            : acc;
    });
    auto per_module = run_to_end(each_job(pairs, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, Text>>, Array<Piece>>>(std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>)>>(prism_rtl::rc([=](std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts> p0) {
        return entered(once_job([=]() {
            return ({
                auto [m, p_] = p0;
                (prism_rtl::more(prism_rtl::rc(ModuleFiles(m, p_))));
            });
        }));
    }))));
    auto pieces = fold(per_module, Array<Piece>{}, [&](const Array<Piece>& acc, const std::tuple<Array<std::tuple<Text, Text>>, Array<Piece>>& _p1) {
        auto&& ps = std::get<1>(_p1);
        return append(acc, ps);
    });
    auto units_ = units(pieces);
    auto unit_files = each(crate::check::errors::range0(len(units_)), [&](const Nat& k) { return unit_file(k, or_(index(units_, k), Array<Piece>{}), generics); });
    auto main_includes = crate::syntax::lexer::chars::join(append(append(Array(std::vector{Text::lit("#include \"elem.types.hpp\"")}), Array(std::vector{includes(Text::lit(""), each(model.mods, [&](const crate::lower::model::ModDef& m) { return prism_rtl::deref(m).name; }))})), Array(std::vector{includes(Text::lit("generic"), generics)})), Text::lit("\n"));
    auto canvas_include = std::move(canvas_1)
        ? crate::emit::cpp::templates::cpp_canvas_include(Text::lit(""))
        : Text::lit("");
    auto main = crate::emit::cpp::templates::cpp_main(model.name, prism_rtl::cat("#include \"programs.hpp\"\n", canvas_include), regs, checks, script_list, world, run_root, crate::syntax::lexer::chars::join(crate::emit::cpp::patterns::concat2(each(Array(std::vector{elem, answer}), [&](const crate::emit::cpp::items::Parts& p_) { return prism_rtl::deref(p_).defs; })), Text::lit("\n\n")));
    auto groups = run_to_end(each_job(filter(model.mods, [&](const crate::lower::model::ModDef& m) { return (len(prism_rtl::deref(m).types_with) > Nat(1u)) && (or_(index(prism_rtl::deref(m).types_with, Nat(0u)), Text::lit("")) == prism_rtl::deref(m).name); }), ({
        auto pairs_2 = pairs;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text>>(crate::lower::model::ModDef)>>(prism_rtl::rc([=, pairs_2 = std::move(pairs_2)](crate::lower::model::ModDef p0) {
        return ({
            auto pairs_2_3 = pairs_2;
            entered(once_job([=, pairs_2_3 = std::move(pairs_2_3)]() {
            return ({
                auto m = p0;
                (prism_rtl::more(prism_rtl::rc(GroupTypesFile(pairs_2_3, prism_rtl::deref(m).types_with))));
            });
        }));
        });
    }));
    })));
    auto files = append(fold(per_module, Array<std::tuple<Text, Text>>{}, [&](const Array<std::tuple<Text, Text>>& acc, const std::tuple<Array<std::tuple<Text, Text>>, Array<Piece>>& _p1) {
        auto&& fs = std::get<0>(_p1);
        return append(acc, fs);
    }), unit_files);
    auto sources = crate::syntax::lexer::chars::join(filter(each(files, [&](const std::tuple<Text, Text>& _p0) {
        auto&& f = std::get<0>(_p0);
        return f;
    }), [&](const Text& f) { return crate::syntax::lexer::chars::contains(f, Text::lit(".cpp")); }), Text::lit(" "));
    return append(Array(std::vector{std::tuple{Text::lit("Makefile"), crate::emit::cpp::templates::cpp_makefile(model.name, runtime, sources, std::move(canvas_1)
        ? crate::emit::cpp::templates::cpp_makefile_canvas(runtime)
        : Text::lit(""))}, std::tuple{Text::lit("src/elem.decl.hpp"), elem_decl}, std::tuple{Text::lit("src/elem.types.hpp"), elem_types}, std::tuple{Text::lit("src/programs.hpp"), crate::emit::cpp::templates::cpp_programs_header(model.name, main_includes, programs)}, std::tuple{Text::lit("src/main.cpp"), main}, std::tuple{Text::lit("src/prelude.hpp"), crate::emit::cpp::prelude::cpp_prelude_source(Text::lit(""))}}), append(groups, files));
}


prism_rtl::Turn<Array<std::tuple<Text, Text>>> EmitCpp::cycle() const {
    const auto& model = this->model;
    const auto& runtime = this->runtime;
    const auto& scripts = this->scripts;
    auto cp = crate::emit::cpp::context(model);
    auto crate_ = crate::emit::cpp::in_home(cp, Text::lit(""));
    auto model_1 = model;
    auto runtime_2 = runtime;
    auto scripts_3 = scripts;
    return call_then(crate::emit::cpp::items::start_row_parts(crate_, Text::lit(""), prism_rtl::deref(model_1).elem), [=](crate::emit::cpp::items::Parts row_parts_11072) {
        return ({
            auto elem = row_parts_11072;
            call_then(crate::emit::cpp::items::start_answer_parts(crate_, model_1->answer), [=, elem = std::move(elem)](crate::emit::cpp::items::Parts answer_parts_11120) {
            return ({
                auto answer = answer_parts_11120;
                call_value(each_job(prism_rtl::deref(model_1).mods, ({
                auto cp_4 = cp;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::emit::cpp::items::Parts>(crate::lower::model::ModDef)>>(prism_rtl::rc([=, cp_4 = std::move(cp_4)](crate::lower::model::ModDef p0) {
                return ({
                    auto cp_4_5 = cp_4;
                    entered(once_job([=, cp_4_5 = std::move(cp_4_5)]() {
                    return ({
                        auto m = p0;
                        (prism_rtl::more(prism_rtl::rc(ModuleParts(cp_4_5, m))));
                    });
                }));
                });
            })));
            })), [=, answer = std::move(answer)](Array<crate::emit::cpp::items::Parts> each_11167) {
                return ({
                    auto mods = each_11167;
                    call_value(each_job(all_programs_cpp(model_1), ({
                    auto crate__4 = crate_;
                    auto model_1_5 = model_1;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::ProgDef)>>(prism_rtl::rc([=, crate__4 = std::move(crate__4), model_1_5 = std::move(model_1_5)](crate::lower::model::ProgDef p0) {
                    return ({
                        auto crate__4_5 = crate__4;
                        auto model_1_5_5 = model_1_5;
                        entered(once_job([=, crate__4_5 = std::move(crate__4_5), model_1_5_5 = std::move(model_1_5_5)]() {
                        return ({
                            auto p_ = p0;
                            (prism_rtl::more(prism_rtl::rc(ProgramCpp(crate__4_5, p_, node_fallible_cpp(model_1_5_5, prism_rtl::deref(p_).node_)))));
                        });
                    }));
                    });
                })));
                })), [=, mods = std::move(mods)](Array<Text> each_11232) {
                    return ({
                        auto programs = crate::syntax::lexer::chars::join(each_11232, Text::lit("\n\n"));
                        auto regs = concat(each(prism_rtl::deref(model_1).programs, [&](const crate::lower::model::ProgDef& p_) { return prism_rtl::cat("\n.program<", prism_rtl::deref(p_).name, ">(\"", prism_rtl::deref(p_).prism, "\")"); }));
                        call_value(each_job(prism_rtl::deref(model_1).checks, ({
                        auto crate__4 = crate_;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CheckDef)>>(prism_rtl::rc([=, crate__4 = std::move(crate__4)](crate::lower::model::CheckDef p0) {
                        return ({
                            auto crate__4_5 = crate__4;
                            entered(once_job([=, crate__4_5 = std::move(crate__4_5)]() {
                            return ({
                                auto c = p0;
                                call_value(each_job(prism_rtl::deref(c).lines, ({
                                auto crate__4_5_5 = crate__4_5;
                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=, crate__4_5_5 = std::move(crate__4_5_5)](crate::lower::model::Ex p0) {
                                return ({
                                    auto crate__4_5_5_5 = crate__4_5_5;
                                    entered(once_job([=, crate__4_5_5_5 = std::move(crate__4_5_5_5)]() {
                                    return ({
                                        auto l = p0;
                                        (prism_rtl::more(prism_rtl::rc(crate::emit::cpp::expr::CppExpr(crate__4_5_5_5, l))));
                                    });
                                }));
                                });
                            })));
                            })), [=](Array<Text> each_11535) { return prism_rtl::finished(prism_rtl::cat("\n.check(\"", prism_rtl::deref(c).name, "\", [] { return std::vector<Result<Pod>>{", crate::syntax::lexer::chars::join(each_11535, Text::lit(", ")), "}; })")); });
                            });
                        }));
                        });
                    })));
                    })), [=, programs = std::move(programs), regs = std::move(regs)](Array<Text> each_11441) {
                        return ({
                            auto checks = concat(each_11441);
                            auto script_list = crate::syntax::lexer::chars::join(each(scripts_3, [&](const Text& s) { return prism_rtl::cat("\"", crate::lower::expr::escape(s), "\","); }), Text::lit("\n"));
                            auto world = ({
                                __label__ _done;
                                prism_rtl::Slot<Text> _v;
                                auto&& _m = model_1->root;
                                if (prism_rtl::is_some(_m)) {
                                    auto&& r = prism_rtl::some_of(_m);
                                    _v.set(r->world);
                                    goto _done;
                                }
                                if (prism_rtl::is_none(_m)) {
                                    _v.set(Text::lit("test"));
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            });
                            auto canvas_4 = world == Text::lit("canvas");
                            auto run_root = ({
                                __label__ _done;
                                prism_rtl::Slot<Text> _v;
                                auto&& _m = model_1->root;
                                if (prism_rtl::is_some(_m)) {
                                    auto&& r = prism_rtl::some_of(_m);
                                    _v.set(crate::emit::cpp::templates::cpp_run_root(prism_rtl::deref(r).name, std::move(canvas_4)
                                        ? crate::emit::cpp::templates::cpp_canvas_run(prism_rtl::deref(r).name)
                                        : crate::emit::cpp::templates::cpp_no_canvas(prism_rtl::deref(r).name)));
                                    goto _done;
                                }
                                if (prism_rtl::is_none(_m)) {
                                    _v.set(crate::emit::cpp::templates::cpp_no_root(prism_rtl::deref(model_1).name));
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            });
                            auto both_ = crate::emit::cpp::items::join_parts(elem, answer);
                            auto elem_decl = crate::emit::cpp::templates::cpp_elem_decl(includes(Text::lit("decl"), append(prism_rtl::deref(model_1).elem_complete, prism_rtl::deref(model_1).elem_declared)), crate::syntax::lexer::chars::join(prism_rtl::deref(both_).forward, Text::lit("\n\n")), crate::emit::cpp::prelude::cpp_prelude_rows(Text::lit("")));
                            auto elem_types = crate::emit::cpp::templates::cpp_elem_types(crate::syntax::lexer::chars::join(filter(Array(std::vector{includes(Text::lit("types"), prism_rtl::deref(model_1).elem_complete), includes(Text::lit("decl"), prism_rtl::deref(model_1).elem_declared)}), [&](const Text& t) { return t != Text::lit(""); }), Text::lit("\n")), crate::syntax::lexer::chars::join(each(prism_rtl::deref(both_).values, [&](const crate::emit::cpp::items::ValueDecl& v_) { return v_->text; }), Text::lit("\n\n")));
                            auto pairs = each(crate::check::errors::range0(len(prism_rtl::deref(model_1).mods)), [&](const Nat& i) { return std::tuple{or_(index(prism_rtl::deref(model_1).mods, i), no_mod()), or_(index(mods, i), crate::emit::cpp::items::no_parts())}; });
                            auto generics = fold(pairs, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>& _p1) {
                                auto&& m = std::get<0>(_p1);
                                auto&& p_ = std::get<1>(_p1);
                                return len(prism_rtl::deref(p_).generic) > Nat(0u)
                                    ? crate::prelude::push(acc, prism_rtl::deref(m).name)
                                    : acc;
                            });
                            call_value(each_job(pairs, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, Text>>, Array<Piece>>>(std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>)>>(prism_rtl::rc([=](std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts> p0) {
                            return entered(once_job([=]() {
                                return ({
                                    auto [m, p_] = p0;
                                    (prism_rtl::more(prism_rtl::rc(ModuleFiles(m, p_))));
                                });
                            }));
                        }))), [=, checks = std::move(checks), script_list = std::move(script_list), world = std::move(world), canvas_4 = std::move(canvas_4), run_root = std::move(run_root), elem_decl = std::move(elem_decl), elem_types = std::move(elem_types), generics = std::move(generics)](Array<std::tuple<Array<std::tuple<Text, Text>>, Array<Piece>>> each_12547) {
                            return ({
                                auto per_module = each_12547;
                                auto pieces = fold(per_module, Array<Piece>{}, [&](const Array<Piece>& acc, const std::tuple<Array<std::tuple<Text, Text>>, Array<Piece>>& _p1) {
                                    auto&& ps = std::get<1>(_p1);
                                    return append(acc, ps);
                                });
                                auto units_ = units(pieces);
                                auto unit_files = each(crate::check::errors::range0(len(units_)), [&](const Nat& k) { return unit_file(k, or_(index(units_, k), Array<Piece>{}), generics); });
                                auto main_includes = crate::syntax::lexer::chars::join(append(append(Array(std::vector{Text::lit("#include \"elem.types.hpp\"")}), Array(std::vector{includes(Text::lit(""), each(prism_rtl::deref(model_1).mods, [&](const crate::lower::model::ModDef& m) { return prism_rtl::deref(m).name; }))})), Array(std::vector{includes(Text::lit("generic"), generics)})), Text::lit("\n"));
                                auto canvas_include = canvas_4
                                    ? crate::emit::cpp::templates::cpp_canvas_include(Text::lit(""))
                                    : Text::lit("");
                                auto main = crate::emit::cpp::templates::cpp_main(prism_rtl::deref(model_1).name, prism_rtl::cat("#include \"programs.hpp\"\n", canvas_include), regs, checks, script_list, world, run_root, crate::syntax::lexer::chars::join(crate::emit::cpp::patterns::concat2(each(Array(std::vector{elem, answer}), [&](const crate::emit::cpp::items::Parts& p_) { return prism_rtl::deref(p_).defs; })), Text::lit("\n\n")));
                                call_value(each_job(filter(prism_rtl::deref(model_1).mods, [&](const crate::lower::model::ModDef& m) { return (len(prism_rtl::deref(m).types_with) > Nat(1u)) && (or_(index(prism_rtl::deref(m).types_with, Nat(0u)), Text::lit("")) == prism_rtl::deref(m).name); }), ({
                                auto pairs_5 = pairs;
                                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text>>(crate::lower::model::ModDef)>>(prism_rtl::rc([=, pairs_5 = std::move(pairs_5)](crate::lower::model::ModDef p0) {
                                return ({
                                    auto pairs_5_6 = pairs_5;
                                    entered(once_job([=, pairs_5_6 = std::move(pairs_5_6)]() {
                                    return ({
                                        auto m = p0;
                                        (prism_rtl::more(prism_rtl::rc(GroupTypesFile(pairs_5_6, prism_rtl::deref(m).types_with))));
                                    });
                                }));
                                });
                            }));
                            })), [=, per_module = std::move(per_module), unit_files = std::move(unit_files), main_includes = std::move(main_includes), main = std::move(main)](Array<std::tuple<Text, Text>> each_13227) {
                                return ({
                                    auto groups = each_13227;
                                    auto files = append(fold(per_module, Array<std::tuple<Text, Text>>{}, [&](const Array<std::tuple<Text, Text>>& acc, const std::tuple<Array<std::tuple<Text, Text>>, Array<Piece>>& _p1) {
                                        auto&& fs = std::get<0>(_p1);
                                        return append(acc, fs);
                                    }), unit_files);
                                    auto sources = crate::syntax::lexer::chars::join(filter(each(files, [&](const std::tuple<Text, Text>& _p0) {
                                        auto&& f = std::get<0>(_p0);
                                        return f;
                                    }), [&](const Text& f) { return crate::syntax::lexer::chars::contains(f, Text::lit(".cpp")); }), Text::lit(" "));
                                    (prism_rtl::finished(append(Array(std::vector{std::tuple{Text::lit("Makefile"), crate::emit::cpp::templates::cpp_makefile(prism_rtl::deref(model_1).name, runtime_2, sources, canvas_4
                                    ? crate::emit::cpp::templates::cpp_makefile_canvas(runtime_2)
                                    : Text::lit(""))}, std::tuple{Text::lit("src/elem.decl.hpp"), elem_decl}, std::tuple{Text::lit("src/elem.types.hpp"), elem_types}, std::tuple{Text::lit("src/programs.hpp"), crate::emit::cpp::templates::cpp_programs_header(prism_rtl::deref(model_1).name, main_includes, programs)}, std::tuple{Text::lit("src/main.cpp"), main}, std::tuple{Text::lit("src/prelude.hpp"), crate::emit::cpp::prelude::cpp_prelude_source(Text::lit(""))}}), append(groups, files))));
                                });
                            });
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start EmitCpp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Text, Text>>> start_emit_cpp(crate::lower::model::Model model, Text runtime, Array<Text> scripts) {
    return prism_rtl::make_rc<EmitCpp>(model, runtime, scripts);
}


/// let noMod
crate::lower::model::ModDef no_mod() {
    return crate::lower::model::ModDef{.name = Text::lit(""), .prism = Text::lit(""), .path_ = Text::lit(""), .uses = Array<Text>{}, .complete = Array<Text>{}, .declared = Array<Text>{}, .types_with = Array<Text>{}, .items = Array<crate::lower::model::Item>{}};
}


/// GroupTypesFile: unbounded fn [((ModDef, Parts))], [Text] -> ((Text, Text))
std::tuple<Text, Text> group_types_file(const Array<std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>>& pairs, const Array<Text>& group) {
    auto members = filter(pairs, [&](const std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>& _p0) {
        auto&& m = std::get<0>(_p0);
        return among(group, prism_rtl::deref(m).name);
    });
    auto p_ = fold(members, crate::emit::cpp::items::no_parts(), [&](const crate::emit::cpp::items::Parts& acc, const std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>& _p1) {
        auto&& q = std::get<1>(_p1);
        return crate::emit::cpp::items::join_parts(acc, q);
    });
    auto complete = fold(members, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>& _p1) {
        auto&& m = std::get<0>(_p1);
        return fold(prism_rtl::deref(m).complete, acc, [&](const Array<Text>& a, const Text& n) { return among(a, n) || among(group, n) ? a : crate::prelude::push(a, n); });
    });
    auto declared_ = fold(members, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>& _p1) {
        auto&& m = std::get<0>(_p1);
        return fold(prism_rtl::deref(m).declared, acc, [&](const Array<Text>& a, const Text& n) {
            return (among(a, n) || among(group, n)) || among(complete, n)
                ? a
                : crate::prelude::push(a, n);
        });
    });
    auto title = prism_rtl::cat("The modules ", crate::syntax::lexer::chars::join(each(group, [&](const Text& n) { return prism_rtl::cat("`", n, "`"); }), Text::lit(", ")));
    return std::tuple{prism_rtl::cat("src/", group_name(group), ".types.hpp"), types_header(title, group, declared_, complete, p_)};
}


prism_rtl::Turn<std::tuple<Text, Text>> GroupTypesFile::cycle() const {
    const auto& pairs = this->pairs;
    const auto& group = this->group;
    auto members = filter(pairs, [&](const std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>& _p0) {
        auto&& m = std::get<0>(_p0);
        return among(group, prism_rtl::deref(m).name);
    });
    auto p_ = fold(members, crate::emit::cpp::items::no_parts(), [&](const crate::emit::cpp::items::Parts& acc, const std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>& _p1) {
        auto&& q = std::get<1>(_p1);
        return crate::emit::cpp::items::join_parts(acc, q);
    });
    auto complete = fold(members, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>& _p1) {
        auto&& m = std::get<0>(_p1);
        return fold(prism_rtl::deref(m).complete, acc, [&](const Array<Text>& a, const Text& n) { return among(a, n) || among(group, n) ? a : crate::prelude::push(a, n); });
    });
    auto declared_ = fold(members, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>& _p1) {
        auto&& m = std::get<0>(_p1);
        return fold(prism_rtl::deref(m).declared, acc, [&](const Array<Text>& a, const Text& n) {
            return (among(a, n) || among(group, n)) || among(complete, n)
                ? a
                : crate::prelude::push(a, n);
        });
    });
    auto title = prism_rtl::cat("The modules ", crate::syntax::lexer::chars::join(each(group, [&](const Text& n) { return prism_rtl::cat("`", n, "`"); }), Text::lit(", ")));
    auto group_1 = group;
    return call_then(start_types_header(title, group_1, declared_, complete, p_), [=](Text types_header_14897) { return prism_rtl::finished(std::tuple{prism_rtl::cat("src/", group_name(group_1), ".types.hpp"), types_header_14897}); });
}


/// `Start GroupTypesFile, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, Text>> start_group_types_file(Array<std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>> pairs, Array<Text> group) {
    return prism_rtl::make_rc<GroupTypesFile>(pairs, group);
}


/// GroupName: fn [Text] -> Text
Text group_name(const Array<Text>& group) {
    return crate::syntax::lexer::chars::join(each(group, [&](const Text& n) { return crate::syntax::lexer::chars::join(split_on(n, Text::lit("::")), Text::lit("_")); }), Text::lit("-"));
}


/// ModDir: fn Text -> Text
Text mod_dir(const Text& m) {
    return crate::syntax::lexer::chars::join(split_on(m, Text::lit("::")), Text::lit("/"));
}


/// Among: fn [Text], Text -> Bool
bool among(const Array<Text>& xs, const Text& x) {
    return fold(xs, false, [&](const bool& f, const Text& y) { return prism_rtl::deref(f) || (y == x); });
}


/// TypesHeader: unbounded fn Text, [Text], [Text], [Text], Parts -> Text
Text types_header(const Text& title, const Array<Text>& members, const Array<Text>& declared_, const Array<Text>& complete, const crate::emit::cpp::items::Parts& p_) {
    auto holds_elem = fold(p_.values, false, [&](const bool& f, const crate::emit::cpp::items::ValueDecl& v_) { return prism_rtl::deref(f) || fold(prism_rtl::deref(v_).deps, false, [&](const bool& g, const Text& d) { return (prism_rtl::deref(g) || (d == Text::lit("Elem"))) || (d == Text::lit("Answer")); }); });
    auto elem_1 = std::move(holds_elem)
        ? Text::lit("#include \"elem.types.hpp\"")
        : Text::lit("#include \"elem.decl.hpp\"");
    auto includes_ = crate::syntax::lexer::chars::join(filter(Array(std::vector{includes(Text::lit("decl"), members), elem_1, includes(Text::lit("decl"), declared_), includes(Text::lit("types"), complete)}), [&](const Text& t) { return t != Text::lit(""); }), Text::lit("\n"));
    auto values_ = crate::syntax::lexer::chars::join(order_values(p_.values, fold(p_.values, Map<Text, bool>{}, [&](const Map<Text, bool>& acc, const crate::emit::cpp::items::ValueDecl& v_) { return insert(acc, v_->path_, false); }), Array<Text>{}), Text::lit("\n\n"));
    return crate::emit::cpp::templates::cpp_types_header(title, includes_, values_);
}


prism_rtl::Turn<Text> TypesHeader::cycle() const {
    const auto& title = this->title;
    const auto& members = this->members;
    const auto& declared_ = this->declared_;
    const auto& complete = this->complete;
    const auto& p_ = this->p_;
    auto holds_elem = fold(prism_rtl::deref(p_).values, false, [&](const bool& f, const crate::emit::cpp::items::ValueDecl& v_) { return prism_rtl::deref(f) || fold(prism_rtl::deref(v_).deps, false, [&](const bool& g, const Text& d) { return (prism_rtl::deref(g) || (d == Text::lit("Elem"))) || (d == Text::lit("Answer")); }); });
    auto elem_1 = std::move(holds_elem)
        ? Text::lit("#include \"elem.types.hpp\"")
        : Text::lit("#include \"elem.decl.hpp\"");
    auto includes_ = crate::syntax::lexer::chars::join(filter(Array(std::vector{includes(Text::lit("decl"), members), elem_1, includes(Text::lit("decl"), declared_), includes(Text::lit("types"), complete)}), [&](const Text& t) { return t != Text::lit(""); }), Text::lit("\n"));
    auto p__2 = p_;
    auto title_3 = title;
    return call_then(start_order_values(prism_rtl::deref(p__2).values, fold(prism_rtl::deref(p__2).values, Map<Text, bool>{}, [&](const Map<Text, bool>& acc, const crate::emit::cpp::items::ValueDecl& v_) { return insert(acc, v_->path_, false); }), Array<Text>{}), [=](Array<Text> order_values_16279) {
        return ({
            auto values_ = crate::syntax::lexer::chars::join(order_values_16279, Text::lit("\n\n"));
            (prism_rtl::finished(crate::emit::cpp::templates::cpp_types_header(title_3, includes_, values_)));
        });
    });
}


/// `Start TypesHeader, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_types_header(Text title, Array<Text> members, Array<Text> declared_, Array<Text> complete, crate::emit::cpp::items::Parts p_) {
    return prism_rtl::make_rc<TypesHeader>(title, members, declared_, complete, p_);
}


/// Includes: fn Text, [Text] -> Text
Text includes(const Text& layer, const Array<Text>& ms) {
    return crate::syntax::lexer::chars::join(each(ms, [&](const Text& m) { return prism_rtl::cat("#include <", mod_dir(m), "/", layer == Text::lit("") ? Text::lit("module") : layer, ".hpp>"); }), Text::lit("\n"));
}


/// Chunks: fn [Text] -> [ [Text] ]
Array<Array<Text>> chunks(const Array<Text>& defs) {
    auto [done, current, size_] = fold(defs, std::tuple{Array<Array<Text>>{}, Array<Text>{}, Nat(0u)}, [&](const std::tuple<Array<Array<Text>>, Array<Text>, Nat>& _p0, const Text& d) {
        auto&& acc = std::get<0>(_p0);
        auto&& cur = std::get<1>(_p0);
        auto&& n = std::get<2>(_p0);
        return (n > chunk_size()) && (len(cur) > Nat(0u))
            ? std::tuple{crate::prelude::push(acc, cur), Array(std::vector{d}), len_text(d)}
            : std::tuple{acc, crate::prelude::push(cur, d), n + len_text(d)};
    });
    return (len(current) == Nat(0u)) && (len(done) > Nat(0u))
        ? done
        : crate::prelude::push(done, current);
}


/// let chunkSize
Nat chunk_size() {
    return Nat(250000u);
}


/// ModuleFiles: unbounded fn ModDef, Parts -> (([((Text, Text))], [Piece]))
std::tuple<Array<std::tuple<Text, Text>>, Array<Piece>> module_files(const crate::lower::model::ModDef& m, const crate::emit::cpp::items::Parts& p_) {
    auto title = m.prism == Text::lit("")
        ? Text::lit("The root module")
        : prism_rtl::cat("The module `", m.prism, "`");
    auto needed = append(m.complete, m.declared);
    auto decl = crate::emit::cpp::templates::cpp_decl_header(title, Text::lit(""), crate::syntax::lexer::chars::join(p_.forward, Text::lit("\n\n")));
    auto types = len(m.types_with) > Nat(1u)
        ? crate::emit::cpp::templates::cpp_types_in_group(title, group_name(m.types_with))
        : types_header(title, Array(std::vector{m.name}), m.declared, m.complete, p_);
    auto head_includes = crate::syntax::lexer::chars::join(filter(Array(std::vector{prism_rtl::cat(includes(Text::lit("types"), Array(std::vector{m.name})), "\n#include \"elem.types.hpp\""), includes(Text::lit("types"), needed)}), [&](const Text& t) { return t != Text::lit(""); }), Text::lit("\n"));
    auto head = crate::emit::cpp::templates::cpp_mod_header(title, head_includes, crate::syntax::lexer::chars::join(p_.protos, Text::lit("\n")), crate::syntax::lexer::chars::join(p_.outer, Text::lit("\n\n")), crate::syntax::lexer::chars::join(p_.classes, Text::lit("\n\n")));
    auto with_mine = append(Array(std::vector{m.name}), needed);
    auto generic_1 = len(p_.generic) == Nat(0u)
        ? Array<std::tuple<Text, Text>>{}
        : Array(std::vector{std::tuple{prism_rtl::cat("src/", mod_dir(m.name), "/generic.hpp"), crate::emit::cpp::templates::cpp_generic_header(title, includes(Text::lit(""), with_mine), crate::syntax::lexer::chars::join(p_.generic, Text::lit("\n\n")))}});
    auto chunks_ = len(p_.defs) == Nat(0u) ? Array<Array<Text>>{} : chunks(p_.defs);
    auto pieces = each(chunks_, [&](const Array<Text>& c) { return Piece{.title = title, .prism = m.prism, .path_ = m.path_, .ns = m.name, .needs = with_mine, .defs = crate::syntax::lexer::chars::join(c, Text::lit("\n\n"))}; });
    auto dir = mod_dir(m.name);
    return std::tuple{append(Array(std::vector{std::tuple{prism_rtl::cat("src/", dir, "/decl.hpp"), decl}, std::tuple{prism_rtl::cat("src/", dir, "/types.hpp"), types}, std::tuple{prism_rtl::cat("src/", dir, "/module.hpp"), head}}), generic_1), pieces};
}


prism_rtl::Turn<std::tuple<Array<std::tuple<Text, Text>>, Array<Piece>>> ModuleFiles::cycle() const {
    const auto& m = this->m;
    const auto& p_ = this->p_;
    auto title = prism_rtl::deref(m).prism == Text::lit("")
        ? Text::lit("The root module")
        : prism_rtl::cat("The module `", prism_rtl::deref(m).prism, "`");
    auto needed = append(prism_rtl::deref(m).complete, prism_rtl::deref(m).declared);
    auto decl = crate::emit::cpp::templates::cpp_decl_header(title, Text::lit(""), crate::syntax::lexer::chars::join(prism_rtl::deref(p_).forward, Text::lit("\n\n")));
    auto types = len(prism_rtl::deref(m).types_with) > Nat(1u)
        ? crate::emit::cpp::templates::cpp_types_in_group(title, group_name(prism_rtl::deref(m).types_with))
        : types_header(title, Array(std::vector{prism_rtl::deref(m).name}), prism_rtl::deref(m).declared, prism_rtl::deref(m).complete, p_);
    auto head_includes = crate::syntax::lexer::chars::join(filter(Array(std::vector{prism_rtl::cat(includes(Text::lit("types"), Array(std::vector{prism_rtl::deref(m).name})), "\n#include \"elem.types.hpp\""), includes(Text::lit("types"), needed)}), [&](const Text& t) { return t != Text::lit(""); }), Text::lit("\n"));
    auto head = crate::emit::cpp::templates::cpp_mod_header(title, head_includes, crate::syntax::lexer::chars::join(prism_rtl::deref(p_).protos, Text::lit("\n")), crate::syntax::lexer::chars::join(prism_rtl::deref(p_).outer, Text::lit("\n\n")), crate::syntax::lexer::chars::join(prism_rtl::deref(p_).classes, Text::lit("\n\n")));
    auto with_mine = append(Array(std::vector{prism_rtl::deref(m).name}), needed);
    auto generic_1 = len(prism_rtl::deref(p_).generic) == Nat(0u)
        ? Array<std::tuple<Text, Text>>{}
        : Array(std::vector{std::tuple{prism_rtl::cat("src/", mod_dir(prism_rtl::deref(m).name), "/generic.hpp"), crate::emit::cpp::templates::cpp_generic_header(title, includes(Text::lit(""), with_mine), crate::syntax::lexer::chars::join(prism_rtl::deref(p_).generic, Text::lit("\n\n")))}});
    auto chunks_ = len(prism_rtl::deref(p_).defs) == Nat(0u)
        ? Array<Array<Text>>{}
        : chunks(prism_rtl::deref(p_).defs);
    auto pieces = each(chunks_, [&](const Array<Text>& c) { return Piece{.title = title, .prism = prism_rtl::deref(m).prism, .path_ = m->path_, .ns = prism_rtl::deref(m).name, .needs = with_mine, .defs = crate::syntax::lexer::chars::join(c, Text::lit("\n\n"))}; });
    auto dir = mod_dir(prism_rtl::deref(m).name);
    return prism_rtl::finished(std::tuple{append(Array(std::vector{std::tuple{prism_rtl::cat("src/", dir, "/decl.hpp"), decl}, std::tuple{prism_rtl::cat("src/", dir, "/types.hpp"), types}, std::tuple{prism_rtl::cat("src/", dir, "/module.hpp"), head}}), generic_1), pieces});
}


/// `Start ModuleFiles, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, Text>>, Array<Piece>>> start_module_files(crate::lower::model::ModDef m, crate::emit::cpp::items::Parts p_) {
    return prism_rtl::make_rc<ModuleFiles>(m, p_);
}


/// Units: fn [Piece] -> [ [Piece] ]
Array<Array<Piece>> units(const Array<Piece>& pieces) {
    auto [done, current, size_] = fold(pieces, std::tuple{Array<Array<Piece>>{}, Array<Piece>{}, Nat(0u)}, [&](const std::tuple<Array<Array<Piece>>, Array<Piece>, Nat>& _p0, const Piece& pc) {
        auto&& acc = std::get<0>(_p0);
        auto&& cur = std::get<1>(_p0);
        auto&& n = std::get<2>(_p0);
        return (len(cur) > Nat(0u)) && ((n + len_text(prism_rtl::deref(pc).defs)) > unit_size())
            ? std::tuple{crate::prelude::push(acc, cur), Array(std::vector{pc}), len_text(prism_rtl::deref(pc).defs)}
            : std::tuple{acc, crate::prelude::push(cur, pc), n + len_text(prism_rtl::deref(pc).defs)};
    });
    return len(current) == Nat(0u) ? done : crate::prelude::push(done, current);
}


/// let unitSize
Nat unit_size() {
    return Nat(125000u);
}


/// UnitFile: fn Nat, [Piece], [Text] -> ((Text, Text))
std::tuple<Text, Text> unit_file(const Nat& k, const Array<Piece>& pieces, const Array<Text>& generics) {
    auto needs = fold(pieces, Array<Text>{}, [&](const Array<Text>& acc, const Piece& pc) { return fold(prism_rtl::deref(pc).needs, acc, [&](const Array<Text>& a, const Text& n) { return among(a, n) ? a : crate::prelude::push(a, n); }); });
    auto includes_ = crate::syntax::lexer::chars::join(filter(Array(std::vector{includes(Text::lit(""), needs), includes(Text::lit("generic"), filter(needs, [&](const Text& n) { return among(generics, n); }))}), [&](const Text& t) { return t != Text::lit(""); }), Text::lit("\n"));
    auto names = fold(pieces, Array<Text>{}, [&](const Array<Text>& acc, const Piece& pc) {
        return among(acc, prism_rtl::deref(pc).prism)
            ? acc
            : crate::prelude::push(acc, prism_rtl::deref(pc).prism);
    });
    auto title = len(names) == Nat(1u)
        ? prism_rtl::deref(or_(index(pieces, Nat(0u)), dummy_piece())).title
        : prism_rtl::cat("The modules ", crate::syntax::lexer::chars::join(each(names, [&](const Text& n) { return n == Text::lit("") ? Text::lit("the root") : prism_rtl::cat("`", n, "`"); }), Text::lit(", ")));
    auto parts = crate::syntax::lexer::chars::join(each(pieces, [&](const Piece& pc) { return crate::emit::cpp::templates::cpp_unit_part(prism_rtl::deref(pc).title, pc->path_, prism_rtl::deref(pc).ns, prism_rtl::deref(pc).defs); }), Text::lit("\n\n"));
    return std::tuple{prism_rtl::cat("src/unit_", k + Nat(1u), ".cpp"), crate::emit::cpp::templates::cpp_unit(title, includes_, parts)};
}


/// let dummyPiece
Piece dummy_piece() {
    return Piece{.title = Text::lit(""), .prism = Text::lit(""), .path_ = Text::lit(""), .ns = Text::lit(""), .needs = Array<Text>{}, .defs = Text::lit("")};
}


/// AllProgramsCpp: fn Model -> [ProgDef]
Array<crate::lower::model::ProgDef> all_programs_cpp(const crate::lower::model::Model& model) {
    auto&& _m = model.root;
    if (prism_rtl::is_some(_m)) {
        auto&& r = prism_rtl::some_of(_m);
        return fold(model.programs, false, [&](const bool& f, const crate::lower::model::ProgDef& p_) { return prism_rtl::deref(f) || (prism_rtl::deref(p_).name == prism_rtl::deref(r).name); })
            ? model.programs
            : crate::prelude::push(model.programs, r);
    }
    if (prism_rtl::is_none(_m)) {
        return model.programs;
    }
    prism_rtl::unreachable("no arm matched");
}


/// OrderValues: unbounded fn [ValueDecl], (Text ==> Bool), [Text] -> [Text]
Array<Text> order_values(const Array<crate::emit::cpp::items::ValueDecl>& left, const Map<Text, bool>& done, const Array<Text>& acc) {
    auto ready = filter(left, [&](const crate::emit::cpp::items::ValueDecl& v_) { return fold(prism_rtl::deref(v_).deps, true, [&](const bool& ok_, const Text& d) { return prism_rtl::deref(ok_) && ((d == v_->path_) || declared(done, d)); }); });
    return len(left) == Nat(0u)
        ? acc
        : len(ready) == Nat(0u)
        ? append(acc, each(left, [&](const crate::emit::cpp::items::ValueDecl& v_) { return v_->text; }))
        : ({
        auto later_ = filter(left, [&](const crate::emit::cpp::items::ValueDecl& v_) { return !fold(prism_rtl::deref(v_).deps, true, [&](const bool& ok_, const Text& d) { return prism_rtl::deref(ok_) && ((d == v_->path_) || declared(done, d)); }); });
        auto done2 = fold(ready, done, [&](const Map<Text, bool>& m, const crate::emit::cpp::items::ValueDecl& v_) { return insert(m, v_->path_, true); });
        order_values(later_, done2, append(acc, each(ready, [&](const crate::emit::cpp::items::ValueDecl& v_) { return v_->text; })));
    });
}


prism_rtl::Turn<Array<Text>> OrderValues::cycle() const {
    const auto& left = this->left;
    const auto& done = this->done;
    const auto& acc = this->acc;
    auto ready = filter(left, [&](const crate::emit::cpp::items::ValueDecl& v_) { return fold(prism_rtl::deref(v_).deps, true, [&](const bool& ok_, const Text& d) { return prism_rtl::deref(ok_) && ((d == v_->path_) || declared(done, d)); }); });
    return len(left) == Nat(0u)
        ? prism_rtl::finished(acc)
        : len(ready) == Nat(0u)
        ? prism_rtl::finished(append(acc, each(left, [&](const crate::emit::cpp::items::ValueDecl& v_) { return v_->text; })))
        : ({
        auto later_ = filter(left, [&](const crate::emit::cpp::items::ValueDecl& v_) { return !fold(prism_rtl::deref(v_).deps, true, [&](const bool& ok_, const Text& d) { return prism_rtl::deref(ok_) && ((d == v_->path_) || declared(done, d)); }); });
        auto done2 = fold(ready, done, [&](const Map<Text, bool>& m, const crate::emit::cpp::items::ValueDecl& v_) { return insert(m, v_->path_, true); });
        (prism_rtl::more(prism_rtl::rc(OrderValues(later_, done2, append(acc, each(ready, [&](const crate::emit::cpp::items::ValueDecl& v_) { return v_->text; }))))));
    });
}


/// `Start OrderValues, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_order_values(Array<crate::emit::cpp::items::ValueDecl> left, Map<Text, bool> done, Array<Text> acc) {
    return prism_rtl::make_rc<OrderValues>(left, done, acc);
}


/// Declared: fn (Text ==> Bool), Text -> Bool
bool declared(const Map<Text, bool>& done, const Text& d) {
    auto&& _m = crate::prelude::get(done, d);
    if (prism_rtl::is_some(_m)) {
        auto&& b = prism_rtl::some_of(_m);
        return b;
    }
    if (prism_rtl::is_none(_m)) {
        return true;
    }
    prism_rtl::unreachable("no arm matched");
}

}  // namespace crate::emit::cpp::program
