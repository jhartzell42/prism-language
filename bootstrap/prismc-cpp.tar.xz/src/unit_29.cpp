// The module `Check.Types.Recording`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/types/recording/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Types.Recording`, from `target/bootstrap/cpp-src/prismc/check/types/recording.prism`.
namespace crate::check::types::recording {

/// AtHere: fn St, Range -> SrcAt
crate::check::typed::SrcAt at_here(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1) {
    return crate::check::typed::SrcAt{.file = st_p0.file, .span = span_p1};
}


/// NoteTy: fn St, Range, Ty -> St
crate::check::types::St note_ty(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const crate::check::types::Ty& t_p2) {
    return !st_p0.recording
        ? st_p0
        : ({
        crate::check::types::St this_ = st_p0;
        prism_rtl::deref(this_.typed).exprs = crate::prelude::push(prism_rtl::deref(this_.typed).exprs, crate::check::typed::TyNote{.at = at_here(st_p0, span_p1), .ty = t_p2});
        (std::move(this_));
    });
}


/// NoteBinder: fn St, Range, Text, Ty -> St
crate::check::types::St note_binder(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const Text& name_p2, const crate::check::types::Ty& t_p3) {
    return !st_p0.recording
        ? st_p0
        : ({
        crate::check::types::St this_ = st_p0;
        prism_rtl::deref(this_.typed).binders = crate::prelude::push(prism_rtl::deref(this_.typed).binders, crate::check::typed::BinderNote{.at = at_here(st_p0, span_p1), .name = name_p2, .ty = t_p3});
        (std::move(this_));
    });
}


/// NoteLocal: fn St, Range, Nat -> St
crate::check::types::St note_local(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const Nat& id_p2) {
    return !st_p0.recording
        ? st_p0
        : ({
        crate::check::types::St this_ = st_p0;
        prism_rtl::deref(this_.typed).locals = crate::prelude::push(prism_rtl::deref(this_.typed).locals, crate::check::typed::LocalNote{.at = at_here(st_p0, span_p1), .id = id_p2});
        (std::move(this_));
    });
}


/// NoteUse: fn St, Range, Nat -> St
crate::check::types::St note_use(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const Nat& id_p2) {
    return !st_p0.recording
        ? st_p0
        : ({
        crate::check::types::St this_ = st_p0;
        prism_rtl::deref(this_.typed).uses = crate::prelude::push(prism_rtl::deref(this_.typed).uses, crate::check::typed::LocalNote{.at = at_here(st_p0, span_p1), .id = id_p2});
        (std::move(this_));
    });
}


/// NoteGen: fn St, Range, Text, Scheme -> St
crate::check::types::St note_gen(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const Text& name_p2, const crate::check::types::Scheme& sc_p3) {
    return (!st_p0.recording) || ((len(sc_p3.qs) == Nat(0u)) && (len(sc_p3.cqs) == Nat(0u)))
        ? st_p0
        : ({
        crate::check::types::St this_ = st_p0;
        prism_rtl::deref(this_.typed).gens = crate::prelude::push(prism_rtl::deref(this_.typed).gens, crate::check::typed::GenNote{.at = at_here(st_p0, span_p1), .name = name_p2, .tys = sc_p3.qs, .cols = sc_p3.cqs});
        (std::move(this_));
    });
}


/// NoteInst: fn St, Range, Text, Scheme, Inst -> St
crate::check::types::St note_inst(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const Text& name_p2, const crate::check::types::Scheme& sc_p3, const crate::check::types::schemes::Inst& inst_p4) {
    return !st_p0.recording
        ? st_p0
        : ({
        crate::check::types::St this_ = st_p0;
        prism_rtl::deref(this_.typed).insts = crate::prelude::push(prism_rtl::deref(this_.typed).insts, crate::check::typed::InstNote{.at = at_here(st_p0, span_p1), .name = name_p2, .tys = each(sc_p3.qs, [&](const Text& q_p5) { return std::tuple{q_p5, or_(crate::prelude::get(inst_p4.tys, q_p5), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))}; }), .cols = each(sc_p3.cqs, [&](const Text& q_p6) { return std::tuple{q_p6, or_(crate::prelude::get(inst_p4.cols, q_p6), crate::check::types::Col(crate::check::types::Col::CBound{}))}; })});
        (std::move(this_));
    });
}


/// NoteApp: fn St, Range, Text, Text, Text, [Nat], Text, Col -> St
crate::check::types::St note_app(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const Text& callee_p2, const Text& kind_p3, const Text& layer_p4, const Array<Nat>& lifted_p5, const Text& inner_p6, const crate::check::types::Col& col_p7) {
    return !st_p0.recording
        ? st_p0
        : ({
        crate::check::types::St this_ = st_p0;
        prism_rtl::deref(this_.typed).apps = crate::prelude::push(prism_rtl::deref(this_.typed).apps, crate::check::typed::AppNote{.at = at_here(st_p0, span_p1), .callee = callee_p2, .kind = kind_p3, .layer = layer_p4, .lifted = lifted_p5, .inner = inner_p6, .color = col_p7});
        (std::move(this_));
    });
}


/// NoteLift: fn St, Range, Text, [Range] -> St
crate::check::types::St note_lift(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const Text& sigil_p2, const Array<crate::syntax::Range>& operands_p3) {
    return (!st_p0.recording) || (len(operands_p3) == Nat(0u))
        ? st_p0
        : ({
        crate::check::types::St this_ = st_p0;
        prism_rtl::deref(this_.typed).lifts = crate::prelude::push(prism_rtl::deref(this_.typed).lifts, crate::check::typed::LiftNote{.at = at_here(st_p0, span_p1), .sigil = sigil_p2, .operands = operands_p3});
        (std::move(this_));
    });
}


/// NoteFn: fn St, Range, Text, Col, Col -> St
crate::check::types::St note_fn(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const Text& name_p2, const crate::check::types::Col& declared_p3, const crate::check::types::Col& body_p4) {
    return !st_p0.recording
        ? st_p0
        : ({
        crate::check::types::St this_ = st_p0;
        prism_rtl::deref(this_.typed).fns = crate::prelude::push(prism_rtl::deref(this_.typed).fns, crate::check::typed::FnNote{.at = at_here(st_p0, span_p1), .name = name_p2, .declared = declared_p3, .body = body_p4});
        (std::move(this_));
    });
}


/// NoteImpl: fn St, Nat, Range, Text, Ty, Text -> St
crate::check::types::St note_impl(const crate::check::types::St& st_p0, const Nat& file_p1, const crate::syntax::Range& span_p2, const Text& cls_p3, const crate::check::types::Ty& t_p4, const Text& how_p5) {
    return (((!st_p0.recording) || crate::syntax::lexer::chars::has_prefix(cls_p3, Text::lit("Range "))) || (cls_p3 == Text::lit("Prelude.Sub"))) || (cls_p3 == Text::lit("Prelude.Signed"))
        ? st_p0
        : ({
        crate::check::types::St this_ = st_p0;
        prism_rtl::deref(this_.typed).impls = crate::prelude::push(prism_rtl::deref(this_.typed).impls, crate::check::typed::ImplNote{.at = crate::check::typed::SrcAt{.file = file_p1, .span = span_p2}, .cls = cls_p3, .ty = t_p4, .how = how_p5});
        (std::move(this_));
    });
}


/// NoteChoice: fn St, Nat, Range, Text, Text -> St
crate::check::types::St note_choice(const crate::check::types::St& st_p0, const Nat& file_p1, const crate::syntax::Range& span_p2, const Text& cls_p3, const Text& ch_p4) {
    auto k_p5 = choice_key(file_p1, span_p2, cls_p3);
    return (crate::syntax::lexer::chars::has_prefix(cls_p3, Text::lit("Range ")) || (cls_p3 == Text::lit("Prelude.Sub"))) || (cls_p3 == Text::lit("Prelude.Signed"))
        ? st_p0
        : ({
        crate::check::types::St this_ = st_p0;
        this_.choices = insert(this_.choices, k_p5, crate::check::types::add_text(or_(crate::prelude::get(this_.choices, k_p5), Array<Text>{}), ch_p4));
        (std::move(this_));
    });
}


/// NoteSizeTy: fn St, Range, Ty -> St
crate::check::types::St note_size_ty(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const crate::check::types::Ty& t_p2) {
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p2)) {
        auto&& ps_p3 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p2).a1;
        auto&& _m = index(ps_p3, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& p_p4 = prism_rtl::some_of(_m);
            crate::check::types::St this_ = st_p0;
            this_.size_tys = insert(this_.size_tys, prism_rtl::cat(st_p0.file, ":", span_p1.start, ":", span_p1.end), p_p4);
            return this_;
        }
        if (prism_rtl::is_none(_m)) {
            return st_p0;
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        return st_p0;
    }
}


/// ChoiceKey: fn Nat, Range, Text -> Text
Text choice_key(const Nat& file_p0, const crate::syntax::Range& span_p1, const Text& cls_p2) {
    return prism_rtl::cat(file_p0, ":", span_p1.start, ":", span_p1.end, ":", cls_p2);
}


/// NoteMethod: fn St, Range, Text, Text -> St
crate::check::types::St note_method(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const Text& method_p2, const Text& cls_p3) {
    return !st_p0.recording
        ? st_p0
        : ({
        crate::check::types::St this_ = st_p0;
        prism_rtl::deref(this_.typed).methods = crate::prelude::push(prism_rtl::deref(this_.typed).methods, crate::check::typed::MethodNote{.at = at_here(st_p0, span_p1), .method = method_p2, .cls = cls_p3});
        (std::move(this_));
    });
}


/// NoteGroup: fn St, Range, Text, [ [Nat] ] -> St
crate::check::types::St note_group(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const Text& kind_p2, const Array<Array<Nat>>& order_p3) {
    return !st_p0.recording
        ? st_p0
        : ({
        crate::check::types::St this_ = st_p0;
        prism_rtl::deref(this_.typed).groups = crate::prelude::push(prism_rtl::deref(this_.typed).groups, crate::check::typed::GroupNote{.at = at_here(st_p0, span_p1), .kind = kind_p2, .order = order_p3});
        (std::move(this_));
    });
}


/// ZonkTyped: unbounded fn St -> TProgram
crate::check::typed::TProgram zonk_typed(const crate::check::types::St& st_p0) {
    auto t_p1 = st_p0.typed;
    crate::check::typed::TProgram this_ = t_p1;
    this_.exprs = run_to_end(each_job(this_.exprs, ({
        auto st_p0_1 = st_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::typed::TyNote>(crate::check::typed::TyNote)>>(prism_rtl::rc([=, st_p0_1 = std::move(st_p0_1)](crate::check::typed::TyNote p0) {
        return ({
            auto st_p0_1_2 = st_p0_1;
            entered(once_job([=, st_p0_1_2 = std::move(st_p0_1_2)]() {
            return ({
                auto n_p2 = p0;
                call_then(start_resolve_ty(st_p0_1_2, prism_rtl::deref(n_p2).ty), [=](crate::check::types::Ty resolve_ty_5873) { return prism_rtl::finished(crate::check::typed::TyNote{.at = prism_rtl::deref(n_p2).at, .ty = resolve_ty_5873}); });
            });
        }));
        });
    })));
    })));
    this_.binders = run_to_end(each_job(this_.binders, ({
        auto st_p0_1 = st_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::typed::BinderNote>(crate::check::typed::BinderNote)>>(prism_rtl::rc([=, st_p0_1 = std::move(st_p0_1)](crate::check::typed::BinderNote p0) {
        return ({
            auto st_p0_1_2 = st_p0_1;
            entered(once_job([=, st_p0_1_2 = std::move(st_p0_1_2)]() {
            return ({
                auto n_p3 = p0;
                call_then(start_resolve_ty(st_p0_1_2, prism_rtl::deref(n_p3).ty), [=](crate::check::types::Ty resolve_ty_5975) { return prism_rtl::finished(crate::check::typed::BinderNote{.at = prism_rtl::deref(n_p3).at, .name = prism_rtl::deref(n_p3).name, .ty = resolve_ty_5975}); });
            });
        }));
        });
    })));
    })));
    this_.insts = run_to_end(each_job(this_.insts, ({
        auto st_p0_1 = st_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::typed::InstNote>(crate::check::typed::InstNote)>>(prism_rtl::rc([=, st_p0_1 = std::move(st_p0_1)](crate::check::typed::InstNote p0) {
        return ({
            auto st_p0_1_2 = st_p0_1;
            entered(once_job([=, st_p0_1_2 = std::move(st_p0_1_2)]() {
            return ({
                auto n_p4 = p0;
                call_value(each_job(prism_rtl::deref(n_p4).tys, ({
                auto st_p0_1_2_2 = st_p0_1_2;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::check::types::Ty>>(std::tuple<Text, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_p0_1_2_2 = std::move(st_p0_1_2_2)](std::tuple<Text, crate::check::types::Ty> p0) {
                return ({
                    auto st_p0_1_2_2_2 = st_p0_1_2_2;
                    entered(once_job([=, st_p0_1_2_2_2 = std::move(st_p0_1_2_2_2)]() {
                    return ({
                        auto [q_p5, x_p6] = p0;
                        call_then(start_resolve_ty(st_p0_1_2_2_2, x_p6), [=](crate::check::types::Ty resolve_ty_6102) { return prism_rtl::finished(std::tuple{q_p5, resolve_ty_6102}); });
                    });
                }));
                });
            }));
            })), [=](Array<std::tuple<Text, crate::check::types::Ty>> each_6072) {
                return call_value(each_job(prism_rtl::deref(n_p4).cols, ({
                    auto st_p0_1_2_2 = st_p0_1_2;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::check::types::Col>>(std::tuple<Text, crate::check::types::Col>)>>(prism_rtl::rc([=, st_p0_1_2_2 = std::move(st_p0_1_2_2)](std::tuple<Text, crate::check::types::Col> p0) {
                    return ({
                        auto st_p0_1_2_2_2 = st_p0_1_2_2;
                        entered(once_job([=, st_p0_1_2_2_2 = std::move(st_p0_1_2_2_2)]() {
                        return ({
                            auto [q_p7, c_p8] = p0;
                            call_then(start_resolve_col(st_p0_1_2_2_2, c_p8), [=](crate::check::types::Col resolve_col_6160) { return prism_rtl::finished(std::tuple{q_p7, resolve_col_6160}); });
                        });
                    }));
                    });
                }));
                })), [=](Array<std::tuple<Text, crate::check::types::Col>> each_6129) { return prism_rtl::finished(crate::check::typed::InstNote{.at = prism_rtl::deref(n_p4).at, .name = prism_rtl::deref(n_p4).name, .tys = each_6072, .cols = each_6129}); });
            });
            });
        }));
        });
    })));
    })));
    this_.impls = run_to_end(each_job(this_.impls, ({
        auto st_p0_1 = st_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::typed::ImplNote>(crate::check::typed::ImplNote)>>(prism_rtl::rc([=, st_p0_1 = std::move(st_p0_1)](crate::check::typed::ImplNote p0) {
        return ({
            auto st_p0_1_2 = st_p0_1;
            entered(once_job([=, st_p0_1_2 = std::move(st_p0_1_2)]() {
            return ({
                auto n_p9 = p0;
                call_then(start_resolve_ty(st_p0_1_2, prism_rtl::deref(n_p9).ty), [=](crate::check::types::Ty resolve_ty_6255) { return prism_rtl::finished(crate::check::typed::ImplNote{.at = prism_rtl::deref(n_p9).at, .cls = prism_rtl::deref(n_p9).cls, .ty = resolve_ty_6255, .how = prism_rtl::deref(n_p9).how}); });
            });
        }));
        });
    })));
    })));
    this_.apps = run_to_end(each_job(this_.apps, ({
        auto st_p0_1 = st_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::typed::AppNote>(crate::check::typed::AppNote)>>(prism_rtl::rc([=, st_p0_1 = std::move(st_p0_1)](crate::check::typed::AppNote p0) {
        return ({
            auto st_p0_1_2 = st_p0_1;
            entered(once_job([=, st_p0_1_2 = std::move(st_p0_1_2)]() {
            return ({
                auto n_pa = p0;
                call_then(start_resolve_col(st_p0_1_2, prism_rtl::deref(n_pa).color), [=](crate::check::types::Col resolve_col_6426) { return prism_rtl::finished(crate::check::typed::AppNote{.at = prism_rtl::deref(n_pa).at, .callee = prism_rtl::deref(n_pa).callee, .kind = prism_rtl::deref(n_pa).kind, .layer = prism_rtl::deref(n_pa).layer, .lifted = prism_rtl::deref(n_pa).lifted, .inner = prism_rtl::deref(n_pa).inner, .color = resolve_col_6426}); });
            });
        }));
        });
    })));
    })));
    this_.fns = run_to_end(each_job(this_.fns, ({
        auto st_p0_1 = st_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::typed::FnNote>(crate::check::typed::FnNote)>>(prism_rtl::rc([=, st_p0_1 = std::move(st_p0_1)](crate::check::typed::FnNote p0) {
        return ({
            auto st_p0_1_2 = st_p0_1;
            entered(once_job([=, st_p0_1_2 = std::move(st_p0_1_2)]() {
            return ({
                auto n_pb = p0;
                call_then(start_resolve_col(st_p0_1_2, prism_rtl::deref(n_pb).declared), [=](crate::check::types::Col resolve_col_6526) { return call_then(start_resolve_col(st_p0_1_2, prism_rtl::deref(n_pb).body), [=](crate::check::types::Col resolve_col_6560) { return prism_rtl::finished(crate::check::typed::FnNote{.at = prism_rtl::deref(n_pb).at, .name = prism_rtl::deref(n_pb).name, .declared = resolve_col_6526, .body = resolve_col_6560}); }); });
            });
        }));
        });
    })));
    })));
    return this_;
}


prism_rtl::Turn<crate::check::typed::TProgram> ZonkTyped::cycle() const {
    const auto& st_p0 = this->st_p0;
    auto t_p1 = prism_rtl::deref(st_p0).typed;
    return prism_rtl::finished(({
        crate::check::typed::TProgram this_ = t_p1;
        this_.exprs = run_to_end(each_job(this_.exprs, ({
            auto st_p0_1 = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::typed::TyNote>(crate::check::typed::TyNote)>>(prism_rtl::rc([=, st_p0_1 = std::move(st_p0_1)](crate::check::typed::TyNote p0) {
            return ({
                auto st_p0_1_2 = st_p0_1;
                entered(once_job([=, st_p0_1_2 = std::move(st_p0_1_2)]() {
                return ({
                    auto n_p2 = p0;
                    call_then(start_resolve_ty(st_p0_1_2, prism_rtl::deref(n_p2).ty), [=](crate::check::types::Ty resolve_ty_5873) { return prism_rtl::finished(crate::check::typed::TyNote{.at = prism_rtl::deref(n_p2).at, .ty = resolve_ty_5873}); });
                });
            }));
            });
        })));
        })));
        this_.binders = run_to_end(each_job(this_.binders, ({
            auto st_p0_1 = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::typed::BinderNote>(crate::check::typed::BinderNote)>>(prism_rtl::rc([=, st_p0_1 = std::move(st_p0_1)](crate::check::typed::BinderNote p0) {
            return ({
                auto st_p0_1_2 = st_p0_1;
                entered(once_job([=, st_p0_1_2 = std::move(st_p0_1_2)]() {
                return ({
                    auto n_p3 = p0;
                    call_then(start_resolve_ty(st_p0_1_2, prism_rtl::deref(n_p3).ty), [=](crate::check::types::Ty resolve_ty_5975) { return prism_rtl::finished(crate::check::typed::BinderNote{.at = prism_rtl::deref(n_p3).at, .name = prism_rtl::deref(n_p3).name, .ty = resolve_ty_5975}); });
                });
            }));
            });
        })));
        })));
        this_.insts = run_to_end(each_job(this_.insts, ({
            auto st_p0_1 = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::typed::InstNote>(crate::check::typed::InstNote)>>(prism_rtl::rc([=, st_p0_1 = std::move(st_p0_1)](crate::check::typed::InstNote p0) {
            return ({
                auto st_p0_1_2 = st_p0_1;
                entered(once_job([=, st_p0_1_2 = std::move(st_p0_1_2)]() {
                return ({
                    auto n_p4 = p0;
                    call_value(each_job(prism_rtl::deref(n_p4).tys, ({
                    auto st_p0_1_2_2 = st_p0_1_2;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::check::types::Ty>>(std::tuple<Text, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_p0_1_2_2 = std::move(st_p0_1_2_2)](std::tuple<Text, crate::check::types::Ty> p0) {
                    return ({
                        auto st_p0_1_2_2_2 = st_p0_1_2_2;
                        entered(once_job([=, st_p0_1_2_2_2 = std::move(st_p0_1_2_2_2)]() {
                        return ({
                            auto [q_p5, x_p6] = p0;
                            call_then(start_resolve_ty(st_p0_1_2_2_2, x_p6), [=](crate::check::types::Ty resolve_ty_6102) { return prism_rtl::finished(std::tuple{q_p5, resolve_ty_6102}); });
                        });
                    }));
                    });
                }));
                })), [=](Array<std::tuple<Text, crate::check::types::Ty>> each_6072) {
                    return call_value(each_job(prism_rtl::deref(n_p4).cols, ({
                        auto st_p0_1_2_2 = st_p0_1_2;
                        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::check::types::Col>>(std::tuple<Text, crate::check::types::Col>)>>(prism_rtl::rc([=, st_p0_1_2_2 = std::move(st_p0_1_2_2)](std::tuple<Text, crate::check::types::Col> p0) {
                        return ({
                            auto st_p0_1_2_2_2 = st_p0_1_2_2;
                            entered(once_job([=, st_p0_1_2_2_2 = std::move(st_p0_1_2_2_2)]() {
                            return ({
                                auto [q_p7, c_p8] = p0;
                                call_then(start_resolve_col(st_p0_1_2_2_2, c_p8), [=](crate::check::types::Col resolve_col_6160) { return prism_rtl::finished(std::tuple{q_p7, resolve_col_6160}); });
                            });
                        }));
                        });
                    }));
                    })), [=](Array<std::tuple<Text, crate::check::types::Col>> each_6129) { return prism_rtl::finished(crate::check::typed::InstNote{.at = prism_rtl::deref(n_p4).at, .name = prism_rtl::deref(n_p4).name, .tys = each_6072, .cols = each_6129}); });
                });
                });
            }));
            });
        })));
        })));
        this_.impls = run_to_end(each_job(this_.impls, ({
            auto st_p0_1 = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::typed::ImplNote>(crate::check::typed::ImplNote)>>(prism_rtl::rc([=, st_p0_1 = std::move(st_p0_1)](crate::check::typed::ImplNote p0) {
            return ({
                auto st_p0_1_2 = st_p0_1;
                entered(once_job([=, st_p0_1_2 = std::move(st_p0_1_2)]() {
                return ({
                    auto n_p9 = p0;
                    call_then(start_resolve_ty(st_p0_1_2, prism_rtl::deref(n_p9).ty), [=](crate::check::types::Ty resolve_ty_6255) { return prism_rtl::finished(crate::check::typed::ImplNote{.at = prism_rtl::deref(n_p9).at, .cls = prism_rtl::deref(n_p9).cls, .ty = resolve_ty_6255, .how = prism_rtl::deref(n_p9).how}); });
                });
            }));
            });
        })));
        })));
        this_.apps = run_to_end(each_job(this_.apps, ({
            auto st_p0_1 = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::typed::AppNote>(crate::check::typed::AppNote)>>(prism_rtl::rc([=, st_p0_1 = std::move(st_p0_1)](crate::check::typed::AppNote p0) {
            return ({
                auto st_p0_1_2 = st_p0_1;
                entered(once_job([=, st_p0_1_2 = std::move(st_p0_1_2)]() {
                return ({
                    auto n_pa = p0;
                    call_then(start_resolve_col(st_p0_1_2, prism_rtl::deref(n_pa).color), [=](crate::check::types::Col resolve_col_6426) { return prism_rtl::finished(crate::check::typed::AppNote{.at = prism_rtl::deref(n_pa).at, .callee = prism_rtl::deref(n_pa).callee, .kind = prism_rtl::deref(n_pa).kind, .layer = prism_rtl::deref(n_pa).layer, .lifted = prism_rtl::deref(n_pa).lifted, .inner = prism_rtl::deref(n_pa).inner, .color = resolve_col_6426}); });
                });
            }));
            });
        })));
        })));
        this_.fns = run_to_end(each_job(this_.fns, ({
            auto st_p0_1 = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::typed::FnNote>(crate::check::typed::FnNote)>>(prism_rtl::rc([=, st_p0_1 = std::move(st_p0_1)](crate::check::typed::FnNote p0) {
            return ({
                auto st_p0_1_2 = st_p0_1;
                entered(once_job([=, st_p0_1_2 = std::move(st_p0_1_2)]() {
                return ({
                    auto n_pb = p0;
                    call_then(start_resolve_col(st_p0_1_2, prism_rtl::deref(n_pb).declared), [=](crate::check::types::Col resolve_col_6526) { return call_then(start_resolve_col(st_p0_1_2, prism_rtl::deref(n_pb).body), [=](crate::check::types::Col resolve_col_6560) { return prism_rtl::finished(crate::check::typed::FnNote{.at = prism_rtl::deref(n_pb).at, .name = prism_rtl::deref(n_pb).name, .declared = resolve_col_6526, .body = resolve_col_6560}); }); });
                });
            }));
            });
        })));
        })));
        (std::move(this_));
    }));
}


/// `Start ZonkTyped, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::typed::TProgram> start_zonk_typed(crate::check::types::St st_p0) {
    return prism_rtl::make_rc<ZonkTyped>(st_p0);
}


/// ResolveCol: unbounded fn St, Col -> Col
crate::check::types::Col resolve_col(const crate::check::types::St& st_p0, const crate::check::types::Col& c_p1) {
    auto&& _m = crate::check::types::colors::walk_col(st_p0, c_p1);
    if (prism_rtl::is<crate::check::types::Col::CFlex>(_m)) {
        auto&& n_p2 = prism_rtl::as<crate::check::types::Col::CFlex>(_m).a0;
        auto&& _m = crate::prelude::get(st_p0.col_q, n_p2);
        if (prism_rtl::is_some(_m)) {
            auto&& q_p3 = prism_rtl::some_of(_m);
            return crate::check::types::Col(crate::check::types::Col::CQ{q_p3});
        }
        if (prism_rtl::is_none(_m)) {
            return crate::check::types::Col(crate::check::types::Col::CBound{});
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        auto&& other_p4 = _m;
        return other_p4;
    }
}


prism_rtl::Turn<crate::check::types::Col> ResolveCol::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& c_p1 = this->c_p1;
    auto c_p1_1 = c_p1;
    auto st_p0_2 = st_p0;
    return call_then(crate::check::types::colors::start_walk_col(st_p0_2, c_p1_1), [=](crate::check::types::Col walk_col_6795) {
        return ({
            prism_rtl::is<crate::check::types::Col::CFlex>(walk_col_6795) ? ({
            auto&& n_p2 = prism_rtl::as<crate::check::types::Col::CFlex>(walk_col_6795).a0;
            ({
            auto&& _m = crate::prelude::get(prism_rtl::deref(st_p0_2).col_q, n_p2);
            prism_rtl::is_some(_m) ? ({
            auto&& q_p3 = prism_rtl::some_of(_m);
            prism_rtl::finished(crate::check::types::Col(crate::check::types::Col::CQ{q_p3}));
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::check::types::Col(crate::check::types::Col::CBound{}))
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : ({
            auto&& other_p4 = walk_col_6795;
            prism_rtl::finished(other_p4);
        });
        });
    });
}


/// `Start ResolveCol, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Col> start_resolve_col(crate::check::types::St st_p0, crate::check::types::Col c_p1) {
    return prism_rtl::make_rc<ResolveCol>(st_p0, c_p1);
}


/// ResolveTy: unbounded fn St, Ty -> Ty
crate::check::types::Ty resolve_ty(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1) {
    return resolve_in(st_p0, zonk(st_p0, t_p1));
}


prism_rtl::Turn<crate::check::types::Ty> ResolveTy::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    auto st_p0_1 = st_p0;
    auto t_p1_2 = t_p1;
    return call_then(start_zonk(st_p0_1, t_p1_2), [=](crate::check::types::Ty zonk_7008) { return prism_rtl::more(prism_rtl::rc(ResolveIn(st_p0_1, zonk_7008))); });
}


/// `Start ResolveTy, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_resolve_ty(crate::check::types::St st_p0, crate::check::types::Ty t_p1) {
    return prism_rtl::make_rc<ResolveTy>(st_p0, t_p1);
}


/// ResolveIn: unbounded fn St, Ty -> Ty
crate::check::types::Ty resolve_in(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1)) {
        auto&& n_p2 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& args_p3 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyCon{n_p2, run_to_end(each_job(args_p3, ({
            auto st_p0_1 = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, st_p0_1 = std::move(st_p0_1)](crate::check::types::Ty p0) {
            return ({
                auto st_p0_1_2 = st_p0_1;
                entered(once_job([=, st_p0_1_2 = std::move(st_p0_1_2)]() {
                return ({
                    auto a_p4 = p0;
                    (prism_rtl::more(prism_rtl::rc(ResolveIn(st_p0_1_2, a_p4))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p1)) {
        auto&& c_p5 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a0;
        auto&& ps_p6 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a1;
        auto&& res_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a2;
        return crate::check::types::Ty(crate::check::types::Ty::TyFn{resolve_col(st_p0, c_p5), run_to_end(each_job(ps_p6, ({
            auto st_p0_1 = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, st_p0_1 = std::move(st_p0_1)](crate::check::types::Ty p0) {
            return ({
                auto st_p0_1_2 = st_p0_1;
                entered(once_job([=, st_p0_1_2 = std::move(st_p0_1_2)]() {
                return ({
                    auto p_p8 = p0;
                    (prism_rtl::more(prism_rtl::rc(ResolveIn(st_p0_1_2, p_p8))));
                });
            }));
            });
        })));
        }))), prism_rtl::rc(resolve_in(st_p0, prism_rtl::deref(prism_rtl::deref(res_p7))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p1)) {
        auto&& ts_p9 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p1).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyTuple{run_to_end(each_job(ts_p9, ({
            auto st_p0_1 = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, st_p0_1 = std::move(st_p0_1)](crate::check::types::Ty p0) {
            return ({
                auto st_p0_1_2 = st_p0_1;
                entered(once_job([=, st_p0_1_2 = std::move(st_p0_1_2)]() {
                return ({
                    auto a_pa = p0;
                    (prism_rtl::more(prism_rtl::rc(ResolveIn(st_p0_1_2, a_pa))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p1)) {
        auto&& e_pb = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p1).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(resolve_in(st_p0, prism_rtl::deref(prism_rtl::deref(e_pb))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p1)) {
        auto&& k_pc = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a0;
        auto&& v_pd = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(resolve_in(st_p0, prism_rtl::deref(prism_rtl::deref(k_pc)))), prism_rtl::rc(resolve_in(st_p0, prism_rtl::deref(prism_rtl::deref(v_pd))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p1)) {
        auto&& s_pe = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        auto&& i_pf = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TySig{s_pe, prism_rtl::rc(resolve_in(st_p0, prism_rtl::deref(prism_rtl::deref(i_pf))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p1)) {
        auto&& i_pg = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p1).a0;
        auto&& rw_ph = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p1).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(resolve_in(st_p0, prism_rtl::deref(prism_rtl::deref(i_pg)))), rw_ph});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t_p1)) {
        auto&& rw_pi = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p1).a0;
        auto&& o_pj = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p1).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyElem{rw_pi, prism_rtl::rc(resolve_in(st_p0, prism_rtl::deref(prism_rtl::deref(o_pj))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p1)) {
        auto&& n_pk = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p1).a0;
        auto&& a_pl = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p1).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyAssoc{n_pk, prism_rtl::rc(resolve_in(st_p0, prism_rtl::deref(prism_rtl::deref(a_pl))))});
    }
    {
        auto&& other_pm = t_p1;
        return other_pm;
    }
}


prism_rtl::Turn<crate::check::types::Ty> ResolveIn::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1) ? ({
        auto&& n_p2 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& args_p3 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        ({
        auto args_p3_1 = args_p3;
        auto n_p2_2 = n_p2;
        auto st_p0_3 = st_p0;
        call_value(each_job(args_p3_1, ({
        auto st_p0_3_4 = st_p0_3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, st_p0_3_4 = std::move(st_p0_3_4)](crate::check::types::Ty p0) {
        return ({
            auto st_p0_3_4_4 = st_p0_3_4;
            entered(once_job([=, st_p0_3_4_4 = std::move(st_p0_3_4_4)]() {
            return ({
                auto a_p4 = p0;
                (prism_rtl::more(prism_rtl::rc(ResolveIn(st_p0_3_4_4, a_p4))));
            });
        }));
        });
    })));
    })), [=, n_p2_2 = std::move(n_p2_2)](Array<crate::check::types::Ty> each_7117) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyCon{n_p2_2, each_7117})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(t_p1) ? ({
        auto&& c_p5 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a0;
        auto&& ps_p6 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a1;
        auto&& res_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a2;
        ({
        auto c_p5_1 = c_p5;
        auto ps_p6_2 = ps_p6;
        auto res_p7_3 = prism_rtl::deref(prism_rtl::deref(res_p7));
        auto st_p0_4 = st_p0;
        call_then(start_resolve_col(st_p0_4, c_p5_1), [=, ps_p6_2 = std::move(ps_p6_2), res_p7_3 = std::move(res_p7_3)](crate::check::types::Col resolve_col_7177) {
        return call_value(each_job(ps_p6_2, ({
            auto st_p0_4_5 = st_p0_4;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, st_p0_4_5 = std::move(st_p0_4_5)](crate::check::types::Ty p0) {
            return ({
                auto st_p0_4_5_5 = st_p0_4_5;
                entered(once_job([=, st_p0_4_5_5 = std::move(st_p0_4_5_5)]() {
                return ({
                    auto p_p8 = p0;
                    (prism_rtl::more(prism_rtl::rc(ResolveIn(st_p0_4_5_5, p_p8))));
                });
            }));
            });
        })));
        })), [=](Array<crate::check::types::Ty> each_7197) { return call_then(start_resolve_in(st_p0_4, res_p7_3), [=](crate::check::types::Ty resolve_in_7230) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyFn{resolve_col_7177, each_7197, prism_rtl::rc(resolve_in_7230)})); }); });
    });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p1) ? ({
        auto&& ts_p9 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p1).a0;
        ({
        auto st_p0_1 = st_p0;
        auto ts_p9_2 = ts_p9;
        call_value(each_job(ts_p9_2, ({
        auto st_p0_1_3 = st_p0_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, st_p0_1_3 = std::move(st_p0_1_3)](crate::check::types::Ty p0) {
        return ({
            auto st_p0_1_3_3 = st_p0_1_3;
            entered(once_job([=, st_p0_1_3_3 = std::move(st_p0_1_3_3)]() {
            return ({
                auto a_pa = p0;
                (prism_rtl::more(prism_rtl::rc(ResolveIn(st_p0_1_3_3, a_pa))));
            });
        }));
        });
    })));
    })), [=](Array<crate::check::types::Ty> each_7274) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyTuple{each_7274})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t_p1) ? ({
        auto&& e_pb = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p1).a0;
        ({
        auto e_pb_1 = prism_rtl::deref(prism_rtl::deref(e_pb));
        auto st_p0_2 = st_p0;
        call_then(start_resolve_in(st_p0_2, e_pb_1), [=](crate::check::types::Ty resolve_in_7329) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(resolve_in_7329)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t_p1) ? ({
        auto&& k_pc = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a0;
        auto&& v_pd = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a1;
        ({
        auto k_pc_1 = prism_rtl::deref(prism_rtl::deref(k_pc));
        auto st_p0_2 = st_p0;
        auto v_pd_3 = prism_rtl::deref(prism_rtl::deref(v_pd));
        call_then(start_resolve_in(st_p0_2, k_pc_1), [=, v_pd_3 = std::move(v_pd_3)](crate::check::types::Ty resolve_in_7369) { return call_then(start_resolve_in(st_p0_2, v_pd_3), [=](crate::check::types::Ty resolve_in_7388) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(resolve_in_7369), prism_rtl::rc(resolve_in_7388)})); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t_p1) ? ({
        auto&& s_pe = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        auto&& i_pf = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        ({
        auto i_pf_1 = prism_rtl::deref(prism_rtl::deref(i_pf));
        auto s_pe_2 = s_pe;
        auto st_p0_3 = st_p0;
        call_then(start_resolve_in(st_p0_3, i_pf_1), [=, s_pe_2 = std::move(s_pe_2)](crate::check::types::Ty resolve_in_7431) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TySig{s_pe_2, prism_rtl::rc(resolve_in_7431)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyAt>(t_p1) ? ({
        auto&& i_pg = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p1).a0;
        auto&& rw_ph = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p1).a1;
        ({
        auto i_pg_1 = prism_rtl::deref(prism_rtl::deref(i_pg));
        auto rw_ph_2 = rw_ph;
        auto st_p0_3 = st_p0;
        call_then(start_resolve_in(st_p0_3, i_pg_1), [=, rw_ph_2 = std::move(rw_ph_2)](crate::check::types::Ty resolve_in_7470) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(resolve_in_7470), rw_ph_2})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyElem>(t_p1) ? ({
        auto&& rw_pi = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p1).a0;
        auto&& o_pj = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p1).a1;
        ({
        auto o_pj_1 = prism_rtl::deref(prism_rtl::deref(o_pj));
        auto rw_pi_2 = rw_pi;
        auto st_p0_3 = st_p0;
        call_then(start_resolve_in(st_p0_3, o_pj_1), [=, rw_pi_2 = std::move(rw_pi_2)](crate::check::types::Ty resolve_in_7521) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyElem{rw_pi_2, prism_rtl::rc(resolve_in_7521)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p1) ? ({
        auto&& n_pk = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p1).a0;
        auto&& a_pl = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p1).a1;
        ({
        auto a_pl_1 = prism_rtl::deref(prism_rtl::deref(a_pl));
        auto n_pk_2 = n_pk;
        auto st_p0_3 = st_p0;
        call_then(start_resolve_in(st_p0_3, a_pl_1), [=, n_pk_2 = std::move(n_pk_2)](crate::check::types::Ty resolve_in_7568) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyAssoc{n_pk_2, prism_rtl::rc(resolve_in_7568)})); });
    });
    })
        : ({
        auto&& other_pm = t_p1;
        prism_rtl::finished(other_pm);
    });
    });
}


/// `Start ResolveIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_resolve_in(crate::check::types::St st_p0, crate::check::types::Ty t_p1) {
    return prism_rtl::make_rc<ResolveIn>(st_p0, t_p1);
}


/// AtBinder: fn St, Ty, Range -> St
crate::check::types::St at_binder(const crate::check::types::St& st_p0, const crate::check::types::Ty& ty1, const crate::syntax::Range& range2) {
    auto&& _m = std::tuple{ty1, range2};
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(std::get<0>(_m))) {
        auto&& n_p1 = prism_rtl::as<crate::check::types::Ty::TyFlex>(std::get<0>(_m)).a0;
        auto&& span_p2 = std::get<1>(_m);
        crate::check::types::St this_ = st_p0;
        this_.binder_at = insert(this_.binder_at, n_p1, span_p2);
        return this_;
    }
    {
        return st_p0;
    }
    prism_rtl::unreachable("no arm matched");
}


/// FreshRow: fn St, [Text] -> ((Rw, St))
std::tuple<crate::check::types::Rw, crate::check::types::St> fresh_row(const crate::check::types::St& st_p0, const Array<Text>& lacking_p1) {
    auto n_p2 = st_p0.next;
    auto st2_p3 = ({
        crate::check::types::St this_ = st_p0;
        this_.next = this_.next + Nat(1u);
        this_.lacks = insert(this_.lacks, n_p2, lacking_p1);
        (std::move(this_));
    });
    return std::tuple{crate::check::types::Rw{.fams = Array<Text>{}, .minus = Array<Text>{}, .tail = crate::check::types::Tail(crate::check::types::Tail::TlFlex{n_p2})}, st2_p3};
}


/// AddDiag: fn St, CDiag -> St
crate::check::types::St add_diag(const crate::check::types::St& st_p0, const crate::check::errors::CDiag& d_p1) {
    crate::check::types::St this_ = st_p0;
    this_.diags = crate::prelude::push(this_.diags, d_p1);
    return this_;
}


/// Err: fn St, Text, Range, Text -> St
crate::check::types::St err(const crate::check::types::St& st_p0, const Text& code_p1, const crate::syntax::Range& span_p2, const Text& message_p3) {
    return add_diag(st_p0, crate::check::errors::diag0(code_p1, st_p0.file, span_p2, message_p3));
}


/// ErrFix: fn St, Text, Range, Text, Text -> St
crate::check::types::St err_fix(const crate::check::types::St& st_p0, const Text& code_p1, const crate::syntax::Range& span_p2, const Text& message_p3, const Text& fix_p4) {
    return add_diag(st_p0, crate::check::errors::diag_fix(code_p1, st_p0.file, span_p2, message_p3, fix_p4));
}


/// InfoOf: fn St, Nat -> VInfo
crate::check::types::VInfo info_of(const crate::check::types::St& st_p0, const Nat& n_p1) {
    return or_(crate::prelude::get(st_p0.infos, n_p1), crate::check::types::VInfo{.plain = false, .level = Nat(0u), .name = Text::lit("")});
}


/// Walk: unbounded fn St, Ty -> Ty
crate::check::types::Ty walk(const crate::check::types::St& st_p0, const crate::check::types::Ty& ty1) {
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(ty1)) {
        auto&& n_p1 = prism_rtl::as<crate::check::types::Ty::TyFlex>(ty1).a0;
        auto&& _m = crate::prelude::get(st_p0.tys, n_p1);
        if (prism_rtl::is_some(_m)) {
            auto&& t_p2 = prism_rtl::some_of(_m);
            return walk(st_p0, t_p2);
        }
        if (prism_rtl::is_none(_m)) {
            return crate::check::types::Ty(crate::check::types::Ty::TyFlex{n_p1});
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        auto&& t_p4 = ty1;
        return t_p4;
    }
}


prism_rtl::Turn<crate::check::types::Ty> Walk::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& ty1 = this->ty1;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyFlex>(ty1) ? ({
        auto&& n_p1 = prism_rtl::as<crate::check::types::Ty::TyFlex>(ty1).a0;
        ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(st_p0).tys, n_p1);
        prism_rtl::is_some(_m) ? ({
        auto&& t_p2 = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(Walk(st_p0, t_p2)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyFlex{n_p1}))
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : ({
        auto&& t_p4 = ty1;
        prism_rtl::finished(t_p4);
    });
    });
}


/// `Start Walk, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_walk(crate::check::types::St st_p0, crate::check::types::Ty ty1) {
    return prism_rtl::make_rc<Walk>(st_p0, ty1);
}


/// WalkRow: unbounded fn St, Rw -> Rw
crate::check::types::Rw walk_row(const crate::check::types::St& st_p0, const crate::check::types::Rw& r_p1) {
    auto&& _m = r_p1.tail;
    if (prism_rtl::is<crate::check::types::Tail::TlFlex>(_m)) {
        auto&& n_p2 = prism_rtl::as<crate::check::types::Tail::TlFlex>(_m).a0;
        auto&& _m = crate::prelude::get(st_p0.rows, n_p2);
        if (prism_rtl::is_some(_m)) {
            auto&& r2_p3 = prism_rtl::some_of(_m);
            auto w_p4 = walk_row(st_p0, r2_p3);
            return crate::check::types::Rw{.fams = crate::check::types::sort_texts(crate::check::types::union_texts(r_p1.fams, prism_rtl::deref(w_p4).fams)), .minus = crate::check::types::union_texts(r_p1.minus, prism_rtl::deref(w_p4).minus), .tail = prism_rtl::deref(w_p4).tail};
        }
        if (prism_rtl::is_none(_m)) {
            return r_p1;
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        return r_p1;
    }
}


prism_rtl::Turn<crate::check::types::Rw> WalkRow::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& r_p1 = this->r_p1;
    return ({
        auto&& _m = prism_rtl::deref(r_p1).tail;
        prism_rtl::is<crate::check::types::Tail::TlFlex>(_m) ? ({
        auto&& n_p2 = prism_rtl::as<crate::check::types::Tail::TlFlex>(_m).a0;
        ({
        auto&& _m = crate::prelude::get(st_p0->rows, n_p2);
        prism_rtl::is_some(_m) ? ({
        auto&& r2_p3 = prism_rtl::some_of(_m);
        ({
        auto r_p1_1 = r_p1;
        auto st_p0_2 = st_p0;
        call_then(start_walk_row(st_p0_2, r2_p3), [=, r_p1_1 = std::move(r_p1_1)](crate::check::types::Rw walk_row_8935) {
        return ({
            auto w_p4 = walk_row_8935;
            (prism_rtl::finished(crate::check::types::Rw{.fams = crate::check::types::sort_texts(crate::check::types::union_texts(prism_rtl::deref(r_p1_1).fams, prism_rtl::deref(w_p4).fams)), .minus = crate::check::types::union_texts(prism_rtl::deref(r_p1_1).minus, prism_rtl::deref(w_p4).minus), .tail = prism_rtl::deref(w_p4).tail}));
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(r_p1)
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::finished(r_p1);
    });
}


/// `Start WalkRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Rw> start_walk_row(crate::check::types::St st_p0, crate::check::types::Rw r_p1) {
    return prism_rtl::make_rc<WalkRow>(st_p0, r_p1);
}


/// Zonk: unbounded fn St, Ty -> Ty
crate::check::types::Ty zonk(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1) {
    auto&& _m = crate::check::types::unify::norm_assoc(st_p0, walk(st_p0, t_p1));
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& n_p2 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& args_p3 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyCon{n_p2, run_to_end(each_job(args_p3, ({
            auto st_p0_1 = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, st_p0_1 = std::move(st_p0_1)](crate::check::types::Ty p0) {
            return ({
                auto st_p0_1_2 = st_p0_1;
                entered(once_job([=, st_p0_1_2 = std::move(st_p0_1_2)]() {
                return ({
                    auto a_p4 = p0;
                    (prism_rtl::more(prism_rtl::rc(Zonk(st_p0_1_2, a_p4))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
        auto&& c_p5 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0;
        auto&& ps_p6 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
        auto&& res_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
        return crate::check::types::Ty(crate::check::types::Ty::TyFn{crate::check::types::colors::walk_col(st_p0, c_p5), run_to_end(each_job(ps_p6, ({
            auto st_p0_1 = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, st_p0_1 = std::move(st_p0_1)](crate::check::types::Ty p0) {
            return ({
                auto st_p0_1_2 = st_p0_1;
                entered(once_job([=, st_p0_1_2 = std::move(st_p0_1_2)]() {
                return ({
                    auto p_p8 = p0;
                    (prism_rtl::more(prism_rtl::rc(Zonk(st_p0_1_2, p_p8))));
                });
            }));
            });
        })));
        }))), prism_rtl::rc(zonk(st_p0, prism_rtl::deref(res_p7)))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(_m)) {
        auto&& ts_p9 = prism_rtl::as<crate::check::types::Ty::TyTuple>(_m).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyTuple{run_to_end(each_job(ts_p9, ({
            auto st_p0_1 = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, st_p0_1 = std::move(st_p0_1)](crate::check::types::Ty p0) {
            return ({
                auto st_p0_1_2 = st_p0_1;
                entered(once_job([=, st_p0_1_2 = std::move(st_p0_1_2)]() {
                return ({
                    auto a_pa = p0;
                    (prism_rtl::more(prism_rtl::rc(Zonk(st_p0_1_2, a_pa))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(_m)) {
        auto&& e_pb = prism_rtl::as<crate::check::types::Ty::TyArray>(_m).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(zonk(st_p0, prism_rtl::deref(e_pb)))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(_m)) {
        auto&& k_pc = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a0;
        auto&& v_pd = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(zonk(st_p0, prism_rtl::deref(k_pc))), prism_rtl::rc(zonk(st_p0, prism_rtl::deref(v_pd)))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& s_pe = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
        auto&& i_pf = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TySig{s_pe, prism_rtl::rc(zonk(st_p0, prism_rtl::deref(i_pf)))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
        auto&& i_pg = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a0;
        auto&& rw_ph = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(zonk(st_p0, prism_rtl::deref(i_pg))), walk_row(st_p0, rw_ph)});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
        auto&& rw_pi = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a0;
        auto&& o_pj = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyElem{walk_row(st_p0, rw_pi), prism_rtl::rc(zonk(st_p0, prism_rtl::deref(o_pj)))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(_m)) {
        auto&& rw_pk = prism_rtl::as<crate::check::types::Ty::TyElemAny>(_m).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyElemAny{walk_row(st_p0, rw_pk)});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(_m)) {
        auto&& n_pl = prism_rtl::as<crate::check::types::Ty::TyAssoc>(_m).a0;
        auto&& a_pm = prism_rtl::as<crate::check::types::Ty::TyAssoc>(_m).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyAssoc{n_pl, prism_rtl::rc(zonk(st_p0, prism_rtl::deref(a_pm)))});
    }
    {
        auto&& w_pn = _m;
        return w_pn;
    }
}


prism_rtl::Turn<crate::check::types::Ty> Zonk::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    auto st_p0_1 = st_p0;
    auto t_p1_2 = t_p1;
    return call_then(start_walk(st_p0_1, t_p1_2), [=](crate::check::types::Ty walk_9226) {
        return call_then(crate::check::types::unify::start_norm_assoc(st_p0_1, walk_9226), [=](crate::check::types::Ty norm_assoc_9211) {
            return ({
                prism_rtl::is<crate::check::types::Ty::TyCon>(norm_assoc_9211) ? ({
                auto&& n_p2 = prism_rtl::as<crate::check::types::Ty::TyCon>(norm_assoc_9211).a0;
                auto&& args_p3 = prism_rtl::as<crate::check::types::Ty::TyCon>(norm_assoc_9211).a1;
                call_value(each_job(args_p3, ({
                auto st_p0_1_3 = st_p0_1;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, st_p0_1_3 = std::move(st_p0_1_3)](crate::check::types::Ty p0) {
                return ({
                    auto st_p0_1_3_3 = st_p0_1_3;
                    entered(once_job([=, st_p0_1_3_3 = std::move(st_p0_1_3_3)]() {
                    return ({
                        auto a_p4 = p0;
                        (prism_rtl::more(prism_rtl::rc(Zonk(st_p0_1_3_3, a_p4))));
                    });
                }));
                });
            })));
            })), [=](Array<crate::check::types::Ty> each_9268) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyCon{n_p2, each_9268})); });
            })
                : prism_rtl::is<crate::check::types::Ty::TyFn>(norm_assoc_9211) ? ({
                auto&& c_p5 = prism_rtl::as<crate::check::types::Ty::TyFn>(norm_assoc_9211).a0;
                auto&& ps_p6 = prism_rtl::as<crate::check::types::Ty::TyFn>(norm_assoc_9211).a1;
                auto&& res_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(norm_assoc_9211).a2;
                call_then(crate::check::types::colors::start_walk_col(st_p0_1, c_p5), [=](crate::check::types::Col walk_col_9323) {
                return call_value(each_job(ps_p6, ({
                    auto st_p0_1_3 = st_p0_1;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, st_p0_1_3 = std::move(st_p0_1_3)](crate::check::types::Ty p0) {
                    return ({
                        auto st_p0_1_3_3 = st_p0_1_3;
                        entered(once_job([=, st_p0_1_3_3 = std::move(st_p0_1_3_3)]() {
                        return ({
                            auto p_p8 = p0;
                            (prism_rtl::more(prism_rtl::rc(Zonk(st_p0_1_3_3, p_p8))));
                        });
                    }));
                    });
                })));
                })), [=](Array<crate::check::types::Ty> each_9340) { return call_then(start_zonk(st_p0_1, prism_rtl::deref(res_p7)), [=](crate::check::types::Ty zonk_9368) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyFn{walk_col_9323, each_9340, prism_rtl::rc(zonk_9368)})); }); });
            });
            })
                : prism_rtl::is<crate::check::types::Ty::TyTuple>(norm_assoc_9211) ? ({
                auto&& ts_p9 = prism_rtl::as<crate::check::types::Ty::TyTuple>(norm_assoc_9211).a0;
                call_value(each_job(ts_p9, ({
                auto st_p0_1_3 = st_p0_1;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, st_p0_1_3 = std::move(st_p0_1_3)](crate::check::types::Ty p0) {
                return ({
                    auto st_p0_1_3_3 = st_p0_1_3;
                    entered(once_job([=, st_p0_1_3_3 = std::move(st_p0_1_3_3)]() {
                    return ({
                        auto a_pa = p0;
                        (prism_rtl::more(prism_rtl::rc(Zonk(st_p0_1_3_3, a_pa))));
                    });
                }));
                });
            })));
            })), [=](Array<crate::check::types::Ty> each_9407) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyTuple{each_9407})); });
            })
                : prism_rtl::is<crate::check::types::Ty::TyArray>(norm_assoc_9211) ? ({
                auto&& e_pb = prism_rtl::as<crate::check::types::Ty::TyArray>(norm_assoc_9211).a0;
                call_then(start_zonk(st_p0_1, prism_rtl::deref(e_pb)), [=](crate::check::types::Ty zonk_9457) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(zonk_9457)})); });
            })
                : prism_rtl::is<crate::check::types::Ty::TyMap>(norm_assoc_9211) ? ({
                auto&& k_pc = prism_rtl::as<crate::check::types::Ty::TyMap>(norm_assoc_9211).a0;
                auto&& v_pd = prism_rtl::as<crate::check::types::Ty::TyMap>(norm_assoc_9211).a1;
                call_then(start_zonk(st_p0_1, prism_rtl::deref(k_pc)), [=](crate::check::types::Ty zonk_9492) { return call_then(start_zonk(st_p0_1, prism_rtl::deref(v_pd)), [=](crate::check::types::Ty zonk_9506) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(zonk_9492), prism_rtl::rc(zonk_9506)})); }); });
            })
                : prism_rtl::is<crate::check::types::Ty::TySig>(norm_assoc_9211) ? ({
                auto&& s_pe = prism_rtl::as<crate::check::types::Ty::TySig>(norm_assoc_9211).a0;
                auto&& i_pf = prism_rtl::as<crate::check::types::Ty::TySig>(norm_assoc_9211).a1;
                call_then(start_zonk(st_p0_1, prism_rtl::deref(i_pf)), [=](crate::check::types::Ty zonk_9544) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TySig{s_pe, prism_rtl::rc(zonk_9544)})); });
            })
                : prism_rtl::is<crate::check::types::Ty::TyAt>(norm_assoc_9211) ? ({
                auto&& i_pg = prism_rtl::as<crate::check::types::Ty::TyAt>(norm_assoc_9211).a0;
                auto&& rw_ph = prism_rtl::as<crate::check::types::Ty::TyAt>(norm_assoc_9211).a1;
                call_then(start_zonk(st_p0_1, prism_rtl::deref(i_pg)), [=](crate::check::types::Ty zonk_9578) { return call_then(start_walk_row(st_p0_1, rw_ph), [=](crate::check::types::Rw walk_row_9592) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(zonk_9578), walk_row_9592})); }); });
            })
                : prism_rtl::is<crate::check::types::Ty::TyElem>(norm_assoc_9211) ? ({
                auto&& rw_pi = prism_rtl::as<crate::check::types::Ty::TyElem>(norm_assoc_9211).a0;
                auto&& o_pj = prism_rtl::as<crate::check::types::Ty::TyElem>(norm_assoc_9211).a1;
                call_then(start_walk_row(st_p0_1, rw_pi), [=](crate::check::types::Rw walk_row_9634) { return call_then(start_zonk(st_p0_1, prism_rtl::deref(o_pj)), [=](crate::check::types::Ty zonk_9652) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyElem{walk_row_9634, prism_rtl::rc(zonk_9652)})); }); });
            })
                : prism_rtl::is<crate::check::types::Ty::TyElemAny>(norm_assoc_9211) ? ({
                auto&& rw_pk = prism_rtl::as<crate::check::types::Ty::TyElemAny>(norm_assoc_9211).a0;
                call_then(start_walk_row(st_p0_1, rw_pk), [=](crate::check::types::Rw walk_row_9693) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyElemAny{walk_row_9693})); });
            })
                : prism_rtl::is<crate::check::types::Ty::TyAssoc>(norm_assoc_9211) ? ({
                auto&& n_pl = prism_rtl::as<crate::check::types::Ty::TyAssoc>(norm_assoc_9211).a0;
                auto&& a_pm = prism_rtl::as<crate::check::types::Ty::TyAssoc>(norm_assoc_9211).a1;
                call_then(start_zonk(st_p0_1, prism_rtl::deref(a_pm)), [=](crate::check::types::Ty zonk_9739) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyAssoc{n_pl, prism_rtl::rc(zonk_9739)})); });
            })
                : ({
                auto&& w_pn = norm_assoc_9211;
                prism_rtl::finished(w_pn);
            });
            });
        });
    });
}


/// `Start Zonk, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_zonk(crate::check::types::St st_p0, crate::check::types::Ty t_p1) {
    return prism_rtl::make_rc<Zonk>(st_p0, t_p1);
}


/// FreeVars: unbounded fn St, Ty -> [Nat]
Array<Nat> free_vars(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1) {
    return free_vars_into(st_p0, Array<Nat>{}, t_p1);
}


prism_rtl::Turn<Array<Nat>> FreeVars::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    return prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_p0, Array<Nat>{}, t_p1)));
}


/// `Start FreeVars, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Nat>> start_free_vars(crate::check::types::St st_p0, crate::check::types::Ty t_p1) {
    return prism_rtl::make_rc<FreeVars>(st_p0, t_p1);
}


/// FreeVarsInto: unbounded fn St, [Nat], Ty -> [Nat]
Array<Nat> free_vars_into(const crate::check::types::St& st_p0, const Array<Nat>& acc_p1, const crate::check::types::Ty& t_p2) {
    auto&& _m = walk(st_p0, t_p2);
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(_m)) {
        auto&& n_p3 = prism_rtl::as<crate::check::types::Ty::TyFlex>(_m).a0;
        return crate::check::types::add_nat(acc_p1, n_p3);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& args_p4 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        return run_to_end(fold_job(args_p4, acc_p1, ({
            auto st_p0_1 = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_p0_1 = std::move(st_p0_1)](std::tuple<Array<Nat>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_p0_1_2 = st_p0_1;
                entered(once_job([=, st_p0_1_2 = std::move(st_p0_1_2)]() {
                return ({
                    auto a_p5 = p0;
                    auto x_p6 = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_p0_1_2, a_p5, x_p6))));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
        auto&& ps_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
        auto&& res_p8 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
        return free_vars_into(st_p0, run_to_end(fold_job(ps_p7, acc_p1, ({
            auto st_p0_1 = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_p0_1 = std::move(st_p0_1)](std::tuple<Array<Nat>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_p0_1_2 = st_p0_1;
                entered(once_job([=, st_p0_1_2 = std::move(st_p0_1_2)]() {
                return ({
                    auto a_p9 = p0;
                    auto x_pa = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_p0_1_2, a_p9, x_pa))));
                });
            }));
            });
        })));
        }))), prism_rtl::deref(res_p8));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(_m)) {
        auto&& ts_pb = prism_rtl::as<crate::check::types::Ty::TyTuple>(_m).a0;
        return run_to_end(fold_job(ts_pb, acc_p1, ({
            auto st_p0_1 = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_p0_1 = std::move(st_p0_1)](std::tuple<Array<Nat>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_p0_1_2 = st_p0_1;
                entered(once_job([=, st_p0_1_2 = std::move(st_p0_1_2)]() {
                return ({
                    auto a_pc = p0;
                    auto x_pd = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_p0_1_2, a_pc, x_pd))));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(_m)) {
        auto&& e_pe = prism_rtl::as<crate::check::types::Ty::TyArray>(_m).a0;
        return free_vars_into(st_p0, acc_p1, prism_rtl::deref(e_pe));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(_m)) {
        auto&& k_pf = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a0;
        auto&& v_pg = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a1;
        return free_vars_into(st_p0, free_vars_into(st_p0, acc_p1, prism_rtl::deref(k_pf)), prism_rtl::deref(v_pg));
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& i_ph = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        return free_vars_into(st_p0, acc_p1, prism_rtl::deref(i_ph));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
        auto&& i_pi = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a0;
        return free_vars_into(st_p0, acc_p1, prism_rtl::deref(i_pi));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
        auto&& o_pj = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a1;
        return free_vars_into(st_p0, acc_p1, prism_rtl::deref(o_pj));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(_m)) {
        auto&& a_pk = prism_rtl::as<crate::check::types::Ty::TyAssoc>(_m).a1;
        return free_vars_into(st_p0, acc_p1, prism_rtl::deref(a_pk));
    }
    {
        return acc_p1;
    }
}


prism_rtl::Turn<Array<Nat>> FreeVarsInto::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& acc_p1 = this->acc_p1;
    const auto& t_p2 = this->t_p2;
    auto acc_p1_1 = acc_p1;
    auto st_p0_2 = st_p0;
    auto t_p2_3 = t_p2;
    return call_then(start_walk(st_p0_2, t_p2_3), [=](crate::check::types::Ty walk_9972) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_9972) ? ({
            auto&& n_p3 = prism_rtl::as<crate::check::types::Ty::TyFlex>(walk_9972).a0;
            prism_rtl::finished(crate::check::types::add_nat(acc_p1_1, n_p3));
        })
            : prism_rtl::is<crate::check::types::Ty::TyCon>(walk_9972) ? ({
            auto&& args_p4 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_9972).a1;
            fold_job(args_p4, acc_p1_1, ({
            auto st_p0_2_4 = st_p0_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_p0_2_4 = std::move(st_p0_2_4)](std::tuple<Array<Nat>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_p0_2_4_4 = st_p0_2_4;
                entered(once_job([=, st_p0_2_4_4 = std::move(st_p0_2_4_4)]() {
                return ({
                    auto a_p5 = p0;
                    auto x_p6 = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_p0_2_4_4, a_p5, x_p6))));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::check::types::Ty::TyFn>(walk_9972) ? ({
            auto&& ps_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_9972).a1;
            auto&& res_p8 = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_9972).a2;
            call_value(fold_job(ps_p7, acc_p1_1, ({
            auto st_p0_2_4 = st_p0_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_p0_2_4 = std::move(st_p0_2_4)](std::tuple<Array<Nat>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_p0_2_4_4 = st_p0_2_4;
                entered(once_job([=, st_p0_2_4_4 = std::move(st_p0_2_4_4)]() {
                return ({
                    auto a_p9 = p0;
                    auto x_pa = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_p0_2_4_4, a_p9, x_pa))));
                });
            }));
            });
        })));
        })), [=](Array<Nat> fold_10126) { return prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_p0_2, fold_10126, prism_rtl::deref(res_p8)))); });
        })
            : prism_rtl::is<crate::check::types::Ty::TyTuple>(walk_9972) ? ({
            auto&& ts_pb = prism_rtl::as<crate::check::types::Ty::TyTuple>(walk_9972).a0;
            fold_job(ts_pb, acc_p1_1, ({
            auto st_p0_2_4 = st_p0_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_p0_2_4 = std::move(st_p0_2_4)](std::tuple<Array<Nat>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_p0_2_4_4 = st_p0_2_4;
                entered(once_job([=, st_p0_2_4_4 = std::move(st_p0_2_4_4)]() {
                return ({
                    auto a_pc = p0;
                    auto x_pd = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_p0_2_4_4, a_pc, x_pd))));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::check::types::Ty::TyArray>(walk_9972) ? ({
            auto&& e_pe = prism_rtl::as<crate::check::types::Ty::TyArray>(walk_9972).a0;
            prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_p0_2, acc_p1_1, prism_rtl::deref(e_pe))));
        })
            : prism_rtl::is<crate::check::types::Ty::TyMap>(walk_9972) ? ({
            auto&& k_pf = prism_rtl::as<crate::check::types::Ty::TyMap>(walk_9972).a0;
            auto&& v_pg = prism_rtl::as<crate::check::types::Ty::TyMap>(walk_9972).a1;
            call_then(start_free_vars_into(st_p0_2, acc_p1_1, prism_rtl::deref(k_pf)), [=](Array<Nat> free_vars_into_10309) { return prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_p0_2, free_vars_into_10309, prism_rtl::deref(v_pg)))); });
        })
            : prism_rtl::is<crate::check::types::Ty::TySig>(walk_9972) ? ({
            auto&& i_ph = prism_rtl::as<crate::check::types::Ty::TySig>(walk_9972).a1;
            prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_p0_2, acc_p1_1, prism_rtl::deref(i_ph))));
        })
            : prism_rtl::is<crate::check::types::Ty::TyAt>(walk_9972) ? ({
            auto&& i_pi = prism_rtl::as<crate::check::types::Ty::TyAt>(walk_9972).a0;
            prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_p0_2, acc_p1_1, prism_rtl::deref(i_pi))));
        })
            : prism_rtl::is<crate::check::types::Ty::TyElem>(walk_9972) ? ({
            auto&& o_pj = prism_rtl::as<crate::check::types::Ty::TyElem>(walk_9972).a1;
            prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_p0_2, acc_p1_1, prism_rtl::deref(o_pj))));
        })
            : prism_rtl::is<crate::check::types::Ty::TyAssoc>(walk_9972) ? ({
            auto&& a_pk = prism_rtl::as<crate::check::types::Ty::TyAssoc>(walk_9972).a1;
            prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_p0_2, acc_p1_1, prism_rtl::deref(a_pk))));
        })
            : prism_rtl::finished(acc_p1_1);
        });
    });
}


/// `Start FreeVarsInto, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Nat>> start_free_vars_into(crate::check::types::St st_p0, Array<Nat> acc_p1, crate::check::types::Ty t_p2) {
    return prism_rtl::make_rc<FreeVarsInto>(st_p0, acc_p1, t_p2);
}

}  // namespace crate::check::types::recording
