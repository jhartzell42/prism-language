// The module `Emit.Cpp`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <emit/cpp/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Emit.Cpp`, from `target/bootstrap/cpp-src/prismc/emit/cpp/mod.prism`.
namespace crate::emit::cpp {

Pod Cp::to_pod() const {
    return Pod::record("Cp", {{"home", prism_rtl::to_pod(home)}, {"mods", prism_rtl::to_pod(mods)}, {"types", prism_rtl::to_pod(types)}, {"ctors", prism_rtl::to_pod(ctors)}, {"members", prism_rtl::to_pod(members)}, {"methods", prism_rtl::to_pod(methods)}, {"field_names", prism_rtl::to_pod(field_names)}, {"fns", prism_rtl::to_pod(fns)}, {"fields", prism_rtl::to_pod(fields)}, {"renames", prism_rtl::to_pod(renames)}, {"pointers", prism_rtl::to_pod(pointers)}});
}

Result<Cp> Cp::from_pod(const Pod& whole) {
    return Cp{.home = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "home")))), .mods = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "mods")))), .types = TRY(prism_rtl::from_pod<Map<Text, TyInfo>>(TRY(crate::prelude::field(whole, "types")))), .ctors = TRY(prism_rtl::from_pod<Map<Text, Text>>(TRY(crate::prelude::field(whole, "ctors")))), .members = TRY(prism_rtl::from_pod<Map<Text, bool>>(TRY(crate::prelude::field(whole, "members")))), .methods = TRY(prism_rtl::from_pod<Map<Text, bool>>(TRY(crate::prelude::field(whole, "methods")))), .field_names = TRY(prism_rtl::from_pod<Map<Text, bool>>(TRY(crate::prelude::field(whole, "field_names")))), .fns = TRY(prism_rtl::from_pod<Map<Text, bool>>(TRY(crate::prelude::field(whole, "fns")))), .fields = TRY(prism_rtl::from_pod<Map<Text, crate::lower::model::OutTy>>(TRY(crate::prelude::field(whole, "fields")))), .renames = TRY(prism_rtl::from_pod<Map<Text, Text>>(TRY(crate::prelude::field(whole, "renames")))), .pointers = TRY(prism_rtl::from_pod<Map<Text, bool>>(TRY(crate::prelude::field(whole, "pointers"))))};
}


void TyInfo::show(Printer& p) const {
    p.record("TyInfo", {{"kind", kind}, {"fields", fields}, {"params", params}});
}

Pod TyInfo::to_pod() const {
    return Pod::record("TyInfo", {{"kind", prism_rtl::to_pod(kind)}, {"fields", prism_rtl::to_pod(fields)}, {"params", prism_rtl::to_pod(params)}});
}

Result<TyInfo> TyInfo::from_pod(const Pod& whole) {
    return TyInfo{.kind = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "kind")))), .fields = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "fields")))), .params = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "params"))))};
}


/// CppId: fn Text -> Text
Text cpp_id(const Text& n) {
    return in_list(crate::lower::cpp_keywords(), n) ? prism_rtl::cat(n, "_") : n;
}


/// FieldId: fn Text -> Text
Text field_id(const Text& f) {
    return in_list(Array(std::vector{Text::lit("show"), Text::lit("to_pod"), Text::lit("from_pod"), Text::lit("cases")}), f)
        ? prism_rtl::cat(f, "_")
        : cpp_id(f);
}


/// CppPathId: fn Text -> Text
Text cpp_path_id(const Text& p_) {
    return crate::syntax::lexer::chars::join(each(split_on(p_, Text::lit("::")), [&](const Text& s) { return cpp_id(s); }), Text::lit("::"));
}


/// InList: fn [Text], Text -> Bool
bool in_list(const Array<Text>& xs, const Text& x) {
    return fold(xs, false, [&](const bool& seen, const Text& y) { return seen || (y == x); });
}


/// Absolute: fn Cp, Text -> Text
Text absolute(const Cp& cp, const Text& p_) {
    auto q = crate::syntax::lexer::chars::drop_prefix(p_, Text::lit("crate::"));
    return fold(cp.mods, false, [&](const bool& f, const Text& m) { return f || crate::syntax::lexer::chars::has_prefix(q, prism_rtl::cat(m, "::")); })
        ? q
        : prism_rtl::cat(cp.home, "::", q);
}


/// ?TypeOf: fn Cp, Text -> ?TyInfo
std::optional<TyInfo> type_of(const Cp& cp, const Text& p_) {
    auto q = crate::syntax::lexer::chars::drop_prefix(p_, Text::lit("crate::"));
    auto&& _m = crate::prelude::get(cp.types, absolute(cp, q));
    if (prism_rtl::is_some(_m)) {
        auto&& t = prism_rtl::some_of(_m);
        return std::optional(t);
    }
    if (prism_rtl::is_none(_m)) {
        auto&& _m = crate::prelude::get(cp.types, prism_rtl::cat("prelude::", q));
        if (prism_rtl::is_some(_m)) {
            auto&& t = prism_rtl::some_of(_m);
            return std::optional(t);
        }
        if (prism_rtl::is_none(_m)) {
            return crate::prelude::get(cp.types, q);
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?CaseOf: fn Cp, Text -> ?Text
std::optional<Text> case_of(const Cp& cp, const Text& p_) {
    auto q = crate::syntax::lexer::chars::drop_prefix(p_, Text::lit("crate::"));
    auto&& _m = crate::prelude::get(cp.ctors, absolute(cp, q));
    if (prism_rtl::is_some(_m)) {
        return std::optional(parent_path(p_));
    }
    if (prism_rtl::is_none(_m)) {
        auto&& _m = crate::prelude::get(cp.ctors, prism_rtl::cat("prelude::", q));
        if (prism_rtl::is_some(_m)) {
            return std::optional(parent_path(p_));
        }
        if (prism_rtl::is_none(_m)) {
            auto&& _m = crate::prelude::get(cp.ctors, q);
            if (prism_rtl::is_some(_m)) {
                return std::optional(parent_path(p_));
            }
            if (prism_rtl::is_none(_m)) {
                return std::optional<Text>{};
            }
            prism_rtl::unreachable("no arm matched");
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


/// ParentPath: fn Text -> Text
Text parent_path(const Text& p_) {
    auto segs = split_on(p_, Text::lit("::"));
    return crate::syntax::lexer::chars::join(take(segs, crate::syntax::lexer::chars::dec(len(segs))), Text::lit("::"));
}


/// LastSegment: fn Text -> Text
Text last_segment(const Text& p_) {
    return or_(crate::syntax::lexer::chars::last(split_on(p_, Text::lit("::"))), p_);
}


/// Context: fn Model -> Cp
Cp context(const crate::lower::model::Model& model) {
    auto names = each(model.mods, [&](const crate::lower::model::ModDef& m) { return m.name; });
    auto tops = fold(names, Array<Text>{}, [&](const Array<Text>& acc, const Text& n) {
        return ({
            auto top = or_(index(split_on(n, Text::lit("::")), Nat(0u)), n);
            in_list(names, top) || in_list(acc, top)
            ? acc
            : crate::prelude::push(acc, top);
        });
    });
    auto mods = crate::prelude::push(append(names, tops), Text::lit("prelude"));
    auto base = Cp{.home = Text::lit(""), .mods = mods, .types = prelude_types(), .ctors = prelude_ctors(), .members = node_base(), .methods = Map<Text, bool>{}, .field_names = Map<Text, bool>{}, .fns = Map<Text, bool>{}, .fields = Map<Text, crate::lower::model::OutTy>{}, .renames = Map<Text, Text>{}, .pointers = Map<Text, bool>{}};
    auto with_elem = add_row(add_answer(base, model->answer), Text::lit(""), model.elem);
    return fold(model.mods, with_elem, [&](const Cp& cp, const crate::lower::model::ModDef& m) { return fold(m.items, cp, [&](const Cp& c, const crate::lower::model::Item& it) { return add_model_item(c, m.name, it); }); });
}


/// let preludeTypes
Map<Text, TyInfo> prelude_types() {
    return map_of(std::vector{std::tuple{Text::lit("prelude::Ordering"), TyInfo{.kind = Text::lit("choice"), .fields = Array<Text>{}, .params = Array<Text>{}}}, std::tuple{Text::lit("prelude::Span"), TyInfo{.kind = Text::lit("record"), .fields = Array(std::vector{Text::lit("file"), Text::lit("line"), Text::lit("column"), Text::lit("binding")}), .params = Array<Text>{}}}, std::tuple{Text::lit("prelude::Exception"), TyInfo{.kind = Text::lit("record"), .fields = Array(std::vector{Text::lit("kind"), Text::lit("message"), Text::lit("spans"), Text::lit("path_")}), .params = Array<Text>{}}}, std::tuple{Text::lit("prelude::Duration"), TyInfo{.kind = Text::lit("newtype"), .fields = Array<Text>{}, .params = Array<Text>{}}}, std::tuple{Text::lit("prelude::PreludeUnwrap"), TyInfo{.kind = Text::lit("tag"), .fields = Array<Text>{}, .params = Array<Text>{}}}, std::tuple{Text::lit("prelude::PreludeExceptions"), TyInfo{.kind = Text::lit("tag"), .fields = Array<Text>{}, .params = Array<Text>{}}}});
}


/// let preludeCtors
Map<Text, Text> prelude_ctors() {
    return map_of(std::vector{std::tuple{Text::lit("prelude::Ordering::Less"), Text::lit("choice")}, std::tuple{Text::lit("prelude::Ordering::Equal"), Text::lit("choice")}, std::tuple{Text::lit("prelude::Ordering::Greater"), Text::lit("choice")}});
}


/// let nodeBase
Map<Text, bool> node_base() {
    return map_of(std::vector{std::tuple{Text::lit("make"), true}, std::tuple{Text::lit("push"), true}, std::tuple{Text::lit("wake"), true}, std::tuple{Text::lit("started"), true}, std::tuple{Text::lit("deferred"), true}, std::tuple{Text::lit("build"), true}, std::tuple{Text::lit("swap"), true}, std::tuple{Text::lit("leave"), true}, std::tuple{Text::lit("patch"), true}, std::tuple{Text::lit("edges"), true}, std::tuple{Text::lit("release"), true}, std::tuple{Text::lit("clean_up"), true}, std::tuple{Text::lit("path"), true}, std::tuple{Text::lit("leave_row"), true}, std::tuple{Text::lit("answer"), true}, std::tuple{Text::lit("document"), true}, std::tuple{Text::lit("deliver"), true}, std::tuple{Text::lit("document_moved"), true}, std::tuple{Text::lit("me"), true}, std::tuple{Text::lit("result_dynamic"), true}});
}


/// AddModelItem: fn Cp, Text, Item -> Cp
Cp add_model_item(const Cp& cp, const Text& m, const crate::lower::model::Item& it) {
    if (prism_rtl::is<crate::lower::model::Item::ItType>(it)) {
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItType>(it).a0;
        return add_type(cp, m, t);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItTag>(it)) {
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItTag>(it).a0;
        return add_ty(cp, prism_rtl::cat(m, "::", t.name), TyInfo{.kind = Text::lit("tag"), .fields = each(t.fields, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
            auto&& f = std::get<1>(_p0);
            return f;
        }), .params = Array<Text>{}});
    }
    if (prism_rtl::is<crate::lower::model::Item::ItRow>(it)) {
        auto&& r = prism_rtl::as<crate::lower::model::Item::ItRow>(it).a0;
        return add_row(cp, m, r);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItJob>(it)) {
        auto&& j = prism_rtl::as<crate::lower::model::Item::ItJob>(it).a0;
        return add_ty(cp, prism_rtl::cat(m, "::", j.name), TyInfo{.kind = Text::lit("job"), .fields = each(j.fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
            auto&& f = std::get<0>(_p0);
            return f;
        }), .params = each(j.generics, [&](const std::tuple<Text, Array<Text>>& _p0) {
            auto&& g = std::get<0>(_p0);
            return g;
        })});
    }
    if (prism_rtl::is<crate::lower::model::Item::ItNode>(it)) {
        auto&& n = prism_rtl::as<crate::lower::model::Item::ItNode>(it).a0;
        return add_node(cp, m, n);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItFn>(it)) {
        auto&& f = prism_rtl::as<crate::lower::model::Item::ItFn>(it).a0;
        Cp this_ = cp;
        this_.fns = insert(this_.fns, prism_rtl::cat(m, "::", f.name), true);
        return this_;
    }
    {
        return cp;
    }
}


/// AddTy: fn Cp, Text, TyInfo -> Cp
Cp add_ty(const Cp& cp, const Text& path_, const TyInfo& info) {
    Cp this_ = cp;
    this_.types = insert(this_.types, path_, info);
    return this_;
}


/// AddCtor: fn Cp, Text, Text -> Cp
Cp add_ctor(const Cp& cp, const Text& path_, const Text& kind) {
    Cp this_ = cp;
    this_.ctors = insert(this_.ctors, path_, kind);
    return this_;
}


/// AddMember: fn Cp, Text -> Cp
Cp add_member(const Cp& cp, const Text& name) {
    Cp this_ = cp;
    this_.members = insert(this_.members, name, true);
    return this_;
}


/// AddType: fn Cp, Text, TyDef -> Cp
Cp add_type(const Cp& cp, const Text& m, const crate::lower::model::TyDef& t) {
    auto path_ = prism_rtl::cat(m, "::", t.name);
    auto first_ = or_(index(t.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
    auto&& _m = t.shape;
    if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
        return add_ty(cp, path_, TyInfo{.kind = Text::lit("record"), .fields = each(first_.fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
            auto&& f = std::get<0>(_p0);
            return f;
        }), .params = t.params});
    }
    if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
        return add_ty(cp, path_, TyInfo{.kind = Text::lit("newtype"), .fields = Array<Text>{}, .params = t.params});
    }
    if (prism_rtl::is<crate::lower::model::TyShape::ShapeUnit>(_m)) {
        return add_ty(cp, path_, TyInfo{.kind = Text::lit("unit"), .fields = Array<Text>{}, .params = t.params});
    }
    if (prism_rtl::is<crate::lower::model::TyShape::ShapeChoice>(_m)) {
        return fold(t.cases_, add_ty(cp, path_, TyInfo{.kind = Text::lit("choice"), .fields = Array<Text>{}, .params = t.params}), [&](const Cp& c, const crate::lower::model::CaseDef& k) { return add_ctor(c, prism_rtl::cat(path_, "::", k.name), Text::lit("choice")); });
    }
    prism_rtl::unreachable("no arm matched");
}


/// AddRow: fn Cp, Text, RowDef -> Cp
Cp add_row(const Cp& cp, const Text& m, const crate::lower::model::RowDef& r) {
    auto path_ = m == Text::lit("") ? r.name : prism_rtl::cat(m, "::", r.name);
    return fold(r.cases_, add_ty(cp, path_, TyInfo{.kind = Text::lit("choice"), .fields = Array<Text>{}, .params = Array<Text>{}}), [&](const Cp& c, const std::tuple<Text, Text>& _p1) {
        auto&& v_ = std::get<0>(_p1);
        return add_ctor(c, prism_rtl::cat(path_, "::", v_), Text::lit("choice"));
    });
}


/// AddAnswer: fn Cp, AnswerDef -> Cp
Cp add_answer(const Cp& cp, const crate::lower::model::AnswerDef& a) {
    return fold(a.cases_, add_ty(cp, Text::lit("Answer"), TyInfo{.kind = Text::lit("choice"), .fields = Array<Text>{}, .params = Array<Text>{}}), [&](const Cp& c, const crate::lower::model::AnswerCase& k) { return add_ctor(c, prism_rtl::cat("Answer::", k.variant), Text::lit("choice")); });
}


/// AddNode: fn Cp, Text, NodeDef -> Cp
Cp add_node(const Cp& cp, const Text& m, const crate::lower::model::NodeDef& n) {
    auto with_fields_ = fold(n.fields, cp, [&](const Cp& c, const std::tuple<Text, crate::lower::model::OutTy, Text>& _p1) {
        auto&& f = std::get<0>(_p1);
        return ({
            Cp this_ = add_member(c, f);
            this_.field_names = insert(this_.field_names, f, true);
            this_;
        });
    });
    auto with_methods = fold(append(n.methods, n.hosted), with_fields_, [&](const Cp& c, const crate::lower::model::MethDef& md) {
        return ({
            Cp this_ = add_member(c, md.name);
            this_.methods = insert(this_.methods, md.name, true);
            this_;
        });
    });
    auto with_builders = fold(n.builders, with_methods, [&](const Cp& c, const crate::lower::model::ForDef& b) { return add_member(c, prism_rtl::cat(b.name, "_build")); });
    auto with_gens = fold(n.gens, with_builders, [&](const Cp& c, const crate::lower::model::GenDef& g) { return add_member(c, prism_rtl::cat(g.name, "_build")); });
    return add_ty(with_gens, prism_rtl::cat(m, "::", n.name), TyInfo{.kind = Text::lit("node"), .fields = each(n.fields, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& f = std::get<0>(_p0);
        return f;
    }), .params = Array<Text>{}});
}


/// InHome: fn Cp, Text -> Cp
Cp in_home(const Cp& cp, const Text& m) {
    Cp this_ = cp;
    this_.home = m;
    return this_;
}


/// WithFields: fn Cp, [((Text, OutTy))] -> Cp
Cp with_fields(const Cp& cp, const Array<std::tuple<Text, crate::lower::model::OutTy>>& fs) {
    Cp this_ = cp;
    this_.fields = fold(fs, Map<Text, crate::lower::model::OutTy>{}, [&](const Map<Text, crate::lower::model::OutTy>& acc, const std::tuple<Text, crate::lower::model::OutTy>& _p1) {
        auto&& f = std::get<0>(_p1);
        auto&& t = std::get<1>(_p1);
        return insert(acc, f, t);
    });
    return this_;
}


/// CppType: unbounded fn Cp, OutTy -> Text
Text cpp_type(const Cp& cp, const crate::lower::model::OutTy& t) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutNat>(t)) {
        return Text::lit("Nat");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutInt>(t)) {
        return Text::lit("Int");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutU8>(t)) {
        return Text::lit("std::uint8_t");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutFloat>(t)) {
        return Text::lit("double");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutBool>(t)) {
        return Text::lit("bool");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutChar>(t)) {
        return Text::lit("char32_t");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutText>(t)) {
        return Text::lit("Text");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutCursor>(t)) {
        return Text::lit("Cursor");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRegex>(t)) {
        return Text::lit("Regex");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutReplacement>(t)) {
        return Text::lit("RegexReplacement");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutUnit>(t)) {
        return Text::lit("Unit");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutPath>(t)) {
        return Text::lit("Path");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDuration>(t)) {
        return Text::lit("Duration");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutError>(t)) {
        return Text::lit("Error");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t)) {
        auto&& m10791_14_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a0;
        auto&& m10791_14_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        if (m10791_14_0 == Text::lit("Cell")) {
            if (m10791_14_1.size() == 1u) {
                {
                    auto&& _c1 = index(m10791_14_1, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& i = prism_rtl::some_of(_c1);
                        return cpp_type(cp, i);
                    }
                }
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t)) {
        auto&& m10791_15_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a0;
        auto&& m10791_15_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        if (m10791_15_0 == Text::lit("RefCell")) {
            if (m10791_15_1.size() == 1u) {
                {
                    auto&& _c1 = index(m10791_15_1, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& i = prism_rtl::some_of(_c1);
                        return cpp_type(cp, i);
                    }
                }
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t)) {
        auto&& m10791_16_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a0;
        auto&& m10791_16_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        if (m10791_16_0 == Text::lit("Vec")) {
            if (m10791_16_1.size() == 1u) {
                {
                    auto&& _c1 = index(m10791_16_1, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& i = prism_rtl::some_of(_c1);
                        return prism_rtl::cat("std::vector<", cpp_type(cp, i), ">");
                    }
                }
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t)) {
        auto&& m10791_17_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a0;
        auto&& m10791_17_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        if (m10791_17_0 == Text::lit("Result")) {
            if (m10791_17_1.size() == 2u) {
                {
                    auto&& _c2 = index(m10791_17_1, Nat(0u));
                    if (prism_rtl::is_some(_c2)) {
                        auto&& a = prism_rtl::some_of(_c2);
                        {
                            auto&& _c1 = index(m10791_17_1, Nat(1u));
                            if (prism_rtl::is_some(_c1)) {
                                auto&& b = prism_rtl::some_of(_c1);
                                return prism_rtl::cat("Expected<", cpp_type(cp, a), ", ", cpp_type(cp, b), ">");
                            }
                        }
                    }
                }
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t)) {
        auto&& n = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a0;
        auto&& m10791_18_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        if (m10791_18_1.size() == 0u) {
            return own_type_path(cp, n);
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t)) {
        auto&& n = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a0;
        auto&& args = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        return prism_rtl::cat(own_type_path(cp, n), "<", cpp_types(cp, args), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t).a0;
        return prism_rtl::cat("std::optional<", cpp_type(cp, i), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t).a0;
        return prism_rtl::cat("Fallible<", cpp_type(cp, i), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t).a0;
        return prism_rtl::cat("std::tuple<", cpp_types(cp, ts), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutArray>(t)) {
        auto&& e = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t).a0;
        return prism_rtl::cat("Array<", cpp_type(cp, e), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(t)) {
        auto&& k = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t).a1;
        return prism_rtl::cat("Map<", cpp_type(cp, k), ", ", cpp_type(cp, v_), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(t)) {
        auto&& ps = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t).a0;
        auto&& r = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t).a1;
        return prism_rtl::cat("Fn<", cpp_type(cp, r), "(", param_types(cp, ps), ")>");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRef>(t)) {
        auto&& m10791_26_0 = prism_rtl::as<crate::lower::model::OutTy::OutRef>(t).a0;
        if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(m10791_26_0)) {
            auto&& ps = prism_rtl::as<crate::lower::model::OutTy::OutFn>(m10791_26_0).a0;
            auto&& r = prism_rtl::as<crate::lower::model::OutTy::OutFn>(m10791_26_0).a1;
            return prism_rtl::cat("const std::function<", cpp_type(cp, r), "(", param_types(cp, ps), ")>&");
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRef>(t)) {
        auto&& m10791_27_0 = prism_rtl::as<crate::lower::model::OutTy::OutRef>(t).a0;
        if (prism_rtl::is<crate::lower::model::OutTy::OutSlice>(m10791_27_0)) {
            auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutSlice>(m10791_27_0).a0;
            return prism_rtl::cat("std::span<const ", cpp_type(cp, i), ">");
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRef>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutRef>(t).a0;
        return prism_rtl::cat("const ", cpp_type(cp, i), "&");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t)) {
        auto&& a = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t).a0;
        auto&& b = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t).a1;
        return prism_rtl::cat("prism_rtl::Fn<prism_rtl::JobRef<", cpp_type(cp, b), ">(", cpp_type(cp, a), ")>");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutJob>(t)) {
        auto&& b = prism_rtl::as<crate::lower::model::OutTy::OutJob>(t).a0;
        return prism_rtl::cat("prism_rtl::JobRef<", cpp_type(cp, b), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutEvent>(t).a0;
        return prism_rtl::cat("Event<", cpp_type(cp, i), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(t).a0;
        return prism_rtl::cat("Dynamic<", cpp_type(cp, i), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutGen>(t)) {
        auto&& n = prism_rtl::as<crate::lower::model::OutTy::OutGen>(t).a0;
        return n;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRc>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t).a0;
        return is_value_ty(cp, i)
            ? cpp_type(cp, i)
            : prism_rtl::cat("prism_rtl::Rc<", cpp_type(cp, i), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutPod>(t)) {
        return Text::lit("Pod");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutShowAny>(t)) {
        return Text::lit("prism_rtl::Rc<const DynShow>");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutHold>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutHold>(t).a0;
        return prism_rtl::cat("Hold<", cpp_type(cp, i), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutStamped>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutStamped>(t).a0;
        return prism_rtl::cat("Stamped<", cpp_type(cp, i), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutSnapshot>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutSnapshot>(t).a0;
        return prism_rtl::cat("Snapshot<", cpp_type(cp, i), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDefer>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutDefer>(t).a0;
        return prism_rtl::cat("Defer<", cpp_type(cp, i), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutWeak>(t)) {
        auto&& n = prism_rtl::as<crate::lower::model::OutTy::OutWeak>(t).a0;
        return prism_rtl::cat("prism_rtl::Weak<", type_path(n), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutCell>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutCell>(t).a0;
        return cpp_type(cp, i);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutWakes>(t)) {
        return Text::lit("Wakes");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutCount>(t)) {
        return Text::lit("std::uint32_t");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutObj>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutObj>(t).a0;
        return prism_rtl::cat("prism_rtl::Rc<", cpp_type(cp, i), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutSlice>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutSlice>(t).a0;
        return prism_rtl::cat("std::span<const ", cpp_type(cp, i), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutPort>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutPort>(t).a0;
        return prism_rtl::cat("Port<", cpp_type(cp, i), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutLive>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutLive>(t).a0;
        return prism_rtl::cat("Live<", cpp_type(cp, i), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutUnknown>(t)) {
        auto&& m10791_49_0 = prism_rtl::as<crate::lower::model::OutTy::OutUnknown>(t).a0;
        if (m10791_49_0 == Text::lit("the job\'s turn")) {
            return Text::lit("decltype(this->cycle())");
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutUnknown>(t)) {
        auto&& what = prism_rtl::as<crate::lower::model::OutTy::OutUnknown>(t).a0;
        return prism_rtl::cat("Unit /* ", what, " */");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutQuantified>(t)) {
        auto&& b = prism_rtl::as<crate::lower::model::OutTy::OutQuantified>(t).a0;
        return prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal(), "a quantified type variable of `", b, "`: no instantiation gives it a type\")");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> CppType::cycle() const {
    const auto& cp = this->cp;
    const auto& t = this->t;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutNat>(t) ? prism_rtl::finished(Text::lit("Nat"))
        : prism_rtl::is<crate::lower::model::OutTy::OutInt>(t) ? prism_rtl::finished(Text::lit("Int"))
        : prism_rtl::is<crate::lower::model::OutTy::OutU8>(t) ? prism_rtl::finished(Text::lit("std::uint8_t"))
        : prism_rtl::is<crate::lower::model::OutTy::OutFloat>(t) ? prism_rtl::finished(Text::lit("double"))
        : prism_rtl::is<crate::lower::model::OutTy::OutBool>(t) ? prism_rtl::finished(Text::lit("bool"))
        : prism_rtl::is<crate::lower::model::OutTy::OutChar>(t) ? prism_rtl::finished(Text::lit("char32_t"))
        : prism_rtl::is<crate::lower::model::OutTy::OutText>(t) ? prism_rtl::finished(Text::lit("Text"))
        : prism_rtl::is<crate::lower::model::OutTy::OutCursor>(t) ? prism_rtl::finished(Text::lit("Cursor"))
        : prism_rtl::is<crate::lower::model::OutTy::OutRegex>(t) ? prism_rtl::finished(Text::lit("Regex"))
        : prism_rtl::is<crate::lower::model::OutTy::OutReplacement>(t) ? prism_rtl::finished(Text::lit("RegexReplacement"))
        : prism_rtl::is<crate::lower::model::OutTy::OutUnit>(t) ? prism_rtl::finished(Text::lit("Unit"))
        : prism_rtl::is<crate::lower::model::OutTy::OutPath>(t) ? prism_rtl::finished(Text::lit("Path"))
        : prism_rtl::is<crate::lower::model::OutTy::OutDuration>(t) ? prism_rtl::finished(Text::lit("Duration"))
        : prism_rtl::is<crate::lower::model::OutTy::OutError>(t) ? prism_rtl::finished(Text::lit("Error"))
        : prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t) && ({
        auto&& m10791_14_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a0;
        auto&& m10791_14_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        (m10791_14_0 == Text::lit("Cell")) && (m10791_14_1.size() == 1u) && ({
        auto&& _c1 = index(m10791_14_1, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m10791_14_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a0;
        auto&& m10791_14_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        auto&& _c1 = index(m10791_14_1, Nat(0u));
        auto&& i = prism_rtl::some_of(_c1);
        prism_rtl::more(prism_rtl::rc(CppType(cp, i)));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t) && ({
        auto&& m10791_15_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a0;
        auto&& m10791_15_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        (m10791_15_0 == Text::lit("RefCell")) && (m10791_15_1.size() == 1u) && ({
        auto&& _c1 = index(m10791_15_1, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m10791_15_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a0;
        auto&& m10791_15_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        auto&& _c1 = index(m10791_15_1, Nat(0u));
        auto&& i = prism_rtl::some_of(_c1);
        prism_rtl::more(prism_rtl::rc(CppType(cp, i)));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t) && ({
        auto&& m10791_16_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a0;
        auto&& m10791_16_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        (m10791_16_0 == Text::lit("Vec")) && (m10791_16_1.size() == 1u) && ({
        auto&& _c1 = index(m10791_16_1, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m10791_16_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a0;
        auto&& m10791_16_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        auto&& _c1 = index(m10791_16_1, Nat(0u));
        auto&& i = prism_rtl::some_of(_c1);
        ({
        auto cp_1 = cp;
        call_then(start_cpp_type(cp_1, i), [=](Text cpp_type_11252) { return prism_rtl::finished(prism_rtl::cat("std::vector<", cpp_type_11252, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t) && ({
        auto&& m10791_17_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a0;
        auto&& m10791_17_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        (m10791_17_0 == Text::lit("Result")) && (m10791_17_1.size() == 2u) && ({
        auto&& _c2 = index(m10791_17_1, Nat(0u));
        prism_rtl::is_some(_c2) && ({
        auto&& a = prism_rtl::some_of(_c2);
        ({
        auto&& _c1 = index(m10791_17_1, Nat(1u));
        prism_rtl::is_some(_c1);
    });
    });
    });
    }) ? ({
        auto&& m10791_17_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a0;
        auto&& m10791_17_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        auto&& _c2 = index(m10791_17_1, Nat(0u));
        auto&& a = prism_rtl::some_of(_c2);
        auto&& _c1 = index(m10791_17_1, Nat(1u));
        auto&& b = prism_rtl::some_of(_c1);
        ({
        auto cp_1 = cp;
        call_then(start_cpp_type(cp_1, a), [=](Text cpp_type_11313) { return call_then(start_cpp_type(cp_1, b), [=](Text cpp_type_11330) { return prism_rtl::finished(prism_rtl::cat("Expected<", cpp_type_11313, ", ", cpp_type_11330, ">")); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t) && ({
        auto&& n = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a0;
        auto&& m10791_18_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        (m10791_18_1.size() == 0u);
    }) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a0;
        auto&& m10791_18_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        prism_rtl::finished(own_type_path(cp, n));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a0;
        auto&& args = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        auto n_3 = n;
        call_then(start_cpp_types(cp_2, args_1), [=](Text cpp_types_11431) { return prism_rtl::finished(prism_rtl::cat(own_type_path(cp_2, n_3), "<", cpp_types_11431, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t).a0;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_11482) { return prism_rtl::finished(prism_rtl::cat("std::optional<", cpp_type_11482, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRes>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t).a0;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_11524) { return prism_rtl::finished(prism_rtl::cat("Fallible<", cpp_type_11524, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t) ? ({
        auto&& ts = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t).a0;
        ({
        auto cp_1 = cp;
        auto ts_2 = ts;
        call_then(start_cpp_types(cp_1, ts_2), [=](Text cpp_types_11571) { return prism_rtl::finished(prism_rtl::cat("std::tuple<", cpp_types_11571, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutArray>(t) ? ({
        auto&& e = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t).a0;
        ({
        auto cp_1 = cp;
        auto e_2 = e;
        call_then(start_cpp_type(cp_1, e_2), [=](Text cpp_type_11614) { return prism_rtl::finished(prism_rtl::cat("Array<", cpp_type_11614, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutMap>(t) ? ({
        auto&& k = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t).a1;
        ({
        auto cp_1 = cp;
        auto k_2 = k;
        auto v__3 = v_;
        call_then(start_cpp_type(cp_1, k_2), [=](Text cpp_type_11654) { return call_then(start_cpp_type(cp_1, v__3), [=](Text cpp_type_11671) { return prism_rtl::finished(prism_rtl::cat("Map<", cpp_type_11654, ", ", cpp_type_11671, ">")); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutFn>(t) ? ({
        auto&& ps = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t).a0;
        auto&& r = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t).a1;
        ({
        auto cp_1 = cp;
        auto ps_2 = ps;
        auto r_3 = r;
        call_then(start_cpp_type(cp_1, r_3), [=](Text cpp_type_11710) { return call_then(start_param_types(cp_1, ps_2), [=](Text param_types_11726) { return prism_rtl::finished(prism_rtl::cat("Fn<", cpp_type_11710, "(", param_types_11726, ")>")); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRef>(t) && ({
        auto&& m10791_26_0 = prism_rtl::as<crate::lower::model::OutTy::OutRef>(t).a0;
        prism_rtl::is<crate::lower::model::OutTy::OutFn>(m10791_26_0);
    }) ? ({
        auto&& m10791_26_0 = prism_rtl::as<crate::lower::model::OutTy::OutRef>(t).a0;
        auto&& ps = prism_rtl::as<crate::lower::model::OutTy::OutFn>(m10791_26_0).a0;
        auto&& r = prism_rtl::as<crate::lower::model::OutTy::OutFn>(m10791_26_0).a1;
        ({
        auto cp_1 = cp;
        auto ps_2 = ps;
        auto r_3 = r;
        call_then(start_cpp_type(cp_1, r_3), [=](Text cpp_type_11796) { return call_then(start_param_types(cp_1, ps_2), [=](Text param_types_11812) { return prism_rtl::finished(prism_rtl::cat("const std::function<", cpp_type_11796, "(", param_types_11812, ")>&")); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRef>(t) && ({
        auto&& m10791_27_0 = prism_rtl::as<crate::lower::model::OutTy::OutRef>(t).a0;
        prism_rtl::is<crate::lower::model::OutTy::OutSlice>(m10791_27_0);
    }) ? ({
        auto&& m10791_27_0 = prism_rtl::as<crate::lower::model::OutTy::OutRef>(t).a0;
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutSlice>(m10791_27_0).a0;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_11878) { return prism_rtl::finished(prism_rtl::cat("std::span<const ", cpp_type_11878, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRef>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutRef>(t).a0;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_11917) { return prism_rtl::finished(prism_rtl::cat("const ", cpp_type_11917, "&")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t) ? ({
        auto&& a = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t).a0;
        auto&& b = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t).a1;
        ({
        auto a_1 = a;
        auto b_2 = b;
        auto cp_3 = cp;
        call_then(start_cpp_type(cp_3, b_2), [=](Text cpp_type_11987) { return call_then(start_cpp_type(cp_3, a_1), [=](Text cpp_type_12004) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::Fn<prism_rtl::JobRef<", cpp_type_11987, ">(", cpp_type_12004, ")>")); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutJob>(t) ? ({
        auto&& b = prism_rtl::as<crate::lower::model::OutTy::OutJob>(t).a0;
        ({
        auto b_1 = b;
        auto cp_2 = cp;
        call_then(start_cpp_type(cp_2, b_1), [=](Text cpp_type_12056) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::JobRef<", cpp_type_12056, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutEvent>(t).a0;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_12097) { return prism_rtl::finished(prism_rtl::cat("Event<", cpp_type_12097, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutDyn>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(t).a0;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_12138) { return prism_rtl::finished(prism_rtl::cat("Dynamic<", cpp_type_12138, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutGen>(t) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::OutTy::OutGen>(t).a0;
        prism_rtl::finished(n);
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRc>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t).a0;
        is_value_ty(cp, i)
        ? prism_rtl::more(prism_rtl::rc(CppType(cp, i)))
        : ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_12240) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::Rc<", cpp_type_12240, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutPod>(t) ? prism_rtl::finished(Text::lit("Pod"))
        : prism_rtl::is<crate::lower::model::OutTy::OutShowAny>(t) ? prism_rtl::finished(Text::lit("prism_rtl::Rc<const DynShow>"))
        : prism_rtl::is<crate::lower::model::OutTy::OutHold>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutHold>(t).a0;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_12344) { return prism_rtl::finished(prism_rtl::cat("Hold<", cpp_type_12344, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutStamped>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutStamped>(t).a0;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_12389) { return prism_rtl::finished(prism_rtl::cat("Stamped<", cpp_type_12389, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutSnapshot>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutSnapshot>(t).a0;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_12436) { return prism_rtl::finished(prism_rtl::cat("Snapshot<", cpp_type_12436, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutDefer>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutDefer>(t).a0;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_12477) { return prism_rtl::finished(prism_rtl::cat("Defer<", cpp_type_12477, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutWeak>(t) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::OutTy::OutWeak>(t).a0;
        prism_rtl::finished(prism_rtl::cat("prism_rtl::Weak<", type_path(n), ">"));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutCell>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutCell>(t).a0;
        prism_rtl::more(prism_rtl::rc(CppType(cp, i)));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutWakes>(t) ? prism_rtl::finished(Text::lit("Wakes"))
        : prism_rtl::is<crate::lower::model::OutTy::OutCount>(t) ? prism_rtl::finished(Text::lit("std::uint32_t"))
        : prism_rtl::is<crate::lower::model::OutTy::OutObj>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutObj>(t).a0;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_12652) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::Rc<", cpp_type_12652, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutSlice>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutSlice>(t).a0;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_12703) { return prism_rtl::finished(prism_rtl::cat("std::span<const ", cpp_type_12703, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutPort>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutPort>(t).a0;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_12742) { return prism_rtl::finished(prism_rtl::cat("Port<", cpp_type_12742, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutLive>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutLive>(t).a0;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_12781) { return prism_rtl::finished(prism_rtl::cat("Live<", cpp_type_12781, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutUnknown>(t) && ({
        auto&& m10791_49_0 = prism_rtl::as<crate::lower::model::OutTy::OutUnknown>(t).a0;
        (m10791_49_0 == Text::lit("the job\'s turn"));
    }) ? ({
        auto&& m10791_49_0 = prism_rtl::as<crate::lower::model::OutTy::OutUnknown>(t).a0;
        prism_rtl::finished(Text::lit("decltype(this->cycle())"));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutUnknown>(t) ? ({
        auto&& what = prism_rtl::as<crate::lower::model::OutTy::OutUnknown>(t).a0;
        prism_rtl::finished(prism_rtl::cat("Unit /* ", what, " */"));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutQuantified>(t) ? ({
        auto&& b = prism_rtl::as<crate::lower::model::OutTy::OutQuantified>(t).a0;
        prism_rtl::finished(prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal(), "a quantified type variable of `", b, "`: no instantiation gives it a type\")"));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CppType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_type(Cp cp, crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<CppType>(cp, t);
}


/// CppTypes: unbounded fn Cp, [OutTy] -> Text
Text cpp_types(const Cp& cp, const Array<crate::lower::model::OutTy>& ts) {
    return crate::syntax::lexer::chars::join(run_to_end(each_job(ts, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::OutTy)>>(prism_rtl::rc([=](crate::lower::model::OutTy p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto t = p0;
                (prism_rtl::more(prism_rtl::rc(CppType(cp_1_2, t))));
            });
        }));
        });
    })));
    }))), Text::lit(", "));
}


prism_rtl::Turn<Text> CppTypes::cycle() const {
    const auto& cp = this->cp;
    const auto& ts = this->ts;
    auto cp_1 = cp;
    auto ts_2 = ts;
    return call_value(each_job(ts_2, ({
        auto cp_1_3 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::OutTy)>>(prism_rtl::rc([=](crate::lower::model::OutTy p0) {
        return ({
            auto cp_1_3_3 = cp_1_3;
            entered(once_job([=]() {
            return ({
                auto t = p0;
                (prism_rtl::more(prism_rtl::rc(CppType(cp_1_3_3, t))));
            });
        }));
        });
    })));
    })), [=](Array<Text> each_13099) { return prism_rtl::finished(crate::syntax::lexer::chars::join(each_13099, Text::lit(", "))); });
}


/// `Start CppTypes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_types(Cp cp, Array<crate::lower::model::OutTy> ts) {
    return prism_rtl::make_rc<CppTypes>(cp, ts);
}


/// ParamTypes: unbounded fn Cp, [OutTy] -> Text
Text param_types(const Cp& cp, const Array<crate::lower::model::OutTy>& ts) {
    return crate::syntax::lexer::chars::join(run_to_end(each_job(ts, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::OutTy)>>(prism_rtl::rc([=](crate::lower::model::OutTy p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto t = p0;
                call_then(start_cpp_type(cp_1_2, t), [=](Text cpp_type_13314) { return prism_rtl::finished(prism_rtl::cat("const ", cpp_type_13314, "&")); });
            });
        }));
        });
    })));
    }))), Text::lit(", "));
}


prism_rtl::Turn<Text> ParamTypes::cycle() const {
    const auto& cp = this->cp;
    const auto& ts = this->ts;
    auto cp_1 = cp;
    auto ts_2 = ts;
    return call_value(each_job(ts_2, ({
        auto cp_1_3 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::OutTy)>>(prism_rtl::rc([=](crate::lower::model::OutTy p0) {
        return ({
            auto cp_1_3_3 = cp_1_3;
            entered(once_job([=]() {
            return ({
                auto t = p0;
                call_then(start_cpp_type(cp_1_3_3, t), [=](Text cpp_type_13314) { return prism_rtl::finished(prism_rtl::cat("const ", cpp_type_13314, "&")); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_13292) { return prism_rtl::finished(crate::syntax::lexer::chars::join(each_13292, Text::lit(", "))); });
}


/// `Start ParamTypes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_param_types(Cp cp, Array<crate::lower::model::OutTy> ts) {
    return prism_rtl::make_rc<ParamTypes>(cp, ts);
}


/// OwnTypePath: fn Cp, Text -> Text
Text own_type_path(const Cp& cp, const Text& n) {
    auto shadowed = (!crate::syntax::lexer::chars::contains(n, Text::lit(":"))) && in_list(Array(std::vector{Text::lit("Job"), Text::lit("Node"), Text::lit("Row"), Text::lit("Turn"), Text::lit("Program")}), n);
    auto&& _m = type_of(cp, n);
    if (prism_rtl::is_some(_m)) {
        return shadowed ? prism_rtl::cat("crate::", cp.home, "::", n) : type_path(n);
    }
    if (prism_rtl::is_none(_m)) {
        return type_path(n);
    }
    prism_rtl::unreachable("no arm matched");
}


/// TypePath: fn Text -> Text
Text type_path(const Text& p_) {
    auto no_fish = crate::syntax::lexer::chars::join(split_on(p_, Text::lit("::<")), Text::lit("<"));
    auto no_holes = crate::syntax::lexer::chars::join(split_on(no_fish, Text::lit(", _>")), Text::lit(">"));
    return crate::syntax::lexer::chars::join(split_on(no_holes, Text::lit("<_>")), Text::lit(""));
}


/// IsValueTy: fn Cp, OutTy -> Bool
bool is_value_ty(const Cp& cp, const crate::lower::model::OutTy& t) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t)) {
        auto&& n = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a0;
        auto&& _m = type_of(cp, n);
        if (prism_rtl::is_some(_m)) {
            auto&& info = prism_rtl::some_of(_m);
            return (info.kind != Text::lit("node")) && (info.kind != Text::lit("job"));
        }
        if (prism_rtl::is_none(_m)) {
            return false;
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutCell>(t)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutPort>(t)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutHold>(t)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutStamped>(t)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutSnapshot>(t)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDefer>(t)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutObj>(t)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutWakes>(t)) {
        return false;
    }
    {
        return true;
    }
}

}  // namespace crate::emit::cpp
