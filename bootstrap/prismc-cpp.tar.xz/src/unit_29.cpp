// The module `Check.Types.Recording`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/types/recording/module.hpp>
#include <check/errors/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Check.Types.Recording`, from `target/bootstrap/cpp-src/prismc/check/types/recording.prism`.
namespace crate::check::types::recording {

/// AtHere: fn St, Range -> SrcAt
crate::check::typed::SrcAt at_here_f(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1) {
    return crate::check::typed::SrcAt{.file_p = st_p0.file_p, .span_p = span_p1};
}


/// NoteTy: fn St, Range, Ty -> St
crate::check::types::St note_ty_f(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const crate::check::types::Ty& t_p2) {
    return !st_p0.recording_p
        ? st_p0
        : ({
        crate::check::types::St this_ = st_p0;
        prism_rtl::deref(this_.typed_p).exprs_p = crate::prelude::push(prism_rtl::deref(this_.typed_p).exprs_p, crate::check::typed::TyNote{.at_p = at_here_f(st_p0, span_p1), .ty_p = t_p2});
        (std::move(this_));
    });
}


/// NoteBinder: fn St, Range, Text, Ty -> St
crate::check::types::St note_binder_f(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const Text& name_p2, const crate::check::types::Ty& t_p3) {
    return !st_p0.recording_p
        ? st_p0
        : ({
        crate::check::types::St this_ = st_p0;
        prism_rtl::deref(this_.typed_p).binders_p = crate::prelude::push(prism_rtl::deref(this_.typed_p).binders_p, crate::check::typed::BinderNote{.at_p = at_here_f(st_p0, span_p1), .name_p = name_p2, .ty_p = t_p3});
        (std::move(this_));
    });
}


/// NoteLocal: fn St, Range, Nat -> St
crate::check::types::St note_local_f(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const Nat& id_p2) {
    return !st_p0.recording_p
        ? st_p0
        : ({
        crate::check::types::St this_ = st_p0;
        prism_rtl::deref(this_.typed_p).locals_p = crate::prelude::push(prism_rtl::deref(this_.typed_p).locals_p, crate::check::typed::LocalNote{.at_p = at_here_f(st_p0, span_p1), .id_p = id_p2});
        (std::move(this_));
    });
}


/// NoteGlobal: fn St, Range, Text -> St
crate::check::types::St note_global_f(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const Text& qk_p2) {
    return !st_p0.recording_p
        ? st_p0
        : ({
        crate::check::types::St this_ = st_p0;
        prism_rtl::deref(this_.typed_p).globals_p = crate::prelude::push(prism_rtl::deref(this_.typed_p).globals_p, crate::check::typed::GlobalNote{.at_p = at_here_f(st_p0, span_p1), .target_p = qk_p2});
        (std::move(this_));
    });
}


/// NoteCall: fn St, Range, Nat -> St
crate::check::types::St note_call_f(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const Nat& id_p2) {
    return !st_p0.recording_p
        ? st_p0
        : ({
        crate::check::types::St this_ = st_p0;
        prism_rtl::deref(this_.typed_p).calls_p = crate::prelude::push(prism_rtl::deref(this_.typed_p).calls_p, crate::check::typed::LocalNote{.at_p = at_here_f(st_p0, span_p1), .id_p = id_p2});
        (std::move(this_));
    });
}


/// NoteUse: fn St, Range, Nat -> St
crate::check::types::St note_use_f(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const Nat& id_p2) {
    return !st_p0.recording_p
        ? st_p0
        : ({
        crate::check::types::St this_ = st_p0;
        prism_rtl::deref(this_.typed_p).uses_p = crate::prelude::push(prism_rtl::deref(this_.typed_p).uses_p, crate::check::typed::LocalNote{.at_p = at_here_f(st_p0, span_p1), .id_p = id_p2});
        (std::move(this_));
    });
}


/// NoteGen: fn St, Range, Text, Scheme -> St
crate::check::types::St note_gen_f(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const Text& name_p2, const crate::check::types::Scheme& sc_p3) {
    return (!st_p0.recording_p) || ((crate::prelude::len(sc_p3.qs_p) == Nat(0u)) && (crate::prelude::len(sc_p3.cqs_p) == Nat(0u)))
        ? st_p0
        : ({
        crate::check::types::St this_ = st_p0;
        prism_rtl::deref(this_.typed_p).gens_p = crate::prelude::push(prism_rtl::deref(this_.typed_p).gens_p, crate::check::typed::GenNote{.at_p = at_here_f(st_p0, span_p1), .name_p = name_p2, .tys_p = sc_p3.qs_p, .cols_p = sc_p3.cqs_p});
        (std::move(this_));
    });
}


/// NoteInst: fn St, Range, Text, Scheme, Inst -> St
crate::check::types::St note_inst_f(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const Text& name_p2, const crate::check::types::Scheme& sc_p3, const crate::check::types::schemes::Inst& inst_p4) {
    return !st_p0.recording_p
        ? st_p0
        : ({
        crate::check::types::St this_ = st_p0;
        prism_rtl::deref(this_.typed_p).insts_p = crate::prelude::push(prism_rtl::deref(this_.typed_p).insts_p, crate::check::typed::InstNote{.at_p = at_here_f(st_p0, span_p1), .name_p = name_p2, .tys_p = crate::prelude::each(sc_p3.qs_p, [&](const Text& q_p5) { return std::tuple{q_p5, crate::prelude::or_(crate::prelude::get(inst_p4.tys_p, q_p5), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))}; }), .cols_p = crate::prelude::each(sc_p3.cqs_p, [&](const Text& q_p6) { return std::tuple{q_p6, crate::prelude::or_(crate::prelude::get(inst_p4.cols_p, q_p6), crate::check::types::Col(crate::check::types::Col::CBound{}))}; })});
        (std::move(this_));
    });
}


/// NoteApp: fn St, Range, Text, Text, Text, [Nat], Text, Col -> St
crate::check::types::St note_app_f(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const Text& callee_p2, const Text& kind_p3, const Text& layer_p4, const Array<Nat>& lifted_p5, const Text& inner_p6, const crate::check::types::Col& col_p7) {
    return !st_p0.recording_p
        ? st_p0
        : ({
        crate::check::types::St this_ = st_p0;
        prism_rtl::deref(this_.typed_p).apps_p = crate::prelude::push(prism_rtl::deref(this_.typed_p).apps_p, crate::check::typed::AppNote{.at_p = at_here_f(st_p0, span_p1), .callee_p = callee_p2, .kind_p = kind_p3, .layer_p = layer_p4, .lifted_p = lifted_p5, .inner_p = inner_p6, .color_p = col_p7});
        (std::move(this_));
    });
}


/// NoteLift: fn St, Range, Text, [Range] -> St
crate::check::types::St note_lift_f(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const Text& sigil_p2, const Array<crate::syntax::Range>& operands_p3) {
    return (!st_p0.recording_p) || (crate::prelude::len(operands_p3) == Nat(0u))
        ? st_p0
        : ({
        crate::check::types::St this_ = st_p0;
        prism_rtl::deref(this_.typed_p).lifts_p = crate::prelude::push(prism_rtl::deref(this_.typed_p).lifts_p, crate::check::typed::LiftNote{.at_p = at_here_f(st_p0, span_p1), .sigil_p = sigil_p2, .operands_p = operands_p3});
        (std::move(this_));
    });
}


/// NoteFn: fn St, Range, Text, Col, Col -> St
crate::check::types::St note_fn_f(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const Text& name_p2, const crate::check::types::Col& declared_p3, const crate::check::types::Col& body_p4) {
    return !st_p0.recording_p
        ? st_p0
        : ({
        crate::check::types::St this_ = st_p0;
        prism_rtl::deref(this_.typed_p).fns_p = crate::prelude::push(prism_rtl::deref(this_.typed_p).fns_p, crate::check::typed::FnNote{.at_p = at_here_f(st_p0, span_p1), .name_p = name_p2, .declared_p = declared_p3, .body_p = body_p4});
        (std::move(this_));
    });
}


/// NoteImpl: fn St, Nat, Range, Text, Ty, Text -> St
crate::check::types::St note_impl_f(const crate::check::types::St& st_p0, const Nat& file_p1, const crate::syntax::Range& span_p2, const Text& cls_p3, const crate::check::types::Ty& t_p4, const Text& how_p5) {
    return (((!st_p0.recording_p) || crate::syntax::lexer::chars::has_prefix_f(cls_p3, Text::lit("Range "))) || (cls_p3 == Text::lit("Prelude.Sub"))) || (cls_p3 == Text::lit("Prelude.Signed"))
        ? st_p0
        : ({
        crate::check::types::St this_ = st_p0;
        prism_rtl::deref(this_.typed_p).impls_p = crate::prelude::push(prism_rtl::deref(this_.typed_p).impls_p, crate::check::typed::ImplNote{.at_p = crate::check::typed::SrcAt{.file_p = file_p1, .span_p = span_p2}, .cls_p = cls_p3, .ty_p = t_p4, .how_p = how_p5});
        (std::move(this_));
    });
}


/// NoteChoice: fn St, Nat, Range, Text, Text -> St
crate::check::types::St note_choice_f(const crate::check::types::St& st_p0, const Nat& file_p1, const crate::syntax::Range& span_p2, const Text& cls_p3, const Text& ch_p4) {
    auto k_p5 = choice_key_f(file_p1, span_p2, cls_p3);
    return (crate::syntax::lexer::chars::has_prefix_f(cls_p3, Text::lit("Range ")) || (cls_p3 == Text::lit("Prelude.Sub"))) || (cls_p3 == Text::lit("Prelude.Signed"))
        ? st_p0
        : ({
        crate::check::types::St this_ = st_p0;
        this_.choices_p = crate::prelude::insert(this_.choices_p, k_p5, crate::check::types::add_text_f(crate::prelude::or_(crate::prelude::get(this_.choices_p, k_p5), Array<Text>{}), ch_p4));
        (std::move(this_));
    });
}


/// NoteSizeTy: fn St, Range, Ty -> St
crate::check::types::St note_size_ty_f(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const crate::check::types::Ty& t_p2) {
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p2)) {
        auto&& ps_p3 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p2).a1;
        auto&& _m = crate::prelude::index(ps_p3, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& p_p4 = prism_rtl::some_of(_m);
            crate::check::types::St this_ = st_p0;
            this_.size_tys_p = crate::prelude::insert(this_.size_tys_p, prism_rtl::cat(st_p0.file_p, ":", span_p1.start_p, ":", span_p1.end_p), p_p4);
            return this_;
        }
        if (prism_rtl::is_none(_m)) {
            return st_p0;
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        return st_p0;
    }
}


/// ChoiceKey: fn Nat, Range, Text -> Text
Text choice_key_f(const Nat& file_p0, const crate::syntax::Range& span_p1, const Text& cls_p2) {
    return prism_rtl::cat(file_p0, ":", span_p1.start_p, ":", span_p1.end_p, ":", cls_p2);
}


/// NoteMethod: fn St, Range, Text, Text -> St
crate::check::types::St note_method_f(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const Text& method_p2, const Text& cls_p3) {
    return !st_p0.recording_p
        ? st_p0
        : ({
        crate::check::types::St this_ = st_p0;
        prism_rtl::deref(this_.typed_p).methods_p = crate::prelude::push(prism_rtl::deref(this_.typed_p).methods_p, crate::check::typed::MethodNote{.at_p = at_here_f(st_p0, span_p1), .method_p = method_p2, .cls_p = cls_p3});
        (std::move(this_));
    });
}


/// NoteGroup: fn St, Range, Text, [ [Nat] ] -> St
crate::check::types::St note_group_f(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const Text& kind_p2, const Array<Array<Nat>>& order_p3) {
    return !st_p0.recording_p
        ? st_p0
        : ({
        crate::check::types::St this_ = st_p0;
        prism_rtl::deref(this_.typed_p).groups_p = crate::prelude::push(prism_rtl::deref(this_.typed_p).groups_p, crate::check::typed::GroupNote{.at_p = at_here_f(st_p0, span_p1), .kind_p = kind_p2, .order_p = order_p3});
        (std::move(this_));
    });
}


/// ZonkTyped: unbounded fn St -> TProgram
crate::check::typed::TProgram zonk_typed_f(const crate::check::types::St& st_p0) {
    auto t_p1 = st_p0.typed_p;
    crate::check::typed::TProgram this_ = t_p1;
    this_.exprs_p = crate::prelude::run_to_end(crate::prelude::each_job(this_.exprs_p, ({
        auto st_p0x = st_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::typed::TyNote>(crate::check::typed::TyNote)>>(prism_rtl::rc([=, st_p0x = std::move(st_p0x)](crate::check::typed::TyNote p0) {
        return ({
            auto st_p0xy = st_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, st_p0xy = std::move(st_p0xy)]() {
            return ({
                auto n_p2 = p0;
                (crate::prelude::call_then(start_resolve_ty_f(st_p0xy, prism_rtl::deref(n_p2).ty_p), [=](crate::check::types::Ty resolve_ty_f_6257) { return prism_rtl::finished(crate::check::typed::TyNote{.at_p = prism_rtl::deref(n_p2).at_p, .ty_p = resolve_ty_f_6257}); }));
            });
        })));
        });
    })));
    })));
    this_.binders_p = crate::prelude::run_to_end(crate::prelude::each_job(this_.binders_p, ({
        auto st_p0x = st_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::typed::BinderNote>(crate::check::typed::BinderNote)>>(prism_rtl::rc([=, st_p0x = std::move(st_p0x)](crate::check::typed::BinderNote p0) {
        return ({
            auto st_p0xy = st_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, st_p0xy = std::move(st_p0xy)]() {
            return ({
                auto n_p3 = p0;
                (crate::prelude::call_then(start_resolve_ty_f(st_p0xy, prism_rtl::deref(n_p3).ty_p), [=](crate::check::types::Ty resolve_ty_f_6359) { return prism_rtl::finished(crate::check::typed::BinderNote{.at_p = prism_rtl::deref(n_p3).at_p, .name_p = prism_rtl::deref(n_p3).name_p, .ty_p = resolve_ty_f_6359}); }));
            });
        })));
        });
    })));
    })));
    this_.insts_p = crate::prelude::run_to_end(crate::prelude::each_job(this_.insts_p, ({
        auto st_p0x = st_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::typed::InstNote>(crate::check::typed::InstNote)>>(prism_rtl::rc([=, st_p0x = std::move(st_p0x)](crate::check::typed::InstNote p0) {
        return ({
            auto st_p0xy = st_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, st_p0xy = std::move(st_p0xy)]() {
            return ({
                auto n_p4 = p0;
                (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(n_p4).tys_p, ({
                auto st_p0xyx = st_p0xy;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::check::types::Ty>>(std::tuple<Text, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_p0xyx = std::move(st_p0xyx)](std::tuple<Text, crate::check::types::Ty> p0) {
                return ({
                    auto st_p0xyxy = st_p0xyx;
                    (crate::prelude::entered(crate::prelude::once_job([=, st_p0xyxy = std::move(st_p0xyxy)]() {
                    return ({
                        auto [q_p5, x_p6] = p0;
                        (crate::prelude::call_then(start_resolve_ty_f(st_p0xyxy, x_p6), [=](crate::check::types::Ty resolve_ty_f_6486) { return prism_rtl::finished(std::tuple{q_p5, resolve_ty_f_6486}); }));
                    });
                })));
                });
            }));
            })), [=](Array<std::tuple<Text, crate::check::types::Ty>> each_6456) {
                return crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(n_p4).cols_p, ({
                    auto st_p0xyx = st_p0xy;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::check::types::Col>>(std::tuple<Text, crate::check::types::Col>)>>(prism_rtl::rc([=, st_p0xyx = std::move(st_p0xyx)](std::tuple<Text, crate::check::types::Col> p0) {
                    return ({
                        auto st_p0xyxy = st_p0xyx;
                        (crate::prelude::entered(crate::prelude::once_job([=, st_p0xyxy = std::move(st_p0xyxy)]() {
                        return ({
                            auto [q_p7, c_p8] = p0;
                            (crate::prelude::call_then(start_resolve_col_f(st_p0xyxy, c_p8), [=](crate::check::types::Col resolve_col_f_6544) { return prism_rtl::finished(std::tuple{q_p7, resolve_col_f_6544}); }));
                        });
                    })));
                    });
                }));
                })), [=](Array<std::tuple<Text, crate::check::types::Col>> each_6513) { return prism_rtl::finished(crate::check::typed::InstNote{.at_p = prism_rtl::deref(n_p4).at_p, .name_p = prism_rtl::deref(n_p4).name_p, .tys_p = each_6456, .cols_p = each_6513}); });
            }));
            });
        })));
        });
    })));
    })));
    this_.impls_p = crate::prelude::run_to_end(crate::prelude::each_job(this_.impls_p, ({
        auto st_p0x = st_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::typed::ImplNote>(crate::check::typed::ImplNote)>>(prism_rtl::rc([=, st_p0x = std::move(st_p0x)](crate::check::typed::ImplNote p0) {
        return ({
            auto st_p0xy = st_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, st_p0xy = std::move(st_p0xy)]() {
            return ({
                auto n_p9 = p0;
                (crate::prelude::call_then(start_resolve_ty_f(st_p0xy, prism_rtl::deref(n_p9).ty_p), [=](crate::check::types::Ty resolve_ty_f_6639) { return prism_rtl::finished(crate::check::typed::ImplNote{.at_p = prism_rtl::deref(n_p9).at_p, .cls_p = prism_rtl::deref(n_p9).cls_p, .ty_p = resolve_ty_f_6639, .how_p = prism_rtl::deref(n_p9).how_p}); }));
            });
        })));
        });
    })));
    })));
    this_.apps_p = crate::prelude::run_to_end(crate::prelude::each_job(this_.apps_p, ({
        auto st_p0x = st_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::typed::AppNote>(crate::check::typed::AppNote)>>(prism_rtl::rc([=, st_p0x = std::move(st_p0x)](crate::check::typed::AppNote p0) {
        return ({
            auto st_p0xy = st_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, st_p0xy = std::move(st_p0xy)]() {
            return ({
                auto n_pa = p0;
                (crate::prelude::call_then(start_resolve_col_f(st_p0xy, prism_rtl::deref(n_pa).color_p), [=](crate::check::types::Col resolve_col_f_6810) { return prism_rtl::finished(crate::check::typed::AppNote{.at_p = prism_rtl::deref(n_pa).at_p, .callee_p = prism_rtl::deref(n_pa).callee_p, .kind_p = prism_rtl::deref(n_pa).kind_p, .layer_p = prism_rtl::deref(n_pa).layer_p, .lifted_p = prism_rtl::deref(n_pa).lifted_p, .inner_p = prism_rtl::deref(n_pa).inner_p, .color_p = resolve_col_f_6810}); }));
            });
        })));
        });
    })));
    })));
    this_.fns_p = crate::prelude::run_to_end(crate::prelude::each_job(this_.fns_p, ({
        auto st_p0x = st_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::typed::FnNote>(crate::check::typed::FnNote)>>(prism_rtl::rc([=, st_p0x = std::move(st_p0x)](crate::check::typed::FnNote p0) {
        return ({
            auto st_p0xy = st_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, st_p0xy = std::move(st_p0xy)]() {
            return ({
                auto n_pb = p0;
                (crate::prelude::call_then(start_resolve_col_f(st_p0xy, prism_rtl::deref(n_pb).declared_p), [=](crate::check::types::Col resolve_col_f_6910) { return crate::prelude::call_then(start_resolve_col_f(st_p0xy, prism_rtl::deref(n_pb).body_p), [=](crate::check::types::Col resolve_col_f_6944) { return prism_rtl::finished(crate::check::typed::FnNote{.at_p = prism_rtl::deref(n_pb).at_p, .name_p = prism_rtl::deref(n_pb).name_p, .declared_p = resolve_col_f_6910, .body_p = resolve_col_f_6944}); }); }));
            });
        })));
        });
    })));
    })));
    return this_;
}


prism_rtl::Turn<crate::check::typed::TProgram> ZonkTyped::cycle() const {
    const auto& st_p0 = this->st_p0;
    auto t_p1 = prism_rtl::deref(st_p0).typed_p;
    return prism_rtl::finished(({
        crate::check::typed::TProgram this_ = t_p1;
        this_.exprs_p = crate::prelude::run_to_end(crate::prelude::each_job(this_.exprs_p, ({
            auto st_p0x = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::typed::TyNote>(crate::check::typed::TyNote)>>(prism_rtl::rc([=, st_p0x = std::move(st_p0x)](crate::check::typed::TyNote p0) {
            return ({
                auto st_p0xy = st_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, st_p0xy = std::move(st_p0xy)]() {
                return ({
                    auto n_p2 = p0;
                    (crate::prelude::call_then(start_resolve_ty_f(st_p0xy, prism_rtl::deref(n_p2).ty_p), [=](crate::check::types::Ty resolve_ty_f_6257) { return prism_rtl::finished(crate::check::typed::TyNote{.at_p = prism_rtl::deref(n_p2).at_p, .ty_p = resolve_ty_f_6257}); }));
                });
            })));
            });
        })));
        })));
        this_.binders_p = crate::prelude::run_to_end(crate::prelude::each_job(this_.binders_p, ({
            auto st_p0x = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::typed::BinderNote>(crate::check::typed::BinderNote)>>(prism_rtl::rc([=, st_p0x = std::move(st_p0x)](crate::check::typed::BinderNote p0) {
            return ({
                auto st_p0xy = st_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, st_p0xy = std::move(st_p0xy)]() {
                return ({
                    auto n_p3 = p0;
                    (crate::prelude::call_then(start_resolve_ty_f(st_p0xy, prism_rtl::deref(n_p3).ty_p), [=](crate::check::types::Ty resolve_ty_f_6359) { return prism_rtl::finished(crate::check::typed::BinderNote{.at_p = prism_rtl::deref(n_p3).at_p, .name_p = prism_rtl::deref(n_p3).name_p, .ty_p = resolve_ty_f_6359}); }));
                });
            })));
            });
        })));
        })));
        this_.insts_p = crate::prelude::run_to_end(crate::prelude::each_job(this_.insts_p, ({
            auto st_p0x = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::typed::InstNote>(crate::check::typed::InstNote)>>(prism_rtl::rc([=, st_p0x = std::move(st_p0x)](crate::check::typed::InstNote p0) {
            return ({
                auto st_p0xy = st_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, st_p0xy = std::move(st_p0xy)]() {
                return ({
                    auto n_p4 = p0;
                    (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(n_p4).tys_p, ({
                    auto st_p0xyx = st_p0xy;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::check::types::Ty>>(std::tuple<Text, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_p0xyx = std::move(st_p0xyx)](std::tuple<Text, crate::check::types::Ty> p0) {
                    return ({
                        auto st_p0xyxy = st_p0xyx;
                        (crate::prelude::entered(crate::prelude::once_job([=, st_p0xyxy = std::move(st_p0xyxy)]() {
                        return ({
                            auto [q_p5, x_p6] = p0;
                            (crate::prelude::call_then(start_resolve_ty_f(st_p0xyxy, x_p6), [=](crate::check::types::Ty resolve_ty_f_6486) { return prism_rtl::finished(std::tuple{q_p5, resolve_ty_f_6486}); }));
                        });
                    })));
                    });
                }));
                })), [=](Array<std::tuple<Text, crate::check::types::Ty>> each_6456) {
                    return crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(n_p4).cols_p, ({
                        auto st_p0xyx = st_p0xy;
                        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::check::types::Col>>(std::tuple<Text, crate::check::types::Col>)>>(prism_rtl::rc([=, st_p0xyx = std::move(st_p0xyx)](std::tuple<Text, crate::check::types::Col> p0) {
                        return ({
                            auto st_p0xyxy = st_p0xyx;
                            (crate::prelude::entered(crate::prelude::once_job([=, st_p0xyxy = std::move(st_p0xyxy)]() {
                            return ({
                                auto [q_p7, c_p8] = p0;
                                (crate::prelude::call_then(start_resolve_col_f(st_p0xyxy, c_p8), [=](crate::check::types::Col resolve_col_f_6544) { return prism_rtl::finished(std::tuple{q_p7, resolve_col_f_6544}); }));
                            });
                        })));
                        });
                    }));
                    })), [=](Array<std::tuple<Text, crate::check::types::Col>> each_6513) { return prism_rtl::finished(crate::check::typed::InstNote{.at_p = prism_rtl::deref(n_p4).at_p, .name_p = prism_rtl::deref(n_p4).name_p, .tys_p = each_6456, .cols_p = each_6513}); });
                }));
                });
            })));
            });
        })));
        })));
        this_.impls_p = crate::prelude::run_to_end(crate::prelude::each_job(this_.impls_p, ({
            auto st_p0x = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::typed::ImplNote>(crate::check::typed::ImplNote)>>(prism_rtl::rc([=, st_p0x = std::move(st_p0x)](crate::check::typed::ImplNote p0) {
            return ({
                auto st_p0xy = st_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, st_p0xy = std::move(st_p0xy)]() {
                return ({
                    auto n_p9 = p0;
                    (crate::prelude::call_then(start_resolve_ty_f(st_p0xy, prism_rtl::deref(n_p9).ty_p), [=](crate::check::types::Ty resolve_ty_f_6639) { return prism_rtl::finished(crate::check::typed::ImplNote{.at_p = prism_rtl::deref(n_p9).at_p, .cls_p = prism_rtl::deref(n_p9).cls_p, .ty_p = resolve_ty_f_6639, .how_p = prism_rtl::deref(n_p9).how_p}); }));
                });
            })));
            });
        })));
        })));
        this_.apps_p = crate::prelude::run_to_end(crate::prelude::each_job(this_.apps_p, ({
            auto st_p0x = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::typed::AppNote>(crate::check::typed::AppNote)>>(prism_rtl::rc([=, st_p0x = std::move(st_p0x)](crate::check::typed::AppNote p0) {
            return ({
                auto st_p0xy = st_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, st_p0xy = std::move(st_p0xy)]() {
                return ({
                    auto n_pa = p0;
                    (crate::prelude::call_then(start_resolve_col_f(st_p0xy, prism_rtl::deref(n_pa).color_p), [=](crate::check::types::Col resolve_col_f_6810) { return prism_rtl::finished(crate::check::typed::AppNote{.at_p = prism_rtl::deref(n_pa).at_p, .callee_p = prism_rtl::deref(n_pa).callee_p, .kind_p = prism_rtl::deref(n_pa).kind_p, .layer_p = prism_rtl::deref(n_pa).layer_p, .lifted_p = prism_rtl::deref(n_pa).lifted_p, .inner_p = prism_rtl::deref(n_pa).inner_p, .color_p = resolve_col_f_6810}); }));
                });
            })));
            });
        })));
        })));
        this_.fns_p = crate::prelude::run_to_end(crate::prelude::each_job(this_.fns_p, ({
            auto st_p0x = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::typed::FnNote>(crate::check::typed::FnNote)>>(prism_rtl::rc([=, st_p0x = std::move(st_p0x)](crate::check::typed::FnNote p0) {
            return ({
                auto st_p0xy = st_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, st_p0xy = std::move(st_p0xy)]() {
                return ({
                    auto n_pb = p0;
                    (crate::prelude::call_then(start_resolve_col_f(st_p0xy, prism_rtl::deref(n_pb).declared_p), [=](crate::check::types::Col resolve_col_f_6910) { return crate::prelude::call_then(start_resolve_col_f(st_p0xy, prism_rtl::deref(n_pb).body_p), [=](crate::check::types::Col resolve_col_f_6944) { return prism_rtl::finished(crate::check::typed::FnNote{.at_p = prism_rtl::deref(n_pb).at_p, .name_p = prism_rtl::deref(n_pb).name_p, .declared_p = resolve_col_f_6910, .body_p = resolve_col_f_6944}); }); }));
                });
            })));
            });
        })));
        })));
        (std::move(this_));
    }));
}


/// `Start ZonkTyped, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::typed::TProgram> start_zonk_typed_f(crate::check::types::St st_p0) {
    return prism_rtl::make_rc<ZonkTyped>(st_p0);
}


/// ResolveCol: unbounded fn St, Col -> Col
crate::check::types::Col resolve_col_f(const crate::check::types::St& st_p0, const crate::check::types::Col& c_p1) {
    auto&& _m = crate::check::types::colors::walk_col_f(st_p0, c_p1);
    if (prism_rtl::is<crate::check::types::Col::CFlex>(_m)) {
        auto&& n_p2 = prism_rtl::as<crate::check::types::Col::CFlex>(_m).a0;
        auto&& _m = crate::prelude::get(st_p0.col_q_p, n_p2);
        if (prism_rtl::is_some(_m)) {
            auto&& q_p3 = prism_rtl::some_of(_m);
            return crate::check::types::Col(crate::check::types::Col::CQ{q_p3});
        }
        if (prism_rtl::is_none(_m)) {
            return crate::check::types::Col(crate::check::types::Col::CBound{});
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        auto&& other_p4 = _m;
        return other_p4;
    }
}


prism_rtl::Turn<crate::check::types::Col> ResolveCol::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& c_p1 = this->c_p1;
    auto c_p1x = c_p1;
    auto st_p0x = st_p0;
    return crate::prelude::call_then(crate::check::types::colors::start_walk_col_f(st_p0x, c_p1x), [=](crate::check::types::Col walk_col_f_7179) {
        return ({
            prism_rtl::is<crate::check::types::Col::CFlex>(walk_col_f_7179) ? ({
            auto&& n_p2 = prism_rtl::as<crate::check::types::Col::CFlex>(walk_col_f_7179).a0;
            ({
            auto&& _m = crate::prelude::get(prism_rtl::deref(st_p0x).col_q_p, n_p2);
            prism_rtl::is_some(_m) ? ({
            auto&& q_p3 = prism_rtl::some_of(_m);
            prism_rtl::finished(crate::check::types::Col(crate::check::types::Col::CQ{q_p3}));
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::check::types::Col(crate::check::types::Col::CBound{}))
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : ({
            auto&& other_p4 = walk_col_f_7179;
            prism_rtl::finished(other_p4);
        });
        });
    });
}


/// `Start ResolveCol, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Col> start_resolve_col_f(crate::check::types::St st_p0, crate::check::types::Col c_p1) {
    return prism_rtl::make_rc<ResolveCol>(st_p0, c_p1);
}


/// ResolveTy: unbounded fn St, Ty -> Ty
crate::check::types::Ty resolve_ty_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1) {
    return resolve_in_f(st_p0, zonk_f(st_p0, t_p1));
}


prism_rtl::Turn<crate::check::types::Ty> ResolveTy::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    auto st_p0x = st_p0;
    auto t_p1x = t_p1;
    return crate::prelude::call_then(start_zonk_f(st_p0x, t_p1x), [=](crate::check::types::Ty zonk_f_7392) { return prism_rtl::more(prism_rtl::rc(ResolveIn(st_p0x, zonk_f_7392))); });
}


/// `Start ResolveTy, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_resolve_ty_f(crate::check::types::St st_p0, crate::check::types::Ty t_p1) {
    return prism_rtl::make_rc<ResolveTy>(st_p0, t_p1);
}


/// ResolveIn: unbounded fn St, Ty -> Ty
crate::check::types::Ty resolve_in_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1)) {
        auto&& n_p2 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& args_p3 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyCon{n_p2, crate::prelude::run_to_end(crate::prelude::each_job(args_p3, ({
            auto st_p0x = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, st_p0x = std::move(st_p0x)](crate::check::types::Ty p0) {
            return ({
                auto st_p0xy = st_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, st_p0xy = std::move(st_p0xy)]() {
                return ({
                    auto a_p4 = p0;
                    (prism_rtl::more(prism_rtl::rc(ResolveIn(st_p0xy, a_p4))));
                });
            })));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p1)) {
        auto&& c_p5 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a0;
        auto&& ps_p6 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a1;
        auto&& res_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a2;
        return crate::check::types::Ty(crate::check::types::Ty::TyFn{resolve_col_f(st_p0, c_p5), crate::prelude::run_to_end(crate::prelude::each_job(ps_p6, ({
            auto st_p0x = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, st_p0x = std::move(st_p0x)](crate::check::types::Ty p0) {
            return ({
                auto st_p0xy = st_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, st_p0xy = std::move(st_p0xy)]() {
                return ({
                    auto p_p8 = p0;
                    (prism_rtl::more(prism_rtl::rc(ResolveIn(st_p0xy, p_p8))));
                });
            })));
            });
        })));
        }))), prism_rtl::rc(resolve_in_f(st_p0, prism_rtl::deref(prism_rtl::deref(res_p7))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p1)) {
        auto&& ts_p9 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p1).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyTuple{crate::prelude::run_to_end(crate::prelude::each_job(ts_p9, ({
            auto st_p0x = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, st_p0x = std::move(st_p0x)](crate::check::types::Ty p0) {
            return ({
                auto st_p0xy = st_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, st_p0xy = std::move(st_p0xy)]() {
                return ({
                    auto a_pa = p0;
                    (prism_rtl::more(prism_rtl::rc(ResolveIn(st_p0xy, a_pa))));
                });
            })));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p1)) {
        auto&& e_pb = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p1).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(resolve_in_f(st_p0, prism_rtl::deref(prism_rtl::deref(e_pb))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p1)) {
        auto&& k_pc = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a0;
        auto&& v_pd = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(resolve_in_f(st_p0, prism_rtl::deref(prism_rtl::deref(k_pc)))), prism_rtl::rc(resolve_in_f(st_p0, prism_rtl::deref(prism_rtl::deref(v_pd))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p1)) {
        auto&& s_pe = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        auto&& i_pf = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TySig{s_pe, prism_rtl::rc(resolve_in_f(st_p0, prism_rtl::deref(prism_rtl::deref(i_pf))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p1)) {
        auto&& i_pg = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p1).a0;
        auto&& rw_ph = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p1).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(resolve_in_f(st_p0, prism_rtl::deref(prism_rtl::deref(i_pg)))), rw_ph});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t_p1)) {
        auto&& rw_pi = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p1).a0;
        auto&& o_pj = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p1).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyElem{rw_pi, prism_rtl::rc(resolve_in_f(st_p0, prism_rtl::deref(prism_rtl::deref(o_pj))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p1)) {
        auto&& n_pk = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p1).a0;
        auto&& a_pl = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p1).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyAssoc{n_pk, prism_rtl::rc(resolve_in_f(st_p0, prism_rtl::deref(prism_rtl::deref(a_pl))))});
    }
    {
        auto&& other_pm = t_p1;
        return other_pm;
    }
}


prism_rtl::Turn<crate::check::types::Ty> ResolveIn::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1) ? ({
        auto&& n_p2 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& args_p3 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        ({
        auto args_p3x = args_p3;
        auto n_p2x = n_p2;
        auto st_p0x = st_p0;
        (crate::prelude::call_value(crate::prelude::each_job(args_p3x, ({
        auto st_p0xx = st_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, st_p0xx = std::move(st_p0xx)](crate::check::types::Ty p0) {
        return ({
            auto st_p0xxy = st_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, st_p0xxy = std::move(st_p0xxy)]() {
            return ({
                auto a_p4 = p0;
                (prism_rtl::more(prism_rtl::rc(ResolveIn(st_p0xxy, a_p4))));
            });
        })));
        });
    })));
    })), [=, n_p2x = std::move(n_p2x)](Array<crate::check::types::Ty> each_7501) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyCon{n_p2x, each_7501})); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(t_p1) ? ({
        auto&& c_p5 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a0;
        auto&& ps_p6 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a1;
        auto&& res_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a2;
        ({
        auto c_p5x = c_p5;
        auto ps_p6x = ps_p6;
        auto res_p7x = prism_rtl::deref(prism_rtl::deref(res_p7));
        auto st_p0x = st_p0;
        (crate::prelude::call_then(start_resolve_col_f(st_p0x, c_p5x), [=, ps_p6x = std::move(ps_p6x), res_p7x = std::move(res_p7x)](crate::check::types::Col resolve_col_f_7561) {
        return crate::prelude::call_value(crate::prelude::each_job(ps_p6x, ({
            auto st_p0xx = st_p0x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, st_p0xx = std::move(st_p0xx)](crate::check::types::Ty p0) {
            return ({
                auto st_p0xxy = st_p0xx;
                (crate::prelude::entered(crate::prelude::once_job([=, st_p0xxy = std::move(st_p0xxy)]() {
                return ({
                    auto p_p8 = p0;
                    (prism_rtl::more(prism_rtl::rc(ResolveIn(st_p0xxy, p_p8))));
                });
            })));
            });
        })));
        })), [=](Array<crate::check::types::Ty> each_7581) { return crate::prelude::call_then(start_resolve_in_f(st_p0x, res_p7x), [=](crate::check::types::Ty resolve_in_f_7614) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyFn{resolve_col_f_7561, each_7581, prism_rtl::rc(resolve_in_f_7614)})); }); });
    }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p1) ? ({
        auto&& ts_p9 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p1).a0;
        ({
        auto st_p0x = st_p0;
        auto ts_p9x = ts_p9;
        (crate::prelude::call_value(crate::prelude::each_job(ts_p9x, ({
        auto st_p0xx = st_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, st_p0xx = std::move(st_p0xx)](crate::check::types::Ty p0) {
        return ({
            auto st_p0xxy = st_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, st_p0xxy = std::move(st_p0xxy)]() {
            return ({
                auto a_pa = p0;
                (prism_rtl::more(prism_rtl::rc(ResolveIn(st_p0xxy, a_pa))));
            });
        })));
        });
    })));
    })), [=](Array<crate::check::types::Ty> each_7658) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyTuple{each_7658})); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t_p1) ? ({
        auto&& e_pb = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p1).a0;
        ({
        auto e_pbx = prism_rtl::deref(prism_rtl::deref(e_pb));
        auto st_p0x = st_p0;
        (crate::prelude::call_then(start_resolve_in_f(st_p0x, e_pbx), [=](crate::check::types::Ty resolve_in_f_7713) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(resolve_in_f_7713)})); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t_p1) ? ({
        auto&& k_pc = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a0;
        auto&& v_pd = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a1;
        ({
        auto k_pcx = prism_rtl::deref(prism_rtl::deref(k_pc));
        auto st_p0x = st_p0;
        auto v_pdx = prism_rtl::deref(prism_rtl::deref(v_pd));
        (crate::prelude::call_then(start_resolve_in_f(st_p0x, k_pcx), [=, v_pdx = std::move(v_pdx)](crate::check::types::Ty resolve_in_f_7753) { return crate::prelude::call_then(start_resolve_in_f(st_p0x, v_pdx), [=](crate::check::types::Ty resolve_in_f_7772) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(resolve_in_f_7753), prism_rtl::rc(resolve_in_f_7772)})); }); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t_p1) ? ({
        auto&& s_pe = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        auto&& i_pf = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        ({
        auto i_pfx = prism_rtl::deref(prism_rtl::deref(i_pf));
        auto s_pex = s_pe;
        auto st_p0x = st_p0;
        (crate::prelude::call_then(start_resolve_in_f(st_p0x, i_pfx), [=, s_pex = std::move(s_pex)](crate::check::types::Ty resolve_in_f_7815) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TySig{s_pex, prism_rtl::rc(resolve_in_f_7815)})); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyAt>(t_p1) ? ({
        auto&& i_pg = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p1).a0;
        auto&& rw_ph = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p1).a1;
        ({
        auto i_pgx = prism_rtl::deref(prism_rtl::deref(i_pg));
        auto rw_phx = rw_ph;
        auto st_p0x = st_p0;
        (crate::prelude::call_then(start_resolve_in_f(st_p0x, i_pgx), [=, rw_phx = std::move(rw_phx)](crate::check::types::Ty resolve_in_f_7854) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(resolve_in_f_7854), rw_phx})); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyElem>(t_p1) ? ({
        auto&& rw_pi = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p1).a0;
        auto&& o_pj = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p1).a1;
        ({
        auto o_pjx = prism_rtl::deref(prism_rtl::deref(o_pj));
        auto rw_pix = rw_pi;
        auto st_p0x = st_p0;
        (crate::prelude::call_then(start_resolve_in_f(st_p0x, o_pjx), [=, rw_pix = std::move(rw_pix)](crate::check::types::Ty resolve_in_f_7905) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyElem{rw_pix, prism_rtl::rc(resolve_in_f_7905)})); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p1) ? ({
        auto&& n_pk = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p1).a0;
        auto&& a_pl = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p1).a1;
        ({
        auto a_plx = prism_rtl::deref(prism_rtl::deref(a_pl));
        auto n_pkx = n_pk;
        auto st_p0x = st_p0;
        (crate::prelude::call_then(start_resolve_in_f(st_p0x, a_plx), [=, n_pkx = std::move(n_pkx)](crate::check::types::Ty resolve_in_f_7952) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyAssoc{n_pkx, prism_rtl::rc(resolve_in_f_7952)})); }));
    });
    })
        : ({
        auto&& other_pm = t_p1;
        prism_rtl::finished(other_pm);
    });
    });
}


/// `Start ResolveIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_resolve_in_f(crate::check::types::St st_p0, crate::check::types::Ty t_p1) {
    return prism_rtl::make_rc<ResolveIn>(st_p0, t_p1);
}


/// AtBinder: fn St, Ty, Range -> St
crate::check::types::St at_binder_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& ty1, const crate::syntax::Range& range2) {
    auto&& _m = std::tuple{ty1, range2};
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(std::get<0>(_m))) {
        auto&& n_p1 = prism_rtl::as<crate::check::types::Ty::TyFlex>(std::get<0>(_m)).a0;
        auto&& span_p2 = std::get<1>(_m);
        crate::check::types::St this_ = st_p0;
        this_.binder_at_p = crate::prelude::insert(this_.binder_at_p, n_p1, span_p2);
        return this_;
    }
    {
        return st_p0;
    }
    prism_rtl::unreachable("no arm matched");
}


/// FreshRow: fn St, [Text] -> ((Rw, St))
std::tuple<crate::check::types::Rw, crate::check::types::St> fresh_row_f(const crate::check::types::St& st_p0, const Array<Text>& lacking_p1) {
    auto n_p2 = st_p0.next_p;
    auto st2_p3 = ({
        crate::check::types::St this_ = st_p0;
        this_.next_p = this_.next_p + Nat(1u);
        this_.lacks_p = crate::prelude::insert(this_.lacks_p, n_p2, lacking_p1);
        (std::move(this_));
    });
    return std::tuple{crate::check::types::Rw{.fams_p = Array<Text>{}, .minus_p = Array<Text>{}, .tail_p = crate::check::types::Tail(crate::check::types::Tail::TlFlex{n_p2})}, st2_p3};
}


/// AddDiag: fn St, CDiag -> St
crate::check::types::St add_diag_f(const crate::check::types::St& st_p0, const crate::check::errors::CDiag& d_p1) {
    crate::check::types::St this_ = st_p0;
    this_.diags_p = crate::prelude::push(this_.diags_p, d_p1);
    return this_;
}


/// Err: fn St, Text, Range, Text -> St
crate::check::types::St err_f(const crate::check::types::St& st_p0, const Text& code_p1, const crate::syntax::Range& span_p2, const Text& message_p3) {
    return add_diag_f(st_p0, crate::check::errors::diag0_f(code_p1, st_p0.file_p, span_p2, message_p3));
}


/// ErrFix: fn St, Text, Range, Text, Text -> St
crate::check::types::St err_fix_f(const crate::check::types::St& st_p0, const Text& code_p1, const crate::syntax::Range& span_p2, const Text& message_p3, const Text& fix_p4) {
    return add_diag_f(st_p0, crate::check::errors::diag_fix_f(code_p1, st_p0.file_p, span_p2, message_p3, fix_p4));
}


/// InfoOf: fn St, Nat -> VInfo
crate::check::types::VInfo info_of_f(const crate::check::types::St& st_p0, const Nat& n_p1) {
    return crate::prelude::or_(crate::prelude::get(st_p0.infos_p, n_p1), crate::check::types::VInfo{.plain_p = false, .level_p = Nat(0u), .name_p = Text::lit("")});
}


/// Walk: unbounded fn St, Ty -> Ty
crate::check::types::Ty walk_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& ty1) {
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(ty1)) {
        auto&& n_p1 = prism_rtl::as<crate::check::types::Ty::TyFlex>(ty1).a0;
        auto&& _m = crate::prelude::get(st_p0.tys_p, n_p1);
        if (prism_rtl::is_some(_m)) {
            auto&& t_p2 = prism_rtl::some_of(_m);
            return walk_f(st_p0, t_p2);
        }
        if (prism_rtl::is_none(_m)) {
            return crate::check::types::Ty(crate::check::types::Ty::TyFlex{n_p1});
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        auto&& t_p4 = ty1;
        return t_p4;
    }
}


prism_rtl::Turn<crate::check::types::Ty> Walk::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& ty1 = this->ty1;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyFlex>(ty1) ? ({
        auto&& n_p1 = prism_rtl::as<crate::check::types::Ty::TyFlex>(ty1).a0;
        ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(st_p0).tys_p, n_p1);
        prism_rtl::is_some(_m) ? ({
        auto&& t_p2 = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(Walk(st_p0, t_p2)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyFlex{n_p1}))
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : ({
        auto&& t_p4 = ty1;
        prism_rtl::finished(t_p4);
    });
    });
}


/// `Start Walk, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_walk_f(crate::check::types::St st_p0, crate::check::types::Ty ty1) {
    return prism_rtl::make_rc<Walk>(st_p0, ty1);
}


/// WalkRow: unbounded fn St, Rw -> Rw
crate::check::types::Rw walk_row_f(const crate::check::types::St& st_p0, const crate::check::types::Rw& r_p1) {
    auto&& _m = r_p1.tail_p;
    if (prism_rtl::is<crate::check::types::Tail::TlFlex>(_m)) {
        auto&& n_p2 = prism_rtl::as<crate::check::types::Tail::TlFlex>(_m).a0;
        auto&& _m = crate::prelude::get(st_p0.rows_p, n_p2);
        if (prism_rtl::is_some(_m)) {
            auto&& r2_p3 = prism_rtl::some_of(_m);
            auto w_p4 = walk_row_f(st_p0, r2_p3);
            return crate::check::types::Rw{.fams_p = crate::check::types::sort_texts_f(crate::check::types::union_texts_f(r_p1.fams_p, prism_rtl::deref(w_p4).fams_p)), .minus_p = crate::check::types::union_texts_f(r_p1.minus_p, prism_rtl::deref(w_p4).minus_p), .tail_p = prism_rtl::deref(w_p4).tail_p};
        }
        if (prism_rtl::is_none(_m)) {
            return r_p1;
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        return r_p1;
    }
}


prism_rtl::Turn<crate::check::types::Rw> WalkRow::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& r_p1 = this->r_p1;
    return ({
        auto&& _m = prism_rtl::deref(r_p1).tail_p;
        prism_rtl::is<crate::check::types::Tail::TlFlex>(_m) ? ({
        auto&& n_p2 = prism_rtl::as<crate::check::types::Tail::TlFlex>(_m).a0;
        ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(st_p0).rows_p, n_p2);
        prism_rtl::is_some(_m) ? ({
        auto&& r2_p3 = prism_rtl::some_of(_m);
        ({
        auto r_p1x = r_p1;
        auto st_p0x = st_p0;
        (crate::prelude::call_then(start_walk_row_f(st_p0x, r2_p3), [=, r_p1x = std::move(r_p1x)](crate::check::types::Rw walk_row_f_9319) {
        return ({
            auto w_p4 = walk_row_f_9319;
            (prism_rtl::finished(crate::check::types::Rw{.fams_p = crate::check::types::sort_texts_f(crate::check::types::union_texts_f(prism_rtl::deref(r_p1x).fams_p, prism_rtl::deref(w_p4).fams_p)), .minus_p = crate::check::types::union_texts_f(prism_rtl::deref(r_p1x).minus_p, prism_rtl::deref(w_p4).minus_p), .tail_p = prism_rtl::deref(w_p4).tail_p}));
        });
    }));
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(r_p1)
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::finished(r_p1);
    });
}


/// `Start WalkRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Rw> start_walk_row_f(crate::check::types::St st_p0, crate::check::types::Rw r_p1) {
    return prism_rtl::make_rc<WalkRow>(st_p0, r_p1);
}


/// Zonk: unbounded fn St, Ty -> Ty
crate::check::types::Ty zonk_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1) {
    auto&& _m = crate::check::types::unify::norm_assoc_f(st_p0, walk_f(st_p0, t_p1));
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& n_p2 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& args_p3 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyCon{n_p2, crate::prelude::run_to_end(crate::prelude::each_job(args_p3, ({
            auto st_p0x = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, st_p0x = std::move(st_p0x)](crate::check::types::Ty p0) {
            return ({
                auto st_p0xy = st_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, st_p0xy = std::move(st_p0xy)]() {
                return ({
                    auto a_p4 = p0;
                    (prism_rtl::more(prism_rtl::rc(Zonk(st_p0xy, a_p4))));
                });
            })));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
        auto&& c_p5 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0;
        auto&& ps_p6 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
        auto&& res_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
        return crate::check::types::Ty(crate::check::types::Ty::TyFn{crate::check::types::colors::walk_col_f(st_p0, c_p5), crate::prelude::run_to_end(crate::prelude::each_job(ps_p6, ({
            auto st_p0x = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, st_p0x = std::move(st_p0x)](crate::check::types::Ty p0) {
            return ({
                auto st_p0xy = st_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, st_p0xy = std::move(st_p0xy)]() {
                return ({
                    auto p_p8 = p0;
                    (prism_rtl::more(prism_rtl::rc(Zonk(st_p0xy, p_p8))));
                });
            })));
            });
        })));
        }))), prism_rtl::rc(zonk_f(st_p0, prism_rtl::deref(res_p7)))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(_m)) {
        auto&& ts_p9 = prism_rtl::as<crate::check::types::Ty::TyTuple>(_m).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyTuple{crate::prelude::run_to_end(crate::prelude::each_job(ts_p9, ({
            auto st_p0x = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, st_p0x = std::move(st_p0x)](crate::check::types::Ty p0) {
            return ({
                auto st_p0xy = st_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, st_p0xy = std::move(st_p0xy)]() {
                return ({
                    auto a_pa = p0;
                    (prism_rtl::more(prism_rtl::rc(Zonk(st_p0xy, a_pa))));
                });
            })));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(_m)) {
        auto&& e_pb = prism_rtl::as<crate::check::types::Ty::TyArray>(_m).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(zonk_f(st_p0, prism_rtl::deref(e_pb)))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(_m)) {
        auto&& k_pc = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a0;
        auto&& v_pd = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(zonk_f(st_p0, prism_rtl::deref(k_pc))), prism_rtl::rc(zonk_f(st_p0, prism_rtl::deref(v_pd)))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& s_pe = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
        auto&& i_pf = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TySig{s_pe, prism_rtl::rc(zonk_f(st_p0, prism_rtl::deref(i_pf)))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
        auto&& i_pg = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a0;
        auto&& rw_ph = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(zonk_f(st_p0, prism_rtl::deref(i_pg))), walk_row_f(st_p0, rw_ph)});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
        auto&& rw_pi = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a0;
        auto&& o_pj = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyElem{walk_row_f(st_p0, rw_pi), prism_rtl::rc(zonk_f(st_p0, prism_rtl::deref(o_pj)))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(_m)) {
        auto&& rw_pk = prism_rtl::as<crate::check::types::Ty::TyElemAny>(_m).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyElemAny{walk_row_f(st_p0, rw_pk)});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(_m)) {
        auto&& n_pl = prism_rtl::as<crate::check::types::Ty::TyAssoc>(_m).a0;
        auto&& a_pm = prism_rtl::as<crate::check::types::Ty::TyAssoc>(_m).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyAssoc{n_pl, prism_rtl::rc(zonk_f(st_p0, prism_rtl::deref(a_pm)))});
    }
    {
        auto&& w_pn = _m;
        return w_pn;
    }
}


prism_rtl::Turn<crate::check::types::Ty> Zonk::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    auto st_p0x = st_p0;
    auto t_p1x = t_p1;
    return crate::prelude::call_then(start_walk_f(st_p0x, t_p1x), [=](crate::check::types::Ty walk_f_9610) {
        return crate::prelude::call_then(crate::check::types::unify::start_norm_assoc_f(st_p0x, walk_f_9610), [=](crate::check::types::Ty norm_assoc_f_9595) {
            return ({
                prism_rtl::is<crate::check::types::Ty::TyCon>(norm_assoc_f_9595) ? ({
                auto&& n_p2 = prism_rtl::as<crate::check::types::Ty::TyCon>(norm_assoc_f_9595).a0;
                auto&& args_p3 = prism_rtl::as<crate::check::types::Ty::TyCon>(norm_assoc_f_9595).a1;
                crate::prelude::call_value(crate::prelude::each_job(args_p3, ({
                auto st_p0xx = st_p0x;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, st_p0xx = std::move(st_p0xx)](crate::check::types::Ty p0) {
                return ({
                    auto st_p0xxy = st_p0xx;
                    (crate::prelude::entered(crate::prelude::once_job([=, st_p0xxy = std::move(st_p0xxy)]() {
                    return ({
                        auto a_p4 = p0;
                        (prism_rtl::more(prism_rtl::rc(Zonk(st_p0xxy, a_p4))));
                    });
                })));
                });
            })));
            })), [=](Array<crate::check::types::Ty> each_9652) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyCon{n_p2, each_9652})); });
            })
                : prism_rtl::is<crate::check::types::Ty::TyFn>(norm_assoc_f_9595) ? ({
                auto&& c_p5 = prism_rtl::as<crate::check::types::Ty::TyFn>(norm_assoc_f_9595).a0;
                auto&& ps_p6 = prism_rtl::as<crate::check::types::Ty::TyFn>(norm_assoc_f_9595).a1;
                auto&& res_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(norm_assoc_f_9595).a2;
                crate::prelude::call_then(crate::check::types::colors::start_walk_col_f(st_p0x, c_p5), [=](crate::check::types::Col walk_col_f_9707) {
                return crate::prelude::call_value(crate::prelude::each_job(ps_p6, ({
                    auto st_p0xx = st_p0x;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, st_p0xx = std::move(st_p0xx)](crate::check::types::Ty p0) {
                    return ({
                        auto st_p0xxy = st_p0xx;
                        (crate::prelude::entered(crate::prelude::once_job([=, st_p0xxy = std::move(st_p0xxy)]() {
                        return ({
                            auto p_p8 = p0;
                            (prism_rtl::more(prism_rtl::rc(Zonk(st_p0xxy, p_p8))));
                        });
                    })));
                    });
                })));
                })), [=](Array<crate::check::types::Ty> each_9724) { return crate::prelude::call_then(start_zonk_f(st_p0x, prism_rtl::deref(res_p7)), [=](crate::check::types::Ty zonk_f_9752) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyFn{walk_col_f_9707, each_9724, prism_rtl::rc(zonk_f_9752)})); }); });
            });
            })
                : prism_rtl::is<crate::check::types::Ty::TyTuple>(norm_assoc_f_9595) ? ({
                auto&& ts_p9 = prism_rtl::as<crate::check::types::Ty::TyTuple>(norm_assoc_f_9595).a0;
                crate::prelude::call_value(crate::prelude::each_job(ts_p9, ({
                auto st_p0xx = st_p0x;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, st_p0xx = std::move(st_p0xx)](crate::check::types::Ty p0) {
                return ({
                    auto st_p0xxy = st_p0xx;
                    (crate::prelude::entered(crate::prelude::once_job([=, st_p0xxy = std::move(st_p0xxy)]() {
                    return ({
                        auto a_pa = p0;
                        (prism_rtl::more(prism_rtl::rc(Zonk(st_p0xxy, a_pa))));
                    });
                })));
                });
            })));
            })), [=](Array<crate::check::types::Ty> each_9791) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyTuple{each_9791})); });
            })
                : prism_rtl::is<crate::check::types::Ty::TyArray>(norm_assoc_f_9595) ? ({
                auto&& e_pb = prism_rtl::as<crate::check::types::Ty::TyArray>(norm_assoc_f_9595).a0;
                crate::prelude::call_then(start_zonk_f(st_p0x, prism_rtl::deref(e_pb)), [=](crate::check::types::Ty zonk_f_9841) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(zonk_f_9841)})); });
            })
                : prism_rtl::is<crate::check::types::Ty::TyMap>(norm_assoc_f_9595) ? ({
                auto&& k_pc = prism_rtl::as<crate::check::types::Ty::TyMap>(norm_assoc_f_9595).a0;
                auto&& v_pd = prism_rtl::as<crate::check::types::Ty::TyMap>(norm_assoc_f_9595).a1;
                crate::prelude::call_then(start_zonk_f(st_p0x, prism_rtl::deref(k_pc)), [=](crate::check::types::Ty zonk_f_9876) { return crate::prelude::call_then(start_zonk_f(st_p0x, prism_rtl::deref(v_pd)), [=](crate::check::types::Ty zonk_f_9890) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(zonk_f_9876), prism_rtl::rc(zonk_f_9890)})); }); });
            })
                : prism_rtl::is<crate::check::types::Ty::TySig>(norm_assoc_f_9595) ? ({
                auto&& s_pe = prism_rtl::as<crate::check::types::Ty::TySig>(norm_assoc_f_9595).a0;
                auto&& i_pf = prism_rtl::as<crate::check::types::Ty::TySig>(norm_assoc_f_9595).a1;
                crate::prelude::call_then(start_zonk_f(st_p0x, prism_rtl::deref(i_pf)), [=](crate::check::types::Ty zonk_f_9928) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TySig{s_pe, prism_rtl::rc(zonk_f_9928)})); });
            })
                : prism_rtl::is<crate::check::types::Ty::TyAt>(norm_assoc_f_9595) ? ({
                auto&& i_pg = prism_rtl::as<crate::check::types::Ty::TyAt>(norm_assoc_f_9595).a0;
                auto&& rw_ph = prism_rtl::as<crate::check::types::Ty::TyAt>(norm_assoc_f_9595).a1;
                crate::prelude::call_then(start_zonk_f(st_p0x, prism_rtl::deref(i_pg)), [=](crate::check::types::Ty zonk_f_9962) { return crate::prelude::call_then(start_walk_row_f(st_p0x, rw_ph), [=](crate::check::types::Rw walk_row_f_9976) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(zonk_f_9962), walk_row_f_9976})); }); });
            })
                : prism_rtl::is<crate::check::types::Ty::TyElem>(norm_assoc_f_9595) ? ({
                auto&& rw_pi = prism_rtl::as<crate::check::types::Ty::TyElem>(norm_assoc_f_9595).a0;
                auto&& o_pj = prism_rtl::as<crate::check::types::Ty::TyElem>(norm_assoc_f_9595).a1;
                crate::prelude::call_then(start_walk_row_f(st_p0x, rw_pi), [=](crate::check::types::Rw walk_row_f_10018) { return crate::prelude::call_then(start_zonk_f(st_p0x, prism_rtl::deref(o_pj)), [=](crate::check::types::Ty zonk_f_10036) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyElem{walk_row_f_10018, prism_rtl::rc(zonk_f_10036)})); }); });
            })
                : prism_rtl::is<crate::check::types::Ty::TyElemAny>(norm_assoc_f_9595) ? ({
                auto&& rw_pk = prism_rtl::as<crate::check::types::Ty::TyElemAny>(norm_assoc_f_9595).a0;
                crate::prelude::call_then(start_walk_row_f(st_p0x, rw_pk), [=](crate::check::types::Rw walk_row_f_10077) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyElemAny{walk_row_f_10077})); });
            })
                : prism_rtl::is<crate::check::types::Ty::TyAssoc>(norm_assoc_f_9595) ? ({
                auto&& n_pl = prism_rtl::as<crate::check::types::Ty::TyAssoc>(norm_assoc_f_9595).a0;
                auto&& a_pm = prism_rtl::as<crate::check::types::Ty::TyAssoc>(norm_assoc_f_9595).a1;
                crate::prelude::call_then(start_zonk_f(st_p0x, prism_rtl::deref(a_pm)), [=](crate::check::types::Ty zonk_f_10123) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyAssoc{n_pl, prism_rtl::rc(zonk_f_10123)})); });
            })
                : ({
                auto&& w_pn = norm_assoc_f_9595;
                prism_rtl::finished(w_pn);
            });
            });
        });
    });
}


/// `Start Zonk, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_zonk_f(crate::check::types::St st_p0, crate::check::types::Ty t_p1) {
    return prism_rtl::make_rc<Zonk>(st_p0, t_p1);
}


/// FreeVars: unbounded fn St, Ty -> [Nat]
Array<Nat> free_vars_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1) {
    return free_vars_into_f(st_p0, Array<Nat>{}, t_p1);
}


prism_rtl::Turn<Array<Nat>> FreeVars::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    return prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_p0, Array<Nat>{}, t_p1)));
}


/// `Start FreeVars, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Nat>> start_free_vars_f(crate::check::types::St st_p0, crate::check::types::Ty t_p1) {
    return prism_rtl::make_rc<FreeVars>(st_p0, t_p1);
}


/// FreeVarsInto: unbounded fn St, [Nat], Ty -> [Nat]
Array<Nat> free_vars_into_f(const crate::check::types::St& st_p0, const Array<Nat>& acc_p1, const crate::check::types::Ty& t_p2) {
    auto&& _m = walk_f(st_p0, t_p2);
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(_m)) {
        auto&& n_p3 = prism_rtl::as<crate::check::types::Ty::TyFlex>(_m).a0;
        return crate::check::types::add_nat_f(acc_p1, n_p3);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& args_p4 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        return crate::prelude::run_to_end(crate::prelude::fold_job(args_p4, acc_p1, ({
            auto st_p0x = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_p0x = std::move(st_p0x)](std::tuple<Array<Nat>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_p0xy = st_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, st_p0xy = std::move(st_p0xy)]() {
                return ({
                    auto a_p5 = p0;
                    auto x_p6 = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_p0xy, a_p5, x_p6))));
                });
            })));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
        auto&& ps_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
        auto&& res_p8 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
        return free_vars_into_f(st_p0, crate::prelude::run_to_end(crate::prelude::fold_job(ps_p7, acc_p1, ({
            auto st_p0x = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_p0x = std::move(st_p0x)](std::tuple<Array<Nat>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_p0xy = st_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, st_p0xy = std::move(st_p0xy)]() {
                return ({
                    auto a_p9 = p0;
                    auto x_pa = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_p0xy, a_p9, x_pa))));
                });
            })));
            });
        })));
        }))), prism_rtl::deref(res_p8));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(_m)) {
        auto&& ts_pb = prism_rtl::as<crate::check::types::Ty::TyTuple>(_m).a0;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ts_pb, acc_p1, ({
            auto st_p0x = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_p0x = std::move(st_p0x)](std::tuple<Array<Nat>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_p0xy = st_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, st_p0xy = std::move(st_p0xy)]() {
                return ({
                    auto a_pc = p0;
                    auto x_pd = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_p0xy, a_pc, x_pd))));
                });
            })));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(_m)) {
        auto&& e_pe = prism_rtl::as<crate::check::types::Ty::TyArray>(_m).a0;
        return free_vars_into_f(st_p0, acc_p1, prism_rtl::deref(e_pe));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(_m)) {
        auto&& k_pf = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a0;
        auto&& v_pg = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a1;
        return free_vars_into_f(st_p0, free_vars_into_f(st_p0, acc_p1, prism_rtl::deref(k_pf)), prism_rtl::deref(v_pg));
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& i_ph = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        return free_vars_into_f(st_p0, acc_p1, prism_rtl::deref(i_ph));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
        auto&& i_pi = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a0;
        return free_vars_into_f(st_p0, acc_p1, prism_rtl::deref(i_pi));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
        auto&& o_pj = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a1;
        return free_vars_into_f(st_p0, acc_p1, prism_rtl::deref(o_pj));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(_m)) {
        auto&& a_pk = prism_rtl::as<crate::check::types::Ty::TyAssoc>(_m).a1;
        return free_vars_into_f(st_p0, acc_p1, prism_rtl::deref(a_pk));
    }
    {
        return acc_p1;
    }
}


prism_rtl::Turn<Array<Nat>> FreeVarsInto::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& acc_p1 = this->acc_p1;
    const auto& t_p2 = this->t_p2;
    auto acc_p1x = acc_p1;
    auto st_p0x = st_p0;
    auto t_p2x = t_p2;
    return crate::prelude::call_then(start_walk_f(st_p0x, t_p2x), [=](crate::check::types::Ty walk_f_10356) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_f_10356) ? ({
            auto&& n_p3 = prism_rtl::as<crate::check::types::Ty::TyFlex>(walk_f_10356).a0;
            prism_rtl::finished(crate::check::types::add_nat_f(acc_p1x, n_p3));
        })
            : prism_rtl::is<crate::check::types::Ty::TyCon>(walk_f_10356) ? ({
            auto&& args_p4 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_10356).a1;
            crate::prelude::fold_job(args_p4, acc_p1x, ({
            auto st_p0xx = st_p0x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_p0xx = std::move(st_p0xx)](std::tuple<Array<Nat>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_p0xxy = st_p0xx;
                (crate::prelude::entered(crate::prelude::once_job([=, st_p0xxy = std::move(st_p0xxy)]() {
                return ({
                    auto a_p5 = p0;
                    auto x_p6 = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_p0xxy, a_p5, x_p6))));
                });
            })));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::check::types::Ty::TyFn>(walk_f_10356) ? ({
            auto&& ps_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_f_10356).a1;
            auto&& res_p8 = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_f_10356).a2;
            crate::prelude::call_value(crate::prelude::fold_job(ps_p7, acc_p1x, ({
            auto st_p0xx = st_p0x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_p0xx = std::move(st_p0xx)](std::tuple<Array<Nat>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_p0xxy = st_p0xx;
                (crate::prelude::entered(crate::prelude::once_job([=, st_p0xxy = std::move(st_p0xxy)]() {
                return ({
                    auto a_p9 = p0;
                    auto x_pa = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_p0xxy, a_p9, x_pa))));
                });
            })));
            });
        })));
        })), [=](Array<Nat> fold_10510) { return prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_p0x, fold_10510, prism_rtl::deref(res_p8)))); });
        })
            : prism_rtl::is<crate::check::types::Ty::TyTuple>(walk_f_10356) ? ({
            auto&& ts_pb = prism_rtl::as<crate::check::types::Ty::TyTuple>(walk_f_10356).a0;
            crate::prelude::fold_job(ts_pb, acc_p1x, ({
            auto st_p0xx = st_p0x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_p0xx = std::move(st_p0xx)](std::tuple<Array<Nat>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_p0xxy = st_p0xx;
                (crate::prelude::entered(crate::prelude::once_job([=, st_p0xxy = std::move(st_p0xxy)]() {
                return ({
                    auto a_pc = p0;
                    auto x_pd = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_p0xxy, a_pc, x_pd))));
                });
            })));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::check::types::Ty::TyArray>(walk_f_10356) ? ({
            auto&& e_pe = prism_rtl::as<crate::check::types::Ty::TyArray>(walk_f_10356).a0;
            prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_p0x, acc_p1x, prism_rtl::deref(e_pe))));
        })
            : prism_rtl::is<crate::check::types::Ty::TyMap>(walk_f_10356) ? ({
            auto&& k_pf = prism_rtl::as<crate::check::types::Ty::TyMap>(walk_f_10356).a0;
            auto&& v_pg = prism_rtl::as<crate::check::types::Ty::TyMap>(walk_f_10356).a1;
            crate::prelude::call_then(start_free_vars_into_f(st_p0x, acc_p1x, prism_rtl::deref(k_pf)), [=](Array<Nat> free_vars_into_f_10693) { return prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_p0x, free_vars_into_f_10693, prism_rtl::deref(v_pg)))); });
        })
            : prism_rtl::is<crate::check::types::Ty::TySig>(walk_f_10356) ? ({
            auto&& i_ph = prism_rtl::as<crate::check::types::Ty::TySig>(walk_f_10356).a1;
            prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_p0x, acc_p1x, prism_rtl::deref(i_ph))));
        })
            : prism_rtl::is<crate::check::types::Ty::TyAt>(walk_f_10356) ? ({
            auto&& i_pi = prism_rtl::as<crate::check::types::Ty::TyAt>(walk_f_10356).a0;
            prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_p0x, acc_p1x, prism_rtl::deref(i_pi))));
        })
            : prism_rtl::is<crate::check::types::Ty::TyElem>(walk_f_10356) ? ({
            auto&& o_pj = prism_rtl::as<crate::check::types::Ty::TyElem>(walk_f_10356).a1;
            prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_p0x, acc_p1x, prism_rtl::deref(o_pj))));
        })
            : prism_rtl::is<crate::check::types::Ty::TyAssoc>(walk_f_10356) ? ({
            auto&& a_pk = prism_rtl::as<crate::check::types::Ty::TyAssoc>(walk_f_10356).a1;
            prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_p0x, acc_p1x, prism_rtl::deref(a_pk))));
        })
            : prism_rtl::finished(acc_p1x);
        });
    });
}


/// `Start FreeVarsInto, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Nat>> start_free_vars_into_f(crate::check::types::St st_p0, Array<Nat> acc_p1, crate::check::types::Ty t_p2) {
    return prism_rtl::make_rc<FreeVarsInto>(st_p0, acc_p1, t_p2);
}

}  // namespace crate::check::types::recording
