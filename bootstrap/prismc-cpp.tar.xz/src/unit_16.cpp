// The module `Check.Passes`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/passes/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Passes`, from `target/bootstrap/cpp-src/prismc/check/passes/mod.prism`.
namespace crate::check::passes {

bool Ctor::operator==(const Ctor& o) const { return name == o.name && arity == o.arity && args == o.args && shown == o.shown; }

void Ctor::show(Printer& p) const {
    p.record("Ctor", {{"name", name}, {"arity", arity}, {"args", args}, {"shown", shown}});
}

Pod Ctor::to_pod() const {
    return Pod::record("Ctor", {{"name", prism_rtl::to_pod(name)}, {"arity", prism_rtl::to_pod(arity)}, {"args", prism_rtl::to_pod(args)}, {"shown", prism_rtl::to_pod(shown)}});
}

Result<Ctor> Ctor::from_pod(const Pod& whole) {
    return Ctor{.name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .arity = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "arity")))), .args = TRY(prism_rtl::from_pod<Array<crate::check::types::Ty>>(TRY(crate::prelude::field(whole, "args")))), .shown = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "shown"))))};
}


bool Pat::PtCon::operator==(const PtCon& o) const { return a0 == o.a0 && a1 == o.a1; }

void Pat::show(Printer& p) const {
    if (auto c = std::get_if<PtAny>(&cases())) p.choice("PtAny", {});
    else if (auto c = std::get_if<PtCon>(&cases())) p.choice("PtCon", {c->a0, c->a1});
    else if (auto c = std::get_if<PtLit>(&cases())) p.choice("PtLit", {c->a0});
    else if (auto c = std::get_if<PtFam>(&cases())) p.choice("PtFam", {c->a0});
}

Pod Pat::to_pod() const {
    return std::holds_alternative<PtAny>(cases()) ? Pod::choice("PtAny", {})
        : std::holds_alternative<PtCon>(cases()) ? Pod::choice("PtCon", {prism_rtl::to_pod(std::get<PtCon>(cases()).a0), prism_rtl::to_pod(std::get<PtCon>(cases()).a1)})
        : std::holds_alternative<PtLit>(cases()) ? Pod::choice("PtLit", {prism_rtl::to_pod(std::get<PtLit>(cases()).a0)})
        : std::holds_alternative<PtFam>(cases()) ? Pod::choice("PtFam", {prism_rtl::to_pod(std::get<PtFam>(cases()).a0)})
        : Pod();
}

Result<Pat> Pat::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "PtAny" && c->args.size() == 0) return Pat(PtAny{});
        if (c->ctor == "PtCon" && c->args.size() == 2) return Pat(PtCon{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Array<Pat>>(c->args[1]))});
        if (c->ctor == "PtLit" && c->args.size() == 1) return Pat(PtLit{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "PtFam" && c->args.size() == 1) return Pat(PtFam{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
    }
    return mismatch<Pat>("a Pat", p);
}


/// ?CtorsOf: unbounded fn Env, St, Ty -> ?[Ctor]
std::optional<Array<Ctor>> ctors_of(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::check::types::Ty& t_p2) {
    auto&& _m = crate::check::types::recording::walk(st_p1, t_p2);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& m2894_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& m2894_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        if (m2894_0_0 == Text::lit("Bool")) {
            if (m2894_0_1.size() == 0u) {
                return std::optional(Array(std::vector{Ctor{.name = Text::lit("True"), .arity = Nat(0u), .args = Array<crate::check::types::Ty>{}, .shown = Text::lit("True")}, Ctor{.name = Text::lit("False"), .arity = Nat(0u), .args = Array<crate::check::types::Ty>{}, .shown = Text::lit("False")}}));
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& m2894_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& m2894_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        if (m2894_1_0 == Text::lit("unit")) {
            if (m2894_1_1.size() == 0u) {
                return std::optional(Array(std::vector{Ctor{.name = Text::lit("unit"), .arity = Nat(0u), .args = Array<crate::check::types::Ty>{}, .shown = Text::lit("unit")}}));
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& m2894_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
        auto&& i_p3 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        if (m2894_2_0 == Text::lit("?")) {
            return std::optional(Array(std::vector{Ctor{.name = Text::lit("?"), .arity = Nat(1u), .args = Array(std::vector{prism_rtl::deref(i_p3)}), .shown = Text::lit("? _")}, Ctor{.name = Text::lit("nil"), .arity = Nat(0u), .args = Array<crate::check::types::Ty>{}, .shown = Text::lit("nil")}}));
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& m2894_3_0 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
        auto&& i_p4 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        if (m2894_3_0 == Text::lit("~")) {
            return std::optional(Array(std::vector{Ctor{.name = Text::lit("~"), .arity = Nat(1u), .args = Array(std::vector{prism_rtl::deref(i_p4)}), .shown = Text::lit("~ _")}, Ctor{.name = Text::lit("Error"), .arity = Nat(2u), .args = Array(std::vector{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Prelude.Fault"), Array<crate::check::types::Ty>{}}), crate::check::types::t_text()}), .shown = Text::lit("Error(..)")}}));
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(_m)) {
        auto&& ts_p5 = prism_rtl::as<crate::check::types::Ty::TyTuple>(_m).a0;
        return std::optional(Array(std::vector{Ctor{.name = Text::lit("tuple"), .arity = len(ts_p5), .args = ts_p5, .shown = prism_rtl::cat("((", crate::syntax::lexer::chars::join(each(ts_p5, [&](const crate::check::types::Ty& _p0) { return Text::lit("_"); }), Text::lit(", ")), "))")}}));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& m2894_5_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& m2894_5_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        if (m2894_5_0 == Text::lit("Prelude.Error")) {
            if (m2894_5_1.size() == 0u) {
                return std::optional(Array(std::vector{Ctor{.name = Text::lit("Error"), .arity = Nat(2u), .args = Array(std::vector{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Prelude.Fault"), Array<crate::check::types::Ty>{}}), crate::check::types::t_text()}), .shown = Text::lit("Error(..)")}}));
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& n_p6 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& args_p7 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0.g).types, n_p6);
        if (prism_rtl::is_some(_m)) {
            auto&& ti_p8 = prism_rtl::some_of(_m);
            auto&& _m = prism_rtl::deref(ti_p8).body;
            if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
                auto&& cases_p9 = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
                return std::optional(run_to_end(each_job(cases_p9, ({
                    auto ti_p8_1 = ti_p8;
                    auto args_p7_2 = args_p7;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ctor>(std::tuple<Text, Array<crate::check::types::Ty>>)>>(prism_rtl::rc([=, ti_p8_1 = std::move(ti_p8_1), args_p7_2 = std::move(args_p7_2)](std::tuple<Text, Array<crate::check::types::Ty>> p0) {
                    return ({
                        auto ti_p8_1_3 = ti_p8_1;
                        auto args_p7_2_3 = args_p7_2;
                        entered(once_job([=, ti_p8_1_3 = std::move(ti_p8_1_3), args_p7_2_3 = std::move(args_p7_2_3)]() {
                        return ({
                            auto [cn_pa, cargs_pb] = p0;
                            (prism_rtl::more(prism_rtl::rc(CtorOfCase(ti_p8_1_3, cn_pa, cargs_pb, args_p7_2_3))));
                        });
                    }));
                    });
                })));
                }))));
            }
            if (prism_rtl::is<crate::check::env::TyBody::BRecord>(_m)) {
                auto&& fields_pc = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
                return std::optional(Array(std::vector{Ctor{.name = n_p6, .arity = len(fields_pc), .args = run_to_end(each_job(fields_pc, ({
                    auto ti_p8_1 = ti_p8;
                    auto args_p7_2 = args_p7;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(std::tuple<Text, crate::check::types::Ty>)>>(prism_rtl::rc([=, ti_p8_1 = std::move(ti_p8_1), args_p7_2 = std::move(args_p7_2)](std::tuple<Text, crate::check::types::Ty> p0) {
                    return ({
                        auto ti_p8_1_3 = ti_p8_1;
                        auto args_p7_2_3 = args_p7_2;
                        entered(once_job([=, ti_p8_1_3 = std::move(ti_p8_1_3), args_p7_2_3 = std::move(args_p7_2_3)]() {
                        return ({
                            auto&& _ft_pd = p0;
                            auto&& ft_pd = std::get<1>(_ft_pd);
                            (prism_rtl::more(prism_rtl::rc(crate::check::types::schemes::SubstQ(crate::check::env::reading::param_inst(prism_rtl::deref(ti_p8_1_3).params, args_p7_2_3), ft_pd))));
                        });
                    }));
                    });
                })));
                }))), .shown = prism_rtl::cat(crate::check::types::bare_name(n_p6), "(..)")}}));
            }
            if (prism_rtl::is<crate::check::env::TyBody::BRowKind>(_m)) {
                return is_root_module(env_p0)
                    ? std::optional(each(tags_of_kind(env_p0, n_p6), [&](const crate::check::env::TagInfo& tg_pe) { return tag_ctor(tg_pe); }))
                    : std::optional<Array<Ctor>>{};
            }
            {
                return std::optional<Array<Ctor>>{};
            }
        }
        if (prism_rtl::is_none(_m)) {
            return (n_p6 == Text::lit("Fault")) || (n_p6 == Text::lit("Prelude.Fault"))
                ? is_root_module(env_p0)
                ? std::optional(each(tags_of_kind(env_p0, Text::lit("Prelude.Fault")), [&](const crate::check::env::TagInfo& tg_pf) { return tag_ctor(tg_pf); }))
                : std::optional<Array<Ctor>>{}
                : std::optional<Array<Ctor>>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
        auto&& rw_pg = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a0;
        auto w_ph = crate::check::types::recording::walk_row(st_p1, rw_pg);
        return prism_rtl::deref(w_ph).tail != crate::check::types::Tail(crate::check::types::Tail::TlClosed{})
            ? std::optional<Array<Ctor>>{}
            : std::optional(each(tags_of_row(env_p0, w_ph), [&](const crate::check::env::TagInfo& tg_pi) { return tag_ctor(tg_pi); }));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(_m)) {
        auto&& rw_pj = prism_rtl::as<crate::check::types::Ty::TyElemAny>(_m).a0;
        auto w_pk = crate::check::types::recording::walk_row(st_p1, rw_pj);
        return prism_rtl::deref(w_pk).tail != crate::check::types::Tail(crate::check::types::Tail::TlClosed{})
            ? std::optional<Array<Ctor>>{}
            : std::optional(each(tags_of_row(env_p0, w_pk), [&](const crate::check::env::TagInfo& tg_pl) { return tag_ctor(tg_pl); }));
    }
    {
        return std::optional<Array<Ctor>>{};
    }
}


prism_rtl::Turn<std::optional<Array<Ctor>>> CtorsOf::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& t_p2 = this->t_p2;
    auto env_p0_1 = env_p0;
    auto st_p1_2 = st_p1;
    auto t_p2_3 = t_p2;
    return call_then(crate::check::types::recording::start_walk(st_p1_2, t_p2_3), [=](crate::check::types::Ty walk_2900) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyCon>(walk_2900) && ({
            auto&& m2894_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2900).a0;
            auto&& m2894_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2900).a1;
            (m2894_0_0 == Text::lit("Bool")) && (m2894_0_1.size() == 0u);
        }) ? ({
            auto&& m2894_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2900).a0;
            auto&& m2894_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2900).a1;
            prism_rtl::finished(std::optional(Array(std::vector{Ctor{.name = Text::lit("True"), .arity = Nat(0u), .args = Array<crate::check::types::Ty>{}, .shown = Text::lit("True")}, Ctor{.name = Text::lit("False"), .arity = Nat(0u), .args = Array<crate::check::types::Ty>{}, .shown = Text::lit("False")}})));
        })
            : prism_rtl::is<crate::check::types::Ty::TyCon>(walk_2900) && ({
            auto&& m2894_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2900).a0;
            auto&& m2894_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2900).a1;
            (m2894_1_0 == Text::lit("unit")) && (m2894_1_1.size() == 0u);
        }) ? ({
            auto&& m2894_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2900).a0;
            auto&& m2894_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2900).a1;
            prism_rtl::finished(std::optional(Array(std::vector{Ctor{.name = Text::lit("unit"), .arity = Nat(0u), .args = Array<crate::check::types::Ty>{}, .shown = Text::lit("unit")}})));
        })
            : prism_rtl::is<crate::check::types::Ty::TySig>(walk_2900) && ({
            auto&& m2894_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_2900).a0;
            auto&& i_p3 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_2900).a1;
            (m2894_2_0 == Text::lit("?"));
        }) ? ({
            auto&& m2894_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_2900).a0;
            auto&& i_p3 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_2900).a1;
            prism_rtl::finished(std::optional(Array(std::vector{Ctor{.name = Text::lit("?"), .arity = Nat(1u), .args = Array(std::vector{prism_rtl::deref(i_p3)}), .shown = Text::lit("? _")}, Ctor{.name = Text::lit("nil"), .arity = Nat(0u), .args = Array<crate::check::types::Ty>{}, .shown = Text::lit("nil")}})));
        })
            : prism_rtl::is<crate::check::types::Ty::TySig>(walk_2900) && ({
            auto&& m2894_3_0 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_2900).a0;
            auto&& i_p4 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_2900).a1;
            (m2894_3_0 == Text::lit("~"));
        }) ? ({
            auto&& m2894_3_0 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_2900).a0;
            auto&& i_p4 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_2900).a1;
            prism_rtl::finished(std::optional(Array(std::vector{Ctor{.name = Text::lit("~"), .arity = Nat(1u), .args = Array(std::vector{prism_rtl::deref(i_p4)}), .shown = Text::lit("~ _")}, Ctor{.name = Text::lit("Error"), .arity = Nat(2u), .args = Array(std::vector{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Prelude.Fault"), Array<crate::check::types::Ty>{}}), crate::check::types::t_text()}), .shown = Text::lit("Error(..)")}})));
        })
            : prism_rtl::is<crate::check::types::Ty::TyTuple>(walk_2900) ? ({
            auto&& ts_p5 = prism_rtl::as<crate::check::types::Ty::TyTuple>(walk_2900).a0;
            prism_rtl::finished(std::optional(Array(std::vector{Ctor{.name = Text::lit("tuple"), .arity = len(ts_p5), .args = ts_p5, .shown = prism_rtl::cat("((", crate::syntax::lexer::chars::join(each(ts_p5, [&](const crate::check::types::Ty& _p0) { return Text::lit("_"); }), Text::lit(", ")), "))")}})));
        })
            : prism_rtl::is<crate::check::types::Ty::TyCon>(walk_2900) && ({
            auto&& m2894_5_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2900).a0;
            auto&& m2894_5_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2900).a1;
            (m2894_5_0 == Text::lit("Prelude.Error")) && (m2894_5_1.size() == 0u);
        }) ? ({
            auto&& m2894_5_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2900).a0;
            auto&& m2894_5_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2900).a1;
            prism_rtl::finished(std::optional(Array(std::vector{Ctor{.name = Text::lit("Error"), .arity = Nat(2u), .args = Array(std::vector{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Prelude.Fault"), Array<crate::check::types::Ty>{}}), crate::check::types::t_text()}), .shown = Text::lit("Error(..)")}})));
        })
            : prism_rtl::is<crate::check::types::Ty::TyCon>(walk_2900) ? ({
            auto&& n_p6 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2900).a0;
            auto&& args_p7 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2900).a1;
            ({
            auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env_p0_1).g).types, n_p6);
            prism_rtl::is_some(_m) ? ({
            auto&& ti_p8 = prism_rtl::some_of(_m);
            ({
            auto&& _m = prism_rtl::deref(ti_p8).body;
            prism_rtl::is<crate::check::env::TyBody::BChoice>(_m) ? ({
            auto&& cases_p9 = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
            prism_rtl::finished(std::optional(run_to_end(each_job(cases_p9, ({
            auto ti_p8_4 = ti_p8;
            auto args_p7_5 = args_p7;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ctor>(std::tuple<Text, Array<crate::check::types::Ty>>)>>(prism_rtl::rc([=, ti_p8_4 = std::move(ti_p8_4), args_p7_5 = std::move(args_p7_5)](std::tuple<Text, Array<crate::check::types::Ty>> p0) {
            return ({
                auto ti_p8_4_6 = ti_p8_4;
                auto args_p7_5_6 = args_p7_5;
                entered(once_job([=, ti_p8_4_6 = std::move(ti_p8_4_6), args_p7_5_6 = std::move(args_p7_5_6)]() {
                return ({
                    auto [cn_pa, cargs_pb] = p0;
                    (prism_rtl::more(prism_rtl::rc(CtorOfCase(ti_p8_4_6, cn_pa, cargs_pb, args_p7_5_6))));
                });
            }));
            });
        })));
        })))));
        })
            : prism_rtl::is<crate::check::env::TyBody::BRecord>(_m) ? ({
            auto&& fields_pc = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
            prism_rtl::finished(std::optional(Array(std::vector{Ctor{.name = n_p6, .arity = len(fields_pc), .args = run_to_end(each_job(fields_pc, ({
            auto ti_p8_4 = ti_p8;
            auto args_p7_5 = args_p7;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(std::tuple<Text, crate::check::types::Ty>)>>(prism_rtl::rc([=, ti_p8_4 = std::move(ti_p8_4), args_p7_5 = std::move(args_p7_5)](std::tuple<Text, crate::check::types::Ty> p0) {
            return ({
                auto ti_p8_4_6 = ti_p8_4;
                auto args_p7_5_6 = args_p7_5;
                entered(once_job([=, ti_p8_4_6 = std::move(ti_p8_4_6), args_p7_5_6 = std::move(args_p7_5_6)]() {
                return ({
                    auto&& _ft_pd = p0;
                    auto&& ft_pd = std::get<1>(_ft_pd);
                    (prism_rtl::more(prism_rtl::rc(crate::check::types::schemes::SubstQ(crate::check::env::reading::param_inst(prism_rtl::deref(ti_p8_4_6).params, args_p7_5_6), ft_pd))));
                });
            }));
            });
        })));
        }))), .shown = prism_rtl::cat(crate::check::types::bare_name(n_p6), "(..)")}})));
        })
            : prism_rtl::is<crate::check::env::TyBody::BRowKind>(_m) ? is_root_module(env_p0_1)
            ? prism_rtl::finished(std::optional(each(tags_of_kind(env_p0_1, n_p6), [&](const crate::check::env::TagInfo& tg_pe) { return tag_ctor(tg_pe); })))
            : prism_rtl::finished(std::optional<Array<Ctor>>{})
            : prism_rtl::finished(std::optional<Array<Ctor>>{});
        });
        })
            : prism_rtl::is_none(_m) ? (n_p6 == Text::lit("Fault")) || (n_p6 == Text::lit("Prelude.Fault"))
            ? is_root_module(env_p0_1)
            ? prism_rtl::finished(std::optional(each(tags_of_kind(env_p0_1, Text::lit("Prelude.Fault")), [&](const crate::check::env::TagInfo& tg_pf) { return tag_ctor(tg_pf); })))
            : prism_rtl::finished(std::optional<Array<Ctor>>{})
            : prism_rtl::finished(std::optional<Array<Ctor>>{})
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::is<crate::check::types::Ty::TyElem>(walk_2900) ? ({
            auto&& rw_pg = prism_rtl::as<crate::check::types::Ty::TyElem>(walk_2900).a0;
            call_then(crate::check::types::recording::start_walk_row(st_p1_2, rw_pg), [=](crate::check::types::Rw walk_row_4329) {
            return ({
                auto w_ph = walk_row_4329;
                (prism_rtl::deref(w_ph).tail != crate::check::types::Tail(crate::check::types::Tail::TlClosed{})
                ? prism_rtl::finished(std::optional<Array<Ctor>>{})
                : prism_rtl::finished(std::optional(each(tags_of_row(env_p0_1, w_ph), [&](const crate::check::env::TagInfo& tg_pi) { return tag_ctor(tg_pi); }))));
            });
        });
        })
            : prism_rtl::is<crate::check::types::Ty::TyElemAny>(walk_2900) ? ({
            auto&& rw_pj = prism_rtl::as<crate::check::types::Ty::TyElemAny>(walk_2900).a0;
            call_then(crate::check::types::recording::start_walk_row(st_p1_2, rw_pj), [=](crate::check::types::Rw walk_row_4473) {
            return ({
                auto w_pk = walk_row_4473;
                (prism_rtl::deref(w_pk).tail != crate::check::types::Tail(crate::check::types::Tail::TlClosed{})
                ? prism_rtl::finished(std::optional<Array<Ctor>>{})
                : prism_rtl::finished(std::optional(each(tags_of_row(env_p0_1, w_pk), [&](const crate::check::env::TagInfo& tg_pl) { return tag_ctor(tg_pl); }))));
            });
        });
        })
            : prism_rtl::finished(std::optional<Array<Ctor>>{});
        });
    });
}


/// `Start CtorsOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Array<Ctor>>> start_ctors_of(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::types::Ty t_p2) {
    return prism_rtl::make_rc<CtorsOf>(env_p0, st_p1, t_p2);
}


/// CtorOfCase: unbounded fn TyInfo, Text, [Ty], [Ty] -> Ctor
Ctor ctor_of_case(const crate::check::env::TyInfo& ti_p0, const Text& cn_p1, const Array<crate::check::types::Ty>& cargs_p2, const Array<crate::check::types::Ty>& args_p3) {
    auto qk_p4 = crate::check::env::qual_key(ti_p0.home, cn_p1);
    return Ctor{.name = qk_p4, .arity = len(cargs_p2), .args = run_to_end(each_job(cargs_p2, ({
        auto ti_p0_1 = ti_p0;
        auto args_p3_2 = args_p3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, ti_p0_1 = std::move(ti_p0_1), args_p3_2 = std::move(args_p3_2)](crate::check::types::Ty p0) {
        return ({
            auto ti_p0_1_3 = ti_p0_1;
            auto args_p3_2_3 = args_p3_2;
            entered(once_job([=, ti_p0_1_3 = std::move(ti_p0_1_3), args_p3_2_3 = std::move(args_p3_2_3)]() {
            return ({
                auto a_p5 = p0;
                (prism_rtl::more(prism_rtl::rc(crate::check::types::schemes::SubstQ(crate::check::env::reading::param_inst(ti_p0_1_3.params, args_p3_2_3), a_p5))));
            });
        }));
        });
    })));
    }))), .shown = len(cargs_p2) == Nat(0u)
        ? cn_p1
        : prism_rtl::cat(cn_p1, " ", crate::syntax::lexer::chars::join(each(cargs_p2, [&](const crate::check::types::Ty& _p0) { return Text::lit("_"); }), Text::lit(", ")))};
}


prism_rtl::Turn<Ctor> CtorOfCase::cycle() const {
    const auto& ti_p0 = this->ti_p0;
    const auto& cn_p1 = this->cn_p1;
    const auto& cargs_p2 = this->cargs_p2;
    const auto& args_p3 = this->args_p3;
    auto qk_p4 = crate::check::env::qual_key(prism_rtl::deref(ti_p0).home, cn_p1);
    auto args_p3_1 = args_p3;
    auto cargs_p2_2 = cargs_p2;
    auto cn_p1_3 = cn_p1;
    auto ti_p0_4 = ti_p0;
    return call_value(each_job(cargs_p2_2, ({
        auto ti_p0_4_5 = ti_p0_4;
        auto args_p3_1_5 = args_p3_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, ti_p0_4_5 = std::move(ti_p0_4_5), args_p3_1_5 = std::move(args_p3_1_5)](crate::check::types::Ty p0) {
        return ({
            auto ti_p0_4_5_5 = ti_p0_4_5;
            auto args_p3_1_5_5 = args_p3_1_5;
            entered(once_job([=, ti_p0_4_5_5 = std::move(ti_p0_4_5_5), args_p3_1_5_5 = std::move(args_p3_1_5_5)]() {
            return ({
                auto a_p5 = p0;
                (prism_rtl::more(prism_rtl::rc(crate::check::types::schemes::SubstQ(crate::check::env::reading::param_inst(prism_rtl::deref(ti_p0_4_5_5).params, args_p3_1_5_5), a_p5))));
            });
        }));
        });
    })));
    })), [=](Array<crate::check::types::Ty> each_4772) {
        return prism_rtl::finished(Ctor{.name = qk_p4, .arity = len(cargs_p2_2), .args = each_4772, .shown = len(cargs_p2_2) == Nat(0u)
            ? cn_p1_3
            : prism_rtl::cat(cn_p1_3, " ", crate::syntax::lexer::chars::join(each(cargs_p2_2, [&](const crate::check::types::Ty& _p0) { return Text::lit("_"); }), Text::lit(", ")))});
    });
}


/// `Start CtorOfCase, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ctor> start_ctor_of_case(crate::check::env::TyInfo ti_p0, Text cn_p1, Array<crate::check::types::Ty> cargs_p2, Array<crate::check::types::Ty> args_p3) {
    return prism_rtl::make_rc<CtorOfCase>(ti_p0, cn_p1, cargs_p2, args_p3);
}


/// TagCtor: fn TagInfo -> Ctor
Ctor tag_ctor(const crate::check::env::TagInfo& tg_p0) {
    return Ctor{.name = prism_rtl::cat("tag:", tg_p0.name), .arity = len(tg_p0.fields), .args = each(tg_p0.fields, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
        auto&& ft_p1 = std::get<1>(_p0);
        return crate::check::types::Ty(crate::check::types::Ty::TyErr{});
    }), .shown = tg_p0.name};
}


/// IsRootModule: fn Env -> Bool
bool is_root_module(const crate::check::expr::Env& env_p0) {
    return env_p0.home == Text::lit("");
}


/// TagsOfKind: fn Env, Text -> [TagInfo]
Array<crate::check::env::TagInfo> tags_of_kind(const crate::check::expr::Env& env_p0, const Text& kind_p1) {
    return filter(values(prism_rtl::deref(env_p0.g).tags), [&](const crate::check::env::TagInfo& tg_p2) { return (prism_rtl::deref(tg_p2).kind == kind_p1) || ((crate::check::types::bare_name(prism_rtl::deref(tg_p2).kind) == Text::lit("Fault")) && (crate::check::types::bare_name(kind_p1) == Text::lit("Fault"))); });
}


/// TagsOfRow: fn Env, Rw -> [TagInfo]
Array<crate::check::env::TagInfo> tags_of_row(const crate::check::expr::Env& env_p0, const crate::check::types::Rw& w_p1) {
    return filter(values(prism_rtl::deref(env_p0.g).tags), [&](const crate::check::env::TagInfo& tg_p2) { return ((prism_rtl::deref(tg_p2).kind == Text::lit("Element")) && crate::check::types::has_text(w_p1.fams, prism_rtl::deref(tg_p2).family)) && (!crate::check::types::has_text(w_p1.minus, prism_rtl::deref(tg_p2).name)); });
}


/// ToPat: unbounded fn Env, Pattern -> Pat
Pat to_pat(const crate::check::expr::Env& env_p0, const crate::syntax::Pattern_& p_p1) {
    auto&& _m = prism_rtl::deref(p_p1.kind);
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n_p2 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        auto bare_p3 = or_(index(n_p2->path_, Nat(0u)), Text::lit(""));
        return (len(n_p2->path_) > Nat(1u)) && crate::check::env::has_key(prism_rtl::deref(env_p0.g).tags, crate::check::env::dotted(n_p2->path_))
            ? Pat(Pat::PtCon{prism_rtl::cat("tag:", crate::check::env::dotted(n_p2->path_)), Array<Pat>{}})
            : (crate::check::env::is_upper_text(bare_p3) && (len_text(prism_rtl::deref(n_p2).sigils) == Nat(0u))) && crate::check::expr::patterns::is_ctor_name(env_p0, n_p2)
            ? Pat(Pat::PtCon{ctor_key(env_p0, n_p2), Array<Pat>{}})
            : Pat(Pat::PtAny{});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m)) {
        return Pat(Pat::PtAny{});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PLit>(_m)) {
        auto&& l_p4 = prism_rtl::as<crate::syntax::PatternKind::PLit>(_m).a0;
        return Pat(Pat::PtLit{lit_text(l_p4)});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PNeg>(_m)) {
        auto&& l_p5 = prism_rtl::as<crate::syntax::PatternKind::PNeg>(_m).a0;
        return Pat(Pat::PtLit{prism_rtl::cat("-", lit_text(l_p5))});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PUnit>(_m)) {
        return Pat(Pat::PtCon{Text::lit("unit"), Array<Pat>{}});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PNil>(_m)) {
        return Pat(Pat::PtCon{Text::lit("nil"), Array<Pat>{}});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PCtor>(_m)) {
        auto&& n_p6 = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a0;
        auto&& args_p7 = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a1;
        return crate::check::env::has_key(prism_rtl::deref(env_p0.g).tags, crate::check::env::dotted(n_p6->path_))
            ? Pat(Pat::PtCon{prism_rtl::cat("tag:", crate::check::env::dotted(n_p6->path_)), Array<Pat>{}})
            : Pat(Pat::PtCon{ctor_key(env_p0, n_p6), run_to_end(each_job(args_p7, ({
            auto env_p0_1 = env_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(crate::syntax::Pattern_)>>(prism_rtl::rc([=, env_p0_1 = std::move(env_p0_1)](crate::syntax::Pattern_ p0) {
            return ({
                auto env_p0_1_2 = env_p0_1;
                entered(once_job([=, env_p0_1_2 = std::move(env_p0_1_2)]() {
                return ({
                    auto a_p8 = p0;
                    (prism_rtl::more(prism_rtl::rc(ToPat(env_p0_1_2, a_p8))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PRecord>(_m)) {
        auto&& n_p9 = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a0;
        auto&& fields_pa = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a1;
        return record_pat(env_p0, n_p9, fields_pa);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m)) {
        auto&& s_pb = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& q_pc = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        return Pat(Pat::PtCon{s_pb, Array(std::vector{to_pat(env_p0, prism_rtl::deref(prism_rtl::deref(q_pc)))})});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m)) {
        auto&& ps_pd = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        return Pat(Pat::PtCon{Text::lit("tuple"), run_to_end(each_job(ps_pd, ({
            auto env_p0_1 = env_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(crate::syntax::Pattern_)>>(prism_rtl::rc([=, env_p0_1 = std::move(env_p0_1)](crate::syntax::Pattern_ p0) {
            return ({
                auto env_p0_1_2 = env_p0_1;
                entered(once_job([=, env_p0_1_2 = std::move(env_p0_1_2)]() {
                return ({
                    auto q_pe = p0;
                    (prism_rtl::more(prism_rtl::rc(ToPat(env_p0_1_2, q_pe))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PArray>(_m)) {
        auto&& ps_pf = prism_rtl::as<crate::syntax::PatternKind::PArray>(_m).a0;
        return Pat(Pat::PtCon{prism_rtl::cat("len", len(ps_pf)), run_to_end(each_job(ps_pf, ({
            auto env_p0_1 = env_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(crate::syntax::Pattern_)>>(prism_rtl::rc([=, env_p0_1 = std::move(env_p0_1)](crate::syntax::Pattern_ p0) {
            return ({
                auto env_p0_1_2 = env_p0_1;
                entered(once_job([=, env_p0_1_2 = std::move(env_p0_1_2)]() {
                return ({
                    auto q_pg = p0;
                    (prism_rtl::more(prism_rtl::rc(ToPat(env_p0_1_2, q_pg))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q_ph = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return to_pat(env_p0, prism_rtl::deref(prism_rtl::deref(q_ph)));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PFamily>(_m)) {
        auto&& q_pi = prism_rtl::as<crate::syntax::PatternKind::PFamily>(_m).a0;
        return Pat(Pat::PtFam{crate::check::env::dotted(q_pi->path_)});
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Pat> ToPat::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& p_p1 = this->p_p1;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p1).kind);
        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n_p2 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        ({
        auto bare_p3 = or_(index(n_p2->path_, Nat(0u)), Text::lit(""));
        (len(n_p2->path_) > Nat(1u)) && crate::check::env::has_key(prism_rtl::deref(prism_rtl::deref(env_p0).g).tags, crate::check::env::dotted(n_p2->path_))
        ? prism_rtl::finished(Pat(Pat::PtCon{prism_rtl::cat("tag:", crate::check::env::dotted(n_p2->path_)), Array<Pat>{}}))
        : (crate::check::env::is_upper_text(bare_p3) && (len_text(prism_rtl::deref(n_p2).sigils) == Nat(0u))) && crate::check::expr::patterns::is_ctor_name(env_p0, n_p2)
        ? prism_rtl::finished(Pat(Pat::PtCon{ctor_key(env_p0, n_p2), Array<Pat>{}}))
        : prism_rtl::finished(Pat(Pat::PtAny{}));
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m) ? prism_rtl::finished(Pat(Pat::PtAny{}))
        : prism_rtl::is<crate::syntax::PatternKind::PLit>(_m) ? ({
        auto&& l_p4 = prism_rtl::as<crate::syntax::PatternKind::PLit>(_m).a0;
        prism_rtl::finished(Pat(Pat::PtLit{lit_text(l_p4)}));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PNeg>(_m) ? ({
        auto&& l_p5 = prism_rtl::as<crate::syntax::PatternKind::PNeg>(_m).a0;
        prism_rtl::finished(Pat(Pat::PtLit{prism_rtl::cat("-", lit_text(l_p5))}));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PUnit>(_m) ? prism_rtl::finished(Pat(Pat::PtCon{Text::lit("unit"), Array<Pat>{}}))
        : prism_rtl::is<crate::syntax::PatternKind::PNil>(_m) ? prism_rtl::finished(Pat(Pat::PtCon{Text::lit("nil"), Array<Pat>{}}))
        : prism_rtl::is<crate::syntax::PatternKind::PCtor>(_m) ? ({
        auto&& n_p6 = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a0;
        auto&& args_p7 = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a1;
        crate::check::env::has_key(prism_rtl::deref(prism_rtl::deref(env_p0).g).tags, crate::check::env::dotted(n_p6->path_))
        ? prism_rtl::finished(Pat(Pat::PtCon{prism_rtl::cat("tag:", crate::check::env::dotted(n_p6->path_)), Array<Pat>{}}))
        : ({
        auto args_p7_1 = args_p7;
        auto env_p0_2 = env_p0;
        auto n_p6_3 = n_p6;
        call_value(each_job(args_p7_1, ({
        auto env_p0_2_4 = env_p0_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(crate::syntax::Pattern_)>>(prism_rtl::rc([=, env_p0_2_4 = std::move(env_p0_2_4)](crate::syntax::Pattern_ p0) {
        return ({
            auto env_p0_2_4_4 = env_p0_2_4;
            entered(once_job([=, env_p0_2_4_4 = std::move(env_p0_2_4_4)]() {
            return ({
                auto a_p8 = p0;
                (prism_rtl::more(prism_rtl::rc(ToPat(env_p0_2_4_4, a_p8))));
            });
        }));
        });
    })));
    })), [=, n_p6_3 = std::move(n_p6_3)](Array<Pat> each_6274) { return prism_rtl::finished(Pat(Pat::PtCon{ctor_key(env_p0_2, n_p6_3), each_6274})); });
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PRecord>(_m) ? ({
        auto&& n_p9 = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a0;
        auto&& fields_pa = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a1;
        prism_rtl::more(prism_rtl::rc(RecordPat(env_p0, n_p9, fields_pa)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m) ? ({
        auto&& s_pb = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& q_pc = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        ({
        auto env_p0_1 = env_p0;
        auto q_pc_2 = prism_rtl::deref(prism_rtl::deref(q_pc));
        auto s_pb_3 = s_pb;
        call_then(start_to_pat(env_p0_1, q_pc_2), [=, s_pb_3 = std::move(s_pb_3)](Pat to_pat_6389) { return prism_rtl::finished(Pat(Pat::PtCon{s_pb_3, Array(std::vector{to_pat_6389})})); });
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m) ? ({
        auto&& ps_pd = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        ({
        auto env_p0_1 = env_p0;
        auto ps_pd_2 = ps_pd;
        call_value(each_job(ps_pd_2, ({
        auto env_p0_1_3 = env_p0_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(crate::syntax::Pattern_)>>(prism_rtl::rc([=, env_p0_1_3 = std::move(env_p0_1_3)](crate::syntax::Pattern_ p0) {
        return ({
            auto env_p0_1_3_3 = env_p0_1_3;
            entered(once_job([=, env_p0_1_3_3 = std::move(env_p0_1_3_3)]() {
            return ({
                auto q_pe = p0;
                (prism_rtl::more(prism_rtl::rc(ToPat(env_p0_1_3_3, q_pe))));
            });
        }));
        });
    })));
    })), [=](Array<Pat> each_6436) { return prism_rtl::finished(Pat(Pat::PtCon{Text::lit("tuple"), each_6436})); });
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PArray>(_m) ? ({
        auto&& ps_pf = prism_rtl::as<crate::syntax::PatternKind::PArray>(_m).a0;
        ({
        auto env_p0_1 = env_p0;
        auto ps_pf_2 = ps_pf;
        call_value(each_job(ps_pf_2, ({
        auto env_p0_1_3 = env_p0_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(crate::syntax::Pattern_)>>(prism_rtl::rc([=, env_p0_1_3 = std::move(env_p0_1_3)](crate::syntax::Pattern_ p0) {
        return ({
            auto env_p0_1_3_3 = env_p0_1_3;
            entered(once_job([=, env_p0_1_3_3 = std::move(env_p0_1_3_3)]() {
            return ({
                auto q_pg = p0;
                (prism_rtl::more(prism_rtl::rc(ToPat(env_p0_1_3_3, q_pg))));
            });
        }));
        });
    })));
    })), [=](Array<Pat> each_6501) { return prism_rtl::finished(Pat(Pat::PtCon{prism_rtl::cat("len", len(ps_pf_2)), each_6501})); });
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m) ? ({
        auto&& q_ph = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ToPat(env_p0, prism_rtl::deref(prism_rtl::deref(q_ph)))));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PFamily>(_m) ? ({
        auto&& q_pi = prism_rtl::as<crate::syntax::PatternKind::PFamily>(_m).a0;
        prism_rtl::finished(Pat(Pat::PtFam{crate::check::env::dotted(q_pi->path_)}));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ToPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Pat> start_to_pat(crate::check::expr::Env env_p0, crate::syntax::Pattern_ p_p1) {
    return prism_rtl::make_rc<ToPat>(env_p0, p_p1);
}


/// LitText: fn Literal -> Text
Text lit_text(const crate::syntax::Literal& l_p0) {
    auto&& _m = l_p0.kind;
    if (prism_rtl::is<crate::syntax::LitKind::LInt>(_m)) {
        auto&& d_p1 = prism_rtl::as<crate::syntax::LitKind::LInt>(_m).a0;
        return d_p1;
    }
    if (prism_rtl::is<crate::syntax::LitKind::LFloat>(_m)) {
        auto&& d_p2 = prism_rtl::as<crate::syntax::LitKind::LFloat>(_m).a0;
        return d_p2;
    }
    if (prism_rtl::is<crate::syntax::LitKind::LChar>(_m)) {
        auto&& c_p3 = prism_rtl::as<crate::syntax::LitKind::LChar>(_m).a0;
        return prism_rtl::cat("\'", c_p3, "\'");
    }
    if (prism_rtl::is<crate::syntax::LitKind::LText>(_m)) {
        auto&& segs_p4 = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
        return concat(each(segs_p4, lit_seg_text));
    }
    if (prism_rtl::is<crate::syntax::LitKind::LDuration>(_m)) {
        auto&& d_p5 = prism_rtl::as<crate::syntax::LitKind::LDuration>(_m).a0;
        auto&& u_p6 = prism_rtl::as<crate::syntax::LitKind::LDuration>(_m).a1;
        return prism_rtl::cat(d_p5, u_p6);
    }
    if (prism_rtl::is<crate::syntax::LitKind::LRegex>(_m)) {
        auto&& r_p7 = prism_rtl::as<crate::syntax::LitKind::LRegex>(_m).a0;
        return prism_rtl::cat("%/", prism_rtl::deref(r_p7).pattern, "/");
    }
    prism_rtl::unreachable("no arm matched");
}


/// LitSegText: fn TextSeg -> Text
Text lit_seg_text(const crate::syntax::TextSeg& text_seg0) {
    if (prism_rtl::is<crate::syntax::TextSeg::SegPlain>(text_seg0)) {
        auto&& t_p0 = prism_rtl::as<crate::syntax::TextSeg::SegPlain>(text_seg0).a0;
        return t_p0;
    }
    {
        return Text::lit("{}");
    }
}


/// CtorKey: fn Env, SName -> Text
Text ctor_key(const crate::check::expr::Env& env_p0, const crate::syntax::SName& n_p1) {
    auto&& _qk_o2 = crate::check::env::names::resolve_value(env_p0.g, env_p0.home, n_p1);
    auto&& qk_o2 = std::get<0>(_qk_o2);
    return or_(qk_o2, crate::check::env::sname_key(n_p1));
}


/// RecordPat: unbounded fn Env, SName, [FieldPat] -> Pat
Pat record_pat(const crate::check::expr::Env& env_p0, const crate::syntax::SName& n_p1, const Array<crate::syntax::FieldPat>& fields_p2) {
    auto name_p3 = crate::check::env::dotted(n_p1.path_);
    auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0.g).tags, name_p3);
    if (prism_rtl::is_some(_m)) {
        auto&& tg_p4 = prism_rtl::some_of(_m);
        auto names_p5 = each(prism_rtl::deref(tg_p4).fields, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
            auto&& f_p6 = std::get<0>(_p0);
            return f_p6;
        });
        return Pat(Pat::PtCon{prism_rtl::cat("tag:", name_p3), run_to_end(each_job(names_p5, ({
            auto env_p0_1 = env_p0;
            auto fields_p2_2 = fields_p2;
            auto names_p5_3 = names_p5;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(Text)>>(prism_rtl::rc([=, env_p0_1 = std::move(env_p0_1), fields_p2_2 = std::move(fields_p2_2), names_p5_3 = std::move(names_p5_3)](Text p0) {
            return ({
                auto env_p0_1_4 = env_p0_1;
                auto fields_p2_2_4 = fields_p2_2;
                auto names_p5_3_4 = names_p5_3;
                entered(once_job([=, env_p0_1_4 = std::move(env_p0_1_4), fields_p2_2_4 = std::move(fields_p2_2_4), names_p5_3_4 = std::move(names_p5_3_4)]() {
                return ({
                    auto f_p7 = p0;
                    (prism_rtl::more(prism_rtl::rc(FieldPatFor(env_p0_1_4, fields_p2_2_4, names_p5_3_4, f_p7))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is_none(_m)) {
        auto qk_p8 = ctor_key(env_p0, n_p1);
        auto fnames_p9 = crate::check::types::bare_name(qk_p8) == Text::lit("Error")
            ? Array(std::vector{Text::lit("kind"), Text::lit("message")})
            : prism_rtl::deref(or_(crate::prelude::get(prism_rtl::deref(env_p0.g).ctors, qk_p8), dummy_ctor())).fields;
        auto pkey_pa = crate::check::types::bare_name(qk_p8) == Text::lit("Error")
            ? Text::lit("Error")
            : qk_p8;
        return Pat(Pat::PtCon{pkey_pa, run_to_end(each_job(fnames_p9, ({
            auto env_p0_1 = env_p0;
            auto fields_p2_2 = fields_p2;
            auto fnames_p9_3 = fnames_p9;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(Text)>>(prism_rtl::rc([=, env_p0_1 = std::move(env_p0_1), fields_p2_2 = std::move(fields_p2_2), fnames_p9_3 = std::move(fnames_p9_3)](Text p0) {
            return ({
                auto env_p0_1_4 = env_p0_1;
                auto fields_p2_2_4 = fields_p2_2;
                auto fnames_p9_3_4 = fnames_p9_3;
                entered(once_job([=, env_p0_1_4 = std::move(env_p0_1_4), fields_p2_2_4 = std::move(fields_p2_2_4), fnames_p9_3_4 = std::move(fnames_p9_3_4)]() {
                return ({
                    auto f_pb = p0;
                    (prism_rtl::more(prism_rtl::rc(FieldPatFor(env_p0_1_4, fields_p2_2_4, fnames_p9_3_4, f_pb))));
                });
            }));
            });
        })));
        })))});
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Pat> RecordPat::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& n_p1 = this->n_p1;
    const auto& fields_p2 = this->fields_p2;
    auto name_p3 = crate::check::env::dotted(n_p1->path_);
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env_p0).g).tags, name_p3);
        prism_rtl::is_some(_m) ? ({
        auto&& tg_p4 = prism_rtl::some_of(_m);
        ({
        auto names_p5 = each(prism_rtl::deref(tg_p4).fields, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
            auto&& f_p6 = std::get<0>(_p0);
            return f_p6;
        });
        auto env_p0_1 = env_p0;
        auto fields_p2_2 = fields_p2;
        call_value(each_job(names_p5, ({
        auto env_p0_1_3 = env_p0_1;
        auto fields_p2_2_3 = fields_p2_2;
        auto names_p5_3 = names_p5;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(Text)>>(prism_rtl::rc([=, env_p0_1_3 = std::move(env_p0_1_3), fields_p2_2_3 = std::move(fields_p2_2_3), names_p5_3 = std::move(names_p5_3)](Text p0) {
        return ({
            auto env_p0_1_3_4 = env_p0_1_3;
            auto fields_p2_2_3_4 = fields_p2_2_3;
            auto names_p5_3_4 = names_p5_3;
            entered(once_job([=, env_p0_1_3_4 = std::move(env_p0_1_3_4), fields_p2_2_3_4 = std::move(fields_p2_2_3_4), names_p5_3_4 = std::move(names_p5_3_4)]() {
            return ({
                auto f_p7 = p0;
                (prism_rtl::more(prism_rtl::rc(FieldPatFor(env_p0_1_3_4, fields_p2_2_3_4, names_p5_3_4, f_p7))));
            });
        }));
        });
    })));
    })), [=](Array<Pat> each_7371) { return prism_rtl::finished(Pat(Pat::PtCon{prism_rtl::cat("tag:", name_p3), each_7371})); });
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto qk_p8 = ctor_key(env_p0, n_p1);
        auto fnames_p9 = crate::check::types::bare_name(qk_p8) == Text::lit("Error")
            ? Array(std::vector{Text::lit("kind"), Text::lit("message")})
            : prism_rtl::deref(or_(crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env_p0).g).ctors, qk_p8), dummy_ctor())).fields;
        auto pkey_pa = crate::check::types::bare_name(qk_p8) == Text::lit("Error")
            ? Text::lit("Error")
            : qk_p8;
        auto env_p0_1 = env_p0;
        auto fields_p2_2 = fields_p2;
        call_value(each_job(fnames_p9, ({
        auto env_p0_1_3 = env_p0_1;
        auto fields_p2_2_3 = fields_p2_2;
        auto fnames_p9_3 = fnames_p9;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(Text)>>(prism_rtl::rc([=, env_p0_1_3 = std::move(env_p0_1_3), fields_p2_2_3 = std::move(fields_p2_2_3), fnames_p9_3 = std::move(fnames_p9_3)](Text p0) {
        return ({
            auto env_p0_1_3_4 = env_p0_1_3;
            auto fields_p2_2_3_4 = fields_p2_2_3;
            auto fnames_p9_3_4 = fnames_p9_3;
            entered(once_job([=, env_p0_1_3_4 = std::move(env_p0_1_3_4), fields_p2_2_3_4 = std::move(fields_p2_2_3_4), fnames_p9_3_4 = std::move(fnames_p9_3_4)]() {
            return ({
                auto f_pb = p0;
                (prism_rtl::more(prism_rtl::rc(FieldPatFor(env_p0_1_3_4, fields_p2_2_3_4, fnames_p9_3_4, f_pb))));
            });
        }));
        });
    })));
    })), [=, pkey_pa = std::move(pkey_pa)](Array<Pat> each_7687) { return prism_rtl::finished(Pat(Pat::PtCon{pkey_pa, each_7687})); });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start RecordPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Pat> start_record_pat(crate::check::expr::Env env_p0, crate::syntax::SName n_p1, Array<crate::syntax::FieldPat> fields_p2) {
    return prism_rtl::make_rc<RecordPat>(env_p0, n_p1, fields_p2);
}


/// let dummyCtor
crate::check::env::CtorInfo dummy_ctor() {
    return crate::check::env::CtorInfo{.name = Text::lit(""), .owner = Text::lit(""), .params = Array<Text>{}, .args = Array<crate::check::types::Ty>{}, .fields = Array<Text>{}, .ty = crate::check::types::Ty(crate::check::types::Ty::TyErr{}), .index = Nat(0u)};
}


/// FieldPatFor: unbounded fn Env, [FieldPat], [Text], Text -> Pat
Pat field_pat_for(const crate::check::expr::Env& env_p0, const Array<crate::syntax::FieldPat>& fields_p1, const Array<Text>& names_p2, const Text& f_p3) {
    return run_to_end(fold_job(crate::check::errors::range0(len(fields_p1)), Pat(Pat::PtAny{}), ({
        auto fields_p1_1 = fields_p1;
        auto names_p2_2 = names_p2;
        auto f_p3_3 = f_p3;
        auto env_p0_4 = env_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(std::tuple<Pat, Nat>)>>(prism_rtl::rc([=, fields_p1_1 = std::move(fields_p1_1), names_p2_2 = std::move(names_p2_2), f_p3_3 = std::move(f_p3_3), env_p0_4 = std::move(env_p0_4)](std::tuple<Pat, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto fields_p1_1_5 = fields_p1_1;
            auto names_p2_2_5 = names_p2_2;
            auto f_p3_3_5 = f_p3_3;
            auto env_p0_4_5 = env_p0_4;
            entered(once_job([=, fields_p1_1_5 = std::move(fields_p1_1_5), names_p2_2_5 = std::move(names_p2_2_5), f_p3_3_5 = std::move(f_p3_3_5), env_p0_4_5 = std::move(env_p0_4_5)]() {
            return ({
                auto acc_p4 = p0;
                auto i_p5 = p1;
                ({
                auto&& _m = index(fields_p1_1_5, i_p5);
                prism_rtl::is_some(_m) ? ({
                auto&& fp_p6 = prism_rtl::some_of(_m);
                crate::check::expr::patterns::field_pat_name(fp_p6, names_p2_2_5, i_p5) == f_p3_3_5
                ? prism_rtl::more(prism_rtl::rc(ToPat(env_p0_4_5, prism_rtl::deref(fp_p6).pattern)))
                : prism_rtl::finished(acc_p4);
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(acc_p4)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Pat> FieldPatFor::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& fields_p1 = this->fields_p1;
    const auto& names_p2 = this->names_p2;
    const auto& f_p3 = this->f_p3;
    return fold_job(crate::check::errors::range0(len(fields_p1)), Pat(Pat::PtAny{}), ({
        auto fields_p1_1 = fields_p1;
        auto names_p2_2 = names_p2;
        auto f_p3_3 = f_p3;
        auto env_p0_4 = env_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(std::tuple<Pat, Nat>)>>(prism_rtl::rc([=, fields_p1_1 = std::move(fields_p1_1), names_p2_2 = std::move(names_p2_2), f_p3_3 = std::move(f_p3_3), env_p0_4 = std::move(env_p0_4)](std::tuple<Pat, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto fields_p1_1_5 = fields_p1_1;
            auto names_p2_2_5 = names_p2_2;
            auto f_p3_3_5 = f_p3_3;
            auto env_p0_4_5 = env_p0_4;
            entered(once_job([=, fields_p1_1_5 = std::move(fields_p1_1_5), names_p2_2_5 = std::move(names_p2_2_5), f_p3_3_5 = std::move(f_p3_3_5), env_p0_4_5 = std::move(env_p0_4_5)]() {
            return ({
                auto acc_p4 = p0;
                auto i_p5 = p1;
                ({
                auto&& _m = index(fields_p1_1_5, i_p5);
                prism_rtl::is_some(_m) ? ({
                auto&& fp_p6 = prism_rtl::some_of(_m);
                crate::check::expr::patterns::field_pat_name(fp_p6, names_p2_2_5, i_p5) == f_p3_3_5
                ? prism_rtl::more(prism_rtl::rc(ToPat(env_p0_4_5, prism_rtl::deref(fp_p6).pattern)))
                : prism_rtl::finished(acc_p4);
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(acc_p4)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start FieldPatFor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Pat> start_field_pat_for(crate::check::expr::Env env_p0, Array<crate::syntax::FieldPat> fields_p1, Array<Text> names_p2, Text f_p3) {
    return prism_rtl::make_rc<FieldPatFor>(env_p0, fields_p1, names_p2, f_p3);
}


/// Useful: unbounded fn Env, St, [ [Pat] ], [Pat], [Ty] -> Bool
bool useful(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Array<Array<Pat>>& rows_p2, const Array<Pat>& q_p3, const Array<crate::check::types::Ty>& tys_p4) {
    auto&& _m = index(q_p3, Nat(0u));
    if (prism_rtl::is_none(_m)) {
        return len(rows_p2) == Nat(0u);
    }
    if (prism_rtl::is_some(_m)) {
        auto&& q1_p5 = prism_rtl::some_of(_m);
        auto t1_p6 = or_(index(tys_p4, Nat(0u)), crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
        auto rest_p7 = drop(tys_p4, Nat(1u));
        if (prism_rtl::is<Pat::PtCon>(q1_p5)) {
            auto&& c_p8 = prism_rtl::as<Pat::PtCon>(q1_p5).a0;
            auto&& args_p9 = prism_rtl::as<Pat::PtCon>(q1_p5).a1;
            auto ctor_pa = ctor_named(env_p0, st_p1, t1_p6, c_p8, len(args_p9));
            return useful(env_p0, st_p1, specialize(rows_p2, ctor_pa), append(args_p9, drop(q_p3, Nat(1u))), append(ctor_pa->args, rest_p7));
        }
        if (prism_rtl::is<Pat::PtLit>(q1_p5)) {
            auto&& l_pb = prism_rtl::as<Pat::PtLit>(q1_p5).a0;
            return useful(env_p0, st_p1, specialize_lit(rows_p2, l_pb), drop(q_p3, Nat(1u)), rest_p7);
        }
        if (prism_rtl::is<Pat::PtFam>(q1_p5)) {
            auto&& f_pc = prism_rtl::as<Pat::PtFam>(q1_p5).a0;
            auto&& _m = ctors_of(env_p0, st_p1, t1_p6);
            if (prism_rtl::is_some(_m)) {
                auto&& cs_pd = prism_rtl::some_of(_m);
                return run_to_end(fold_job(filter(cs_pd, [&](const Ctor& c_pe) { return ctor_family(c_pe) == f_pc; }), false, ({
                    auto env_p0_1 = env_p0;
                    auto st_p1_2 = st_p1;
                    auto rows_p2_3 = rows_p2;
                    auto q_p3_4 = q_p3;
                    auto rest_p7_5 = rest_p7;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Ctor>)>>(prism_rtl::rc([=, env_p0_1 = std::move(env_p0_1), st_p1_2 = std::move(st_p1_2), rows_p2_3 = std::move(rows_p2_3), q_p3_4 = std::move(q_p3_4), rest_p7_5 = std::move(rest_p7_5)](std::tuple<bool, Ctor> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto env_p0_1_6 = env_p0_1;
                        auto st_p1_2_6 = st_p1_2;
                        auto rows_p2_3_6 = rows_p2_3;
                        auto q_p3_4_6 = q_p3_4;
                        auto rest_p7_5_6 = rest_p7_5;
                        entered(once_job([=, env_p0_1_6 = std::move(env_p0_1_6), st_p1_2_6 = std::move(st_p1_2_6), rows_p2_3_6 = std::move(rows_p2_3_6), q_p3_4_6 = std::move(q_p3_4_6), rest_p7_5_6 = std::move(rest_p7_5_6)]() {
                        return ({
                            auto seen_pf = p0;
                            auto c_pg = p1;
                            (prism_rtl::finished(std::move(seen_pf) || useful(env_p0_1_6, st_p1_2_6, specialize(rows_p2_3_6, c_pg), append(wilds(prism_rtl::deref(c_pg).arity), drop(q_p3_4_6, Nat(1u))), append(c_pg->args, rest_p7_5_6))));
                        });
                    }));
                    });
                })));
                })));
            }
            if (prism_rtl::is_none(_m)) {
                return useful(env_p0, st_p1, default_rows(rows_p2), drop(q_p3, Nat(1u)), rest_p7);
            }
            prism_rtl::unreachable("no arm matched");
        }
        if (prism_rtl::is<Pat::PtAny>(q1_p5)) {
            auto heads_ph = head_names(rows_p2);
            auto&& _m = ctors_of(env_p0, st_p1, t1_p6);
            if (prism_rtl::is_some(_m)) {
                auto&& cs_pi = prism_rtl::some_of(_m);
                return complete(cs_pi, heads_ph, rows_p2)
                    ? run_to_end(fold_job(cs_pi, false, ({
                    auto env_p0_1 = env_p0;
                    auto st_p1_2 = st_p1;
                    auto rows_p2_3 = rows_p2;
                    auto q_p3_4 = q_p3;
                    auto rest_p7_5 = rest_p7;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Ctor>)>>(prism_rtl::rc([=, env_p0_1 = std::move(env_p0_1), st_p1_2 = std::move(st_p1_2), rows_p2_3 = std::move(rows_p2_3), q_p3_4 = std::move(q_p3_4), rest_p7_5 = std::move(rest_p7_5)](std::tuple<bool, Ctor> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto env_p0_1_6 = env_p0_1;
                        auto st_p1_2_6 = st_p1_2;
                        auto rows_p2_3_6 = rows_p2_3;
                        auto q_p3_4_6 = q_p3_4;
                        auto rest_p7_5_6 = rest_p7_5;
                        entered(once_job([=, env_p0_1_6 = std::move(env_p0_1_6), st_p1_2_6 = std::move(st_p1_2_6), rows_p2_3_6 = std::move(rows_p2_3_6), q_p3_4_6 = std::move(q_p3_4_6), rest_p7_5_6 = std::move(rest_p7_5_6)]() {
                        return ({
                            auto seen_pj = p0;
                            auto c_pk = p1;
                            (prism_rtl::finished(std::move(seen_pj) || useful(env_p0_1_6, st_p1_2_6, specialize(rows_p2_3_6, c_pk), append(wilds(prism_rtl::deref(c_pk).arity), drop(q_p3_4_6, Nat(1u))), append(c_pk->args, rest_p7_5_6))));
                        });
                    }));
                    });
                })));
                })))
                    : useful(env_p0, st_p1, default_rows(rows_p2), drop(q_p3, Nat(1u)), rest_p7);
            }
            if (prism_rtl::is_none(_m)) {
                return useful(env_p0, st_p1, default_rows(rows_p2), drop(q_p3, Nat(1u)), rest_p7);
            }
            prism_rtl::unreachable("no arm matched");
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> Useful::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& rows_p2 = this->rows_p2;
    const auto& q_p3 = this->q_p3;
    const auto& tys_p4 = this->tys_p4;
    return ({
        auto&& _m = index(q_p3, Nat(0u));
        prism_rtl::is_none(_m) ? prism_rtl::finished(len(rows_p2) == Nat(0u))
        : prism_rtl::is_some(_m) ? ({
        auto&& q1_p5 = prism_rtl::some_of(_m);
        ({
        auto t1_p6 = or_(index(tys_p4, Nat(0u)), crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
        auto rest_p7 = drop(tys_p4, Nat(1u));
        ({
        prism_rtl::is<Pat::PtCon>(q1_p5) ? ({
        auto&& c_p8 = prism_rtl::as<Pat::PtCon>(q1_p5).a0;
        auto&& args_p9 = prism_rtl::as<Pat::PtCon>(q1_p5).a1;
        ({
        auto args_p9_1 = args_p9;
        auto c_p8_2 = c_p8;
        auto env_p0_3 = env_p0;
        auto q_p3_4 = q_p3;
        auto rows_p2_5 = rows_p2;
        auto st_p1_6 = st_p1;
        call_then(start_ctor_named(env_p0_3, st_p1_6, t1_p6, c_p8_2, len(args_p9_1)), [=, q_p3_4 = std::move(q_p3_4), rows_p2_5 = std::move(rows_p2_5)](Ctor ctor_named_8483) {
        return ({
            auto ctor_pa = ctor_named_8483;
            (prism_rtl::more(prism_rtl::rc(Useful(env_p0_3, st_p1_6, specialize(rows_p2_5, ctor_pa), append(args_p9_1, drop(q_p3_4, Nat(1u))), append(ctor_pa->args, rest_p7)))));
        });
    });
    });
    })
        : prism_rtl::is<Pat::PtLit>(q1_p5) ? ({
        auto&& l_pb = prism_rtl::as<Pat::PtLit>(q1_p5).a0;
        prism_rtl::more(prism_rtl::rc(Useful(env_p0, st_p1, specialize_lit(rows_p2, l_pb), drop(q_p3, Nat(1u)), rest_p7)));
    })
        : prism_rtl::is<Pat::PtFam>(q1_p5) ? ({
        auto&& f_pc = prism_rtl::as<Pat::PtFam>(q1_p5).a0;
        ({
        auto env_p0_1 = env_p0;
        auto f_pc_2 = f_pc;
        auto q_p3_3 = q_p3;
        auto rows_p2_4 = rows_p2;
        auto st_p1_5 = st_p1;
        call_then(start_ctors_of(env_p0_1, st_p1_5, t1_p6), [=, f_pc_2 = std::move(f_pc_2), q_p3_3 = std::move(q_p3_3), rows_p2_4 = std::move(rows_p2_4)](std::optional<Array<Ctor>> ctors_of_8737) {
        return ({
            prism_rtl::is_some(ctors_of_8737) ? ({
            auto&& cs_pd = prism_rtl::some_of(ctors_of_8737);
            fold_job(filter(cs_pd, [&](const Ctor& c_pe) { return ctor_family(c_pe) == f_pc_2; }), false, ({
            auto env_p0_1_6 = env_p0_1;
            auto st_p1_5_6 = st_p1_5;
            auto rows_p2_4_6 = rows_p2_4;
            auto q_p3_3_6 = q_p3_3;
            auto rest_p7_6 = rest_p7;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Ctor>)>>(prism_rtl::rc([=, env_p0_1_6 = std::move(env_p0_1_6), st_p1_5_6 = std::move(st_p1_5_6), rows_p2_4_6 = std::move(rows_p2_4_6), q_p3_3_6 = std::move(q_p3_3_6), rest_p7_6 = std::move(rest_p7_6)](std::tuple<bool, Ctor> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env_p0_1_6_7 = env_p0_1_6;
                auto st_p1_5_6_7 = st_p1_5_6;
                auto rows_p2_4_6_7 = rows_p2_4_6;
                auto q_p3_3_6_7 = q_p3_3_6;
                auto rest_p7_6_7 = rest_p7_6;
                entered(once_job([=, env_p0_1_6_7 = std::move(env_p0_1_6_7), st_p1_5_6_7 = std::move(st_p1_5_6_7), rows_p2_4_6_7 = std::move(rows_p2_4_6_7), q_p3_3_6_7 = std::move(q_p3_3_6_7), rest_p7_6_7 = std::move(rest_p7_6_7)]() {
                return ({
                    auto seen_pf = p0;
                    auto c_pg = p1;
                    (prism_rtl::finished(std::move(seen_pf) || useful(env_p0_1_6_7, st_p1_5_6_7, specialize(rows_p2_4_6_7, c_pg), append(wilds(prism_rtl::deref(c_pg).arity), drop(q_p3_3_6_7, Nat(1u))), append(c_pg->args, rest_p7_6_7))));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is_none(ctors_of_8737) ? prism_rtl::more(prism_rtl::rc(Useful(env_p0_1, st_p1_5, default_rows(rows_p2_4), drop(q_p3_3, Nat(1u)), rest_p7)))
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    });
    })
        : prism_rtl::is<Pat::PtAny>(q1_p5) ? ({
        auto heads_ph = head_names(rows_p2);
        auto env_p0_1 = env_p0;
        auto q_p3_2 = q_p3;
        auto rows_p2_3 = rows_p2;
        auto st_p1_4 = st_p1;
        call_then(start_ctors_of(env_p0_1, st_p1_4, t1_p6), [=, heads_ph = std::move(heads_ph), q_p3_2 = std::move(q_p3_2), rows_p2_3 = std::move(rows_p2_3)](std::optional<Array<Ctor>> ctors_of_9109) {
        return ({
            prism_rtl::is_some(ctors_of_9109) ? ({
            auto&& cs_pi = prism_rtl::some_of(ctors_of_9109);
            complete(cs_pi, heads_ph, rows_p2_3)
            ? fold_job(cs_pi, false, ({
            auto env_p0_1_5 = env_p0_1;
            auto st_p1_4_5 = st_p1_4;
            auto rows_p2_3_5 = rows_p2_3;
            auto q_p3_2_5 = q_p3_2;
            auto rest_p7_5 = rest_p7;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Ctor>)>>(prism_rtl::rc([=, env_p0_1_5 = std::move(env_p0_1_5), st_p1_4_5 = std::move(st_p1_4_5), rows_p2_3_5 = std::move(rows_p2_3_5), q_p3_2_5 = std::move(q_p3_2_5), rest_p7_5 = std::move(rest_p7_5)](std::tuple<bool, Ctor> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env_p0_1_5_6 = env_p0_1_5;
                auto st_p1_4_5_6 = st_p1_4_5;
                auto rows_p2_3_5_6 = rows_p2_3_5;
                auto q_p3_2_5_6 = q_p3_2_5;
                auto rest_p7_5_6 = rest_p7_5;
                entered(once_job([=, env_p0_1_5_6 = std::move(env_p0_1_5_6), st_p1_4_5_6 = std::move(st_p1_4_5_6), rows_p2_3_5_6 = std::move(rows_p2_3_5_6), q_p3_2_5_6 = std::move(q_p3_2_5_6), rest_p7_5_6 = std::move(rest_p7_5_6)]() {
                return ({
                    auto seen_pj = p0;
                    auto c_pk = p1;
                    (prism_rtl::finished(std::move(seen_pj) || useful(env_p0_1_5_6, st_p1_4_5_6, specialize(rows_p2_3_5_6, c_pk), append(wilds(prism_rtl::deref(c_pk).arity), drop(q_p3_2_5_6, Nat(1u))), append(c_pk->args, rest_p7_5_6))));
                });
            }));
            });
        })));
        }))->cycle()
            : prism_rtl::more(prism_rtl::rc(Useful(env_p0_1, st_p1_4, default_rows(rows_p2_3), drop(q_p3_2, Nat(1u)), rest_p7)));
        })
            : prism_rtl::is_none(ctors_of_9109) ? prism_rtl::more(prism_rtl::rc(Useful(env_p0_1, st_p1_4, default_rows(rows_p2_3), drop(q_p3_2, Nat(1u)), rest_p7)))
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start Useful, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_useful(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<Array<Pat>> rows_p2, Array<Pat> q_p3, Array<crate::check::types::Ty> tys_p4) {
    return prism_rtl::make_rc<Useful>(env_p0, st_p1, rows_p2, q_p3, tys_p4);
}


/// CtorFamily: fn Ctor -> Text
Text ctor_family(const Ctor& c_p0) {
    return crate::syntax::lexer::chars::has_prefix(c_p0.name, Text::lit("tag:"))
        ? crate::check::env::dotted(crate::syntax::lexer::chars::pop(split_on(crate::syntax::lexer::chars::drop_prefix(c_p0.name, Text::lit("tag:")), Text::lit("."))))
        : Text::lit("");
}


/// Wilds: fn Nat -> [Pat]
Array<Pat> wilds(const Nat& n_p0) {
    return each(crate::check::errors::range0(n_p0), [&](const Nat& _p0) { return Pat(Pat::PtAny{}); });
}


/// CtorNamed: unbounded fn Env, St, Ty, Text, Nat -> Ctor
Ctor ctor_named(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::check::types::Ty& t_p2, const Text& c_p3, const Nat& arity_p4) {
    auto&& _m = ctors_of(env_p0, st_p1, t_p2);
    if (prism_rtl::is_some(_m)) {
        auto&& cs_p5 = prism_rtl::some_of(_m);
        auto&& _m = find_ctor(cs_p5, c_p3);
        if (prism_rtl::is_some(_m)) {
            auto&& found_p6 = prism_rtl::some_of(_m);
            return found_p6;
        }
        if (prism_rtl::is_none(_m)) {
            return Ctor{.name = c_p3, .arity = arity_p4, .args = each(crate::check::errors::range0(arity_p4), [&](const Nat& _p0) { return crate::check::types::Ty(crate::check::types::Ty::TyErr{}); }), .shown = c_p3};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_none(_m)) {
        return Ctor{.name = c_p3, .arity = arity_p4, .args = each(crate::check::errors::range0(arity_p4), [&](const Nat& _p0) { return crate::check::types::Ty(crate::check::types::Ty::TyErr{}); }), .shown = c_p3};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Ctor> CtorNamed::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& t_p2 = this->t_p2;
    const auto& c_p3 = this->c_p3;
    const auto& arity_p4 = this->arity_p4;
    auto arity_p4_1 = arity_p4;
    auto c_p3_2 = c_p3;
    auto env_p0_3 = env_p0;
    auto st_p1_4 = st_p1;
    auto t_p2_5 = t_p2;
    return call_then(start_ctors_of(env_p0_3, st_p1_4, t_p2_5), [=](std::optional<Array<Ctor>> ctors_of_9906) {
        return ({
            prism_rtl::is_some(ctors_of_9906) ? ({
            auto&& cs_p5 = prism_rtl::some_of(ctors_of_9906);
            ({
            auto&& _m = find_ctor(cs_p5, c_p3_2);
            prism_rtl::is_some(_m) ? ({
            auto&& found_p6 = prism_rtl::some_of(_m);
            prism_rtl::finished(found_p6);
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(Ctor{.name = c_p3_2, .arity = arity_p4_1, .args = each(crate::check::errors::range0(arity_p4_1), [&](const Nat& _p0) { return crate::check::types::Ty(crate::check::types::Ty::TyErr{}); }), .shown = c_p3_2})
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::is_none(ctors_of_9906) ? prism_rtl::finished(Ctor{.name = c_p3_2, .arity = arity_p4_1, .args = each(crate::check::errors::range0(arity_p4_1), [&](const Nat& _p0) { return crate::check::types::Ty(crate::check::types::Ty::TyErr{}); }), .shown = c_p3_2})
            : throw prism_rtl::Panic("no arm matched");
        });
    });
}


/// `Start CtorNamed, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ctor> start_ctor_named(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::types::Ty t_p2, Text c_p3, Nat arity_p4) {
    return prism_rtl::make_rc<CtorNamed>(env_p0, st_p1, t_p2, c_p3, arity_p4);
}


/// ?FindCtor: fn [Ctor], Text -> ?Ctor
std::optional<Ctor> find_ctor(const Array<Ctor>& cs_p0, const Text& c_p1) {
    return fold(cs_p0, std::optional<Ctor>{}, [&](const std::optional<Ctor>& found_o2, const Ctor& x_p3) {
        return ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Ctor>> _v;
            if (prism_rtl::is_some(found_o2)) {
                auto&& f_p4 = prism_rtl::some_of(found_o2);
                _v.set(std::optional(f_p4));
                goto _done;
            }
            if (prism_rtl::is_none(found_o2)) {
                _v.set((prism_rtl::deref(x_p3).name == c_p1) || (crate::check::types::bare_name(prism_rtl::deref(x_p3).name) == crate::check::types::bare_name(c_p1))
                    ? std::optional(x_p3)
                    : std::optional<Ctor>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// Specialize: fn [ [Pat] ], Ctor -> [ [Pat] ]
Array<Array<Pat>> specialize(const Array<Array<Pat>>& rows_p0, const Ctor& c_p1) {
    return fold(rows_p0, Array<Array<Pat>>{}, [&](const Array<Array<Pat>>& acc_p2, const Array<Pat>& prow_p3) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Array<Pat>>> _v;
            auto&& _m = index(prow_p3, Nat(0u));
            if (prism_rtl::is_some(_m) && prism_rtl::is<Pat::PtCon>(prism_rtl::some_of(_m))) {
                auto&& d_p4 = prism_rtl::as<Pat::PtCon>(prism_rtl::some_of(_m)).a0;
                auto&& args_p5 = prism_rtl::as<Pat::PtCon>(prism_rtl::some_of(_m)).a1;
                _v.set((d_p4 == c_p1.name) || (crate::check::types::bare_name(d_p4) == crate::check::types::bare_name(c_p1.name))
                    ? crate::prelude::push(acc_p2, append(pad(args_p5, c_p1.arity), drop(prow_p3, Nat(1u))))
                    : acc_p2);
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<Pat::PtAny>(prism_rtl::some_of(_m))) {
                _v.set(crate::prelude::push(acc_p2, append(wilds(c_p1.arity), drop(prow_p3, Nat(1u)))));
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<Pat::PtFam>(prism_rtl::some_of(_m))) {
                auto&& f_p6 = prism_rtl::as<Pat::PtFam>(prism_rtl::some_of(_m)).a0;
                _v.set(ctor_family(c_p1) == f_p6
                    ? crate::prelude::push(acc_p2, append(wilds(c_p1.arity), drop(prow_p3, Nat(1u))))
                    : acc_p2);
                goto _done;
            }
            {
                _v.set(acc_p2);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// Pad: fn [Pat], Nat -> [Pat]
Array<Pat> pad(const Array<Pat>& args_p0, const Nat& n_p1) {
    return len(args_p0) >= n_p1
        ? take(args_p0, n_p1)
        : append(args_p0, wilds(or_(n_p1.checked_sub(len(args_p0)), Nat(0u))));
}


/// SpecializeLit: fn [ [Pat] ], Text -> [ [Pat] ]
Array<Array<Pat>> specialize_lit(const Array<Array<Pat>>& rows_p0, const Text& l_p1) {
    return fold(rows_p0, Array<Array<Pat>>{}, [&](const Array<Array<Pat>>& acc_p2, const Array<Pat>& prow_p3) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Array<Pat>>> _v;
            auto&& _m = index(prow_p3, Nat(0u));
            if (prism_rtl::is_some(_m) && prism_rtl::is<Pat::PtLit>(prism_rtl::some_of(_m))) {
                auto&& m_p4 = prism_rtl::as<Pat::PtLit>(prism_rtl::some_of(_m)).a0;
                _v.set(m_p4 == l_p1
                    ? crate::prelude::push(acc_p2, drop(prow_p3, Nat(1u)))
                    : acc_p2);
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<Pat::PtAny>(prism_rtl::some_of(_m))) {
                _v.set(crate::prelude::push(acc_p2, drop(prow_p3, Nat(1u))));
                goto _done;
            }
            {
                _v.set(acc_p2);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// DefaultRows: fn [ [Pat] ] -> [ [Pat] ]
Array<Array<Pat>> default_rows(const Array<Array<Pat>>& rows_p0) {
    return fold(rows_p0, Array<Array<Pat>>{}, [&](const Array<Array<Pat>>& acc_p1, const Array<Pat>& prow_p2) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Array<Pat>>> _v;
            auto&& _m = index(prow_p2, Nat(0u));
            if (prism_rtl::is_some(_m) && prism_rtl::is<Pat::PtAny>(prism_rtl::some_of(_m))) {
                _v.set(crate::prelude::push(acc_p1, drop(prow_p2, Nat(1u))));
                goto _done;
            }
            {
                _v.set(acc_p1);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// HeadNames: fn [ [Pat] ] -> [Text]
Array<Text> head_names(const Array<Array<Pat>>& rows_p0) {
    return fold(rows_p0, Array<Text>{}, [&](const Array<Text>& acc_p1, const Array<Pat>& prow_p2) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = index(prow_p2, Nat(0u));
            if (prism_rtl::is_some(_m) && prism_rtl::is<Pat::PtCon>(prism_rtl::some_of(_m))) {
                auto&& c_p3 = prism_rtl::as<Pat::PtCon>(prism_rtl::some_of(_m)).a0;
                _v.set(crate::check::types::add_text(acc_p1, c_p3));
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<Pat::PtFam>(prism_rtl::some_of(_m))) {
                auto&& f_p4 = prism_rtl::as<Pat::PtFam>(prism_rtl::some_of(_m)).a0;
                _v.set(crate::check::types::add_text(acc_p1, prism_rtl::cat("fam:", f_p4)));
                goto _done;
            }
            {
                _v.set(acc_p1);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// Complete: fn [Ctor], [Text], [ [Pat] ] -> Bool
bool complete(const Array<Ctor>& cs_p0, const Array<Text>& heads_p1, const Array<Array<Pat>>& rows_p2) {
    return (len(cs_p0) > Nat(0u)) && fold(cs_p0, true, [&](const bool& ok_p3, const Ctor& c_p4) { return prism_rtl::deref(ok_p3) && ((crate::check::types::has_text(heads_p1, prism_rtl::deref(c_p4).name) || crate::check::types::has_text(each(heads_p1, [&](const Text& h_p5) { return crate::check::types::bare_name(h_p5); }), crate::check::types::bare_name(prism_rtl::deref(c_p4).name))) || crate::check::types::has_text(heads_p1, prism_rtl::cat("fam:", ctor_family(c_p4)))); });
}


/// ?Witness: unbounded fn Env, St, [ [Pat] ], [Ty] -> ?[Text]
std::optional<Array<Text>> witness(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Array<Array<Pat>>& rows_p2, const Array<crate::check::types::Ty>& tys_p3) {
    auto&& _m = index(tys_p3, Nat(0u));
    if (prism_rtl::is_none(_m)) {
        return len(rows_p2) == Nat(0u)
            ? std::optional(Array<Text>{})
            : std::optional<Array<Text>>{};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& t1_p4 = prism_rtl::some_of(_m);
        auto rest_p5 = drop(tys_p3, Nat(1u));
        auto heads_p6 = head_names(rows_p2);
        auto&& _m = ctors_of(env_p0, st_p1, t1_p4);
        if (prism_rtl::is_some(_m)) {
            auto&& cs_p7 = prism_rtl::some_of(_m);
            return complete(cs_p7, heads_p6, rows_p2)
                ? run_to_end(fold_job(cs_p7, std::optional<Array<Text>>{}, ({
                auto env_p0_1 = env_p0;
                auto st_p1_2 = st_p1;
                auto rows_p2_3 = rows_p2;
                auto rest_p5_4 = rest_p5;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<Array<Text>>>(std::tuple<std::optional<Array<Text>>, Ctor>)>>(prism_rtl::rc([=, env_p0_1 = std::move(env_p0_1), st_p1_2 = std::move(st_p1_2), rows_p2_3 = std::move(rows_p2_3), rest_p5_4 = std::move(rest_p5_4)](std::tuple<std::optional<Array<Text>>, Ctor> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto env_p0_1_5 = env_p0_1;
                    auto st_p1_2_5 = st_p1_2;
                    auto rows_p2_3_5 = rows_p2_3;
                    auto rest_p5_4_5 = rest_p5_4;
                    entered(once_job([=, env_p0_1_5 = std::move(env_p0_1_5), st_p1_2_5 = std::move(st_p1_2_5), rows_p2_3_5 = std::move(rows_p2_3_5), rest_p5_4_5 = std::move(rest_p5_4_5)]() {
                    return ({
                        auto found_o8 = p0;
                        auto c_p9 = p1;
                        ({
                        prism_rtl::is_some(found_o8) ? ({
                        auto&& f_pa = prism_rtl::some_of(found_o8);
                        prism_rtl::finished(std::optional(f_pa));
                    })
                        : prism_rtl::is_none(found_o8) ? call_then(start_witness(env_p0_1_5, st_p1_2_5, specialize(rows_p2_3_5, c_p9), append(c_p9->args, rest_p5_4_5)), [=](std::optional<Array<Text>> witness_12482) {
                        return ({
                            prism_rtl::is_some(witness_12482) ? ({
                            auto&& w_pb = prism_rtl::some_of(witness_12482);
                            prism_rtl::finished(std::optional(append(Array(std::vector{show_witness(c_p9, take(w_pb, prism_rtl::deref(c_p9).arity))}), drop(w_pb, prism_rtl::deref(c_p9).arity))));
                        })
                            : prism_rtl::is_none(witness_12482) ? prism_rtl::finished(std::optional<Array<Text>>{})
                            : throw prism_rtl::Panic("no arm matched");
                        });
                    })
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                }));
                });
            })));
            })))
                : ({
                __label__ _done;
                prism_rtl::Slot<std::optional<Array<Text>>> _v;
                auto&& _m = witness(env_p0, st_p1, default_rows(rows_p2), rest_p5);
                if (prism_rtl::is_some(_m)) {
                    auto&& w_pc = prism_rtl::some_of(_m);
                    _v.set(({
                        auto missing_pd = filter(cs_p7, [&](const Ctor& c_pf) { return !(crate::check::types::has_text(heads_p6, prism_rtl::deref(c_pf).name) || crate::check::types::has_text(heads_p6, prism_rtl::cat("fam:", ctor_family(c_pf)))); });
                        auto shown_pe = ({
                            __label__ _done;
                            prism_rtl::Slot<Text> _v;
                            auto&& _m = index(missing_pd, Nat(0u));
                            if (prism_rtl::is_some(_m)) {
                                auto&& c_pg = prism_rtl::some_of(_m);
                                _v.set(prism_rtl::deref(c_pg).shown);
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(Text::lit("_"));
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        });
                        (std::optional(append(Array(std::vector{shown_pe}), w_pc)));
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::optional<Array<Text>>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        }
        if (prism_rtl::is_none(_m)) {
            auto&& _m = witness(env_p0, st_p1, default_rows(rows_p2), rest_p5);
            if (prism_rtl::is_some(_m)) {
                auto&& w_ph = prism_rtl::some_of(_m);
                return std::optional(append(Array(std::vector{Text::lit("_")}), w_ph));
            }
            if (prism_rtl::is_none(_m)) {
                return std::optional<Array<Text>>{};
            }
            prism_rtl::unreachable("no arm matched");
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::optional<Array<Text>>> Witness::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& rows_p2 = this->rows_p2;
    const auto& tys_p3 = this->tys_p3;
    return ({
        auto&& _m = index(tys_p3, Nat(0u));
        prism_rtl::is_none(_m) ? len(rows_p2) == Nat(0u)
        ? prism_rtl::finished(std::optional(Array<Text>{}))
        : prism_rtl::finished(std::optional<Array<Text>>{})
        : prism_rtl::is_some(_m) ? ({
        auto&& t1_p4 = prism_rtl::some_of(_m);
        ({
        auto rest_p5 = drop(tys_p3, Nat(1u));
        auto heads_p6 = head_names(rows_p2);
        auto env_p0_1 = env_p0;
        auto rows_p2_2 = rows_p2;
        auto st_p1_3 = st_p1;
        call_then(start_ctors_of(env_p0_1, st_p1_3, t1_p4), [=, rest_p5 = std::move(rest_p5), heads_p6 = std::move(heads_p6), rows_p2_2 = std::move(rows_p2_2)](std::optional<Array<Ctor>> ctors_of_12268) {
        return ({
            prism_rtl::is_some(ctors_of_12268) ? ({
            auto&& cs_p7 = prism_rtl::some_of(ctors_of_12268);
            complete(cs_p7, heads_p6, rows_p2_2)
            ? fold_job(cs_p7, std::optional<Array<Text>>{}, ({
            auto env_p0_1_4 = env_p0_1;
            auto st_p1_3_4 = st_p1_3;
            auto rows_p2_2_4 = rows_p2_2;
            auto rest_p5_4 = rest_p5;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<Array<Text>>>(std::tuple<std::optional<Array<Text>>, Ctor>)>>(prism_rtl::rc([=, env_p0_1_4 = std::move(env_p0_1_4), st_p1_3_4 = std::move(st_p1_3_4), rows_p2_2_4 = std::move(rows_p2_2_4), rest_p5_4 = std::move(rest_p5_4)](std::tuple<std::optional<Array<Text>>, Ctor> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env_p0_1_4_5 = env_p0_1_4;
                auto st_p1_3_4_5 = st_p1_3_4;
                auto rows_p2_2_4_5 = rows_p2_2_4;
                auto rest_p5_4_5 = rest_p5_4;
                entered(once_job([=, env_p0_1_4_5 = std::move(env_p0_1_4_5), st_p1_3_4_5 = std::move(st_p1_3_4_5), rows_p2_2_4_5 = std::move(rows_p2_2_4_5), rest_p5_4_5 = std::move(rest_p5_4_5)]() {
                return ({
                    auto found_o8 = p0;
                    auto c_p9 = p1;
                    ({
                    prism_rtl::is_some(found_o8) ? ({
                    auto&& f_pa = prism_rtl::some_of(found_o8);
                    prism_rtl::finished(std::optional(f_pa));
                })
                    : prism_rtl::is_none(found_o8) ? call_then(start_witness(env_p0_1_4_5, st_p1_3_4_5, specialize(rows_p2_2_4_5, c_p9), append(c_p9->args, rest_p5_4_5)), [=](std::optional<Array<Text>> witness_12482) {
                    return ({
                        prism_rtl::is_some(witness_12482) ? ({
                        auto&& w_pb = prism_rtl::some_of(witness_12482);
                        prism_rtl::finished(std::optional(append(Array(std::vector{show_witness(c_p9, take(w_pb, prism_rtl::deref(c_p9).arity))}), drop(w_pb, prism_rtl::deref(c_p9).arity))));
                    })
                        : prism_rtl::is_none(witness_12482) ? prism_rtl::finished(std::optional<Array<Text>>{})
                        : throw prism_rtl::Panic("no arm matched");
                    });
                })
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        })));
        }))->cycle()
            : call_then(start_witness(env_p0_1, st_p1_3, default_rows(rows_p2_2), rest_p5), [=](std::optional<Array<Text>> witness_12712) {
            return ({
                prism_rtl::is_some(witness_12712) ? ({
                auto&& w_pc = prism_rtl::some_of(witness_12712);
                ({
                auto missing_pd = filter(cs_p7, [&](const Ctor& c_pf) { return !(crate::check::types::has_text(heads_p6, prism_rtl::deref(c_pf).name) || crate::check::types::has_text(heads_p6, prism_rtl::cat("fam:", ctor_family(c_pf)))); });
                auto shown_pe = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = index(missing_pd, Nat(0u));
                    if (prism_rtl::is_some(_m)) {
                        auto&& c_pg = prism_rtl::some_of(_m);
                        _v.set(prism_rtl::deref(c_pg).shown);
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Text::lit("_"));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                (prism_rtl::finished(std::optional(append(Array(std::vector{shown_pe}), w_pc))));
            });
            })
                : prism_rtl::is_none(witness_12712) ? prism_rtl::finished(std::optional<Array<Text>>{})
                : throw prism_rtl::Panic("no arm matched");
            });
        });
        })
            : prism_rtl::is_none(ctors_of_12268) ? call_then(start_witness(env_p0_1, st_p1_3, default_rows(rows_p2_2), rest_p5), [=](std::optional<Array<Text>> witness_13138) {
            return ({
                prism_rtl::is_some(witness_13138) ? ({
                auto&& w_ph = prism_rtl::some_of(witness_13138);
                prism_rtl::finished(std::optional(append(Array(std::vector{Text::lit("_")}), w_ph)));
            })
                : prism_rtl::is_none(witness_13138) ? prism_rtl::finished(std::optional<Array<Text>>{})
                : throw prism_rtl::Panic("no arm matched");
            });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start Witness, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Array<Text>>> start_witness(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<Array<Pat>> rows_p2, Array<crate::check::types::Ty> tys_p3) {
    return prism_rtl::make_rc<Witness>(env_p0, st_p1, rows_p2, tys_p3);
}


/// ShowWitness: fn Ctor, [Text] -> Text
Text show_witness(const Ctor& c_p0, const Array<Text>& args_p1) {
    return c_p0.name == Text::lit("?")
        ? prism_rtl::cat("? ", or_(index(args_p1, Nat(0u)), Text::lit("_")))
        : c_p0.name == Text::lit("~")
        ? prism_rtl::cat("~ ", or_(index(args_p1, Nat(0u)), Text::lit("_")))
        : c_p0.name == Text::lit("tuple")
        ? prism_rtl::cat("((", crate::syntax::lexer::chars::join(args_p1, Text::lit(", ")), "))")
        : (len(args_p1) == Nat(0u)) || fold(args_p1, true, [&](const bool& ok_p2, const Text& a_p3) { return prism_rtl::deref(ok_p2) && (a_p3 == Text::lit("_")); })
        ? c_p0.shown
        : prism_rtl::cat(crate::check::types::bare_name(c_p0.name), " ", crate::syntax::lexer::chars::join(args_p1, Text::lit(", ")));
}


/// MatchCoverage: unbounded fn Env, St, Ty, [Arm], Range -> St
crate::check::types::St match_coverage(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::check::types::Ty& t_p2, const Array<crate::syntax::Arm>& arms_p3, const crate::syntax::Range& span_p4) {
    auto has_otherwise_p5 = fold(arms_p3, false, [&](const bool& seen_p7, const crate::syntax::Arm& a_p8) { return prism_rtl::deref(seen_p7) || (prism_rtl::deref(a_p8).pattern == std::optional<crate::syntax::Pattern_>{}); });
    auto tys_p6 = Array(std::vector{t_p2});
    auto [rows_pi, st2_pj] = run_to_end(fold_job(arms_p3, std::tuple{Array<Array<Pat>>{}, st_p1}, ({
        auto env_p0_1 = env_p0;
        auto tys_p6_2 = tys_p6;
        auto t_p2_3 = t_p2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Array<Pat>>, crate::check::types::St>>(std::tuple<std::tuple<Array<Array<Pat>>, crate::check::types::St>, crate::syntax::Arm>)>>(prism_rtl::rc([=, env_p0_1 = std::move(env_p0_1), tys_p6_2 = std::move(tys_p6_2), t_p2_3 = std::move(t_p2_3)](std::tuple<std::tuple<Array<Array<Pat>>, crate::check::types::St>, crate::syntax::Arm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_p0_1_4 = env_p0_1;
            auto tys_p6_2_4 = tys_p6_2;
            auto t_p2_3_4 = t_p2_3;
            entered(once_job([=, env_p0_1_4 = std::move(env_p0_1_4), tys_p6_2_4 = std::move(tys_p6_2_4), t_p2_3_4 = std::move(t_p2_3_4)]() {
            return ({
                auto [acc_p9, s_pa] = p0;
                auto arm_pb = p1;
                ({
                auto q_pc = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Pat>> _v;
                    auto&& _m = prism_rtl::deref(arm_pb).pattern;
                    if (prism_rtl::is_some(_m)) {
                        auto&& p_ph = prism_rtl::some_of(_m);
                        _v.set(Array(std::vector{to_pat(env_p0_1_4, p_ph)}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Array(std::vector{Pat(Pat::PtAny{})}));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                call_then(start_useful(env_p0_1_4, s_pa, acc_p9, q_pc, tys_p6_2_4), [=](bool useful_14224) {
                return ({
                    auto reachable_pd = useful_14224;
                    call_then(start_owns_row(env_p0_1_4, s_pa, t_p2_3_4), [=, reachable_pd = std::move(reachable_pd)](bool owns_row_14273) {
                    return ({
                        auto owns_all_pe = owns_row_14273;
                        auto s2_pf = reachable_pd
                            ? s_pa
                            : (prism_rtl::deref(arm_pb).pattern == std::optional<crate::syntax::Pattern_>{}) && (!std::move(owns_all_pe))
                            ? s_pa
                            : crate::check::types::recording::err_fix(s_pa, Text::lit("unreachable"), arm_span(arm_pb), Text::lit("this arm is never reached"), Text::lit("remove it, or put it above the arm that covers it"));
                        auto acc2_pg = prism_rtl::deref(arm_pb).guard == std::optional<crate::syntax::Expr>{}
                            ? crate::prelude::push(acc_p9, q_pc)
                            : acc_p9;
                        (prism_rtl::finished(std::tuple{acc2_pg, s2_pf}));
                    });
                });
                });
            });
            });
            });
        }));
        });
    }));
    })));
    return std::move(has_otherwise_p5)
        ? st2_pj
        : is_open_row(env_p0, st2_pj, t_p2)
        ? crate::check::types::recording::err_fix(st2_pj, Text::lit("row-not-closed"), span_p4, prism_rtl::cat("a match over `", crate::check::types::show_ty(st2_pj, t_p2), "` needs `otherwise:`"), Text::lit("add an `otherwise:` arm: the row\'s variable may hold tags this match cannot name"))
        : ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        auto&& _m = witness(env_p0, st2_pj, rows_pi, tys_p6);
        if (prism_rtl::is_some(_m)) {
            auto&& w_pk = prism_rtl::some_of(_m);
            _v.set(crate::check::types::recording::err_fix(st2_pj, Text::lit("not-exhaustive"), span_p4, prism_rtl::cat("this match misses `", crate::syntax::lexer::chars::join(w_pk, Text::lit(", ")), "`"), Text::lit("add an arm for it, or `otherwise:`")));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(st2_pj);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<crate::check::types::St> MatchCoverage::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& t_p2 = this->t_p2;
    const auto& arms_p3 = this->arms_p3;
    const auto& span_p4 = this->span_p4;
    auto has_otherwise_p5 = fold(arms_p3, false, [&](const bool& seen_p7, const crate::syntax::Arm& a_p8) { return prism_rtl::deref(seen_p7) || (prism_rtl::deref(a_p8).pattern == std::optional<crate::syntax::Pattern_>{}); });
    auto tys_p6 = Array(std::vector{t_p2});
    auto arms_p3_1 = arms_p3;
    auto env_p0_2 = env_p0;
    auto span_p4_3 = span_p4;
    auto st_p1_4 = st_p1;
    auto t_p2_5 = t_p2;
    return call_value(fold_job(arms_p3_1, std::tuple{Array<Array<Pat>>{}, st_p1_4}, ({
        auto env_p0_2_6 = env_p0_2;
        auto tys_p6_6 = tys_p6;
        auto t_p2_5_7 = t_p2_5;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Array<Pat>>, crate::check::types::St>>(std::tuple<std::tuple<Array<Array<Pat>>, crate::check::types::St>, crate::syntax::Arm>)>>(prism_rtl::rc([=, env_p0_2_6 = std::move(env_p0_2_6), tys_p6_6 = std::move(tys_p6_6), t_p2_5_7 = std::move(t_p2_5_7)](std::tuple<std::tuple<Array<Array<Pat>>, crate::check::types::St>, crate::syntax::Arm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_p0_2_6_7 = env_p0_2_6;
            auto tys_p6_6_7 = tys_p6_6;
            auto t_p2_5_7_7 = t_p2_5_7;
            entered(once_job([=, env_p0_2_6_7 = std::move(env_p0_2_6_7), tys_p6_6_7 = std::move(tys_p6_6_7), t_p2_5_7_7 = std::move(t_p2_5_7_7)]() {
            return ({
                auto [acc_p9, s_pa] = p0;
                auto arm_pb = p1;
                ({
                auto q_pc = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Pat>> _v;
                    auto&& _m = prism_rtl::deref(arm_pb).pattern;
                    if (prism_rtl::is_some(_m)) {
                        auto&& p_ph = prism_rtl::some_of(_m);
                        _v.set(Array(std::vector{to_pat(env_p0_2_6_7, p_ph)}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Array(std::vector{Pat(Pat::PtAny{})}));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                call_then(start_useful(env_p0_2_6_7, s_pa, acc_p9, q_pc, tys_p6_6_7), [=](bool useful_14224) {
                return ({
                    auto reachable_pd = useful_14224;
                    call_then(start_owns_row(env_p0_2_6_7, s_pa, t_p2_5_7_7), [=, reachable_pd = std::move(reachable_pd)](bool owns_row_14273) {
                    return ({
                        auto owns_all_pe = owns_row_14273;
                        auto s2_pf = reachable_pd
                            ? s_pa
                            : (prism_rtl::deref(arm_pb).pattern == std::optional<crate::syntax::Pattern_>{}) && (!std::move(owns_all_pe))
                            ? s_pa
                            : crate::check::types::recording::err_fix(s_pa, Text::lit("unreachable"), arm_span(arm_pb), Text::lit("this arm is never reached"), Text::lit("remove it, or put it above the arm that covers it"));
                        auto acc2_pg = prism_rtl::deref(arm_pb).guard == std::optional<crate::syntax::Expr>{}
                            ? crate::prelude::push(acc_p9, q_pc)
                            : acc_p9;
                        (prism_rtl::finished(std::tuple{acc2_pg, s2_pf}));
                    });
                });
                });
            });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<Array<Pat>>, crate::check::types::St> fold_14057) {
        return ({
            auto [rows_pi, st2_pj] = fold_14057;
            has_otherwise_p5
            ? prism_rtl::finished(st2_pj)
            : call_then(start_is_open_row(env_p0_2, st2_pj, t_p2_5), [=](bool is_open_row_14621) {
            return is_open_row_14621
                ? call_then(crate::check::types::start_show_ty(st2_pj, t_p2_5), [=](Text show_ty_14696) { return prism_rtl::finished(crate::check::types::recording::err_fix(st2_pj, Text::lit("row-not-closed"), span_p4_3, prism_rtl::cat("a match over `", show_ty_14696, "` needs `otherwise:`"), Text::lit("add an `otherwise:` arm: the row\'s variable may hold tags this match cannot name"))); })
                : call_then(start_witness(env_p0_2, st2_pj, rows_pi, tys_p6), [=](std::optional<Array<Text>> witness_14832) {
                return ({
                    prism_rtl::is_some(witness_14832) ? ({
                    auto&& w_pk = prism_rtl::some_of(witness_14832);
                    prism_rtl::finished(crate::check::types::recording::err_fix(st2_pj, Text::lit("not-exhaustive"), span_p4_3, prism_rtl::cat("this match misses `", crate::syntax::lexer::chars::join(w_pk, Text::lit(", ")), "`"), Text::lit("add an arm for it, or `otherwise:`")));
                })
                    : prism_rtl::is_none(witness_14832) ? prism_rtl::finished(st2_pj)
                    : throw prism_rtl::Panic("no arm matched");
                });
            });
        });
        });
    });
}


/// `Start MatchCoverage, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_match_coverage(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::types::Ty t_p2, Array<crate::syntax::Arm> arms_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<MatchCoverage>(env_p0, st_p1, t_p2, arms_p3, span_p4);
}


/// ArmSpan: fn Arm -> Range
crate::syntax::Range arm_span(const crate::syntax::Arm& a_p0) {
    auto&& _m = a_p0.pattern;
    if (prism_rtl::is_some(_m)) {
        auto&& p_p1 = prism_rtl::some_of(_m);
        return prism_rtl::deref(p_p1).span;
    }
    if (prism_rtl::is_none(_m)) {
        return a_p0.span;
    }
    prism_rtl::unreachable("no arm matched");
}


/// IsOpenRow: unbounded fn Env, St, Ty -> Bool
bool is_open_row(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::check::types::Ty& t_p2) {
    auto&& _m = crate::check::types::recording::walk(st_p1, t_p2);
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
        auto&& rw_p3 = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a0;
        return prism_rtl::deref(crate::check::types::recording::walk_row(st_p1, rw_p3)).tail != crate::check::types::Tail(crate::check::types::Tail::TlClosed{});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(_m)) {
        auto&& rw_p4 = prism_rtl::as<crate::check::types::Ty::TyElemAny>(_m).a0;
        return prism_rtl::deref(crate::check::types::recording::walk_row(st_p1, rw_p4)).tail != crate::check::types::Tail(crate::check::types::Tail::TlClosed{});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& n_p5 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& m15254_2_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        if (m15254_2_1.size() == 0u) {
            auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0.g).types, n_p5);
            if (prism_rtl::is_some(_m)) {
                auto&& ti_p6 = prism_rtl::some_of(_m);
                return (prism_rtl::deref(ti_p6).body == crate::check::env::TyBody(crate::check::env::TyBody::BRowKind{})) && (!is_root_module(env_p0));
            }
            if (prism_rtl::is_none(_m)) {
                return ((n_p5 == Text::lit("Fault")) || (n_p5 == Text::lit("Prelude.Fault"))) && (!is_root_module(env_p0));
            }
            prism_rtl::unreachable("no arm matched");
        }
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> IsOpenRow::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& t_p2 = this->t_p2;
    auto env_p0_1 = env_p0;
    auto st_p1_2 = st_p1;
    auto t_p2_3 = t_p2;
    return call_then(crate::check::types::recording::start_walk(st_p1_2, t_p2_3), [=](crate::check::types::Ty walk_15260) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyElem>(walk_15260) ? ({
            auto&& rw_p3 = prism_rtl::as<crate::check::types::Ty::TyElem>(walk_15260).a0;
            call_then(crate::check::types::recording::start_walk_row(st_p1_2, rw_p3), [=](crate::check::types::Rw walk_row_15296) { return prism_rtl::finished(prism_rtl::deref(walk_row_15296).tail != crate::check::types::Tail(crate::check::types::Tail::TlClosed{})); });
        })
            : prism_rtl::is<crate::check::types::Ty::TyElemAny>(walk_15260) ? ({
            auto&& rw_p4 = prism_rtl::as<crate::check::types::Ty::TyElemAny>(walk_15260).a0;
            call_then(crate::check::types::recording::start_walk_row(st_p1_2, rw_p4), [=](crate::check::types::Rw walk_row_15348) { return prism_rtl::finished(prism_rtl::deref(walk_row_15348).tail != crate::check::types::Tail(crate::check::types::Tail::TlClosed{})); });
        })
            : prism_rtl::is<crate::check::types::Ty::TyCon>(walk_15260) && ({
            auto&& n_p5 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_15260).a0;
            auto&& m15254_2_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_15260).a1;
            (m15254_2_1.size() == 0u);
        }) ? ({
            auto&& n_p5 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_15260).a0;
            auto&& m15254_2_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_15260).a1;
            ({
            auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env_p0_1).g).types, n_p5);
            prism_rtl::is_some(_m) ? ({
            auto&& ti_p6 = prism_rtl::some_of(_m);
            prism_rtl::finished((prism_rtl::deref(ti_p6).body == crate::check::env::TyBody(crate::check::env::TyBody::BRowKind{})) && (!is_root_module(env_p0_1)));
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(((n_p5 == Text::lit("Fault")) || (n_p5 == Text::lit("Prelude.Fault"))) && (!is_root_module(env_p0_1)))
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::finished(false);
        });
    });
}


/// `Start IsOpenRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_open_row(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::types::Ty t_p2) {
    return prism_rtl::make_rc<IsOpenRow>(env_p0, st_p1, t_p2);
}


/// OwnsRow: unbounded fn Env, St, Ty -> Bool
bool owns_row(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::check::types::Ty& t_p2) {
    auto&& _m = crate::check::types::recording::walk(st_p1, t_p2);
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
        auto&& rw_p3 = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a0;
        return fold(prism_rtl::deref(crate::check::types::recording::walk_row(st_p1, rw_p3)).fams, true, [&](const bool& ok_p4, const Text& f_p5) { return prism_rtl::deref(ok_p4) && (or_(crate::prelude::get(prism_rtl::deref(env_p0.g).fam_owner, f_p5), Text::lit("")) == env_p0.home); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& n_p6 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& m15723_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        if (m15723_1_1.size() == 0u) {
            auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0.g).types, n_p6);
            if (prism_rtl::is_some(_m)) {
                auto&& ti_p7 = prism_rtl::some_of(_m);
                return prism_rtl::deref(ti_p7).body != crate::check::env::TyBody(crate::check::env::TyBody::BRowKind{});
            }
            if (prism_rtl::is_none(_m)) {
                return !((n_p6 == Text::lit("Fault")) || (n_p6 == Text::lit("Prelude.Fault")));
            }
            prism_rtl::unreachable("no arm matched");
        }
    }
    {
        return true;
    }
}


prism_rtl::Turn<bool> OwnsRow::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& t_p2 = this->t_p2;
    auto env_p0_1 = env_p0;
    auto st_p1_2 = st_p1;
    auto t_p2_3 = t_p2;
    return call_then(crate::check::types::recording::start_walk(st_p1_2, t_p2_3), [=](crate::check::types::Ty walk_15729) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyElem>(walk_15729) ? ({
            auto&& rw_p3 = prism_rtl::as<crate::check::types::Ty::TyElem>(walk_15729).a0;
            call_then(crate::check::types::recording::start_walk_row(st_p1_2, rw_p3), [=](crate::check::types::Rw walk_row_15770) { return prism_rtl::finished(fold(prism_rtl::deref(walk_row_15770).fams, true, [&](const bool& ok_p4, const Text& f_p5) { return prism_rtl::deref(ok_p4) && (or_(crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env_p0_1).g).fam_owner, f_p5), Text::lit("")) == prism_rtl::deref(env_p0_1).home); })); });
        })
            : prism_rtl::is<crate::check::types::Ty::TyCon>(walk_15729) && ({
            auto&& n_p6 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_15729).a0;
            auto&& m15723_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_15729).a1;
            (m15723_1_1.size() == 0u);
        }) ? ({
            auto&& n_p6 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_15729).a0;
            auto&& m15723_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_15729).a1;
            ({
            auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env_p0_1).g).types, n_p6);
            prism_rtl::is_some(_m) ? ({
            auto&& ti_p7 = prism_rtl::some_of(_m);
            prism_rtl::finished(prism_rtl::deref(ti_p7).body != crate::check::env::TyBody(crate::check::env::TyBody::BRowKind{}));
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(!((n_p6 == Text::lit("Fault")) || (n_p6 == Text::lit("Prelude.Fault"))))
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::finished(true);
        });
    });
}


/// `Start OwnsRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_owns_row(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::types::Ty t_p2) {
    return prism_rtl::make_rc<OwnsRow>(env_p0, st_p1, t_p2);
}


/// ClauseCoverage: unbounded fn Env, St, [FnClause], [Ty], Range -> St
crate::check::types::St clause_coverage(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Array<crate::syntax::decls::FnClause>& clauses_p2, const Array<crate::check::types::Ty>& params_p3, const crate::syntax::Range& span_p4) {
    auto [rows_pc, st2_pd] = run_to_end(fold_job(clauses_p2, std::tuple{Array<Array<Pat>>{}, st_p1}, ({
        auto env_p0_1 = env_p0;
        auto params_p3_2 = params_p3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Array<Pat>>, crate::check::types::St>>(std::tuple<std::tuple<Array<Array<Pat>>, crate::check::types::St>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, env_p0_1 = std::move(env_p0_1), params_p3_2 = std::move(params_p3_2)](std::tuple<std::tuple<Array<Array<Pat>>, crate::check::types::St>, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_p0_1_3 = env_p0_1;
            auto params_p3_2_3 = params_p3_2;
            entered(once_job([=, env_p0_1_3 = std::move(env_p0_1_3), params_p3_2_3 = std::move(params_p3_2_3)]() {
            return ({
                auto [acc_p5, s_p6] = p0;
                auto c_p7 = p1;
                call_value(each_job(prism_rtl::deref(c_p7).params, ({
                auto env_p0_1_3_3 = env_p0_1_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(crate::syntax::Pattern_)>>(prism_rtl::rc([=, env_p0_1_3_3 = std::move(env_p0_1_3_3)](crate::syntax::Pattern_ p0) {
                return ({
                    auto env_p0_1_3_3_3 = env_p0_1_3_3;
                    entered(once_job([=, env_p0_1_3_3_3 = std::move(env_p0_1_3_3_3)]() {
                    return ({
                        auto p_pb = p0;
                        (prism_rtl::more(prism_rtl::rc(ToPat(env_p0_1_3_3_3, p_pb))));
                    });
                }));
                });
            })));
            })), [=](Array<Pat> each_16266) {
                return ({
                    auto q_p8 = each_16266;
                    auto reachable_p9 = (len(q_p8) != len(params_p3_2_3)) || useful(env_p0_1_3, s_p6, acc_p5, q_p8, params_p3_2_3);
                    auto s2_pa = std::move(reachable_p9)
                        ? s_p6
                        : crate::check::types::recording::err_fix(s_p6, Text::lit("unreachable"), prism_rtl::deref(c_p7).span, Text::lit("this clause is never reached"), Text::lit("remove it, or put it above the clause that covers it"));
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc_p5, q_p8), s2_pa}));
                });
            });
            });
        }));
        });
    }));
    })));
    return len(params_p3) == Nat(0u)
        ? st2_pd
        : ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        auto&& _m = witness(env_p0, st2_pd, rows_pc, params_p3);
        if (prism_rtl::is_some(_m)) {
            auto&& w_pe = prism_rtl::some_of(_m);
            _v.set(crate::check::types::recording::err_fix(st2_pd, Text::lit("not-exhaustive"), span_p4, prism_rtl::cat("these clauses miss `", crate::syntax::lexer::chars::join(w_pe, Text::lit(", ")), "`"), Text::lit("add a clause for it")));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(st2_pd);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<crate::check::types::St> ClauseCoverage::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& clauses_p2 = this->clauses_p2;
    const auto& params_p3 = this->params_p3;
    const auto& span_p4 = this->span_p4;
    auto clauses_p2_1 = clauses_p2;
    auto env_p0_2 = env_p0;
    auto params_p3_3 = params_p3;
    auto span_p4_4 = span_p4;
    auto st_p1_5 = st_p1;
    return call_value(fold_job(clauses_p2_1, std::tuple{Array<Array<Pat>>{}, st_p1_5}, ({
        auto env_p0_2_6 = env_p0_2;
        auto params_p3_3_6 = params_p3_3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Array<Pat>>, crate::check::types::St>>(std::tuple<std::tuple<Array<Array<Pat>>, crate::check::types::St>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, env_p0_2_6 = std::move(env_p0_2_6), params_p3_3_6 = std::move(params_p3_3_6)](std::tuple<std::tuple<Array<Array<Pat>>, crate::check::types::St>, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_p0_2_6_6 = env_p0_2_6;
            auto params_p3_3_6_6 = params_p3_3_6;
            entered(once_job([=, env_p0_2_6_6 = std::move(env_p0_2_6_6), params_p3_3_6_6 = std::move(params_p3_3_6_6)]() {
            return ({
                auto [acc_p5, s_p6] = p0;
                auto c_p7 = p1;
                call_value(each_job(prism_rtl::deref(c_p7).params, ({
                auto env_p0_2_6_6_6 = env_p0_2_6_6;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(crate::syntax::Pattern_)>>(prism_rtl::rc([=, env_p0_2_6_6_6 = std::move(env_p0_2_6_6_6)](crate::syntax::Pattern_ p0) {
                return ({
                    auto env_p0_2_6_6_6_6 = env_p0_2_6_6_6;
                    entered(once_job([=, env_p0_2_6_6_6_6 = std::move(env_p0_2_6_6_6_6)]() {
                    return ({
                        auto p_pb = p0;
                        (prism_rtl::more(prism_rtl::rc(ToPat(env_p0_2_6_6_6_6, p_pb))));
                    });
                }));
                });
            })));
            })), [=](Array<Pat> each_16266) {
                return ({
                    auto q_p8 = each_16266;
                    auto reachable_p9 = (len(q_p8) != len(params_p3_3_6_6)) || useful(env_p0_2_6_6, s_p6, acc_p5, q_p8, params_p3_3_6_6);
                    auto s2_pa = std::move(reachable_p9)
                        ? s_p6
                        : crate::check::types::recording::err_fix(s_p6, Text::lit("unreachable"), prism_rtl::deref(c_p7).span, Text::lit("this clause is never reached"), Text::lit("remove it, or put it above the clause that covers it"));
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc_p5, q_p8), s2_pa}));
                });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<Array<Pat>>, crate::check::types::St> fold_16205) {
        return ({
            auto [rows_pc, st2_pd] = fold_16205;
            len(params_p3_3) == Nat(0u)
            ? prism_rtl::finished(st2_pd)
            : call_then(start_witness(env_p0_2, st2_pd, rows_pc, params_p3_3), [=](std::optional<Array<Text>> witness_16615) {
            return ({
                prism_rtl::is_some(witness_16615) ? ({
                auto&& w_pe = prism_rtl::some_of(witness_16615);
                prism_rtl::finished(crate::check::types::recording::err_fix(st2_pd, Text::lit("not-exhaustive"), span_p4_4, prism_rtl::cat("these clauses miss `", crate::syntax::lexer::chars::join(w_pe, Text::lit(", ")), "`"), Text::lit("add a clause for it")));
            })
                : prism_rtl::is_none(witness_16615) ? prism_rtl::finished(st2_pd)
                : throw prism_rtl::Panic("no arm matched");
            });
        });
        });
    });
}


/// `Start ClauseCoverage, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_clause_coverage(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<crate::syntax::decls::FnClause> clauses_p2, Array<crate::check::types::Ty> params_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<ClauseCoverage>(env_p0, st_p1, clauses_p2, params_p3, span_p4);
}


/// DischargeIncls: unbounded fn G, St, Nat -> St
crate::check::types::St discharge_incls(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const Nat& from_p2) {
    auto batch_p3 = drop(st_p1.incls, from_p2);
    return run_to_end(fold_job(batch_p3, st_p1, ({
        auto g_p0_1 = g_p0;
        auto batch_p3_2 = batch_p3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::Incl>)>>(prism_rtl::rc([=, g_p0_1 = std::move(g_p0_1), batch_p3_2 = std::move(batch_p3_2)](std::tuple<crate::check::types::St, crate::check::types::Incl> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0_1_3 = g_p0_1;
            auto batch_p3_2_3 = batch_p3_2;
            entered(once_job([=, g_p0_1_3 = std::move(g_p0_1_3), batch_p3_2_3 = std::move(batch_p3_2_3)]() {
            return ({
                auto s_p4 = p0;
                auto inc_p5 = p1;
                call_then(start_through(s_p4, inc_p5, batch_p3_2_3), [=](crate::check::types::Incl through_17456) { return prism_rtl::more(prism_rtl::rc(DischargeOne(g_p0_1_3, s_p4, through_17456))); });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<crate::check::types::St> DischargeIncls::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& from_p2 = this->from_p2;
    auto batch_p3 = drop(prism_rtl::deref(st_p1).incls, from_p2);
    return fold_job(batch_p3, st_p1, ({
        auto g_p0_1 = g_p0;
        auto batch_p3_2 = batch_p3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::Incl>)>>(prism_rtl::rc([=, g_p0_1 = std::move(g_p0_1), batch_p3_2 = std::move(batch_p3_2)](std::tuple<crate::check::types::St, crate::check::types::Incl> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0_1_3 = g_p0_1;
            auto batch_p3_2_3 = batch_p3_2;
            entered(once_job([=, g_p0_1_3 = std::move(g_p0_1_3), batch_p3_2_3 = std::move(batch_p3_2_3)]() {
            return ({
                auto s_p4 = p0;
                auto inc_p5 = p1;
                call_then(start_through(s_p4, inc_p5, batch_p3_2_3), [=](crate::check::types::Incl through_17456) { return prism_rtl::more(prism_rtl::rc(DischargeOne(g_p0_1_3, s_p4, through_17456))); });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start DischargeIncls, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_discharge_incls(crate::check::env::G g_p0, crate::check::types::St st_p1, Nat from_p2) {
    return prism_rtl::make_rc<DischargeIncls>(g_p0, st_p1, from_p2);
}


/// Through: unbounded fn St, Incl, [Incl] -> Incl
crate::check::types::Incl through(const crate::check::types::St& st_p0, const crate::check::types::Incl& inc_p1, const Array<crate::check::types::Incl>& batch_p2) {
    auto sup_p3 = crate::check::types::recording::walk_row(st_p0, inc_p1.sup);
    auto&& _m = prism_rtl::deref(sup_p3).tail;
    if (prism_rtl::is<crate::check::types::Tail::TlFlex>(_m)) {
        auto&& n_p4 = prism_rtl::as<crate::check::types::Tail::TlFlex>(_m).a0;
        return len(prism_rtl::deref(sup_p3).fams) > Nat(0u)
            ? inc_p1
            : run_to_end(fold_job(batch_p2, inc_p1, ({
            auto st_p0_1 = st_p0;
            auto n_p4_2 = n_p4;
            auto inc_p1_3 = inc_p1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Incl>(std::tuple<crate::check::types::Incl, crate::check::types::Incl>)>>(prism_rtl::rc([=, st_p0_1 = std::move(st_p0_1), n_p4_2 = std::move(n_p4_2), inc_p1_3 = std::move(inc_p1_3)](std::tuple<crate::check::types::Incl, crate::check::types::Incl> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_p0_1_4 = st_p0_1;
                auto n_p4_2_4 = n_p4_2;
                auto inc_p1_3_4 = inc_p1_3;
                entered(once_job([=, st_p0_1_4 = std::move(st_p0_1_4), n_p4_2_4 = std::move(n_p4_2_4), inc_p1_3_4 = std::move(inc_p1_3_4)]() {
                return ({
                    auto acc_p5 = p0;
                    auto other_p6 = p1;
                    call_then(crate::check::types::recording::start_walk_row(st_p0_1_4, prism_rtl::deref(other_p6).sub), [=, acc_p5 = std::move(acc_p5)](crate::check::types::Rw walk_row_17970) {
                    return ({
                        auto sub_p7 = walk_row_17970;
                        ((len(prism_rtl::deref(sub_p7).fams) == Nat(0u)) && (prism_rtl::deref(sub_p7).tail == crate::check::types::Tail(crate::check::types::Tail::TlFlex{n_p4_2_4}))) && (other_p6 != inc_p1_3_4)
                        ? prism_rtl::finished(({
                        crate::check::types::Incl this_ = acc_p5;
                        this_.sup = prism_rtl::deref(other_p6).sup;
                        (std::move(this_));
                    }))
                        : prism_rtl::finished(acc_p5);
                    });
                });
                });
            }));
            });
        })));
        })));
    }
    {
        return inc_p1;
    }
}


prism_rtl::Turn<crate::check::types::Incl> Through::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& inc_p1 = this->inc_p1;
    const auto& batch_p2 = this->batch_p2;
    auto batch_p2_1 = batch_p2;
    auto inc_p1_2 = inc_p1;
    auto st_p0_3 = st_p0;
    return call_then(crate::check::types::recording::start_walk_row(st_p0_3, prism_rtl::deref(inc_p1_2).sup), [=](crate::check::types::Rw walk_row_17798) {
        return ({
            auto sup_p3 = walk_row_17798;
            ({
            auto&& _m = prism_rtl::deref(sup_p3).tail;
            prism_rtl::is<crate::check::types::Tail::TlFlex>(_m) ? ({
            auto&& n_p4 = prism_rtl::as<crate::check::types::Tail::TlFlex>(_m).a0;
            len(prism_rtl::deref(sup_p3).fams) > Nat(0u)
            ? prism_rtl::finished(inc_p1_2)
            : fold_job(batch_p2_1, inc_p1_2, ({
            auto st_p0_3_4 = st_p0_3;
            auto n_p4_4 = n_p4;
            auto inc_p1_2_5 = inc_p1_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Incl>(std::tuple<crate::check::types::Incl, crate::check::types::Incl>)>>(prism_rtl::rc([=, st_p0_3_4 = std::move(st_p0_3_4), n_p4_4 = std::move(n_p4_4), inc_p1_2_5 = std::move(inc_p1_2_5)](std::tuple<crate::check::types::Incl, crate::check::types::Incl> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_p0_3_4_5 = st_p0_3_4;
                auto n_p4_4_5 = n_p4_4;
                auto inc_p1_2_5_5 = inc_p1_2_5;
                entered(once_job([=, st_p0_3_4_5 = std::move(st_p0_3_4_5), n_p4_4_5 = std::move(n_p4_4_5), inc_p1_2_5_5 = std::move(inc_p1_2_5_5)]() {
                return ({
                    auto acc_p5 = p0;
                    auto other_p6 = p1;
                    call_then(crate::check::types::recording::start_walk_row(st_p0_3_4_5, prism_rtl::deref(other_p6).sub), [=, acc_p5 = std::move(acc_p5)](crate::check::types::Rw walk_row_17970) {
                    return ({
                        auto sub_p7 = walk_row_17970;
                        ((len(prism_rtl::deref(sub_p7).fams) == Nat(0u)) && (prism_rtl::deref(sub_p7).tail == crate::check::types::Tail(crate::check::types::Tail::TlFlex{n_p4_4_5}))) && (other_p6 != inc_p1_2_5_5)
                        ? prism_rtl::finished(({
                        crate::check::types::Incl this_ = acc_p5;
                        this_.sup = prism_rtl::deref(other_p6).sup;
                        (std::move(this_));
                    }))
                        : prism_rtl::finished(acc_p5);
                    });
                });
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::finished(inc_p1_2);
        });
        });
    });
}


/// `Start Through, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Incl> start_through(crate::check::types::St st_p0, crate::check::types::Incl inc_p1, Array<crate::check::types::Incl> batch_p2) {
    return prism_rtl::make_rc<Through>(st_p0, inc_p1, batch_p2);
}


/// DischargeOne: unbounded fn G, St, Incl -> St
crate::check::types::St discharge_one(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::types::Incl& inc_p2) {
    auto sub_p3 = crate::check::types::recording::walk_row(st_p1, inc_p2.sub);
    auto sup_p4 = crate::check::types::recording::walk_row(st_p1, inc_p2.sup);
    auto st1_p5 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        auto&& _m = prism_rtl::deref(sub_p3).tail;
        if (prism_rtl::is<crate::check::types::Tail::TlFlex>(_m)) {
            auto&& n_p9 = prism_rtl::as<crate::check::types::Tail::TlFlex>(_m).a0;
            _v.set(close_tail(st_p1, n_p9));
            goto _done;
        }
        {
            _v.set(st_p1);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto sub2_p6 = crate::check::types::recording::walk_row(st1_p5, inc_p2.sub);
    auto left_p7 = filter(prism_rtl::deref(sub2_p6).fams, [&](const Text& f_pa) { return (!crate::check::types::has_text(prism_rtl::deref(sup_p4).fams, f_pa)) && (len(tags_left(g_p0, f_pa, prism_rtl::deref(sub2_p6).minus)) > Nat(0u)); });
    auto tail_bad_p8 = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = std::tuple{prism_rtl::deref(sub2_p6).tail, prism_rtl::deref(sup_p4).tail};
        if (prism_rtl::is<crate::check::types::Tail::TlRigid>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Tail::TlRigid>(std::get<1>(_m))) {
            auto&& a_pb = prism_rtl::as<crate::check::types::Tail::TlRigid>(std::get<0>(_m)).a0;
            auto&& b_pc = prism_rtl::as<crate::check::types::Tail::TlRigid>(std::get<1>(_m)).a0;
            _v.set(a_pb != b_pc);
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Tail::TlRigid>(std::get<0>(_m))) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    return (len(left_p7) == Nat(0u)) && (!std::move(tail_bad_p8))
        ? st1_p5
        : ({
        auto s0_pd = ({
            crate::check::types::St this_ = st1_p5;
            this_.file = inc_p2.file;
            (std::move(this_));
        });
        auto tags_pe = fold(left_p7, Array<Text>{}, [&](const Array<Text>& acc_pg, const Text& f_ph) { return append(acc_pg, tags_left(g_p0, f_ph, prism_rtl::deref(sub2_p6).minus)); });
        auto s1_pf = inc_p2.forward
            ? crate::check::types::recording::err_fix(s0_pd, Text::lit("forwarding"), inc_p2.span, prism_rtl::cat("forwarding ", crate::syntax::lexer::chars::join(tags_pe, Text::lit(", ")), " from a scope that emits ", crate::check::types::show_row(sup_p4)), prism_rtl::cat("answer ", len(tags_pe) == Nat(1u) ? Text::lit("it") : Text::lit("them"), " above this arm, for example `", or_(index(tags_pe, Nat(0u)), Text::lit("")), "(..): @ never`"))
            : crate::check::types::recording::err_fix(s0_pd, Text::lit("row-outside"), inc_p2.span, prism_rtl::cat("a child that emits `", crate::check::types::show_row(sub2_p6), "` in a scope that emits `", crate::check::types::show_row(sup_p4), "`"), Text::lit("widen the scope\'s `emit` row, or host the child with `@HostDocument`"));
        ({
        crate::check::types::St this_ = s1_pf;
        this_.file = st1_p5->file;
        (std::move(this_));
    });
    });
}


prism_rtl::Turn<crate::check::types::St> DischargeOne::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& inc_p2 = this->inc_p2;
    auto g_p0_1 = g_p0;
    auto inc_p2_2 = inc_p2;
    auto st_p1_3 = st_p1;
    return call_then(crate::check::types::recording::start_walk_row(st_p1_3, prism_rtl::deref(inc_p2_2).sub), [=](crate::check::types::Rw walk_row_18289) {
        return ({
            auto sub_p3 = walk_row_18289;
            call_then(crate::check::types::recording::start_walk_row(st_p1_3, prism_rtl::deref(inc_p2_2).sup), [=, sub_p3 = std::move(sub_p3)](crate::check::types::Rw walk_row_18323) {
            return ({
                auto sup_p4 = walk_row_18323;
                auto st1_p5 = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::check::types::St> _v;
                    auto&& _m = prism_rtl::deref(sub_p3).tail;
                    if (prism_rtl::is<crate::check::types::Tail::TlFlex>(_m)) {
                        auto&& n_p9 = prism_rtl::as<crate::check::types::Tail::TlFlex>(_m).a0;
                        _v.set(close_tail(st_p1_3, n_p9));
                        goto _done;
                    }
                    {
                        _v.set(st_p1_3);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                call_then(crate::check::types::recording::start_walk_row(st1_p5, prism_rtl::deref(inc_p2_2).sub), [=, sup_p4 = std::move(sup_p4)](crate::check::types::Rw walk_row_18444) {
                return ({
                    auto sub2_p6 = walk_row_18444;
                    auto left_p7 = filter(prism_rtl::deref(sub2_p6).fams, [&](const Text& f_pa) { return (!crate::check::types::has_text(prism_rtl::deref(sup_p4).fams, f_pa)) && (len(tags_left(g_p0_1, f_pa, prism_rtl::deref(sub2_p6).minus)) > Nat(0u)); });
                    auto tail_bad_p8 = ({
                        __label__ _done;
                        prism_rtl::Slot<bool> _v;
                        auto&& _m = std::tuple{prism_rtl::deref(sub2_p6).tail, prism_rtl::deref(sup_p4).tail};
                        if (prism_rtl::is<crate::check::types::Tail::TlRigid>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Tail::TlRigid>(std::get<1>(_m))) {
                            auto&& a_pb = prism_rtl::as<crate::check::types::Tail::TlRigid>(std::get<0>(_m)).a0;
                            auto&& b_pc = prism_rtl::as<crate::check::types::Tail::TlRigid>(std::get<1>(_m)).a0;
                            _v.set(a_pb != b_pc);
                            goto _done;
                        }
                        if (prism_rtl::is<crate::check::types::Tail::TlRigid>(std::get<0>(_m))) {
                            _v.set(true);
                            goto _done;
                        }
                        {
                            _v.set(false);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    (len(left_p7) == Nat(0u)) && (!std::move(tail_bad_p8))
                    ? prism_rtl::finished(st1_p5)
                    : ({
                    auto s0_pd = ({
                        crate::check::types::St this_ = st1_p5;
                        this_.file = inc_p2_2->file;
                        (std::move(this_));
                    });
                    auto tags_pe = fold(left_p7, Array<Text>{}, [&](const Array<Text>& acc_pg, const Text& f_ph) { return append(acc_pg, tags_left(g_p0_1, f_ph, prism_rtl::deref(sub2_p6).minus)); });
                    auto s1_pf = prism_rtl::deref(inc_p2_2).forward
                        ? crate::check::types::recording::err_fix(s0_pd, Text::lit("forwarding"), prism_rtl::deref(inc_p2_2).span, prism_rtl::cat("forwarding ", crate::syntax::lexer::chars::join(tags_pe, Text::lit(", ")), " from a scope that emits ", crate::check::types::show_row(sup_p4)), prism_rtl::cat("answer ", len(tags_pe) == Nat(1u) ? Text::lit("it") : Text::lit("them"), " above this arm, for example `", or_(index(tags_pe, Nat(0u)), Text::lit("")), "(..): @ never`"))
                        : crate::check::types::recording::err_fix(s0_pd, Text::lit("row-outside"), prism_rtl::deref(inc_p2_2).span, prism_rtl::cat("a child that emits `", crate::check::types::show_row(sub2_p6), "` in a scope that emits `", crate::check::types::show_row(sup_p4), "`"), Text::lit("widen the scope\'s `emit` row, or host the child with `@HostDocument`"));
                    (prism_rtl::finished(({
                    crate::check::types::St this_ = s1_pf;
                    this_.file = st1_p5->file;
                    (std::move(this_));
                })));
                });
                });
            });
            });
        });
        });
    });
}


/// `Start DischargeOne, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_discharge_one(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::types::Incl inc_p2) {
    return prism_rtl::make_rc<DischargeOne>(g_p0, st_p1, inc_p2);
}


/// TagsLeft: fn G, Text, [Text] -> [Text]
Array<Text> tags_left(const crate::check::env::G& g_p0, const Text& fam_p1, const Array<Text>& minus_p2) {
    return filter(or_(crate::prelude::get(g_p0.families, fam_p1), Array<Text>{}), [&](const Text& t_p3) { return (!crate::check::types::has_text(minus_p2, t_p3)) && is_element_tag(g_p0, t_p3); });
}


/// IsElementTag: fn G, Text -> Bool
bool is_element_tag(const crate::check::env::G& g_p0, const Text& t_p1) {
    auto&& _m = crate::prelude::get(g_p0.tags, t_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& tg_p2 = prism_rtl::some_of(_m);
        return prism_rtl::deref(tg_p2).kind == Text::lit("Element");
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// CloseTail: fn St, Nat -> St
crate::check::types::St close_tail(const crate::check::types::St& st_p0, const Nat& n_p1) {
    crate::check::types::St this_ = st_p0;
    this_.rows = insert(this_.rows, n_p1, crate::check::types::empty_row());
    return this_;
}

}  // namespace crate::check::passes
