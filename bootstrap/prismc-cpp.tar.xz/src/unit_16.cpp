// The module `Check.Passes`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/passes/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Check.Passes`, from `target/bootstrap/cpp-src/prismc/check/passes/mod.prism`.
namespace crate::check::passes {

bool Ctor::operator==(const Ctor& o) const { return name_p == o.name_p && arity_p == o.arity_p && args_p == o.args_p && shown_p == o.shown_p; }

void Ctor::show(Printer& p) const {
    p.record("Ctor", {{"name", name_p}, {"arity", arity_p}, {"args", args_p}, {"shown", shown_p}});
}

Pod Ctor::to_pod() const {
    return Pod::record("Ctor", {{"name", prism_rtl::to_pod(name_p)}, {"arity", prism_rtl::to_pod(arity_p)}, {"args", prism_rtl::to_pod(args_p)}, {"shown", prism_rtl::to_pod(shown_p)}});
}

Result<Ctor> Ctor::from_pod(const Pod& whole) {
    return Ctor{.name_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .arity_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "arity")))), .args_p = TRY(prism_rtl::from_pod<Array<crate::check::types::Ty>>(TRY(crate::prelude::field(whole, "args")))), .shown_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "shown"))))};
}


bool Pat::PtCon::operator==(const PtCon& o) const { return a0 == o.a0 && a1 == o.a1; }

void Pat::show(Printer& p) const {
    if (auto c = std::get_if<PtAny>(&cases())) p.choice("PtAny", {});
    else if (auto c = std::get_if<PtCon>(&cases())) p.choice("PtCon", {c->a0, c->a1});
    else if (auto c = std::get_if<PtLit>(&cases())) p.choice("PtLit", {c->a0});
    else if (auto c = std::get_if<PtFam>(&cases())) p.choice("PtFam", {c->a0});
}

Pod Pat::to_pod() const {
    return std::holds_alternative<PtAny>(cases()) ? Pod::choice("PtAny", {})
        : std::holds_alternative<PtCon>(cases()) ? Pod::choice("PtCon", {prism_rtl::to_pod(std::get<PtCon>(cases()).a0), prism_rtl::to_pod(std::get<PtCon>(cases()).a1)})
        : std::holds_alternative<PtLit>(cases()) ? Pod::choice("PtLit", {prism_rtl::to_pod(std::get<PtLit>(cases()).a0)})
        : std::holds_alternative<PtFam>(cases()) ? Pod::choice("PtFam", {prism_rtl::to_pod(std::get<PtFam>(cases()).a0)})
        : Pod();
}

Result<Pat> Pat::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "PtAny" && c->args.size() == 0) return Pat(PtAny{});
        if (c->ctor == "PtCon" && c->args.size() == 2) return Pat(PtCon{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Array<Pat>>(c->args[1]))});
        if (c->ctor == "PtLit" && c->args.size() == 1) return Pat(PtLit{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "PtFam" && c->args.size() == 1) return Pat(PtFam{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
    }
    return mismatch<Pat>("a Pat", p);
}


/// ?CtorsOf: unbounded fn Env, St, Ty -> ?[Ctor]
std::optional<Array<Ctor>> ctors_of_o(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::check::types::Ty& t_p2) {
    auto&& _m = crate::check::types::recording::walk_f(st_p1, t_p2);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& m2894_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& m2894_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        if (m2894_0_0 == Text::lit("Bool")) {
            if (m2894_0_1.size() == 0u) {
                return std::optional(Array(std::vector{Ctor{.name_p = Text::lit("True"), .arity_p = Nat(0u), .args_p = Array<crate::check::types::Ty>{}, .shown_p = Text::lit("True")}, Ctor{.name_p = Text::lit("False"), .arity_p = Nat(0u), .args_p = Array<crate::check::types::Ty>{}, .shown_p = Text::lit("False")}}));
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& m2894_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& m2894_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        if (m2894_1_0 == Text::lit("unit")) {
            if (m2894_1_1.size() == 0u) {
                return std::optional(Array(std::vector{Ctor{.name_p = Text::lit("unit"), .arity_p = Nat(0u), .args_p = Array<crate::check::types::Ty>{}, .shown_p = Text::lit("unit")}}));
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& m2894_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
        auto&& i_p3 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        if (m2894_2_0 == Text::lit("?")) {
            return std::optional(Array(std::vector{Ctor{.name_p = Text::lit("?"), .arity_p = Nat(1u), .args_p = Array(std::vector{prism_rtl::deref(i_p3)}), .shown_p = Text::lit("? _")}, Ctor{.name_p = Text::lit("nil"), .arity_p = Nat(0u), .args_p = Array<crate::check::types::Ty>{}, .shown_p = Text::lit("nil")}}));
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& m2894_3_0 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
        auto&& i_p4 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        if (m2894_3_0 == Text::lit("~")) {
            return std::optional(Array(std::vector{Ctor{.name_p = Text::lit("~"), .arity_p = Nat(1u), .args_p = Array(std::vector{prism_rtl::deref(i_p4)}), .shown_p = Text::lit("~ _")}, Ctor{.name_p = Text::lit("Error"), .arity_p = Nat(2u), .args_p = Array(std::vector{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Prelude.Fault"), Array<crate::check::types::Ty>{}}), crate::check::types::t_text_p()}), .shown_p = Text::lit("Error(..)")}}));
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(_m)) {
        auto&& ts_p5 = prism_rtl::as<crate::check::types::Ty::TyTuple>(_m).a0;
        return std::optional(Array(std::vector{Ctor{.name_p = Text::lit("tuple"), .arity_p = crate::prelude::len(ts_p5), .args_p = ts_p5, .shown_p = prism_rtl::cat("((", crate::syntax::lexer::chars::join_f(crate::prelude::each(ts_p5, [&](const crate::check::types::Ty& _p0) { return Text::lit("_"); }), Text::lit(", ")), "))")}}));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& m2894_5_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& m2894_5_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        if (m2894_5_0 == Text::lit("Prelude.Error")) {
            if (m2894_5_1.size() == 0u) {
                return std::optional(Array(std::vector{Ctor{.name_p = Text::lit("Error"), .arity_p = Nat(2u), .args_p = Array(std::vector{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Prelude.Fault"), Array<crate::check::types::Ty>{}}), crate::check::types::t_text_p()}), .shown_p = Text::lit("Error(..)")}}));
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& n_p6 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& args_p7 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0.g_p).types_p, n_p6);
        if (prism_rtl::is_some(_m)) {
            auto&& ti_p8 = prism_rtl::some_of(_m);
            auto&& _m = prism_rtl::deref(ti_p8).body_p;
            if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
                auto&& cases_p9 = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
                return std::optional(crate::prelude::run_to_end(crate::prelude::each_job(cases_p9, ({
                    auto ti_p8x = ti_p8;
                    auto args_p7x = args_p7;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ctor>(std::tuple<Text, Array<crate::check::types::Ty>>)>>(prism_rtl::rc([=, ti_p8x = std::move(ti_p8x), args_p7x = std::move(args_p7x)](std::tuple<Text, Array<crate::check::types::Ty>> p0) {
                    return ({
                        auto ti_p8xy = ti_p8x;
                        auto args_p7xy = args_p7x;
                        (crate::prelude::entered(crate::prelude::once_job([=, ti_p8xy = std::move(ti_p8xy), args_p7xy = std::move(args_p7xy)]() {
                        return ({
                            auto [cn_pa, cargs_pb] = p0;
                            (prism_rtl::more(prism_rtl::rc(CtorOfCase(ti_p8xy, cn_pa, cargs_pb, args_p7xy))));
                        });
                    })));
                    });
                })));
                }))));
            }
            if (prism_rtl::is<crate::check::env::TyBody::BRecord>(_m)) {
                auto&& fields_pc = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
                return std::optional(Array(std::vector{Ctor{.name_p = n_p6, .arity_p = crate::prelude::len(fields_pc), .args_p = crate::prelude::run_to_end(crate::prelude::each_job(fields_pc, ({
                    auto ti_p8x = ti_p8;
                    auto args_p7x = args_p7;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(std::tuple<Text, crate::check::types::Ty>)>>(prism_rtl::rc([=, ti_p8x = std::move(ti_p8x), args_p7x = std::move(args_p7x)](std::tuple<Text, crate::check::types::Ty> p0) {
                    return ({
                        auto ti_p8xy = ti_p8x;
                        auto args_p7xy = args_p7x;
                        (crate::prelude::entered(crate::prelude::once_job([=, ti_p8xy = std::move(ti_p8xy), args_p7xy = std::move(args_p7xy)]() {
                        return ({
                            auto&& _ft_pd = p0;
                            auto&& ft_pd = std::get<1>(_ft_pd);
                            (prism_rtl::more(prism_rtl::rc(crate::check::types::schemes::SubstQ(crate::check::env::reading::param_inst_f(prism_rtl::deref(ti_p8xy).params_p, args_p7xy), ft_pd))));
                        });
                    })));
                    });
                })));
                }))), .shown_p = prism_rtl::cat(crate::check::types::bare_name_f(n_p6), "(..)")}}));
            }
            if (prism_rtl::is<crate::check::env::TyBody::BRowKind>(_m)) {
                return is_root_module_f(env_p0)
                    ? std::optional(crate::prelude::each(tags_of_kind_f(env_p0, n_p6), [&](const crate::check::env::TagInfo& tg_pe) { return tag_ctor_f(tg_pe); }))
                    : std::optional<Array<Ctor>>{};
            }
            {
                return std::optional<Array<Ctor>>{};
            }
        }
        if (prism_rtl::is_none(_m)) {
            return (n_p6 == Text::lit("Fault")) || (n_p6 == Text::lit("Prelude.Fault"))
                ? is_root_module_f(env_p0)
                ? std::optional(crate::prelude::each(tags_of_kind_f(env_p0, Text::lit("Prelude.Fault")), [&](const crate::check::env::TagInfo& tg_pf) { return tag_ctor_f(tg_pf); }))
                : std::optional<Array<Ctor>>{}
                : std::optional<Array<Ctor>>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
        auto&& rw_pg = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a0;
        auto w_ph = crate::check::types::recording::walk_row_f(st_p1, rw_pg);
        return prism_rtl::deref(w_ph).tail_p != crate::check::types::Tail(crate::check::types::Tail::TlClosed{})
            ? std::optional<Array<Ctor>>{}
            : std::optional(crate::prelude::each(tags_of_row_f(env_p0, w_ph), [&](const crate::check::env::TagInfo& tg_pi) { return tag_ctor_f(tg_pi); }));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(_m)) {
        auto&& rw_pj = prism_rtl::as<crate::check::types::Ty::TyElemAny>(_m).a0;
        auto w_pk = crate::check::types::recording::walk_row_f(st_p1, rw_pj);
        return prism_rtl::deref(w_pk).tail_p != crate::check::types::Tail(crate::check::types::Tail::TlClosed{})
            ? std::optional<Array<Ctor>>{}
            : std::optional(crate::prelude::each(tags_of_row_f(env_p0, w_pk), [&](const crate::check::env::TagInfo& tg_pl) { return tag_ctor_f(tg_pl); }));
    }
    {
        return std::optional<Array<Ctor>>{};
    }
}


prism_rtl::Turn<std::optional<Array<Ctor>>> CtorsOf::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& t_p2 = this->t_p2;
    auto env_p0x = env_p0;
    auto st_p1x = st_p1;
    auto t_p2x = t_p2;
    return crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x, t_p2x), [=](crate::check::types::Ty walk_f_2900) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyCon>(walk_f_2900) && ({
            auto&& m2894_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_2900).a0;
            auto&& m2894_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_2900).a1;
            (m2894_0_0 == Text::lit("Bool")) && (m2894_0_1.size() == 0u);
        }) ? ({
            auto&& m2894_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_2900).a0;
            auto&& m2894_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_2900).a1;
            prism_rtl::finished(std::optional(Array(std::vector{Ctor{.name_p = Text::lit("True"), .arity_p = Nat(0u), .args_p = Array<crate::check::types::Ty>{}, .shown_p = Text::lit("True")}, Ctor{.name_p = Text::lit("False"), .arity_p = Nat(0u), .args_p = Array<crate::check::types::Ty>{}, .shown_p = Text::lit("False")}})));
        })
            : prism_rtl::is<crate::check::types::Ty::TyCon>(walk_f_2900) && ({
            auto&& m2894_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_2900).a0;
            auto&& m2894_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_2900).a1;
            (m2894_1_0 == Text::lit("unit")) && (m2894_1_1.size() == 0u);
        }) ? ({
            auto&& m2894_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_2900).a0;
            auto&& m2894_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_2900).a1;
            prism_rtl::finished(std::optional(Array(std::vector{Ctor{.name_p = Text::lit("unit"), .arity_p = Nat(0u), .args_p = Array<crate::check::types::Ty>{}, .shown_p = Text::lit("unit")}})));
        })
            : prism_rtl::is<crate::check::types::Ty::TySig>(walk_f_2900) && ({
            auto&& m2894_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_f_2900).a0;
            auto&& i_p3 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_f_2900).a1;
            (m2894_2_0 == Text::lit("?"));
        }) ? ({
            auto&& m2894_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_f_2900).a0;
            auto&& i_p3 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_f_2900).a1;
            prism_rtl::finished(std::optional(Array(std::vector{Ctor{.name_p = Text::lit("?"), .arity_p = Nat(1u), .args_p = Array(std::vector{prism_rtl::deref(i_p3)}), .shown_p = Text::lit("? _")}, Ctor{.name_p = Text::lit("nil"), .arity_p = Nat(0u), .args_p = Array<crate::check::types::Ty>{}, .shown_p = Text::lit("nil")}})));
        })
            : prism_rtl::is<crate::check::types::Ty::TySig>(walk_f_2900) && ({
            auto&& m2894_3_0 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_f_2900).a0;
            auto&& i_p4 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_f_2900).a1;
            (m2894_3_0 == Text::lit("~"));
        }) ? ({
            auto&& m2894_3_0 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_f_2900).a0;
            auto&& i_p4 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_f_2900).a1;
            prism_rtl::finished(std::optional(Array(std::vector{Ctor{.name_p = Text::lit("~"), .arity_p = Nat(1u), .args_p = Array(std::vector{prism_rtl::deref(i_p4)}), .shown_p = Text::lit("~ _")}, Ctor{.name_p = Text::lit("Error"), .arity_p = Nat(2u), .args_p = Array(std::vector{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Prelude.Fault"), Array<crate::check::types::Ty>{}}), crate::check::types::t_text_p()}), .shown_p = Text::lit("Error(..)")}})));
        })
            : prism_rtl::is<crate::check::types::Ty::TyTuple>(walk_f_2900) ? ({
            auto&& ts_p5 = prism_rtl::as<crate::check::types::Ty::TyTuple>(walk_f_2900).a0;
            prism_rtl::finished(std::optional(Array(std::vector{Ctor{.name_p = Text::lit("tuple"), .arity_p = crate::prelude::len(ts_p5), .args_p = ts_p5, .shown_p = prism_rtl::cat("((", crate::syntax::lexer::chars::join_f(crate::prelude::each(ts_p5, [&](const crate::check::types::Ty& _p0) { return Text::lit("_"); }), Text::lit(", ")), "))")}})));
        })
            : prism_rtl::is<crate::check::types::Ty::TyCon>(walk_f_2900) && ({
            auto&& m2894_5_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_2900).a0;
            auto&& m2894_5_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_2900).a1;
            (m2894_5_0 == Text::lit("Prelude.Error")) && (m2894_5_1.size() == 0u);
        }) ? ({
            auto&& m2894_5_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_2900).a0;
            auto&& m2894_5_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_2900).a1;
            prism_rtl::finished(std::optional(Array(std::vector{Ctor{.name_p = Text::lit("Error"), .arity_p = Nat(2u), .args_p = Array(std::vector{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Prelude.Fault"), Array<crate::check::types::Ty>{}}), crate::check::types::t_text_p()}), .shown_p = Text::lit("Error(..)")}})));
        })
            : prism_rtl::is<crate::check::types::Ty::TyCon>(walk_f_2900) ? ({
            auto&& n_p6 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_2900).a0;
            auto&& args_p7 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_2900).a1;
            ({
            auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env_p0x).g_p).types_p, n_p6);
            prism_rtl::is_some(_m) ? ({
            auto&& ti_p8 = prism_rtl::some_of(_m);
            ({
            auto&& _m = prism_rtl::deref(ti_p8).body_p;
            prism_rtl::is<crate::check::env::TyBody::BChoice>(_m) ? ({
            auto&& cases_p9 = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
            prism_rtl::finished(std::optional(crate::prelude::run_to_end(crate::prelude::each_job(cases_p9, ({
            auto ti_p8x = ti_p8;
            auto args_p7x = args_p7;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ctor>(std::tuple<Text, Array<crate::check::types::Ty>>)>>(prism_rtl::rc([=, ti_p8x = std::move(ti_p8x), args_p7x = std::move(args_p7x)](std::tuple<Text, Array<crate::check::types::Ty>> p0) {
            return ({
                auto ti_p8xy = ti_p8x;
                auto args_p7xy = args_p7x;
                (crate::prelude::entered(crate::prelude::once_job([=, ti_p8xy = std::move(ti_p8xy), args_p7xy = std::move(args_p7xy)]() {
                return ({
                    auto [cn_pa, cargs_pb] = p0;
                    (prism_rtl::more(prism_rtl::rc(CtorOfCase(ti_p8xy, cn_pa, cargs_pb, args_p7xy))));
                });
            })));
            });
        })));
        })))));
        })
            : prism_rtl::is<crate::check::env::TyBody::BRecord>(_m) ? ({
            auto&& fields_pc = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
            prism_rtl::finished(std::optional(Array(std::vector{Ctor{.name_p = n_p6, .arity_p = crate::prelude::len(fields_pc), .args_p = crate::prelude::run_to_end(crate::prelude::each_job(fields_pc, ({
            auto ti_p8x = ti_p8;
            auto args_p7x = args_p7;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(std::tuple<Text, crate::check::types::Ty>)>>(prism_rtl::rc([=, ti_p8x = std::move(ti_p8x), args_p7x = std::move(args_p7x)](std::tuple<Text, crate::check::types::Ty> p0) {
            return ({
                auto ti_p8xy = ti_p8x;
                auto args_p7xy = args_p7x;
                (crate::prelude::entered(crate::prelude::once_job([=, ti_p8xy = std::move(ti_p8xy), args_p7xy = std::move(args_p7xy)]() {
                return ({
                    auto&& _ft_pd = p0;
                    auto&& ft_pd = std::get<1>(_ft_pd);
                    (prism_rtl::more(prism_rtl::rc(crate::check::types::schemes::SubstQ(crate::check::env::reading::param_inst_f(prism_rtl::deref(ti_p8xy).params_p, args_p7xy), ft_pd))));
                });
            })));
            });
        })));
        }))), .shown_p = prism_rtl::cat(crate::check::types::bare_name_f(n_p6), "(..)")}})));
        })
            : prism_rtl::is<crate::check::env::TyBody::BRowKind>(_m) ? is_root_module_f(env_p0x)
            ? prism_rtl::finished(std::optional(crate::prelude::each(tags_of_kind_f(env_p0x, n_p6), [&](const crate::check::env::TagInfo& tg_pe) { return tag_ctor_f(tg_pe); })))
            : prism_rtl::finished(std::optional<Array<Ctor>>{})
            : prism_rtl::finished(std::optional<Array<Ctor>>{});
        });
        })
            : prism_rtl::is_none(_m) ? (n_p6 == Text::lit("Fault")) || (n_p6 == Text::lit("Prelude.Fault"))
            ? is_root_module_f(env_p0x)
            ? prism_rtl::finished(std::optional(crate::prelude::each(tags_of_kind_f(env_p0x, Text::lit("Prelude.Fault")), [&](const crate::check::env::TagInfo& tg_pf) { return tag_ctor_f(tg_pf); })))
            : prism_rtl::finished(std::optional<Array<Ctor>>{})
            : prism_rtl::finished(std::optional<Array<Ctor>>{})
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::is<crate::check::types::Ty::TyElem>(walk_f_2900) ? ({
            auto&& rw_pg = prism_rtl::as<crate::check::types::Ty::TyElem>(walk_f_2900).a0;
            crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st_p1x, rw_pg), [=](crate::check::types::Rw walk_row_f_4329) {
            return ({
                auto w_ph = walk_row_f_4329;
                (prism_rtl::deref(w_ph).tail_p != crate::check::types::Tail(crate::check::types::Tail::TlClosed{})
                ? prism_rtl::finished(std::optional<Array<Ctor>>{})
                : prism_rtl::finished(std::optional(crate::prelude::each(tags_of_row_f(env_p0x, w_ph), [&](const crate::check::env::TagInfo& tg_pi) { return tag_ctor_f(tg_pi); }))));
            });
        });
        })
            : prism_rtl::is<crate::check::types::Ty::TyElemAny>(walk_f_2900) ? ({
            auto&& rw_pj = prism_rtl::as<crate::check::types::Ty::TyElemAny>(walk_f_2900).a0;
            crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st_p1x, rw_pj), [=](crate::check::types::Rw walk_row_f_4473) {
            return ({
                auto w_pk = walk_row_f_4473;
                (prism_rtl::deref(w_pk).tail_p != crate::check::types::Tail(crate::check::types::Tail::TlClosed{})
                ? prism_rtl::finished(std::optional<Array<Ctor>>{})
                : prism_rtl::finished(std::optional(crate::prelude::each(tags_of_row_f(env_p0x, w_pk), [&](const crate::check::env::TagInfo& tg_pl) { return tag_ctor_f(tg_pl); }))));
            });
        });
        })
            : prism_rtl::finished(std::optional<Array<Ctor>>{});
        });
    });
}


/// `Start CtorsOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Array<Ctor>>> start_ctors_of_o(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::types::Ty t_p2) {
    return prism_rtl::make_rc<CtorsOf>(env_p0, st_p1, t_p2);
}


/// CtorOfCase: unbounded fn TyInfo, Text, [Ty], [Ty] -> Ctor
Ctor ctor_of_case_f(const crate::check::env::TyInfo& ti_p0, const Text& cn_p1, const Array<crate::check::types::Ty>& cargs_p2, const Array<crate::check::types::Ty>& args_p3) {
    auto qk_p4 = crate::check::env::qual_key_f(ti_p0.home_p, cn_p1);
    return Ctor{.name_p = qk_p4, .arity_p = crate::prelude::len(cargs_p2), .args_p = crate::prelude::run_to_end(crate::prelude::each_job(cargs_p2, ({
        auto ti_p0x = ti_p0;
        auto args_p3x = args_p3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, ti_p0x = std::move(ti_p0x), args_p3x = std::move(args_p3x)](crate::check::types::Ty p0) {
        return ({
            auto ti_p0xy = ti_p0x;
            auto args_p3xy = args_p3x;
            (crate::prelude::entered(crate::prelude::once_job([=, ti_p0xy = std::move(ti_p0xy), args_p3xy = std::move(args_p3xy)]() {
            return ({
                auto a_p5 = p0;
                (prism_rtl::more(prism_rtl::rc(crate::check::types::schemes::SubstQ(crate::check::env::reading::param_inst_f(prism_rtl::deref(ti_p0xy).params_p, args_p3xy), a_p5))));
            });
        })));
        });
    })));
    }))), .shown_p = crate::prelude::len(cargs_p2) == Nat(0u)
        ? cn_p1
        : prism_rtl::cat(cn_p1, " ", crate::syntax::lexer::chars::join_f(crate::prelude::each(cargs_p2, [&](const crate::check::types::Ty& _p0) { return Text::lit("_"); }), Text::lit(", ")))};
}


prism_rtl::Turn<Ctor> CtorOfCase::cycle() const {
    const auto& ti_p0 = this->ti_p0;
    const auto& cn_p1 = this->cn_p1;
    const auto& cargs_p2 = this->cargs_p2;
    const auto& args_p3 = this->args_p3;
    auto qk_p4 = crate::check::env::qual_key_f(prism_rtl::deref(ti_p0).home_p, cn_p1);
    auto args_p3x = args_p3;
    auto cargs_p2x = cargs_p2;
    auto cn_p1x = cn_p1;
    auto ti_p0x = ti_p0;
    return crate::prelude::call_value(crate::prelude::each_job(cargs_p2x, ({
        auto ti_p0xx = ti_p0x;
        auto args_p3xx = args_p3x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, ti_p0xx = std::move(ti_p0xx), args_p3xx = std::move(args_p3xx)](crate::check::types::Ty p0) {
        return ({
            auto ti_p0xxy = ti_p0xx;
            auto args_p3xxy = args_p3xx;
            (crate::prelude::entered(crate::prelude::once_job([=, ti_p0xxy = std::move(ti_p0xxy), args_p3xxy = std::move(args_p3xxy)]() {
            return ({
                auto a_p5 = p0;
                (prism_rtl::more(prism_rtl::rc(crate::check::types::schemes::SubstQ(crate::check::env::reading::param_inst_f(prism_rtl::deref(ti_p0xxy).params_p, args_p3xxy), a_p5))));
            });
        })));
        });
    })));
    })), [=](Array<crate::check::types::Ty> each_4772) {
        return prism_rtl::finished(Ctor{.name_p = qk_p4, .arity_p = crate::prelude::len(cargs_p2x), .args_p = each_4772, .shown_p = crate::prelude::len(cargs_p2x) == Nat(0u)
            ? cn_p1x
            : prism_rtl::cat(cn_p1x, " ", crate::syntax::lexer::chars::join_f(crate::prelude::each(cargs_p2x, [&](const crate::check::types::Ty& _p0) { return Text::lit("_"); }), Text::lit(", ")))});
    });
}


/// `Start CtorOfCase, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ctor> start_ctor_of_case_f(crate::check::env::TyInfo ti_p0, Text cn_p1, Array<crate::check::types::Ty> cargs_p2, Array<crate::check::types::Ty> args_p3) {
    return prism_rtl::make_rc<CtorOfCase>(ti_p0, cn_p1, cargs_p2, args_p3);
}


/// TagCtor: fn TagInfo -> Ctor
Ctor tag_ctor_f(const crate::check::env::TagInfo& tg_p0) {
    return Ctor{.name_p = prism_rtl::cat("tag:", tg_p0.name_p), .arity_p = crate::prelude::len(tg_p0.fields_p), .args_p = crate::prelude::each(tg_p0.fields_p, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
        auto&& ft_p1 = std::get<1>(_p0);
        return crate::check::types::Ty(crate::check::types::Ty::TyErr{});
    }), .shown_p = tg_p0.name_p};
}


/// IsRootModule: fn Env -> Bool
bool is_root_module_f(const crate::check::expr::Env& env_p0) {
    return env_p0.home_p == Text::lit("");
}


/// TagsOfKind: fn Env, Text -> [TagInfo]
Array<crate::check::env::TagInfo> tags_of_kind_f(const crate::check::expr::Env& env_p0, const Text& kind_p1) {
    return crate::prelude::filter(crate::prelude::values(prism_rtl::deref(env_p0.g_p).tags_p), [&](const crate::check::env::TagInfo& tg_p2) { return (prism_rtl::deref(tg_p2).kind_p == kind_p1) || ((crate::check::types::bare_name_f(prism_rtl::deref(tg_p2).kind_p) == Text::lit("Fault")) && (crate::check::types::bare_name_f(kind_p1) == Text::lit("Fault"))); });
}


/// TagsOfRow: fn Env, Rw -> [TagInfo]
Array<crate::check::env::TagInfo> tags_of_row_f(const crate::check::expr::Env& env_p0, const crate::check::types::Rw& w_p1) {
    return crate::prelude::filter(crate::prelude::values(prism_rtl::deref(env_p0.g_p).tags_p), [&](const crate::check::env::TagInfo& tg_p2) { return ((prism_rtl::deref(tg_p2).kind_p == Text::lit("Element")) && crate::check::types::has_text_f(w_p1.fams_p, prism_rtl::deref(tg_p2).family_p)) && (!crate::check::types::has_text_f(w_p1.minus_p, prism_rtl::deref(tg_p2).name_p)); });
}


/// ToPat: unbounded fn Env, Pattern -> Pat
Pat to_pat_f(const crate::check::expr::Env& env_p0, const crate::syntax::Pattern_& p_p1) {
    auto&& _m = prism_rtl::deref(p_p1.kind_p);
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n_p2 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        auto bare_p3 = crate::prelude::or_(crate::prelude::index(prism_rtl::deref(n_p2).path_p, Nat(0u)), Text::lit(""));
        return (crate::prelude::len(prism_rtl::deref(n_p2).path_p) > Nat(1u)) && crate::check::env::has_key_f(prism_rtl::deref(env_p0.g_p).tags_p, crate::check::env::dotted_f(prism_rtl::deref(n_p2).path_p))
            ? Pat(Pat::PtCon{prism_rtl::cat("tag:", crate::check::env::dotted_f(prism_rtl::deref(n_p2).path_p)), Array<Pat>{}})
            : (crate::check::env::is_upper_text_f(bare_p3) && (crate::prelude::len_text(prism_rtl::deref(n_p2).sigils_p) == Nat(0u))) && crate::check::expr::patterns::is_ctor_name_f(env_p0, n_p2)
            ? Pat(Pat::PtCon{ctor_key_f(env_p0, n_p2), Array<Pat>{}})
            : Pat(Pat::PtAny{});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m)) {
        return Pat(Pat::PtAny{});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PLit>(_m)) {
        auto&& l_p4 = prism_rtl::as<crate::syntax::PatternKind::PLit>(_m).a0;
        return Pat(Pat::PtLit{lit_text_f(l_p4)});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PNeg>(_m)) {
        auto&& l_p5 = prism_rtl::as<crate::syntax::PatternKind::PNeg>(_m).a0;
        return Pat(Pat::PtLit{prism_rtl::cat("-", lit_text_f(l_p5))});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PUnit>(_m)) {
        return Pat(Pat::PtCon{Text::lit("unit"), Array<Pat>{}});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PNil>(_m)) {
        return Pat(Pat::PtCon{Text::lit("nil"), Array<Pat>{}});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PCtor>(_m)) {
        auto&& n_p6 = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a0;
        auto&& args_p7 = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a1;
        return crate::check::env::has_key_f(prism_rtl::deref(env_p0.g_p).tags_p, crate::check::env::dotted_f(prism_rtl::deref(n_p6).path_p))
            ? Pat(Pat::PtCon{prism_rtl::cat("tag:", crate::check::env::dotted_f(prism_rtl::deref(n_p6).path_p)), Array<Pat>{}})
            : Pat(Pat::PtCon{ctor_key_f(env_p0, n_p6), crate::prelude::run_to_end(crate::prelude::each_job(args_p7, ({
            auto env_p0x = env_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(crate::syntax::Pattern_)>>(prism_rtl::rc([=, env_p0x = std::move(env_p0x)](crate::syntax::Pattern_ p0) {
            return ({
                auto env_p0xy = env_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, env_p0xy = std::move(env_p0xy)]() {
                return ({
                    auto a_p8 = p0;
                    (prism_rtl::more(prism_rtl::rc(ToPat(env_p0xy, a_p8))));
                });
            })));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PRecord>(_m)) {
        auto&& n_p9 = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a0;
        auto&& fields_pa = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a1;
        return record_pat_f(env_p0, n_p9, fields_pa);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m)) {
        auto&& s_pb = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& q_pc = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        return Pat(Pat::PtCon{s_pb, Array(std::vector{to_pat_f(env_p0, prism_rtl::deref(prism_rtl::deref(q_pc)))})});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m)) {
        auto&& ps_pd = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        return Pat(Pat::PtCon{Text::lit("tuple"), crate::prelude::run_to_end(crate::prelude::each_job(ps_pd, ({
            auto env_p0x = env_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(crate::syntax::Pattern_)>>(prism_rtl::rc([=, env_p0x = std::move(env_p0x)](crate::syntax::Pattern_ p0) {
            return ({
                auto env_p0xy = env_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, env_p0xy = std::move(env_p0xy)]() {
                return ({
                    auto q_pe = p0;
                    (prism_rtl::more(prism_rtl::rc(ToPat(env_p0xy, q_pe))));
                });
            })));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PArray>(_m)) {
        auto&& ps_pf = prism_rtl::as<crate::syntax::PatternKind::PArray>(_m).a0;
        return Pat(Pat::PtCon{prism_rtl::cat("len", crate::prelude::len(ps_pf)), crate::prelude::run_to_end(crate::prelude::each_job(ps_pf, ({
            auto env_p0x = env_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(crate::syntax::Pattern_)>>(prism_rtl::rc([=, env_p0x = std::move(env_p0x)](crate::syntax::Pattern_ p0) {
            return ({
                auto env_p0xy = env_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, env_p0xy = std::move(env_p0xy)]() {
                return ({
                    auto q_pg = p0;
                    (prism_rtl::more(prism_rtl::rc(ToPat(env_p0xy, q_pg))));
                });
            })));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q_ph = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return to_pat_f(env_p0, prism_rtl::deref(prism_rtl::deref(q_ph)));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PFamily>(_m)) {
        auto&& q_pi = prism_rtl::as<crate::syntax::PatternKind::PFamily>(_m).a0;
        return Pat(Pat::PtFam{crate::check::env::dotted_f(prism_rtl::deref(q_pi).path_p)});
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Pat> ToPat::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& p_p1 = this->p_p1;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p1).kind_p);
        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n_p2 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        ({
        auto bare_p3 = crate::prelude::or_(crate::prelude::index(prism_rtl::deref(n_p2).path_p, Nat(0u)), Text::lit(""));
        (crate::prelude::len(prism_rtl::deref(n_p2).path_p) > Nat(1u)) && crate::check::env::has_key_f(prism_rtl::deref(prism_rtl::deref(env_p0).g_p).tags_p, crate::check::env::dotted_f(prism_rtl::deref(n_p2).path_p))
        ? prism_rtl::finished(Pat(Pat::PtCon{prism_rtl::cat("tag:", crate::check::env::dotted_f(prism_rtl::deref(n_p2).path_p)), Array<Pat>{}}))
        : (crate::check::env::is_upper_text_f(bare_p3) && (crate::prelude::len_text(prism_rtl::deref(n_p2).sigils_p) == Nat(0u))) && crate::check::expr::patterns::is_ctor_name_f(env_p0, n_p2)
        ? prism_rtl::finished(Pat(Pat::PtCon{ctor_key_f(env_p0, n_p2), Array<Pat>{}}))
        : prism_rtl::finished(Pat(Pat::PtAny{}));
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m) ? prism_rtl::finished(Pat(Pat::PtAny{}))
        : prism_rtl::is<crate::syntax::PatternKind::PLit>(_m) ? ({
        auto&& l_p4 = prism_rtl::as<crate::syntax::PatternKind::PLit>(_m).a0;
        prism_rtl::finished(Pat(Pat::PtLit{lit_text_f(l_p4)}));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PNeg>(_m) ? ({
        auto&& l_p5 = prism_rtl::as<crate::syntax::PatternKind::PNeg>(_m).a0;
        prism_rtl::finished(Pat(Pat::PtLit{prism_rtl::cat("-", lit_text_f(l_p5))}));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PUnit>(_m) ? prism_rtl::finished(Pat(Pat::PtCon{Text::lit("unit"), Array<Pat>{}}))
        : prism_rtl::is<crate::syntax::PatternKind::PNil>(_m) ? prism_rtl::finished(Pat(Pat::PtCon{Text::lit("nil"), Array<Pat>{}}))
        : prism_rtl::is<crate::syntax::PatternKind::PCtor>(_m) ? ({
        auto&& n_p6 = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a0;
        auto&& args_p7 = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a1;
        crate::check::env::has_key_f(prism_rtl::deref(prism_rtl::deref(env_p0).g_p).tags_p, crate::check::env::dotted_f(prism_rtl::deref(n_p6).path_p))
        ? prism_rtl::finished(Pat(Pat::PtCon{prism_rtl::cat("tag:", crate::check::env::dotted_f(prism_rtl::deref(n_p6).path_p)), Array<Pat>{}}))
        : ({
        auto args_p7x = args_p7;
        auto env_p0x = env_p0;
        auto n_p6x = n_p6;
        (crate::prelude::call_value(crate::prelude::each_job(args_p7x, ({
        auto env_p0xx = env_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(crate::syntax::Pattern_)>>(prism_rtl::rc([=, env_p0xx = std::move(env_p0xx)](crate::syntax::Pattern_ p0) {
        return ({
            auto env_p0xxy = env_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, env_p0xxy = std::move(env_p0xxy)]() {
            return ({
                auto a_p8 = p0;
                (prism_rtl::more(prism_rtl::rc(ToPat(env_p0xxy, a_p8))));
            });
        })));
        });
    })));
    })), [=, n_p6x = std::move(n_p6x)](Array<Pat> each_6274) { return prism_rtl::finished(Pat(Pat::PtCon{ctor_key_f(env_p0x, n_p6x), each_6274})); }));
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PRecord>(_m) ? ({
        auto&& n_p9 = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a0;
        auto&& fields_pa = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a1;
        prism_rtl::more(prism_rtl::rc(RecordPat(env_p0, n_p9, fields_pa)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m) ? ({
        auto&& s_pb = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& q_pc = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        ({
        auto env_p0x = env_p0;
        auto q_pcx = prism_rtl::deref(prism_rtl::deref(q_pc));
        auto s_pbx = s_pb;
        (crate::prelude::call_then(start_to_pat_f(env_p0x, q_pcx), [=, s_pbx = std::move(s_pbx)](Pat to_pat_f_6389) { return prism_rtl::finished(Pat(Pat::PtCon{s_pbx, Array(std::vector{to_pat_f_6389})})); }));
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m) ? ({
        auto&& ps_pd = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        ({
        auto env_p0x = env_p0;
        auto ps_pdx = ps_pd;
        (crate::prelude::call_value(crate::prelude::each_job(ps_pdx, ({
        auto env_p0xx = env_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(crate::syntax::Pattern_)>>(prism_rtl::rc([=, env_p0xx = std::move(env_p0xx)](crate::syntax::Pattern_ p0) {
        return ({
            auto env_p0xxy = env_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, env_p0xxy = std::move(env_p0xxy)]() {
            return ({
                auto q_pe = p0;
                (prism_rtl::more(prism_rtl::rc(ToPat(env_p0xxy, q_pe))));
            });
        })));
        });
    })));
    })), [=](Array<Pat> each_6436) { return prism_rtl::finished(Pat(Pat::PtCon{Text::lit("tuple"), each_6436})); }));
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PArray>(_m) ? ({
        auto&& ps_pf = prism_rtl::as<crate::syntax::PatternKind::PArray>(_m).a0;
        ({
        auto env_p0x = env_p0;
        auto ps_pfx = ps_pf;
        (crate::prelude::call_value(crate::prelude::each_job(ps_pfx, ({
        auto env_p0xx = env_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(crate::syntax::Pattern_)>>(prism_rtl::rc([=, env_p0xx = std::move(env_p0xx)](crate::syntax::Pattern_ p0) {
        return ({
            auto env_p0xxy = env_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, env_p0xxy = std::move(env_p0xxy)]() {
            return ({
                auto q_pg = p0;
                (prism_rtl::more(prism_rtl::rc(ToPat(env_p0xxy, q_pg))));
            });
        })));
        });
    })));
    })), [=](Array<Pat> each_6501) { return prism_rtl::finished(Pat(Pat::PtCon{prism_rtl::cat("len", crate::prelude::len(ps_pfx)), each_6501})); }));
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m) ? ({
        auto&& q_ph = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ToPat(env_p0, prism_rtl::deref(prism_rtl::deref(q_ph)))));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PFamily>(_m) ? ({
        auto&& q_pi = prism_rtl::as<crate::syntax::PatternKind::PFamily>(_m).a0;
        prism_rtl::finished(Pat(Pat::PtFam{crate::check::env::dotted_f(prism_rtl::deref(q_pi).path_p)}));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ToPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Pat> start_to_pat_f(crate::check::expr::Env env_p0, crate::syntax::Pattern_ p_p1) {
    return prism_rtl::make_rc<ToPat>(env_p0, p_p1);
}


/// LitText: fn Literal -> Text
Text lit_text_f(const crate::syntax::Literal& l_p0) {
    auto&& _m = l_p0.kind_p;
    if (prism_rtl::is<crate::syntax::LitKind::LInt>(_m)) {
        auto&& d_p1 = prism_rtl::as<crate::syntax::LitKind::LInt>(_m).a0;
        return d_p1;
    }
    if (prism_rtl::is<crate::syntax::LitKind::LFloat>(_m)) {
        auto&& d_p2 = prism_rtl::as<crate::syntax::LitKind::LFloat>(_m).a0;
        return d_p2;
    }
    if (prism_rtl::is<crate::syntax::LitKind::LChar>(_m)) {
        auto&& c_p3 = prism_rtl::as<crate::syntax::LitKind::LChar>(_m).a0;
        return prism_rtl::cat("\'", c_p3, "\'");
    }
    if (prism_rtl::is<crate::syntax::LitKind::LText>(_m)) {
        auto&& segs_p4 = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
        return crate::prelude::concat(crate::prelude::each(segs_p4, lit_seg_text_f));
    }
    if (prism_rtl::is<crate::syntax::LitKind::LDuration>(_m)) {
        auto&& d_p5 = prism_rtl::as<crate::syntax::LitKind::LDuration>(_m).a0;
        auto&& u_p6 = prism_rtl::as<crate::syntax::LitKind::LDuration>(_m).a1;
        return prism_rtl::cat(d_p5, u_p6);
    }
    if (prism_rtl::is<crate::syntax::LitKind::LRegex>(_m)) {
        auto&& r_p7 = prism_rtl::as<crate::syntax::LitKind::LRegex>(_m).a0;
        return prism_rtl::cat("%/", prism_rtl::deref(r_p7).pattern_p, "/");
    }
    prism_rtl::unreachable("no arm matched");
}


/// LitSegText: fn TextSeg -> Text
Text lit_seg_text_f(const crate::syntax::TextSeg& text_seg0) {
    if (prism_rtl::is<crate::syntax::TextSeg::SegPlain>(text_seg0)) {
        auto&& t_p0 = prism_rtl::as<crate::syntax::TextSeg::SegPlain>(text_seg0).a0;
        return t_p0;
    }
    {
        return Text::lit("{}");
    }
}


/// CtorKey: fn Env, SName -> Text
Text ctor_key_f(const crate::check::expr::Env& env_p0, const crate::syntax::SName& n_p1) {
    auto&& _qk_o2 = crate::check::env::names::resolve_value_f(env_p0.g_p, env_p0.home_p, n_p1);
    auto&& qk_o2 = std::get<0>(_qk_o2);
    return crate::prelude::or_(qk_o2, crate::check::env::sname_key_f(n_p1));
}


/// RecordPat: unbounded fn Env, SName, [FieldPat] -> Pat
Pat record_pat_f(const crate::check::expr::Env& env_p0, const crate::syntax::SName& n_p1, const Array<crate::syntax::FieldPat>& fields_p2) {
    auto name_p3 = crate::check::env::dotted_f(n_p1.path_p);
    auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0.g_p).tags_p, name_p3);
    if (prism_rtl::is_some(_m)) {
        auto&& tg_p4 = prism_rtl::some_of(_m);
        auto names_p5 = crate::prelude::each(prism_rtl::deref(tg_p4).fields_p, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
            auto&& f_p6 = std::get<0>(_p0);
            return f_p6;
        });
        return Pat(Pat::PtCon{prism_rtl::cat("tag:", name_p3), crate::prelude::run_to_end(crate::prelude::each_job(names_p5, ({
            auto env_p0x = env_p0;
            auto fields_p2x = fields_p2;
            auto names_p5x = names_p5;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(Text)>>(prism_rtl::rc([=, env_p0x = std::move(env_p0x), fields_p2x = std::move(fields_p2x), names_p5x = std::move(names_p5x)](Text p0) {
            return ({
                auto env_p0xy = env_p0x;
                auto fields_p2xy = fields_p2x;
                auto names_p5xy = names_p5x;
                (crate::prelude::entered(crate::prelude::once_job([=, env_p0xy = std::move(env_p0xy), fields_p2xy = std::move(fields_p2xy), names_p5xy = std::move(names_p5xy)]() {
                return ({
                    auto f_p7 = p0;
                    (prism_rtl::more(prism_rtl::rc(FieldPatFor(env_p0xy, fields_p2xy, names_p5xy, f_p7))));
                });
            })));
            });
        })));
        })))});
    }
    if (prism_rtl::is_none(_m)) {
        auto qk_p8 = ctor_key_f(env_p0, n_p1);
        auto fnames_p9 = crate::check::types::bare_name_f(qk_p8) == Text::lit("Error")
            ? Array(std::vector{Text::lit("kind"), Text::lit("message")})
            : prism_rtl::deref(crate::prelude::or_(crate::prelude::get(prism_rtl::deref(env_p0.g_p).ctors_p, qk_p8), dummy_ctor_p())).fields_p;
        auto pkey_pa = crate::check::types::bare_name_f(qk_p8) == Text::lit("Error")
            ? Text::lit("Error")
            : qk_p8;
        return Pat(Pat::PtCon{pkey_pa, crate::prelude::run_to_end(crate::prelude::each_job(fnames_p9, ({
            auto env_p0x = env_p0;
            auto fields_p2x = fields_p2;
            auto fnames_p9x = fnames_p9;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(Text)>>(prism_rtl::rc([=, env_p0x = std::move(env_p0x), fields_p2x = std::move(fields_p2x), fnames_p9x = std::move(fnames_p9x)](Text p0) {
            return ({
                auto env_p0xy = env_p0x;
                auto fields_p2xy = fields_p2x;
                auto fnames_p9xy = fnames_p9x;
                (crate::prelude::entered(crate::prelude::once_job([=, env_p0xy = std::move(env_p0xy), fields_p2xy = std::move(fields_p2xy), fnames_p9xy = std::move(fnames_p9xy)]() {
                return ({
                    auto f_pb = p0;
                    (prism_rtl::more(prism_rtl::rc(FieldPatFor(env_p0xy, fields_p2xy, fnames_p9xy, f_pb))));
                });
            })));
            });
        })));
        })))});
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Pat> RecordPat::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& n_p1 = this->n_p1;
    const auto& fields_p2 = this->fields_p2;
    auto name_p3 = crate::check::env::dotted_f(prism_rtl::deref(n_p1).path_p);
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env_p0).g_p).tags_p, name_p3);
        prism_rtl::is_some(_m) ? ({
        auto&& tg_p4 = prism_rtl::some_of(_m);
        ({
        auto names_p5 = crate::prelude::each(prism_rtl::deref(tg_p4).fields_p, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
            auto&& f_p6 = std::get<0>(_p0);
            return f_p6;
        });
        auto env_p0x = env_p0;
        auto fields_p2x = fields_p2;
        (crate::prelude::call_value(crate::prelude::each_job(names_p5, ({
        auto env_p0xx = env_p0x;
        auto fields_p2xx = fields_p2x;
        auto names_p5x = names_p5;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(Text)>>(prism_rtl::rc([=, env_p0xx = std::move(env_p0xx), fields_p2xx = std::move(fields_p2xx), names_p5x = std::move(names_p5x)](Text p0) {
        return ({
            auto env_p0xxy = env_p0xx;
            auto fields_p2xxy = fields_p2xx;
            auto names_p5xy = names_p5x;
            (crate::prelude::entered(crate::prelude::once_job([=, env_p0xxy = std::move(env_p0xxy), fields_p2xxy = std::move(fields_p2xxy), names_p5xy = std::move(names_p5xy)]() {
            return ({
                auto f_p7 = p0;
                (prism_rtl::more(prism_rtl::rc(FieldPatFor(env_p0xxy, fields_p2xxy, names_p5xy, f_p7))));
            });
        })));
        });
    })));
    })), [=](Array<Pat> each_7371) { return prism_rtl::finished(Pat(Pat::PtCon{prism_rtl::cat("tag:", name_p3), each_7371})); }));
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto qk_p8 = ctor_key_f(env_p0, n_p1);
        auto fnames_p9 = crate::check::types::bare_name_f(qk_p8) == Text::lit("Error")
            ? Array(std::vector{Text::lit("kind"), Text::lit("message")})
            : prism_rtl::deref(crate::prelude::or_(crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env_p0).g_p).ctors_p, qk_p8), dummy_ctor_p())).fields_p;
        auto pkey_pa = crate::check::types::bare_name_f(qk_p8) == Text::lit("Error")
            ? Text::lit("Error")
            : qk_p8;
        auto env_p0x = env_p0;
        auto fields_p2x = fields_p2;
        (crate::prelude::call_value(crate::prelude::each_job(fnames_p9, ({
        auto env_p0xx = env_p0x;
        auto fields_p2xx = fields_p2x;
        auto fnames_p9x = fnames_p9;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(Text)>>(prism_rtl::rc([=, env_p0xx = std::move(env_p0xx), fields_p2xx = std::move(fields_p2xx), fnames_p9x = std::move(fnames_p9x)](Text p0) {
        return ({
            auto env_p0xxy = env_p0xx;
            auto fields_p2xxy = fields_p2xx;
            auto fnames_p9xy = fnames_p9x;
            (crate::prelude::entered(crate::prelude::once_job([=, env_p0xxy = std::move(env_p0xxy), fields_p2xxy = std::move(fields_p2xxy), fnames_p9xy = std::move(fnames_p9xy)]() {
            return ({
                auto f_pb = p0;
                (prism_rtl::more(prism_rtl::rc(FieldPatFor(env_p0xxy, fields_p2xxy, fnames_p9xy, f_pb))));
            });
        })));
        });
    })));
    })), [=, pkey_pa = std::move(pkey_pa)](Array<Pat> each_7687) { return prism_rtl::finished(Pat(Pat::PtCon{pkey_pa, each_7687})); }));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start RecordPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Pat> start_record_pat_f(crate::check::expr::Env env_p0, crate::syntax::SName n_p1, Array<crate::syntax::FieldPat> fields_p2) {
    return prism_rtl::make_rc<RecordPat>(env_p0, n_p1, fields_p2);
}


/// let dummyCtor
crate::check::env::CtorInfo dummy_ctor_p() {
    return crate::check::env::CtorInfo{.name_p = Text::lit(""), .owner_p = Text::lit(""), .params_p = Array<Text>{}, .args_p = Array<crate::check::types::Ty>{}, .fields_p = Array<Text>{}, .ty_p = crate::check::types::Ty(crate::check::types::Ty::TyErr{}), .index_p = Nat(0u)};
}


/// FieldPatFor: unbounded fn Env, [FieldPat], [Text], Text -> Pat
Pat field_pat_for_f(const crate::check::expr::Env& env_p0, const Array<crate::syntax::FieldPat>& fields_p1, const Array<Text>& names_p2, const Text& f_p3) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(fields_p1)), Pat(Pat::PtAny{}), ({
        auto fields_p1x = fields_p1;
        auto names_p2x = names_p2;
        auto f_p3x = f_p3;
        auto env_p0x = env_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(std::tuple<Pat, Nat>)>>(prism_rtl::rc([=, fields_p1x = std::move(fields_p1x), names_p2x = std::move(names_p2x), f_p3x = std::move(f_p3x), env_p0x = std::move(env_p0x)](std::tuple<Pat, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto fields_p1xy = fields_p1x;
            auto names_p2xy = names_p2x;
            auto f_p3xy = f_p3x;
            auto env_p0xy = env_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, fields_p1xy = std::move(fields_p1xy), names_p2xy = std::move(names_p2xy), f_p3xy = std::move(f_p3xy), env_p0xy = std::move(env_p0xy)]() {
            return ({
                auto acc_p4 = p0;
                auto i_p5 = p1;
                ({
                auto&& _m = crate::prelude::index(fields_p1xy, i_p5);
                prism_rtl::is_some(_m) ? ({
                auto&& fp_p6 = prism_rtl::some_of(_m);
                crate::check::expr::patterns::field_pat_name_f(fp_p6, names_p2xy, i_p5) == f_p3xy
                ? prism_rtl::more(prism_rtl::rc(ToPat(env_p0xy, prism_rtl::deref(fp_p6).pattern_p)))
                : prism_rtl::finished(acc_p4);
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(acc_p4)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        })));
        });
    })));
    })));
}


prism_rtl::Turn<Pat> FieldPatFor::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& fields_p1 = this->fields_p1;
    const auto& names_p2 = this->names_p2;
    const auto& f_p3 = this->f_p3;
    return crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(fields_p1)), Pat(Pat::PtAny{}), ({
        auto fields_p1x = fields_p1;
        auto names_p2x = names_p2;
        auto f_p3x = f_p3;
        auto env_p0x = env_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(std::tuple<Pat, Nat>)>>(prism_rtl::rc([=, fields_p1x = std::move(fields_p1x), names_p2x = std::move(names_p2x), f_p3x = std::move(f_p3x), env_p0x = std::move(env_p0x)](std::tuple<Pat, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto fields_p1xy = fields_p1x;
            auto names_p2xy = names_p2x;
            auto f_p3xy = f_p3x;
            auto env_p0xy = env_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, fields_p1xy = std::move(fields_p1xy), names_p2xy = std::move(names_p2xy), f_p3xy = std::move(f_p3xy), env_p0xy = std::move(env_p0xy)]() {
            return ({
                auto acc_p4 = p0;
                auto i_p5 = p1;
                ({
                auto&& _m = crate::prelude::index(fields_p1xy, i_p5);
                prism_rtl::is_some(_m) ? ({
                auto&& fp_p6 = prism_rtl::some_of(_m);
                crate::check::expr::patterns::field_pat_name_f(fp_p6, names_p2xy, i_p5) == f_p3xy
                ? prism_rtl::more(prism_rtl::rc(ToPat(env_p0xy, prism_rtl::deref(fp_p6).pattern_p)))
                : prism_rtl::finished(acc_p4);
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(acc_p4)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        })));
        });
    })));
    }))->cycle();
}


/// `Start FieldPatFor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Pat> start_field_pat_for_f(crate::check::expr::Env env_p0, Array<crate::syntax::FieldPat> fields_p1, Array<Text> names_p2, Text f_p3) {
    return prism_rtl::make_rc<FieldPatFor>(env_p0, fields_p1, names_p2, f_p3);
}


/// Useful: unbounded fn Env, St, [ [Pat] ], [Pat], [Ty] -> Bool
bool useful_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Array<Array<Pat>>& rows_p2, const Array<Pat>& q_p3, const Array<crate::check::types::Ty>& tys_p4) {
    auto&& _m = crate::prelude::index(q_p3, Nat(0u));
    if (prism_rtl::is_none(_m)) {
        return crate::prelude::len(rows_p2) == Nat(0u);
    }
    if (prism_rtl::is_some(_m)) {
        auto&& q1_p5 = prism_rtl::some_of(_m);
        auto t1_p6 = crate::prelude::or_(crate::prelude::index(tys_p4, Nat(0u)), crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
        auto rest_p7 = crate::prelude::drop(tys_p4, Nat(1u));
        if (prism_rtl::is<Pat::PtCon>(q1_p5)) {
            auto&& c_p8 = prism_rtl::as<Pat::PtCon>(q1_p5).a0;
            auto&& args_p9 = prism_rtl::as<Pat::PtCon>(q1_p5).a1;
            auto ctor_pa = ctor_named_f(env_p0, st_p1, t1_p6, c_p8, crate::prelude::len(args_p9));
            return useful_f(env_p0, st_p1, specialize_f(rows_p2, ctor_pa), crate::prelude::append(args_p9, crate::prelude::drop(q_p3, Nat(1u))), crate::prelude::append(prism_rtl::deref(ctor_pa).args_p, rest_p7));
        }
        if (prism_rtl::is<Pat::PtLit>(q1_p5)) {
            auto&& l_pb = prism_rtl::as<Pat::PtLit>(q1_p5).a0;
            return useful_f(env_p0, st_p1, specialize_lit_f(rows_p2, l_pb), crate::prelude::drop(q_p3, Nat(1u)), rest_p7);
        }
        if (prism_rtl::is<Pat::PtFam>(q1_p5)) {
            auto&& f_pc = prism_rtl::as<Pat::PtFam>(q1_p5).a0;
            auto&& _m = ctors_of_o(env_p0, st_p1, t1_p6);
            if (prism_rtl::is_some(_m)) {
                auto&& cs_pd = prism_rtl::some_of(_m);
                return crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::filter(cs_pd, [&](const Ctor& c_pe) { return ctor_family_f(c_pe) == f_pc; }), false, ({
                    auto env_p0x = env_p0;
                    auto st_p1x = st_p1;
                    auto rows_p2x = rows_p2;
                    auto q_p3x = q_p3;
                    auto rest_p7x = rest_p7;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Ctor>)>>(prism_rtl::rc([=, env_p0x = std::move(env_p0x), st_p1x = std::move(st_p1x), rows_p2x = std::move(rows_p2x), q_p3x = std::move(q_p3x), rest_p7x = std::move(rest_p7x)](std::tuple<bool, Ctor> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto env_p0xy = env_p0x;
                        auto st_p1xy = st_p1x;
                        auto rows_p2xy = rows_p2x;
                        auto q_p3xy = q_p3x;
                        auto rest_p7xy = rest_p7x;
                        (crate::prelude::entered(crate::prelude::once_job([=, env_p0xy = std::move(env_p0xy), st_p1xy = std::move(st_p1xy), rows_p2xy = std::move(rows_p2xy), q_p3xy = std::move(q_p3xy), rest_p7xy = std::move(rest_p7xy)]() {
                        return ({
                            auto seen_pf = p0;
                            auto c_pg = p1;
                            (prism_rtl::finished(std::move(seen_pf) || useful_f(env_p0xy, st_p1xy, specialize_f(rows_p2xy, c_pg), crate::prelude::append(wilds_f(prism_rtl::deref(c_pg).arity_p), crate::prelude::drop(q_p3xy, Nat(1u))), crate::prelude::append(prism_rtl::deref(c_pg).args_p, rest_p7xy))));
                        });
                    })));
                    });
                })));
                })));
            }
            if (prism_rtl::is_none(_m)) {
                return useful_f(env_p0, st_p1, default_rows_f(rows_p2), crate::prelude::drop(q_p3, Nat(1u)), rest_p7);
            }
            prism_rtl::unreachable("no arm matched");
        }
        if (prism_rtl::is<Pat::PtAny>(q1_p5)) {
            auto heads_ph = head_names_f(rows_p2);
            auto&& _m = ctors_of_o(env_p0, st_p1, t1_p6);
            if (prism_rtl::is_some(_m)) {
                auto&& cs_pi = prism_rtl::some_of(_m);
                return complete_f(cs_pi, heads_ph, rows_p2)
                    ? crate::prelude::run_to_end(crate::prelude::fold_job(cs_pi, false, ({
                    auto env_p0x = env_p0;
                    auto st_p1x = st_p1;
                    auto rows_p2x = rows_p2;
                    auto q_p3x = q_p3;
                    auto rest_p7x = rest_p7;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Ctor>)>>(prism_rtl::rc([=, env_p0x = std::move(env_p0x), st_p1x = std::move(st_p1x), rows_p2x = std::move(rows_p2x), q_p3x = std::move(q_p3x), rest_p7x = std::move(rest_p7x)](std::tuple<bool, Ctor> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto env_p0xy = env_p0x;
                        auto st_p1xy = st_p1x;
                        auto rows_p2xy = rows_p2x;
                        auto q_p3xy = q_p3x;
                        auto rest_p7xy = rest_p7x;
                        (crate::prelude::entered(crate::prelude::once_job([=, env_p0xy = std::move(env_p0xy), st_p1xy = std::move(st_p1xy), rows_p2xy = std::move(rows_p2xy), q_p3xy = std::move(q_p3xy), rest_p7xy = std::move(rest_p7xy)]() {
                        return ({
                            auto seen_pj = p0;
                            auto c_pk = p1;
                            (prism_rtl::finished(std::move(seen_pj) || useful_f(env_p0xy, st_p1xy, specialize_f(rows_p2xy, c_pk), crate::prelude::append(wilds_f(prism_rtl::deref(c_pk).arity_p), crate::prelude::drop(q_p3xy, Nat(1u))), crate::prelude::append(prism_rtl::deref(c_pk).args_p, rest_p7xy))));
                        });
                    })));
                    });
                })));
                })))
                    : useful_f(env_p0, st_p1, default_rows_f(rows_p2), crate::prelude::drop(q_p3, Nat(1u)), rest_p7);
            }
            if (prism_rtl::is_none(_m)) {
                return useful_f(env_p0, st_p1, default_rows_f(rows_p2), crate::prelude::drop(q_p3, Nat(1u)), rest_p7);
            }
            prism_rtl::unreachable("no arm matched");
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> Useful::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& rows_p2 = this->rows_p2;
    const auto& q_p3 = this->q_p3;
    const auto& tys_p4 = this->tys_p4;
    return ({
        auto&& _m = crate::prelude::index(q_p3, Nat(0u));
        prism_rtl::is_none(_m) ? prism_rtl::finished(crate::prelude::len(rows_p2) == Nat(0u))
        : prism_rtl::is_some(_m) ? ({
        auto&& q1_p5 = prism_rtl::some_of(_m);
        ({
        auto t1_p6 = crate::prelude::or_(crate::prelude::index(tys_p4, Nat(0u)), crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
        auto rest_p7 = crate::prelude::drop(tys_p4, Nat(1u));
        ({
        prism_rtl::is<Pat::PtCon>(q1_p5) ? ({
        auto&& c_p8 = prism_rtl::as<Pat::PtCon>(q1_p5).a0;
        auto&& args_p9 = prism_rtl::as<Pat::PtCon>(q1_p5).a1;
        ({
        auto args_p9x = args_p9;
        auto c_p8x = c_p8;
        auto env_p0x = env_p0;
        auto q_p3x = q_p3;
        auto rows_p2x = rows_p2;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(start_ctor_named_f(env_p0x, st_p1x, t1_p6, c_p8x, crate::prelude::len(args_p9x)), [=, q_p3x = std::move(q_p3x), rows_p2x = std::move(rows_p2x)](Ctor ctor_named_f_8483) {
        return ({
            auto ctor_pa = ctor_named_f_8483;
            (prism_rtl::more(prism_rtl::rc(Useful(env_p0x, st_p1x, specialize_f(rows_p2x, ctor_pa), crate::prelude::append(args_p9x, crate::prelude::drop(q_p3x, Nat(1u))), crate::prelude::append(prism_rtl::deref(ctor_pa).args_p, rest_p7)))));
        });
    }));
    });
    })
        : prism_rtl::is<Pat::PtLit>(q1_p5) ? ({
        auto&& l_pb = prism_rtl::as<Pat::PtLit>(q1_p5).a0;
        prism_rtl::more(prism_rtl::rc(Useful(env_p0, st_p1, specialize_lit_f(rows_p2, l_pb), crate::prelude::drop(q_p3, Nat(1u)), rest_p7)));
    })
        : prism_rtl::is<Pat::PtFam>(q1_p5) ? ({
        auto&& f_pc = prism_rtl::as<Pat::PtFam>(q1_p5).a0;
        ({
        auto env_p0x = env_p0;
        auto f_pcx = f_pc;
        auto q_p3x = q_p3;
        auto rows_p2x = rows_p2;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(start_ctors_of_o(env_p0x, st_p1x, t1_p6), [=, f_pcx = std::move(f_pcx), q_p3x = std::move(q_p3x), rows_p2x = std::move(rows_p2x)](std::optional<Array<Ctor>> ctors_of_o_8737) {
        return ({
            prism_rtl::is_some(ctors_of_o_8737) ? ({
            auto&& cs_pd = prism_rtl::some_of(ctors_of_o_8737);
            crate::prelude::fold_job(crate::prelude::filter(cs_pd, [&](const Ctor& c_pe) { return ctor_family_f(c_pe) == f_pcx; }), false, ({
            auto env_p0xx = env_p0x;
            auto st_p1xx = st_p1x;
            auto rows_p2xx = rows_p2x;
            auto q_p3xx = q_p3x;
            auto rest_p7x = rest_p7;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Ctor>)>>(prism_rtl::rc([=, env_p0xx = std::move(env_p0xx), st_p1xx = std::move(st_p1xx), rows_p2xx = std::move(rows_p2xx), q_p3xx = std::move(q_p3xx), rest_p7x = std::move(rest_p7x)](std::tuple<bool, Ctor> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env_p0xxy = env_p0xx;
                auto st_p1xxy = st_p1xx;
                auto rows_p2xxy = rows_p2xx;
                auto q_p3xxy = q_p3xx;
                auto rest_p7xy = rest_p7x;
                (crate::prelude::entered(crate::prelude::once_job([=, env_p0xxy = std::move(env_p0xxy), st_p1xxy = std::move(st_p1xxy), rows_p2xxy = std::move(rows_p2xxy), q_p3xxy = std::move(q_p3xxy), rest_p7xy = std::move(rest_p7xy)]() {
                return ({
                    auto seen_pf = p0;
                    auto c_pg = p1;
                    (prism_rtl::finished(std::move(seen_pf) || useful_f(env_p0xxy, st_p1xxy, specialize_f(rows_p2xxy, c_pg), crate::prelude::append(wilds_f(prism_rtl::deref(c_pg).arity_p), crate::prelude::drop(q_p3xxy, Nat(1u))), crate::prelude::append(prism_rtl::deref(c_pg).args_p, rest_p7xy))));
                });
            })));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is_none(ctors_of_o_8737) ? prism_rtl::more(prism_rtl::rc(Useful(env_p0x, st_p1x, default_rows_f(rows_p2x), crate::prelude::drop(q_p3x, Nat(1u)), rest_p7)))
            : throw prism_rtl::Panic("no arm matched");
        });
    }));
    });
    })
        : prism_rtl::is<Pat::PtAny>(q1_p5) ? ({
        auto heads_ph = head_names_f(rows_p2);
        auto env_p0x = env_p0;
        auto q_p3x = q_p3;
        auto rows_p2x = rows_p2;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(start_ctors_of_o(env_p0x, st_p1x, t1_p6), [=, heads_ph = std::move(heads_ph), q_p3x = std::move(q_p3x), rows_p2x = std::move(rows_p2x)](std::optional<Array<Ctor>> ctors_of_o_9109) {
        return ({
            prism_rtl::is_some(ctors_of_o_9109) ? ({
            auto&& cs_pi = prism_rtl::some_of(ctors_of_o_9109);
            complete_f(cs_pi, heads_ph, rows_p2x)
            ? crate::prelude::fold_job(cs_pi, false, ({
            auto env_p0xx = env_p0x;
            auto st_p1xx = st_p1x;
            auto rows_p2xx = rows_p2x;
            auto q_p3xx = q_p3x;
            auto rest_p7x = rest_p7;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Ctor>)>>(prism_rtl::rc([=, env_p0xx = std::move(env_p0xx), st_p1xx = std::move(st_p1xx), rows_p2xx = std::move(rows_p2xx), q_p3xx = std::move(q_p3xx), rest_p7x = std::move(rest_p7x)](std::tuple<bool, Ctor> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env_p0xxy = env_p0xx;
                auto st_p1xxy = st_p1xx;
                auto rows_p2xxy = rows_p2xx;
                auto q_p3xxy = q_p3xx;
                auto rest_p7xy = rest_p7x;
                (crate::prelude::entered(crate::prelude::once_job([=, env_p0xxy = std::move(env_p0xxy), st_p1xxy = std::move(st_p1xxy), rows_p2xxy = std::move(rows_p2xxy), q_p3xxy = std::move(q_p3xxy), rest_p7xy = std::move(rest_p7xy)]() {
                return ({
                    auto seen_pj = p0;
                    auto c_pk = p1;
                    (prism_rtl::finished(std::move(seen_pj) || useful_f(env_p0xxy, st_p1xxy, specialize_f(rows_p2xxy, c_pk), crate::prelude::append(wilds_f(prism_rtl::deref(c_pk).arity_p), crate::prelude::drop(q_p3xxy, Nat(1u))), crate::prelude::append(prism_rtl::deref(c_pk).args_p, rest_p7xy))));
                });
            })));
            });
        })));
        }))->cycle()
            : prism_rtl::more(prism_rtl::rc(Useful(env_p0x, st_p1x, default_rows_f(rows_p2x), crate::prelude::drop(q_p3x, Nat(1u)), rest_p7)));
        })
            : prism_rtl::is_none(ctors_of_o_9109) ? prism_rtl::more(prism_rtl::rc(Useful(env_p0x, st_p1x, default_rows_f(rows_p2x), crate::prelude::drop(q_p3x, Nat(1u)), rest_p7)))
            : throw prism_rtl::Panic("no arm matched");
        });
    }));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start Useful, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_useful_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<Array<Pat>> rows_p2, Array<Pat> q_p3, Array<crate::check::types::Ty> tys_p4) {
    return prism_rtl::make_rc<Useful>(env_p0, st_p1, rows_p2, q_p3, tys_p4);
}


/// CtorFamily: fn Ctor -> Text
Text ctor_family_f(const Ctor& c_p0) {
    return crate::syntax::lexer::chars::has_prefix_f(c_p0.name_p, Text::lit("tag:"))
        ? crate::check::env::dotted_f(crate::syntax::lexer::chars::pop_f(crate::prelude::split_on(crate::syntax::lexer::chars::drop_prefix_f(c_p0.name_p, Text::lit("tag:")), Text::lit("."))))
        : Text::lit("");
}


/// Wilds: fn Nat -> [Pat]
Array<Pat> wilds_f(const Nat& n_p0) {
    return crate::prelude::each(crate::check::errors::range0_f(n_p0), [&](const Nat& _p0) { return Pat(Pat::PtAny{}); });
}


/// CtorNamed: unbounded fn Env, St, Ty, Text, Nat -> Ctor
Ctor ctor_named_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::check::types::Ty& t_p2, const Text& c_p3, const Nat& arity_p4) {
    auto&& _m = ctors_of_o(env_p0, st_p1, t_p2);
    if (prism_rtl::is_some(_m)) {
        auto&& cs_p5 = prism_rtl::some_of(_m);
        auto&& _m = find_ctor_o(cs_p5, c_p3);
        if (prism_rtl::is_some(_m)) {
            auto&& found_p6 = prism_rtl::some_of(_m);
            return found_p6;
        }
        if (prism_rtl::is_none(_m)) {
            return Ctor{.name_p = c_p3, .arity_p = arity_p4, .args_p = crate::prelude::each(crate::check::errors::range0_f(arity_p4), [&](const Nat& _p0) { return crate::check::types::Ty(crate::check::types::Ty::TyErr{}); }), .shown_p = c_p3};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_none(_m)) {
        return Ctor{.name_p = c_p3, .arity_p = arity_p4, .args_p = crate::prelude::each(crate::check::errors::range0_f(arity_p4), [&](const Nat& _p0) { return crate::check::types::Ty(crate::check::types::Ty::TyErr{}); }), .shown_p = c_p3};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Ctor> CtorNamed::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& t_p2 = this->t_p2;
    const auto& c_p3 = this->c_p3;
    const auto& arity_p4 = this->arity_p4;
    auto arity_p4x = arity_p4;
    auto c_p3x = c_p3;
    auto env_p0x = env_p0;
    auto st_p1x = st_p1;
    auto t_p2x = t_p2;
    return crate::prelude::call_then(start_ctors_of_o(env_p0x, st_p1x, t_p2x), [=](std::optional<Array<Ctor>> ctors_of_o_9906) {
        return ({
            prism_rtl::is_some(ctors_of_o_9906) ? ({
            auto&& cs_p5 = prism_rtl::some_of(ctors_of_o_9906);
            ({
            auto&& _m = find_ctor_o(cs_p5, c_p3x);
            prism_rtl::is_some(_m) ? ({
            auto&& found_p6 = prism_rtl::some_of(_m);
            prism_rtl::finished(found_p6);
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(Ctor{.name_p = c_p3x, .arity_p = arity_p4x, .args_p = crate::prelude::each(crate::check::errors::range0_f(arity_p4x), [&](const Nat& _p0) { return crate::check::types::Ty(crate::check::types::Ty::TyErr{}); }), .shown_p = c_p3x})
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::is_none(ctors_of_o_9906) ? prism_rtl::finished(Ctor{.name_p = c_p3x, .arity_p = arity_p4x, .args_p = crate::prelude::each(crate::check::errors::range0_f(arity_p4x), [&](const Nat& _p0) { return crate::check::types::Ty(crate::check::types::Ty::TyErr{}); }), .shown_p = c_p3x})
            : throw prism_rtl::Panic("no arm matched");
        });
    });
}


/// `Start CtorNamed, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ctor> start_ctor_named_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::types::Ty t_p2, Text c_p3, Nat arity_p4) {
    return prism_rtl::make_rc<CtorNamed>(env_p0, st_p1, t_p2, c_p3, arity_p4);
}


/// ?FindCtor: fn [Ctor], Text -> ?Ctor
std::optional<Ctor> find_ctor_o(const Array<Ctor>& cs_p0, const Text& c_p1) {
    return crate::prelude::fold(cs_p0, std::optional<Ctor>{}, [&](const std::optional<Ctor>& found_o2, const Ctor& x_p3) {
        return ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Ctor>> _v;
            if (prism_rtl::is_some(found_o2)) {
                auto&& f_p4 = prism_rtl::some_of(found_o2);
                _v.set(std::optional(f_p4));
                goto _done;
            }
            if (prism_rtl::is_none(found_o2)) {
                _v.set((prism_rtl::deref(x_p3).name_p == c_p1) || (crate::check::types::bare_name_f(prism_rtl::deref(x_p3).name_p) == crate::check::types::bare_name_f(c_p1))
                    ? std::optional(x_p3)
                    : std::optional<Ctor>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// Specialize: fn [ [Pat] ], Ctor -> [ [Pat] ]
Array<Array<Pat>> specialize_f(const Array<Array<Pat>>& rows_p0, const Ctor& c_p1) {
    return crate::prelude::fold(rows_p0, Array<Array<Pat>>{}, [&](const Array<Array<Pat>>& acc_p2, const Array<Pat>& prow_p3) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Array<Pat>>> _v;
            auto&& _m = crate::prelude::index(prow_p3, Nat(0u));
            if (prism_rtl::is_some(_m) && prism_rtl::is<Pat::PtCon>(prism_rtl::some_of(_m))) {
                auto&& d_p4 = prism_rtl::as<Pat::PtCon>(prism_rtl::some_of(_m)).a0;
                auto&& args_p5 = prism_rtl::as<Pat::PtCon>(prism_rtl::some_of(_m)).a1;
                _v.set((d_p4 == c_p1.name_p) || (crate::check::types::bare_name_f(d_p4) == crate::check::types::bare_name_f(c_p1.name_p))
                    ? crate::prelude::push(acc_p2, crate::prelude::append(pad_f(args_p5, c_p1.arity_p), crate::prelude::drop(prow_p3, Nat(1u))))
                    : acc_p2);
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<Pat::PtAny>(prism_rtl::some_of(_m))) {
                _v.set(crate::prelude::push(acc_p2, crate::prelude::append(wilds_f(c_p1.arity_p), crate::prelude::drop(prow_p3, Nat(1u)))));
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<Pat::PtFam>(prism_rtl::some_of(_m))) {
                auto&& f_p6 = prism_rtl::as<Pat::PtFam>(prism_rtl::some_of(_m)).a0;
                _v.set(ctor_family_f(c_p1) == f_p6
                    ? crate::prelude::push(acc_p2, crate::prelude::append(wilds_f(c_p1.arity_p), crate::prelude::drop(prow_p3, Nat(1u))))
                    : acc_p2);
                goto _done;
            }
            {
                _v.set(acc_p2);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// Pad: fn [Pat], Nat -> [Pat]
Array<Pat> pad_f(const Array<Pat>& args_p0, const Nat& n_p1) {
    return crate::prelude::len(args_p0) >= n_p1
        ? crate::prelude::take(args_p0, n_p1)
        : crate::prelude::append(args_p0, wilds_f(crate::prelude::or_(n_p1.checked_sub(crate::prelude::len(args_p0)), Nat(0u))));
}


/// SpecializeLit: fn [ [Pat] ], Text -> [ [Pat] ]
Array<Array<Pat>> specialize_lit_f(const Array<Array<Pat>>& rows_p0, const Text& l_p1) {
    return crate::prelude::fold(rows_p0, Array<Array<Pat>>{}, [&](const Array<Array<Pat>>& acc_p2, const Array<Pat>& prow_p3) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Array<Pat>>> _v;
            auto&& _m = crate::prelude::index(prow_p3, Nat(0u));
            if (prism_rtl::is_some(_m) && prism_rtl::is<Pat::PtLit>(prism_rtl::some_of(_m))) {
                auto&& m_p4 = prism_rtl::as<Pat::PtLit>(prism_rtl::some_of(_m)).a0;
                _v.set(m_p4 == l_p1
                    ? crate::prelude::push(acc_p2, crate::prelude::drop(prow_p3, Nat(1u)))
                    : acc_p2);
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<Pat::PtAny>(prism_rtl::some_of(_m))) {
                _v.set(crate::prelude::push(acc_p2, crate::prelude::drop(prow_p3, Nat(1u))));
                goto _done;
            }
            {
                _v.set(acc_p2);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// DefaultRows: fn [ [Pat] ] -> [ [Pat] ]
Array<Array<Pat>> default_rows_f(const Array<Array<Pat>>& rows_p0) {
    return crate::prelude::fold(rows_p0, Array<Array<Pat>>{}, [&](const Array<Array<Pat>>& acc_p1, const Array<Pat>& prow_p2) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Array<Pat>>> _v;
            auto&& _m = crate::prelude::index(prow_p2, Nat(0u));
            if (prism_rtl::is_some(_m) && prism_rtl::is<Pat::PtAny>(prism_rtl::some_of(_m))) {
                _v.set(crate::prelude::push(acc_p1, crate::prelude::drop(prow_p2, Nat(1u))));
                goto _done;
            }
            {
                _v.set(acc_p1);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// HeadNames: fn [ [Pat] ] -> [Text]
Array<Text> head_names_f(const Array<Array<Pat>>& rows_p0) {
    return crate::prelude::fold(rows_p0, Array<Text>{}, [&](const Array<Text>& acc_p1, const Array<Pat>& prow_p2) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = crate::prelude::index(prow_p2, Nat(0u));
            if (prism_rtl::is_some(_m) && prism_rtl::is<Pat::PtCon>(prism_rtl::some_of(_m))) {
                auto&& c_p3 = prism_rtl::as<Pat::PtCon>(prism_rtl::some_of(_m)).a0;
                _v.set(crate::check::types::add_text_f(acc_p1, c_p3));
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<Pat::PtFam>(prism_rtl::some_of(_m))) {
                auto&& f_p4 = prism_rtl::as<Pat::PtFam>(prism_rtl::some_of(_m)).a0;
                _v.set(crate::check::types::add_text_f(acc_p1, prism_rtl::cat("fam:", f_p4)));
                goto _done;
            }
            {
                _v.set(acc_p1);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// Complete: fn [Ctor], [Text], [ [Pat] ] -> Bool
bool complete_f(const Array<Ctor>& cs_p0, const Array<Text>& heads_p1, const Array<Array<Pat>>& rows_p2) {
    return (crate::prelude::len(cs_p0) > Nat(0u)) && crate::prelude::fold(cs_p0, true, [&](const bool& ok_p3, const Ctor& c_p4) { return prism_rtl::deref(ok_p3) && ((crate::check::types::has_text_f(heads_p1, prism_rtl::deref(c_p4).name_p) || crate::check::types::has_text_f(crate::prelude::each(heads_p1, [&](const Text& h_p5) { return crate::check::types::bare_name_f(h_p5); }), crate::check::types::bare_name_f(prism_rtl::deref(c_p4).name_p))) || crate::check::types::has_text_f(heads_p1, prism_rtl::cat("fam:", ctor_family_f(c_p4)))); });
}


/// ?Witness: unbounded fn Env, St, [ [Pat] ], [Ty] -> ?[Text]
std::optional<Array<Text>> witness_o(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Array<Array<Pat>>& rows_p2, const Array<crate::check::types::Ty>& tys_p3) {
    auto&& _m = crate::prelude::index(tys_p3, Nat(0u));
    if (prism_rtl::is_none(_m)) {
        return crate::prelude::len(rows_p2) == Nat(0u)
            ? std::optional(Array<Text>{})
            : std::optional<Array<Text>>{};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& t1_p4 = prism_rtl::some_of(_m);
        auto rest_p5 = crate::prelude::drop(tys_p3, Nat(1u));
        auto heads_p6 = head_names_f(rows_p2);
        auto&& _m = ctors_of_o(env_p0, st_p1, t1_p4);
        if (prism_rtl::is_some(_m)) {
            auto&& cs_p7 = prism_rtl::some_of(_m);
            return complete_f(cs_p7, heads_p6, rows_p2)
                ? crate::prelude::run_to_end(crate::prelude::fold_job(cs_p7, std::optional<Array<Text>>{}, ({
                auto env_p0x = env_p0;
                auto st_p1x = st_p1;
                auto rows_p2x = rows_p2;
                auto rest_p5x = rest_p5;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<Array<Text>>>(std::tuple<std::optional<Array<Text>>, Ctor>)>>(prism_rtl::rc([=, env_p0x = std::move(env_p0x), st_p1x = std::move(st_p1x), rows_p2x = std::move(rows_p2x), rest_p5x = std::move(rest_p5x)](std::tuple<std::optional<Array<Text>>, Ctor> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto env_p0xy = env_p0x;
                    auto st_p1xy = st_p1x;
                    auto rows_p2xy = rows_p2x;
                    auto rest_p5xy = rest_p5x;
                    (crate::prelude::entered(crate::prelude::once_job([=, env_p0xy = std::move(env_p0xy), st_p1xy = std::move(st_p1xy), rows_p2xy = std::move(rows_p2xy), rest_p5xy = std::move(rest_p5xy)]() {
                    return ({
                        auto found_o8 = p0;
                        auto c_p9 = p1;
                        ({
                        prism_rtl::is_some(found_o8) ? ({
                        auto&& f_pa = prism_rtl::some_of(found_o8);
                        prism_rtl::finished(std::optional(f_pa));
                    })
                        : prism_rtl::is_none(found_o8) ? crate::prelude::call_then(start_witness_o(env_p0xy, st_p1xy, specialize_f(rows_p2xy, c_p9), crate::prelude::append(prism_rtl::deref(c_p9).args_p, rest_p5xy)), [=](std::optional<Array<Text>> witness_o_12482) {
                        return ({
                            prism_rtl::is_some(witness_o_12482) ? ({
                            auto&& w_pb = prism_rtl::some_of(witness_o_12482);
                            prism_rtl::finished(std::optional(crate::prelude::append(Array(std::vector{show_witness_f(c_p9, crate::prelude::take(w_pb, prism_rtl::deref(c_p9).arity_p))}), crate::prelude::drop(w_pb, prism_rtl::deref(c_p9).arity_p))));
                        })
                            : prism_rtl::is_none(witness_o_12482) ? prism_rtl::finished(std::optional<Array<Text>>{})
                            : throw prism_rtl::Panic("no arm matched");
                        });
                    })
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                })));
                });
            })));
            })))
                : ({
                __label__ _done;
                prism_rtl::Slot<std::optional<Array<Text>>> _v;
                auto&& _m = witness_o(env_p0, st_p1, default_rows_f(rows_p2), rest_p5);
                if (prism_rtl::is_some(_m)) {
                    auto&& w_pc = prism_rtl::some_of(_m);
                    _v.set(({
                        auto missing_pd = crate::prelude::filter(cs_p7, [&](const Ctor& c_pf) { return !(crate::check::types::has_text_f(heads_p6, prism_rtl::deref(c_pf).name_p) || crate::check::types::has_text_f(heads_p6, prism_rtl::cat("fam:", ctor_family_f(c_pf)))); });
                        auto shown_pe = ({
                            __label__ _done;
                            prism_rtl::Slot<Text> _v;
                            auto&& _m = crate::prelude::index(missing_pd, Nat(0u));
                            if (prism_rtl::is_some(_m)) {
                                auto&& c_pg = prism_rtl::some_of(_m);
                                _v.set(prism_rtl::deref(c_pg).shown_p);
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(Text::lit("_"));
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        });
                        (std::optional(crate::prelude::append(Array(std::vector{shown_pe}), w_pc)));
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::optional<Array<Text>>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        }
        if (prism_rtl::is_none(_m)) {
            auto&& _m = witness_o(env_p0, st_p1, default_rows_f(rows_p2), rest_p5);
            if (prism_rtl::is_some(_m)) {
                auto&& w_ph = prism_rtl::some_of(_m);
                return std::optional(crate::prelude::append(Array(std::vector{Text::lit("_")}), w_ph));
            }
            if (prism_rtl::is_none(_m)) {
                return std::optional<Array<Text>>{};
            }
            prism_rtl::unreachable("no arm matched");
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::optional<Array<Text>>> Witness::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& rows_p2 = this->rows_p2;
    const auto& tys_p3 = this->tys_p3;
    return ({
        auto&& _m = crate::prelude::index(tys_p3, Nat(0u));
        prism_rtl::is_none(_m) ? crate::prelude::len(rows_p2) == Nat(0u)
        ? prism_rtl::finished(std::optional(Array<Text>{}))
        : prism_rtl::finished(std::optional<Array<Text>>{})
        : prism_rtl::is_some(_m) ? ({
        auto&& t1_p4 = prism_rtl::some_of(_m);
        ({
        auto rest_p5 = crate::prelude::drop(tys_p3, Nat(1u));
        auto heads_p6 = head_names_f(rows_p2);
        auto env_p0x = env_p0;
        auto rows_p2x = rows_p2;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(start_ctors_of_o(env_p0x, st_p1x, t1_p4), [=, rest_p5 = std::move(rest_p5), heads_p6 = std::move(heads_p6), rows_p2x = std::move(rows_p2x)](std::optional<Array<Ctor>> ctors_of_o_12268) {
        return ({
            prism_rtl::is_some(ctors_of_o_12268) ? ({
            auto&& cs_p7 = prism_rtl::some_of(ctors_of_o_12268);
            complete_f(cs_p7, heads_p6, rows_p2x)
            ? crate::prelude::fold_job(cs_p7, std::optional<Array<Text>>{}, ({
            auto env_p0xx = env_p0x;
            auto st_p1xx = st_p1x;
            auto rows_p2xx = rows_p2x;
            auto rest_p5x = rest_p5;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<Array<Text>>>(std::tuple<std::optional<Array<Text>>, Ctor>)>>(prism_rtl::rc([=, env_p0xx = std::move(env_p0xx), st_p1xx = std::move(st_p1xx), rows_p2xx = std::move(rows_p2xx), rest_p5x = std::move(rest_p5x)](std::tuple<std::optional<Array<Text>>, Ctor> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env_p0xxy = env_p0xx;
                auto st_p1xxy = st_p1xx;
                auto rows_p2xxy = rows_p2xx;
                auto rest_p5xy = rest_p5x;
                (crate::prelude::entered(crate::prelude::once_job([=, env_p0xxy = std::move(env_p0xxy), st_p1xxy = std::move(st_p1xxy), rows_p2xxy = std::move(rows_p2xxy), rest_p5xy = std::move(rest_p5xy)]() {
                return ({
                    auto found_o8 = p0;
                    auto c_p9 = p1;
                    ({
                    prism_rtl::is_some(found_o8) ? ({
                    auto&& f_pa = prism_rtl::some_of(found_o8);
                    prism_rtl::finished(std::optional(f_pa));
                })
                    : prism_rtl::is_none(found_o8) ? crate::prelude::call_then(start_witness_o(env_p0xxy, st_p1xxy, specialize_f(rows_p2xxy, c_p9), crate::prelude::append(prism_rtl::deref(c_p9).args_p, rest_p5xy)), [=](std::optional<Array<Text>> witness_o_12482) {
                    return ({
                        prism_rtl::is_some(witness_o_12482) ? ({
                        auto&& w_pb = prism_rtl::some_of(witness_o_12482);
                        prism_rtl::finished(std::optional(crate::prelude::append(Array(std::vector{show_witness_f(c_p9, crate::prelude::take(w_pb, prism_rtl::deref(c_p9).arity_p))}), crate::prelude::drop(w_pb, prism_rtl::deref(c_p9).arity_p))));
                    })
                        : prism_rtl::is_none(witness_o_12482) ? prism_rtl::finished(std::optional<Array<Text>>{})
                        : throw prism_rtl::Panic("no arm matched");
                    });
                })
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            })));
            });
        })));
        }))->cycle()
            : crate::prelude::call_then(start_witness_o(env_p0x, st_p1x, default_rows_f(rows_p2x), rest_p5), [=](std::optional<Array<Text>> witness_o_12712) {
            return ({
                prism_rtl::is_some(witness_o_12712) ? ({
                auto&& w_pc = prism_rtl::some_of(witness_o_12712);
                ({
                auto missing_pd = crate::prelude::filter(cs_p7, [&](const Ctor& c_pf) { return !(crate::check::types::has_text_f(heads_p6, prism_rtl::deref(c_pf).name_p) || crate::check::types::has_text_f(heads_p6, prism_rtl::cat("fam:", ctor_family_f(c_pf)))); });
                auto shown_pe = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = crate::prelude::index(missing_pd, Nat(0u));
                    if (prism_rtl::is_some(_m)) {
                        auto&& c_pg = prism_rtl::some_of(_m);
                        _v.set(prism_rtl::deref(c_pg).shown_p);
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Text::lit("_"));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                (prism_rtl::finished(std::optional(crate::prelude::append(Array(std::vector{shown_pe}), w_pc))));
            });
            })
                : prism_rtl::is_none(witness_o_12712) ? prism_rtl::finished(std::optional<Array<Text>>{})
                : throw prism_rtl::Panic("no arm matched");
            });
        });
        })
            : prism_rtl::is_none(ctors_of_o_12268) ? crate::prelude::call_then(start_witness_o(env_p0x, st_p1x, default_rows_f(rows_p2x), rest_p5), [=](std::optional<Array<Text>> witness_o_13138) {
            return ({
                prism_rtl::is_some(witness_o_13138) ? ({
                auto&& w_ph = prism_rtl::some_of(witness_o_13138);
                prism_rtl::finished(std::optional(crate::prelude::append(Array(std::vector{Text::lit("_")}), w_ph)));
            })
                : prism_rtl::is_none(witness_o_13138) ? prism_rtl::finished(std::optional<Array<Text>>{})
                : throw prism_rtl::Panic("no arm matched");
            });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
    }));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start Witness, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Array<Text>>> start_witness_o(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<Array<Pat>> rows_p2, Array<crate::check::types::Ty> tys_p3) {
    return prism_rtl::make_rc<Witness>(env_p0, st_p1, rows_p2, tys_p3);
}


/// ShowWitness: fn Ctor, [Text] -> Text
Text show_witness_f(const Ctor& c_p0, const Array<Text>& args_p1) {
    return c_p0.name_p == Text::lit("?")
        ? prism_rtl::cat("? ", crate::prelude::or_(crate::prelude::index(args_p1, Nat(0u)), Text::lit("_")))
        : c_p0.name_p == Text::lit("~")
        ? prism_rtl::cat("~ ", crate::prelude::or_(crate::prelude::index(args_p1, Nat(0u)), Text::lit("_")))
        : c_p0.name_p == Text::lit("tuple")
        ? prism_rtl::cat("((", crate::syntax::lexer::chars::join_f(args_p1, Text::lit(", ")), "))")
        : (crate::prelude::len(args_p1) == Nat(0u)) || crate::prelude::fold(args_p1, true, [&](const bool& ok_p2, const Text& a_p3) { return prism_rtl::deref(ok_p2) && (a_p3 == Text::lit("_")); })
        ? c_p0.shown_p
        : prism_rtl::cat(crate::check::types::bare_name_f(c_p0.name_p), " ", crate::syntax::lexer::chars::join_f(args_p1, Text::lit(", ")));
}


/// MatchCoverage: unbounded fn Env, St, Ty, [Arm], Range -> St
crate::check::types::St match_coverage_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::check::types::Ty& t_p2, const Array<crate::syntax::Arm>& arms_p3, const crate::syntax::Range& span_p4) {
    auto has_otherwise_p5 = crate::prelude::fold(arms_p3, false, [&](const bool& seen_p7, const crate::syntax::Arm& a_p8) { return prism_rtl::deref(seen_p7) || (prism_rtl::deref(a_p8).pattern_o == std::optional<crate::syntax::Pattern_>{}); });
    auto tys_p6 = Array(std::vector{t_p2});
    auto [rows_pi, st2_pj] = crate::prelude::run_to_end(crate::prelude::fold_job(arms_p3, std::tuple{Array<Array<Pat>>{}, st_p1}, ({
        auto env_p0x = env_p0;
        auto tys_p6x = tys_p6;
        auto t_p2x = t_p2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Array<Pat>>, crate::check::types::St>>(std::tuple<std::tuple<Array<Array<Pat>>, crate::check::types::St>, crate::syntax::Arm>)>>(prism_rtl::rc([=, env_p0x = std::move(env_p0x), tys_p6x = std::move(tys_p6x), t_p2x = std::move(t_p2x)](std::tuple<std::tuple<Array<Array<Pat>>, crate::check::types::St>, crate::syntax::Arm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_p0xy = env_p0x;
            auto tys_p6xy = tys_p6x;
            auto t_p2xy = t_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, env_p0xy = std::move(env_p0xy), tys_p6xy = std::move(tys_p6xy), t_p2xy = std::move(t_p2xy)]() {
            return ({
                auto [acc_p9, s_pa] = p0;
                auto arm_pb = p1;
                ({
                auto q_pc = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Pat>> _v;
                    auto&& _m = prism_rtl::deref(arm_pb).pattern_o;
                    if (prism_rtl::is_some(_m)) {
                        auto&& p_ph = prism_rtl::some_of(_m);
                        _v.set(Array(std::vector{to_pat_f(env_p0xy, p_ph)}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Array(std::vector{Pat(Pat::PtAny{})}));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                (crate::prelude::call_then(start_useful_f(env_p0xy, s_pa, acc_p9, q_pc, tys_p6xy), [=](bool useful_f_14224) {
                return ({
                    auto reachable_pd = useful_f_14224;
                    (crate::prelude::call_then(start_owns_row_f(env_p0xy, s_pa, t_p2xy), [=, reachable_pd = std::move(reachable_pd)](bool owns_row_f_14273) {
                    return ({
                        auto owns_all_pe = owns_row_f_14273;
                        auto s2_pf = reachable_pd
                            ? s_pa
                            : (prism_rtl::deref(arm_pb).pattern_o == std::optional<crate::syntax::Pattern_>{}) && (!std::move(owns_all_pe))
                            ? s_pa
                            : crate::check::types::recording::err_fix_f(s_pa, Text::lit("unreachable"), arm_span_f(arm_pb), Text::lit("this arm is never reached"), Text::lit("remove it, or put it above the arm that covers it"));
                        auto acc2_pg = prism_rtl::deref(arm_pb).guard_o == std::optional<crate::syntax::Expr>{}
                            ? crate::prelude::push(acc_p9, q_pc)
                            : acc_p9;
                        (prism_rtl::finished(std::tuple{acc2_pg, s2_pf}));
                    });
                }));
                });
            }));
            });
            });
        })));
        });
    }));
    })));
    return std::move(has_otherwise_p5)
        ? st2_pj
        : is_open_row_f(env_p0, st2_pj, t_p2)
        ? crate::check::types::recording::err_fix_f(st2_pj, Text::lit("row-not-closed"), span_p4, prism_rtl::cat("a match over `", crate::check::types::show_ty_f(st2_pj, t_p2), "` needs `otherwise:`"), Text::lit("add an `otherwise:` arm: the row\'s variable may hold tags this match cannot name"))
        : ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        auto&& _m = witness_o(env_p0, st2_pj, rows_pi, tys_p6);
        if (prism_rtl::is_some(_m)) {
            auto&& w_pk = prism_rtl::some_of(_m);
            _v.set(crate::check::types::recording::err_fix_f(st2_pj, Text::lit("not-exhaustive"), span_p4, prism_rtl::cat("this match misses `", crate::syntax::lexer::chars::join_f(w_pk, Text::lit(", ")), "`"), Text::lit("add an arm for it, or `otherwise:`")));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(st2_pj);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<crate::check::types::St> MatchCoverage::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& t_p2 = this->t_p2;
    const auto& arms_p3 = this->arms_p3;
    const auto& span_p4 = this->span_p4;
    auto has_otherwise_p5 = crate::prelude::fold(arms_p3, false, [&](const bool& seen_p7, const crate::syntax::Arm& a_p8) { return prism_rtl::deref(seen_p7) || (prism_rtl::deref(a_p8).pattern_o == std::optional<crate::syntax::Pattern_>{}); });
    auto tys_p6 = Array(std::vector{t_p2});
    auto arms_p3x = arms_p3;
    auto env_p0x = env_p0;
    auto span_p4x = span_p4;
    auto st_p1x = st_p1;
    auto t_p2x = t_p2;
    return crate::prelude::call_value(crate::prelude::fold_job(arms_p3x, std::tuple{Array<Array<Pat>>{}, st_p1x}, ({
        auto env_p0xx = env_p0x;
        auto tys_p6x = tys_p6;
        auto t_p2xx = t_p2x;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Array<Pat>>, crate::check::types::St>>(std::tuple<std::tuple<Array<Array<Pat>>, crate::check::types::St>, crate::syntax::Arm>)>>(prism_rtl::rc([=, env_p0xx = std::move(env_p0xx), tys_p6x = std::move(tys_p6x), t_p2xx = std::move(t_p2xx)](std::tuple<std::tuple<Array<Array<Pat>>, crate::check::types::St>, crate::syntax::Arm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_p0xxy = env_p0xx;
            auto tys_p6xy = tys_p6x;
            auto t_p2xxy = t_p2xx;
            (crate::prelude::entered(crate::prelude::once_job([=, env_p0xxy = std::move(env_p0xxy), tys_p6xy = std::move(tys_p6xy), t_p2xxy = std::move(t_p2xxy)]() {
            return ({
                auto [acc_p9, s_pa] = p0;
                auto arm_pb = p1;
                ({
                auto q_pc = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Pat>> _v;
                    auto&& _m = prism_rtl::deref(arm_pb).pattern_o;
                    if (prism_rtl::is_some(_m)) {
                        auto&& p_ph = prism_rtl::some_of(_m);
                        _v.set(Array(std::vector{to_pat_f(env_p0xxy, p_ph)}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Array(std::vector{Pat(Pat::PtAny{})}));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                (crate::prelude::call_then(start_useful_f(env_p0xxy, s_pa, acc_p9, q_pc, tys_p6xy), [=](bool useful_f_14224) {
                return ({
                    auto reachable_pd = useful_f_14224;
                    (crate::prelude::call_then(start_owns_row_f(env_p0xxy, s_pa, t_p2xxy), [=, reachable_pd = std::move(reachable_pd)](bool owns_row_f_14273) {
                    return ({
                        auto owns_all_pe = owns_row_f_14273;
                        auto s2_pf = reachable_pd
                            ? s_pa
                            : (prism_rtl::deref(arm_pb).pattern_o == std::optional<crate::syntax::Pattern_>{}) && (!std::move(owns_all_pe))
                            ? s_pa
                            : crate::check::types::recording::err_fix_f(s_pa, Text::lit("unreachable"), arm_span_f(arm_pb), Text::lit("this arm is never reached"), Text::lit("remove it, or put it above the arm that covers it"));
                        auto acc2_pg = prism_rtl::deref(arm_pb).guard_o == std::optional<crate::syntax::Expr>{}
                            ? crate::prelude::push(acc_p9, q_pc)
                            : acc_p9;
                        (prism_rtl::finished(std::tuple{acc2_pg, s2_pf}));
                    });
                }));
                });
            }));
            });
            });
        })));
        });
    }));
    })), [=](std::tuple<Array<Array<Pat>>, crate::check::types::St> fold_14057) {
        return ({
            auto [rows_pi, st2_pj] = fold_14057;
            has_otherwise_p5
            ? prism_rtl::finished(st2_pj)
            : crate::prelude::call_then(start_is_open_row_f(env_p0x, st2_pj, t_p2x), [=](bool is_open_row_f_14621) {
            return is_open_row_f_14621
                ? crate::prelude::call_then(crate::check::types::start_show_ty_f(st2_pj, t_p2x), [=](Text show_ty_f_14696) { return prism_rtl::finished(crate::check::types::recording::err_fix_f(st2_pj, Text::lit("row-not-closed"), span_p4x, prism_rtl::cat("a match over `", show_ty_f_14696, "` needs `otherwise:`"), Text::lit("add an `otherwise:` arm: the row\'s variable may hold tags this match cannot name"))); })
                : crate::prelude::call_then(start_witness_o(env_p0x, st2_pj, rows_pi, tys_p6), [=](std::optional<Array<Text>> witness_o_14832) {
                return ({
                    prism_rtl::is_some(witness_o_14832) ? ({
                    auto&& w_pk = prism_rtl::some_of(witness_o_14832);
                    prism_rtl::finished(crate::check::types::recording::err_fix_f(st2_pj, Text::lit("not-exhaustive"), span_p4x, prism_rtl::cat("this match misses `", crate::syntax::lexer::chars::join_f(w_pk, Text::lit(", ")), "`"), Text::lit("add an arm for it, or `otherwise:`")));
                })
                    : prism_rtl::is_none(witness_o_14832) ? prism_rtl::finished(st2_pj)
                    : throw prism_rtl::Panic("no arm matched");
                });
            });
        });
        });
    });
}


/// `Start MatchCoverage, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_match_coverage_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::types::Ty t_p2, Array<crate::syntax::Arm> arms_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<MatchCoverage>(env_p0, st_p1, t_p2, arms_p3, span_p4);
}


/// ArmSpan: fn Arm -> Range
crate::syntax::Range arm_span_f(const crate::syntax::Arm& a_p0) {
    auto&& _m = a_p0.pattern_o;
    if (prism_rtl::is_some(_m)) {
        auto&& p_p1 = prism_rtl::some_of(_m);
        return prism_rtl::deref(p_p1).span_p;
    }
    if (prism_rtl::is_none(_m)) {
        return a_p0.span_p;
    }
    prism_rtl::unreachable("no arm matched");
}


/// IsOpenRow: unbounded fn Env, St, Ty -> Bool
bool is_open_row_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::check::types::Ty& t_p2) {
    auto&& _m = crate::check::types::recording::walk_f(st_p1, t_p2);
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
        auto&& rw_p3 = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a0;
        return prism_rtl::deref(crate::check::types::recording::walk_row_f(st_p1, rw_p3)).tail_p != crate::check::types::Tail(crate::check::types::Tail::TlClosed{});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(_m)) {
        auto&& rw_p4 = prism_rtl::as<crate::check::types::Ty::TyElemAny>(_m).a0;
        return prism_rtl::deref(crate::check::types::recording::walk_row_f(st_p1, rw_p4)).tail_p != crate::check::types::Tail(crate::check::types::Tail::TlClosed{});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& n_p5 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& m15254_2_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        if (m15254_2_1.size() == 0u) {
            auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0.g_p).types_p, n_p5);
            if (prism_rtl::is_some(_m)) {
                auto&& ti_p6 = prism_rtl::some_of(_m);
                return (prism_rtl::deref(ti_p6).body_p == crate::check::env::TyBody(crate::check::env::TyBody::BRowKind{})) && (!is_root_module_f(env_p0));
            }
            if (prism_rtl::is_none(_m)) {
                return ((n_p5 == Text::lit("Fault")) || (n_p5 == Text::lit("Prelude.Fault"))) && (!is_root_module_f(env_p0));
            }
            prism_rtl::unreachable("no arm matched");
        }
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> IsOpenRow::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& t_p2 = this->t_p2;
    auto env_p0x = env_p0;
    auto st_p1x = st_p1;
    auto t_p2x = t_p2;
    return crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x, t_p2x), [=](crate::check::types::Ty walk_f_15260) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyElem>(walk_f_15260) ? ({
            auto&& rw_p3 = prism_rtl::as<crate::check::types::Ty::TyElem>(walk_f_15260).a0;
            crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st_p1x, rw_p3), [=](crate::check::types::Rw walk_row_f_15296) { return prism_rtl::finished(prism_rtl::deref(walk_row_f_15296).tail_p != crate::check::types::Tail(crate::check::types::Tail::TlClosed{})); });
        })
            : prism_rtl::is<crate::check::types::Ty::TyElemAny>(walk_f_15260) ? ({
            auto&& rw_p4 = prism_rtl::as<crate::check::types::Ty::TyElemAny>(walk_f_15260).a0;
            crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st_p1x, rw_p4), [=](crate::check::types::Rw walk_row_f_15348) { return prism_rtl::finished(prism_rtl::deref(walk_row_f_15348).tail_p != crate::check::types::Tail(crate::check::types::Tail::TlClosed{})); });
        })
            : prism_rtl::is<crate::check::types::Ty::TyCon>(walk_f_15260) && ({
            auto&& n_p5 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_15260).a0;
            auto&& m15254_2_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_15260).a1;
            (m15254_2_1.size() == 0u);
        }) ? ({
            auto&& n_p5 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_15260).a0;
            auto&& m15254_2_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_15260).a1;
            ({
            auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env_p0x).g_p).types_p, n_p5);
            prism_rtl::is_some(_m) ? ({
            auto&& ti_p6 = prism_rtl::some_of(_m);
            prism_rtl::finished((prism_rtl::deref(ti_p6).body_p == crate::check::env::TyBody(crate::check::env::TyBody::BRowKind{})) && (!is_root_module_f(env_p0x)));
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(((n_p5 == Text::lit("Fault")) || (n_p5 == Text::lit("Prelude.Fault"))) && (!is_root_module_f(env_p0x)))
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::finished(false);
        });
    });
}


/// `Start IsOpenRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_open_row_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::types::Ty t_p2) {
    return prism_rtl::make_rc<IsOpenRow>(env_p0, st_p1, t_p2);
}


/// OwnsRow: unbounded fn Env, St, Ty -> Bool
bool owns_row_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::check::types::Ty& t_p2) {
    auto&& _m = crate::check::types::recording::walk_f(st_p1, t_p2);
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
        auto&& rw_p3 = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a0;
        return crate::prelude::fold(prism_rtl::deref(crate::check::types::recording::walk_row_f(st_p1, rw_p3)).fams_p, true, [&](const bool& ok_p4, const Text& f_p5) { return prism_rtl::deref(ok_p4) && (crate::prelude::or_(crate::prelude::get(prism_rtl::deref(env_p0.g_p).fam_owner_p, f_p5), Text::lit("")) == env_p0.home_p); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& n_p6 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& m15723_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        if (m15723_1_1.size() == 0u) {
            auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0.g_p).types_p, n_p6);
            if (prism_rtl::is_some(_m)) {
                auto&& ti_p7 = prism_rtl::some_of(_m);
                return prism_rtl::deref(ti_p7).body_p != crate::check::env::TyBody(crate::check::env::TyBody::BRowKind{});
            }
            if (prism_rtl::is_none(_m)) {
                return !((n_p6 == Text::lit("Fault")) || (n_p6 == Text::lit("Prelude.Fault")));
            }
            prism_rtl::unreachable("no arm matched");
        }
    }
    {
        return true;
    }
}


prism_rtl::Turn<bool> OwnsRow::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& t_p2 = this->t_p2;
    auto env_p0x = env_p0;
    auto st_p1x = st_p1;
    auto t_p2x = t_p2;
    return crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x, t_p2x), [=](crate::check::types::Ty walk_f_15729) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyElem>(walk_f_15729) ? ({
            auto&& rw_p3 = prism_rtl::as<crate::check::types::Ty::TyElem>(walk_f_15729).a0;
            crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st_p1x, rw_p3), [=](crate::check::types::Rw walk_row_f_15770) { return prism_rtl::finished(crate::prelude::fold(prism_rtl::deref(walk_row_f_15770).fams_p, true, [&](const bool& ok_p4, const Text& f_p5) { return prism_rtl::deref(ok_p4) && (crate::prelude::or_(crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env_p0x).g_p).fam_owner_p, f_p5), Text::lit("")) == prism_rtl::deref(env_p0x).home_p); })); });
        })
            : prism_rtl::is<crate::check::types::Ty::TyCon>(walk_f_15729) && ({
            auto&& n_p6 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_15729).a0;
            auto&& m15723_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_15729).a1;
            (m15723_1_1.size() == 0u);
        }) ? ({
            auto&& n_p6 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_15729).a0;
            auto&& m15723_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_15729).a1;
            ({
            auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env_p0x).g_p).types_p, n_p6);
            prism_rtl::is_some(_m) ? ({
            auto&& ti_p7 = prism_rtl::some_of(_m);
            prism_rtl::finished(prism_rtl::deref(ti_p7).body_p != crate::check::env::TyBody(crate::check::env::TyBody::BRowKind{}));
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(!((n_p6 == Text::lit("Fault")) || (n_p6 == Text::lit("Prelude.Fault"))))
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::finished(true);
        });
    });
}


/// `Start OwnsRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_owns_row_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::types::Ty t_p2) {
    return prism_rtl::make_rc<OwnsRow>(env_p0, st_p1, t_p2);
}


/// ClauseCoverage: unbounded fn Env, St, [FnClause], [Ty], Range -> St
crate::check::types::St clause_coverage_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Array<crate::syntax::decls::FnClause>& clauses_p2, const Array<crate::check::types::Ty>& params_p3, const crate::syntax::Range& span_p4) {
    auto [rows_pc, st2_pd] = crate::prelude::run_to_end(crate::prelude::fold_job(clauses_p2, std::tuple{Array<Array<Pat>>{}, st_p1}, ({
        auto env_p0x = env_p0;
        auto params_p3x = params_p3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Array<Pat>>, crate::check::types::St>>(std::tuple<std::tuple<Array<Array<Pat>>, crate::check::types::St>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, env_p0x = std::move(env_p0x), params_p3x = std::move(params_p3x)](std::tuple<std::tuple<Array<Array<Pat>>, crate::check::types::St>, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_p0xy = env_p0x;
            auto params_p3xy = params_p3x;
            (crate::prelude::entered(crate::prelude::once_job([=, env_p0xy = std::move(env_p0xy), params_p3xy = std::move(params_p3xy)]() {
            return ({
                auto [acc_p5, s_p6] = p0;
                auto c_p7 = p1;
                (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(c_p7).params_p, ({
                auto env_p0xyx = env_p0xy;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(crate::syntax::Pattern_)>>(prism_rtl::rc([=, env_p0xyx = std::move(env_p0xyx)](crate::syntax::Pattern_ p0) {
                return ({
                    auto env_p0xyxy = env_p0xyx;
                    (crate::prelude::entered(crate::prelude::once_job([=, env_p0xyxy = std::move(env_p0xyxy)]() {
                    return ({
                        auto p_pb = p0;
                        (prism_rtl::more(prism_rtl::rc(ToPat(env_p0xyxy, p_pb))));
                    });
                })));
                });
            })));
            })), [=](Array<Pat> each_16266) {
                return ({
                    auto q_p8 = each_16266;
                    auto reachable_p9 = (crate::prelude::len(q_p8) != crate::prelude::len(params_p3xy)) || useful_f(env_p0xy, s_p6, acc_p5, q_p8, params_p3xy);
                    auto s2_pa = std::move(reachable_p9)
                        ? s_p6
                        : crate::check::types::recording::err_fix_f(s_p6, Text::lit("unreachable"), prism_rtl::deref(c_p7).span_p, Text::lit("this clause is never reached"), Text::lit("remove it, or put it above the clause that covers it"));
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc_p5, q_p8), s2_pa}));
                });
            }));
            });
        })));
        });
    }));
    })));
    return crate::prelude::len(params_p3) == Nat(0u)
        ? st2_pd
        : ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        auto&& _m = witness_o(env_p0, st2_pd, rows_pc, params_p3);
        if (prism_rtl::is_some(_m)) {
            auto&& w_pe = prism_rtl::some_of(_m);
            _v.set(crate::check::types::recording::err_fix_f(st2_pd, Text::lit("not-exhaustive"), span_p4, prism_rtl::cat("these clauses miss `", crate::syntax::lexer::chars::join_f(w_pe, Text::lit(", ")), "`"), Text::lit("add a clause for it")));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(st2_pd);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<crate::check::types::St> ClauseCoverage::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& clauses_p2 = this->clauses_p2;
    const auto& params_p3 = this->params_p3;
    const auto& span_p4 = this->span_p4;
    auto clauses_p2x = clauses_p2;
    auto env_p0x = env_p0;
    auto params_p3x = params_p3;
    auto span_p4x = span_p4;
    auto st_p1x = st_p1;
    return crate::prelude::call_value(crate::prelude::fold_job(clauses_p2x, std::tuple{Array<Array<Pat>>{}, st_p1x}, ({
        auto env_p0xx = env_p0x;
        auto params_p3xx = params_p3x;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Array<Pat>>, crate::check::types::St>>(std::tuple<std::tuple<Array<Array<Pat>>, crate::check::types::St>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, env_p0xx = std::move(env_p0xx), params_p3xx = std::move(params_p3xx)](std::tuple<std::tuple<Array<Array<Pat>>, crate::check::types::St>, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_p0xxy = env_p0xx;
            auto params_p3xxy = params_p3xx;
            (crate::prelude::entered(crate::prelude::once_job([=, env_p0xxy = std::move(env_p0xxy), params_p3xxy = std::move(params_p3xxy)]() {
            return ({
                auto [acc_p5, s_p6] = p0;
                auto c_p7 = p1;
                (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(c_p7).params_p, ({
                auto env_p0xxyx = env_p0xxy;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(crate::syntax::Pattern_)>>(prism_rtl::rc([=, env_p0xxyx = std::move(env_p0xxyx)](crate::syntax::Pattern_ p0) {
                return ({
                    auto env_p0xxyxy = env_p0xxyx;
                    (crate::prelude::entered(crate::prelude::once_job([=, env_p0xxyxy = std::move(env_p0xxyxy)]() {
                    return ({
                        auto p_pb = p0;
                        (prism_rtl::more(prism_rtl::rc(ToPat(env_p0xxyxy, p_pb))));
                    });
                })));
                });
            })));
            })), [=](Array<Pat> each_16266) {
                return ({
                    auto q_p8 = each_16266;
                    auto reachable_p9 = (crate::prelude::len(q_p8) != crate::prelude::len(params_p3xxy)) || useful_f(env_p0xxy, s_p6, acc_p5, q_p8, params_p3xxy);
                    auto s2_pa = std::move(reachable_p9)
                        ? s_p6
                        : crate::check::types::recording::err_fix_f(s_p6, Text::lit("unreachable"), prism_rtl::deref(c_p7).span_p, Text::lit("this clause is never reached"), Text::lit("remove it, or put it above the clause that covers it"));
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc_p5, q_p8), s2_pa}));
                });
            }));
            });
        })));
        });
    }));
    })), [=](std::tuple<Array<Array<Pat>>, crate::check::types::St> fold_16205) {
        return ({
            auto [rows_pc, st2_pd] = fold_16205;
            (crate::prelude::len(params_p3x) == Nat(0u)
            ? prism_rtl::finished(st2_pd)
            : crate::prelude::call_then(start_witness_o(env_p0x, st2_pd, rows_pc, params_p3x), [=](std::optional<Array<Text>> witness_o_16615) {
            return ({
                prism_rtl::is_some(witness_o_16615) ? ({
                auto&& w_pe = prism_rtl::some_of(witness_o_16615);
                prism_rtl::finished(crate::check::types::recording::err_fix_f(st2_pd, Text::lit("not-exhaustive"), span_p4x, prism_rtl::cat("these clauses miss `", crate::syntax::lexer::chars::join_f(w_pe, Text::lit(", ")), "`"), Text::lit("add a clause for it")));
            })
                : prism_rtl::is_none(witness_o_16615) ? prism_rtl::finished(st2_pd)
                : throw prism_rtl::Panic("no arm matched");
            });
        }));
        });
    });
}


/// `Start ClauseCoverage, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_clause_coverage_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<crate::syntax::decls::FnClause> clauses_p2, Array<crate::check::types::Ty> params_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<ClauseCoverage>(env_p0, st_p1, clauses_p2, params_p3, span_p4);
}


/// DischargeIncls: unbounded fn G, St, Nat -> St
crate::check::types::St discharge_incls_f(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const Nat& from_p2) {
    auto batch_p3 = crate::prelude::drop(st_p1.incls_p, from_p2);
    return crate::prelude::run_to_end(crate::prelude::fold_job(batch_p3, st_p1, ({
        auto g_p0x = g_p0;
        auto batch_p3x = batch_p3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::Incl>)>>(prism_rtl::rc([=, g_p0x = std::move(g_p0x), batch_p3x = std::move(batch_p3x)](std::tuple<crate::check::types::St, crate::check::types::Incl> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0xy = g_p0x;
            auto batch_p3xy = batch_p3x;
            (crate::prelude::entered(crate::prelude::once_job([=, g_p0xy = std::move(g_p0xy), batch_p3xy = std::move(batch_p3xy)]() {
            return ({
                auto s_p4 = p0;
                auto inc_p5 = p1;
                (crate::prelude::call_then(start_through_f(s_p4, inc_p5, batch_p3xy), [=](crate::check::types::Incl through_f_17456) { return prism_rtl::more(prism_rtl::rc(DischargeOne(g_p0xy, s_p4, through_f_17456))); }));
            });
        })));
        });
    })));
    })));
}


prism_rtl::Turn<crate::check::types::St> DischargeIncls::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& from_p2 = this->from_p2;
    auto batch_p3 = crate::prelude::drop(prism_rtl::deref(st_p1).incls_p, from_p2);
    return crate::prelude::fold_job(batch_p3, st_p1, ({
        auto g_p0x = g_p0;
        auto batch_p3x = batch_p3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::Incl>)>>(prism_rtl::rc([=, g_p0x = std::move(g_p0x), batch_p3x = std::move(batch_p3x)](std::tuple<crate::check::types::St, crate::check::types::Incl> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0xy = g_p0x;
            auto batch_p3xy = batch_p3x;
            (crate::prelude::entered(crate::prelude::once_job([=, g_p0xy = std::move(g_p0xy), batch_p3xy = std::move(batch_p3xy)]() {
            return ({
                auto s_p4 = p0;
                auto inc_p5 = p1;
                (crate::prelude::call_then(start_through_f(s_p4, inc_p5, batch_p3xy), [=](crate::check::types::Incl through_f_17456) { return prism_rtl::more(prism_rtl::rc(DischargeOne(g_p0xy, s_p4, through_f_17456))); }));
            });
        })));
        });
    })));
    }))->cycle();
}


/// `Start DischargeIncls, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_discharge_incls_f(crate::check::env::G g_p0, crate::check::types::St st_p1, Nat from_p2) {
    return prism_rtl::make_rc<DischargeIncls>(g_p0, st_p1, from_p2);
}


/// Through: unbounded fn St, Incl, [Incl] -> Incl
crate::check::types::Incl through_f(const crate::check::types::St& st_p0, const crate::check::types::Incl& inc_p1, const Array<crate::check::types::Incl>& batch_p2) {
    auto sup_p3 = crate::check::types::recording::walk_row_f(st_p0, inc_p1.sup_p);
    auto&& _m = prism_rtl::deref(sup_p3).tail_p;
    if (prism_rtl::is<crate::check::types::Tail::TlFlex>(_m)) {
        auto&& n_p4 = prism_rtl::as<crate::check::types::Tail::TlFlex>(_m).a0;
        return crate::prelude::len(prism_rtl::deref(sup_p3).fams_p) > Nat(0u)
            ? inc_p1
            : crate::prelude::run_to_end(crate::prelude::fold_job(batch_p2, inc_p1, ({
            auto st_p0x = st_p0;
            auto n_p4x = n_p4;
            auto inc_p1x = inc_p1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Incl>(std::tuple<crate::check::types::Incl, crate::check::types::Incl>)>>(prism_rtl::rc([=, st_p0x = std::move(st_p0x), n_p4x = std::move(n_p4x), inc_p1x = std::move(inc_p1x)](std::tuple<crate::check::types::Incl, crate::check::types::Incl> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_p0xy = st_p0x;
                auto n_p4xy = n_p4x;
                auto inc_p1xy = inc_p1x;
                (crate::prelude::entered(crate::prelude::once_job([=, st_p0xy = std::move(st_p0xy), n_p4xy = std::move(n_p4xy), inc_p1xy = std::move(inc_p1xy)]() {
                return ({
                    auto acc_p5 = p0;
                    auto other_p6 = p1;
                    (crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st_p0xy, prism_rtl::deref(other_p6).sub_p), [=, acc_p5 = std::move(acc_p5)](crate::check::types::Rw walk_row_f_17970) {
                    return ({
                        auto sub_p7 = walk_row_f_17970;
                        ((crate::prelude::len(prism_rtl::deref(sub_p7).fams_p) == Nat(0u)) && (prism_rtl::deref(sub_p7).tail_p == crate::check::types::Tail(crate::check::types::Tail::TlFlex{n_p4xy}))) && (other_p6 != inc_p1xy)
                        ? prism_rtl::finished(({
                        crate::check::types::Incl this_ = acc_p5;
                        this_.sup_p = prism_rtl::deref(other_p6).sup_p;
                        (std::move(this_));
                    }))
                        : prism_rtl::finished(acc_p5);
                    });
                }));
                });
            })));
            });
        })));
        })));
    }
    {
        return inc_p1;
    }
}


prism_rtl::Turn<crate::check::types::Incl> Through::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& inc_p1 = this->inc_p1;
    const auto& batch_p2 = this->batch_p2;
    auto batch_p2x = batch_p2;
    auto inc_p1x = inc_p1;
    auto st_p0x = st_p0;
    return crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st_p0x, prism_rtl::deref(inc_p1x).sup_p), [=](crate::check::types::Rw walk_row_f_17798) {
        return ({
            auto sup_p3 = walk_row_f_17798;
            ({
            auto&& _m = prism_rtl::deref(sup_p3).tail_p;
            prism_rtl::is<crate::check::types::Tail::TlFlex>(_m) ? ({
            auto&& n_p4 = prism_rtl::as<crate::check::types::Tail::TlFlex>(_m).a0;
            crate::prelude::len(prism_rtl::deref(sup_p3).fams_p) > Nat(0u)
            ? prism_rtl::finished(inc_p1x)
            : crate::prelude::fold_job(batch_p2x, inc_p1x, ({
            auto st_p0xx = st_p0x;
            auto n_p4x = n_p4;
            auto inc_p1xx = inc_p1x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Incl>(std::tuple<crate::check::types::Incl, crate::check::types::Incl>)>>(prism_rtl::rc([=, st_p0xx = std::move(st_p0xx), n_p4x = std::move(n_p4x), inc_p1xx = std::move(inc_p1xx)](std::tuple<crate::check::types::Incl, crate::check::types::Incl> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_p0xxy = st_p0xx;
                auto n_p4xy = n_p4x;
                auto inc_p1xxy = inc_p1xx;
                (crate::prelude::entered(crate::prelude::once_job([=, st_p0xxy = std::move(st_p0xxy), n_p4xy = std::move(n_p4xy), inc_p1xxy = std::move(inc_p1xxy)]() {
                return ({
                    auto acc_p5 = p0;
                    auto other_p6 = p1;
                    (crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st_p0xxy, prism_rtl::deref(other_p6).sub_p), [=, acc_p5 = std::move(acc_p5)](crate::check::types::Rw walk_row_f_17970) {
                    return ({
                        auto sub_p7 = walk_row_f_17970;
                        ((crate::prelude::len(prism_rtl::deref(sub_p7).fams_p) == Nat(0u)) && (prism_rtl::deref(sub_p7).tail_p == crate::check::types::Tail(crate::check::types::Tail::TlFlex{n_p4xy}))) && (other_p6 != inc_p1xxy)
                        ? prism_rtl::finished(({
                        crate::check::types::Incl this_ = acc_p5;
                        this_.sup_p = prism_rtl::deref(other_p6).sup_p;
                        (std::move(this_));
                    }))
                        : prism_rtl::finished(acc_p5);
                    });
                }));
                });
            })));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::finished(inc_p1x);
        });
        });
    });
}


/// `Start Through, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Incl> start_through_f(crate::check::types::St st_p0, crate::check::types::Incl inc_p1, Array<crate::check::types::Incl> batch_p2) {
    return prism_rtl::make_rc<Through>(st_p0, inc_p1, batch_p2);
}


/// DischargeOne: unbounded fn G, St, Incl -> St
crate::check::types::St discharge_one_f(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::types::Incl& inc_p2) {
    auto sub_p3 = crate::check::types::recording::walk_row_f(st_p1, inc_p2.sub_p);
    auto sup_p4 = crate::check::types::recording::walk_row_f(st_p1, inc_p2.sup_p);
    auto st1_p5 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        auto&& _m = prism_rtl::deref(sub_p3).tail_p;
        if (prism_rtl::is<crate::check::types::Tail::TlFlex>(_m)) {
            auto&& n_p9 = prism_rtl::as<crate::check::types::Tail::TlFlex>(_m).a0;
            _v.set(close_tail_f(st_p1, n_p9));
            goto _done;
        }
        {
            _v.set(st_p1);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto sub2_p6 = crate::check::types::recording::walk_row_f(st1_p5, inc_p2.sub_p);
    auto left_p7 = crate::prelude::filter(prism_rtl::deref(sub2_p6).fams_p, [&](const Text& f_pa) { return (!crate::check::types::has_text_f(prism_rtl::deref(sup_p4).fams_p, f_pa)) && (crate::prelude::len(tags_left_f(g_p0, f_pa, prism_rtl::deref(sub2_p6).minus_p)) > Nat(0u)); });
    auto tail_bad_p8 = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = std::tuple{prism_rtl::deref(sub2_p6).tail_p, prism_rtl::deref(sup_p4).tail_p};
        if (prism_rtl::is<crate::check::types::Tail::TlRigid>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Tail::TlRigid>(std::get<1>(_m))) {
            auto&& a_pb = prism_rtl::as<crate::check::types::Tail::TlRigid>(std::get<0>(_m)).a0;
            auto&& b_pc = prism_rtl::as<crate::check::types::Tail::TlRigid>(std::get<1>(_m)).a0;
            _v.set(a_pb != b_pc);
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Tail::TlRigid>(std::get<0>(_m))) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    return (crate::prelude::len(left_p7) == Nat(0u)) && (!std::move(tail_bad_p8))
        ? st1_p5
        : ({
        auto s0_pd = ({
            crate::check::types::St this_ = st1_p5;
            this_.file_p = inc_p2.file_p;
            (std::move(this_));
        });
        auto tags_pe = crate::prelude::fold(left_p7, Array<Text>{}, [&](const Array<Text>& acc_pg, const Text& f_ph) { return crate::prelude::append(acc_pg, tags_left_f(g_p0, f_ph, prism_rtl::deref(sub2_p6).minus_p)); });
        auto s1_pf = inc_p2.forward_p
            ? crate::check::types::recording::err_fix_f(s0_pd, Text::lit("forwarding"), inc_p2.span_p, prism_rtl::cat("forwarding ", crate::syntax::lexer::chars::join_f(tags_pe, Text::lit(", ")), " from a scope that emits ", crate::check::types::show_row_f(sup_p4)), prism_rtl::cat("answer ", crate::prelude::len(tags_pe) == Nat(1u)
            ? Text::lit("it")
            : Text::lit("them"), " above this arm, for example `", crate::prelude::or_(crate::prelude::index(tags_pe, Nat(0u)), Text::lit("")), "(..): @ never`"))
            : crate::check::types::recording::err_fix_f(s0_pd, Text::lit("row-outside"), inc_p2.span_p, prism_rtl::cat("a child that emits `", crate::check::types::show_row_f(sub2_p6), "` in a scope that emits `", crate::check::types::show_row_f(sup_p4), "`"), Text::lit("widen the scope\'s `emit` row, or host the child with `@HostDocument`"));
        ({
        crate::check::types::St this_ = s1_pf;
        this_.file_p = prism_rtl::deref(st1_p5).file_p;
        (std::move(this_));
    });
    });
}


prism_rtl::Turn<crate::check::types::St> DischargeOne::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& inc_p2 = this->inc_p2;
    auto g_p0x = g_p0;
    auto inc_p2x = inc_p2;
    auto st_p1x = st_p1;
    return crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st_p1x, prism_rtl::deref(inc_p2x).sub_p), [=](crate::check::types::Rw walk_row_f_18289) {
        return ({
            auto sub_p3 = walk_row_f_18289;
            (crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st_p1x, prism_rtl::deref(inc_p2x).sup_p), [=, sub_p3 = std::move(sub_p3)](crate::check::types::Rw walk_row_f_18323) {
            return ({
                auto sup_p4 = walk_row_f_18323;
                auto st1_p5 = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::check::types::St> _v;
                    auto&& _m = prism_rtl::deref(sub_p3).tail_p;
                    if (prism_rtl::is<crate::check::types::Tail::TlFlex>(_m)) {
                        auto&& n_p9 = prism_rtl::as<crate::check::types::Tail::TlFlex>(_m).a0;
                        _v.set(close_tail_f(st_p1x, n_p9));
                        goto _done;
                    }
                    {
                        _v.set(st_p1x);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                (crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st1_p5, prism_rtl::deref(inc_p2x).sub_p), [=, sup_p4 = std::move(sup_p4)](crate::check::types::Rw walk_row_f_18444) {
                return ({
                    auto sub2_p6 = walk_row_f_18444;
                    auto left_p7 = crate::prelude::filter(prism_rtl::deref(sub2_p6).fams_p, [&](const Text& f_pa) { return (!crate::check::types::has_text_f(prism_rtl::deref(sup_p4).fams_p, f_pa)) && (crate::prelude::len(tags_left_f(g_p0x, f_pa, prism_rtl::deref(sub2_p6).minus_p)) > Nat(0u)); });
                    auto tail_bad_p8 = ({
                        __label__ _done;
                        prism_rtl::Slot<bool> _v;
                        auto&& _m = std::tuple{prism_rtl::deref(sub2_p6).tail_p, prism_rtl::deref(sup_p4).tail_p};
                        if (prism_rtl::is<crate::check::types::Tail::TlRigid>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Tail::TlRigid>(std::get<1>(_m))) {
                            auto&& a_pb = prism_rtl::as<crate::check::types::Tail::TlRigid>(std::get<0>(_m)).a0;
                            auto&& b_pc = prism_rtl::as<crate::check::types::Tail::TlRigid>(std::get<1>(_m)).a0;
                            _v.set(a_pb != b_pc);
                            goto _done;
                        }
                        if (prism_rtl::is<crate::check::types::Tail::TlRigid>(std::get<0>(_m))) {
                            _v.set(true);
                            goto _done;
                        }
                        {
                            _v.set(false);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    (crate::prelude::len(left_p7) == Nat(0u)) && (!std::move(tail_bad_p8))
                    ? prism_rtl::finished(st1_p5)
                    : ({
                    auto s0_pd = ({
                        crate::check::types::St this_ = st1_p5;
                        this_.file_p = prism_rtl::deref(inc_p2x).file_p;
                        (std::move(this_));
                    });
                    auto tags_pe = crate::prelude::fold(left_p7, Array<Text>{}, [&](const Array<Text>& acc_pg, const Text& f_ph) { return crate::prelude::append(acc_pg, tags_left_f(g_p0x, f_ph, prism_rtl::deref(sub2_p6).minus_p)); });
                    auto s1_pf = prism_rtl::deref(inc_p2x).forward_p
                        ? crate::check::types::recording::err_fix_f(s0_pd, Text::lit("forwarding"), prism_rtl::deref(inc_p2x).span_p, prism_rtl::cat("forwarding ", crate::syntax::lexer::chars::join_f(tags_pe, Text::lit(", ")), " from a scope that emits ", crate::check::types::show_row_f(sup_p4)), prism_rtl::cat("answer ", crate::prelude::len(tags_pe) == Nat(1u)
                        ? Text::lit("it")
                        : Text::lit("them"), " above this arm, for example `", crate::prelude::or_(crate::prelude::index(tags_pe, Nat(0u)), Text::lit("")), "(..): @ never`"))
                        : crate::check::types::recording::err_fix_f(s0_pd, Text::lit("row-outside"), prism_rtl::deref(inc_p2x).span_p, prism_rtl::cat("a child that emits `", crate::check::types::show_row_f(sub2_p6), "` in a scope that emits `", crate::check::types::show_row_f(sup_p4), "`"), Text::lit("widen the scope\'s `emit` row, or host the child with `@HostDocument`"));
                    (prism_rtl::finished(({
                    crate::check::types::St this_ = s1_pf;
                    this_.file_p = prism_rtl::deref(st1_p5).file_p;
                    (std::move(this_));
                })));
                });
                });
            }));
            });
        }));
        });
    });
}


/// `Start DischargeOne, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_discharge_one_f(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::types::Incl inc_p2) {
    return prism_rtl::make_rc<DischargeOne>(g_p0, st_p1, inc_p2);
}


/// TagsLeft: fn G, Text, [Text] -> [Text]
Array<Text> tags_left_f(const crate::check::env::G& g_p0, const Text& fam_p1, const Array<Text>& minus_p2) {
    return crate::prelude::filter(crate::prelude::or_(crate::prelude::get(g_p0.families_p, fam_p1), Array<Text>{}), [&](const Text& t_p3) { return (!crate::check::types::has_text_f(minus_p2, t_p3)) && is_element_tag_f(g_p0, t_p3); });
}


/// IsElementTag: fn G, Text -> Bool
bool is_element_tag_f(const crate::check::env::G& g_p0, const Text& t_p1) {
    auto&& _m = crate::prelude::get(g_p0.tags_p, t_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& tg_p2 = prism_rtl::some_of(_m);
        return prism_rtl::deref(tg_p2).kind_p == Text::lit("Element");
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// CloseTail: fn St, Nat -> St
crate::check::types::St close_tail_f(const crate::check::types::St& st_p0, const Nat& n_p1) {
    crate::check::types::St this_ = st_p0;
    this_.rows_p = crate::prelude::insert(this_.rows_p, n_p1, crate::check::types::empty_row_p());
    return this_;
}

}  // namespace crate::check::passes
