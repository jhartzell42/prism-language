// The module `EmitCpp`, from `target/bootstrap/cpp-src/prismc/emit_cpp.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include "emit_cpp.hpp"
#include "ast.hpp"
#include "check_env.hpp"
#include "check_errors.hpp"
#include "check_types.hpp"
#include "cpp_prelude_template.hpp"
#include "cpp_templates.hpp"
#include "lexer.hpp"
#include "lower.hpp"
#include "prelude_template.hpp"
#include "typed.hpp"
#include "check_env.generic.hpp"
#include "lexer.generic.hpp"
#include "lower.generic.hpp"

namespace crate::emit_cpp {

/// EmitCpp: unbounded fn Model, Text, [Text] -> [((Text, Text))]
Array<std::tuple<Text, Text>> emit_cpp(const lower::Model& model, const Text& runtime, const Array<Text>& scripts) {
    auto cp = context(model);
    auto crate_ = in_home(cp, Text(""));
    auto elem = row_parts(crate_, Text(""), model.elem);
    auto answer = answer_parts(crate_, model->answer);
    auto mods = run_to_end(each_job(model.mods, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Parts>(lower::ModDef)>>(prism_rtl::rc([=](lower::ModDef p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                (prism_rtl::more(prism_rtl::rc(ModuleParts(cp_1_2, m))));
            });
        }));
        });
    })));
    })));
    auto programs = lexer::join(run_to_end(each_job(all_programs_cpp(model), ({
        auto crate__1 = crate_;
        auto model_2 = model;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::ProgDef)>>(prism_rtl::rc([=](lower::ProgDef p0) {
        return ({
            auto crate__1_3 = crate__1;
            auto model_2_3 = model_2;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(ProgramCpp(crate__1_3, p_, node_fallible_cpp(model_2_3, p_.node_)))));
            });
        }));
        });
    })));
    }))), Text("\n\n"));
    auto regs = concat(each(model.programs, [&](const lower::ProgDef& p_) { return prism_rtl::cat("\n.program<", p_.name, ">(\"", p_.prism, "\")"); }));
    auto checks = concat(run_to_end(each_job(model.checks, ({
        auto crate__1 = crate_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::CheckDef)>>(prism_rtl::rc([=](lower::CheckDef p0) {
        return ({
            auto crate__1_2 = crate__1;
            entered(once_job([=]() {
            return ({
                auto c = p0;
                call_value(each_job(c.lines, ({
                auto crate__1_2_2 = crate__1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Ex)>>(prism_rtl::rc([=](lower::Ex p0) {
                return ({
                    auto crate__1_2_2_2 = crate__1_2_2;
                    entered(once_job([=]() {
                    return ({
                        auto l = p0;
                        (prism_rtl::more(prism_rtl::rc(CppExpr(crate__1_2_2_2, l))));
                    });
                }));
                });
            })));
            })), [=](Array<Text> each_86115) { return prism_rtl::finished(prism_rtl::cat("\n.check(\"", c.name, "\", [] { return std::vector<Result<Pod>>{", lexer::join(each_86115, Text(", ")), "}; })")); });
            });
        }));
        });
    })));
    }))));
    auto script_list = lexer::join(each(scripts, [&](const Text& s) { return prism_rtl::cat("\"", lower::escape(s), "\","); }), Text("\n"));
    auto world = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = model.root;
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(r->world);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text("test"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto canvas_1 = world == Text("canvas");
    auto run_root = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = model.root;
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(cpp_templates::cpp_run_root(r.name, canvas_1
                ? cpp_templates::cpp_canvas_run(r.name)
                : cpp_templates::cpp_no_canvas(r.name)));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(cpp_templates::cpp_no_root(model.name));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto both_ = join_parts(elem, answer);
    auto elem_decl = cpp_templates::cpp_elem_decl(includes(Text("decl"), append(model.elem_complete, model.elem_declared)), lexer::join(both_.forward, Text("\n\n")), lexer::join(both_.handles, Text("\n\n")), cpp_prelude_template::cpp_prelude_rows(Text("")));
    auto elem_types = cpp_templates::cpp_elem_types(lexer::join(filter(Array(std::vector{includes(Text("types"), model.elem_complete), includes(Text("decl"), model.elem_declared)}), [&](const Text& t) { return t != Text(""); }), Text("\n")), lexer::join(both_.cases_, Text("\n\n")));
    auto pairs = each(check_errors::range0(len(model.mods)), [&](const Nat& i) { return std::tuple{or_(index(model.mods, i), no_mod()), or_(index(mods, i), no_parts())}; });
    auto generics = fold(pairs, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<lower::ModDef, Parts>& _p1) {
        auto&& m = std::get<0>(_p1);
        auto&& p_ = std::get<1>(_p1);
        return len(p_.generic) > Nat(0u) ? prelude::push(acc, m.name) : acc;
    });
    auto per_module = run_to_end(each_job(pairs, ({
        auto generics_2 = generics;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, Text>>>(std::tuple<lower::ModDef, Parts>)>>(prism_rtl::rc([=](std::tuple<lower::ModDef, Parts> p0) {
        return ({
            auto generics_2_3 = generics_2;
            entered(once_job([=]() {
            return ({
                auto [m, p_] = p0;
                (prism_rtl::more(prism_rtl::rc(ModuleFiles(m, p_, generics_2_3))));
            });
        }));
        });
    }));
    })));
    auto main_includes = lexer::join(append(append(Array(std::vector{Text("#include \"elem.types.hpp\"")}), each(model.mods, [&](const lower::ModDef& m) { return prism_rtl::cat("#include \"", m.name, ".hpp\""); })), each(generics, [&](const Text& n) { return prism_rtl::cat("#include \"", n, ".generic.hpp\""); })), Text("\n"));
    auto canvas_include = canvas_1 ? cpp_templates::cpp_canvas_include(Text("")) : Text("");
    auto main = cpp_templates::cpp_main(model.name, prism_rtl::cat("#include \"programs.hpp\"\n", canvas_include), regs, checks, script_list, world, run_root, lexer::join(concat2(each(Array(std::vector{elem, answer}), [&](const Parts& p_) { return p_.defs; })), Text("\n\n")));
    auto groups = run_to_end(each_job(filter(model.mods, [&](const lower::ModDef& m) { return (len(m.types_with) > Nat(1u)) && (or_(index(m.types_with, Nat(0u)), Text("")) == m.name); }), ({
        auto pairs_2 = pairs;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text>>(lower::ModDef)>>(prism_rtl::rc([=](lower::ModDef p0) {
        return ({
            auto pairs_2_3 = pairs_2;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                (prism_rtl::more(prism_rtl::rc(GroupTypesFile(pairs_2_3, m.types_with))));
            });
        }));
        });
    }));
    })));
    auto files = fold(per_module, Array<std::tuple<Text, Text>>{}, [&](const Array<std::tuple<Text, Text>>& acc, const Array<std::tuple<Text, Text>>& fs) { return append(acc, fs); });
    auto sources = lexer::join(filter(each(files, [&](const std::tuple<Text, Text>& _p0) {
        auto&& f = std::get<0>(_p0);
        return f;
    }), [&](const Text& f) { return lexer::contains(f, Text(".cpp")); }), Text(" "));
    return append(Array(std::vector{std::tuple{Text("Makefile"), cpp_templates::cpp_makefile(model.name, runtime, sources, canvas_1 ? cpp_templates::cpp_makefile_canvas(runtime) : Text(""))}, std::tuple{Text("src/elem.decl.hpp"), elem_decl}, std::tuple{Text("src/elem.types.hpp"), elem_types}, std::tuple{Text("src/programs.hpp"), cpp_templates::cpp_programs_header(model.name, main_includes, programs)}, std::tuple{Text("src/main.cpp"), main}, std::tuple{Text("src/prelude.hpp"), cpp_prelude_template::cpp_prelude_source(Text(""))}}), append(groups, files));
}


prism_rtl::Turn<Array<std::tuple<Text, Text>>> EmitCpp::cycle() const {
    const auto& model = this->model;
    const auto& runtime = this->runtime;
    const auto& scripts = this->scripts;
    auto cp = context(model);
    auto crate_ = in_home(cp, Text(""));
    auto model_1 = model;
    auto runtime_2 = runtime;
    auto scripts_3 = scripts;
    return call_then(start_row_parts(crate_, Text(""), model_1.elem), [=](Parts row_parts_85652) {
        return ({
            auto elem = row_parts_85652;
            call_then(start_answer_parts(crate_, model_1->answer), [=](Parts answer_parts_85700) {
            return ({
                auto answer = answer_parts_85700;
                call_value(each_job(model_1.mods, ({
                auto cp_4 = cp;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Parts>(lower::ModDef)>>(prism_rtl::rc([=](lower::ModDef p0) {
                return ({
                    auto cp_4_5 = cp_4;
                    entered(once_job([=]() {
                    return ({
                        auto m = p0;
                        (prism_rtl::more(prism_rtl::rc(ModuleParts(cp_4_5, m))));
                    });
                }));
                });
            })));
            })), [=](Array<Parts> each_85747) {
                return ({
                    auto mods = each_85747;
                    call_value(each_job(all_programs_cpp(model_1), ({
                    auto crate__4 = crate_;
                    auto model_1_5 = model_1;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::ProgDef)>>(prism_rtl::rc([=](lower::ProgDef p0) {
                    return ({
                        auto crate__4_5 = crate__4;
                        auto model_1_5_5 = model_1_5;
                        entered(once_job([=]() {
                        return ({
                            auto p_ = p0;
                            (prism_rtl::more(prism_rtl::rc(ProgramCpp(crate__4_5, p_, node_fallible_cpp(model_1_5_5, p_.node_)))));
                        });
                    }));
                    });
                })));
                })), [=](Array<Text> each_85812) {
                    return ({
                        auto programs = lexer::join(each_85812, Text("\n\n"));
                        auto regs = concat(each(model_1.programs, [&](const lower::ProgDef& p_) { return prism_rtl::cat("\n.program<", p_.name, ">(\"", p_.prism, "\")"); }));
                        call_value(each_job(model_1.checks, ({
                        auto crate__4 = crate_;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::CheckDef)>>(prism_rtl::rc([=](lower::CheckDef p0) {
                        return ({
                            auto crate__4_5 = crate__4;
                            entered(once_job([=]() {
                            return ({
                                auto c = p0;
                                call_value(each_job(c.lines, ({
                                auto crate__4_5_5 = crate__4_5;
                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Ex)>>(prism_rtl::rc([=](lower::Ex p0) {
                                return ({
                                    auto crate__4_5_5_5 = crate__4_5_5;
                                    entered(once_job([=]() {
                                    return ({
                                        auto l = p0;
                                        (prism_rtl::more(prism_rtl::rc(CppExpr(crate__4_5_5_5, l))));
                                    });
                                }));
                                });
                            })));
                            })), [=](Array<Text> each_86115) { return prism_rtl::finished(prism_rtl::cat("\n.check(\"", c.name, "\", [] { return std::vector<Result<Pod>>{", lexer::join(each_86115, Text(", ")), "}; })")); });
                            });
                        }));
                        });
                    })));
                    })), [=](Array<Text> each_86021) {
                        return ({
                            auto checks = concat(each_86021);
                            auto script_list = lexer::join(each(scripts_3, [&](const Text& s) { return prism_rtl::cat("\"", lower::escape(s), "\","); }), Text("\n"));
                            auto world = ({
                                __label__ _done;
                                prism_rtl::Slot<Text> _v;
                                auto&& _m = model_1.root;
                                if (prism_rtl::is_some(_m)) {
                                    auto&& r = prism_rtl::some_of(_m);
                                    _v.set(r->world);
                                    goto _done;
                                }
                                if (prism_rtl::is_none(_m)) {
                                    _v.set(Text("test"));
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            });
                            auto canvas_4 = world == Text("canvas");
                            auto run_root = ({
                                __label__ _done;
                                prism_rtl::Slot<Text> _v;
                                auto&& _m = model_1.root;
                                if (prism_rtl::is_some(_m)) {
                                    auto&& r = prism_rtl::some_of(_m);
                                    _v.set(cpp_templates::cpp_run_root(r.name, canvas_4
                                        ? cpp_templates::cpp_canvas_run(r.name)
                                        : cpp_templates::cpp_no_canvas(r.name)));
                                    goto _done;
                                }
                                if (prism_rtl::is_none(_m)) {
                                    _v.set(cpp_templates::cpp_no_root(model_1.name));
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            });
                            auto both_ = join_parts(elem, answer);
                            auto elem_decl = cpp_templates::cpp_elem_decl(includes(Text("decl"), append(model_1.elem_complete, model_1.elem_declared)), lexer::join(both_.forward, Text("\n\n")), lexer::join(both_.handles, Text("\n\n")), cpp_prelude_template::cpp_prelude_rows(Text("")));
                            auto elem_types = cpp_templates::cpp_elem_types(lexer::join(filter(Array(std::vector{includes(Text("types"), model_1.elem_complete), includes(Text("decl"), model_1.elem_declared)}), [&](const Text& t) { return t != Text(""); }), Text("\n")), lexer::join(both_.cases_, Text("\n\n")));
                            auto pairs = each(check_errors::range0(len(model_1.mods)), [&](const Nat& i) { return std::tuple{or_(index(model_1.mods, i), no_mod()), or_(index(mods, i), no_parts())}; });
                            auto generics = fold(pairs, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<lower::ModDef, Parts>& _p1) {
                                auto&& m = std::get<0>(_p1);
                                auto&& p_ = std::get<1>(_p1);
                                return len(p_.generic) > Nat(0u) ? prelude::push(acc, m.name) : acc;
                            });
                            call_value(each_job(pairs, ({
                            auto generics_5 = generics;
                            static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, Text>>>(std::tuple<lower::ModDef, Parts>)>>(prism_rtl::rc([=](std::tuple<lower::ModDef, Parts> p0) {
                            return ({
                                auto generics_5_6 = generics_5;
                                entered(once_job([=]() {
                                return ({
                                    auto [m, p_] = p0;
                                    (prism_rtl::more(prism_rtl::rc(ModuleFiles(m, p_, generics_5_6))));
                                });
                            }));
                            });
                        }));
                        })), [=](Array<Array<std::tuple<Text, Text>>> each_87135) {
                            return ({
                                auto per_module = each_87135;
                                auto main_includes = lexer::join(append(append(Array(std::vector{Text("#include \"elem.types.hpp\"")}), each(model_1.mods, [&](const lower::ModDef& m) { return prism_rtl::cat("#include \"", m.name, ".hpp\""); })), each(generics, [&](const Text& n) { return prism_rtl::cat("#include \"", n, ".generic.hpp\""); })), Text("\n"));
                                auto canvas_include = canvas_4 ? cpp_templates::cpp_canvas_include(Text("")) : Text("");
                                auto main = cpp_templates::cpp_main(model_1.name, prism_rtl::cat("#include \"programs.hpp\"\n", canvas_include), regs, checks, script_list, world, run_root, lexer::join(concat2(each(Array(std::vector{elem, answer}), [&](const Parts& p_) { return p_.defs; })), Text("\n\n")));
                                call_value(each_job(filter(model_1.mods, [&](const lower::ModDef& m) { return (len(m.types_with) > Nat(1u)) && (or_(index(m.types_with, Nat(0u)), Text("")) == m.name); }), ({
                                auto pairs_5 = pairs;
                                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text>>(lower::ModDef)>>(prism_rtl::rc([=](lower::ModDef p0) {
                                return ({
                                    auto pairs_5_6 = pairs_5;
                                    entered(once_job([=]() {
                                    return ({
                                        auto m = p0;
                                        (prism_rtl::more(prism_rtl::rc(GroupTypesFile(pairs_5_6, m.types_with))));
                                    });
                                }));
                                });
                            }));
                            })), [=](Array<std::tuple<Text, Text>> each_87645) {
                                return ({
                                    auto groups = each_87645;
                                    auto files = fold(per_module, Array<std::tuple<Text, Text>>{}, [&](const Array<std::tuple<Text, Text>>& acc, const Array<std::tuple<Text, Text>>& fs) { return append(acc, fs); });
                                    auto sources = lexer::join(filter(each(files, [&](const std::tuple<Text, Text>& _p0) {
                                        auto&& f = std::get<0>(_p0);
                                        return f;
                                    }), [&](const Text& f) { return lexer::contains(f, Text(".cpp")); }), Text(" "));
                                    (prism_rtl::finished(append(Array(std::vector{std::tuple{Text("Makefile"), cpp_templates::cpp_makefile(model_1.name, runtime_2, sources, canvas_4 ? cpp_templates::cpp_makefile_canvas(runtime_2) : Text(""))}, std::tuple{Text("src/elem.decl.hpp"), elem_decl}, std::tuple{Text("src/elem.types.hpp"), elem_types}, std::tuple{Text("src/programs.hpp"), cpp_templates::cpp_programs_header(model_1.name, main_includes, programs)}, std::tuple{Text("src/main.cpp"), main}, std::tuple{Text("src/prelude.hpp"), cpp_prelude_template::cpp_prelude_source(Text(""))}}), append(groups, files))));
                                });
                            });
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start EmitCpp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Text, Text>>> start_emit_cpp(lower::Model model, Text runtime, Array<Text> scripts) {
    return std::make_shared<EmitCpp>(model, runtime, scripts);
}


/// let noMod
lower::ModDef no_mod() {
    return lower::ModDef{.name = Text(""), .prism = Text(""), .path_ = Text(""), .uses = Array<Text>{}, .complete = Array<Text>{}, .declared = Array<Text>{}, .types_with = Array<Text>{}, .items = Array<lower::Item>{}};
}


/// GroupTypesFile: unbounded fn [((ModDef, Parts))], [Text] -> ((Text, Text))
std::tuple<Text, Text> group_types_file(const Array<std::tuple<lower::ModDef, Parts>>& pairs, const Array<Text>& group) {
    auto members_ = filter(pairs, [&](const std::tuple<lower::ModDef, Parts>& _p0) {
        auto&& m = std::get<0>(_p0);
        return among(group, m.name);
    });
    auto p_ = fold(members_, no_parts(), [&](const Parts& acc, const std::tuple<lower::ModDef, Parts>& _p1) {
        auto&& q = std::get<1>(_p1);
        return join_parts(acc, q);
    });
    auto complete = fold(members_, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<lower::ModDef, Parts>& _p1) {
        auto&& m = std::get<0>(_p1);
        return fold(m.complete, acc, [&](const Array<Text>& a, const Text& n) { return among(a, n) || among(group, n) ? a : prelude::push(a, n); });
    });
    auto declared_ = fold(members_, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<lower::ModDef, Parts>& _p1) {
        auto&& m = std::get<0>(_p1);
        return fold(m.declared, acc, [&](const Array<Text>& a, const Text& n) {
            return (among(a, n) || among(group, n)) || among(complete, n)
                ? a
                : prelude::push(a, n);
        });
    });
    auto title = prism_rtl::cat("The modules ", lexer::join(each(group, [&](const Text& n) { return prism_rtl::cat("`", n, "`"); }), Text(", ")));
    return std::tuple{prism_rtl::cat("src/", group_name(group), ".types.hpp"), types_header(title, group, declared_, complete, p_)};
}


prism_rtl::Turn<std::tuple<Text, Text>> GroupTypesFile::cycle() const {
    const auto& pairs = this->pairs;
    const auto& group = this->group;
    auto members_ = filter(pairs, [&](const std::tuple<lower::ModDef, Parts>& _p0) {
        auto&& m = std::get<0>(_p0);
        return among(group, m.name);
    });
    auto p_ = fold(members_, no_parts(), [&](const Parts& acc, const std::tuple<lower::ModDef, Parts>& _p1) {
        auto&& q = std::get<1>(_p1);
        return join_parts(acc, q);
    });
    auto complete = fold(members_, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<lower::ModDef, Parts>& _p1) {
        auto&& m = std::get<0>(_p1);
        return fold(m.complete, acc, [&](const Array<Text>& a, const Text& n) { return among(a, n) || among(group, n) ? a : prelude::push(a, n); });
    });
    auto declared_ = fold(members_, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<lower::ModDef, Parts>& _p1) {
        auto&& m = std::get<0>(_p1);
        return fold(m.declared, acc, [&](const Array<Text>& a, const Text& n) {
            return (among(a, n) || among(group, n)) || among(complete, n)
                ? a
                : prelude::push(a, n);
        });
    });
    auto title = prism_rtl::cat("The modules ", lexer::join(each(group, [&](const Text& n) { return prism_rtl::cat("`", n, "`"); }), Text(", ")));
    auto group_1 = group;
    return call_then(start_types_header(title, group_1, declared_, complete, p_), [=](Text types_header_89283) { return prism_rtl::finished(std::tuple{prism_rtl::cat("src/", group_name(group_1), ".types.hpp"), types_header_89283}); });
}


/// `Start GroupTypesFile, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, Text>> start_group_types_file(Array<std::tuple<lower::ModDef, Parts>> pairs, Array<Text> group) {
    return std::make_shared<GroupTypesFile>(pairs, group);
}


/// GroupName: fn [Text] -> Text
Text group_name(const Array<Text>& group) {
    return lexer::join(group, Text("-"));
}


/// Among: fn [Text], Text -> Bool
bool among(const Array<Text>& xs, const Text& x) {
    return fold(xs, false, [&](const bool& f, const Text& y) { return f || (y == x); });
}


/// TypesHeader: unbounded fn Text, [Text], [Text], [Text], Parts -> Text
Text types_header(const Text& title, const Array<Text>& members_, const Array<Text>& declared_, const Array<Text>& complete, const Parts& p_) {
    auto includes_ = lexer::join(filter(Array(std::vector{includes(Text("decl"), members_), Text("#include \"elem.decl.hpp\""), includes(Text("decl"), declared_), includes(Text("types"), complete)}), [&](const Text& t) { return t != Text(""); }), Text("\n"));
    auto values_ = lexer::join(order_values(p_.values, fold(p_.values, Map<Text, bool>{}, [&](const Map<Text, bool>& acc, const ValueDecl& v_) { return insert(acc, v_->path_, false); }), Array<Text>{}), Text("\n\n"));
    return cpp_templates::cpp_types_header(title, includes_, values_, lexer::join(p_.cases_, Text("\n\n")));
}


prism_rtl::Turn<Text> TypesHeader::cycle() const {
    const auto& title = this->title;
    const auto& members_ = this->members_;
    const auto& declared_ = this->declared_;
    const auto& complete = this->complete;
    const auto& p_ = this->p_;
    auto includes_ = lexer::join(filter(Array(std::vector{includes(Text("decl"), members_), Text("#include \"elem.decl.hpp\""), includes(Text("decl"), declared_), includes(Text("types"), complete)}), [&](const Text& t) { return t != Text(""); }), Text("\n"));
    auto p__1 = p_;
    auto title_2 = title;
    return call_then(start_order_values(p__1.values, fold(p__1.values, Map<Text, bool>{}, [&](const Map<Text, bool>& acc, const ValueDecl& v_) { return insert(acc, v_->path_, false); }), Array<Text>{}), [=](Array<Text> order_values_90172) {
        return ({
            auto values_ = lexer::join(order_values_90172, Text("\n\n"));
            (prism_rtl::finished(cpp_templates::cpp_types_header(title_2, includes_, values_, lexer::join(p__1.cases_, Text("\n\n")))));
        });
    });
}


/// `Start TypesHeader, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_types_header(Text title, Array<Text> members_, Array<Text> declared_, Array<Text> complete, Parts p_) {
    return std::make_shared<TypesHeader>(title, members_, declared_, complete, p_);
}


/// Includes: fn Text, [Text] -> Text
Text includes(const Text& layer, const Array<Text>& ms) {
    return lexer::join(each(ms, [&](const Text& m) {
        return layer == Text("")
            ? prism_rtl::cat("#include \"", m, ".hpp\"")
            : prism_rtl::cat("#include \"", m, ".", layer, ".hpp\"");
    }), Text("\n"));
}


/// Chunks: fn [Text] -> [ [Text] ]
Array<Array<Text>> chunks(const Array<Text>& defs) {
    auto [done, current, size_] = fold(defs, std::tuple{Array<Array<Text>>{}, Array<Text>{}, Nat(0u)}, [&](const std::tuple<Array<Array<Text>>, Array<Text>, Nat>& _p0, const Text& d) {
        auto&& acc = std::get<0>(_p0);
        auto&& cur = std::get<1>(_p0);
        auto&& n = std::get<2>(_p0);
        return (n > chunk_size()) && (len(cur) > Nat(0u))
            ? std::tuple{prelude::push(acc, cur), Array(std::vector{d}), len_text(d)}
            : std::tuple{acc, prelude::push(cur, d), n + len_text(d)};
    });
    return (len(current) == Nat(0u)) && (len(done) > Nat(0u))
        ? done
        : prelude::push(done, current);
}


/// let chunkSize
Nat chunk_size() {
    return Nat(250000u);
}


/// ModuleFiles: unbounded fn ModDef, Parts, [Text] -> [((Text, Text))]
Array<std::tuple<Text, Text>> module_files(const lower::ModDef& m, const Parts& p_, const Array<Text>& generics) {
    auto title = m.prism == Text("")
        ? Text("The root module")
        : prism_rtl::cat("The module `", m.prism, "`");
    auto needed = append(m.complete, m.declared);
    auto decl = cpp_templates::cpp_decl_header(title, Text(""), lexer::join(p_.forward, Text("\n\n")), lexer::join(p_.handles, Text("\n\n")));
    auto types = len(m.types_with) > Nat(1u)
        ? cpp_templates::cpp_types_in_group(title, group_name(m.types_with))
        : types_header(title, Array(std::vector{m.name}), m.declared, m.complete, p_);
    auto head_includes = lexer::join(filter(Array(std::vector{prism_rtl::cat("#include \"", m.name, ".types.hpp\"\n#include \"elem.types.hpp\""), includes(Text("types"), needed)}), [&](const Text& t) { return t != Text(""); }), Text("\n"));
    auto head = cpp_templates::cpp_mod_header(title, head_includes, lexer::join(p_.protos, Text("\n")), lexer::join(p_.outer, Text("\n\n")), lexer::join(p_.classes, Text("\n\n")));
    auto with_mine = append(Array(std::vector{m.name}), needed);
    auto generic = len(p_.generic) == Nat(0u)
        ? Array<std::tuple<Text, Text>>{}
        : Array(std::vector{std::tuple{prism_rtl::cat("src/", m.name, ".generic.hpp"), cpp_templates::cpp_generic_header(title, includes(Text(""), with_mine), lexer::join(p_.generic, Text("\n\n")))}});
    auto body_includes = lexer::join(filter(Array(std::vector{includes(Text(""), with_mine), includes(Text("generic"), filter(with_mine, [&](const Text& n) { return among(generics, n); }))}), [&](const Text& t) { return t != Text(""); }), Text("\n"));
    auto chunks_ = chunks(p_.defs);
    auto sources = each(check_errors::range0(len(chunks_)), [&](const Nat& k) { return std::tuple{chunk_file(m.name, k), cpp_templates::cpp_module(title, m->path_, m.name, body_includes, lexer::join(or_(index(chunks_, k), Array<Text>{}), Text("\n\n")))}; });
    return append(append(Array(std::vector{std::tuple{prism_rtl::cat("src/", m.name, ".decl.hpp"), decl}, std::tuple{prism_rtl::cat("src/", m.name, ".types.hpp"), types}, std::tuple{prism_rtl::cat("src/", m.name, ".hpp"), head}}), generic), sources);
}


prism_rtl::Turn<Array<std::tuple<Text, Text>>> ModuleFiles::cycle() const {
    const auto& m = this->m;
    const auto& p_ = this->p_;
    const auto& generics = this->generics;
    auto title = m.prism == Text("")
        ? Text("The root module")
        : prism_rtl::cat("The module `", m.prism, "`");
    auto needed = append(m.complete, m.declared);
    auto decl = cpp_templates::cpp_decl_header(title, Text(""), lexer::join(p_.forward, Text("\n\n")), lexer::join(p_.handles, Text("\n\n")));
    auto types = len(m.types_with) > Nat(1u)
        ? cpp_templates::cpp_types_in_group(title, group_name(m.types_with))
        : types_header(title, Array(std::vector{m.name}), m.declared, m.complete, p_);
    auto head_includes = lexer::join(filter(Array(std::vector{prism_rtl::cat("#include \"", m.name, ".types.hpp\"\n#include \"elem.types.hpp\""), includes(Text("types"), needed)}), [&](const Text& t) { return t != Text(""); }), Text("\n"));
    auto head = cpp_templates::cpp_mod_header(title, head_includes, lexer::join(p_.protos, Text("\n")), lexer::join(p_.outer, Text("\n\n")), lexer::join(p_.classes, Text("\n\n")));
    auto with_mine = append(Array(std::vector{m.name}), needed);
    auto generic = len(p_.generic) == Nat(0u)
        ? Array<std::tuple<Text, Text>>{}
        : Array(std::vector{std::tuple{prism_rtl::cat("src/", m.name, ".generic.hpp"), cpp_templates::cpp_generic_header(title, includes(Text(""), with_mine), lexer::join(p_.generic, Text("\n\n")))}});
    auto body_includes = lexer::join(filter(Array(std::vector{includes(Text(""), with_mine), includes(Text("generic"), filter(with_mine, [&](const Text& n) { return among(generics, n); }))}), [&](const Text& t) { return t != Text(""); }), Text("\n"));
    auto chunks_ = chunks(p_.defs);
    auto sources = each(check_errors::range0(len(chunks_)), [&](const Nat& k) { return std::tuple{chunk_file(m.name, k), cpp_templates::cpp_module(title, m->path_, m.name, body_includes, lexer::join(or_(index(chunks_, k), Array<Text>{}), Text("\n\n")))}; });
    return prism_rtl::finished(append(append(Array(std::vector{std::tuple{prism_rtl::cat("src/", m.name, ".decl.hpp"), decl}, std::tuple{prism_rtl::cat("src/", m.name, ".types.hpp"), types}, std::tuple{prism_rtl::cat("src/", m.name, ".hpp"), head}}), generic), sources));
}


/// `Start ModuleFiles, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Text, Text>>> start_module_files(lower::ModDef m, Parts p_, Array<Text> generics) {
    return std::make_shared<ModuleFiles>(m, p_, generics);
}


/// ChunkFile: fn Text, Nat -> Text
Text chunk_file(const Text& m, const Nat& k) {
    return k == Nat(0u)
        ? prism_rtl::cat("src/", m, ".cpp")
        : prism_rtl::cat("src/", m, "_", k + Nat(1u), ".cpp");
}


/// AllProgramsCpp: fn Model -> [ProgDef]
Array<lower::ProgDef> all_programs_cpp(const lower::Model& model) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<lower::ProgDef>> _v;
        auto&& _m = model.root;
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(fold(model.programs, false, [&](const bool& f, const lower::ProgDef& p_) { return f || (p_.name == r.name); })
                ? model.programs
                : prelude::push(model.programs, r));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(model.programs);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// OrderValues: unbounded fn [ValueDecl], (Text ==> Bool), [Text] -> [Text]
Array<Text> order_values(const Array<ValueDecl>& left, const Map<Text, bool>& done, const Array<Text>& acc) {
    auto ready = filter(left, [&](const ValueDecl& v_) { return fold(v_.deps, true, [&](const bool& ok, const Text& d) { return ok && ((d == v_->path_) || declared(done, d)); }); });
    return len(left) == Nat(0u)
        ? acc
        : len(ready) == Nat(0u)
        ? append(acc, each(left, [&](const ValueDecl& v_) { return v_->text; }))
        : ({
        auto later_ = filter(left, [&](const ValueDecl& v_) { return !fold(v_.deps, true, [&](const bool& ok, const Text& d) { return ok && ((d == v_->path_) || declared(done, d)); }); });
        auto done2 = fold(ready, done, [&](const Map<Text, bool>& m, const ValueDecl& v_) { return insert(m, v_->path_, true); });
        order_values(later_, done2, append(acc, each(ready, [&](const ValueDecl& v_) { return v_->text; })));
    });
}


prism_rtl::Turn<Array<Text>> OrderValues::cycle() const {
    const auto& left = this->left;
    const auto& done = this->done;
    const auto& acc = this->acc;
    auto ready = filter(left, [&](const ValueDecl& v_) { return fold(v_.deps, true, [&](const bool& ok, const Text& d) { return ok && ((d == v_->path_) || declared(done, d)); }); });
    return len(left) == Nat(0u)
        ? prism_rtl::finished(acc)
        : len(ready) == Nat(0u)
        ? prism_rtl::finished(append(acc, each(left, [&](const ValueDecl& v_) { return v_->text; })))
        : ({
        auto later_ = filter(left, [&](const ValueDecl& v_) { return !fold(v_.deps, true, [&](const bool& ok, const Text& d) { return ok && ((d == v_->path_) || declared(done, d)); }); });
        auto done2 = fold(ready, done, [&](const Map<Text, bool>& m, const ValueDecl& v_) { return insert(m, v_->path_, true); });
        (prism_rtl::more(prism_rtl::rc(OrderValues(later_, done2, append(acc, each(ready, [&](const ValueDecl& v_) { return v_->text; }))))));
    });
}


/// `Start OrderValues, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_order_values(Array<ValueDecl> left, Map<Text, bool> done, Array<Text> acc) {
    return std::make_shared<OrderValues>(left, done, acc);
}


/// Declared: fn (Text ==> Bool), Text -> Bool
bool declared(const Map<Text, bool>& done, const Text& d) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = prelude::get(done, d);
        if (prism_rtl::is_some(_m)) {
            auto&& b = prism_rtl::some_of(_m);
            _v.set(b);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(true);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}

}  // namespace crate::emit_cpp
