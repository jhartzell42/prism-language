// The module `EmitCpp`, from `target/bootstrap/cpp-src/prismc/emit_cpp.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include "emit_cpp.hpp"
#include "ast.hpp"
#include "check_env.hpp"
#include "check_errors.hpp"
#include "check_types.hpp"
#include "cpp_prelude_template.hpp"
#include "cpp_templates.hpp"
#include "lexer.hpp"
#include "lower.hpp"
#include "prelude_template.hpp"
#include "typed.hpp"
#include "check_env.generic.hpp"
#include "lexer.generic.hpp"
#include "lower.generic.hpp"

namespace crate::emit_cpp {

/// Includes: fn Text, [Text] -> Text
Text includes(const Text& layer, const Array<Text>& ms) {
    return lexer::join(each(ms, [&](const Text& m) {
        return layer == Text::lit("")
            ? prism_rtl::cat("#include \"", m, ".hpp\"")
            : prism_rtl::cat("#include \"", m, ".", layer, ".hpp\"");
    }), Text::lit("\n"));
}


/// Chunks: fn [Text] -> [ [Text] ]
Array<Array<Text>> chunks(const Array<Text>& defs) {
    auto [done, current, size_] = fold(defs, std::tuple{Array<Array<Text>>{}, Array<Text>{}, Nat(0u)}, [&](const std::tuple<Array<Array<Text>>, Array<Text>, Nat>& _p0, const Text& d) {
        auto&& acc = std::get<0>(_p0);
        auto&& cur = std::get<1>(_p0);
        auto&& n = std::get<2>(_p0);
        return (n > chunk_size()) && (len(cur) > Nat(0u))
            ? std::tuple{prelude::push(acc, cur), Array(std::vector{d}), len_text(d)}
            : std::tuple{acc, prelude::push(cur, d), n + len_text(d)};
    });
    return (len(current) == Nat(0u)) && (len(done) > Nat(0u))
        ? done
        : prelude::push(done, current);
}


/// let chunkSize
Nat chunk_size() {
    return Nat(250000u);
}


/// ModuleFiles: unbounded fn ModDef, Parts, [Text] -> [((Text, Text))]
Array<std::tuple<Text, Text>> module_files(const lower::ModDef& m, const Parts& p_, const Array<Text>& generics) {
    auto title = m.prism == Text::lit("")
        ? Text::lit("The root module")
        : prism_rtl::cat("The module `", m.prism, "`");
    auto needed = append(m.complete, m.declared);
    auto decl = cpp_templates::cpp_decl_header(title, Text::lit(""), lexer::join(p_.forward, Text::lit("\n\n")), lexer::join(p_.handles, Text::lit("\n\n")));
    auto types = len(m.types_with) > Nat(1u)
        ? cpp_templates::cpp_types_in_group(title, group_name(m.types_with))
        : types_header(title, Array(std::vector{m.name}), m.declared, m.complete, p_);
    auto head_includes = lexer::join(filter(Array(std::vector{prism_rtl::cat("#include \"", m.name, ".types.hpp\"\n#include \"elem.types.hpp\""), includes(Text::lit("types"), needed)}), [&](const Text& t) { return t != Text::lit(""); }), Text::lit("\n"));
    auto head = cpp_templates::cpp_mod_header(title, head_includes, lexer::join(p_.protos, Text::lit("\n")), lexer::join(p_.outer, Text::lit("\n\n")), lexer::join(p_.classes, Text::lit("\n\n")));
    auto with_mine = append(Array(std::vector{m.name}), needed);
    auto generic = len(p_.generic) == Nat(0u)
        ? Array<std::tuple<Text, Text>>{}
        : Array(std::vector{std::tuple{prism_rtl::cat("src/", m.name, ".generic.hpp"), cpp_templates::cpp_generic_header(title, includes(Text::lit(""), with_mine), lexer::join(p_.generic, Text::lit("\n\n")))}});
    auto body_includes = lexer::join(filter(Array(std::vector{includes(Text::lit(""), with_mine), includes(Text::lit("generic"), filter(with_mine, [&](const Text& n) { return among(generics, n); }))}), [&](const Text& t) { return t != Text::lit(""); }), Text::lit("\n"));
    auto chunks_ = chunks(p_.defs);
    auto sources = each(check_errors::range0(len(chunks_)), [&](const Nat& k) { return std::tuple{chunk_file(m.name, k), cpp_templates::cpp_module(title, m->path_, m.name, body_includes, lexer::join(or_(index(chunks_, k), Array<Text>{}), Text::lit("\n\n")))}; });
    return append(append(Array(std::vector{std::tuple{prism_rtl::cat("src/", m.name, ".decl.hpp"), decl}, std::tuple{prism_rtl::cat("src/", m.name, ".types.hpp"), types}, std::tuple{prism_rtl::cat("src/", m.name, ".hpp"), head}}), generic), sources);
}


prism_rtl::Turn<Array<std::tuple<Text, Text>>> ModuleFiles::cycle() const {
    const auto& m = this->m;
    const auto& p_ = this->p_;
    const auto& generics = this->generics;
    auto title = m.prism == Text::lit("")
        ? Text::lit("The root module")
        : prism_rtl::cat("The module `", m.prism, "`");
    auto needed = append(m.complete, m.declared);
    auto decl = cpp_templates::cpp_decl_header(title, Text::lit(""), lexer::join(p_.forward, Text::lit("\n\n")), lexer::join(p_.handles, Text::lit("\n\n")));
    auto types = len(m.types_with) > Nat(1u)
        ? cpp_templates::cpp_types_in_group(title, group_name(m.types_with))
        : types_header(title, Array(std::vector{m.name}), m.declared, m.complete, p_);
    auto head_includes = lexer::join(filter(Array(std::vector{prism_rtl::cat("#include \"", m.name, ".types.hpp\"\n#include \"elem.types.hpp\""), includes(Text::lit("types"), needed)}), [&](const Text& t) { return t != Text::lit(""); }), Text::lit("\n"));
    auto head = cpp_templates::cpp_mod_header(title, head_includes, lexer::join(p_.protos, Text::lit("\n")), lexer::join(p_.outer, Text::lit("\n\n")), lexer::join(p_.classes, Text::lit("\n\n")));
    auto with_mine = append(Array(std::vector{m.name}), needed);
    auto generic = len(p_.generic) == Nat(0u)
        ? Array<std::tuple<Text, Text>>{}
        : Array(std::vector{std::tuple{prism_rtl::cat("src/", m.name, ".generic.hpp"), cpp_templates::cpp_generic_header(title, includes(Text::lit(""), with_mine), lexer::join(p_.generic, Text::lit("\n\n")))}});
    auto body_includes = lexer::join(filter(Array(std::vector{includes(Text::lit(""), with_mine), includes(Text::lit("generic"), filter(with_mine, [&](const Text& n) { return among(generics, n); }))}), [&](const Text& t) { return t != Text::lit(""); }), Text::lit("\n"));
    auto chunks_ = chunks(p_.defs);
    auto sources = each(check_errors::range0(len(chunks_)), [&](const Nat& k) { return std::tuple{chunk_file(m.name, k), cpp_templates::cpp_module(title, m->path_, m.name, body_includes, lexer::join(or_(index(chunks_, k), Array<Text>{}), Text::lit("\n\n")))}; });
    return prism_rtl::finished(append(append(Array(std::vector{std::tuple{prism_rtl::cat("src/", m.name, ".decl.hpp"), decl}, std::tuple{prism_rtl::cat("src/", m.name, ".types.hpp"), types}, std::tuple{prism_rtl::cat("src/", m.name, ".hpp"), head}}), generic), sources));
}


/// `Start ModuleFiles, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Text, Text>>> start_module_files(lower::ModDef m, Parts p_, Array<Text> generics) {
    return prism_rtl::make_rc<ModuleFiles>(m, p_, generics);
}


/// ChunkFile: fn Text, Nat -> Text
Text chunk_file(const Text& m, const Nat& k) {
    return k == Nat(0u)
        ? prism_rtl::cat("src/", m, ".cpp")
        : prism_rtl::cat("src/", m, "_", k + Nat(1u), ".cpp");
}


/// AllProgramsCpp: fn Model -> [ProgDef]
Array<lower::ProgDef> all_programs_cpp(const lower::Model& model) {
    auto&& _m = model.root;
    if (prism_rtl::is_some(_m)) {
        auto&& r = prism_rtl::some_of(_m);
        return fold(model.programs, false, [&](const bool& f, const lower::ProgDef& p_) { return f || (p_.name == r.name); })
            ? model.programs
            : prelude::push(model.programs, r);
    }
    if (prism_rtl::is_none(_m)) {
        return model.programs;
    }
    prism_rtl::unreachable("no arm matched");
}


/// OrderValues: unbounded fn [ValueDecl], (Text ==> Bool), [Text] -> [Text]
Array<Text> order_values(const Array<ValueDecl>& left, const Map<Text, bool>& done, const Array<Text>& acc) {
    auto ready = filter(left, [&](const ValueDecl& v_) { return fold(v_.deps, true, [&](const bool& ok, const Text& d) { return ok && ((d == v_->path_) || declared(done, d)); }); });
    return len(left) == Nat(0u)
        ? acc
        : len(ready) == Nat(0u)
        ? append(acc, each(left, [&](const ValueDecl& v_) { return v_->text; }))
        : ({
        auto later_ = filter(left, [&](const ValueDecl& v_) { return !fold(v_.deps, true, [&](const bool& ok, const Text& d) { return ok && ((d == v_->path_) || declared(done, d)); }); });
        auto done2 = fold(ready, done, [&](const Map<Text, bool>& m, const ValueDecl& v_) { return insert(m, v_->path_, true); });
        order_values(later_, done2, append(acc, each(ready, [&](const ValueDecl& v_) { return v_->text; })));
    });
}


prism_rtl::Turn<Array<Text>> OrderValues::cycle() const {
    const auto& left = this->left;
    const auto& done = this->done;
    const auto& acc = this->acc;
    auto ready = filter(left, [&](const ValueDecl& v_) { return fold(v_.deps, true, [&](const bool& ok, const Text& d) { return ok && ((d == v_->path_) || declared(done, d)); }); });
    return len(left) == Nat(0u)
        ? prism_rtl::finished(acc)
        : len(ready) == Nat(0u)
        ? prism_rtl::finished(append(acc, each(left, [&](const ValueDecl& v_) { return v_->text; })))
        : ({
        auto later_ = filter(left, [&](const ValueDecl& v_) { return !fold(v_.deps, true, [&](const bool& ok, const Text& d) { return ok && ((d == v_->path_) || declared(done, d)); }); });
        auto done2 = fold(ready, done, [&](const Map<Text, bool>& m, const ValueDecl& v_) { return insert(m, v_->path_, true); });
        (prism_rtl::more(prism_rtl::rc(OrderValues(later_, done2, append(acc, each(ready, [&](const ValueDecl& v_) { return v_->text; }))))));
    });
}


/// `Start OrderValues, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_order_values(Array<ValueDecl> left, Map<Text, bool> done, Array<Text> acc) {
    return prism_rtl::make_rc<OrderValues>(left, done, acc);
}


/// Declared: fn (Text ==> Bool), Text -> Bool
bool declared(const Map<Text, bool>& done, const Text& d) {
    auto&& _m = prelude::get(done, d);
    if (prism_rtl::is_some(_m)) {
        auto&& b = prism_rtl::some_of(_m);
        return b;
    }
    if (prism_rtl::is_none(_m)) {
        return true;
    }
    prism_rtl::unreachable("no arm matched");
}

}  // namespace crate::emit_cpp
