// The module `EmitCpp`, from `target/bootstrap/cpp-src/prismc/emit_cpp.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include "crate.hpp"

namespace crate::emit_cpp {

/// `Start EmitCpp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Text, Text>>> start_emit_cpp(lower::Model model, Text runtime, Array<Text> scripts) {
    return std::make_shared<EmitCpp>(model, runtime, scripts);
}


/// Chunks: fn [Text] -> [ [Text] ]
Array<Array<Text>> chunks(const Array<Text>& defs) {
    auto [done, current, size_] = fold(defs, std::tuple{Array<Array<Text>>{}, Array<Text>{}, Nat(0u)}, [&](const std::tuple<Array<Array<Text>>, Array<Text>, Nat>& _p0, const Text& d) {
        auto&& acc = std::get<0>(_p0);
        auto&& cur = std::get<1>(_p0);
        auto&& n = std::get<2>(_p0);
        return (n > chunk_size()) && (len(cur) > Nat(0u))
            ? std::tuple{prelude::push(acc, cur), Array(std::vector{d}), len_text(d)}
            : std::tuple{acc, prelude::push(cur, d), n + len_text(d)};
    });
    return (len(current) == Nat(0u)) && (len(done) > Nat(0u))
        ? done
        : prelude::push(done, current);
}


/// let chunkSize
Nat chunk_size() {
    return Nat(250000u);
}


/// ModuleFiles: fn ModDef, [ [Text] ] -> [((Text, Text))]
Array<std::tuple<Text, Text>> module_files(const lower::ModDef& m, const Array<Array<Text>>& chunks_) {
    auto title = m.prism == Text("")
        ? Text("The root module")
        : prism_rtl::cat("The module `", m.prism, "`");
    return each(check_errors::range0(len(chunks_)), [&](const Nat& k) { return std::tuple{chunk_file(m.name, k), cpp_templates::cpp_module(title, m->path_, m.name, lexer::join(or_(index(chunks_, k), Array<Text>{}), Text("\n\n")))}; });
}


/// ChunkFile: fn Text, Nat -> Text
Text chunk_file(const Text& m, const Nat& k) {
    return k == Nat(0u)
        ? prism_rtl::cat("src/", m, ".cpp")
        : prism_rtl::cat("src/", m, "_", k + Nat(1u), ".cpp");
}


/// AllProgramsCpp: fn Model -> [ProgDef]
Array<lower::ProgDef> all_programs_cpp(const lower::Model& model) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<lower::ProgDef>> _v;
        auto&& _m = model.root;
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(fold(model.programs, false, [&](const bool& f, const lower::ProgDef& p_) { return f || (p_.name == r.name); })
                ? model.programs
                : prelude::push(model.programs, r));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(model.programs);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// Header: unbounded fn Text, Parts, Text -> Text
Text header(const Text& name, const Parts& all, const Text& programs) {
    return cpp_templates::cpp_header(name, lexer::join(all.forward, Text("\n\n")), lexer::join(all.handles, Text("\n\n")), lexer::join(order_values(all.values, fold(all.values, Map<Text, bool>{}, [&](const Map<Text, bool>& m, const ValueDecl& v_) { return insert(m, v_->path_, false); }), Array<Text>{}), Text("\n\n")), lexer::join(all.cases_, Text("\n\n")), cpp_prelude_template::cpp_prelude_rows(Text("")), lexer::join(all.protos, Text("\n")), lexer::join(all.classes, Text("\n\n")), programs, lexer::join(all.generic, Text("\n\n")));
}


prism_rtl::Turn<Text> Header::cycle() const {
    const auto& name = this->name;
    const auto& all = this->all;
    const auto& programs = this->programs;
    auto all_1 = all;
    auto name_2 = name;
    auto programs_3 = programs;
    return call_then(start_order_values(all_1.values, fold(all_1.values, Map<Text, bool>{}, [&](const Map<Text, bool>& m, const ValueDecl& v_) { return insert(m, v_->path_, false); }), Array<Text>{}), [=](Array<Text> order_values_87660) { return prism_rtl::finished(cpp_templates::cpp_header(name_2, lexer::join(all_1.forward, Text("\n\n")), lexer::join(all_1.handles, Text("\n\n")), lexer::join(order_values_87660, Text("\n\n")), lexer::join(all_1.cases_, Text("\n\n")), cpp_prelude_template::cpp_prelude_rows(Text("")), lexer::join(all_1.protos, Text("\n")), lexer::join(all_1.classes, Text("\n\n")), programs_3, lexer::join(all_1.generic, Text("\n\n")))); });
}


/// `Start Header, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_header(Text name, Parts all, Text programs) {
    return std::make_shared<Header>(name, all, programs);
}


/// OrderValues: unbounded fn [ValueDecl], (Text ==> Bool), [Text] -> [Text]
Array<Text> order_values(const Array<ValueDecl>& left, const Map<Text, bool>& done, const Array<Text>& acc) {
    auto ready = filter(left, [&](const ValueDecl& v_) { return fold(v_.deps, true, [&](const bool& ok, const Text& d) { return ok && ((d == v_->path_) || declared(done, d)); }); });
    return len(left) == Nat(0u)
        ? acc
        : len(ready) == Nat(0u)
        ? append(acc, each(left, [&](const ValueDecl& v_) { return v_->text; }))
        : ({
        auto later_ = filter(left, [&](const ValueDecl& v_) { return !fold(v_.deps, true, [&](const bool& ok, const Text& d) { return ok && ((d == v_->path_) || declared(done, d)); }); });
        auto done2 = fold(ready, done, [&](const Map<Text, bool>& m, const ValueDecl& v_) { return insert(m, v_->path_, true); });
        order_values(later_, done2, append(acc, each(ready, [&](const ValueDecl& v_) { return v_->text; })));
    });
}


prism_rtl::Turn<Array<Text>> OrderValues::cycle() const {
    const auto& left = this->left;
    const auto& done = this->done;
    const auto& acc = this->acc;
    auto ready = filter(left, [&](const ValueDecl& v_) { return fold(v_.deps, true, [&](const bool& ok, const Text& d) { return ok && ((d == v_->path_) || declared(done, d)); }); });
    return len(left) == Nat(0u)
        ? prism_rtl::finished(acc)
        : len(ready) == Nat(0u)
        ? prism_rtl::finished(append(acc, each(left, [&](const ValueDecl& v_) { return v_->text; })))
        : ({
        auto later_ = filter(left, [&](const ValueDecl& v_) { return !fold(v_.deps, true, [&](const bool& ok, const Text& d) { return ok && ((d == v_->path_) || declared(done, d)); }); });
        auto done2 = fold(ready, done, [&](const Map<Text, bool>& m, const ValueDecl& v_) { return insert(m, v_->path_, true); });
        (prism_rtl::more(prism_rtl::rc(OrderValues(later_, done2, append(acc, each(ready, [&](const ValueDecl& v_) { return v_->text; }))))));
    });
}


/// `Start OrderValues, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_order_values(Array<ValueDecl> left, Map<Text, bool> done, Array<Text> acc) {
    return std::make_shared<OrderValues>(left, done, acc);
}


/// Declared: fn (Text ==> Bool), Text -> Bool
bool declared(const Map<Text, bool>& done, const Text& d) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = prelude::get(done, d);
        if (prism_rtl::is_some(_m)) {
            auto&& b = prism_rtl::some_of(_m);
            _v.set(b);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(true);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}

}  // namespace crate::emit_cpp
