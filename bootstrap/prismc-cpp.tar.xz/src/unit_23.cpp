// The modules `Check.Shrink.Walk`, `Check.Typed`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/shrink/walk/module.hpp>
#include <syntax/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Shrink.Walk`, from `target/bootstrap/cpp-src/prismc/check/shrink/walk.prism`.
namespace crate::check::shrink::walk {

void Kid::show(Printer& p) const {
    if (auto c = std::get_if<KidExpr>(&cases())) p.choice("KidExpr", {c->a0, c->a1});
    else if (auto c = std::get_if<KidStmts>(&cases())) p.choice("KidStmts", {c->a0, c->a1});
}

Pod Kid::to_pod() const {
    return std::holds_alternative<KidExpr>(cases()) ? Pod::choice("KidExpr", {prism_rtl::to_pod(std::get<KidExpr>(cases()).a0), prism_rtl::to_pod(std::get<KidExpr>(cases()).a1)})
        : std::holds_alternative<KidStmts>(cases()) ? Pod::choice("KidStmts", {prism_rtl::to_pod(std::get<KidStmts>(cases()).a0), prism_rtl::to_pod(std::get<KidStmts>(cases()).a1)})
        : Pod();
}

Result<Kid> Kid::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "KidExpr" && c->args.size() == 2) return Kid(KidExpr{TRY(prism_rtl::from_pod<crate::syntax::Expr>(c->args[0])), TRY(prism_rtl::from_pod<Map<Text, crate::check::shrink::Rel>>(c->args[1]))});
        if (c->ctor == "KidStmts" && c->args.size() == 2) return Kid(KidStmts{TRY(prism_rtl::from_pod<Array<crate::syntax::Stmt>>(c->args[0])), TRY(prism_rtl::from_pod<Map<Text, crate::check::shrink::Rel>>(c->args[1]))});
    }
    return mismatch<Kid>("a Kid", p);
}


void Site::show(Printer& p) const {
    p.record("Site", {{"callee", callee}, {"args", args}, {"span", span}, {"rels", rels}});
}

Pod Site::to_pod() const {
    return Pod::record("Site", {{"callee", prism_rtl::to_pod(callee)}, {"args", prism_rtl::to_pod(args)}, {"span", prism_rtl::to_pod(span)}, {"rels", prism_rtl::to_pod(rels)}});
}

Result<Site> Site::from_pod(const Pod& whole) {
    return Site{.callee = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "callee")))), .args = TRY(prism_rtl::from_pod<Array<crate::syntax::Arg>>(TRY(crate::prelude::field(whole, "args")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span")))), .rels = TRY(prism_rtl::from_pod<Map<Text, crate::check::shrink::Rel>>(TRY(crate::prelude::field(whole, "rels"))))};
}


void Spot::show(Printer& p) const {
    if (auto c = std::get_if<SpotExpr>(&cases())) p.choice("SpotExpr", {c->a0, c->a1});
    else if (auto c = std::get_if<SpotStmt>(&cases())) p.choice("SpotStmt", {c->a0, c->a1});
}

Pod Spot::to_pod() const {
    return std::holds_alternative<SpotExpr>(cases()) ? Pod::choice("SpotExpr", {prism_rtl::to_pod(std::get<SpotExpr>(cases()).a0), prism_rtl::to_pod(std::get<SpotExpr>(cases()).a1)})
        : std::holds_alternative<SpotStmt>(cases()) ? Pod::choice("SpotStmt", {prism_rtl::to_pod(std::get<SpotStmt>(cases()).a0), prism_rtl::to_pod(std::get<SpotStmt>(cases()).a1)})
        : Pod();
}

Result<Spot> Spot::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "SpotExpr" && c->args.size() == 2) return Spot(SpotExpr{TRY(prism_rtl::from_pod<crate::syntax::Expr>(c->args[0])), TRY(prism_rtl::from_pod<Map<Text, crate::check::shrink::Rel>>(c->args[1]))});
        if (c->ctor == "SpotStmt" && c->args.size() == 2) return Spot(SpotStmt{TRY(prism_rtl::from_pod<crate::syntax::Stmt>(c->args[0])), TRY(prism_rtl::from_pod<Map<Text, crate::check::shrink::Rel>>(c->args[1]))});
    }
    return mismatch<Spot>("a Spot", p);
}


/// ExprSpots: unbounded fn Expr, (Text ==> Rel) -> [Spot]
Array<Spot> expr_spots(const crate::syntax::Expr& e, const Map<Text, crate::check::shrink::Rel>& m) {
    return run_to_end(fold_job(expr_kids(e, m), Array(std::vector{Spot(Spot::SpotExpr{e, m})}), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Spot>>(std::tuple<Array<Spot>, Kid>)>>(prism_rtl::rc([=](std::tuple<Array<Spot>, Kid> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto k = p1;
                call_then(start_kid_spots(k), [=](Array<Spot> kid_spots_2175) { return prism_rtl::finished(append(acc, kid_spots_2175)); });
            });
        }));
    }))));
}


prism_rtl::Turn<Array<Spot>> ExprSpots::cycle() const {
    const auto& e = this->e;
    const auto& m = this->m;
    auto e_1 = e;
    auto m_2 = m;
    return call_then(start_expr_kids(e_1, m_2), [=](Array<Kid> expr_kids_2115) {
        return fold_job(expr_kids_2115, Array(std::vector{Spot(Spot::SpotExpr{e_1, m_2})}), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Spot>>(std::tuple<Array<Spot>, Kid>)>>(prism_rtl::rc([=](std::tuple<Array<Spot>, Kid> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto k = p1;
                    call_then(start_kid_spots(k), [=](Array<Spot> kid_spots_2175) { return prism_rtl::finished(append(acc, kid_spots_2175)); });
                });
            }));
        })))->cycle();
    });
}


/// `Start ExprSpots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Spot>> start_expr_spots(crate::syntax::Expr e, Map<Text, crate::check::shrink::Rel> m) {
    return prism_rtl::make_rc<ExprSpots>(e, m);
}


/// KidSpots: unbounded fn Kid -> [Spot]
Array<Spot> kid_spots(const Kid& kid0) {
    if (prism_rtl::is<Kid::KidExpr>(kid0)) {
        auto&& x = prism_rtl::as<Kid::KidExpr>(kid0).a0;
        auto&& m = prism_rtl::as<Kid::KidExpr>(kid0).a1;
        return expr_spots(x, m);
    }
    if (prism_rtl::is<Kid::KidStmts>(kid0)) {
        auto&& ss = prism_rtl::as<Kid::KidStmts>(kid0).a0;
        auto&& m = prism_rtl::as<Kid::KidStmts>(kid0).a1;
        return stmts_spots(ss, m);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Spot>> KidSpots::cycle() const {
    const auto& kid0 = this->kid0;
    return ({
        prism_rtl::is<Kid::KidExpr>(kid0) ? ({
        auto&& x = prism_rtl::as<Kid::KidExpr>(kid0).a0;
        auto&& m = prism_rtl::as<Kid::KidExpr>(kid0).a1;
        prism_rtl::more(prism_rtl::rc(ExprSpots(x, m)));
    })
        : prism_rtl::is<Kid::KidStmts>(kid0) ? ({
        auto&& ss = prism_rtl::as<Kid::KidStmts>(kid0).a0;
        auto&& m = prism_rtl::as<Kid::KidStmts>(kid0).a1;
        prism_rtl::more(prism_rtl::rc(StmtsSpots(ss, m)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start KidSpots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Spot>> start_kid_spots(Kid kid0) {
    return prism_rtl::make_rc<KidSpots>(kid0);
}


/// StmtsSpots: unbounded fn [Stmt], (Text ==> Rel) -> [Spot]
Array<Spot> stmts_spots(const Array<crate::syntax::Stmt>& stmts, const Map<Text, crate::check::shrink::Rel>& m) {
    auto bm = crate::check::shrink::relations::block_rels(stmts, m);
    return run_to_end(fold_job(stmts, Array<Spot>{}, ({
        auto bm_1 = bm;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Spot>>(std::tuple<Array<Spot>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<Spot>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto bm_1_2 = bm_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto s = p1;
                call_then(start_stmt_spots(s, bm_1_2), [=](Array<Spot> stmt_spots_2562) { return prism_rtl::finished(append(acc, stmt_spots_2562)); });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Spot>> StmtsSpots::cycle() const {
    const auto& stmts = this->stmts;
    const auto& m = this->m;
    auto m_1 = m;
    auto stmts_2 = stmts;
    return call_then(crate::check::shrink::relations::start_block_rels(stmts_2, m_1), [=](Map<Text, crate::check::shrink::Rel> block_rels_2498) {
        return ({
            auto bm = block_rels_2498;
            fold_job(stmts_2, Array<Spot>{}, ({
            auto bm_3 = bm;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Spot>>(std::tuple<Array<Spot>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<Spot>, crate::syntax::Stmt> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto bm_3_4 = bm_3;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto s = p1;
                    call_then(start_stmt_spots(s, bm_3_4), [=](Array<Spot> stmt_spots_2562) { return prism_rtl::finished(append(acc, stmt_spots_2562)); });
                });
            }));
            });
        })));
        }))->cycle();
        });
    });
}


/// `Start StmtsSpots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Spot>> start_stmts_spots(Array<crate::syntax::Stmt> stmts, Map<Text, crate::check::shrink::Rel> m) {
    return prism_rtl::make_rc<StmtsSpots>(stmts, m);
}


/// StmtSpots: unbounded fn Stmt, (Text ==> Rel) -> [Spot]
Array<Spot> stmt_spots(const crate::syntax::Stmt& s, const Map<Text, crate::check::shrink::Rel>& m) {
    return run_to_end(fold_job(stmt_kids(s, m), Array(std::vector{Spot(Spot::SpotStmt{s, m})}), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Spot>>(std::tuple<Array<Spot>, Kid>)>>(prism_rtl::rc([=](std::tuple<Array<Spot>, Kid> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto k = p1;
                call_then(start_kid_spots(k), [=](Array<Spot> kid_spots_2721) { return prism_rtl::finished(append(acc, kid_spots_2721)); });
            });
        }));
    }))));
}


prism_rtl::Turn<Array<Spot>> StmtSpots::cycle() const {
    const auto& s = this->s;
    const auto& m = this->m;
    auto m_1 = m;
    auto s_2 = s;
    return call_then(start_stmt_kids(s_2, m_1), [=](Array<Kid> stmt_kids_2661) {
        return fold_job(stmt_kids_2661, Array(std::vector{Spot(Spot::SpotStmt{s_2, m_1})}), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Spot>>(std::tuple<Array<Spot>, Kid>)>>(prism_rtl::rc([=](std::tuple<Array<Spot>, Kid> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto k = p1;
                    call_then(start_kid_spots(k), [=](Array<Spot> kid_spots_2721) { return prism_rtl::finished(append(acc, kid_spots_2721)); });
                });
            }));
        })))->cycle();
    });
}


/// `Start StmtSpots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Spot>> start_stmt_spots(crate::syntax::Stmt s, Map<Text, crate::check::shrink::Rel> m) {
    return prism_rtl::make_rc<StmtSpots>(s, m);
}


/// BodySpots: unbounded fn FnBody, (Text ==> Rel) -> [Spot]
Array<Spot> body_spots(const crate::syntax::decls::FnBody& fn_body0, const Map<Text, crate::check::shrink::Rel>& m) {
    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(fn_body0)) {
        auto&& e = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(fn_body0).a0;
        return expr_spots(e, m);
    }
    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(fn_body0)) {
        auto&& b = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(fn_body0).a0;
        return stmts_spots(b.stmts, m);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Spot>> BodySpots::cycle() const {
    const auto& fn_body0 = this->fn_body0;
    const auto& m = this->m;
    return ({
        prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(fn_body0) ? ({
        auto&& e = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(fn_body0).a0;
        prism_rtl::more(prism_rtl::rc(ExprSpots(e, m)));
    })
        : prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(fn_body0) ? ({
        auto&& b = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(fn_body0).a0;
        prism_rtl::more(prism_rtl::rc(StmtsSpots(b.stmts, m)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start BodySpots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Spot>> start_body_spots(crate::syntax::decls::FnBody fn_body0, Map<Text, crate::check::shrink::Rel> m) {
    return prism_rtl::make_rc<BodySpots>(fn_body0, m);
}


/// ExprKids: unbounded fn Expr, (Text ==> Rel) -> [Kid]
Array<Kid> expr_kids(const crate::syntax::Expr& e, const Map<Text, crate::check::shrink::Rel>& m) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        return call_kids(c, args, m);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a1;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
        return call_kids(method_callee(n), method_args(r, args), m);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        return exprs_kids(Array(std::vector{l, r}), m);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ESuffixed>(_m)) {
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::ESuffixed>(_m).a2;
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::ESuffixed>(_m).a3;
        return exprs_kids(Array(std::vector{l, r}), m);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& i = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        return exprs_kids(Array(std::vector{r, i}), m);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
        return Array(std::vector{Kid(Kid::KidExpr{x, m})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        return Array(std::vector{Kid(Kid::KidExpr{x, m})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{r, m})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETopicIndex>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::ETopicIndex>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{x, m})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{x, m})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{x, m})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECast>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{x, m})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ENonEmpty>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::ENonEmpty>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{x, m})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EAny>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EAny>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{x, m})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m)) {
        auto&& es = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
        return exprs_kids(es, m);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EArray>(_m)) {
        auto&& es = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
        return exprs_kids(es, m);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMap>(_m)) {
        auto&& kvs = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
        return fold(kvs, Array<Kid>{}, [&](const Array<Kid>& acc, const std::tuple<crate::syntax::Expr, crate::syntax::Expr>& _p1) {
            auto&& k = std::get<0>(_p1);
            auto&& v_ = std::get<1>(_p1);
            return append(acc, exprs_kids(Array(std::vector{k, v_}), m));
        });
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELit>(_m)) {
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
        auto&& _m = l.kind;
        if (prism_rtl::is<crate::syntax::LitKind::LText>(_m)) {
            auto&& segs = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
            return fold(segs, Array<Kid>{}, [&](const Array<Kid>& acc, const crate::syntax::TextSeg& sg) {
                return ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Kid>> _v;
                    if (prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(sg)) {
                        auto&& x = prism_rtl::as<crate::syntax::TextSeg::SegPlaceholder>(sg).a0;
                        _v.set(crate::prelude::push(acc, Kid(Kid::KidExpr{x, m})));
                        goto _done;
                    }
                    {
                        _v.set(acc);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            });
        }
        {
            return Array<Kid>{};
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
        auto&& ps_opt = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
        return Array(std::vector{lambda_kid(body, later(crate::check::shrink::relations::hide(m, patterns_names(or_(ps_opt, Array<crate::syntax::Pattern_>{})))))});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& t = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& el_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        auto with_then = crate::prelude::push(cond_kids(c, m), Kid(Kid::KidStmts{t.stmts, crate::check::shrink::relations::cond_rels(c, m)}));
        if (prism_rtl::is_some(el_opt)) {
            auto&& b = prism_rtl::some_of(el_opt);
            return crate::prelude::push(with_then, Kid(Kid::KidStmts{b.stmts, m}));
        }
        if (prism_rtl::is_none(el_opt)) {
            return with_then;
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        return run_to_end(fold_job(arms, Array(std::vector{Kid(Kid::KidExpr{s, m})}), ({
            auto s_1 = s;
            auto m_2 = m;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Kid>>(std::tuple<Array<Kid>, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<Array<Kid>, crate::syntax::Arm> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto s_1_3 = s_1;
                auto m_2_3 = m_2;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(crate::check::shrink::relations::start_arm_pat_rels(s_1_3, a, m_2_3), [=](Map<Text, crate::check::shrink::Rel> arm_pat_rels_4324) {
                    return ({
                        auto am = arm_pat_rels_4324;
                        (prism_rtl::finished(crate::prelude::push(append(acc, opt_kids(a.guard, am)), Kid(Kid::KidStmts{a.body.stmts, am}))));
                    });
                });
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ERebuild>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a0;
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a1;
        return Array(std::vector{Kid(Kid::KidExpr{s, m}), Kid(Kid::KidStmts{b.stmts, later(m)})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
        return Array(std::vector{Kid(Kid::KidExpr{s, m}), Kid(Kid::KidStmts{b.stmts, m})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMonad>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::ExprKind::EMonad>(_m).a0;
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EMonad>(_m).a1;
        return Array(std::vector{Kid(Kid::KidExpr{s, m}), Kid(Kid::KidStmts{b.stmts, m})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFor>(_m)) {
        auto&& fb_opt = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
        auto&& s = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
        auto names_1 = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            if (prism_rtl::is_some(fb_opt)) {
                auto&& fb = prism_rtl::some_of(fb_opt);
                _v.set(crate::check::types::union_texts(crate::check::env::names::pattern_names(fb.first), crate::check::shrink::summaries::opt_names(fb.second)));
                goto _done;
            }
            if (prism_rtl::is_none(fb_opt)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto in_body = ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, crate::check::shrink::Rel>> _v;
            if (prism_rtl::is_some(fb_opt)) {
                auto&& fb = prism_rtl::some_of(fb_opt);
                _v.set(({
                    auto with_first = crate::check::shrink::relations::bind_rels(fb.first, part_of(s), crate::check::shrink::relations::hide(m, names_1), false);
                    ({
                    __label__ _done;
                    prism_rtl::Slot<Map<Text, crate::check::shrink::Rel>> _v;
                    auto&& _m = fb.second;
                    if (prism_rtl::is_some(_m)) {
                        auto&& p2 = prism_rtl::some_of(_m);
                        _v.set(crate::check::shrink::relations::bind_rels(p2, part_of(s), with_first, false));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(with_first);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                }));
                goto _done;
            }
            if (prism_rtl::is_none(fb_opt)) {
                _v.set(crate::check::shrink::relations::hide(m, names_1));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return Array(std::vector{Kid(Kid::KidExpr{s, m}), Kid(Kid::KidStmts{b.stmts, in_body})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGiven>(_m)) {
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EGiven>(_m).a0;
        return Array(std::vector{Kid(Kid::KidStmts{b.stmts, m})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m)) {
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EWidgetBlock>(_m).a0;
        return Array(std::vector{Kid(Kid::KidStmts{b.stmts, later(m)})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETemplate>(_m)) {
        auto&& t = prism_rtl::as<crate::syntax::ExprKind::ETemplate>(_m).a0;
        return template_kids(t.parts, m);
    }
    {
        return Array<Kid>{};
    }
}


prism_rtl::Turn<Array<Kid>> ExprKids::cycle() const {
    const auto& e = this->e;
    const auto& m = this->m;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::ECall>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        prism_rtl::more(prism_rtl::rc(CallKids(c, args, m)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m) ? ({
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a1;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
        prism_rtl::more(prism_rtl::rc(CallKids(method_callee(n), method_args(r, args), m)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m) ? ({
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        prism_rtl::finished(exprs_kids(Array(std::vector{l, r}), m));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ESuffixed>(_m) ? ({
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::ESuffixed>(_m).a2;
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::ESuffixed>(_m).a3;
        prism_rtl::finished(exprs_kids(Array(std::vector{l, r}), m));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m) ? ({
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& i = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        prism_rtl::finished(exprs_kids(Array(std::vector{r, i}), m));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{x, m})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{x, m})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EField>(_m) ? ({
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{r, m})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ETopicIndex>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::ETopicIndex>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{x, m})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{x, m})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{x, m})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ECast>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{x, m})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ENonEmpty>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::ENonEmpty>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{x, m})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EAny>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EAny>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{x, m})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m) ? ({
        auto&& es = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
        prism_rtl::finished(exprs_kids(es, m));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EArray>(_m) ? ({
        auto&& es = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
        prism_rtl::finished(exprs_kids(es, m));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMap>(_m) ? ({
        auto&& kvs = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
        prism_rtl::finished(fold(kvs, Array<Kid>{}, [&](const Array<Kid>& acc, const std::tuple<crate::syntax::Expr, crate::syntax::Expr>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& v_ = std::get<1>(_p1);
        return append(acc, exprs_kids(Array(std::vector{k, v_}), m));
    }));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ELit>(_m) ? ({
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
        ({
        auto&& _m = l.kind;
        prism_rtl::is<crate::syntax::LitKind::LText>(_m) ? ({
        auto&& segs = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
        prism_rtl::finished(fold(segs, Array<Kid>{}, [&](const Array<Kid>& acc, const crate::syntax::TextSeg& sg) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Kid>> _v;
            if (prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(sg)) {
                auto&& x = prism_rtl::as<crate::syntax::TextSeg::SegPlaceholder>(sg).a0;
                _v.set(crate::prelude::push(acc, Kid(Kid::KidExpr{x, m})));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    }));
    })
        : prism_rtl::finished(Array<Kid>{});
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) ? ({
        auto&& ps_opt = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
        ({
        auto ps_opt_1 = ps_opt;
        auto body_2 = body;
        auto m_3 = m;
        call_then(start_patterns_names(or_(ps_opt_1, Array<crate::syntax::Pattern_>{})), [=](Array<Text> patterns_names_4012) { return prism_rtl::finished(Array(std::vector{lambda_kid(body_2, later(crate::check::shrink::relations::hide(m_3, patterns_names_4012)))})); });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& t = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& el_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        ({
        auto el_opt_1 = el_opt;
        auto c_2 = c;
        auto m_3 = m;
        auto t_4 = t;
        call_then(start_cond_kids(c_2, m_3), [=](Array<Kid> cond_kids_4095) {
        return call_then(crate::check::shrink::relations::start_cond_rels(c_2, m_3), [=](Map<Text, crate::check::shrink::Rel> cond_rels_4131) {
            return ({
                auto with_then = crate::prelude::push(cond_kids_4095, Kid(Kid::KidStmts{t_4.stmts, cond_rels_4131}));
                ({
                prism_rtl::is_some(el_opt_1) ? ({
                auto&& b = prism_rtl::some_of(el_opt_1);
                prism_rtl::finished(crate::prelude::push(with_then, Kid(Kid::KidStmts{b.stmts, m_3})));
            })
                : prism_rtl::is_none(el_opt_1) ? prism_rtl::finished(with_then)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
        auto&& s = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        fold_job(arms, Array(std::vector{Kid(Kid::KidExpr{s, m})}), ({
        auto s_1 = s;
        auto m_2 = m;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Kid>>(std::tuple<Array<Kid>, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<Array<Kid>, crate::syntax::Arm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto s_1_3 = s_1;
            auto m_2_3 = m_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto a = p1;
                call_then(crate::check::shrink::relations::start_arm_pat_rels(s_1_3, a, m_2_3), [=](Map<Text, crate::check::shrink::Rel> arm_pat_rels_4324) {
                return ({
                    auto am = arm_pat_rels_4324;
                    (prism_rtl::finished(crate::prelude::push(append(acc, opt_kids(a.guard, am)), Kid(Kid::KidStmts{a.body.stmts, am}))));
                });
            });
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::syntax::ExprKind::ERebuild>(_m) ? ({
        auto&& s = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a0;
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a1;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{s, m}), Kid(Kid::KidStmts{b.stmts, later(m)})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m) ? ({
        auto&& s = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{s, m}), Kid(Kid::KidStmts{b.stmts, m})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMonad>(_m) ? ({
        auto&& s = prism_rtl::as<crate::syntax::ExprKind::EMonad>(_m).a0;
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EMonad>(_m).a1;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{s, m}), Kid(Kid::KidStmts{b.stmts, m})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EFor>(_m) ? ({
        auto&& fb_opt = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
        auto&& s = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
        ({
        auto names_1 = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            if (prism_rtl::is_some(fb_opt)) {
                auto&& fb = prism_rtl::some_of(fb_opt);
                _v.set(crate::check::types::union_texts(crate::check::env::names::pattern_names(fb.first), crate::check::shrink::summaries::opt_names(fb.second)));
                goto _done;
            }
            if (prism_rtl::is_none(fb_opt)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto in_body = ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, crate::check::shrink::Rel>> _v;
            if (prism_rtl::is_some(fb_opt)) {
                auto&& fb = prism_rtl::some_of(fb_opt);
                _v.set(({
                    auto with_first = crate::check::shrink::relations::bind_rels(fb.first, part_of(s), crate::check::shrink::relations::hide(m, names_1), false);
                    ({
                    __label__ _done;
                    prism_rtl::Slot<Map<Text, crate::check::shrink::Rel>> _v;
                    auto&& _m = fb.second;
                    if (prism_rtl::is_some(_m)) {
                        auto&& p2 = prism_rtl::some_of(_m);
                        _v.set(crate::check::shrink::relations::bind_rels(p2, part_of(s), with_first, false));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(with_first);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                }));
                goto _done;
            }
            if (prism_rtl::is_none(fb_opt)) {
                _v.set(crate::check::shrink::relations::hide(m, names_1));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        (prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{s, m}), Kid(Kid::KidStmts{b.stmts, in_body})})));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGiven>(_m) ? ({
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EGiven>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidStmts{b.stmts, m})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m) ? ({
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EWidgetBlock>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidStmts{b.stmts, later(m)})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ETemplate>(_m) ? ({
        auto&& t = prism_rtl::as<crate::syntax::ExprKind::ETemplate>(_m).a0;
        prism_rtl::more(prism_rtl::rc(TemplateKids(t.parts, m)));
    })
        : prism_rtl::finished(Array<Kid>{});
    });
}


/// `Start ExprKids, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Kid>> start_expr_kids(crate::syntax::Expr e, Map<Text, crate::check::shrink::Rel> m) {
    return prism_rtl::make_rc<ExprKids>(e, m);
}


/// StmtKids: unbounded fn Stmt, (Text ==> Rel) -> [Kid]
Array<Kid> stmt_kids(const crate::syntax::Stmt& s, const Map<Text, crate::check::shrink::Rel>& m) {
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m)) {
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        auto&& t_opt = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2;
        return append(Array(std::vector{Kid(Kid::KidExpr{e, m})}), opt_kids(t_opt, m));
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SIgnore>(_m)) {
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SIgnore>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{e, m})});
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        return Array(std::vector{Kid(Kid::KidExpr{e, m})});
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        auto&& f = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        return Array(std::vector{body_kid(f.body, later(crate::check::shrink::relations::hide(m, patterns_names(f.params))))});
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m)) {
        auto&& w = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
        return Array(std::vector{Kid(Kid::KidStmts{w.body.stmts, later(m)})});
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SSet>(_m)) {
        auto&& t = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
        return exprs_kids(Array(std::vector{t, v_}), m);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m)) {
        auto&& t = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a2;
        return exprs_kids(Array(std::vector{t, v_}), m);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SRequire>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SRequire>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{c, m})});
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SForbid>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SForbid>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{c, m})});
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SReturn>(_m)) {
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SReturn>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{e, m})});
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
        auto&& b = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
        return crate::prelude::push(cond_kids(c, m), Kid(Kid::KidStmts{b.stmts, crate::check::shrink::relations::cond_rels(c, m)}));
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{e, m})});
    }
    {
        return Array<Kid>{};
    }
}


prism_rtl::Turn<Array<Kid>> StmtKids::cycle() const {
    const auto& s = this->s;
    const auto& m = this->m;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) ? ({
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        auto&& t_opt = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2;
        prism_rtl::finished(append(Array(std::vector{Kid(Kid::KidExpr{e, m})}), opt_kids(t_opt, m)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SIgnore>(_m) ? ({
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SIgnore>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{e, m})}));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{e, m})}));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? ({
        auto&& f = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        ({
        auto f_1 = f;
        auto m_2 = m;
        call_then(start_patterns_names(f_1.params), [=](Array<Text> patterns_names_5759) { return prism_rtl::finished(Array(std::vector{body_kid(f_1.body, later(crate::check::shrink::relations::hide(m_2, patterns_names_5759)))})); });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m) ? ({
        auto&& w = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidStmts{w.body.stmts, later(m)})}));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SSet>(_m) ? ({
        auto&& t = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
        prism_rtl::finished(exprs_kids(Array(std::vector{t, v_}), m));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m) ? ({
        auto&& t = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a2;
        prism_rtl::finished(exprs_kids(Array(std::vector{t, v_}), m));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SRequire>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SRequire>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{c, m})}));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SForbid>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SForbid>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{c, m})}));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SReturn>(_m) ? ({
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SReturn>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{e, m})}));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
        auto&& b = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
        ({
        auto b_1 = b;
        auto c_2 = c;
        auto m_3 = m;
        call_then(start_cond_kids(c_2, m_3), [=](Array<Kid> cond_kids_6052) { return call_then(crate::check::shrink::relations::start_cond_rels(c_2, m_3), [=](Map<Text, crate::check::shrink::Rel> cond_rels_6088) { return prism_rtl::finished(crate::prelude::push(cond_kids_6052, Kid(Kid::KidStmts{b_1.stmts, cond_rels_6088}))); }); });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{e, m})}));
    })
        : prism_rtl::finished(Array<Kid>{});
    });
}


/// `Start StmtKids, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Kid>> start_stmt_kids(crate::syntax::Stmt s, Map<Text, crate::check::shrink::Rel> m) {
    return prism_rtl::make_rc<StmtKids>(s, m);
}


/// CondKids: unbounded fn Cond, (Text ==> Rel) -> [Kid]
Array<Kid> cond_kids(const crate::syntax::Cond& c, const Map<Text, crate::check::shrink::Rel>& m) {
    if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c)) {
        auto&& x = prism_rtl::as<crate::syntax::Cond::CondExpr>(c).a0;
        return Array(std::vector{Kid(Kid::KidExpr{x, m})});
    }
    if (prism_rtl::is<crate::syntax::Cond::CondBind>(c)) {
        auto&& x = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a1;
        auto&& g_opt = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a2;
        return append(Array(std::vector{Kid(Kid::KidExpr{x, m})}), opt_kids(g_opt, crate::check::shrink::relations::cond_rels(c, m)));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Kid>> CondKids::cycle() const {
    const auto& c = this->c;
    const auto& m = this->m;
    return ({
        prism_rtl::is<crate::syntax::Cond::CondExpr>(c) ? ({
        auto&& x = prism_rtl::as<crate::syntax::Cond::CondExpr>(c).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{x, m})}));
    })
        : prism_rtl::is<crate::syntax::Cond::CondBind>(c) ? ({
        auto&& x = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a1;
        auto&& g_opt = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a2;
        ({
        auto g_opt_1 = g_opt;
        auto c_2 = c;
        auto m_3 = m;
        auto x_4 = x;
        call_then(crate::check::shrink::relations::start_cond_rels(c_2, m_3), [=](Map<Text, crate::check::shrink::Rel> cond_rels_6428) { return prism_rtl::finished(append(Array(std::vector{Kid(Kid::KidExpr{x_4, m_3})}), opt_kids(g_opt_1, cond_rels_6428))); });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CondKids, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Kid>> start_cond_kids(crate::syntax::Cond c, Map<Text, crate::check::shrink::Rel> m) {
    return prism_rtl::make_rc<CondKids>(c, m);
}


/// CallKids: unbounded fn Expr, [Arg], (Text ==> Rel) -> [Kid]
Array<Kid> call_kids(const crate::syntax::Expr& c, const Array<crate::syntax::Arg>& args, const Map<Text, crate::check::shrink::Rel>& m) {
    auto callee = ({
        __label__ _done;
        prism_rtl::Slot<Array<Kid>> _v;
        auto&& _m = callee_name(c);
        if (prism_rtl::is_some(_m)) {
            _v.set(Array<Kid>{});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array(std::vector{Kid(Kid::KidExpr{c, m})}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& _m = traversal_of(m, c, args);
    if (prism_rtl::is_none(_m)) {
        auto&& _m = acc_callee(m, c, args);
        if (prism_rtl::is_some(_m)) {
            auto&& cn = prism_rtl::some_of(_m);
            return append(callee, run_to_end(fold_job(crate::check::errors::range0(len(args)), Array<Kid>{}, ({
                auto m_1 = m;
                auto cn_2 = cn;
                auto args_3 = args;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Kid>>(std::tuple<Array<Kid>, Nat>)>>(prism_rtl::rc([=](std::tuple<Array<Kid>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto m_1_4 = m_1;
                    auto cn_2_4 = cn_2;
                    auto args_3_4 = args_3;
                    entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto i = p1;
                        call_then(start_acc_kids(m_1_4, cn_2_4, args_3_4, i), [=](Array<Kid> acc_kids_7288) { return prism_rtl::finished(append(acc, acc_kids_7288)); });
                    });
                }));
                });
            })));
            }))));
        }
        if (prism_rtl::is_none(_m)) {
            return append(callee, exprs_kids(each(args, [&](const crate::syntax::Arg& a) { return a->value; }), m));
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_some(_m)) {
        auto&& coll = std::get<0>(prism_rtl::some_of(_m));
        auto&& step_ = std::get<1>(prism_rtl::some_of(_m));
        auto&& at_ = std::get<2>(prism_rtl::some_of(_m));
        auto others = fold(crate::check::errors::range0(len(args)), callee, [&](const Array<Kid>& acc, const Nat& i) {
            return i == (at_ + Nat(1u))
                ? acc
                : ({
                __label__ _done;
                prism_rtl::Slot<Array<Kid>> _v;
                auto&& _m = index(args, i);
                if (prism_rtl::is_some(_m)) {
                    auto&& a = prism_rtl::some_of(_m);
                    _v.set(crate::prelude::push(acc, Kid(Kid::KidExpr{a->value, m})));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(acc);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        });
        auto&& _m = step_.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0)) {
            auto&& ps = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0);
            auto&& body = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
            return crate::prelude::push(others, lambda_kid(body, crate::check::shrink::relations::step_rels(m, coll, ps, at_)));
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            return others;
        }
        {
            return crate::prelude::push(others, Kid(Kid::KidExpr{step_, m}));
        }
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Kid>> CallKids::cycle() const {
    const auto& c = this->c;
    const auto& args = this->args;
    const auto& m = this->m;
    auto callee = ({
        __label__ _done;
        prism_rtl::Slot<Array<Kid>> _v;
        auto&& _m = callee_name(c);
        if (prism_rtl::is_some(_m)) {
            _v.set(Array<Kid>{});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array(std::vector{Kid(Kid::KidExpr{c, m})}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ({
        auto&& _m = traversal_of(m, c, args);
        prism_rtl::is_none(_m) ? ({
        auto&& _m = acc_callee(m, c, args);
        prism_rtl::is_some(_m) ? ({
        auto&& cn = prism_rtl::some_of(_m);
        ({
        auto args_1 = args;
        auto m_2 = m;
        call_value(fold_job(crate::check::errors::range0(len(args_1)), Array<Kid>{}, ({
        auto m_2_3 = m_2;
        auto cn_3 = cn;
        auto args_1_4 = args_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Kid>>(std::tuple<Array<Kid>, Nat>)>>(prism_rtl::rc([=](std::tuple<Array<Kid>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_2_3_4 = m_2_3;
            auto cn_3_4 = cn_3;
            auto args_1_4_4 = args_1_4;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto i = p1;
                call_then(start_acc_kids(m_2_3_4, cn_3_4, args_1_4_4, i), [=](Array<Kid> acc_kids_7288) { return prism_rtl::finished(append(acc, acc_kids_7288)); });
            });
        }));
        });
    })));
    })), [=](Array<Kid> fold_7233) { return prism_rtl::finished(append(callee, fold_7233)); });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(append(callee, exprs_kids(each(args, [&](const crate::syntax::Arg& a) { return a->value; }), m)))
        : throw prism_rtl::Panic("no arm matched");
    })
        : prism_rtl::is_some(_m) ? ({
        auto&& coll = std::get<0>(prism_rtl::some_of(_m));
        auto&& step_ = std::get<1>(prism_rtl::some_of(_m));
        auto&& at_ = std::get<2>(prism_rtl::some_of(_m));
        ({
        auto others = fold(crate::check::errors::range0(len(args)), callee, [&](const Array<Kid>& acc, const Nat& i) {
            return i == (at_ + Nat(1u))
                ? acc
                : ({
                __label__ _done;
                prism_rtl::Slot<Array<Kid>> _v;
                auto&& _m = index(args, i);
                if (prism_rtl::is_some(_m)) {
                    auto&& a = prism_rtl::some_of(_m);
                    _v.set(crate::prelude::push(acc, Kid(Kid::KidExpr{a->value, m})));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(acc);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        });
        ({
        auto&& _m = step_.kind;
        prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0) ? ({
        auto&& ps = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0);
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
        ({
        auto body_1 = body;
        auto m_2 = m;
        auto ps_3 = ps;
        call_then(crate::check::shrink::relations::start_step_rels(m_2, coll, ps_3, at_), [=](Map<Text, crate::check::shrink::Rel> step_rels_7701) { return prism_rtl::finished(crate::prelude::push(others, lambda_kid(body_1, step_rels_7701))); });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? prism_rtl::finished(others)
        : prism_rtl::finished(crate::prelude::push(others, Kid(Kid::KidExpr{step_, m})));
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CallKids, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Kid>> start_call_kids(crate::syntax::Expr c, Array<crate::syntax::Arg> args, Map<Text, crate::check::shrink::Rel> m) {
    return prism_rtl::make_rc<CallKids>(c, args, m);
}


/// Later: fn (Text ==> Rel) -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> later(const Map<Text, crate::check::shrink::Rel>& m) {
    return insert(m, Text::lit("lam:"), crate::check::shrink::relations::no_rel());
}


/// ?AccCallee: fn (Text ==> Rel), Expr, [Arg] -> ?Text
std::optional<Text> acc_callee(const Map<Text, crate::check::shrink::Rel>& m, const crate::syntax::Expr& c, const Array<crate::syntax::Arg>& args) {
    auto&& _m = callee_name(c);
    if (prism_rtl::is_some(_m)) {
        auto&& cn = prism_rtl::some_of(_m);
        return crate::check::shrink::relations::is_local(m, cn)
            ? std::optional<Text>{}
            : !fold(args, true, [&](const bool& ok_, const crate::syntax::Arg& a) { return ok_ && (a.name == std::optional<crate::syntax::Ident>{}); })
            ? std::optional<Text>{}
            : fold(crate::check::errors::range0(len(args)), false, [&](const bool& seen, const Nat& i) { return seen || crate::check::env::has_key(m, prism_rtl::cat("acc:", cn, ":", i)); })
            ? std::optional(cn)
            : std::optional<Text>{};
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// AccKids: unbounded fn (Text ==> Rel), Text, [Arg], Nat -> [Kid]
Array<Kid> acc_kids(const Map<Text, crate::check::shrink::Rel>& m, const Text& cn, const Array<crate::syntax::Arg>& args, const Nat& i) {
    auto a = or_(index(args, i), crate::check::shrink::summaries::dummy_arg());
    return !crate::check::env::has_key(m, prism_rtl::cat("acc:", cn, ":", i))
        ? Array(std::vector{Kid(Kid::KidExpr{a->value, m})})
        : ({
        __label__ _done;
        prism_rtl::Slot<Array<Kid>> _v;
        auto&& _m = a->value.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
            auto&& ps_opt = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
            auto&& body = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
            _v.set(Array(std::vector{lambda_kid(body, acc_lambda_rels(m, cn, i, or_(ps_opt, Array<crate::syntax::Pattern_>{}), args))}));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            _v.set(Array<Kid>{});
            goto _done;
        }
        {
            _v.set(Array(std::vector{Kid(Kid::KidExpr{a->value, m})}));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Array<Kid>> AccKids::cycle() const {
    const auto& m = this->m;
    const auto& cn = this->cn;
    const auto& args = this->args;
    const auto& i = this->i;
    auto a = or_(index(args, i), crate::check::shrink::summaries::dummy_arg());
    return !crate::check::env::has_key(m, prism_rtl::cat("acc:", cn, ":", i))
        ? prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{a->value, m})}))
        : ({
        auto&& _m = a->value.kind;
        prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) ? ({
        auto&& ps_opt = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
        prism_rtl::finished(Array(std::vector{lambda_kid(body, acc_lambda_rels(m, cn, i, or_(ps_opt, Array<crate::syntax::Pattern_>{}), args))}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? prism_rtl::finished(Array<Kid>{})
        : prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{a->value, m})}));
    });
}


/// `Start AccKids, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Kid>> start_acc_kids(Map<Text, crate::check::shrink::Rel> m, Text cn, Array<crate::syntax::Arg> args, Nat i) {
    return prism_rtl::make_rc<AccKids>(m, cn, args, i);
}


/// AccLambdaRels: unbounded fn (Text ==> Rel), Text, Nat, [Pattern], [Arg] -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> acc_lambda_rels(const Map<Text, crate::check::shrink::Rel>& m, const Text& cn, const Nat& j, const Array<crate::syntax::Pattern_>& ps, const Array<crate::syntax::Arg>& args) {
    auto h = crate::check::shrink::relations::hide(m, patterns_names(ps));
    return run_to_end(fold_job(crate::check::errors::range0(len(ps)), h, ({
        auto m_1 = m;
        auto cn_2 = cn;
        auto j_3 = j;
        auto ps_4 = ps;
        auto args_5 = args;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>>(std::tuple<Map<Text, crate::check::shrink::Rel>, Nat>)>>(prism_rtl::rc([=](std::tuple<Map<Text, crate::check::shrink::Rel>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_1_6 = m_1;
            auto cn_2_6 = cn_2;
            auto j_3_6 = j_3;
            auto ps_4_6 = ps_4;
            auto args_5_6 = args_5;
            entered(once_job([=]() {
            return ({
                auto m2 = p0;
                auto q = p1;
                ({
                auto&& _m = std::tuple{crate::prelude::get(m_1_6, prism_rtl::cat("sum:", cn_2_6, ":", j_3_6, ":", q)), index(ps_4_6, q)};
                prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m)) ? ({
                auto&& s = prism_rtl::some_of(std::get<0>(_m));
                auto&& p_ = prism_rtl::some_of(std::get<1>(_m));
                s.param == top_param()
                ? prism_rtl::finished(m2)
                : ({
                auto&& _m = index(args_5_6, s.param);
                prism_rtl::is_some(_m) ? ({
                auto&& a = prism_rtl::some_of(_m);
                call_then(start_rel_of(m_1_6, a->value), [=](std::optional<crate::check::shrink::Rel> rel_of_9689) {
                return ({
                    prism_rtl::is_some(rel_of_9689) ? ({
                    auto&& r = prism_rtl::some_of(rel_of_9689);
                    ({
                    auto&& _m = p_.kind;
                    prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
                    auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                    prism_rtl::finished(insert(m2, crate::check::env::sname_key(n), crate::check::shrink::Rel{.param = r.param, .strict = r.strict || s.strict}));
                })
                    : call_then(crate::check::env::names::start_pattern_names(p_), [=](Array<Text> pattern_names_9884) { return prism_rtl::finished(fold(pattern_names_9884, m2, [&](const Map<Text, crate::check::shrink::Rel>& m3, const Text& n) { return insert(m3, n, crate::check::shrink::Rel{.param = r.param, .strict = true}); })); });
                });
                })
                    : prism_rtl::is_none(rel_of_9689) ? prism_rtl::finished(m2)
                    : throw prism_rtl::Panic("no arm matched");
                });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(m2)
                : throw prism_rtl::Panic("no arm matched");
            });
            })
                : prism_rtl::finished(m2);
            });
            });
        }));
        });
    }));
    })));
}


/// let topParam
Nat top_param() {
    return Nat(9999u);
}


/// TemplateKids: unbounded fn [TemplatePart], (Text ==> Rel) -> [Kid]
Array<Kid> template_kids(const Array<crate::syntax::TemplatePart>& parts, const Map<Text, crate::check::shrink::Rel>& m) {
    return fold(parts, Array<Kid>{}, [&](const Array<Kid>& acc, const crate::syntax::TemplatePart& p_) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Kid>> _v;
            if (prism_rtl::is<crate::syntax::TemplatePart::TpPlaceholder>(p_)) {
                auto&& x = prism_rtl::as<crate::syntax::TemplatePart::TpPlaceholder>(p_).a0;
                _v.set(crate::prelude::push(acc, Kid(Kid::KidExpr{x, m})));
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::TemplatePart::TpBlock>(p_)) {
                auto&& b = prism_rtl::as<crate::syntax::TemplatePart::TpBlock>(p_).a0;
                _v.set(crate::prelude::push(acc, Kid(Kid::KidStmts{b.stmts, m})));
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::TemplatePart::TpCall>(p_)) {
                auto&& n = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_).a0;
                auto&& args = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_).a1;
                auto&& ps_opt = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_).a2;
                auto&& span = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_).a3;
                _v.set(crate::prelude::push(acc, Kid(Kid::KidExpr{template_call_expr(n, args, ps_opt, span), m})));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Array<Kid>> TemplateKids::cycle() const {
    const auto& parts = this->parts;
    const auto& m = this->m;
    return prism_rtl::finished(fold(parts, Array<Kid>{}, [&](const Array<Kid>& acc, const crate::syntax::TemplatePart& p_) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Kid>> _v;
            if (prism_rtl::is<crate::syntax::TemplatePart::TpPlaceholder>(p_)) {
                auto&& x = prism_rtl::as<crate::syntax::TemplatePart::TpPlaceholder>(p_).a0;
                _v.set(crate::prelude::push(acc, Kid(Kid::KidExpr{x, m})));
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::TemplatePart::TpBlock>(p_)) {
                auto&& b = prism_rtl::as<crate::syntax::TemplatePart::TpBlock>(p_).a0;
                _v.set(crate::prelude::push(acc, Kid(Kid::KidStmts{b.stmts, m})));
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::TemplatePart::TpCall>(p_)) {
                auto&& n = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_).a0;
                auto&& args = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_).a1;
                auto&& ps_opt = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_).a2;
                auto&& span = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_).a3;
                _v.set(crate::prelude::push(acc, Kid(Kid::KidExpr{template_call_expr(n, args, ps_opt, span), m})));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    }));
}


/// `Start TemplateKids, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Kid>> start_template_kids(Array<crate::syntax::TemplatePart> parts, Map<Text, crate::check::shrink::Rel> m) {
    return prism_rtl::make_rc<TemplateKids>(parts, m);
}


/// TemplateCallExpr: fn SName, [Arg], ?[TemplatePart], Range -> Expr
crate::syntax::Expr template_call_expr(const crate::syntax::SName& n, const Array<crate::syntax::Arg>& args, const std::optional<Array<crate::syntax::TemplatePart>>& ps_opt, const crate::syntax::Range& span) {
    auto body_1 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::syntax::Arg>> _v;
        if (prism_rtl::is_some(ps_opt)) {
            auto&& ps = prism_rtl::some_of(ps_opt);
            _v.set(Array(std::vector{crate::syntax::Arg{.name = std::optional(crate::syntax::Ident{.name = Text::lit("#body"), .span = span}), .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ETemplate{crate::syntax::Template{.keyword = Text::lit("InlineText"), .lang = Text::lit(""), .delims = Text::lit("double"), .parts = ps, .span = span}})), .span = span}, .span = span}}));
            goto _done;
        }
        if (prism_rtl::is_none(ps_opt)) {
            _v.set(Array<crate::syntax::Arg>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ECall{prism_rtl::rc(crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{n})), .span = n.span}), append(args, body_1), false, false})), .span = span};
}


/// ArgOf: fn Expr -> Arg
crate::syntax::Arg arg_of(const crate::syntax::Expr& x) {
    return crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = x, .span = x.span};
}


/// ExprsKids: fn [Expr], (Text ==> Rel) -> [Kid]
Array<Kid> exprs_kids(const Array<crate::syntax::Expr>& xs, const Map<Text, crate::check::shrink::Rel>& m) {
    return each(xs, [&](const crate::syntax::Expr& x) { return Kid(Kid::KidExpr{x, m}); });
}


/// OptKids: fn ?Expr, (Text ==> Rel) -> [Kid]
Array<Kid> opt_kids(const std::optional<crate::syntax::Expr>& opt0, const Map<Text, crate::check::shrink::Rel>& map1) {
    auto&& _m = std::tuple{opt0, map1};
    if (prism_rtl::is_some(std::get<0>(_m))) {
        auto&& x = prism_rtl::some_of(std::get<0>(_m));
        auto&& m = std::get<1>(_m);
        return Array(std::vector{Kid(Kid::KidExpr{x, m})});
    }
    if (prism_rtl::is_none(std::get<0>(_m))) {
        return Array<Kid>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// LambdaKid: fn LambdaBody, (Text ==> Rel) -> Kid
Kid lambda_kid(const crate::syntax::LambdaBody& lambda_body0, const Map<Text, crate::check::shrink::Rel>& m) {
    if (prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(lambda_body0)) {
        auto&& x = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(lambda_body0).a0;
        return Kid(Kid::KidExpr{x, m});
    }
    if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(lambda_body0)) {
        auto&& b = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(lambda_body0).a0;
        return Kid(Kid::KidStmts{b.stmts, m});
    }
    prism_rtl::unreachable("no arm matched");
}


/// BodyKid: fn FnBody, (Text ==> Rel) -> Kid
Kid body_kid(const crate::syntax::decls::FnBody& fn_body0, const Map<Text, crate::check::shrink::Rel>& m) {
    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(fn_body0)) {
        auto&& x = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(fn_body0).a0;
        return Kid(Kid::KidExpr{x, m});
    }
    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(fn_body0)) {
        auto&& b = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(fn_body0).a0;
        return Kid(Kid::KidStmts{b.stmts, m});
    }
    prism_rtl::unreachable("no arm matched");
}


/// PatternsNames: unbounded fn [Pattern] -> [Text]
Array<Text> patterns_names(const Array<crate::syntax::Pattern_>& ps) {
    return run_to_end(fold_job(ps, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto a = p0;
                auto p_ = p1;
                call_then(crate::check::env::names::start_pattern_names(p_), [=](Array<Text> pattern_names_11843) { return prism_rtl::finished(crate::check::types::union_texts(a, pattern_names_11843)); });
            });
        }));
    }))));
}


prism_rtl::Turn<Array<Text>> PatternsNames::cycle() const {
    const auto& ps = this->ps;
    return fold_job(ps, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto a = p0;
                auto p_ = p1;
                call_then(crate::check::env::names::start_pattern_names(p_), [=](Array<Text> pattern_names_11843) { return prism_rtl::finished(crate::check::types::union_texts(a, pattern_names_11843)); });
            });
        }));
    })))->cycle();
}


/// `Start PatternsNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_patterns_names(Array<crate::syntax::Pattern_> ps) {
    return prism_rtl::make_rc<PatternsNames>(ps);
}


/// ?CalleeName: fn Expr -> ?Text
std::optional<Text> callee_name(const crate::syntax::Expr& c) {
    auto&& _m = c.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return std::optional(crate::check::env::sname_key(n));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m)) {
        auto&& t = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
        auto&& _m = t.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            return std::optional(crate::check::env::sname_key(n));
        }
        {
            return std::optional<Text>{};
        }
    }
    {
        return std::optional<Text>{};
    }
}


/// MethodCallee: fn SName -> Expr
crate::syntax::Expr method_callee(const crate::syntax::SName& n) {
    return crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{n})), .span = n.span};
}


/// MethodArgs: fn Expr, [Arg] -> [Arg]
Array<crate::syntax::Arg> method_args(const crate::syntax::Expr& r, const Array<crate::syntax::Arg>& args) {
    return append(Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = r, .span = r.span}}), args);
}


/// BodySites: unbounded fn FnBody, (Text ==> Rel) -> [Site]
Array<Site> body_sites(const crate::syntax::decls::FnBody& body, const Map<Text, crate::check::shrink::Rel>& m) {
    return run_to_end(fold_job(body_spots(body, m), Array<Site>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Site>>(std::tuple<Array<Site>, Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Site>, Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto sp = p1;
                call_then(start_spot_sites(sp), [=](Array<Site> spot_sites_12800) { return prism_rtl::finished(append(acc, spot_sites_12800)); });
            });
        }));
    }))));
}


prism_rtl::Turn<Array<Site>> BodySites::cycle() const {
    const auto& body = this->body;
    const auto& m = this->m;
    auto body_1 = body;
    auto m_2 = m;
    return call_then(start_body_spots(body_1, m_2), [=](Array<Spot> body_spots_12750) {
        return fold_job(body_spots_12750, Array<Site>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Site>>(std::tuple<Array<Site>, Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Site>, Spot> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto sp = p1;
                    call_then(start_spot_sites(sp), [=](Array<Site> spot_sites_12800) { return prism_rtl::finished(append(acc, spot_sites_12800)); });
                });
            }));
        })))->cycle();
    });
}


/// `Start BodySites, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Site>> start_body_sites(crate::syntax::decls::FnBody body, Map<Text, crate::check::shrink::Rel> m) {
    return prism_rtl::make_rc<BodySites>(body, m);
}


/// SpotSites: unbounded fn Spot -> [Site]
Array<Site> spot_sites(const Spot& spot0) {
    if (prism_rtl::is<Spot::SpotStmt>(spot0)) {
        return Array<Site>{};
    }
    if (prism_rtl::is<Spot::SpotExpr>(spot0)) {
        auto&& e = prism_rtl::as<Spot::SpotExpr>(spot0).a0;
        auto&& m = prism_rtl::as<Spot::SpotExpr>(spot0).a1;
        auto&& _m = e.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            return Array(std::vector{Site{.callee = crate::check::env::sname_key(n), .args = Array<crate::syntax::Arg>{}, .span = e.span, .rels = m}});
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
            auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
            auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
            return call_sites(c, args, e.span, m);
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m)) {
            auto&& r = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a1;
            auto&& args = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
            return call_sites(method_callee(n), method_args(r, args), e.span, m);
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
            auto&& op = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
            auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
            auto&& r = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
            return is_called_op(op)
                ? Array(std::vector{Site{.callee = op, .args = Array(std::vector{arg_of(l), arg_of(r)}), .span = e.span, .rels = m}})
                : Array<Site>{};
        }
        {
            return Array<Site>{};
        }
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Site>> SpotSites::cycle() const {
    const auto& spot0 = this->spot0;
    return ({
        prism_rtl::is<Spot::SpotStmt>(spot0) ? prism_rtl::finished(Array<Site>{})
        : prism_rtl::is<Spot::SpotExpr>(spot0) ? ({
        auto&& e = prism_rtl::as<Spot::SpotExpr>(spot0).a0;
        auto&& m = prism_rtl::as<Spot::SpotExpr>(spot0).a1;
        ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        prism_rtl::finished(Array(std::vector{Site{.callee = crate::check::env::sname_key(n), .args = Array<crate::syntax::Arg>{}, .span = e.span, .rels = m}}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ECall>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        prism_rtl::more(prism_rtl::rc(CallSites(c, args, e.span, m)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m) ? ({
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a1;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
        prism_rtl::more(prism_rtl::rc(CallSites(method_callee(n), method_args(r, args), e.span, m)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m) ? ({
        auto&& op = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        is_called_op(op)
        ? prism_rtl::finished(Array(std::vector{Site{.callee = op, .args = Array(std::vector{arg_of(l), arg_of(r)}), .span = e.span, .rels = m}}))
        : prism_rtl::finished(Array<Site>{});
    })
        : prism_rtl::finished(Array<Site>{});
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SpotSites, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Site>> start_spot_sites(Spot spot0) {
    return prism_rtl::make_rc<SpotSites>(spot0);
}


/// IsCalledOp: fn Text -> Bool
bool is_called_op(const Text& op) {
    return !crate::check::types::has_text(Array(std::vector{Text::lit("and"), Text::lit("or"), Text::lit("on"), Text::lit("<|"), Text::lit("mod")}), op);
}


/// CallSites: unbounded fn Expr, [Arg], Range, (Text ==> Rel) -> [Site]
Array<Site> call_sites(const crate::syntax::Expr& c, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span, const Map<Text, crate::check::shrink::Rel>& m) {
    auto direct = ({
        __label__ _done;
        prism_rtl::Slot<Array<Site>> _v;
        auto&& _m = callee_name(c);
        if (prism_rtl::is_some(_m)) {
            auto&& n = prism_rtl::some_of(_m);
            _v.set(Array(std::vector{Site{.callee = n, .args = args, .span = span, .rels = m}}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<Site>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& _m = traversal_of(m, c, args);
    if (prism_rtl::is_some(_m)) {
        auto&& coll = std::get<0>(prism_rtl::some_of(_m));
        auto&& step_ = std::get<1>(prism_rtl::some_of(_m));
        auto&& at_ = std::get<2>(prism_rtl::some_of(_m));
        auto&& _m = step_.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            auto call_args = at_ == Nat(1u)
                ? Array(std::vector{or_(index(args, Nat(1u)), crate::check::shrink::summaries::dummy_arg()), arg_of(part_of(coll))})
                : Array(std::vector{arg_of(part_of(coll))});
            return crate::prelude::push(direct, Site{.callee = crate::check::env::sname_key(n), .args = call_args, .span = step_.span, .rels = m});
        }
        {
            return direct;
        }
    }
    if (prism_rtl::is_none(_m)) {
        auto&& _m = acc_callee(m, c, args);
        if (prism_rtl::is_some(_m)) {
            auto&& cn = prism_rtl::some_of(_m);
            return append(direct, acc_sites(m, cn, args));
        }
        if (prism_rtl::is_none(_m)) {
            return direct;
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Site>> CallSites::cycle() const {
    const auto& c = this->c;
    const auto& args = this->args;
    const auto& span = this->span;
    const auto& m = this->m;
    auto direct = ({
        __label__ _done;
        prism_rtl::Slot<Array<Site>> _v;
        auto&& _m = callee_name(c);
        if (prism_rtl::is_some(_m)) {
            auto&& n = prism_rtl::some_of(_m);
            _v.set(Array(std::vector{Site{.callee = n, .args = args, .span = span, .rels = m}}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<Site>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ({
        auto&& _m = traversal_of(m, c, args);
        prism_rtl::is_some(_m) ? ({
        auto&& coll = std::get<0>(prism_rtl::some_of(_m));
        auto&& step_ = std::get<1>(prism_rtl::some_of(_m));
        auto&& at_ = std::get<2>(prism_rtl::some_of(_m));
        ({
        auto&& _m = step_.kind;
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        ({
        auto call_args = at_ == Nat(1u)
            ? Array(std::vector{or_(index(args, Nat(1u)), crate::check::shrink::summaries::dummy_arg()), arg_of(part_of(coll))})
            : Array(std::vector{arg_of(part_of(coll))});
        (prism_rtl::finished(crate::prelude::push(direct, Site{.callee = crate::check::env::sname_key(n), .args = call_args, .span = step_.span, .rels = m})));
    });
    })
        : prism_rtl::finished(direct);
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto&& _m = acc_callee(m, c, args);
        prism_rtl::is_some(_m) ? ({
        auto&& cn = prism_rtl::some_of(_m);
        prism_rtl::finished(append(direct, acc_sites(m, cn, args)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(direct)
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CallSites, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Site>> start_call_sites(crate::syntax::Expr c, Array<crate::syntax::Arg> args, crate::syntax::Range span, Map<Text, crate::check::shrink::Rel> m) {
    return prism_rtl::make_rc<CallSites>(c, args, span, m);
}


/// PartOf: fn Expr -> Expr
crate::syntax::Expr part_of(const crate::syntax::Expr& x) {
    return crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EField{prism_rtl::rc(x), Text::lit(""), crate::syntax::Ident{.name = Text::lit("element"), .span = x.span}})), .span = x.span};
}


/// AccSites: fn (Text ==> Rel), Text, [Arg] -> [Site]
Array<Site> acc_sites(const Map<Text, crate::check::shrink::Rel>& m, const Text& cn, const Array<crate::syntax::Arg>& args) {
    return fold(crate::check::errors::range0(len(args)), Array<Site>{}, [&](const Array<Site>& acc, const Nat& j) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Site>> _v;
            auto&& _m = std::tuple{crate::prelude::get(m, prism_rtl::cat("acc:", cn, ":", j)), index(args, j)};
            if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                auto&& ar = prism_rtl::some_of(std::get<0>(_m));
                auto&& a = prism_rtl::some_of(std::get<1>(_m));
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<Site>> _v;
                    auto&& _m = a->value.kind;
                    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                        auto&& f = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                        _v.set(crate::prelude::push(acc, Site{.callee = crate::check::env::sname_key(f), .args = each(crate::check::errors::range0(ar.param), [&](const Nat& q) { return acc_arg(m, cn, j, q, args); }), .span = a->value.span, .rels = m}));
                        goto _done;
                    }
                    {
                        _v.set(acc);
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// AccArg: fn (Text ==> Rel), Text, Nat, Nat, [Arg] -> Arg
crate::syntax::Arg acc_arg(const Map<Text, crate::check::shrink::Rel>& m, const Text& cn, const Nat& j, const Nat& q, const Array<crate::syntax::Arg>& args) {
    auto&& _m = crate::prelude::get(m, prism_rtl::cat("sum:", cn, ":", j, ":", q));
    if (prism_rtl::is_some(_m)) {
        auto&& s = prism_rtl::some_of(_m);
        return s.param == top_param()
            ? arg_of(top_expr())
            : ({
            __label__ _done;
            prism_rtl::Slot<crate::syntax::Arg> _v;
            auto&& _m = index(args, s.param);
            if (prism_rtl::is_some(_m)) {
                auto&& a = prism_rtl::some_of(_m);
                _v.set(arg_of(s.strict ? part_of(a->value) : a->value));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(crate::check::shrink::summaries::dummy_arg());
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_none(_m)) {
        return crate::check::shrink::summaries::dummy_arg();
    }
    prism_rtl::unreachable("no arm matched");
}


/// let topExpr
crate::syntax::Expr top_expr() {
    return crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{crate::syntax::SName{.sigils = Text::lit(""), .path_ = Array(std::vector{Text::lit("⊤")}), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}}})), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// SpotsNames: unbounded fn [Spot] -> [Text]
Array<Text> spots_names(const Array<Spot>& spots) {
    return run_to_end(fold_job(spots, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto sp = p1;
                call_then(start_spot_names(sp), [=](Array<Text> spot_names_16141) { return prism_rtl::finished(crate::check::types::union_texts(acc, spot_names_16141)); });
            });
        }));
    }))));
}


prism_rtl::Turn<Array<Text>> SpotsNames::cycle() const {
    const auto& spots = this->spots;
    return fold_job(spots, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto sp = p1;
                call_then(start_spot_names(sp), [=](Array<Text> spot_names_16141) { return prism_rtl::finished(crate::check::types::union_texts(acc, spot_names_16141)); });
            });
        }));
    })))->cycle();
}


/// `Start SpotsNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_spots_names(Array<Spot> spots) {
    return prism_rtl::make_rc<SpotsNames>(spots);
}


/// SpotNames: unbounded fn Spot -> [Text]
Array<Text> spot_names(const Spot& sp) {
    auto called = each(spot_sites(sp), [&](const Site& s) { return s.callee; });
    if (prism_rtl::is<Spot::SpotExpr>(sp)) {
        return called;
    }
    if (prism_rtl::is<Spot::SpotStmt>(sp)) {
        auto&& s = prism_rtl::as<Spot::SpotStmt>(sp).a0;
        auto&& _m = s.kind;
        if (prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m)) {
            auto&& w = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
            return crate::check::types::add_text(called, crate::check::env::sname_key(w.name));
        }
        {
            return called;
        }
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> SpotNames::cycle() const {
    const auto& sp = this->sp;
    auto sp_1 = sp;
    return call_then(start_spot_sites(sp_1), [=](Array<Site> spot_sites_16235) {
        return ({
            auto called = each(spot_sites_16235, [&](const Site& s) { return s.callee; });
            ({
            prism_rtl::is<Spot::SpotExpr>(sp_1) ? prism_rtl::finished(called)
            : prism_rtl::is<Spot::SpotStmt>(sp_1) ? ({
            auto&& s = prism_rtl::as<Spot::SpotStmt>(sp_1).a0;
            ({
            auto&& _m = s.kind;
            prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m) ? ({
            auto&& w = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
            prism_rtl::finished(crate::check::types::add_text(called, crate::check::env::sname_key(w.name)));
        })
            : prism_rtl::finished(called);
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
}


/// `Start SpotNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_spot_names(Spot sp) {
    return prism_rtl::make_rc<SpotNames>(sp);
}


/// ?TraversalOf: fn (Text ==> Rel), Expr, [Arg] -> ?((Expr, Expr, Nat))
std::optional<std::tuple<crate::syntax::Expr, crate::syntax::Expr, Nat>> traversal_of(const Map<Text, crate::check::shrink::Rel>& m, const crate::syntax::Expr& c, const Array<crate::syntax::Arg>& args) {
    auto&& _m = c.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        auto name = crate::check::env::sname_key(n);
        return crate::check::shrink::relations::pre_is(m, name, Text::lit("Fold")) && (len(args) == Nat(3u))
            ? ({
            __label__ _done;
            prism_rtl::Slot<std::optional<std::tuple<crate::syntax::Expr, crate::syntax::Expr, Nat>>> _v;
            auto&& _m = std::tuple{index(args, Nat(0u)), index(args, Nat(2u))};
            if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                auto&& a = prism_rtl::some_of(std::get<0>(_m));
                auto&& s = prism_rtl::some_of(std::get<1>(_m));
                _v.set(std::optional(std::tuple{a->value, s->value, Nat(1u)}));
                goto _done;
            }
            {
                _v.set(std::optional<std::tuple<crate::syntax::Expr, crate::syntax::Expr, Nat>>{});
                goto _done;
            }
        _done:
            _v.take();
        })
            : (crate::check::shrink::relations::pre_is(m, name, Text::lit("Each")) || crate::check::shrink::relations::pre_is(m, name, Text::lit("Filter"))) && (len(args) == Nat(2u))
            ? ({
            __label__ _done;
            prism_rtl::Slot<std::optional<std::tuple<crate::syntax::Expr, crate::syntax::Expr, Nat>>> _v;
            auto&& _m = std::tuple{index(args, Nat(0u)), index(args, Nat(1u))};
            if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                auto&& a = prism_rtl::some_of(std::get<0>(_m));
                auto&& s = prism_rtl::some_of(std::get<1>(_m));
                _v.set(std::optional(std::tuple{a->value, s->value, Nat(0u)}));
                goto _done;
            }
            {
                _v.set(std::optional<std::tuple<crate::syntax::Expr, crate::syntax::Expr, Nat>>{});
                goto _done;
            }
        _done:
            _v.take();
        })
            : std::optional<std::tuple<crate::syntax::Expr, crate::syntax::Expr, Nat>>{};
    }
    {
        return std::optional<std::tuple<crate::syntax::Expr, crate::syntax::Expr, Nat>>{};
    }
}


/// ?LastExpr: fn Block -> ?Expr
std::optional<crate::syntax::Expr> last_expr(const crate::syntax::Block& b) {
    auto&& _m = crate::syntax::lexer::chars::last(b.stmts);
    if (prism_rtl::is_some(_m)) {
        auto&& s = prism_rtl::some_of(_m);
        auto&& _m = s.kind;
        if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
            auto&& x = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
            return std::optional(x);
        }
        {
            return std::optional<crate::syntax::Expr>{};
        }
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<crate::syntax::Expr>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?RelOf: unbounded fn (Text ==> Rel), Expr -> ?Rel
std::optional<crate::check::shrink::Rel> rel_of(const Map<Text, crate::check::shrink::Rel>& m, const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return crate::prelude::get(m, crate::check::env::sname_key(n));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        auto&& _m = rel_of(m, r);
        if (prism_rtl::is_some(_m)) {
            auto&& x = prism_rtl::some_of(_m);
            return std::optional(crate::check::shrink::Rel{.param = x.param, .strict = true});
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional<crate::check::shrink::Rel>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        return rel_of(m, r);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return rel_of(m, x);
    }
    {
        auto&& _m = call_of(e);
        if (prism_rtl::is_some(_m)) {
            auto&& c = std::get<0>(prism_rtl::some_of(_m));
            auto&& args = std::get<1>(prism_rtl::some_of(_m));
            return is_non_nat_min(m, e, c)
                ? std::optional<crate::check::shrink::Rel>{}
                : rel_of_call(m, c, args);
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional<crate::check::shrink::Rel>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<std::optional<crate::check::shrink::Rel>> RelOf::cycle() const {
    const auto& m = this->m;
    const auto& e = this->e;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        prism_rtl::finished(crate::prelude::get(m, crate::check::env::sname_key(n)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EField>(_m) ? ({
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        ({
        auto m_1 = m;
        auto r_2 = r;
        call_then(start_rel_of(m_1, r_2), [=](std::optional<crate::check::shrink::Rel> rel_of_18351) {
        return ({
            prism_rtl::is_some(rel_of_18351) ? ({
            auto&& x = prism_rtl::some_of(rel_of_18351);
            prism_rtl::finished(std::optional(crate::check::shrink::Rel{.param = x.param, .strict = true}));
        })
            : prism_rtl::is_none(rel_of_18351) ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m) ? ({
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        prism_rtl::more(prism_rtl::rc(RelOf(m, r)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(RelOf(m, x)));
    })
        : ({
        auto&& _m = call_of(e);
        prism_rtl::is_some(_m) ? ({
        auto&& c = std::get<0>(prism_rtl::some_of(_m));
        auto&& args = std::get<1>(prism_rtl::some_of(_m));
        is_non_nat_min(m, e, c)
        ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
        : prism_rtl::more(prism_rtl::rc(RelOfCall(m, c, args)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    });
}


/// `Start RelOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<crate::check::shrink::Rel>> start_rel_of(Map<Text, crate::check::shrink::Rel> m, crate::syntax::Expr e) {
    return prism_rtl::make_rc<RelOf>(m, e);
}


/// IsNonNatMin: fn (Text ==> Rel), Expr, Expr -> Bool
bool is_non_nat_min(const Map<Text, crate::check::shrink::Rel>& m, const crate::syntax::Expr& e, const crate::syntax::Expr& c) {
    auto&& _m = callee_name(c);
    if (prism_rtl::is_some(_m)) {
        auto&& n = prism_rtl::some_of(_m);
        return crate::check::shrink::relations::pre_is(m, n, Text::lit("Min"))
            ? !is_nat_at(m, e)
            : false;
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// IsNatAt: fn (Text ==> Rel), Expr -> Bool
bool is_nat_at(const Map<Text, crate::check::shrink::Rel>& m, const crate::syntax::Expr& e) {
    auto&& _m = crate::prelude::get(m, Text::lit("file:"));
    if (prism_rtl::is_some(_m)) {
        auto&& f = prism_rtl::some_of(_m);
        return crate::check::env::has_key(m, prism_rtl::cat("nat:", f.param, ":", e.span.start, ":", e.span.end));
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?RelOfCall: unbounded fn (Text ==> Rel), Expr, [Arg] -> ?Rel
std::optional<crate::check::shrink::Rel> rel_of_call(const Map<Text, crate::check::shrink::Rel>& m, const crate::syntax::Expr& c, const Array<crate::syntax::Arg>& args) {
    auto&& _m = c.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        auto name = crate::check::env::sname_key(n);
        return (crate::check::shrink::relations::pre_is(m, name, Text::lit("Drop")) && (len(args) == Nat(2u))) && crate::check::shrink::summaries::is_positive_lit(or_(index(args, Nat(1u)), crate::check::shrink::summaries::dummy_arg())->value)
            ? ({
            __label__ _done;
            prism_rtl::Slot<std::optional<crate::check::shrink::Rel>> _v;
            auto&& _m = index(args, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& a = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<std::optional<crate::check::shrink::Rel>> _v;
                    auto&& _m = rel_of(m, a->value);
                    if (prism_rtl::is_some(_m)) {
                        auto&& x = prism_rtl::some_of(_m);
                        _v.set(std::optional(crate::check::shrink::Rel{.param = x.param, .strict = x.strict || known_non_empty(m, a->value)}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(std::optional<crate::check::shrink::Rel>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(std::optional<crate::check::shrink::Rel>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        })
            : (crate::check::shrink::relations::pre_is(m, name, Text::lit("Values")) || crate::check::shrink::relations::pre_is(m, name, Text::lit("Keys"))) && (len(args) == Nat(1u))
            ? rel_of(m, or_(index(args, Nat(0u)), crate::check::shrink::summaries::dummy_arg())->value)
            : ({
            __label__ _done;
            prism_rtl::Slot<std::optional<crate::check::shrink::Rel>> _v;
            auto&& _m = no_larger_arg(m, c, args);
            if (prism_rtl::is_some(_m)) {
                auto&& a = prism_rtl::some_of(_m);
                _v.set(rel_of(m, a));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(std::optional<crate::check::shrink::Rel>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    {
        return std::optional<crate::check::shrink::Rel>{};
    }
}


prism_rtl::Turn<std::optional<crate::check::shrink::Rel>> RelOfCall::cycle() const {
    const auto& m = this->m;
    const auto& c = this->c;
    const auto& args = this->args;
    return ({
        auto&& _m = c.kind;
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        ({
        auto name = crate::check::env::sname_key(n);
        (crate::check::shrink::relations::pre_is(m, name, Text::lit("Drop")) && (len(args) == Nat(2u))) && crate::check::shrink::summaries::is_positive_lit(or_(index(args, Nat(1u)), crate::check::shrink::summaries::dummy_arg())->value)
        ? ({
        auto&& _m = index(args, Nat(0u));
        prism_rtl::is_some(_m) ? ({
        auto&& a = prism_rtl::some_of(_m);
        ({
        auto m_1 = m;
        call_then(start_rel_of(m_1, a->value), [=](std::optional<crate::check::shrink::Rel> rel_of_19508) {
        return ({
            prism_rtl::is_some(rel_of_19508) ? ({
            auto&& x = prism_rtl::some_of(rel_of_19508);
            prism_rtl::finished(std::optional(crate::check::shrink::Rel{.param = x.param, .strict = x.strict || known_non_empty(m_1, a->value)}));
        })
            : prism_rtl::is_none(rel_of_19508) ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
        : throw prism_rtl::Panic("no arm matched");
    })
        : (crate::check::shrink::relations::pre_is(m, name, Text::lit("Values")) || crate::check::shrink::relations::pre_is(m, name, Text::lit("Keys"))) && (len(args) == Nat(1u))
        ? prism_rtl::more(prism_rtl::rc(RelOf(m, or_(index(args, Nat(0u)), crate::check::shrink::summaries::dummy_arg())->value)))
        : ({
        auto&& _m = no_larger_arg(m, c, args);
        prism_rtl::is_some(_m) ? ({
        auto&& a = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(RelOf(m, a)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : prism_rtl::finished(std::optional<crate::check::shrink::Rel>{});
    });
}


/// `Start RelOfCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<crate::check::shrink::Rel>> start_rel_of_call(Map<Text, crate::check::shrink::Rel> m, crate::syntax::Expr c, Array<crate::syntax::Arg> args) {
    return prism_rtl::make_rc<RelOfCall>(m, c, args);
}


/// KnownNonEmpty: fn (Text ==> Rel), Expr -> Bool
bool known_non_empty(const Map<Text, crate::check::shrink::Rel>& m, const crate::syntax::Expr& e) {
    auto&& _m = crate::check::shrink::relations::name_of(e);
    if (prism_rtl::is_some(_m)) {
        auto&& n = prism_rtl::some_of(_m);
        return crate::check::env::has_key(m, prism_rtl::cat("ne:", n));
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?CallOf: fn Expr -> ?((Expr, [Arg]))
std::optional<std::tuple<crate::syntax::Expr, Array<crate::syntax::Arg>>> call_of(const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        return std::optional(std::tuple{c, args});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a1;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
        return std::optional(std::tuple{method_callee(n), method_args(r, args)});
    }
    {
        return std::optional<std::tuple<crate::syntax::Expr, Array<crate::syntax::Arg>>>{};
    }
}


/// ?NoLargerArg: fn (Text ==> Rel), Expr, [Arg] -> ?Expr
std::optional<crate::syntax::Expr> no_larger_arg(const Map<Text, crate::check::shrink::Rel>& m, const crate::syntax::Expr& c, const Array<crate::syntax::Arg>& args) {
    auto&& _m = callee_name(c);
    if (prism_rtl::is_some(_m)) {
        auto&& n = prism_rtl::some_of(_m);
        return crate::check::shrink::relations::is_local(m, n)
            ? std::optional<crate::syntax::Expr>{}
            : ({
            __label__ _done;
            prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
            auto&& _m = crate::prelude::get(m, prism_rtl::cat("fn:", n));
            if (prism_rtl::is_some(_m)) {
                auto&& s = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                    auto&& _m = index(args, s.param);
                    if (prism_rtl::is_some(_m)) {
                        auto&& a = prism_rtl::some_of(_m);
                        _v.set(std::optional(a->value));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(std::optional<crate::syntax::Expr>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(std::optional<crate::syntax::Expr>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<crate::syntax::Expr>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// IsNoLargerPrelude: fn G, Text -> Bool
bool is_no_larger_prelude(const crate::check::env::G& g, const Text& k) {
    return crate::check::types::has_text(Array(std::vector{Text::lit("Prelude.Take"), Text::lit("Prelude.Drop"), Text::lit("Prelude.Filter"), Text::lit("Prelude.Remove"), Text::lit("Prelude.Min"), Text::lit("Prelude.@Flatten")}), k) && crate::check::shrink::relations::is_prelude_key(g, k);
}

}  // namespace crate::check::shrink::walk


// The module `Check.Typed`, from `target/bootstrap/cpp-src/prismc/check/typed/mod.prism`.
namespace crate::check::typed {

void AppNote::show(Printer& p) const {
    p.record("AppNote", {{"at", at}, {"callee", callee}, {"kind", kind}, {"layer", layer}, {"lifted", lifted}, {"inner", inner}, {"color", color}});
}

Pod AppNote::to_pod() const {
    return Pod::record("AppNote", {{"at", prism_rtl::to_pod(at)}, {"callee", prism_rtl::to_pod(callee)}, {"kind", prism_rtl::to_pod(kind)}, {"layer", prism_rtl::to_pod(layer)}, {"lifted", prism_rtl::to_pod(lifted)}, {"inner", prism_rtl::to_pod(inner)}, {"color", prism_rtl::to_pod(color)}});
}

Result<AppNote> AppNote::from_pod(const Pod& whole) {
    return AppNote{.at = TRY(prism_rtl::from_pod<SrcAt>(TRY(crate::prelude::field(whole, "at")))), .callee = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "callee")))), .kind = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "kind")))), .layer = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "layer")))), .lifted = TRY(prism_rtl::from_pod<Array<Nat>>(TRY(crate::prelude::field(whole, "lifted")))), .inner = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "inner")))), .color = TRY(prism_rtl::from_pod<crate::check::types::Col>(TRY(crate::prelude::field(whole, "color"))))};
}


void BinderNote::show(Printer& p) const {
    p.record("BinderNote", {{"at", at}, {"name", name}, {"ty", ty}});
}

Pod BinderNote::to_pod() const {
    return Pod::record("BinderNote", {{"at", prism_rtl::to_pod(at)}, {"name", prism_rtl::to_pod(name)}, {"ty", prism_rtl::to_pod(ty)}});
}

Result<BinderNote> BinderNote::from_pod(const Pod& whole) {
    return BinderNote{.at = TRY(prism_rtl::from_pod<SrcAt>(TRY(crate::prelude::field(whole, "at")))), .name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .ty = TRY(prism_rtl::from_pod<crate::check::types::Ty>(TRY(crate::prelude::field(whole, "ty"))))};
}


void DefNote::show(Printer& p) const {
    p.record("DefNote", {{"at", at}, {"name", name}, {"scheme", scheme}});
}

Pod DefNote::to_pod() const {
    return Pod::record("DefNote", {{"at", prism_rtl::to_pod(at)}, {"name", prism_rtl::to_pod(name)}, {"scheme", prism_rtl::to_pod(scheme)}});
}

Result<DefNote> DefNote::from_pod(const Pod& whole) {
    return DefNote{.at = TRY(prism_rtl::from_pod<SrcAt>(TRY(crate::prelude::field(whole, "at")))), .name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .scheme = TRY(prism_rtl::from_pod<crate::check::types::Scheme>(TRY(crate::prelude::field(whole, "scheme"))))};
}


void FnNote::show(Printer& p) const {
    p.record("FnNote", {{"at", at}, {"name", name}, {"declared", declared}, {"body", body}});
}

Pod FnNote::to_pod() const {
    return Pod::record("FnNote", {{"at", prism_rtl::to_pod(at)}, {"name", prism_rtl::to_pod(name)}, {"declared", prism_rtl::to_pod(declared)}, {"body", prism_rtl::to_pod(body)}});
}

Result<FnNote> FnNote::from_pod(const Pod& whole) {
    return FnNote{.at = TRY(prism_rtl::from_pod<SrcAt>(TRY(crate::prelude::field(whole, "at")))), .name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .declared = TRY(prism_rtl::from_pod<crate::check::types::Col>(TRY(crate::prelude::field(whole, "declared")))), .body = TRY(prism_rtl::from_pod<crate::check::types::Col>(TRY(crate::prelude::field(whole, "body"))))};
}


void GenNote::show(Printer& p) const {
    p.record("GenNote", {{"at", at}, {"name", name}, {"tys", tys}, {"cols", cols}});
}

Pod GenNote::to_pod() const {
    return Pod::record("GenNote", {{"at", prism_rtl::to_pod(at)}, {"name", prism_rtl::to_pod(name)}, {"tys", prism_rtl::to_pod(tys)}, {"cols", prism_rtl::to_pod(cols)}});
}

Result<GenNote> GenNote::from_pod(const Pod& whole) {
    return GenNote{.at = TRY(prism_rtl::from_pod<SrcAt>(TRY(crate::prelude::field(whole, "at")))), .name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .tys = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "tys")))), .cols = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "cols"))))};
}


void GroupNote::show(Printer& p) const {
    p.record("GroupNote", {{"at", at}, {"kind", kind}, {"order", order}});
}

Pod GroupNote::to_pod() const {
    return Pod::record("GroupNote", {{"at", prism_rtl::to_pod(at)}, {"kind", prism_rtl::to_pod(kind)}, {"order", prism_rtl::to_pod(order)}});
}

Result<GroupNote> GroupNote::from_pod(const Pod& whole) {
    return GroupNote{.at = TRY(prism_rtl::from_pod<SrcAt>(TRY(crate::prelude::field(whole, "at")))), .kind = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "kind")))), .order = TRY(prism_rtl::from_pod<Array<Array<Nat>>>(TRY(crate::prelude::field(whole, "order"))))};
}


void ImplNote::show(Printer& p) const {
    p.record("ImplNote", {{"at", at}, {"cls", cls}, {"ty", ty}, {"how", how}});
}

Pod ImplNote::to_pod() const {
    return Pod::record("ImplNote", {{"at", prism_rtl::to_pod(at)}, {"cls", prism_rtl::to_pod(cls)}, {"ty", prism_rtl::to_pod(ty)}, {"how", prism_rtl::to_pod(how)}});
}

Result<ImplNote> ImplNote::from_pod(const Pod& whole) {
    return ImplNote{.at = TRY(prism_rtl::from_pod<SrcAt>(TRY(crate::prelude::field(whole, "at")))), .cls = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "cls")))), .ty = TRY(prism_rtl::from_pod<crate::check::types::Ty>(TRY(crate::prelude::field(whole, "ty")))), .how = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "how"))))};
}


void InstNote::show(Printer& p) const {
    p.record("InstNote", {{"at", at}, {"name", name}, {"tys", tys}, {"cols", cols}});
}

Pod InstNote::to_pod() const {
    return Pod::record("InstNote", {{"at", prism_rtl::to_pod(at)}, {"name", prism_rtl::to_pod(name)}, {"tys", prism_rtl::to_pod(tys)}, {"cols", prism_rtl::to_pod(cols)}});
}

Result<InstNote> InstNote::from_pod(const Pod& whole) {
    return InstNote{.at = TRY(prism_rtl::from_pod<SrcAt>(TRY(crate::prelude::field(whole, "at")))), .name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .tys = TRY(prism_rtl::from_pod<Array<std::tuple<Text, crate::check::types::Ty>>>(TRY(crate::prelude::field(whole, "tys")))), .cols = TRY(prism_rtl::from_pod<Array<std::tuple<Text, crate::check::types::Col>>>(TRY(crate::prelude::field(whole, "cols"))))};
}


void LiftNote::show(Printer& p) const {
    p.record("LiftNote", {{"at", at}, {"sigil", sigil}, {"operands", operands}});
}

Pod LiftNote::to_pod() const {
    return Pod::record("LiftNote", {{"at", prism_rtl::to_pod(at)}, {"sigil", prism_rtl::to_pod(sigil)}, {"operands", prism_rtl::to_pod(operands)}});
}

Result<LiftNote> LiftNote::from_pod(const Pod& whole) {
    return LiftNote{.at = TRY(prism_rtl::from_pod<SrcAt>(TRY(crate::prelude::field(whole, "at")))), .sigil = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "sigil")))), .operands = TRY(prism_rtl::from_pod<Array<crate::syntax::Range>>(TRY(crate::prelude::field(whole, "operands"))))};
}


void MethodNote::show(Printer& p) const {
    p.record("MethodNote", {{"at", at}, {"method", method}, {"cls", cls}});
}

Pod MethodNote::to_pod() const {
    return Pod::record("MethodNote", {{"at", prism_rtl::to_pod(at)}, {"method", prism_rtl::to_pod(method)}, {"cls", prism_rtl::to_pod(cls)}});
}

Result<MethodNote> MethodNote::from_pod(const Pod& whole) {
    return MethodNote{.at = TRY(prism_rtl::from_pod<SrcAt>(TRY(crate::prelude::field(whole, "at")))), .method = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "method")))), .cls = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "cls"))))};
}


void SrcAt::show(Printer& p) const {
    p.record("SrcAt", {{"file", file}, {"span", span}});
}

Pod SrcAt::to_pod() const {
    return Pod::record("SrcAt", {{"file", prism_rtl::to_pod(file)}, {"span", prism_rtl::to_pod(span)}});
}

Result<SrcAt> SrcAt::from_pod(const Pod& whole) {
    return SrcAt{.file = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void TProgram::show(Printer& p) const {
    p.record("TProgram", {{"exprs", exprs}, {"apps", apps}, {"lifts", lifts}, {"fns", fns}, {"impls", impls}, {"methods", methods}, {"groups", groups}, {"binders", binders}, {"gens", gens}, {"insts", insts}, {"defs", defs}, {"unshrunk", unshrunk}});
}

Pod TProgram::to_pod() const {
    return Pod::record("TProgram", {{"exprs", prism_rtl::to_pod(exprs)}, {"apps", prism_rtl::to_pod(apps)}, {"lifts", prism_rtl::to_pod(lifts)}, {"fns", prism_rtl::to_pod(fns)}, {"impls", prism_rtl::to_pod(impls)}, {"methods", prism_rtl::to_pod(methods)}, {"groups", prism_rtl::to_pod(groups)}, {"binders", prism_rtl::to_pod(binders)}, {"gens", prism_rtl::to_pod(gens)}, {"insts", prism_rtl::to_pod(insts)}, {"defs", prism_rtl::to_pod(defs)}, {"unshrunk", prism_rtl::to_pod(unshrunk)}});
}

Result<TProgram> TProgram::from_pod(const Pod& whole) {
    return TProgram{.exprs = TRY(prism_rtl::from_pod<Array<TyNote>>(TRY(crate::prelude::field(whole, "exprs")))), .apps = TRY(prism_rtl::from_pod<Array<AppNote>>(TRY(crate::prelude::field(whole, "apps")))), .lifts = TRY(prism_rtl::from_pod<Array<LiftNote>>(TRY(crate::prelude::field(whole, "lifts")))), .fns = TRY(prism_rtl::from_pod<Array<FnNote>>(TRY(crate::prelude::field(whole, "fns")))), .impls = TRY(prism_rtl::from_pod<Array<ImplNote>>(TRY(crate::prelude::field(whole, "impls")))), .methods = TRY(prism_rtl::from_pod<Array<MethodNote>>(TRY(crate::prelude::field(whole, "methods")))), .groups = TRY(prism_rtl::from_pod<Array<GroupNote>>(TRY(crate::prelude::field(whole, "groups")))), .binders = TRY(prism_rtl::from_pod<Array<BinderNote>>(TRY(crate::prelude::field(whole, "binders")))), .gens = TRY(prism_rtl::from_pod<Array<GenNote>>(TRY(crate::prelude::field(whole, "gens")))), .insts = TRY(prism_rtl::from_pod<Array<InstNote>>(TRY(crate::prelude::field(whole, "insts")))), .defs = TRY(prism_rtl::from_pod<Array<DefNote>>(TRY(crate::prelude::field(whole, "defs")))), .unshrunk = TRY(prism_rtl::from_pod<Array<SrcAt>>(TRY(crate::prelude::field(whole, "unshrunk"))))};
}


void TyNote::show(Printer& p) const {
    p.record("TyNote", {{"at", at}, {"ty", ty}});
}

Pod TyNote::to_pod() const {
    return Pod::record("TyNote", {{"at", prism_rtl::to_pod(at)}, {"ty", prism_rtl::to_pod(ty)}});
}

Result<TyNote> TyNote::from_pod(const Pod& whole) {
    return TyNote{.at = TRY(prism_rtl::from_pod<SrcAt>(TRY(crate::prelude::field(whole, "at")))), .ty = TRY(prism_rtl::from_pod<crate::check::types::Ty>(TRY(crate::prelude::field(whole, "ty"))))};
}


/// let emptyTyped
TProgram empty_typed() {
    return TProgram{.exprs = Array<TyNote>{}, .apps = Array<AppNote>{}, .lifts = Array<LiftNote>{}, .fns = Array<FnNote>{}, .impls = Array<ImplNote>{}, .methods = Array<MethodNote>{}, .groups = Array<GroupNote>{}, .binders = Array<BinderNote>{}, .gens = Array<GenNote>{}, .insts = Array<InstNote>{}, .defs = Array<DefNote>{}, .unshrunk = Array<SrcAt>{}};
}


/// AtKey: fn SrcAt -> Text
Text at_key(const SrcAt& a) {
    return prism_rtl::cat(a->file, ":", a.span.start, ":", a.span.end);
}

}  // namespace crate::check::typed
