// The module `Check.Shrink.Summaries`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/shrink/summaries/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Check.Shrink.Summaries`, from `target/bootstrap/cpp-src/prismc/check/shrink/summaries.prism`.
namespace crate::check::shrink::summaries {

/// PartsSummaries: unbounded fn Shrink, [Def] -> (Text ==> Nat)
Map<Text, Nat> parts_summaries_f(const crate::check::shrink::Shrink& sk_p0, const Array<crate::check::env::Def>& fns_p1) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(fns_p1, Map<Text, Nat>{}, ({
        auto sk_p0x = sk_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Nat>>(std::tuple<Map<Text, Nat>, crate::check::env::Def>)>>(prism_rtl::rc([=, sk_p0x = std::move(sk_p0x)](std::tuple<Map<Text, Nat>, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_p0xy = sk_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, sk_p0xy = std::move(sk_p0xy)]() {
            return ({
                auto m_p2 = p0;
                auto d_p3 = p1;
                ({
                auto&& _m = prism_rtl::deref(d_p3).body_p;
                prism_rtl::is<crate::check::env::DefBody::DbFn>(_m) ? ({
                auto&& clauses_p4 = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
                ({
                auto n_p5 = ({
                    __label__ _done;
                    prism_rtl::Slot<Nat> _v;
                    auto&& _m = crate::prelude::index(clauses_p4, Nat(0u));
                    if (prism_rtl::is_some(_m)) {
                        auto&& c0_p7 = prism_rtl::some_of(_m);
                        _v.set(crate::prelude::len(prism_rtl::deref(c0_p7).params_p));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Nat(0u));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto clauses_p4x = clauses_p4;
                (crate::prelude::call_value(crate::prelude::filter_job(crate::check::errors::range0_f(n_p5), ({
                auto clauses_p4xx = clauses_p4x;
                auto sk_p0xyx = sk_p0xy;
                auto d_p3x = d_p3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Nat)>>(prism_rtl::rc([=, clauses_p4xx = std::move(clauses_p4xx), sk_p0xyx = std::move(sk_p0xyx), d_p3x = std::move(d_p3x)](Nat p0) {
                return ({
                    auto clauses_p4xxy = clauses_p4xx;
                    auto sk_p0xyxy = sk_p0xyx;
                    auto d_p3xy = d_p3x;
                    (crate::prelude::entered(crate::prelude::once_job([=, clauses_p4xxy = std::move(clauses_p4xxy), sk_p0xyxy = std::move(sk_p0xyxy), d_p3xy = std::move(d_p3xy)]() {
                    return ({
                        auto i_p8 = p0;
                        (crate::prelude::fold_job(clauses_p4xxy, true, ({
                        auto sk_p0xyxyx = sk_p0xyxy;
                        auto d_p3xyx = d_p3xy;
                        auto i_p8x = i_p8;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, sk_p0xyxyx = std::move(sk_p0xyxyx), d_p3xyx = std::move(d_p3xyx), i_p8x = std::move(i_p8x)](std::tuple<bool, crate::syntax::decls::FnClause> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto sk_p0xyxyxy = sk_p0xyxyx;
                            auto d_p3xyxy = d_p3xyx;
                            auto i_p8xy = i_p8x;
                            (crate::prelude::entered(crate::prelude::once_job([=, sk_p0xyxyxy = std::move(sk_p0xyxyxy), d_p3xyxy = std::move(d_p3xyxy), i_p8xy = std::move(i_p8xy)]() {
                            return ({
                                auto okc_p9 = p0;
                                auto c_pa = p1;
                                (prism_rtl::finished(std::move(okc_p9) && clause_within_f(crate::check::shrink::locals::clause_base_f(sk_p0xyxyxy, d_p3xyxy, c_pa), c_pa, i_p8xy)));
                            });
                        })));
                        });
                    })));
                    }))->cycle());
                    });
                })));
                });
            })));
            })), [=](Array<Nat> filter_2084) {
                return ({
                    auto ok_p6 = filter_2084;
                    ({
                    auto&& _m = crate::prelude::index(ok_p6, Nat(0u));
                    prism_rtl::is_some(_m) ? ({
                    auto&& i_pb = prism_rtl::some_of(_m);
                    prism_rtl::finished(crate::prelude::insert(m_p2, prism_rtl::deref(d_p3).qk_p, i_pb));
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(m_p2)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
            })
                : prism_rtl::finished(m_p2);
            });
            });
        })));
        });
    }));
    })));
}


prism_rtl::Turn<Map<Text, Nat>> PartsSummaries::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& fns_p1 = this->fns_p1;
    return crate::prelude::fold_job(fns_p1, Map<Text, Nat>{}, ({
        auto sk_p0x = sk_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Nat>>(std::tuple<Map<Text, Nat>, crate::check::env::Def>)>>(prism_rtl::rc([=, sk_p0x = std::move(sk_p0x)](std::tuple<Map<Text, Nat>, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_p0xy = sk_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, sk_p0xy = std::move(sk_p0xy)]() {
            return ({
                auto m_p2 = p0;
                auto d_p3 = p1;
                ({
                auto&& _m = prism_rtl::deref(d_p3).body_p;
                prism_rtl::is<crate::check::env::DefBody::DbFn>(_m) ? ({
                auto&& clauses_p4 = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
                ({
                auto n_p5 = ({
                    __label__ _done;
                    prism_rtl::Slot<Nat> _v;
                    auto&& _m = crate::prelude::index(clauses_p4, Nat(0u));
                    if (prism_rtl::is_some(_m)) {
                        auto&& c0_p7 = prism_rtl::some_of(_m);
                        _v.set(crate::prelude::len(prism_rtl::deref(c0_p7).params_p));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Nat(0u));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto clauses_p4x = clauses_p4;
                (crate::prelude::call_value(crate::prelude::filter_job(crate::check::errors::range0_f(n_p5), ({
                auto clauses_p4xx = clauses_p4x;
                auto sk_p0xyx = sk_p0xy;
                auto d_p3x = d_p3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Nat)>>(prism_rtl::rc([=, clauses_p4xx = std::move(clauses_p4xx), sk_p0xyx = std::move(sk_p0xyx), d_p3x = std::move(d_p3x)](Nat p0) {
                return ({
                    auto clauses_p4xxy = clauses_p4xx;
                    auto sk_p0xyxy = sk_p0xyx;
                    auto d_p3xy = d_p3x;
                    (crate::prelude::entered(crate::prelude::once_job([=, clauses_p4xxy = std::move(clauses_p4xxy), sk_p0xyxy = std::move(sk_p0xyxy), d_p3xy = std::move(d_p3xy)]() {
                    return ({
                        auto i_p8 = p0;
                        (crate::prelude::fold_job(clauses_p4xxy, true, ({
                        auto sk_p0xyxyx = sk_p0xyxy;
                        auto d_p3xyx = d_p3xy;
                        auto i_p8x = i_p8;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, sk_p0xyxyx = std::move(sk_p0xyxyx), d_p3xyx = std::move(d_p3xyx), i_p8x = std::move(i_p8x)](std::tuple<bool, crate::syntax::decls::FnClause> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto sk_p0xyxyxy = sk_p0xyxyx;
                            auto d_p3xyxy = d_p3xyx;
                            auto i_p8xy = i_p8x;
                            (crate::prelude::entered(crate::prelude::once_job([=, sk_p0xyxyxy = std::move(sk_p0xyxyxy), d_p3xyxy = std::move(d_p3xyxy), i_p8xy = std::move(i_p8xy)]() {
                            return ({
                                auto okc_p9 = p0;
                                auto c_pa = p1;
                                (prism_rtl::finished(std::move(okc_p9) && clause_within_f(crate::check::shrink::locals::clause_base_f(sk_p0xyxyxy, d_p3xyxy, c_pa), c_pa, i_p8xy)));
                            });
                        })));
                        });
                    })));
                    }))->cycle());
                    });
                })));
                });
            })));
            })), [=](Array<Nat> filter_2084) {
                return ({
                    auto ok_p6 = filter_2084;
                    ({
                    auto&& _m = crate::prelude::index(ok_p6, Nat(0u));
                    prism_rtl::is_some(_m) ? ({
                    auto&& i_pb = prism_rtl::some_of(_m);
                    prism_rtl::finished(crate::prelude::insert(m_p2, prism_rtl::deref(d_p3).qk_p, i_pb));
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(m_p2)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
            })
                : prism_rtl::finished(m_p2);
            });
            });
        })));
        });
    }));
    }))->cycle();
}


/// `Start PartsSummaries, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Nat>> start_parts_summaries_f(crate::check::shrink::Shrink sk_p0, Array<crate::check::env::Def> fns_p1) {
    return prism_rtl::make_rc<PartsSummaries>(sk_p0, fns_p1);
}


/// ClauseWithin: unbounded fn (Text ==> Rel), FnClause, Nat -> Bool
bool clause_within_f(const Map<Text, crate::check::shrink::Rel>& base_p0, const crate::syntax::decls::FnClause& c_p1, const Nat& i_p2) {
    auto&& _m = c_p1.body_p;
    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(_m)) {
        auto&& e_p3 = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(_m).a0;
        return within_f(base_p0, i_p2, e_p3);
    }
    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(_m)) {
        auto&& b_p4 = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(_m).a0;
        return within_block_f(base_p0, i_p2, b_p4);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> ClauseWithin::cycle() const {
    const auto& base_p0 = this->base_p0;
    const auto& c_p1 = this->c_p1;
    const auto& i_p2 = this->i_p2;
    return ({
        auto&& _m = prism_rtl::deref(c_p1).body_p;
        prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(_m) ? ({
        auto&& e_p3 = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(_m).a0;
        prism_rtl::more(prism_rtl::rc(Within(base_p0, i_p2, e_p3)));
    })
        : prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(_m) ? ({
        auto&& b_p4 = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(_m).a0;
        prism_rtl::more(prism_rtl::rc(WithinBlock(base_p0, i_p2, b_p4)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ClauseWithin, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_clause_within_f(Map<Text, crate::check::shrink::Rel> base_p0, crate::syntax::decls::FnClause c_p1, Nat i_p2) {
    return prism_rtl::make_rc<ClauseWithin>(base_p0, c_p1, i_p2);
}


/// Within: unbounded fn (Text ==> Rel), Nat, Expr -> Bool
bool within_f(const Map<Text, crate::check::shrink::Rel>& m_p0, const Nat& i_p1, const crate::syntax::Expr& e_p2) {
    auto&& _m = crate::check::shrink::walk::rel_of_o(m_p0, e_p2);
    if (prism_rtl::is_some(_m)) {
        auto&& r_p3 = prism_rtl::some_of(_m);
        return prism_rtl::deref(r_p3).param_p == i_p1;
    }
    if (prism_rtl::is_none(_m)) {
        auto&& _m = prism_rtl::deref(e_p2.kind_p);
        if (prism_rtl::is<crate::syntax::ExprKind::EArray>(_m)) {
            auto&& es_p4 = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
            return crate::prelude::run_to_end(crate::prelude::fold_job(es_p4, true, ({
                auto m_p0x = m_p0;
                auto i_p1x = i_p1;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Expr>)>>(prism_rtl::rc([=, m_p0x = std::move(m_p0x), i_p1x = std::move(i_p1x)](std::tuple<bool, crate::syntax::Expr> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto m_p0xy = m_p0x;
                    auto i_p1xy = i_p1x;
                    (crate::prelude::entered(crate::prelude::once_job([=, m_p0xy = std::move(m_p0xy), i_p1xy = std::move(i_p1xy)]() {
                    return ({
                        auto ok_p5 = p0;
                        auto x_p6 = p1;
                        (prism_rtl::finished(std::move(ok_p5) && part_f(m_p0xy, i_p1xy, x_p6)));
                    });
                })));
                });
            })));
            })));
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMap>(_m)) {
            auto&& kvs_p7 = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
            return crate::prelude::run_to_end(crate::prelude::fold_job(kvs_p7, true, ({
                auto m_p0x = m_p0;
                auto i_p1x = i_p1;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<crate::syntax::Expr, crate::syntax::Expr>>)>>(prism_rtl::rc([=, m_p0x = std::move(m_p0x), i_p1x = std::move(i_p1x)](std::tuple<bool, std::tuple<crate::syntax::Expr, crate::syntax::Expr>> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto m_p0xy = m_p0x;
                    auto i_p1xy = i_p1x;
                    (crate::prelude::entered(crate::prelude::once_job([=, m_p0xy = std::move(m_p0xy), i_p1xy = std::move(i_p1xy)]() {
                    return ({
                        auto ok_p8 = p0;
                        auto [k_p9, v_pa] = p1;
                        (prism_rtl::finished((std::move(ok_p8) && part_f(m_p0xy, i_p1xy, k_p9)) && part_f(m_p0xy, i_p1xy, v_pa)));
                    });
                })));
                });
            })));
            })));
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
            auto&& x_pb = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
            return within_f(m_p0, i_p1, prism_rtl::deref(prism_rtl::deref(x_pb)));
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
            auto&& s_pc = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
            auto&& arms_pd = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
            return crate::prelude::run_to_end(crate::prelude::fold_job(arms_pd, true, ({
                auto s_pcx = prism_rtl::deref(prism_rtl::deref(s_pc));
                auto m_p0x = m_p0;
                auto i_p1x = i_p1;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Arm>)>>(prism_rtl::rc([=, s_pcx = std::move(s_pcx), m_p0x = std::move(m_p0x), i_p1x = std::move(i_p1x)](std::tuple<bool, crate::syntax::Arm> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto s_pcxy = s_pcx;
                    auto m_p0xy = m_p0x;
                    auto i_p1xy = i_p1x;
                    (crate::prelude::entered(crate::prelude::once_job([=, s_pcxy = std::move(s_pcxy), m_p0xy = std::move(m_p0xy), i_p1xy = std::move(i_p1xy)]() {
                    return ({
                        auto ok_pe = p0;
                        auto a_pf = p1;
                        (prism_rtl::finished(std::move(ok_pe) && within_block_f(crate::check::shrink::relations::arm_pat_rels_f(s_pcxy, a_pf, m_p0xy), i_p1xy, prism_rtl::deref(a_pf).body_p)));
                    });
                })));
                });
            })));
            })));
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2)) {
            auto&& c_pg = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
            auto&& t_ph = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
            auto&& el_pi = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
            return within_block_f(crate::check::shrink::relations::cond_rels_f(prism_rtl::deref(prism_rtl::deref(c_pg)), m_p0), i_p1, t_ph) && within_block_f(m_p0, i_p1, el_pi);
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m)) {
            auto&& start_pj = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
            auto&& b_pk = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
            return within_f(m_p0, i_p1, prism_rtl::deref(prism_rtl::deref(start_pj))) && update_within_f(crate::prelude::insert(m_p0, Text::lit("&_"), crate::check::shrink::Rel{.param_p = i_p1, .strict_p = false}), i_p1, b_pk);
        }
        {
            auto&& _m = crate::check::shrink::walk::call_of_o(e_p2);
            if (prism_rtl::is_some(_m)) {
                auto&& c_pl = std::get<0>(prism_rtl::some_of(_m));
                auto&& args_pm = std::get<1>(prism_rtl::some_of(_m));
                auto&& _m = crate::check::shrink::walk::traversal_of_o(m_p0, c_pl, args_pm);
                if (prism_rtl::is_some(_m)) {
                    auto&& coll_pn = std::get<0>(prism_rtl::some_of(_m));
                    auto&& step_po = std::get<1>(prism_rtl::some_of(_m));
                    auto&& at_pp = std::get<2>(prism_rtl::some_of(_m));
                    return within_f(m_p0, i_p1, coll_pn) && step_within_f(m_p0, i_p1, crate::check::shrink::locals::expr_name_f(c_pl), coll_pn, step_po, at_pp, prism_rtl::deref(crate::prelude::or_(crate::prelude::index(args_pm, Nat(1u)), dummy_arg_p())).value_p);
                }
                if (prism_rtl::is_none(_m)) {
                    return false;
                }
                prism_rtl::unreachable("no arm matched");
            }
            if (prism_rtl::is_none(_m)) {
                return false;
            }
            prism_rtl::unreachable("no arm matched");
        }
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> Within::cycle() const {
    const auto& m_p0 = this->m_p0;
    const auto& i_p1 = this->i_p1;
    const auto& e_p2 = this->e_p2;
    auto e_p2x = e_p2;
    auto i_p1x = i_p1;
    auto m_p0x = m_p0;
    return crate::prelude::call_then(crate::check::shrink::walk::start_rel_of_o(m_p0x, e_p2x), [=](std::optional<crate::check::shrink::Rel> rel_of_o_2544) {
        return ({
            prism_rtl::is_some(rel_of_o_2544) ? ({
            auto&& r_p3 = prism_rtl::some_of(rel_of_o_2544);
            prism_rtl::finished(prism_rtl::deref(r_p3).param_p == i_p1x);
        })
            : prism_rtl::is_none(rel_of_o_2544) ? ({
            auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p2x).kind_p);
            prism_rtl::is<crate::syntax::ExprKind::EArray>(_m) ? ({
            auto&& es_p4 = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
            crate::prelude::fold_job(es_p4, true, ({
            auto m_p0xx = m_p0x;
            auto i_p1xx = i_p1x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Expr>)>>(prism_rtl::rc([=, m_p0xx = std::move(m_p0xx), i_p1xx = std::move(i_p1xx)](std::tuple<bool, crate::syntax::Expr> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto m_p0xxy = m_p0xx;
                auto i_p1xxy = i_p1xx;
                (crate::prelude::entered(crate::prelude::once_job([=, m_p0xxy = std::move(m_p0xxy), i_p1xxy = std::move(i_p1xxy)]() {
                return ({
                    auto ok_p5 = p0;
                    auto x_p6 = p1;
                    (prism_rtl::finished(std::move(ok_p5) && part_f(m_p0xxy, i_p1xxy, x_p6)));
                });
            })));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::syntax::ExprKind::EMap>(_m) ? ({
            auto&& kvs_p7 = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
            crate::prelude::fold_job(kvs_p7, true, ({
            auto m_p0xx = m_p0x;
            auto i_p1xx = i_p1x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<crate::syntax::Expr, crate::syntax::Expr>>)>>(prism_rtl::rc([=, m_p0xx = std::move(m_p0xx), i_p1xx = std::move(i_p1xx)](std::tuple<bool, std::tuple<crate::syntax::Expr, crate::syntax::Expr>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto m_p0xxy = m_p0xx;
                auto i_p1xxy = i_p1xx;
                (crate::prelude::entered(crate::prelude::once_job([=, m_p0xxy = std::move(m_p0xxy), i_p1xxy = std::move(i_p1xxy)]() {
                return ({
                    auto ok_p8 = p0;
                    auto [k_p9, v_pa] = p1;
                    (prism_rtl::finished((std::move(ok_p8) && part_f(m_p0xxy, i_p1xxy, k_p9)) && part_f(m_p0xxy, i_p1xxy, v_pa)));
                });
            })));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
            auto&& x_pb = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
            prism_rtl::more(prism_rtl::rc(Within(m_p0x, i_p1x, prism_rtl::deref(prism_rtl::deref(x_pb)))));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
            auto&& s_pc = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
            auto&& arms_pd = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
            crate::prelude::fold_job(arms_pd, true, ({
            auto s_pcx = prism_rtl::deref(prism_rtl::deref(s_pc));
            auto m_p0xx = m_p0x;
            auto i_p1xx = i_p1x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Arm>)>>(prism_rtl::rc([=, s_pcx = std::move(s_pcx), m_p0xx = std::move(m_p0xx), i_p1xx = std::move(i_p1xx)](std::tuple<bool, crate::syntax::Arm> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto s_pcxy = s_pcx;
                auto m_p0xxy = m_p0xx;
                auto i_p1xxy = i_p1xx;
                (crate::prelude::entered(crate::prelude::once_job([=, s_pcxy = std::move(s_pcxy), m_p0xxy = std::move(m_p0xxy), i_p1xxy = std::move(i_p1xxy)]() {
                return ({
                    auto ok_pe = p0;
                    auto a_pf = p1;
                    (prism_rtl::finished(std::move(ok_pe) && within_block_f(crate::check::shrink::relations::arm_pat_rels_f(s_pcxy, a_pf, m_p0xxy), i_p1xxy, prism_rtl::deref(a_pf).body_p)));
                });
            })));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2) ? ({
            auto&& c_pg = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
            auto&& t_ph = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
            auto&& el_pi = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
            ({
            auto c_pgx = prism_rtl::deref(prism_rtl::deref(c_pg));
            auto el_pix = el_pi;
            auto t_phx = t_ph;
            (crate::prelude::call_then(crate::check::shrink::relations::start_cond_rels_f(c_pgx, m_p0x), [=, el_pix = std::move(el_pix), t_phx = std::move(t_phx)](Map<Text, crate::check::shrink::Rel> cond_rels_f_2928) { return crate::prelude::call_then(start_within_block_f(cond_rels_f_2928, i_p1x, t_phx), [=](bool within_block_f_2915) { return prism_rtl::finished(within_block_f_2915 && within_block_f(m_p0x, i_p1x, el_pix)); }); }));
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m) ? ({
            auto&& start_pj = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
            auto&& b_pk = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
            ({
            auto b_pkx = b_pk;
            auto start_pjx = prism_rtl::deref(prism_rtl::deref(start_pj));
            (crate::prelude::call_then(start_within_f(m_p0x, i_p1x, start_pjx), [=, b_pkx = std::move(b_pkx)](bool within_f_3002) { return prism_rtl::finished(within_f_3002 && update_within_f(crate::prelude::insert(m_p0x, Text::lit("&_"), crate::check::shrink::Rel{.param_p = i_p1x, .strict_p = false}), i_p1x, b_pkx)); }));
        });
        })
            : ({
            auto&& _m = crate::check::shrink::walk::call_of_o(e_p2x);
            prism_rtl::is_some(_m) ? ({
            auto&& c_pl = std::get<0>(prism_rtl::some_of(_m));
            auto&& args_pm = std::get<1>(prism_rtl::some_of(_m));
            ({
            auto&& _m = crate::check::shrink::walk::traversal_of_o(m_p0x, c_pl, args_pm);
            prism_rtl::is_some(_m) ? ({
            auto&& coll_pn = std::get<0>(prism_rtl::some_of(_m));
            auto&& step_po = std::get<1>(prism_rtl::some_of(_m));
            auto&& at_pp = std::get<2>(prism_rtl::some_of(_m));
            crate::prelude::call_then(start_within_f(m_p0x, i_p1x, coll_pn), [=](bool within_f_3223) { return prism_rtl::finished(within_f_3223 && step_within_f(m_p0x, i_p1x, crate::check::shrink::locals::expr_name_f(c_pl), coll_pn, step_po, at_pp, prism_rtl::deref(crate::prelude::or_(crate::prelude::index(args_pm, Nat(1u)), dummy_arg_p())).value_p)); });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
    });
}


/// `Start Within, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_within_f(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, crate::syntax::Expr e_p2) {
    return prism_rtl::make_rc<Within>(m_p0, i_p1, e_p2);
}


/// UpdateWithin: unbounded fn (Text ==> Rel), Nat, Block -> Bool
bool update_within_f(const Map<Text, crate::check::shrink::Rel>& m_p0, const Nat& i_p1, const crate::syntax::Block& b_p2) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::shrink::walk::stmts_spots_f(b_p2.stmts_p, m_p0), true, ({
        auto i_p1x = i_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=, i_p1x = std::move(i_p1x)](std::tuple<bool, crate::check::shrink::walk::Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto i_p1xy = i_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, i_p1xy = std::move(i_p1xy)]() {
            return ({
                auto ok_p3 = p0;
                auto sp_p4 = p1;
                (prism_rtl::finished(std::move(ok_p3) && spot_keeps_within_f(sp_p4, i_p1xy)));
            });
        })));
        });
    })));
    })));
}


prism_rtl::Turn<bool> UpdateWithin::cycle() const {
    const auto& m_p0 = this->m_p0;
    const auto& i_p1 = this->i_p1;
    const auto& b_p2 = this->b_p2;
    auto b_p2x = b_p2;
    auto i_p1x = i_p1;
    auto m_p0x = m_p0;
    return crate::prelude::call_then(crate::check::shrink::walk::start_stmts_spots_f(prism_rtl::deref(b_p2x).stmts_p, m_p0x), [=](Array<crate::check::shrink::walk::Spot> stmts_spots_f_3685) {
        return crate::prelude::fold_job(stmts_spots_f_3685, true, ({
            auto i_p1xx = i_p1x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=, i_p1xx = std::move(i_p1xx)](std::tuple<bool, crate::check::shrink::walk::Spot> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto i_p1xxy = i_p1xx;
                (crate::prelude::entered(crate::prelude::once_job([=, i_p1xxy = std::move(i_p1xxy)]() {
                return ({
                    auto ok_p3 = p0;
                    auto sp_p4 = p1;
                    (prism_rtl::finished(std::move(ok_p3) && spot_keeps_within_f(sp_p4, i_p1xxy)));
                });
            })));
            });
        })));
        }))->cycle();
    });
}


/// `Start UpdateWithin, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_update_within_f(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, crate::syntax::Block b_p2) {
    return prism_rtl::make_rc<UpdateWithin>(m_p0, i_p1, b_p2);
}


/// SpotKeepsWithin: unbounded fn Spot, Nat -> Bool
bool spot_keeps_within_f(const crate::check::shrink::walk::Spot& spot0, const Nat& n1) {
    auto&& _m = std::tuple{spot0, n1};
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(std::get<0>(_m))) {
        auto&& s_p0 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(std::get<0>(_m)).a0;
        auto&& m_p1 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(std::get<0>(_m)).a1;
        auto&& i_p2 = std::get<1>(_m);
        auto&& _m = prism_rtl::deref(s_p0).kind_p;
        if (prism_rtl::is<crate::syntax::StmtKind::SSet>(_m)) {
            auto&& t_p3 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
            auto&& value_p4 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
            return crate::prelude::take(crate::check::passes::borrows::ref_path_f(t_p3), Nat(1u)) != Array(std::vector{Text::lit("&_")})
                ? true
                : (crate::check::passes::borrows::ref_path_f(t_p3) == Array(std::vector{Text::lit("&_")})) && within_f(m_p1, i_p2, value_p4);
        }
        if (prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m)) {
            auto&& t_p5 = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
            return crate::prelude::take(crate::check::passes::borrows::ref_path_f(t_p5), Nat(1u)) != Array(std::vector{Text::lit("&_")});
        }
        {
            return true;
        }
    }
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotExpr>(std::get<0>(_m))) {
        return true;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> SpotKeepsWithin::cycle() const {
    const auto& spot0 = this->spot0;
    const auto& n1 = this->n1;
    return ({
        auto&& _m = std::tuple{spot0, n1};
        prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(std::get<0>(_m)) ? ({
        auto&& s_p0 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(std::get<0>(_m)).a0;
        auto&& m_p1 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(std::get<0>(_m)).a1;
        auto&& i_p2 = std::get<1>(_m);
        ({
        auto&& _m = prism_rtl::deref(s_p0).kind_p;
        prism_rtl::is<crate::syntax::StmtKind::SSet>(_m) ? ({
        auto&& t_p3 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
        auto&& value_p4 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
        ({
        auto i_p2x = i_p2;
        auto m_p1x = m_p1;
        auto t_p3x = t_p3;
        auto value_p4x = value_p4;
        (crate::prelude::call_then(crate::check::passes::borrows::start_ref_path_f(t_p3x), [=, i_p2x = std::move(i_p2x), m_p1x = std::move(m_p1x), value_p4x = std::move(value_p4x)](Array<Text> ref_path_f_3894) {
        return crate::prelude::take(ref_path_f_3894, Nat(1u)) != Array(std::vector{Text::lit("&_")})
            ? prism_rtl::finished(true)
            : crate::prelude::call_then(crate::check::passes::borrows::start_ref_path_f(t_p3x), [=](Array<Text> ref_path_f_3942) { return prism_rtl::finished((ref_path_f_3942 == Array(std::vector{Text::lit("&_")})) && within_f(m_p1x, i_p2x, value_p4x)); });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m) ? ({
        auto&& t_p5 = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
        ({
        auto t_p5x = t_p5;
        (crate::prelude::call_then(crate::check::passes::borrows::start_ref_path_f(t_p5x), [=](Array<Text> ref_path_f_4025) { return prism_rtl::finished(crate::prelude::take(ref_path_f_4025, Nat(1u)) != Array(std::vector{Text::lit("&_")})); }));
    });
    })
        : prism_rtl::finished(true);
    });
    })
        : prism_rtl::is<crate::check::shrink::walk::Spot::SpotExpr>(std::get<0>(_m)) ? prism_rtl::finished(true)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SpotKeepsWithin, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_spot_keeps_within_f(crate::check::shrink::walk::Spot spot0, Nat n1) {
    return prism_rtl::make_rc<SpotKeepsWithin>(spot0, n1);
}


/// WithinBlock: unbounded fn (Text ==> Rel), Nat, Block -> Bool
bool within_block_f(const Map<Text, crate::check::shrink::Rel>& m_p0, const Nat& i_p1, const crate::syntax::Block& b_p2) {
    return within_f(crate::check::shrink::relations::block_rels_f(b_p2.stmts_p, m_p0), i_p1, last_or_f(b_p2));
}


prism_rtl::Turn<bool> WithinBlock::cycle() const {
    const auto& m_p0 = this->m_p0;
    const auto& i_p1 = this->i_p1;
    const auto& b_p2 = this->b_p2;
    auto b_p2x = b_p2;
    auto i_p1x = i_p1;
    auto m_p0x = m_p0;
    return crate::prelude::call_then(crate::check::shrink::relations::start_block_rels_f(prism_rtl::deref(b_p2x).stmts_p, m_p0x), [=](Map<Text, crate::check::shrink::Rel> block_rels_f_4289) { return prism_rtl::more(prism_rtl::rc(Within(block_rels_f_4289, i_p1x, last_or_f(b_p2x)))); });
}


/// `Start WithinBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_within_block_f(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, crate::syntax::Block b_p2) {
    return prism_rtl::make_rc<WithinBlock>(m_p0, i_p1, b_p2);
}


/// StepWithin: unbounded fn (Text ==> Rel), Nat, Text, Expr, Expr, Nat, Expr -> Bool
bool step_within_f(const Map<Text, crate::check::shrink::Rel>& m_p0, const Nat& i_p1, const Text& f_p2, const crate::syntax::Expr& coll_p3, const crate::syntax::Expr& step_p4, const Nat& at_p5, const crate::syntax::Expr& z_p6) {
    return crate::check::shrink::relations::pre_is_f(m_p0, f_p2, Text::lit("Filter"))
        ? true
        : ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = prism_rtl::deref(step_p4.kind_p);
        if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0)) {
            auto&& ps_p7 = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0);
            auto&& body_p8 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
            _v.set(({
                auto sm_p9 = crate::check::shrink::relations::step_rels_f(m_p0, coll_p3, ps_p7, at_p5);
                auto [bm_pc, x_pd] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<Map<Text, crate::check::shrink::Rel>, crate::syntax::Expr>> _v;
                    auto&& _m = prism_rtl::deref(prism_rtl::deref(body_p8));
                    if (prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(_m)) {
                        auto&& y_pa = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(_m).a0;
                        _v.set(std::tuple{sm_p9, prism_rtl::deref(prism_rtl::deref(y_pa))});
                        goto _done;
                    }
                    if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(_m)) {
                        auto&& b_pb = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(_m).a0;
                        _v.set(std::tuple{crate::check::shrink::relations::block_rels_f(prism_rtl::deref(b_pb).stmts_p, sm_p9), last_or_f(b_pb)});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                (crate::check::shrink::relations::pre_is_f(m_p0, f_p2, Text::lit("Each"))
                ? part_f(bm_pc, i_p1, x_pd)
                : ({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = crate::prelude::index(ps_p7, Nat(0u));
                if (prism_rtl::is_some(_m)) {
                    auto&& acc_pe = prism_rtl::some_of(_m);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<bool> _v;
                        auto&& _m = prism_rtl::deref(prism_rtl::deref(acc_pe).kind_p);
                        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                            auto&& n_pf = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                            _v.set(within_f(m_p0, i_p1, z_p6) && builds_on_f(bm_pc, i_p1, crate::check::env::sname_key_f(n_pf), x_pd));
                            goto _done;
                        }
                        {
                            _v.set(false);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(false);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            }));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<bool> StepWithin::cycle() const {
    const auto& m_p0 = this->m_p0;
    const auto& i_p1 = this->i_p1;
    const auto& f_p2 = this->f_p2;
    const auto& coll_p3 = this->coll_p3;
    const auto& step_p4 = this->step_p4;
    const auto& at_p5 = this->at_p5;
    const auto& z_p6 = this->z_p6;
    return crate::check::shrink::relations::pre_is_f(m_p0, f_p2, Text::lit("Filter"))
        ? prism_rtl::finished(true)
        : ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(step_p4).kind_p);
        prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0) ? ({
        auto&& ps_p7 = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0);
        auto&& body_p8 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
        ({
        auto at_p5x = at_p5;
        auto body_p8x = prism_rtl::deref(prism_rtl::deref(body_p8));
        auto coll_p3x = coll_p3;
        auto f_p2x = f_p2;
        auto i_p1x = i_p1;
        auto m_p0x = m_p0;
        auto ps_p7x = ps_p7;
        auto z_p6x = z_p6;
        (crate::prelude::call_then(crate::check::shrink::relations::start_step_rels_f(m_p0x, coll_p3x, ps_p7x, at_p5x), [=, body_p8x = std::move(body_p8x), f_p2x = std::move(f_p2x), i_p1x = std::move(i_p1x), z_p6x = std::move(z_p6x)](Map<Text, crate::check::shrink::Rel> step_rels_f_4719) {
        return ({
            auto sm_p9 = step_rels_f_4719;
            auto [bm_pc, x_pd] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Map<Text, crate::check::shrink::Rel>, crate::syntax::Expr>> _v;
                if (prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(body_p8x)) {
                    auto&& y_pa = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(body_p8x).a0;
                    _v.set(std::tuple{sm_p9, prism_rtl::deref(prism_rtl::deref(y_pa))});
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(body_p8x)) {
                    auto&& b_pb = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(body_p8x).a0;
                    _v.set(std::tuple{crate::check::shrink::relations::block_rels_f(prism_rtl::deref(b_pb).stmts_p, sm_p9), last_or_f(b_pb)});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (crate::check::shrink::relations::pre_is_f(m_p0x, f_p2x, Text::lit("Each"))
            ? prism_rtl::more(prism_rtl::rc(Part(bm_pc, i_p1x, x_pd)))
            : ({
            auto&& _m = crate::prelude::index(ps_p7x, Nat(0u));
            prism_rtl::is_some(_m) ? ({
            auto&& acc_pe = prism_rtl::some_of(_m);
            ({
            auto&& _m = prism_rtl::deref(prism_rtl::deref(acc_pe).kind_p);
            prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
            auto&& n_pf = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            ({
            auto n_pfx = n_pf;
            (crate::prelude::call_then(start_within_f(m_p0x, i_p1x, z_p6x), [=, n_pfx = std::move(n_pfx)](bool within_f_5036) { return prism_rtl::finished(within_f_5036 && builds_on_f(bm_pc, i_p1x, crate::check::env::sname_key_f(n_pfx), x_pd)); }));
        });
        })
            : prism_rtl::finished(false);
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
            : throw prism_rtl::Panic("no arm matched");
        }));
        });
    }));
    });
    })
        : prism_rtl::finished(false);
    });
}


/// `Start StepWithin, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_step_within_f(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, Text f_p2, crate::syntax::Expr coll_p3, crate::syntax::Expr step_p4, Nat at_p5, crate::syntax::Expr z_p6) {
    return prism_rtl::make_rc<StepWithin>(m_p0, i_p1, f_p2, coll_p3, step_p4, at_p5, z_p6);
}


/// LastOr: fn Block -> Expr
crate::syntax::Expr last_or_f(const crate::syntax::Block& b_p0) {
    return crate::prelude::or_(crate::check::shrink::walk::last_expr_o(b_p0), prism_rtl::deref(dummy_arg_p()).value_p);
}


/// BuildsOn: unbounded fn (Text ==> Rel), Nat, Text, Expr -> Bool
bool builds_on_f(const Map<Text, crate::check::shrink::Rel>& m_p0, const Nat& i_p1, const Text& acc_p2, const crate::syntax::Expr& e_p3) {
    auto&& _m = prism_rtl::deref(e_p3.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p4 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return crate::check::env::sname_key_f(n_p4) == acc_p2;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p5 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return builds_on_f(m_p0, i_p1, acc_p2, prism_rtl::deref(prism_rtl::deref(x_p5)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
        auto&& s_p6 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms_p7 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        return crate::prelude::run_to_end(crate::prelude::fold_job(arms_p7, true, ({
            auto acc_p2x = acc_p2;
            auto s_p6x = prism_rtl::deref(prism_rtl::deref(s_p6));
            auto m_p0x = m_p0;
            auto i_p1x = i_p1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Arm>)>>(prism_rtl::rc([=, acc_p2x = std::move(acc_p2x), s_p6x = std::move(s_p6x), m_p0x = std::move(m_p0x), i_p1x = std::move(i_p1x)](std::tuple<bool, crate::syntax::Arm> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto acc_p2xy = acc_p2x;
                auto s_p6xy = s_p6x;
                auto m_p0xy = m_p0x;
                auto i_p1xy = i_p1x;
                (crate::prelude::entered(crate::prelude::once_job([=, acc_p2xy = std::move(acc_p2xy), s_p6xy = std::move(s_p6xy), m_p0xy = std::move(m_p0xy), i_p1xy = std::move(i_p1xy)]() {
                return ({
                    auto ok_p8 = p0;
                    auto a_p9 = p1;
                    (prism_rtl::finished((std::move(ok_p8) && (!crate::check::types::has_text_f(opt_names_f(prism_rtl::deref(a_p9).pattern_o), acc_p2xy))) && builds_on_block_f(crate::check::shrink::relations::arm_pat_rels_f(s_p6xy, a_p9, m_p0xy), i_p1xy, acc_p2xy, prism_rtl::deref(a_p9).body_p)));
                });
            })));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2)) {
        auto&& c_pa = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& t_pb = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& el_pc = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
        return ((!crate::check::types::has_text_f(cond_names_f(prism_rtl::deref(prism_rtl::deref(c_pa))), acc_p2)) && builds_on_block_f(crate::check::shrink::relations::cond_rels_f(prism_rtl::deref(prism_rtl::deref(c_pa)), m_p0), i_p1, acc_p2, t_pb)) && builds_on_block_f(m_p0, i_p1, acc_p2, el_pc);
    }
    {
        auto&& _m = crate::check::shrink::walk::call_of_o(e_p3);
        if (prism_rtl::is_some(_m)) {
            auto&& c_pd = std::get<0>(prism_rtl::some_of(_m));
            auto&& args_pe = std::get<1>(prism_rtl::some_of(_m));
            return builds_on_call_f(m_p0, i_p1, acc_p2, c_pd, args_pe);
        }
        if (prism_rtl::is_none(_m)) {
            return false;
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<bool> BuildsOn::cycle() const {
    const auto& m_p0 = this->m_p0;
    const auto& i_p1 = this->i_p1;
    const auto& acc_p2 = this->acc_p2;
    const auto& e_p3 = this->e_p3;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p3).kind_p);
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n_p4 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        prism_rtl::finished(crate::check::env::sname_key_f(n_p4) == acc_p2);
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x_p5 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(BuildsOn(m_p0, i_p1, acc_p2, prism_rtl::deref(prism_rtl::deref(x_p5)))));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
        auto&& s_p6 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms_p7 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        crate::prelude::fold_job(arms_p7, true, ({
        auto acc_p2x = acc_p2;
        auto s_p6x = prism_rtl::deref(prism_rtl::deref(s_p6));
        auto m_p0x = m_p0;
        auto i_p1x = i_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Arm>)>>(prism_rtl::rc([=, acc_p2x = std::move(acc_p2x), s_p6x = std::move(s_p6x), m_p0x = std::move(m_p0x), i_p1x = std::move(i_p1x)](std::tuple<bool, crate::syntax::Arm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto acc_p2xy = acc_p2x;
            auto s_p6xy = s_p6x;
            auto m_p0xy = m_p0x;
            auto i_p1xy = i_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, acc_p2xy = std::move(acc_p2xy), s_p6xy = std::move(s_p6xy), m_p0xy = std::move(m_p0xy), i_p1xy = std::move(i_p1xy)]() {
            return ({
                auto ok_p8 = p0;
                auto a_p9 = p1;
                (prism_rtl::finished((std::move(ok_p8) && (!crate::check::types::has_text_f(opt_names_f(prism_rtl::deref(a_p9).pattern_o), acc_p2xy))) && builds_on_block_f(crate::check::shrink::relations::arm_pat_rels_f(s_p6xy, a_p9, m_p0xy), i_p1xy, acc_p2xy, prism_rtl::deref(a_p9).body_p)));
            });
        })));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2) ? ({
        auto&& c_pa = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& t_pb = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& el_pc = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
        ({
        auto acc_p2x = acc_p2;
        auto c_pax = prism_rtl::deref(prism_rtl::deref(c_pa));
        auto el_pcx = el_pc;
        auto i_p1x = i_p1;
        auto m_p0x = m_p0;
        auto t_pbx = t_pb;
        (crate::prelude::call_then(start_cond_names_f(c_pax), [=, acc_p2x = std::move(acc_p2x), el_pcx = std::move(el_pcx), i_p1x = std::move(i_p1x), m_p0x = std::move(m_p0x), t_pbx = std::move(t_pbx)](Array<Text> cond_names_f_5750) { return prism_rtl::finished(((!crate::check::types::has_text_f(cond_names_f_5750, acc_p2x)) && builds_on_block_f(crate::check::shrink::relations::cond_rels_f(c_pax, m_p0x), i_p1x, acc_p2x, t_pbx)) && builds_on_block_f(m_p0x, i_p1x, acc_p2x, el_pcx)); }));
    });
    })
        : ({
        auto&& _m = crate::check::shrink::walk::call_of_o(e_p3);
        prism_rtl::is_some(_m) ? ({
        auto&& c_pd = std::get<0>(prism_rtl::some_of(_m));
        auto&& args_pe = std::get<1>(prism_rtl::some_of(_m));
        prism_rtl::more(prism_rtl::rc(BuildsOnCall(m_p0, i_p1, acc_p2, c_pd, args_pe)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
        : throw prism_rtl::Panic("no arm matched");
    });
    });
}


/// `Start BuildsOn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_builds_on_f(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, Text acc_p2, crate::syntax::Expr e_p3) {
    return prism_rtl::make_rc<BuildsOn>(m_p0, i_p1, acc_p2, e_p3);
}


/// BuildsOnCall: unbounded fn (Text ==> Rel), Nat, Text, Expr, [Arg] -> Bool
bool builds_on_call_f(const Map<Text, crate::check::shrink::Rel>& m_p0, const Nat& i_p1, const Text& acc_p2, const crate::syntax::Expr& c_p3, const Array<crate::syntax::Arg>& args_p4) {
    auto f_p5 = crate::check::shrink::locals::expr_name_f(c_p3);
    auto on_acc_p6 = builds_on_f(m_p0, i_p1, acc_p2, prism_rtl::deref(crate::prelude::or_(crate::prelude::index(args_p4, Nat(0u)), dummy_arg_p())).value_p);
    auto rest_p7 = crate::prelude::each(crate::prelude::drop(args_p4, Nat(1u)), [&](const crate::syntax::Arg& a_p9) { return prism_rtl::deref(a_p9).value_p; });
    auto parts_p8 = crate::prelude::run_to_end(crate::prelude::fold_job(rest_p7, true, ({
        auto m_p0x = m_p0;
        auto i_p1x = i_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Expr>)>>(prism_rtl::rc([=, m_p0x = std::move(m_p0x), i_p1x = std::move(i_p1x)](std::tuple<bool, crate::syntax::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_p0xy = m_p0x;
            auto i_p1xy = i_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, m_p0xy = std::move(m_p0xy), i_p1xy = std::move(i_p1xy)]() {
            return ({
                auto ok_pa = p0;
                auto x_pb = p1;
                (prism_rtl::finished(std::move(ok_pa) && part_f(m_p0xy, i_p1xy, x_pb)));
            });
        })));
        });
    })));
    })));
    return !std::move(on_acc_p6)
        ? false
        : crate::check::shrink::relations::pre_is_f(m_p0, f_p5, Text::lit("Push")) && (crate::prelude::len(rest_p7) == Nat(1u))
        ? std::move(parts_p8)
        : crate::check::shrink::relations::pre_is_f(m_p0, f_p5, Text::lit("Insert")) && (crate::prelude::len(rest_p7) == Nat(2u))
        ? std::move(parts_p8)
        : crate::check::shrink::relations::pre_is_f(m_p0, f_p5, Text::lit("Append")) && (crate::prelude::len(rest_p7) == Nat(1u))
        ? within_f(m_p0, i_p1, crate::prelude::or_(crate::prelude::index(rest_p7, Nat(0u)), prism_rtl::deref(dummy_arg_p()).value_p))
        : false;
}


prism_rtl::Turn<bool> BuildsOnCall::cycle() const {
    const auto& m_p0 = this->m_p0;
    const auto& i_p1 = this->i_p1;
    const auto& acc_p2 = this->acc_p2;
    const auto& c_p3 = this->c_p3;
    const auto& args_p4 = this->args_p4;
    auto f_p5 = crate::check::shrink::locals::expr_name_f(c_p3);
    auto acc_p2x = acc_p2;
    auto args_p4x = args_p4;
    auto i_p1x = i_p1;
    auto m_p0x = m_p0;
    return crate::prelude::call_then(start_builds_on_f(m_p0x, i_p1x, acc_p2x, prism_rtl::deref(crate::prelude::or_(crate::prelude::index(args_p4x, Nat(0u)), dummy_arg_p())).value_p), [=](bool builds_on_f_6180) {
        return ({
            auto on_acc_p6 = builds_on_f_6180;
            auto rest_p7 = crate::prelude::each(crate::prelude::drop(args_p4x, Nat(1u)), [&](const crate::syntax::Arg& a_p9) { return prism_rtl::deref(a_p9).value_p; });
            (crate::prelude::call_value(crate::prelude::fold_job(rest_p7, true, ({
            auto m_p0xx = m_p0x;
            auto i_p1xx = i_p1x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Expr>)>>(prism_rtl::rc([=, m_p0xx = std::move(m_p0xx), i_p1xx = std::move(i_p1xx)](std::tuple<bool, crate::syntax::Expr> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto m_p0xxy = m_p0xx;
                auto i_p1xxy = i_p1xx;
                (crate::prelude::entered(crate::prelude::once_job([=, m_p0xxy = std::move(m_p0xxy), i_p1xxy = std::move(i_p1xxy)]() {
                return ({
                    auto ok_pa = p0;
                    auto x_pb = p1;
                    (prism_rtl::finished(std::move(ok_pa) && part_f(m_p0xxy, i_p1xxy, x_pb)));
                });
            })));
            });
        })));
        })), [=, on_acc_p6 = std::move(on_acc_p6)](bool fold_6294) {
            return ({
                auto parts_p8 = fold_6294;
                !on_acc_p6
                ? prism_rtl::finished(false)
                : crate::check::shrink::relations::pre_is_f(m_p0x, f_p5, Text::lit("Push")) && (crate::prelude::len(rest_p7) == Nat(1u))
                ? prism_rtl::finished(std::move(parts_p8))
                : crate::check::shrink::relations::pre_is_f(m_p0x, f_p5, Text::lit("Insert")) && (crate::prelude::len(rest_p7) == Nat(2u))
                ? prism_rtl::finished(std::move(parts_p8))
                : crate::check::shrink::relations::pre_is_f(m_p0x, f_p5, Text::lit("Append")) && (crate::prelude::len(rest_p7) == Nat(1u))
                ? prism_rtl::more(prism_rtl::rc(Within(m_p0x, i_p1x, crate::prelude::or_(crate::prelude::index(rest_p7, Nat(0u)), prism_rtl::deref(dummy_arg_p()).value_p))))
                : prism_rtl::finished(false);
            });
        }));
        });
    });
}


/// `Start BuildsOnCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_builds_on_call_f(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, Text acc_p2, crate::syntax::Expr c_p3, Array<crate::syntax::Arg> args_p4) {
    return prism_rtl::make_rc<BuildsOnCall>(m_p0, i_p1, acc_p2, c_p3, args_p4);
}


/// BuildsOnBlock: unbounded fn (Text ==> Rel), Nat, Text, Block -> Bool
bool builds_on_block_f(const Map<Text, crate::check::shrink::Rel>& m_p0, const Nat& i_p1, const Text& acc_p2, const crate::syntax::Block& b_p3) {
    return (!crate::check::types::has_text_f(crate::check::shrink::relations::stmts_binders_f(b_p3.stmts_p), acc_p2)) && builds_on_f(crate::check::shrink::relations::block_rels_f(b_p3.stmts_p, m_p0), i_p1, acc_p2, last_or_f(b_p3));
}


prism_rtl::Turn<bool> BuildsOnBlock::cycle() const {
    const auto& m_p0 = this->m_p0;
    const auto& i_p1 = this->i_p1;
    const auto& acc_p2 = this->acc_p2;
    const auto& b_p3 = this->b_p3;
    auto acc_p2x = acc_p2;
    auto b_p3x = b_p3;
    auto i_p1x = i_p1;
    auto m_p0x = m_p0;
    return crate::prelude::call_then(crate::check::shrink::relations::start_stmts_binders_f(prism_rtl::deref(b_p3x).stmts_p), [=](Array<Text> stmts_binders_f_6854) { return prism_rtl::finished((!crate::check::types::has_text_f(stmts_binders_f_6854, acc_p2x)) && builds_on_f(crate::check::shrink::relations::block_rels_f(prism_rtl::deref(b_p3x).stmts_p, m_p0x), i_p1x, acc_p2x, last_or_f(b_p3x))); });
}


/// `Start BuildsOnBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_builds_on_block_f(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, Text acc_p2, crate::syntax::Block b_p3) {
    return prism_rtl::make_rc<BuildsOnBlock>(m_p0, i_p1, acc_p2, b_p3);
}


/// CondNames: unbounded fn Cond -> [Text]
Array<Text> cond_names_f(const crate::syntax::Cond& cond0) {
    if (prism_rtl::is<crate::syntax::Cond::CondBind>(cond0)) {
        auto&& p_p0 = prism_rtl::as<crate::syntax::Cond::CondBind>(cond0).a0;
        return crate::check::env::names::pattern_names_f(p_p0);
    }
    if (prism_rtl::is<crate::syntax::Cond::CondExpr>(cond0)) {
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> CondNames::cycle() const {
    const auto& cond0 = this->cond0;
    return ({
        prism_rtl::is<crate::syntax::Cond::CondBind>(cond0) ? ({
        auto&& p_p0 = prism_rtl::as<crate::syntax::Cond::CondBind>(cond0).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::env::names::PatternNames(p_p0)));
    })
        : prism_rtl::is<crate::syntax::Cond::CondExpr>(cond0) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CondNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_cond_names_f(crate::syntax::Cond cond0) {
    return prism_rtl::make_rc<CondNames>(cond0);
}


/// Part: unbounded fn (Text ==> Rel), Nat, Expr -> Bool
bool part_f(const Map<Text, crate::check::shrink::Rel>& m_p0, const Nat& i_p1, const crate::syntax::Expr& e_p2) {
    auto&& _m = prism_rtl::deref(e_p2.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m)) {
        auto&& es_p3 = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
        return crate::prelude::run_to_end(crate::prelude::fold_job(es_p3, true, ({
            auto m_p0x = m_p0;
            auto i_p1x = i_p1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Expr>)>>(prism_rtl::rc([=, m_p0x = std::move(m_p0x), i_p1x = std::move(i_p1x)](std::tuple<bool, crate::syntax::Expr> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto m_p0xy = m_p0x;
                auto i_p1xy = i_p1x;
                (crate::prelude::entered(crate::prelude::once_job([=, m_p0xy = std::move(m_p0xy), i_p1xy = std::move(i_p1xy)]() {
                return ({
                    auto ok_p4 = p0;
                    auto x_p5 = p1;
                    (prism_rtl::finished(std::move(ok_p4) && part_f(m_p0xy, i_p1xy, x_p5)));
                });
            })));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p6 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return part_f(m_p0, i_p1, prism_rtl::deref(prism_rtl::deref(x_p6)));
    }
    {
        auto&& _m = crate::check::shrink::walk::rel_of_o(m_p0, e_p2);
        if (prism_rtl::is_some(_m)) {
            auto&& r_p7 = prism_rtl::some_of(_m);
            return (prism_rtl::deref(r_p7).param_p == i_p1) && prism_rtl::deref(r_p7).strict_p;
        }
        if (prism_rtl::is_none(_m)) {
            return false;
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<bool> Part::cycle() const {
    const auto& m_p0 = this->m_p0;
    const auto& i_p1 = this->i_p1;
    const auto& e_p2 = this->e_p2;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p2).kind_p);
        prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m) ? ({
        auto&& es_p3 = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
        crate::prelude::fold_job(es_p3, true, ({
        auto m_p0x = m_p0;
        auto i_p1x = i_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Expr>)>>(prism_rtl::rc([=, m_p0x = std::move(m_p0x), i_p1x = std::move(i_p1x)](std::tuple<bool, crate::syntax::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_p0xy = m_p0x;
            auto i_p1xy = i_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, m_p0xy = std::move(m_p0xy), i_p1xy = std::move(i_p1xy)]() {
            return ({
                auto ok_p4 = p0;
                auto x_p5 = p1;
                (prism_rtl::finished(std::move(ok_p4) && part_f(m_p0xy, i_p1xy, x_p5)));
            });
        })));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x_p6 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(Part(m_p0, i_p1, prism_rtl::deref(prism_rtl::deref(x_p6)))));
    })
        : ({
        auto e_p2x = e_p2;
        auto i_p1x = i_p1;
        auto m_p0x = m_p0;
        (crate::prelude::call_then(crate::check::shrink::walk::start_rel_of_o(m_p0x, e_p2x), [=, i_p1x = std::move(i_p1x)](std::optional<crate::check::shrink::Rel> rel_of_o_7269) {
        return ({
            prism_rtl::is_some(rel_of_o_7269) ? ({
            auto&& r_p7 = prism_rtl::some_of(rel_of_o_7269);
            prism_rtl::finished((prism_rtl::deref(r_p7).param_p == i_p1x) && prism_rtl::deref(r_p7).strict_p);
        })
            : prism_rtl::is_none(rel_of_o_7269) ? prism_rtl::finished(false)
            : throw prism_rtl::Panic("no arm matched");
        });
    }));
    });
    });
}


/// `Start Part, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_part_f(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, crate::syntax::Expr e_p2) {
    return prism_rtl::make_rc<Part>(m_p0, i_p1, e_p2);
}


/// SummarySeeds: unbounded fn Shrink, Def, [Spot], (Text ==> Rel) -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> summary_seeds_f(const crate::check::shrink::Shrink& sk_p0, const crate::check::env::Def& d_p1, const Array<crate::check::shrink::walk::Spot>& spots_p2, const Map<Text, crate::check::shrink::Rel>& rels_p3) {
    return crate::prelude::fold(crate::prelude::run_to_end(crate::prelude::fold_job(spots_p2, Array<crate::check::shrink::walk::Site>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::walk::Site>>(std::tuple<Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=](std::tuple<Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_p4 = p0;
                auto sp_p5 = p1;
                (crate::prelude::call_then(crate::check::shrink::walk::start_spot_sites_f(sp_p5), [=, acc_p4 = std::move(acc_p4)](Array<crate::check::shrink::walk::Site> spot_sites_f_7945) { return prism_rtl::finished(crate::prelude::append(acc_p4, spot_sites_f_7945)); }));
            });
        }));
    })))), rels_p3, [&](const Map<Text, crate::check::shrink::Rel>& m_p6, const crate::check::shrink::walk::Site& site_p7) {
        return crate::check::shrink::relations::is_local_f(prism_rtl::deref(site_p7).rels_p, prism_rtl::deref(site_p7).callee_p)
            ? m_p6
            : ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, crate::check::shrink::Rel>> _v;
            auto&& _m = crate::check::shrink::locals::resolve_callee_o(sk_p0.g_p, d_p1.home_p, prism_rtl::deref(site_p7).callee_p);
            if (prism_rtl::is_some(_m)) {
                auto&& k_p8 = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Map<Text, crate::check::shrink::Rel>> _v;
                    auto&& _m = crate::prelude::get(sk_p0.sums_p, k_p8);
                    if (prism_rtl::is_some(_m)) {
                        auto&& i_p9 = prism_rtl::some_of(_m);
                        _v.set(crate::prelude::insert(m_p6, prism_rtl::cat("fn:", prism_rtl::deref(site_p7).callee_p), crate::check::shrink::Rel{.param_p = i_p9, .strict_p = false}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(crate::check::shrink::walk::is_no_larger_prelude_f(sk_p0.g_p, k_p8)
                            ? crate::prelude::insert(m_p6, prism_rtl::cat("fn:", prism_rtl::deref(site_p7).callee_p), crate::check::shrink::Rel{.param_p = Nat(0u), .strict_p = false})
                            : m_p6);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(m_p6);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> SummarySeeds::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& d_p1 = this->d_p1;
    const auto& spots_p2 = this->spots_p2;
    const auto& rels_p3 = this->rels_p3;
    auto d_p1x = d_p1;
    auto rels_p3x = rels_p3;
    auto sk_p0x = sk_p0;
    auto spots_p2x = spots_p2;
    return crate::prelude::call_value(crate::prelude::fold_job(spots_p2x, Array<crate::check::shrink::walk::Site>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::walk::Site>>(std::tuple<Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=](std::tuple<Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_p4 = p0;
                auto sp_p5 = p1;
                (crate::prelude::call_then(crate::check::shrink::walk::start_spot_sites_f(sp_p5), [=, acc_p4 = std::move(acc_p4)](Array<crate::check::shrink::walk::Site> spot_sites_f_7945) { return prism_rtl::finished(crate::prelude::append(acc_p4, spot_sites_f_7945)); }));
            });
        }));
    }))), [=](Array<crate::check::shrink::walk::Site> fold_7903) {
        return prism_rtl::finished(crate::prelude::fold(fold_7903, rels_p3x, [&](const Map<Text, crate::check::shrink::Rel>& m_p6, const crate::check::shrink::walk::Site& site_p7) {
            return crate::check::shrink::relations::is_local_f(prism_rtl::deref(site_p7).rels_p, prism_rtl::deref(site_p7).callee_p)
                ? m_p6
                : ({
                __label__ _done;
                prism_rtl::Slot<Map<Text, crate::check::shrink::Rel>> _v;
                auto&& _m = crate::check::shrink::locals::resolve_callee_o(prism_rtl::deref(sk_p0x).g_p, prism_rtl::deref(d_p1x).home_p, prism_rtl::deref(site_p7).callee_p);
                if (prism_rtl::is_some(_m)) {
                    auto&& k_p8 = prism_rtl::some_of(_m);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Map<Text, crate::check::shrink::Rel>> _v;
                        auto&& _m = crate::prelude::get(prism_rtl::deref(sk_p0x).sums_p, k_p8);
                        if (prism_rtl::is_some(_m)) {
                            auto&& i_p9 = prism_rtl::some_of(_m);
                            _v.set(crate::prelude::insert(m_p6, prism_rtl::cat("fn:", prism_rtl::deref(site_p7).callee_p), crate::check::shrink::Rel{.param_p = i_p9, .strict_p = false}));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(crate::check::shrink::walk::is_no_larger_prelude_f(prism_rtl::deref(sk_p0x).g_p, k_p8)
                                ? crate::prelude::insert(m_p6, prism_rtl::cat("fn:", prism_rtl::deref(site_p7).callee_p), crate::check::shrink::Rel{.param_p = Nat(0u), .strict_p = false})
                                : m_p6);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(m_p6);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        }));
    });
}


/// `Start SummarySeeds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_summary_seeds_f(crate::check::shrink::Shrink sk_p0, crate::check::env::Def d_p1, Array<crate::check::shrink::walk::Spot> spots_p2, Map<Text, crate::check::shrink::Rel> rels_p3) {
    return prism_rtl::make_rc<SummarySeeds>(sk_p0, d_p1, spots_p2, rels_p3);
}


/// OptNames: unbounded fn ?Pattern -> [Text]
Array<Text> opt_names_f(const std::optional<crate::syntax::Pattern_>& opt0) {
    if (prism_rtl::is_some(opt0)) {
        auto&& p_p0 = prism_rtl::some_of(opt0);
        return crate::check::env::names::pattern_names_f(p_p0);
    }
    if (prism_rtl::is_none(opt0)) {
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> OptNames::cycle() const {
    const auto& opt0 = this->opt0;
    return ({
        prism_rtl::is_some(opt0) ? ({
        auto&& p_p0 = prism_rtl::some_of(opt0);
        prism_rtl::more(prism_rtl::rc(crate::check::env::names::PatternNames(p_p0)));
    })
        : prism_rtl::is_none(opt0) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start OptNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_opt_names_f(std::optional<crate::syntax::Pattern_> opt0) {
    return prism_rtl::make_rc<OptNames>(opt0);
}


/// let dummyArg
crate::syntax::Arg dummy_arg_p() {
    return crate::syntax::Arg{.name_o = std::optional<crate::syntax::Ident>{}, .value_p = crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}}, .span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}};
}


/// ?DecrementOf: unbounded fn (Text ==> Rel), Expr -> ?Rel
std::optional<crate::check::shrink::Rel> decrement_of_o(const Map<Text, crate::check::shrink::Rel>& m_p0, const crate::syntax::Expr& e_p1) {
    auto&& _m = prism_rtl::deref(e_p1.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
        auto&& m8753_0_0 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& l_p2 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r_p3 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        if (m8753_0_0 == Text::lit("-?")) {
            return is_positive_lit_f(prism_rtl::deref(prism_rtl::deref(r_p3))) && is_nat_minus_f(m_p0, e_p1)
                ? smaller_o(m_p0, prism_rtl::deref(prism_rtl::deref(l_p2)))
                : std::optional<crate::check::shrink::Rel>{};
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p4 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return decrement_of_o(m_p0, prism_rtl::deref(prism_rtl::deref(x_p4)));
    }
    {
        auto&& _m = crate::check::shrink::walk::call_of_o(e_p1);
        if (prism_rtl::is_some(_m)) {
            auto&& c_p5 = std::get<0>(prism_rtl::some_of(_m));
            auto&& args_p6 = std::get<1>(prism_rtl::some_of(_m));
            auto&& _m = crate::check::shrink::walk::callee_name_o(c_p5);
            if (prism_rtl::is_some(_m)) {
                auto&& n_p7 = prism_rtl::some_of(_m);
                return crate::check::shrink::relations::pre_is_f(m_p0, n_p7, Text::lit("?Step"))
                    ? smaller_o(m_p0, prism_rtl::deref(crate::prelude::or_(crate::prelude::index(args_p6, Nat(0u)), dummy_arg_p())).value_p)
                    : std::optional<crate::check::shrink::Rel>{};
            }
            if (prism_rtl::is_none(_m)) {
                return std::optional<crate::check::shrink::Rel>{};
            }
            prism_rtl::unreachable("no arm matched");
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional<crate::check::shrink::Rel>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<std::optional<crate::check::shrink::Rel>> DecrementOf::cycle() const {
    const auto& m_p0 = this->m_p0;
    const auto& e_p1 = this->e_p1;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p1).kind_p);
        prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m) && ({
        auto&& m8753_0_0 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& l_p2 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r_p3 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        (m8753_0_0 == Text::lit("-?"));
    }) ? ({
        auto&& m8753_0_0 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& l_p2 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r_p3 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        is_positive_lit_f(prism_rtl::deref(prism_rtl::deref(r_p3))) && is_nat_minus_f(m_p0, e_p1)
        ? prism_rtl::finished(smaller_o(m_p0, prism_rtl::deref(prism_rtl::deref(l_p2))))
        : prism_rtl::finished(std::optional<crate::check::shrink::Rel>{});
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x_p4 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(DecrementOf(m_p0, prism_rtl::deref(prism_rtl::deref(x_p4)))));
    })
        : ({
        auto&& _m = crate::check::shrink::walk::call_of_o(e_p1);
        prism_rtl::is_some(_m) ? ({
        auto&& c_p5 = std::get<0>(prism_rtl::some_of(_m));
        auto&& args_p6 = std::get<1>(prism_rtl::some_of(_m));
        ({
        auto&& _m = crate::check::shrink::walk::callee_name_o(c_p5);
        prism_rtl::is_some(_m) ? ({
        auto&& n_p7 = prism_rtl::some_of(_m);
        crate::check::shrink::relations::pre_is_f(m_p0, n_p7, Text::lit("?Step"))
        ? prism_rtl::finished(smaller_o(m_p0, prism_rtl::deref(crate::prelude::or_(crate::prelude::index(args_p6, Nat(0u)), dummy_arg_p())).value_p))
        : prism_rtl::finished(std::optional<crate::check::shrink::Rel>{});
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    });
}


/// `Start DecrementOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<crate::check::shrink::Rel>> start_decrement_of_o(Map<Text, crate::check::shrink::Rel> m_p0, crate::syntax::Expr e_p1) {
    return prism_rtl::make_rc<DecrementOf>(m_p0, e_p1);
}


/// IsNatMinus: fn (Text ==> Rel), Expr -> Bool
bool is_nat_minus_f(const Map<Text, crate::check::shrink::Rel>& m_p0, const crate::syntax::Expr& e_p1) {
    return crate::check::shrink::relations::pre_is_f(m_p0, Text::lit("-?"), Text::lit("-?")) && crate::check::shrink::walk::is_nat_at_f(m_p0, e_p1);
}


/// ?Smaller: unbounded fn (Text ==> Rel), Expr -> ?Rel
std::optional<crate::check::shrink::Rel> smaller_o(const Map<Text, crate::check::shrink::Rel>& m_p0, const crate::syntax::Expr& x_p1) {
    auto&& _m = crate::check::shrink::walk::rel_of_o(m_p0, x_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& r_p2 = prism_rtl::some_of(_m);
        return std::optional(crate::check::shrink::Rel{.param_p = prism_rtl::deref(r_p2).param_p, .strict_p = true});
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<crate::check::shrink::Rel>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// IsPositiveLit: fn Expr -> Bool
bool is_positive_lit_f(const crate::syntax::Expr& e_p0) {
    auto&& _m = prism_rtl::deref(e_p0.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::ELit>(_m)) {
        auto&& l_p1 = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
        auto&& _m = prism_rtl::deref(l_p1).kind_p;
        if (prism_rtl::is<crate::syntax::LitKind::LInt>(_m)) {
            auto&& d_p2 = prism_rtl::as<crate::syntax::LitKind::LInt>(_m).a0;
            return d_p2 != Text::lit("0");
        }
        {
            return false;
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p3 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return is_positive_lit_f(prism_rtl::deref(prism_rtl::deref(x_p3)));
    }
    {
        return false;
    }
}


/// Closure: unbounded fn [Sc] -> [Sc]
Array<crate::check::shrink::Sc> closure_f(const Array<crate::check::shrink::Sc>& graphs_p0) {
    return closure_from_f(graphs_p0, dedup_f(graphs_p0), dedup_f(graphs_p0));
}


prism_rtl::Turn<Array<crate::check::shrink::Sc>> Closure::cycle() const {
    const auto& graphs_p0 = this->graphs_p0;
    return prism_rtl::more(prism_rtl::rc(ClosureFrom(graphs_p0, dedup_f(graphs_p0), dedup_f(graphs_p0))));
}


/// `Start Closure, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::check::shrink::Sc>> start_closure_f(Array<crate::check::shrink::Sc> graphs_p0) {
    return prism_rtl::make_rc<Closure>(graphs_p0);
}


/// Dedup: fn [Sc] -> [Sc]
Array<crate::check::shrink::Sc> dedup_f(const Array<crate::check::shrink::Sc>& gs_p0) {
    return crate::prelude::fold(gs_p0, Array<crate::check::shrink::Sc>{}, [&](const Array<crate::check::shrink::Sc>& acc_p1, const crate::check::shrink::Sc& g_p2) { return has_sc_f(acc_p1, g_p2) ? acc_p1 : crate::prelude::push(acc_p1, g_p2); });
}


/// ClosureFrom: unbounded fn [Sc], [Sc], [Sc] -> [Sc]
Array<crate::check::shrink::Sc> closure_from_f(const Array<crate::check::shrink::Sc>& base_p0, const Array<crate::check::shrink::Sc>& acc_p1, const Array<crate::check::shrink::Sc>& frontier_p2) {
    auto fresh_p3 = crate::prelude::fold(frontier_p2, Array<crate::check::shrink::Sc>{}, [&](const Array<crate::check::shrink::Sc>& out_p4, const crate::check::shrink::Sc& a_p5) { return crate::prelude::fold(base_p0, out_p4, [&](const Array<crate::check::shrink::Sc>& out2_p6, const crate::check::shrink::Sc& b_p7) { return add_composed_f(acc_p1, out2_p6, a_p5, b_p7); }); });
    return crate::prelude::len(fresh_p3) == Nat(0u)
        ? acc_p1
        : closure_from_f(base_p0, crate::prelude::append(acc_p1, fresh_p3), fresh_p3);
}


prism_rtl::Turn<Array<crate::check::shrink::Sc>> ClosureFrom::cycle() const {
    const auto& base_p0 = this->base_p0;
    const auto& acc_p1 = this->acc_p1;
    const auto& frontier_p2 = this->frontier_p2;
    auto fresh_p3 = crate::prelude::fold(frontier_p2, Array<crate::check::shrink::Sc>{}, [&](const Array<crate::check::shrink::Sc>& out_p4, const crate::check::shrink::Sc& a_p5) { return crate::prelude::fold(base_p0, out_p4, [&](const Array<crate::check::shrink::Sc>& out2_p6, const crate::check::shrink::Sc& b_p7) { return add_composed_f(acc_p1, out2_p6, a_p5, b_p7); }); });
    return crate::prelude::len(fresh_p3) == Nat(0u)
        ? prism_rtl::finished(acc_p1)
        : prism_rtl::more(prism_rtl::rc(ClosureFrom(base_p0, crate::prelude::append(acc_p1, fresh_p3), fresh_p3)));
}


/// `Start ClosureFrom, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::check::shrink::Sc>> start_closure_from_f(Array<crate::check::shrink::Sc> base_p0, Array<crate::check::shrink::Sc> acc_p1, Array<crate::check::shrink::Sc> frontier_p2) {
    return prism_rtl::make_rc<ClosureFrom>(base_p0, acc_p1, frontier_p2);
}


/// AddComposed: fn [Sc], [Sc], Sc, Sc -> [Sc]
Array<crate::check::shrink::Sc> add_composed_f(const Array<crate::check::shrink::Sc>& acc_p0, const Array<crate::check::shrink::Sc>& out_p1, const crate::check::shrink::Sc& a_p2, const crate::check::shrink::Sc& b_p3) {
    return a_p2.callee_p != b_p3.caller_p
        ? out_p1
        : ({
        auto c_p4 = compose_f(a_p2, b_p3);
        has_sc_f(acc_p0, c_p4) || has_sc_f(out_p1, c_p4)
        ? out_p1
        : crate::prelude::push(out_p1, c_p4);
    });
}


/// HasSc: fn [Sc], Sc -> Bool
bool has_sc_f(const Array<crate::check::shrink::Sc>& xs_p0, const crate::check::shrink::Sc& c_p1) {
    return crate::prelude::fold(xs_p0, false, [&](const bool& seen_p2, const crate::check::shrink::Sc& x_p3) { return prism_rtl::deref(seen_p2) || (((prism_rtl::deref(x_p3).caller_p == c_p1.caller_p) && (prism_rtl::deref(x_p3).callee_p == c_p1.callee_p)) && (prism_rtl::deref(x_p3).edges_p == c_p1.edges_p)); });
}


/// Compose: fn Sc, Sc -> Sc
crate::check::shrink::Sc compose_f(const crate::check::shrink::Sc& a_p0, const crate::check::shrink::Sc& b_p1) {
    auto pairs_p2 = crate::prelude::fold(a_p0.edges_p, Array<std::tuple<Nat, Nat, bool>>{}, [&](const Array<std::tuple<Nat, Nat, bool>>& acc_p3, const std::tuple<Nat, Nat, bool>& _p1) {
        auto&& x_p4 = std::get<0>(_p1);
        auto&& y_p5 = std::get<1>(_p1);
        auto&& s1_p6 = std::get<2>(_p1);
        return crate::prelude::fold(b_p1.edges_p, acc_p3, [&](const Array<std::tuple<Nat, Nat, bool>>& acc2_p7, const std::tuple<Nat, Nat, bool>& _p1) {
            auto&& y2_p8 = std::get<0>(_p1);
            auto&& z_p9 = std::get<1>(_p1);
            auto&& s2_pa = std::get<2>(_p1);
            return y_p5 == y2_p8
                ? add_edge_f(acc2_p7, x_p4, z_p9, prism_rtl::deref(s1_p6) || prism_rtl::deref(s2_pa))
                : acc2_p7;
        });
    });
    return crate::check::shrink::Sc{.caller_p = a_p0.caller_p, .callee_p = b_p1.callee_p, .edges_p = sort_edges_f(pairs_p2), .span_p = a_p0.span_p, .file_p = a_p0.file_p, .arg_p = a_p0.arg_p};
}


/// AddEdge: fn [((Nat, Nat, Bool))], Nat, Nat, Bool -> [((Nat, Nat, Bool))]
Array<std::tuple<Nat, Nat, bool>> add_edge_f(const Array<std::tuple<Nat, Nat, bool>>& es_p0, const Nat& x_p1, const Nat& z_p2, const bool& s_p3) {
    auto others_p4 = crate::prelude::filter(es_p0, [&](const std::tuple<Nat, Nat, bool>& _p0) {
        auto&& a_p6 = std::get<0>(_p0);
        auto&& b_p7 = std::get<1>(_p0);
        return !((a_p6 == x_p1) && (b_p7 == z_p2));
    });
    auto had_p5 = crate::prelude::fold(es_p0, false, [&](const bool& seen_p8, const std::tuple<Nat, Nat, bool>& _p1) {
        auto&& a_p9 = std::get<0>(_p1);
        auto&& b_pa = std::get<1>(_p1);
        auto&& t_pb = std::get<2>(_p1);
        return prism_rtl::deref(seen_p8) || (((a_p9 == x_p1) && (b_pa == z_p2)) && prism_rtl::deref(t_pb));
    });
    return crate::prelude::push(others_p4, std::tuple{x_p1, z_p2, s_p3 || std::move(had_p5)});
}


/// SortEdges: fn [((Nat, Nat, Bool))] -> [((Nat, Nat, Bool))]
Array<std::tuple<Nat, Nat, bool>> sort_edges_f(const Array<std::tuple<Nat, Nat, bool>>& es_p0) {
    return crate::prelude::fold(es_p0, Array<std::tuple<Nat, Nat, bool>>{}, [&](const Array<std::tuple<Nat, Nat, bool>>& acc_p1, const std::tuple<Nat, Nat, bool>& e_p2) { return crate::prelude::append(crate::prelude::push(crate::prelude::filter(acc_p1, [&](const std::tuple<Nat, Nat, bool>& x_p3) { return edge_before_f(x_p3, e_p2); }), e_p2), crate::prelude::filter(acc_p1, [&](const std::tuple<Nat, Nat, bool>& x_p4) { return !edge_before_f(x_p4, e_p2); })); });
}


/// EdgeBefore: fn ((Nat, Nat, Bool)), ((Nat, Nat, Bool)) -> Bool
bool edge_before_f(const std::tuple<Nat, Nat, bool>& arg0, const std::tuple<Nat, Nat, bool>& arg1) {
    auto&& _m = std::tuple{arg0, arg1};
    {
        auto&& a1_p0 = std::get<0>(std::get<0>(_m));
        auto&& b1_p1 = std::get<1>(std::get<0>(_m));
        auto&& a2_p2 = std::get<0>(std::get<1>(_m));
        auto&& b2_p3 = std::get<1>(std::get<1>(_m));
        return (a1_p0 < a2_p2) || ((a1_p0 == a2_p2) && (b1_p1 < b2_p3));
    }
    prism_rtl::unreachable("no arm matched");
}


/// LoopsOf: unbounded fn Shrink, St, Def -> St
crate::check::types::St loops_of_f(const crate::check::shrink::Shrink& sk_p0, const crate::check::types::St& st_p1, const crate::check::env::Def& d_p2) {
    auto unb_p3 = crate::check::shrink::types::is_unbounded_key_f(sk_p0.g_p, crate::check::shrink::types::sig_key_of_f(sk_p0, d_p2.qk_p));
    return std::move(unb_p3) && (!st_p1.recording_p)
        ? st_p1
        : ({
        auto s0_p4 = ({
            crate::check::types::St this_ = st_p1;
            this_.file_p = d_p2.file_p;
            (std::move(this_));
        });
        auto s1_p5 = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::shrink::types::def_clauses_f(d_p2), s0_p4, ({
            auto sk_p0x = sk_p0;
            auto d_p2x = d_p2;
            auto unb_p3x = std::move(unb_p3);
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, sk_p0x = std::move(sk_p0x), d_p2x = std::move(d_p2x), unb_p3x = std::move(unb_p3x)](std::tuple<crate::check::types::St, crate::syntax::decls::FnClause> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto sk_p0xy = sk_p0x;
                auto d_p2xy = d_p2x;
                auto unb_p3xy = unb_p3x;
                (crate::prelude::entered(crate::prelude::once_job([=, sk_p0xy = std::move(sk_p0xy), d_p2xy = std::move(d_p2xy), unb_p3xy = std::move(unb_p3xy)]() {
                return ({
                    auto s_p6 = p0;
                    auto c_p7 = p1;
                    (prism_rtl::more(prism_rtl::rc(ClauseLoops(sk_p0xy, s_p6, d_p2xy, c_p7, unb_p3xy))));
                });
            })));
            });
        })));
        })));
        ({
        crate::check::types::St this_ = s1_p5;
        this_.file_p = st_p1.file_p;
        (std::move(this_));
    });
    });
}


prism_rtl::Turn<crate::check::types::St> LoopsOf::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& st_p1 = this->st_p1;
    const auto& d_p2 = this->d_p2;
    auto unb_p3 = crate::check::shrink::types::is_unbounded_key_f(prism_rtl::deref(sk_p0).g_p, crate::check::shrink::types::sig_key_of_f(sk_p0, prism_rtl::deref(d_p2).qk_p));
    return std::move(unb_p3) && (!prism_rtl::deref(st_p1).recording_p)
        ? prism_rtl::finished(st_p1)
        : ({
        auto s0_p4 = ({
            crate::check::types::St this_ = st_p1;
            this_.file_p = prism_rtl::deref(d_p2).file_p;
            (std::move(this_));
        });
        auto d_p2x = d_p2;
        auto sk_p0x = sk_p0;
        auto st_p1x = st_p1;
        (crate::prelude::call_value(crate::prelude::fold_job(crate::check::shrink::types::def_clauses_f(d_p2x), s0_p4, ({
        auto sk_p0xx = sk_p0x;
        auto d_p2xx = d_p2x;
        auto unb_p3x = std::move(unb_p3);
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, sk_p0xx = std::move(sk_p0xx), d_p2xx = std::move(d_p2xx), unb_p3x = std::move(unb_p3x)](std::tuple<crate::check::types::St, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_p0xxy = sk_p0xx;
            auto d_p2xxy = d_p2xx;
            auto unb_p3xy = unb_p3x;
            (crate::prelude::entered(crate::prelude::once_job([=, sk_p0xxy = std::move(sk_p0xxy), d_p2xxy = std::move(d_p2xxy), unb_p3xy = std::move(unb_p3xy)]() {
            return ({
                auto s_p6 = p0;
                auto c_p7 = p1;
                (prism_rtl::more(prism_rtl::rc(ClauseLoops(sk_p0xxy, s_p6, d_p2xxy, c_p7, unb_p3xy))));
            });
        })));
        });
    })));
    })), [=, st_p1x = std::move(st_p1x)](crate::check::types::St fold_12724) {
        return ({
            auto s1_p5 = fold_12724;
            (prism_rtl::finished(({
            crate::check::types::St this_ = s1_p5;
            this_.file_p = prism_rtl::deref(st_p1x).file_p;
            (std::move(this_));
        })));
        });
    }));
    });
}


/// `Start LoopsOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_loops_of_f(crate::check::shrink::Shrink sk_p0, crate::check::types::St st_p1, crate::check::env::Def d_p2) {
    return prism_rtl::make_rc<LoopsOf>(sk_p0, st_p1, d_p2);
}


/// ClauseLoops: unbounded fn Shrink, St, Def, FnClause, Bool -> St
crate::check::types::St clause_loops_f(const crate::check::shrink::Shrink& sk_p0, const crate::check::types::St& st_p1, const crate::check::env::Def& d_p2, const crate::syntax::decls::FnClause& c_p3, const bool& unb_p4) {
    auto base_p5 = crate::check::shrink::locals::clause_base_f(sk_p0, d_p2, c_p3);
    auto spots0_p6 = crate::check::shrink::walk::body_spots_f(c_p3.body_p, base_p5);
    return !crate::prelude::fold(spots0_p6, false, [&](const bool& seen_p7, const crate::check::shrink::walk::Spot& sp_p8) { return prism_rtl::deref(seen_p7) || is_while_spot_f(sp_p8); })
        ? st_p1
        : ({
        auto spots_p9 = crate::check::shrink::walk::body_spots_f(c_p3.body_p, summary_seeds_f(sk_p0, d_p2, spots0_p6, base_p5));
        (crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::filter(spots_p9, [&](const crate::check::shrink::walk::Spot& sp_pa) { return is_while_spot_f(sp_pa); }), st_p1, ({
        auto d_p2x = d_p2;
        auto unb_p4x = unb_p4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=, d_p2x = std::move(d_p2x), unb_p4x = std::move(unb_p4x)](std::tuple<crate::check::types::St, crate::check::shrink::walk::Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto d_p2xy = d_p2x;
            auto unb_p4xy = unb_p4x;
            (crate::prelude::entered(crate::prelude::once_job([=, d_p2xy = std::move(d_p2xy), unb_p4xy = std::move(unb_p4xy)]() {
            return ({
                auto s_pb = p0;
                auto sp_pc = p1;
                ({
                prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(sp_pc) ? ({
                auto&& w_pd = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(sp_pc).a0;
                auto&& m_pe = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(sp_pc).a1;
                ({
                auto&& _m = prism_rtl::deref(w_pd).kind_p;
                prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m) ? ({
                auto&& cond_pf = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
                auto&& body_pg = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
                prism_rtl::more(prism_rtl::rc(CheckWhile(s_pb, cond_pf, body_pg, prism_rtl::deref(w_pd).span_p, prism_rtl::deref(d_p2xy).name_p, marks_f(m_pe), unb_p4xy)));
            })
                : prism_rtl::finished(s_pb);
            });
            })
                : prism_rtl::finished(s_pb);
            });
            });
        })));
        });
    })));
    }))));
    });
}


prism_rtl::Turn<crate::check::types::St> ClauseLoops::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& st_p1 = this->st_p1;
    const auto& d_p2 = this->d_p2;
    const auto& c_p3 = this->c_p3;
    const auto& unb_p4 = this->unb_p4;
    auto c_p3x = c_p3;
    auto d_p2x = d_p2;
    auto sk_p0x = sk_p0;
    auto st_p1x = st_p1;
    auto unb_p4x = prism_rtl::deref(unb_p4);
    return crate::prelude::call_then(crate::check::shrink::locals::start_clause_base_f(sk_p0x, d_p2x, c_p3x), [=](Map<Text, crate::check::shrink::Rel> clause_base_f_12950) {
        return ({
            auto base_p5 = clause_base_f_12950;
            (crate::prelude::call_then(crate::check::shrink::walk::start_body_spots_f(prism_rtl::deref(c_p3x).body_p, base_p5), [=](Array<crate::check::shrink::walk::Spot> body_spots_f_12987) {
            return ({
                auto spots0_p6 = body_spots_f_12987;
                (!crate::prelude::fold(spots0_p6, false, [&](const bool& seen_p7, const crate::check::shrink::walk::Spot& sp_p8) { return prism_rtl::deref(seen_p7) || is_while_spot_f(sp_p8); })
                ? prism_rtl::finished(st_p1x)
                : crate::prelude::call_then(start_summary_seeds_f(sk_p0x, d_p2x, spots0_p6, base_p5), [=](Map<Text, crate::check::shrink::Rel> summary_seeds_f_13131) {
                return crate::prelude::call_then(crate::check::shrink::walk::start_body_spots_f(prism_rtl::deref(c_p3x).body_p, summary_seeds_f_13131), [=](Array<crate::check::shrink::walk::Spot> body_spots_f_13112) {
                    return ({
                        auto spots_p9 = body_spots_f_13112;
                        (crate::prelude::fold_job(crate::prelude::filter(spots_p9, [&](const crate::check::shrink::walk::Spot& sp_pa) { return is_while_spot_f(sp_pa); }), st_p1x, ({
                        auto d_p2xx = d_p2x;
                        auto unb_p4xx = unb_p4x;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=, d_p2xx = std::move(d_p2xx), unb_p4xx = std::move(unb_p4xx)](std::tuple<crate::check::types::St, crate::check::shrink::walk::Spot> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto d_p2xxy = d_p2xx;
                            auto unb_p4xxy = unb_p4xx;
                            (crate::prelude::entered(crate::prelude::once_job([=, d_p2xxy = std::move(d_p2xxy), unb_p4xxy = std::move(unb_p4xxy)]() {
                            return ({
                                auto s_pb = p0;
                                auto sp_pc = p1;
                                ({
                                prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(sp_pc) ? ({
                                auto&& w_pd = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(sp_pc).a0;
                                auto&& m_pe = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(sp_pc).a1;
                                ({
                                auto&& _m = prism_rtl::deref(w_pd).kind_p;
                                prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m) ? ({
                                auto&& cond_pf = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
                                auto&& body_pg = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
                                prism_rtl::more(prism_rtl::rc(CheckWhile(s_pb, cond_pf, body_pg, prism_rtl::deref(w_pd).span_p, prism_rtl::deref(d_p2xxy).name_p, marks_f(m_pe), unb_p4xxy)));
                            })
                                : prism_rtl::finished(s_pb);
                            });
                            })
                                : prism_rtl::finished(s_pb);
                            });
                            });
                        })));
                        });
                    })));
                    }))->cycle());
                    });
                });
            }));
            });
        }));
        });
    });
}


/// `Start ClauseLoops, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_clause_loops_f(crate::check::shrink::Shrink sk_p0, crate::check::types::St st_p1, crate::check::env::Def d_p2, crate::syntax::decls::FnClause c_p3, bool unb_p4) {
    return prism_rtl::make_rc<ClauseLoops>(sk_p0, st_p1, d_p2, c_p3, unb_p4);
}


/// Marks: fn (Text ==> Rel) -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> marks_f(const Map<Text, crate::check::shrink::Rel>& m_p0) {
    return crate::prelude::fold(crate::prelude::keys(m_p0), m_p0, [&](const Map<Text, crate::check::shrink::Rel>& m2_p1, const Text& k_p2) {
        return crate::syntax::lexer::chars::contains_f(k_p2, Text::lit(":"))
            ? m2_p1
            : crate::prelude::remove(m2_p1, k_p2);
    });
}


/// IsWhileSpot: fn Spot -> Bool
bool is_while_spot_f(const crate::check::shrink::walk::Spot& spot0) {
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(spot0)) {
        auto&& s_p0 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(spot0).a0;
        auto&& _m = prism_rtl::deref(s_p0).kind_p;
        if (prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m)) {
            return true;
        }
        {
            return false;
        }
    }
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotExpr>(spot0)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// CheckWhile: unbounded fn St, Cond, Block, Range, Text, (Text ==> Rel), Bool -> St
crate::check::types::St check_while_f(const crate::check::types::St& st_p0, const crate::syntax::Cond& c_p1, const crate::syntax::Block& body_p2, const crate::syntax::Range& span_p3, const Text& name_p4, const Map<Text, crate::check::shrink::Rel>& seeds_p5, const bool& unb_p6) {
    auto vars_p7 = set_targets_f(body_p2.stmts_p);
    auto base_p8 = crate::prelude::fold(crate::check::errors::range0_f(crate::prelude::len(vars_p7)), seeds_p5, [&](const Map<Text, crate::check::shrink::Rel>& m_pb, const Nat& i_pc) { return crate::prelude::insert(m_pb, crate::prelude::or_(crate::prelude::index(vars_p7, i_pc), Text::lit("")), crate::check::shrink::Rel{.param_p = i_pc, .strict_p = false}); });
    auto rels_p9 = crate::check::shrink::relations::cond_rels_f(c_p1, base_p8);
    auto ok_pa = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(vars_p7)), false, ({
        auto body_p2x = body_p2;
        auto vars_p7x = vars_p7;
        auto rels_p9x = rels_p9;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Nat>)>>(prism_rtl::rc([=, body_p2x = std::move(body_p2x), vars_p7x = std::move(vars_p7x), rels_p9x = std::move(rels_p9x)](std::tuple<bool, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto body_p2xy = body_p2x;
            auto vars_p7xy = vars_p7x;
            auto rels_p9xy = rels_p9x;
            (crate::prelude::entered(crate::prelude::once_job([=, body_p2xy = std::move(body_p2xy), vars_p7xy = std::move(vars_p7xy), rels_p9xy = std::move(rels_p9xy)]() {
            return ({
                auto seen_pd = p0;
                auto i_pe = p1;
                (prism_rtl::finished(std::move(seen_pd) || all_paths_strict_f(prism_rtl::deref(body_p2xy).stmts_p, crate::prelude::or_(crate::prelude::index(vars_p7xy, i_pe), Text::lit("")), i_pe, rels_p9xy)));
            });
        })));
        });
    })));
    })));
    return std::move(ok_pa)
        ? st_p0
        : unb_p6
        ? note_unshrunk_f(st_p0, span_p3)
        : crate::check::types::recording::err_fix_f(st_p0, Text::lit("may-not-end"), span_p3, prism_rtl::cat("this loop in `", name_p4, "` may not end: nothing it sets gets smaller on every turn"), prism_rtl::cat("set a local from `&x -? 1` through a pattern, as `while ? left <- &fuel -? 1:`, or mark `", name_p4, "` `unbounded fn`"));
}


prism_rtl::Turn<crate::check::types::St> CheckWhile::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& c_p1 = this->c_p1;
    const auto& body_p2 = this->body_p2;
    const auto& span_p3 = this->span_p3;
    const auto& name_p4 = this->name_p4;
    const auto& seeds_p5 = this->seeds_p5;
    const auto& unb_p6 = this->unb_p6;
    auto body_p2x = body_p2;
    auto c_p1x = c_p1;
    auto name_p4x = name_p4;
    auto seeds_p5x = seeds_p5;
    auto span_p3x = span_p3;
    auto st_p0x = st_p0;
    auto unb_p6x = prism_rtl::deref(unb_p6);
    return crate::prelude::call_then(start_set_targets_f(prism_rtl::deref(body_p2x).stmts_p), [=](Array<Text> set_targets_f_14238) {
        return ({
            auto vars_p7 = set_targets_f_14238;
            auto base_p8 = crate::prelude::fold(crate::check::errors::range0_f(crate::prelude::len(vars_p7)), seeds_p5x, [&](const Map<Text, crate::check::shrink::Rel>& m_pb, const Nat& i_pc) { return crate::prelude::insert(m_pb, crate::prelude::or_(crate::prelude::index(vars_p7, i_pc), Text::lit("")), crate::check::shrink::Rel{.param_p = i_pc, .strict_p = false}); });
            (crate::prelude::call_then(crate::check::shrink::relations::start_cond_rels_f(c_p1x, base_p8), [=, vars_p7 = std::move(vars_p7)](Map<Text, crate::check::shrink::Rel> cond_rels_f_14552) {
            return ({
                auto rels_p9 = cond_rels_f_14552;
                (crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(vars_p7)), false, ({
                auto body_p2xx = body_p2x;
                auto vars_p7x = vars_p7;
                auto rels_p9x = rels_p9;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Nat>)>>(prism_rtl::rc([=, body_p2xx = std::move(body_p2xx), vars_p7x = std::move(vars_p7x), rels_p9x = std::move(rels_p9x)](std::tuple<bool, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto body_p2xxy = body_p2xx;
                    auto vars_p7xy = vars_p7x;
                    auto rels_p9xy = rels_p9x;
                    (crate::prelude::entered(crate::prelude::once_job([=, body_p2xxy = std::move(body_p2xxy), vars_p7xy = std::move(vars_p7xy), rels_p9xy = std::move(rels_p9xy)]() {
                    return ({
                        auto seen_pd = p0;
                        auto i_pe = p1;
                        (prism_rtl::finished(std::move(seen_pd) || all_paths_strict_f(prism_rtl::deref(body_p2xxy).stmts_p, crate::prelude::or_(crate::prelude::index(vars_p7xy, i_pe), Text::lit("")), i_pe, rels_p9xy)));
                    });
                })));
                });
            })));
            })), [=](bool fold_14582) {
                return ({
                    auto ok_pa = fold_14582;
                    (std::move(ok_pa)
                    ? prism_rtl::finished(st_p0x)
                    : unb_p6x
                    ? prism_rtl::finished(note_unshrunk_f(st_p0x, span_p3x))
                    : prism_rtl::finished(crate::check::types::recording::err_fix_f(st_p0x, Text::lit("may-not-end"), span_p3x, prism_rtl::cat("this loop in `", name_p4x, "` may not end: nothing it sets gets smaller on every turn"), prism_rtl::cat("set a local from `&x -? 1` through a pattern, as `while ? left <- &fuel -? 1:`, or mark `", name_p4x, "` `unbounded fn`"))));
                });
            }));
            });
        }));
        });
    });
}


/// `Start CheckWhile, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_while_f(crate::check::types::St st_p0, crate::syntax::Cond c_p1, crate::syntax::Block body_p2, crate::syntax::Range span_p3, Text name_p4, Map<Text, crate::check::shrink::Rel> seeds_p5, bool unb_p6) {
    return prism_rtl::make_rc<CheckWhile>(st_p0, c_p1, body_p2, span_p3, name_p4, seeds_p5, unb_p6);
}


/// NoteUnshrunk: fn St, Range -> St
crate::check::types::St note_unshrunk_f(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1) {
    crate::check::types::St this_ = st_p0;
    prism_rtl::deref(this_.typed_p).unshrunk_p = crate::prelude::push(prism_rtl::deref(this_.typed_p).unshrunk_p, crate::check::types::recording::at_here_f(st_p0, span_p1));
    return this_;
}


/// SetTargets: unbounded fn [Stmt] -> [Text]
Array<Text> set_targets_f(const Array<crate::syntax::Stmt>& stmts_p0) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::shrink::walk::stmts_spots_f(stmts_p0, Map<Text, crate::check::shrink::Rel>{}), Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::shrink::walk::Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_p1 = p0;
                auto sp_p2 = p1;
                (crate::prelude::call_then(start_spot_set_root_f(sp_p2), [=, acc_p1 = std::move(acc_p1)](Array<Text> spot_set_root_f_15448) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_p1, spot_set_root_f_15448)); }));
            });
        }));
    }))));
}


prism_rtl::Turn<Array<Text>> SetTargets::cycle() const {
    const auto& stmts_p0 = this->stmts_p0;
    auto stmts_p0x = stmts_p0;
    return crate::prelude::call_then(crate::check::shrink::walk::start_stmts_spots_f(stmts_p0x, Map<Text, crate::check::shrink::Rel>{}), [=](Array<crate::check::shrink::walk::Spot> stmts_spots_f_15391) {
        return crate::prelude::fold_job(stmts_spots_f_15391, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::shrink::walk::Spot> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_p1 = p0;
                    auto sp_p2 = p1;
                    (crate::prelude::call_then(start_spot_set_root_f(sp_p2), [=, acc_p1 = std::move(acc_p1)](Array<Text> spot_set_root_f_15448) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_p1, spot_set_root_f_15448)); }));
                });
            }));
        })))->cycle();
    });
}


/// `Start SetTargets, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_set_targets_f(Array<crate::syntax::Stmt> stmts_p0) {
    return prism_rtl::make_rc<SetTargets>(stmts_p0);
}


/// SpotSetRoot: unbounded fn Spot -> [Text]
Array<Text> spot_set_root_f(const crate::check::shrink::walk::Spot& spot0) {
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(spot0)) {
        auto&& s_p0 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(spot0).a0;
        auto&& _m = prism_rtl::deref(s_p0).kind_p;
        if (prism_rtl::is<crate::syntax::StmtKind::SSet>(_m)) {
            auto&& t_p1 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
            return crate::prelude::take(crate::check::passes::borrows::ref_path_f(t_p1), Nat(1u));
        }
        if (prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m)) {
            auto&& t_p2 = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
            return crate::prelude::take(crate::check::passes::borrows::ref_path_f(t_p2), Nat(1u));
        }
        {
            return Array<Text>{};
        }
    }
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotExpr>(spot0)) {
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> SpotSetRoot::cycle() const {
    const auto& spot0 = this->spot0;
    return ({
        prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(spot0) ? ({
        auto&& s_p0 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(spot0).a0;
        ({
        auto&& _m = prism_rtl::deref(s_p0).kind_p;
        prism_rtl::is<crate::syntax::StmtKind::SSet>(_m) ? ({
        auto&& t_p1 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
        ({
        auto t_p1x = t_p1;
        (crate::prelude::call_then(crate::check::passes::borrows::start_ref_path_f(t_p1x), [=](Array<Text> ref_path_f_15584) { return prism_rtl::finished(crate::prelude::take(ref_path_f_15584, Nat(1u))); }));
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m) ? ({
        auto&& t_p2 = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
        ({
        auto t_p2x = t_p2;
        (crate::prelude::call_then(crate::check::passes::borrows::start_ref_path_f(t_p2x), [=](Array<Text> ref_path_f_15634) { return prism_rtl::finished(crate::prelude::take(ref_path_f_15634, Nat(1u))); }));
    });
    })
        : prism_rtl::finished(Array<Text>{});
    });
    })
        : prism_rtl::is<crate::check::shrink::walk::Spot::SpotExpr>(spot0) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SpotSetRoot, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_spot_set_root_f(crate::check::shrink::walk::Spot spot0) {
    return prism_rtl::make_rc<SpotSetRoot>(spot0);
}


/// AllPathsStrict: unbounded fn [Stmt], Text, Nat, (Text ==> Rel) -> Bool
bool all_paths_strict_f(const Array<crate::syntax::Stmt>& stmts_p0, const Text& v_p1, const Nat& vi_p2, const Map<Text, crate::check::shrink::Rel>& outer_p3) {
    auto rels_p4 = crate::check::shrink::relations::block_rels_f(stmts_p0, outer_p3);
    return crate::prelude::run_to_end(crate::prelude::fold_job(stmts_p0, false, ({
        auto v_p1x = v_p1;
        auto vi_p2x = vi_p2;
        auto rels_p4x = rels_p4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Stmt>)>>(prism_rtl::rc([=, v_p1x = std::move(v_p1x), vi_p2x = std::move(vi_p2x), rels_p4x = std::move(rels_p4x)](std::tuple<bool, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto v_p1xy = v_p1x;
            auto vi_p2xy = vi_p2x;
            auto rels_p4xy = rels_p4x;
            (crate::prelude::entered(crate::prelude::once_job([=, v_p1xy = std::move(v_p1xy), vi_p2xy = std::move(vi_p2xy), rels_p4xy = std::move(rels_p4xy)]() {
            return ({
                auto ok_p5 = p0;
                auto s_p6 = p1;
                ({
                auto&& _m = prism_rtl::deref(s_p6).kind_p;
                prism_rtl::is<crate::syntax::StmtKind::SSet>(_m) ? ({
                auto&& t_p7 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
                auto&& value_p8 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
                ({
                auto t_p7x = t_p7;
                auto value_p8x = value_p8;
                (crate::prelude::call_then(crate::check::passes::borrows::start_ref_path_f(t_p7x), [=, value_p8x = std::move(value_p8x)](Array<Text> ref_path_f_16319) {
                return ref_path_f_16319 == Array(std::vector{v_p1xy})
                    ? is_zero_lit_f(value_p8x)
                    ? prism_rtl::finished(ok_p5)
                    : prism_rtl::more(prism_rtl::rc(SetsStrict(value_p8x, v_p1xy, vi_p2xy, rels_p4xy)))
                    : prism_rtl::finished(ok_p5 && (!stmt_sets_weak_f(s_p6, v_p1xy, vi_p2xy, rels_p4xy)));
            }));
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
                auto&& e_p9 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                ({
                auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p9).kind_p);
                prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
                auto&& c_pa = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
                auto&& tb_pb = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
                auto&& eb_oc = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
                ({
                auto eb_ocx = eb_oc;
                auto c_pax = prism_rtl::deref(prism_rtl::deref(c_pa));
                auto tb_pbx = tb_pb;
                (crate::prelude::call_then(crate::check::shrink::relations::start_cond_rels_f(c_pax, rels_p4xy), [=, eb_ocx = std::move(eb_ocx), tb_pbx = std::move(tb_pbx)](Map<Text, crate::check::shrink::Rel> cond_rels_f_16544) {
                return ({
                    auto tr_pd = cond_rels_f_16544;
                    ({
                    prism_rtl::is_some(eb_ocx) ? ({
                    auto&& b_pe = prism_rtl::some_of(eb_ocx);
                    ({
                    auto b_pex = b_pe;
                    (crate::prelude::call_then(start_all_paths_strict_f(prism_rtl::deref(tb_pbx).stmts_p, v_p1xy, vi_p2xy, tr_pd), [=, b_pex = std::move(b_pex)](bool all_paths_strict_f_16617) {
                    return all_paths_strict_f_16617 && all_paths_strict_f(prism_rtl::deref(b_pex).stmts_p, v_p1xy, vi_p2xy, rels_p4xy)
                        ? prism_rtl::finished(true)
                        : prism_rtl::finished((ok_p5 && (!sets_weak_f(prism_rtl::deref(tb_pbx).stmts_p, v_p1xy, vi_p2xy, tr_pd))) && (!sets_weak_f(prism_rtl::deref(b_pex).stmts_p, v_p1xy, vi_p2xy, rels_p4xy)));
                }));
                });
                })
                    : prism_rtl::is_none(eb_ocx) ? prism_rtl::finished(ok_p5 && (!sets_weak_f(prism_rtl::deref(tb_pbx).stmts_p, v_p1xy, vi_p2xy, tr_pd)))
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
            })
                : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
                auto&& subj_pf = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
                auto&& arms_pg = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
                ({
                auto arms_pgx = arms_pg;
                auto subj_pfx = prism_rtl::deref(prism_rtl::deref(subj_pf));
                (crate::prelude::call_value(crate::prelude::fold_job(arms_pgx, true, ({
                auto v_p1xyx = v_p1xy;
                auto vi_p2xyx = vi_p2xy;
                auto subj_pfxx = subj_pfx;
                auto rels_p4xyx = rels_p4xy;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Arm>)>>(prism_rtl::rc([=, v_p1xyx = std::move(v_p1xyx), vi_p2xyx = std::move(vi_p2xyx), subj_pfxx = std::move(subj_pfxx), rels_p4xyx = std::move(rels_p4xyx)](std::tuple<bool, crate::syntax::Arm> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto v_p1xyxy = v_p1xyx;
                    auto vi_p2xyxy = vi_p2xyx;
                    auto subj_pfxxy = subj_pfxx;
                    auto rels_p4xyxy = rels_p4xyx;
                    (crate::prelude::entered(crate::prelude::once_job([=, v_p1xyxy = std::move(v_p1xyxy), vi_p2xyxy = std::move(vi_p2xyxy), subj_pfxxy = std::move(subj_pfxxy), rels_p4xyxy = std::move(rels_p4xyxy)]() {
                    return ({
                        auto all_arms_ph = p0;
                        auto a_pi = p1;
                        (prism_rtl::finished(std::move(all_arms_ph) && all_paths_strict_f(prism_rtl::deref(prism_rtl::deref(a_pi).body_p).stmts_p, v_p1xyxy, vi_p2xyxy, crate::check::shrink::relations::arm_pat_rels_f(subj_pfxxy, a_pi, rels_p4xyxy))));
                    });
                })));
                });
            })));
            })), [=](bool fold_16906) {
                return fold_16906
                    ? prism_rtl::finished(true)
                    : prism_rtl::finished(ok_p5 && (!crate::prelude::run_to_end(crate::prelude::fold_job(arms_pgx, false, ({
                    auto v_p1xyx = v_p1xy;
                    auto vi_p2xyx = vi_p2xy;
                    auto subj_pfxx = subj_pfx;
                    auto rels_p4xyx = rels_p4xy;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Arm>)>>(prism_rtl::rc([=, v_p1xyx = std::move(v_p1xyx), vi_p2xyx = std::move(vi_p2xyx), subj_pfxx = std::move(subj_pfxx), rels_p4xyx = std::move(rels_p4xyx)](std::tuple<bool, crate::syntax::Arm> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto v_p1xyxy = v_p1xyx;
                        auto vi_p2xyxy = vi_p2xyx;
                        auto subj_pfxxy = subj_pfxx;
                        auto rels_p4xyxy = rels_p4xyx;
                        (crate::prelude::entered(crate::prelude::once_job([=, v_p1xyxy = std::move(v_p1xyxy), vi_p2xyxy = std::move(vi_p2xyxy), subj_pfxxy = std::move(subj_pfxxy), rels_p4xyxy = std::move(rels_p4xyxy)]() {
                        return ({
                            auto any_arm_pj = p0;
                            auto a_pk = p1;
                            (prism_rtl::finished(std::move(any_arm_pj) || sets_weak_f(prism_rtl::deref(prism_rtl::deref(a_pk).body_p).stmts_p, v_p1xyxy, vi_p2xyxy, crate::check::shrink::relations::arm_pat_rels_f(subj_pfxxy, a_pk, rels_p4xyxy))));
                        });
                    })));
                    });
                })));
                })))));
            }));
            });
            })
                : prism_rtl::finished(std::move(ok_p5) && (!stmt_sets_weak_f(s_p6, v_p1xy, vi_p2xy, rels_p4xy)));
            });
            })
                : prism_rtl::finished(std::move(ok_p5) && (!stmt_sets_weak_f(s_p6, v_p1xy, vi_p2xy, rels_p4xy)));
            });
            });
        })));
        });
    })));
    })));
}


prism_rtl::Turn<bool> AllPathsStrict::cycle() const {
    const auto& stmts_p0 = this->stmts_p0;
    const auto& v_p1 = this->v_p1;
    const auto& vi_p2 = this->vi_p2;
    const auto& outer_p3 = this->outer_p3;
    auto outer_p3x = outer_p3;
    auto stmts_p0x = stmts_p0;
    auto v_p1x = v_p1;
    auto vi_p2x = vi_p2;
    return crate::prelude::call_then(crate::check::shrink::relations::start_block_rels_f(stmts_p0x, outer_p3x), [=](Map<Text, crate::check::shrink::Rel> block_rels_f_16211) {
        return ({
            auto rels_p4 = block_rels_f_16211;
            (crate::prelude::fold_job(stmts_p0x, false, ({
            auto v_p1xx = v_p1x;
            auto vi_p2xx = vi_p2x;
            auto rels_p4x = rels_p4;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Stmt>)>>(prism_rtl::rc([=, v_p1xx = std::move(v_p1xx), vi_p2xx = std::move(vi_p2xx), rels_p4x = std::move(rels_p4x)](std::tuple<bool, crate::syntax::Stmt> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto v_p1xxy = v_p1xx;
                auto vi_p2xxy = vi_p2xx;
                auto rels_p4xy = rels_p4x;
                (crate::prelude::entered(crate::prelude::once_job([=, v_p1xxy = std::move(v_p1xxy), vi_p2xxy = std::move(vi_p2xxy), rels_p4xy = std::move(rels_p4xy)]() {
                return ({
                    auto ok_p5 = p0;
                    auto s_p6 = p1;
                    ({
                    auto&& _m = prism_rtl::deref(s_p6).kind_p;
                    prism_rtl::is<crate::syntax::StmtKind::SSet>(_m) ? ({
                    auto&& t_p7 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
                    auto&& value_p8 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
                    ({
                    auto t_p7x = t_p7;
                    auto value_p8x = value_p8;
                    (crate::prelude::call_then(crate::check::passes::borrows::start_ref_path_f(t_p7x), [=, value_p8x = std::move(value_p8x)](Array<Text> ref_path_f_16319) {
                    return ref_path_f_16319 == Array(std::vector{v_p1xxy})
                        ? is_zero_lit_f(value_p8x)
                        ? prism_rtl::finished(ok_p5)
                        : prism_rtl::more(prism_rtl::rc(SetsStrict(value_p8x, v_p1xxy, vi_p2xxy, rels_p4xy)))
                        : prism_rtl::finished(ok_p5 && (!stmt_sets_weak_f(s_p6, v_p1xxy, vi_p2xxy, rels_p4xy)));
                }));
                });
                })
                    : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
                    auto&& e_p9 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                    ({
                    auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p9).kind_p);
                    prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
                    auto&& c_pa = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
                    auto&& tb_pb = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
                    auto&& eb_oc = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
                    ({
                    auto eb_ocx = eb_oc;
                    auto c_pax = prism_rtl::deref(prism_rtl::deref(c_pa));
                    auto tb_pbx = tb_pb;
                    (crate::prelude::call_then(crate::check::shrink::relations::start_cond_rels_f(c_pax, rels_p4xy), [=, eb_ocx = std::move(eb_ocx), tb_pbx = std::move(tb_pbx)](Map<Text, crate::check::shrink::Rel> cond_rels_f_16544) {
                    return ({
                        auto tr_pd = cond_rels_f_16544;
                        ({
                        prism_rtl::is_some(eb_ocx) ? ({
                        auto&& b_pe = prism_rtl::some_of(eb_ocx);
                        ({
                        auto b_pex = b_pe;
                        (crate::prelude::call_then(start_all_paths_strict_f(prism_rtl::deref(tb_pbx).stmts_p, v_p1xxy, vi_p2xxy, tr_pd), [=, b_pex = std::move(b_pex)](bool all_paths_strict_f_16617) {
                        return all_paths_strict_f_16617 && all_paths_strict_f(prism_rtl::deref(b_pex).stmts_p, v_p1xxy, vi_p2xxy, rels_p4xy)
                            ? prism_rtl::finished(true)
                            : prism_rtl::finished((ok_p5 && (!sets_weak_f(prism_rtl::deref(tb_pbx).stmts_p, v_p1xxy, vi_p2xxy, tr_pd))) && (!sets_weak_f(prism_rtl::deref(b_pex).stmts_p, v_p1xxy, vi_p2xxy, rels_p4xy)));
                    }));
                    });
                    })
                        : prism_rtl::is_none(eb_ocx) ? prism_rtl::finished(ok_p5 && (!sets_weak_f(prism_rtl::deref(tb_pbx).stmts_p, v_p1xxy, vi_p2xxy, tr_pd)))
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                }));
                });
                })
                    : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
                    auto&& subj_pf = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
                    auto&& arms_pg = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
                    ({
                    auto arms_pgx = arms_pg;
                    auto subj_pfx = prism_rtl::deref(prism_rtl::deref(subj_pf));
                    (crate::prelude::call_value(crate::prelude::fold_job(arms_pgx, true, ({
                    auto v_p1xxyx = v_p1xxy;
                    auto vi_p2xxyx = vi_p2xxy;
                    auto subj_pfxx = subj_pfx;
                    auto rels_p4xyx = rels_p4xy;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Arm>)>>(prism_rtl::rc([=, v_p1xxyx = std::move(v_p1xxyx), vi_p2xxyx = std::move(vi_p2xxyx), subj_pfxx = std::move(subj_pfxx), rels_p4xyx = std::move(rels_p4xyx)](std::tuple<bool, crate::syntax::Arm> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto v_p1xxyxy = v_p1xxyx;
                        auto vi_p2xxyxy = vi_p2xxyx;
                        auto subj_pfxxy = subj_pfxx;
                        auto rels_p4xyxy = rels_p4xyx;
                        (crate::prelude::entered(crate::prelude::once_job([=, v_p1xxyxy = std::move(v_p1xxyxy), vi_p2xxyxy = std::move(vi_p2xxyxy), subj_pfxxy = std::move(subj_pfxxy), rels_p4xyxy = std::move(rels_p4xyxy)]() {
                        return ({
                            auto all_arms_ph = p0;
                            auto a_pi = p1;
                            (prism_rtl::finished(std::move(all_arms_ph) && all_paths_strict_f(prism_rtl::deref(prism_rtl::deref(a_pi).body_p).stmts_p, v_p1xxyxy, vi_p2xxyxy, crate::check::shrink::relations::arm_pat_rels_f(subj_pfxxy, a_pi, rels_p4xyxy))));
                        });
                    })));
                    });
                })));
                })), [=](bool fold_16906) {
                    return fold_16906
                        ? prism_rtl::finished(true)
                        : prism_rtl::finished(ok_p5 && (!crate::prelude::run_to_end(crate::prelude::fold_job(arms_pgx, false, ({
                        auto v_p1xxyx = v_p1xxy;
                        auto vi_p2xxyx = vi_p2xxy;
                        auto subj_pfxx = subj_pfx;
                        auto rels_p4xyx = rels_p4xy;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Arm>)>>(prism_rtl::rc([=, v_p1xxyx = std::move(v_p1xxyx), vi_p2xxyx = std::move(vi_p2xxyx), subj_pfxx = std::move(subj_pfxx), rels_p4xyx = std::move(rels_p4xyx)](std::tuple<bool, crate::syntax::Arm> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto v_p1xxyxy = v_p1xxyx;
                            auto vi_p2xxyxy = vi_p2xxyx;
                            auto subj_pfxxy = subj_pfxx;
                            auto rels_p4xyxy = rels_p4xyx;
                            (crate::prelude::entered(crate::prelude::once_job([=, v_p1xxyxy = std::move(v_p1xxyxy), vi_p2xxyxy = std::move(vi_p2xxyxy), subj_pfxxy = std::move(subj_pfxxy), rels_p4xyxy = std::move(rels_p4xyxy)]() {
                            return ({
                                auto any_arm_pj = p0;
                                auto a_pk = p1;
                                (prism_rtl::finished(std::move(any_arm_pj) || sets_weak_f(prism_rtl::deref(prism_rtl::deref(a_pk).body_p).stmts_p, v_p1xxyxy, vi_p2xxyxy, crate::check::shrink::relations::arm_pat_rels_f(subj_pfxxy, a_pk, rels_p4xyxy))));
                            });
                        })));
                        });
                    })));
                    })))));
                }));
                });
                })
                    : prism_rtl::finished(std::move(ok_p5) && (!stmt_sets_weak_f(s_p6, v_p1xxy, vi_p2xxy, rels_p4xy)));
                });
                })
                    : prism_rtl::finished(std::move(ok_p5) && (!stmt_sets_weak_f(s_p6, v_p1xxy, vi_p2xxy, rels_p4xy)));
                });
                });
            })));
            });
        })));
        }))->cycle());
        });
    });
}


/// `Start AllPathsStrict, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_all_paths_strict_f(Array<crate::syntax::Stmt> stmts_p0, Text v_p1, Nat vi_p2, Map<Text, crate::check::shrink::Rel> outer_p3) {
    return prism_rtl::make_rc<AllPathsStrict>(stmts_p0, v_p1, vi_p2, outer_p3);
}


/// SetsWeak: unbounded fn [Stmt], Text, Nat, (Text ==> Rel) -> Bool
bool sets_weak_f(const Array<crate::syntax::Stmt>& stmts_p0, const Text& v_p1, const Nat& vi_p2, const Map<Text, crate::check::shrink::Rel>& outer_p3) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::shrink::walk::stmts_spots_f(stmts_p0, outer_p3), false, ({
        auto v_p1x = v_p1;
        auto vi_p2x = vi_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=, v_p1x = std::move(v_p1x), vi_p2x = std::move(vi_p2x)](std::tuple<bool, crate::check::shrink::walk::Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto v_p1xy = v_p1x;
            auto vi_p2xy = vi_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, v_p1xy = std::move(v_p1xy), vi_p2xy = std::move(vi_p2xy)]() {
            return ({
                auto seen_p4 = p0;
                auto sp_p5 = p1;
                (prism_rtl::finished(std::move(seen_p4) || spot_sets_weak_f(sp_p5, v_p1xy, vi_p2xy)));
            });
        })));
        });
    })));
    })));
}


prism_rtl::Turn<bool> SetsWeak::cycle() const {
    const auto& stmts_p0 = this->stmts_p0;
    const auto& v_p1 = this->v_p1;
    const auto& vi_p2 = this->vi_p2;
    const auto& outer_p3 = this->outer_p3;
    auto outer_p3x = outer_p3;
    auto stmts_p0x = stmts_p0;
    auto v_p1x = v_p1;
    auto vi_p2x = vi_p2;
    return crate::prelude::call_then(crate::check::shrink::walk::start_stmts_spots_f(stmts_p0x, outer_p3x), [=](Array<crate::check::shrink::walk::Spot> stmts_spots_f_17553) {
        return crate::prelude::fold_job(stmts_spots_f_17553, false, ({
            auto v_p1xx = v_p1x;
            auto vi_p2xx = vi_p2x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=, v_p1xx = std::move(v_p1xx), vi_p2xx = std::move(vi_p2xx)](std::tuple<bool, crate::check::shrink::walk::Spot> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto v_p1xxy = v_p1xx;
                auto vi_p2xxy = vi_p2xx;
                (crate::prelude::entered(crate::prelude::once_job([=, v_p1xxy = std::move(v_p1xxy), vi_p2xxy = std::move(vi_p2xxy)]() {
                return ({
                    auto seen_p4 = p0;
                    auto sp_p5 = p1;
                    (prism_rtl::finished(std::move(seen_p4) || spot_sets_weak_f(sp_p5, v_p1xxy, vi_p2xxy)));
                });
            })));
            });
        })));
        }))->cycle();
    });
}


/// `Start SetsWeak, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_sets_weak_f(Array<crate::syntax::Stmt> stmts_p0, Text v_p1, Nat vi_p2, Map<Text, crate::check::shrink::Rel> outer_p3) {
    return prism_rtl::make_rc<SetsWeak>(stmts_p0, v_p1, vi_p2, outer_p3);
}


/// StmtSetsWeak: unbounded fn Stmt, Text, Nat, (Text ==> Rel) -> Bool
bool stmt_sets_weak_f(const crate::syntax::Stmt& s_p0, const Text& v_p1, const Nat& vi_p2, const Map<Text, crate::check::shrink::Rel>& rels_p3) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::shrink::walk::stmt_spots_f(s_p0, rels_p3), false, ({
        auto v_p1x = v_p1;
        auto vi_p2x = vi_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=, v_p1x = std::move(v_p1x), vi_p2x = std::move(vi_p2x)](std::tuple<bool, crate::check::shrink::walk::Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto v_p1xy = v_p1x;
            auto vi_p2xy = vi_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, v_p1xy = std::move(v_p1xy), vi_p2xy = std::move(vi_p2xy)]() {
            return ({
                auto seen_p4 = p0;
                auto sp_p5 = p1;
                (prism_rtl::finished(std::move(seen_p4) || spot_sets_weak_f(sp_p5, v_p1xy, vi_p2xy)));
            });
        })));
        });
    })));
    })));
}


prism_rtl::Turn<bool> StmtSetsWeak::cycle() const {
    const auto& s_p0 = this->s_p0;
    const auto& v_p1 = this->v_p1;
    const auto& vi_p2 = this->vi_p2;
    const auto& rels_p3 = this->rels_p3;
    auto rels_p3x = rels_p3;
    auto s_p0x = s_p0;
    auto v_p1x = v_p1;
    auto vi_p2x = vi_p2;
    return crate::prelude::call_then(crate::check::shrink::walk::start_stmt_spots_f(s_p0x, rels_p3x), [=](Array<crate::check::shrink::walk::Spot> stmt_spots_f_17736) {
        return crate::prelude::fold_job(stmt_spots_f_17736, false, ({
            auto v_p1xx = v_p1x;
            auto vi_p2xx = vi_p2x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=, v_p1xx = std::move(v_p1xx), vi_p2xx = std::move(vi_p2xx)](std::tuple<bool, crate::check::shrink::walk::Spot> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto v_p1xxy = v_p1xx;
                auto vi_p2xxy = vi_p2xx;
                (crate::prelude::entered(crate::prelude::once_job([=, v_p1xxy = std::move(v_p1xxy), vi_p2xxy = std::move(vi_p2xxy)]() {
                return ({
                    auto seen_p4 = p0;
                    auto sp_p5 = p1;
                    (prism_rtl::finished(std::move(seen_p4) || spot_sets_weak_f(sp_p5, v_p1xxy, vi_p2xxy)));
                });
            })));
            });
        })));
        }))->cycle();
    });
}


/// `Start StmtSetsWeak, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_stmt_sets_weak_f(crate::syntax::Stmt s_p0, Text v_p1, Nat vi_p2, Map<Text, crate::check::shrink::Rel> rels_p3) {
    return prism_rtl::make_rc<StmtSetsWeak>(s_p0, v_p1, vi_p2, rels_p3);
}


/// SpotSetsWeak: unbounded fn Spot, Text, Nat -> Bool
bool spot_sets_weak_f(const crate::check::shrink::walk::Spot& spot0, const Text& text1, const Nat& n2) {
    auto&& _m = std::tuple{spot0, text1, n2};
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(std::get<0>(_m))) {
        auto&& s_p0 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(std::get<0>(_m)).a0;
        auto&& m_p1 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(std::get<0>(_m)).a1;
        auto&& v_p2 = std::get<1>(_m);
        auto&& vi_p3 = std::get<2>(_m);
        auto&& _m = prism_rtl::deref(s_p0).kind_p;
        if (prism_rtl::is<crate::syntax::StmtKind::SSet>(_m)) {
            auto&& t_p4 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
            auto&& value_p5 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
            return ((crate::prelude::take(crate::check::passes::borrows::ref_path_f(t_p4), Nat(1u)) == Array(std::vector{v_p2})) && (!sets_strict_f(value_p5, v_p2, vi_p3, m_p1))) && (!((crate::check::passes::borrows::ref_path_f(t_p4) == Array(std::vector{v_p2})) && is_zero_lit_f(value_p5)));
        }
        if (prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m)) {
            auto&& t_p6 = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
            return crate::prelude::take(crate::check::passes::borrows::ref_path_f(t_p6), Nat(1u)) == Array(std::vector{v_p2});
        }
        {
            return false;
        }
    }
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotExpr>(std::get<0>(_m))) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> SpotSetsWeak::cycle() const {
    const auto& spot0 = this->spot0;
    const auto& text1 = this->text1;
    const auto& n2 = this->n2;
    return ({
        auto&& _m = std::tuple{spot0, text1, n2};
        prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(std::get<0>(_m)) ? ({
        auto&& s_p0 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(std::get<0>(_m)).a0;
        auto&& m_p1 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(std::get<0>(_m)).a1;
        auto&& v_p2 = std::get<1>(_m);
        auto&& vi_p3 = std::get<2>(_m);
        ({
        auto&& _m = prism_rtl::deref(s_p0).kind_p;
        prism_rtl::is<crate::syntax::StmtKind::SSet>(_m) ? ({
        auto&& t_p4 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
        auto&& value_p5 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
        ({
        auto m_p1x = m_p1;
        auto t_p4x = t_p4;
        auto v_p2x = v_p2;
        auto value_p5x = value_p5;
        auto vi_p3x = vi_p3;
        (crate::prelude::call_then(crate::check::passes::borrows::start_ref_path_f(t_p4x), [=, m_p1x = std::move(m_p1x), v_p2x = std::move(v_p2x), value_p5x = std::move(value_p5x), vi_p3x = std::move(vi_p3x)](Array<Text> ref_path_f_17939) { return prism_rtl::finished(((crate::prelude::take(ref_path_f_17939, Nat(1u)) == Array(std::vector{v_p2x})) && (!sets_strict_f(value_p5x, v_p2x, vi_p3x, m_p1x))) && (!((crate::check::passes::borrows::ref_path_f(t_p4x) == Array(std::vector{v_p2x})) && is_zero_lit_f(value_p5x)))); }));
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m) ? ({
        auto&& t_p6 = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
        ({
        auto t_p6x = t_p6;
        auto v_p2x = v_p2;
        (crate::prelude::call_then(crate::check::passes::borrows::start_ref_path_f(t_p6x), [=, v_p2x = std::move(v_p2x)](Array<Text> ref_path_f_18088) { return prism_rtl::finished(crate::prelude::take(ref_path_f_18088, Nat(1u)) == Array(std::vector{v_p2x})); }));
    });
    })
        : prism_rtl::finished(false);
    });
    })
        : prism_rtl::is<crate::check::shrink::walk::Spot::SpotExpr>(std::get<0>(_m)) ? prism_rtl::finished(false)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SpotSetsWeak, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_spot_sets_weak_f(crate::check::shrink::walk::Spot spot0, Text text1, Nat n2) {
    return prism_rtl::make_rc<SpotSetsWeak>(spot0, text1, n2);
}


/// IsZeroLit: fn Expr -> Bool
bool is_zero_lit_f(const crate::syntax::Expr& e_p0) {
    auto&& _m = prism_rtl::deref(e_p0.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::ELit>(_m)) {
        auto&& l_p1 = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
        auto&& _m = prism_rtl::deref(l_p1).kind_p;
        if (prism_rtl::is<crate::syntax::LitKind::LInt>(_m)) {
            auto&& d_p2 = prism_rtl::as<crate::syntax::LitKind::LInt>(_m).a0;
            return d_p2 == Text::lit("0");
        }
        {
            return false;
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p3 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return is_zero_lit_f(prism_rtl::deref(prism_rtl::deref(x_p3)));
    }
    {
        return false;
    }
}


/// SetsStrict: unbounded fn Expr, Text, Nat, (Text ==> Rel) -> Bool
bool sets_strict_f(const crate::syntax::Expr& e_p0, const Text& v_p1, const Nat& vi_p2, const Map<Text, crate::check::shrink::Rel>& rels_p3) {
    auto&& _m = prism_rtl::deref(e_p0.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p4 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return sets_strict_f(prism_rtl::deref(prism_rtl::deref(x_p4)), v_p1, vi_p2, rels_p3);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
        auto&& m19465_1_0 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& l_p5 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        if (m19465_1_0 == Text::lit("-?")) {
            return is_nat_minus_f(rels_p3, e_p0) && sets_strict_f(prism_rtl::deref(prism_rtl::deref(l_p5)), v_p1, vi_p2, rels_p3);
        }
    }
    {
        return rel_strict_f(rels_p3, e_p0, vi_p2) || call_strict_f(e_p0, v_p1, vi_p2, rels_p3);
    }
}


prism_rtl::Turn<bool> SetsStrict::cycle() const {
    const auto& e_p0 = this->e_p0;
    const auto& v_p1 = this->v_p1;
    const auto& vi_p2 = this->vi_p2;
    const auto& rels_p3 = this->rels_p3;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p0).kind_p);
        prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x_p4 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(SetsStrict(prism_rtl::deref(prism_rtl::deref(x_p4)), v_p1, vi_p2, rels_p3)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m) && ({
        auto&& m19465_1_0 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& l_p5 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        (m19465_1_0 == Text::lit("-?"));
    }) ? ({
        auto&& m19465_1_0 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& l_p5 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        prism_rtl::finished(is_nat_minus_f(rels_p3, e_p0) && sets_strict_f(prism_rtl::deref(prism_rtl::deref(l_p5)), v_p1, vi_p2, rels_p3));
    })
        : ({
        auto e_p0x = e_p0;
        auto rels_p3x = rels_p3;
        auto v_p1x = v_p1;
        auto vi_p2x = vi_p2;
        (crate::prelude::call_then(start_rel_strict_f(rels_p3x, e_p0x, vi_p2x), [=, v_p1x = std::move(v_p1x)](bool rel_strict_f_19615) { return prism_rtl::finished(rel_strict_f_19615 || call_strict_f(e_p0x, v_p1x, vi_p2x, rels_p3x)); }));
    });
    });
}


/// `Start SetsStrict, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_sets_strict_f(crate::syntax::Expr e_p0, Text v_p1, Nat vi_p2, Map<Text, crate::check::shrink::Rel> rels_p3) {
    return prism_rtl::make_rc<SetsStrict>(e_p0, v_p1, vi_p2, rels_p3);
}


/// RelStrict: unbounded fn (Text ==> Rel), Expr, Nat -> Bool
bool rel_strict_f(const Map<Text, crate::check::shrink::Rel>& rels_p0, const crate::syntax::Expr& e_p1, const Nat& vi_p2) {
    auto&& _m = crate::check::shrink::walk::rel_of_o(rels_p0, e_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& r_p3 = prism_rtl::some_of(_m);
        return prism_rtl::deref(r_p3).strict_p && (prism_rtl::deref(r_p3).param_p == vi_p2);
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> RelStrict::cycle() const {
    const auto& rels_p0 = this->rels_p0;
    const auto& e_p1 = this->e_p1;
    const auto& vi_p2 = this->vi_p2;
    auto e_p1x = e_p1;
    auto rels_p0x = rels_p0;
    auto vi_p2x = vi_p2;
    return crate::prelude::call_then(crate::check::shrink::walk::start_rel_of_o(rels_p0x, e_p1x), [=](std::optional<crate::check::shrink::Rel> rel_of_o_19761) {
        return ({
            prism_rtl::is_some(rel_of_o_19761) ? ({
            auto&& r_p3 = prism_rtl::some_of(rel_of_o_19761);
            prism_rtl::finished(prism_rtl::deref(r_p3).strict_p && (prism_rtl::deref(r_p3).param_p == vi_p2x));
        })
            : prism_rtl::is_none(rel_of_o_19761) ? prism_rtl::finished(false)
            : throw prism_rtl::Panic("no arm matched");
        });
    });
}


/// `Start RelStrict, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_rel_strict_f(Map<Text, crate::check::shrink::Rel> rels_p0, crate::syntax::Expr e_p1, Nat vi_p2) {
    return prism_rtl::make_rc<RelStrict>(rels_p0, e_p1, vi_p2);
}


/// CallStrict: unbounded fn Expr, Text, Nat, (Text ==> Rel) -> Bool
bool call_strict_f(const crate::syntax::Expr& e_p0, const Text& v_p1, const Nat& vi_p2, const Map<Text, crate::check::shrink::Rel>& rels_p3) {
    auto&& _m = crate::check::shrink::walk::call_of_o(e_p0);
    if (prism_rtl::is_some(_m)) {
        auto&& c_p4 = std::get<0>(prism_rtl::some_of(_m));
        auto&& args_p5 = std::get<1>(prism_rtl::some_of(_m));
        return crate::check::shrink::walk::is_non_nat_min_f(rels_p3, e_p0, c_p4)
            ? false
            : ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = crate::check::shrink::walk::no_larger_arg_o(rels_p3, c_p4, args_p5);
            if (prism_rtl::is_some(_m)) {
                auto&& a_p6 = prism_rtl::some_of(_m);
                _v.set(sets_strict_f(a_p6, v_p1, vi_p2, rels_p3));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> CallStrict::cycle() const {
    const auto& e_p0 = this->e_p0;
    const auto& v_p1 = this->v_p1;
    const auto& vi_p2 = this->vi_p2;
    const auto& rels_p3 = this->rels_p3;
    return ({
        auto&& _m = crate::check::shrink::walk::call_of_o(e_p0);
        prism_rtl::is_some(_m) ? ({
        auto&& c_p4 = std::get<0>(prism_rtl::some_of(_m));
        auto&& args_p5 = std::get<1>(prism_rtl::some_of(_m));
        crate::check::shrink::walk::is_non_nat_min_f(rels_p3, e_p0, c_p4)
        ? prism_rtl::finished(false)
        : ({
        auto&& _m = crate::check::shrink::walk::no_larger_arg_o(rels_p3, c_p4, args_p5);
        prism_rtl::is_some(_m) ? ({
        auto&& a_p6 = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(SetsStrict(a_p6, v_p1, vi_p2, rels_p3)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CallStrict, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_call_strict_f(crate::syntax::Expr e_p0, Text v_p1, Nat vi_p2, Map<Text, crate::check::shrink::Rel> rels_p3) {
    return prism_rtl::make_rc<CallStrict>(e_p0, v_p1, vi_p2, rels_p3);
}

}  // namespace crate::check::shrink::summaries
