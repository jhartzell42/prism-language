// The module `Check.Shrink.Summaries`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/shrink/summaries/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Shrink.Summaries`, from `target/bootstrap/cpp-src/prismc/check/shrink/summaries.prism`.
namespace crate::check::shrink::summaries {

/// PartsSummaries: unbounded fn Shrink, [Def] -> (Text ==> Nat)
Map<Text, Nat> parts_summaries(const crate::check::shrink::Shrink& sk_p0, const Array<crate::check::env::Def>& fns_p1) {
    return run_to_end(fold_job(fns_p1, Map<Text, Nat>{}, ({
        auto sk_p0_1 = sk_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Nat>>(std::tuple<Map<Text, Nat>, crate::check::env::Def>)>>(prism_rtl::rc([=, sk_p0_1 = std::move(sk_p0_1)](std::tuple<Map<Text, Nat>, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_p0_1_2 = sk_p0_1;
            entered(once_job([=, sk_p0_1_2 = std::move(sk_p0_1_2)]() {
            return ({
                auto m_p2 = p0;
                auto d_p3 = p1;
                ({
                auto&& _m = prism_rtl::deref(d_p3).body;
                prism_rtl::is<crate::check::env::DefBody::DbFn>(_m) ? ({
                auto&& clauses_p4 = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
                ({
                auto n_p5 = ({
                    __label__ _done;
                    prism_rtl::Slot<Nat> _v;
                    auto&& _m = index(clauses_p4, Nat(0u));
                    if (prism_rtl::is_some(_m)) {
                        auto&& c0_p7 = prism_rtl::some_of(_m);
                        _v.set(len(prism_rtl::deref(c0_p7).params));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Nat(0u));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto clauses_p4_2 = clauses_p4;
                call_value(filter_job(crate::check::errors::range0(n_p5), ({
                auto clauses_p4_2_3 = clauses_p4_2;
                auto sk_p0_1_2_3 = sk_p0_1_2;
                auto d_p3_3 = d_p3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Nat)>>(prism_rtl::rc([=, clauses_p4_2_3 = std::move(clauses_p4_2_3), sk_p0_1_2_3 = std::move(sk_p0_1_2_3), d_p3_3 = std::move(d_p3_3)](Nat p0) {
                return ({
                    auto clauses_p4_2_3_4 = clauses_p4_2_3;
                    auto sk_p0_1_2_3_4 = sk_p0_1_2_3;
                    auto d_p3_3_4 = d_p3_3;
                    entered(once_job([=, clauses_p4_2_3_4 = std::move(clauses_p4_2_3_4), sk_p0_1_2_3_4 = std::move(sk_p0_1_2_3_4), d_p3_3_4 = std::move(d_p3_3_4)]() {
                    return ({
                        auto i_p8 = p0;
                        fold_job(clauses_p4_2_3_4, true, ({
                        auto sk_p0_1_2_3_4_4 = sk_p0_1_2_3_4;
                        auto d_p3_3_4_4 = d_p3_3_4;
                        auto i_p8_4 = i_p8;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, sk_p0_1_2_3_4_4 = std::move(sk_p0_1_2_3_4_4), d_p3_3_4_4 = std::move(d_p3_3_4_4), i_p8_4 = std::move(i_p8_4)](std::tuple<bool, crate::syntax::decls::FnClause> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto sk_p0_1_2_3_4_4_5 = sk_p0_1_2_3_4_4;
                            auto d_p3_3_4_4_5 = d_p3_3_4_4;
                            auto i_p8_4_5 = i_p8_4;
                            entered(once_job([=, sk_p0_1_2_3_4_4_5 = std::move(sk_p0_1_2_3_4_4_5), d_p3_3_4_4_5 = std::move(d_p3_3_4_4_5), i_p8_4_5 = std::move(i_p8_4_5)]() {
                            return ({
                                auto okc_p9 = p0;
                                auto c_pa = p1;
                                (prism_rtl::finished(std::move(okc_p9) && clause_within(crate::check::shrink::locals::clause_base(sk_p0_1_2_3_4_4_5, d_p3_3_4_4_5, c_pa), c_pa, i_p8_4_5)));
                            });
                        }));
                        });
                    })));
                    }))->cycle();
                    });
                }));
                });
            })));
            })), [=](Array<Nat> filter_2084) {
                return ({
                    auto ok_p6 = filter_2084;
                    ({
                    auto&& _m = index(ok_p6, Nat(0u));
                    prism_rtl::is_some(_m) ? ({
                    auto&& i_pb = prism_rtl::some_of(_m);
                    prism_rtl::finished(insert(m_p2, prism_rtl::deref(d_p3).qk, i_pb));
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(m_p2)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            });
            });
            })
                : prism_rtl::finished(m_p2);
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<Map<Text, Nat>> PartsSummaries::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& fns_p1 = this->fns_p1;
    return fold_job(fns_p1, Map<Text, Nat>{}, ({
        auto sk_p0_1 = sk_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Nat>>(std::tuple<Map<Text, Nat>, crate::check::env::Def>)>>(prism_rtl::rc([=, sk_p0_1 = std::move(sk_p0_1)](std::tuple<Map<Text, Nat>, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_p0_1_2 = sk_p0_1;
            entered(once_job([=, sk_p0_1_2 = std::move(sk_p0_1_2)]() {
            return ({
                auto m_p2 = p0;
                auto d_p3 = p1;
                ({
                auto&& _m = prism_rtl::deref(d_p3).body;
                prism_rtl::is<crate::check::env::DefBody::DbFn>(_m) ? ({
                auto&& clauses_p4 = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
                ({
                auto n_p5 = ({
                    __label__ _done;
                    prism_rtl::Slot<Nat> _v;
                    auto&& _m = index(clauses_p4, Nat(0u));
                    if (prism_rtl::is_some(_m)) {
                        auto&& c0_p7 = prism_rtl::some_of(_m);
                        _v.set(len(prism_rtl::deref(c0_p7).params));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Nat(0u));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto clauses_p4_2 = clauses_p4;
                call_value(filter_job(crate::check::errors::range0(n_p5), ({
                auto clauses_p4_2_3 = clauses_p4_2;
                auto sk_p0_1_2_3 = sk_p0_1_2;
                auto d_p3_3 = d_p3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Nat)>>(prism_rtl::rc([=, clauses_p4_2_3 = std::move(clauses_p4_2_3), sk_p0_1_2_3 = std::move(sk_p0_1_2_3), d_p3_3 = std::move(d_p3_3)](Nat p0) {
                return ({
                    auto clauses_p4_2_3_4 = clauses_p4_2_3;
                    auto sk_p0_1_2_3_4 = sk_p0_1_2_3;
                    auto d_p3_3_4 = d_p3_3;
                    entered(once_job([=, clauses_p4_2_3_4 = std::move(clauses_p4_2_3_4), sk_p0_1_2_3_4 = std::move(sk_p0_1_2_3_4), d_p3_3_4 = std::move(d_p3_3_4)]() {
                    return ({
                        auto i_p8 = p0;
                        fold_job(clauses_p4_2_3_4, true, ({
                        auto sk_p0_1_2_3_4_4 = sk_p0_1_2_3_4;
                        auto d_p3_3_4_4 = d_p3_3_4;
                        auto i_p8_4 = i_p8;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, sk_p0_1_2_3_4_4 = std::move(sk_p0_1_2_3_4_4), d_p3_3_4_4 = std::move(d_p3_3_4_4), i_p8_4 = std::move(i_p8_4)](std::tuple<bool, crate::syntax::decls::FnClause> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto sk_p0_1_2_3_4_4_5 = sk_p0_1_2_3_4_4;
                            auto d_p3_3_4_4_5 = d_p3_3_4_4;
                            auto i_p8_4_5 = i_p8_4;
                            entered(once_job([=, sk_p0_1_2_3_4_4_5 = std::move(sk_p0_1_2_3_4_4_5), d_p3_3_4_4_5 = std::move(d_p3_3_4_4_5), i_p8_4_5 = std::move(i_p8_4_5)]() {
                            return ({
                                auto okc_p9 = p0;
                                auto c_pa = p1;
                                (prism_rtl::finished(std::move(okc_p9) && clause_within(crate::check::shrink::locals::clause_base(sk_p0_1_2_3_4_4_5, d_p3_3_4_4_5, c_pa), c_pa, i_p8_4_5)));
                            });
                        }));
                        });
                    })));
                    }))->cycle();
                    });
                }));
                });
            })));
            })), [=](Array<Nat> filter_2084) {
                return ({
                    auto ok_p6 = filter_2084;
                    ({
                    auto&& _m = index(ok_p6, Nat(0u));
                    prism_rtl::is_some(_m) ? ({
                    auto&& i_pb = prism_rtl::some_of(_m);
                    prism_rtl::finished(insert(m_p2, prism_rtl::deref(d_p3).qk, i_pb));
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(m_p2)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            });
            });
            })
                : prism_rtl::finished(m_p2);
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start PartsSummaries, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Nat>> start_parts_summaries(crate::check::shrink::Shrink sk_p0, Array<crate::check::env::Def> fns_p1) {
    return prism_rtl::make_rc<PartsSummaries>(sk_p0, fns_p1);
}


/// ClauseWithin: unbounded fn (Text ==> Rel), FnClause, Nat -> Bool
bool clause_within(const Map<Text, crate::check::shrink::Rel>& base_p0, const crate::syntax::decls::FnClause& c_p1, const Nat& i_p2) {
    auto&& _m = c_p1.body;
    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(_m)) {
        auto&& e_p3 = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(_m).a0;
        return within(base_p0, i_p2, e_p3);
    }
    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(_m)) {
        auto&& b_p4 = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(_m).a0;
        return within_block(base_p0, i_p2, b_p4);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> ClauseWithin::cycle() const {
    const auto& base_p0 = this->base_p0;
    const auto& c_p1 = this->c_p1;
    const auto& i_p2 = this->i_p2;
    return ({
        auto&& _m = prism_rtl::deref(c_p1).body;
        prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(_m) ? ({
        auto&& e_p3 = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(_m).a0;
        prism_rtl::more(prism_rtl::rc(Within(base_p0, i_p2, e_p3)));
    })
        : prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(_m) ? ({
        auto&& b_p4 = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(_m).a0;
        prism_rtl::more(prism_rtl::rc(WithinBlock(base_p0, i_p2, b_p4)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ClauseWithin, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_clause_within(Map<Text, crate::check::shrink::Rel> base_p0, crate::syntax::decls::FnClause c_p1, Nat i_p2) {
    return prism_rtl::make_rc<ClauseWithin>(base_p0, c_p1, i_p2);
}


/// Within: unbounded fn (Text ==> Rel), Nat, Expr -> Bool
bool within(const Map<Text, crate::check::shrink::Rel>& m_p0, const Nat& i_p1, const crate::syntax::Expr& e_p2) {
    auto&& _m = crate::check::shrink::walk::rel_of(m_p0, e_p2);
    if (prism_rtl::is_some(_m)) {
        auto&& r_p3 = prism_rtl::some_of(_m);
        return prism_rtl::deref(r_p3).param == i_p1;
    }
    if (prism_rtl::is_none(_m)) {
        auto&& _m = prism_rtl::deref(e_p2.kind);
        if (prism_rtl::is<crate::syntax::ExprKind::EArray>(_m)) {
            auto&& es_p4 = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
            return run_to_end(fold_job(es_p4, true, ({
                auto m_p0_1 = m_p0;
                auto i_p1_2 = i_p1;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Expr>)>>(prism_rtl::rc([=, m_p0_1 = std::move(m_p0_1), i_p1_2 = std::move(i_p1_2)](std::tuple<bool, crate::syntax::Expr> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto m_p0_1_3 = m_p0_1;
                    auto i_p1_2_3 = i_p1_2;
                    entered(once_job([=, m_p0_1_3 = std::move(m_p0_1_3), i_p1_2_3 = std::move(i_p1_2_3)]() {
                    return ({
                        auto ok_p5 = p0;
                        auto x_p6 = p1;
                        (prism_rtl::finished(std::move(ok_p5) && part(m_p0_1_3, i_p1_2_3, x_p6)));
                    });
                }));
                });
            })));
            })));
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMap>(_m)) {
            auto&& kvs_p7 = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
            return run_to_end(fold_job(kvs_p7, true, ({
                auto m_p0_1 = m_p0;
                auto i_p1_2 = i_p1;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<crate::syntax::Expr, crate::syntax::Expr>>)>>(prism_rtl::rc([=, m_p0_1 = std::move(m_p0_1), i_p1_2 = std::move(i_p1_2)](std::tuple<bool, std::tuple<crate::syntax::Expr, crate::syntax::Expr>> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto m_p0_1_3 = m_p0_1;
                    auto i_p1_2_3 = i_p1_2;
                    entered(once_job([=, m_p0_1_3 = std::move(m_p0_1_3), i_p1_2_3 = std::move(i_p1_2_3)]() {
                    return ({
                        auto ok_p8 = p0;
                        auto [k_p9, v_pa] = p1;
                        (prism_rtl::finished((std::move(ok_p8) && part(m_p0_1_3, i_p1_2_3, k_p9)) && part(m_p0_1_3, i_p1_2_3, v_pa)));
                    });
                }));
                });
            })));
            })));
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
            auto&& x_pb = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
            return within(m_p0, i_p1, prism_rtl::deref(prism_rtl::deref(x_pb)));
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
            auto&& s_pc = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
            auto&& arms_pd = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
            return run_to_end(fold_job(arms_pd, true, ({
                auto s_pc_1 = prism_rtl::deref(prism_rtl::deref(s_pc));
                auto m_p0_2 = m_p0;
                auto i_p1_3 = i_p1;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Arm>)>>(prism_rtl::rc([=, s_pc_1 = std::move(s_pc_1), m_p0_2 = std::move(m_p0_2), i_p1_3 = std::move(i_p1_3)](std::tuple<bool, crate::syntax::Arm> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto s_pc_1_4 = s_pc_1;
                    auto m_p0_2_4 = m_p0_2;
                    auto i_p1_3_4 = i_p1_3;
                    entered(once_job([=, s_pc_1_4 = std::move(s_pc_1_4), m_p0_2_4 = std::move(m_p0_2_4), i_p1_3_4 = std::move(i_p1_3_4)]() {
                    return ({
                        auto ok_pe = p0;
                        auto a_pf = p1;
                        (prism_rtl::finished(std::move(ok_pe) && within_block(crate::check::shrink::relations::arm_pat_rels(s_pc_1_4, a_pf, m_p0_2_4), i_p1_3_4, prism_rtl::deref(a_pf).body)));
                    });
                }));
                });
            })));
            })));
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2)) {
            auto&& c_pg = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
            auto&& t_ph = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
            auto&& el_pi = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
            return within_block(crate::check::shrink::relations::cond_rels(prism_rtl::deref(prism_rtl::deref(c_pg)), m_p0), i_p1, t_ph) && within_block(m_p0, i_p1, el_pi);
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m)) {
            auto&& start_pj = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
            auto&& b_pk = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
            return within(m_p0, i_p1, prism_rtl::deref(prism_rtl::deref(start_pj))) && update_within(insert(m_p0, Text::lit("&_"), crate::check::shrink::Rel{.param = i_p1, .strict = false}), i_p1, b_pk);
        }
        {
            auto&& _m = crate::check::shrink::walk::call_of(e_p2);
            if (prism_rtl::is_some(_m)) {
                auto&& c_pl = std::get<0>(prism_rtl::some_of(_m));
                auto&& args_pm = std::get<1>(prism_rtl::some_of(_m));
                auto&& _m = crate::check::shrink::walk::traversal_of(m_p0, c_pl, args_pm);
                if (prism_rtl::is_some(_m)) {
                    auto&& coll_pn = std::get<0>(prism_rtl::some_of(_m));
                    auto&& step_po = std::get<1>(prism_rtl::some_of(_m));
                    auto&& at_pp = std::get<2>(prism_rtl::some_of(_m));
                    return within(m_p0, i_p1, coll_pn) && step_within(m_p0, i_p1, crate::check::shrink::locals::expr_name(c_pl), coll_pn, step_po, at_pp, or_(index(args_pm, Nat(1u)), dummy_arg())->value);
                }
                if (prism_rtl::is_none(_m)) {
                    return false;
                }
                prism_rtl::unreachable("no arm matched");
            }
            if (prism_rtl::is_none(_m)) {
                return false;
            }
            prism_rtl::unreachable("no arm matched");
        }
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> Within::cycle() const {
    const auto& m_p0 = this->m_p0;
    const auto& i_p1 = this->i_p1;
    const auto& e_p2 = this->e_p2;
    auto e_p2_1 = e_p2;
    auto i_p1_2 = i_p1;
    auto m_p0_3 = m_p0;
    return call_then(crate::check::shrink::walk::start_rel_of(m_p0_3, e_p2_1), [=](std::optional<crate::check::shrink::Rel> rel_of_2544) {
        return ({
            prism_rtl::is_some(rel_of_2544) ? ({
            auto&& r_p3 = prism_rtl::some_of(rel_of_2544);
            prism_rtl::finished(prism_rtl::deref(r_p3).param == i_p1_2);
        })
            : prism_rtl::is_none(rel_of_2544) ? ({
            auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p2_1).kind);
            prism_rtl::is<crate::syntax::ExprKind::EArray>(_m) ? ({
            auto&& es_p4 = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
            fold_job(es_p4, true, ({
            auto m_p0_3_4 = m_p0_3;
            auto i_p1_2_4 = i_p1_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Expr>)>>(prism_rtl::rc([=, m_p0_3_4 = std::move(m_p0_3_4), i_p1_2_4 = std::move(i_p1_2_4)](std::tuple<bool, crate::syntax::Expr> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto m_p0_3_4_4 = m_p0_3_4;
                auto i_p1_2_4_4 = i_p1_2_4;
                entered(once_job([=, m_p0_3_4_4 = std::move(m_p0_3_4_4), i_p1_2_4_4 = std::move(i_p1_2_4_4)]() {
                return ({
                    auto ok_p5 = p0;
                    auto x_p6 = p1;
                    (prism_rtl::finished(std::move(ok_p5) && part(m_p0_3_4_4, i_p1_2_4_4, x_p6)));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::syntax::ExprKind::EMap>(_m) ? ({
            auto&& kvs_p7 = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
            fold_job(kvs_p7, true, ({
            auto m_p0_3_4 = m_p0_3;
            auto i_p1_2_4 = i_p1_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<crate::syntax::Expr, crate::syntax::Expr>>)>>(prism_rtl::rc([=, m_p0_3_4 = std::move(m_p0_3_4), i_p1_2_4 = std::move(i_p1_2_4)](std::tuple<bool, std::tuple<crate::syntax::Expr, crate::syntax::Expr>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto m_p0_3_4_4 = m_p0_3_4;
                auto i_p1_2_4_4 = i_p1_2_4;
                entered(once_job([=, m_p0_3_4_4 = std::move(m_p0_3_4_4), i_p1_2_4_4 = std::move(i_p1_2_4_4)]() {
                return ({
                    auto ok_p8 = p0;
                    auto [k_p9, v_pa] = p1;
                    (prism_rtl::finished((std::move(ok_p8) && part(m_p0_3_4_4, i_p1_2_4_4, k_p9)) && part(m_p0_3_4_4, i_p1_2_4_4, v_pa)));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
            auto&& x_pb = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
            prism_rtl::more(prism_rtl::rc(Within(m_p0_3, i_p1_2, prism_rtl::deref(prism_rtl::deref(x_pb)))));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
            auto&& s_pc = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
            auto&& arms_pd = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
            fold_job(arms_pd, true, ({
            auto s_pc_4 = prism_rtl::deref(prism_rtl::deref(s_pc));
            auto m_p0_3_5 = m_p0_3;
            auto i_p1_2_5 = i_p1_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Arm>)>>(prism_rtl::rc([=, s_pc_4 = std::move(s_pc_4), m_p0_3_5 = std::move(m_p0_3_5), i_p1_2_5 = std::move(i_p1_2_5)](std::tuple<bool, crate::syntax::Arm> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto s_pc_4_5 = s_pc_4;
                auto m_p0_3_5_5 = m_p0_3_5;
                auto i_p1_2_5_5 = i_p1_2_5;
                entered(once_job([=, s_pc_4_5 = std::move(s_pc_4_5), m_p0_3_5_5 = std::move(m_p0_3_5_5), i_p1_2_5_5 = std::move(i_p1_2_5_5)]() {
                return ({
                    auto ok_pe = p0;
                    auto a_pf = p1;
                    (prism_rtl::finished(std::move(ok_pe) && within_block(crate::check::shrink::relations::arm_pat_rels(s_pc_4_5, a_pf, m_p0_3_5_5), i_p1_2_5_5, prism_rtl::deref(a_pf).body)));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2) ? ({
            auto&& c_pg = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
            auto&& t_ph = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
            auto&& el_pi = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
            ({
            auto c_pg_4 = prism_rtl::deref(prism_rtl::deref(c_pg));
            auto el_pi_5 = el_pi;
            auto t_ph_6 = t_ph;
            call_then(crate::check::shrink::relations::start_cond_rels(c_pg_4, m_p0_3), [=, el_pi_5 = std::move(el_pi_5), t_ph_6 = std::move(t_ph_6)](Map<Text, crate::check::shrink::Rel> cond_rels_2928) { return call_then(start_within_block(cond_rels_2928, i_p1_2, t_ph_6), [=](bool within_block_2915) { return prism_rtl::finished(within_block_2915 && within_block(m_p0_3, i_p1_2, el_pi_5)); }); });
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m) ? ({
            auto&& start_pj = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
            auto&& b_pk = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
            ({
            auto b_pk_4 = b_pk;
            auto start_pj_5 = prism_rtl::deref(prism_rtl::deref(start_pj));
            call_then(start_within(m_p0_3, i_p1_2, start_pj_5), [=, b_pk_4 = std::move(b_pk_4)](bool within_3002) { return prism_rtl::finished(within_3002 && update_within(insert(m_p0_3, Text::lit("&_"), crate::check::shrink::Rel{.param = i_p1_2, .strict = false}), i_p1_2, b_pk_4)); });
        });
        })
            : ({
            auto&& _m = crate::check::shrink::walk::call_of(e_p2_1);
            prism_rtl::is_some(_m) ? ({
            auto&& c_pl = std::get<0>(prism_rtl::some_of(_m));
            auto&& args_pm = std::get<1>(prism_rtl::some_of(_m));
            ({
            auto&& _m = crate::check::shrink::walk::traversal_of(m_p0_3, c_pl, args_pm);
            prism_rtl::is_some(_m) ? ({
            auto&& coll_pn = std::get<0>(prism_rtl::some_of(_m));
            auto&& step_po = std::get<1>(prism_rtl::some_of(_m));
            auto&& at_pp = std::get<2>(prism_rtl::some_of(_m));
            call_then(start_within(m_p0_3, i_p1_2, coll_pn), [=](bool within_3223) { return prism_rtl::finished(within_3223 && step_within(m_p0_3, i_p1_2, crate::check::shrink::locals::expr_name(c_pl), coll_pn, step_po, at_pp, or_(index(args_pm, Nat(1u)), dummy_arg())->value)); });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
    });
}


/// `Start Within, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_within(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, crate::syntax::Expr e_p2) {
    return prism_rtl::make_rc<Within>(m_p0, i_p1, e_p2);
}


/// UpdateWithin: unbounded fn (Text ==> Rel), Nat, Block -> Bool
bool update_within(const Map<Text, crate::check::shrink::Rel>& m_p0, const Nat& i_p1, const crate::syntax::Block& b_p2) {
    return run_to_end(fold_job(crate::check::shrink::walk::stmts_spots(b_p2.stmts, m_p0), true, ({
        auto i_p1_1 = i_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=, i_p1_1 = std::move(i_p1_1)](std::tuple<bool, crate::check::shrink::walk::Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto i_p1_1_2 = i_p1_1;
            entered(once_job([=, i_p1_1_2 = std::move(i_p1_1_2)]() {
            return ({
                auto ok_p3 = p0;
                auto sp_p4 = p1;
                (prism_rtl::finished(std::move(ok_p3) && spot_keeps_within(sp_p4, i_p1_1_2)));
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<bool> UpdateWithin::cycle() const {
    const auto& m_p0 = this->m_p0;
    const auto& i_p1 = this->i_p1;
    const auto& b_p2 = this->b_p2;
    auto b_p2_1 = b_p2;
    auto i_p1_2 = i_p1;
    auto m_p0_3 = m_p0;
    return call_then(crate::check::shrink::walk::start_stmts_spots(prism_rtl::deref(b_p2_1).stmts, m_p0_3), [=](Array<crate::check::shrink::walk::Spot> stmts_spots_3685) {
        return fold_job(stmts_spots_3685, true, ({
            auto i_p1_2_4 = i_p1_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=, i_p1_2_4 = std::move(i_p1_2_4)](std::tuple<bool, crate::check::shrink::walk::Spot> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto i_p1_2_4_4 = i_p1_2_4;
                entered(once_job([=, i_p1_2_4_4 = std::move(i_p1_2_4_4)]() {
                return ({
                    auto ok_p3 = p0;
                    auto sp_p4 = p1;
                    (prism_rtl::finished(std::move(ok_p3) && spot_keeps_within(sp_p4, i_p1_2_4_4)));
                });
            }));
            });
        })));
        }))->cycle();
    });
}


/// `Start UpdateWithin, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_update_within(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, crate::syntax::Block b_p2) {
    return prism_rtl::make_rc<UpdateWithin>(m_p0, i_p1, b_p2);
}


/// SpotKeepsWithin: unbounded fn Spot, Nat -> Bool
bool spot_keeps_within(const crate::check::shrink::walk::Spot& spot0, const Nat& n1) {
    auto&& _m = std::tuple{spot0, n1};
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(std::get<0>(_m))) {
        auto&& s_p0 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(std::get<0>(_m)).a0;
        auto&& m_p1 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(std::get<0>(_m)).a1;
        auto&& i_p2 = std::get<1>(_m);
        auto&& _m = prism_rtl::deref(s_p0).kind;
        if (prism_rtl::is<crate::syntax::StmtKind::SSet>(_m)) {
            auto&& t_p3 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
            auto&& value_p4 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
            return take(crate::check::passes::borrows::ref_path(t_p3), Nat(1u)) != Array(std::vector{Text::lit("&_")})
                ? true
                : (crate::check::passes::borrows::ref_path(t_p3) == Array(std::vector{Text::lit("&_")})) && within(m_p1, i_p2, value_p4);
        }
        if (prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m)) {
            auto&& t_p5 = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
            return take(crate::check::passes::borrows::ref_path(t_p5), Nat(1u)) != Array(std::vector{Text::lit("&_")});
        }
        {
            return true;
        }
    }
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotExpr>(std::get<0>(_m))) {
        return true;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> SpotKeepsWithin::cycle() const {
    const auto& spot0 = this->spot0;
    const auto& n1 = this->n1;
    return ({
        auto&& _m = std::tuple{spot0, n1};
        prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(std::get<0>(_m)) ? ({
        auto&& s_p0 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(std::get<0>(_m)).a0;
        auto&& m_p1 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(std::get<0>(_m)).a1;
        auto&& i_p2 = std::get<1>(_m);
        ({
        auto&& _m = prism_rtl::deref(s_p0).kind;
        prism_rtl::is<crate::syntax::StmtKind::SSet>(_m) ? ({
        auto&& t_p3 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
        auto&& value_p4 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
        ({
        auto i_p2_1 = i_p2;
        auto m_p1_2 = m_p1;
        auto t_p3_3 = t_p3;
        auto value_p4_4 = value_p4;
        call_then(crate::check::passes::borrows::start_ref_path(t_p3_3), [=, i_p2_1 = std::move(i_p2_1), m_p1_2 = std::move(m_p1_2), value_p4_4 = std::move(value_p4_4)](Array<Text> ref_path_3894) {
        return take(ref_path_3894, Nat(1u)) != Array(std::vector{Text::lit("&_")})
            ? prism_rtl::finished(true)
            : call_then(crate::check::passes::borrows::start_ref_path(t_p3_3), [=](Array<Text> ref_path_3942) { return prism_rtl::finished((ref_path_3942 == Array(std::vector{Text::lit("&_")})) && within(m_p1_2, i_p2_1, value_p4_4)); });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m) ? ({
        auto&& t_p5 = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
        ({
        auto t_p5_1 = t_p5;
        call_then(crate::check::passes::borrows::start_ref_path(t_p5_1), [=](Array<Text> ref_path_4025) { return prism_rtl::finished(take(ref_path_4025, Nat(1u)) != Array(std::vector{Text::lit("&_")})); });
    });
    })
        : prism_rtl::finished(true);
    });
    })
        : prism_rtl::is<crate::check::shrink::walk::Spot::SpotExpr>(std::get<0>(_m)) ? prism_rtl::finished(true)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SpotKeepsWithin, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_spot_keeps_within(crate::check::shrink::walk::Spot spot0, Nat n1) {
    return prism_rtl::make_rc<SpotKeepsWithin>(spot0, n1);
}


/// WithinBlock: unbounded fn (Text ==> Rel), Nat, Block -> Bool
bool within_block(const Map<Text, crate::check::shrink::Rel>& m_p0, const Nat& i_p1, const crate::syntax::Block& b_p2) {
    return within(crate::check::shrink::relations::block_rels(b_p2.stmts, m_p0), i_p1, last_or(b_p2));
}


prism_rtl::Turn<bool> WithinBlock::cycle() const {
    const auto& m_p0 = this->m_p0;
    const auto& i_p1 = this->i_p1;
    const auto& b_p2 = this->b_p2;
    auto b_p2_1 = b_p2;
    auto i_p1_2 = i_p1;
    auto m_p0_3 = m_p0;
    return call_then(crate::check::shrink::relations::start_block_rels(prism_rtl::deref(b_p2_1).stmts, m_p0_3), [=](Map<Text, crate::check::shrink::Rel> block_rels_4289) { return prism_rtl::more(prism_rtl::rc(Within(block_rels_4289, i_p1_2, last_or(b_p2_1)))); });
}


/// `Start WithinBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_within_block(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, crate::syntax::Block b_p2) {
    return prism_rtl::make_rc<WithinBlock>(m_p0, i_p1, b_p2);
}


/// StepWithin: unbounded fn (Text ==> Rel), Nat, Text, Expr, Expr, Nat, Expr -> Bool
bool step_within(const Map<Text, crate::check::shrink::Rel>& m_p0, const Nat& i_p1, const Text& f_p2, const crate::syntax::Expr& coll_p3, const crate::syntax::Expr& step_p4, const Nat& at_p5, const crate::syntax::Expr& z_p6) {
    return crate::check::shrink::relations::pre_is(m_p0, f_p2, Text::lit("Filter"))
        ? true
        : ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = prism_rtl::deref(step_p4.kind);
        if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0)) {
            auto&& ps_p7 = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0);
            auto&& body_p8 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
            _v.set(({
                auto sm_p9 = crate::check::shrink::relations::step_rels(m_p0, coll_p3, ps_p7, at_p5);
                auto [bm_pc, x_pd] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<Map<Text, crate::check::shrink::Rel>, crate::syntax::Expr>> _v;
                    auto&& _m = prism_rtl::deref(prism_rtl::deref(body_p8));
                    if (prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(_m)) {
                        auto&& y_pa = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(_m).a0;
                        _v.set(std::tuple{sm_p9, prism_rtl::deref(prism_rtl::deref(y_pa))});
                        goto _done;
                    }
                    if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(_m)) {
                        auto&& b_pb = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(_m).a0;
                        _v.set(std::tuple{crate::check::shrink::relations::block_rels(prism_rtl::deref(b_pb).stmts, sm_p9), last_or(b_pb)});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                (crate::check::shrink::relations::pre_is(m_p0, f_p2, Text::lit("Each"))
                ? part(bm_pc, i_p1, x_pd)
                : ({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = index(ps_p7, Nat(0u));
                if (prism_rtl::is_some(_m)) {
                    auto&& acc_pe = prism_rtl::some_of(_m);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<bool> _v;
                        auto&& _m = prism_rtl::deref(prism_rtl::deref(acc_pe).kind);
                        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                            auto&& n_pf = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                            _v.set(within(m_p0, i_p1, z_p6) && builds_on(bm_pc, i_p1, crate::check::env::sname_key(n_pf), x_pd));
                            goto _done;
                        }
                        {
                            _v.set(false);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(false);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            }));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<bool> StepWithin::cycle() const {
    const auto& m_p0 = this->m_p0;
    const auto& i_p1 = this->i_p1;
    const auto& f_p2 = this->f_p2;
    const auto& coll_p3 = this->coll_p3;
    const auto& step_p4 = this->step_p4;
    const auto& at_p5 = this->at_p5;
    const auto& z_p6 = this->z_p6;
    return crate::check::shrink::relations::pre_is(m_p0, f_p2, Text::lit("Filter"))
        ? prism_rtl::finished(true)
        : ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(step_p4).kind);
        prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0) ? ({
        auto&& ps_p7 = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0);
        auto&& body_p8 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
        ({
        auto at_p5_1 = at_p5;
        auto body_p8_2 = prism_rtl::deref(prism_rtl::deref(body_p8));
        auto coll_p3_3 = coll_p3;
        auto f_p2_4 = f_p2;
        auto i_p1_5 = i_p1;
        auto m_p0_6 = m_p0;
        auto ps_p7_7 = ps_p7;
        auto z_p6_8 = z_p6;
        call_then(crate::check::shrink::relations::start_step_rels(m_p0_6, coll_p3_3, ps_p7_7, at_p5_1), [=, body_p8_2 = std::move(body_p8_2), f_p2_4 = std::move(f_p2_4), i_p1_5 = std::move(i_p1_5), z_p6_8 = std::move(z_p6_8)](Map<Text, crate::check::shrink::Rel> step_rels_4719) {
        return ({
            auto sm_p9 = step_rels_4719;
            auto [bm_pc, x_pd] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Map<Text, crate::check::shrink::Rel>, crate::syntax::Expr>> _v;
                if (prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(body_p8_2)) {
                    auto&& y_pa = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(body_p8_2).a0;
                    _v.set(std::tuple{sm_p9, prism_rtl::deref(prism_rtl::deref(y_pa))});
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(body_p8_2)) {
                    auto&& b_pb = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(body_p8_2).a0;
                    _v.set(std::tuple{crate::check::shrink::relations::block_rels(prism_rtl::deref(b_pb).stmts, sm_p9), last_or(b_pb)});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (crate::check::shrink::relations::pre_is(m_p0_6, f_p2_4, Text::lit("Each"))
            ? prism_rtl::more(prism_rtl::rc(Part(bm_pc, i_p1_5, x_pd)))
            : ({
            auto&& _m = index(ps_p7_7, Nat(0u));
            prism_rtl::is_some(_m) ? ({
            auto&& acc_pe = prism_rtl::some_of(_m);
            ({
            auto&& _m = prism_rtl::deref(prism_rtl::deref(acc_pe).kind);
            prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
            auto&& n_pf = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            ({
            auto n_pf_9 = n_pf;
            call_then(start_within(m_p0_6, i_p1_5, z_p6_8), [=, n_pf_9 = std::move(n_pf_9)](bool within_5036) { return prism_rtl::finished(within_5036 && builds_on(bm_pc, i_p1_5, crate::check::env::sname_key(n_pf_9), x_pd)); });
        });
        })
            : prism_rtl::finished(false);
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
            : throw prism_rtl::Panic("no arm matched");
        }));
        });
    });
    });
    })
        : prism_rtl::finished(false);
    });
}


/// `Start StepWithin, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_step_within(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, Text f_p2, crate::syntax::Expr coll_p3, crate::syntax::Expr step_p4, Nat at_p5, crate::syntax::Expr z_p6) {
    return prism_rtl::make_rc<StepWithin>(m_p0, i_p1, f_p2, coll_p3, step_p4, at_p5, z_p6);
}


/// LastOr: fn Block -> Expr
crate::syntax::Expr last_or(const crate::syntax::Block& b_p0) {
    return or_(crate::check::shrink::walk::last_expr(b_p0), dummy_arg()->value);
}


/// BuildsOn: unbounded fn (Text ==> Rel), Nat, Text, Expr -> Bool
bool builds_on(const Map<Text, crate::check::shrink::Rel>& m_p0, const Nat& i_p1, const Text& acc_p2, const crate::syntax::Expr& e_p3) {
    auto&& _m = prism_rtl::deref(e_p3.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p4 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return crate::check::env::sname_key(n_p4) == acc_p2;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p5 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return builds_on(m_p0, i_p1, acc_p2, prism_rtl::deref(prism_rtl::deref(x_p5)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
        auto&& s_p6 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms_p7 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        return run_to_end(fold_job(arms_p7, true, ({
            auto acc_p2_1 = acc_p2;
            auto s_p6_2 = prism_rtl::deref(prism_rtl::deref(s_p6));
            auto m_p0_3 = m_p0;
            auto i_p1_4 = i_p1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Arm>)>>(prism_rtl::rc([=, acc_p2_1 = std::move(acc_p2_1), s_p6_2 = std::move(s_p6_2), m_p0_3 = std::move(m_p0_3), i_p1_4 = std::move(i_p1_4)](std::tuple<bool, crate::syntax::Arm> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto acc_p2_1_5 = acc_p2_1;
                auto s_p6_2_5 = s_p6_2;
                auto m_p0_3_5 = m_p0_3;
                auto i_p1_4_5 = i_p1_4;
                entered(once_job([=, acc_p2_1_5 = std::move(acc_p2_1_5), s_p6_2_5 = std::move(s_p6_2_5), m_p0_3_5 = std::move(m_p0_3_5), i_p1_4_5 = std::move(i_p1_4_5)]() {
                return ({
                    auto ok_p8 = p0;
                    auto a_p9 = p1;
                    (prism_rtl::finished((std::move(ok_p8) && (!crate::check::types::has_text(opt_names(prism_rtl::deref(a_p9).pattern), acc_p2_1_5))) && builds_on_block(crate::check::shrink::relations::arm_pat_rels(s_p6_2_5, a_p9, m_p0_3_5), i_p1_4_5, acc_p2_1_5, prism_rtl::deref(a_p9).body)));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2)) {
        auto&& c_pa = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& t_pb = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& el_pc = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
        return ((!crate::check::types::has_text(cond_names(prism_rtl::deref(prism_rtl::deref(c_pa))), acc_p2)) && builds_on_block(crate::check::shrink::relations::cond_rels(prism_rtl::deref(prism_rtl::deref(c_pa)), m_p0), i_p1, acc_p2, t_pb)) && builds_on_block(m_p0, i_p1, acc_p2, el_pc);
    }
    {
        auto&& _m = crate::check::shrink::walk::call_of(e_p3);
        if (prism_rtl::is_some(_m)) {
            auto&& c_pd = std::get<0>(prism_rtl::some_of(_m));
            auto&& args_pe = std::get<1>(prism_rtl::some_of(_m));
            return builds_on_call(m_p0, i_p1, acc_p2, c_pd, args_pe);
        }
        if (prism_rtl::is_none(_m)) {
            return false;
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<bool> BuildsOn::cycle() const {
    const auto& m_p0 = this->m_p0;
    const auto& i_p1 = this->i_p1;
    const auto& acc_p2 = this->acc_p2;
    const auto& e_p3 = this->e_p3;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p3).kind);
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n_p4 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        prism_rtl::finished(crate::check::env::sname_key(n_p4) == acc_p2);
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x_p5 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(BuildsOn(m_p0, i_p1, acc_p2, prism_rtl::deref(prism_rtl::deref(x_p5)))));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
        auto&& s_p6 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms_p7 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        fold_job(arms_p7, true, ({
        auto acc_p2_1 = acc_p2;
        auto s_p6_2 = prism_rtl::deref(prism_rtl::deref(s_p6));
        auto m_p0_3 = m_p0;
        auto i_p1_4 = i_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Arm>)>>(prism_rtl::rc([=, acc_p2_1 = std::move(acc_p2_1), s_p6_2 = std::move(s_p6_2), m_p0_3 = std::move(m_p0_3), i_p1_4 = std::move(i_p1_4)](std::tuple<bool, crate::syntax::Arm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto acc_p2_1_5 = acc_p2_1;
            auto s_p6_2_5 = s_p6_2;
            auto m_p0_3_5 = m_p0_3;
            auto i_p1_4_5 = i_p1_4;
            entered(once_job([=, acc_p2_1_5 = std::move(acc_p2_1_5), s_p6_2_5 = std::move(s_p6_2_5), m_p0_3_5 = std::move(m_p0_3_5), i_p1_4_5 = std::move(i_p1_4_5)]() {
            return ({
                auto ok_p8 = p0;
                auto a_p9 = p1;
                (prism_rtl::finished((std::move(ok_p8) && (!crate::check::types::has_text(opt_names(prism_rtl::deref(a_p9).pattern), acc_p2_1_5))) && builds_on_block(crate::check::shrink::relations::arm_pat_rels(s_p6_2_5, a_p9, m_p0_3_5), i_p1_4_5, acc_p2_1_5, prism_rtl::deref(a_p9).body)));
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2) ? ({
        auto&& c_pa = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& t_pb = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& el_pc = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
        ({
        auto acc_p2_1 = acc_p2;
        auto c_pa_2 = prism_rtl::deref(prism_rtl::deref(c_pa));
        auto el_pc_3 = el_pc;
        auto i_p1_4 = i_p1;
        auto m_p0_5 = m_p0;
        auto t_pb_6 = t_pb;
        call_then(start_cond_names(c_pa_2), [=, acc_p2_1 = std::move(acc_p2_1), el_pc_3 = std::move(el_pc_3), i_p1_4 = std::move(i_p1_4), m_p0_5 = std::move(m_p0_5), t_pb_6 = std::move(t_pb_6)](Array<Text> cond_names_5750) { return prism_rtl::finished(((!crate::check::types::has_text(cond_names_5750, acc_p2_1)) && builds_on_block(crate::check::shrink::relations::cond_rels(c_pa_2, m_p0_5), i_p1_4, acc_p2_1, t_pb_6)) && builds_on_block(m_p0_5, i_p1_4, acc_p2_1, el_pc_3)); });
    });
    })
        : ({
        auto&& _m = crate::check::shrink::walk::call_of(e_p3);
        prism_rtl::is_some(_m) ? ({
        auto&& c_pd = std::get<0>(prism_rtl::some_of(_m));
        auto&& args_pe = std::get<1>(prism_rtl::some_of(_m));
        prism_rtl::more(prism_rtl::rc(BuildsOnCall(m_p0, i_p1, acc_p2, c_pd, args_pe)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
        : throw prism_rtl::Panic("no arm matched");
    });
    });
}


/// `Start BuildsOn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_builds_on(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, Text acc_p2, crate::syntax::Expr e_p3) {
    return prism_rtl::make_rc<BuildsOn>(m_p0, i_p1, acc_p2, e_p3);
}


/// BuildsOnCall: unbounded fn (Text ==> Rel), Nat, Text, Expr, [Arg] -> Bool
bool builds_on_call(const Map<Text, crate::check::shrink::Rel>& m_p0, const Nat& i_p1, const Text& acc_p2, const crate::syntax::Expr& c_p3, const Array<crate::syntax::Arg>& args_p4) {
    auto f_p5 = crate::check::shrink::locals::expr_name(c_p3);
    auto on_acc_p6 = builds_on(m_p0, i_p1, acc_p2, or_(index(args_p4, Nat(0u)), dummy_arg())->value);
    auto rest_p7 = each(drop(args_p4, Nat(1u)), [&](const crate::syntax::Arg& a_p9) { return a_p9->value; });
    auto parts_p8 = run_to_end(fold_job(rest_p7, true, ({
        auto m_p0_1 = m_p0;
        auto i_p1_2 = i_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Expr>)>>(prism_rtl::rc([=, m_p0_1 = std::move(m_p0_1), i_p1_2 = std::move(i_p1_2)](std::tuple<bool, crate::syntax::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_p0_1_3 = m_p0_1;
            auto i_p1_2_3 = i_p1_2;
            entered(once_job([=, m_p0_1_3 = std::move(m_p0_1_3), i_p1_2_3 = std::move(i_p1_2_3)]() {
            return ({
                auto ok_pa = p0;
                auto x_pb = p1;
                (prism_rtl::finished(std::move(ok_pa) && part(m_p0_1_3, i_p1_2_3, x_pb)));
            });
        }));
        });
    })));
    })));
    return !std::move(on_acc_p6)
        ? false
        : crate::check::shrink::relations::pre_is(m_p0, f_p5, Text::lit("Push")) && (len(rest_p7) == Nat(1u))
        ? std::move(parts_p8)
        : crate::check::shrink::relations::pre_is(m_p0, f_p5, Text::lit("Insert")) && (len(rest_p7) == Nat(2u))
        ? std::move(parts_p8)
        : crate::check::shrink::relations::pre_is(m_p0, f_p5, Text::lit("Append")) && (len(rest_p7) == Nat(1u))
        ? within(m_p0, i_p1, or_(index(rest_p7, Nat(0u)), dummy_arg()->value))
        : false;
}


prism_rtl::Turn<bool> BuildsOnCall::cycle() const {
    const auto& m_p0 = this->m_p0;
    const auto& i_p1 = this->i_p1;
    const auto& acc_p2 = this->acc_p2;
    const auto& c_p3 = this->c_p3;
    const auto& args_p4 = this->args_p4;
    auto f_p5 = crate::check::shrink::locals::expr_name(c_p3);
    auto acc_p2_1 = acc_p2;
    auto args_p4_2 = args_p4;
    auto i_p1_3 = i_p1;
    auto m_p0_4 = m_p0;
    return call_then(start_builds_on(m_p0_4, i_p1_3, acc_p2_1, or_(index(args_p4_2, Nat(0u)), dummy_arg())->value), [=](bool builds_on_6180) {
        return ({
            auto on_acc_p6 = builds_on_6180;
            auto rest_p7 = each(drop(args_p4_2, Nat(1u)), [&](const crate::syntax::Arg& a_p9) { return a_p9->value; });
            call_value(fold_job(rest_p7, true, ({
            auto m_p0_4_5 = m_p0_4;
            auto i_p1_3_5 = i_p1_3;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Expr>)>>(prism_rtl::rc([=, m_p0_4_5 = std::move(m_p0_4_5), i_p1_3_5 = std::move(i_p1_3_5)](std::tuple<bool, crate::syntax::Expr> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto m_p0_4_5_5 = m_p0_4_5;
                auto i_p1_3_5_5 = i_p1_3_5;
                entered(once_job([=, m_p0_4_5_5 = std::move(m_p0_4_5_5), i_p1_3_5_5 = std::move(i_p1_3_5_5)]() {
                return ({
                    auto ok_pa = p0;
                    auto x_pb = p1;
                    (prism_rtl::finished(std::move(ok_pa) && part(m_p0_4_5_5, i_p1_3_5_5, x_pb)));
                });
            }));
            });
        })));
        })), [=, on_acc_p6 = std::move(on_acc_p6)](bool fold_6294) {
            return ({
                auto parts_p8 = fold_6294;
                !on_acc_p6
                ? prism_rtl::finished(false)
                : crate::check::shrink::relations::pre_is(m_p0_4, f_p5, Text::lit("Push")) && (len(rest_p7) == Nat(1u))
                ? prism_rtl::finished(std::move(parts_p8))
                : crate::check::shrink::relations::pre_is(m_p0_4, f_p5, Text::lit("Insert")) && (len(rest_p7) == Nat(2u))
                ? prism_rtl::finished(std::move(parts_p8))
                : crate::check::shrink::relations::pre_is(m_p0_4, f_p5, Text::lit("Append")) && (len(rest_p7) == Nat(1u))
                ? prism_rtl::more(prism_rtl::rc(Within(m_p0_4, i_p1_3, or_(index(rest_p7, Nat(0u)), dummy_arg()->value))))
                : prism_rtl::finished(false);
            });
        });
        });
    });
}


/// `Start BuildsOnCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_builds_on_call(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, Text acc_p2, crate::syntax::Expr c_p3, Array<crate::syntax::Arg> args_p4) {
    return prism_rtl::make_rc<BuildsOnCall>(m_p0, i_p1, acc_p2, c_p3, args_p4);
}


/// BuildsOnBlock: unbounded fn (Text ==> Rel), Nat, Text, Block -> Bool
bool builds_on_block(const Map<Text, crate::check::shrink::Rel>& m_p0, const Nat& i_p1, const Text& acc_p2, const crate::syntax::Block& b_p3) {
    return (!crate::check::types::has_text(crate::check::shrink::relations::stmts_binders(b_p3.stmts), acc_p2)) && builds_on(crate::check::shrink::relations::block_rels(b_p3.stmts, m_p0), i_p1, acc_p2, last_or(b_p3));
}


prism_rtl::Turn<bool> BuildsOnBlock::cycle() const {
    const auto& m_p0 = this->m_p0;
    const auto& i_p1 = this->i_p1;
    const auto& acc_p2 = this->acc_p2;
    const auto& b_p3 = this->b_p3;
    auto acc_p2_1 = acc_p2;
    auto b_p3_2 = b_p3;
    auto i_p1_3 = i_p1;
    auto m_p0_4 = m_p0;
    return call_then(crate::check::shrink::relations::start_stmts_binders(prism_rtl::deref(b_p3_2).stmts), [=](Array<Text> stmts_binders_6854) { return prism_rtl::finished((!crate::check::types::has_text(stmts_binders_6854, acc_p2_1)) && builds_on(crate::check::shrink::relations::block_rels(prism_rtl::deref(b_p3_2).stmts, m_p0_4), i_p1_3, acc_p2_1, last_or(b_p3_2))); });
}


/// `Start BuildsOnBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_builds_on_block(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, Text acc_p2, crate::syntax::Block b_p3) {
    return prism_rtl::make_rc<BuildsOnBlock>(m_p0, i_p1, acc_p2, b_p3);
}


/// CondNames: unbounded fn Cond -> [Text]
Array<Text> cond_names(const crate::syntax::Cond& cond0) {
    if (prism_rtl::is<crate::syntax::Cond::CondBind>(cond0)) {
        auto&& p_p0 = prism_rtl::as<crate::syntax::Cond::CondBind>(cond0).a0;
        return crate::check::env::names::pattern_names(p_p0);
    }
    if (prism_rtl::is<crate::syntax::Cond::CondExpr>(cond0)) {
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> CondNames::cycle() const {
    const auto& cond0 = this->cond0;
    return ({
        prism_rtl::is<crate::syntax::Cond::CondBind>(cond0) ? ({
        auto&& p_p0 = prism_rtl::as<crate::syntax::Cond::CondBind>(cond0).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::env::names::PatternNames(p_p0)));
    })
        : prism_rtl::is<crate::syntax::Cond::CondExpr>(cond0) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CondNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_cond_names(crate::syntax::Cond cond0) {
    return prism_rtl::make_rc<CondNames>(cond0);
}


/// Part: unbounded fn (Text ==> Rel), Nat, Expr -> Bool
bool part(const Map<Text, crate::check::shrink::Rel>& m_p0, const Nat& i_p1, const crate::syntax::Expr& e_p2) {
    auto&& _m = prism_rtl::deref(e_p2.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m)) {
        auto&& es_p3 = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
        return run_to_end(fold_job(es_p3, true, ({
            auto m_p0_1 = m_p0;
            auto i_p1_2 = i_p1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Expr>)>>(prism_rtl::rc([=, m_p0_1 = std::move(m_p0_1), i_p1_2 = std::move(i_p1_2)](std::tuple<bool, crate::syntax::Expr> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto m_p0_1_3 = m_p0_1;
                auto i_p1_2_3 = i_p1_2;
                entered(once_job([=, m_p0_1_3 = std::move(m_p0_1_3), i_p1_2_3 = std::move(i_p1_2_3)]() {
                return ({
                    auto ok_p4 = p0;
                    auto x_p5 = p1;
                    (prism_rtl::finished(std::move(ok_p4) && part(m_p0_1_3, i_p1_2_3, x_p5)));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p6 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return part(m_p0, i_p1, prism_rtl::deref(prism_rtl::deref(x_p6)));
    }
    {
        auto&& _m = crate::check::shrink::walk::rel_of(m_p0, e_p2);
        if (prism_rtl::is_some(_m)) {
            auto&& r_p7 = prism_rtl::some_of(_m);
            return (prism_rtl::deref(r_p7).param == i_p1) && prism_rtl::deref(r_p7).strict;
        }
        if (prism_rtl::is_none(_m)) {
            return false;
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<bool> Part::cycle() const {
    const auto& m_p0 = this->m_p0;
    const auto& i_p1 = this->i_p1;
    const auto& e_p2 = this->e_p2;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p2).kind);
        prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m) ? ({
        auto&& es_p3 = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
        fold_job(es_p3, true, ({
        auto m_p0_1 = m_p0;
        auto i_p1_2 = i_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Expr>)>>(prism_rtl::rc([=, m_p0_1 = std::move(m_p0_1), i_p1_2 = std::move(i_p1_2)](std::tuple<bool, crate::syntax::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_p0_1_3 = m_p0_1;
            auto i_p1_2_3 = i_p1_2;
            entered(once_job([=, m_p0_1_3 = std::move(m_p0_1_3), i_p1_2_3 = std::move(i_p1_2_3)]() {
            return ({
                auto ok_p4 = p0;
                auto x_p5 = p1;
                (prism_rtl::finished(std::move(ok_p4) && part(m_p0_1_3, i_p1_2_3, x_p5)));
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x_p6 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(Part(m_p0, i_p1, prism_rtl::deref(prism_rtl::deref(x_p6)))));
    })
        : ({
        auto e_p2_1 = e_p2;
        auto i_p1_2 = i_p1;
        auto m_p0_3 = m_p0;
        call_then(crate::check::shrink::walk::start_rel_of(m_p0_3, e_p2_1), [=, i_p1_2 = std::move(i_p1_2)](std::optional<crate::check::shrink::Rel> rel_of_7269) {
        return ({
            prism_rtl::is_some(rel_of_7269) ? ({
            auto&& r_p7 = prism_rtl::some_of(rel_of_7269);
            prism_rtl::finished((prism_rtl::deref(r_p7).param == i_p1_2) && prism_rtl::deref(r_p7).strict);
        })
            : prism_rtl::is_none(rel_of_7269) ? prism_rtl::finished(false)
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    });
    });
}


/// `Start Part, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_part(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, crate::syntax::Expr e_p2) {
    return prism_rtl::make_rc<Part>(m_p0, i_p1, e_p2);
}


/// SummarySeeds: unbounded fn Shrink, Def, [Spot], (Text ==> Rel) -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> summary_seeds(const crate::check::shrink::Shrink& sk_p0, const crate::check::env::Def& d_p1, const Array<crate::check::shrink::walk::Spot>& spots_p2, const Map<Text, crate::check::shrink::Rel>& rels_p3) {
    return fold(run_to_end(fold_job(spots_p2, Array<crate::check::shrink::walk::Site>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::walk::Site>>(std::tuple<Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=](std::tuple<Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_p4 = p0;
                auto sp_p5 = p1;
                call_then(crate::check::shrink::walk::start_spot_sites(sp_p5), [=, acc_p4 = std::move(acc_p4)](Array<crate::check::shrink::walk::Site> spot_sites_7945) { return prism_rtl::finished(append(acc_p4, spot_sites_7945)); });
            });
        }));
    })))), rels_p3, [&](const Map<Text, crate::check::shrink::Rel>& m_p6, const crate::check::shrink::walk::Site& site_p7) {
        return crate::check::shrink::relations::is_local(prism_rtl::deref(site_p7).rels, prism_rtl::deref(site_p7).callee)
            ? m_p6
            : ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, crate::check::shrink::Rel>> _v;
            auto&& _m = crate::check::shrink::locals::resolve_callee(sk_p0.g, d_p1.home, prism_rtl::deref(site_p7).callee);
            if (prism_rtl::is_some(_m)) {
                auto&& k_p8 = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Map<Text, crate::check::shrink::Rel>> _v;
                    auto&& _m = crate::prelude::get(sk_p0.sums, k_p8);
                    if (prism_rtl::is_some(_m)) {
                        auto&& i_p9 = prism_rtl::some_of(_m);
                        _v.set(insert(m_p6, prism_rtl::cat("fn:", prism_rtl::deref(site_p7).callee), crate::check::shrink::Rel{.param = i_p9, .strict = false}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(crate::check::shrink::walk::is_no_larger_prelude(sk_p0.g, k_p8)
                            ? insert(m_p6, prism_rtl::cat("fn:", prism_rtl::deref(site_p7).callee), crate::check::shrink::Rel{.param = Nat(0u), .strict = false})
                            : m_p6);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(m_p6);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> SummarySeeds::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& d_p1 = this->d_p1;
    const auto& spots_p2 = this->spots_p2;
    const auto& rels_p3 = this->rels_p3;
    auto d_p1_1 = d_p1;
    auto rels_p3_2 = rels_p3;
    auto sk_p0_3 = sk_p0;
    auto spots_p2_4 = spots_p2;
    return call_value(fold_job(spots_p2_4, Array<crate::check::shrink::walk::Site>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::walk::Site>>(std::tuple<Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=](std::tuple<Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_p4 = p0;
                auto sp_p5 = p1;
                call_then(crate::check::shrink::walk::start_spot_sites(sp_p5), [=, acc_p4 = std::move(acc_p4)](Array<crate::check::shrink::walk::Site> spot_sites_7945) { return prism_rtl::finished(append(acc_p4, spot_sites_7945)); });
            });
        }));
    }))), [=](Array<crate::check::shrink::walk::Site> fold_7903) {
        return prism_rtl::finished(fold(fold_7903, rels_p3_2, [&](const Map<Text, crate::check::shrink::Rel>& m_p6, const crate::check::shrink::walk::Site& site_p7) {
            return crate::check::shrink::relations::is_local(prism_rtl::deref(site_p7).rels, prism_rtl::deref(site_p7).callee)
                ? m_p6
                : ({
                __label__ _done;
                prism_rtl::Slot<Map<Text, crate::check::shrink::Rel>> _v;
                auto&& _m = crate::check::shrink::locals::resolve_callee(prism_rtl::deref(sk_p0_3).g, prism_rtl::deref(d_p1_1).home, prism_rtl::deref(site_p7).callee);
                if (prism_rtl::is_some(_m)) {
                    auto&& k_p8 = prism_rtl::some_of(_m);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Map<Text, crate::check::shrink::Rel>> _v;
                        auto&& _m = crate::prelude::get(prism_rtl::deref(sk_p0_3).sums, k_p8);
                        if (prism_rtl::is_some(_m)) {
                            auto&& i_p9 = prism_rtl::some_of(_m);
                            _v.set(insert(m_p6, prism_rtl::cat("fn:", prism_rtl::deref(site_p7).callee), crate::check::shrink::Rel{.param = i_p9, .strict = false}));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(crate::check::shrink::walk::is_no_larger_prelude(prism_rtl::deref(sk_p0_3).g, k_p8)
                                ? insert(m_p6, prism_rtl::cat("fn:", prism_rtl::deref(site_p7).callee), crate::check::shrink::Rel{.param = Nat(0u), .strict = false})
                                : m_p6);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(m_p6);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        }));
    });
}


/// `Start SummarySeeds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_summary_seeds(crate::check::shrink::Shrink sk_p0, crate::check::env::Def d_p1, Array<crate::check::shrink::walk::Spot> spots_p2, Map<Text, crate::check::shrink::Rel> rels_p3) {
    return prism_rtl::make_rc<SummarySeeds>(sk_p0, d_p1, spots_p2, rels_p3);
}


/// OptNames: unbounded fn ?Pattern -> [Text]
Array<Text> opt_names(const std::optional<crate::syntax::Pattern_>& opt0) {
    if (prism_rtl::is_some(opt0)) {
        auto&& p_p0 = prism_rtl::some_of(opt0);
        return crate::check::env::names::pattern_names(p_p0);
    }
    if (prism_rtl::is_none(opt0)) {
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> OptNames::cycle() const {
    const auto& opt0 = this->opt0;
    return ({
        prism_rtl::is_some(opt0) ? ({
        auto&& p_p0 = prism_rtl::some_of(opt0);
        prism_rtl::more(prism_rtl::rc(crate::check::env::names::PatternNames(p_p0)));
    })
        : prism_rtl::is_none(opt0) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start OptNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_opt_names(std::optional<crate::syntax::Pattern_> opt0) {
    return prism_rtl::make_rc<OptNames>(opt0);
}


/// let dummyArg
crate::syntax::Arg dummy_arg() {
    return crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}}, .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// ?DecrementOf: unbounded fn (Text ==> Rel), Expr -> ?Rel
std::optional<crate::check::shrink::Rel> decrement_of(const Map<Text, crate::check::shrink::Rel>& m_p0, const crate::syntax::Expr& e_p1) {
    auto&& _m = prism_rtl::deref(e_p1.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
        auto&& m8753_0_0 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& l_p2 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r_p3 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        if (m8753_0_0 == Text::lit("-?")) {
            return is_positive_lit(prism_rtl::deref(prism_rtl::deref(r_p3))) && is_nat_minus(m_p0, e_p1)
                ? smaller(m_p0, prism_rtl::deref(prism_rtl::deref(l_p2)))
                : std::optional<crate::check::shrink::Rel>{};
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p4 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return decrement_of(m_p0, prism_rtl::deref(prism_rtl::deref(x_p4)));
    }
    {
        auto&& _m = crate::check::shrink::walk::call_of(e_p1);
        if (prism_rtl::is_some(_m)) {
            auto&& c_p5 = std::get<0>(prism_rtl::some_of(_m));
            auto&& args_p6 = std::get<1>(prism_rtl::some_of(_m));
            auto&& _m = crate::check::shrink::walk::callee_name(c_p5);
            if (prism_rtl::is_some(_m)) {
                auto&& n_p7 = prism_rtl::some_of(_m);
                return crate::check::shrink::relations::pre_is(m_p0, n_p7, Text::lit("?Step"))
                    ? smaller(m_p0, or_(index(args_p6, Nat(0u)), dummy_arg())->value)
                    : std::optional<crate::check::shrink::Rel>{};
            }
            if (prism_rtl::is_none(_m)) {
                return std::optional<crate::check::shrink::Rel>{};
            }
            prism_rtl::unreachable("no arm matched");
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional<crate::check::shrink::Rel>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<std::optional<crate::check::shrink::Rel>> DecrementOf::cycle() const {
    const auto& m_p0 = this->m_p0;
    const auto& e_p1 = this->e_p1;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p1).kind);
        prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m) && ({
        auto&& m8753_0_0 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& l_p2 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r_p3 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        (m8753_0_0 == Text::lit("-?"));
    }) ? ({
        auto&& m8753_0_0 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& l_p2 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r_p3 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        is_positive_lit(prism_rtl::deref(prism_rtl::deref(r_p3))) && is_nat_minus(m_p0, e_p1)
        ? prism_rtl::finished(smaller(m_p0, prism_rtl::deref(prism_rtl::deref(l_p2))))
        : prism_rtl::finished(std::optional<crate::check::shrink::Rel>{});
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x_p4 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(DecrementOf(m_p0, prism_rtl::deref(prism_rtl::deref(x_p4)))));
    })
        : ({
        auto&& _m = crate::check::shrink::walk::call_of(e_p1);
        prism_rtl::is_some(_m) ? ({
        auto&& c_p5 = std::get<0>(prism_rtl::some_of(_m));
        auto&& args_p6 = std::get<1>(prism_rtl::some_of(_m));
        ({
        auto&& _m = crate::check::shrink::walk::callee_name(c_p5);
        prism_rtl::is_some(_m) ? ({
        auto&& n_p7 = prism_rtl::some_of(_m);
        crate::check::shrink::relations::pre_is(m_p0, n_p7, Text::lit("?Step"))
        ? prism_rtl::finished(smaller(m_p0, or_(index(args_p6, Nat(0u)), dummy_arg())->value))
        : prism_rtl::finished(std::optional<crate::check::shrink::Rel>{});
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    });
}


/// `Start DecrementOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<crate::check::shrink::Rel>> start_decrement_of(Map<Text, crate::check::shrink::Rel> m_p0, crate::syntax::Expr e_p1) {
    return prism_rtl::make_rc<DecrementOf>(m_p0, e_p1);
}


/// IsNatMinus: fn (Text ==> Rel), Expr -> Bool
bool is_nat_minus(const Map<Text, crate::check::shrink::Rel>& m_p0, const crate::syntax::Expr& e_p1) {
    return crate::check::shrink::relations::pre_is(m_p0, Text::lit("-?"), Text::lit("-?")) && crate::check::shrink::walk::is_nat_at(m_p0, e_p1);
}


/// ?Smaller: unbounded fn (Text ==> Rel), Expr -> ?Rel
std::optional<crate::check::shrink::Rel> smaller(const Map<Text, crate::check::shrink::Rel>& m_p0, const crate::syntax::Expr& x_p1) {
    auto&& _m = crate::check::shrink::walk::rel_of(m_p0, x_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& r_p2 = prism_rtl::some_of(_m);
        return std::optional(crate::check::shrink::Rel{.param = prism_rtl::deref(r_p2).param, .strict = true});
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<crate::check::shrink::Rel>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// IsPositiveLit: fn Expr -> Bool
bool is_positive_lit(const crate::syntax::Expr& e_p0) {
    auto&& _m = prism_rtl::deref(e_p0.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::ELit>(_m)) {
        auto&& l_p1 = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
        auto&& _m = prism_rtl::deref(l_p1).kind;
        if (prism_rtl::is<crate::syntax::LitKind::LInt>(_m)) {
            auto&& d_p2 = prism_rtl::as<crate::syntax::LitKind::LInt>(_m).a0;
            return d_p2 != Text::lit("0");
        }
        {
            return false;
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p3 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return is_positive_lit(prism_rtl::deref(prism_rtl::deref(x_p3)));
    }
    {
        return false;
    }
}


/// Closure: unbounded fn [Sc] -> [Sc]
Array<crate::check::shrink::Sc> closure(const Array<crate::check::shrink::Sc>& graphs_p0) {
    return closure_from(graphs_p0, dedup(graphs_p0), dedup(graphs_p0));
}


prism_rtl::Turn<Array<crate::check::shrink::Sc>> Closure::cycle() const {
    const auto& graphs_p0 = this->graphs_p0;
    return prism_rtl::more(prism_rtl::rc(ClosureFrom(graphs_p0, dedup(graphs_p0), dedup(graphs_p0))));
}


/// `Start Closure, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::check::shrink::Sc>> start_closure(Array<crate::check::shrink::Sc> graphs_p0) {
    return prism_rtl::make_rc<Closure>(graphs_p0);
}


/// Dedup: fn [Sc] -> [Sc]
Array<crate::check::shrink::Sc> dedup(const Array<crate::check::shrink::Sc>& gs_p0) {
    return fold(gs_p0, Array<crate::check::shrink::Sc>{}, [&](const Array<crate::check::shrink::Sc>& acc_p1, const crate::check::shrink::Sc& g_p2) { return has_sc(acc_p1, g_p2) ? acc_p1 : crate::prelude::push(acc_p1, g_p2); });
}


/// ClosureFrom: unbounded fn [Sc], [Sc], [Sc] -> [Sc]
Array<crate::check::shrink::Sc> closure_from(const Array<crate::check::shrink::Sc>& base_p0, const Array<crate::check::shrink::Sc>& acc_p1, const Array<crate::check::shrink::Sc>& frontier_p2) {
    auto fresh_p3 = fold(frontier_p2, Array<crate::check::shrink::Sc>{}, [&](const Array<crate::check::shrink::Sc>& out_p4, const crate::check::shrink::Sc& a_p5) { return fold(base_p0, out_p4, [&](const Array<crate::check::shrink::Sc>& out2_p6, const crate::check::shrink::Sc& b_p7) { return add_composed(acc_p1, out2_p6, a_p5, b_p7); }); });
    return len(fresh_p3) == Nat(0u)
        ? acc_p1
        : closure_from(base_p0, append(acc_p1, fresh_p3), fresh_p3);
}


prism_rtl::Turn<Array<crate::check::shrink::Sc>> ClosureFrom::cycle() const {
    const auto& base_p0 = this->base_p0;
    const auto& acc_p1 = this->acc_p1;
    const auto& frontier_p2 = this->frontier_p2;
    auto fresh_p3 = fold(frontier_p2, Array<crate::check::shrink::Sc>{}, [&](const Array<crate::check::shrink::Sc>& out_p4, const crate::check::shrink::Sc& a_p5) { return fold(base_p0, out_p4, [&](const Array<crate::check::shrink::Sc>& out2_p6, const crate::check::shrink::Sc& b_p7) { return add_composed(acc_p1, out2_p6, a_p5, b_p7); }); });
    return len(fresh_p3) == Nat(0u)
        ? prism_rtl::finished(acc_p1)
        : prism_rtl::more(prism_rtl::rc(ClosureFrom(base_p0, append(acc_p1, fresh_p3), fresh_p3)));
}


/// `Start ClosureFrom, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::check::shrink::Sc>> start_closure_from(Array<crate::check::shrink::Sc> base_p0, Array<crate::check::shrink::Sc> acc_p1, Array<crate::check::shrink::Sc> frontier_p2) {
    return prism_rtl::make_rc<ClosureFrom>(base_p0, acc_p1, frontier_p2);
}


/// AddComposed: fn [Sc], [Sc], Sc, Sc -> [Sc]
Array<crate::check::shrink::Sc> add_composed(const Array<crate::check::shrink::Sc>& acc_p0, const Array<crate::check::shrink::Sc>& out_p1, const crate::check::shrink::Sc& a_p2, const crate::check::shrink::Sc& b_p3) {
    return a_p2.callee != b_p3.caller
        ? out_p1
        : ({
        auto c_p4 = compose(a_p2, b_p3);
        has_sc(acc_p0, c_p4) || has_sc(out_p1, c_p4)
        ? out_p1
        : crate::prelude::push(out_p1, c_p4);
    });
}


/// HasSc: fn [Sc], Sc -> Bool
bool has_sc(const Array<crate::check::shrink::Sc>& xs_p0, const crate::check::shrink::Sc& c_p1) {
    return fold(xs_p0, false, [&](const bool& seen_p2, const crate::check::shrink::Sc& x_p3) { return prism_rtl::deref(seen_p2) || (((prism_rtl::deref(x_p3).caller == c_p1.caller) && (prism_rtl::deref(x_p3).callee == c_p1.callee)) && (x_p3->edges == c_p1.edges)); });
}


/// Compose: fn Sc, Sc -> Sc
crate::check::shrink::Sc compose(const crate::check::shrink::Sc& a_p0, const crate::check::shrink::Sc& b_p1) {
    auto pairs_p2 = fold(a_p0.edges, Array<std::tuple<Nat, Nat, bool>>{}, [&](const Array<std::tuple<Nat, Nat, bool>>& acc_p3, const std::tuple<Nat, Nat, bool>& _p1) {
        auto&& x_p4 = std::get<0>(_p1);
        auto&& y_p5 = std::get<1>(_p1);
        auto&& s1_p6 = std::get<2>(_p1);
        return fold(b_p1.edges, acc_p3, [&](const Array<std::tuple<Nat, Nat, bool>>& acc2_p7, const std::tuple<Nat, Nat, bool>& _p1) {
            auto&& y2_p8 = std::get<0>(_p1);
            auto&& z_p9 = std::get<1>(_p1);
            auto&& s2_pa = std::get<2>(_p1);
            return y_p5 == y2_p8
                ? add_edge(acc2_p7, x_p4, z_p9, prism_rtl::deref(s1_p6) || prism_rtl::deref(s2_pa))
                : acc2_p7;
        });
    });
    return crate::check::shrink::Sc{.caller = a_p0.caller, .callee = b_p1.callee, .edges = sort_edges(pairs_p2), .span = a_p0.span, .file = a_p0.file, .arg = a_p0.arg};
}


/// AddEdge: fn [((Nat, Nat, Bool))], Nat, Nat, Bool -> [((Nat, Nat, Bool))]
Array<std::tuple<Nat, Nat, bool>> add_edge(const Array<std::tuple<Nat, Nat, bool>>& es_p0, const Nat& x_p1, const Nat& z_p2, const bool& s_p3) {
    auto others_p4 = filter(es_p0, [&](const std::tuple<Nat, Nat, bool>& _p0) {
        auto&& a_p6 = std::get<0>(_p0);
        auto&& b_p7 = std::get<1>(_p0);
        return !((a_p6 == x_p1) && (b_p7 == z_p2));
    });
    auto had_p5 = fold(es_p0, false, [&](const bool& seen_p8, const std::tuple<Nat, Nat, bool>& _p1) {
        auto&& a_p9 = std::get<0>(_p1);
        auto&& b_pa = std::get<1>(_p1);
        auto&& t_pb = std::get<2>(_p1);
        return prism_rtl::deref(seen_p8) || (((a_p9 == x_p1) && (b_pa == z_p2)) && prism_rtl::deref(t_pb));
    });
    return crate::prelude::push(others_p4, std::tuple{x_p1, z_p2, s_p3 || std::move(had_p5)});
}


/// SortEdges: fn [((Nat, Nat, Bool))] -> [((Nat, Nat, Bool))]
Array<std::tuple<Nat, Nat, bool>> sort_edges(const Array<std::tuple<Nat, Nat, bool>>& es_p0) {
    return fold(es_p0, Array<std::tuple<Nat, Nat, bool>>{}, [&](const Array<std::tuple<Nat, Nat, bool>>& acc_p1, const std::tuple<Nat, Nat, bool>& e_p2) { return append(crate::prelude::push(filter(acc_p1, [&](const std::tuple<Nat, Nat, bool>& x_p3) { return edge_before(x_p3, e_p2); }), e_p2), filter(acc_p1, [&](const std::tuple<Nat, Nat, bool>& x_p4) { return !edge_before(x_p4, e_p2); })); });
}


/// EdgeBefore: fn ((Nat, Nat, Bool)), ((Nat, Nat, Bool)) -> Bool
bool edge_before(const std::tuple<Nat, Nat, bool>& arg0, const std::tuple<Nat, Nat, bool>& arg1) {
    auto&& _m = std::tuple{arg0, arg1};
    {
        auto&& a1_p0 = std::get<0>(std::get<0>(_m));
        auto&& b1_p1 = std::get<1>(std::get<0>(_m));
        auto&& a2_p2 = std::get<0>(std::get<1>(_m));
        auto&& b2_p3 = std::get<1>(std::get<1>(_m));
        return (a1_p0 < a2_p2) || ((a1_p0 == a2_p2) && (b1_p1 < b2_p3));
    }
    prism_rtl::unreachable("no arm matched");
}


/// LoopsOf: unbounded fn Shrink, St, Def -> St
crate::check::types::St loops_of(const crate::check::shrink::Shrink& sk_p0, const crate::check::types::St& st_p1, const crate::check::env::Def& d_p2) {
    auto unb_p3 = crate::check::shrink::types::is_unbounded_key(sk_p0.g, crate::check::shrink::types::sig_key_of(sk_p0, d_p2.qk));
    return std::move(unb_p3) && (!st_p1.recording)
        ? st_p1
        : ({
        auto s0_p4 = ({
            crate::check::types::St this_ = st_p1;
            this_.file = d_p2.file;
            (std::move(this_));
        });
        auto s1_p5 = run_to_end(fold_job(crate::check::shrink::types::def_clauses(d_p2), s0_p4, ({
            auto sk_p0_1 = sk_p0;
            auto d_p2_2 = d_p2;
            auto unb_p3_3 = std::move(unb_p3);
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, sk_p0_1 = std::move(sk_p0_1), d_p2_2 = std::move(d_p2_2), unb_p3_3 = std::move(unb_p3_3)](std::tuple<crate::check::types::St, crate::syntax::decls::FnClause> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto sk_p0_1_4 = sk_p0_1;
                auto d_p2_2_4 = d_p2_2;
                auto unb_p3_3_4 = unb_p3_3;
                entered(once_job([=, sk_p0_1_4 = std::move(sk_p0_1_4), d_p2_2_4 = std::move(d_p2_2_4), unb_p3_3_4 = std::move(unb_p3_3_4)]() {
                return ({
                    auto s_p6 = p0;
                    auto c_p7 = p1;
                    (prism_rtl::more(prism_rtl::rc(ClauseLoops(sk_p0_1_4, s_p6, d_p2_2_4, c_p7, unb_p3_3_4))));
                });
            }));
            });
        })));
        })));
        ({
        crate::check::types::St this_ = s1_p5;
        this_.file = st_p1.file;
        (std::move(this_));
    });
    });
}


prism_rtl::Turn<crate::check::types::St> LoopsOf::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& st_p1 = this->st_p1;
    const auto& d_p2 = this->d_p2;
    auto unb_p3 = crate::check::shrink::types::is_unbounded_key(prism_rtl::deref(sk_p0).g, crate::check::shrink::types::sig_key_of(sk_p0, prism_rtl::deref(d_p2).qk));
    return std::move(unb_p3) && (!prism_rtl::deref(st_p1).recording)
        ? prism_rtl::finished(st_p1)
        : ({
        auto s0_p4 = ({
            crate::check::types::St this_ = st_p1;
            this_.file = d_p2->file;
            (std::move(this_));
        });
        auto d_p2_1 = d_p2;
        auto sk_p0_2 = sk_p0;
        auto st_p1_3 = st_p1;
        call_value(fold_job(crate::check::shrink::types::def_clauses(d_p2_1), s0_p4, ({
        auto sk_p0_2_4 = sk_p0_2;
        auto d_p2_1_4 = d_p2_1;
        auto unb_p3_4 = std::move(unb_p3);
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, sk_p0_2_4 = std::move(sk_p0_2_4), d_p2_1_4 = std::move(d_p2_1_4), unb_p3_4 = std::move(unb_p3_4)](std::tuple<crate::check::types::St, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_p0_2_4_5 = sk_p0_2_4;
            auto d_p2_1_4_5 = d_p2_1_4;
            auto unb_p3_4_5 = unb_p3_4;
            entered(once_job([=, sk_p0_2_4_5 = std::move(sk_p0_2_4_5), d_p2_1_4_5 = std::move(d_p2_1_4_5), unb_p3_4_5 = std::move(unb_p3_4_5)]() {
            return ({
                auto s_p6 = p0;
                auto c_p7 = p1;
                (prism_rtl::more(prism_rtl::rc(ClauseLoops(sk_p0_2_4_5, s_p6, d_p2_1_4_5, c_p7, unb_p3_4_5))));
            });
        }));
        });
    })));
    })), [=, st_p1_3 = std::move(st_p1_3)](crate::check::types::St fold_12724) {
        return ({
            auto s1_p5 = fold_12724;
            (prism_rtl::finished(({
            crate::check::types::St this_ = s1_p5;
            this_.file = st_p1_3->file;
            (std::move(this_));
        })));
        });
    });
    });
}


/// `Start LoopsOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_loops_of(crate::check::shrink::Shrink sk_p0, crate::check::types::St st_p1, crate::check::env::Def d_p2) {
    return prism_rtl::make_rc<LoopsOf>(sk_p0, st_p1, d_p2);
}


/// ClauseLoops: unbounded fn Shrink, St, Def, FnClause, Bool -> St
crate::check::types::St clause_loops(const crate::check::shrink::Shrink& sk_p0, const crate::check::types::St& st_p1, const crate::check::env::Def& d_p2, const crate::syntax::decls::FnClause& c_p3, const bool& unb_p4) {
    auto base_p5 = crate::check::shrink::locals::clause_base(sk_p0, d_p2, c_p3);
    auto spots0_p6 = crate::check::shrink::walk::body_spots(c_p3.body, base_p5);
    return !fold(spots0_p6, false, [&](const bool& seen_p7, const crate::check::shrink::walk::Spot& sp_p8) { return prism_rtl::deref(seen_p7) || is_while_spot(sp_p8); })
        ? st_p1
        : ({
        auto spots_p9 = crate::check::shrink::walk::body_spots(c_p3.body, summary_seeds(sk_p0, d_p2, spots0_p6, base_p5));
        run_to_end(fold_job(filter(spots_p9, [&](const crate::check::shrink::walk::Spot& sp_pa) { return is_while_spot(sp_pa); }), st_p1, ({
        auto d_p2_1 = d_p2;
        auto unb_p4_2 = unb_p4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=, d_p2_1 = std::move(d_p2_1), unb_p4_2 = std::move(unb_p4_2)](std::tuple<crate::check::types::St, crate::check::shrink::walk::Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto d_p2_1_3 = d_p2_1;
            auto unb_p4_2_3 = unb_p4_2;
            entered(once_job([=, d_p2_1_3 = std::move(d_p2_1_3), unb_p4_2_3 = std::move(unb_p4_2_3)]() {
            return ({
                auto s_pb = p0;
                auto sp_pc = p1;
                ({
                prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(sp_pc) ? ({
                auto&& w_pd = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(sp_pc).a0;
                auto&& m_pe = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(sp_pc).a1;
                ({
                auto&& _m = prism_rtl::deref(w_pd).kind;
                prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m) ? ({
                auto&& cond_pf = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
                auto&& body_pg = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
                prism_rtl::more(prism_rtl::rc(CheckWhile(s_pb, cond_pf, body_pg, prism_rtl::deref(w_pd).span, d_p2_1_3.name, marks(m_pe), unb_p4_2_3)));
            })
                : prism_rtl::finished(s_pb);
            });
            })
                : prism_rtl::finished(s_pb);
            });
            });
        }));
        });
    })));
    })));
    });
}


prism_rtl::Turn<crate::check::types::St> ClauseLoops::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& st_p1 = this->st_p1;
    const auto& d_p2 = this->d_p2;
    const auto& c_p3 = this->c_p3;
    const auto& unb_p4 = this->unb_p4;
    auto c_p3_1 = c_p3;
    auto d_p2_2 = d_p2;
    auto sk_p0_3 = sk_p0;
    auto st_p1_4 = st_p1;
    auto unb_p4_5 = prism_rtl::deref(unb_p4);
    return call_then(crate::check::shrink::locals::start_clause_base(sk_p0_3, d_p2_2, c_p3_1), [=](Map<Text, crate::check::shrink::Rel> clause_base_12950) {
        return ({
            auto base_p5 = clause_base_12950;
            call_then(crate::check::shrink::walk::start_body_spots(prism_rtl::deref(c_p3_1).body, base_p5), [=](Array<crate::check::shrink::walk::Spot> body_spots_12987) {
            return ({
                auto spots0_p6 = body_spots_12987;
                !fold(spots0_p6, false, [&](const bool& seen_p7, const crate::check::shrink::walk::Spot& sp_p8) { return prism_rtl::deref(seen_p7) || is_while_spot(sp_p8); })
                ? prism_rtl::finished(st_p1_4)
                : call_then(start_summary_seeds(sk_p0_3, d_p2_2, spots0_p6, base_p5), [=](Map<Text, crate::check::shrink::Rel> summary_seeds_13131) {
                return call_then(crate::check::shrink::walk::start_body_spots(prism_rtl::deref(c_p3_1).body, summary_seeds_13131), [=](Array<crate::check::shrink::walk::Spot> body_spots_13112) {
                    return ({
                        auto spots_p9 = body_spots_13112;
                        fold_job(filter(spots_p9, [&](const crate::check::shrink::walk::Spot& sp_pa) { return is_while_spot(sp_pa); }), st_p1_4, ({
                        auto d_p2_2_6 = d_p2_2;
                        auto unb_p4_5_6 = unb_p4_5;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=, d_p2_2_6 = std::move(d_p2_2_6), unb_p4_5_6 = std::move(unb_p4_5_6)](std::tuple<crate::check::types::St, crate::check::shrink::walk::Spot> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto d_p2_2_6_6 = d_p2_2_6;
                            auto unb_p4_5_6_6 = unb_p4_5_6;
                            entered(once_job([=, d_p2_2_6_6 = std::move(d_p2_2_6_6), unb_p4_5_6_6 = std::move(unb_p4_5_6_6)]() {
                            return ({
                                auto s_pb = p0;
                                auto sp_pc = p1;
                                ({
                                prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(sp_pc) ? ({
                                auto&& w_pd = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(sp_pc).a0;
                                auto&& m_pe = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(sp_pc).a1;
                                ({
                                auto&& _m = prism_rtl::deref(w_pd).kind;
                                prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m) ? ({
                                auto&& cond_pf = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
                                auto&& body_pg = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
                                prism_rtl::more(prism_rtl::rc(CheckWhile(s_pb, cond_pf, body_pg, prism_rtl::deref(w_pd).span, prism_rtl::deref(d_p2_2_6_6).name, marks(m_pe), unb_p4_5_6_6)));
                            })
                                : prism_rtl::finished(s_pb);
                            });
                            })
                                : prism_rtl::finished(s_pb);
                            });
                            });
                        }));
                        });
                    })));
                    }))->cycle();
                    });
                });
            });
            });
        });
        });
    });
}


/// `Start ClauseLoops, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_clause_loops(crate::check::shrink::Shrink sk_p0, crate::check::types::St st_p1, crate::check::env::Def d_p2, crate::syntax::decls::FnClause c_p3, bool unb_p4) {
    return prism_rtl::make_rc<ClauseLoops>(sk_p0, st_p1, d_p2, c_p3, unb_p4);
}


/// Marks: fn (Text ==> Rel) -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> marks(const Map<Text, crate::check::shrink::Rel>& m_p0) {
    return fold(keys(m_p0), m_p0, [&](const Map<Text, crate::check::shrink::Rel>& m2_p1, const Text& k_p2) {
        return crate::syntax::lexer::chars::contains(k_p2, Text::lit(":"))
            ? m2_p1
            : crate::prelude::remove(m2_p1, k_p2);
    });
}


/// IsWhileSpot: fn Spot -> Bool
bool is_while_spot(const crate::check::shrink::walk::Spot& spot0) {
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(spot0)) {
        auto&& s_p0 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(spot0).a0;
        auto&& _m = prism_rtl::deref(s_p0).kind;
        if (prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m)) {
            return true;
        }
        {
            return false;
        }
    }
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotExpr>(spot0)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// CheckWhile: unbounded fn St, Cond, Block, Range, Text, (Text ==> Rel), Bool -> St
crate::check::types::St check_while(const crate::check::types::St& st_p0, const crate::syntax::Cond& c_p1, const crate::syntax::Block& body_p2, const crate::syntax::Range& span_p3, const Text& name_p4, const Map<Text, crate::check::shrink::Rel>& seeds_p5, const bool& unb_p6) {
    auto vars_p7 = set_targets(body_p2.stmts);
    auto base_p8 = fold(crate::check::errors::range0(len(vars_p7)), seeds_p5, [&](const Map<Text, crate::check::shrink::Rel>& m_pb, const Nat& i_pc) { return insert(m_pb, or_(index(vars_p7, i_pc), Text::lit("")), crate::check::shrink::Rel{.param = i_pc, .strict = false}); });
    auto rels_p9 = crate::check::shrink::relations::cond_rels(c_p1, base_p8);
    auto ok_pa = run_to_end(fold_job(crate::check::errors::range0(len(vars_p7)), false, ({
        auto body_p2_1 = body_p2;
        auto vars_p7_2 = vars_p7;
        auto rels_p9_3 = rels_p9;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Nat>)>>(prism_rtl::rc([=, body_p2_1 = std::move(body_p2_1), vars_p7_2 = std::move(vars_p7_2), rels_p9_3 = std::move(rels_p9_3)](std::tuple<bool, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto body_p2_1_4 = body_p2_1;
            auto vars_p7_2_4 = vars_p7_2;
            auto rels_p9_3_4 = rels_p9_3;
            entered(once_job([=, body_p2_1_4 = std::move(body_p2_1_4), vars_p7_2_4 = std::move(vars_p7_2_4), rels_p9_3_4 = std::move(rels_p9_3_4)]() {
            return ({
                auto seen_pd = p0;
                auto i_pe = p1;
                (prism_rtl::finished(std::move(seen_pd) || all_paths_strict(body_p2_1_4.stmts, or_(index(vars_p7_2_4, i_pe), Text::lit("")), i_pe, rels_p9_3_4)));
            });
        }));
        });
    })));
    })));
    return std::move(ok_pa)
        ? st_p0
        : unb_p6
        ? note_unshrunk(st_p0, span_p3)
        : crate::check::types::recording::err_fix(st_p0, Text::lit("may-not-end"), span_p3, prism_rtl::cat("this loop in `", name_p4, "` may not end: nothing it sets gets smaller on every turn"), prism_rtl::cat("set a local from `&x -? 1` through a pattern, as `while ? left <- &fuel -? 1:`, or mark `", name_p4, "` `unbounded fn`"));
}


prism_rtl::Turn<crate::check::types::St> CheckWhile::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& c_p1 = this->c_p1;
    const auto& body_p2 = this->body_p2;
    const auto& span_p3 = this->span_p3;
    const auto& name_p4 = this->name_p4;
    const auto& seeds_p5 = this->seeds_p5;
    const auto& unb_p6 = this->unb_p6;
    auto body_p2_1 = body_p2;
    auto c_p1_2 = c_p1;
    auto name_p4_3 = name_p4;
    auto seeds_p5_4 = seeds_p5;
    auto span_p3_5 = span_p3;
    auto st_p0_6 = st_p0;
    auto unb_p6_7 = prism_rtl::deref(unb_p6);
    return call_then(start_set_targets(prism_rtl::deref(body_p2_1).stmts), [=](Array<Text> set_targets_14238) {
        return ({
            auto vars_p7 = set_targets_14238;
            auto base_p8 = fold(crate::check::errors::range0(len(vars_p7)), seeds_p5_4, [&](const Map<Text, crate::check::shrink::Rel>& m_pb, const Nat& i_pc) { return insert(m_pb, or_(index(vars_p7, i_pc), Text::lit("")), crate::check::shrink::Rel{.param = i_pc, .strict = false}); });
            call_then(crate::check::shrink::relations::start_cond_rels(c_p1_2, base_p8), [=, vars_p7 = std::move(vars_p7)](Map<Text, crate::check::shrink::Rel> cond_rels_14552) {
            return ({
                auto rels_p9 = cond_rels_14552;
                call_value(fold_job(crate::check::errors::range0(len(vars_p7)), false, ({
                auto body_p2_1_8 = body_p2_1;
                auto vars_p7_8 = vars_p7;
                auto rels_p9_9 = rels_p9;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Nat>)>>(prism_rtl::rc([=, body_p2_1_8 = std::move(body_p2_1_8), vars_p7_8 = std::move(vars_p7_8), rels_p9_9 = std::move(rels_p9_9)](std::tuple<bool, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto body_p2_1_8_10 = body_p2_1_8;
                    auto vars_p7_8_10 = vars_p7_8;
                    auto rels_p9_9_10 = rels_p9_9;
                    entered(once_job([=, body_p2_1_8_10 = std::move(body_p2_1_8_10), vars_p7_8_10 = std::move(vars_p7_8_10), rels_p9_9_10 = std::move(rels_p9_9_10)]() {
                    return ({
                        auto seen_pd = p0;
                        auto i_pe = p1;
                        (prism_rtl::finished(std::move(seen_pd) || all_paths_strict(prism_rtl::deref(body_p2_1_8_10).stmts, or_(index(vars_p7_8_10, i_pe), Text::lit("")), i_pe, rels_p9_9_10)));
                    });
                }));
                });
            })));
            })), [=](bool fold_14582) {
                return ({
                    auto ok_pa = fold_14582;
                    (std::move(ok_pa)
                    ? prism_rtl::finished(st_p0_6)
                    : unb_p6_7
                    ? prism_rtl::finished(note_unshrunk(st_p0_6, span_p3_5))
                    : prism_rtl::finished(crate::check::types::recording::err_fix(st_p0_6, Text::lit("may-not-end"), span_p3_5, prism_rtl::cat("this loop in `", name_p4_3, "` may not end: nothing it sets gets smaller on every turn"), prism_rtl::cat("set a local from `&x -? 1` through a pattern, as `while ? left <- &fuel -? 1:`, or mark `", name_p4_3, "` `unbounded fn`"))));
                });
            });
            });
        });
        });
    });
}


/// `Start CheckWhile, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_while(crate::check::types::St st_p0, crate::syntax::Cond c_p1, crate::syntax::Block body_p2, crate::syntax::Range span_p3, Text name_p4, Map<Text, crate::check::shrink::Rel> seeds_p5, bool unb_p6) {
    return prism_rtl::make_rc<CheckWhile>(st_p0, c_p1, body_p2, span_p3, name_p4, seeds_p5, unb_p6);
}


/// NoteUnshrunk: fn St, Range -> St
crate::check::types::St note_unshrunk(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1) {
    crate::check::types::St this_ = st_p0;
    prism_rtl::deref(this_.typed).unshrunk = crate::prelude::push(prism_rtl::deref(this_.typed).unshrunk, crate::check::types::recording::at_here(st_p0, span_p1));
    return this_;
}


/// SetTargets: unbounded fn [Stmt] -> [Text]
Array<Text> set_targets(const Array<crate::syntax::Stmt>& stmts_p0) {
    return run_to_end(fold_job(crate::check::shrink::walk::stmts_spots(stmts_p0, Map<Text, crate::check::shrink::Rel>{}), Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::shrink::walk::Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_p1 = p0;
                auto sp_p2 = p1;
                call_then(start_spot_set_root(sp_p2), [=, acc_p1 = std::move(acc_p1)](Array<Text> spot_set_root_15448) { return prism_rtl::finished(crate::check::types::union_texts(acc_p1, spot_set_root_15448)); });
            });
        }));
    }))));
}


prism_rtl::Turn<Array<Text>> SetTargets::cycle() const {
    const auto& stmts_p0 = this->stmts_p0;
    auto stmts_p0_1 = stmts_p0;
    return call_then(crate::check::shrink::walk::start_stmts_spots(stmts_p0_1, Map<Text, crate::check::shrink::Rel>{}), [=](Array<crate::check::shrink::walk::Spot> stmts_spots_15391) {
        return fold_job(stmts_spots_15391, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::shrink::walk::Spot> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc_p1 = p0;
                    auto sp_p2 = p1;
                    call_then(start_spot_set_root(sp_p2), [=, acc_p1 = std::move(acc_p1)](Array<Text> spot_set_root_15448) { return prism_rtl::finished(crate::check::types::union_texts(acc_p1, spot_set_root_15448)); });
                });
            }));
        })))->cycle();
    });
}


/// `Start SetTargets, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_set_targets(Array<crate::syntax::Stmt> stmts_p0) {
    return prism_rtl::make_rc<SetTargets>(stmts_p0);
}


/// SpotSetRoot: unbounded fn Spot -> [Text]
Array<Text> spot_set_root(const crate::check::shrink::walk::Spot& spot0) {
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(spot0)) {
        auto&& s_p0 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(spot0).a0;
        auto&& _m = prism_rtl::deref(s_p0).kind;
        if (prism_rtl::is<crate::syntax::StmtKind::SSet>(_m)) {
            auto&& t_p1 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
            return take(crate::check::passes::borrows::ref_path(t_p1), Nat(1u));
        }
        if (prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m)) {
            auto&& t_p2 = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
            return take(crate::check::passes::borrows::ref_path(t_p2), Nat(1u));
        }
        {
            return Array<Text>{};
        }
    }
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotExpr>(spot0)) {
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> SpotSetRoot::cycle() const {
    const auto& spot0 = this->spot0;
    return ({
        prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(spot0) ? ({
        auto&& s_p0 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(spot0).a0;
        ({
        auto&& _m = prism_rtl::deref(s_p0).kind;
        prism_rtl::is<crate::syntax::StmtKind::SSet>(_m) ? ({
        auto&& t_p1 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
        ({
        auto t_p1_1 = t_p1;
        call_then(crate::check::passes::borrows::start_ref_path(t_p1_1), [=](Array<Text> ref_path_15584) { return prism_rtl::finished(take(ref_path_15584, Nat(1u))); });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m) ? ({
        auto&& t_p2 = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
        ({
        auto t_p2_1 = t_p2;
        call_then(crate::check::passes::borrows::start_ref_path(t_p2_1), [=](Array<Text> ref_path_15634) { return prism_rtl::finished(take(ref_path_15634, Nat(1u))); });
    });
    })
        : prism_rtl::finished(Array<Text>{});
    });
    })
        : prism_rtl::is<crate::check::shrink::walk::Spot::SpotExpr>(spot0) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SpotSetRoot, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_spot_set_root(crate::check::shrink::walk::Spot spot0) {
    return prism_rtl::make_rc<SpotSetRoot>(spot0);
}


/// AllPathsStrict: unbounded fn [Stmt], Text, Nat, (Text ==> Rel) -> Bool
bool all_paths_strict(const Array<crate::syntax::Stmt>& stmts_p0, const Text& v_p1, const Nat& vi_p2, const Map<Text, crate::check::shrink::Rel>& outer_p3) {
    auto rels_p4 = crate::check::shrink::relations::block_rels(stmts_p0, outer_p3);
    return run_to_end(fold_job(stmts_p0, false, ({
        auto v_p1_1 = v_p1;
        auto vi_p2_2 = vi_p2;
        auto rels_p4_3 = rels_p4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Stmt>)>>(prism_rtl::rc([=, v_p1_1 = std::move(v_p1_1), vi_p2_2 = std::move(vi_p2_2), rels_p4_3 = std::move(rels_p4_3)](std::tuple<bool, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto v_p1_1_4 = v_p1_1;
            auto vi_p2_2_4 = vi_p2_2;
            auto rels_p4_3_4 = rels_p4_3;
            entered(once_job([=, v_p1_1_4 = std::move(v_p1_1_4), vi_p2_2_4 = std::move(vi_p2_2_4), rels_p4_3_4 = std::move(rels_p4_3_4)]() {
            return ({
                auto ok_p5 = p0;
                auto s_p6 = p1;
                ({
                auto&& _m = prism_rtl::deref(s_p6).kind;
                prism_rtl::is<crate::syntax::StmtKind::SSet>(_m) ? ({
                auto&& t_p7 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
                auto&& value_p8 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
                ({
                auto t_p7_4 = t_p7;
                auto value_p8_5 = value_p8;
                call_then(crate::check::passes::borrows::start_ref_path(t_p7_4), [=, value_p8_5 = std::move(value_p8_5)](Array<Text> ref_path_16319) {
                return ref_path_16319 == Array(std::vector{v_p1_1_4})
                    ? is_zero_lit(value_p8_5)
                    ? prism_rtl::finished(ok_p5)
                    : prism_rtl::more(prism_rtl::rc(SetsStrict(value_p8_5, v_p1_1_4, vi_p2_2_4, rels_p4_3_4)))
                    : prism_rtl::finished(ok_p5 && (!stmt_sets_weak(s_p6, v_p1_1_4, vi_p2_2_4, rels_p4_3_4)));
            });
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
                auto&& e_p9 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                ({
                auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p9).kind);
                prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
                auto&& c_pa = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
                auto&& tb_pb = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
                auto&& eb_oc = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
                ({
                auto eb_oc_4 = eb_oc;
                auto c_pa_5 = prism_rtl::deref(prism_rtl::deref(c_pa));
                auto tb_pb_6 = tb_pb;
                call_then(crate::check::shrink::relations::start_cond_rels(c_pa_5, rels_p4_3_4), [=, eb_oc_4 = std::move(eb_oc_4), tb_pb_6 = std::move(tb_pb_6)](Map<Text, crate::check::shrink::Rel> cond_rels_16544) {
                return ({
                    auto tr_pd = cond_rels_16544;
                    ({
                    prism_rtl::is_some(eb_oc_4) ? ({
                    auto&& b_pe = prism_rtl::some_of(eb_oc_4);
                    ({
                    auto b_pe_7 = b_pe;
                    call_then(start_all_paths_strict(prism_rtl::deref(tb_pb_6).stmts, v_p1_1_4, vi_p2_2_4, tr_pd), [=, b_pe_7 = std::move(b_pe_7)](bool all_paths_strict_16617) {
                    return all_paths_strict_16617 && all_paths_strict(prism_rtl::deref(b_pe_7).stmts, v_p1_1_4, vi_p2_2_4, rels_p4_3_4)
                        ? prism_rtl::finished(true)
                        : prism_rtl::finished((ok_p5 && (!sets_weak(prism_rtl::deref(tb_pb_6).stmts, v_p1_1_4, vi_p2_2_4, tr_pd))) && (!sets_weak(prism_rtl::deref(b_pe_7).stmts, v_p1_1_4, vi_p2_2_4, rels_p4_3_4)));
                });
                });
                })
                    : prism_rtl::is_none(eb_oc_4) ? prism_rtl::finished(ok_p5 && (!sets_weak(prism_rtl::deref(tb_pb_6).stmts, v_p1_1_4, vi_p2_2_4, tr_pd)))
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            });
            });
            })
                : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
                auto&& subj_pf = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
                auto&& arms_pg = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
                ({
                auto arms_pg_4 = arms_pg;
                auto subj_pf_5 = prism_rtl::deref(prism_rtl::deref(subj_pf));
                call_value(fold_job(arms_pg_4, true, ({
                auto v_p1_1_4_6 = v_p1_1_4;
                auto vi_p2_2_4_6 = vi_p2_2_4;
                auto subj_pf_5_6 = subj_pf_5;
                auto rels_p4_3_4_6 = rels_p4_3_4;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Arm>)>>(prism_rtl::rc([=, v_p1_1_4_6 = std::move(v_p1_1_4_6), vi_p2_2_4_6 = std::move(vi_p2_2_4_6), subj_pf_5_6 = std::move(subj_pf_5_6), rels_p4_3_4_6 = std::move(rels_p4_3_4_6)](std::tuple<bool, crate::syntax::Arm> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto v_p1_1_4_6_6 = v_p1_1_4_6;
                    auto vi_p2_2_4_6_6 = vi_p2_2_4_6;
                    auto subj_pf_5_6_6 = subj_pf_5_6;
                    auto rels_p4_3_4_6_6 = rels_p4_3_4_6;
                    entered(once_job([=, v_p1_1_4_6_6 = std::move(v_p1_1_4_6_6), vi_p2_2_4_6_6 = std::move(vi_p2_2_4_6_6), subj_pf_5_6_6 = std::move(subj_pf_5_6_6), rels_p4_3_4_6_6 = std::move(rels_p4_3_4_6_6)]() {
                    return ({
                        auto all_arms_ph = p0;
                        auto a_pi = p1;
                        (prism_rtl::finished(std::move(all_arms_ph) && all_paths_strict(prism_rtl::deref(prism_rtl::deref(a_pi).body).stmts, v_p1_1_4_6_6, vi_p2_2_4_6_6, crate::check::shrink::relations::arm_pat_rels(subj_pf_5_6_6, a_pi, rels_p4_3_4_6_6))));
                    });
                }));
                });
            })));
            })), [=](bool fold_16906) {
                return fold_16906
                    ? prism_rtl::finished(true)
                    : prism_rtl::finished(ok_p5 && (!run_to_end(fold_job(arms_pg_4, false, ({
                    auto v_p1_1_4_6 = v_p1_1_4;
                    auto vi_p2_2_4_6 = vi_p2_2_4;
                    auto subj_pf_5_6 = subj_pf_5;
                    auto rels_p4_3_4_6 = rels_p4_3_4;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Arm>)>>(prism_rtl::rc([=, v_p1_1_4_6 = std::move(v_p1_1_4_6), vi_p2_2_4_6 = std::move(vi_p2_2_4_6), subj_pf_5_6 = std::move(subj_pf_5_6), rels_p4_3_4_6 = std::move(rels_p4_3_4_6)](std::tuple<bool, crate::syntax::Arm> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto v_p1_1_4_6_6 = v_p1_1_4_6;
                        auto vi_p2_2_4_6_6 = vi_p2_2_4_6;
                        auto subj_pf_5_6_6 = subj_pf_5_6;
                        auto rels_p4_3_4_6_6 = rels_p4_3_4_6;
                        entered(once_job([=, v_p1_1_4_6_6 = std::move(v_p1_1_4_6_6), vi_p2_2_4_6_6 = std::move(vi_p2_2_4_6_6), subj_pf_5_6_6 = std::move(subj_pf_5_6_6), rels_p4_3_4_6_6 = std::move(rels_p4_3_4_6_6)]() {
                        return ({
                            auto any_arm_pj = p0;
                            auto a_pk = p1;
                            (prism_rtl::finished(std::move(any_arm_pj) || sets_weak(prism_rtl::deref(prism_rtl::deref(a_pk).body).stmts, v_p1_1_4_6_6, vi_p2_2_4_6_6, crate::check::shrink::relations::arm_pat_rels(subj_pf_5_6_6, a_pk, rels_p4_3_4_6_6))));
                        });
                    }));
                    });
                })));
                })))));
            });
            });
            })
                : prism_rtl::finished(std::move(ok_p5) && (!stmt_sets_weak(s_p6, v_p1_1_4, vi_p2_2_4, rels_p4_3_4)));
            });
            })
                : prism_rtl::finished(std::move(ok_p5) && (!stmt_sets_weak(s_p6, v_p1_1_4, vi_p2_2_4, rels_p4_3_4)));
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<bool> AllPathsStrict::cycle() const {
    const auto& stmts_p0 = this->stmts_p0;
    const auto& v_p1 = this->v_p1;
    const auto& vi_p2 = this->vi_p2;
    const auto& outer_p3 = this->outer_p3;
    auto outer_p3_1 = outer_p3;
    auto stmts_p0_2 = stmts_p0;
    auto v_p1_3 = v_p1;
    auto vi_p2_4 = vi_p2;
    return call_then(crate::check::shrink::relations::start_block_rels(stmts_p0_2, outer_p3_1), [=](Map<Text, crate::check::shrink::Rel> block_rels_16211) {
        return ({
            auto rels_p4 = block_rels_16211;
            fold_job(stmts_p0_2, false, ({
            auto v_p1_3_5 = v_p1_3;
            auto vi_p2_4_5 = vi_p2_4;
            auto rels_p4_5 = rels_p4;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Stmt>)>>(prism_rtl::rc([=, v_p1_3_5 = std::move(v_p1_3_5), vi_p2_4_5 = std::move(vi_p2_4_5), rels_p4_5 = std::move(rels_p4_5)](std::tuple<bool, crate::syntax::Stmt> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto v_p1_3_5_6 = v_p1_3_5;
                auto vi_p2_4_5_6 = vi_p2_4_5;
                auto rels_p4_5_6 = rels_p4_5;
                entered(once_job([=, v_p1_3_5_6 = std::move(v_p1_3_5_6), vi_p2_4_5_6 = std::move(vi_p2_4_5_6), rels_p4_5_6 = std::move(rels_p4_5_6)]() {
                return ({
                    auto ok_p5 = p0;
                    auto s_p6 = p1;
                    ({
                    auto&& _m = prism_rtl::deref(s_p6).kind;
                    prism_rtl::is<crate::syntax::StmtKind::SSet>(_m) ? ({
                    auto&& t_p7 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
                    auto&& value_p8 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
                    ({
                    auto t_p7_6 = t_p7;
                    auto value_p8_7 = value_p8;
                    call_then(crate::check::passes::borrows::start_ref_path(t_p7_6), [=, value_p8_7 = std::move(value_p8_7)](Array<Text> ref_path_16319) {
                    return ref_path_16319 == Array(std::vector{v_p1_3_5_6})
                        ? is_zero_lit(value_p8_7)
                        ? prism_rtl::finished(ok_p5)
                        : prism_rtl::more(prism_rtl::rc(SetsStrict(value_p8_7, v_p1_3_5_6, vi_p2_4_5_6, rels_p4_5_6)))
                        : prism_rtl::finished(ok_p5 && (!stmt_sets_weak(s_p6, v_p1_3_5_6, vi_p2_4_5_6, rels_p4_5_6)));
                });
                });
                })
                    : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
                    auto&& e_p9 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                    ({
                    auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p9).kind);
                    prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
                    auto&& c_pa = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
                    auto&& tb_pb = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
                    auto&& eb_oc = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
                    ({
                    auto eb_oc_6 = eb_oc;
                    auto c_pa_7 = prism_rtl::deref(prism_rtl::deref(c_pa));
                    auto tb_pb_8 = tb_pb;
                    call_then(crate::check::shrink::relations::start_cond_rels(c_pa_7, rels_p4_5_6), [=, eb_oc_6 = std::move(eb_oc_6), tb_pb_8 = std::move(tb_pb_8)](Map<Text, crate::check::shrink::Rel> cond_rels_16544) {
                    return ({
                        auto tr_pd = cond_rels_16544;
                        ({
                        prism_rtl::is_some(eb_oc_6) ? ({
                        auto&& b_pe = prism_rtl::some_of(eb_oc_6);
                        ({
                        auto b_pe_9 = b_pe;
                        call_then(start_all_paths_strict(prism_rtl::deref(tb_pb_8).stmts, v_p1_3_5_6, vi_p2_4_5_6, tr_pd), [=, b_pe_9 = std::move(b_pe_9)](bool all_paths_strict_16617) {
                        return all_paths_strict_16617 && all_paths_strict(prism_rtl::deref(b_pe_9).stmts, v_p1_3_5_6, vi_p2_4_5_6, rels_p4_5_6)
                            ? prism_rtl::finished(true)
                            : prism_rtl::finished((ok_p5 && (!sets_weak(prism_rtl::deref(tb_pb_8).stmts, v_p1_3_5_6, vi_p2_4_5_6, tr_pd))) && (!sets_weak(prism_rtl::deref(b_pe_9).stmts, v_p1_3_5_6, vi_p2_4_5_6, rels_p4_5_6)));
                    });
                    });
                    })
                        : prism_rtl::is_none(eb_oc_6) ? prism_rtl::finished(ok_p5 && (!sets_weak(prism_rtl::deref(tb_pb_8).stmts, v_p1_3_5_6, vi_p2_4_5_6, tr_pd)))
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                });
                });
                })
                    : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
                    auto&& subj_pf = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
                    auto&& arms_pg = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
                    ({
                    auto arms_pg_6 = arms_pg;
                    auto subj_pf_7 = prism_rtl::deref(prism_rtl::deref(subj_pf));
                    call_value(fold_job(arms_pg_6, true, ({
                    auto v_p1_3_5_6_8 = v_p1_3_5_6;
                    auto vi_p2_4_5_6_8 = vi_p2_4_5_6;
                    auto subj_pf_7_8 = subj_pf_7;
                    auto rels_p4_5_6_8 = rels_p4_5_6;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Arm>)>>(prism_rtl::rc([=, v_p1_3_5_6_8 = std::move(v_p1_3_5_6_8), vi_p2_4_5_6_8 = std::move(vi_p2_4_5_6_8), subj_pf_7_8 = std::move(subj_pf_7_8), rels_p4_5_6_8 = std::move(rels_p4_5_6_8)](std::tuple<bool, crate::syntax::Arm> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto v_p1_3_5_6_8_8 = v_p1_3_5_6_8;
                        auto vi_p2_4_5_6_8_8 = vi_p2_4_5_6_8;
                        auto subj_pf_7_8_8 = subj_pf_7_8;
                        auto rels_p4_5_6_8_8 = rels_p4_5_6_8;
                        entered(once_job([=, v_p1_3_5_6_8_8 = std::move(v_p1_3_5_6_8_8), vi_p2_4_5_6_8_8 = std::move(vi_p2_4_5_6_8_8), subj_pf_7_8_8 = std::move(subj_pf_7_8_8), rels_p4_5_6_8_8 = std::move(rels_p4_5_6_8_8)]() {
                        return ({
                            auto all_arms_ph = p0;
                            auto a_pi = p1;
                            (prism_rtl::finished(std::move(all_arms_ph) && all_paths_strict(prism_rtl::deref(prism_rtl::deref(a_pi).body).stmts, v_p1_3_5_6_8_8, vi_p2_4_5_6_8_8, crate::check::shrink::relations::arm_pat_rels(subj_pf_7_8_8, a_pi, rels_p4_5_6_8_8))));
                        });
                    }));
                    });
                })));
                })), [=](bool fold_16906) {
                    return fold_16906
                        ? prism_rtl::finished(true)
                        : prism_rtl::finished(ok_p5 && (!run_to_end(fold_job(arms_pg_6, false, ({
                        auto v_p1_3_5_6_8 = v_p1_3_5_6;
                        auto vi_p2_4_5_6_8 = vi_p2_4_5_6;
                        auto subj_pf_7_8 = subj_pf_7;
                        auto rels_p4_5_6_8 = rels_p4_5_6;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Arm>)>>(prism_rtl::rc([=, v_p1_3_5_6_8 = std::move(v_p1_3_5_6_8), vi_p2_4_5_6_8 = std::move(vi_p2_4_5_6_8), subj_pf_7_8 = std::move(subj_pf_7_8), rels_p4_5_6_8 = std::move(rels_p4_5_6_8)](std::tuple<bool, crate::syntax::Arm> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto v_p1_3_5_6_8_8 = v_p1_3_5_6_8;
                            auto vi_p2_4_5_6_8_8 = vi_p2_4_5_6_8;
                            auto subj_pf_7_8_8 = subj_pf_7_8;
                            auto rels_p4_5_6_8_8 = rels_p4_5_6_8;
                            entered(once_job([=, v_p1_3_5_6_8_8 = std::move(v_p1_3_5_6_8_8), vi_p2_4_5_6_8_8 = std::move(vi_p2_4_5_6_8_8), subj_pf_7_8_8 = std::move(subj_pf_7_8_8), rels_p4_5_6_8_8 = std::move(rels_p4_5_6_8_8)]() {
                            return ({
                                auto any_arm_pj = p0;
                                auto a_pk = p1;
                                (prism_rtl::finished(std::move(any_arm_pj) || sets_weak(prism_rtl::deref(prism_rtl::deref(a_pk).body).stmts, v_p1_3_5_6_8_8, vi_p2_4_5_6_8_8, crate::check::shrink::relations::arm_pat_rels(subj_pf_7_8_8, a_pk, rels_p4_5_6_8_8))));
                            });
                        }));
                        });
                    })));
                    })))));
                });
                });
                })
                    : prism_rtl::finished(std::move(ok_p5) && (!stmt_sets_weak(s_p6, v_p1_3_5_6, vi_p2_4_5_6, rels_p4_5_6)));
                });
                })
                    : prism_rtl::finished(std::move(ok_p5) && (!stmt_sets_weak(s_p6, v_p1_3_5_6, vi_p2_4_5_6, rels_p4_5_6)));
                });
                });
            }));
            });
        })));
        }))->cycle();
        });
    });
}


/// `Start AllPathsStrict, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_all_paths_strict(Array<crate::syntax::Stmt> stmts_p0, Text v_p1, Nat vi_p2, Map<Text, crate::check::shrink::Rel> outer_p3) {
    return prism_rtl::make_rc<AllPathsStrict>(stmts_p0, v_p1, vi_p2, outer_p3);
}


/// SetsWeak: unbounded fn [Stmt], Text, Nat, (Text ==> Rel) -> Bool
bool sets_weak(const Array<crate::syntax::Stmt>& stmts_p0, const Text& v_p1, const Nat& vi_p2, const Map<Text, crate::check::shrink::Rel>& outer_p3) {
    return run_to_end(fold_job(crate::check::shrink::walk::stmts_spots(stmts_p0, outer_p3), false, ({
        auto v_p1_1 = v_p1;
        auto vi_p2_2 = vi_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=, v_p1_1 = std::move(v_p1_1), vi_p2_2 = std::move(vi_p2_2)](std::tuple<bool, crate::check::shrink::walk::Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto v_p1_1_3 = v_p1_1;
            auto vi_p2_2_3 = vi_p2_2;
            entered(once_job([=, v_p1_1_3 = std::move(v_p1_1_3), vi_p2_2_3 = std::move(vi_p2_2_3)]() {
            return ({
                auto seen_p4 = p0;
                auto sp_p5 = p1;
                (prism_rtl::finished(std::move(seen_p4) || spot_sets_weak(sp_p5, v_p1_1_3, vi_p2_2_3)));
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<bool> SetsWeak::cycle() const {
    const auto& stmts_p0 = this->stmts_p0;
    const auto& v_p1 = this->v_p1;
    const auto& vi_p2 = this->vi_p2;
    const auto& outer_p3 = this->outer_p3;
    auto outer_p3_1 = outer_p3;
    auto stmts_p0_2 = stmts_p0;
    auto v_p1_3 = v_p1;
    auto vi_p2_4 = vi_p2;
    return call_then(crate::check::shrink::walk::start_stmts_spots(stmts_p0_2, outer_p3_1), [=](Array<crate::check::shrink::walk::Spot> stmts_spots_17553) {
        return fold_job(stmts_spots_17553, false, ({
            auto v_p1_3_5 = v_p1_3;
            auto vi_p2_4_5 = vi_p2_4;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=, v_p1_3_5 = std::move(v_p1_3_5), vi_p2_4_5 = std::move(vi_p2_4_5)](std::tuple<bool, crate::check::shrink::walk::Spot> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto v_p1_3_5_5 = v_p1_3_5;
                auto vi_p2_4_5_5 = vi_p2_4_5;
                entered(once_job([=, v_p1_3_5_5 = std::move(v_p1_3_5_5), vi_p2_4_5_5 = std::move(vi_p2_4_5_5)]() {
                return ({
                    auto seen_p4 = p0;
                    auto sp_p5 = p1;
                    (prism_rtl::finished(std::move(seen_p4) || spot_sets_weak(sp_p5, v_p1_3_5_5, vi_p2_4_5_5)));
                });
            }));
            });
        })));
        }))->cycle();
    });
}


/// `Start SetsWeak, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_sets_weak(Array<crate::syntax::Stmt> stmts_p0, Text v_p1, Nat vi_p2, Map<Text, crate::check::shrink::Rel> outer_p3) {
    return prism_rtl::make_rc<SetsWeak>(stmts_p0, v_p1, vi_p2, outer_p3);
}


/// StmtSetsWeak: unbounded fn Stmt, Text, Nat, (Text ==> Rel) -> Bool
bool stmt_sets_weak(const crate::syntax::Stmt& s_p0, const Text& v_p1, const Nat& vi_p2, const Map<Text, crate::check::shrink::Rel>& rels_p3) {
    return run_to_end(fold_job(crate::check::shrink::walk::stmt_spots(s_p0, rels_p3), false, ({
        auto v_p1_1 = v_p1;
        auto vi_p2_2 = vi_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=, v_p1_1 = std::move(v_p1_1), vi_p2_2 = std::move(vi_p2_2)](std::tuple<bool, crate::check::shrink::walk::Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto v_p1_1_3 = v_p1_1;
            auto vi_p2_2_3 = vi_p2_2;
            entered(once_job([=, v_p1_1_3 = std::move(v_p1_1_3), vi_p2_2_3 = std::move(vi_p2_2_3)]() {
            return ({
                auto seen_p4 = p0;
                auto sp_p5 = p1;
                (prism_rtl::finished(std::move(seen_p4) || spot_sets_weak(sp_p5, v_p1_1_3, vi_p2_2_3)));
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<bool> StmtSetsWeak::cycle() const {
    const auto& s_p0 = this->s_p0;
    const auto& v_p1 = this->v_p1;
    const auto& vi_p2 = this->vi_p2;
    const auto& rels_p3 = this->rels_p3;
    auto rels_p3_1 = rels_p3;
    auto s_p0_2 = s_p0;
    auto v_p1_3 = v_p1;
    auto vi_p2_4 = vi_p2;
    return call_then(crate::check::shrink::walk::start_stmt_spots(s_p0_2, rels_p3_1), [=](Array<crate::check::shrink::walk::Spot> stmt_spots_17736) {
        return fold_job(stmt_spots_17736, false, ({
            auto v_p1_3_5 = v_p1_3;
            auto vi_p2_4_5 = vi_p2_4;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=, v_p1_3_5 = std::move(v_p1_3_5), vi_p2_4_5 = std::move(vi_p2_4_5)](std::tuple<bool, crate::check::shrink::walk::Spot> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto v_p1_3_5_5 = v_p1_3_5;
                auto vi_p2_4_5_5 = vi_p2_4_5;
                entered(once_job([=, v_p1_3_5_5 = std::move(v_p1_3_5_5), vi_p2_4_5_5 = std::move(vi_p2_4_5_5)]() {
                return ({
                    auto seen_p4 = p0;
                    auto sp_p5 = p1;
                    (prism_rtl::finished(std::move(seen_p4) || spot_sets_weak(sp_p5, v_p1_3_5_5, vi_p2_4_5_5)));
                });
            }));
            });
        })));
        }))->cycle();
    });
}


/// `Start StmtSetsWeak, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_stmt_sets_weak(crate::syntax::Stmt s_p0, Text v_p1, Nat vi_p2, Map<Text, crate::check::shrink::Rel> rels_p3) {
    return prism_rtl::make_rc<StmtSetsWeak>(s_p0, v_p1, vi_p2, rels_p3);
}


/// SpotSetsWeak: unbounded fn Spot, Text, Nat -> Bool
bool spot_sets_weak(const crate::check::shrink::walk::Spot& spot0, const Text& text1, const Nat& n2) {
    auto&& _m = std::tuple{spot0, text1, n2};
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(std::get<0>(_m))) {
        auto&& s_p0 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(std::get<0>(_m)).a0;
        auto&& m_p1 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(std::get<0>(_m)).a1;
        auto&& v_p2 = std::get<1>(_m);
        auto&& vi_p3 = std::get<2>(_m);
        auto&& _m = prism_rtl::deref(s_p0).kind;
        if (prism_rtl::is<crate::syntax::StmtKind::SSet>(_m)) {
            auto&& t_p4 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
            auto&& value_p5 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
            return ((take(crate::check::passes::borrows::ref_path(t_p4), Nat(1u)) == Array(std::vector{v_p2})) && (!sets_strict(value_p5, v_p2, vi_p3, m_p1))) && (!((crate::check::passes::borrows::ref_path(t_p4) == Array(std::vector{v_p2})) && is_zero_lit(value_p5)));
        }
        if (prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m)) {
            auto&& t_p6 = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
            return take(crate::check::passes::borrows::ref_path(t_p6), Nat(1u)) == Array(std::vector{v_p2});
        }
        {
            return false;
        }
    }
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotExpr>(std::get<0>(_m))) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> SpotSetsWeak::cycle() const {
    const auto& spot0 = this->spot0;
    const auto& text1 = this->text1;
    const auto& n2 = this->n2;
    return ({
        auto&& _m = std::tuple{spot0, text1, n2};
        prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(std::get<0>(_m)) ? ({
        auto&& s_p0 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(std::get<0>(_m)).a0;
        auto&& m_p1 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(std::get<0>(_m)).a1;
        auto&& v_p2 = std::get<1>(_m);
        auto&& vi_p3 = std::get<2>(_m);
        ({
        auto&& _m = prism_rtl::deref(s_p0).kind;
        prism_rtl::is<crate::syntax::StmtKind::SSet>(_m) ? ({
        auto&& t_p4 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
        auto&& value_p5 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
        ({
        auto m_p1_1 = m_p1;
        auto t_p4_2 = t_p4;
        auto v_p2_3 = v_p2;
        auto value_p5_4 = value_p5;
        auto vi_p3_5 = vi_p3;
        call_then(crate::check::passes::borrows::start_ref_path(t_p4_2), [=, m_p1_1 = std::move(m_p1_1), v_p2_3 = std::move(v_p2_3), value_p5_4 = std::move(value_p5_4), vi_p3_5 = std::move(vi_p3_5)](Array<Text> ref_path_17939) { return prism_rtl::finished(((take(ref_path_17939, Nat(1u)) == Array(std::vector{v_p2_3})) && (!sets_strict(value_p5_4, v_p2_3, vi_p3_5, m_p1_1))) && (!((crate::check::passes::borrows::ref_path(t_p4_2) == Array(std::vector{v_p2_3})) && is_zero_lit(value_p5_4)))); });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m) ? ({
        auto&& t_p6 = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
        ({
        auto t_p6_1 = t_p6;
        auto v_p2_2 = v_p2;
        call_then(crate::check::passes::borrows::start_ref_path(t_p6_1), [=, v_p2_2 = std::move(v_p2_2)](Array<Text> ref_path_18088) { return prism_rtl::finished(take(ref_path_18088, Nat(1u)) == Array(std::vector{v_p2_2})); });
    });
    })
        : prism_rtl::finished(false);
    });
    })
        : prism_rtl::is<crate::check::shrink::walk::Spot::SpotExpr>(std::get<0>(_m)) ? prism_rtl::finished(false)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SpotSetsWeak, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_spot_sets_weak(crate::check::shrink::walk::Spot spot0, Text text1, Nat n2) {
    return prism_rtl::make_rc<SpotSetsWeak>(spot0, text1, n2);
}


/// IsZeroLit: fn Expr -> Bool
bool is_zero_lit(const crate::syntax::Expr& e_p0) {
    auto&& _m = prism_rtl::deref(e_p0.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::ELit>(_m)) {
        auto&& l_p1 = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
        auto&& _m = prism_rtl::deref(l_p1).kind;
        if (prism_rtl::is<crate::syntax::LitKind::LInt>(_m)) {
            auto&& d_p2 = prism_rtl::as<crate::syntax::LitKind::LInt>(_m).a0;
            return d_p2 == Text::lit("0");
        }
        {
            return false;
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p3 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return is_zero_lit(prism_rtl::deref(prism_rtl::deref(x_p3)));
    }
    {
        return false;
    }
}


/// SetsStrict: unbounded fn Expr, Text, Nat, (Text ==> Rel) -> Bool
bool sets_strict(const crate::syntax::Expr& e_p0, const Text& v_p1, const Nat& vi_p2, const Map<Text, crate::check::shrink::Rel>& rels_p3) {
    auto&& _m = prism_rtl::deref(e_p0.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p4 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return sets_strict(prism_rtl::deref(prism_rtl::deref(x_p4)), v_p1, vi_p2, rels_p3);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
        auto&& m19465_1_0 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& l_p5 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        if (m19465_1_0 == Text::lit("-?")) {
            return is_nat_minus(rels_p3, e_p0) && sets_strict(prism_rtl::deref(prism_rtl::deref(l_p5)), v_p1, vi_p2, rels_p3);
        }
    }
    {
        return rel_strict(rels_p3, e_p0, vi_p2) || call_strict(e_p0, v_p1, vi_p2, rels_p3);
    }
}


prism_rtl::Turn<bool> SetsStrict::cycle() const {
    const auto& e_p0 = this->e_p0;
    const auto& v_p1 = this->v_p1;
    const auto& vi_p2 = this->vi_p2;
    const auto& rels_p3 = this->rels_p3;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p0).kind);
        prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x_p4 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(SetsStrict(prism_rtl::deref(prism_rtl::deref(x_p4)), v_p1, vi_p2, rels_p3)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m) && ({
        auto&& m19465_1_0 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& l_p5 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        (m19465_1_0 == Text::lit("-?"));
    }) ? ({
        auto&& m19465_1_0 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& l_p5 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        prism_rtl::finished(is_nat_minus(rels_p3, e_p0) && sets_strict(prism_rtl::deref(prism_rtl::deref(l_p5)), v_p1, vi_p2, rels_p3));
    })
        : ({
        auto e_p0_1 = e_p0;
        auto rels_p3_2 = rels_p3;
        auto v_p1_3 = v_p1;
        auto vi_p2_4 = vi_p2;
        call_then(start_rel_strict(rels_p3_2, e_p0_1, vi_p2_4), [=, v_p1_3 = std::move(v_p1_3)](bool rel_strict_19615) { return prism_rtl::finished(rel_strict_19615 || call_strict(e_p0_1, v_p1_3, vi_p2_4, rels_p3_2)); });
    });
    });
}


/// `Start SetsStrict, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_sets_strict(crate::syntax::Expr e_p0, Text v_p1, Nat vi_p2, Map<Text, crate::check::shrink::Rel> rels_p3) {
    return prism_rtl::make_rc<SetsStrict>(e_p0, v_p1, vi_p2, rels_p3);
}


/// RelStrict: unbounded fn (Text ==> Rel), Expr, Nat -> Bool
bool rel_strict(const Map<Text, crate::check::shrink::Rel>& rels_p0, const crate::syntax::Expr& e_p1, const Nat& vi_p2) {
    auto&& _m = crate::check::shrink::walk::rel_of(rels_p0, e_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& r_p3 = prism_rtl::some_of(_m);
        return prism_rtl::deref(r_p3).strict && (prism_rtl::deref(r_p3).param == vi_p2);
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> RelStrict::cycle() const {
    const auto& rels_p0 = this->rels_p0;
    const auto& e_p1 = this->e_p1;
    const auto& vi_p2 = this->vi_p2;
    auto e_p1_1 = e_p1;
    auto rels_p0_2 = rels_p0;
    auto vi_p2_3 = vi_p2;
    return call_then(crate::check::shrink::walk::start_rel_of(rels_p0_2, e_p1_1), [=](std::optional<crate::check::shrink::Rel> rel_of_19761) {
        return ({
            prism_rtl::is_some(rel_of_19761) ? ({
            auto&& r_p3 = prism_rtl::some_of(rel_of_19761);
            prism_rtl::finished(prism_rtl::deref(r_p3).strict && (prism_rtl::deref(r_p3).param == vi_p2_3));
        })
            : prism_rtl::is_none(rel_of_19761) ? prism_rtl::finished(false)
            : throw prism_rtl::Panic("no arm matched");
        });
    });
}


/// `Start RelStrict, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_rel_strict(Map<Text, crate::check::shrink::Rel> rels_p0, crate::syntax::Expr e_p1, Nat vi_p2) {
    return prism_rtl::make_rc<RelStrict>(rels_p0, e_p1, vi_p2);
}


/// CallStrict: unbounded fn Expr, Text, Nat, (Text ==> Rel) -> Bool
bool call_strict(const crate::syntax::Expr& e_p0, const Text& v_p1, const Nat& vi_p2, const Map<Text, crate::check::shrink::Rel>& rels_p3) {
    auto&& _m = crate::check::shrink::walk::call_of(e_p0);
    if (prism_rtl::is_some(_m)) {
        auto&& c_p4 = std::get<0>(prism_rtl::some_of(_m));
        auto&& args_p5 = std::get<1>(prism_rtl::some_of(_m));
        return crate::check::shrink::walk::is_non_nat_min(rels_p3, e_p0, c_p4)
            ? false
            : ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = crate::check::shrink::walk::no_larger_arg(rels_p3, c_p4, args_p5);
            if (prism_rtl::is_some(_m)) {
                auto&& a_p6 = prism_rtl::some_of(_m);
                _v.set(sets_strict(a_p6, v_p1, vi_p2, rels_p3));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> CallStrict::cycle() const {
    const auto& e_p0 = this->e_p0;
    const auto& v_p1 = this->v_p1;
    const auto& vi_p2 = this->vi_p2;
    const auto& rels_p3 = this->rels_p3;
    return ({
        auto&& _m = crate::check::shrink::walk::call_of(e_p0);
        prism_rtl::is_some(_m) ? ({
        auto&& c_p4 = std::get<0>(prism_rtl::some_of(_m));
        auto&& args_p5 = std::get<1>(prism_rtl::some_of(_m));
        crate::check::shrink::walk::is_non_nat_min(rels_p3, e_p0, c_p4)
        ? prism_rtl::finished(false)
        : ({
        auto&& _m = crate::check::shrink::walk::no_larger_arg(rels_p3, c_p4, args_p5);
        prism_rtl::is_some(_m) ? ({
        auto&& a_p6 = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(SetsStrict(a_p6, v_p1, vi_p2, rels_p3)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CallStrict, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_call_strict(crate::syntax::Expr e_p0, Text v_p1, Nat vi_p2, Map<Text, crate::check::shrink::Rel> rels_p3) {
    return prism_rtl::make_rc<CallStrict>(e_p0, v_p1, vi_p2, rels_p3);
}

}  // namespace crate::check::shrink::summaries
