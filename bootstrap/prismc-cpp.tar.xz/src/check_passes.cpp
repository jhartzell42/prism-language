// The module `CheckPasses`, from `target/bootstrap/cpp-src/prismc/check-passes.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include "check_passes.hpp"
#include "ast.hpp"
#include "check_env.hpp"
#include "typed.hpp"
#include "check_blocks.hpp"
#include "check_errors.hpp"
#include "check_expr.hpp"
#include "check_types.hpp"
#include "lexer.hpp"
#include "check_env.generic.hpp"
#include "lexer.generic.hpp"

namespace crate::check_passes {

void Ctor::show(Printer& p) const {
    p.record("Ctor", {{"name", name}, {"arity", arity}, {"args", args}, {"shown", shown}});
}

Pod Ctor::to_pod() const {
    return Pod::record("Ctor", {{"name", prism_rtl::to_pod(name)}, {"arity", prism_rtl::to_pod(arity)}, {"args", prism_rtl::to_pod(args)}, {"shown", prism_rtl::to_pod(shown)}});
}

Result<Ctor> Ctor::from_pod(const Pod& whole) {
    return Ctor{.name = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "name")))), .arity = TRY(prism_rtl::from_pod<Nat>(TRY(prelude::field(whole, "arity")))), .args = TRY(prism_rtl::from_pod<Array<check_types::Ty>>(TRY(prelude::field(whole, "args")))), .shown = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "shown"))))};
}


void Kid::show(Printer& p) const {
    if (auto c = std::get_if<KidExpr>(&cases())) p.choice("KidExpr", {c->a0, c->a1});
    else if (auto c = std::get_if<KidStmts>(&cases())) p.choice("KidStmts", {c->a0, c->a1});
}

Pod Kid::to_pod() const {
    return std::holds_alternative<KidExpr>(cases()) ? Pod::choice("KidExpr", {prism_rtl::to_pod(std::get<KidExpr>(cases()).a0), prism_rtl::to_pod(std::get<KidExpr>(cases()).a1)})
        : std::holds_alternative<KidStmts>(cases()) ? Pod::choice("KidStmts", {prism_rtl::to_pod(std::get<KidStmts>(cases()).a0), prism_rtl::to_pod(std::get<KidStmts>(cases()).a1)})
        : Pod();
}

Result<Kid> Kid::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "KidExpr" && c->args.size() == 2) return Kid(KidExpr{TRY(prism_rtl::from_pod<ast::Expr>(c->args[0])), TRY(prism_rtl::from_pod<Map<Text, Rel>>(c->args[1]))});
        if (c->ctor == "KidStmts" && c->args.size() == 2) return Kid(KidStmts{TRY(prism_rtl::from_pod<Array<ast::Stmt>>(c->args[0])), TRY(prism_rtl::from_pod<Map<Text, Rel>>(c->args[1]))});
    }
    return mismatch<Kid>("a Kid", p);
}


void PCx::show(Printer& p) const {
    p.record("PCx", {{"g", g}, {"home", home}, {"lams", lams}, {"base", base}});
}

Pod PCx::to_pod() const {
    return Pod::record("PCx", {{"g", prism_rtl::to_pod(g)}, {"home", prism_rtl::to_pod(home)}, {"lams", prism_rtl::to_pod(lams)}, {"base", prism_rtl::to_pod(base)}});
}

Result<PCx> PCx::from_pod(const Pod& whole) {
    return PCx{.g = TRY(prism_rtl::from_pod<check_env::G>(TRY(prelude::field(whole, "g")))), .home = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "home")))), .lams = TRY(prism_rtl::from_pod<Map<Nat, ast::Expr>>(TRY(prelude::field(whole, "lams")))), .base = TRY(prism_rtl::from_pod<Map<Text, Rel>>(TRY(prelude::field(whole, "base"))))};
}


void Pat::show(Printer& p) const {
    if (auto c = std::get_if<PtAny>(&cases())) p.choice("PtAny", {});
    else if (auto c = std::get_if<PtCon>(&cases())) p.choice("PtCon", {c->a0, c->a1});
    else if (auto c = std::get_if<PtLit>(&cases())) p.choice("PtLit", {c->a0});
    else if (auto c = std::get_if<PtFam>(&cases())) p.choice("PtFam", {c->a0});
}

Pod Pat::to_pod() const {
    return std::holds_alternative<PtAny>(cases()) ? Pod::choice("PtAny", {})
        : std::holds_alternative<PtCon>(cases()) ? Pod::choice("PtCon", {prism_rtl::to_pod(std::get<PtCon>(cases()).a0), prism_rtl::to_pod(std::get<PtCon>(cases()).a1)})
        : std::holds_alternative<PtLit>(cases()) ? Pod::choice("PtLit", {prism_rtl::to_pod(std::get<PtLit>(cases()).a0)})
        : std::holds_alternative<PtFam>(cases()) ? Pod::choice("PtFam", {prism_rtl::to_pod(std::get<PtFam>(cases()).a0)})
        : Pod();
}

Result<Pat> Pat::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "PtAny" && c->args.size() == 0) return Pat(PtAny{});
        if (c->ctor == "PtCon" && c->args.size() == 2) return Pat(PtCon{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Array<Pat>>(c->args[1]))});
        if (c->ctor == "PtLit" && c->args.size() == 1) return Pat(PtLit{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "PtFam" && c->args.size() == 1) return Pat(PtFam{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
    }
    return mismatch<Pat>("a Pat", p);
}


void Rel::show(Printer& p) const {
    p.record("Rel", {{"param", param}, {"strict", strict}});
}

Pod Rel::to_pod() const {
    return Pod::record("Rel", {{"param", prism_rtl::to_pod(param)}, {"strict", prism_rtl::to_pod(strict)}});
}

Result<Rel> Rel::from_pod(const Pod& whole) {
    return Rel{.param = TRY(prism_rtl::from_pod<Nat>(TRY(prelude::field(whole, "param")))), .strict = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "strict"))))};
}


void Report_::show(Printer& p) const {
    p.record("Report", {{"text", text}, {"errors", errors}, {"root_row", root_row}, {"typed", typed}});
}

Pod Report_::to_pod() const {
    return Pod::record("Report", {{"text", prism_rtl::to_pod(text)}, {"errors", prism_rtl::to_pod(errors)}, {"root_row", prism_rtl::to_pod(root_row)}, {"typed", prism_rtl::to_pod(typed)}});
}

Result<Report_> Report_::from_pod(const Pod& whole) {
    return Report_{.text = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "text")))), .errors = TRY(prism_rtl::from_pod<Nat>(TRY(prelude::field(whole, "errors")))), .root_row = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "root_row")))), .typed = TRY(prism_rtl::from_pod<typed::TProgram>(TRY(prelude::field(whole, "typed"))))};
}


void Sc::show(Printer& p) const {
    p.record("Sc", {{"caller", caller}, {"callee", callee}, {"edges", edges}, {"span", span}, {"file", file}, {"arg", arg}});
}

Pod Sc::to_pod() const {
    return Pod::record("Sc", {{"caller", prism_rtl::to_pod(caller)}, {"callee", prism_rtl::to_pod(callee)}, {"edges", prism_rtl::to_pod(edges)}, {"span", prism_rtl::to_pod(span)}, {"file", prism_rtl::to_pod(file)}, {"arg", prism_rtl::to_pod(arg)}});
}

Result<Sc> Sc::from_pod(const Pod& whole) {
    return Sc{.caller = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "caller")))), .callee = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "callee")))), .edges = TRY(prism_rtl::from_pod<Array<std::tuple<Nat, Nat, bool>>>(TRY(prelude::field(whole, "edges")))), .span = TRY(prism_rtl::from_pod<ast::Range>(TRY(prelude::field(whole, "span")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(prelude::field(whole, "file")))), .arg = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "arg"))))};
}


void Shrink::show(Printer& p) const {
    p.record("Shrink", {{"g", g}, {"fns", fns}, {"by_key", by_key}, {"targets", targets}, {"impl_defs", impl_defs}, {"choices", choices}, {"sums", sums}, {"seeds", seeds}, {"local_of", local_of}, {"local_base", local_base}});
}

Pod Shrink::to_pod() const {
    return Pod::record("Shrink", {{"g", prism_rtl::to_pod(g)}, {"fns", prism_rtl::to_pod(fns)}, {"by_key", prism_rtl::to_pod(by_key)}, {"targets", prism_rtl::to_pod(targets)}, {"impl_defs", prism_rtl::to_pod(impl_defs)}, {"choices", prism_rtl::to_pod(choices)}, {"sums", prism_rtl::to_pod(sums)}, {"seeds", prism_rtl::to_pod(seeds)}, {"local_of", prism_rtl::to_pod(local_of)}, {"local_base", prism_rtl::to_pod(local_base)}});
}

Result<Shrink> Shrink::from_pod(const Pod& whole) {
    return Shrink{.g = TRY(prism_rtl::from_pod<check_env::G>(TRY(prelude::field(whole, "g")))), .fns = TRY(prism_rtl::from_pod<Array<check_env::Def>>(TRY(prelude::field(whole, "fns")))), .by_key = TRY(prism_rtl::from_pod<Map<Text, check_env::Def>>(TRY(prelude::field(whole, "by_key")))), .targets = TRY(prism_rtl::from_pod<Map<Text, Array<Text>>>(TRY(prelude::field(whole, "targets")))), .impl_defs = TRY(prism_rtl::from_pod<Map<Text, Text>>(TRY(prelude::field(whole, "impl_defs")))), .choices = TRY(prism_rtl::from_pod<Map<Text, Array<Text>>>(TRY(prelude::field(whole, "choices")))), .sums = TRY(prism_rtl::from_pod<Map<Text, Nat>>(TRY(prelude::field(whole, "sums")))), .seeds = TRY(prism_rtl::from_pod<Map<Text, Map<Text, Rel>>>(TRY(prelude::field(whole, "seeds")))), .local_of = TRY(prism_rtl::from_pod<Map<Text, Text>>(TRY(prelude::field(whole, "local_of")))), .local_base = TRY(prism_rtl::from_pod<Map<Text, Map<Text, Rel>>>(TRY(prelude::field(whole, "local_base"))))};
}


void Site::show(Printer& p) const {
    p.record("Site", {{"callee", callee}, {"args", args}, {"span", span}, {"rels", rels}});
}

Pod Site::to_pod() const {
    return Pod::record("Site", {{"callee", prism_rtl::to_pod(callee)}, {"args", prism_rtl::to_pod(args)}, {"span", prism_rtl::to_pod(span)}, {"rels", prism_rtl::to_pod(rels)}});
}

Result<Site> Site::from_pod(const Pod& whole) {
    return Site{.callee = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "callee")))), .args = TRY(prism_rtl::from_pod<Array<ast::Arg>>(TRY(prelude::field(whole, "args")))), .span = TRY(prism_rtl::from_pod<ast::Range>(TRY(prelude::field(whole, "span")))), .rels = TRY(prism_rtl::from_pod<Map<Text, Rel>>(TRY(prelude::field(whole, "rels"))))};
}


void Slot_::show(Printer& p) const {
    p.record("Slot", {{"owner", owner}, {"at", at}, {"arity", arity}});
}

Pod Slot_::to_pod() const {
    return Pod::record("Slot", {{"owner", prism_rtl::to_pod(owner)}, {"at", prism_rtl::to_pod(at)}, {"arity", prism_rtl::to_pod(arity)}});
}

Result<Slot_> Slot_::from_pod(const Pod& whole) {
    return Slot_{.owner = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "owner")))), .at = TRY(prism_rtl::from_pod<Nat>(TRY(prelude::field(whole, "at")))), .arity = TRY(prism_rtl::from_pod<Nat>(TRY(prelude::field(whole, "arity"))))};
}


void Spot::show(Printer& p) const {
    if (auto c = std::get_if<SpotExpr>(&cases())) p.choice("SpotExpr", {c->a0, c->a1});
    else if (auto c = std::get_if<SpotStmt>(&cases())) p.choice("SpotStmt", {c->a0, c->a1});
}

Pod Spot::to_pod() const {
    return std::holds_alternative<SpotExpr>(cases()) ? Pod::choice("SpotExpr", {prism_rtl::to_pod(std::get<SpotExpr>(cases()).a0), prism_rtl::to_pod(std::get<SpotExpr>(cases()).a1)})
        : std::holds_alternative<SpotStmt>(cases()) ? Pod::choice("SpotStmt", {prism_rtl::to_pod(std::get<SpotStmt>(cases()).a0), prism_rtl::to_pod(std::get<SpotStmt>(cases()).a1)})
        : Pod();
}

Result<Spot> Spot::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "SpotExpr" && c->args.size() == 2) return Spot(SpotExpr{TRY(prism_rtl::from_pod<ast::Expr>(c->args[0])), TRY(prism_rtl::from_pod<Map<Text, Rel>>(c->args[1]))});
        if (c->ctor == "SpotStmt" && c->args.size() == 2) return Spot(SpotStmt{TRY(prism_rtl::from_pod<ast::Stmt>(c->args[0])), TRY(prism_rtl::from_pod<Map<Text, Rel>>(c->args[1]))});
    }
    return mismatch<Spot>("a Spot", p);
}


/// ?CtorsOf: unbounded fn Env, St, Ty -> ?[Ctor]
std::optional<Array<Ctor>> ctors_of(const check_expr::Env& env, const check_types::St& st, const check_types::Ty& t) {
    auto&& _m = check_types::walk(st, t);
    if (prism_rtl::is<check_types::Ty::TyCon>(_m)) {
        auto&& m2052_0_0 = prism_rtl::as<check_types::Ty::TyCon>(_m).a0;
        auto&& m2052_0_1 = prism_rtl::as<check_types::Ty::TyCon>(_m).a1;
        if (m2052_0_0 == Text::lit("Bool")) {
            if (m2052_0_1.size() == 0u) {
                return std::optional(Array(std::vector{Ctor{.name = Text::lit("True"), .arity = Nat(0u), .args = Array<check_types::Ty>{}, .shown = Text::lit("True")}, Ctor{.name = Text::lit("False"), .arity = Nat(0u), .args = Array<check_types::Ty>{}, .shown = Text::lit("False")}}));
            }
        }
    }
    if (prism_rtl::is<check_types::Ty::TyCon>(_m)) {
        auto&& m2052_1_0 = prism_rtl::as<check_types::Ty::TyCon>(_m).a0;
        auto&& m2052_1_1 = prism_rtl::as<check_types::Ty::TyCon>(_m).a1;
        if (m2052_1_0 == Text::lit("unit")) {
            if (m2052_1_1.size() == 0u) {
                return std::optional(Array(std::vector{Ctor{.name = Text::lit("unit"), .arity = Nat(0u), .args = Array<check_types::Ty>{}, .shown = Text::lit("unit")}}));
            }
        }
    }
    if (prism_rtl::is<check_types::Ty::TySig>(_m)) {
        auto&& m2052_2_0 = prism_rtl::as<check_types::Ty::TySig>(_m).a0;
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(_m).a1;
        if (m2052_2_0 == Text::lit("?")) {
            return std::optional(Array(std::vector{Ctor{.name = Text::lit("?"), .arity = Nat(1u), .args = Array(std::vector{i}), .shown = Text::lit("? _")}, Ctor{.name = Text::lit("nil"), .arity = Nat(0u), .args = Array<check_types::Ty>{}, .shown = Text::lit("nil")}}));
        }
    }
    if (prism_rtl::is<check_types::Ty::TySig>(_m)) {
        auto&& m2052_3_0 = prism_rtl::as<check_types::Ty::TySig>(_m).a0;
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(_m).a1;
        if (m2052_3_0 == Text::lit("~")) {
            return std::optional(Array(std::vector{Ctor{.name = Text::lit("~"), .arity = Nat(1u), .args = Array(std::vector{i}), .shown = Text::lit("~ _")}, Ctor{.name = Text::lit("Error"), .arity = Nat(2u), .args = Array(std::vector{check_types::Ty(check_types::Ty::TyCon{Text::lit("Prelude.Fault"), Array<check_types::Ty>{}}), check_types::t_text()}), .shown = Text::lit("Error(..)")}}));
        }
    }
    if (prism_rtl::is<check_types::Ty::TyTuple>(_m)) {
        auto&& ts = prism_rtl::as<check_types::Ty::TyTuple>(_m).a0;
        return std::optional(Array(std::vector{Ctor{.name = Text::lit("tuple"), .arity = len(ts), .args = ts, .shown = prism_rtl::cat("((", lexer::join(each(ts, [&](const check_types::Ty& _p0) { return Text::lit("_"); }), Text::lit(", ")), "))")}}));
    }
    if (prism_rtl::is<check_types::Ty::TyCon>(_m)) {
        auto&& m2052_5_0 = prism_rtl::as<check_types::Ty::TyCon>(_m).a0;
        auto&& m2052_5_1 = prism_rtl::as<check_types::Ty::TyCon>(_m).a1;
        if (m2052_5_0 == Text::lit("Prelude.Error")) {
            if (m2052_5_1.size() == 0u) {
                return std::optional(Array(std::vector{Ctor{.name = Text::lit("Error"), .arity = Nat(2u), .args = Array(std::vector{check_types::Ty(check_types::Ty::TyCon{Text::lit("Prelude.Fault"), Array<check_types::Ty>{}}), check_types::t_text()}), .shown = Text::lit("Error(..)")}}));
            }
        }
    }
    if (prism_rtl::is<check_types::Ty::TyCon>(_m)) {
        auto&& n = prism_rtl::as<check_types::Ty::TyCon>(_m).a0;
        auto&& args = prism_rtl::as<check_types::Ty::TyCon>(_m).a1;
        auto&& _m = prelude::get(env.g.types, n);
        if (prism_rtl::is_some(_m)) {
            auto&& ti = prism_rtl::some_of(_m);
            auto&& _m = ti.body;
            if (prism_rtl::is<check_env::TyBody::BChoice>(_m)) {
                auto&& cases = prism_rtl::as<check_env::TyBody::BChoice>(_m).a0;
                return std::optional(run_to_end(each_job(cases, ({
                    auto ti_1 = ti;
                    auto args_2 = args;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ctor>(std::tuple<Text, Array<check_types::Ty>>)>>(prism_rtl::rc([=](std::tuple<Text, Array<check_types::Ty>> p0) {
                    return ({
                        auto ti_1_3 = ti_1;
                        auto args_2_3 = args_2;
                        entered(once_job([=]() {
                        return ({
                            auto [cn, cargs] = p0;
                            (prism_rtl::more(prism_rtl::rc(CtorOfCase(ti_1_3, cn, cargs, args_2_3))));
                        });
                    }));
                    });
                })));
                }))));
            }
            if (prism_rtl::is<check_env::TyBody::BRecord>(_m)) {
                auto&& fields = prism_rtl::as<check_env::TyBody::BRecord>(_m).a0;
                return std::optional(Array(std::vector{Ctor{.name = n, .arity = len(fields), .args = run_to_end(each_job(fields, ({
                    auto ti_1 = ti;
                    auto args_2 = args;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::Ty>(std::tuple<Text, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<Text, check_types::Ty> p0) {
                    return ({
                        auto ti_1_3 = ti_1;
                        auto args_2_3 = args_2;
                        entered(once_job([=]() {
                        return ({
                            auto&& _ft = p0;
                            auto&& ft = std::get<1>(_ft);
                            (prism_rtl::more(prism_rtl::rc(check_types::SubstQ(check_env::param_inst(ti_1_3.params, args_2_3), ft))));
                        });
                    }));
                    });
                })));
                }))), .shown = prism_rtl::cat(check_types::bare_name(n), "(..)")}}));
            }
            if (prism_rtl::is<check_env::TyBody::BRowKind>(_m)) {
                return is_root_module(env)
                    ? std::optional(each(tags_of_kind(env, n), [&](const check_env::TagInfo& tg) { return tag_ctor(tg); }))
                    : std::optional<Array<Ctor>>{};
            }
            {
                return std::optional<Array<Ctor>>{};
            }
        }
        if (prism_rtl::is_none(_m)) {
            return (n == Text::lit("Fault")) || (n == Text::lit("Prelude.Fault"))
                ? is_root_module(env)
                ? std::optional(each(tags_of_kind(env, Text::lit("Prelude.Fault")), [&](const check_env::TagInfo& tg) { return tag_ctor(tg); }))
                : std::optional<Array<Ctor>>{}
                : std::optional<Array<Ctor>>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<check_types::Ty::TyElem>(_m)) {
        auto&& rw = prism_rtl::as<check_types::Ty::TyElem>(_m).a0;
        auto w = check_types::walk_row(st, rw);
        return w.tail != check_types::Tail(check_types::Tail::TlClosed{})
            ? std::optional<Array<Ctor>>{}
            : std::optional(each(tags_of_row(env, w), [&](const check_env::TagInfo& tg) { return tag_ctor(tg); }));
    }
    if (prism_rtl::is<check_types::Ty::TyElemAny>(_m)) {
        auto&& rw = prism_rtl::as<check_types::Ty::TyElemAny>(_m).a0;
        auto w = check_types::walk_row(st, rw);
        return w.tail != check_types::Tail(check_types::Tail::TlClosed{})
            ? std::optional<Array<Ctor>>{}
            : std::optional(each(tags_of_row(env, w), [&](const check_env::TagInfo& tg) { return tag_ctor(tg); }));
    }
    {
        return std::optional<Array<Ctor>>{};
    }
}


prism_rtl::Turn<std::optional<Array<Ctor>>> CtorsOf::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& t = this->t;
    auto env_1 = env;
    auto st_2 = st;
    auto t_3 = t;
    return call_then(check_types::start_walk(st_2, t_3), [=](check_types::Ty walk_2058) {
        return ({
            prism_rtl::is<check_types::Ty::TyCon>(walk_2058) && ({
            auto&& m2052_0_0 = prism_rtl::as<check_types::Ty::TyCon>(walk_2058).a0;
            auto&& m2052_0_1 = prism_rtl::as<check_types::Ty::TyCon>(walk_2058).a1;
            (m2052_0_0 == Text::lit("Bool")) && (m2052_0_1.size() == 0u);
        }) ? ({
            auto&& m2052_0_0 = prism_rtl::as<check_types::Ty::TyCon>(walk_2058).a0;
            auto&& m2052_0_1 = prism_rtl::as<check_types::Ty::TyCon>(walk_2058).a1;
            prism_rtl::finished(std::optional(Array(std::vector{Ctor{.name = Text::lit("True"), .arity = Nat(0u), .args = Array<check_types::Ty>{}, .shown = Text::lit("True")}, Ctor{.name = Text::lit("False"), .arity = Nat(0u), .args = Array<check_types::Ty>{}, .shown = Text::lit("False")}})));
        })
            : prism_rtl::is<check_types::Ty::TyCon>(walk_2058) && ({
            auto&& m2052_1_0 = prism_rtl::as<check_types::Ty::TyCon>(walk_2058).a0;
            auto&& m2052_1_1 = prism_rtl::as<check_types::Ty::TyCon>(walk_2058).a1;
            (m2052_1_0 == Text::lit("unit")) && (m2052_1_1.size() == 0u);
        }) ? ({
            auto&& m2052_1_0 = prism_rtl::as<check_types::Ty::TyCon>(walk_2058).a0;
            auto&& m2052_1_1 = prism_rtl::as<check_types::Ty::TyCon>(walk_2058).a1;
            prism_rtl::finished(std::optional(Array(std::vector{Ctor{.name = Text::lit("unit"), .arity = Nat(0u), .args = Array<check_types::Ty>{}, .shown = Text::lit("unit")}})));
        })
            : prism_rtl::is<check_types::Ty::TySig>(walk_2058) && ({
            auto&& m2052_2_0 = prism_rtl::as<check_types::Ty::TySig>(walk_2058).a0;
            auto&& i = prism_rtl::as<check_types::Ty::TySig>(walk_2058).a1;
            (m2052_2_0 == Text::lit("?"));
        }) ? ({
            auto&& m2052_2_0 = prism_rtl::as<check_types::Ty::TySig>(walk_2058).a0;
            auto&& i = prism_rtl::as<check_types::Ty::TySig>(walk_2058).a1;
            prism_rtl::finished(std::optional(Array(std::vector{Ctor{.name = Text::lit("?"), .arity = Nat(1u), .args = Array(std::vector{i}), .shown = Text::lit("? _")}, Ctor{.name = Text::lit("nil"), .arity = Nat(0u), .args = Array<check_types::Ty>{}, .shown = Text::lit("nil")}})));
        })
            : prism_rtl::is<check_types::Ty::TySig>(walk_2058) && ({
            auto&& m2052_3_0 = prism_rtl::as<check_types::Ty::TySig>(walk_2058).a0;
            auto&& i = prism_rtl::as<check_types::Ty::TySig>(walk_2058).a1;
            (m2052_3_0 == Text::lit("~"));
        }) ? ({
            auto&& m2052_3_0 = prism_rtl::as<check_types::Ty::TySig>(walk_2058).a0;
            auto&& i = prism_rtl::as<check_types::Ty::TySig>(walk_2058).a1;
            prism_rtl::finished(std::optional(Array(std::vector{Ctor{.name = Text::lit("~"), .arity = Nat(1u), .args = Array(std::vector{i}), .shown = Text::lit("~ _")}, Ctor{.name = Text::lit("Error"), .arity = Nat(2u), .args = Array(std::vector{check_types::Ty(check_types::Ty::TyCon{Text::lit("Prelude.Fault"), Array<check_types::Ty>{}}), check_types::t_text()}), .shown = Text::lit("Error(..)")}})));
        })
            : prism_rtl::is<check_types::Ty::TyTuple>(walk_2058) ? ({
            auto&& ts = prism_rtl::as<check_types::Ty::TyTuple>(walk_2058).a0;
            prism_rtl::finished(std::optional(Array(std::vector{Ctor{.name = Text::lit("tuple"), .arity = len(ts), .args = ts, .shown = prism_rtl::cat("((", lexer::join(each(ts, [&](const check_types::Ty& _p0) { return Text::lit("_"); }), Text::lit(", ")), "))")}})));
        })
            : prism_rtl::is<check_types::Ty::TyCon>(walk_2058) && ({
            auto&& m2052_5_0 = prism_rtl::as<check_types::Ty::TyCon>(walk_2058).a0;
            auto&& m2052_5_1 = prism_rtl::as<check_types::Ty::TyCon>(walk_2058).a1;
            (m2052_5_0 == Text::lit("Prelude.Error")) && (m2052_5_1.size() == 0u);
        }) ? ({
            auto&& m2052_5_0 = prism_rtl::as<check_types::Ty::TyCon>(walk_2058).a0;
            auto&& m2052_5_1 = prism_rtl::as<check_types::Ty::TyCon>(walk_2058).a1;
            prism_rtl::finished(std::optional(Array(std::vector{Ctor{.name = Text::lit("Error"), .arity = Nat(2u), .args = Array(std::vector{check_types::Ty(check_types::Ty::TyCon{Text::lit("Prelude.Fault"), Array<check_types::Ty>{}}), check_types::t_text()}), .shown = Text::lit("Error(..)")}})));
        })
            : prism_rtl::is<check_types::Ty::TyCon>(walk_2058) ? ({
            auto&& n = prism_rtl::as<check_types::Ty::TyCon>(walk_2058).a0;
            auto&& args = prism_rtl::as<check_types::Ty::TyCon>(walk_2058).a1;
            ({
            auto&& _m = prelude::get(env_1.g.types, n);
            prism_rtl::is_some(_m) ? ({
            auto&& ti = prism_rtl::some_of(_m);
            ({
            auto&& _m = ti.body;
            prism_rtl::is<check_env::TyBody::BChoice>(_m) ? ({
            auto&& cases = prism_rtl::as<check_env::TyBody::BChoice>(_m).a0;
            prism_rtl::finished(std::optional(run_to_end(each_job(cases, ({
            auto ti_4 = ti;
            auto args_5 = args;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ctor>(std::tuple<Text, Array<check_types::Ty>>)>>(prism_rtl::rc([=](std::tuple<Text, Array<check_types::Ty>> p0) {
            return ({
                auto ti_4_6 = ti_4;
                auto args_5_6 = args_5;
                entered(once_job([=]() {
                return ({
                    auto [cn, cargs] = p0;
                    (prism_rtl::more(prism_rtl::rc(CtorOfCase(ti_4_6, cn, cargs, args_5_6))));
                });
            }));
            });
        })));
        })))));
        })
            : prism_rtl::is<check_env::TyBody::BRecord>(_m) ? ({
            auto&& fields = prism_rtl::as<check_env::TyBody::BRecord>(_m).a0;
            prism_rtl::finished(std::optional(Array(std::vector{Ctor{.name = n, .arity = len(fields), .args = run_to_end(each_job(fields, ({
            auto ti_4 = ti;
            auto args_5 = args;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::Ty>(std::tuple<Text, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<Text, check_types::Ty> p0) {
            return ({
                auto ti_4_6 = ti_4;
                auto args_5_6 = args_5;
                entered(once_job([=]() {
                return ({
                    auto&& _ft = p0;
                    auto&& ft = std::get<1>(_ft);
                    (prism_rtl::more(prism_rtl::rc(check_types::SubstQ(check_env::param_inst(ti_4_6.params, args_5_6), ft))));
                });
            }));
            });
        })));
        }))), .shown = prism_rtl::cat(check_types::bare_name(n), "(..)")}})));
        })
            : prism_rtl::is<check_env::TyBody::BRowKind>(_m) ? is_root_module(env_1)
            ? prism_rtl::finished(std::optional(each(tags_of_kind(env_1, n), [&](const check_env::TagInfo& tg) { return tag_ctor(tg); })))
            : prism_rtl::finished(std::optional<Array<Ctor>>{})
            : prism_rtl::finished(std::optional<Array<Ctor>>{});
        });
        })
            : prism_rtl::is_none(_m) ? (n == Text::lit("Fault")) || (n == Text::lit("Prelude.Fault"))
            ? is_root_module(env_1)
            ? prism_rtl::finished(std::optional(each(tags_of_kind(env_1, Text::lit("Prelude.Fault")), [&](const check_env::TagInfo& tg) { return tag_ctor(tg); })))
            : prism_rtl::finished(std::optional<Array<Ctor>>{})
            : prism_rtl::finished(std::optional<Array<Ctor>>{})
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::is<check_types::Ty::TyElem>(walk_2058) ? ({
            auto&& rw = prism_rtl::as<check_types::Ty::TyElem>(walk_2058).a0;
            call_then(check_types::start_walk_row(st_2, rw), [=](check_types::Rw walk_row_3487) {
            return ({
                auto w = walk_row_3487;
                w.tail != check_types::Tail(check_types::Tail::TlClosed{})
                ? prism_rtl::finished(std::optional<Array<Ctor>>{})
                : prism_rtl::finished(std::optional(each(tags_of_row(env_1, w), [&](const check_env::TagInfo& tg) { return tag_ctor(tg); })));
            });
        });
        })
            : prism_rtl::is<check_types::Ty::TyElemAny>(walk_2058) ? ({
            auto&& rw = prism_rtl::as<check_types::Ty::TyElemAny>(walk_2058).a0;
            call_then(check_types::start_walk_row(st_2, rw), [=](check_types::Rw walk_row_3631) {
            return ({
                auto w = walk_row_3631;
                w.tail != check_types::Tail(check_types::Tail::TlClosed{})
                ? prism_rtl::finished(std::optional<Array<Ctor>>{})
                : prism_rtl::finished(std::optional(each(tags_of_row(env_1, w), [&](const check_env::TagInfo& tg) { return tag_ctor(tg); })));
            });
        });
        })
            : prism_rtl::finished(std::optional<Array<Ctor>>{});
        });
    });
}


/// `Start CtorsOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Array<Ctor>>> start_ctors_of(check_expr::Env env, check_types::St st, check_types::Ty t) {
    return prism_rtl::make_rc<CtorsOf>(env, st, t);
}


/// CtorOfCase: unbounded fn TyInfo, Text, [Ty], [Ty] -> Ctor
Ctor ctor_of_case(const check_env::TyInfo& ti, const Text& cn, const Array<check_types::Ty>& cargs, const Array<check_types::Ty>& args) {
    auto qk = check_env::qual_key(ti.home, cn);
    return Ctor{.name = qk, .arity = len(cargs), .args = run_to_end(each_job(cargs, ({
        auto ti_1 = ti;
        auto args_2 = args;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::Ty>(check_types::Ty)>>(prism_rtl::rc([=](check_types::Ty p0) {
        return ({
            auto ti_1_3 = ti_1;
            auto args_2_3 = args_2;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(check_types::SubstQ(check_env::param_inst(ti_1_3.params, args_2_3), a))));
            });
        }));
        });
    })));
    }))), .shown = len(cargs) == Nat(0u)
        ? cn
        : prism_rtl::cat(cn, " ", lexer::join(each(cargs, [&](const check_types::Ty& _p0) { return Text::lit("_"); }), Text::lit(", ")))};
}


prism_rtl::Turn<Ctor> CtorOfCase::cycle() const {
    const auto& ti = this->ti;
    const auto& cn = this->cn;
    const auto& cargs = this->cargs;
    const auto& args = this->args;
    auto qk = check_env::qual_key(ti.home, cn);
    auto args_1 = args;
    auto cargs_2 = cargs;
    auto cn_3 = cn;
    auto ti_4 = ti;
    return call_value(each_job(cargs_2, ({
        auto ti_4_5 = ti_4;
        auto args_1_5 = args_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::Ty>(check_types::Ty)>>(prism_rtl::rc([=](check_types::Ty p0) {
        return ({
            auto ti_4_5_5 = ti_4_5;
            auto args_1_5_5 = args_1_5;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(check_types::SubstQ(check_env::param_inst(ti_4_5_5.params, args_1_5_5), a))));
            });
        }));
        });
    })));
    })), [=](Array<check_types::Ty> each_3930) {
        return prism_rtl::finished(Ctor{.name = qk, .arity = len(cargs_2), .args = each_3930, .shown = len(cargs_2) == Nat(0u)
            ? cn_3
            : prism_rtl::cat(cn_3, " ", lexer::join(each(cargs_2, [&](const check_types::Ty& _p0) { return Text::lit("_"); }), Text::lit(", ")))});
    });
}


/// `Start CtorOfCase, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ctor> start_ctor_of_case(check_env::TyInfo ti, Text cn, Array<check_types::Ty> cargs, Array<check_types::Ty> args) {
    return prism_rtl::make_rc<CtorOfCase>(ti, cn, cargs, args);
}


/// TagCtor: fn TagInfo -> Ctor
Ctor tag_ctor(const check_env::TagInfo& tg) {
    return Ctor{.name = prism_rtl::cat("tag:", tg.name), .arity = len(tg.fields), .args = each(tg.fields, [&](const std::tuple<Text, check_types::Ty>& _p0) {
        auto&& ft = std::get<1>(_p0);
        return check_types::Ty(check_types::Ty::TyErr{});
    }), .shown = tg.name};
}


/// IsRootModule: fn Env -> Bool
bool is_root_module(const check_expr::Env& env) {
    return env.home == Text::lit("");
}


/// TagsOfKind: fn Env, Text -> [TagInfo]
Array<check_env::TagInfo> tags_of_kind(const check_expr::Env& env, const Text& kind) {
    return filter(values(env.g.tags), [&](const check_env::TagInfo& tg) { return (tg.kind == kind) || ((check_types::bare_name(tg.kind) == Text::lit("Fault")) && (check_types::bare_name(kind) == Text::lit("Fault"))); });
}


/// TagsOfRow: fn Env, Rw -> [TagInfo]
Array<check_env::TagInfo> tags_of_row(const check_expr::Env& env, const check_types::Rw& w) {
    return filter(values(env.g.tags), [&](const check_env::TagInfo& tg) { return ((tg.kind == Text::lit("Element")) && check_types::has_text(w.fams, tg.family)) && (!check_types::has_text(w.minus, tg.name)); });
}


/// ToPat: unbounded fn Env, Pattern -> Pat
Pat to_pat(const check_expr::Env& env, const ast::Pattern_& p_) {
    auto&& _m = p_.kind;
    if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
        auto bare = or_(index(n->path_, Nat(0u)), Text::lit(""));
        return (len(n->path_) > Nat(1u)) && check_env::has_key(env.g.tags, check_env::dotted(n->path_))
            ? Pat(Pat::PtCon{prism_rtl::cat("tag:", check_env::dotted(n->path_)), Array<Pat>{}})
            : (check_env::is_upper_text(bare) && (len_text(n.sigils) == Nat(0u))) && check_expr::is_ctor_name(env, n)
            ? Pat(Pat::PtCon{ctor_key(env, n), Array<Pat>{}})
            : Pat(Pat::PtAny{});
    }
    if (prism_rtl::is<ast::PatternKind::PIgnore>(_m)) {
        return Pat(Pat::PtAny{});
    }
    if (prism_rtl::is<ast::PatternKind::PLit>(_m)) {
        auto&& l = prism_rtl::as<ast::PatternKind::PLit>(_m).a0;
        return Pat(Pat::PtLit{lit_text(l)});
    }
    if (prism_rtl::is<ast::PatternKind::PNeg>(_m)) {
        auto&& l = prism_rtl::as<ast::PatternKind::PNeg>(_m).a0;
        return Pat(Pat::PtLit{prism_rtl::cat("-", lit_text(l))});
    }
    if (prism_rtl::is<ast::PatternKind::PUnit>(_m)) {
        return Pat(Pat::PtCon{Text::lit("unit"), Array<Pat>{}});
    }
    if (prism_rtl::is<ast::PatternKind::PNil>(_m)) {
        return Pat(Pat::PtCon{Text::lit("nil"), Array<Pat>{}});
    }
    if (prism_rtl::is<ast::PatternKind::PCtor>(_m)) {
        auto&& n = prism_rtl::as<ast::PatternKind::PCtor>(_m).a0;
        auto&& args = prism_rtl::as<ast::PatternKind::PCtor>(_m).a1;
        return check_env::has_key(env.g.tags, check_env::dotted(n->path_))
            ? Pat(Pat::PtCon{prism_rtl::cat("tag:", check_env::dotted(n->path_)), Array<Pat>{}})
            : Pat(Pat::PtCon{ctor_key(env, n), run_to_end(each_job(args, ({
            auto env_1 = env;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(ast::Pattern_)>>(prism_rtl::rc([=](ast::Pattern_ p0) {
            return ({
                auto env_1_2 = env_1;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(ToPat(env_1_2, a))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<ast::PatternKind::PRecord>(_m)) {
        auto&& n = prism_rtl::as<ast::PatternKind::PRecord>(_m).a0;
        auto&& fields = prism_rtl::as<ast::PatternKind::PRecord>(_m).a1;
        return record_pat(env, n, fields);
    }
    if (prism_rtl::is<ast::PatternKind::PSigil>(_m)) {
        auto&& s = prism_rtl::as<ast::PatternKind::PSigil>(_m).a0;
        auto&& q = prism_rtl::as<ast::PatternKind::PSigil>(_m).a1;
        return Pat(Pat::PtCon{s, Array(std::vector{to_pat(env, q)})});
    }
    if (prism_rtl::is<ast::PatternKind::PTuple>(_m)) {
        auto&& ps = prism_rtl::as<ast::PatternKind::PTuple>(_m).a0;
        return Pat(Pat::PtCon{Text::lit("tuple"), run_to_end(each_job(ps, ({
            auto env_1 = env;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(ast::Pattern_)>>(prism_rtl::rc([=](ast::Pattern_ p0) {
            return ({
                auto env_1_2 = env_1;
                entered(once_job([=]() {
                return ({
                    auto q = p0;
                    (prism_rtl::more(prism_rtl::rc(ToPat(env_1_2, q))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<ast::PatternKind::PArray>(_m)) {
        auto&& ps = prism_rtl::as<ast::PatternKind::PArray>(_m).a0;
        return Pat(Pat::PtCon{prism_rtl::cat("len", len(ps)), run_to_end(each_job(ps, ({
            auto env_1 = env;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(ast::Pattern_)>>(prism_rtl::rc([=](ast::Pattern_ p0) {
            return ({
                auto env_1_2 = env_1;
                entered(once_job([=]() {
                return ({
                    auto q = p0;
                    (prism_rtl::more(prism_rtl::rc(ToPat(env_1_2, q))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<ast::PatternKind::PGroup>(_m)) {
        auto&& q = prism_rtl::as<ast::PatternKind::PGroup>(_m).a0;
        return to_pat(env, q);
    }
    if (prism_rtl::is<ast::PatternKind::PFamily>(_m)) {
        auto&& q = prism_rtl::as<ast::PatternKind::PFamily>(_m).a0;
        return Pat(Pat::PtFam{check_env::dotted(q->path_)});
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Pat> ToPat::cycle() const {
    const auto& env = this->env;
    const auto& p_ = this->p_;
    return ({
        auto&& _m = p_.kind;
        prism_rtl::is<ast::PatternKind::PName>(_m) ? ({
        auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
        ({
        auto bare = or_(index(n->path_, Nat(0u)), Text::lit(""));
        (len(n->path_) > Nat(1u)) && check_env::has_key(env.g.tags, check_env::dotted(n->path_))
        ? prism_rtl::finished(Pat(Pat::PtCon{prism_rtl::cat("tag:", check_env::dotted(n->path_)), Array<Pat>{}}))
        : (check_env::is_upper_text(bare) && (len_text(n.sigils) == Nat(0u))) && check_expr::is_ctor_name(env, n)
        ? prism_rtl::finished(Pat(Pat::PtCon{ctor_key(env, n), Array<Pat>{}}))
        : prism_rtl::finished(Pat(Pat::PtAny{}));
    });
    })
        : prism_rtl::is<ast::PatternKind::PIgnore>(_m) ? prism_rtl::finished(Pat(Pat::PtAny{}))
        : prism_rtl::is<ast::PatternKind::PLit>(_m) ? ({
        auto&& l = prism_rtl::as<ast::PatternKind::PLit>(_m).a0;
        prism_rtl::finished(Pat(Pat::PtLit{lit_text(l)}));
    })
        : prism_rtl::is<ast::PatternKind::PNeg>(_m) ? ({
        auto&& l = prism_rtl::as<ast::PatternKind::PNeg>(_m).a0;
        prism_rtl::finished(Pat(Pat::PtLit{prism_rtl::cat("-", lit_text(l))}));
    })
        : prism_rtl::is<ast::PatternKind::PUnit>(_m) ? prism_rtl::finished(Pat(Pat::PtCon{Text::lit("unit"), Array<Pat>{}}))
        : prism_rtl::is<ast::PatternKind::PNil>(_m) ? prism_rtl::finished(Pat(Pat::PtCon{Text::lit("nil"), Array<Pat>{}}))
        : prism_rtl::is<ast::PatternKind::PCtor>(_m) ? ({
        auto&& n = prism_rtl::as<ast::PatternKind::PCtor>(_m).a0;
        auto&& args = prism_rtl::as<ast::PatternKind::PCtor>(_m).a1;
        check_env::has_key(env.g.tags, check_env::dotted(n->path_))
        ? prism_rtl::finished(Pat(Pat::PtCon{prism_rtl::cat("tag:", check_env::dotted(n->path_)), Array<Pat>{}}))
        : ({
        auto args_1 = args;
        auto env_2 = env;
        auto n_3 = n;
        call_value(each_job(args_1, ({
        auto env_2_4 = env_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(ast::Pattern_)>>(prism_rtl::rc([=](ast::Pattern_ p0) {
        return ({
            auto env_2_4_4 = env_2_4;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(ToPat(env_2_4_4, a))));
            });
        }));
        });
    })));
    })), [=](Array<Pat> each_5432) { return prism_rtl::finished(Pat(Pat::PtCon{ctor_key(env_2, n_3), each_5432})); });
    });
    })
        : prism_rtl::is<ast::PatternKind::PRecord>(_m) ? ({
        auto&& n = prism_rtl::as<ast::PatternKind::PRecord>(_m).a0;
        auto&& fields = prism_rtl::as<ast::PatternKind::PRecord>(_m).a1;
        prism_rtl::more(prism_rtl::rc(RecordPat(env, n, fields)));
    })
        : prism_rtl::is<ast::PatternKind::PSigil>(_m) ? ({
        auto&& s = prism_rtl::as<ast::PatternKind::PSigil>(_m).a0;
        auto&& q = prism_rtl::as<ast::PatternKind::PSigil>(_m).a1;
        ({
        auto env_1 = env;
        auto q_2 = q;
        auto s_3 = s;
        call_then(start_to_pat(env_1, q_2), [=](Pat to_pat_5547) { return prism_rtl::finished(Pat(Pat::PtCon{s_3, Array(std::vector{to_pat_5547})})); });
    });
    })
        : prism_rtl::is<ast::PatternKind::PTuple>(_m) ? ({
        auto&& ps = prism_rtl::as<ast::PatternKind::PTuple>(_m).a0;
        ({
        auto env_1 = env;
        auto ps_2 = ps;
        call_value(each_job(ps_2, ({
        auto env_1_3 = env_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(ast::Pattern_)>>(prism_rtl::rc([=](ast::Pattern_ p0) {
        return ({
            auto env_1_3_3 = env_1_3;
            entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(ToPat(env_1_3_3, q))));
            });
        }));
        });
    })));
    })), [=](Array<Pat> each_5594) { return prism_rtl::finished(Pat(Pat::PtCon{Text::lit("tuple"), each_5594})); });
    });
    })
        : prism_rtl::is<ast::PatternKind::PArray>(_m) ? ({
        auto&& ps = prism_rtl::as<ast::PatternKind::PArray>(_m).a0;
        ({
        auto env_1 = env;
        auto ps_2 = ps;
        call_value(each_job(ps_2, ({
        auto env_1_3 = env_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(ast::Pattern_)>>(prism_rtl::rc([=](ast::Pattern_ p0) {
        return ({
            auto env_1_3_3 = env_1_3;
            entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(ToPat(env_1_3_3, q))));
            });
        }));
        });
    })));
    })), [=](Array<Pat> each_5659) { return prism_rtl::finished(Pat(Pat::PtCon{prism_rtl::cat("len", len(ps_2)), each_5659})); });
    });
    })
        : prism_rtl::is<ast::PatternKind::PGroup>(_m) ? ({
        auto&& q = prism_rtl::as<ast::PatternKind::PGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ToPat(env, q)));
    })
        : prism_rtl::is<ast::PatternKind::PFamily>(_m) ? ({
        auto&& q = prism_rtl::as<ast::PatternKind::PFamily>(_m).a0;
        prism_rtl::finished(Pat(Pat::PtFam{check_env::dotted(q->path_)}));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ToPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Pat> start_to_pat(check_expr::Env env, ast::Pattern_ p_) {
    return prism_rtl::make_rc<ToPat>(env, p_);
}


/// LitText: fn Literal -> Text
Text lit_text(const ast::Literal& l) {
    auto&& _m = l.kind;
    if (prism_rtl::is<ast::LitKind::LInt>(_m)) {
        auto&& d = prism_rtl::as<ast::LitKind::LInt>(_m).a0;
        return d;
    }
    if (prism_rtl::is<ast::LitKind::LFloat>(_m)) {
        auto&& d = prism_rtl::as<ast::LitKind::LFloat>(_m).a0;
        return d;
    }
    if (prism_rtl::is<ast::LitKind::LChar>(_m)) {
        auto&& c = prism_rtl::as<ast::LitKind::LChar>(_m).a0;
        return prism_rtl::cat("'", c, "'");
    }
    if (prism_rtl::is<ast::LitKind::LText>(_m)) {
        auto&& segs = prism_rtl::as<ast::LitKind::LText>(_m).a0;
        return concat(each(segs, lit_seg_text));
    }
    if (prism_rtl::is<ast::LitKind::LDuration>(_m)) {
        auto&& d = prism_rtl::as<ast::LitKind::LDuration>(_m).a0;
        auto&& u = prism_rtl::as<ast::LitKind::LDuration>(_m).a1;
        return prism_rtl::cat(d, u);
    }
    prism_rtl::unreachable("no arm matched");
}


/// LitSegText: fn TextSeg -> Text
Text lit_seg_text(const ast::TextSeg& text_seg0) {
    if (prism_rtl::is<ast::TextSeg::SegPlain>(text_seg0)) {
        auto&& t = prism_rtl::as<ast::TextSeg::SegPlain>(text_seg0).a0;
        return t;
    }
    {
        return Text::lit("{}");
    }
}


/// CtorKey: fn Env, SName -> Text
Text ctor_key(const check_expr::Env& env, const ast::SName& n) {
    auto&& _qk_opt = check_env::resolve_value(env.g, env.home, n);
    auto&& qk_opt = std::get<0>(_qk_opt);
    return or_(qk_opt, check_env::sname_key(n));
}


/// RecordPat: unbounded fn Env, SName, [FieldPat] -> Pat
Pat record_pat(const check_expr::Env& env, const ast::SName& n, const Array<ast::FieldPat>& fields) {
    auto name = check_env::dotted(n->path_);
    auto&& _m = prelude::get(env.g.tags, name);
    if (prism_rtl::is_some(_m)) {
        auto&& tg = prism_rtl::some_of(_m);
        auto names = each(tg.fields, [&](const std::tuple<Text, check_types::Ty>& _p0) {
            auto&& f = std::get<0>(_p0);
            return f;
        });
        return Pat(Pat::PtCon{prism_rtl::cat("tag:", name), run_to_end(each_job(names, ({
            auto env_1 = env;
            auto fields_2 = fields;
            auto names_3 = names;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(Text)>>(prism_rtl::rc([=](Text p0) {
            return ({
                auto env_1_4 = env_1;
                auto fields_2_4 = fields_2;
                auto names_3_4 = names_3;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    (prism_rtl::more(prism_rtl::rc(FieldPatFor(env_1_4, fields_2_4, names_3_4, f))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is_none(_m)) {
        auto qk = ctor_key(env, n);
        auto fnames = check_types::bare_name(qk) == Text::lit("Error")
            ? Array(std::vector{Text::lit("kind"), Text::lit("message")})
            : or_(prelude::get(env.g.ctors, qk), dummy_ctor()).fields;
        auto pkey = check_types::bare_name(qk) == Text::lit("Error") ? Text::lit("Error") : qk;
        return Pat(Pat::PtCon{pkey, run_to_end(each_job(fnames, ({
            auto env_1 = env;
            auto fields_2 = fields;
            auto fnames_3 = fnames;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(Text)>>(prism_rtl::rc([=](Text p0) {
            return ({
                auto env_1_4 = env_1;
                auto fields_2_4 = fields_2;
                auto fnames_3_4 = fnames_3;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    (prism_rtl::more(prism_rtl::rc(FieldPatFor(env_1_4, fields_2_4, fnames_3_4, f))));
                });
            }));
            });
        })));
        })))});
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Pat> RecordPat::cycle() const {
    const auto& env = this->env;
    const auto& n = this->n;
    const auto& fields = this->fields;
    auto name = check_env::dotted(n->path_);
    return ({
        auto&& _m = prelude::get(env.g.tags, name);
        prism_rtl::is_some(_m) ? ({
        auto&& tg = prism_rtl::some_of(_m);
        ({
        auto names = each(tg.fields, [&](const std::tuple<Text, check_types::Ty>& _p0) {
            auto&& f = std::get<0>(_p0);
            return f;
        });
        auto env_1 = env;
        auto fields_2 = fields;
        call_value(each_job(names, ({
        auto env_1_3 = env_1;
        auto fields_2_3 = fields_2;
        auto names_3 = names;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(Text)>>(prism_rtl::rc([=](Text p0) {
        return ({
            auto env_1_3_4 = env_1_3;
            auto fields_2_3_4 = fields_2_3;
            auto names_3_4 = names_3;
            entered(once_job([=]() {
            return ({
                auto f = p0;
                (prism_rtl::more(prism_rtl::rc(FieldPatFor(env_1_3_4, fields_2_3_4, names_3_4, f))));
            });
        }));
        });
    })));
    })), [=](Array<Pat> each_6498) { return prism_rtl::finished(Pat(Pat::PtCon{prism_rtl::cat("tag:", name), each_6498})); });
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto qk = ctor_key(env, n);
        auto fnames = check_types::bare_name(qk) == Text::lit("Error")
            ? Array(std::vector{Text::lit("kind"), Text::lit("message")})
            : or_(prelude::get(env.g.ctors, qk), dummy_ctor()).fields;
        auto pkey = check_types::bare_name(qk) == Text::lit("Error") ? Text::lit("Error") : qk;
        auto env_1 = env;
        auto fields_2 = fields;
        call_value(each_job(fnames, ({
        auto env_1_3 = env_1;
        auto fields_2_3 = fields_2;
        auto fnames_3 = fnames;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(Text)>>(prism_rtl::rc([=](Text p0) {
        return ({
            auto env_1_3_4 = env_1_3;
            auto fields_2_3_4 = fields_2_3;
            auto fnames_3_4 = fnames_3;
            entered(once_job([=]() {
            return ({
                auto f = p0;
                (prism_rtl::more(prism_rtl::rc(FieldPatFor(env_1_3_4, fields_2_3_4, fnames_3_4, f))));
            });
        }));
        });
    })));
    })), [=](Array<Pat> each_6814) { return prism_rtl::finished(Pat(Pat::PtCon{pkey, each_6814})); });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start RecordPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Pat> start_record_pat(check_expr::Env env, ast::SName n, Array<ast::FieldPat> fields) {
    return prism_rtl::make_rc<RecordPat>(env, n, fields);
}


/// let dummyCtor
check_env::CtorInfo dummy_ctor() {
    return check_env::CtorInfo{.name = Text::lit(""), .owner = Text::lit(""), .params = Array<Text>{}, .args = Array<check_types::Ty>{}, .fields = Array<Text>{}, .ty = check_types::Ty(check_types::Ty::TyErr{}), .index = Nat(0u)};
}


/// FieldPatFor: unbounded fn Env, [FieldPat], [Text], Text -> Pat
Pat field_pat_for(const check_expr::Env& env, const Array<ast::FieldPat>& fields, const Array<Text>& names, const Text& f) {
    return run_to_end(fold_job(check_errors::range0(len(fields)), Pat(Pat::PtAny{}), ({
        auto fields_1 = fields;
        auto names_2 = names;
        auto f_3 = f;
        auto env_4 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(std::tuple<Pat, Nat>)>>(prism_rtl::rc([=](std::tuple<Pat, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto fields_1_5 = fields_1;
            auto names_2_5 = names_2;
            auto f_3_5 = f_3;
            auto env_4_5 = env_4;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto i = p1;
                ({
                auto&& _m = index(fields_1_5, i);
                prism_rtl::is_some(_m) ? ({
                auto&& fp = prism_rtl::some_of(_m);
                check_expr::field_pat_name(fp, names_2_5, i) == f_3_5
                ? prism_rtl::more(prism_rtl::rc(ToPat(env_4_5, fp.pattern)))
                : prism_rtl::finished(acc);
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(acc)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Pat> FieldPatFor::cycle() const {
    const auto& env = this->env;
    const auto& fields = this->fields;
    const auto& names = this->names;
    const auto& f = this->f;
    return fold_job(check_errors::range0(len(fields)), Pat(Pat::PtAny{}), ({
        auto fields_1 = fields;
        auto names_2 = names;
        auto f_3 = f;
        auto env_4 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(std::tuple<Pat, Nat>)>>(prism_rtl::rc([=](std::tuple<Pat, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto fields_1_5 = fields_1;
            auto names_2_5 = names_2;
            auto f_3_5 = f_3;
            auto env_4_5 = env_4;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto i = p1;
                ({
                auto&& _m = index(fields_1_5, i);
                prism_rtl::is_some(_m) ? ({
                auto&& fp = prism_rtl::some_of(_m);
                check_expr::field_pat_name(fp, names_2_5, i) == f_3_5
                ? prism_rtl::more(prism_rtl::rc(ToPat(env_4_5, fp.pattern)))
                : prism_rtl::finished(acc);
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(acc)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start FieldPatFor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Pat> start_field_pat_for(check_expr::Env env, Array<ast::FieldPat> fields, Array<Text> names, Text f) {
    return prism_rtl::make_rc<FieldPatFor>(env, fields, names, f);
}


/// Useful: unbounded fn Env, St, [ [Pat] ], [Pat], [Ty] -> Bool
bool useful(const check_expr::Env& env, const check_types::St& st, const Array<Array<Pat>>& rows, const Array<Pat>& q, const Array<check_types::Ty>& tys) {
    auto&& _m = index(q, Nat(0u));
    if (prism_rtl::is_none(_m)) {
        return len(rows) == Nat(0u);
    }
    if (prism_rtl::is_some(_m)) {
        auto&& q1 = prism_rtl::some_of(_m);
        auto t1 = or_(index(tys, Nat(0u)), check_types::Ty(check_types::Ty::TyErr{}));
        auto rest = drop(tys, Nat(1u));
        if (prism_rtl::is<Pat::PtCon>(q1)) {
            auto&& c = prism_rtl::as<Pat::PtCon>(q1).a0;
            auto&& args = prism_rtl::as<Pat::PtCon>(q1).a1;
            auto ctor = ctor_named(env, st, t1, c, len(args));
            return useful(env, st, specialize(rows, ctor), append(args, drop(q, Nat(1u))), append(ctor->args, rest));
        }
        if (prism_rtl::is<Pat::PtLit>(q1)) {
            auto&& l = prism_rtl::as<Pat::PtLit>(q1).a0;
            return useful(env, st, specialize_lit(rows, l), drop(q, Nat(1u)), rest);
        }
        if (prism_rtl::is<Pat::PtFam>(q1)) {
            auto&& f = prism_rtl::as<Pat::PtFam>(q1).a0;
            auto&& _m = ctors_of(env, st, t1);
            if (prism_rtl::is_some(_m)) {
                auto&& cs = prism_rtl::some_of(_m);
                return run_to_end(fold_job(filter(cs, [&](const Ctor& c) { return ctor_family(c) == f; }), false, ({
                    auto env_1 = env;
                    auto st_2 = st;
                    auto rows_3 = rows;
                    auto q_4 = q;
                    auto rest_5 = rest;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Ctor>)>>(prism_rtl::rc([=](std::tuple<bool, Ctor> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto env_1_6 = env_1;
                        auto st_2_6 = st_2;
                        auto rows_3_6 = rows_3;
                        auto q_4_6 = q_4;
                        auto rest_5_6 = rest_5;
                        entered(once_job([=]() {
                        return ({
                            auto seen = p0;
                            auto c = p1;
                            (prism_rtl::finished(seen || useful(env_1_6, st_2_6, specialize(rows_3_6, c), append(wilds(c.arity), drop(q_4_6, Nat(1u))), append(c->args, rest_5_6))));
                        });
                    }));
                    });
                })));
                })));
            }
            if (prism_rtl::is_none(_m)) {
                return useful(env, st, default_rows(rows), drop(q, Nat(1u)), rest);
            }
            prism_rtl::unreachable("no arm matched");
        }
        if (prism_rtl::is<Pat::PtAny>(q1)) {
            auto heads = head_names(rows);
            auto&& _m = ctors_of(env, st, t1);
            if (prism_rtl::is_some(_m)) {
                auto&& cs = prism_rtl::some_of(_m);
                return complete(cs, heads, rows)
                    ? run_to_end(fold_job(cs, false, ({
                    auto env_1 = env;
                    auto st_2 = st;
                    auto rows_3 = rows;
                    auto q_4 = q;
                    auto rest_5 = rest;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Ctor>)>>(prism_rtl::rc([=](std::tuple<bool, Ctor> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto env_1_6 = env_1;
                        auto st_2_6 = st_2;
                        auto rows_3_6 = rows_3;
                        auto q_4_6 = q_4;
                        auto rest_5_6 = rest_5;
                        entered(once_job([=]() {
                        return ({
                            auto seen = p0;
                            auto c = p1;
                            (prism_rtl::finished(seen || useful(env_1_6, st_2_6, specialize(rows_3_6, c), append(wilds(c.arity), drop(q_4_6, Nat(1u))), append(c->args, rest_5_6))));
                        });
                    }));
                    });
                })));
                })))
                    : useful(env, st, default_rows(rows), drop(q, Nat(1u)), rest);
            }
            if (prism_rtl::is_none(_m)) {
                return useful(env, st, default_rows(rows), drop(q, Nat(1u)), rest);
            }
            prism_rtl::unreachable("no arm matched");
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> Useful::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& rows = this->rows;
    const auto& q = this->q;
    const auto& tys = this->tys;
    return ({
        auto&& _m = index(q, Nat(0u));
        prism_rtl::is_none(_m) ? prism_rtl::finished(len(rows) == Nat(0u))
        : prism_rtl::is_some(_m) ? ({
        auto&& q1 = prism_rtl::some_of(_m);
        ({
        auto t1 = or_(index(tys, Nat(0u)), check_types::Ty(check_types::Ty::TyErr{}));
        auto rest = drop(tys, Nat(1u));
        ({
        prism_rtl::is<Pat::PtCon>(q1) ? ({
        auto&& c = prism_rtl::as<Pat::PtCon>(q1).a0;
        auto&& args = prism_rtl::as<Pat::PtCon>(q1).a1;
        ({
        auto args_1 = args;
        auto c_2 = c;
        auto env_3 = env;
        auto q_4 = q;
        auto rows_5 = rows;
        auto st_6 = st;
        call_then(start_ctor_named(env_3, st_6, t1, c_2, len(args_1)), [=](Ctor ctor_named_7610) {
        return ({
            auto ctor = ctor_named_7610;
            (prism_rtl::more(prism_rtl::rc(Useful(env_3, st_6, specialize(rows_5, ctor), append(args_1, drop(q_4, Nat(1u))), append(ctor->args, rest)))));
        });
    });
    });
    })
        : prism_rtl::is<Pat::PtLit>(q1) ? ({
        auto&& l = prism_rtl::as<Pat::PtLit>(q1).a0;
        prism_rtl::more(prism_rtl::rc(Useful(env, st, specialize_lit(rows, l), drop(q, Nat(1u)), rest)));
    })
        : prism_rtl::is<Pat::PtFam>(q1) ? ({
        auto&& f = prism_rtl::as<Pat::PtFam>(q1).a0;
        ({
        auto env_1 = env;
        auto f_2 = f;
        auto q_3 = q;
        auto rows_4 = rows;
        auto st_5 = st;
        call_then(start_ctors_of(env_1, st_5, t1), [=](std::optional<Array<Ctor>> ctors_of_7864) {
        return ({
            prism_rtl::is_some(ctors_of_7864) ? ({
            auto&& cs = prism_rtl::some_of(ctors_of_7864);
            fold_job(filter(cs, [&](const Ctor& c) { return ctor_family(c) == f_2; }), false, ({
            auto env_1_6 = env_1;
            auto st_5_6 = st_5;
            auto rows_4_6 = rows_4;
            auto q_3_6 = q_3;
            auto rest_6 = rest;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Ctor>)>>(prism_rtl::rc([=](std::tuple<bool, Ctor> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env_1_6_7 = env_1_6;
                auto st_5_6_7 = st_5_6;
                auto rows_4_6_7 = rows_4_6;
                auto q_3_6_7 = q_3_6;
                auto rest_6_7 = rest_6;
                entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto c = p1;
                    (prism_rtl::finished(seen || useful(env_1_6_7, st_5_6_7, specialize(rows_4_6_7, c), append(wilds(c.arity), drop(q_3_6_7, Nat(1u))), append(c->args, rest_6_7))));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is_none(ctors_of_7864) ? prism_rtl::more(prism_rtl::rc(Useful(env_1, st_5, default_rows(rows_4), drop(q_3, Nat(1u)), rest)))
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    });
    })
        : prism_rtl::is<Pat::PtAny>(q1) ? ({
        auto heads = head_names(rows);
        auto env_1 = env;
        auto q_2 = q;
        auto rows_3 = rows;
        auto st_4 = st;
        call_then(start_ctors_of(env_1, st_4, t1), [=](std::optional<Array<Ctor>> ctors_of_8236) {
        return ({
            prism_rtl::is_some(ctors_of_8236) ? ({
            auto&& cs = prism_rtl::some_of(ctors_of_8236);
            complete(cs, heads, rows_3)
            ? fold_job(cs, false, ({
            auto env_1_5 = env_1;
            auto st_4_5 = st_4;
            auto rows_3_5 = rows_3;
            auto q_2_5 = q_2;
            auto rest_5 = rest;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Ctor>)>>(prism_rtl::rc([=](std::tuple<bool, Ctor> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env_1_5_6 = env_1_5;
                auto st_4_5_6 = st_4_5;
                auto rows_3_5_6 = rows_3_5;
                auto q_2_5_6 = q_2_5;
                auto rest_5_6 = rest_5;
                entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto c = p1;
                    (prism_rtl::finished(seen || useful(env_1_5_6, st_4_5_6, specialize(rows_3_5_6, c), append(wilds(c.arity), drop(q_2_5_6, Nat(1u))), append(c->args, rest_5_6))));
                });
            }));
            });
        })));
        }))->cycle()
            : prism_rtl::more(prism_rtl::rc(Useful(env_1, st_4, default_rows(rows_3), drop(q_2, Nat(1u)), rest)));
        })
            : prism_rtl::is_none(ctors_of_8236) ? prism_rtl::more(prism_rtl::rc(Useful(env_1, st_4, default_rows(rows_3), drop(q_2, Nat(1u)), rest)))
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start Useful, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_useful(check_expr::Env env, check_types::St st, Array<Array<Pat>> rows, Array<Pat> q, Array<check_types::Ty> tys) {
    return prism_rtl::make_rc<Useful>(env, st, rows, q, tys);
}


/// CtorFamily: fn Ctor -> Text
Text ctor_family(const Ctor& c) {
    return lexer::has_prefix(c.name, Text::lit("tag:"))
        ? check_env::dotted(lexer::pop(split(lexer::drop_prefix(c.name, Text::lit("tag:")), Text::lit("."))))
        : Text::lit("");
}


/// Wilds: fn Nat -> [Pat]
Array<Pat> wilds(const Nat& n) {
    return each(check_errors::range0(n), [&](const Nat& _p0) { return Pat(Pat::PtAny{}); });
}


/// CtorNamed: unbounded fn Env, St, Ty, Text, Nat -> Ctor
Ctor ctor_named(const check_expr::Env& env, const check_types::St& st, const check_types::Ty& t, const Text& c, const Nat& arity) {
    auto&& _m = ctors_of(env, st, t);
    if (prism_rtl::is_some(_m)) {
        auto&& cs = prism_rtl::some_of(_m);
        auto&& _m = find_ctor(cs, c);
        if (prism_rtl::is_some(_m)) {
            auto&& found = prism_rtl::some_of(_m);
            return found;
        }
        if (prism_rtl::is_none(_m)) {
            return Ctor{.name = c, .arity = arity, .args = each(check_errors::range0(arity), [&](const Nat& _p0) { return check_types::Ty(check_types::Ty::TyErr{}); }), .shown = c};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_none(_m)) {
        return Ctor{.name = c, .arity = arity, .args = each(check_errors::range0(arity), [&](const Nat& _p0) { return check_types::Ty(check_types::Ty::TyErr{}); }), .shown = c};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Ctor> CtorNamed::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& t = this->t;
    const auto& c = this->c;
    const auto& arity = this->arity;
    auto arity_1 = arity;
    auto c_2 = c;
    auto env_3 = env;
    auto st_4 = st;
    auto t_5 = t;
    return call_then(start_ctors_of(env_3, st_4, t_5), [=](std::optional<Array<Ctor>> ctors_of_9031) {
        return ({
            prism_rtl::is_some(ctors_of_9031) ? ({
            auto&& cs = prism_rtl::some_of(ctors_of_9031);
            ({
            auto&& _m = find_ctor(cs, c_2);
            prism_rtl::is_some(_m) ? ({
            auto&& found = prism_rtl::some_of(_m);
            prism_rtl::finished(found);
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(Ctor{.name = c_2, .arity = arity_1, .args = each(check_errors::range0(arity_1), [&](const Nat& _p0) { return check_types::Ty(check_types::Ty::TyErr{}); }), .shown = c_2})
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::is_none(ctors_of_9031) ? prism_rtl::finished(Ctor{.name = c_2, .arity = arity_1, .args = each(check_errors::range0(arity_1), [&](const Nat& _p0) { return check_types::Ty(check_types::Ty::TyErr{}); }), .shown = c_2})
            : throw prism_rtl::Panic("no arm matched");
        });
    });
}


/// `Start CtorNamed, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ctor> start_ctor_named(check_expr::Env env, check_types::St st, check_types::Ty t, Text c, Nat arity) {
    return prism_rtl::make_rc<CtorNamed>(env, st, t, c, arity);
}


/// ?FindCtor: fn [Ctor], Text -> ?Ctor
std::optional<Ctor> find_ctor(const Array<Ctor>& cs, const Text& c) {
    return fold(cs, std::optional<Ctor>{}, [&](const std::optional<Ctor>& found_opt, const Ctor& x) {
        return ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Ctor>> _v;
            if (prism_rtl::is_some(found_opt)) {
                auto&& f = prism_rtl::some_of(found_opt);
                _v.set(std::optional(f));
                goto _done;
            }
            if (prism_rtl::is_none(found_opt)) {
                _v.set((x.name == c) || (check_types::bare_name(x.name) == check_types::bare_name(c))
                    ? std::optional(x)
                    : std::optional<Ctor>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// Specialize: fn [ [Pat] ], Ctor -> [ [Pat] ]
Array<Array<Pat>> specialize(const Array<Array<Pat>>& rows, const Ctor& c) {
    return fold(rows, Array<Array<Pat>>{}, [&](const Array<Array<Pat>>& acc, const Array<Pat>& prow) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Array<Pat>>> _v;
            auto&& _m = index(prow, Nat(0u));
            if (prism_rtl::is_some(_m) && prism_rtl::is<Pat::PtCon>(prism_rtl::some_of(_m))) {
                auto&& d = prism_rtl::as<Pat::PtCon>(prism_rtl::some_of(_m)).a0;
                auto&& args = prism_rtl::as<Pat::PtCon>(prism_rtl::some_of(_m)).a1;
                _v.set((d == c.name) || (check_types::bare_name(d) == check_types::bare_name(c.name))
                    ? prelude::push(acc, append(pad(args, c.arity), drop(prow, Nat(1u))))
                    : acc);
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<Pat::PtAny>(prism_rtl::some_of(_m))) {
                _v.set(prelude::push(acc, append(wilds(c.arity), drop(prow, Nat(1u)))));
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<Pat::PtFam>(prism_rtl::some_of(_m))) {
                auto&& f = prism_rtl::as<Pat::PtFam>(prism_rtl::some_of(_m)).a0;
                _v.set(ctor_family(c) == f
                    ? prelude::push(acc, append(wilds(c.arity), drop(prow, Nat(1u))))
                    : acc);
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// Pad: fn [Pat], Nat -> [Pat]
Array<Pat> pad(const Array<Pat>& args, const Nat& n) {
    return len(args) >= n
        ? take(args, n)
        : append(args, wilds(or_(n.checked_sub(len(args)), Nat(0u))));
}


/// SpecializeLit: fn [ [Pat] ], Text -> [ [Pat] ]
Array<Array<Pat>> specialize_lit(const Array<Array<Pat>>& rows, const Text& l) {
    return fold(rows, Array<Array<Pat>>{}, [&](const Array<Array<Pat>>& acc, const Array<Pat>& prow) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Array<Pat>>> _v;
            auto&& _m = index(prow, Nat(0u));
            if (prism_rtl::is_some(_m) && prism_rtl::is<Pat::PtLit>(prism_rtl::some_of(_m))) {
                auto&& m = prism_rtl::as<Pat::PtLit>(prism_rtl::some_of(_m)).a0;
                _v.set(m == l ? prelude::push(acc, drop(prow, Nat(1u))) : acc);
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<Pat::PtAny>(prism_rtl::some_of(_m))) {
                _v.set(prelude::push(acc, drop(prow, Nat(1u))));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// DefaultRows: fn [ [Pat] ] -> [ [Pat] ]
Array<Array<Pat>> default_rows(const Array<Array<Pat>>& rows) {
    return fold(rows, Array<Array<Pat>>{}, [&](const Array<Array<Pat>>& acc, const Array<Pat>& prow) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Array<Pat>>> _v;
            auto&& _m = index(prow, Nat(0u));
            if (prism_rtl::is_some(_m) && prism_rtl::is<Pat::PtAny>(prism_rtl::some_of(_m))) {
                _v.set(prelude::push(acc, drop(prow, Nat(1u))));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// HeadNames: fn [ [Pat] ] -> [Text]
Array<Text> head_names(const Array<Array<Pat>>& rows) {
    return fold(rows, Array<Text>{}, [&](const Array<Text>& acc, const Array<Pat>& prow) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = index(prow, Nat(0u));
            if (prism_rtl::is_some(_m) && prism_rtl::is<Pat::PtCon>(prism_rtl::some_of(_m))) {
                auto&& c = prism_rtl::as<Pat::PtCon>(prism_rtl::some_of(_m)).a0;
                _v.set(check_types::add_text(acc, c));
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<Pat::PtFam>(prism_rtl::some_of(_m))) {
                auto&& f = prism_rtl::as<Pat::PtFam>(prism_rtl::some_of(_m)).a0;
                _v.set(check_types::add_text(acc, prism_rtl::cat("fam:", f)));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// Complete: fn [Ctor], [Text], [ [Pat] ] -> Bool
bool complete(const Array<Ctor>& cs, const Array<Text>& heads, const Array<Array<Pat>>& rows) {
    return (len(cs) > Nat(0u)) && fold(cs, true, [&](const bool& ok, const Ctor& c) { return ok && ((check_types::has_text(heads, c.name) || check_types::has_text(each(heads, [&](const Text& h) { return check_types::bare_name(h); }), check_types::bare_name(c.name))) || check_types::has_text(heads, prism_rtl::cat("fam:", ctor_family(c)))); });
}


/// ?Witness: unbounded fn Env, St, [ [Pat] ], [Ty] -> ?[Text]
std::optional<Array<Text>> witness(const check_expr::Env& env, const check_types::St& st, const Array<Array<Pat>>& rows, const Array<check_types::Ty>& tys) {
    auto&& _m = index(tys, Nat(0u));
    if (prism_rtl::is_none(_m)) {
        return len(rows) == Nat(0u)
            ? std::optional(Array<Text>{})
            : std::optional<Array<Text>>{};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& t1 = prism_rtl::some_of(_m);
        auto rest = drop(tys, Nat(1u));
        auto heads = head_names(rows);
        auto&& _m = ctors_of(env, st, t1);
        if (prism_rtl::is_some(_m)) {
            auto&& cs = prism_rtl::some_of(_m);
            return complete(cs, heads, rows)
                ? run_to_end(fold_job(cs, std::optional<Array<Text>>{}, ({
                auto env_1 = env;
                auto st_2 = st;
                auto rows_3 = rows;
                auto rest_4 = rest;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<Array<Text>>>(std::tuple<std::optional<Array<Text>>, Ctor>)>>(prism_rtl::rc([=](std::tuple<std::optional<Array<Text>>, Ctor> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto env_1_5 = env_1;
                    auto st_2_5 = st_2;
                    auto rows_3_5 = rows_3;
                    auto rest_4_5 = rest_4;
                    entered(once_job([=]() {
                    return ({
                        auto found_opt = p0;
                        auto c = p1;
                        ({
                        prism_rtl::is_some(found_opt) ? ({
                        auto&& f = prism_rtl::some_of(found_opt);
                        prism_rtl::finished(std::optional(f));
                    })
                        : prism_rtl::is_none(found_opt) ? call_then(start_witness(env_1_5, st_2_5, specialize(rows_3_5, c), append(c->args, rest_4_5)), [=](std::optional<Array<Text>> witness_11607) {
                        return ({
                            prism_rtl::is_some(witness_11607) ? ({
                            auto&& w = prism_rtl::some_of(witness_11607);
                            prism_rtl::finished(std::optional(append(Array(std::vector{show_witness(c, take(w, c.arity))}), drop(w, c.arity))));
                        })
                            : prism_rtl::is_none(witness_11607) ? prism_rtl::finished(std::optional<Array<Text>>{})
                            : throw prism_rtl::Panic("no arm matched");
                        });
                    })
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                }));
                });
            })));
            })))
                : ({
                __label__ _done;
                prism_rtl::Slot<std::optional<Array<Text>>> _v;
                auto&& _m = witness(env, st, default_rows(rows), rest);
                if (prism_rtl::is_some(_m)) {
                    auto&& w = prism_rtl::some_of(_m);
                    _v.set(({
                        auto missing = filter(cs, [&](const Ctor& c) { return !(check_types::has_text(heads, c.name) || check_types::has_text(heads, prism_rtl::cat("fam:", ctor_family(c)))); });
                        auto shown = ({
                            __label__ _done;
                            prism_rtl::Slot<Text> _v;
                            auto&& _m = index(missing, Nat(0u));
                            if (prism_rtl::is_some(_m)) {
                                auto&& c = prism_rtl::some_of(_m);
                                _v.set(c.shown);
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(Text::lit("_"));
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        });
                        (std::optional(append(Array(std::vector{shown}), w)));
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::optional<Array<Text>>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        }
        if (prism_rtl::is_none(_m)) {
            auto&& _m = witness(env, st, default_rows(rows), rest);
            if (prism_rtl::is_some(_m)) {
                auto&& w = prism_rtl::some_of(_m);
                return std::optional(append(Array(std::vector{Text::lit("_")}), w));
            }
            if (prism_rtl::is_none(_m)) {
                return std::optional<Array<Text>>{};
            }
            prism_rtl::unreachable("no arm matched");
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::optional<Array<Text>>> Witness::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& rows = this->rows;
    const auto& tys = this->tys;
    return ({
        auto&& _m = index(tys, Nat(0u));
        prism_rtl::is_none(_m) ? len(rows) == Nat(0u)
        ? prism_rtl::finished(std::optional(Array<Text>{}))
        : prism_rtl::finished(std::optional<Array<Text>>{})
        : prism_rtl::is_some(_m) ? ({
        auto&& t1 = prism_rtl::some_of(_m);
        ({
        auto rest = drop(tys, Nat(1u));
        auto heads = head_names(rows);
        auto env_1 = env;
        auto rows_2 = rows;
        auto st_3 = st;
        call_then(start_ctors_of(env_1, st_3, t1), [=](std::optional<Array<Ctor>> ctors_of_11393) {
        return ({
            prism_rtl::is_some(ctors_of_11393) ? ({
            auto&& cs = prism_rtl::some_of(ctors_of_11393);
            complete(cs, heads, rows_2)
            ? fold_job(cs, std::optional<Array<Text>>{}, ({
            auto env_1_4 = env_1;
            auto st_3_4 = st_3;
            auto rows_2_4 = rows_2;
            auto rest_4 = rest;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<Array<Text>>>(std::tuple<std::optional<Array<Text>>, Ctor>)>>(prism_rtl::rc([=](std::tuple<std::optional<Array<Text>>, Ctor> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env_1_4_5 = env_1_4;
                auto st_3_4_5 = st_3_4;
                auto rows_2_4_5 = rows_2_4;
                auto rest_4_5 = rest_4;
                entered(once_job([=]() {
                return ({
                    auto found_opt = p0;
                    auto c = p1;
                    ({
                    prism_rtl::is_some(found_opt) ? ({
                    auto&& f = prism_rtl::some_of(found_opt);
                    prism_rtl::finished(std::optional(f));
                })
                    : prism_rtl::is_none(found_opt) ? call_then(start_witness(env_1_4_5, st_3_4_5, specialize(rows_2_4_5, c), append(c->args, rest_4_5)), [=](std::optional<Array<Text>> witness_11607) {
                    return ({
                        prism_rtl::is_some(witness_11607) ? ({
                        auto&& w = prism_rtl::some_of(witness_11607);
                        prism_rtl::finished(std::optional(append(Array(std::vector{show_witness(c, take(w, c.arity))}), drop(w, c.arity))));
                    })
                        : prism_rtl::is_none(witness_11607) ? prism_rtl::finished(std::optional<Array<Text>>{})
                        : throw prism_rtl::Panic("no arm matched");
                    });
                })
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        })));
        }))->cycle()
            : call_then(start_witness(env_1, st_3, default_rows(rows_2), rest), [=](std::optional<Array<Text>> witness_11837) {
            return ({
                prism_rtl::is_some(witness_11837) ? ({
                auto&& w = prism_rtl::some_of(witness_11837);
                ({
                auto missing = filter(cs, [&](const Ctor& c) { return !(check_types::has_text(heads, c.name) || check_types::has_text(heads, prism_rtl::cat("fam:", ctor_family(c)))); });
                auto shown = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = index(missing, Nat(0u));
                    if (prism_rtl::is_some(_m)) {
                        auto&& c = prism_rtl::some_of(_m);
                        _v.set(c.shown);
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Text::lit("_"));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                (prism_rtl::finished(std::optional(append(Array(std::vector{shown}), w))));
            });
            })
                : prism_rtl::is_none(witness_11837) ? prism_rtl::finished(std::optional<Array<Text>>{})
                : throw prism_rtl::Panic("no arm matched");
            });
        });
        })
            : prism_rtl::is_none(ctors_of_11393) ? call_then(start_witness(env_1, st_3, default_rows(rows_2), rest), [=](std::optional<Array<Text>> witness_12263) {
            return ({
                prism_rtl::is_some(witness_12263) ? ({
                auto&& w = prism_rtl::some_of(witness_12263);
                prism_rtl::finished(std::optional(append(Array(std::vector{Text::lit("_")}), w)));
            })
                : prism_rtl::is_none(witness_12263) ? prism_rtl::finished(std::optional<Array<Text>>{})
                : throw prism_rtl::Panic("no arm matched");
            });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start Witness, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Array<Text>>> start_witness(check_expr::Env env, check_types::St st, Array<Array<Pat>> rows, Array<check_types::Ty> tys) {
    return prism_rtl::make_rc<Witness>(env, st, rows, tys);
}


/// ShowWitness: fn Ctor, [Text] -> Text
Text show_witness(const Ctor& c, const Array<Text>& args) {
    return c.name == Text::lit("?")
        ? prism_rtl::cat("? ", or_(index(args, Nat(0u)), Text::lit("_")))
        : c.name == Text::lit("~")
        ? prism_rtl::cat("~ ", or_(index(args, Nat(0u)), Text::lit("_")))
        : c.name == Text::lit("tuple")
        ? prism_rtl::cat("((", lexer::join(args, Text::lit(", ")), "))")
        : (len(args) == Nat(0u)) || fold(args, true, [&](const bool& ok, const Text& a) { return ok && (a == Text::lit("_")); })
        ? c.shown
        : prism_rtl::cat(check_types::bare_name(c.name), " ", lexer::join(args, Text::lit(", ")));
}


/// MatchCoverage: unbounded fn Env, St, Ty, [Arm], Range -> St
check_types::St match_coverage(const check_expr::Env& env, const check_types::St& st, const check_types::Ty& t, const Array<ast::Arm>& arms, const ast::Range& span) {
    auto has_otherwise = fold(arms, false, [&](const bool& seen, const ast::Arm& a) { return seen || (a.pattern == std::optional<ast::Pattern_>{}); });
    auto tys = Array(std::vector{t});
    auto [rows, st2] = run_to_end(fold_job(arms, std::tuple{Array<Array<Pat>>{}, st}, ({
        auto env_1 = env;
        auto tys_2 = tys;
        auto t_3 = t;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Array<Pat>>, check_types::St>>(std::tuple<std::tuple<Array<Array<Pat>>, check_types::St>, ast::Arm>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Array<Pat>>, check_types::St>, ast::Arm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_4 = env_1;
            auto tys_2_4 = tys_2;
            auto t_3_4 = t_3;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto arm = p1;
                ({
                auto q = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Pat>> _v;
                    auto&& _m = arm.pattern;
                    if (prism_rtl::is_some(_m)) {
                        auto&& p_ = prism_rtl::some_of(_m);
                        _v.set(Array(std::vector{to_pat(env_1_4, p_)}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Array(std::vector{Pat(Pat::PtAny{})}));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                call_then(start_useful(env_1_4, s, acc, q, tys_2_4), [=](bool useful_13349) {
                return ({
                    auto reachable = useful_13349;
                    call_then(start_owns_row(env_1_4, s, t_3_4), [=](bool owns_row_13398) {
                    return ({
                        auto owns_all = owns_row_13398;
                        auto s2 = reachable
                            ? s
                            : (arm.pattern == std::optional<ast::Pattern_>{}) && (!owns_all)
                            ? s
                            : check_types::err_fix(s, Text::lit("unreachable"), arm_span(arm), Text::lit("this arm is never reached"), Text::lit("remove it, or put it above the arm that covers it"));
                        auto acc2 = arm.guard == std::optional<ast::Expr>{} ? prelude::push(acc, q) : acc;
                        (prism_rtl::finished(std::tuple{acc2, s2}));
                    });
                });
                });
            });
            });
            });
        }));
        });
    }));
    })));
    return has_otherwise
        ? st2
        : is_open_row(env, st2, t)
        ? check_types::err_fix(st2, Text::lit("row-not-closed"), span, prism_rtl::cat("a match over `", check_types::show_ty(st2, t), "` needs `otherwise:`"), Text::lit("add an `otherwise:` arm: the row's variable may hold tags this match cannot name"))
        : ({
        __label__ _done;
        prism_rtl::Slot<check_types::St> _v;
        auto&& _m = witness(env, st2, rows, tys);
        if (prism_rtl::is_some(_m)) {
            auto&& w = prism_rtl::some_of(_m);
            _v.set(check_types::err_fix(st2, Text::lit("not-exhaustive"), span, prism_rtl::cat("this match misses `", lexer::join(w, Text::lit(", ")), "`"), Text::lit("add an arm for it, or `otherwise:`")));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(st2);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<check_types::St> MatchCoverage::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& t = this->t;
    const auto& arms = this->arms;
    const auto& span = this->span;
    auto has_otherwise = fold(arms, false, [&](const bool& seen, const ast::Arm& a) { return seen || (a.pattern == std::optional<ast::Pattern_>{}); });
    auto tys = Array(std::vector{t});
    auto arms_1 = arms;
    auto env_2 = env;
    auto span_3 = span;
    auto st_4 = st;
    auto t_5 = t;
    return call_value(fold_job(arms_1, std::tuple{Array<Array<Pat>>{}, st_4}, ({
        auto env_2_6 = env_2;
        auto tys_6 = tys;
        auto t_5_7 = t_5;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Array<Pat>>, check_types::St>>(std::tuple<std::tuple<Array<Array<Pat>>, check_types::St>, ast::Arm>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Array<Pat>>, check_types::St>, ast::Arm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_2_6_7 = env_2_6;
            auto tys_6_7 = tys_6;
            auto t_5_7_7 = t_5_7;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto arm = p1;
                ({
                auto q = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Pat>> _v;
                    auto&& _m = arm.pattern;
                    if (prism_rtl::is_some(_m)) {
                        auto&& p_ = prism_rtl::some_of(_m);
                        _v.set(Array(std::vector{to_pat(env_2_6_7, p_)}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Array(std::vector{Pat(Pat::PtAny{})}));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                call_then(start_useful(env_2_6_7, s, acc, q, tys_6_7), [=](bool useful_13349) {
                return ({
                    auto reachable = useful_13349;
                    call_then(start_owns_row(env_2_6_7, s, t_5_7_7), [=](bool owns_row_13398) {
                    return ({
                        auto owns_all = owns_row_13398;
                        auto s2 = reachable
                            ? s
                            : (arm.pattern == std::optional<ast::Pattern_>{}) && (!owns_all)
                            ? s
                            : check_types::err_fix(s, Text::lit("unreachable"), arm_span(arm), Text::lit("this arm is never reached"), Text::lit("remove it, or put it above the arm that covers it"));
                        auto acc2 = arm.guard == std::optional<ast::Expr>{} ? prelude::push(acc, q) : acc;
                        (prism_rtl::finished(std::tuple{acc2, s2}));
                    });
                });
                });
            });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<Array<Pat>>, check_types::St> fold_13182) {
        return ({
            auto [rows, st2] = fold_13182;
            has_otherwise
            ? prism_rtl::finished(st2)
            : call_then(start_is_open_row(env_2, st2, t_5), [=](bool is_open_row_13746) {
            return is_open_row_13746
                ? call_then(check_types::start_show_ty(st2, t_5), [=](Text show_ty_13821) { return prism_rtl::finished(check_types::err_fix(st2, Text::lit("row-not-closed"), span_3, prism_rtl::cat("a match over `", show_ty_13821, "` needs `otherwise:`"), Text::lit("add an `otherwise:` arm: the row's variable may hold tags this match cannot name"))); })
                : call_then(start_witness(env_2, st2, rows, tys), [=](std::optional<Array<Text>> witness_13957) {
                return ({
                    prism_rtl::is_some(witness_13957) ? ({
                    auto&& w = prism_rtl::some_of(witness_13957);
                    prism_rtl::finished(check_types::err_fix(st2, Text::lit("not-exhaustive"), span_3, prism_rtl::cat("this match misses `", lexer::join(w, Text::lit(", ")), "`"), Text::lit("add an arm for it, or `otherwise:`")));
                })
                    : prism_rtl::is_none(witness_13957) ? prism_rtl::finished(st2)
                    : throw prism_rtl::Panic("no arm matched");
                });
            });
        });
        });
    });
}


/// `Start MatchCoverage, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_match_coverage(check_expr::Env env, check_types::St st, check_types::Ty t, Array<ast::Arm> arms, ast::Range span) {
    return prism_rtl::make_rc<MatchCoverage>(env, st, t, arms, span);
}


/// ArmSpan: fn Arm -> Range
ast::Range arm_span(const ast::Arm& a) {
    auto&& _m = a.pattern;
    if (prism_rtl::is_some(_m)) {
        auto&& p_ = prism_rtl::some_of(_m);
        return p_.span;
    }
    if (prism_rtl::is_none(_m)) {
        return a.span;
    }
    prism_rtl::unreachable("no arm matched");
}


/// IsOpenRow: unbounded fn Env, St, Ty -> Bool
bool is_open_row(const check_expr::Env& env, const check_types::St& st, const check_types::Ty& t) {
    auto&& _m = check_types::walk(st, t);
    if (prism_rtl::is<check_types::Ty::TyElem>(_m)) {
        auto&& rw = prism_rtl::as<check_types::Ty::TyElem>(_m).a0;
        return check_types::walk_row(st, rw).tail != check_types::Tail(check_types::Tail::TlClosed{});
    }
    if (prism_rtl::is<check_types::Ty::TyElemAny>(_m)) {
        auto&& rw = prism_rtl::as<check_types::Ty::TyElemAny>(_m).a0;
        return check_types::walk_row(st, rw).tail != check_types::Tail(check_types::Tail::TlClosed{});
    }
    if (prism_rtl::is<check_types::Ty::TyCon>(_m)) {
        auto&& n = prism_rtl::as<check_types::Ty::TyCon>(_m).a0;
        auto&& m14379_2_1 = prism_rtl::as<check_types::Ty::TyCon>(_m).a1;
        if (m14379_2_1.size() == 0u) {
            auto&& _m = prelude::get(env.g.types, n);
            if (prism_rtl::is_some(_m)) {
                auto&& ti = prism_rtl::some_of(_m);
                return (ti.body == check_env::TyBody(check_env::TyBody::BRowKind{})) && (!is_root_module(env));
            }
            if (prism_rtl::is_none(_m)) {
                return ((n == Text::lit("Fault")) || (n == Text::lit("Prelude.Fault"))) && (!is_root_module(env));
            }
            prism_rtl::unreachable("no arm matched");
        }
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> IsOpenRow::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& t = this->t;
    auto env_1 = env;
    auto st_2 = st;
    auto t_3 = t;
    return call_then(check_types::start_walk(st_2, t_3), [=](check_types::Ty walk_14385) {
        return ({
            prism_rtl::is<check_types::Ty::TyElem>(walk_14385) ? ({
            auto&& rw = prism_rtl::as<check_types::Ty::TyElem>(walk_14385).a0;
            call_then(check_types::start_walk_row(st_2, rw), [=](check_types::Rw walk_row_14421) { return prism_rtl::finished(walk_row_14421.tail != check_types::Tail(check_types::Tail::TlClosed{})); });
        })
            : prism_rtl::is<check_types::Ty::TyElemAny>(walk_14385) ? ({
            auto&& rw = prism_rtl::as<check_types::Ty::TyElemAny>(walk_14385).a0;
            call_then(check_types::start_walk_row(st_2, rw), [=](check_types::Rw walk_row_14473) { return prism_rtl::finished(walk_row_14473.tail != check_types::Tail(check_types::Tail::TlClosed{})); });
        })
            : prism_rtl::is<check_types::Ty::TyCon>(walk_14385) && ({
            auto&& n = prism_rtl::as<check_types::Ty::TyCon>(walk_14385).a0;
            auto&& m14379_2_1 = prism_rtl::as<check_types::Ty::TyCon>(walk_14385).a1;
            (m14379_2_1.size() == 0u);
        }) ? ({
            auto&& n = prism_rtl::as<check_types::Ty::TyCon>(walk_14385).a0;
            auto&& m14379_2_1 = prism_rtl::as<check_types::Ty::TyCon>(walk_14385).a1;
            ({
            auto&& _m = prelude::get(env_1.g.types, n);
            prism_rtl::is_some(_m) ? ({
            auto&& ti = prism_rtl::some_of(_m);
            prism_rtl::finished((ti.body == check_env::TyBody(check_env::TyBody::BRowKind{})) && (!is_root_module(env_1)));
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(((n == Text::lit("Fault")) || (n == Text::lit("Prelude.Fault"))) && (!is_root_module(env_1)))
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::finished(false);
        });
    });
}


/// `Start IsOpenRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_open_row(check_expr::Env env, check_types::St st, check_types::Ty t) {
    return prism_rtl::make_rc<IsOpenRow>(env, st, t);
}


/// OwnsRow: unbounded fn Env, St, Ty -> Bool
bool owns_row(const check_expr::Env& env, const check_types::St& st, const check_types::Ty& t) {
    auto&& _m = check_types::walk(st, t);
    if (prism_rtl::is<check_types::Ty::TyElem>(_m)) {
        auto&& rw = prism_rtl::as<check_types::Ty::TyElem>(_m).a0;
        return fold(check_types::walk_row(st, rw).fams, true, [&](const bool& ok, const Text& f) { return ok && (or_(prelude::get(env.g.fam_owner, f), Text::lit("")) == env.home); });
    }
    if (prism_rtl::is<check_types::Ty::TyCon>(_m)) {
        auto&& n = prism_rtl::as<check_types::Ty::TyCon>(_m).a0;
        auto&& m14848_1_1 = prism_rtl::as<check_types::Ty::TyCon>(_m).a1;
        if (m14848_1_1.size() == 0u) {
            auto&& _m = prelude::get(env.g.types, n);
            if (prism_rtl::is_some(_m)) {
                auto&& ti = prism_rtl::some_of(_m);
                return ti.body != check_env::TyBody(check_env::TyBody::BRowKind{});
            }
            if (prism_rtl::is_none(_m)) {
                return !((n == Text::lit("Fault")) || (n == Text::lit("Prelude.Fault")));
            }
            prism_rtl::unreachable("no arm matched");
        }
    }
    {
        return true;
    }
}


prism_rtl::Turn<bool> OwnsRow::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& t = this->t;
    auto env_1 = env;
    auto st_2 = st;
    auto t_3 = t;
    return call_then(check_types::start_walk(st_2, t_3), [=](check_types::Ty walk_14854) {
        return ({
            prism_rtl::is<check_types::Ty::TyElem>(walk_14854) ? ({
            auto&& rw = prism_rtl::as<check_types::Ty::TyElem>(walk_14854).a0;
            call_then(check_types::start_walk_row(st_2, rw), [=](check_types::Rw walk_row_14895) { return prism_rtl::finished(fold(walk_row_14895.fams, true, [&](const bool& ok, const Text& f) { return ok && (or_(prelude::get(env_1.g.fam_owner, f), Text::lit("")) == env_1.home); })); });
        })
            : prism_rtl::is<check_types::Ty::TyCon>(walk_14854) && ({
            auto&& n = prism_rtl::as<check_types::Ty::TyCon>(walk_14854).a0;
            auto&& m14848_1_1 = prism_rtl::as<check_types::Ty::TyCon>(walk_14854).a1;
            (m14848_1_1.size() == 0u);
        }) ? ({
            auto&& n = prism_rtl::as<check_types::Ty::TyCon>(walk_14854).a0;
            auto&& m14848_1_1 = prism_rtl::as<check_types::Ty::TyCon>(walk_14854).a1;
            ({
            auto&& _m = prelude::get(env_1.g.types, n);
            prism_rtl::is_some(_m) ? ({
            auto&& ti = prism_rtl::some_of(_m);
            prism_rtl::finished(ti.body != check_env::TyBody(check_env::TyBody::BRowKind{}));
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(!((n == Text::lit("Fault")) || (n == Text::lit("Prelude.Fault"))))
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::finished(true);
        });
    });
}


/// `Start OwnsRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_owns_row(check_expr::Env env, check_types::St st, check_types::Ty t) {
    return prism_rtl::make_rc<OwnsRow>(env, st, t);
}


/// ClauseCoverage: unbounded fn Env, St, [FnClause], [Ty], Range -> St
check_types::St clause_coverage(const check_expr::Env& env, const check_types::St& st, const Array<ast::FnClause>& clauses, const Array<check_types::Ty>& params, const ast::Range& span) {
    auto [rows, st2] = run_to_end(fold_job(clauses, std::tuple{Array<Array<Pat>>{}, st}, ({
        auto env_1 = env;
        auto params_2 = params;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Array<Pat>>, check_types::St>>(std::tuple<std::tuple<Array<Array<Pat>>, check_types::St>, ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Array<Pat>>, check_types::St>, ast::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_3 = env_1;
            auto params_2_3 = params_2;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto c = p1;
                call_value(each_job(c.params, ({
                auto env_1_3_3 = env_1_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(ast::Pattern_)>>(prism_rtl::rc([=](ast::Pattern_ p0) {
                return ({
                    auto env_1_3_3_3 = env_1_3_3;
                    entered(once_job([=]() {
                    return ({
                        auto p_ = p0;
                        (prism_rtl::more(prism_rtl::rc(ToPat(env_1_3_3_3, p_))));
                    });
                }));
                });
            })));
            })), [=](Array<Pat> each_15391) {
                return ({
                    auto q = each_15391;
                    auto reachable = (len(q) != len(params_2_3)) || useful(env_1_3, s, acc, q, params_2_3);
                    auto s2 = reachable
                        ? s
                        : check_types::err_fix(s, Text::lit("unreachable"), c.span, Text::lit("this clause is never reached"), Text::lit("remove it, or put it above the clause that covers it"));
                    (prism_rtl::finished(std::tuple{prelude::push(acc, q), s2}));
                });
            });
            });
        }));
        });
    }));
    })));
    return len(params) == Nat(0u)
        ? st2
        : ({
        __label__ _done;
        prism_rtl::Slot<check_types::St> _v;
        auto&& _m = witness(env, st2, rows, params);
        if (prism_rtl::is_some(_m)) {
            auto&& w = prism_rtl::some_of(_m);
            _v.set(check_types::err_fix(st2, Text::lit("not-exhaustive"), span, prism_rtl::cat("these clauses miss `", lexer::join(w, Text::lit(", ")), "`"), Text::lit("add a clause for it")));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(st2);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<check_types::St> ClauseCoverage::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& clauses = this->clauses;
    const auto& params = this->params;
    const auto& span = this->span;
    auto clauses_1 = clauses;
    auto env_2 = env;
    auto params_3 = params;
    auto span_4 = span;
    auto st_5 = st;
    return call_value(fold_job(clauses_1, std::tuple{Array<Array<Pat>>{}, st_5}, ({
        auto env_2_6 = env_2;
        auto params_3_6 = params_3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Array<Pat>>, check_types::St>>(std::tuple<std::tuple<Array<Array<Pat>>, check_types::St>, ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Array<Pat>>, check_types::St>, ast::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_2_6_6 = env_2_6;
            auto params_3_6_6 = params_3_6;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto c = p1;
                call_value(each_job(c.params, ({
                auto env_2_6_6_6 = env_2_6_6;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(ast::Pattern_)>>(prism_rtl::rc([=](ast::Pattern_ p0) {
                return ({
                    auto env_2_6_6_6_6 = env_2_6_6_6;
                    entered(once_job([=]() {
                    return ({
                        auto p_ = p0;
                        (prism_rtl::more(prism_rtl::rc(ToPat(env_2_6_6_6_6, p_))));
                    });
                }));
                });
            })));
            })), [=](Array<Pat> each_15391) {
                return ({
                    auto q = each_15391;
                    auto reachable = (len(q) != len(params_3_6_6)) || useful(env_2_6_6, s, acc, q, params_3_6_6);
                    auto s2 = reachable
                        ? s
                        : check_types::err_fix(s, Text::lit("unreachable"), c.span, Text::lit("this clause is never reached"), Text::lit("remove it, or put it above the clause that covers it"));
                    (prism_rtl::finished(std::tuple{prelude::push(acc, q), s2}));
                });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<Array<Pat>>, check_types::St> fold_15330) {
        return ({
            auto [rows, st2] = fold_15330;
            len(params_3) == Nat(0u)
            ? prism_rtl::finished(st2)
            : call_then(start_witness(env_2, st2, rows, params_3), [=](std::optional<Array<Text>> witness_15740) {
            return ({
                prism_rtl::is_some(witness_15740) ? ({
                auto&& w = prism_rtl::some_of(witness_15740);
                prism_rtl::finished(check_types::err_fix(st2, Text::lit("not-exhaustive"), span_4, prism_rtl::cat("these clauses miss `", lexer::join(w, Text::lit(", ")), "`"), Text::lit("add a clause for it")));
            })
                : prism_rtl::is_none(witness_15740) ? prism_rtl::finished(st2)
                : throw prism_rtl::Panic("no arm matched");
            });
        });
        });
    });
}


/// `Start ClauseCoverage, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_clause_coverage(check_expr::Env env, check_types::St st, Array<ast::FnClause> clauses, Array<check_types::Ty> params, ast::Range span) {
    return prism_rtl::make_rc<ClauseCoverage>(env, st, clauses, params, span);
}


/// IsDelayedWidget: fn Text -> Bool
bool is_delayed_widget(const Text& n) {
    return check_types::has_text(Array(std::vector{Text::lit("@Defer"), Text::lit("@Later"), Text::lit("@Run"), Text::lit("@Machine"), Text::lit("@started")}), n);
}


/// BlockPromptCycles: unbounded fn Env, St, Block -> St
check_types::St block_prompt_cycles(const check_expr::Env& env, const check_types::St& st, const ast::Block& b) {
    auto defs = run_to_end(fold_job(b.stmts, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto s = p1;
                call_then(start_stmt_defs(s), [=](Array<Text> stmt_defs_17015) { return prism_rtl::finished(append(acc, stmt_defs_17015)); });
            });
        }));
    }))));
    auto cx_ = PCx{.g = env.g, .home = env.home, .lams = let_lambdas(b.stmts), .base = prompt_base(env, b.stmts)};
    auto edges_ = run_to_end(fold_job(b.stmts, Array<std::tuple<Text, Text>>{}, ({
        auto env_1 = env;
        auto st_2 = st;
        auto cx__3 = cx_;
        auto defs_4 = defs;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, Text>>>(std::tuple<Array<std::tuple<Text, Text>>, ast::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, Text>>, ast::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_5 = env_1;
            auto st_2_5 = st_2;
            auto cx__3_5 = cx__3;
            auto defs_4_5 = defs_4;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto s = p1;
                call_then(start_prompt_edges(env_1_5, st_2_5, cx__3_5, s, defs_4_5), [=](Array<std::tuple<Text, Text>> prompt_edges_17186) { return prism_rtl::finished(append(acc, prompt_edges_17186)); });
            });
        }));
        });
    }));
    })));
    auto cyc = find_cycle(defs, edges_);
    return len(cyc) == Nat(0u)
        ? st
        : ({
        auto span = run_to_end(fold_job(b.stmts, b.span, ({
            auto cyc_1 = cyc;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<ast::Range>(std::tuple<ast::Range, ast::Stmt>)>>(prism_rtl::rc([=](std::tuple<ast::Range, ast::Stmt> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cyc_1_2 = cyc_1;
                entered(once_job([=]() {
                return ({
                    auto sp = p0;
                    auto s = p1;
                    call_then(start_stmt_defs(s), [=](Array<Text> stmt_defs_17354) {
                    return check_types::has_text(stmt_defs_17354, or_(index(cyc_1_2, Nat(0u)), Text::lit("")))
                        ? prism_rtl::finished(s.span)
                        : prism_rtl::finished(sp);
                });
                });
            }));
            });
        })));
        })));
        (check_types::err_fix(st, Text::lit("prompt-cycle"), span, prism_rtl::cat("a prompt cycle: ", lexer::join(each(cyc, [&](const Text& n) { return prism_rtl::cat("`", n, "`"); }), Text::lit(", "))), Text::lit("break it with a hold: `$last <- start then ...` reads the value as the tick opened")));
    });
}


prism_rtl::Turn<check_types::St> BlockPromptCycles::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& b = this->b;
    auto b_1 = b;
    auto env_2 = env;
    auto st_3 = st;
    return call_value(fold_job(b_1.stmts, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto s = p1;
                call_then(start_stmt_defs(s), [=](Array<Text> stmt_defs_17015) { return prism_rtl::finished(append(acc, stmt_defs_17015)); });
            });
        }));
    }))), [=](Array<Text> fold_16972) {
        return ({
            auto defs = fold_16972;
            call_then(start_let_lambdas(b_1.stmts), [=](Map<Nat, ast::Expr> let_lambdas_17074) {
            return call_then(start_prompt_base(env_2, b_1.stmts), [=](Map<Text, Rel> prompt_base_17101) {
                return ({
                    auto cx_ = PCx{.g = env_2.g, .home = env_2.home, .lams = let_lambdas_17074, .base = prompt_base_17101};
                    call_value(fold_job(b_1.stmts, Array<std::tuple<Text, Text>>{}, ({
                    auto env_2_4 = env_2;
                    auto st_3_4 = st_3;
                    auto cx__4 = cx_;
                    auto defs_5 = defs;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, Text>>>(std::tuple<Array<std::tuple<Text, Text>>, ast::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, Text>>, ast::Stmt> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto env_2_4_6 = env_2_4;
                        auto st_3_4_6 = st_3_4;
                        auto cx__4_6 = cx__4;
                        auto defs_5_6 = defs_5;
                        entered(once_job([=]() {
                        return ({
                            auto acc = p0;
                            auto s = p1;
                            call_then(start_prompt_edges(env_2_4_6, st_3_4_6, cx__4_6, s, defs_5_6), [=](Array<std::tuple<Text, Text>> prompt_edges_17186) { return prism_rtl::finished(append(acc, prompt_edges_17186)); });
                        });
                    }));
                    });
                }));
                })), [=](Array<std::tuple<Text, Text>> fold_17143) {
                    return ({
                        auto edges_ = fold_17143;
                        call_then(start_find_cycle(defs, edges_), [=](Array<Text> find_cycle_17234) {
                        return ({
                            auto cyc = find_cycle_17234;
                            len(cyc) == Nat(0u)
                            ? prism_rtl::finished(st_3)
                            : call_value(fold_job(b_1.stmts, b_1.span, ({
                            auto cyc_4 = cyc;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<ast::Range>(std::tuple<ast::Range, ast::Stmt>)>>(prism_rtl::rc([=](std::tuple<ast::Range, ast::Stmt> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto cyc_4_5 = cyc_4;
                                entered(once_job([=]() {
                                return ({
                                    auto sp = p0;
                                    auto s = p1;
                                    call_then(start_stmt_defs(s), [=](Array<Text> stmt_defs_17354) {
                                    return check_types::has_text(stmt_defs_17354, or_(index(cyc_4_5, Nat(0u)), Text::lit("")))
                                        ? prism_rtl::finished(s.span)
                                        : prism_rtl::finished(sp);
                                });
                                });
                            }));
                            });
                        })));
                        })), [=](ast::Range fold_17311) {
                            return ({
                                auto span = fold_17311;
                                (prism_rtl::finished(check_types::err_fix(st_3, Text::lit("prompt-cycle"), span, prism_rtl::cat("a prompt cycle: ", lexer::join(each(cyc, [&](const Text& n) { return prism_rtl::cat("`", n, "`"); }), Text::lit(", "))), Text::lit("break it with a hold: `$last <- start then ...` reads the value as the tick opened"))));
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
        });
        });
    });
}


/// `Start BlockPromptCycles, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_block_prompt_cycles(check_expr::Env env, check_types::St st, ast::Block b) {
    return prism_rtl::make_rc<BlockPromptCycles>(env, st, b);
}


/// StmtDefs: unbounded fn Stmt -> [Text]
Array<Text> stmt_defs(const ast::Stmt& s) {
    auto&& _m = s.kind;
    if (prism_rtl::is<ast::StmtKind::SBind>(_m)) {
        auto&& p_ = prism_rtl::as<ast::StmtKind::SBind>(_m).a0;
        return check_env::pattern_names(p_);
    }
    if (prism_rtl::is<ast::StmtKind::SLet>(_m)) {
        auto&& p_ = prism_rtl::as<ast::StmtKind::SLet>(_m).a0;
        return check_env::pattern_names(p_);
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> StmtDefs::cycle() const {
    const auto& s = this->s;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<ast::StmtKind::SBind>(_m) ? ({
        auto&& p_ = prism_rtl::as<ast::StmtKind::SBind>(_m).a0;
        prism_rtl::more(prism_rtl::rc(check_env::PatternNames(p_)));
    })
        : prism_rtl::is<ast::StmtKind::SLet>(_m) ? ({
        auto&& p_ = prism_rtl::as<ast::StmtKind::SLet>(_m).a0;
        prism_rtl::more(prism_rtl::rc(check_env::PatternNames(p_)));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start StmtDefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_stmt_defs(ast::Stmt s) {
    return prism_rtl::make_rc<StmtDefs>(s);
}


/// PromptEdges: unbounded fn Env, St, PCx, Stmt, [Text] -> [((Text, Text))]
Array<std::tuple<Text, Text>> prompt_edges(const check_expr::Env& env, const check_types::St& st, const PCx& cx_, const ast::Stmt& s, const Array<Text>& defs) {
    auto&& _m = s.kind;
    if (prism_rtl::is<ast::StmtKind::SBind>(_m) && prism_rtl::is_some(prism_rtl::as<ast::StmtKind::SBind>(_m).a2)) {
        return Array<std::tuple<Text, Text>>{};
    }
    if (prism_rtl::is<ast::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<ast::StmtKind::SBind>(_m).a2)) {
        auto&& p_ = prism_rtl::as<ast::StmtKind::SBind>(_m).a0;
        auto&& e = prism_rtl::as<ast::StmtKind::SBind>(_m).a1;
        return check_passes::edges(check_env::pattern_names(p_), prompt_reads(cx_, e, defs));
    }
    if (prism_rtl::is<ast::StmtKind::SLet>(_m)) {
        auto&& p_ = prism_rtl::as<ast::StmtKind::SLet>(_m).a0;
        auto&& e = prism_rtl::as<ast::StmtKind::SLet>(_m).a2;
        auto names = check_env::pattern_names(p_);
        auto layer = run_to_end(fold_job(names, Text::lit(""), ({
            auto env_1 = env;
            auto st_2 = st;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text>)>>(prism_rtl::rc([=](std::tuple<Text, Text> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env_1_3 = env_1;
                auto st_2_3 = st_2;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto n = p1;
                    ({
                    auto&& _m = prelude::get(env_1_3.locals, n);
                    prism_rtl::is_some(_m) ? ({
                    auto&& sc = prism_rtl::some_of(_m);
                    prism_rtl::more(prism_rtl::rc(check_types::HeadSigil(st_2_3, sc.ty)));
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(acc)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        })));
        })));
        return check_passes::edges(names, run_to_end(filter_job(prompt_reads(cx_, e, defs), ({
            auto env_1 = env;
            auto st_2 = st;
            auto layer_3 = layer;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text p0) {
            return ({
                auto env_1_4 = env_1;
                auto st_2_4 = st_2;
                auto layer_3_4 = layer_3;
                entered(once_job([=]() {
                return ({
                    auto n = p0;
                    (prism_rtl::more(prism_rtl::rc(ReadIsPrompt(env_1_4, st_2_4, n, layer_3_4))));
                });
            }));
            });
        })));
        }))));
    }
    {
        return Array<std::tuple<Text, Text>>{};
    }
}


prism_rtl::Turn<Array<std::tuple<Text, Text>>> PromptEdges::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& cx_ = this->cx_;
    const auto& s = this->s;
    const auto& defs = this->defs;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<ast::StmtKind::SBind>(_m) && prism_rtl::is_some(prism_rtl::as<ast::StmtKind::SBind>(_m).a2) ? prism_rtl::finished(Array<std::tuple<Text, Text>>{})
        : prism_rtl::is<ast::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<ast::StmtKind::SBind>(_m).a2) ? ({
        auto&& p_ = prism_rtl::as<ast::StmtKind::SBind>(_m).a0;
        auto&& e = prism_rtl::as<ast::StmtKind::SBind>(_m).a1;
        ({
        auto cx__1 = cx_;
        auto defs_2 = defs;
        auto e_3 = e;
        auto p__4 = p_;
        call_then(check_env::start_pattern_names(p__4), [=](Array<Text> pattern_names_18078) { return call_then(start_prompt_reads(cx__1, e_3, defs_2), [=](Array<Text> prompt_reads_18096) { return prism_rtl::finished(check_passes::edges(pattern_names_18078, prompt_reads_18096)); }); });
    });
    })
        : prism_rtl::is<ast::StmtKind::SLet>(_m) ? ({
        auto&& p_ = prism_rtl::as<ast::StmtKind::SLet>(_m).a0;
        auto&& e = prism_rtl::as<ast::StmtKind::SLet>(_m).a2;
        ({
        auto cx__1 = cx_;
        auto defs_2 = defs;
        auto e_3 = e;
        auto env_4 = env;
        auto p__5 = p_;
        auto st_6 = st;
        call_then(check_env::start_pattern_names(p__5), [=](Array<Text> pattern_names_18164) {
        return ({
            auto names = pattern_names_18164;
            call_value(fold_job(names, Text::lit(""), ({
            auto env_4_7 = env_4;
            auto st_6_7 = st_6;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text>)>>(prism_rtl::rc([=](std::tuple<Text, Text> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env_4_7_7 = env_4_7;
                auto st_6_7_7 = st_6_7;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto n = p1;
                    ({
                    auto&& _m = prelude::get(env_4_7_7.locals, n);
                    prism_rtl::is_some(_m) ? ({
                    auto&& sc = prism_rtl::some_of(_m);
                    prism_rtl::more(prism_rtl::rc(check_types::HeadSigil(st_6_7_7, sc.ty)));
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(acc)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        })));
        })), [=](Text fold_18199) {
            return ({
                auto layer = fold_18199;
                call_then(start_prompt_reads(cx__1, e_3, defs_2), [=](Array<Text> prompt_reads_18335) {
                return call_value(filter_job(prompt_reads_18335, ({
                    auto env_4_7 = env_4;
                    auto st_6_7 = st_6;
                    auto layer_7 = layer;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text p0) {
                    return ({
                        auto env_4_7_8 = env_4_7;
                        auto st_6_7_8 = st_6_7;
                        auto layer_7_8 = layer_7;
                        entered(once_job([=]() {
                        return ({
                            auto n = p0;
                            (prism_rtl::more(prism_rtl::rc(ReadIsPrompt(env_4_7_8, st_6_7_8, n, layer_7_8))));
                        });
                    }));
                    });
                })));
                })), [=](Array<Text> filter_18327) { return prism_rtl::finished(check_passes::edges(names, filter_18327)); });
            });
            });
        });
        });
    });
    });
    })
        : prism_rtl::finished(Array<std::tuple<Text, Text>>{});
    });
}


/// `Start PromptEdges, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Text, Text>>> start_prompt_edges(check_expr::Env env, check_types::St st, PCx cx_, ast::Stmt s, Array<Text> defs) {
    return prism_rtl::make_rc<PromptEdges>(env, st, cx_, s, defs);
}


/// Edges: fn [Text], [Text] -> [((Text, Text))]
Array<std::tuple<Text, Text>> edges(const Array<Text>& froms, const Array<Text>& tos) {
    return fold(froms, Array<std::tuple<Text, Text>>{}, [&](const Array<std::tuple<Text, Text>>& acc, const Text& f) { return append(acc, each(tos, [&](const Text& t) { return std::tuple{f, t}; })); });
}


/// ReadIsPrompt: unbounded fn Env, St, Text, Text -> Bool
bool read_is_prompt(const check_expr::Env& env, const check_types::St& st, const Text& n, const Text& layer) {
    auto&& _m = prelude::get(env.locals, n);
    if (prism_rtl::is_some(_m)) {
        auto&& sc = prism_rtl::some_of(_m);
        auto h = check_types::head_sigil(st, sc.ty);
        return layer == Text::lit("!")
            ? (h == Text::lit("!")) || (h == Text::lit("@"))
            : layer == Text::lit("$")
            ? (h == Text::lit("$")) || (h == Text::lit("!"))
            : ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = check_types::walk(st, sc.ty);
            if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
                _v.set(false);
                goto _done;
            }
            {
                _v.set(check_env::is_lower_text(lexer::drop_prefix(n, check_types::marks_of(n))) && (h == Text::lit("")));
                goto _done;
            }
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> ReadIsPrompt::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& n = this->n;
    const auto& layer = this->layer;
    return ({
        auto&& _m = prelude::get(env.locals, n);
        prism_rtl::is_some(_m) ? ({
        auto&& sc = prism_rtl::some_of(_m);
        ({
        auto layer_1 = layer;
        auto n_2 = n;
        auto st_3 = st;
        call_then(check_types::start_head_sigil(st_3, sc.ty), [=](Text head_sigil_18822) {
        return ({
            auto h = head_sigil_18822;
            layer_1 == Text::lit("!")
            ? prism_rtl::finished((h == Text::lit("!")) || (h == Text::lit("@")))
            : layer_1 == Text::lit("$")
            ? prism_rtl::finished((h == Text::lit("$")) || (h == Text::lit("!")))
            : call_then(check_types::start_walk(st_3, sc.ty), [=](check_types::Ty walk_18960) {
            return ({
                prism_rtl::is<check_types::Ty::TyFn>(walk_18960) ? prism_rtl::finished(false)
                : prism_rtl::finished(check_env::is_lower_text(lexer::drop_prefix(n_2, check_types::marks_of(n_2))) && (h == Text::lit("")));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ReadIsPrompt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_read_is_prompt(check_expr::Env env, check_types::St st, Text n, Text layer) {
    return prism_rtl::make_rc<ReadIsPrompt>(env, st, n, layer);
}


/// PromptBase: unbounded fn Env, [Stmt] -> (Text ==> Rel)
Map<Text, Rel> prompt_base(const check_expr::Env& env, const Array<ast::Stmt>& stmts) {
    auto pre = prelude_seeds(env.g, env.home);
    auto seeds = fold(keys(pre), pre, [&](const Map<Text, Rel>& m, const Text& k) {
        return check_env::has_key(env.locals, lexer::drop_prefix(k, Text::lit("pre:")))
            ? prelude::remove(m, k)
            : m;
    });
    return fold(stmts, seeds, [&](const Map<Text, Rel>& m, const ast::Stmt& s) { return lam_let_rels(s, m); });
}


prism_rtl::Turn<Map<Text, Rel>> PromptBase::cycle() const {
    const auto& env = this->env;
    const auto& stmts = this->stmts;
    auto pre = prelude_seeds(env.g, env.home);
    auto seeds = fold(keys(pre), pre, [&](const Map<Text, Rel>& m, const Text& k) {
        return check_env::has_key(env.locals, lexer::drop_prefix(k, Text::lit("pre:")))
            ? prelude::remove(m, k)
            : m;
    });
    return prism_rtl::finished(fold(stmts, seeds, [&](const Map<Text, Rel>& m, const ast::Stmt& s) { return lam_let_rels(s, m); }));
}


/// `Start PromptBase, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Rel>> start_prompt_base(check_expr::Env env, Array<ast::Stmt> stmts) {
    return prism_rtl::make_rc<PromptBase>(env, stmts);
}


/// LamLetRels: fn Stmt, (Text ==> Rel) -> (Text ==> Rel)
Map<Text, Rel> lam_let_rels(const ast::Stmt& s, const Map<Text, Rel>& m) {
    auto&& _m = s.kind;
    if (prism_rtl::is<ast::StmtKind::SLet>(_m)) {
        auto&& p_ = prism_rtl::as<ast::StmtKind::SLet>(_m).a0;
        auto&& e = prism_rtl::as<ast::StmtKind::SLet>(_m).a2;
        auto&& _m = std::tuple{p_.kind, lambda_of(e)};
        if (prism_rtl::is<ast::PatternKind::PName>(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
            auto&& n = prism_rtl::as<ast::PatternKind::PName>(std::get<0>(_m)).a0;
            auto&& lam = prism_rtl::some_of(std::get<1>(_m));
            return insert(m, prism_rtl::cat("lamlet:", check_env::sname_key(n)), Rel{.param = lam.span.start, .strict = false});
        }
        {
            return m;
        }
    }
    {
        return m;
    }
}


/// ?LambdaOf: fn Expr -> ?Expr
std::optional<ast::Expr> lambda_of(const ast::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<ast::ExprKind::ELambda>(_m)) {
        return std::optional(e);
    }
    if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        return lambda_of(x);
    }
    {
        return std::optional<ast::Expr>{};
    }
}


/// LetLambdas: unbounded fn [Stmt] -> (Nat ==> Expr)
Map<Nat, ast::Expr> let_lambdas(const Array<ast::Stmt>& stmts) {
    return fold(stmts_spots(stmts, Map<Text, Rel>{}), Map<Nat, ast::Expr>{}, [&](const Map<Nat, ast::Expr>& m, const Spot& sp) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Map<Nat, ast::Expr>> _v;
            if (prism_rtl::is<Spot::SpotStmt>(sp)) {
                auto&& s = prism_rtl::as<Spot::SpotStmt>(sp).a0;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Map<Nat, ast::Expr>> _v;
                    auto&& _m = s.kind;
                    if (prism_rtl::is<ast::StmtKind::SLet>(_m)) {
                        auto&& e = prism_rtl::as<ast::StmtKind::SLet>(_m).a2;
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Map<Nat, ast::Expr>> _v;
                            auto&& _m = lambda_of(e);
                            if (prism_rtl::is_some(_m)) {
                                auto&& lam = prism_rtl::some_of(_m);
                                _v.set(insert(m, lam.span.start, lam));
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(m);
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    {
                        _v.set(m);
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(m);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Map<Nat, ast::Expr>> LetLambdas::cycle() const {
    const auto& stmts = this->stmts;
    auto stmts_1 = stmts;
    return call_then(start_stmts_spots(stmts_1, Map<Text, Rel>{}), [=](Array<Spot> stmts_spots_20684) {
        return prism_rtl::finished(fold(stmts_spots_20684, Map<Nat, ast::Expr>{}, [&](const Map<Nat, ast::Expr>& m, const Spot& sp) {
            return ({
                __label__ _done;
                prism_rtl::Slot<Map<Nat, ast::Expr>> _v;
                if (prism_rtl::is<Spot::SpotStmt>(sp)) {
                    auto&& s = prism_rtl::as<Spot::SpotStmt>(sp).a0;
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Map<Nat, ast::Expr>> _v;
                        auto&& _m = s.kind;
                        if (prism_rtl::is<ast::StmtKind::SLet>(_m)) {
                            auto&& e = prism_rtl::as<ast::StmtKind::SLet>(_m).a2;
                            _v.set(({
                                __label__ _done;
                                prism_rtl::Slot<Map<Nat, ast::Expr>> _v;
                                auto&& _m = lambda_of(e);
                                if (prism_rtl::is_some(_m)) {
                                    auto&& lam = prism_rtl::some_of(_m);
                                    _v.set(insert(m, lam.span.start, lam));
                                    goto _done;
                                }
                                if (prism_rtl::is_none(_m)) {
                                    _v.set(m);
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        {
                            _v.set(m);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                {
                    _v.set(m);
                    goto _done;
                }
            _done:
                _v.take();
            });
        }));
    });
}


/// `Start LetLambdas, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Nat, ast::Expr>> start_let_lambdas(Array<ast::Stmt> stmts) {
    return prism_rtl::make_rc<LetLambdas>(stmts);
}


/// PromptReads: unbounded fn PCx, Expr, [Text] -> [Text]
Array<Text> prompt_reads(const PCx& cx_, const ast::Expr& e, const Array<Text>& defs) {
    auto spots = prompt_spots(cx_, e, cx_.base);
    return run_to_end(fold_job(spots, Array<Text>{}, ({
        auto defs_1 = defs;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto defs_1_2 = defs_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto sp = p1;
                call_then(start_spot_sites(sp), [=](Array<Site> spot_sites_22033) {
                return prism_rtl::finished(fold(spot_sites_22033, acc, [&](const Array<Text>& a2, const Site& site) {
                    return check_types::has_text(defs_1_2, site.callee) && (!is_local(site.rels, site.callee))
                        ? check_types::add_text(a2, site.callee)
                        : a2;
                }));
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Text>> PromptReads::cycle() const {
    const auto& cx_ = this->cx_;
    const auto& e = this->e;
    const auto& defs = this->defs;
    auto cx__1 = cx_;
    auto defs_2 = defs;
    auto e_3 = e;
    return call_then(start_prompt_spots(cx__1, e_3, cx__1.base), [=](Array<Spot> prompt_spots_21967) {
        return ({
            auto spots = prompt_spots_21967;
            fold_job(spots, Array<Text>{}, ({
            auto defs_2_4 = defs_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Spot> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto defs_2_4_4 = defs_2_4;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto sp = p1;
                    call_then(start_spot_sites(sp), [=](Array<Site> spot_sites_22033) {
                    return prism_rtl::finished(fold(spot_sites_22033, acc, [&](const Array<Text>& a2, const Site& site) {
                        return check_types::has_text(defs_2_4_4, site.callee) && (!is_local(site.rels, site.callee))
                            ? check_types::add_text(a2, site.callee)
                            : a2;
                    }));
                });
                });
            }));
            });
        })));
        }))->cycle();
        });
    });
}


/// `Start PromptReads, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_prompt_reads(PCx cx_, ast::Expr e, Array<Text> defs) {
    return prism_rtl::make_rc<PromptReads>(cx_, e, defs);
}


/// PromptSpots: unbounded fn PCx, Expr, (Text ==> Rel) -> [Spot]
Array<Spot> prompt_spots(const PCx& cx_, const ast::Expr& e, const Map<Text, Rel>& m) {
    return run_to_end(fold_job(prompt_kids(cx_, e, m), Array(std::vector{Spot(Spot::SpotExpr{e, m})}), ({
        auto cx__1 = cx_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Spot>>(std::tuple<Array<Spot>, Kid>)>>(prism_rtl::rc([=](std::tuple<Array<Spot>, Kid> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx__1_2 = cx__1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto k = p1;
                (prism_rtl::finished(append(acc, prompt_kid_spots(cx__1_2, k))));
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Spot>> PromptSpots::cycle() const {
    const auto& cx_ = this->cx_;
    const auto& e = this->e;
    const auto& m = this->m;
    return fold_job(prompt_kids(cx_, e, m), Array(std::vector{Spot(Spot::SpotExpr{e, m})}), ({
        auto cx__1 = cx_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Spot>>(std::tuple<Array<Spot>, Kid>)>>(prism_rtl::rc([=](std::tuple<Array<Spot>, Kid> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx__1_2 = cx__1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto k = p1;
                (prism_rtl::finished(append(acc, prompt_kid_spots(cx__1_2, k))));
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start PromptSpots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Spot>> start_prompt_spots(PCx cx_, ast::Expr e, Map<Text, Rel> m) {
    return prism_rtl::make_rc<PromptSpots>(cx_, e, m);
}


/// PromptKids: unbounded fn PCx, Expr, (Text ==> Rel) -> [Kid]
Array<Kid> prompt_kids(const PCx& cx_, const ast::Expr& e, const Map<Text, Rel>& m) {
    auto&& _m = e.kind;
    if (prism_rtl::is<ast::ExprKind::ELambda>(_m)) {
        return Array<Kid>{};
    }
    if (prism_rtl::is<ast::ExprKind::ERebuild>(_m)) {
        auto&& body = prism_rtl::as<ast::ExprKind::ERebuild>(_m).a1;
        return row_kids(body, m, Array<Text>{});
    }
    if (prism_rtl::is<ast::ExprKind::EFor>(_m)) {
        auto&& binders_opt = prism_rtl::as<ast::ExprKind::EFor>(_m).a0;
        auto&& body = prism_rtl::as<ast::ExprKind::EFor>(_m).a2;
        return row_kids(body, m, for_binder_names(binders_opt));
    }
    if (prism_rtl::is<ast::ExprKind::EWidgetBlock>(_m)) {
        return Array<Kid>{};
    }
    if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
        auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
        return prompt_call_kids(cx_, e, callee_name(c), m);
    }
    if (prism_rtl::is<ast::ExprKind::EMethod>(_m)) {
        auto&& n = prism_rtl::as<ast::ExprKind::EMethod>(_m).a1;
        return prompt_call_kids(cx_, e, std::optional(check_env::sname_key(n)), m);
    }
    {
        return expr_kids(e, m);
    }
}


/// RowKids: unbounded fn Block, (Text ==> Rel), [Text] -> [Kid]
Array<Kid> row_kids(const ast::Block& body, const Map<Text, Rel>& m, const Array<Text>& binders) {
    auto lines = filter(body.stmts, [&](const ast::Stmt& s) {
        return ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = s.kind;
            if (prism_rtl::is<ast::StmtKind::SBind>(_m) && prism_rtl::is_some(prism_rtl::as<ast::StmtKind::SBind>(_m).a2)) {
                _v.set(false);
                goto _done;
            }
            {
                _v.set(true);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto own = run_to_end(fold_job(body.stmts, append(binders, Array(std::vector{Text::lit("_"), Text::lit("$_")})), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto s = p1;
                call_then(start_stmt_defs(s), [=](Array<Text> stmt_defs_23704) { return prism_rtl::finished(append(acc, stmt_defs_23704)); });
            });
        }));
    }))));
    return Array(std::vector{Kid(Kid::KidStmts{lines, hide(m, own)})});
}


/// ForBinderNames: unbounded fn ?ForBinders -> [Text]
Array<Text> for_binder_names(const std::optional<ast::ForBinders>& binders_opt) {
    if (prism_rtl::is_some(binders_opt)) {
        auto&& fb = prism_rtl::some_of(binders_opt);
        auto&& _m = fb.second;
        if (prism_rtl::is_some(_m)) {
            auto&& second = prism_rtl::some_of(_m);
            return append(check_env::pattern_names(fb.first), check_env::pattern_names(second));
        }
        if (prism_rtl::is_none(_m)) {
            return check_env::pattern_names(fb.first);
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_none(binders_opt)) {
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// PromptCallKids: unbounded fn PCx, Expr, ?Text, (Text ==> Rel) -> [Kid]
Array<Kid> prompt_call_kids(const PCx& cx_, const ast::Expr& e, const std::optional<Text>& n_opt, const Map<Text, Rel>& m) {
    if (prism_rtl::is_some(n_opt)) {
        auto&& n = prism_rtl::some_of(n_opt);
        auto called = follow_lam_let(cx_, n, m);
        return is_local(m, n)
            ? append(called, open_lambdas(cx_, expr_kids(e, m)))
            : len(called) > Nat(0u)
            ? append(called, open_lambdas(cx_, expr_kids(e, m)))
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<Kid>> _v;
            auto&& _m = resolve_callee(cx_.g, cx_.home, n);
            if (prism_rtl::is_some(_m)) {
                auto&& k = prism_rtl::some_of(_m);
                _v.set(is_prelude_key(cx_.g, k) && is_delayed_widget(lexer::drop_prefix(k, Text::lit("Prelude.")))
                    ? Array<Kid>{}
                    : is_prelude_key(cx_.g, k) && lexer::has_prefix(k, Text::lit("Prelude.@"))
                    ? expr_kids(e, m)
                    : open_lambdas(cx_, expr_kids(e, m)));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(open_lambdas(cx_, expr_kids(e, m)));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_none(n_opt)) {
        return open_lambdas(cx_, expr_kids(e, m));
    }
    prism_rtl::unreachable("no arm matched");
}


/// OpenLambdas: unbounded fn PCx, [Kid] -> [Kid]
Array<Kid> open_lambdas(const PCx& cx_, const Array<Kid>& kids) {
    return run_to_end(fold_job(kids, Array<Kid>{}, ({
        auto cx__1 = cx_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Kid>>(std::tuple<Array<Kid>, Kid>)>>(prism_rtl::rc([=](std::tuple<Array<Kid>, Kid> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx__1_2 = cx__1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto k = p1;
                ({
                prism_rtl::is<Kid::KidExpr>(k) ? ({
                auto&& x = prism_rtl::as<Kid::KidExpr>(k).a0;
                auto&& m = prism_rtl::as<Kid::KidExpr>(k).a1;
                ({
                auto&& _m = x.kind;
                prism_rtl::is<ast::ExprKind::ELambda>(_m) ? ({
                auto&& ps_opt = prism_rtl::as<ast::ExprKind::ELambda>(_m).a0;
                auto&& body = prism_rtl::as<ast::ExprKind::ELambda>(_m).a1;
                ({
                auto ps_opt_2 = ps_opt;
                auto body_3 = body;
                auto m_4 = m;
                call_then(start_patterns_names(or_(ps_opt_2, Array<ast::Pattern_>{})), [=](Array<Text> patterns_names_25323) { return prism_rtl::finished(prelude::push(acc, lambda_kid(body_3, hide(m_4, patterns_names_25323)))); });
            });
            })
                : prism_rtl::is<ast::ExprKind::EName>(_m) ? ({
                auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
                prism_rtl::finished(append(prelude::push(acc, k), follow_lam_let(cx__1_2, check_env::sname_key(n), m)));
            })
                : prism_rtl::finished(prelude::push(acc, k));
            });
            })
                : prism_rtl::finished(prelude::push(acc, k));
            });
            });
        }));
        });
    })));
    })));
}


/// FollowLamLet: unbounded fn PCx, Text, (Text ==> Rel) -> [Kid]
Array<Kid> follow_lam_let(const PCx& cx_, const Text& n, const Map<Text, Rel>& m) {
    auto&& _m = prelude::get(m, prism_rtl::cat("lamlet:", n));
    if (prism_rtl::is_some(_m)) {
        auto&& r = prism_rtl::some_of(_m);
        return check_env::has_key(m, prism_rtl::cat("seen:", r.param))
            ? Array<Kid>{}
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<Kid>> _v;
            auto&& _m = prelude::get(cx_.lams, r.param);
            if (prism_rtl::is_some(_m)) {
                auto&& lam = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<Kid>> _v;
                    auto&& _m = lam.kind;
                    if (prism_rtl::is<ast::ExprKind::ELambda>(_m)) {
                        auto&& ps_opt = prism_rtl::as<ast::ExprKind::ELambda>(_m).a0;
                        auto&& body = prism_rtl::as<ast::ExprKind::ELambda>(_m).a1;
                        _v.set(({
                            auto seen_1 = fold(keys(m), cx_.base, [&](const Map<Text, Rel>& m2, const Text& k) { return lexer::has_prefix(k, Text::lit("seen:")) ? insert(m2, k, no_rel()) : m2; });
                            (Array(std::vector{lambda_kid(body, hide(insert(seen_1, prism_rtl::cat("seen:", r.param), no_rel()), patterns_names(or_(ps_opt, Array<ast::Pattern_>{}))))}));
                        }));
                        goto _done;
                    }
                    {
                        _v.set(Array<Kid>{});
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<Kid>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_none(_m)) {
        return Array<Kid>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// PromptKidSpots: unbounded fn PCx, Kid -> [Spot]
Array<Spot> prompt_kid_spots(const PCx& cx_, const Kid& k) {
    if (prism_rtl::is<Kid::KidExpr>(k)) {
        auto&& x = prism_rtl::as<Kid::KidExpr>(k).a0;
        auto&& m = prism_rtl::as<Kid::KidExpr>(k).a1;
        return prompt_spots(cx_, x, m);
    }
    if (prism_rtl::is<Kid::KidStmts>(k)) {
        auto&& ss = prism_rtl::as<Kid::KidStmts>(k).a0;
        auto&& m = prism_rtl::as<Kid::KidStmts>(k).a1;
        auto bm = block_rels(ss, m);
        return run_to_end(fold_job(ss, Array<Spot>{}, ({
            auto cx__1 = cx_;
            auto bm_2 = bm;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Spot>>(std::tuple<Array<Spot>, ast::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<Spot>, ast::Stmt> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cx__1_3 = cx__1;
                auto bm_2_3 = bm_2;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto s = p1;
                    (prism_rtl::finished(append(acc, prompt_stmt_spots(cx__1_3, s, bm_2_3))));
                });
            }));
            });
        })));
        })));
    }
    prism_rtl::unreachable("no arm matched");
}


/// PromptStmtSpots: unbounded fn PCx, Stmt, (Text ==> Rel) -> [Spot]
Array<Spot> prompt_stmt_spots(const PCx& cx_, const ast::Stmt& s, const Map<Text, Rel>& m) {
    auto&& _m = s.kind;
    if (prism_rtl::is<ast::StmtKind::SFn>(_m)) {
        return Array(std::vector{Spot(Spot::SpotStmt{s, m})});
    }
    if (prism_rtl::is<ast::StmtKind::SWidget>(_m)) {
        return Array(std::vector{Spot(Spot::SpotStmt{s, m})});
    }
    {
        return run_to_end(fold_job(stmt_kids(s, m), Array(std::vector{Spot(Spot::SpotStmt{s, m})}), ({
            auto cx__1 = cx_;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Spot>>(std::tuple<Array<Spot>, Kid>)>>(prism_rtl::rc([=](std::tuple<Array<Spot>, Kid> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cx__1_2 = cx__1;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto k = p1;
                    (prism_rtl::finished(append(acc, prompt_kid_spots(cx__1_2, k))));
                });
            }));
            });
        })));
        })));
    }
}


/// FindCycle: unbounded fn [Text], [((Text, Text))] -> [Text]
Array<Text> find_cycle(const Array<Text>& defs, const Array<std::tuple<Text, Text>>& edges_) {
    return run_to_end(fold_job(defs, Array<Text>{}, ({
        auto defs_1 = defs;
        auto edges__2 = edges_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto defs_1_3 = defs_1;
            auto edges__2_3 = edges__2;
            entered(once_job([=]() {
            return ({
                auto found = p0;
                auto d = p1;
                len(found) > Nat(0u)
                ? prism_rtl::finished(found)
                : prism_rtl::more(prism_rtl::rc(CycleThrough(defs_1_3, edges__2_3, d)));
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Text>> FindCycle::cycle() const {
    const auto& defs = this->defs;
    const auto& edges_ = this->edges_;
    return fold_job(defs, Array<Text>{}, ({
        auto defs_1 = defs;
        auto edges__2 = edges_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto defs_1_3 = defs_1;
            auto edges__2_3 = edges__2;
            entered(once_job([=]() {
            return ({
                auto found = p0;
                auto d = p1;
                len(found) > Nat(0u)
                ? prism_rtl::finished(found)
                : prism_rtl::more(prism_rtl::rc(CycleThrough(defs_1_3, edges__2_3, d)));
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start FindCycle, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_find_cycle(Array<Text> defs, Array<std::tuple<Text, Text>> edges_) {
    return prism_rtl::make_rc<FindCycle>(defs, edges_);
}


/// CycleThrough: unbounded fn [Text], [((Text, Text))], Text -> [Text]
Array<Text> cycle_through(const Array<Text>& defs, const Array<std::tuple<Text, Text>>& edges_, const Text& d) {
    auto fwd = reach_from(edges_, d);
    return check_types::has_text(fwd, d)
        ? run_to_end(filter_job(defs, ({
        auto fwd_1 = fwd;
        auto edges__2 = edges_;
        auto d_3 = d;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text p0) {
        return ({
            auto fwd_1_4 = fwd_1;
            auto edges__2_4 = edges__2;
            auto d_3_4 = d_3;
            entered(once_job([=]() {
            return ({
                auto x = p0;
                (prism_rtl::finished(check_types::has_text(fwd_1_4, x) && check_types::has_text(reach_from(edges__2_4, x), d_3_4)));
            });
        }));
        });
    })));
    })))
        : Array<Text>{};
}


prism_rtl::Turn<Array<Text>> CycleThrough::cycle() const {
    const auto& defs = this->defs;
    const auto& edges_ = this->edges_;
    const auto& d = this->d;
    auto d_1 = d;
    auto defs_2 = defs;
    auto edges__3 = edges_;
    return call_then(start_reach_from(edges__3, d_1), [=](Array<Text> reach_from_27343) {
        return ({
            auto fwd = reach_from_27343;
            (check_types::has_text(fwd, d_1)
            ? filter_job(defs_2, ({
            auto fwd_4 = fwd;
            auto edges__3_5 = edges__3;
            auto d_1_5 = d_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text p0) {
            return ({
                auto fwd_4_5 = fwd_4;
                auto edges__3_5_5 = edges__3_5;
                auto d_1_5_5 = d_1_5;
                entered(once_job([=]() {
                return ({
                    auto x = p0;
                    (prism_rtl::finished(check_types::has_text(fwd_4_5, x) && check_types::has_text(reach_from(edges__3_5_5, x), d_1_5_5)));
                });
            }));
            });
        })));
        }))->cycle()
            : prism_rtl::finished(Array<Text>{}));
        });
    });
}


/// `Start CycleThrough, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_cycle_through(Array<Text> defs, Array<std::tuple<Text, Text>> edges_, Text d) {
    return prism_rtl::make_rc<CycleThrough>(defs, edges_, d);
}


/// ReachFrom: unbounded fn [((Text, Text))], Text -> [Text]
Array<Text> reach_from(const Array<std::tuple<Text, Text>>& edges_, const Text& d) {
    return reach(edges_, each(filter(edges_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& f = std::get<0>(_p0);
        return f == d;
    }), [&](const std::tuple<Text, Text>& _p0) {
        auto&& t = std::get<1>(_p0);
        return t;
    }), Array<Text>{});
}


prism_rtl::Turn<Array<Text>> ReachFrom::cycle() const {
    const auto& edges_ = this->edges_;
    const auto& d = this->d;
    return prism_rtl::finished(reach(edges_, each(filter(edges_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& f = std::get<0>(_p0);
        return f == d;
    }), [&](const std::tuple<Text, Text>& _p0) {
        auto&& t = std::get<1>(_p0);
        return t;
    }), Array<Text>{}));
}


/// `Start ReachFrom, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_reach_from(Array<std::tuple<Text, Text>> edges_, Text d) {
    return prism_rtl::make_rc<ReachFrom>(edges_, d);
}


/// Reach: unbounded fn [((Text, Text))], [Text], [Text] -> [Text]
Array<Text> reach(const Array<std::tuple<Text, Text>>& edges_, const Array<Text>& frontier, const Array<Text>& seen) {
    auto&& _m = index(frontier, Nat(0u));
    if (prism_rtl::is_none(_m)) {
        return seen;
    }
    if (prism_rtl::is_some(_m)) {
        auto&& x = prism_rtl::some_of(_m);
        return check_types::has_text(seen, x)
            ? reach(edges_, drop(frontier, Nat(1u)), seen)
            : reach(edges_, append(drop(frontier, Nat(1u)), each(filter(edges_, [&](const std::tuple<Text, Text>& _p0) {
            auto&& f = std::get<0>(_p0);
            return f == x;
        }), [&](const std::tuple<Text, Text>& _p0) {
            auto&& t = std::get<1>(_p0);
            return t;
        })), prelude::push(seen, x));
    }
    prism_rtl::unreachable("no arm matched");
}


/// IsLocalType: unbounded fn St, Ty -> Bool
bool is_local_type(const check_types::St& st, const check_types::Ty& t) {
    auto&& _m = check_types::walk(st, t);
    if (prism_rtl::is<check_types::Ty::TyCon>(_m)) {
        auto&& m28289_0_0 = prism_rtl::as<check_types::Ty::TyCon>(_m).a0;
        if (m28289_0_0 == Text::lit("Buffer")) {
            return true;
        }
    }
    if (prism_rtl::is<check_types::Ty::TyCon>(_m)) {
        auto&& m28289_1_0 = prism_rtl::as<check_types::Ty::TyCon>(_m).a0;
        if (m28289_1_0 == Text::lit("Table")) {
            return true;
        }
    }
    if (prism_rtl::is<check_types::Ty::TyArray>(_m)) {
        auto&& e = prism_rtl::as<check_types::Ty::TyArray>(_m).a0;
        return is_local_type(st, e);
    }
    if (prism_rtl::is<check_types::Ty::TyTuple>(_m)) {
        auto&& ts = prism_rtl::as<check_types::Ty::TyTuple>(_m).a0;
        return run_to_end(fold_job(ts, false, ({
            auto st_1 = st;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, check_types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_1_2 = st_1;
                entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto x = p1;
                    (prism_rtl::finished(seen || is_local_type(st_1_2, x)));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<check_types::Ty::TyMap>(_m)) {
        auto&& k = prism_rtl::as<check_types::Ty::TyMap>(_m).a0;
        auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(_m).a1;
        return is_local_type(st, k) || is_local_type(st, v_);
    }
    if (prism_rtl::is<check_types::Ty::TySig>(_m)) {
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(_m).a1;
        return is_local_type(st, i);
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> IsLocalType::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    auto st_1 = st;
    auto t_2 = t;
    return call_then(check_types::start_walk(st_1, t_2), [=](check_types::Ty walk_28295) {
        return ({
            prism_rtl::is<check_types::Ty::TyCon>(walk_28295) && ({
            auto&& m28289_0_0 = prism_rtl::as<check_types::Ty::TyCon>(walk_28295).a0;
            (m28289_0_0 == Text::lit("Buffer"));
        }) ? ({
            auto&& m28289_0_0 = prism_rtl::as<check_types::Ty::TyCon>(walk_28295).a0;
            prism_rtl::finished(true);
        })
            : prism_rtl::is<check_types::Ty::TyCon>(walk_28295) && ({
            auto&& m28289_1_0 = prism_rtl::as<check_types::Ty::TyCon>(walk_28295).a0;
            (m28289_1_0 == Text::lit("Table"));
        }) ? ({
            auto&& m28289_1_0 = prism_rtl::as<check_types::Ty::TyCon>(walk_28295).a0;
            prism_rtl::finished(true);
        })
            : prism_rtl::is<check_types::Ty::TyArray>(walk_28295) ? ({
            auto&& e = prism_rtl::as<check_types::Ty::TyArray>(walk_28295).a0;
            prism_rtl::more(prism_rtl::rc(IsLocalType(st_1, e)));
        })
            : prism_rtl::is<check_types::Ty::TyTuple>(walk_28295) ? ({
            auto&& ts = prism_rtl::as<check_types::Ty::TyTuple>(walk_28295).a0;
            fold_job(ts, false, ({
            auto st_1_3 = st_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, check_types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_1_3_3 = st_1_3;
                entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto x = p1;
                    (prism_rtl::finished(seen || is_local_type(st_1_3_3, x)));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<check_types::Ty::TyMap>(walk_28295) ? ({
            auto&& k = prism_rtl::as<check_types::Ty::TyMap>(walk_28295).a0;
            auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(walk_28295).a1;
            call_then(start_is_local_type(st_1, k), [=](bool is_local_type_28491) { return prism_rtl::finished(is_local_type_28491 || is_local_type(st_1, v_)); });
        })
            : prism_rtl::is<check_types::Ty::TySig>(walk_28295) ? ({
            auto&& i = prism_rtl::as<check_types::Ty::TySig>(walk_28295).a1;
            prism_rtl::more(prism_rtl::rc(IsLocalType(st_1, i)));
        })
            : prism_rtl::finished(false);
        });
    });
}


/// `Start IsLocalType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_local_type(check_types::St st, check_types::Ty t) {
    return prism_rtl::make_rc<IsLocalType>(st, t);
}


/// AndBlockChecks: unbounded fn Env, St, Block, Ty -> St
check_types::St and_block_checks(const check_expr::Env& env, const check_types::St& st, const ast::Block& b, const check_types::Ty& t) {
    auto st1 = is_local_type(st, t)
        ? check_types::err_fix(st, Text::lit("local-escapes"), b.span, prism_rtl::cat("a `", block_local_name(st, t), "` cannot leave its block"), Text::lit("`Freeze` it into a plain value first"))
        : st;
    auto st2 = escape_stmts(env, st1, b.stmts);
    auto&& _st3 = frozen_stmts(env, st2, b.stmts, Map<Text, Nat>{});
    auto&& st3 = std::get<1>(_st3);
    return borrow_stmts(env, st3, b.stmts, Array<Array<Text>>{});
}


prism_rtl::Turn<check_types::St> AndBlockChecks::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& b = this->b;
    const auto& t = this->t;
    auto b_1 = b;
    auto env_2 = env;
    auto st_3 = st;
    auto t_4 = t;
    return call_then(start_is_local_type(st_3, t_4), [=](bool is_local_type_28845) {
        return ({
            auto st1 = is_local_type_28845
                ? check_types::err_fix(st_3, Text::lit("local-escapes"), b_1.span, prism_rtl::cat("a `", block_local_name(st_3, t_4), "` cannot leave its block"), Text::lit("`Freeze` it into a plain value first"))
                : st_3;
            call_then(start_escape_stmts(env_2, st1, b_1.stmts), [=](check_types::St escape_stmts_29015) {
            return ({
                auto st2 = escape_stmts_29015;
                call_then(start_frozen_stmts(env_2, st2, b_1.stmts, Map<Text, Nat>{}), [=](std::tuple<Map<Text, Nat>, check_types::St> frozen_stmts_29071) {
                return ({
                    auto&& _st3 = frozen_stmts_29071;
                    auto&& st3 = std::get<1>(_st3);
                    (prism_rtl::more(prism_rtl::rc(BorrowStmts(env_2, st3, b_1.stmts, Array<Array<Text>>{}))));
                });
            });
            });
        });
        });
    });
}


/// `Start AndBlockChecks, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_and_block_checks(check_expr::Env env, check_types::St st, ast::Block b, check_types::Ty t) {
    return prism_rtl::make_rc<AndBlockChecks>(env, st, b, t);
}


/// BlockLocalName: unbounded fn St, Ty -> Text
Text block_local_name(const check_types::St& st, const check_types::Ty& t) {
    auto&& _m = check_types::walk(st, t);
    if (prism_rtl::is<check_types::Ty::TyCon>(_m)) {
        auto&& n = prism_rtl::as<check_types::Ty::TyCon>(_m).a0;
        return n;
    }
    {
        return Text::lit("Buffer");
    }
}


prism_rtl::Turn<Text> BlockLocalName::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    auto st_1 = st;
    auto t_2 = t;
    return call_then(check_types::start_walk(st_1, t_2), [=](check_types::Ty walk_29222) {
        return ({
            prism_rtl::is<check_types::Ty::TyCon>(walk_29222) ? ({
            auto&& n = prism_rtl::as<check_types::Ty::TyCon>(walk_29222).a0;
            prism_rtl::finished(n);
        })
            : prism_rtl::finished(Text::lit("Buffer"));
        });
    });
}


/// `Start BlockLocalName, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_block_local_name(check_types::St st, check_types::Ty t) {
    return prism_rtl::make_rc<BlockLocalName>(st, t);
}


/// EscapeStmts: unbounded fn Env, St, [Stmt] -> St
check_types::St escape_stmts(const check_expr::Env& env, const check_types::St& st, const Array<ast::Stmt>& stmts) {
    return run_to_end(fold_job(stmts, st, ({
        auto env_1 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, ast::Stmt>)>>(prism_rtl::rc([=](std::tuple<check_types::St, ast::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_2 = env_1;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto stmt = p1;
                ({
                auto&& _m = stmt.kind;
                prism_rtl::is<ast::StmtKind::SLet>(_m) ? ({
                auto&& p_ = prism_rtl::as<ast::StmtKind::SLet>(_m).a0;
                auto&& e = prism_rtl::as<ast::StmtKind::SLet>(_m).a2;
                ({
                auto&& _m = p_.kind;
                prism_rtl::is<ast::PatternKind::PName>(_m) ? ({
                auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
                lexer::has_prefix(n.sigils, Text::lit("&"))
                ? prism_rtl::finished(s)
                : ({
                auto&& _m = prelude::get(env_1_2.locals, check_env::sname_key(n));
                prism_rtl::is_some(_m) ? prism_rtl::finished(s)
                : prism_rtl::is_none(_m) ? calls_local_maker(env_1_2, e)
                ? prism_rtl::finished(check_types::err_fix(s, Text::lit("local-escapes"), stmt.span, prism_rtl::cat("a `Buffer` cannot leave its block: `", check_env::sname_key(n), "` is no `&` local"), prism_rtl::cat("write `let &", check_env::sname_key(n), " = ...`")))
                : prism_rtl::finished(s)
                : throw prism_rtl::Panic("no arm matched");
            });
            })
                : prism_rtl::finished(s);
            });
            })
                : prism_rtl::is<ast::StmtKind::SWhile>(_m) ? ({
                auto&& body = prism_rtl::as<ast::StmtKind::SWhile>(_m).a1;
                prism_rtl::more(prism_rtl::rc(EscapeStmts(env_1_2, s, body.stmts)));
            })
                : prism_rtl::is<ast::StmtKind::SExpr>(_m) ? ({
                auto&& e = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
                ({
                auto&& _m = e.kind;
                prism_rtl::is<ast::ExprKind::EIf>(_m) ? ({
                auto&& tb = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
                auto&& eb_opt = prism_rtl::as<ast::ExprKind::EIf>(_m).a2;
                ({
                auto eb_opt_2 = eb_opt;
                auto tb_3 = tb;
                call_then(start_escape_stmts(env_1_2, s, tb_3.stmts), [=](check_types::St escape_stmts_29931) {
                return ({
                    auto s2 = escape_stmts_29931;
                    ({
                    prism_rtl::is_some(eb_opt_2) ? ({
                    auto&& x = prism_rtl::some_of(eb_opt_2);
                    prism_rtl::more(prism_rtl::rc(EscapeStmts(env_1_2, s2, x.stmts)));
                })
                    : prism_rtl::is_none(eb_opt_2) ? prism_rtl::finished(s2)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            });
            });
            })
                : prism_rtl::is<ast::ExprKind::EMatch>(_m) ? ({
                auto&& arms = prism_rtl::as<ast::ExprKind::EMatch>(_m).a1;
                fold_job(arms, s, ({
                auto env_1_2_2 = env_1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, ast::Arm>)>>(prism_rtl::rc([=](std::tuple<check_types::St, ast::Arm> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto env_1_2_2_2 = env_1_2_2;
                    entered(once_job([=]() {
                    return ({
                        auto s3 = p0;
                        auto a = p1;
                        (prism_rtl::more(prism_rtl::rc(EscapeStmts(env_1_2_2_2, s3, a.body.stmts))));
                    });
                }));
                });
            })));
            }))->cycle();
            })
                : prism_rtl::is<ast::ExprKind::EFor>(_m) ? ({
                auto&& body = prism_rtl::as<ast::ExprKind::EFor>(_m).a2;
                prism_rtl::more(prism_rtl::rc(EscapeStmts(env_1_2, s, body.stmts)));
            })
                : prism_rtl::finished(s);
            });
            })
                : prism_rtl::finished(s);
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<check_types::St> EscapeStmts::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& stmts = this->stmts;
    return fold_job(stmts, st, ({
        auto env_1 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, ast::Stmt>)>>(prism_rtl::rc([=](std::tuple<check_types::St, ast::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_2 = env_1;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto stmt = p1;
                ({
                auto&& _m = stmt.kind;
                prism_rtl::is<ast::StmtKind::SLet>(_m) ? ({
                auto&& p_ = prism_rtl::as<ast::StmtKind::SLet>(_m).a0;
                auto&& e = prism_rtl::as<ast::StmtKind::SLet>(_m).a2;
                ({
                auto&& _m = p_.kind;
                prism_rtl::is<ast::PatternKind::PName>(_m) ? ({
                auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
                lexer::has_prefix(n.sigils, Text::lit("&"))
                ? prism_rtl::finished(s)
                : ({
                auto&& _m = prelude::get(env_1_2.locals, check_env::sname_key(n));
                prism_rtl::is_some(_m) ? prism_rtl::finished(s)
                : prism_rtl::is_none(_m) ? calls_local_maker(env_1_2, e)
                ? prism_rtl::finished(check_types::err_fix(s, Text::lit("local-escapes"), stmt.span, prism_rtl::cat("a `Buffer` cannot leave its block: `", check_env::sname_key(n), "` is no `&` local"), prism_rtl::cat("write `let &", check_env::sname_key(n), " = ...`")))
                : prism_rtl::finished(s)
                : throw prism_rtl::Panic("no arm matched");
            });
            })
                : prism_rtl::finished(s);
            });
            })
                : prism_rtl::is<ast::StmtKind::SWhile>(_m) ? ({
                auto&& body = prism_rtl::as<ast::StmtKind::SWhile>(_m).a1;
                prism_rtl::more(prism_rtl::rc(EscapeStmts(env_1_2, s, body.stmts)));
            })
                : prism_rtl::is<ast::StmtKind::SExpr>(_m) ? ({
                auto&& e = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
                ({
                auto&& _m = e.kind;
                prism_rtl::is<ast::ExprKind::EIf>(_m) ? ({
                auto&& tb = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
                auto&& eb_opt = prism_rtl::as<ast::ExprKind::EIf>(_m).a2;
                ({
                auto eb_opt_2 = eb_opt;
                auto tb_3 = tb;
                call_then(start_escape_stmts(env_1_2, s, tb_3.stmts), [=](check_types::St escape_stmts_29931) {
                return ({
                    auto s2 = escape_stmts_29931;
                    ({
                    prism_rtl::is_some(eb_opt_2) ? ({
                    auto&& x = prism_rtl::some_of(eb_opt_2);
                    prism_rtl::more(prism_rtl::rc(EscapeStmts(env_1_2, s2, x.stmts)));
                })
                    : prism_rtl::is_none(eb_opt_2) ? prism_rtl::finished(s2)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            });
            });
            })
                : prism_rtl::is<ast::ExprKind::EMatch>(_m) ? ({
                auto&& arms = prism_rtl::as<ast::ExprKind::EMatch>(_m).a1;
                fold_job(arms, s, ({
                auto env_1_2_2 = env_1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, ast::Arm>)>>(prism_rtl::rc([=](std::tuple<check_types::St, ast::Arm> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto env_1_2_2_2 = env_1_2_2;
                    entered(once_job([=]() {
                    return ({
                        auto s3 = p0;
                        auto a = p1;
                        (prism_rtl::more(prism_rtl::rc(EscapeStmts(env_1_2_2_2, s3, a.body.stmts))));
                    });
                }));
                });
            })));
            }))->cycle();
            })
                : prism_rtl::is<ast::ExprKind::EFor>(_m) ? ({
                auto&& body = prism_rtl::as<ast::ExprKind::EFor>(_m).a2;
                prism_rtl::more(prism_rtl::rc(EscapeStmts(env_1_2, s, body.stmts)));
            })
                : prism_rtl::finished(s);
            });
            })
                : prism_rtl::finished(s);
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start EscapeStmts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_escape_stmts(check_expr::Env env, check_types::St st, Array<ast::Stmt> stmts) {
    return prism_rtl::make_rc<EscapeStmts>(env, st, stmts);
}


/// CallsLocalMaker: fn Env, Expr -> Bool
bool calls_local_maker(const check_expr::Env& env, const ast::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
        auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
        return maker_of(env, c) != std::optional<Text>{};
    }
    if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
        auto&& _m = maker_of(env, e);
        if (prism_rtl::is_some(_m)) {
            auto&& k = prism_rtl::some_of(_m);
            return k != Text::lit("Buffer.Numbered");
        }
        if (prism_rtl::is_none(_m)) {
            return false;
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        return calls_local_maker(env, x);
    }
    {
        return false;
    }
}


/// ?MakerOf: fn Env, Expr -> ?Text
std::optional<Text> maker_of(const check_expr::Env& env, const ast::Expr& c) {
    auto&& _m = callee_name(c);
    if (prism_rtl::is_some(_m)) {
        auto&& n = prism_rtl::some_of(_m);
        return check_env::has_key(env.locals, n)
            ? std::optional<Text>{}
            : ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Text>> _v;
            auto&& _m = resolve_name(env.g, env.home, n);
            if (prism_rtl::is_some(_m)) {
                auto&& k = prism_rtl::some_of(_m);
                _v.set(check_expr::is_local_maker(k) && (or_(prelude::get(env.g.vals, k), dummy_val()).sort == Text::lit("builtin"))
                    ? std::optional(k)
                    : std::optional<Text>{});
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(std::optional<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// FrozenStmts: unbounded fn Env, St, [Stmt], (Text ==> Nat) -> (((Text ==> Nat), St))
std::tuple<Map<Text, Nat>, check_types::St> frozen_stmts(const check_expr::Env& env, const check_types::St& st, const Array<ast::Stmt>& stmts, const Map<Text, Nat>& frozen) {
    auto pre = prelude_seeds(env.g, env.home);
    auto seeds = fold(keys(pre), pre, [&](const Map<Text, Rel>& m, const Text& k) {
        return check_env::has_key(env.locals, lexer::drop_prefix(k, Text::lit("pre:")))
            ? prelude::remove(m, k)
            : m;
    });
    auto bm = block_rels(stmts, seeds);
    return run_to_end(fold_job(stmts, std::tuple{frozen, st}, ({
        auto bm_1 = bm;
        auto env_2 = env;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, Nat>, check_types::St>>(std::tuple<std::tuple<Map<Text, Nat>, check_types::St>, ast::Stmt>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Map<Text, Nat>, check_types::St>, ast::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto bm_1_3 = bm_1;
            auto env_2_3 = env_2;
            entered(once_job([=]() {
            return ({
                auto [fz, s] = p0;
                auto stmt = p1;
                call_then(start_stmt_spots(stmt, bm_1_3), [=](Array<Spot> stmt_spots_31796) {
                return ({
                    auto spots = stmt_spots_31796;
                    auto reads = fold(spots, Array<std::tuple<Text, ast::Range>>{}, [&](const Array<std::tuple<Text, ast::Range>>& acc, const Spot& sp) { return append(acc, spot_refs(sp)); });
                    auto s2 = fold(reads, s, [&](const check_types::St& s1, const std::tuple<Text, ast::Range>& _p1) {
                        auto&& n = std::get<0>(_p1);
                        auto&& sp = std::get<1>(_p1);
                        return ({
                            __label__ _done;
                            prism_rtl::Slot<check_types::St> _v;
                            auto&& _m = prelude::get(fz, n);
                            if (prism_rtl::is_some(_m)) {
                                auto&& line = prism_rtl::some_of(_m);
                                _v.set(check_types::err_fix(s1, Text::lit("frozen"), sp, prism_rtl::cat("`", n, "` was frozen on line ", line + Nat(1u)), Text::lit("use the frozen value, or make a new local")));
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(s1);
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        });
                    });
                    auto fz1 = ({
                        __label__ _done;
                        prism_rtl::Slot<Map<Text, Nat>> _v;
                        auto&& _m = stmt.kind;
                        if (prism_rtl::is<ast::StmtKind::SLet>(_m)) {
                            auto&& p_ = prism_rtl::as<ast::StmtKind::SLet>(_m).a0;
                            _v.set(fold(check_env::pattern_names(p_), fz, [&](const Map<Text, Nat>& m, const Text& n) { return prelude::remove(m, n); }));
                            goto _done;
                        }
                        {
                            _v.set(fz);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    call_value(fold_job(spots, fz1, ({
                    auto env_2_3_3 = env_2_3;
                    auto stmt_3 = stmt;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Nat>>(std::tuple<Map<Text, Nat>, Spot>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Nat>, Spot> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto env_2_3_3_4 = env_2_3_3;
                        auto stmt_3_4 = stmt_3;
                        entered(once_job([=]() {
                        return ({
                            auto m = p0;
                            auto sp = p1;
                            call_then(start_spot_freezes(sp), [=](Array<Text> spot_freezes_32294) { return prism_rtl::finished(fold(spot_freezes_32294, m, [&](const Map<Text, Nat>& m2, const Text& n) { return insert(m2, n, check_errors::cline_of(env_2_3_3_4.src.starts, stmt_3_4.span.start)); })); });
                        });
                    }));
                    });
                }));
                })), [=](Map<Text, Nat> fold_32262) {
                    return ({
                        auto fz2 = fold_32262;
                        (prism_rtl::finished(std::tuple{fz2, s2}));
                    });
                });
                });
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Map<Text, Nat>, check_types::St>> FrozenStmts::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& stmts = this->stmts;
    const auto& frozen = this->frozen;
    auto pre = prelude_seeds(env.g, env.home);
    auto seeds = fold(keys(pre), pre, [&](const Map<Text, Rel>& m, const Text& k) {
        return check_env::has_key(env.locals, lexer::drop_prefix(k, Text::lit("pre:")))
            ? prelude::remove(m, k)
            : m;
    });
    auto env_1 = env;
    auto frozen_2 = frozen;
    auto st_3 = st;
    auto stmts_4 = stmts;
    return call_then(start_block_rels(stmts_4, seeds), [=](Map<Text, Rel> block_rels_31702) {
        return ({
            auto bm = block_rels_31702;
            fold_job(stmts_4, std::tuple{frozen_2, st_3}, ({
            auto bm_5 = bm;
            auto env_1_6 = env_1;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, Nat>, check_types::St>>(std::tuple<std::tuple<Map<Text, Nat>, check_types::St>, ast::Stmt>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Map<Text, Nat>, check_types::St>, ast::Stmt> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto bm_5_6 = bm_5;
                auto env_1_6_6 = env_1_6;
                entered(once_job([=]() {
                return ({
                    auto [fz, s] = p0;
                    auto stmt = p1;
                    call_then(start_stmt_spots(stmt, bm_5_6), [=](Array<Spot> stmt_spots_31796) {
                    return ({
                        auto spots = stmt_spots_31796;
                        auto reads = fold(spots, Array<std::tuple<Text, ast::Range>>{}, [&](const Array<std::tuple<Text, ast::Range>>& acc, const Spot& sp) { return append(acc, spot_refs(sp)); });
                        auto s2 = fold(reads, s, [&](const check_types::St& s1, const std::tuple<Text, ast::Range>& _p1) {
                            auto&& n = std::get<0>(_p1);
                            auto&& sp = std::get<1>(_p1);
                            return ({
                                __label__ _done;
                                prism_rtl::Slot<check_types::St> _v;
                                auto&& _m = prelude::get(fz, n);
                                if (prism_rtl::is_some(_m)) {
                                    auto&& line = prism_rtl::some_of(_m);
                                    _v.set(check_types::err_fix(s1, Text::lit("frozen"), sp, prism_rtl::cat("`", n, "` was frozen on line ", line + Nat(1u)), Text::lit("use the frozen value, or make a new local")));
                                    goto _done;
                                }
                                if (prism_rtl::is_none(_m)) {
                                    _v.set(s1);
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            });
                        });
                        auto fz1 = ({
                            __label__ _done;
                            prism_rtl::Slot<Map<Text, Nat>> _v;
                            auto&& _m = stmt.kind;
                            if (prism_rtl::is<ast::StmtKind::SLet>(_m)) {
                                auto&& p_ = prism_rtl::as<ast::StmtKind::SLet>(_m).a0;
                                _v.set(fold(check_env::pattern_names(p_), fz, [&](const Map<Text, Nat>& m, const Text& n) { return prelude::remove(m, n); }));
                                goto _done;
                            }
                            {
                                _v.set(fz);
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                        call_value(fold_job(spots, fz1, ({
                        auto env_1_6_6_6 = env_1_6_6;
                        auto stmt_6 = stmt;
                        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Nat>>(std::tuple<Map<Text, Nat>, Spot>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Nat>, Spot> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto env_1_6_6_6_7 = env_1_6_6_6;
                            auto stmt_6_7 = stmt_6;
                            entered(once_job([=]() {
                            return ({
                                auto m = p0;
                                auto sp = p1;
                                call_then(start_spot_freezes(sp), [=](Array<Text> spot_freezes_32294) { return prism_rtl::finished(fold(spot_freezes_32294, m, [&](const Map<Text, Nat>& m2, const Text& n) { return insert(m2, n, check_errors::cline_of(env_1_6_6_6_7.src.starts, stmt_6_7.span.start)); })); });
                            });
                        }));
                        });
                    }));
                    })), [=](Map<Text, Nat> fold_32262) {
                        return ({
                            auto fz2 = fold_32262;
                            (prism_rtl::finished(std::tuple{fz2, s2}));
                        });
                    });
                    });
                });
                });
            }));
            });
        }));
        }))->cycle();
        });
    });
}


/// `Start FrozenStmts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Map<Text, Nat>, check_types::St>> start_frozen_stmts(check_expr::Env env, check_types::St st, Array<ast::Stmt> stmts, Map<Text, Nat> frozen) {
    return prism_rtl::make_rc<FrozenStmts>(env, st, stmts, frozen);
}


/// SpotRefs: fn Spot -> [((Text, Range))]
Array<std::tuple<Text, ast::Range>> spot_refs(const Spot& spot0) {
    if (prism_rtl::is<Spot::SpotExpr>(spot0)) {
        auto&& e = prism_rtl::as<Spot::SpotExpr>(spot0).a0;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            return lexer::has_prefix(n.sigils, Text::lit("&"))
                ? Array(std::vector{std::tuple{check_env::sname_key(n), n.span}})
                : Array<std::tuple<Text, ast::Range>>{};
        }
        {
            return Array<std::tuple<Text, ast::Range>>{};
        }
    }
    if (prism_rtl::is<Spot::SpotStmt>(spot0)) {
        return Array<std::tuple<Text, ast::Range>>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// SpotFreezes: unbounded fn Spot -> [Text]
Array<Text> spot_freezes(const Spot& spot0) {
    if (prism_rtl::is<Spot::SpotExpr>(spot0)) {
        auto&& e = prism_rtl::as<Spot::SpotExpr>(spot0).a0;
        auto&& m = prism_rtl::as<Spot::SpotExpr>(spot0).a1;
        auto&& _m = call_of(e);
        if (prism_rtl::is_some(_m)) {
            auto&& c = std::get<0>(prism_rtl::some_of(_m));
            auto&& args = std::get<1>(prism_rtl::some_of(_m));
            auto&& _m = callee_name(c);
            if (prism_rtl::is_some(_m)) {
                auto&& n = prism_rtl::some_of(_m);
                return pre_is(m, n, Text::lit("Freeze"))
                    ? run_to_end(fold_job(args, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::Arg>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::Arg> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return entered(once_job([=]() {
                        return ({
                            auto acc = p0;
                            auto a = p1;
                            (prism_rtl::finished(append(acc, each(refs_in(a->value), [&](const std::tuple<Text, ast::Range>& _p0) {
                            auto&& n2 = std::get<0>(_p0);
                            return n2;
                        }))));
                        });
                    }));
                }))))
                    : Array<Text>{};
            }
            if (prism_rtl::is_none(_m)) {
                return Array<Text>{};
            }
            prism_rtl::unreachable("no arm matched");
        }
        if (prism_rtl::is_none(_m)) {
            return Array<Text>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<Spot::SpotStmt>(spot0)) {
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> SpotFreezes::cycle() const {
    const auto& spot0 = this->spot0;
    return ({
        prism_rtl::is<Spot::SpotExpr>(spot0) ? ({
        auto&& e = prism_rtl::as<Spot::SpotExpr>(spot0).a0;
        auto&& m = prism_rtl::as<Spot::SpotExpr>(spot0).a1;
        ({
        auto&& _m = call_of(e);
        prism_rtl::is_some(_m) ? ({
        auto&& c = std::get<0>(prism_rtl::some_of(_m));
        auto&& args = std::get<1>(prism_rtl::some_of(_m));
        ({
        auto&& _m = callee_name(c);
        prism_rtl::is_some(_m) ? ({
        auto&& n = prism_rtl::some_of(_m);
        pre_is(m, n, Text::lit("Freeze"))
        ? fold_job(args, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::Arg>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::Arg> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto a = p1;
                (prism_rtl::finished(append(acc, each(refs_in(a->value), [&](const std::tuple<Text, ast::Range>& _p0) {
                auto&& n2 = std::get<0>(_p0);
                return n2;
            }))));
            });
        }));
    })))->cycle()
        : prism_rtl::finished(Array<Text>{});
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is<Spot::SpotStmt>(spot0) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SpotFreezes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_spot_freezes(Spot spot0) {
    return prism_rtl::make_rc<SpotFreezes>(spot0);
}


/// RefsIn: unbounded fn Expr -> [((Text, Range))]
Array<std::tuple<Text, ast::Range>> refs_in(const ast::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
        return lexer::has_prefix(n.sigils, Text::lit("&"))
            ? Array(std::vector{std::tuple{check_env::sname_key(n), n.span}})
            : Array<std::tuple<Text, ast::Range>>{};
    }
    if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
        auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
        return run_to_end(fold_job(args, refs_in(c), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, ast::Range>>>(std::tuple<Array<std::tuple<Text, ast::Range>>, ast::Arg>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, ast::Range>>, ast::Arg> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    (prism_rtl::finished(append(acc, refs_in(a->value))));
                });
            }));
        }))));
    }
    if (prism_rtl::is<ast::ExprKind::EBinary>(_m)) {
        auto&& l = prism_rtl::as<ast::ExprKind::EBinary>(_m).a1;
        auto&& r = prism_rtl::as<ast::ExprKind::EBinary>(_m).a2;
        return append(refs_in(l), refs_in(r));
    }
    if (prism_rtl::is<ast::ExprKind::EUnary>(_m)) {
        auto&& x = prism_rtl::as<ast::ExprKind::EUnary>(_m).a1;
        return refs_in(x);
    }
    if (prism_rtl::is<ast::ExprKind::EFreeSigil>(_m)) {
        auto&& x = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a1;
        return refs_in(x);
    }
    if (prism_rtl::is<ast::ExprKind::EField>(_m)) {
        auto&& r = prism_rtl::as<ast::ExprKind::EField>(_m).a0;
        return refs_in(r);
    }
    if (prism_rtl::is<ast::ExprKind::EIndex>(_m)) {
        auto&& r = prism_rtl::as<ast::ExprKind::EIndex>(_m).a0;
        auto&& i = prism_rtl::as<ast::ExprKind::EIndex>(_m).a1;
        return append(refs_in(r), refs_in(i));
    }
    if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        return refs_in(x);
    }
    if (prism_rtl::is<ast::ExprKind::ETuple>(_m)) {
        auto&& es = prism_rtl::as<ast::ExprKind::ETuple>(_m).a0;
        return run_to_end(fold_job(es, Array<std::tuple<Text, ast::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, ast::Range>>>(std::tuple<Array<std::tuple<Text, ast::Range>>, ast::Expr>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, ast::Range>>, ast::Expr> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto x = p1;
                    (prism_rtl::finished(append(acc, refs_in(x))));
                });
            }));
        }))));
    }
    if (prism_rtl::is<ast::ExprKind::EArray>(_m)) {
        auto&& es = prism_rtl::as<ast::ExprKind::EArray>(_m).a0;
        return run_to_end(fold_job(es, Array<std::tuple<Text, ast::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, ast::Range>>>(std::tuple<Array<std::tuple<Text, ast::Range>>, ast::Expr>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, ast::Range>>, ast::Expr> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto x = p1;
                    (prism_rtl::finished(append(acc, refs_in(x))));
                });
            }));
        }))));
    }
    {
        return Array<std::tuple<Text, ast::Range>>{};
    }
}


/// BorrowStmts: unbounded fn Env, St, [Stmt], [ [Text] ] -> St
check_types::St borrow_stmts(const check_expr::Env& env, const check_types::St& st, const Array<ast::Stmt>& stmts, const Array<Array<Text>>& lent) {
    return run_to_end(fold_job(stmts, st, ({
        auto env_1 = env;
        auto lent_2 = lent;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, ast::Stmt>)>>(prism_rtl::rc([=](std::tuple<check_types::St, ast::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_3 = env_1;
            auto lent_2_3 = lent_2;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto stmt = p1;
                ({
                auto&& _m = stmt.kind;
                prism_rtl::is<ast::StmtKind::SSet>(_m) ? ({
                auto&& t = prism_rtl::as<ast::StmtKind::SSet>(_m).a0;
                prism_rtl::more(prism_rtl::rc(CheckLent(env_1_3, s, t, lent_2_3)));
            })
                : prism_rtl::is<ast::StmtKind::SAccum>(_m) ? ({
                auto&& t = prism_rtl::as<ast::StmtKind::SAccum>(_m).a0;
                prism_rtl::more(prism_rtl::rc(CheckLent(env_1_3, s, t, lent_2_3)));
            })
                : prism_rtl::is<ast::StmtKind::SWhile>(_m) ? ({
                auto&& body = prism_rtl::as<ast::StmtKind::SWhile>(_m).a1;
                prism_rtl::more(prism_rtl::rc(BorrowStmts(env_1_3, s, body.stmts, lent_2_3)));
            })
                : prism_rtl::is<ast::StmtKind::SExpr>(_m) ? ({
                auto&& e = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
                ({
                auto&& _m = e.kind;
                prism_rtl::is<ast::ExprKind::EFor>(_m) ? ({
                auto&& binders_opt = prism_rtl::as<ast::ExprKind::EFor>(_m).a0;
                auto&& source = prism_rtl::as<ast::ExprKind::EFor>(_m).a1;
                auto&& body = prism_rtl::as<ast::ExprKind::EFor>(_m).a2;
                ({
                auto binders_opt_3 = binders_opt;
                auto body_4 = body;
                auto source_5 = source;
                call_then(start_ref_path(source_5), [=](Array<Text> ref_path_34235) {
                return ({
                    auto path_ = ref_path_34235;
                    auto lent2 = (len(path_) > Nat(0u)) && (binders_opt_3 != std::optional<ast::ForBinders>{})
                        ? prelude::push(lent_2_3, path_)
                        : lent_2_3;
                    (prism_rtl::more(prism_rtl::rc(BorrowStmts(env_1_3, s, body_4.stmts, lent2))));
                });
            });
            });
            })
                : prism_rtl::is<ast::ExprKind::EIf>(_m) ? ({
                auto&& tb = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
                auto&& eb_opt = prism_rtl::as<ast::ExprKind::EIf>(_m).a2;
                ({
                auto eb_opt_3 = eb_opt;
                auto tb_4 = tb;
                call_then(start_borrow_stmts(env_1_3, s, tb_4.stmts, lent_2_3), [=](check_types::St borrow_stmts_34440) {
                return ({
                    auto s2 = borrow_stmts_34440;
                    ({
                    prism_rtl::is_some(eb_opt_3) ? ({
                    auto&& x = prism_rtl::some_of(eb_opt_3);
                    prism_rtl::more(prism_rtl::rc(BorrowStmts(env_1_3, s2, x.stmts, lent_2_3)));
                })
                    : prism_rtl::is_none(eb_opt_3) ? prism_rtl::finished(s2)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            });
            });
            })
                : prism_rtl::is<ast::ExprKind::EMatch>(_m) ? ({
                auto&& arms = prism_rtl::as<ast::ExprKind::EMatch>(_m).a1;
                fold_job(arms, s, ({
                auto env_1_3_3 = env_1_3;
                auto lent_2_3_3 = lent_2_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, ast::Arm>)>>(prism_rtl::rc([=](std::tuple<check_types::St, ast::Arm> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto env_1_3_3_3 = env_1_3_3;
                    auto lent_2_3_3_3 = lent_2_3_3;
                    entered(once_job([=]() {
                    return ({
                        auto s3 = p0;
                        auto a = p1;
                        (prism_rtl::more(prism_rtl::rc(BorrowStmts(env_1_3_3_3, s3, a.body.stmts, lent_2_3_3_3))));
                    });
                }));
                });
            })));
            }))->cycle();
            })
                : prism_rtl::finished(s);
            });
            })
                : prism_rtl::finished(s);
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<check_types::St> BorrowStmts::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& stmts = this->stmts;
    const auto& lent = this->lent;
    return fold_job(stmts, st, ({
        auto env_1 = env;
        auto lent_2 = lent;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, ast::Stmt>)>>(prism_rtl::rc([=](std::tuple<check_types::St, ast::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_3 = env_1;
            auto lent_2_3 = lent_2;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto stmt = p1;
                ({
                auto&& _m = stmt.kind;
                prism_rtl::is<ast::StmtKind::SSet>(_m) ? ({
                auto&& t = prism_rtl::as<ast::StmtKind::SSet>(_m).a0;
                prism_rtl::more(prism_rtl::rc(CheckLent(env_1_3, s, t, lent_2_3)));
            })
                : prism_rtl::is<ast::StmtKind::SAccum>(_m) ? ({
                auto&& t = prism_rtl::as<ast::StmtKind::SAccum>(_m).a0;
                prism_rtl::more(prism_rtl::rc(CheckLent(env_1_3, s, t, lent_2_3)));
            })
                : prism_rtl::is<ast::StmtKind::SWhile>(_m) ? ({
                auto&& body = prism_rtl::as<ast::StmtKind::SWhile>(_m).a1;
                prism_rtl::more(prism_rtl::rc(BorrowStmts(env_1_3, s, body.stmts, lent_2_3)));
            })
                : prism_rtl::is<ast::StmtKind::SExpr>(_m) ? ({
                auto&& e = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
                ({
                auto&& _m = e.kind;
                prism_rtl::is<ast::ExprKind::EFor>(_m) ? ({
                auto&& binders_opt = prism_rtl::as<ast::ExprKind::EFor>(_m).a0;
                auto&& source = prism_rtl::as<ast::ExprKind::EFor>(_m).a1;
                auto&& body = prism_rtl::as<ast::ExprKind::EFor>(_m).a2;
                ({
                auto binders_opt_3 = binders_opt;
                auto body_4 = body;
                auto source_5 = source;
                call_then(start_ref_path(source_5), [=](Array<Text> ref_path_34235) {
                return ({
                    auto path_ = ref_path_34235;
                    auto lent2 = (len(path_) > Nat(0u)) && (binders_opt_3 != std::optional<ast::ForBinders>{})
                        ? prelude::push(lent_2_3, path_)
                        : lent_2_3;
                    (prism_rtl::more(prism_rtl::rc(BorrowStmts(env_1_3, s, body_4.stmts, lent2))));
                });
            });
            });
            })
                : prism_rtl::is<ast::ExprKind::EIf>(_m) ? ({
                auto&& tb = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
                auto&& eb_opt = prism_rtl::as<ast::ExprKind::EIf>(_m).a2;
                ({
                auto eb_opt_3 = eb_opt;
                auto tb_4 = tb;
                call_then(start_borrow_stmts(env_1_3, s, tb_4.stmts, lent_2_3), [=](check_types::St borrow_stmts_34440) {
                return ({
                    auto s2 = borrow_stmts_34440;
                    ({
                    prism_rtl::is_some(eb_opt_3) ? ({
                    auto&& x = prism_rtl::some_of(eb_opt_3);
                    prism_rtl::more(prism_rtl::rc(BorrowStmts(env_1_3, s2, x.stmts, lent_2_3)));
                })
                    : prism_rtl::is_none(eb_opt_3) ? prism_rtl::finished(s2)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            });
            });
            })
                : prism_rtl::is<ast::ExprKind::EMatch>(_m) ? ({
                auto&& arms = prism_rtl::as<ast::ExprKind::EMatch>(_m).a1;
                fold_job(arms, s, ({
                auto env_1_3_3 = env_1_3;
                auto lent_2_3_3 = lent_2_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, ast::Arm>)>>(prism_rtl::rc([=](std::tuple<check_types::St, ast::Arm> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto env_1_3_3_3 = env_1_3_3;
                    auto lent_2_3_3_3 = lent_2_3_3;
                    entered(once_job([=]() {
                    return ({
                        auto s3 = p0;
                        auto a = p1;
                        (prism_rtl::more(prism_rtl::rc(BorrowStmts(env_1_3_3_3, s3, a.body.stmts, lent_2_3_3_3))));
                    });
                }));
                });
            })));
            }))->cycle();
            })
                : prism_rtl::finished(s);
            });
            })
                : prism_rtl::finished(s);
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start BorrowStmts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_borrow_stmts(check_expr::Env env, check_types::St st, Array<ast::Stmt> stmts, Array<Array<Text>> lent) {
    return prism_rtl::make_rc<BorrowStmts>(env, st, stmts, lent);
}


/// CheckLent: unbounded fn Env, St, Expr, [ [Text] ] -> St
check_types::St check_lent(const check_expr::Env& env, const check_types::St& st, const ast::Expr& t, const Array<Array<Text>>& lent) {
    auto path_ = ref_path(t);
    return fold(lent, st, [&](const check_types::St& s, const Array<Text>& l) {
        return ((len(path_) > Nat(0u)) && is_prefix(l, path_)) || is_prefix(path_, l)
            ? check_types::err_fix(s, Text::lit("borrow-overlap"), t.span, prism_rtl::cat("`", lexer::join(l, Text::lit(".")), "` is lent to the `for`"), Text::lit("set it after the loop, or loop over a copy"))
            : s;
    });
}


prism_rtl::Turn<check_types::St> CheckLent::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& t = this->t;
    const auto& lent = this->lent;
    auto lent_1 = lent;
    auto st_2 = st;
    auto t_3 = t;
    return call_then(start_ref_path(t_3), [=](Array<Text> ref_path_34811) {
        return ({
            auto path_ = ref_path_34811;
            (prism_rtl::finished(fold(lent_1, st_2, [&](const check_types::St& s, const Array<Text>& l) {
            return ((len(path_) > Nat(0u)) && is_prefix(l, path_)) || is_prefix(path_, l)
                ? check_types::err_fix(s, Text::lit("borrow-overlap"), t_3.span, prism_rtl::cat("`", lexer::join(l, Text::lit(".")), "` is lent to the `for`"), Text::lit("set it after the loop, or loop over a copy"))
                : s;
        })));
        });
    });
}


/// `Start CheckLent, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_check_lent(check_expr::Env env, check_types::St st, ast::Expr t, Array<Array<Text>> lent) {
    return prism_rtl::make_rc<CheckLent>(env, st, t, lent);
}


/// IsPrefix: fn [Text], [Text] -> Bool
bool is_prefix(const Array<Text>& a, const Array<Text>& b) {
    return (len(a) <= len(b)) && (take(b, len(a)) == a);
}


/// RefPath: unbounded fn Expr -> [Text]
Array<Text> ref_path(const ast::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
        return lexer::has_prefix(n.sigils, Text::lit("&"))
            ? Array(std::vector{check_env::sname_key(n)})
            : Array<Text>{};
    }
    if (prism_rtl::is<ast::ExprKind::EField>(_m)) {
        auto&& r = prism_rtl::as<ast::ExprKind::EField>(_m).a0;
        auto&& f = prism_rtl::as<ast::ExprKind::EField>(_m).a2;
        auto p_ = ref_path(r);
        return len(p_) > Nat(0u) ? prelude::push(p_, f.name) : p_;
    }
    if (prism_rtl::is<ast::ExprKind::EIndex>(_m)) {
        auto&& r = prism_rtl::as<ast::ExprKind::EIndex>(_m).a0;
        auto p_ = ref_path(r);
        return len(p_) > Nat(0u) ? prelude::push(p_, Text::lit("[]")) : p_;
    }
    if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        return ref_path(x);
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> RefPath::cycle() const {
    const auto& e = this->e;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<ast::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
        lexer::has_prefix(n.sigils, Text::lit("&"))
        ? prism_rtl::finished(Array(std::vector{check_env::sname_key(n)}))
        : prism_rtl::finished(Array<Text>{});
    })
        : prism_rtl::is<ast::ExprKind::EField>(_m) ? ({
        auto&& r = prism_rtl::as<ast::ExprKind::EField>(_m).a0;
        auto&& f = prism_rtl::as<ast::ExprKind::EField>(_m).a2;
        ({
        auto f_1 = f;
        auto r_2 = r;
        call_then(start_ref_path(r_2), [=](Array<Text> ref_path_35401) {
        return ({
            auto p_ = ref_path_35401;
            len(p_) > Nat(0u)
            ? prism_rtl::finished(prelude::push(p_, f_1.name))
            : prism_rtl::finished(p_);
        });
    });
    });
    })
        : prism_rtl::is<ast::ExprKind::EIndex>(_m) ? ({
        auto&& r = prism_rtl::as<ast::ExprKind::EIndex>(_m).a0;
        ({
        auto r_1 = r;
        call_then(start_ref_path(r_1), [=](Array<Text> ref_path_35496) {
        return ({
            auto p_ = ref_path_35496;
            len(p_) > Nat(0u)
            ? prism_rtl::finished(prelude::push(p_, Text::lit("[]")))
            : prism_rtl::finished(p_);
        });
    });
    });
    })
        : prism_rtl::is<ast::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(RefPath(x)));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start RefPath, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_ref_path(ast::Expr e) {
    return prism_rtl::make_rc<RefPath>(e);
}


/// ShrinkCheck: unbounded fn G, St, [Def] -> ((St, [((Text, [Text]))]))
std::tuple<check_types::St, Array<std::tuple<Text, Array<Text>>>> shrink_check(const check_env::G& g, const check_types::St& st, const Array<check_env::Def>& defs) {
    auto fns = each(filter(defs, [&](const check_env::Def& d) { return len(def_clauses(d)) > Nat(0u); }), [&](const check_env::Def& d) { return own_key(d); });
    auto by_key = fold(fns, Map<Text, check_env::Def>{}, [&](const Map<Text, check_env::Def>& m, const check_env::Def& d) { return insert(m, d.qk, d); });
    auto homes = fold(fns, Array<Text>{}, [&](const Array<Text>& acc, const check_env::Def& d) { return check_types::add_text(acc, d.home); });
    auto nats = nat_minus_seeds(st);
    auto pre = fold(homes, Map<Text, Map<Text, Rel>>{}, [&](const Map<Text, Map<Text, Rel>>& m, const Text& h) { return insert(m, h, fold(keys(nats), prelude_seeds(g, h), [&](const Map<Text, Rel>& m2, const Text& k) { return insert(m2, k, no_rel()); })); });
    auto sk0 = Shrink{.g = g, .fns = fns, .by_key = by_key, .targets = method_targets(g, fns), .impl_defs = impl_defs(g, fns), .choices = st.choices, .sums = Map<Text, Nat>{}, .seeds = pre, .local_of = Map<Text, Text>{}, .local_base = Map<Text, Map<Text, Rel>>{}};
    auto sk1 = ({
        Shrink this_ = sk0;
        this_.sums = parts_summaries(sk0, fns);
        this_;
    });
    auto skg = ({
        Shrink this_ = sk1;
        this_.seeds = hof_seeds(sk1, homes);
        this_;
    });
    auto walked = run_to_end(each_job(fns, ({
        auto skg_1 = skg;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Array<Text>, Array<std::tuple<check_env::Def, Text, Text, Map<Text, Rel>, std::optional<ast::FnClause>, std::optional<ast::WidgetDecl>>>>>(check_env::Def)>>(prism_rtl::rc([=](check_env::Def p0) {
        return ({
            auto skg_1_2 = skg_1;
            entered(once_job([=]() {
            return ({
                auto d = p0;
                (prism_rtl::more(prism_rtl::rc(DefWalk(skg_1_2, d))));
            });
        }));
        });
    }));
    })));
    auto sk = with_locals(skg, fold(walked, Array<std::tuple<check_env::Def, Text, Text, Map<Text, Rel>, std::optional<ast::FnClause>, std::optional<ast::WidgetDecl>>>{}, [&](const Array<std::tuple<check_env::Def, Text, Text, Map<Text, Rel>, std::optional<ast::FnClause>, std::optional<ast::WidgetDecl>>>& acc, const std::tuple<Text, Array<Text>, Array<std::tuple<check_env::Def, Text, Text, Map<Text, Rel>, std::optional<ast::FnClause>, std::optional<ast::WidgetDecl>>>>& _p1) {
        auto&& ls = std::get<2>(_p1);
        return append(acc, ls);
    }));
    auto refs = append(each(walked, [&](const std::tuple<Text, Array<Text>, Array<std::tuple<check_env::Def, Text, Text, Map<Text, Rel>, std::optional<ast::FnClause>, std::optional<ast::WidgetDecl>>>>& _p0) {
        auto&& k = std::get<0>(_p0);
        auto&& rs = std::get<1>(_p0);
        return std::tuple{k, rs};
    }), run_to_end(each_job(drop(sk.fns, len(fns)), ({
        auto sk_1 = sk;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Array<Text>>>(check_env::Def)>>(prism_rtl::rc([=](check_env::Def p0) {
        return ({
            auto sk_1_2 = sk_1;
            entered(once_job([=]() {
            return ({
                auto d = p0;
                call_then(start_def_refs(sk_1_2, d), [=](Array<Text> def_refs_38255) { return prism_rtl::finished(std::tuple{d.qk, def_refs_38255}); });
            });
        }));
        });
    }));
    }))));
    auto keys_ = each(sk.fns, [&](const check_env::Def& d) { return d.qk; });
    auto sccs_ = sccs(keys_, refs);
    auto st2 = run_to_end(fold_job(sccs_, negative_types(g, st), ({
        auto sk_1 = sk;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, Array<Text>>)>>(prism_rtl::rc([=](std::tuple<check_types::St, Array<Text>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_1_2 = sk_1;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto comp = p1;
                (prism_rtl::more(prism_rtl::rc(ShrinkComponent(sk_1_2, s, comp))));
            });
        }));
        });
    })));
    })));
    auto st3 = run_to_end(fold_job(fns, st2, ({
        auto sk_1 = sk;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, check_env::Def>)>>(prism_rtl::rc([=](std::tuple<check_types::St, check_env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_1_2 = sk_1;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto d = p1;
                (prism_rtl::more(prism_rtl::rc(LoopsOf(sk_1_2, s, d))));
            });
        }));
        });
    })));
    })));
    return std::tuple{st3, refs};
}


prism_rtl::Turn<std::tuple<check_types::St, Array<std::tuple<Text, Array<Text>>>>> ShrinkCheck::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& defs = this->defs;
    auto fns = each(filter(defs, [&](const check_env::Def& d) { return len(def_clauses(d)) > Nat(0u); }), [&](const check_env::Def& d) { return own_key(d); });
    auto by_key = fold(fns, Map<Text, check_env::Def>{}, [&](const Map<Text, check_env::Def>& m, const check_env::Def& d) { return insert(m, d.qk, d); });
    auto homes = fold(fns, Array<Text>{}, [&](const Array<Text>& acc, const check_env::Def& d) { return check_types::add_text(acc, d.home); });
    auto g_1 = g;
    auto st_2 = st;
    return call_then(start_nat_minus_seeds(st_2), [=](Map<Text, Rel> nat_minus_seeds_37550) {
        return ({
            auto nats = nat_minus_seeds_37550;
            auto pre = fold(homes, Map<Text, Map<Text, Rel>>{}, [&](const Map<Text, Map<Text, Rel>>& m, const Text& h) { return insert(m, h, fold(keys(nats), prelude_seeds(g_1, h), [&](const Map<Text, Rel>& m2, const Text& k) { return insert(m2, k, no_rel()); })); });
            auto sk0 = Shrink{.g = g_1, .fns = fns, .by_key = by_key, .targets = method_targets(g_1, fns), .impl_defs = impl_defs(g_1, fns), .choices = st_2.choices, .sums = Map<Text, Nat>{}, .seeds = pre, .local_of = Map<Text, Text>{}, .local_base = Map<Text, Map<Text, Rel>>{}};
            auto sk1 = ({
                Shrink this_ = sk0;
                this_.sums = parts_summaries(sk0, fns);
                this_;
            });
            auto skg = ({
                Shrink this_ = sk1;
                this_.seeds = hof_seeds(sk1, homes);
                this_;
            });
            call_value(each_job(fns, ({
            auto skg_3 = skg;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Array<Text>, Array<std::tuple<check_env::Def, Text, Text, Map<Text, Rel>, std::optional<ast::FnClause>, std::optional<ast::WidgetDecl>>>>>(check_env::Def)>>(prism_rtl::rc([=](check_env::Def p0) {
            return ({
                auto skg_3_4 = skg_3;
                entered(once_job([=]() {
                return ({
                    auto d = p0;
                    (prism_rtl::more(prism_rtl::rc(DefWalk(skg_3_4, d))));
                });
            }));
            });
        }));
        })), [=](Array<std::tuple<Text, Array<Text>, Array<std::tuple<check_env::Def, Text, Text, Map<Text, Rel>, std::optional<ast::FnClause>, std::optional<ast::WidgetDecl>>>>> each_38014) {
            return ({
                auto walked = each_38014;
                call_then(start_with_locals(skg, fold(walked, Array<std::tuple<check_env::Def, Text, Text, Map<Text, Rel>, std::optional<ast::FnClause>, std::optional<ast::WidgetDecl>>>{}, [&](const Array<std::tuple<check_env::Def, Text, Text, Map<Text, Rel>, std::optional<ast::FnClause>, std::optional<ast::WidgetDecl>>>& acc, const std::tuple<Text, Array<Text>, Array<std::tuple<check_env::Def, Text, Text, Map<Text, Rel>, std::optional<ast::FnClause>, std::optional<ast::WidgetDecl>>>>& _p1) {
                auto&& ls = std::get<2>(_p1);
                return append(acc, ls);
            })), [=](Shrink with_locals_38057) {
                return ({
                    auto sk = with_locals_38057;
                    call_value(each_job(drop(sk.fns, len(fns)), ({
                    auto sk_3 = sk;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Array<Text>>>(check_env::Def)>>(prism_rtl::rc([=](check_env::Def p0) {
                    return ({
                        auto sk_3_4 = sk_3;
                        entered(once_job([=]() {
                        return ({
                            auto d = p0;
                            call_then(start_def_refs(sk_3_4, d), [=](Array<Text> def_refs_38255) { return prism_rtl::finished(std::tuple{d.qk, def_refs_38255}); });
                        });
                    }));
                    });
                }));
                })), [=](Array<std::tuple<Text, Array<Text>>> each_38210) {
                    return ({
                        auto refs = append(each(walked, [&](const std::tuple<Text, Array<Text>, Array<std::tuple<check_env::Def, Text, Text, Map<Text, Rel>, std::optional<ast::FnClause>, std::optional<ast::WidgetDecl>>>>& _p0) {
                            auto&& k = std::get<0>(_p0);
                            auto&& rs = std::get<1>(_p0);
                            return std::tuple{k, rs};
                        }), each_38210);
                        auto keys_ = each(sk.fns, [&](const check_env::Def& d) { return d.qk; });
                        call_then(start_sccs(keys_, refs), [=](Array<Array<Text>> sccs_38326) {
                        return ({
                            auto sccs_ = sccs_38326;
                            call_then(start_negative_types(g_1, st_2), [=](check_types::St negative_types_38368) {
                            return call_value(fold_job(sccs_, negative_types_38368, ({
                                auto sk_3 = sk;
                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, Array<Text>>)>>(prism_rtl::rc([=](std::tuple<check_types::St, Array<Text>> _p0) {
                                auto&& p0 = std::get<0>(_p0);
                                auto&& p1 = std::get<1>(_p0);
                                return ({
                                    auto sk_3_4 = sk_3;
                                    entered(once_job([=]() {
                                    return ({
                                        auto s = p0;
                                        auto comp = p1;
                                        (prism_rtl::more(prism_rtl::rc(ShrinkComponent(sk_3_4, s, comp))));
                                    });
                                }));
                                });
                            })));
                            })), [=](check_types::St fold_38356) {
                                return ({
                                    auto st2 = fold_38356;
                                    call_value(fold_job(fns, st2, ({
                                    auto sk_3 = sk;
                                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, check_env::Def>)>>(prism_rtl::rc([=](std::tuple<check_types::St, check_env::Def> _p0) {
                                    auto&& p0 = std::get<0>(_p0);
                                    auto&& p1 = std::get<1>(_p0);
                                    return ({
                                        auto sk_3_4 = sk_3;
                                        entered(once_job([=]() {
                                        return ({
                                            auto s = p0;
                                            auto d = p1;
                                            (prism_rtl::more(prism_rtl::rc(LoopsOf(sk_3_4, s, d))));
                                        });
                                    }));
                                    });
                                })));
                                })), [=](check_types::St fold_38443) {
                                    return ({
                                        auto st3 = fold_38443;
                                        (prism_rtl::finished(std::tuple{st3, refs}));
                                    });
                                });
                                });
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start ShrinkCheck, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::St, Array<std::tuple<Text, Array<Text>>>>> start_shrink_check(check_env::G g, check_types::St st, Array<check_env::Def> defs) {
    return prism_rtl::make_rc<ShrinkCheck>(g, st, defs);
}


/// UnusedDefs: fn [Def], [((Text, [Text]))], Nat -> [CDiag]
Array<check_errors::CDiag> unused_defs(const Array<check_env::Def>& defs, const Array<std::tuple<Text, Array<Text>>>& refs, const Nat& shown) {
    auto used = fold(refs, Map<Text, Unit>{}, [&](const Map<Text, Unit>& m, const std::tuple<Text, Array<Text>>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        return fold(rs, m, [&](const Map<Text, Unit>& m2, const Text& r) { return r == k ? m2 : insert(m2, r, Unit{}); });
    });
    auto own = filter(defs, [&](const check_env::Def& d) { return (((d->file < shown) && (!check_env::has_key(used, d.qk))) && (d.name != Text::lit("@main"))) && (!is_method_def(d)); });
    return each(own, [&](const check_env::Def& d) { return check_errors::CDiag{.code = Text::lit("unused"), .file = d->file, .span = d.span, .message = prism_rtl::cat("nothing uses `", d.name, "`"), .fix = Text::lit("delete it, or use it")}; });
}


/// IsMethodDef: fn Def -> Bool
bool is_method_def(const check_env::Def& d) {
    auto&& _m = d.body;
    if (prism_rtl::is<check_env::DefBody::DbMethod>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// NegativeTypes: unbounded fn G, St -> St
check_types::St negative_types(const check_env::G& g, const check_types::St& st) {
    auto arrowy = arrowy_types(g);
    return run_to_end(fold_job(keys(g.types), st, ({
        auto g_1 = g;
        auto arrowy_2 = arrowy;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, Text>)>>(prism_rtl::rc([=](std::tuple<check_types::St, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_3 = g_1;
            auto arrowy_2_3 = arrowy_2;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto n = p1;
                (prism_rtl::more(prism_rtl::rc(NegativeType(g_1_3, s, arrowy_2_3, n))));
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<check_types::St> NegativeTypes::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    auto g_1 = g;
    auto st_2 = st;
    return call_then(start_arrowy_types(g_1), [=](Map<Text, bool> arrowy_types_40143) {
        return ({
            auto arrowy = arrowy_types_40143;
            fold_job(keys(g_1.types), st_2, ({
            auto g_1_3 = g_1;
            auto arrowy_3 = arrowy;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, Text>)>>(prism_rtl::rc([=](std::tuple<check_types::St, Text> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto g_1_3_4 = g_1_3;
                auto arrowy_3_4 = arrowy_3;
                entered(once_job([=]() {
                return ({
                    auto s = p0;
                    auto n = p1;
                    (prism_rtl::more(prism_rtl::rc(NegativeType(g_1_3_4, s, arrowy_3_4, n))));
                });
            }));
            });
        })));
        }))->cycle();
        });
    });
}


/// `Start NegativeTypes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_negative_types(check_env::G g, check_types::St st) {
    return prism_rtl::make_rc<NegativeTypes>(g, st);
}


/// NegativeType: unbounded fn G, St, (Text ==> Bool), Text -> St
check_types::St negative_type(const check_env::G& g, const check_types::St& s, const Map<Text, bool>& arrowy, const Text& n) {
    auto&& _m = prelude::get(g.types, n);
    if (prism_rtl::is_some(_m)) {
        auto&& ti = prism_rtl::some_of(_m);
        auto&& _neg = (ti->file >= g.prelude_from) || (!check_env::has_key(arrowy, n))
            ? std::tuple{false, Map<Text, bool>{}}
            : neg_walks(g, n, body_tys(ti), false, Map<Text, bool>{});
        auto&& neg = std::get<0>(_neg);
        return !neg
            ? s
            : ({
            auto s0 = ({
                check_types::St this_ = s;
                this_.file = ti->file;
                this_;
            });
            auto s1 = check_types::err_fix(s0, Text::lit("may-not-end"), ti.span, prism_rtl::cat("`", check_types::bare_name(n), "` stands left of a function arrow in its own definition: a call through the function it holds is a cycle, and nothing in it shrinks"), prism_rtl::cat("keep `", check_types::bare_name(n), "` right of the arrow, or make the arrow `unbounded fn`, which makes every call through it unbounded"));
            ({
            check_types::St this_ = s1;
            this_.file = s->file;
            this_;
        });
        });
    }
    if (prism_rtl::is_none(_m)) {
        return s;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<check_types::St> NegativeType::cycle() const {
    const auto& g = this->g;
    const auto& s = this->s;
    const auto& arrowy = this->arrowy;
    const auto& n = this->n;
    return ({
        auto&& _m = prelude::get(g.types, n);
        prism_rtl::is_some(_m) ? ({
        auto&& ti = prism_rtl::some_of(_m);
        ({
        auto&& _neg = (ti->file >= g.prelude_from) || (!check_env::has_key(arrowy, n))
            ? std::tuple{false, Map<Text, bool>{}}
            : neg_walks(g, n, body_tys(ti), false, Map<Text, bool>{});
        auto&& neg = std::get<0>(_neg);
        !neg
        ? prism_rtl::finished(s)
        : ({
        auto s0 = ({
            check_types::St this_ = s;
            this_.file = ti->file;
            this_;
        });
        auto s1 = check_types::err_fix(s0, Text::lit("may-not-end"), ti.span, prism_rtl::cat("`", check_types::bare_name(n), "` stands left of a function arrow in its own definition: a call through the function it holds is a cycle, and nothing in it shrinks"), prism_rtl::cat("keep `", check_types::bare_name(n), "` right of the arrow, or make the arrow `unbounded fn`, which makes every call through it unbounded"));
        (prism_rtl::finished(({
        check_types::St this_ = s1;
        this_.file = s->file;
        this_;
    })));
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(s)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start NegativeType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_negative_type(check_env::G g, check_types::St s, Map<Text, bool> arrowy, Text n) {
    return prism_rtl::make_rc<NegativeType>(g, s, arrowy, n);
}


/// ArrowyTypes: unbounded fn G -> (Text ==> Bool)
Map<Text, bool> arrowy_types(const check_env::G& g) {
    auto names = run_to_end(fold_job(keys(g.types), Map<Text, Array<Text>>{}, ({
        auto g_1 = g;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, Text>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Array<Text>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_2 = g_1;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                auto n = p1;
                ({
                auto&& _m = prelude::get(g_1_2.types, n);
                prism_rtl::is_some(_m) ? ({
                auto&& ti = prism_rtl::some_of(_m);
                call_value(fold_job(body_tys(ti), Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, check_types::Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto t = p1;
                        call_then(start_ty_names_in(t), [=](Array<Text> ty_names_in_41439) { return prism_rtl::finished(check_types::union_texts(acc, ty_names_in_41439)); });
                    });
                }));
            }))), [=](Array<Text> fold_41387) { return prism_rtl::finished(insert(m, n, fold_41387)); });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(m)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })));
    auto direct = run_to_end(fold_job(keys(g.types), Map<Text, bool>{}, ({
        auto g_1 = g;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, bool>>(std::tuple<Map<Text, bool>, Text>)>>(prism_rtl::rc([=](std::tuple<Map<Text, bool>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_2 = g_1;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                auto n = p1;
                ({
                auto&& _m = prelude::get(g_1_2.types, n);
                prism_rtl::is_some(_m) ? ({
                auto&& ti = prism_rtl::some_of(_m);
                call_value(fold_job(body_tys(ti), false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, check_types::Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto seen = p0;
                        auto t = p1;
                        (prism_rtl::finished(seen || has_arrow(t)));
                    });
                }));
            }))), [=](bool fold_41553) {
                return fold_41553
                    ? prism_rtl::finished(insert(m, n, true))
                    : prism_rtl::finished(m);
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(m)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })));
    return arrowy_from(names, direct);
}


prism_rtl::Turn<Map<Text, bool>> ArrowyTypes::cycle() const {
    const auto& g = this->g;
    auto g_1 = g;
    return call_value(fold_job(keys(g_1.types), Map<Text, Array<Text>>{}, ({
        auto g_1_2 = g_1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, Text>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Array<Text>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_2_2 = g_1_2;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                auto n = p1;
                ({
                auto&& _m = prelude::get(g_1_2_2.types, n);
                prism_rtl::is_some(_m) ? ({
                auto&& ti = prism_rtl::some_of(_m);
                call_value(fold_job(body_tys(ti), Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, check_types::Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto t = p1;
                        call_then(start_ty_names_in(t), [=](Array<Text> ty_names_in_41439) { return prism_rtl::finished(check_types::union_texts(acc, ty_names_in_41439)); });
                    });
                }));
            }))), [=](Array<Text> fold_41387) { return prism_rtl::finished(insert(m, n, fold_41387)); });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(m)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })), [=](Map<Text, Array<Text>> fold_41308) {
        return ({
            auto names = fold_41308;
            call_value(fold_job(keys(g_1.types), Map<Text, bool>{}, ({
            auto g_1_2 = g_1;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, bool>>(std::tuple<Map<Text, bool>, Text>)>>(prism_rtl::rc([=](std::tuple<Map<Text, bool>, Text> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto g_1_2_2 = g_1_2;
                entered(once_job([=]() {
                return ({
                    auto m = p0;
                    auto n = p1;
                    ({
                    auto&& _m = prelude::get(g_1_2_2.types, n);
                    prism_rtl::is_some(_m) ? ({
                    auto&& ti = prism_rtl::some_of(_m);
                    call_value(fold_job(body_tys(ti), false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, check_types::Ty> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return entered(once_job([=]() {
                        return ({
                            auto seen = p0;
                            auto t = p1;
                            (prism_rtl::finished(seen || has_arrow(t)));
                        });
                    }));
                }))), [=](bool fold_41553) {
                    return fold_41553
                        ? prism_rtl::finished(insert(m, n, true))
                        : prism_rtl::finished(m);
                });
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(m)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        }));
        })), [=](Map<Text, bool> fold_41485) {
            return ({
                auto direct = fold_41485;
                (prism_rtl::more(prism_rtl::rc(ArrowyFrom(names, direct))));
            });
        });
        });
    });
}


/// `Start ArrowyTypes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, bool>> start_arrowy_types(check_env::G g) {
    return prism_rtl::make_rc<ArrowyTypes>(g);
}


/// ArrowyFrom: unbounded fn (Text ==> [Text]), (Text ==> Bool) -> (Text ==> Bool)
Map<Text, bool> arrowy_from(const Map<Text, Array<Text>>& names, const Map<Text, bool>& got) {
    auto next = fold(keys(names), got, [&](const Map<Text, bool>& m, const Text& n) {
        return check_env::has_key(m, n)
            ? m
            : fold(or_(prelude::get(names, n), Array<Text>{}), false, [&](const bool& seen, const Text& r) { return seen || check_env::has_key(got, r); })
            ? insert(m, n, true)
            : m;
    });
    return len(keys(next)) == len(keys(got)) ? got : arrowy_from(names, next);
}


prism_rtl::Turn<Map<Text, bool>> ArrowyFrom::cycle() const {
    const auto& names = this->names;
    const auto& got = this->got;
    auto next = fold(keys(names), got, [&](const Map<Text, bool>& m, const Text& n) {
        return check_env::has_key(m, n)
            ? m
            : fold(or_(prelude::get(names, n), Array<Text>{}), false, [&](const bool& seen, const Text& r) { return seen || check_env::has_key(got, r); })
            ? insert(m, n, true)
            : m;
    });
    return len(keys(next)) == len(keys(got))
        ? prism_rtl::finished(got)
        : prism_rtl::more(prism_rtl::rc(ArrowyFrom(names, next)));
}


/// `Start ArrowyFrom, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, bool>> start_arrowy_from(Map<Text, Array<Text>> names, Map<Text, bool> got) {
    return prism_rtl::make_rc<ArrowyFrom>(names, got);
}


/// TyNamesIn: unbounded fn Ty -> [Text]
Array<Text> ty_names_in(const check_types::Ty& t) {
    if (prism_rtl::is<check_types::Ty::TyCon>(t)) {
        auto&& c = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        return run_to_end(fold_job(args, Array(std::vector{c}), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, check_types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_ty_names_in(a), [=](Array<Text> ty_names_in_42235) { return prism_rtl::finished(check_types::union_texts(acc, ty_names_in_42235)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<check_types::Ty::TyFn>(t)) {
        auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<check_types::Ty::TyFn>(t).a2;
        return run_to_end(fold_job(ps, ty_names_in(res), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, check_types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_ty_names_in(a), [=](Array<Text> ty_names_in_42327) { return prism_rtl::finished(check_types::union_texts(acc, ty_names_in_42327)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<check_types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<check_types::Ty::TyTuple>(t).a0;
        return run_to_end(fold_job(ts, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, check_types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_ty_names_in(a), [=](Array<Text> ty_names_in_42398) { return prism_rtl::finished(check_types::union_texts(acc, ty_names_in_42398)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<check_types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<check_types::Ty::TyArray>(t).a0;
        return ty_names_in(e);
    }
    if (prism_rtl::is<check_types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<check_types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(t).a1;
        return check_types::union_texts(ty_names_in(k), ty_names_in(v_));
    }
    if (prism_rtl::is<check_types::Ty::TySig>(t)) {
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        return ty_names_in(i);
    }
    if (prism_rtl::is<check_types::Ty::TyAt>(t)) {
        auto&& i = prism_rtl::as<check_types::Ty::TyAt>(t).a0;
        return ty_names_in(i);
    }
    if (prism_rtl::is<check_types::Ty::TyElem>(t)) {
        auto&& i = prism_rtl::as<check_types::Ty::TyElem>(t).a1;
        return ty_names_in(i);
    }
    if (prism_rtl::is<check_types::Ty::TyAssoc>(t)) {
        auto&& i = prism_rtl::as<check_types::Ty::TyAssoc>(t).a1;
        return ty_names_in(i);
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> TyNamesIn::cycle() const {
    const auto& t = this->t;
    return ({
        prism_rtl::is<check_types::Ty::TyCon>(t) ? ({
        auto&& c = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        fold_job(args, Array(std::vector{c}), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, check_types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto a = p1;
                call_then(start_ty_names_in(a), [=](Array<Text> ty_names_in_42235) { return prism_rtl::finished(check_types::union_texts(acc, ty_names_in_42235)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<check_types::Ty::TyFn>(t) ? ({
        auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<check_types::Ty::TyFn>(t).a2;
        ({
        auto ps_1 = ps;
        auto res_2 = res;
        call_then(start_ty_names_in(res_2), [=](Array<Text> ty_names_in_42284) {
        return fold_job(ps_1, ty_names_in_42284, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, check_types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_ty_names_in(a), [=](Array<Text> ty_names_in_42327) { return prism_rtl::finished(check_types::union_texts(acc, ty_names_in_42327)); });
                });
            }));
        })))->cycle();
    });
    });
    })
        : prism_rtl::is<check_types::Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<check_types::Ty::TyTuple>(t).a0;
        fold_job(ts, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, check_types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto a = p1;
                call_then(start_ty_names_in(a), [=](Array<Text> ty_names_in_42398) { return prism_rtl::finished(check_types::union_texts(acc, ty_names_in_42398)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<check_types::Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<check_types::Ty::TyArray>(t).a0;
        prism_rtl::more(prism_rtl::rc(TyNamesIn(e)));
    })
        : prism_rtl::is<check_types::Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<check_types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(t).a1;
        ({
        auto k_1 = k;
        auto v__2 = v_;
        call_then(start_ty_names_in(k_1), [=](Array<Text> ty_names_in_42466) { return call_then(start_ty_names_in(v__2), [=](Array<Text> ty_names_in_42481) { return prism_rtl::finished(check_types::union_texts(ty_names_in_42466, ty_names_in_42481)); }); });
    });
    })
        : prism_rtl::is<check_types::Ty::TySig>(t) ? ({
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        prism_rtl::more(prism_rtl::rc(TyNamesIn(i)));
    })
        : prism_rtl::is<check_types::Ty::TyAt>(t) ? ({
        auto&& i = prism_rtl::as<check_types::Ty::TyAt>(t).a0;
        prism_rtl::more(prism_rtl::rc(TyNamesIn(i)));
    })
        : prism_rtl::is<check_types::Ty::TyElem>(t) ? ({
        auto&& i = prism_rtl::as<check_types::Ty::TyElem>(t).a1;
        prism_rtl::more(prism_rtl::rc(TyNamesIn(i)));
    })
        : prism_rtl::is<check_types::Ty::TyAssoc>(t) ? ({
        auto&& i = prism_rtl::as<check_types::Ty::TyAssoc>(t).a1;
        prism_rtl::more(prism_rtl::rc(TyNamesIn(i)));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start TyNamesIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_ty_names_in(check_types::Ty t) {
    return prism_rtl::make_rc<TyNamesIn>(t);
}


/// HasArrow: unbounded fn Ty -> Bool
bool has_arrow(const check_types::Ty& t) {
    if (prism_rtl::is<check_types::Ty::TyFn>(t)) {
        return true;
    }
    if (prism_rtl::is<check_types::Ty::TyCon>(t)) {
        auto&& args = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        return run_to_end(fold_job(args, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, check_types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto a = p1;
                    (prism_rtl::finished(seen || has_arrow(a)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<check_types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<check_types::Ty::TyTuple>(t).a0;
        return run_to_end(fold_job(ts, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, check_types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto a = p1;
                    (prism_rtl::finished(seen || has_arrow(a)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<check_types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<check_types::Ty::TyArray>(t).a0;
        return has_arrow(e);
    }
    if (prism_rtl::is<check_types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<check_types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(t).a1;
        return has_arrow(k) || has_arrow(v_);
    }
    if (prism_rtl::is<check_types::Ty::TySig>(t)) {
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        return has_arrow(i);
    }
    if (prism_rtl::is<check_types::Ty::TyAt>(t)) {
        auto&& i = prism_rtl::as<check_types::Ty::TyAt>(t).a0;
        return has_arrow(i);
    }
    if (prism_rtl::is<check_types::Ty::TyElem>(t)) {
        auto&& i = prism_rtl::as<check_types::Ty::TyElem>(t).a1;
        return has_arrow(i);
    }
    if (prism_rtl::is<check_types::Ty::TyAssoc>(t)) {
        auto&& i = prism_rtl::as<check_types::Ty::TyAssoc>(t).a1;
        return has_arrow(i);
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> HasArrow::cycle() const {
    const auto& t = this->t;
    return ({
        prism_rtl::is<check_types::Ty::TyFn>(t) ? prism_rtl::finished(true)
        : prism_rtl::is<check_types::Ty::TyCon>(t) ? ({
        auto&& args = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        fold_job(args, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, check_types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto seen = p0;
                auto a = p1;
                (prism_rtl::finished(seen || has_arrow(a)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<check_types::Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<check_types::Ty::TyTuple>(t).a0;
        fold_job(ts, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, check_types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto seen = p0;
                auto a = p1;
                (prism_rtl::finished(seen || has_arrow(a)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<check_types::Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<check_types::Ty::TyArray>(t).a0;
        prism_rtl::more(prism_rtl::rc(HasArrow(e)));
    })
        : prism_rtl::is<check_types::Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<check_types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(t).a1;
        ({
        auto k_1 = k;
        auto v__2 = v_;
        call_then(start_has_arrow(k_1), [=](bool has_arrow_42923) { return prism_rtl::finished(has_arrow_42923 || has_arrow(v__2)); });
    });
    })
        : prism_rtl::is<check_types::Ty::TySig>(t) ? ({
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        prism_rtl::more(prism_rtl::rc(HasArrow(i)));
    })
        : prism_rtl::is<check_types::Ty::TyAt>(t) ? ({
        auto&& i = prism_rtl::as<check_types::Ty::TyAt>(t).a0;
        prism_rtl::more(prism_rtl::rc(HasArrow(i)));
    })
        : prism_rtl::is<check_types::Ty::TyElem>(t) ? ({
        auto&& i = prism_rtl::as<check_types::Ty::TyElem>(t).a1;
        prism_rtl::more(prism_rtl::rc(HasArrow(i)));
    })
        : prism_rtl::is<check_types::Ty::TyAssoc>(t) ? ({
        auto&& i = prism_rtl::as<check_types::Ty::TyAssoc>(t).a1;
        prism_rtl::more(prism_rtl::rc(HasArrow(i)));
    })
        : prism_rtl::finished(false);
    });
}

}  // namespace crate::check_passes
