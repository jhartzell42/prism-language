// The module `Check.Typed.Print`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/typed/print/module.hpp>
#include <check/errors/module.hpp>
#include <check/typed/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Check.Typed.Print`, from `target/bootstrap/cpp-src/prismc/check/typed/print.prism`.
namespace crate::check::typed::print {

/// TySexp: unbounded fn Ty -> Text
Text ty_sexp_f(const crate::check::types::Ty& t_p0) {
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(t_p0)) {
        auto&& n_p1 = prism_rtl::as<crate::check::types::Ty::TyFlex>(t_p0).a0;
        return prism_rtl::cat("(var t", n_p1, ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyRigid>(t_p0)) {
        auto&& n_p2 = prism_rtl::as<crate::check::types::Ty::TyRigid>(t_p0).a0;
        return prism_rtl::cat("(rigid ", n_p2, ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyQ>(t_p0)) {
        auto&& n_p3 = prism_rtl::as<crate::check::types::Ty::TyQ>(t_p0).a0;
        return prism_rtl::cat("(q ", n_p3, ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p0)) {
        auto&& n_p4 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a0;
        auto&& m820_3_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a1;
        if (m820_3_1.size() == 0u) {
            return n_p4;
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p0)) {
        auto&& n_p5 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a0;
        auto&& args_p6 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a1;
        return prism_rtl::cat("(", n_p5, crate::prelude::concat(crate::prelude::run_to_end(crate::prelude::each_job(args_p6, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto a_p7 = p0;
                    (crate::prelude::call_then(start_ty_sexp_f(a_p7), [=](Text ty_sexp_f_979) { return prism_rtl::finished(prism_rtl::cat(" ", ty_sexp_f_979)); }));
                });
            }));
        }))))), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p0)) {
        auto&& c_p8 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a0;
        auto&& ps_p9 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a1;
        auto&& res_pa = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a2;
        return prism_rtl::cat("(fn ", col_sexp_f(c_p8), " (", crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(ps_p9, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::types::Ty)>>(prism_rtl::rc([&](crate::check::types::Ty a0) { return crate::prelude::entered(start_ty_sexp_f(a0)); })))), Text::lit(" ")), ") ", ty_sexp_f(prism_rtl::deref(prism_rtl::deref(res_pa))), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p0)) {
        auto&& ts_pb = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p0).a0;
        return prism_rtl::cat("(tuple", crate::prelude::concat(crate::prelude::run_to_end(crate::prelude::each_job(ts_pb, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto a_pc = p0;
                    (crate::prelude::call_then(start_ty_sexp_f(a_pc), [=](Text ty_sexp_f_1128) { return prism_rtl::finished(prism_rtl::cat(" ", ty_sexp_f_1128)); }));
                });
            }));
        }))))), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p0)) {
        auto&& e_pd = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p0).a0;
        return prism_rtl::cat("(array ", ty_sexp_f(prism_rtl::deref(prism_rtl::deref(e_pd))), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p0)) {
        auto&& k_pe = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a0;
        auto&& v_pf = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a1;
        return prism_rtl::cat("(map ", ty_sexp_f(prism_rtl::deref(prism_rtl::deref(k_pe))), " ", ty_sexp_f(prism_rtl::deref(prism_rtl::deref(v_pf))), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& s_pg = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a0;
        auto&& i_ph = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        return prism_rtl::cat("(", s_pg, " ", ty_sexp_f(prism_rtl::deref(prism_rtl::deref(i_ph))), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p0)) {
        auto&& i_pi = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p0).a0;
        auto&& rw_pj = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p0).a1;
        return prism_rtl::cat("(@ ", ty_sexp_f(prism_rtl::deref(prism_rtl::deref(i_pi))), " ", row_sexp_f(rw_pj), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t_p0)) {
        auto&& rw_pk = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p0).a0;
        auto&& o_pl = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p0).a1;
        return prism_rtl::cat("(element ", row_sexp_f(rw_pk), " ", ty_sexp_f(prism_rtl::deref(prism_rtl::deref(o_pl))), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(t_p0)) {
        auto&& rw_pm = prism_rtl::as<crate::check::types::Ty::TyElemAny>(t_p0).a0;
        return prism_rtl::cat("(elem ", row_sexp_f(rw_pm), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p0)) {
        auto&& n_pn = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p0).a0;
        auto&& a_po = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p0).a1;
        return prism_rtl::cat("(assoc ", n_pn, " ", ty_sexp_f(prism_rtl::deref(prism_rtl::deref(a_po))), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAny>(t_p0)) {
        auto&& trs_pp = prism_rtl::as<crate::check::types::Ty::TyAny>(t_p0).a0;
        return prism_rtl::cat("(any", crate::prelude::concat(crate::prelude::each(trs_pp, [&](const Text& x_pq) { return prism_rtl::cat(" ^", x_pq); })), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyErr>(t_p0)) {
        return Text::lit("unknown");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> TySexp::cycle() const {
    const auto& t_p0 = this->t_p0;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyFlex>(t_p0) ? ({
        auto&& n_p1 = prism_rtl::as<crate::check::types::Ty::TyFlex>(t_p0).a0;
        prism_rtl::finished(prism_rtl::cat("(var t", n_p1, ")"));
    })
        : prism_rtl::is<crate::check::types::Ty::TyRigid>(t_p0) ? ({
        auto&& n_p2 = prism_rtl::as<crate::check::types::Ty::TyRigid>(t_p0).a0;
        prism_rtl::finished(prism_rtl::cat("(rigid ", n_p2, ")"));
    })
        : prism_rtl::is<crate::check::types::Ty::TyQ>(t_p0) ? ({
        auto&& n_p3 = prism_rtl::as<crate::check::types::Ty::TyQ>(t_p0).a0;
        prism_rtl::finished(prism_rtl::cat("(q ", n_p3, ")"));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p0) && ({
        auto&& n_p4 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a0;
        auto&& m820_3_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a1;
        (m820_3_1.size() == 0u);
    }) ? ({
        auto&& n_p4 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a0;
        auto&& m820_3_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a1;
        prism_rtl::finished(n_p4);
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p0) ? ({
        auto&& n_p5 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a0;
        auto&& args_p6 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a1;
        ({
        auto args_p6x = args_p6;
        auto n_p5x = n_p5;
        (crate::prelude::call_value(crate::prelude::each_job(args_p6x, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto a_p7 = p0;
                (crate::prelude::call_then(start_ty_sexp_f(a_p7), [=](Text ty_sexp_f_979) { return prism_rtl::finished(prism_rtl::cat(" ", ty_sexp_f_979)); }));
            });
        }));
    }))), [=, n_p5x = std::move(n_p5x)](Array<Text> each_960) { return prism_rtl::finished(prism_rtl::cat("(", n_p5x, crate::prelude::concat(each_960), ")")); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(t_p0) ? ({
        auto&& c_p8 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a0;
        auto&& ps_p9 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a1;
        auto&& res_pa = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a2;
        ({
        auto c_p8x = c_p8;
        auto ps_p9x = ps_p9;
        auto res_pax = prism_rtl::deref(prism_rtl::deref(res_pa));
        (crate::prelude::call_value(crate::prelude::each_job(ps_p9x, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::types::Ty)>>(prism_rtl::rc([&](crate::check::types::Ty a0) { return crate::prelude::entered(start_ty_sexp_f(a0)); }))), [=, c_p8x = std::move(c_p8x), res_pax = std::move(res_pax)](Array<Text> each_1040) { return crate::prelude::call_then(start_ty_sexp_f(res_pax), [=](Text ty_sexp_f_1065) { return prism_rtl::finished(prism_rtl::cat("(fn ", col_sexp_f(c_p8x), " (", crate::syntax::lexer::chars::join_f(each_1040, Text::lit(" ")), ") ", ty_sexp_f_1065, ")")); }); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p0) ? ({
        auto&& ts_pb = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p0).a0;
        ({
        auto ts_pbx = ts_pb;
        (crate::prelude::call_value(crate::prelude::each_job(ts_pbx, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto a_pc = p0;
                (crate::prelude::call_then(start_ty_sexp_f(a_pc), [=](Text ty_sexp_f_1128) { return prism_rtl::finished(prism_rtl::cat(" ", ty_sexp_f_1128)); }));
            });
        }));
    }))), [=](Array<Text> each_1111) { return prism_rtl::finished(prism_rtl::cat("(tuple", crate::prelude::concat(each_1111), ")")); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t_p0) ? ({
        auto&& e_pd = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p0).a0;
        ({
        auto e_pdx = prism_rtl::deref(prism_rtl::deref(e_pd));
        (crate::prelude::call_then(start_ty_sexp_f(e_pdx), [=](Text ty_sexp_f_1167) { return prism_rtl::finished(prism_rtl::cat("(array ", ty_sexp_f_1167, ")")); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t_p0) ? ({
        auto&& k_pe = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a0;
        auto&& v_pf = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a1;
        ({
        auto k_pex = prism_rtl::deref(prism_rtl::deref(k_pe));
        auto v_pfx = prism_rtl::deref(prism_rtl::deref(v_pf));
        (crate::prelude::call_then(start_ty_sexp_f(k_pex), [=, v_pfx = std::move(v_pfx)](Text ty_sexp_f_1202) { return crate::prelude::call_then(start_ty_sexp_f(v_pfx), [=](Text ty_sexp_f_1213) { return prism_rtl::finished(prism_rtl::cat("(map ", ty_sexp_f_1202, " ", ty_sexp_f_1213, ")")); }); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t_p0) ? ({
        auto&& s_pg = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a0;
        auto&& i_ph = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        ({
        auto i_phx = prism_rtl::deref(prism_rtl::deref(i_ph));
        auto s_pgx = s_pg;
        (crate::prelude::call_then(start_ty_sexp_f(i_phx), [=, s_pgx = std::move(s_pgx)](Text ty_sexp_f_1248) { return prism_rtl::finished(prism_rtl::cat("(", s_pgx, " ", ty_sexp_f_1248, ")")); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyAt>(t_p0) ? ({
        auto&& i_pi = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p0).a0;
        auto&& rw_pj = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p0).a1;
        ({
        auto i_pix = prism_rtl::deref(prism_rtl::deref(i_pi));
        auto rw_pjx = rw_pj;
        (crate::prelude::call_then(start_ty_sexp_f(i_pix), [=, rw_pjx = std::move(rw_pjx)](Text ty_sexp_f_1281) { return prism_rtl::finished(prism_rtl::cat("(@ ", ty_sexp_f_1281, " ", row_sexp_f(rw_pjx), ")")); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyElem>(t_p0) ? ({
        auto&& rw_pk = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p0).a0;
        auto&& o_pl = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p0).a1;
        ({
        auto o_plx = prism_rtl::deref(prism_rtl::deref(o_pl));
        auto rw_pkx = rw_pk;
        (crate::prelude::call_then(start_ty_sexp_f(o_plx), [=, rw_pkx = std::move(rw_pkx)](Text ty_sexp_f_1348) { return prism_rtl::finished(prism_rtl::cat("(element ", row_sexp_f(rw_pkx), " ", ty_sexp_f_1348, ")")); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyElemAny>(t_p0) ? ({
        auto&& rw_pm = prism_rtl::as<crate::check::types::Ty::TyElemAny>(t_p0).a0;
        prism_rtl::finished(prism_rtl::cat("(elem ", row_sexp_f(rw_pm), ")"));
    })
        : prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p0) ? ({
        auto&& n_pn = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p0).a0;
        auto&& a_po = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p0).a1;
        ({
        auto a_pox = prism_rtl::deref(prism_rtl::deref(a_po));
        auto n_pnx = n_pn;
        (crate::prelude::call_then(start_ty_sexp_f(a_pox), [=, n_pnx = std::move(n_pnx)](Text ty_sexp_f_1431) { return prism_rtl::finished(prism_rtl::cat("(assoc ", n_pnx, " ", ty_sexp_f_1431, ")")); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyAny>(t_p0) ? ({
        auto&& trs_pp = prism_rtl::as<crate::check::types::Ty::TyAny>(t_p0).a0;
        prism_rtl::finished(prism_rtl::cat("(any", crate::prelude::concat(crate::prelude::each(trs_pp, [&](const Text& x_pq) { return prism_rtl::cat(" ^", x_pq); })), ")"));
    })
        : prism_rtl::is<crate::check::types::Ty::TyErr>(t_p0) ? prism_rtl::finished(Text::lit("unknown"))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TySexp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_ty_sexp_f(crate::check::types::Ty t_p0) {
    return prism_rtl::make_rc<TySexp>(t_p0);
}


/// ColSexp: fn Col -> Text
Text col_sexp_f(const crate::check::types::Col& col0) {
    if (prism_rtl::is<crate::check::types::Col::CBound>(col0)) {
        return Text::lit("bounded");
    }
    if (prism_rtl::is<crate::check::types::Col::CUnbound>(col0)) {
        return Text::lit("unbounded");
    }
    if (prism_rtl::is<crate::check::types::Col::CRigid>(col0)) {
        auto&& n_p0 = prism_rtl::as<crate::check::types::Col::CRigid>(col0).a0;
        return prism_rtl::cat("(color ", n_p0, ")");
    }
    if (prism_rtl::is<crate::check::types::Col::CQ>(col0)) {
        auto&& n_p1 = prism_rtl::as<crate::check::types::Col::CQ>(col0).a0;
        return prism_rtl::cat("(color ", n_p1, ")");
    }
    if (prism_rtl::is<crate::check::types::Col::CFlex>(col0)) {
        auto&& n_p2 = prism_rtl::as<crate::check::types::Col::CFlex>(col0).a0;
        return prism_rtl::cat("(color c", n_p2, ")");
    }
    prism_rtl::unreachable("no arm matched");
}


/// RowSexp: fn Rw -> Text
Text row_sexp_f(const crate::check::types::Rw& rw_p0) {
    auto tail_p1 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = rw_p0.tail_p;
        if (prism_rtl::is<crate::check::types::Tail::TlClosed>(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Tail::TlFlex>(_m)) {
            auto&& n_p3 = prism_rtl::as<crate::check::types::Tail::TlFlex>(_m).a0;
            _v.set(prism_rtl::cat(" (tail r", n_p3, ")"));
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Tail::TlRigid>(_m)) {
            auto&& n_p4 = prism_rtl::as<crate::check::types::Tail::TlRigid>(_m).a0;
            _v.set(prism_rtl::cat(" (tail ", n_p4, ")"));
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Tail::TlQ>(_m)) {
            auto&& n_p5 = prism_rtl::as<crate::check::types::Tail::TlQ>(_m).a0;
            _v.set(prism_rtl::cat(" (tail ", n_p5, ")"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto minus_p2 = crate::prelude::len(rw_p0.minus_p) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" (minus", crate::prelude::concat(crate::prelude::each(rw_p0.minus_p, [&](const Text& m_p6) { return prism_rtl::cat(" ", m_p6); })), ")");
    return prism_rtl::cat("(row", crate::prelude::concat(crate::prelude::each(rw_p0.fams_p, [&](const Text& f_p7) { return prism_rtl::cat(" ", f_p7, ".*"); })), tail_p1, minus_p2, ")");
}


/// SchemeSexp: unbounded fn Scheme -> Text
Text scheme_sexp_f(const crate::check::types::Scheme& sc_p0) {
    auto qs_p1 = crate::prelude::len(sc_p0.qs_p) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" (forall", crate::prelude::concat(crate::prelude::each(sc_p0.qs_p, [&](const Text& q_p5) { return prism_rtl::cat(" ", q_p5); })), ")");
    auto rqs_p2 = crate::prelude::len(sc_p0.rqs_p) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" (rows", crate::prelude::concat(crate::prelude::each(sc_p0.rqs_p, [&](const Text& q_p6) { return prism_rtl::cat(" ", q_p6); })), ")");
    auto cqs_p3 = crate::prelude::len(sc_p0.cqs_p) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" (colors", crate::prelude::concat(crate::prelude::each(sc_p0.cqs_p, [&](const Text& q_p7) { return prism_rtl::cat(" ", q_p7); })), ")");
    auto bs_p4 = crate::prelude::len(sc_p0.bounds_p) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" (where", crate::prelude::concat(crate::prelude::each(sc_p0.bounds_p, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_p8 = std::get<0>(_p0);
        auto&& c_p9 = std::get<1>(_p0);
        return prism_rtl::cat(" ", v_p8, ":^", c_p9);
    })), ")");
    return prism_rtl::cat("(scheme", qs_p1, rqs_p2, cqs_p3, bs_p4, " ", ty_sexp_f(sc_p0.ty_p), ")");
}


prism_rtl::Turn<Text> SchemeSexp::cycle() const {
    const auto& sc_p0 = this->sc_p0;
    auto qs_p1 = crate::prelude::len(prism_rtl::deref(sc_p0).qs_p) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" (forall", crate::prelude::concat(crate::prelude::each(prism_rtl::deref(sc_p0).qs_p, [&](const Text& q_p5) { return prism_rtl::cat(" ", q_p5); })), ")");
    auto rqs_p2 = crate::prelude::len(prism_rtl::deref(sc_p0).rqs_p) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" (rows", crate::prelude::concat(crate::prelude::each(prism_rtl::deref(sc_p0).rqs_p, [&](const Text& q_p6) { return prism_rtl::cat(" ", q_p6); })), ")");
    auto cqs_p3 = crate::prelude::len(prism_rtl::deref(sc_p0).cqs_p) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" (colors", crate::prelude::concat(crate::prelude::each(prism_rtl::deref(sc_p0).cqs_p, [&](const Text& q_p7) { return prism_rtl::cat(" ", q_p7); })), ")");
    auto bs_p4 = crate::prelude::len(prism_rtl::deref(sc_p0).bounds_p) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" (where", crate::prelude::concat(crate::prelude::each(prism_rtl::deref(sc_p0).bounds_p, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_p8 = std::get<0>(_p0);
        auto&& c_p9 = std::get<1>(_p0);
        return prism_rtl::cat(" ", v_p8, ":^", c_p9);
    })), ")");
    auto sc_p0x = sc_p0;
    return crate::prelude::call_then(start_ty_sexp_f(prism_rtl::deref(sc_p0x).ty_p), [=](Text ty_sexp_f_2534) { return prism_rtl::finished(prism_rtl::cat("(scheme", qs_p1, rqs_p2, cqs_p3, bs_p4, " ", ty_sexp_f_2534, ")")); });
}


/// `Start SchemeSexp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_scheme_sexp_f(crate::check::types::Scheme sc_p0) {
    return prism_rtl::make_rc<SchemeSexp>(sc_p0);
}


/// AtText: fn [Src], SrcAt -> Text
Text at_text_f(const Array<crate::check::errors::Src>& srcs_p0, const crate::check::typed::SrcAt& a_p1) {
    auto&& _m = crate::prelude::index(srcs_p0, a_p1.file_p);
    if (prism_rtl::is_none(_m)) {
        return prism_rtl::cat("?:", prism_rtl::deref(a_p1.span_p).start_p);
    }
    if (prism_rtl::is_some(_m)) {
        auto&& src_p2 = prism_rtl::some_of(_m);
        return prism_rtl::cat(prism_rtl::deref(crate::check::errors::seg_at_f(src_p2, prism_rtl::deref(a_p1.span_p).start_p)).path_p, ":", pos_text_f(src_p2, prism_rtl::deref(a_p1.span_p).start_p), "-", pos_text_f(src_p2, prism_rtl::deref(a_p1.span_p).end_p));
    }
    prism_rtl::unreachable("no arm matched");
}


/// PosText: fn Src, Nat -> Text
Text pos_text_f(const crate::check::errors::Src& src_p0, const Nat& offset_p1) {
    auto line_p2 = crate::check::errors::cline_of_f(src_p0.starts_p, offset_p1);
    auto col_p3 = crate::syntax::lexer::chars::column_of_f(src_p0.text_p, crate::prelude::or_(crate::prelude::index(src_p0.starts_p, line_p2), Nat(0u)), offset_p1);
    return prism_rtl::cat(crate::prelude::or_(line_p2.checked_sub(prism_rtl::deref(crate::check::errors::seg_at_f(src_p0, offset_p1)).line_p), Nat(0u)) + Nat(1u), ":", col_p3 + Nat(1u));
}


/// TypedSexp: unbounded fn [Src], [Module], Nat, TProgram -> Text
Text typed_sexp_f(const Array<crate::check::errors::Src>& srcs_p0, const Array<crate::syntax::Module>& trees_p1, const Nat& shown_p2, const crate::check::typed::TProgram& tp_p3) {
    auto tys_p4 = crate::prelude::fold(tp_p3.exprs_p, Map<Text, crate::check::types::Ty>{}, [&](const Map<Text, crate::check::types::Ty>& m_pk, const crate::check::typed::TyNote& n_pl) { return crate::prelude::insert(m_pk, crate::check::typed::at_key_f(prism_rtl::deref(n_pl).at_p), prism_rtl::deref(n_pl).ty_p); });
    auto files_p5 = crate::prelude::filter(crate::check::errors::range0_f(crate::prelude::len(trees_p1)), [&](const Nat& i_pm) { return i_pm < shown_p2; });
    auto defs_p6 = crate::prelude::concat(crate::prelude::run_to_end(crate::prelude::each_job(crate::prelude::filter(tp_p3.defs_p, [&](const crate::check::typed::DefNote& d_pn) { return prism_rtl::deref(prism_rtl::deref(d_pn).at_p).file_p < shown_p2; }), ({
        auto srcs_p0x = srcs_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::typed::DefNote)>>(prism_rtl::rc([=, srcs_p0x = std::move(srcs_p0x)](crate::check::typed::DefNote p0) {
        return ({
            auto srcs_p0xy = srcs_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, srcs_p0xy = std::move(srcs_p0xy)]() {
            return ({
                auto d_po = p0;
                (crate::prelude::call_then(start_scheme_sexp_f(prism_rtl::deref(d_po).scheme_p), [=](Text scheme_sexp_f_3620) { return prism_rtl::finished(prism_rtl::cat("  (def ", prism_rtl::deref(d_po).name_p, " ", at_text_f(srcs_p0xy, prism_rtl::deref(d_po).at_p), " ", scheme_sexp_f_3620, ")\n")); }));
            });
        })));
        });
    })));
    }))));
    auto exprs_p7 = crate::prelude::concat(crate::prelude::run_to_end(crate::prelude::each_job(files_p5, ({
        auto srcs_p0x = srcs_p0;
        auto tys_p4x = tys_p4;
        auto trees_p1x = trees_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=, srcs_p0x = std::move(srcs_p0x), tys_p4x = std::move(tys_p4x), trees_p1x = std::move(trees_p1x)](Nat p0) {
        return ({
            auto srcs_p0xy = srcs_p0x;
            auto tys_p4xy = tys_p4x;
            auto trees_p1xy = trees_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, srcs_p0xy = std::move(srcs_p0xy), tys_p4xy = std::move(tys_p4xy), trees_p1xy = std::move(trees_p1xy)]() {
            return ({
                auto i_pp = p0;
                (prism_rtl::more(prism_rtl::rc(ExprsOfFile(srcs_p0xy, tys_p4xy, i_pp, crate::prelude::or_(crate::prelude::index(trees_p1xy, i_pp), empty_mod_p())))));
            });
        })));
        });
    })));
    }))));
    auto mine_f8 = ({
        auto shown_p2x = shown_p2;
        static_cast<Fn<bool(const crate::check::typed::SrcAt&)>>(prism_rtl::rc([=, shown_p2x = std::move(shown_p2x)](const crate::check::typed::SrcAt& a_pq) { return shown_f(a_pq, shown_p2x); }));
    });
    auto apps_p9 = crate::prelude::concat(crate::prelude::each(crate::prelude::filter(tp_p3.apps_p, [&](const crate::check::typed::AppNote& x_pr) { return mine_f8(prism_rtl::deref(x_pr).at_p); }), [&](const crate::check::typed::AppNote& x_ps) { return prism_rtl::cat("  (app ", at_text_f(srcs_p0, prism_rtl::deref(x_ps).at_p), " ", quote_f(prism_rtl::deref(x_ps).callee_p), " ", prism_rtl::deref(x_ps).kind_p, " ", layer_word_f(prism_rtl::deref(x_ps).layer_p), " (lifted", crate::prelude::concat(crate::prelude::each(prism_rtl::deref(x_ps).lifted_p, [&](const Nat& i_pt) { return prism_rtl::cat(" ", i_pt); })), ") ", layer_word_f(prism_rtl::deref(x_ps).inner_p), " ", col_sexp_f(prism_rtl::deref(x_ps).color_p), ")\n"); }));
    auto lifts_pa = crate::prelude::concat(crate::prelude::each(crate::prelude::filter(tp_p3.lifts_p, [&](const crate::check::typed::LiftNote& x_pu) { return mine_f8(prism_rtl::deref(x_pu).at_p); }), [&](const crate::check::typed::LiftNote& x_pv) { return prism_rtl::cat("  (lift ", at_text_f(srcs_p0, prism_rtl::deref(x_pv).at_p), " ", prism_rtl::deref(x_pv).sigil_p, crate::prelude::concat(crate::prelude::each(prism_rtl::deref(x_pv).operands_p, [&](const crate::syntax::Range& r_p10) { return prism_rtl::cat(" ", at_text_f(srcs_p0, crate::check::typed::SrcAt{.file_p = prism_rtl::deref(prism_rtl::deref(x_pv).at_p).file_p, .span_p = r_p10})); })), ")\n"); }));
    auto fns_pb = crate::prelude::concat(crate::prelude::each(crate::prelude::filter(tp_p3.fns_p, [&](const crate::check::typed::FnNote& x_p11) { return mine_f8(prism_rtl::deref(x_p11).at_p); }), [&](const crate::check::typed::FnNote& x_p12) { return prism_rtl::cat("  (fn ", quote_f(prism_rtl::deref(x_p12).name_p), " ", at_text_f(srcs_p0, prism_rtl::deref(x_p12).at_p), " ", col_sexp_f(prism_rtl::deref(x_p12).declared_p), " ", col_sexp_f(prism_rtl::deref(x_p12).body_p), ")\n"); }));
    auto methods_pc = crate::prelude::concat(crate::prelude::each(crate::prelude::filter(tp_p3.methods_p, [&](const crate::check::typed::MethodNote& x_p13) { return mine_f8(prism_rtl::deref(x_p13).at_p); }), [&](const crate::check::typed::MethodNote& x_p14) { return prism_rtl::cat("  (method ", at_text_f(srcs_p0, prism_rtl::deref(x_p14).at_p), " ", prism_rtl::deref(x_p14).method_p, " ^", prism_rtl::deref(x_p14).cls_p, ")\n"); }));
    auto impls_pd = crate::prelude::concat(crate::prelude::run_to_end(crate::prelude::each_job(crate::prelude::filter(tp_p3.impls_p, [&](const crate::check::typed::ImplNote& x_p15) { return mine_f8(prism_rtl::deref(x_p15).at_p); }), ({
        auto srcs_p0x = srcs_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::typed::ImplNote)>>(prism_rtl::rc([=, srcs_p0x = std::move(srcs_p0x)](crate::check::typed::ImplNote p0) {
        return ({
            auto srcs_p0xy = srcs_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, srcs_p0xy = std::move(srcs_p0xy)]() {
            return ({
                auto x_p16 = p0;
                (crate::prelude::call_then(start_ty_sexp_f(prism_rtl::deref(x_p16).ty_p), [=](Text ty_sexp_f_4583) { return prism_rtl::finished(prism_rtl::cat("  (impl ", at_text_f(srcs_p0xy, prism_rtl::deref(x_p16).at_p), " ^", prism_rtl::deref(x_p16).cls_p, " ", ty_sexp_f_4583, " ", prism_rtl::deref(x_p16).how_p, ")\n")); }));
            });
        })));
        });
    })));
    }))));
    auto groups_pe = crate::prelude::concat(crate::prelude::each(crate::prelude::filter(tp_p3.groups_p, [&](const crate::check::typed::GroupNote& x_p17) { return mine_f8(prism_rtl::deref(x_p17).at_p); }), [&](const crate::check::typed::GroupNote& x_p18) { return prism_rtl::cat("  (group ", prism_rtl::deref(x_p18).kind_p, " ", at_text_f(srcs_p0, prism_rtl::deref(x_p18).at_p), crate::prelude::concat(crate::prelude::each(prism_rtl::deref(x_p18).order_p, [&](const Array<Nat>& c_p19) { return prism_rtl::cat(" (", crate::syntax::lexer::chars::join_f(crate::prelude::each(c_p19, [&](const Nat& i_p1a) { return prism_rtl::cat(i_p1a); }), Text::lit(" ")), ")"); })), ")\n"); }));
    auto binders_pf = crate::prelude::concat(crate::prelude::run_to_end(crate::prelude::each_job(crate::prelude::filter(tp_p3.binders_p, [&](const crate::check::typed::BinderNote& x_p1b) { return mine_f8(prism_rtl::deref(x_p1b).at_p); }), ({
        auto srcs_p0x = srcs_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::typed::BinderNote)>>(prism_rtl::rc([=, srcs_p0x = std::move(srcs_p0x)](crate::check::typed::BinderNote p0) {
        return ({
            auto srcs_p0xy = srcs_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, srcs_p0xy = std::move(srcs_p0xy)]() {
            return ({
                auto x_p1c = p0;
                (crate::prelude::call_then(start_ty_sexp_f(prism_rtl::deref(x_p1c).ty_p), [=](Text ty_sexp_f_4911) { return prism_rtl::finished(prism_rtl::cat("  (binder ", quote_f(prism_rtl::deref(x_p1c).name_p), " ", at_text_f(srcs_p0xy, prism_rtl::deref(x_p1c).at_p), " ", ty_sexp_f_4911, ")\n")); }));
            });
        })));
        });
    })));
    }))));
    auto locals_pg = crate::prelude::concat(crate::prelude::each(crate::prelude::filter(tp_p3.locals_p, [&](const crate::check::typed::LocalNote& x_p1d) { return mine_f8(prism_rtl::deref(x_p1d).at_p); }), [&](const crate::check::typed::LocalNote& x_p1e) { return prism_rtl::cat("  (local ", prism_rtl::deref(x_p1e).id_p, " ", at_text_f(srcs_p0, prism_rtl::deref(x_p1e).at_p), ")\n"); }));
    auto uses_ph = crate::prelude::concat(crate::prelude::each(crate::prelude::filter(tp_p3.uses_p, [&](const crate::check::typed::LocalNote& x_p1f) { return mine_f8(prism_rtl::deref(x_p1f).at_p); }), [&](const crate::check::typed::LocalNote& x_p1g) { return prism_rtl::cat("  (use ", prism_rtl::deref(x_p1g).id_p, " ", at_text_f(srcs_p0, prism_rtl::deref(x_p1g).at_p), ")\n"); }));
    auto gens_pi = crate::prelude::concat(crate::prelude::each(crate::prelude::filter(tp_p3.gens_p, [&](const crate::check::typed::GenNote& x_p1h) { return mine_f8(prism_rtl::deref(x_p1h).at_p); }), [&](const crate::check::typed::GenNote& x_p1i) { return prism_rtl::cat("  (gen ", quote_f(prism_rtl::deref(x_p1i).name_p), " ", at_text_f(srcs_p0, prism_rtl::deref(x_p1i).at_p), crate::prelude::concat(crate::prelude::each(prism_rtl::deref(x_p1i).tys_p, [&](const Text& q_p1j) { return prism_rtl::cat(" ", q_p1j); })), crate::prelude::concat(crate::prelude::each(prism_rtl::deref(x_p1i).cols_p, [&](const Text& q_p1k) { return prism_rtl::cat(" ", q_p1k); })), ")\n"); }));
    auto insts_pj = crate::prelude::concat(crate::prelude::run_to_end(crate::prelude::each_job(crate::prelude::filter(tp_p3.insts_p, [&](const crate::check::typed::InstNote& x_p1l) { return mine_f8(prism_rtl::deref(x_p1l).at_p); }), ({
        auto srcs_p0x = srcs_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::typed::InstNote)>>(prism_rtl::rc([=, srcs_p0x = std::move(srcs_p0x)](crate::check::typed::InstNote p0) {
        return ({
            auto srcs_p0xy = srcs_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, srcs_p0xy = std::move(srcs_p0xy)]() {
            return ({
                auto x_p1m = p0;
                (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(x_p1m).tys_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Text, crate::check::types::Ty> p0) {
                return crate::prelude::entered(crate::prelude::once_job([=]() {
                    return ({
                        auto [q_p1n, t_p1o] = p0;
                        (crate::prelude::call_then(start_ty_sexp_f(t_p1o), [=](Text ty_sexp_f_5486) { return prism_rtl::finished(prism_rtl::cat(" (", q_p1n, " ", ty_sexp_f_5486, ")")); }));
                    });
                }));
            }))), [=](Array<Text> each_5454) {
                return prism_rtl::finished(prism_rtl::cat("  (inst ", quote_f(prism_rtl::deref(x_p1m).name_p), " ", at_text_f(srcs_p0xy, prism_rtl::deref(x_p1m).at_p), crate::prelude::concat(each_5454), crate::prelude::concat(crate::prelude::each(prism_rtl::deref(x_p1m).cols_p, [&](const std::tuple<Text, crate::check::types::Col>& _p0) {
                    auto&& q_p1p = std::get<0>(_p0);
                    auto&& c_p1q = std::get<1>(_p0);
                    return prism_rtl::cat(" (", q_p1p, " ", col_sexp_f(c_p1q), ")");
                })), ")\n"));
            }));
            });
        })));
        });
    })));
    }))));
    return prism_rtl::cat("(typed\n (defs\n", defs_p6, " )\n (exprs\n", exprs_p7, " )\n (apps\n", apps_p9, " )\n (lifts\n", lifts_pa, " )\n (fns\n", fns_pb, " )\n (methods\n", methods_pc, " )\n (impls\n", impls_pd, " )\n (groups\n", groups_pe, " )\n (binders\n", binders_pf, " )\n (locals\n", locals_pg, " )\n (uses\n", uses_ph, " )\n (gens\n", gens_pi, " )\n (insts\n", insts_pj, " ))\n");
}


prism_rtl::Turn<Text> TypedSexp::cycle() const {
    const auto& srcs_p0 = this->srcs_p0;
    const auto& trees_p1 = this->trees_p1;
    const auto& shown_p2 = this->shown_p2;
    const auto& tp_p3 = this->tp_p3;
    auto tys_p4 = crate::prelude::fold(prism_rtl::deref(tp_p3).exprs_p, Map<Text, crate::check::types::Ty>{}, [&](const Map<Text, crate::check::types::Ty>& m_pk, const crate::check::typed::TyNote& n_pl) { return crate::prelude::insert(m_pk, crate::check::typed::at_key_f(prism_rtl::deref(n_pl).at_p), prism_rtl::deref(n_pl).ty_p); });
    auto files_p5 = crate::prelude::filter(crate::check::errors::range0_f(crate::prelude::len(trees_p1)), [&](const Nat& i_pm) { return i_pm < shown_p2; });
    auto shown_p2x = shown_p2;
    auto srcs_p0x = srcs_p0;
    auto tp_p3x = tp_p3;
    auto trees_p1x = trees_p1;
    return crate::prelude::call_value(crate::prelude::each_job(crate::prelude::filter(prism_rtl::deref(tp_p3x).defs_p, [&](const crate::check::typed::DefNote& d_pn) { return prism_rtl::deref(prism_rtl::deref(d_pn).at_p).file_p < shown_p2x; }), ({
        auto srcs_p0xx = srcs_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::typed::DefNote)>>(prism_rtl::rc([=, srcs_p0xx = std::move(srcs_p0xx)](crate::check::typed::DefNote p0) {
        return ({
            auto srcs_p0xxy = srcs_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, srcs_p0xxy = std::move(srcs_p0xxy)]() {
            return ({
                auto d_po = p0;
                (crate::prelude::call_then(start_scheme_sexp_f(prism_rtl::deref(d_po).scheme_p), [=](Text scheme_sexp_f_3620) { return prism_rtl::finished(prism_rtl::cat("  (def ", prism_rtl::deref(d_po).name_p, " ", at_text_f(srcs_p0xxy, prism_rtl::deref(d_po).at_p), " ", scheme_sexp_f_3620, ")\n")); }));
            });
        })));
        });
    })));
    })), [=](Array<Text> each_3530) {
        return ({
            auto defs_p6 = crate::prelude::concat(each_3530);
            (crate::prelude::call_value(crate::prelude::each_job(files_p5, ({
            auto srcs_p0xx = srcs_p0x;
            auto tys_p4x = tys_p4;
            auto trees_p1xx = trees_p1x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=, srcs_p0xx = std::move(srcs_p0xx), tys_p4x = std::move(tys_p4x), trees_p1xx = std::move(trees_p1xx)](Nat p0) {
            return ({
                auto srcs_p0xxy = srcs_p0xx;
                auto tys_p4xy = tys_p4x;
                auto trees_p1xxy = trees_p1xx;
                (crate::prelude::entered(crate::prelude::once_job([=, srcs_p0xxy = std::move(srcs_p0xxy), tys_p4xy = std::move(tys_p4xy), trees_p1xxy = std::move(trees_p1xxy)]() {
                return ({
                    auto i_pp = p0;
                    (prism_rtl::more(prism_rtl::rc(ExprsOfFile(srcs_p0xxy, tys_p4xy, i_pp, crate::prelude::or_(crate::prelude::index(trees_p1xxy, i_pp), empty_mod_p())))));
                });
            })));
            });
        })));
        })), [=, defs_p6 = std::move(defs_p6)](Array<Text> each_3670) {
            return ({
                auto exprs_p7 = crate::prelude::concat(each_3670);
                auto mine_f8 = ({
                    auto shown_p2xx = shown_p2x;
                    static_cast<Fn<bool(const crate::check::typed::SrcAt&)>>(prism_rtl::rc([=, shown_p2xx = std::move(shown_p2xx)](const crate::check::typed::SrcAt& a_pq) { return shown_f(a_pq, shown_p2xx); }));
                });
                auto apps_p9 = crate::prelude::concat(crate::prelude::each(crate::prelude::filter(prism_rtl::deref(tp_p3x).apps_p, [&](const crate::check::typed::AppNote& x_pr) { return mine_f8(prism_rtl::deref(x_pr).at_p); }), [&](const crate::check::typed::AppNote& x_ps) { return prism_rtl::cat("  (app ", at_text_f(srcs_p0x, prism_rtl::deref(x_ps).at_p), " ", quote_f(prism_rtl::deref(x_ps).callee_p), " ", prism_rtl::deref(x_ps).kind_p, " ", layer_word_f(prism_rtl::deref(x_ps).layer_p), " (lifted", crate::prelude::concat(crate::prelude::each(prism_rtl::deref(x_ps).lifted_p, [&](const Nat& i_pt) { return prism_rtl::cat(" ", i_pt); })), ") ", layer_word_f(prism_rtl::deref(x_ps).inner_p), " ", col_sexp_f(prism_rtl::deref(x_ps).color_p), ")\n"); }));
                auto lifts_pa = crate::prelude::concat(crate::prelude::each(crate::prelude::filter(prism_rtl::deref(tp_p3x).lifts_p, [&](const crate::check::typed::LiftNote& x_pu) { return mine_f8(prism_rtl::deref(x_pu).at_p); }), [&](const crate::check::typed::LiftNote& x_pv) { return prism_rtl::cat("  (lift ", at_text_f(srcs_p0x, prism_rtl::deref(x_pv).at_p), " ", prism_rtl::deref(x_pv).sigil_p, crate::prelude::concat(crate::prelude::each(prism_rtl::deref(x_pv).operands_p, [&](const crate::syntax::Range& r_p10) { return prism_rtl::cat(" ", at_text_f(srcs_p0x, crate::check::typed::SrcAt{.file_p = prism_rtl::deref(prism_rtl::deref(x_pv).at_p).file_p, .span_p = r_p10})); })), ")\n"); }));
                auto fns_pb = crate::prelude::concat(crate::prelude::each(crate::prelude::filter(prism_rtl::deref(tp_p3x).fns_p, [&](const crate::check::typed::FnNote& x_p11) { return mine_f8(prism_rtl::deref(x_p11).at_p); }), [&](const crate::check::typed::FnNote& x_p12) { return prism_rtl::cat("  (fn ", quote_f(prism_rtl::deref(x_p12).name_p), " ", at_text_f(srcs_p0x, prism_rtl::deref(x_p12).at_p), " ", col_sexp_f(prism_rtl::deref(x_p12).declared_p), " ", col_sexp_f(prism_rtl::deref(x_p12).body_p), ")\n"); }));
                auto methods_pc = crate::prelude::concat(crate::prelude::each(crate::prelude::filter(prism_rtl::deref(tp_p3x).methods_p, [&](const crate::check::typed::MethodNote& x_p13) { return mine_f8(prism_rtl::deref(x_p13).at_p); }), [&](const crate::check::typed::MethodNote& x_p14) { return prism_rtl::cat("  (method ", at_text_f(srcs_p0x, prism_rtl::deref(x_p14).at_p), " ", prism_rtl::deref(x_p14).method_p, " ^", prism_rtl::deref(x_p14).cls_p, ")\n"); }));
                (crate::prelude::call_value(crate::prelude::each_job(crate::prelude::filter(prism_rtl::deref(tp_p3x).impls_p, [&](const crate::check::typed::ImplNote& x_p15) { return mine_f8(prism_rtl::deref(x_p15).at_p); }), ({
                auto srcs_p0xx = srcs_p0x;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::typed::ImplNote)>>(prism_rtl::rc([=, srcs_p0xx = std::move(srcs_p0xx)](crate::check::typed::ImplNote p0) {
                return ({
                    auto srcs_p0xxy = srcs_p0xx;
                    (crate::prelude::entered(crate::prelude::once_job([=, srcs_p0xxy = std::move(srcs_p0xxy)]() {
                    return ({
                        auto x_p16 = p0;
                        (crate::prelude::call_then(start_ty_sexp_f(prism_rtl::deref(x_p16).ty_p), [=](Text ty_sexp_f_4583) { return prism_rtl::finished(prism_rtl::cat("  (impl ", at_text_f(srcs_p0xxy, prism_rtl::deref(x_p16).at_p), " ^", prism_rtl::deref(x_p16).cls_p, " ", ty_sexp_f_4583, " ", prism_rtl::deref(x_p16).how_p, ")\n")); }));
                    });
                })));
                });
            })));
            })), [=, exprs_p7 = std::move(exprs_p7), apps_p9 = std::move(apps_p9), lifts_pa = std::move(lifts_pa), fns_pb = std::move(fns_pb), methods_pc = std::move(methods_pc)](Array<Text> each_4499) {
                return ({
                    auto impls_pd = crate::prelude::concat(each_4499);
                    auto groups_pe = crate::prelude::concat(crate::prelude::each(crate::prelude::filter(prism_rtl::deref(tp_p3x).groups_p, [&](const crate::check::typed::GroupNote& x_p17) { return mine_f8(prism_rtl::deref(x_p17).at_p); }), [&](const crate::check::typed::GroupNote& x_p18) { return prism_rtl::cat("  (group ", prism_rtl::deref(x_p18).kind_p, " ", at_text_f(srcs_p0x, prism_rtl::deref(x_p18).at_p), crate::prelude::concat(crate::prelude::each(prism_rtl::deref(x_p18).order_p, [&](const Array<Nat>& c_p19) { return prism_rtl::cat(" (", crate::syntax::lexer::chars::join_f(crate::prelude::each(c_p19, [&](const Nat& i_p1a) { return prism_rtl::cat(i_p1a); }), Text::lit(" ")), ")"); })), ")\n"); }));
                    (crate::prelude::call_value(crate::prelude::each_job(crate::prelude::filter(prism_rtl::deref(tp_p3x).binders_p, [&](const crate::check::typed::BinderNote& x_p1b) { return mine_f8(prism_rtl::deref(x_p1b).at_p); }), ({
                    auto srcs_p0xx = srcs_p0x;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::typed::BinderNote)>>(prism_rtl::rc([=, srcs_p0xx = std::move(srcs_p0xx)](crate::check::typed::BinderNote p0) {
                    return ({
                        auto srcs_p0xxy = srcs_p0xx;
                        (crate::prelude::entered(crate::prelude::once_job([=, srcs_p0xxy = std::move(srcs_p0xxy)]() {
                        return ({
                            auto x_p1c = p0;
                            (crate::prelude::call_then(start_ty_sexp_f(prism_rtl::deref(x_p1c).ty_p), [=](Text ty_sexp_f_4911) { return prism_rtl::finished(prism_rtl::cat("  (binder ", quote_f(prism_rtl::deref(x_p1c).name_p), " ", at_text_f(srcs_p0xxy, prism_rtl::deref(x_p1c).at_p), " ", ty_sexp_f_4911, ")\n")); }));
                        });
                    })));
                    });
                })));
                })), [=, impls_pd = std::move(impls_pd), groups_pe = std::move(groups_pe)](Array<Text> each_4817) {
                    return ({
                        auto binders_pf = crate::prelude::concat(each_4817);
                        auto locals_pg = crate::prelude::concat(crate::prelude::each(crate::prelude::filter(prism_rtl::deref(tp_p3x).locals_p, [&](const crate::check::typed::LocalNote& x_p1d) { return mine_f8(prism_rtl::deref(x_p1d).at_p); }), [&](const crate::check::typed::LocalNote& x_p1e) { return prism_rtl::cat("  (local ", prism_rtl::deref(x_p1e).id_p, " ", at_text_f(srcs_p0x, prism_rtl::deref(x_p1e).at_p), ")\n"); }));
                        auto uses_ph = crate::prelude::concat(crate::prelude::each(crate::prelude::filter(prism_rtl::deref(tp_p3x).uses_p, [&](const crate::check::typed::LocalNote& x_p1f) { return mine_f8(prism_rtl::deref(x_p1f).at_p); }), [&](const crate::check::typed::LocalNote& x_p1g) { return prism_rtl::cat("  (use ", prism_rtl::deref(x_p1g).id_p, " ", at_text_f(srcs_p0x, prism_rtl::deref(x_p1g).at_p), ")\n"); }));
                        auto gens_pi = crate::prelude::concat(crate::prelude::each(crate::prelude::filter(prism_rtl::deref(tp_p3x).gens_p, [&](const crate::check::typed::GenNote& x_p1h) { return mine_f8(prism_rtl::deref(x_p1h).at_p); }), [&](const crate::check::typed::GenNote& x_p1i) { return prism_rtl::cat("  (gen ", quote_f(prism_rtl::deref(x_p1i).name_p), " ", at_text_f(srcs_p0x, prism_rtl::deref(x_p1i).at_p), crate::prelude::concat(crate::prelude::each(prism_rtl::deref(x_p1i).tys_p, [&](const Text& q_p1j) { return prism_rtl::cat(" ", q_p1j); })), crate::prelude::concat(crate::prelude::each(prism_rtl::deref(x_p1i).cols_p, [&](const Text& q_p1k) { return prism_rtl::cat(" ", q_p1k); })), ")\n"); }));
                        (crate::prelude::call_value(crate::prelude::each_job(crate::prelude::filter(prism_rtl::deref(tp_p3x).insts_p, [&](const crate::check::typed::InstNote& x_p1l) { return mine_f8(prism_rtl::deref(x_p1l).at_p); }), ({
                        auto srcs_p0xx = srcs_p0x;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::typed::InstNote)>>(prism_rtl::rc([=, srcs_p0xx = std::move(srcs_p0xx)](crate::check::typed::InstNote p0) {
                        return ({
                            auto srcs_p0xxy = srcs_p0xx;
                            (crate::prelude::entered(crate::prelude::once_job([=, srcs_p0xxy = std::move(srcs_p0xxy)]() {
                            return ({
                                auto x_p1m = p0;
                                (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(x_p1m).tys_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Text, crate::check::types::Ty> p0) {
                                return crate::prelude::entered(crate::prelude::once_job([=]() {
                                    return ({
                                        auto [q_p1n, t_p1o] = p0;
                                        (crate::prelude::call_then(start_ty_sexp_f(t_p1o), [=](Text ty_sexp_f_5486) { return prism_rtl::finished(prism_rtl::cat(" (", q_p1n, " ", ty_sexp_f_5486, ")")); }));
                                    });
                                }));
                            }))), [=](Array<Text> each_5454) {
                                return prism_rtl::finished(prism_rtl::cat("  (inst ", quote_f(prism_rtl::deref(x_p1m).name_p), " ", at_text_f(srcs_p0xxy, prism_rtl::deref(x_p1m).at_p), crate::prelude::concat(each_5454), crate::prelude::concat(crate::prelude::each(prism_rtl::deref(x_p1m).cols_p, [&](const std::tuple<Text, crate::check::types::Col>& _p0) {
                                    auto&& q_p1p = std::get<0>(_p0);
                                    auto&& c_p1q = std::get<1>(_p0);
                                    return prism_rtl::cat(" (", q_p1p, " ", col_sexp_f(c_p1q), ")");
                                })), ")\n"));
                            }));
                            });
                        })));
                        });
                    })));
                    })), [=, binders_pf = std::move(binders_pf), locals_pg = std::move(locals_pg), uses_ph = std::move(uses_ph), gens_pi = std::move(gens_pi)](Array<Text> each_5357) {
                        return ({
                            auto insts_pj = crate::prelude::concat(each_5357);
                            (prism_rtl::finished(prism_rtl::cat("(typed\n (defs\n", defs_p6, " )\n (exprs\n", exprs_p7, " )\n (apps\n", apps_p9, " )\n (lifts\n", lifts_pa, " )\n (fns\n", fns_pb, " )\n (methods\n", methods_pc, " )\n (impls\n", impls_pd, " )\n (groups\n", groups_pe, " )\n (binders\n", binders_pf, " )\n (locals\n", locals_pg, " )\n (uses\n", uses_ph, " )\n (gens\n", gens_pi, " )\n (insts\n", insts_pj, " ))\n")));
                        });
                    }));
                    });
                }));
                });
            }));
            });
        }));
        });
    });
}


/// `Start TypedSexp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_typed_sexp_f(Array<crate::check::errors::Src> srcs_p0, Array<crate::syntax::Module> trees_p1, Nat shown_p2, crate::check::typed::TProgram tp_p3) {
    return prism_rtl::make_rc<TypedSexp>(srcs_p0, trees_p1, shown_p2, tp_p3);
}


/// Shown: fn SrcAt, Nat -> Bool
bool shown_f(const crate::check::typed::SrcAt& a_p0, const Nat& shown_p1) {
    return a_p0.file_p < shown_p1;
}


/// let emptyMod
crate::syntax::Module empty_mod_p() {
    return crate::syntax::Module{.name_o = std::optional<crate::syntax::QualName>{}, .emit_row_o = std::optional<crate::syntax::Row_>{}, .mods_p = Array<crate::syntax::ModLine>{}, .uses_p = Array<crate::syntax::Use>{}, .decls_p = Array<crate::syntax::decls::Decl>{}, .template_o = std::optional<crate::syntax::Template>{}, .span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}};
}


/// Quote: fn Text -> Text
Text quote_f(const Text& t_p0) {
    return prism_rtl::cat("\"", t_p0, "\"");
}


/// LayerWord: fn Text -> Text
Text layer_word_f(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("")) {
            return Text::lit("-");
        }
    }
    {
        auto&& s_p0 = text0;
        return s_p0;
    }
}


/// ExprsOfFile: unbounded fn [Src], (Text ==> Ty), Nat, Module -> Text
Text exprs_of_file_f(const Array<crate::check::errors::Src>& srcs_p0, const Map<Text, crate::check::types::Ty>& tys_p1, const Nat& file_p2, const crate::syntax::Module& m_p3) {
    auto es_p4 = crate::prelude::run_to_end(crate::prelude::fold_job(m_p3.decls_p, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::Decl>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::Decl> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_p5 = p0;
                auto d_p6 = p1;
                (crate::prelude::call_then(start_decl_exprs_f(d_p6), [=, acc_p5 = std::move(acc_p5)](Array<crate::syntax::Expr> decl_exprs_f_6366) { return prism_rtl::finished(crate::prelude::append(acc_p5, decl_exprs_f_6366)); }));
            });
        }));
    }))));
    return crate::prelude::concat(crate::prelude::run_to_end(crate::prelude::each_job(es_p4, ({
        auto srcs_p0x = srcs_p0;
        auto tys_p1x = tys_p1;
        auto file_p2x = file_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::syntax::Expr)>>(prism_rtl::rc([=, srcs_p0x = std::move(srcs_p0x), tys_p1x = std::move(tys_p1x), file_p2x = std::move(file_p2x)](crate::syntax::Expr p0) {
        return ({
            auto srcs_p0xy = srcs_p0x;
            auto tys_p1xy = tys_p1x;
            auto file_p2xy = file_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, srcs_p0xy = std::move(srcs_p0xy), tys_p1xy = std::move(tys_p1xy), file_p2xy = std::move(file_p2xy)]() {
            return ({
                auto e_p7 = p0;
                (prism_rtl::more(prism_rtl::rc(ExprLine(srcs_p0xy, tys_p1xy, crate::check::typed::SrcAt{.file_p = file_p2xy, .span_p = prism_rtl::deref(e_p7).span_p}))));
            });
        })));
        });
    })));
    }))));
}


prism_rtl::Turn<Text> ExprsOfFile::cycle() const {
    const auto& srcs_p0 = this->srcs_p0;
    const auto& tys_p1 = this->tys_p1;
    const auto& file_p2 = this->file_p2;
    const auto& m_p3 = this->m_p3;
    auto file_p2x = file_p2;
    auto m_p3x = m_p3;
    auto srcs_p0x = srcs_p0;
    auto tys_p1x = tys_p1;
    return crate::prelude::call_value(crate::prelude::fold_job(prism_rtl::deref(m_p3x).decls_p, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::Decl>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::Decl> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_p5 = p0;
                auto d_p6 = p1;
                (crate::prelude::call_then(start_decl_exprs_f(d_p6), [=, acc_p5 = std::move(acc_p5)](Array<crate::syntax::Expr> decl_exprs_f_6366) { return prism_rtl::finished(crate::prelude::append(acc_p5, decl_exprs_f_6366)); }));
            });
        }));
    }))), [=](Array<crate::syntax::Expr> fold_6323) {
        return ({
            auto es_p4 = fold_6323;
            (crate::prelude::call_value(crate::prelude::each_job(es_p4, ({
            auto srcs_p0xx = srcs_p0x;
            auto tys_p1xx = tys_p1x;
            auto file_p2xx = file_p2x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::syntax::Expr)>>(prism_rtl::rc([=, srcs_p0xx = std::move(srcs_p0xx), tys_p1xx = std::move(tys_p1xx), file_p2xx = std::move(file_p2xx)](crate::syntax::Expr p0) {
            return ({
                auto srcs_p0xxy = srcs_p0xx;
                auto tys_p1xxy = tys_p1xx;
                auto file_p2xxy = file_p2xx;
                (crate::prelude::entered(crate::prelude::once_job([=, srcs_p0xxy = std::move(srcs_p0xxy), tys_p1xxy = std::move(tys_p1xxy), file_p2xxy = std::move(file_p2xxy)]() {
                return ({
                    auto e_p7 = p0;
                    (prism_rtl::more(prism_rtl::rc(ExprLine(srcs_p0xxy, tys_p1xxy, crate::check::typed::SrcAt{.file_p = file_p2xxy, .span_p = prism_rtl::deref(e_p7).span_p}))));
                });
            })));
            });
        })));
        })), [=](Array<Text> each_6391) { return prism_rtl::finished(crate::prelude::concat(each_6391)); }));
        });
    });
}


/// `Start ExprsOfFile, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_exprs_of_file_f(Array<crate::check::errors::Src> srcs_p0, Map<Text, crate::check::types::Ty> tys_p1, Nat file_p2, crate::syntax::Module m_p3) {
    return prism_rtl::make_rc<ExprsOfFile>(srcs_p0, tys_p1, file_p2, m_p3);
}


/// ExprLine: unbounded fn [Src], (Text ==> Ty), SrcAt -> Text
Text expr_line_f(const Array<crate::check::errors::Src>& srcs_p0, const Map<Text, crate::check::types::Ty>& tys_p1, const crate::check::typed::SrcAt& a_p2) {
    return prism_rtl::cat("  (expr ", at_text_f(srcs_p0, a_p2), " ", ty_sexp_f(crate::prelude::or_(crate::prelude::get(tys_p1, crate::check::typed::at_key_f(a_p2)), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), ")\n");
}


prism_rtl::Turn<Text> ExprLine::cycle() const {
    const auto& srcs_p0 = this->srcs_p0;
    const auto& tys_p1 = this->tys_p1;
    const auto& a_p2 = this->a_p2;
    auto a_p2x = a_p2;
    auto srcs_p0x = srcs_p0;
    auto tys_p1x = tys_p1;
    return crate::prelude::call_then(start_ty_sexp_f(crate::prelude::or_(crate::prelude::get(tys_p1x, crate::check::typed::at_key_f(a_p2x)), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](Text ty_sexp_f_6570) { return prism_rtl::finished(prism_rtl::cat("  (expr ", at_text_f(srcs_p0x, a_p2x), " ", ty_sexp_f_6570, ")\n")); });
}


/// `Start ExprLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_expr_line_f(Array<crate::check::errors::Src> srcs_p0, Map<Text, crate::check::types::Ty> tys_p1, crate::check::typed::SrcAt a_p2) {
    return prism_rtl::make_rc<ExprLine>(srcs_p0, tys_p1, a_p2);
}


/// DeclExprs: unbounded fn Decl -> [Expr]
Array<crate::syntax::Expr> decl_exprs_f(const crate::syntax::decls::Decl& d_p0) {
    auto&& _m = d_p0.kind_p;
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DFn>(_m)) {
        auto&& f_p1 = prism_rtl::as<crate::syntax::decls::DeclKind::DFn>(_m).a0;
        return body_exprs_f(prism_rtl::deref(f_p1).body_p);
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DLet>(_m)) {
        auto&& l_p2 = prism_rtl::as<crate::syntax::decls::DeclKind::DLet>(_m).a0;
        return exprs_in_f(prism_rtl::deref(l_p2).value_p);
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DWidget>(_m)) {
        auto&& w_p3 = prism_rtl::as<crate::syntax::decls::DeclKind::DWidget>(_m).a0;
        return stmts_exprs_f(prism_rtl::deref(prism_rtl::deref(w_p3).body_p).stmts_p);
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DTrait>(_m)) {
        auto&& t_p4 = prism_rtl::as<crate::syntax::decls::DeclKind::DTrait>(_m).a0;
        return crate::prelude::run_to_end(crate::prelude::fold_job(prism_rtl::deref(t_p4).items_p, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_p5 = p0;
                    auto it_p6 = p1;
                    ({
                    prism_rtl::is<crate::syntax::decls::TraitItem::TiFn>(it_p6) ? ({
                    auto&& f_p7 = prism_rtl::as<crate::syntax::decls::TraitItem::TiFn>(it_p6).a0;
                    ({
                    auto f_p7x = f_p7;
                    (crate::prelude::call_then(start_body_exprs_f(prism_rtl::deref(f_p7x).body_p), [=](Array<crate::syntax::Expr> body_exprs_f_6857) { return prism_rtl::finished(crate::prelude::append(acc_p5, body_exprs_f_6857)); }));
                });
                })
                    : prism_rtl::finished(acc_p5);
                });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DImpl>(_m)) {
        auto&& i_p8 = prism_rtl::as<crate::syntax::decls::DeclKind::DImpl>(_m).a0;
        return crate::prelude::run_to_end(crate::prelude::fold_job(prism_rtl::deref(i_p8).items_p, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_p9 = p0;
                    auto it_pa = p1;
                    ({
                    prism_rtl::is<crate::syntax::decls::TraitItem::TiFn>(it_pa) ? ({
                    auto&& f_pb = prism_rtl::as<crate::syntax::decls::TraitItem::TiFn>(it_pa).a0;
                    ({
                    auto f_pbx = f_pb;
                    (crate::prelude::call_then(start_body_exprs_f(prism_rtl::deref(f_pbx).body_p), [=](Array<crate::syntax::Expr> body_exprs_f_6981) { return prism_rtl::finished(crate::prelude::append(acc_p9, body_exprs_f_6981)); }));
                });
                })
                    : prism_rtl::finished(acc_p9);
                });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DCheck>(_m)) {
        auto&& c_pc = prism_rtl::as<crate::syntax::decls::DeclKind::DCheck>(_m).a0;
        return crate::prelude::run_to_end(crate::prelude::fold_job(prism_rtl::deref(c_pc).lines_p, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::CheckLine>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::CheckLine> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_pd = p0;
                    auto l_pe = p1;
                    (crate::prelude::call_then(start_exprs_in_f(prism_rtl::deref(l_pe).expr_p), [=, acc_pd = std::move(acc_pd)](Array<crate::syntax::Expr> exprs_in_f_7079) { return prism_rtl::finished(crate::prelude::append(acc_pd, exprs_in_f_7079)); }));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DTest>(_m)) {
        auto&& t_pf = prism_rtl::as<crate::syntax::decls::DeclKind::DTest>(_m).a0;
        return exprs_in_f(prism_rtl::deref(t_pf).blueprint_p);
    }
    {
        return Array<crate::syntax::Expr>{};
    }
}


prism_rtl::Turn<Array<crate::syntax::Expr>> DeclExprs::cycle() const {
    const auto& d_p0 = this->d_p0;
    return ({
        auto&& _m = prism_rtl::deref(d_p0).kind_p;
        prism_rtl::is<crate::syntax::decls::DeclKind::DFn>(_m) ? ({
        auto&& f_p1 = prism_rtl::as<crate::syntax::decls::DeclKind::DFn>(_m).a0;
        prism_rtl::more(prism_rtl::rc(BodyExprs(prism_rtl::deref(f_p1).body_p)));
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DLet>(_m) ? ({
        auto&& l_p2 = prism_rtl::as<crate::syntax::decls::DeclKind::DLet>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ExprsIn(prism_rtl::deref(l_p2).value_p)));
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DWidget>(_m) ? ({
        auto&& w_p3 = prism_rtl::as<crate::syntax::decls::DeclKind::DWidget>(_m).a0;
        prism_rtl::more(prism_rtl::rc(StmtsExprs(prism_rtl::deref(prism_rtl::deref(w_p3).body_p).stmts_p)));
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DTrait>(_m) ? ({
        auto&& t_p4 = prism_rtl::as<crate::syntax::decls::DeclKind::DTrait>(_m).a0;
        crate::prelude::fold_job(prism_rtl::deref(t_p4).items_p, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_p5 = p0;
                auto it_p6 = p1;
                ({
                prism_rtl::is<crate::syntax::decls::TraitItem::TiFn>(it_p6) ? ({
                auto&& f_p7 = prism_rtl::as<crate::syntax::decls::TraitItem::TiFn>(it_p6).a0;
                ({
                auto f_p7x = f_p7;
                (crate::prelude::call_then(start_body_exprs_f(prism_rtl::deref(f_p7x).body_p), [=](Array<crate::syntax::Expr> body_exprs_f_6857) { return prism_rtl::finished(crate::prelude::append(acc_p5, body_exprs_f_6857)); }));
            });
            })
                : prism_rtl::finished(acc_p5);
            });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DImpl>(_m) ? ({
        auto&& i_p8 = prism_rtl::as<crate::syntax::decls::DeclKind::DImpl>(_m).a0;
        crate::prelude::fold_job(prism_rtl::deref(i_p8).items_p, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_p9 = p0;
                auto it_pa = p1;
                ({
                prism_rtl::is<crate::syntax::decls::TraitItem::TiFn>(it_pa) ? ({
                auto&& f_pb = prism_rtl::as<crate::syntax::decls::TraitItem::TiFn>(it_pa).a0;
                ({
                auto f_pbx = f_pb;
                (crate::prelude::call_then(start_body_exprs_f(prism_rtl::deref(f_pbx).body_p), [=](Array<crate::syntax::Expr> body_exprs_f_6981) { return prism_rtl::finished(crate::prelude::append(acc_p9, body_exprs_f_6981)); }));
            });
            })
                : prism_rtl::finished(acc_p9);
            });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DCheck>(_m) ? ({
        auto&& c_pc = prism_rtl::as<crate::syntax::decls::DeclKind::DCheck>(_m).a0;
        crate::prelude::fold_job(prism_rtl::deref(c_pc).lines_p, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::CheckLine>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::CheckLine> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_pd = p0;
                auto l_pe = p1;
                (crate::prelude::call_then(start_exprs_in_f(prism_rtl::deref(l_pe).expr_p), [=, acc_pd = std::move(acc_pd)](Array<crate::syntax::Expr> exprs_in_f_7079) { return prism_rtl::finished(crate::prelude::append(acc_pd, exprs_in_f_7079)); }));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DTest>(_m) ? ({
        auto&& t_pf = prism_rtl::as<crate::syntax::decls::DeclKind::DTest>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ExprsIn(prism_rtl::deref(t_pf).blueprint_p)));
    })
        : prism_rtl::finished(Array<crate::syntax::Expr>{});
    });
}


/// `Start DeclExprs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::syntax::Expr>> start_decl_exprs_f(crate::syntax::decls::Decl d_p0) {
    return prism_rtl::make_rc<DeclExprs>(d_p0);
}


/// BodyExprs: unbounded fn FnBody -> [Expr]
Array<crate::syntax::Expr> body_exprs_f(const crate::syntax::decls::FnBody& fn_body0) {
    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(fn_body0)) {
        auto&& e_p0 = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(fn_body0).a0;
        return exprs_in_f(e_p0);
    }
    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(fn_body0)) {
        auto&& b_p1 = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(fn_body0).a0;
        return stmts_exprs_f(prism_rtl::deref(b_p1).stmts_p);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<crate::syntax::Expr>> BodyExprs::cycle() const {
    const auto& fn_body0 = this->fn_body0;
    return ({
        prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(fn_body0) ? ({
        auto&& e_p0 = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(fn_body0).a0;
        prism_rtl::more(prism_rtl::rc(ExprsIn(e_p0)));
    })
        : prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(fn_body0) ? ({
        auto&& b_p1 = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(fn_body0).a0;
        prism_rtl::more(prism_rtl::rc(StmtsExprs(prism_rtl::deref(b_p1).stmts_p)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start BodyExprs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::syntax::Expr>> start_body_exprs_f(crate::syntax::decls::FnBody fn_body0) {
    return prism_rtl::make_rc<BodyExprs>(fn_body0);
}


/// StmtsExprs: unbounded fn [Stmt] -> [Expr]
Array<crate::syntax::Expr> stmts_exprs_f(const Array<crate::syntax::Stmt>& stmts_p0) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(stmts_p0, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_p1 = p0;
                auto s_p2 = p1;
                (crate::prelude::call_then(start_stmt_exprs_f(s_p2), [=, acc_p1 = std::move(acc_p1)](Array<crate::syntax::Expr> stmt_exprs_f_7382) { return prism_rtl::finished(crate::prelude::append(acc_p1, stmt_exprs_f_7382)); }));
            });
        }));
    }))));
}


prism_rtl::Turn<Array<crate::syntax::Expr>> StmtsExprs::cycle() const {
    const auto& stmts_p0 = this->stmts_p0;
    return crate::prelude::fold_job(stmts_p0, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_p1 = p0;
                auto s_p2 = p1;
                (crate::prelude::call_then(start_stmt_exprs_f(s_p2), [=, acc_p1 = std::move(acc_p1)](Array<crate::syntax::Expr> stmt_exprs_f_7382) { return prism_rtl::finished(crate::prelude::append(acc_p1, stmt_exprs_f_7382)); }));
            });
        }));
    })))->cycle();
}


/// `Start StmtsExprs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::syntax::Expr>> start_stmts_exprs_f(Array<crate::syntax::Stmt> stmts_p0) {
    return prism_rtl::make_rc<StmtsExprs>(stmts_p0);
}


/// StmtExprs: unbounded fn Stmt -> [Expr]
Array<crate::syntax::Expr> stmt_exprs_f(const crate::syntax::Stmt& s_p0) {
    auto&& _m = s_p0.kind_p;
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m)) {
        auto&& e_p1 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        auto&& t_o2 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2;
        if (prism_rtl::is_some(t_o2)) {
            auto&& x_p3 = prism_rtl::some_of(t_o2);
            return crate::prelude::append(exprs_in_f(e_p1), exprs_in_f(x_p3));
        }
        if (prism_rtl::is_none(t_o2)) {
            return exprs_in_f(e_p1);
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SIgnore>(_m)) {
        auto&& e_p4 = prism_rtl::as<crate::syntax::StmtKind::SIgnore>(_m).a0;
        return exprs_in_f(e_p4);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& e_p5 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        return exprs_in_f(e_p5);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        auto&& f_p6 = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        return body_exprs_f(prism_rtl::deref(f_p6).body_p);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m)) {
        auto&& w_p7 = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
        return stmts_exprs_f(prism_rtl::deref(prism_rtl::deref(w_p7).body_p).stmts_p);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SSet>(_m)) {
        auto&& t_p8 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
        auto&& v_p9 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
        return crate::prelude::append(exprs_in_f(t_p8), exprs_in_f(v_p9));
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m)) {
        auto&& t_pa = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
        auto&& v_pb = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a2;
        return crate::prelude::append(exprs_in_f(t_pa), exprs_in_f(v_pb));
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SRequire>(_m)) {
        auto&& c_pc = prism_rtl::as<crate::syntax::StmtKind::SRequire>(_m).a0;
        return exprs_in_f(c_pc);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SForbid>(_m)) {
        auto&& c_pd = prism_rtl::as<crate::syntax::StmtKind::SForbid>(_m).a0;
        return exprs_in_f(c_pd);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m)) {
        auto&& c_pe = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
        auto&& b_pf = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
        return crate::prelude::append(cond_exprs_f(c_pe), stmts_exprs_f(prism_rtl::deref(b_pf).stmts_p));
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SReturn>(_m)) {
        auto&& e_pg = prism_rtl::as<crate::syntax::StmtKind::SReturn>(_m).a0;
        return exprs_in_f(e_pg);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
        auto&& e_ph = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        return exprs_in_f(e_ph);
    }
    {
        return Array<crate::syntax::Expr>{};
    }
}


prism_rtl::Turn<Array<crate::syntax::Expr>> StmtExprs::cycle() const {
    const auto& s_p0 = this->s_p0;
    return ({
        auto&& _m = prism_rtl::deref(s_p0).kind_p;
        prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) ? ({
        auto&& e_p1 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        auto&& t_o2 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2;
        ({
        prism_rtl::is_some(t_o2) ? ({
        auto&& x_p3 = prism_rtl::some_of(t_o2);
        ({
        auto e_p1x = e_p1;
        auto x_p3x = x_p3;
        (crate::prelude::call_then(start_exprs_in_f(e_p1x), [=, x_p3x = std::move(x_p3x)](Array<crate::syntax::Expr> exprs_in_f_7522) { return crate::prelude::call_then(start_exprs_in_f(x_p3x), [=](Array<crate::syntax::Expr> exprs_in_f_7535) { return prism_rtl::finished(crate::prelude::append(exprs_in_f_7522, exprs_in_f_7535)); }); }));
    });
    })
        : prism_rtl::is_none(t_o2) ? prism_rtl::more(prism_rtl::rc(ExprsIn(e_p1)))
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SIgnore>(_m) ? ({
        auto&& e_p4 = prism_rtl::as<crate::syntax::StmtKind::SIgnore>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ExprsIn(e_p4)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& e_p5 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        prism_rtl::more(prism_rtl::rc(ExprsIn(e_p5)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? ({
        auto&& f_p6 = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        prism_rtl::more(prism_rtl::rc(BodyExprs(prism_rtl::deref(f_p6).body_p)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m) ? ({
        auto&& w_p7 = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
        prism_rtl::more(prism_rtl::rc(StmtsExprs(prism_rtl::deref(prism_rtl::deref(w_p7).body_p).stmts_p)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SSet>(_m) ? ({
        auto&& t_p8 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
        auto&& v_p9 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
        ({
        auto t_p8x = t_p8;
        auto v_p9x = v_p9;
        (crate::prelude::call_then(start_exprs_in_f(t_p8x), [=, v_p9x = std::move(v_p9x)](Array<crate::syntax::Expr> exprs_in_f_7722) { return crate::prelude::call_then(start_exprs_in_f(v_p9x), [=](Array<crate::syntax::Expr> exprs_in_f_7735) { return prism_rtl::finished(crate::prelude::append(exprs_in_f_7722, exprs_in_f_7735)); }); }));
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m) ? ({
        auto&& t_pa = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
        auto&& v_pb = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a2;
        ({
        auto t_pax = t_pa;
        auto v_pbx = v_pb;
        (crate::prelude::call_then(start_exprs_in_f(t_pax), [=, v_pbx = std::move(v_pbx)](Array<crate::syntax::Expr> exprs_in_f_7779) { return crate::prelude::call_then(start_exprs_in_f(v_pbx), [=](Array<crate::syntax::Expr> exprs_in_f_7792) { return prism_rtl::finished(crate::prelude::append(exprs_in_f_7779, exprs_in_f_7792)); }); }));
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SRequire>(_m) ? ({
        auto&& c_pc = prism_rtl::as<crate::syntax::StmtKind::SRequire>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ExprsIn(c_pc)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SForbid>(_m) ? ({
        auto&& c_pd = prism_rtl::as<crate::syntax::StmtKind::SForbid>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ExprsIn(c_pd)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m) ? ({
        auto&& c_pe = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
        auto&& b_pf = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
        ({
        auto b_pfx = b_pf;
        auto c_pex = c_pe;
        (crate::prelude::call_then(start_cond_exprs_f(c_pex), [=, b_pfx = std::move(b_pfx)](Array<crate::syntax::Expr> cond_exprs_f_7879) { return crate::prelude::call_then(start_stmts_exprs_f(prism_rtl::deref(b_pfx).stmts_p), [=](Array<crate::syntax::Expr> stmts_exprs_f_7894) { return prism_rtl::finished(crate::prelude::append(cond_exprs_f_7879, stmts_exprs_f_7894)); }); }));
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SReturn>(_m) ? ({
        auto&& e_pg = prism_rtl::as<crate::syntax::StmtKind::SReturn>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ExprsIn(e_pg)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
        auto&& e_ph = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ExprsIn(e_ph)));
    })
        : prism_rtl::finished(Array<crate::syntax::Expr>{});
    });
}


/// `Start StmtExprs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::syntax::Expr>> start_stmt_exprs_f(crate::syntax::Stmt s_p0) {
    return prism_rtl::make_rc<StmtExprs>(s_p0);
}


/// CondExprs: unbounded fn Cond -> [Expr]
Array<crate::syntax::Expr> cond_exprs_f(const crate::syntax::Cond& cond0) {
    if (prism_rtl::is<crate::syntax::Cond::CondExpr>(cond0)) {
        auto&& e_p0 = prism_rtl::as<crate::syntax::Cond::CondExpr>(cond0).a0;
        return exprs_in_f(prism_rtl::deref(prism_rtl::deref(e_p0)));
    }
    if (prism_rtl::is<crate::syntax::Cond::CondBind>(cond0)) {
        auto&& e_p1 = prism_rtl::as<crate::syntax::Cond::CondBind>(cond0).a1;
        auto&& g_o2 = prism_rtl::as<crate::syntax::Cond::CondBind>(cond0).a2;
        return crate::prelude::append(exprs_in_f(prism_rtl::deref(prism_rtl::deref(e_p1))), opt_exprs_f(prism_rtl::deref(prism_rtl::deref(g_o2))));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<crate::syntax::Expr>> CondExprs::cycle() const {
    const auto& cond0 = this->cond0;
    return ({
        prism_rtl::is<crate::syntax::Cond::CondExpr>(cond0) ? ({
        auto&& e_p0 = prism_rtl::as<crate::syntax::Cond::CondExpr>(cond0).a0;
        prism_rtl::more(prism_rtl::rc(ExprsIn(prism_rtl::deref(prism_rtl::deref(e_p0)))));
    })
        : prism_rtl::is<crate::syntax::Cond::CondBind>(cond0) ? ({
        auto&& e_p1 = prism_rtl::as<crate::syntax::Cond::CondBind>(cond0).a1;
        auto&& g_o2 = prism_rtl::as<crate::syntax::Cond::CondBind>(cond0).a2;
        ({
        auto g_o2x = prism_rtl::deref(prism_rtl::deref(g_o2));
        auto e_p1x = prism_rtl::deref(prism_rtl::deref(e_p1));
        (crate::prelude::call_then(start_exprs_in_f(e_p1x), [=, g_o2x = std::move(g_o2x)](Array<crate::syntax::Expr> exprs_in_f_8108) { return crate::prelude::call_then(start_opt_exprs_f(g_o2x), [=](Array<crate::syntax::Expr> opt_exprs_f_8121) { return prism_rtl::finished(crate::prelude::append(exprs_in_f_8108, opt_exprs_f_8121)); }); }));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CondExprs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::syntax::Expr>> start_cond_exprs_f(crate::syntax::Cond cond0) {
    return prism_rtl::make_rc<CondExprs>(cond0);
}


/// ArgsExprs: unbounded fn [Arg] -> [Expr]
Array<crate::syntax::Expr> args_exprs_f(const Array<crate::syntax::Arg>& args_p0) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(args_p0, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::Arg>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::Arg> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_p1 = p0;
                auto a_p2 = p1;
                (crate::prelude::call_then(start_exprs_in_f(prism_rtl::deref(a_p2).value_p), [=, acc_p1 = std::move(acc_p1)](Array<crate::syntax::Expr> exprs_in_f_8235) { return prism_rtl::finished(crate::prelude::append(acc_p1, exprs_in_f_8235)); }));
            });
        }));
    }))));
}


prism_rtl::Turn<Array<crate::syntax::Expr>> ArgsExprs::cycle() const {
    const auto& args_p0 = this->args_p0;
    return crate::prelude::fold_job(args_p0, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::Arg>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::Arg> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_p1 = p0;
                auto a_p2 = p1;
                (crate::prelude::call_then(start_exprs_in_f(prism_rtl::deref(a_p2).value_p), [=, acc_p1 = std::move(acc_p1)](Array<crate::syntax::Expr> exprs_in_f_8235) { return prism_rtl::finished(crate::prelude::append(acc_p1, exprs_in_f_8235)); }));
            });
        }));
    })))->cycle();
}


/// `Start ArgsExprs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::syntax::Expr>> start_args_exprs_f(Array<crate::syntax::Arg> args_p0) {
    return prism_rtl::make_rc<ArgsExprs>(args_p0);
}


/// BlockExprs: unbounded fn Block -> [Expr]
Array<crate::syntax::Expr> block_exprs_f(const crate::syntax::Block& b_p0) {
    return stmts_exprs_f(b_p0.stmts_p);
}


prism_rtl::Turn<Array<crate::syntax::Expr>> BlockExprs::cycle() const {
    const auto& b_p0 = this->b_p0;
    return prism_rtl::more(prism_rtl::rc(StmtsExprs(prism_rtl::deref(b_p0).stmts_p)));
}


/// `Start BlockExprs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::syntax::Expr>> start_block_exprs_f(crate::syntax::Block b_p0) {
    return prism_rtl::make_rc<BlockExprs>(b_p0);
}


/// ExprsIn: unbounded fn Expr -> [Expr]
Array<crate::syntax::Expr> exprs_in_f(const crate::syntax::Expr& e_p0) {
    auto inner_p1 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
        auto&& _m = prism_rtl::deref(e_p0.kind_p);
        if (prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m)) {
            auto&& es_p2 = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
            _v.set(crate::prelude::run_to_end(crate::prelude::fold_job(es_p2, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::Expr> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return crate::prelude::entered(crate::prelude::once_job([=]() {
                    return ({
                        auto acc_p3 = p0;
                        auto x_p4 = p1;
                        (crate::prelude::call_then(start_exprs_in_f(x_p4), [=, acc_p3 = std::move(acc_p3)](Array<crate::syntax::Expr> exprs_in_f_8621) { return prism_rtl::finished(crate::prelude::append(acc_p3, exprs_in_f_8621)); }));
                    });
                }));
            })))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EArray>(_m)) {
            auto&& es_p5 = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
            _v.set(crate::prelude::run_to_end(crate::prelude::fold_job(es_p5, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::Expr> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return crate::prelude::entered(crate::prelude::once_job([=]() {
                    return ({
                        auto acc_p6 = p0;
                        auto x_p7 = p1;
                        (crate::prelude::call_then(start_exprs_in_f(x_p7), [=, acc_p6 = std::move(acc_p6)](Array<crate::syntax::Expr> exprs_in_f_8689) { return prism_rtl::finished(crate::prelude::append(acc_p6, exprs_in_f_8689)); }));
                    });
                }));
            })))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMap>(_m)) {
            auto&& kvs_p8 = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
            _v.set(crate::prelude::run_to_end(crate::prelude::fold_job(kvs_p8, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, std::tuple<crate::syntax::Expr, crate::syntax::Expr>>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, std::tuple<crate::syntax::Expr, crate::syntax::Expr>> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return crate::prelude::entered(crate::prelude::once_job([=]() {
                    return ({
                        auto acc_p9 = p0;
                        auto [k_pa, v_pb] = p1;
                        (crate::prelude::call_then(start_exprs_in_f(k_pa), [=, acc_p9 = std::move(acc_p9)](Array<crate::syntax::Expr> exprs_in_f_8772) { return crate::prelude::call_then(start_exprs_in_f(v_pb), [=](Array<crate::syntax::Expr> exprs_in_f_8786) { return prism_rtl::finished(crate::prelude::append(crate::prelude::append(acc_p9, exprs_in_f_8772), exprs_in_f_8786)); }); }));
                    });
                }));
            })))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
            auto&& x_pc = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
            _v.set(exprs_in_f(prism_rtl::deref(prism_rtl::deref(x_pc))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
            auto&& c_pd = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
            auto&& args_pe = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
            _v.set(crate::prelude::append(exprs_in_f(prism_rtl::deref(prism_rtl::deref(c_pd))), args_exprs_f(args_pe)));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
            auto&& l_pf = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
            auto&& r_pg = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
            _v.set(crate::prelude::append(exprs_in_f(prism_rtl::deref(prism_rtl::deref(l_pf))), exprs_in_f(prism_rtl::deref(prism_rtl::deref(r_pg)))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m)) {
            auto&& x_ph = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
            _v.set(exprs_in_f(prism_rtl::deref(prism_rtl::deref(x_ph))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
            auto&& x_pi = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
            _v.set(exprs_in_f(prism_rtl::deref(prism_rtl::deref(x_pi))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
            auto&& r_pj = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
            _v.set(exprs_in_f(prism_rtl::deref(prism_rtl::deref(r_pj))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
            auto&& r_pk = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
            auto&& i_pl = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
            _v.set(crate::prelude::append(exprs_in_f(prism_rtl::deref(prism_rtl::deref(r_pk))), exprs_in_f(prism_rtl::deref(prism_rtl::deref(i_pl)))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ETopicIndex>(_m)) {
            auto&& x_pm = prism_rtl::as<crate::syntax::ExprKind::ETopicIndex>(_m).a0;
            _v.set(exprs_in_f(prism_rtl::deref(prism_rtl::deref(x_pm))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m)) {
            auto&& r_pn = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
            auto&& args_po = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
            _v.set(crate::prelude::append(exprs_in_f(prism_rtl::deref(prism_rtl::deref(r_pn))), args_exprs_f(args_po)));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m)) {
            auto&& x_pp = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
            _v.set(exprs_in_f(prism_rtl::deref(prism_rtl::deref(x_pp))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ECast>(_m)) {
            auto&& x_pq = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a0;
            _v.set(exprs_in_f(prism_rtl::deref(prism_rtl::deref(x_pq))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
            auto&& body_pr = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
                auto&& _m = prism_rtl::deref(prism_rtl::deref(body_pr));
                if (prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(_m)) {
                    auto&& x_ps = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(_m).a0;
                    _v.set(exprs_in_f(prism_rtl::deref(prism_rtl::deref(x_ps))));
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(_m)) {
                    auto&& b_pt = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(_m).a0;
                    _v.set(block_exprs_f(b_pt));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
            auto&& c_pu = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
            auto&& t_pv = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
            auto&& el_o10 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
            _v.set(crate::prelude::append(crate::prelude::append(cond_exprs_f(prism_rtl::deref(prism_rtl::deref(c_pu))), block_exprs_f(t_pv)), opt_block_exprs_f(el_o10)));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
            auto&& s_p11 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
            auto&& arms_p12 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
            _v.set(crate::prelude::run_to_end(crate::prelude::fold_job(arms_p12, exprs_in_f(prism_rtl::deref(prism_rtl::deref(s_p11))), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::Arm> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return crate::prelude::entered(crate::prelude::once_job([=]() {
                    return ({
                        auto acc_p13 = p0;
                        auto a_p14 = p1;
                        (crate::prelude::call_then(start_opt_exprs_f(prism_rtl::deref(a_p14).guard_o), [=, acc_p13 = std::move(acc_p13)](Array<crate::syntax::Expr> opt_exprs_f_9600) { return crate::prelude::call_then(start_block_exprs_f(prism_rtl::deref(a_p14).body_p), [=](Array<crate::syntax::Expr> block_exprs_f_9622) { return prism_rtl::finished(crate::prelude::append(crate::prelude::append(acc_p13, opt_exprs_f_9600), block_exprs_f_9622)); }); }));
                    });
                }));
            })))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ERebuild>(_m)) {
            auto&& s_p15 = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a0;
            auto&& b_p16 = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a1;
            _v.set(crate::prelude::append(exprs_in_f(prism_rtl::deref(prism_rtl::deref(s_p15))), block_exprs_f(b_p16)));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EFor>(_m)) {
            auto&& s_p17 = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
            auto&& b_p18 = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
            _v.set(crate::prelude::append(exprs_in_f(prism_rtl::deref(prism_rtl::deref(s_p17))), block_exprs_f(b_p18)));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EGiven>(_m)) {
            auto&& b_p19 = prism_rtl::as<crate::syntax::ExprKind::EGiven>(_m).a0;
            _v.set(block_exprs_f(b_p19));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m)) {
            auto&& t_p1a = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
            auto&& b_p1b = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
            _v.set(crate::prelude::append(exprs_in_f(prism_rtl::deref(prism_rtl::deref(t_p1a))), block_exprs_f(b_p1b)));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m)) {
            auto&& b_p1c = prism_rtl::as<crate::syntax::ExprKind::EWidgetBlock>(_m).a0;
            _v.set(block_exprs_f(b_p1c));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EAny>(_m)) {
            auto&& x_p1d = prism_rtl::as<crate::syntax::ExprKind::EAny>(_m).a0;
            _v.set(exprs_in_f(prism_rtl::deref(prism_rtl::deref(x_p1d))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ELit>(_m)) {
            auto&& l_p1e = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
                auto&& _m = prism_rtl::deref(l_p1e).kind_p;
                if (prism_rtl::is<crate::syntax::LitKind::LText>(_m)) {
                    auto&& segs_p1f = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
                    _v.set(crate::prelude::run_to_end(crate::prelude::fold_job(segs_p1f, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::TextSeg>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::TextSeg> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return crate::prelude::entered(crate::prelude::once_job([=]() {
                            return ({
                                auto acc_p1g = p0;
                                auto sg_p1h = p1;
                                ({
                                prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(sg_p1h) ? ({
                                auto&& x_p1i = prism_rtl::as<crate::syntax::TextSeg::SegPlaceholder>(sg_p1h).a0;
                                ({
                                auto x_p1ix = x_p1i;
                                (crate::prelude::call_then(start_exprs_in_f(x_p1ix), [=](Array<crate::syntax::Expr> exprs_in_f_10051) { return prism_rtl::finished(crate::prelude::append(acc_p1g, exprs_in_f_10051)); }));
                            });
                            })
                                : prism_rtl::finished(acc_p1g);
                            });
                            });
                        }));
                    })))));
                    goto _done;
                }
                {
                    _v.set(Array<crate::syntax::Expr>{});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ETemplate>(_m)) {
            auto&& t_p1j = prism_rtl::as<crate::syntax::ExprKind::ETemplate>(_m).a0;
            _v.set(template_exprs_f(prism_rtl::deref(t_p1j).parts_p));
            goto _done;
        }
        {
            _v.set(Array<crate::syntax::Expr>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto&& _m = prism_rtl::deref(e_p0.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::ERest>(_m)) {
        return inner_p1;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EError>(_m)) {
        return inner_p1;
    }
    {
        return crate::prelude::append(Array(std::vector{e_p0}), inner_p1);
    }
}


prism_rtl::Turn<Array<crate::syntax::Expr>> ExprsIn::cycle() const {
    const auto& e_p0 = this->e_p0;
    auto inner_p1 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p0).kind_p);
        if (prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m)) {
            auto&& es_p2 = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
            _v.set(crate::prelude::run_to_end(crate::prelude::fold_job(es_p2, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::Expr> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return crate::prelude::entered(crate::prelude::once_job([=]() {
                    return ({
                        auto acc_p3 = p0;
                        auto x_p4 = p1;
                        (crate::prelude::call_then(start_exprs_in_f(x_p4), [=, acc_p3 = std::move(acc_p3)](Array<crate::syntax::Expr> exprs_in_f_8621) { return prism_rtl::finished(crate::prelude::append(acc_p3, exprs_in_f_8621)); }));
                    });
                }));
            })))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EArray>(_m)) {
            auto&& es_p5 = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
            _v.set(crate::prelude::run_to_end(crate::prelude::fold_job(es_p5, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::Expr> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return crate::prelude::entered(crate::prelude::once_job([=]() {
                    return ({
                        auto acc_p6 = p0;
                        auto x_p7 = p1;
                        (crate::prelude::call_then(start_exprs_in_f(x_p7), [=, acc_p6 = std::move(acc_p6)](Array<crate::syntax::Expr> exprs_in_f_8689) { return prism_rtl::finished(crate::prelude::append(acc_p6, exprs_in_f_8689)); }));
                    });
                }));
            })))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMap>(_m)) {
            auto&& kvs_p8 = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
            _v.set(crate::prelude::run_to_end(crate::prelude::fold_job(kvs_p8, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, std::tuple<crate::syntax::Expr, crate::syntax::Expr>>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, std::tuple<crate::syntax::Expr, crate::syntax::Expr>> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return crate::prelude::entered(crate::prelude::once_job([=]() {
                    return ({
                        auto acc_p9 = p0;
                        auto [k_pa, v_pb] = p1;
                        (crate::prelude::call_then(start_exprs_in_f(k_pa), [=, acc_p9 = std::move(acc_p9)](Array<crate::syntax::Expr> exprs_in_f_8772) { return crate::prelude::call_then(start_exprs_in_f(v_pb), [=](Array<crate::syntax::Expr> exprs_in_f_8786) { return prism_rtl::finished(crate::prelude::append(crate::prelude::append(acc_p9, exprs_in_f_8772), exprs_in_f_8786)); }); }));
                    });
                }));
            })))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
            auto&& x_pc = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
            _v.set(exprs_in_f(prism_rtl::deref(prism_rtl::deref(x_pc))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
            auto&& c_pd = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
            auto&& args_pe = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
            _v.set(crate::prelude::append(exprs_in_f(prism_rtl::deref(prism_rtl::deref(c_pd))), args_exprs_f(args_pe)));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
            auto&& l_pf = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
            auto&& r_pg = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
            _v.set(crate::prelude::append(exprs_in_f(prism_rtl::deref(prism_rtl::deref(l_pf))), exprs_in_f(prism_rtl::deref(prism_rtl::deref(r_pg)))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m)) {
            auto&& x_ph = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
            _v.set(exprs_in_f(prism_rtl::deref(prism_rtl::deref(x_ph))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
            auto&& x_pi = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
            _v.set(exprs_in_f(prism_rtl::deref(prism_rtl::deref(x_pi))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
            auto&& r_pj = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
            _v.set(exprs_in_f(prism_rtl::deref(prism_rtl::deref(r_pj))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
            auto&& r_pk = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
            auto&& i_pl = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
            _v.set(crate::prelude::append(exprs_in_f(prism_rtl::deref(prism_rtl::deref(r_pk))), exprs_in_f(prism_rtl::deref(prism_rtl::deref(i_pl)))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ETopicIndex>(_m)) {
            auto&& x_pm = prism_rtl::as<crate::syntax::ExprKind::ETopicIndex>(_m).a0;
            _v.set(exprs_in_f(prism_rtl::deref(prism_rtl::deref(x_pm))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m)) {
            auto&& r_pn = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
            auto&& args_po = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
            _v.set(crate::prelude::append(exprs_in_f(prism_rtl::deref(prism_rtl::deref(r_pn))), args_exprs_f(args_po)));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m)) {
            auto&& x_pp = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
            _v.set(exprs_in_f(prism_rtl::deref(prism_rtl::deref(x_pp))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ECast>(_m)) {
            auto&& x_pq = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a0;
            _v.set(exprs_in_f(prism_rtl::deref(prism_rtl::deref(x_pq))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
            auto&& body_pr = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
                auto&& _m = prism_rtl::deref(prism_rtl::deref(body_pr));
                if (prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(_m)) {
                    auto&& x_ps = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(_m).a0;
                    _v.set(exprs_in_f(prism_rtl::deref(prism_rtl::deref(x_ps))));
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(_m)) {
                    auto&& b_pt = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(_m).a0;
                    _v.set(block_exprs_f(b_pt));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
            auto&& c_pu = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
            auto&& t_pv = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
            auto&& el_o10 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
            _v.set(crate::prelude::append(crate::prelude::append(cond_exprs_f(prism_rtl::deref(prism_rtl::deref(c_pu))), block_exprs_f(t_pv)), opt_block_exprs_f(el_o10)));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
            auto&& s_p11 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
            auto&& arms_p12 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
            _v.set(crate::prelude::run_to_end(crate::prelude::fold_job(arms_p12, exprs_in_f(prism_rtl::deref(prism_rtl::deref(s_p11))), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::Arm> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return crate::prelude::entered(crate::prelude::once_job([=]() {
                    return ({
                        auto acc_p13 = p0;
                        auto a_p14 = p1;
                        (crate::prelude::call_then(start_opt_exprs_f(prism_rtl::deref(a_p14).guard_o), [=, acc_p13 = std::move(acc_p13)](Array<crate::syntax::Expr> opt_exprs_f_9600) { return crate::prelude::call_then(start_block_exprs_f(prism_rtl::deref(a_p14).body_p), [=](Array<crate::syntax::Expr> block_exprs_f_9622) { return prism_rtl::finished(crate::prelude::append(crate::prelude::append(acc_p13, opt_exprs_f_9600), block_exprs_f_9622)); }); }));
                    });
                }));
            })))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ERebuild>(_m)) {
            auto&& s_p15 = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a0;
            auto&& b_p16 = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a1;
            _v.set(crate::prelude::append(exprs_in_f(prism_rtl::deref(prism_rtl::deref(s_p15))), block_exprs_f(b_p16)));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EFor>(_m)) {
            auto&& s_p17 = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
            auto&& b_p18 = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
            _v.set(crate::prelude::append(exprs_in_f(prism_rtl::deref(prism_rtl::deref(s_p17))), block_exprs_f(b_p18)));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EGiven>(_m)) {
            auto&& b_p19 = prism_rtl::as<crate::syntax::ExprKind::EGiven>(_m).a0;
            _v.set(block_exprs_f(b_p19));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m)) {
            auto&& t_p1a = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
            auto&& b_p1b = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
            _v.set(crate::prelude::append(exprs_in_f(prism_rtl::deref(prism_rtl::deref(t_p1a))), block_exprs_f(b_p1b)));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m)) {
            auto&& b_p1c = prism_rtl::as<crate::syntax::ExprKind::EWidgetBlock>(_m).a0;
            _v.set(block_exprs_f(b_p1c));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EAny>(_m)) {
            auto&& x_p1d = prism_rtl::as<crate::syntax::ExprKind::EAny>(_m).a0;
            _v.set(exprs_in_f(prism_rtl::deref(prism_rtl::deref(x_p1d))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ELit>(_m)) {
            auto&& l_p1e = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
                auto&& _m = prism_rtl::deref(l_p1e).kind_p;
                if (prism_rtl::is<crate::syntax::LitKind::LText>(_m)) {
                    auto&& segs_p1f = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
                    _v.set(crate::prelude::run_to_end(crate::prelude::fold_job(segs_p1f, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::TextSeg>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::TextSeg> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return crate::prelude::entered(crate::prelude::once_job([=]() {
                            return ({
                                auto acc_p1g = p0;
                                auto sg_p1h = p1;
                                ({
                                prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(sg_p1h) ? ({
                                auto&& x_p1i = prism_rtl::as<crate::syntax::TextSeg::SegPlaceholder>(sg_p1h).a0;
                                ({
                                auto x_p1ix = x_p1i;
                                (crate::prelude::call_then(start_exprs_in_f(x_p1ix), [=](Array<crate::syntax::Expr> exprs_in_f_10051) { return prism_rtl::finished(crate::prelude::append(acc_p1g, exprs_in_f_10051)); }));
                            });
                            })
                                : prism_rtl::finished(acc_p1g);
                            });
                            });
                        }));
                    })))));
                    goto _done;
                }
                {
                    _v.set(Array<crate::syntax::Expr>{});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ETemplate>(_m)) {
            auto&& t_p1j = prism_rtl::as<crate::syntax::ExprKind::ETemplate>(_m).a0;
            _v.set(template_exprs_f(prism_rtl::deref(t_p1j).parts_p));
            goto _done;
        }
        {
            _v.set(Array<crate::syntax::Expr>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p0).kind_p);
        prism_rtl::is<crate::syntax::ExprKind::ERest>(_m) ? prism_rtl::finished(inner_p1)
        : prism_rtl::is<crate::syntax::ExprKind::EError>(_m) ? prism_rtl::finished(inner_p1)
        : prism_rtl::finished(crate::prelude::append(Array(std::vector{e_p0}), inner_p1));
    });
}


/// `Start ExprsIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::syntax::Expr>> start_exprs_in_f(crate::syntax::Expr e_p0) {
    return prism_rtl::make_rc<ExprsIn>(e_p0);
}


/// TemplateExprs: unbounded fn [TemplatePart] -> [Expr]
Array<crate::syntax::Expr> template_exprs_f(const Array<crate::syntax::TemplatePart>& parts_p0) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(parts_p0, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::TemplatePart>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::TemplatePart> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_p1 = p0;
                auto p_p2 = p1;
                ({
                prism_rtl::is<crate::syntax::TemplatePart::TpPlaceholder>(p_p2) ? ({
                auto&& x_p3 = prism_rtl::as<crate::syntax::TemplatePart::TpPlaceholder>(p_p2).a0;
                ({
                auto x_p3x = x_p3;
                (crate::prelude::call_then(start_exprs_in_f(x_p3x), [=](Array<crate::syntax::Expr> exprs_in_f_10446) { return prism_rtl::finished(crate::prelude::append(acc_p1, exprs_in_f_10446)); }));
            });
            })
                : prism_rtl::is<crate::syntax::TemplatePart::TpBlock>(p_p2) ? ({
                auto&& b_p4 = prism_rtl::as<crate::syntax::TemplatePart::TpBlock>(p_p2).a0;
                ({
                auto b_p4x = b_p4;
                (crate::prelude::call_then(start_block_exprs_f(b_p4x), [=](Array<crate::syntax::Expr> block_exprs_f_10485) { return prism_rtl::finished(crate::prelude::append(acc_p1, block_exprs_f_10485)); }));
            });
            })
                : prism_rtl::is<crate::syntax::TemplatePart::TpCall>(p_p2) ? ({
                auto&& args_p5 = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_p2).a1;
                auto&& ps_o6 = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_p2).a2;
                ({
                auto ps_o6x = ps_o6;
                auto args_p5x = args_p5;
                (crate::prelude::call_then(start_args_exprs_f(args_p5x), [=, ps_o6x = std::move(ps_o6x)](Array<crate::syntax::Expr> args_exprs_f_10558) { return crate::prelude::call_then(start_opt_parts_f(ps_o6x), [=](Array<crate::syntax::Expr> opt_parts_f_10577) { return prism_rtl::finished(crate::prelude::append(crate::prelude::append(acc_p1, args_exprs_f_10558), opt_parts_f_10577)); }); }));
            });
            })
                : prism_rtl::finished(acc_p1);
            });
            });
        }));
    }))));
}


prism_rtl::Turn<Array<crate::syntax::Expr>> TemplateExprs::cycle() const {
    const auto& parts_p0 = this->parts_p0;
    return crate::prelude::fold_job(parts_p0, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::TemplatePart>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::TemplatePart> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_p1 = p0;
                auto p_p2 = p1;
                ({
                prism_rtl::is<crate::syntax::TemplatePart::TpPlaceholder>(p_p2) ? ({
                auto&& x_p3 = prism_rtl::as<crate::syntax::TemplatePart::TpPlaceholder>(p_p2).a0;
                ({
                auto x_p3x = x_p3;
                (crate::prelude::call_then(start_exprs_in_f(x_p3x), [=](Array<crate::syntax::Expr> exprs_in_f_10446) { return prism_rtl::finished(crate::prelude::append(acc_p1, exprs_in_f_10446)); }));
            });
            })
                : prism_rtl::is<crate::syntax::TemplatePart::TpBlock>(p_p2) ? ({
                auto&& b_p4 = prism_rtl::as<crate::syntax::TemplatePart::TpBlock>(p_p2).a0;
                ({
                auto b_p4x = b_p4;
                (crate::prelude::call_then(start_block_exprs_f(b_p4x), [=](Array<crate::syntax::Expr> block_exprs_f_10485) { return prism_rtl::finished(crate::prelude::append(acc_p1, block_exprs_f_10485)); }));
            });
            })
                : prism_rtl::is<crate::syntax::TemplatePart::TpCall>(p_p2) ? ({
                auto&& args_p5 = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_p2).a1;
                auto&& ps_o6 = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_p2).a2;
                ({
                auto ps_o6x = ps_o6;
                auto args_p5x = args_p5;
                (crate::prelude::call_then(start_args_exprs_f(args_p5x), [=, ps_o6x = std::move(ps_o6x)](Array<crate::syntax::Expr> args_exprs_f_10558) { return crate::prelude::call_then(start_opt_parts_f(ps_o6x), [=](Array<crate::syntax::Expr> opt_parts_f_10577) { return prism_rtl::finished(crate::prelude::append(crate::prelude::append(acc_p1, args_exprs_f_10558), opt_parts_f_10577)); }); }));
            });
            })
                : prism_rtl::finished(acc_p1);
            });
            });
        }));
    })))->cycle();
}


/// `Start TemplateExprs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::syntax::Expr>> start_template_exprs_f(Array<crate::syntax::TemplatePart> parts_p0) {
    return prism_rtl::make_rc<TemplateExprs>(parts_p0);
}


/// OptParts: unbounded fn ?[TemplatePart] -> [Expr]
Array<crate::syntax::Expr> opt_parts_f(const std::optional<Array<crate::syntax::TemplatePart>>& opt0) {
    if (prism_rtl::is_some(opt0)) {
        auto&& ps_p0 = prism_rtl::some_of(opt0);
        return template_exprs_f(ps_p0);
    }
    if (prism_rtl::is_none(opt0)) {
        return Array<crate::syntax::Expr>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<crate::syntax::Expr>> OptParts::cycle() const {
    const auto& opt0 = this->opt0;
    return ({
        prism_rtl::is_some(opt0) ? ({
        auto&& ps_p0 = prism_rtl::some_of(opt0);
        prism_rtl::more(prism_rtl::rc(TemplateExprs(ps_p0)));
    })
        : prism_rtl::is_none(opt0) ? prism_rtl::finished(Array<crate::syntax::Expr>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start OptParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::syntax::Expr>> start_opt_parts_f(std::optional<Array<crate::syntax::TemplatePart>> opt0) {
    return prism_rtl::make_rc<OptParts>(opt0);
}


/// OptBlockExprs: unbounded fn ?Block -> [Expr]
Array<crate::syntax::Expr> opt_block_exprs_f(const std::optional<crate::syntax::Block>& opt0) {
    if (prism_rtl::is_some(opt0)) {
        auto&& b_p0 = prism_rtl::some_of(opt0);
        return block_exprs_f(b_p0);
    }
    if (prism_rtl::is_none(opt0)) {
        return Array<crate::syntax::Expr>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<crate::syntax::Expr>> OptBlockExprs::cycle() const {
    const auto& opt0 = this->opt0;
    return ({
        prism_rtl::is_some(opt0) ? ({
        auto&& b_p0 = prism_rtl::some_of(opt0);
        prism_rtl::more(prism_rtl::rc(BlockExprs(b_p0)));
    })
        : prism_rtl::is_none(opt0) ? prism_rtl::finished(Array<crate::syntax::Expr>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start OptBlockExprs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::syntax::Expr>> start_opt_block_exprs_f(std::optional<crate::syntax::Block> opt0) {
    return prism_rtl::make_rc<OptBlockExprs>(opt0);
}


/// OptExprs: unbounded fn ?Expr -> [Expr]
Array<crate::syntax::Expr> opt_exprs_f(const std::optional<crate::syntax::Expr>& opt0) {
    if (prism_rtl::is_some(opt0)) {
        auto&& x_p0 = prism_rtl::some_of(opt0);
        return exprs_in_f(x_p0);
    }
    if (prism_rtl::is_none(opt0)) {
        return Array<crate::syntax::Expr>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<crate::syntax::Expr>> OptExprs::cycle() const {
    const auto& opt0 = this->opt0;
    return ({
        prism_rtl::is_some(opt0) ? ({
        auto&& x_p0 = prism_rtl::some_of(opt0);
        prism_rtl::more(prism_rtl::rc(ExprsIn(x_p0)));
    })
        : prism_rtl::is_none(opt0) ? prism_rtl::finished(Array<crate::syntax::Expr>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start OptExprs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::syntax::Expr>> start_opt_exprs_f(std::optional<crate::syntax::Expr> opt0) {
    return prism_rtl::make_rc<OptExprs>(opt0);
}

}  // namespace crate::check::typed::print
