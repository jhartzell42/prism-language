// The module `Check.Typed.Print`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/typed/print/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Typed.Print`, from `target/bootstrap/cpp-src/prismc/check/typed/print.prism`.
namespace crate::check::typed::print {

/// TySexp: unbounded fn Ty -> Text
Text ty_sexp(const crate::check::types::Ty& t_p0) {
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(t_p0)) {
        auto&& n_p1 = prism_rtl::as<crate::check::types::Ty::TyFlex>(t_p0).a0;
        return prism_rtl::cat("(var t", n_p1, ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyRigid>(t_p0)) {
        auto&& n_p2 = prism_rtl::as<crate::check::types::Ty::TyRigid>(t_p0).a0;
        return prism_rtl::cat("(rigid ", n_p2, ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyQ>(t_p0)) {
        auto&& n_p3 = prism_rtl::as<crate::check::types::Ty::TyQ>(t_p0).a0;
        return prism_rtl::cat("(q ", n_p3, ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p0)) {
        auto&& n_p4 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a0;
        auto&& m820_3_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a1;
        if (m820_3_1.size() == 0u) {
            return n_p4;
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p0)) {
        auto&& n_p5 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a0;
        auto&& args_p6 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a1;
        return prism_rtl::cat("(", n_p5, concat(run_to_end(each_job(args_p6, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
            return entered(once_job([=]() {
                return ({
                    auto a_p7 = p0;
                    call_then(start_ty_sexp(a_p7), [=](Text ty_sexp_979) { return prism_rtl::finished(prism_rtl::cat(" ", ty_sexp_979)); });
                });
            }));
        }))))), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p0)) {
        auto&& c_p8 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a0;
        auto&& ps_p9 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a1;
        auto&& res_pa = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a2;
        return prism_rtl::cat("(fn ", col_sexp(c_p8), " (", crate::syntax::lexer::chars::join(run_to_end(each_job(ps_p9, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::types::Ty)>>(prism_rtl::rc([&](crate::check::types::Ty a0) { return entered(start_ty_sexp(a0)); })))), Text::lit(" ")), ") ", ty_sexp(prism_rtl::deref(prism_rtl::deref(res_pa))), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p0)) {
        auto&& ts_pb = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p0).a0;
        return prism_rtl::cat("(tuple", concat(run_to_end(each_job(ts_pb, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
            return entered(once_job([=]() {
                return ({
                    auto a_pc = p0;
                    call_then(start_ty_sexp(a_pc), [=](Text ty_sexp_1128) { return prism_rtl::finished(prism_rtl::cat(" ", ty_sexp_1128)); });
                });
            }));
        }))))), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p0)) {
        auto&& e_pd = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p0).a0;
        return prism_rtl::cat("(array ", ty_sexp(prism_rtl::deref(prism_rtl::deref(e_pd))), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p0)) {
        auto&& k_pe = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a0;
        auto&& v_pf = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a1;
        return prism_rtl::cat("(map ", ty_sexp(prism_rtl::deref(prism_rtl::deref(k_pe))), " ", ty_sexp(prism_rtl::deref(prism_rtl::deref(v_pf))), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& s_pg = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a0;
        auto&& i_ph = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        return prism_rtl::cat("(", s_pg, " ", ty_sexp(prism_rtl::deref(prism_rtl::deref(i_ph))), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p0)) {
        auto&& i_pi = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p0).a0;
        auto&& rw_pj = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p0).a1;
        return prism_rtl::cat("(@ ", ty_sexp(prism_rtl::deref(prism_rtl::deref(i_pi))), " ", row_sexp(rw_pj), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t_p0)) {
        auto&& rw_pk = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p0).a0;
        auto&& o_pl = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p0).a1;
        return prism_rtl::cat("(element ", row_sexp(rw_pk), " ", ty_sexp(prism_rtl::deref(prism_rtl::deref(o_pl))), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(t_p0)) {
        auto&& rw_pm = prism_rtl::as<crate::check::types::Ty::TyElemAny>(t_p0).a0;
        return prism_rtl::cat("(elem ", row_sexp(rw_pm), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p0)) {
        auto&& n_pn = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p0).a0;
        auto&& a_po = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p0).a1;
        return prism_rtl::cat("(assoc ", n_pn, " ", ty_sexp(prism_rtl::deref(prism_rtl::deref(a_po))), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAny>(t_p0)) {
        auto&& trs_pp = prism_rtl::as<crate::check::types::Ty::TyAny>(t_p0).a0;
        return prism_rtl::cat("(any", concat(each(trs_pp, [&](const Text& x_pq) { return prism_rtl::cat(" ^", x_pq); })), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyErr>(t_p0)) {
        return Text::lit("unknown");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> TySexp::cycle() const {
    const auto& t_p0 = this->t_p0;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyFlex>(t_p0) ? ({
        auto&& n_p1 = prism_rtl::as<crate::check::types::Ty::TyFlex>(t_p0).a0;
        prism_rtl::finished(prism_rtl::cat("(var t", n_p1, ")"));
    })
        : prism_rtl::is<crate::check::types::Ty::TyRigid>(t_p0) ? ({
        auto&& n_p2 = prism_rtl::as<crate::check::types::Ty::TyRigid>(t_p0).a0;
        prism_rtl::finished(prism_rtl::cat("(rigid ", n_p2, ")"));
    })
        : prism_rtl::is<crate::check::types::Ty::TyQ>(t_p0) ? ({
        auto&& n_p3 = prism_rtl::as<crate::check::types::Ty::TyQ>(t_p0).a0;
        prism_rtl::finished(prism_rtl::cat("(q ", n_p3, ")"));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p0) && ({
        auto&& n_p4 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a0;
        auto&& m820_3_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a1;
        (m820_3_1.size() == 0u);
    }) ? ({
        auto&& n_p4 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a0;
        auto&& m820_3_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a1;
        prism_rtl::finished(n_p4);
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p0) ? ({
        auto&& n_p5 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a0;
        auto&& args_p6 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a1;
        ({
        auto args_p6_1 = args_p6;
        auto n_p5_2 = n_p5;
        call_value(each_job(args_p6_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return entered(once_job([=]() {
            return ({
                auto a_p7 = p0;
                call_then(start_ty_sexp(a_p7), [=](Text ty_sexp_979) { return prism_rtl::finished(prism_rtl::cat(" ", ty_sexp_979)); });
            });
        }));
    }))), [=, n_p5_2 = std::move(n_p5_2)](Array<Text> each_960) { return prism_rtl::finished(prism_rtl::cat("(", n_p5_2, concat(each_960), ")")); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(t_p0) ? ({
        auto&& c_p8 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a0;
        auto&& ps_p9 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a1;
        auto&& res_pa = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a2;
        ({
        auto c_p8_1 = c_p8;
        auto ps_p9_2 = ps_p9;
        auto res_pa_3 = prism_rtl::deref(prism_rtl::deref(res_pa));
        call_value(each_job(ps_p9_2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::types::Ty)>>(prism_rtl::rc([&](crate::check::types::Ty a0) { return entered(start_ty_sexp(a0)); }))), [=, c_p8_1 = std::move(c_p8_1), res_pa_3 = std::move(res_pa_3)](Array<Text> each_1040) { return call_then(start_ty_sexp(res_pa_3), [=](Text ty_sexp_1065) { return prism_rtl::finished(prism_rtl::cat("(fn ", col_sexp(c_p8_1), " (", crate::syntax::lexer::chars::join(each_1040, Text::lit(" ")), ") ", ty_sexp_1065, ")")); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p0) ? ({
        auto&& ts_pb = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p0).a0;
        ({
        auto ts_pb_1 = ts_pb;
        call_value(each_job(ts_pb_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return entered(once_job([=]() {
            return ({
                auto a_pc = p0;
                call_then(start_ty_sexp(a_pc), [=](Text ty_sexp_1128) { return prism_rtl::finished(prism_rtl::cat(" ", ty_sexp_1128)); });
            });
        }));
    }))), [=](Array<Text> each_1111) { return prism_rtl::finished(prism_rtl::cat("(tuple", concat(each_1111), ")")); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t_p0) ? ({
        auto&& e_pd = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p0).a0;
        ({
        auto e_pd_1 = prism_rtl::deref(prism_rtl::deref(e_pd));
        call_then(start_ty_sexp(e_pd_1), [=](Text ty_sexp_1167) { return prism_rtl::finished(prism_rtl::cat("(array ", ty_sexp_1167, ")")); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t_p0) ? ({
        auto&& k_pe = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a0;
        auto&& v_pf = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a1;
        ({
        auto k_pe_1 = prism_rtl::deref(prism_rtl::deref(k_pe));
        auto v_pf_2 = prism_rtl::deref(prism_rtl::deref(v_pf));
        call_then(start_ty_sexp(k_pe_1), [=, v_pf_2 = std::move(v_pf_2)](Text ty_sexp_1202) { return call_then(start_ty_sexp(v_pf_2), [=](Text ty_sexp_1213) { return prism_rtl::finished(prism_rtl::cat("(map ", ty_sexp_1202, " ", ty_sexp_1213, ")")); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t_p0) ? ({
        auto&& s_pg = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a0;
        auto&& i_ph = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        ({
        auto i_ph_1 = prism_rtl::deref(prism_rtl::deref(i_ph));
        auto s_pg_2 = s_pg;
        call_then(start_ty_sexp(i_ph_1), [=, s_pg_2 = std::move(s_pg_2)](Text ty_sexp_1248) { return prism_rtl::finished(prism_rtl::cat("(", s_pg_2, " ", ty_sexp_1248, ")")); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyAt>(t_p0) ? ({
        auto&& i_pi = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p0).a0;
        auto&& rw_pj = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p0).a1;
        ({
        auto i_pi_1 = prism_rtl::deref(prism_rtl::deref(i_pi));
        auto rw_pj_2 = rw_pj;
        call_then(start_ty_sexp(i_pi_1), [=, rw_pj_2 = std::move(rw_pj_2)](Text ty_sexp_1281) { return prism_rtl::finished(prism_rtl::cat("(@ ", ty_sexp_1281, " ", row_sexp(rw_pj_2), ")")); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyElem>(t_p0) ? ({
        auto&& rw_pk = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p0).a0;
        auto&& o_pl = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p0).a1;
        ({
        auto o_pl_1 = prism_rtl::deref(prism_rtl::deref(o_pl));
        auto rw_pk_2 = rw_pk;
        call_then(start_ty_sexp(o_pl_1), [=, rw_pk_2 = std::move(rw_pk_2)](Text ty_sexp_1348) { return prism_rtl::finished(prism_rtl::cat("(element ", row_sexp(rw_pk_2), " ", ty_sexp_1348, ")")); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyElemAny>(t_p0) ? ({
        auto&& rw_pm = prism_rtl::as<crate::check::types::Ty::TyElemAny>(t_p0).a0;
        prism_rtl::finished(prism_rtl::cat("(elem ", row_sexp(rw_pm), ")"));
    })
        : prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p0) ? ({
        auto&& n_pn = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p0).a0;
        auto&& a_po = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p0).a1;
        ({
        auto a_po_1 = prism_rtl::deref(prism_rtl::deref(a_po));
        auto n_pn_2 = n_pn;
        call_then(start_ty_sexp(a_po_1), [=, n_pn_2 = std::move(n_pn_2)](Text ty_sexp_1431) { return prism_rtl::finished(prism_rtl::cat("(assoc ", n_pn_2, " ", ty_sexp_1431, ")")); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyAny>(t_p0) ? ({
        auto&& trs_pp = prism_rtl::as<crate::check::types::Ty::TyAny>(t_p0).a0;
        prism_rtl::finished(prism_rtl::cat("(any", concat(each(trs_pp, [&](const Text& x_pq) { return prism_rtl::cat(" ^", x_pq); })), ")"));
    })
        : prism_rtl::is<crate::check::types::Ty::TyErr>(t_p0) ? prism_rtl::finished(Text::lit("unknown"))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TySexp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_ty_sexp(crate::check::types::Ty t_p0) {
    return prism_rtl::make_rc<TySexp>(t_p0);
}


/// ColSexp: fn Col -> Text
Text col_sexp(const crate::check::types::Col& col0) {
    if (prism_rtl::is<crate::check::types::Col::CBound>(col0)) {
        return Text::lit("bounded");
    }
    if (prism_rtl::is<crate::check::types::Col::CUnbound>(col0)) {
        return Text::lit("unbounded");
    }
    if (prism_rtl::is<crate::check::types::Col::CRigid>(col0)) {
        auto&& n_p0 = prism_rtl::as<crate::check::types::Col::CRigid>(col0).a0;
        return prism_rtl::cat("(color ", n_p0, ")");
    }
    if (prism_rtl::is<crate::check::types::Col::CQ>(col0)) {
        auto&& n_p1 = prism_rtl::as<crate::check::types::Col::CQ>(col0).a0;
        return prism_rtl::cat("(color ", n_p1, ")");
    }
    if (prism_rtl::is<crate::check::types::Col::CFlex>(col0)) {
        auto&& n_p2 = prism_rtl::as<crate::check::types::Col::CFlex>(col0).a0;
        return prism_rtl::cat("(color c", n_p2, ")");
    }
    prism_rtl::unreachable("no arm matched");
}


/// RowSexp: fn Rw -> Text
Text row_sexp(const crate::check::types::Rw& rw_p0) {
    auto tail_p1 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = rw_p0.tail;
        if (prism_rtl::is<crate::check::types::Tail::TlClosed>(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Tail::TlFlex>(_m)) {
            auto&& n_p3 = prism_rtl::as<crate::check::types::Tail::TlFlex>(_m).a0;
            _v.set(prism_rtl::cat(" (tail r", n_p3, ")"));
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Tail::TlRigid>(_m)) {
            auto&& n_p4 = prism_rtl::as<crate::check::types::Tail::TlRigid>(_m).a0;
            _v.set(prism_rtl::cat(" (tail ", n_p4, ")"));
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Tail::TlQ>(_m)) {
            auto&& n_p5 = prism_rtl::as<crate::check::types::Tail::TlQ>(_m).a0;
            _v.set(prism_rtl::cat(" (tail ", n_p5, ")"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto minus_p2 = len(rw_p0.minus) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" (minus", concat(each(rw_p0.minus, [&](const Text& m_p6) { return prism_rtl::cat(" ", m_p6); })), ")");
    return prism_rtl::cat("(row", concat(each(rw_p0.fams, [&](const Text& f_p7) { return prism_rtl::cat(" ", f_p7, ".*"); })), tail_p1, minus_p2, ")");
}


/// SchemeSexp: unbounded fn Scheme -> Text
Text scheme_sexp(const crate::check::types::Scheme& sc_p0) {
    auto qs_p1 = len(sc_p0.qs) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" (forall", concat(each(sc_p0.qs, [&](const Text& q_p5) { return prism_rtl::cat(" ", q_p5); })), ")");
    auto rqs_p2 = len(sc_p0.rqs) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" (rows", concat(each(sc_p0.rqs, [&](const Text& q_p6) { return prism_rtl::cat(" ", q_p6); })), ")");
    auto cqs_p3 = len(sc_p0.cqs) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" (colors", concat(each(sc_p0.cqs, [&](const Text& q_p7) { return prism_rtl::cat(" ", q_p7); })), ")");
    auto bs_p4 = len(sc_p0.bounds) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" (where", concat(each(sc_p0.bounds, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_p8 = std::get<0>(_p0);
        auto&& c_p9 = std::get<1>(_p0);
        return prism_rtl::cat(" ", v_p8, ":^", c_p9);
    })), ")");
    return prism_rtl::cat("(scheme", qs_p1, rqs_p2, cqs_p3, bs_p4, " ", ty_sexp(sc_p0.ty), ")");
}


prism_rtl::Turn<Text> SchemeSexp::cycle() const {
    const auto& sc_p0 = this->sc_p0;
    auto qs_p1 = len(prism_rtl::deref(sc_p0).qs) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" (forall", concat(each(prism_rtl::deref(sc_p0).qs, [&](const Text& q_p5) { return prism_rtl::cat(" ", q_p5); })), ")");
    auto rqs_p2 = len(prism_rtl::deref(sc_p0).rqs) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" (rows", concat(each(prism_rtl::deref(sc_p0).rqs, [&](const Text& q_p6) { return prism_rtl::cat(" ", q_p6); })), ")");
    auto cqs_p3 = len(prism_rtl::deref(sc_p0).cqs) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" (colors", concat(each(prism_rtl::deref(sc_p0).cqs, [&](const Text& q_p7) { return prism_rtl::cat(" ", q_p7); })), ")");
    auto bs_p4 = len(prism_rtl::deref(sc_p0).bounds) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" (where", concat(each(prism_rtl::deref(sc_p0).bounds, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_p8 = std::get<0>(_p0);
        auto&& c_p9 = std::get<1>(_p0);
        return prism_rtl::cat(" ", v_p8, ":^", c_p9);
    })), ")");
    auto sc_p0_1 = sc_p0;
    return call_then(start_ty_sexp(prism_rtl::deref(sc_p0_1).ty), [=](Text ty_sexp_2534) { return prism_rtl::finished(prism_rtl::cat("(scheme", qs_p1, rqs_p2, cqs_p3, bs_p4, " ", ty_sexp_2534, ")")); });
}


/// `Start SchemeSexp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_scheme_sexp(crate::check::types::Scheme sc_p0) {
    return prism_rtl::make_rc<SchemeSexp>(sc_p0);
}


/// AtText: fn [Src], SrcAt -> Text
Text at_text(const Array<crate::check::errors::Src>& srcs_p0, const crate::check::typed::SrcAt& a_p1) {
    auto&& _m = index(srcs_p0, a_p1.file);
    if (prism_rtl::is_none(_m)) {
        return prism_rtl::cat("?:", prism_rtl::deref(a_p1.span).start);
    }
    if (prism_rtl::is_some(_m)) {
        auto&& src_p2 = prism_rtl::some_of(_m);
        return prism_rtl::cat(crate::check::errors::seg_at(src_p2, prism_rtl::deref(a_p1.span).start)->path_, ":", pos_text(src_p2, prism_rtl::deref(a_p1.span).start), "-", pos_text(src_p2, prism_rtl::deref(a_p1.span).end));
    }
    prism_rtl::unreachable("no arm matched");
}


/// PosText: fn Src, Nat -> Text
Text pos_text(const crate::check::errors::Src& src_p0, const Nat& offset_p1) {
    auto line_p2 = crate::check::errors::cline_of(src_p0.starts, offset_p1);
    auto col_p3 = crate::syntax::lexer::chars::column_of(src_p0.text, or_(index(src_p0.starts, line_p2), Nat(0u)), offset_p1);
    return prism_rtl::cat(or_(line_p2.checked_sub(prism_rtl::deref(crate::check::errors::seg_at(src_p0, offset_p1)).line), Nat(0u)) + Nat(1u), ":", col_p3 + Nat(1u));
}


/// TypedSexp: unbounded fn [Src], [Module], Nat, TProgram -> Text
Text typed_sexp(const Array<crate::check::errors::Src>& srcs_p0, const Array<crate::syntax::Module>& trees_p1, const Nat& shown_p2, const crate::check::typed::TProgram& tp_p3) {
    auto tys_p4 = fold(tp_p3.exprs, Map<Text, crate::check::types::Ty>{}, [&](const Map<Text, crate::check::types::Ty>& m_pk, const crate::check::typed::TyNote& n_pl) { return insert(m_pk, crate::check::typed::at_key(prism_rtl::deref(n_pl).at), prism_rtl::deref(n_pl).ty); });
    auto files_p5 = filter(crate::check::errors::range0(len(trees_p1)), [&](const Nat& i_pm) { return i_pm < shown_p2; });
    auto defs_p6 = concat(run_to_end(each_job(filter(tp_p3.defs, [&](const crate::check::typed::DefNote& d_pn) { return prism_rtl::deref(d_pn).at->file < shown_p2; }), ({
        auto srcs_p0_1 = srcs_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::typed::DefNote)>>(prism_rtl::rc([=, srcs_p0_1 = std::move(srcs_p0_1)](crate::check::typed::DefNote p0) {
        return ({
            auto srcs_p0_1_2 = srcs_p0_1;
            entered(once_job([=, srcs_p0_1_2 = std::move(srcs_p0_1_2)]() {
            return ({
                auto d_po = p0;
                call_then(start_scheme_sexp(prism_rtl::deref(d_po).scheme), [=](Text scheme_sexp_3620) { return prism_rtl::finished(prism_rtl::cat("  (def ", prism_rtl::deref(d_po).name, " ", at_text(srcs_p0_1_2, prism_rtl::deref(d_po).at), " ", scheme_sexp_3620, ")\n")); });
            });
        }));
        });
    })));
    }))));
    auto exprs_p7 = concat(run_to_end(each_job(files_p5, ({
        auto srcs_p0_1 = srcs_p0;
        auto tys_p4_2 = tys_p4;
        auto trees_p1_3 = trees_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=, srcs_p0_1 = std::move(srcs_p0_1), tys_p4_2 = std::move(tys_p4_2), trees_p1_3 = std::move(trees_p1_3)](Nat p0) {
        return ({
            auto srcs_p0_1_4 = srcs_p0_1;
            auto tys_p4_2_4 = tys_p4_2;
            auto trees_p1_3_4 = trees_p1_3;
            entered(once_job([=, srcs_p0_1_4 = std::move(srcs_p0_1_4), tys_p4_2_4 = std::move(tys_p4_2_4), trees_p1_3_4 = std::move(trees_p1_3_4)]() {
            return ({
                auto i_pp = p0;
                (prism_rtl::more(prism_rtl::rc(ExprsOfFile(srcs_p0_1_4, tys_p4_2_4, i_pp, or_(index(trees_p1_3_4, i_pp), empty_mod())))));
            });
        }));
        });
    })));
    }))));
    auto mine_f8 = ({
        auto shown_p2_1 = shown_p2;
        static_cast<Fn<bool(const crate::check::typed::SrcAt&)>>(prism_rtl::rc([=, shown_p2_1 = std::move(shown_p2_1)](const crate::check::typed::SrcAt& a_pq) { return shown(a_pq, shown_p2_1); }));
    });
    auto apps_p9 = concat(each(filter(tp_p3.apps, [&](const crate::check::typed::AppNote& x_pr) { return mine_f8(prism_rtl::deref(x_pr).at); }), [&](const crate::check::typed::AppNote& x_ps) { return prism_rtl::cat("  (app ", at_text(srcs_p0, prism_rtl::deref(x_ps).at), " ", quote(prism_rtl::deref(x_ps).callee), " ", prism_rtl::deref(x_ps).kind, " ", layer_word(prism_rtl::deref(x_ps).layer), " (lifted", concat(each(prism_rtl::deref(x_ps).lifted, [&](const Nat& i_pt) { return prism_rtl::cat(" ", i_pt); })), ") ", layer_word(prism_rtl::deref(x_ps).inner), " ", col_sexp(prism_rtl::deref(x_ps).color), ")\n"); }));
    auto lifts_pa = concat(each(filter(tp_p3.lifts, [&](const crate::check::typed::LiftNote& x_pu) { return mine_f8(prism_rtl::deref(x_pu).at); }), [&](const crate::check::typed::LiftNote& x_pv) { return prism_rtl::cat("  (lift ", at_text(srcs_p0, prism_rtl::deref(x_pv).at), " ", prism_rtl::deref(x_pv).sigil, concat(each(prism_rtl::deref(x_pv).operands, [&](const crate::syntax::Range& r_p10) { return prism_rtl::cat(" ", at_text(srcs_p0, crate::check::typed::SrcAt{.file = prism_rtl::deref(x_pv).at->file, .span = r_p10})); })), ")\n"); }));
    auto fns_pb = concat(each(filter(tp_p3.fns, [&](const crate::check::typed::FnNote& x_p11) { return mine_f8(prism_rtl::deref(x_p11).at); }), [&](const crate::check::typed::FnNote& x_p12) { return prism_rtl::cat("  (fn ", quote(prism_rtl::deref(x_p12).name), " ", at_text(srcs_p0, prism_rtl::deref(x_p12).at), " ", col_sexp(prism_rtl::deref(x_p12).declared), " ", col_sexp(prism_rtl::deref(x_p12).body), ")\n"); }));
    auto methods_pc = concat(each(filter(tp_p3.methods, [&](const crate::check::typed::MethodNote& x_p13) { return mine_f8(prism_rtl::deref(x_p13).at); }), [&](const crate::check::typed::MethodNote& x_p14) { return prism_rtl::cat("  (method ", at_text(srcs_p0, prism_rtl::deref(x_p14).at), " ", prism_rtl::deref(x_p14).method, " ^", prism_rtl::deref(x_p14).cls, ")\n"); }));
    auto impls_pd = concat(run_to_end(each_job(filter(tp_p3.impls, [&](const crate::check::typed::ImplNote& x_p15) { return mine_f8(prism_rtl::deref(x_p15).at); }), ({
        auto srcs_p0_1 = srcs_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::typed::ImplNote)>>(prism_rtl::rc([=, srcs_p0_1 = std::move(srcs_p0_1)](crate::check::typed::ImplNote p0) {
        return ({
            auto srcs_p0_1_2 = srcs_p0_1;
            entered(once_job([=, srcs_p0_1_2 = std::move(srcs_p0_1_2)]() {
            return ({
                auto x_p16 = p0;
                call_then(start_ty_sexp(prism_rtl::deref(x_p16).ty), [=](Text ty_sexp_4583) { return prism_rtl::finished(prism_rtl::cat("  (impl ", at_text(srcs_p0_1_2, prism_rtl::deref(x_p16).at), " ^", prism_rtl::deref(x_p16).cls, " ", ty_sexp_4583, " ", prism_rtl::deref(x_p16).how, ")\n")); });
            });
        }));
        });
    })));
    }))));
    auto groups_pe = concat(each(filter(tp_p3.groups, [&](const crate::check::typed::GroupNote& x_p17) { return mine_f8(prism_rtl::deref(x_p17).at); }), [&](const crate::check::typed::GroupNote& x_p18) { return prism_rtl::cat("  (group ", prism_rtl::deref(x_p18).kind, " ", at_text(srcs_p0, prism_rtl::deref(x_p18).at), concat(each(prism_rtl::deref(x_p18).order, [&](const Array<Nat>& c_p19) { return prism_rtl::cat(" (", crate::syntax::lexer::chars::join(each(c_p19, [&](const Nat& i_p1a) { return prism_rtl::cat(i_p1a); }), Text::lit(" ")), ")"); })), ")\n"); }));
    auto binders_pf = concat(run_to_end(each_job(filter(tp_p3.binders, [&](const crate::check::typed::BinderNote& x_p1b) { return mine_f8(prism_rtl::deref(x_p1b).at); }), ({
        auto srcs_p0_1 = srcs_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::typed::BinderNote)>>(prism_rtl::rc([=, srcs_p0_1 = std::move(srcs_p0_1)](crate::check::typed::BinderNote p0) {
        return ({
            auto srcs_p0_1_2 = srcs_p0_1;
            entered(once_job([=, srcs_p0_1_2 = std::move(srcs_p0_1_2)]() {
            return ({
                auto x_p1c = p0;
                call_then(start_ty_sexp(prism_rtl::deref(x_p1c).ty), [=](Text ty_sexp_4911) { return prism_rtl::finished(prism_rtl::cat("  (binder ", quote(prism_rtl::deref(x_p1c).name), " ", at_text(srcs_p0_1_2, prism_rtl::deref(x_p1c).at), " ", ty_sexp_4911, ")\n")); });
            });
        }));
        });
    })));
    }))));
    auto locals_pg = concat(each(filter(tp_p3.locals, [&](const crate::check::typed::LocalNote& x_p1d) { return mine_f8(prism_rtl::deref(x_p1d).at); }), [&](const crate::check::typed::LocalNote& x_p1e) { return prism_rtl::cat("  (local ", prism_rtl::deref(x_p1e).id, " ", at_text(srcs_p0, prism_rtl::deref(x_p1e).at), ")\n"); }));
    auto uses_ph = concat(each(filter(tp_p3.uses, [&](const crate::check::typed::LocalNote& x_p1f) { return mine_f8(prism_rtl::deref(x_p1f).at); }), [&](const crate::check::typed::LocalNote& x_p1g) { return prism_rtl::cat("  (use ", prism_rtl::deref(x_p1g).id, " ", at_text(srcs_p0, prism_rtl::deref(x_p1g).at), ")\n"); }));
    auto gens_pi = concat(each(filter(tp_p3.gens, [&](const crate::check::typed::GenNote& x_p1h) { return mine_f8(prism_rtl::deref(x_p1h).at); }), [&](const crate::check::typed::GenNote& x_p1i) { return prism_rtl::cat("  (gen ", quote(prism_rtl::deref(x_p1i).name), " ", at_text(srcs_p0, prism_rtl::deref(x_p1i).at), concat(each(prism_rtl::deref(x_p1i).tys, [&](const Text& q_p1j) { return prism_rtl::cat(" ", q_p1j); })), concat(each(prism_rtl::deref(x_p1i).cols, [&](const Text& q_p1k) { return prism_rtl::cat(" ", q_p1k); })), ")\n"); }));
    auto insts_pj = concat(run_to_end(each_job(filter(tp_p3.insts, [&](const crate::check::typed::InstNote& x_p1l) { return mine_f8(prism_rtl::deref(x_p1l).at); }), ({
        auto srcs_p0_1 = srcs_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::typed::InstNote)>>(prism_rtl::rc([=, srcs_p0_1 = std::move(srcs_p0_1)](crate::check::typed::InstNote p0) {
        return ({
            auto srcs_p0_1_2 = srcs_p0_1;
            entered(once_job([=, srcs_p0_1_2 = std::move(srcs_p0_1_2)]() {
            return ({
                auto x_p1m = p0;
                call_value(each_job(prism_rtl::deref(x_p1m).tys, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Text, crate::check::types::Ty> p0) {
                return entered(once_job([=]() {
                    return ({
                        auto [q_p1n, t_p1o] = p0;
                        call_then(start_ty_sexp(t_p1o), [=](Text ty_sexp_5486) { return prism_rtl::finished(prism_rtl::cat(" (", q_p1n, " ", ty_sexp_5486, ")")); });
                    });
                }));
            }))), [=](Array<Text> each_5454) {
                return prism_rtl::finished(prism_rtl::cat("  (inst ", quote(prism_rtl::deref(x_p1m).name), " ", at_text(srcs_p0_1_2, prism_rtl::deref(x_p1m).at), concat(each_5454), concat(each(prism_rtl::deref(x_p1m).cols, [&](const std::tuple<Text, crate::check::types::Col>& _p0) {
                    auto&& q_p1p = std::get<0>(_p0);
                    auto&& c_p1q = std::get<1>(_p0);
                    return prism_rtl::cat(" (", q_p1p, " ", col_sexp(c_p1q), ")");
                })), ")\n"));
            });
            });
        }));
        });
    })));
    }))));
    return prism_rtl::cat("(typed\n (defs\n", defs_p6, " )\n (exprs\n", exprs_p7, " )\n (apps\n", apps_p9, " )\n (lifts\n", lifts_pa, " )\n (fns\n", fns_pb, " )\n (methods\n", methods_pc, " )\n (impls\n", impls_pd, " )\n (groups\n", groups_pe, " )\n (binders\n", binders_pf, " )\n (locals\n", locals_pg, " )\n (uses\n", uses_ph, " )\n (gens\n", gens_pi, " )\n (insts\n", insts_pj, " ))\n");
}


prism_rtl::Turn<Text> TypedSexp::cycle() const {
    const auto& srcs_p0 = this->srcs_p0;
    const auto& trees_p1 = this->trees_p1;
    const auto& shown_p2 = this->shown_p2;
    const auto& tp_p3 = this->tp_p3;
    auto tys_p4 = fold(prism_rtl::deref(tp_p3).exprs, Map<Text, crate::check::types::Ty>{}, [&](const Map<Text, crate::check::types::Ty>& m_pk, const crate::check::typed::TyNote& n_pl) { return insert(m_pk, crate::check::typed::at_key(prism_rtl::deref(n_pl).at), prism_rtl::deref(n_pl).ty); });
    auto files_p5 = filter(crate::check::errors::range0(len(trees_p1)), [&](const Nat& i_pm) { return i_pm < shown_p2; });
    auto shown_p2_1 = shown_p2;
    auto srcs_p0_2 = srcs_p0;
    auto tp_p3_3 = tp_p3;
    auto trees_p1_4 = trees_p1;
    return call_value(each_job(filter(prism_rtl::deref(tp_p3_3).defs, [&](const crate::check::typed::DefNote& d_pn) { return prism_rtl::deref(d_pn).at->file < shown_p2_1; }), ({
        auto srcs_p0_2_5 = srcs_p0_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::typed::DefNote)>>(prism_rtl::rc([=, srcs_p0_2_5 = std::move(srcs_p0_2_5)](crate::check::typed::DefNote p0) {
        return ({
            auto srcs_p0_2_5_5 = srcs_p0_2_5;
            entered(once_job([=, srcs_p0_2_5_5 = std::move(srcs_p0_2_5_5)]() {
            return ({
                auto d_po = p0;
                call_then(start_scheme_sexp(prism_rtl::deref(d_po).scheme), [=](Text scheme_sexp_3620) { return prism_rtl::finished(prism_rtl::cat("  (def ", prism_rtl::deref(d_po).name, " ", at_text(srcs_p0_2_5_5, prism_rtl::deref(d_po).at), " ", scheme_sexp_3620, ")\n")); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_3530) {
        return ({
            auto defs_p6 = concat(each_3530);
            call_value(each_job(files_p5, ({
            auto srcs_p0_2_5 = srcs_p0_2;
            auto tys_p4_5 = tys_p4;
            auto trees_p1_4_6 = trees_p1_4;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=, srcs_p0_2_5 = std::move(srcs_p0_2_5), tys_p4_5 = std::move(tys_p4_5), trees_p1_4_6 = std::move(trees_p1_4_6)](Nat p0) {
            return ({
                auto srcs_p0_2_5_6 = srcs_p0_2_5;
                auto tys_p4_5_6 = tys_p4_5;
                auto trees_p1_4_6_6 = trees_p1_4_6;
                entered(once_job([=, srcs_p0_2_5_6 = std::move(srcs_p0_2_5_6), tys_p4_5_6 = std::move(tys_p4_5_6), trees_p1_4_6_6 = std::move(trees_p1_4_6_6)]() {
                return ({
                    auto i_pp = p0;
                    (prism_rtl::more(prism_rtl::rc(ExprsOfFile(srcs_p0_2_5_6, tys_p4_5_6, i_pp, or_(index(trees_p1_4_6_6, i_pp), empty_mod())))));
                });
            }));
            });
        })));
        })), [=, defs_p6 = std::move(defs_p6)](Array<Text> each_3670) {
            return ({
                auto exprs_p7 = concat(each_3670);
                auto mine_f8 = ({
                    auto shown_p2_1_5 = shown_p2_1;
                    static_cast<Fn<bool(const crate::check::typed::SrcAt&)>>(prism_rtl::rc([=, shown_p2_1_5 = std::move(shown_p2_1_5)](const crate::check::typed::SrcAt& a_pq) { return shown(a_pq, shown_p2_1_5); }));
                });
                auto apps_p9 = concat(each(filter(prism_rtl::deref(tp_p3_3).apps, [&](const crate::check::typed::AppNote& x_pr) { return mine_f8(prism_rtl::deref(x_pr).at); }), [&](const crate::check::typed::AppNote& x_ps) { return prism_rtl::cat("  (app ", at_text(srcs_p0_2, prism_rtl::deref(x_ps).at), " ", quote(prism_rtl::deref(x_ps).callee), " ", prism_rtl::deref(x_ps).kind, " ", layer_word(prism_rtl::deref(x_ps).layer), " (lifted", concat(each(prism_rtl::deref(x_ps).lifted, [&](const Nat& i_pt) { return prism_rtl::cat(" ", i_pt); })), ") ", layer_word(prism_rtl::deref(x_ps).inner), " ", col_sexp(prism_rtl::deref(x_ps).color), ")\n"); }));
                auto lifts_pa = concat(each(filter(prism_rtl::deref(tp_p3_3).lifts, [&](const crate::check::typed::LiftNote& x_pu) { return mine_f8(prism_rtl::deref(x_pu).at); }), [&](const crate::check::typed::LiftNote& x_pv) { return prism_rtl::cat("  (lift ", at_text(srcs_p0_2, prism_rtl::deref(x_pv).at), " ", prism_rtl::deref(x_pv).sigil, concat(each(prism_rtl::deref(x_pv).operands, [&](const crate::syntax::Range& r_p10) { return prism_rtl::cat(" ", at_text(srcs_p0_2, crate::check::typed::SrcAt{.file = prism_rtl::deref(x_pv).at->file, .span = r_p10})); })), ")\n"); }));
                auto fns_pb = concat(each(filter(prism_rtl::deref(tp_p3_3).fns, [&](const crate::check::typed::FnNote& x_p11) { return mine_f8(prism_rtl::deref(x_p11).at); }), [&](const crate::check::typed::FnNote& x_p12) { return prism_rtl::cat("  (fn ", quote(prism_rtl::deref(x_p12).name), " ", at_text(srcs_p0_2, prism_rtl::deref(x_p12).at), " ", col_sexp(prism_rtl::deref(x_p12).declared), " ", col_sexp(prism_rtl::deref(x_p12).body), ")\n"); }));
                auto methods_pc = concat(each(filter(prism_rtl::deref(tp_p3_3).methods, [&](const crate::check::typed::MethodNote& x_p13) { return mine_f8(prism_rtl::deref(x_p13).at); }), [&](const crate::check::typed::MethodNote& x_p14) { return prism_rtl::cat("  (method ", at_text(srcs_p0_2, prism_rtl::deref(x_p14).at), " ", prism_rtl::deref(x_p14).method, " ^", prism_rtl::deref(x_p14).cls, ")\n"); }));
                call_value(each_job(filter(prism_rtl::deref(tp_p3_3).impls, [&](const crate::check::typed::ImplNote& x_p15) { return mine_f8(prism_rtl::deref(x_p15).at); }), ({
                auto srcs_p0_2_5 = srcs_p0_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::typed::ImplNote)>>(prism_rtl::rc([=, srcs_p0_2_5 = std::move(srcs_p0_2_5)](crate::check::typed::ImplNote p0) {
                return ({
                    auto srcs_p0_2_5_5 = srcs_p0_2_5;
                    entered(once_job([=, srcs_p0_2_5_5 = std::move(srcs_p0_2_5_5)]() {
                    return ({
                        auto x_p16 = p0;
                        call_then(start_ty_sexp(prism_rtl::deref(x_p16).ty), [=](Text ty_sexp_4583) { return prism_rtl::finished(prism_rtl::cat("  (impl ", at_text(srcs_p0_2_5_5, prism_rtl::deref(x_p16).at), " ^", prism_rtl::deref(x_p16).cls, " ", ty_sexp_4583, " ", prism_rtl::deref(x_p16).how, ")\n")); });
                    });
                }));
                });
            })));
            })), [=, exprs_p7 = std::move(exprs_p7), apps_p9 = std::move(apps_p9), lifts_pa = std::move(lifts_pa), fns_pb = std::move(fns_pb), methods_pc = std::move(methods_pc)](Array<Text> each_4499) {
                return ({
                    auto impls_pd = concat(each_4499);
                    auto groups_pe = concat(each(filter(prism_rtl::deref(tp_p3_3).groups, [&](const crate::check::typed::GroupNote& x_p17) { return mine_f8(prism_rtl::deref(x_p17).at); }), [&](const crate::check::typed::GroupNote& x_p18) { return prism_rtl::cat("  (group ", prism_rtl::deref(x_p18).kind, " ", at_text(srcs_p0_2, prism_rtl::deref(x_p18).at), concat(each(prism_rtl::deref(x_p18).order, [&](const Array<Nat>& c_p19) { return prism_rtl::cat(" (", crate::syntax::lexer::chars::join(each(c_p19, [&](const Nat& i_p1a) { return prism_rtl::cat(i_p1a); }), Text::lit(" ")), ")"); })), ")\n"); }));
                    call_value(each_job(filter(prism_rtl::deref(tp_p3_3).binders, [&](const crate::check::typed::BinderNote& x_p1b) { return mine_f8(prism_rtl::deref(x_p1b).at); }), ({
                    auto srcs_p0_2_5 = srcs_p0_2;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::typed::BinderNote)>>(prism_rtl::rc([=, srcs_p0_2_5 = std::move(srcs_p0_2_5)](crate::check::typed::BinderNote p0) {
                    return ({
                        auto srcs_p0_2_5_5 = srcs_p0_2_5;
                        entered(once_job([=, srcs_p0_2_5_5 = std::move(srcs_p0_2_5_5)]() {
                        return ({
                            auto x_p1c = p0;
                            call_then(start_ty_sexp(prism_rtl::deref(x_p1c).ty), [=](Text ty_sexp_4911) { return prism_rtl::finished(prism_rtl::cat("  (binder ", quote(prism_rtl::deref(x_p1c).name), " ", at_text(srcs_p0_2_5_5, prism_rtl::deref(x_p1c).at), " ", ty_sexp_4911, ")\n")); });
                        });
                    }));
                    });
                })));
                })), [=, impls_pd = std::move(impls_pd), groups_pe = std::move(groups_pe)](Array<Text> each_4817) {
                    return ({
                        auto binders_pf = concat(each_4817);
                        auto locals_pg = concat(each(filter(prism_rtl::deref(tp_p3_3).locals, [&](const crate::check::typed::LocalNote& x_p1d) { return mine_f8(prism_rtl::deref(x_p1d).at); }), [&](const crate::check::typed::LocalNote& x_p1e) { return prism_rtl::cat("  (local ", prism_rtl::deref(x_p1e).id, " ", at_text(srcs_p0_2, prism_rtl::deref(x_p1e).at), ")\n"); }));
                        auto uses_ph = concat(each(filter(prism_rtl::deref(tp_p3_3).uses, [&](const crate::check::typed::LocalNote& x_p1f) { return mine_f8(prism_rtl::deref(x_p1f).at); }), [&](const crate::check::typed::LocalNote& x_p1g) { return prism_rtl::cat("  (use ", prism_rtl::deref(x_p1g).id, " ", at_text(srcs_p0_2, prism_rtl::deref(x_p1g).at), ")\n"); }));
                        auto gens_pi = concat(each(filter(prism_rtl::deref(tp_p3_3).gens, [&](const crate::check::typed::GenNote& x_p1h) { return mine_f8(prism_rtl::deref(x_p1h).at); }), [&](const crate::check::typed::GenNote& x_p1i) { return prism_rtl::cat("  (gen ", quote(prism_rtl::deref(x_p1i).name), " ", at_text(srcs_p0_2, prism_rtl::deref(x_p1i).at), concat(each(prism_rtl::deref(x_p1i).tys, [&](const Text& q_p1j) { return prism_rtl::cat(" ", q_p1j); })), concat(each(prism_rtl::deref(x_p1i).cols, [&](const Text& q_p1k) { return prism_rtl::cat(" ", q_p1k); })), ")\n"); }));
                        call_value(each_job(filter(prism_rtl::deref(tp_p3_3).insts, [&](const crate::check::typed::InstNote& x_p1l) { return mine_f8(prism_rtl::deref(x_p1l).at); }), ({
                        auto srcs_p0_2_5 = srcs_p0_2;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::typed::InstNote)>>(prism_rtl::rc([=, srcs_p0_2_5 = std::move(srcs_p0_2_5)](crate::check::typed::InstNote p0) {
                        return ({
                            auto srcs_p0_2_5_5 = srcs_p0_2_5;
                            entered(once_job([=, srcs_p0_2_5_5 = std::move(srcs_p0_2_5_5)]() {
                            return ({
                                auto x_p1m = p0;
                                call_value(each_job(prism_rtl::deref(x_p1m).tys, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Text, crate::check::types::Ty> p0) {
                                return entered(once_job([=]() {
                                    return ({
                                        auto [q_p1n, t_p1o] = p0;
                                        call_then(start_ty_sexp(t_p1o), [=](Text ty_sexp_5486) { return prism_rtl::finished(prism_rtl::cat(" (", q_p1n, " ", ty_sexp_5486, ")")); });
                                    });
                                }));
                            }))), [=](Array<Text> each_5454) {
                                return prism_rtl::finished(prism_rtl::cat("  (inst ", quote(prism_rtl::deref(x_p1m).name), " ", at_text(srcs_p0_2_5_5, prism_rtl::deref(x_p1m).at), concat(each_5454), concat(each(prism_rtl::deref(x_p1m).cols, [&](const std::tuple<Text, crate::check::types::Col>& _p0) {
                                    auto&& q_p1p = std::get<0>(_p0);
                                    auto&& c_p1q = std::get<1>(_p0);
                                    return prism_rtl::cat(" (", q_p1p, " ", col_sexp(c_p1q), ")");
                                })), ")\n"));
                            });
                            });
                        }));
                        });
                    })));
                    })), [=, binders_pf = std::move(binders_pf), locals_pg = std::move(locals_pg), uses_ph = std::move(uses_ph), gens_pi = std::move(gens_pi)](Array<Text> each_5357) {
                        return ({
                            auto insts_pj = concat(each_5357);
                            (prism_rtl::finished(prism_rtl::cat("(typed\n (defs\n", defs_p6, " )\n (exprs\n", exprs_p7, " )\n (apps\n", apps_p9, " )\n (lifts\n", lifts_pa, " )\n (fns\n", fns_pb, " )\n (methods\n", methods_pc, " )\n (impls\n", impls_pd, " )\n (groups\n", groups_pe, " )\n (binders\n", binders_pf, " )\n (locals\n", locals_pg, " )\n (uses\n", uses_ph, " )\n (gens\n", gens_pi, " )\n (insts\n", insts_pj, " ))\n")));
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start TypedSexp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_typed_sexp(Array<crate::check::errors::Src> srcs_p0, Array<crate::syntax::Module> trees_p1, Nat shown_p2, crate::check::typed::TProgram tp_p3) {
    return prism_rtl::make_rc<TypedSexp>(srcs_p0, trees_p1, shown_p2, tp_p3);
}


/// Shown: fn SrcAt, Nat -> Bool
bool shown(const crate::check::typed::SrcAt& a_p0, const Nat& shown_p1) {
    return a_p0.file < shown_p1;
}


/// let emptyMod
crate::syntax::Module empty_mod() {
    return crate::syntax::Module{.name = std::optional<crate::syntax::QualName>{}, .emit_row = std::optional<crate::syntax::Row_>{}, .mods = Array<crate::syntax::ModLine>{}, .uses = Array<crate::syntax::Use>{}, .decls = Array<crate::syntax::decls::Decl>{}, .template_ = std::optional<crate::syntax::Template>{}, .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// Quote: fn Text -> Text
Text quote(const Text& t_p0) {
    return prism_rtl::cat("\"", t_p0, "\"");
}


/// LayerWord: fn Text -> Text
Text layer_word(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("")) {
            return Text::lit("-");
        }
    }
    {
        auto&& s_p0 = text0;
        return s_p0;
    }
}


/// ExprsOfFile: unbounded fn [Src], (Text ==> Ty), Nat, Module -> Text
Text exprs_of_file(const Array<crate::check::errors::Src>& srcs_p0, const Map<Text, crate::check::types::Ty>& tys_p1, const Nat& file_p2, const crate::syntax::Module& m_p3) {
    auto es_p4 = run_to_end(fold_job(m_p3.decls, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::Decl>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::Decl> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_p5 = p0;
                auto d_p6 = p1;
                call_then(start_decl_exprs(d_p6), [=, acc_p5 = std::move(acc_p5)](Array<crate::syntax::Expr> decl_exprs_6366) { return prism_rtl::finished(append(acc_p5, decl_exprs_6366)); });
            });
        }));
    }))));
    return concat(run_to_end(each_job(es_p4, ({
        auto srcs_p0_1 = srcs_p0;
        auto tys_p1_2 = tys_p1;
        auto file_p2_3 = file_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::syntax::Expr)>>(prism_rtl::rc([=, srcs_p0_1 = std::move(srcs_p0_1), tys_p1_2 = std::move(tys_p1_2), file_p2_3 = std::move(file_p2_3)](crate::syntax::Expr p0) {
        return ({
            auto srcs_p0_1_4 = srcs_p0_1;
            auto tys_p1_2_4 = tys_p1_2;
            auto file_p2_3_4 = file_p2_3;
            entered(once_job([=, srcs_p0_1_4 = std::move(srcs_p0_1_4), tys_p1_2_4 = std::move(tys_p1_2_4), file_p2_3_4 = std::move(file_p2_3_4)]() {
            return ({
                auto e_p7 = p0;
                (prism_rtl::more(prism_rtl::rc(ExprLine(srcs_p0_1_4, tys_p1_2_4, crate::check::typed::SrcAt{.file = file_p2_3_4, .span = prism_rtl::deref(e_p7).span}))));
            });
        }));
        });
    })));
    }))));
}


prism_rtl::Turn<Text> ExprsOfFile::cycle() const {
    const auto& srcs_p0 = this->srcs_p0;
    const auto& tys_p1 = this->tys_p1;
    const auto& file_p2 = this->file_p2;
    const auto& m_p3 = this->m_p3;
    auto file_p2_1 = file_p2;
    auto m_p3_2 = m_p3;
    auto srcs_p0_3 = srcs_p0;
    auto tys_p1_4 = tys_p1;
    return call_value(fold_job(prism_rtl::deref(m_p3_2).decls, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::Decl>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::Decl> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_p5 = p0;
                auto d_p6 = p1;
                call_then(start_decl_exprs(d_p6), [=, acc_p5 = std::move(acc_p5)](Array<crate::syntax::Expr> decl_exprs_6366) { return prism_rtl::finished(append(acc_p5, decl_exprs_6366)); });
            });
        }));
    }))), [=](Array<crate::syntax::Expr> fold_6323) {
        return ({
            auto es_p4 = fold_6323;
            call_value(each_job(es_p4, ({
            auto srcs_p0_3_5 = srcs_p0_3;
            auto tys_p1_4_5 = tys_p1_4;
            auto file_p2_1_5 = file_p2_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::syntax::Expr)>>(prism_rtl::rc([=, srcs_p0_3_5 = std::move(srcs_p0_3_5), tys_p1_4_5 = std::move(tys_p1_4_5), file_p2_1_5 = std::move(file_p2_1_5)](crate::syntax::Expr p0) {
            return ({
                auto srcs_p0_3_5_5 = srcs_p0_3_5;
                auto tys_p1_4_5_5 = tys_p1_4_5;
                auto file_p2_1_5_5 = file_p2_1_5;
                entered(once_job([=, srcs_p0_3_5_5 = std::move(srcs_p0_3_5_5), tys_p1_4_5_5 = std::move(tys_p1_4_5_5), file_p2_1_5_5 = std::move(file_p2_1_5_5)]() {
                return ({
                    auto e_p7 = p0;
                    (prism_rtl::more(prism_rtl::rc(ExprLine(srcs_p0_3_5_5, tys_p1_4_5_5, crate::check::typed::SrcAt{.file = file_p2_1_5_5, .span = prism_rtl::deref(e_p7).span}))));
                });
            }));
            });
        })));
        })), [=](Array<Text> each_6391) { return prism_rtl::finished(concat(each_6391)); });
        });
    });
}


/// `Start ExprsOfFile, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_exprs_of_file(Array<crate::check::errors::Src> srcs_p0, Map<Text, crate::check::types::Ty> tys_p1, Nat file_p2, crate::syntax::Module m_p3) {
    return prism_rtl::make_rc<ExprsOfFile>(srcs_p0, tys_p1, file_p2, m_p3);
}


/// ExprLine: unbounded fn [Src], (Text ==> Ty), SrcAt -> Text
Text expr_line(const Array<crate::check::errors::Src>& srcs_p0, const Map<Text, crate::check::types::Ty>& tys_p1, const crate::check::typed::SrcAt& a_p2) {
    return prism_rtl::cat("  (expr ", at_text(srcs_p0, a_p2), " ", ty_sexp(or_(crate::prelude::get(tys_p1, crate::check::typed::at_key(a_p2)), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), ")\n");
}


prism_rtl::Turn<Text> ExprLine::cycle() const {
    const auto& srcs_p0 = this->srcs_p0;
    const auto& tys_p1 = this->tys_p1;
    const auto& a_p2 = this->a_p2;
    auto a_p2_1 = a_p2;
    auto srcs_p0_2 = srcs_p0;
    auto tys_p1_3 = tys_p1;
    return call_then(start_ty_sexp(or_(crate::prelude::get(tys_p1_3, crate::check::typed::at_key(a_p2_1)), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](Text ty_sexp_6570) { return prism_rtl::finished(prism_rtl::cat("  (expr ", at_text(srcs_p0_2, a_p2_1), " ", ty_sexp_6570, ")\n")); });
}


/// `Start ExprLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_expr_line(Array<crate::check::errors::Src> srcs_p0, Map<Text, crate::check::types::Ty> tys_p1, crate::check::typed::SrcAt a_p2) {
    return prism_rtl::make_rc<ExprLine>(srcs_p0, tys_p1, a_p2);
}


/// DeclExprs: unbounded fn Decl -> [Expr]
Array<crate::syntax::Expr> decl_exprs(const crate::syntax::decls::Decl& d_p0) {
    auto&& _m = d_p0.kind;
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DFn>(_m)) {
        auto&& f_p1 = prism_rtl::as<crate::syntax::decls::DeclKind::DFn>(_m).a0;
        return body_exprs(prism_rtl::deref(f_p1).body);
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DLet>(_m)) {
        auto&& l_p2 = prism_rtl::as<crate::syntax::decls::DeclKind::DLet>(_m).a0;
        return exprs_in(l_p2->value);
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DWidget>(_m)) {
        auto&& w_p3 = prism_rtl::as<crate::syntax::decls::DeclKind::DWidget>(_m).a0;
        return stmts_exprs(prism_rtl::deref(prism_rtl::deref(w_p3).body).stmts);
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DTrait>(_m)) {
        auto&& t_p4 = prism_rtl::as<crate::syntax::decls::DeclKind::DTrait>(_m).a0;
        return run_to_end(fold_job(prism_rtl::deref(t_p4).items, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc_p5 = p0;
                    auto it_p6 = p1;
                    ({
                    prism_rtl::is<crate::syntax::decls::TraitItem::TiFn>(it_p6) ? ({
                    auto&& f_p7 = prism_rtl::as<crate::syntax::decls::TraitItem::TiFn>(it_p6).a0;
                    ({
                    auto f_p7_1 = f_p7;
                    call_then(start_body_exprs(prism_rtl::deref(f_p7_1).body), [=](Array<crate::syntax::Expr> body_exprs_6857) { return prism_rtl::finished(append(acc_p5, body_exprs_6857)); });
                });
                })
                    : prism_rtl::finished(acc_p5);
                });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DImpl>(_m)) {
        auto&& i_p8 = prism_rtl::as<crate::syntax::decls::DeclKind::DImpl>(_m).a0;
        return run_to_end(fold_job(prism_rtl::deref(i_p8).items, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc_p9 = p0;
                    auto it_pa = p1;
                    ({
                    prism_rtl::is<crate::syntax::decls::TraitItem::TiFn>(it_pa) ? ({
                    auto&& f_pb = prism_rtl::as<crate::syntax::decls::TraitItem::TiFn>(it_pa).a0;
                    ({
                    auto f_pb_1 = f_pb;
                    call_then(start_body_exprs(prism_rtl::deref(f_pb_1).body), [=](Array<crate::syntax::Expr> body_exprs_6981) { return prism_rtl::finished(append(acc_p9, body_exprs_6981)); });
                });
                })
                    : prism_rtl::finished(acc_p9);
                });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DCheck>(_m)) {
        auto&& c_pc = prism_rtl::as<crate::syntax::decls::DeclKind::DCheck>(_m).a0;
        return run_to_end(fold_job(prism_rtl::deref(c_pc).lines, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::CheckLine>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::CheckLine> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc_pd = p0;
                    auto l_pe = p1;
                    call_then(start_exprs_in(prism_rtl::deref(l_pe).expr), [=, acc_pd = std::move(acc_pd)](Array<crate::syntax::Expr> exprs_in_7079) { return prism_rtl::finished(append(acc_pd, exprs_in_7079)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DTest>(_m)) {
        auto&& t_pf = prism_rtl::as<crate::syntax::decls::DeclKind::DTest>(_m).a0;
        return exprs_in(prism_rtl::deref(t_pf).blueprint);
    }
    {
        return Array<crate::syntax::Expr>{};
    }
}


prism_rtl::Turn<Array<crate::syntax::Expr>> DeclExprs::cycle() const {
    const auto& d_p0 = this->d_p0;
    return ({
        auto&& _m = prism_rtl::deref(d_p0).kind;
        prism_rtl::is<crate::syntax::decls::DeclKind::DFn>(_m) ? ({
        auto&& f_p1 = prism_rtl::as<crate::syntax::decls::DeclKind::DFn>(_m).a0;
        prism_rtl::more(prism_rtl::rc(BodyExprs(prism_rtl::deref(f_p1).body)));
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DLet>(_m) ? ({
        auto&& l_p2 = prism_rtl::as<crate::syntax::decls::DeclKind::DLet>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ExprsIn(l_p2->value)));
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DWidget>(_m) ? ({
        auto&& w_p3 = prism_rtl::as<crate::syntax::decls::DeclKind::DWidget>(_m).a0;
        prism_rtl::more(prism_rtl::rc(StmtsExprs(prism_rtl::deref(prism_rtl::deref(w_p3).body).stmts)));
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DTrait>(_m) ? ({
        auto&& t_p4 = prism_rtl::as<crate::syntax::decls::DeclKind::DTrait>(_m).a0;
        fold_job(prism_rtl::deref(t_p4).items, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_p5 = p0;
                auto it_p6 = p1;
                ({
                prism_rtl::is<crate::syntax::decls::TraitItem::TiFn>(it_p6) ? ({
                auto&& f_p7 = prism_rtl::as<crate::syntax::decls::TraitItem::TiFn>(it_p6).a0;
                ({
                auto f_p7_1 = f_p7;
                call_then(start_body_exprs(prism_rtl::deref(f_p7_1).body), [=](Array<crate::syntax::Expr> body_exprs_6857) { return prism_rtl::finished(append(acc_p5, body_exprs_6857)); });
            });
            })
                : prism_rtl::finished(acc_p5);
            });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DImpl>(_m) ? ({
        auto&& i_p8 = prism_rtl::as<crate::syntax::decls::DeclKind::DImpl>(_m).a0;
        fold_job(prism_rtl::deref(i_p8).items, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_p9 = p0;
                auto it_pa = p1;
                ({
                prism_rtl::is<crate::syntax::decls::TraitItem::TiFn>(it_pa) ? ({
                auto&& f_pb = prism_rtl::as<crate::syntax::decls::TraitItem::TiFn>(it_pa).a0;
                ({
                auto f_pb_1 = f_pb;
                call_then(start_body_exprs(prism_rtl::deref(f_pb_1).body), [=](Array<crate::syntax::Expr> body_exprs_6981) { return prism_rtl::finished(append(acc_p9, body_exprs_6981)); });
            });
            })
                : prism_rtl::finished(acc_p9);
            });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DCheck>(_m) ? ({
        auto&& c_pc = prism_rtl::as<crate::syntax::decls::DeclKind::DCheck>(_m).a0;
        fold_job(prism_rtl::deref(c_pc).lines, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::CheckLine>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::CheckLine> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_pd = p0;
                auto l_pe = p1;
                call_then(start_exprs_in(prism_rtl::deref(l_pe).expr), [=, acc_pd = std::move(acc_pd)](Array<crate::syntax::Expr> exprs_in_7079) { return prism_rtl::finished(append(acc_pd, exprs_in_7079)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DTest>(_m) ? ({
        auto&& t_pf = prism_rtl::as<crate::syntax::decls::DeclKind::DTest>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ExprsIn(prism_rtl::deref(t_pf).blueprint)));
    })
        : prism_rtl::finished(Array<crate::syntax::Expr>{});
    });
}


/// `Start DeclExprs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::syntax::Expr>> start_decl_exprs(crate::syntax::decls::Decl d_p0) {
    return prism_rtl::make_rc<DeclExprs>(d_p0);
}


/// BodyExprs: unbounded fn FnBody -> [Expr]
Array<crate::syntax::Expr> body_exprs(const crate::syntax::decls::FnBody& fn_body0) {
    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(fn_body0)) {
        auto&& e_p0 = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(fn_body0).a0;
        return exprs_in(e_p0);
    }
    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(fn_body0)) {
        auto&& b_p1 = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(fn_body0).a0;
        return stmts_exprs(prism_rtl::deref(b_p1).stmts);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<crate::syntax::Expr>> BodyExprs::cycle() const {
    const auto& fn_body0 = this->fn_body0;
    return ({
        prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(fn_body0) ? ({
        auto&& e_p0 = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(fn_body0).a0;
        prism_rtl::more(prism_rtl::rc(ExprsIn(e_p0)));
    })
        : prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(fn_body0) ? ({
        auto&& b_p1 = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(fn_body0).a0;
        prism_rtl::more(prism_rtl::rc(StmtsExprs(prism_rtl::deref(b_p1).stmts)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start BodyExprs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::syntax::Expr>> start_body_exprs(crate::syntax::decls::FnBody fn_body0) {
    return prism_rtl::make_rc<BodyExprs>(fn_body0);
}


/// StmtsExprs: unbounded fn [Stmt] -> [Expr]
Array<crate::syntax::Expr> stmts_exprs(const Array<crate::syntax::Stmt>& stmts_p0) {
    return run_to_end(fold_job(stmts_p0, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_p1 = p0;
                auto s_p2 = p1;
                call_then(start_stmt_exprs(s_p2), [=, acc_p1 = std::move(acc_p1)](Array<crate::syntax::Expr> stmt_exprs_7382) { return prism_rtl::finished(append(acc_p1, stmt_exprs_7382)); });
            });
        }));
    }))));
}


prism_rtl::Turn<Array<crate::syntax::Expr>> StmtsExprs::cycle() const {
    const auto& stmts_p0 = this->stmts_p0;
    return fold_job(stmts_p0, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_p1 = p0;
                auto s_p2 = p1;
                call_then(start_stmt_exprs(s_p2), [=, acc_p1 = std::move(acc_p1)](Array<crate::syntax::Expr> stmt_exprs_7382) { return prism_rtl::finished(append(acc_p1, stmt_exprs_7382)); });
            });
        }));
    })))->cycle();
}


/// `Start StmtsExprs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::syntax::Expr>> start_stmts_exprs(Array<crate::syntax::Stmt> stmts_p0) {
    return prism_rtl::make_rc<StmtsExprs>(stmts_p0);
}


/// StmtExprs: unbounded fn Stmt -> [Expr]
Array<crate::syntax::Expr> stmt_exprs(const crate::syntax::Stmt& s_p0) {
    auto&& _m = s_p0.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m)) {
        auto&& e_p1 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        auto&& t_o2 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2;
        if (prism_rtl::is_some(t_o2)) {
            auto&& x_p3 = prism_rtl::some_of(t_o2);
            return append(exprs_in(e_p1), exprs_in(x_p3));
        }
        if (prism_rtl::is_none(t_o2)) {
            return exprs_in(e_p1);
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SIgnore>(_m)) {
        auto&& e_p4 = prism_rtl::as<crate::syntax::StmtKind::SIgnore>(_m).a0;
        return exprs_in(e_p4);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& e_p5 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        return exprs_in(e_p5);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        auto&& f_p6 = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        return body_exprs(prism_rtl::deref(f_p6).body);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m)) {
        auto&& w_p7 = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
        return stmts_exprs(prism_rtl::deref(prism_rtl::deref(w_p7).body).stmts);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SSet>(_m)) {
        auto&& t_p8 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
        auto&& v_p9 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
        return append(exprs_in(t_p8), exprs_in(v_p9));
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m)) {
        auto&& t_pa = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
        auto&& v_pb = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a2;
        return append(exprs_in(t_pa), exprs_in(v_pb));
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SRequire>(_m)) {
        auto&& c_pc = prism_rtl::as<crate::syntax::StmtKind::SRequire>(_m).a0;
        return exprs_in(c_pc);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SForbid>(_m)) {
        auto&& c_pd = prism_rtl::as<crate::syntax::StmtKind::SForbid>(_m).a0;
        return exprs_in(c_pd);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m)) {
        auto&& c_pe = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
        auto&& b_pf = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
        return append(cond_exprs(c_pe), stmts_exprs(prism_rtl::deref(b_pf).stmts));
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SReturn>(_m)) {
        auto&& e_pg = prism_rtl::as<crate::syntax::StmtKind::SReturn>(_m).a0;
        return exprs_in(e_pg);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
        auto&& e_ph = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        return exprs_in(e_ph);
    }
    {
        return Array<crate::syntax::Expr>{};
    }
}


prism_rtl::Turn<Array<crate::syntax::Expr>> StmtExprs::cycle() const {
    const auto& s_p0 = this->s_p0;
    return ({
        auto&& _m = prism_rtl::deref(s_p0).kind;
        prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) ? ({
        auto&& e_p1 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        auto&& t_o2 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2;
        ({
        prism_rtl::is_some(t_o2) ? ({
        auto&& x_p3 = prism_rtl::some_of(t_o2);
        ({
        auto e_p1_1 = e_p1;
        auto x_p3_2 = x_p3;
        call_then(start_exprs_in(e_p1_1), [=, x_p3_2 = std::move(x_p3_2)](Array<crate::syntax::Expr> exprs_in_7522) { return call_then(start_exprs_in(x_p3_2), [=](Array<crate::syntax::Expr> exprs_in_7535) { return prism_rtl::finished(append(exprs_in_7522, exprs_in_7535)); }); });
    });
    })
        : prism_rtl::is_none(t_o2) ? prism_rtl::more(prism_rtl::rc(ExprsIn(e_p1)))
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SIgnore>(_m) ? ({
        auto&& e_p4 = prism_rtl::as<crate::syntax::StmtKind::SIgnore>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ExprsIn(e_p4)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& e_p5 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        prism_rtl::more(prism_rtl::rc(ExprsIn(e_p5)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? ({
        auto&& f_p6 = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        prism_rtl::more(prism_rtl::rc(BodyExprs(prism_rtl::deref(f_p6).body)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m) ? ({
        auto&& w_p7 = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
        prism_rtl::more(prism_rtl::rc(StmtsExprs(prism_rtl::deref(prism_rtl::deref(w_p7).body).stmts)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SSet>(_m) ? ({
        auto&& t_p8 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
        auto&& v_p9 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
        ({
        auto t_p8_1 = t_p8;
        auto v_p9_2 = v_p9;
        call_then(start_exprs_in(t_p8_1), [=, v_p9_2 = std::move(v_p9_2)](Array<crate::syntax::Expr> exprs_in_7722) { return call_then(start_exprs_in(v_p9_2), [=](Array<crate::syntax::Expr> exprs_in_7735) { return prism_rtl::finished(append(exprs_in_7722, exprs_in_7735)); }); });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m) ? ({
        auto&& t_pa = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
        auto&& v_pb = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a2;
        ({
        auto t_pa_1 = t_pa;
        auto v_pb_2 = v_pb;
        call_then(start_exprs_in(t_pa_1), [=, v_pb_2 = std::move(v_pb_2)](Array<crate::syntax::Expr> exprs_in_7779) { return call_then(start_exprs_in(v_pb_2), [=](Array<crate::syntax::Expr> exprs_in_7792) { return prism_rtl::finished(append(exprs_in_7779, exprs_in_7792)); }); });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SRequire>(_m) ? ({
        auto&& c_pc = prism_rtl::as<crate::syntax::StmtKind::SRequire>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ExprsIn(c_pc)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SForbid>(_m) ? ({
        auto&& c_pd = prism_rtl::as<crate::syntax::StmtKind::SForbid>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ExprsIn(c_pd)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m) ? ({
        auto&& c_pe = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
        auto&& b_pf = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
        ({
        auto b_pf_1 = b_pf;
        auto c_pe_2 = c_pe;
        call_then(start_cond_exprs(c_pe_2), [=, b_pf_1 = std::move(b_pf_1)](Array<crate::syntax::Expr> cond_exprs_7879) { return call_then(start_stmts_exprs(prism_rtl::deref(b_pf_1).stmts), [=](Array<crate::syntax::Expr> stmts_exprs_7894) { return prism_rtl::finished(append(cond_exprs_7879, stmts_exprs_7894)); }); });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SReturn>(_m) ? ({
        auto&& e_pg = prism_rtl::as<crate::syntax::StmtKind::SReturn>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ExprsIn(e_pg)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
        auto&& e_ph = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ExprsIn(e_ph)));
    })
        : prism_rtl::finished(Array<crate::syntax::Expr>{});
    });
}


/// `Start StmtExprs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::syntax::Expr>> start_stmt_exprs(crate::syntax::Stmt s_p0) {
    return prism_rtl::make_rc<StmtExprs>(s_p0);
}


/// CondExprs: unbounded fn Cond -> [Expr]
Array<crate::syntax::Expr> cond_exprs(const crate::syntax::Cond& cond0) {
    if (prism_rtl::is<crate::syntax::Cond::CondExpr>(cond0)) {
        auto&& e_p0 = prism_rtl::as<crate::syntax::Cond::CondExpr>(cond0).a0;
        return exprs_in(prism_rtl::deref(prism_rtl::deref(e_p0)));
    }
    if (prism_rtl::is<crate::syntax::Cond::CondBind>(cond0)) {
        auto&& e_p1 = prism_rtl::as<crate::syntax::Cond::CondBind>(cond0).a1;
        auto&& g_o2 = prism_rtl::as<crate::syntax::Cond::CondBind>(cond0).a2;
        return append(exprs_in(prism_rtl::deref(prism_rtl::deref(e_p1))), opt_exprs(prism_rtl::deref(prism_rtl::deref(g_o2))));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<crate::syntax::Expr>> CondExprs::cycle() const {
    const auto& cond0 = this->cond0;
    return ({
        prism_rtl::is<crate::syntax::Cond::CondExpr>(cond0) ? ({
        auto&& e_p0 = prism_rtl::as<crate::syntax::Cond::CondExpr>(cond0).a0;
        prism_rtl::more(prism_rtl::rc(ExprsIn(prism_rtl::deref(prism_rtl::deref(e_p0)))));
    })
        : prism_rtl::is<crate::syntax::Cond::CondBind>(cond0) ? ({
        auto&& e_p1 = prism_rtl::as<crate::syntax::Cond::CondBind>(cond0).a1;
        auto&& g_o2 = prism_rtl::as<crate::syntax::Cond::CondBind>(cond0).a2;
        ({
        auto g_o2_1 = prism_rtl::deref(prism_rtl::deref(g_o2));
        auto e_p1_2 = prism_rtl::deref(prism_rtl::deref(e_p1));
        call_then(start_exprs_in(e_p1_2), [=, g_o2_1 = std::move(g_o2_1)](Array<crate::syntax::Expr> exprs_in_8108) { return call_then(start_opt_exprs(g_o2_1), [=](Array<crate::syntax::Expr> opt_exprs_8121) { return prism_rtl::finished(append(exprs_in_8108, opt_exprs_8121)); }); });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CondExprs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::syntax::Expr>> start_cond_exprs(crate::syntax::Cond cond0) {
    return prism_rtl::make_rc<CondExprs>(cond0);
}


/// ArgsExprs: unbounded fn [Arg] -> [Expr]
Array<crate::syntax::Expr> args_exprs(const Array<crate::syntax::Arg>& args_p0) {
    return run_to_end(fold_job(args_p0, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::Arg>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::Arg> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_p1 = p0;
                auto a_p2 = p1;
                call_then(start_exprs_in(a_p2->value), [=, acc_p1 = std::move(acc_p1)](Array<crate::syntax::Expr> exprs_in_8235) { return prism_rtl::finished(append(acc_p1, exprs_in_8235)); });
            });
        }));
    }))));
}


prism_rtl::Turn<Array<crate::syntax::Expr>> ArgsExprs::cycle() const {
    const auto& args_p0 = this->args_p0;
    return fold_job(args_p0, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::Arg>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::Arg> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_p1 = p0;
                auto a_p2 = p1;
                call_then(start_exprs_in(a_p2->value), [=, acc_p1 = std::move(acc_p1)](Array<crate::syntax::Expr> exprs_in_8235) { return prism_rtl::finished(append(acc_p1, exprs_in_8235)); });
            });
        }));
    })))->cycle();
}


/// `Start ArgsExprs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::syntax::Expr>> start_args_exprs(Array<crate::syntax::Arg> args_p0) {
    return prism_rtl::make_rc<ArgsExprs>(args_p0);
}


/// BlockExprs: unbounded fn Block -> [Expr]
Array<crate::syntax::Expr> block_exprs(const crate::syntax::Block& b_p0) {
    return stmts_exprs(b_p0.stmts);
}


prism_rtl::Turn<Array<crate::syntax::Expr>> BlockExprs::cycle() const {
    const auto& b_p0 = this->b_p0;
    return prism_rtl::more(prism_rtl::rc(StmtsExprs(prism_rtl::deref(b_p0).stmts)));
}


/// `Start BlockExprs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::syntax::Expr>> start_block_exprs(crate::syntax::Block b_p0) {
    return prism_rtl::make_rc<BlockExprs>(b_p0);
}


/// ExprsIn: unbounded fn Expr -> [Expr]
Array<crate::syntax::Expr> exprs_in(const crate::syntax::Expr& e_p0) {
    auto inner_p1 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
        auto&& _m = prism_rtl::deref(e_p0.kind);
        if (prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m)) {
            auto&& es_p2 = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
            _v.set(run_to_end(fold_job(es_p2, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::Expr> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc_p3 = p0;
                        auto x_p4 = p1;
                        call_then(start_exprs_in(x_p4), [=, acc_p3 = std::move(acc_p3)](Array<crate::syntax::Expr> exprs_in_8621) { return prism_rtl::finished(append(acc_p3, exprs_in_8621)); });
                    });
                }));
            })))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EArray>(_m)) {
            auto&& es_p5 = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
            _v.set(run_to_end(fold_job(es_p5, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::Expr> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc_p6 = p0;
                        auto x_p7 = p1;
                        call_then(start_exprs_in(x_p7), [=, acc_p6 = std::move(acc_p6)](Array<crate::syntax::Expr> exprs_in_8689) { return prism_rtl::finished(append(acc_p6, exprs_in_8689)); });
                    });
                }));
            })))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMap>(_m)) {
            auto&& kvs_p8 = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
            _v.set(run_to_end(fold_job(kvs_p8, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, std::tuple<crate::syntax::Expr, crate::syntax::Expr>>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, std::tuple<crate::syntax::Expr, crate::syntax::Expr>> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc_p9 = p0;
                        auto [k_pa, v_pb] = p1;
                        call_then(start_exprs_in(k_pa), [=, acc_p9 = std::move(acc_p9)](Array<crate::syntax::Expr> exprs_in_8772) { return call_then(start_exprs_in(v_pb), [=](Array<crate::syntax::Expr> exprs_in_8786) { return prism_rtl::finished(append(append(acc_p9, exprs_in_8772), exprs_in_8786)); }); });
                    });
                }));
            })))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
            auto&& x_pc = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
            _v.set(exprs_in(prism_rtl::deref(prism_rtl::deref(x_pc))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
            auto&& c_pd = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
            auto&& args_pe = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
            _v.set(append(exprs_in(prism_rtl::deref(prism_rtl::deref(c_pd))), args_exprs(args_pe)));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
            auto&& l_pf = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
            auto&& r_pg = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
            _v.set(append(exprs_in(prism_rtl::deref(prism_rtl::deref(l_pf))), exprs_in(prism_rtl::deref(prism_rtl::deref(r_pg)))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m)) {
            auto&& x_ph = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
            _v.set(exprs_in(prism_rtl::deref(prism_rtl::deref(x_ph))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
            auto&& x_pi = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
            _v.set(exprs_in(prism_rtl::deref(prism_rtl::deref(x_pi))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
            auto&& r_pj = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
            _v.set(exprs_in(prism_rtl::deref(prism_rtl::deref(r_pj))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
            auto&& r_pk = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
            auto&& i_pl = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
            _v.set(append(exprs_in(prism_rtl::deref(prism_rtl::deref(r_pk))), exprs_in(prism_rtl::deref(prism_rtl::deref(i_pl)))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ETopicIndex>(_m)) {
            auto&& x_pm = prism_rtl::as<crate::syntax::ExprKind::ETopicIndex>(_m).a0;
            _v.set(exprs_in(prism_rtl::deref(prism_rtl::deref(x_pm))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m)) {
            auto&& r_pn = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
            auto&& args_po = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
            _v.set(append(exprs_in(prism_rtl::deref(prism_rtl::deref(r_pn))), args_exprs(args_po)));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m)) {
            auto&& x_pp = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
            _v.set(exprs_in(prism_rtl::deref(prism_rtl::deref(x_pp))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ECast>(_m)) {
            auto&& x_pq = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a0;
            _v.set(exprs_in(prism_rtl::deref(prism_rtl::deref(x_pq))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
            auto&& body_pr = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
                auto&& _m = prism_rtl::deref(prism_rtl::deref(body_pr));
                if (prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(_m)) {
                    auto&& x_ps = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(_m).a0;
                    _v.set(exprs_in(prism_rtl::deref(prism_rtl::deref(x_ps))));
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(_m)) {
                    auto&& b_pt = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(_m).a0;
                    _v.set(block_exprs(b_pt));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
            auto&& c_pu = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
            auto&& t_pv = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
            auto&& el_o10 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
            _v.set(append(append(cond_exprs(prism_rtl::deref(prism_rtl::deref(c_pu))), block_exprs(t_pv)), opt_block_exprs(el_o10)));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
            auto&& s_p11 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
            auto&& arms_p12 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
            _v.set(run_to_end(fold_job(arms_p12, exprs_in(prism_rtl::deref(prism_rtl::deref(s_p11))), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::Arm> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc_p13 = p0;
                        auto a_p14 = p1;
                        call_then(start_opt_exprs(prism_rtl::deref(a_p14).guard), [=, acc_p13 = std::move(acc_p13)](Array<crate::syntax::Expr> opt_exprs_9600) { return call_then(start_block_exprs(prism_rtl::deref(a_p14).body), [=](Array<crate::syntax::Expr> block_exprs_9622) { return prism_rtl::finished(append(append(acc_p13, opt_exprs_9600), block_exprs_9622)); }); });
                    });
                }));
            })))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ERebuild>(_m)) {
            auto&& s_p15 = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a0;
            auto&& b_p16 = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a1;
            _v.set(append(exprs_in(prism_rtl::deref(prism_rtl::deref(s_p15))), block_exprs(b_p16)));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EFor>(_m)) {
            auto&& s_p17 = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
            auto&& b_p18 = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
            _v.set(append(exprs_in(prism_rtl::deref(prism_rtl::deref(s_p17))), block_exprs(b_p18)));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EGiven>(_m)) {
            auto&& b_p19 = prism_rtl::as<crate::syntax::ExprKind::EGiven>(_m).a0;
            _v.set(block_exprs(b_p19));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m)) {
            auto&& t_p1a = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
            auto&& b_p1b = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
            _v.set(append(exprs_in(prism_rtl::deref(prism_rtl::deref(t_p1a))), block_exprs(b_p1b)));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m)) {
            auto&& b_p1c = prism_rtl::as<crate::syntax::ExprKind::EWidgetBlock>(_m).a0;
            _v.set(block_exprs(b_p1c));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EAny>(_m)) {
            auto&& x_p1d = prism_rtl::as<crate::syntax::ExprKind::EAny>(_m).a0;
            _v.set(exprs_in(prism_rtl::deref(prism_rtl::deref(x_p1d))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ELit>(_m)) {
            auto&& l_p1e = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
                auto&& _m = prism_rtl::deref(l_p1e).kind;
                if (prism_rtl::is<crate::syntax::LitKind::LText>(_m)) {
                    auto&& segs_p1f = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
                    _v.set(run_to_end(fold_job(segs_p1f, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::TextSeg>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::TextSeg> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return entered(once_job([=]() {
                            return ({
                                auto acc_p1g = p0;
                                auto sg_p1h = p1;
                                ({
                                prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(sg_p1h) ? ({
                                auto&& x_p1i = prism_rtl::as<crate::syntax::TextSeg::SegPlaceholder>(sg_p1h).a0;
                                ({
                                auto x_p1i_1 = x_p1i;
                                call_then(start_exprs_in(x_p1i_1), [=](Array<crate::syntax::Expr> exprs_in_10051) { return prism_rtl::finished(append(acc_p1g, exprs_in_10051)); });
                            });
                            })
                                : prism_rtl::finished(acc_p1g);
                            });
                            });
                        }));
                    })))));
                    goto _done;
                }
                {
                    _v.set(Array<crate::syntax::Expr>{});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ETemplate>(_m)) {
            auto&& t_p1j = prism_rtl::as<crate::syntax::ExprKind::ETemplate>(_m).a0;
            _v.set(template_exprs(prism_rtl::deref(t_p1j).parts));
            goto _done;
        }
        {
            _v.set(Array<crate::syntax::Expr>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto&& _m = prism_rtl::deref(e_p0.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::ERest>(_m)) {
        return inner_p1;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EError>(_m)) {
        return inner_p1;
    }
    {
        return append(Array(std::vector{e_p0}), inner_p1);
    }
}


prism_rtl::Turn<Array<crate::syntax::Expr>> ExprsIn::cycle() const {
    const auto& e_p0 = this->e_p0;
    auto inner_p1 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p0).kind);
        if (prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m)) {
            auto&& es_p2 = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
            _v.set(run_to_end(fold_job(es_p2, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::Expr> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc_p3 = p0;
                        auto x_p4 = p1;
                        call_then(start_exprs_in(x_p4), [=, acc_p3 = std::move(acc_p3)](Array<crate::syntax::Expr> exprs_in_8621) { return prism_rtl::finished(append(acc_p3, exprs_in_8621)); });
                    });
                }));
            })))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EArray>(_m)) {
            auto&& es_p5 = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
            _v.set(run_to_end(fold_job(es_p5, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::Expr> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc_p6 = p0;
                        auto x_p7 = p1;
                        call_then(start_exprs_in(x_p7), [=, acc_p6 = std::move(acc_p6)](Array<crate::syntax::Expr> exprs_in_8689) { return prism_rtl::finished(append(acc_p6, exprs_in_8689)); });
                    });
                }));
            })))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMap>(_m)) {
            auto&& kvs_p8 = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
            _v.set(run_to_end(fold_job(kvs_p8, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, std::tuple<crate::syntax::Expr, crate::syntax::Expr>>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, std::tuple<crate::syntax::Expr, crate::syntax::Expr>> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc_p9 = p0;
                        auto [k_pa, v_pb] = p1;
                        call_then(start_exprs_in(k_pa), [=, acc_p9 = std::move(acc_p9)](Array<crate::syntax::Expr> exprs_in_8772) { return call_then(start_exprs_in(v_pb), [=](Array<crate::syntax::Expr> exprs_in_8786) { return prism_rtl::finished(append(append(acc_p9, exprs_in_8772), exprs_in_8786)); }); });
                    });
                }));
            })))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
            auto&& x_pc = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
            _v.set(exprs_in(prism_rtl::deref(prism_rtl::deref(x_pc))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
            auto&& c_pd = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
            auto&& args_pe = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
            _v.set(append(exprs_in(prism_rtl::deref(prism_rtl::deref(c_pd))), args_exprs(args_pe)));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
            auto&& l_pf = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
            auto&& r_pg = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
            _v.set(append(exprs_in(prism_rtl::deref(prism_rtl::deref(l_pf))), exprs_in(prism_rtl::deref(prism_rtl::deref(r_pg)))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m)) {
            auto&& x_ph = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
            _v.set(exprs_in(prism_rtl::deref(prism_rtl::deref(x_ph))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
            auto&& x_pi = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
            _v.set(exprs_in(prism_rtl::deref(prism_rtl::deref(x_pi))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
            auto&& r_pj = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
            _v.set(exprs_in(prism_rtl::deref(prism_rtl::deref(r_pj))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
            auto&& r_pk = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
            auto&& i_pl = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
            _v.set(append(exprs_in(prism_rtl::deref(prism_rtl::deref(r_pk))), exprs_in(prism_rtl::deref(prism_rtl::deref(i_pl)))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ETopicIndex>(_m)) {
            auto&& x_pm = prism_rtl::as<crate::syntax::ExprKind::ETopicIndex>(_m).a0;
            _v.set(exprs_in(prism_rtl::deref(prism_rtl::deref(x_pm))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m)) {
            auto&& r_pn = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
            auto&& args_po = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
            _v.set(append(exprs_in(prism_rtl::deref(prism_rtl::deref(r_pn))), args_exprs(args_po)));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m)) {
            auto&& x_pp = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
            _v.set(exprs_in(prism_rtl::deref(prism_rtl::deref(x_pp))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ECast>(_m)) {
            auto&& x_pq = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a0;
            _v.set(exprs_in(prism_rtl::deref(prism_rtl::deref(x_pq))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
            auto&& body_pr = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
                auto&& _m = prism_rtl::deref(prism_rtl::deref(body_pr));
                if (prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(_m)) {
                    auto&& x_ps = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(_m).a0;
                    _v.set(exprs_in(prism_rtl::deref(prism_rtl::deref(x_ps))));
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(_m)) {
                    auto&& b_pt = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(_m).a0;
                    _v.set(block_exprs(b_pt));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
            auto&& c_pu = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
            auto&& t_pv = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
            auto&& el_o10 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
            _v.set(append(append(cond_exprs(prism_rtl::deref(prism_rtl::deref(c_pu))), block_exprs(t_pv)), opt_block_exprs(el_o10)));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
            auto&& s_p11 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
            auto&& arms_p12 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
            _v.set(run_to_end(fold_job(arms_p12, exprs_in(prism_rtl::deref(prism_rtl::deref(s_p11))), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::Arm> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc_p13 = p0;
                        auto a_p14 = p1;
                        call_then(start_opt_exprs(prism_rtl::deref(a_p14).guard), [=, acc_p13 = std::move(acc_p13)](Array<crate::syntax::Expr> opt_exprs_9600) { return call_then(start_block_exprs(prism_rtl::deref(a_p14).body), [=](Array<crate::syntax::Expr> block_exprs_9622) { return prism_rtl::finished(append(append(acc_p13, opt_exprs_9600), block_exprs_9622)); }); });
                    });
                }));
            })))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ERebuild>(_m)) {
            auto&& s_p15 = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a0;
            auto&& b_p16 = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a1;
            _v.set(append(exprs_in(prism_rtl::deref(prism_rtl::deref(s_p15))), block_exprs(b_p16)));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EFor>(_m)) {
            auto&& s_p17 = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
            auto&& b_p18 = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
            _v.set(append(exprs_in(prism_rtl::deref(prism_rtl::deref(s_p17))), block_exprs(b_p18)));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EGiven>(_m)) {
            auto&& b_p19 = prism_rtl::as<crate::syntax::ExprKind::EGiven>(_m).a0;
            _v.set(block_exprs(b_p19));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m)) {
            auto&& t_p1a = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
            auto&& b_p1b = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
            _v.set(append(exprs_in(prism_rtl::deref(prism_rtl::deref(t_p1a))), block_exprs(b_p1b)));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m)) {
            auto&& b_p1c = prism_rtl::as<crate::syntax::ExprKind::EWidgetBlock>(_m).a0;
            _v.set(block_exprs(b_p1c));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EAny>(_m)) {
            auto&& x_p1d = prism_rtl::as<crate::syntax::ExprKind::EAny>(_m).a0;
            _v.set(exprs_in(prism_rtl::deref(prism_rtl::deref(x_p1d))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ELit>(_m)) {
            auto&& l_p1e = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
                auto&& _m = prism_rtl::deref(l_p1e).kind;
                if (prism_rtl::is<crate::syntax::LitKind::LText>(_m)) {
                    auto&& segs_p1f = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
                    _v.set(run_to_end(fold_job(segs_p1f, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::TextSeg>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::TextSeg> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return entered(once_job([=]() {
                            return ({
                                auto acc_p1g = p0;
                                auto sg_p1h = p1;
                                ({
                                prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(sg_p1h) ? ({
                                auto&& x_p1i = prism_rtl::as<crate::syntax::TextSeg::SegPlaceholder>(sg_p1h).a0;
                                ({
                                auto x_p1i_1 = x_p1i;
                                call_then(start_exprs_in(x_p1i_1), [=](Array<crate::syntax::Expr> exprs_in_10051) { return prism_rtl::finished(append(acc_p1g, exprs_in_10051)); });
                            });
                            })
                                : prism_rtl::finished(acc_p1g);
                            });
                            });
                        }));
                    })))));
                    goto _done;
                }
                {
                    _v.set(Array<crate::syntax::Expr>{});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ETemplate>(_m)) {
            auto&& t_p1j = prism_rtl::as<crate::syntax::ExprKind::ETemplate>(_m).a0;
            _v.set(template_exprs(prism_rtl::deref(t_p1j).parts));
            goto _done;
        }
        {
            _v.set(Array<crate::syntax::Expr>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p0).kind);
        prism_rtl::is<crate::syntax::ExprKind::ERest>(_m) ? prism_rtl::finished(inner_p1)
        : prism_rtl::is<crate::syntax::ExprKind::EError>(_m) ? prism_rtl::finished(inner_p1)
        : prism_rtl::finished(append(Array(std::vector{e_p0}), inner_p1));
    });
}


/// `Start ExprsIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::syntax::Expr>> start_exprs_in(crate::syntax::Expr e_p0) {
    return prism_rtl::make_rc<ExprsIn>(e_p0);
}


/// TemplateExprs: unbounded fn [TemplatePart] -> [Expr]
Array<crate::syntax::Expr> template_exprs(const Array<crate::syntax::TemplatePart>& parts_p0) {
    return run_to_end(fold_job(parts_p0, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::TemplatePart>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::TemplatePart> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_p1 = p0;
                auto p_p2 = p1;
                ({
                prism_rtl::is<crate::syntax::TemplatePart::TpPlaceholder>(p_p2) ? ({
                auto&& x_p3 = prism_rtl::as<crate::syntax::TemplatePart::TpPlaceholder>(p_p2).a0;
                ({
                auto x_p3_1 = x_p3;
                call_then(start_exprs_in(x_p3_1), [=](Array<crate::syntax::Expr> exprs_in_10446) { return prism_rtl::finished(append(acc_p1, exprs_in_10446)); });
            });
            })
                : prism_rtl::is<crate::syntax::TemplatePart::TpBlock>(p_p2) ? ({
                auto&& b_p4 = prism_rtl::as<crate::syntax::TemplatePart::TpBlock>(p_p2).a0;
                ({
                auto b_p4_1 = b_p4;
                call_then(start_block_exprs(b_p4_1), [=](Array<crate::syntax::Expr> block_exprs_10485) { return prism_rtl::finished(append(acc_p1, block_exprs_10485)); });
            });
            })
                : prism_rtl::is<crate::syntax::TemplatePart::TpCall>(p_p2) ? ({
                auto&& args_p5 = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_p2).a1;
                auto&& ps_o6 = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_p2).a2;
                ({
                auto ps_o6_1 = ps_o6;
                auto args_p5_2 = args_p5;
                call_then(start_args_exprs(args_p5_2), [=, ps_o6_1 = std::move(ps_o6_1)](Array<crate::syntax::Expr> args_exprs_10558) { return call_then(start_opt_parts(ps_o6_1), [=](Array<crate::syntax::Expr> opt_parts_10577) { return prism_rtl::finished(append(append(acc_p1, args_exprs_10558), opt_parts_10577)); }); });
            });
            })
                : prism_rtl::finished(acc_p1);
            });
            });
        }));
    }))));
}


prism_rtl::Turn<Array<crate::syntax::Expr>> TemplateExprs::cycle() const {
    const auto& parts_p0 = this->parts_p0;
    return fold_job(parts_p0, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::TemplatePart>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::TemplatePart> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_p1 = p0;
                auto p_p2 = p1;
                ({
                prism_rtl::is<crate::syntax::TemplatePart::TpPlaceholder>(p_p2) ? ({
                auto&& x_p3 = prism_rtl::as<crate::syntax::TemplatePart::TpPlaceholder>(p_p2).a0;
                ({
                auto x_p3_1 = x_p3;
                call_then(start_exprs_in(x_p3_1), [=](Array<crate::syntax::Expr> exprs_in_10446) { return prism_rtl::finished(append(acc_p1, exprs_in_10446)); });
            });
            })
                : prism_rtl::is<crate::syntax::TemplatePart::TpBlock>(p_p2) ? ({
                auto&& b_p4 = prism_rtl::as<crate::syntax::TemplatePart::TpBlock>(p_p2).a0;
                ({
                auto b_p4_1 = b_p4;
                call_then(start_block_exprs(b_p4_1), [=](Array<crate::syntax::Expr> block_exprs_10485) { return prism_rtl::finished(append(acc_p1, block_exprs_10485)); });
            });
            })
                : prism_rtl::is<crate::syntax::TemplatePart::TpCall>(p_p2) ? ({
                auto&& args_p5 = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_p2).a1;
                auto&& ps_o6 = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_p2).a2;
                ({
                auto ps_o6_1 = ps_o6;
                auto args_p5_2 = args_p5;
                call_then(start_args_exprs(args_p5_2), [=, ps_o6_1 = std::move(ps_o6_1)](Array<crate::syntax::Expr> args_exprs_10558) { return call_then(start_opt_parts(ps_o6_1), [=](Array<crate::syntax::Expr> opt_parts_10577) { return prism_rtl::finished(append(append(acc_p1, args_exprs_10558), opt_parts_10577)); }); });
            });
            })
                : prism_rtl::finished(acc_p1);
            });
            });
        }));
    })))->cycle();
}


/// `Start TemplateExprs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::syntax::Expr>> start_template_exprs(Array<crate::syntax::TemplatePart> parts_p0) {
    return prism_rtl::make_rc<TemplateExprs>(parts_p0);
}


/// OptParts: unbounded fn ?[TemplatePart] -> [Expr]
Array<crate::syntax::Expr> opt_parts(const std::optional<Array<crate::syntax::TemplatePart>>& opt0) {
    if (prism_rtl::is_some(opt0)) {
        auto&& ps_p0 = prism_rtl::some_of(opt0);
        return template_exprs(ps_p0);
    }
    if (prism_rtl::is_none(opt0)) {
        return Array<crate::syntax::Expr>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<crate::syntax::Expr>> OptParts::cycle() const {
    const auto& opt0 = this->opt0;
    return ({
        prism_rtl::is_some(opt0) ? ({
        auto&& ps_p0 = prism_rtl::some_of(opt0);
        prism_rtl::more(prism_rtl::rc(TemplateExprs(ps_p0)));
    })
        : prism_rtl::is_none(opt0) ? prism_rtl::finished(Array<crate::syntax::Expr>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start OptParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::syntax::Expr>> start_opt_parts(std::optional<Array<crate::syntax::TemplatePart>> opt0) {
    return prism_rtl::make_rc<OptParts>(opt0);
}


/// OptBlockExprs: unbounded fn ?Block -> [Expr]
Array<crate::syntax::Expr> opt_block_exprs(const std::optional<crate::syntax::Block>& opt0) {
    if (prism_rtl::is_some(opt0)) {
        auto&& b_p0 = prism_rtl::some_of(opt0);
        return block_exprs(b_p0);
    }
    if (prism_rtl::is_none(opt0)) {
        return Array<crate::syntax::Expr>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<crate::syntax::Expr>> OptBlockExprs::cycle() const {
    const auto& opt0 = this->opt0;
    return ({
        prism_rtl::is_some(opt0) ? ({
        auto&& b_p0 = prism_rtl::some_of(opt0);
        prism_rtl::more(prism_rtl::rc(BlockExprs(b_p0)));
    })
        : prism_rtl::is_none(opt0) ? prism_rtl::finished(Array<crate::syntax::Expr>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start OptBlockExprs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::syntax::Expr>> start_opt_block_exprs(std::optional<crate::syntax::Block> opt0) {
    return prism_rtl::make_rc<OptBlockExprs>(opt0);
}


/// OptExprs: unbounded fn ?Expr -> [Expr]
Array<crate::syntax::Expr> opt_exprs(const std::optional<crate::syntax::Expr>& opt0) {
    if (prism_rtl::is_some(opt0)) {
        auto&& x_p0 = prism_rtl::some_of(opt0);
        return exprs_in(x_p0);
    }
    if (prism_rtl::is_none(opt0)) {
        return Array<crate::syntax::Expr>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<crate::syntax::Expr>> OptExprs::cycle() const {
    const auto& opt0 = this->opt0;
    return ({
        prism_rtl::is_some(opt0) ? ({
        auto&& x_p0 = prism_rtl::some_of(opt0);
        prism_rtl::more(prism_rtl::rc(ExprsIn(x_p0)));
    })
        : prism_rtl::is_none(opt0) ? prism_rtl::finished(Array<crate::syntax::Expr>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start OptExprs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::syntax::Expr>> start_opt_exprs(std::optional<crate::syntax::Expr> opt0) {
    return prism_rtl::make_rc<OptExprs>(opt0);
}

}  // namespace crate::check::typed::print
