// The module `Check.Types.Schemes`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/types/schemes/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Types.Schemes`, from `target/bootstrap/cpp-src/prismc/check/types/schemes.prism`.
namespace crate::check::types::schemes {

bool Inst::operator==(const Inst& o) const { return tys == o.tys && rows == o.rows && cols == o.cols; }

void Inst::show(Printer& p) const {
    p.record("Inst", {{"tys", tys}, {"rows", rows}, {"cols", cols}});
}

Pod Inst::to_pod() const {
    return Pod::record("Inst", {{"tys", prism_rtl::to_pod(tys)}, {"rows", prism_rtl::to_pod(rows)}, {"cols", prism_rtl::to_pod(cols)}});
}

Result<Inst> Inst::from_pod(const Pod& whole) {
    return Inst{.tys = TRY(prism_rtl::from_pod<Map<Text, crate::check::types::Ty>>(TRY(crate::prelude::field(whole, "tys")))), .rows = TRY(prism_rtl::from_pod<Map<Text, crate::check::types::Tail>>(TRY(crate::prelude::field(whole, "rows")))), .cols = TRY(prism_rtl::from_pod<Map<Text, crate::check::types::Col>>(TRY(crate::prelude::field(whole, "cols"))))};
}


/// Mono: fn Ty -> Scheme
crate::check::types::Scheme mono(const crate::check::types::Ty& t) {
    return crate::check::types::Scheme{.qs = Array<Text>{}, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = t};
}


/// SubstQ: unbounded fn Inst, Ty -> Ty
crate::check::types::Ty subst_q(const Inst& m, const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TyQ>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyQ>(t).a0;
        return or_(crate::prelude::get(m.tys, n), crate::check::types::Ty(crate::check::types::Ty::TyQ{n}));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyCon{n, run_to_end(each_job(args, ({
            auto m_1 = m;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
            return ({
                auto m_1_2 = m_1;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(SubstQ(m_1_2, a))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t)) {
        auto&& c = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        return crate::check::types::Ty(crate::check::types::Ty::TyFn{subst_col(m, c), run_to_end(each_job(ps, ({
            auto m_1 = m;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
            return ({
                auto m_1_2 = m_1;
                entered(once_job([=]() {
                return ({
                    auto p_ = p0;
                    (prism_rtl::more(prism_rtl::rc(SubstQ(m_1_2, p_))));
                });
            }));
            });
        })));
        }))), prism_rtl::rc(subst_q(m, prism_rtl::val(prism_rtl::val(res))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyTuple{run_to_end(each_job(ts, ({
            auto m_1 = m;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
            return ({
                auto m_1_2 = m_1;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(SubstQ(m_1_2, a))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(subst_q(m, prism_rtl::val(prism_rtl::val(e))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(subst_q(m, prism_rtl::val(prism_rtl::val(k)))), prism_rtl::rc(subst_q(m, prism_rtl::val(prism_rtl::val(v_))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& s = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TySig{s, prism_rtl::rc(subst_q(m, prism_rtl::val(prism_rtl::val(i))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a0;
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(subst_q(m, prism_rtl::val(prism_rtl::val(i)))), subst_row_q(m, rw)});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t)) {
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a0;
        auto&& o = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyElem{subst_row_q(m, rw), prism_rtl::rc(subst_q(m, prism_rtl::val(prism_rtl::val(o))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(t)) {
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElemAny>(t).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyElemAny{subst_row_q(m, rw)});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t).a0;
        auto&& a = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyAssoc{n, prism_rtl::rc(subst_q(m, prism_rtl::val(prism_rtl::val(a))))});
    }
    {
        auto&& other = t;
        return other;
    }
}


prism_rtl::Turn<crate::check::types::Ty> SubstQ::cycle() const {
    const auto& m = this->m;
    const auto& t = this->t;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyQ>(t) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyQ>(t).a0;
        prism_rtl::finished(or_(crate::prelude::get(prism_rtl::val(m).tys, n), crate::check::types::Ty(crate::check::types::Ty::TyQ{n})));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        ({
        auto args_1 = args;
        auto m_2 = m;
        auto n_3 = n;
        call_value(each_job(args_1, ({
        auto m_2_4 = m_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return ({
            auto m_2_4_4 = m_2_4;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(SubstQ(m_2_4_4, a))));
            });
        }));
        });
    })));
    })), [=](Array<crate::check::types::Ty> each_1157) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyCon{n_3, each_1157})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(t) ? ({
        auto&& c = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        ({
        auto c_1 = c;
        auto m_2 = m;
        auto ps_3 = ps;
        auto res_4 = prism_rtl::val(prism_rtl::val(res));
        call_value(each_job(ps_3, ({
        auto m_2_5 = m_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return ({
            auto m_2_5_5 = m_2_5;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(SubstQ(m_2_5_5, p_))));
            });
        }));
        });
    })));
    })), [=](Array<crate::check::types::Ty> each_1230) { return call_then(start_subst_q(m_2, res_4), [=](crate::check::types::Ty subst_q_1259) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyFn{subst_col(m_2, c_1), each_1230, prism_rtl::rc(subst_q_1259)})); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        ({
        auto m_1 = m;
        auto ts_2 = ts;
        call_value(each_job(ts_2, ({
        auto m_1_3 = m_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return ({
            auto m_1_3_3 = m_1_3;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(SubstQ(m_1_3_3, a))));
            });
        }));
        });
    })));
    })), [=](Array<crate::check::types::Ty> each_1299) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyTuple{each_1299})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        ({
        auto e_1 = prism_rtl::val(prism_rtl::val(e));
        auto m_2 = m;
        call_then(start_subst_q(m_2, e_1), [=](crate::check::types::Ty subst_q_1350) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(subst_q_1350)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        ({
        auto k_1 = prism_rtl::val(prism_rtl::val(k));
        auto m_2 = m;
        auto v__3 = prism_rtl::val(prism_rtl::val(v_));
        call_then(start_subst_q(m_2, k_1), [=](crate::check::types::Ty subst_q_1386) { return call_then(start_subst_q(m_2, v__3), [=](crate::check::types::Ty subst_q_1401) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(subst_q_1386), prism_rtl::rc(subst_q_1401)})); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t) ? ({
        auto&& s = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        ({
        auto i_1 = prism_rtl::val(prism_rtl::val(i));
        auto m_2 = m;
        auto s_3 = s;
        call_then(start_subst_q(m_2, i_1), [=](crate::check::types::Ty subst_q_1440) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TySig{s_3, prism_rtl::rc(subst_q_1440)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyAt>(t) ? ({
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a0;
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a1;
        ({
        auto i_1 = prism_rtl::val(prism_rtl::val(i));
        auto m_2 = m;
        auto rw_3 = rw;
        call_then(start_subst_q(m_2, i_1), [=](crate::check::types::Ty subst_q_1475) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(subst_q_1475), subst_row_q(m_2, rw_3)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyElem>(t) ? ({
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a0;
        auto&& o = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a1;
        ({
        auto m_1 = m;
        auto o_2 = prism_rtl::val(prism_rtl::val(o));
        auto rw_3 = rw;
        call_then(start_subst_q(m_1, o_2), [=](crate::check::types::Ty subst_q_1552) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyElem{subst_row_q(m_1, rw_3), prism_rtl::rc(subst_q_1552)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyElemAny>(t) ? ({
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElemAny>(t).a0;
        prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyElemAny{subst_row_q(m, rw)}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyAssoc>(t) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t).a0;
        auto&& a = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t).a1;
        ({
        auto a_1 = prism_rtl::val(prism_rtl::val(a));
        auto m_2 = m;
        auto n_3 = n;
        call_then(start_subst_q(m_2, a_1), [=](crate::check::types::Ty subst_q_1641) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyAssoc{n_3, prism_rtl::rc(subst_q_1641)})); });
    });
    })
        : ({
        auto&& other = t;
        prism_rtl::finished(other);
    });
    });
}


/// `Start SubstQ, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_subst_q(Inst m, crate::check::types::Ty t) {
    return prism_rtl::make_rc<SubstQ>(m, t);
}


/// SubstRowQ: fn Inst, Rw -> Rw
crate::check::types::Rw subst_row_q(const Inst& m, const crate::check::types::Rw& rw) {
    auto&& _m = rw.tail;
    if (prism_rtl::is<crate::check::types::Tail::TlQ>(_m)) {
        auto&& n = prism_rtl::as<crate::check::types::Tail::TlQ>(_m).a0;
        auto&& _m = crate::prelude::get(m.rows, n);
        if (prism_rtl::is_some(_m)) {
            auto&& t = prism_rtl::some_of(_m);
            return crate::check::types::Rw{.fams = rw.fams, .minus = rw.minus, .tail = t};
        }
        if (prism_rtl::is_none(_m)) {
            return rw;
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        return rw;
    }
}


/// SubstCol: fn Inst, Col -> Col
crate::check::types::Col subst_col(const Inst& m, const crate::check::types::Col& col1) {
    if (prism_rtl::is<crate::check::types::Col::CQ>(col1)) {
        auto&& n = prism_rtl::as<crate::check::types::Col::CQ>(col1).a0;
        return or_(crate::prelude::get(m.cols, n), crate::check::types::Col(crate::check::types::Col::CQ{n}));
    }
    {
        auto&& c = col1;
        return c;
    }
}


/// Instantiate: unbounded fn St, Scheme, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> instantiate(const crate::check::types::St& st, const crate::check::types::Scheme& sc, const crate::syntax::Range& span) {
    auto&& _t = instantiate_with(st, sc, span, Array<crate::check::types::Ty>{});
    auto&& t = std::get<0>(_t);
    auto&& st2 = std::get<1>(_t);
    return std::tuple{t, st2};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> Instantiate::cycle() const {
    const auto& st = this->st;
    const auto& sc = this->sc;
    const auto& span = this->span;
    auto sc_1 = sc;
    auto span_2 = span;
    auto st_3 = st;
    return call_then(start_instantiate_with(st_3, sc_1, span_2, Array<crate::check::types::Ty>{}), [=](std::tuple<crate::check::types::Ty, crate::check::types::St, Inst> instantiate_with_2231) {
        return ({
            auto&& _t = instantiate_with_2231;
            auto&& t = std::get<0>(_t);
            auto&& st2 = std::get<1>(_t);
            (prism_rtl::finished(std::tuple{t, st2}));
        });
    });
}


/// `Start Instantiate, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_instantiate(crate::check::types::St st, crate::check::types::Scheme sc, crate::syntax::Range span) {
    return prism_rtl::make_rc<Instantiate>(st, sc, span);
}


/// InstantiateWith: unbounded fn St, Scheme, Range, [Ty] -> ((Ty, St, Inst))
std::tuple<crate::check::types::Ty, crate::check::types::St, Inst> instantiate_with(const crate::check::types::St& st, const crate::check::types::Scheme& sc, const crate::syntax::Range& span, const Array<crate::check::types::Ty>& explicit_) {
    auto [tys, st1] = fold(crate::check::errors::range0(len(sc.qs)), std::tuple{Map<Text, crate::check::types::Ty>{}, st}, [&](const std::tuple<Map<Text, crate::check::types::Ty>, crate::check::types::St>& _p0, const Nat& i) {
        auto&& m = std::get<0>(_p0);
        auto&& s = std::get<1>(_p0);
        return ({
            auto q = or_(index(sc.qs, i), Text::lit(""));
            ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Map<Text, crate::check::types::Ty>, crate::check::types::St>> _v;
            auto&& _m = index(explicit_, i);
            if (prism_rtl::is_some(_m)) {
                auto&& g = prism_rtl::some_of(_m);
                _v.set(std::tuple{insert(m, q, g), s});
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(({
                    auto [v_, s2] = crate::check::types::fresh_var(s, crate::check::types::has_text(sc.plain_qs, q), Text::lit(""));
                    std::tuple{insert(m, q, v_), s2};
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        });
    });
    auto nq = len(sc.qs);
    auto [rows, st2] = run_to_end(fold_job(sc.rqs, std::tuple{Map<Text, crate::check::types::Tail>{}, st1}, ({
        auto sc_1 = sc;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, crate::check::types::Tail>, crate::check::types::St>>(std::tuple<std::tuple<Map<Text, crate::check::types::Tail>, crate::check::types::St>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Map<Text, crate::check::types::Tail>, crate::check::types::St>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sc_1_2 = sc_1;
            entered(once_job([=]() {
            return ({
                auto [m, s] = p0;
                auto q = p1;
                call_then(start_lacks_in(sc_1_2.ty, q), [=](Array<Text> lacks_in_2973) {
                return ({
                    auto [rw, s2] = crate::check::types::recording::fresh_row(s, lacks_in_2973);
                    (prism_rtl::finished(std::tuple{insert(m, q, prism_rtl::val(rw).tail), crate::check::types::unify::name_row(s2, prism_rtl::val(rw).tail, q)}));
                });
            });
            });
        }));
        });
    }));
    })));
    auto [cols, st2b] = fold(sc.cqs, std::tuple{Map<Text, crate::check::types::Col>{}, st2}, [&](const std::tuple<Map<Text, crate::check::types::Col>, crate::check::types::St>& _p0, const Text& q) {
        auto&& m = std::get<0>(_p0);
        auto&& s = std::get<1>(_p0);
        return ({
            auto [c, s2] = crate::check::types::fresh_col(s);
            std::tuple{insert(m, q, c), s2};
        });
    });
    auto inst = Inst{.tys = tys, .rows = rows, .cols = cols};
    auto st2c = run_to_end(fold_job(sc.cjoins, st2b, ({
        auto cols_1 = cols;
        auto span_2 = span;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, std::tuple<Text, Text>>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, std::tuple<Text, Text>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cols_1_3 = cols_1;
            auto span_2_3 = span_2;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto [lo, hi] = p1;
                (prism_rtl::more(prism_rtl::rc(crate::check::types::colors::AddLeq(s, or_(crate::prelude::get(cols_1_3, lo), crate::check::types::Col(crate::check::types::Col::CBound{})), or_(crate::prelude::get(cols_1_3, hi), crate::check::types::Col(crate::check::types::Col::CBound{})), span_2_3, Text::lit("arg"), Text::lit(""), Text::lit("")))));
            });
        }));
        });
    })));
    })));
    auto st3 = fold(sc.bounds, st2c, [&](const crate::check::types::St& s, const std::tuple<Text, Text>& _p1) {
        auto&& v_ = std::get<0>(_p1);
        auto&& tr = std::get<1>(_p1);
        return ({
            crate::check::types::St this_ = s;
            this_.wants = crate::prelude::push(this_.wants, crate::check::types::Want{.cls = tr, .ty = or_(crate::prelude::get(tys, v_), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), .file = s->file, .span = span, .level = prism_rtl::val(s).level});
            this_;
        });
    });
    return std::tuple{subst_q(inst, sc.ty), st3, inst};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St, Inst>> InstantiateWith::cycle() const {
    const auto& st = this->st;
    const auto& sc = this->sc;
    const auto& span = this->span;
    const auto& explicit_ = this->explicit_;
    auto [tys, st1] = fold(crate::check::errors::range0(len(prism_rtl::val(sc).qs)), std::tuple{Map<Text, crate::check::types::Ty>{}, st}, [&](const std::tuple<Map<Text, crate::check::types::Ty>, crate::check::types::St>& _p0, const Nat& i) {
        auto&& m = std::get<0>(_p0);
        auto&& s = std::get<1>(_p0);
        return ({
            auto q = or_(index(prism_rtl::val(sc).qs, i), Text::lit(""));
            ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Map<Text, crate::check::types::Ty>, crate::check::types::St>> _v;
            auto&& _m = index(explicit_, i);
            if (prism_rtl::is_some(_m)) {
                auto&& g = prism_rtl::some_of(_m);
                _v.set(std::tuple{insert(m, q, g), s});
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(({
                    auto [v_, s2] = crate::check::types::fresh_var(s, crate::check::types::has_text(prism_rtl::val(sc).plain_qs, q), Text::lit(""));
                    std::tuple{insert(m, q, v_), s2};
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        });
    });
    auto nq = len(prism_rtl::val(sc).qs);
    auto sc_1 = sc;
    auto span_2 = span;
    return call_value(fold_job(prism_rtl::val(sc_1).rqs, std::tuple{Map<Text, crate::check::types::Tail>{}, st1}, ({
        auto sc_1_3 = sc_1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, crate::check::types::Tail>, crate::check::types::St>>(std::tuple<std::tuple<Map<Text, crate::check::types::Tail>, crate::check::types::St>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Map<Text, crate::check::types::Tail>, crate::check::types::St>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sc_1_3_3 = sc_1_3;
            entered(once_job([=]() {
            return ({
                auto [m, s] = p0;
                auto q = p1;
                call_then(start_lacks_in(prism_rtl::val(sc_1_3_3).ty, q), [=](Array<Text> lacks_in_2973) {
                return ({
                    auto [rw, s2] = crate::check::types::recording::fresh_row(s, lacks_in_2973);
                    (prism_rtl::finished(std::tuple{insert(m, q, prism_rtl::val(rw).tail), crate::check::types::unify::name_row(s2, prism_rtl::val(rw).tail, q)}));
                });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Map<Text, crate::check::types::Tail>, crate::check::types::St> fold_2894) {
        return ({
            auto [rows, st2] = fold_2894;
            auto [cols, st2b] = fold(prism_rtl::val(sc_1).cqs, std::tuple{Map<Text, crate::check::types::Col>{}, st2}, [&](const std::tuple<Map<Text, crate::check::types::Col>, crate::check::types::St>& _p0, const Text& q) {
                auto&& m = std::get<0>(_p0);
                auto&& s = std::get<1>(_p0);
                return ({
                    auto [c, s2] = crate::check::types::fresh_col(s);
                    std::tuple{insert(m, q, c), s2};
                });
            });
            auto inst = Inst{.tys = tys, .rows = rows, .cols = cols};
            call_value(fold_job(prism_rtl::val(sc_1).cjoins, st2b, ({
            auto cols_3 = cols;
            auto span_2_4 = span_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, std::tuple<Text, Text>>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, std::tuple<Text, Text>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cols_3_4 = cols_3;
                auto span_2_4_4 = span_2_4;
                entered(once_job([=]() {
                return ({
                    auto s = p0;
                    auto [lo, hi] = p1;
                    (prism_rtl::more(prism_rtl::rc(crate::check::types::colors::AddLeq(s, or_(crate::prelude::get(cols_3_4, lo), crate::check::types::Col(crate::check::types::Col::CBound{})), or_(crate::prelude::get(cols_3_4, hi), crate::check::types::Col(crate::check::types::Col::CBound{})), span_2_4_4, Text::lit("arg"), Text::lit(""), Text::lit("")))));
                });
            }));
            });
        })));
        })), [=](crate::check::types::St fold_3252) {
            return ({
                auto st2c = fold_3252;
                auto st3 = fold(prism_rtl::val(sc_1).bounds, st2c, [&](const crate::check::types::St& s, const std::tuple<Text, Text>& _p1) {
                    auto&& v_ = std::get<0>(_p1);
                    auto&& tr = std::get<1>(_p1);
                    return ({
                        crate::check::types::St this_ = s;
                        this_.wants = crate::prelude::push(this_.wants, crate::check::types::Want{.cls = tr, .ty = or_(crate::prelude::get(tys, v_), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), .file = s->file, .span = span_2, .level = prism_rtl::val(s).level});
                        this_;
                    });
                });
                call_then(start_subst_q(inst, prism_rtl::val(sc_1).ty), [=](crate::check::types::Ty subst_q_3546) { return prism_rtl::finished(std::tuple{subst_q_3546, st3, inst}); });
            });
        });
        });
    });
}


/// `Start InstantiateWith, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St, Inst>> start_instantiate_with(crate::check::types::St st, crate::check::types::Scheme sc, crate::syntax::Range span, Array<crate::check::types::Ty> explicit_) {
    return prism_rtl::make_rc<InstantiateWith>(st, sc, span, explicit_);
}


/// LacksIn: unbounded fn Ty, Text -> [Text]
Array<Text> lacks_in(const crate::check::types::Ty& t, const Text& q) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        return run_to_end(fold_job(args, Array<Text>{}, ({
            auto q_1 = q;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto q_1_2 = q_1;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_lacks_in(a, q_1_2), [=](Array<Text> lacks_in_3833) { return prism_rtl::finished(crate::check::types::union_texts(acc, lacks_in_3833)); });
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t)) {
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& r = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        return run_to_end(fold_job(ps, lacks_in(prism_rtl::val(prism_rtl::val(r)), q), ({
            auto q_1 = q;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto q_1_2 = q_1;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_lacks_in(a, q_1_2), [=](Array<Text> lacks_in_3923) { return prism_rtl::finished(crate::check::types::union_texts(acc, lacks_in_3923)); });
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        return run_to_end(fold_job(ts, Array<Text>{}, ({
            auto q_1 = q;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto q_1_2 = q_1;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_lacks_in(a, q_1_2), [=](Array<Text> lacks_in_3995) { return prism_rtl::finished(crate::check::types::union_texts(acc, lacks_in_3995)); });
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        return lacks_in(prism_rtl::val(prism_rtl::val(e)), q);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        return crate::check::types::union_texts(lacks_in(prism_rtl::val(prism_rtl::val(k)), q), lacks_in(prism_rtl::val(prism_rtl::val(v_)), q));
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        return lacks_in(prism_rtl::val(prism_rtl::val(i)), q);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a0;
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a1;
        return crate::check::types::union_texts(lacks_in(prism_rtl::val(prism_rtl::val(i)), q), row_lacks(rw, q));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t)) {
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a0;
        auto&& o = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a1;
        return crate::check::types::union_texts(lacks_in(prism_rtl::val(prism_rtl::val(o)), q), row_lacks(rw, q));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(t)) {
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElemAny>(t).a0;
        return row_lacks(rw, q);
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> LacksIn::cycle() const {
    const auto& t = this->t;
    const auto& q = this->q;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyCon>(t) ? ({
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        fold_job(args, Array<Text>{}, ({
        auto q_1 = q;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto q_1_2 = q_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto a = p1;
                call_then(start_lacks_in(a, q_1_2), [=](Array<Text> lacks_in_3833) { return prism_rtl::finished(crate::check::types::union_texts(acc, lacks_in_3833)); });
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(t) ? ({
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& r = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        ({
        auto ps_1 = ps;
        auto q_2 = q;
        auto r_3 = prism_rtl::val(prism_rtl::val(r));
        call_then(start_lacks_in(r_3, q_2), [=](Array<Text> lacks_in_3881) {
        return fold_job(ps_1, lacks_in_3881, ({
            auto q_2_4 = q_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto q_2_4_4 = q_2_4;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_lacks_in(a, q_2_4_4), [=](Array<Text> lacks_in_3923) { return prism_rtl::finished(crate::check::types::union_texts(acc, lacks_in_3923)); });
                });
            }));
            });
        })));
        }))->cycle();
    });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        fold_job(ts, Array<Text>{}, ({
        auto q_1 = q;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto q_1_2 = q_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto a = p1;
                call_then(start_lacks_in(a, q_1_2), [=](Array<Text> lacks_in_3995) { return prism_rtl::finished(crate::check::types::union_texts(acc, lacks_in_3995)); });
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        prism_rtl::more(prism_rtl::rc(LacksIn(prism_rtl::val(prism_rtl::val(e)), q)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        ({
        auto k_1 = prism_rtl::val(prism_rtl::val(k));
        auto q_2 = q;
        auto v__3 = prism_rtl::val(prism_rtl::val(v_));
        call_then(start_lacks_in(k_1, q_2), [=](Array<Text> lacks_in_4065) { return call_then(start_lacks_in(v__3, q_2), [=](Array<Text> lacks_in_4081) { return prism_rtl::finished(crate::check::types::union_texts(lacks_in_4065, lacks_in_4081)); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t) ? ({
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        prism_rtl::more(prism_rtl::rc(LacksIn(prism_rtl::val(prism_rtl::val(i)), q)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyAt>(t) ? ({
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a0;
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a1;
        ({
        auto i_1 = prism_rtl::val(prism_rtl::val(i));
        auto q_2 = q;
        auto rw_3 = rw;
        call_then(start_lacks_in(i_1, q_2), [=](Array<Text> lacks_in_4157) { return prism_rtl::finished(crate::check::types::union_texts(lacks_in_4157, row_lacks(rw_3, q_2))); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyElem>(t) ? ({
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a0;
        auto&& o = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a1;
        ({
        auto o_1 = prism_rtl::val(prism_rtl::val(o));
        auto q_2 = q;
        auto rw_3 = rw;
        call_then(start_lacks_in(o_1, q_2), [=](Array<Text> lacks_in_4219) { return prism_rtl::finished(crate::check::types::union_texts(lacks_in_4219, row_lacks(rw_3, q_2))); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyElemAny>(t) ? ({
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElemAny>(t).a0;
        prism_rtl::finished(row_lacks(rw, q));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start LacksIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_lacks_in(crate::check::types::Ty t, Text q) {
    return prism_rtl::make_rc<LacksIn>(t, q);
}


/// RowLacks: fn Rw, Text -> [Text]
Array<Text> row_lacks(const crate::check::types::Rw& rw, const Text& q) {
    return rw.tail == crate::check::types::Tail(crate::check::types::Tail::TlQ{q})
        ? rw.fams
        : Array<Text>{};
}


/// Skolemize: unbounded fn Scheme -> Ty
crate::check::types::Ty skolemize(const crate::check::types::Scheme& sc) {
    auto tys = fold(sc.qs, Map<Text, crate::check::types::Ty>{}, [&](const Map<Text, crate::check::types::Ty>& m, const Text& q) { return insert(m, q, crate::check::types::Ty(crate::check::types::Ty::TyRigid{q})); });
    auto rows = fold(sc.rqs, Map<Text, crate::check::types::Tail>{}, [&](const Map<Text, crate::check::types::Tail>& m, const Text& q) { return insert(m, q, crate::check::types::Tail(crate::check::types::Tail::TlRigid{q})); });
    auto cols = fold(sc.cqs, Map<Text, crate::check::types::Col>{}, [&](const Map<Text, crate::check::types::Col>& m, const Text& q) { return insert(m, q, crate::check::types::Col(crate::check::types::Col::CRigid{q})); });
    return subst_q(Inst{.tys = tys, .rows = rows, .cols = cols}, sc.ty);
}


prism_rtl::Turn<crate::check::types::Ty> Skolemize::cycle() const {
    const auto& sc = this->sc;
    auto tys = fold(prism_rtl::val(sc).qs, Map<Text, crate::check::types::Ty>{}, [&](const Map<Text, crate::check::types::Ty>& m, const Text& q) { return insert(m, q, crate::check::types::Ty(crate::check::types::Ty::TyRigid{q})); });
    auto rows = fold(prism_rtl::val(sc).rqs, Map<Text, crate::check::types::Tail>{}, [&](const Map<Text, crate::check::types::Tail>& m, const Text& q) { return insert(m, q, crate::check::types::Tail(crate::check::types::Tail::TlRigid{q})); });
    auto cols = fold(prism_rtl::val(sc).cqs, Map<Text, crate::check::types::Col>{}, [&](const Map<Text, crate::check::types::Col>& m, const Text& q) { return insert(m, q, crate::check::types::Col(crate::check::types::Col::CRigid{q})); });
    return prism_rtl::more(prism_rtl::rc(SubstQ(Inst{.tys = tys, .rows = rows, .cols = cols}, prism_rtl::val(sc).ty)));
}


/// `Start Skolemize, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_skolemize(crate::check::types::Scheme sc) {
    return prism_rtl::make_rc<Skolemize>(sc);
}


/// Generalize: unbounded fn St, Ty, [Nat], [((Nat, Text))] -> ((Scheme, St))
std::tuple<crate::check::types::Scheme, crate::check::types::St> generalize(const crate::check::types::St& st0, const crate::check::types::Ty& t, const Array<Nat>& keep, const Array<std::tuple<Nat, Text>>& bounds) {
    auto waiting = run_to_end(fold_job(st0.field_qs, Array<Nat>{}, ({
        auto st0_1 = st0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::unify::FieldQ>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, crate::check::types::unify::FieldQ> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto st0_1_2 = st0_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto q = p1;
                call_then(crate::check::types::recording::start_free_vars_into(st0_1_2, acc, prism_rtl::val(q).recv), [=](Array<Nat> free_vars_into_5383) { return prism_rtl::more(prism_rtl::rc(crate::check::types::recording::FreeVarsInto(st0_1_2, free_vars_into_5383, q->result))); });
            });
        }));
        });
    })));
    })));
    auto st = crate::check::types::colors::generalize_cols(crate::check::types::unify::lower_levels(st0, waiting, st0.level));
    auto z = crate::check::types::recording::zonk(st, t);
    auto vs = filter(crate::check::types::recording::free_vars(st, z), [&](const Nat& v_) { return (prism_rtl::val(crate::check::types::recording::info_of(st, v_)).level > prism_rtl::val(st).level) && (!crate::check::types::has_nat(keep, v_)); });
    auto cvs = filter(crate::check::types::colors::free_col_vars(st, z), [&](const Nat& v_) { return prism_rtl::val(crate::check::types::recording::info_of(st, v_)).level > prism_rtl::val(st).level; });
    auto tys = fold(vs, Map<Nat, crate::check::types::Ty>{}, [&](const Map<Nat, crate::check::types::Ty>& m, const Nat& v_) { return insert(m, v_, crate::check::types::Ty(crate::check::types::Ty::TyQ{prism_rtl::cat("\'", v_)})); });
    auto cols = fold(cvs, Map<Nat, crate::check::types::Col>{}, [&](const Map<Nat, crate::check::types::Col>& m, const Nat& v_) { return insert(m, v_, crate::check::types::Col(crate::check::types::Col::CQ{prism_rtl::cat("\'c", v_)})); });
    auto named_ = subst_flex(tys, cols, z);
    auto plains = each(filter(vs, [&](const Nat& v_) { return prism_rtl::val(crate::check::types::recording::info_of(st, v_)).plain; }), [&](const Nat& v_) { return prism_rtl::cat("\'", v_); });
    auto bs = each(filter(bounds, [&](const std::tuple<Nat, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        return crate::check::types::has_nat(vs, v_);
    }), [&](const std::tuple<Nat, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        auto&& tr = std::get<1>(_p0);
        return std::tuple{prism_rtl::cat("\'", v_), tr};
    });
    auto st2 = ({
        crate::check::types::St this_ = st;
        this_.col_q = fold(cvs, this_.col_q, [&](const Map<Nat, Text>& m, const Nat& v_) { return insert(m, v_, prism_rtl::cat("\'c", v_)); });
        this_;
    });
    return std::tuple{crate::check::types::Scheme{.qs = each(vs, [&](const Nat& v_) { return prism_rtl::cat("\'", v_); }), .plain_qs = plains, .rqs = Array<Text>{}, .cqs = each(cvs, [&](const Nat& v_) { return prism_rtl::cat("\'c", v_); }), .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = bs, .ty = named_}, st2};
}


prism_rtl::Turn<std::tuple<crate::check::types::Scheme, crate::check::types::St>> Generalize::cycle() const {
    const auto& st0 = this->st0;
    const auto& t = this->t;
    const auto& keep = this->keep;
    const auto& bounds = this->bounds;
    auto bounds_1 = bounds;
    auto keep_2 = keep;
    auto st0_3 = st0;
    auto t_4 = t;
    return call_value(fold_job(prism_rtl::val(st0_3).field_qs, Array<Nat>{}, ({
        auto st0_3_5 = st0_3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::unify::FieldQ>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, crate::check::types::unify::FieldQ> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto st0_3_5_5 = st0_3_5;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto q = p1;
                call_then(crate::check::types::recording::start_free_vars_into(st0_3_5_5, acc, prism_rtl::val(q).recv), [=](Array<Nat> free_vars_into_5383) { return prism_rtl::more(prism_rtl::rc(crate::check::types::recording::FreeVarsInto(st0_3_5_5, free_vars_into_5383, q->result))); });
            });
        }));
        });
    })));
    })), [=](Array<Nat> fold_5330) {
        return ({
            auto waiting = fold_5330;
            call_then(crate::check::types::colors::start_generalize_cols(crate::check::types::unify::lower_levels(st0_3, waiting, prism_rtl::val(st0_3).level)), [=](crate::check::types::St generalize_cols_5437) {
            return ({
                auto st = generalize_cols_5437;
                call_then(crate::check::types::recording::start_zonk(st, t_4), [=](crate::check::types::Ty zonk_5502) {
                return ({
                    auto z = zonk_5502;
                    call_then(crate::check::types::recording::start_free_vars(st, z), [=](Array<Nat> free_vars_5534) {
                    return ({
                        auto vs = filter(free_vars_5534, [&](const Nat& v_) { return (prism_rtl::val(crate::check::types::recording::info_of(st, v_)).level > prism_rtl::val(st).level) && (!crate::check::types::has_nat(keep_2, v_)); });
                        call_then(crate::check::types::colors::start_free_col_vars(st, z), [=](Array<Nat> free_col_vars_5635) {
                        return ({
                            auto cvs = filter(free_col_vars_5635, [&](const Nat& v_) { return prism_rtl::val(crate::check::types::recording::info_of(st, v_)).level > prism_rtl::val(st).level; });
                            auto tys = fold(vs, Map<Nat, crate::check::types::Ty>{}, [&](const Map<Nat, crate::check::types::Ty>& m, const Nat& v_) { return insert(m, v_, crate::check::types::Ty(crate::check::types::Ty::TyQ{prism_rtl::cat("\'", v_)})); });
                            auto cols = fold(cvs, Map<Nat, crate::check::types::Col>{}, [&](const Map<Nat, crate::check::types::Col>& m, const Nat& v_) { return insert(m, v_, crate::check::types::Col(crate::check::types::Col::CQ{prism_rtl::cat("\'c", v_)})); });
                            call_then(start_subst_flex(tys, cols, z), [=](crate::check::types::Ty subst_flex_5832) {
                            return ({
                                auto named_ = subst_flex_5832;
                                auto plains = each(filter(vs, [&](const Nat& v_) { return prism_rtl::val(crate::check::types::recording::info_of(st, v_)).plain; }), [&](const Nat& v_) { return prism_rtl::cat("\'", v_); });
                                auto bs = each(filter(bounds_1, [&](const std::tuple<Nat, Text>& _p0) {
                                    auto&& v_ = std::get<0>(_p0);
                                    return crate::check::types::has_nat(vs, v_);
                                }), [&](const std::tuple<Nat, Text>& _p0) {
                                    auto&& v_ = std::get<0>(_p0);
                                    auto&& tr = std::get<1>(_p0);
                                    return std::tuple{prism_rtl::cat("\'", v_), tr};
                                });
                                auto st2 = ({
                                    crate::check::types::St this_ = st;
                                    this_.col_q = fold(cvs, this_.col_q, [&](const Map<Nat, Text>& m, const Nat& v_) { return insert(m, v_, prism_rtl::cat("\'c", v_)); });
                                    this_;
                                });
                                (prism_rtl::finished(std::tuple{crate::check::types::Scheme{.qs = each(vs, [&](const Nat& v_) { return prism_rtl::cat("\'", v_); }), .plain_qs = plains, .rqs = Array<Text>{}, .cqs = each(cvs, [&](const Nat& v_) { return prism_rtl::cat("\'c", v_); }), .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = bs, .ty = named_}, st2}));
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start Generalize, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Scheme, crate::check::types::St>> start_generalize(crate::check::types::St st0, crate::check::types::Ty t, Array<Nat> keep, Array<std::tuple<Nat, Text>> bounds) {
    return prism_rtl::make_rc<Generalize>(st0, t, keep, bounds);
}


/// SubstFlex: unbounded fn (Nat ==> Ty), (Nat ==> Col), Ty -> Ty
crate::check::types::Ty subst_flex(const Map<Nat, crate::check::types::Ty>& m, const Map<Nat, crate::check::types::Col>& cm, const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyFlex>(t).a0;
        return or_(crate::prelude::get(m, n), crate::check::types::Ty(crate::check::types::Ty::TyFlex{n}));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyCon{n, run_to_end(each_job(args, ({
            auto m_1 = m;
            auto cm_2 = cm;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
            return ({
                auto m_1_3 = m_1;
                auto cm_2_3 = cm_2;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(SubstFlex(m_1_3, cm_2_3, a))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t)) {
        auto&& c = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        auto c2 = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::Col> _v;
            if (prism_rtl::is<crate::check::types::Col::CFlex>(c)) {
                auto&& n = prism_rtl::as<crate::check::types::Col::CFlex>(c).a0;
                _v.set(or_(crate::prelude::get(cm, n), c));
                goto _done;
            }
            {
                auto&& other = c;
                _v.set(other);
                goto _done;
            }
        _done:
            _v.take();
        });
        return crate::check::types::Ty(crate::check::types::Ty::TyFn{c2, run_to_end(each_job(ps, ({
            auto m_1 = m;
            auto cm_2 = cm;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
            return ({
                auto m_1_3 = m_1;
                auto cm_2_3 = cm_2;
                entered(once_job([=]() {
                return ({
                    auto p_ = p0;
                    (prism_rtl::more(prism_rtl::rc(SubstFlex(m_1_3, cm_2_3, p_))));
                });
            }));
            });
        })));
        }))), prism_rtl::rc(subst_flex(m, cm, prism_rtl::val(prism_rtl::val(res))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyTuple{run_to_end(each_job(ts, ({
            auto m_1 = m;
            auto cm_2 = cm;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
            return ({
                auto m_1_3 = m_1;
                auto cm_2_3 = cm_2;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(SubstFlex(m_1_3, cm_2_3, a))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(subst_flex(m, cm, prism_rtl::val(prism_rtl::val(e))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(subst_flex(m, cm, prism_rtl::val(prism_rtl::val(k)))), prism_rtl::rc(subst_flex(m, cm, prism_rtl::val(prism_rtl::val(v_))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& s = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TySig{s, prism_rtl::rc(subst_flex(m, cm, prism_rtl::val(prism_rtl::val(i))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a0;
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(subst_flex(m, cm, prism_rtl::val(prism_rtl::val(i)))), rw});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t)) {
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a0;
        auto&& o = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyElem{rw, prism_rtl::rc(subst_flex(m, cm, prism_rtl::val(prism_rtl::val(o))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t).a0;
        auto&& a = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyAssoc{n, prism_rtl::rc(subst_flex(m, cm, prism_rtl::val(prism_rtl::val(a))))});
    }
    {
        auto&& other = t;
        return other;
    }
}


prism_rtl::Turn<crate::check::types::Ty> SubstFlex::cycle() const {
    const auto& m = this->m;
    const auto& cm = this->cm;
    const auto& t = this->t;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyFlex>(t) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyFlex>(t).a0;
        prism_rtl::finished(or_(crate::prelude::get(m, n), crate::check::types::Ty(crate::check::types::Ty::TyFlex{n})));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        ({
        auto args_1 = args;
        auto cm_2 = cm;
        auto m_3 = m;
        auto n_4 = n;
        call_value(each_job(args_1, ({
        auto m_3_5 = m_3;
        auto cm_2_5 = cm_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return ({
            auto m_3_5_5 = m_3_5;
            auto cm_2_5_5 = cm_2_5;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(SubstFlex(m_3_5_5, cm_2_5_5, a))));
            });
        }));
        });
    })));
    })), [=](Array<crate::check::types::Ty> each_6411) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyCon{n_4, each_6411})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(t) ? ({
        auto&& c = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        ({
        auto c2 = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::Col> _v;
            if (prism_rtl::is<crate::check::types::Col::CFlex>(c)) {
                auto&& n = prism_rtl::as<crate::check::types::Col::CFlex>(c).a0;
                _v.set(or_(crate::prelude::get(cm, n), c));
                goto _done;
            }
            {
                auto&& other = c;
                _v.set(other);
                goto _done;
            }
        _done:
            _v.take();
        });
        auto cm_1 = cm;
        auto m_2 = m;
        auto ps_3 = ps;
        auto res_4 = prism_rtl::val(prism_rtl::val(res));
        call_value(each_job(ps_3, ({
        auto m_2_5 = m_2;
        auto cm_1_5 = cm_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return ({
            auto m_2_5_5 = m_2_5;
            auto cm_1_5_5 = cm_1_5;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(SubstFlex(m_2_5_5, cm_1_5_5, p_))));
            });
        }));
        });
    })));
    })), [=](Array<crate::check::types::Ty> each_6570) { return call_then(start_subst_flex(m_2, cm_1, res_4), [=](crate::check::types::Ty subst_flex_6606) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyFn{c2, each_6570, prism_rtl::rc(subst_flex_6606)})); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        ({
        auto cm_1 = cm;
        auto m_2 = m;
        auto ts_3 = ts;
        call_value(each_job(ts_3, ({
        auto m_2_4 = m_2;
        auto cm_1_4 = cm_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return ({
            auto m_2_4_4 = m_2_4;
            auto cm_1_4_4 = cm_1_4;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(SubstFlex(m_2_4_4, cm_1_4_4, a))));
            });
        }));
        });
    })));
    })), [=](Array<crate::check::types::Ty> each_6653) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyTuple{each_6653})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        ({
        auto cm_1 = cm;
        auto e_2 = prism_rtl::val(prism_rtl::val(e));
        auto m_3 = m;
        call_then(start_subst_flex(m_3, cm_1, e_2), [=](crate::check::types::Ty subst_flex_6711) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(subst_flex_6711)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        ({
        auto cm_1 = cm;
        auto k_2 = prism_rtl::val(prism_rtl::val(k));
        auto m_3 = m;
        auto v__4 = prism_rtl::val(prism_rtl::val(v_));
        call_then(start_subst_flex(m_3, cm_1, k_2), [=](crate::check::types::Ty subst_flex_6754) { return call_then(start_subst_flex(m_3, cm_1, v__4), [=](crate::check::types::Ty subst_flex_6776) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(subst_flex_6754), prism_rtl::rc(subst_flex_6776)})); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t) ? ({
        auto&& s = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        ({
        auto cm_1 = cm;
        auto i_2 = prism_rtl::val(prism_rtl::val(i));
        auto m_3 = m;
        auto s_4 = s;
        call_then(start_subst_flex(m_3, cm_1, i_2), [=](crate::check::types::Ty subst_flex_6822) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TySig{s_4, prism_rtl::rc(subst_flex_6822)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyAt>(t) ? ({
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a0;
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a1;
        ({
        auto cm_1 = cm;
        auto i_2 = prism_rtl::val(prism_rtl::val(i));
        auto m_3 = m;
        auto rw_4 = rw;
        call_then(start_subst_flex(m_3, cm_1, i_2), [=](crate::check::types::Ty subst_flex_6864) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(subst_flex_6864), rw_4})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyElem>(t) ? ({
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a0;
        auto&& o = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a1;
        ({
        auto cm_1 = cm;
        auto m_2 = m;
        auto o_3 = prism_rtl::val(prism_rtl::val(o));
        auto rw_4 = rw;
        call_then(start_subst_flex(m_2, cm_1, o_3), [=](crate::check::types::Ty subst_flex_6918) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyElem{rw_4, prism_rtl::rc(subst_flex_6918)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyAssoc>(t) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t).a0;
        auto&& a = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t).a1;
        ({
        auto a_1 = prism_rtl::val(prism_rtl::val(a));
        auto cm_2 = cm;
        auto m_3 = m;
        auto n_4 = n;
        call_then(start_subst_flex(m_3, cm_2, a_1), [=](crate::check::types::Ty subst_flex_6968) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyAssoc{n_4, prism_rtl::rc(subst_flex_6968)})); });
    });
    })
        : ({
        auto&& other = t;
        prism_rtl::finished(other);
    });
    });
}


/// `Start SubstFlex, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_subst_flex(Map<Nat, crate::check::types::Ty> m, Map<Nat, crate::check::types::Col> cm, crate::check::types::Ty t) {
    return prism_rtl::make_rc<SubstFlex>(m, cm, t);
}


/// HoldsNode: unbounded fn St, Ty -> Bool
bool holds_node(const crate::check::types::St& st, const crate::check::types::Ty& t) {
    auto&& _m = crate::check::types::recording::walk(st, t);
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& s = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        return ((s == Text::lit("$")) || (s == Text::lit("!"))) || holds_node(st, prism_rtl::val(i));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(_m)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(_m).a0;
        return run_to_end(fold_job(ts, false, ({
            auto st_1 = st;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_1_2 = st_1;
                entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto x = p1;
                    (prism_rtl::finished(seen || holds_node(st_1_2, x)));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(_m)) {
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(_m).a0;
        return holds_node(st, prism_rtl::val(e));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(_m)) {
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a1;
        return holds_node(st, prism_rtl::val(k)) || holds_node(st, prism_rtl::val(v_));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        return run_to_end(fold_job(args, false, ({
            auto st_1 = st;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_1_2 = st_1;
                entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto x = p1;
                    (prism_rtl::finished(seen || holds_node(st_1_2, x)));
                });
            }));
            });
        })));
        })));
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> HoldsNode::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    auto st_1 = st;
    auto t_2 = t;
    return call_then(crate::check::types::recording::start_walk(st_1, t_2), [=](crate::check::types::Ty walk_7202) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TySig>(walk_7202) ? ({
            auto&& s = prism_rtl::as<crate::check::types::Ty::TySig>(walk_7202).a0;
            auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(walk_7202).a1;
            prism_rtl::finished(((s == Text::lit("$")) || (s == Text::lit("!"))) || holds_node(st_1, prism_rtl::val(i)));
        })
            : prism_rtl::is<crate::check::types::Ty::TyTuple>(walk_7202) ? ({
            auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(walk_7202).a0;
            fold_job(ts, false, ({
            auto st_1_3 = st_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_1_3_3 = st_1_3;
                entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto x = p1;
                    (prism_rtl::finished(seen || holds_node(st_1_3_3, x)));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::check::types::Ty::TyArray>(walk_7202) ? ({
            auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(walk_7202).a0;
            prism_rtl::more(prism_rtl::rc(HoldsNode(st_1, prism_rtl::val(e))));
        })
            : prism_rtl::is<crate::check::types::Ty::TyMap>(walk_7202) ? ({
            auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(walk_7202).a0;
            auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(walk_7202).a1;
            call_then(start_holds_node(st_1, prism_rtl::val(k)), [=](bool holds_node_7385) { return prism_rtl::finished(holds_node_7385 || holds_node(st_1, prism_rtl::val(v_))); });
        })
            : prism_rtl::is<crate::check::types::Ty::TyCon>(walk_7202) ? ({
            auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_7202).a1;
            fold_job(args, false, ({
            auto st_1_3 = st_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_1_3_3 = st_1_3;
                entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto x = p1;
                    (prism_rtl::finished(seen || holds_node(st_1_3_3, x)));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::finished(false);
        });
    });
}


/// `Start HoldsNode, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_holds_node(crate::check::types::St st, crate::check::types::Ty t) {
    return prism_rtl::make_rc<HoldsNode>(st, t);
}


/// EnterLevel: fn St -> St
crate::check::types::St enter_level(const crate::check::types::St& st) {
    crate::check::types::St this_ = st;
    this_.level = this_.level + Nat(1u);
    return this_;
}


/// LeaveLevel: fn St -> St
crate::check::types::St leave_level(const crate::check::types::St& st) {
    crate::check::types::St this_ = st;
    this_.level = or_(this_.level.checked_sub(Nat(1u)), Nat(0u));
    return this_;
}

}  // namespace crate::check::types::schemes
