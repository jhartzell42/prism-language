// The modules `Syntax.Lexer.Words`, `Syntax.Parser`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <syntax/lexer/words/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Syntax.Lexer.Words`, from `target/bootstrap/cpp-src/prismc/syntax/lexer/words.prism`.
namespace crate::syntax::lexer::words {

/// LexToken: unbounded fn Lex -> Lex
crate::syntax::lexer::Lex lex_token_f(const crate::syntax::lexer::Lex& l0_p0) {
    auto start_p1 = l0_p0.pos_p;
    auto c_p2 = crate::syntax::lexer::chars::peek_f(l0_p0);
    auto l_p3 = ({
        crate::syntax::lexer::Lex this_ = l0_p0;
        this_.path_next_p = false;
        (std::move(this_));
    });
    return l0_p0.path_next_p && ((crate::syntax::lexer::chars::is_digit_f(c_p2) || (c_p2 == Text::lit("#"))) || (c_p2 == Text::lit("[")))
        ? lex_path_token_f(l_p3, start_p1)
        : lex_token_at_f(l_p3, start_p1, c_p2);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexToken::cycle() const {
    const auto& l0_p0 = this->l0_p0;
    auto start_p1 = prism_rtl::deref(l0_p0).pos_p;
    auto c_p2 = crate::syntax::lexer::chars::peek_f(l0_p0);
    auto l_p3 = ({
        crate::syntax::lexer::Lex this_ = l0_p0;
        this_.path_next_p = false;
        (std::move(this_));
    });
    return prism_rtl::deref(l0_p0).path_next_p && ((crate::syntax::lexer::chars::is_digit_f(c_p2) || (c_p2 == Text::lit("#"))) || (c_p2 == Text::lit("[")))
        ? prism_rtl::more(prism_rtl::rc(LexPathToken(l_p3, start_p1)))
        : prism_rtl::more(prism_rtl::rc(LexTokenAt(l_p3, start_p1, c_p2)));
}


/// `Start LexToken, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_token_f(crate::syntax::lexer::Lex l0_p0) {
    return prism_rtl::make_rc<LexToken>(l0_p0);
}


/// LexPathToken: unbounded fn Lex, Nat -> Lex
crate::syntax::lexer::Lex lex_path_token_f(const crate::syntax::lexer::Lex& l_p0, const Nat& start_p1) {
    auto [segs_p2, l2_p3] = crate::syntax::lexer::literals::lex_path_f(l_p0);
    return crate::syntax::lexer::push_tok_f(l2_p3, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KPath{segs_p2}), start_p1, prism_rtl::deref(l2_p3).pos_p);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexPathToken::cycle() const {
    const auto& l_p0 = this->l_p0;
    const auto& start_p1 = this->start_p1;
    auto l_p0x = l_p0;
    auto start_p1x = start_p1;
    return crate::prelude::call_then(crate::syntax::lexer::literals::start_lex_path_f(l_p0x), [=](std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex> lex_path_f_963) {
        return ({
            auto [segs_p2, l2_p3] = lex_path_f_963;
            (prism_rtl::finished(crate::syntax::lexer::push_tok_f(l2_p3, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KPath{segs_p2}), start_p1x, prism_rtl::deref(l2_p3).pos_p)));
        });
    });
}


/// `Start LexPathToken, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_path_token_f(crate::syntax::lexer::Lex l_p0, Nat start_p1) {
    return prism_rtl::make_rc<LexPathToken>(l_p0, start_p1);
}


/// LexTokenAt: unbounded fn Lex, Nat, Text -> Lex
crate::syntax::lexer::Lex lex_token_at_f(const crate::syntax::lexer::Lex& l_p0, const Nat& start_p1, const Text& c_p2) {
    {
        auto&& m1093_0 = c_p2;
        if (m1093_0 == Text::lit("\"")) {
            auto [text_p3, l2_p4] = crate::syntax::lexer::literals::lex_text_f(l_p0);
            return crate::syntax::lexer::push_tok_f(l2_p4, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KText{Text::lit(""), text_p3}), start_p1, prism_rtl::deref(l2_p4).pos_p);
        }
    }
    {
        auto&& m1093_1 = c_p2;
        if (m1093_1 == Text::lit("\'")) {
            auto [ch_p5, l2_p6] = crate::syntax::lexer::literals::lex_char_f(l_p0);
            return crate::syntax::lexer::push_tok_f(l2_p6, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KChar{Text::lit(""), ch_p5}), start_p1, prism_rtl::deref(l2_p6).pos_p);
        }
    }
    {
        if (crate::syntax::lexer::chars::is_digit_f(c_p2)) {
            auto [kind_p7, l2_p8] = crate::syntax::lexer::literals::lex_number_f(l_p0, Text::lit(""));
            return crate::syntax::lexer::push_tok_f(l2_p8, kind_p7, start_p1, prism_rtl::deref(l2_p8).pos_p);
        }
    }
    {
        if (crate::syntax::lexer::chars::is_ident_start_f(c_p2)) {
            return lex_word_token_f(l_p0, Text::lit(""), start_p1);
        }
    }
    {
        if (crate::syntax::lexer::chars::contains_f(Text::lit("$@?~&^"), c_p2)) {
            return lex_sigils_f(l_p0);
        }
    }
    {
        auto&& m1093_5 = c_p2;
        if (m1093_5 == Text::lit("!")) {
            return crate::syntax::lexer::chars::peek_at_f(l_p0, Nat(1u)) == Text::lit("=")
                ? push_op_suffix_f(crate::syntax::lexer::chars::forward_f(l_p0, Nat(2u)), Text::lit("!="), start_p1)
                : lex_sigils_f(l_p0);
        }
    }
    {
        if (crate::syntax::lexer::chars::contains_f(Text::lit("([{"), c_p2)) {
            return lex_open_f(l_p0, c_p2, start_p1);
        }
    }
    {
        if (crate::syntax::lexer::chars::contains_f(Text::lit(")]}"), c_p2)) {
            return lex_close_f(l_p0, c_p2, start_p1);
        }
    }
    {
        auto&& m1093_8 = c_p2;
        if (m1093_8 == Text::lit(",")) {
            return crate::syntax::lexer::push_tok_f(crate::syntax::lexer::chars::bump_f(l_p0), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KComma{}), start_p1, start_p1 + Nat(1u));
        }
    }
    {
        auto&& m1093_9 = c_p2;
        if (m1093_9 == Text::lit(":")) {
            return crate::syntax::lexer::push_tok_f(crate::syntax::lexer::chars::bump_f(l_p0), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KColon{}), start_p1, start_p1 + Nat(1u));
        }
    }
    {
        auto&& m1093_10 = c_p2;
        if (m1093_10 == Text::lit(";")) {
            return crate::syntax::lexer::push_tok_f(crate::syntax::lexer::chars::bump_f(l_p0), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KSemi{}), start_p1, start_p1 + Nat(1u));
        }
    }
    {
        auto&& m1093_11 = c_p2;
        if (m1093_11 == Text::lit("\\")) {
            return lex_backslash_f(l_p0, start_p1);
        }
    }
    {
        auto&& m1093_12 = c_p2;
        if (m1093_12 == Text::lit("%")) {
            return crate::syntax::lexer::regexes::lex_regex_f(l_p0, Text::lit(""), start_p1);
        }
    }
    {
        auto&& m1093_13 = c_p2;
        if (m1093_13 == Text::lit("|")) {
            return lex_bar_f(l_p0, start_p1);
        }
    }
    {
        auto&& m1093_14 = c_p2;
        if (m1093_14 == Text::lit(".")) {
            return lex_dot_f(l_p0, start_p1);
        }
    }
    {
        auto&& _m = lex_operator_o(l_p0, start_p1);
        if (prism_rtl::is_some(_m)) {
            auto&& l2_p9 = prism_rtl::some_of(_m);
            return l2_p9;
        }
        if (prism_rtl::is_none(_m)) {
            auto l1_pa = crate::syntax::lexer::chars::bump_f(l_p0);
            auto l2_pb = crate::syntax::lexer::chars::lex_err_f(l1_pa, start_p1, prism_rtl::deref(l1_pa).pos_p, prism_rtl::cat("unexpected character `", c_p2, "`"));
            crate::syntax::lexer::Lex this_ = l2_pb;
            this_.last_ws_p = true;
            return this_;
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexTokenAt::cycle() const {
    const auto& l_p0 = this->l_p0;
    const auto& start_p1 = this->start_p1;
    const auto& c_p2 = this->c_p2;
    return ({
        ({
        auto&& m1093_0 = c_p2;
        (m1093_0 == Text::lit("\""));
    }) ? ({
        auto&& m1093_0 = c_p2;
        ({
        auto l_p0x = l_p0;
        auto start_p1x = start_p1;
        (crate::prelude::call_then(crate::syntax::lexer::literals::start_lex_text_f(l_p0x), [=, start_p1x = std::move(start_p1x)](std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex> lex_text_f_1139) {
        return ({
            auto [text_p3, l2_p4] = lex_text_f_1139;
            (prism_rtl::finished(crate::syntax::lexer::push_tok_f(l2_p4, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KText{Text::lit(""), text_p3}), start_p1x, prism_rtl::deref(l2_p4).pos_p)));
        });
    }));
    });
    })
        : ({
        auto&& m1093_1 = c_p2;
        (m1093_1 == Text::lit("\'"));
    }) ? ({
        auto&& m1093_1 = c_p2;
        ({
        auto l_p0x = l_p0;
        auto start_p1x = start_p1;
        (crate::prelude::call_then(crate::syntax::lexer::literals::start_lex_char_f(l_p0x), [=, start_p1x = std::move(start_p1x)](std::tuple<Text, crate::syntax::lexer::Lex> lex_char_f_1235) {
        return ({
            auto [ch_p5, l2_p6] = lex_char_f_1235;
            (prism_rtl::finished(crate::syntax::lexer::push_tok_f(l2_p6, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KChar{Text::lit(""), ch_p5}), start_p1x, prism_rtl::deref(l2_p6).pos_p)));
        });
    }));
    });
    })
        : ({
        crate::syntax::lexer::chars::is_digit_f(c_p2);
    }) ? ({
        auto l_p0x = l_p0;
        auto start_p1x = start_p1;
        (crate::prelude::call_then(crate::syntax::lexer::literals::start_lex_number_f(l_p0x, Text::lit("")), [=, start_p1x = std::move(start_p1x)](std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> lex_number_f_1347) {
        return ({
            auto [kind_p7, l2_p8] = lex_number_f_1347;
            (prism_rtl::finished(crate::syntax::lexer::push_tok_f(l2_p8, kind_p7, start_p1x, prism_rtl::deref(l2_p8).pos_p)));
        });
    }));
    })
        : ({
        crate::syntax::lexer::chars::is_ident_start_f(c_p2);
    }) ? prism_rtl::more(prism_rtl::rc(LexWordToken(l_p0, Text::lit(""), start_p1)))
        : ({
        crate::syntax::lexer::chars::contains_f(Text::lit("$@?~&^"), c_p2);
    }) ? prism_rtl::more(prism_rtl::rc(LexSigils(l_p0)))
        : ({
        auto&& m1093_5 = c_p2;
        (m1093_5 == Text::lit("!"));
    }) ? ({
        auto&& m1093_5 = c_p2;
        crate::syntax::lexer::chars::peek_at_f(l_p0, Nat(1u)) == Text::lit("=")
        ? prism_rtl::more(prism_rtl::rc(PushOpSuffix(crate::syntax::lexer::chars::forward_f(l_p0, Nat(2u)), Text::lit("!="), start_p1)))
        : prism_rtl::more(prism_rtl::rc(LexSigils(l_p0)));
    })
        : ({
        crate::syntax::lexer::chars::contains_f(Text::lit("([{"), c_p2);
    }) ? prism_rtl::finished(lex_open_f(l_p0, c_p2, start_p1))
        : ({
        crate::syntax::lexer::chars::contains_f(Text::lit(")]}"), c_p2);
    }) ? prism_rtl::finished(lex_close_f(l_p0, c_p2, start_p1))
        : ({
        auto&& m1093_8 = c_p2;
        (m1093_8 == Text::lit(","));
    }) ? ({
        auto&& m1093_8 = c_p2;
        prism_rtl::finished(crate::syntax::lexer::push_tok_f(crate::syntax::lexer::chars::bump_f(l_p0), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KComma{}), start_p1, start_p1 + Nat(1u)));
    })
        : ({
        auto&& m1093_9 = c_p2;
        (m1093_9 == Text::lit(":"));
    }) ? ({
        auto&& m1093_9 = c_p2;
        prism_rtl::finished(crate::syntax::lexer::push_tok_f(crate::syntax::lexer::chars::bump_f(l_p0), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KColon{}), start_p1, start_p1 + Nat(1u)));
    })
        : ({
        auto&& m1093_10 = c_p2;
        (m1093_10 == Text::lit(";"));
    }) ? ({
        auto&& m1093_10 = c_p2;
        prism_rtl::finished(crate::syntax::lexer::push_tok_f(crate::syntax::lexer::chars::bump_f(l_p0), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KSemi{}), start_p1, start_p1 + Nat(1u)));
    })
        : ({
        auto&& m1093_11 = c_p2;
        (m1093_11 == Text::lit("\\"));
    }) ? ({
        auto&& m1093_11 = c_p2;
        prism_rtl::finished(lex_backslash_f(l_p0, start_p1));
    })
        : ({
        auto&& m1093_12 = c_p2;
        (m1093_12 == Text::lit("%"));
    }) ? ({
        auto&& m1093_12 = c_p2;
        prism_rtl::more(prism_rtl::rc(crate::syntax::lexer::regexes::LexRegex(l_p0, Text::lit(""), start_p1)));
    })
        : ({
        auto&& m1093_13 = c_p2;
        (m1093_13 == Text::lit("|"));
    }) ? ({
        auto&& m1093_13 = c_p2;
        prism_rtl::finished(lex_bar_f(l_p0, start_p1));
    })
        : ({
        auto&& m1093_14 = c_p2;
        (m1093_14 == Text::lit("."));
    }) ? ({
        auto&& m1093_14 = c_p2;
        prism_rtl::finished(lex_dot_f(l_p0, start_p1));
    })
        : ({
        auto c_p2x = c_p2;
        auto l_p0x = l_p0;
        auto start_p1x = start_p1;
        (crate::prelude::call_then(start_lex_operator_o(l_p0x, start_p1x), [=, c_p2x = std::move(c_p2x)](std::optional<crate::syntax::lexer::Lex> lex_operator_o_1998) {
        return ({
            prism_rtl::is_some(lex_operator_o_1998) ? ({
            auto&& l2_p9 = prism_rtl::some_of(lex_operator_o_1998);
            prism_rtl::finished(l2_p9);
        })
            : prism_rtl::is_none(lex_operator_o_1998) ? ({
            auto l1_pa = crate::syntax::lexer::chars::bump_f(l_p0x);
            auto l2_pb = crate::syntax::lexer::chars::lex_err_f(l1_pa, start_p1x, prism_rtl::deref(l1_pa).pos_p, prism_rtl::cat("unexpected character `", c_p2x, "`"));
            (prism_rtl::finished(({
            crate::syntax::lexer::Lex this_ = l2_pb;
            this_.last_ws_p = true;
            (std::move(this_));
        })));
        })
            : throw prism_rtl::Panic("no arm matched");
        });
    }));
    });
    });
}


/// `Start LexTokenAt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_token_at_f(crate::syntax::lexer::Lex l_p0, Nat start_p1, Text c_p2) {
    return prism_rtl::make_rc<LexTokenAt>(l_p0, start_p1, c_p2);
}


/// LexOpen: fn Lex, Text, Nat -> Lex
crate::syntax::lexer::Lex lex_open_f(const crate::syntax::lexer::Lex& l_p0, const Text& c_p1, const Nat& start_p2) {
    auto prefix_p3 = ((c_p1 == Text::lit("[")) && crate::syntax::lexer::prefix_position_f(l_p0)) && (!crate::syntax::lexer::chars::next_is_space_f(l_p0, Nat(1u)));
    auto l2_p4 = ({
        crate::syntax::lexer::Lex this_ = crate::syntax::lexer::chars::bump_f(l_p0);
        this_.frames_p = crate::prelude::push(this_.frames_p, c_p1);
        (std::move(this_));
    });
    return crate::syntax::lexer::push_tok_f(l2_p4, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KOpen{c_p1, std::move(prefix_p3)}), start_p2, prism_rtl::deref(l2_p4).pos_p);
}


/// LexClose: fn Lex, Text, Nat -> Lex
crate::syntax::lexer::Lex lex_close_f(const crate::syntax::lexer::Lex& l_p0, const Text& c_p1, const Nat& start_p2) {
    auto kind_p3 = crate::syntax::lexer::open_of_f(c_p1);
    auto l1_p4 = crate::syntax::lexer::chars::bump_f(l_p0);
    auto l2_p5 = ({
        __label__ _done;
        prism_rtl::Slot<crate::syntax::lexer::Lex> _v;
        auto&& _m = crate::syntax::lexer::chars::last_o(prism_rtl::deref(l1_p4).frames_p);
        if (prism_rtl::is_some(_m)) {
            auto&& k_p6 = prism_rtl::some_of(_m);
            if (k_p6 == kind_p3) {
                _v.set(({
                    crate::syntax::lexer::Lex this_ = l1_p4;
                    this_.frames_p = crate::syntax::lexer::chars::pop_f(this_.frames_p);
                    (std::move(this_));
                }));
                goto _done;
            }
        }
        if (prism_rtl::is_some(_m)) {
            auto&& m2675_1 = prism_rtl::some_of(_m);
            if (m2675_1 == Text::lit("<<")) {
                _v.set(crate::syntax::lexer::chars::lex_err_f(l1_p4, start_p2, prism_rtl::deref(l1_p4).pos_p, prism_rtl::cat("`", c_p1, "` inside `<<`: expected `>>`")));
                goto _done;
            }
        }
        if (prism_rtl::is_some(_m)) {
            auto&& k_p7 = prism_rtl::some_of(_m);
            _v.set(({
                auto l3_p8 = crate::syntax::lexer::chars::lex_err_f(l1_p4, start_p2, prism_rtl::deref(l1_p4).pos_p, prism_rtl::cat("`", c_p1, "` closes a `", k_p7, "`"));
                ({
                crate::syntax::lexer::Lex this_ = l3_p8;
                this_.frames_p = crate::syntax::lexer::chars::pop_f(this_.frames_p);
                (std::move(this_));
            });
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::syntax::lexer::chars::lex_err_f(l1_p4, start_p2, prism_rtl::deref(l1_p4).pos_p, prism_rtl::cat("`", c_p1, "` closes nothing")));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return crate::syntax::lexer::push_tok_f(l2_p5, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KClose{kind_p3}), start_p2, prism_rtl::deref(l2_p5).pos_p);
}


/// LexBackslash: fn Lex, Nat -> Lex
crate::syntax::lexer::Lex lex_backslash_f(const crate::syntax::lexer::Lex& l_p0, const Nat& start_p1) {
    auto l1_p2 = crate::syntax::lexer::push_tok_f(crate::syntax::lexer::chars::bump_f(l_p0), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KBackslash{}), start_p1, start_p1 + Nat(1u));
    return crate::syntax::lexer::chars::peek_f(l1_p2) == Text::lit("|")
        ? ({
        auto l2_p3 = ({
            crate::syntax::lexer::Lex this_ = crate::syntax::lexer::chars::bump_f(l1_p2);
            this_.lambda_open_p = true;
            (std::move(this_));
        });
        (crate::syntax::lexer::push_tok_f(l2_p3, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLambdaBar{true}), prism_rtl::deref(l1_p2).pos_p, prism_rtl::deref(l1_p2).pos_p + Nat(1u)));
    })
        : l1_p2;
}


/// LexBar: fn Lex, Nat -> Lex
crate::syntax::lexer::Lex lex_bar_f(const crate::syntax::lexer::Lex& l_p0, const Nat& start_p1) {
    auto l1_p2 = crate::syntax::lexer::chars::bump_f(l_p0);
    return prism_rtl::deref(l1_p2).lambda_open_p
        ? ({
        auto l2_p3 = ({
            crate::syntax::lexer::Lex this_ = l1_p2;
            this_.lambda_open_p = false;
            (std::move(this_));
        });
        (crate::syntax::lexer::push_tok_f(l2_p3, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLambdaBar{false}), start_p1, prism_rtl::deref(l2_p3).pos_p));
    })
        : crate::syntax::lexer::push_tok_f(l1_p2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KBar{}), start_p1, prism_rtl::deref(l1_p2).pos_p);
}


/// LexDot: fn Lex, Nat -> Lex
crate::syntax::lexer::Lex lex_dot_f(const crate::syntax::lexer::Lex& l_p0, const Nat& start_p1) {
    return crate::syntax::lexer::chars::starts_with_f(l_p0, Text::lit(".."))
        ? crate::syntax::lexer::push_tok_f(crate::syntax::lexer::chars::forward_f(l_p0, Nat(2u)), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KDotDot{}), start_p1, start_p1 + Nat(2u))
        : ({
        auto prefix_p2 = crate::syntax::lexer::prefix_position_f(l_p0) && (!crate::syntax::lexer::chars::next_is_space_f(l_p0, Nat(1u)));
        auto l1_p3 = std::move(prefix_p2) && crate::syntax::lexer::chars::is_digit_f(crate::syntax::lexer::chars::peek_at_f(l_p0, Nat(1u)))
            ? crate::syntax::lexer::chars::lex_err_f(l_p0, start_p1, start_p1 + Nat(1u), Text::lit("a decimal literal has digits on both sides of its point: write `0.5`, not `.5`"))
            : l_p0;
        (crate::syntax::lexer::push_tok_f(crate::syntax::lexer::chars::bump_f(l1_p3), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KDot{std::move(prefix_p2)}), start_p1, start_p1 + Nat(1u)));
    });
}


/// PushOpSuffix: unbounded fn Lex, Text, Nat -> Lex
crate::syntax::lexer::Lex push_op_suffix_f(const crate::syntax::lexer::Lex& l_p0, const Text& op_p1, const Nat& start_p2) {
    return crate::syntax::lexer::takes_suffix_f(op_p1) && crate::syntax::lexer::chars::is_upper_f(crate::syntax::lexer::chars::peek_f(l_p0))
        ? ({
        auto [path_p3, l2_p4] = lex_qualified_path_f(l_p0);
        (crate::syntax::lexer::push_tok_f(l2_p4, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KSuffixed{op_p1, path_p3}), start_p2, prism_rtl::deref(l2_p4).pos_p));
    })
        : crate::syntax::lexer::push_tok_f(l_p0, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KOp{op_p1, false}), start_p2, l_p0.pos_p);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> PushOpSuffix::cycle() const {
    const auto& l_p0 = this->l_p0;
    const auto& op_p1 = this->op_p1;
    const auto& start_p2 = this->start_p2;
    return crate::syntax::lexer::takes_suffix_f(op_p1) && crate::syntax::lexer::chars::is_upper_f(crate::syntax::lexer::chars::peek_f(l_p0))
        ? ({
        auto l_p0x = l_p0;
        auto op_p1x = op_p1;
        auto start_p2x = start_p2;
        (crate::prelude::call_then(start_lex_qualified_path_f(l_p0x), [=, op_p1x = std::move(op_p1x), start_p2x = std::move(start_p2x)](std::tuple<Array<Text>, crate::syntax::lexer::Lex> lex_qualified_path_f_4539) {
        return ({
            auto [path_p3, l2_p4] = lex_qualified_path_f_4539;
            (prism_rtl::finished(crate::syntax::lexer::push_tok_f(l2_p4, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KSuffixed{op_p1x, path_p3}), start_p2x, prism_rtl::deref(l2_p4).pos_p)));
        });
    }));
    })
        : prism_rtl::finished(crate::syntax::lexer::push_tok_f(l_p0, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KOp{op_p1, false}), start_p2, prism_rtl::deref(l_p0).pos_p));
}


/// `Start PushOpSuffix, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_push_op_suffix_f(crate::syntax::lexer::Lex l_p0, Text op_p1, Nat start_p2) {
    return prism_rtl::make_rc<PushOpSuffix>(l_p0, op_p1, start_p2);
}


/// FirstOp: fn Lex -> Text
Text first_op_f(const crate::syntax::lexer::Lex& l_p0) {
    return crate::syntax::lexer::chars::match_here_f(crate::syntax::lexer::fat_arrow_on_f(l_p0)
        ? ([]() -> const Regex& { static const Regex r = Regex::lit("==>|<-|<=|<\\||->|-=|-\\?|\\+=|\\+\\?|\\*=|\\*\\?|\\/=|==|>=|=>|<|>|-|\\+|\\*|\\/|=", ""); return r; }())
        : ([]() -> const Regex& { static const Regex r = Regex::lit("==>|<-|<=|<\\||->|-=|-\\?|\\+=|\\+\\?|\\*=|\\*\\?|\\/=|==|>=|<|>|-|\\+|\\*|\\/|=", ""); return r; }()), l_p0);
}


/// EndsMark: fn Text -> Bool
bool ends_mark_f(const Text& a_p0) {
    return (a_p0 == Text::lit("")) || crate::syntax::lexer::chars::contains_f(Text::lit(" \n\r,)]}"), a_p0);
}


/// ClosesSquareOrBrace: fn ?Tok -> Bool
bool closes_square_or_brace_f(const std::optional<crate::syntax::lexer::Tok>& opt0) {
    if (prism_rtl::is_some(opt0)) {
        auto&& t_p0 = prism_rtl::some_of(opt0);
        return (prism_rtl::deref(t_p0).kind_p == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KClose{Text::lit("[")})) || (prism_rtl::deref(t_p0).kind_p == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KClose{Text::lit("{")}));
    }
    if (prism_rtl::is_none(opt0)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?LexOperator: unbounded fn Lex, Nat -> ?Lex
std::optional<crate::syntax::lexer::Lex> lex_operator_o(const crate::syntax::lexer::Lex& l_p0, const Nat& start_p1) {
    auto c_p2 = crate::syntax::lexer::chars::peek_f(l_p0);
    auto after_p3 = crate::syntax::lexer::chars::peek_at_f(l_p0, Nat(1u));
    auto non_empty_p4 = (((c_p2 == Text::lit("+")) && (!l_p0.last_ws_p)) && closes_square_or_brace_f(crate::syntax::lexer::chars::last_o(l_p0.tokens_p))) && (ends_mark_f(after_p3) || ((after_p3 == Text::lit("?")) && ends_mark_f(crate::syntax::lexer::chars::peek_at_f(l_p0, Nat(2u)))));
    return (c_p2 == Text::lit("-")) && crate::syntax::lexer::chars::contains_f(Text::lit(",)]}"), after_p3)
        ? std::optional(crate::syntax::lexer::push_tok_f(crate::syntax::lexer::chars::bump_f(l_p0), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KAbsent{}), start_p1, start_p1 + Nat(1u)))
        : std::move(non_empty_p4)
        ? std::optional(non_empty_mark_f(l_p0, start_p1, after_p3))
        : crate::syntax::lexer::chars::starts_with_f(l_p0, Text::lit("<<"))
        ? std::optional(open_type_args_f(l_p0, start_p1))
        : crate::syntax::lexer::chars::starts_with_f(l_p0, Text::lit(">>")) && (crate::syntax::lexer::chars::last_o(l_p0.frames_p) == std::optional(Text::lit("<<")))
        ? std::optional(close_type_args_f(l_p0, start_p1))
        : crate::syntax::lexer::chars::starts_with_f(l_p0, Text::lit(">>"))
        ? std::optional(crate::syntax::lexer::chars::lex_err_f(crate::syntax::lexer::push_tok_f(crate::syntax::lexer::chars::forward_f(l_p0, Nat(2u)), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KGtGt{}), start_p1, start_p1 + Nat(2u)), start_p1, start_p1 + Nat(2u), Text::lit("`>>` closes explicit type arguments, and none is open (Prism has no shift operators)")))
        : ({
        __label__ _done;
        prism_rtl::Slot<std::optional<crate::syntax::lexer::Lex>> _v;
        auto&& _m = first_op_f(l_p0);
        {
            auto&& m6465_0 = _m;
            if (m6465_0 == Text::lit("")) {
                _v.set(std::optional<crate::syntax::lexer::Lex>{});
                goto _done;
            }
        }
        {
            auto&& op_p5 = _m;
            _v.set(std::optional(push_operator_f(l_p0, op_p5, start_p1)));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::optional<crate::syntax::lexer::Lex>> LexOperator::cycle() const {
    const auto& l_p0 = this->l_p0;
    const auto& start_p1 = this->start_p1;
    auto c_p2 = crate::syntax::lexer::chars::peek_f(l_p0);
    auto after_p3 = crate::syntax::lexer::chars::peek_at_f(l_p0, Nat(1u));
    auto non_empty_p4 = (((c_p2 == Text::lit("+")) && (!prism_rtl::deref(l_p0).last_ws_p)) && closes_square_or_brace_f(crate::syntax::lexer::chars::last_o(prism_rtl::deref(l_p0).tokens_p))) && (ends_mark_f(after_p3) || ((after_p3 == Text::lit("?")) && ends_mark_f(crate::syntax::lexer::chars::peek_at_f(l_p0, Nat(2u)))));
    return (c_p2 == Text::lit("-")) && crate::syntax::lexer::chars::contains_f(Text::lit(",)]}"), after_p3)
        ? prism_rtl::finished(std::optional(crate::syntax::lexer::push_tok_f(crate::syntax::lexer::chars::bump_f(l_p0), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KAbsent{}), start_p1, start_p1 + Nat(1u))))
        : std::move(non_empty_p4)
        ? prism_rtl::finished(std::optional(non_empty_mark_f(l_p0, start_p1, after_p3)))
        : crate::syntax::lexer::chars::starts_with_f(l_p0, Text::lit("<<"))
        ? prism_rtl::finished(std::optional(open_type_args_f(l_p0, start_p1)))
        : crate::syntax::lexer::chars::starts_with_f(l_p0, Text::lit(">>")) && (crate::syntax::lexer::chars::last_o(prism_rtl::deref(l_p0).frames_p) == std::optional(Text::lit("<<")))
        ? prism_rtl::finished(std::optional(close_type_args_f(l_p0, start_p1)))
        : crate::syntax::lexer::chars::starts_with_f(l_p0, Text::lit(">>"))
        ? prism_rtl::finished(std::optional(crate::syntax::lexer::chars::lex_err_f(crate::syntax::lexer::push_tok_f(crate::syntax::lexer::chars::forward_f(l_p0, Nat(2u)), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KGtGt{}), start_p1, start_p1 + Nat(2u)), start_p1, start_p1 + Nat(2u), Text::lit("`>>` closes explicit type arguments, and none is open (Prism has no shift operators)"))))
        : ({
        auto&& _m = first_op_f(l_p0);
        ({
        auto&& m6465_0 = _m;
        (m6465_0 == Text::lit(""));
    }) ? ({
        auto&& m6465_0 = _m;
        prism_rtl::finished(std::optional<crate::syntax::lexer::Lex>{});
    })
        : ({
        auto&& op_p5 = _m;
        prism_rtl::finished(std::optional(push_operator_f(l_p0, op_p5, start_p1)));
    });
    });
}


/// `Start LexOperator, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<crate::syntax::lexer::Lex>> start_lex_operator_o(crate::syntax::lexer::Lex l_p0, Nat start_p1) {
    return prism_rtl::make_rc<LexOperator>(l_p0, start_p1);
}


/// NonEmptyMark: fn Lex, Nat, Text -> Lex
crate::syntax::lexer::Lex non_empty_mark_f(const crate::syntax::lexer::Lex& l_p0, const Nat& start_p1, const Text& after_p2) {
    auto l1_p3 = crate::syntax::lexer::push_tok_f(crate::syntax::lexer::chars::bump_f(l_p0), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KNonEmpty{}), start_p1, start_p1 + Nat(1u));
    return after_p2 == Text::lit("?")
        ? crate::syntax::lexer::push_tok_f(crate::syntax::lexer::chars::bump_f(l1_p3), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KFree{Text::lit("?")}), prism_rtl::deref(l1_p3).pos_p, prism_rtl::deref(l1_p3).pos_p + Nat(1u))
        : l1_p3;
}


/// OpenTypeArgs: fn Lex, Nat -> Lex
crate::syntax::lexer::Lex open_type_args_f(const crate::syntax::lexer::Lex& l_p0, const Nat& start_p1) {
    auto touching_p2 = (!l_p0.last_ws_p) && is_name_tok_f(crate::syntax::lexer::chars::last_o(l_p0.tokens_p));
    auto l1_p3 = crate::syntax::lexer::chars::forward_f(l_p0, Nat(2u));
    auto l2_p4 = std::move(touching_p2)
        ? l1_p3
        : crate::syntax::lexer::chars::lex_err_f(l1_p3, start_p1, prism_rtl::deref(l1_p3).pos_p, Text::lit("`<<` opens explicit type arguments and must touch a name on its left (Prism has no shift operators)"));
    auto l3_p5 = ({
        crate::syntax::lexer::Lex this_ = l2_p4;
        this_.frames_p = crate::prelude::push(this_.frames_p, Text::lit("<<"));
        (std::move(this_));
    });
    return crate::syntax::lexer::push_tok_f(l3_p5, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLtLt{}), start_p1, prism_rtl::deref(l3_p5).pos_p);
}


/// IsNameTok: fn ?Tok -> Bool
bool is_name_tok_f(const std::optional<crate::syntax::lexer::Tok>& opt0) {
    if (prism_rtl::is_some(opt0)) {
        auto&& t_p0 = prism_rtl::some_of(opt0);
        auto&& _m = prism_rtl::deref(t_p0).kind_p;
        if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
            return true;
        }
        {
            return false;
        }
    }
    if (prism_rtl::is_none(opt0)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// CloseTypeArgs: fn Lex, Nat -> Lex
crate::syntax::lexer::Lex close_type_args_f(const crate::syntax::lexer::Lex& l_p0, const Nat& start_p1) {
    auto l1_p2 = ({
        crate::syntax::lexer::Lex this_ = crate::syntax::lexer::chars::forward_f(l_p0, Nat(2u));
        this_.frames_p = crate::syntax::lexer::chars::pop_f(this_.frames_p);
        (std::move(this_));
    });
    return crate::syntax::lexer::push_tok_f(l1_p2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KGtGt{}), start_p1, prism_rtl::deref(l1_p2).pos_p);
}


/// PushOperator: unbounded fn Lex, Text, Nat -> Lex
crate::syntax::lexer::Lex push_operator_f(const crate::syntax::lexer::Lex& l_p0, const Text& op_p1, const Nat& start_p2) {
    auto l1_p3 = crate::syntax::lexer::chars::forward_f(l_p0, crate::prelude::len_text(op_p1));
    return (((op_p1 == Text::lit("+")) || (op_p1 == Text::lit("-"))) || (op_p1 == Text::lit("-?"))) && (!crate::syntax::lexer::chars::is_upper_f(crate::syntax::lexer::chars::peek_f(l1_p3)))
        ? crate::syntax::lexer::push_tok_f(l1_p3, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KOp{op_p1, crate::syntax::lexer::prefix_position_f(l1_p3) && (!crate::syntax::lexer::chars::next_is_space_f(l1_p3, Nat(0u)))}), start_p2, prism_rtl::deref(l1_p3).pos_p)
        : push_op_suffix_f(l1_p3, op_p1, start_p2);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> PushOperator::cycle() const {
    const auto& l_p0 = this->l_p0;
    const auto& op_p1 = this->op_p1;
    const auto& start_p2 = this->start_p2;
    auto l1_p3 = crate::syntax::lexer::chars::forward_f(l_p0, crate::prelude::len_text(op_p1));
    return (((op_p1 == Text::lit("+")) || (op_p1 == Text::lit("-"))) || (op_p1 == Text::lit("-?"))) && (!crate::syntax::lexer::chars::is_upper_f(crate::syntax::lexer::chars::peek_f(l1_p3)))
        ? prism_rtl::finished(crate::syntax::lexer::push_tok_f(l1_p3, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KOp{op_p1, crate::syntax::lexer::prefix_position_f(l1_p3) && (!crate::syntax::lexer::chars::next_is_space_f(l1_p3, Nat(0u)))}), start_p2, prism_rtl::deref(l1_p3).pos_p))
        : prism_rtl::more(prism_rtl::rc(PushOpSuffix(l1_p3, op_p1, start_p2)));
}


/// `Start PushOperator, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_push_operator_f(crate::syntax::lexer::Lex l_p0, Text op_p1, Nat start_p2) {
    return prism_rtl::make_rc<PushOperator>(l_p0, op_p1, start_p2);
}


/// LexSigils: unbounded fn Lex -> Lex
crate::syntax::lexer::Lex lex_sigils_f(const crate::syntax::lexer::Lex& l0_p0) {
    auto start_p1 = l0_p0.pos_p;
    auto [sigils_p3, caret_p4, l_p5] = read_sigils_f(l0_p0);
    auto next_p2 = crate::syntax::lexer::chars::peek_f(l_p5);
    return caret_p4
        ? lex_caret_f(l_p5, start_p1, sigils_p3, next_p2)
        : ((crate::syntax::lexer::chars::is_ident_start_f(next_p2) || crate::syntax::lexer::chars::is_digit_f(next_p2)) || (next_p2 == Text::lit("\""))) || (next_p2 == Text::lit("%"))
        ? lex_attached_f(l_p5, start_p1, sigils_p3, next_p2)
        : ((sigils_p3 == Text::lit("&")) && (next_p2 == Text::lit("."))) && crate::syntax::lexer::chars::is_lower_f(crate::syntax::lexer::chars::peek_at_f(l_p5, Nat(1u)))
        ? crate::syntax::lexer::push_tok_f(crate::syntax::lexer::chars::bump_f(l_p5), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLensDot{}), start_p1, prism_rtl::deref(l_p5).pos_p + Nat(1u))
        : free_sigils_f(l_p5, start_p1, sigils_p3);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexSigils::cycle() const {
    const auto& l0_p0 = this->l0_p0;
    auto start_p1 = prism_rtl::deref(l0_p0).pos_p;
    auto l0_p0x = l0_p0;
    return crate::prelude::call_then(start_read_sigils_f(l0_p0x), [=](std::tuple<Text, bool, crate::syntax::lexer::Lex> read_sigils_f_8705) {
        return ({
            auto [sigils_p3, caret_p4, l_p5] = read_sigils_f_8705;
            auto next_p2 = crate::syntax::lexer::chars::peek_f(l_p5);
            caret_p4
            ? prism_rtl::more(prism_rtl::rc(LexCaret(l_p5, start_p1, sigils_p3, next_p2)))
            : ((crate::syntax::lexer::chars::is_ident_start_f(next_p2) || crate::syntax::lexer::chars::is_digit_f(next_p2)) || (next_p2 == Text::lit("\""))) || (next_p2 == Text::lit("%"))
            ? prism_rtl::more(prism_rtl::rc(LexAttached(l_p5, start_p1, sigils_p3, next_p2)))
            : ((sigils_p3 == Text::lit("&")) && (next_p2 == Text::lit("."))) && crate::syntax::lexer::chars::is_lower_f(crate::syntax::lexer::chars::peek_at_f(l_p5, Nat(1u)))
            ? prism_rtl::finished(crate::syntax::lexer::push_tok_f(crate::syntax::lexer::chars::bump_f(l_p5), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLensDot{}), start_p1, prism_rtl::deref(l_p5).pos_p + Nat(1u)))
            : prism_rtl::finished(free_sigils_f(l_p5, start_p1, sigils_p3));
        });
    });
}


/// `Start LexSigils, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_sigils_f(crate::syntax::lexer::Lex l0_p0) {
    return prism_rtl::make_rc<LexSigils>(l0_p0);
}


/// ReadSigils: unbounded fn Lex -> ((Text, Bool, Lex))
std::tuple<Text, bool, crate::syntax::lexer::Lex> read_sigils_f(const crate::syntax::lexer::Lex& l0_p0) {
    std::tuple<Text, bool, crate::syntax::lexer::Lex> this_ = std::tuple{Text::lit(""), false, l0_p0};
    crate::syntax::lexer::Lex l_p1 = l0_p0;
    Text sigils_p2 = Text::lit("");
    bool caret_p3 = false;
    bool going_p4 = true;
    while (std::move(going_p4)) {
        auto c_p5 = crate::syntax::lexer::chars::peek_f(l_p1);
        if (c_p5 == Text::lit("^")) {
            l_p1 = crate::syntax::lexer::chars::bump_f(l_p1);
            caret_p3 = true;
            going_p4 = false;
        } else if (crate::syntax::lexer::chars::is_sigil_char_f(c_p5) && (!((c_p5 == Text::lit("!")) && (crate::syntax::lexer::chars::peek_at_f(l_p1, Nat(1u)) == Text::lit("="))))) {
            l_p1 = crate::syntax::lexer::chars::bump_f(l_p1);
            sigils_p2 = prism_rtl::cat(sigils_p2, c_p5);
        } else  {
            going_p4 = false;
        }
    }
    this_ = std::tuple{sigils_p2, std::move(caret_p3), l_p1};
    return this_;
}


prism_rtl::Turn<std::tuple<Text, bool, crate::syntax::lexer::Lex>> ReadSigils::cycle() const {
    const auto& l0_p0 = this->l0_p0;
    std::tuple<Text, bool, crate::syntax::lexer::Lex> this_ = std::tuple{Text::lit(""), false, l0_p0};
    crate::syntax::lexer::Lex l_p1 = l0_p0;
    Text sigils_p2 = Text::lit("");
    bool caret_p3 = false;
    bool going_p4 = true;
    return crate::prelude::call_then(crate::prelude::loop_job(std::tuple{std::move(this_), std::move(caret_p3), std::move(going_p4), std::move(l_p1), std::move(sigils_p2)}, [=](std::tuple<std::tuple<Text, bool, crate::syntax::lexer::Lex>, bool, bool, crate::syntax::lexer::Lex, Text> _p0) {
        auto this_ = std::get<0>(_p0);
        auto caret_p3 = std::get<1>(_p0);
        auto going_p4 = std::get<2>(_p0);
        auto l_p1 = std::get<3>(_p0);
        auto sigils_p2 = std::get<4>(_p0);
        return going_p4
            ? ({
            auto c_p5 = crate::syntax::lexer::chars::peek_f(l_p1);
            if (c_p5 == Text::lit("^")) {
                l_p1 = crate::syntax::lexer::chars::bump_f(l_p1);
                caret_p3 = true;
                going_p4 = false;
            } else if (crate::syntax::lexer::chars::is_sigil_char_f(c_p5) && (!((c_p5 == Text::lit("!")) && (crate::syntax::lexer::chars::peek_at_f(l_p1, Nat(1u)) == Text::lit("="))))) {
                l_p1 = crate::syntax::lexer::chars::bump_f(l_p1);
                sigils_p2 = prism_rtl::cat(sigils_p2, c_p5);
            } else  {
                going_p4 = false;
            }
            Expected<std::tuple<std::tuple<Text, bool, crate::syntax::lexer::Lex>, bool, bool, crate::syntax::lexer::Lex, Text>, std::tuple<std::tuple<Text, bool, crate::syntax::lexer::Lex>, bool, bool, crate::syntax::lexer::Lex, Text>>(std::tuple{this_, caret_p3, going_p4, l_p1, sigils_p2});
        })
            : Expected<std::tuple<std::tuple<Text, bool, crate::syntax::lexer::Lex>, bool, bool, crate::syntax::lexer::Lex, Text>, std::tuple<std::tuple<Text, bool, crate::syntax::lexer::Lex>, bool, bool, crate::syntax::lexer::Lex, Text>>(unexpected(std::tuple{this_, caret_p3, going_p4, l_p1, sigils_p2}));
    }), [=](std::tuple<std::tuple<Text, bool, crate::syntax::lexer::Lex>, bool, bool, crate::syntax::lexer::Lex, Text> _p0) {
        auto this_ = std::get<0>(_p0);
        auto caret_p3 = std::get<1>(_p0);
        auto going_p4 = std::get<2>(_p0);
        auto l_p1 = std::get<3>(_p0);
        auto sigils_p2 = std::get<4>(_p0);
        return ({
            this_ = std::tuple{sigils_p2, caret_p3, l_p1};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start ReadSigils, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, bool, crate::syntax::lexer::Lex>> start_read_sigils_f(crate::syntax::lexer::Lex l0_p0) {
    return prism_rtl::make_rc<ReadSigils>(l0_p0);
}


/// LexCaret: unbounded fn Lex, Nat, Text, Text -> Lex
crate::syntax::lexer::Lex lex_caret_f(const crate::syntax::lexer::Lex& l_p0, const Nat& start_p1, const Text& sigils_p2, const Text& next_p3) {
    return crate::syntax::lexer::chars::is_upper_f(next_p3) && (sigils_p2 == Text::lit(""))
        ? ({
        auto [path_p4, l2_p5] = lex_qualified_path_f(l_p0);
        (crate::syntax::lexer::push_tok_f(l2_p5, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KTrait{path_p4}), start_p1, prism_rtl::deref(l2_p5).pos_p));
    })
        : ({
        auto&& _skipped_p7 = lex_qualified_path_f(l_p0);
        auto&& skipped_p7 = std::get<1>(_skipped_p7);
        auto l2_p6 = crate::syntax::lexer::chars::is_ident_start_f(next_p3) ? skipped_p7 : l_p0;
        (crate::syntax::lexer::chars::lex_err_f(l2_p6, start_p1, crate::prelude::max(prism_rtl::deref(l2_p6).pos_p, l_p0.pos_p), Text::lit("`^` marks a trait and attaches to its uppercase name: no trait is a value")));
    });
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexCaret::cycle() const {
    const auto& l_p0 = this->l_p0;
    const auto& start_p1 = this->start_p1;
    const auto& sigils_p2 = this->sigils_p2;
    const auto& next_p3 = this->next_p3;
    return crate::syntax::lexer::chars::is_upper_f(next_p3) && (sigils_p2 == Text::lit(""))
        ? ({
        auto l_p0x = l_p0;
        auto start_p1x = start_p1;
        (crate::prelude::call_then(start_lex_qualified_path_f(l_p0x), [=, start_p1x = std::move(start_p1x)](std::tuple<Array<Text>, crate::syntax::lexer::Lex> lex_qualified_path_f_9909) {
        return ({
            auto [path_p4, l2_p5] = lex_qualified_path_f_9909;
            (prism_rtl::finished(crate::syntax::lexer::push_tok_f(l2_p5, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KTrait{path_p4}), start_p1x, prism_rtl::deref(l2_p5).pos_p)));
        });
    }));
    })
        : ({
        auto l_p0x = l_p0;
        auto next_p3x = next_p3;
        auto start_p1x = start_p1;
        (crate::prelude::call_then(start_lex_qualified_path_f(l_p0x), [=, next_p3x = std::move(next_p3x), start_p1x = std::move(start_p1x)](std::tuple<Array<Text>, crate::syntax::lexer::Lex> lex_qualified_path_f_10021) {
        return ({
            auto&& _skipped_p7 = lex_qualified_path_f_10021;
            auto&& skipped_p7 = std::get<1>(_skipped_p7);
            auto l2_p6 = crate::syntax::lexer::chars::is_ident_start_f(next_p3x)
                ? skipped_p7
                : l_p0x;
            (prism_rtl::finished(crate::syntax::lexer::chars::lex_err_f(l2_p6, start_p1x, crate::prelude::max(prism_rtl::deref(l2_p6).pos_p, prism_rtl::deref(l_p0x).pos_p), Text::lit("`^` marks a trait and attaches to its uppercase name: no trait is a value"))));
        });
    }));
    });
}


/// `Start LexCaret, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_caret_f(crate::syntax::lexer::Lex l_p0, Nat start_p1, Text sigils_p2, Text next_p3) {
    return prism_rtl::make_rc<LexCaret>(l_p0, start_p1, sigils_p2, next_p3);
}


/// LexAttached: unbounded fn Lex, Nat, Text, Text -> Lex
crate::syntax::lexer::Lex lex_attached_f(const crate::syntax::lexer::Lex& l_p0, const Nat& start_p1, const Text& sigils_p2, const Text& next_p3) {
    return next_p3 == Text::lit("\"")
        ? ({
        auto [text_p4, l2_p5] = crate::syntax::lexer::literals::lex_text_f(l_p0);
        (crate::syntax::lexer::push_tok_f(l2_p5, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KText{sigils_p2, text_p4}), start_p1, prism_rtl::deref(l2_p5).pos_p));
    })
        : crate::syntax::lexer::chars::is_digit_f(next_p3)
        ? ({
        auto [kind_p6, l2_p7] = crate::syntax::lexer::literals::lex_number_f(l_p0, sigils_p2);
        (crate::syntax::lexer::push_tok_f(l2_p7, kind_p6, start_p1, prism_rtl::deref(l2_p7).pos_p));
    })
        : next_p3 == Text::lit("%")
        ? crate::syntax::lexer::regexes::lex_regex_f(l_p0, sigils_p2, start_p1)
        : lex_word_token_f(l_p0, sigils_p2, start_p1);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexAttached::cycle() const {
    const auto& l_p0 = this->l_p0;
    const auto& start_p1 = this->start_p1;
    const auto& sigils_p2 = this->sigils_p2;
    const auto& next_p3 = this->next_p3;
    return next_p3 == Text::lit("\"")
        ? ({
        auto l_p0x = l_p0;
        auto sigils_p2x = sigils_p2;
        auto start_p1x = start_p1;
        (crate::prelude::call_then(crate::syntax::lexer::literals::start_lex_text_f(l_p0x), [=, sigils_p2x = std::move(sigils_p2x), start_p1x = std::move(start_p1x)](std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex> lex_text_f_10360) {
        return ({
            auto [text_p4, l2_p5] = lex_text_f_10360;
            (prism_rtl::finished(crate::syntax::lexer::push_tok_f(l2_p5, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KText{sigils_p2x, text_p4}), start_p1x, prism_rtl::deref(l2_p5).pos_p)));
        });
    }));
    })
        : crate::syntax::lexer::chars::is_digit_f(next_p3)
        ? ({
        auto l_p0x = l_p0;
        auto sigils_p2x = sigils_p2;
        auto start_p1x = start_p1;
        (crate::prelude::call_then(crate::syntax::lexer::literals::start_lex_number_f(l_p0x, sigils_p2x), [=, start_p1x = std::move(start_p1x)](std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> lex_number_f_10480) {
        return ({
            auto [kind_p6, l2_p7] = lex_number_f_10480;
            (prism_rtl::finished(crate::syntax::lexer::push_tok_f(l2_p7, kind_p6, start_p1x, prism_rtl::deref(l2_p7).pos_p)));
        });
    }));
    })
        : next_p3 == Text::lit("%")
        ? prism_rtl::more(prism_rtl::rc(crate::syntax::lexer::regexes::LexRegex(l_p0, sigils_p2, start_p1)))
        : prism_rtl::more(prism_rtl::rc(LexWordToken(l_p0, sigils_p2, start_p1)));
}


/// `Start LexAttached, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_attached_f(crate::syntax::lexer::Lex l_p0, Nat start_p1, Text sigils_p2, Text next_p3) {
    return prism_rtl::make_rc<LexAttached>(l_p0, start_p1, sigils_p2, next_p3);
}


/// FreeSigils: fn Lex, Nat, Text -> Lex
crate::syntax::lexer::Lex free_sigils_f(const crate::syntax::lexer::Lex& l0_p0, const Nat& start_p1, const Text& sigils_p2) {
    crate::syntax::lexer::Lex this_ = l0_p0;
    auto space_after_p3 = crate::syntax::lexer::chars::next_is_space_f(this_, Nat(0u));
    auto all_p6 = crate::syntax::lexer::chars::fold_chars_f(sigils_p2, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::once_job([=]() {
            return ({
                auto acc_p4 = p0;
                auto c_p5 = p1;
                (prism_rtl::finished(crate::prelude::push(acc_p4, c_p5)));
            });
        });
    })));
    for (auto&& [i10960, v10960] : prism_rtl::enumerate(all_p6)) {
        auto k10960 = crate::prelude::nat_of(i10960);
        auto s_p7 = v10960;
        auto at_p8 = start_p1 + k10960;
        if (std::move(space_after_p3) && ((k10960 + Nat(1u)) == crate::prelude::len(all_p6))) {
            if (s_p7 == Text::lit("!")) {
                this_ = crate::syntax::lexer::chars::lex_err_f(this_, at_p8, at_p8 + Nat(1u), Text::lit("`!` is never free: no event fires a constant (write `!e` touching its name)"));
            }
            if (s_p7 == Text::lit("&")) {
                this_ = crate::syntax::lexer::chars::lex_err_f(this_, at_p8, at_p8 + Nat(1u), Text::lit("`&` is never free: no reference exists outside the value an `update` block names"));
            }
        }
        this_ = crate::syntax::lexer::push_tok_f(this_, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KFree{s_p7}), at_p8, at_p8 + Nat(1u));
    }
    return this_;
}


/// LexQualifiedPath: unbounded fn Lex -> (([Text], Lex))
std::tuple<Array<Text>, crate::syntax::lexer::Lex> lex_qualified_path_f(const crate::syntax::lexer::Lex& l0_p0) {
    std::tuple<Array<Text>, crate::syntax::lexer::Lex> this_ = std::tuple{Array<Text>{}, l0_p0};
    auto [first_p1, l1_p2] = lex_ident_f(l0_p0);
    Array<Text> path_p3 = Array(std::vector{first_p1});
    crate::syntax::lexer::Lex l_p4 = l1_p2;
    bool going_p5 = true;
    while (std::move(going_p5)) {
        auto last_p6 = crate::prelude::or_(crate::syntax::lexer::chars::last_o(path_p3), Text::lit(""));
        auto next_p7 = crate::syntax::lexer::chars::peek_at_f(l_p4, Nat(1u));
        if ((crate::syntax::lexer::chars::peek_f(l_p4) != Text::lit(".")) || (!crate::syntax::lexer::chars::is_upper_f(crate::syntax::lexer::chars::head_f(last_p6)))) {
            going_p5 = false;
        } else if (crate::syntax::lexer::chars::is_upper_f(next_p7)) {
            auto [seg_p8, l2_p9] = lex_ident_f(crate::syntax::lexer::chars::bump_f(l_p4));
            path_p3 = crate::prelude::push(path_p3, seg_p8);
            l_p4 = l2_p9;
        } else  {
            going_p5 = false;
            if (crate::syntax::lexer::chars::is_ident_start_f(next_p7)) {
                auto [w_pa, l2_pb] = lex_ident_f(crate::syntax::lexer::chars::bump_f(l_p4));
                if (crate::syntax::lexer::chars::is_reserved_ctor_f(w_pa)) {
                    path_p3 = crate::prelude::push(path_p3, w_pa);
                    l_p4 = l2_pb;
                }
            }
        }
    }
    this_ = std::tuple{path_p3, l_p4};
    return this_;
}


prism_rtl::Turn<std::tuple<Array<Text>, crate::syntax::lexer::Lex>> LexQualifiedPath::cycle() const {
    const auto& l0_p0 = this->l0_p0;
    std::tuple<Array<Text>, crate::syntax::lexer::Lex> this_ = std::tuple{Array<Text>{}, l0_p0};
    auto [first_p1, l1_p2] = lex_ident_f(l0_p0);
    Array<Text> path_p3 = Array(std::vector{first_p1});
    crate::syntax::lexer::Lex l_p4 = l1_p2;
    bool going_p5 = true;
    return crate::prelude::call_then(crate::prelude::loop_job(std::tuple{std::move(this_), std::move(going_p5), std::move(l_p4), std::move(path_p3)}, [=](std::tuple<std::tuple<Array<Text>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<Text>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going_p5 = std::get<1>(_p0);
        auto l_p4 = std::get<2>(_p0);
        auto path_p3 = std::get<3>(_p0);
        return going_p5
            ? ({
            auto last_p6 = crate::prelude::or_(crate::syntax::lexer::chars::last_o(path_p3), Text::lit(""));
            auto next_p7 = crate::syntax::lexer::chars::peek_at_f(l_p4, Nat(1u));
            if ((crate::syntax::lexer::chars::peek_f(l_p4) != Text::lit(".")) || (!crate::syntax::lexer::chars::is_upper_f(crate::syntax::lexer::chars::head_f(last_p6)))) {
                going_p5 = false;
            } else if (crate::syntax::lexer::chars::is_upper_f(next_p7)) {
                auto [seg_p8, l2_p9] = lex_ident_f(crate::syntax::lexer::chars::bump_f(l_p4));
                path_p3 = crate::prelude::push(path_p3, seg_p8);
                l_p4 = l2_p9;
            } else  {
                going_p5 = false;
                if (crate::syntax::lexer::chars::is_ident_start_f(next_p7)) {
                    auto [w_pa, l2_pb] = lex_ident_f(crate::syntax::lexer::chars::bump_f(l_p4));
                    if (crate::syntax::lexer::chars::is_reserved_ctor_f(w_pa)) {
                        path_p3 = crate::prelude::push(path_p3, w_pa);
                        l_p4 = l2_pb;
                    }
                }
            }
            Expected<std::tuple<std::tuple<Array<Text>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<Text>>, std::tuple<std::tuple<Array<Text>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<Text>>>(std::tuple{this_, going_p5, l_p4, path_p3});
        })
            : Expected<std::tuple<std::tuple<Array<Text>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<Text>>, std::tuple<std::tuple<Array<Text>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<Text>>>(unexpected(std::tuple{this_, going_p5, l_p4, path_p3}));
    }), [=](std::tuple<std::tuple<Array<Text>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<Text>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going_p5 = std::get<1>(_p0);
        auto l_p4 = std::get<2>(_p0);
        auto path_p3 = std::get<3>(_p0);
        return ({
            this_ = std::tuple{path_p3, l_p4};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start LexQualifiedPath, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<Text>, crate::syntax::lexer::Lex>> start_lex_qualified_path_f(crate::syntax::lexer::Lex l0_p0) {
    return prism_rtl::make_rc<LexQualifiedPath>(l0_p0);
}


/// LexIdent: unbounded fn Lex -> ((Text, Lex))
std::tuple<Text, crate::syntax::lexer::Lex> lex_ident_f(const crate::syntax::lexer::Lex& l0_p0) {
    auto word_p1 = crate::syntax::lexer::chars::match_here_f(([]() -> const Regex& { static const Regex r = Regex::lit("[A-Za-z0-9_]*", ""); return r; }()), l0_p0);
    auto l_p2 = ({
        crate::syntax::lexer::Lex this_ = l0_p0;
        this_.pos_p = this_.pos_p + crate::prelude::len_text(word_p1);
        (std::move(this_));
    });
    return std::tuple{word_p1, l_p2};
}


prism_rtl::Turn<std::tuple<Text, crate::syntax::lexer::Lex>> LexIdent::cycle() const {
    const auto& l0_p0 = this->l0_p0;
    auto word_p1 = crate::syntax::lexer::chars::match_here_f(([]() -> const Regex& { static const Regex r = Regex::lit("[A-Za-z0-9_]*", ""); return r; }()), l0_p0);
    auto l_p2 = ({
        crate::syntax::lexer::Lex this_ = l0_p0;
        this_.pos_p = this_.pos_p + crate::prelude::len_text(word_p1);
        (std::move(this_));
    });
    return prism_rtl::finished(std::tuple{word_p1, l_p2});
}


/// `Start LexIdent, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::syntax::lexer::Lex>> start_lex_ident_f(crate::syntax::lexer::Lex l0_p0) {
    return prism_rtl::make_rc<LexIdent>(l0_p0);
}


/// LexWordToken: unbounded fn Lex, Text, Nat -> Lex
crate::syntax::lexer::Lex lex_word_token_f(const crate::syntax::lexer::Lex& l0_p0, const Text& sigils_p1, const Nat& start_p2) {
    auto w_start_p3 = l0_p0.pos_p;
    auto [path_p6, l1_p7] = lex_qualified_path_f(l0_p0);
    auto l_p4 = crate::syntax::lexer::chars::is_non_ascii_f(crate::syntax::lexer::chars::peek_f(l1_p7))
        ? skip_non_ascii_f(l1_p7, w_start_p3)
        : l1_p7;
    auto first_p5 = crate::prelude::or_(crate::prelude::index(path_p6, Nat(0u)), Text::lit(""));
    return crate::syntax::lexer::chars::starts_with_f(l_p4, Text::lit(".*")) && crate::syntax::lexer::chars::is_upper_f(crate::syntax::lexer::chars::head_f(first_p5))
        ? ({
        auto l2_p8 = crate::syntax::lexer::chars::forward_f(l_p4, Nat(2u));
        auto l3_p9 = sigils_p1 != Text::lit("")
            ? crate::syntax::lexer::chars::lex_err_f(l2_p8, start_p2, prism_rtl::deref(l2_p8).pos_p, Text::lit("a family pattern takes no sigil"))
            : l2_p8;
        (crate::syntax::lexer::push_tok_f(l3_p9, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KFamily{path_p6}), start_p2, prism_rtl::deref(l3_p9).pos_p));
    })
        : ((crate::prelude::len(path_p6) == Nat(1u)) && crate::syntax::lexer::is_keyword_f(first_p5)) && (!(crate::syntax::lexer::is_bound_word_f(first_p5) && (sigils_p1 != Text::lit(""))))
        ? lex_keyword_f(l_p4, first_p5, sigils_p1, start_p2)
        : lex_name_f(l_p4, path_p6, sigils_p1, start_p2, w_start_p3);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexWordToken::cycle() const {
    const auto& l0_p0 = this->l0_p0;
    const auto& sigils_p1 = this->sigils_p1;
    const auto& start_p2 = this->start_p2;
    auto w_start_p3 = prism_rtl::deref(l0_p0).pos_p;
    auto l0_p0x = l0_p0;
    auto sigils_p1x = sigils_p1;
    auto start_p2x = start_p2;
    return crate::prelude::call_then(start_lex_qualified_path_f(l0_p0x), [=](std::tuple<Array<Text>, crate::syntax::lexer::Lex> lex_qualified_path_f_12808) {
        return ({
            auto [path_p6, l1_p7] = lex_qualified_path_f_12808;
            auto l_p4 = crate::syntax::lexer::chars::is_non_ascii_f(crate::syntax::lexer::chars::peek_f(l1_p7))
                ? skip_non_ascii_f(l1_p7, w_start_p3)
                : l1_p7;
            auto first_p5 = crate::prelude::or_(crate::prelude::index(path_p6, Nat(0u)), Text::lit(""));
            (crate::syntax::lexer::chars::starts_with_f(l_p4, Text::lit(".*")) && crate::syntax::lexer::chars::is_upper_f(crate::syntax::lexer::chars::head_f(first_p5))
            ? ({
            auto l2_p8 = crate::syntax::lexer::chars::forward_f(l_p4, Nat(2u));
            auto l3_p9 = sigils_p1x != Text::lit("")
                ? crate::syntax::lexer::chars::lex_err_f(l2_p8, start_p2x, prism_rtl::deref(l2_p8).pos_p, Text::lit("a family pattern takes no sigil"))
                : l2_p8;
            (prism_rtl::finished(crate::syntax::lexer::push_tok_f(l3_p9, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KFamily{path_p6}), start_p2x, prism_rtl::deref(l3_p9).pos_p)));
        })
            : ((crate::prelude::len(path_p6) == Nat(1u)) && crate::syntax::lexer::is_keyword_f(first_p5)) && (!(crate::syntax::lexer::is_bound_word_f(first_p5) && (sigils_p1x != Text::lit(""))))
            ? prism_rtl::more(prism_rtl::rc(LexKeyword(l_p4, first_p5, sigils_p1x, start_p2x)))
            : prism_rtl::more(prism_rtl::rc(LexName(l_p4, path_p6, sigils_p1x, start_p2x, w_start_p3))));
        });
    });
}


/// `Start LexWordToken, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_word_token_f(crate::syntax::lexer::Lex l0_p0, Text sigils_p1, Nat start_p2) {
    return prism_rtl::make_rc<LexWordToken>(l0_p0, sigils_p1, start_p2);
}


/// SkipNonAscii: unbounded fn Lex, Nat -> Lex
crate::syntax::lexer::Lex skip_non_ascii_f(const crate::syntax::lexer::Lex& l0_p0, const Nat& w_start_p1) {
    auto l_p2 = ({
        crate::syntax::lexer::Lex this_ = l0_p0;
        this_.pos_p = crate::syntax::lexer::chars::match_end_f(([]() -> const Regex& { static const Regex r = Regex::lit("[A-Za-z0-9_\\x{80}-\\x{10FFFF}]*", ""); return r; }()), this_.src_p, this_.pos_p);
        (std::move(this_));
    });
    return crate::syntax::lexer::chars::lex_err_f(l_p2, w_start_p1, prism_rtl::deref(l_p2).pos_p, Text::lit("names are ASCII letters, digits and underscores"));
}


prism_rtl::Turn<crate::syntax::lexer::Lex> SkipNonAscii::cycle() const {
    const auto& l0_p0 = this->l0_p0;
    const auto& w_start_p1 = this->w_start_p1;
    auto l_p2 = ({
        crate::syntax::lexer::Lex this_ = l0_p0;
        this_.pos_p = crate::syntax::lexer::chars::match_end_f(([]() -> const Regex& { static const Regex r = Regex::lit("[A-Za-z0-9_\\x{80}-\\x{10FFFF}]*", ""); return r; }()), this_.src_p, this_.pos_p);
        (std::move(this_));
    });
    return prism_rtl::finished(crate::syntax::lexer::chars::lex_err_f(l_p2, w_start_p1, prism_rtl::deref(l_p2).pos_p, Text::lit("names are ASCII letters, digits and underscores")));
}


/// `Start SkipNonAscii, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_skip_non_ascii_f(crate::syntax::lexer::Lex l0_p0, Nat w_start_p1) {
    return prism_rtl::make_rc<SkipNonAscii>(l0_p0, w_start_p1);
}


/// LexKeyword: unbounded fn Lex, Text, Text, Nat -> Lex
crate::syntax::lexer::Lex lex_keyword_f(const crate::syntax::lexer::Lex& l_p0, const Text& w_p1, const Text& sigils_p2, const Nat& start_p3) {
    auto l1_p4 = (sigils_p2 != Text::lit("")) && (!(((w_p1 == Text::lit("widget")) || (w_p1 == Text::lit("unit"))) || (w_p1 == Text::lit("nil"))))
        ? crate::syntax::lexer::chars::lex_err_f(l_p0, start_p3, l_p0.pos_p, prism_rtl::cat("`", w_p1, "` is a keyword and takes no sigil"))
        : l_p0;
    auto l2_p5 = (w_p1 == Text::lit("widget")) && (sigils_p2 != Text::lit("@"))
        ? crate::syntax::lexer::chars::lex_err_f(l1_p4, start_p3, prism_rtl::deref(l1_p4).pos_p, Text::lit("`widget` is a block only as `@widget:`"))
        : l1_p4;
    auto l3_p6 = crate::syntax::lexer::push_tok_f(l2_p5, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KKw{w_p1, sigils_p2}), start_p3, prism_rtl::deref(l2_p5).pos_p);
    return ((w_p1 == Text::lit("output")) || (w_p1 == Text::lit("inline_text"))) || (w_p1 == Text::lit("raw"))
        ? crate::syntax::lexer::templates::maybe_template_f(l3_p6, w_p1)
        : l3_p6;
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexKeyword::cycle() const {
    const auto& l_p0 = this->l_p0;
    const auto& w_p1 = this->w_p1;
    const auto& sigils_p2 = this->sigils_p2;
    const auto& start_p3 = this->start_p3;
    auto l1_p4 = (sigils_p2 != Text::lit("")) && (!(((w_p1 == Text::lit("widget")) || (w_p1 == Text::lit("unit"))) || (w_p1 == Text::lit("nil"))))
        ? crate::syntax::lexer::chars::lex_err_f(l_p0, start_p3, prism_rtl::deref(l_p0).pos_p, prism_rtl::cat("`", w_p1, "` is a keyword and takes no sigil"))
        : l_p0;
    auto l2_p5 = (w_p1 == Text::lit("widget")) && (sigils_p2 != Text::lit("@"))
        ? crate::syntax::lexer::chars::lex_err_f(l1_p4, start_p3, prism_rtl::deref(l1_p4).pos_p, Text::lit("`widget` is a block only as `@widget:`"))
        : l1_p4;
    auto l3_p6 = crate::syntax::lexer::push_tok_f(l2_p5, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KKw{w_p1, sigils_p2}), start_p3, prism_rtl::deref(l2_p5).pos_p);
    return ((w_p1 == Text::lit("output")) || (w_p1 == Text::lit("inline_text"))) || (w_p1 == Text::lit("raw"))
        ? prism_rtl::more(prism_rtl::rc(crate::syntax::lexer::templates::MaybeTemplate(l3_p6, w_p1)))
        : prism_rtl::finished(l3_p6);
}


/// `Start LexKeyword, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_keyword_f(crate::syntax::lexer::Lex l_p0, Text w_p1, Text sigils_p2, Nat start_p3) {
    return prism_rtl::make_rc<LexKeyword>(l_p0, w_p1, sigils_p2, start_p3);
}


/// LexName: unbounded fn Lex, [Text], Text, Nat, Nat -> Lex
crate::syntax::lexer::Lex lex_name_f(const crate::syntax::lexer::Lex& l_p0, const Array<Text>& path_p1, const Text& sigils_p2, const Nat& start_p3, const Nat& w_start_p4) {
    auto [case_p6, l1_p7] = name_case_of_f(l_p0, path_p1, w_start_p4);
    auto l2_p5 = is_path_word_f(l1_p7, sigils_p2, path_p1)
        ? ({
        crate::syntax::lexer::Lex this_ = l1_p7;
        this_.path_next_p = true;
        (std::move(this_));
    })
        : l1_p7;
    return crate::syntax::lexer::push_tok_f(l2_p5, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KName{crate::syntax::lexer::NameTok{.sigils_p = sigils_p2, .path_p = path_p1, .case_p = case_p6}}), start_p3, prism_rtl::deref(l2_p5).pos_p);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexName::cycle() const {
    const auto& l_p0 = this->l_p0;
    const auto& path_p1 = this->path_p1;
    const auto& sigils_p2 = this->sigils_p2;
    const auto& start_p3 = this->start_p3;
    const auto& w_start_p4 = this->w_start_p4;
    auto [case_p6, l1_p7] = name_case_of_f(l_p0, path_p1, w_start_p4);
    auto l2_p5 = is_path_word_f(l1_p7, sigils_p2, path_p1)
        ? ({
        crate::syntax::lexer::Lex this_ = l1_p7;
        this_.path_next_p = true;
        (std::move(this_));
    })
        : l1_p7;
    return prism_rtl::finished(crate::syntax::lexer::push_tok_f(l2_p5, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KName{crate::syntax::lexer::NameTok{.sigils_p = sigils_p2, .path_p = path_p1, .case_p = case_p6}}), start_p3, prism_rtl::deref(l2_p5).pos_p));
}


/// `Start LexName, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_name_f(crate::syntax::lexer::Lex l_p0, Array<Text> path_p1, Text sigils_p2, Nat start_p3, Nat w_start_p4) {
    return prism_rtl::make_rc<LexName>(l_p0, path_p1, sigils_p2, start_p3, w_start_p4);
}


/// NameCaseOf: fn Lex, [Text], Nat -> ((NameCase, Lex))
std::tuple<crate::syntax::lexer::NameCase, crate::syntax::lexer::Lex> name_case_of_f(const crate::syntax::lexer::Lex& l_p0, const Array<Text>& path_p1, const Nat& w_start_p2) {
    auto last_p3 = crate::prelude::or_(crate::syntax::lexer::chars::last_o(path_p1), Text::lit(""));
    return last_p3 == Text::lit("_")
        ? std::tuple{crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseTopic{}), l_p0}
        : (crate::syntax::lexer::chars::head_f(last_p3) == Text::lit("_")) && crate::syntax::lexer::chars::all_chars_f(crate::syntax::lexer::chars::after_first_f(last_p3), ({
        auto f = prism_rtl::rc(crate::syntax::lexer::chars::is_digit_f);
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, f = std::move(f)](Text a0) {
        return ({
            auto fy = f;
            (crate::prelude::once_job([=, fy = std::move(fy)]() { return prism_rtl::finished(fy(a0)); }));
        });
    })));
    }))
        ? std::tuple{crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseHole{}), l_p0}
        : crate::syntax::lexer::chars::head_f(last_p3) == Text::lit("_")
        ? std::tuple{crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseLower{}), crate::syntax::lexer::chars::lex_err_f(l_p0, w_start_p2, l_p0.pos_p, Text::lit("`_` followed by a letter is not a name: `_` alone is the topic, `_1` a hole"))}
        : crate::syntax::lexer::chars::is_reserved_ctor_f(last_p3)
        ? std::tuple{crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseReserved{}), l_p0}
        : crate::syntax::lexer::chars::is_upper_f(crate::syntax::lexer::chars::head_f(last_p3))
        ? ({
        auto underscored_p4 = crate::prelude::fold(path_p1, false, [&](const bool& seen_p5, const Text& seg_p6) { return prism_rtl::deref(seen_p5) || crate::syntax::lexer::chars::contains_f(seg_p6, Text::lit("_")); });
        std::move(underscored_p4)
        ? std::tuple{crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseUpper{}), crate::syntax::lexer::chars::lex_err_f(l_p0, w_start_p2, l_p0.pos_p, prism_rtl::cat("`", crate::syntax::lexer::chars::join_f(path_p1, Text::lit(".")), "`: a capital promises UpperCamelCase"))}
        : std::tuple{crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseUpper{}), l_p0};
    })
        : std::tuple{crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseLower{}), l_p0};
}


/// IsPathWord: fn Lex, Text, [Text] -> Bool
bool is_path_word_f(const crate::syntax::lexer::Lex& l_p0, const Text& sigils_p1, const Array<Text>& path_p2) {
    auto w_p3 = crate::prelude::or_(crate::prelude::index(path_p2, Nat(0u)), Text::lit(""));
    auto words_p4 = w_p3 == Text::lit("at")
        ? Array(std::vector{Text::lit("send"), Text::lit("click"), Text::lit("answer")})
        : Array(std::vector{Text::lit("click")});
    auto prev_p5 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = crate::syntax::lexer::chars::last_o(l_p0.tokens_p);
        if (prism_rtl::is_some(_m)) {
            auto&& t_p6 = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = prism_rtl::deref(t_p6).kind_p;
                if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
                    auto&& n_p7 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
                    if ((prism_rtl::deref(n_p7).sigils_p == Text::lit("")) && (crate::prelude::len(prism_rtl::deref(n_p7).path_p) == Nat(1u))) {
                        _v.set(crate::prelude::or_(crate::prelude::index(prism_rtl::deref(n_p7).path_p, Nat(0u)), Text::lit("")));
                        goto _done;
                    }
                }
                {
                    _v.set(Text::lit(""));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ((((l_p0.test_depth_o != std::optional<Nat>{}) && (sigils_p1 == Text::lit(""))) && (crate::prelude::len(path_p2) == Nat(1u))) && ((w_p3 == Text::lit("at")) || (w_p3 == Text::lit("element")))) && crate::prelude::fold(words_p4, false, [&](const bool& seen_p8, const Text& x_p9) { return prism_rtl::deref(seen_p8) || (x_p9 == prev_p5); });
}

}  // namespace crate::syntax::lexer::words


// The module `Syntax.Parser`, from `target/bootstrap/cpp-src/prismc/syntax/parser/mod.prism`.
namespace crate::syntax::parser {

void Pair::show(Printer& p) const {
    p.record("Pair", {{"partner", partner_o}, {"outer", outer_p}, {"inner", inner_p}});
}

Pod Pair::to_pod() const {
    return Pod::record("Pair", {{"partner", prism_rtl::to_pod(partner_o)}, {"outer", prism_rtl::to_pod(outer_p)}, {"inner", prism_rtl::to_pod(inner_p)}});
}

Result<Pair> Pair::from_pod(const Pod& whole) {
    return Pair{.partner_o = TRY(prism_rtl::from_pod<std::optional<Nat>>(TRY(crate::prelude::field(whole, "partner")))), .outer_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "outer")))), .inner_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "inner"))))};
}


bool Parsed::operator==(const Parsed& o) const { return tree_p == o.tree_p && diags_p == o.diags_p; }

void Parsed::show(Printer& p) const {
    p.record("Parsed", {{"tree", tree_p}, {"diags", diags_p}});
}

Pod Parsed::to_pod() const {
    return Pod::record("Parsed", {{"tree", prism_rtl::to_pod(tree_p)}, {"diags", prism_rtl::to_pod(diags_p)}});
}

Result<Parsed> Parsed::from_pod(const Pod& whole) {
    return Parsed{.tree_p = TRY(prism_rtl::from_pod<crate::syntax::Module>(TRY(crate::prelude::field(whole, "tree")))), .diags_p = TRY(prism_rtl::from_pod<Array<crate::syntax::Diag>>(TRY(crate::prelude::field(whole, "diags"))))};
}


bool Ps::operator==(const Ps& o) const { return toks_p == o.toks_p && pairs_p == o.pairs_p && pos_p == o.pos_p && diags_p == o.diags_p && out_p == o.out_p && step_mode_p == o.step_mode_p && in_trait_p == o.in_trait_p && bad_p == o.bad_p; }

void Ps::show(Printer& p) const {
    p.record("Ps", {{"toks", toks_p}, {"pairs", pairs_p}, {"pos", pos_p}, {"diags", diags_p}, {"out", out_p}, {"stepMode", step_mode_p}, {"inTrait", in_trait_p}, {"bad", bad_p}});
}

Pod Ps::to_pod() const {
    return Pod::record("Ps", {{"toks", prism_rtl::to_pod(toks_p)}, {"pairs", prism_rtl::to_pod(pairs_p)}, {"pos", prism_rtl::to_pod(pos_p)}, {"diags", prism_rtl::to_pod(diags_p)}, {"out", prism_rtl::to_pod(out_p)}, {"stepMode", prism_rtl::to_pod(step_mode_p)}, {"inTrait", prism_rtl::to_pod(in_trait_p)}, {"bad", prism_rtl::to_pod(bad_p)}});
}

Result<Ps> Ps::from_pod(const Pod& whole) {
    return Ps{.toks_p = TRY(prism_rtl::from_pod<Array<crate::syntax::lexer::Tok>>(TRY(crate::prelude::field(whole, "toks")))), .pairs_p = TRY(prism_rtl::from_pod<Array<Pair>>(TRY(crate::prelude::field(whole, "pairs")))), .pos_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "pos")))), .diags_p = TRY(prism_rtl::from_pod<Array<crate::syntax::Diag>>(TRY(crate::prelude::field(whole, "diags")))), .out_p = TRY(prism_rtl::from_pod<Array<crate::syntax::Diag>>(TRY(crate::prelude::field(whole, "out")))), .step_mode_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "stepMode")))), .in_trait_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "inTrait")))), .bad_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "bad"))))};
}


/// let noRange
crate::syntax::Range no_range_p() {
    return crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)};
}


/// let eofTok
crate::syntax::lexer::Tok eof_tok_p() {
    return crate::syntax::lexer::Tok{.kind_p = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KEof{}), .span_p = no_range_p(), .touches_p = false, .line_start_p = false};
}


/// let noPair
Pair no_pair_p() {
    return Pair{.partner_o = std::optional<Nat>{}, .outer_p = false, .inner_p = false};
}


/// ParseFile: unbounded fn Text -> Parsed
Parsed parse_file_f(const Text& src_p0) {
    auto lexed_p1 = crate::syntax::lexer::layout::lex_file_f(src_p0);
    auto [m_p2, p_p3] = crate::syntax::parser::decls::parse_module_f(new_ps_f(prism_rtl::deref(lexed_p1).tokens_p), false);
    return Parsed{.tree_p = m_p2, .diags_p = finish_diags_f(crate::prelude::append(crate::prelude::append(prism_rtl::deref(lexed_p1).diags_p, prism_rtl::deref(p_p3).diags_p), prism_rtl::deref(p_p3).out_p))};
}


prism_rtl::Turn<Parsed> ParseFile::cycle() const {
    const auto& src_p0 = this->src_p0;
    auto src_p0x = src_p0;
    return crate::prelude::call_then(crate::syntax::lexer::layout::start_lex_file_f(src_p0x), [=](crate::syntax::lexer::Lexed lex_file_f_3340) {
        return ({
            auto lexed_p1 = lex_file_f_3340;
            (crate::prelude::call_then(start_new_ps_f(prism_rtl::deref(lexed_p1).tokens_p), [=](Ps new_ps_f_3384) {
            return crate::prelude::call_then(crate::syntax::parser::decls::start_parse_module_f(new_ps_f_3384, false), [=](std::tuple<crate::syntax::Module, Ps> parse_module_f_3371) {
                return ({
                    auto [m_p2, p_p3] = parse_module_f_3371;
                    (prism_rtl::finished(Parsed{.tree_p = m_p2, .diags_p = finish_diags_f(crate::prelude::append(crate::prelude::append(prism_rtl::deref(lexed_p1).diags_p, prism_rtl::deref(p_p3).diags_p), prism_rtl::deref(p_p3).out_p))}));
                });
            });
        }));
        });
    });
}


/// `Start ParseFile, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parsed> start_parse_file_f(Text src_p0) {
    return prism_rtl::make_rc<ParseFile>(src_p0);
}


/// ParseFragment: unbounded fn Text -> Parsed
Parsed parse_fragment_f(const Text& src_p0) {
    auto lexed_p1 = crate::syntax::lexer::layout::lex_file_f(src_p0);
    auto [m_p2, p_p3] = crate::syntax::parser::decls::parse_module_f(new_ps_f(prism_rtl::deref(lexed_p1).tokens_p), true);
    return Parsed{.tree_p = m_p2, .diags_p = finish_diags_f(crate::prelude::append(crate::prelude::append(prism_rtl::deref(lexed_p1).diags_p, prism_rtl::deref(p_p3).diags_p), prism_rtl::deref(p_p3).out_p))};
}


prism_rtl::Turn<Parsed> ParseFragment::cycle() const {
    const auto& src_p0 = this->src_p0;
    auto src_p0x = src_p0;
    return crate::prelude::call_then(crate::syntax::lexer::layout::start_lex_file_f(src_p0x), [=](crate::syntax::lexer::Lexed lex_file_f_3733) {
        return ({
            auto lexed_p1 = lex_file_f_3733;
            (crate::prelude::call_then(start_new_ps_f(prism_rtl::deref(lexed_p1).tokens_p), [=](Ps new_ps_f_3777) {
            return crate::prelude::call_then(crate::syntax::parser::decls::start_parse_module_f(new_ps_f_3777, true), [=](std::tuple<crate::syntax::Module, Ps> parse_module_f_3764) {
                return ({
                    auto [m_p2, p_p3] = parse_module_f_3764;
                    (prism_rtl::finished(Parsed{.tree_p = m_p2, .diags_p = finish_diags_f(crate::prelude::append(crate::prelude::append(prism_rtl::deref(lexed_p1).diags_p, prism_rtl::deref(p_p3).diags_p), prism_rtl::deref(p_p3).out_p))}));
                });
            });
        }));
        });
    });
}


/// `Start ParseFragment, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parsed> start_parse_fragment_f(Text src_p0) {
    return prism_rtl::make_rc<ParseFragment>(src_p0);
}


/// NewPs: unbounded fn [Tok] -> Ps
Ps new_ps_f(const Array<crate::syntax::lexer::Tok>& toks0_p0) {
    auto ends_p1 = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = crate::syntax::lexer::chars::last_o(toks0_p0);
        if (prism_rtl::is_some(_m)) {
            auto&& t_p4 = prism_rtl::some_of(_m);
            _v.set(prism_rtl::deref(t_p4).kind_p == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KEof{}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto end_p2 = ({
        __label__ _done;
        prism_rtl::Slot<crate::syntax::Range> _v;
        auto&& _m = crate::syntax::lexer::chars::last_o(toks0_p0);
        if (prism_rtl::is_some(_m)) {
            auto&& t_p5 = prism_rtl::some_of(_m);
            _v.set(crate::syntax::Range{.start_p = prism_rtl::deref(prism_rtl::deref(t_p5).span_p).end_p, .end_p = prism_rtl::deref(prism_rtl::deref(t_p5).span_p).end_p});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(no_range_p());
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto toks_p3 = std::move(ends_p1)
        ? toks0_p0
        : crate::prelude::push(toks0_p0, crate::syntax::lexer::Tok{.kind_p = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KEof{}), .span_p = end_p2, .touches_p = false, .line_start_p = false});
    return Ps{.toks_p = toks_p3, .pairs_p = pair_brackets_f(toks_p3), .pos_p = Nat(0u), .diags_p = Array<crate::syntax::Diag>{}, .out_p = Array<crate::syntax::Diag>{}, .step_mode_p = false, .in_trait_p = false, .bad_p = false};
}


prism_rtl::Turn<Ps> NewPs::cycle() const {
    const auto& toks0_p0 = this->toks0_p0;
    auto ends_p1 = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = crate::syntax::lexer::chars::last_o(toks0_p0);
        if (prism_rtl::is_some(_m)) {
            auto&& t_p4 = prism_rtl::some_of(_m);
            _v.set(prism_rtl::deref(t_p4).kind_p == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KEof{}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto end_p2 = ({
        __label__ _done;
        prism_rtl::Slot<crate::syntax::Range> _v;
        auto&& _m = crate::syntax::lexer::chars::last_o(toks0_p0);
        if (prism_rtl::is_some(_m)) {
            auto&& t_p5 = prism_rtl::some_of(_m);
            _v.set(crate::syntax::Range{.start_p = prism_rtl::deref(prism_rtl::deref(t_p5).span_p).end_p, .end_p = prism_rtl::deref(prism_rtl::deref(t_p5).span_p).end_p});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(no_range_p());
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto toks_p3 = std::move(ends_p1)
        ? toks0_p0
        : crate::prelude::push(toks0_p0, crate::syntax::lexer::Tok{.kind_p = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KEof{}), .span_p = end_p2, .touches_p = false, .line_start_p = false});
    return crate::prelude::call_then(start_pair_brackets_f(toks_p3), [=](Array<Pair> pair_brackets_f_4256) { return prism_rtl::finished(Ps{.toks_p = toks_p3, .pairs_p = pair_brackets_f_4256, .pos_p = Nat(0u), .diags_p = Array<crate::syntax::Diag>{}, .out_p = Array<crate::syntax::Diag>{}, .step_mode_p = false, .in_trait_p = false, .bad_p = false}); });
}


/// `Start NewPs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ps> start_new_ps_f(Array<crate::syntax::lexer::Tok> toks0_p0) {
    return prism_rtl::make_rc<NewPs>(toks0_p0);
}


/// Sub: unbounded fn Ps, [Tok], Range -> Ps
Ps sub_f(const Ps& p_p0, const Array<crate::syntax::lexer::Tok>& toks_p1, const crate::syntax::Range& end_p2) {
    auto q_p3 = new_ps_f(crate::prelude::push(toks_p1, crate::syntax::lexer::Tok{.kind_p = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KEof{}), .span_p = end_p2, .touches_p = false, .line_start_p = false}));
    Ps this_ = q_p3;
    this_.step_mode_p = p_p0.step_mode_p;
    return this_;
}


prism_rtl::Turn<Ps> Sub::cycle() const {
    const auto& p_p0 = this->p_p0;
    const auto& toks_p1 = this->toks_p1;
    const auto& end_p2 = this->end_p2;
    auto end_p2x = end_p2;
    auto p_p0x = p_p0;
    auto toks_p1x = toks_p1;
    return crate::prelude::call_then(start_new_ps_f(crate::prelude::push(toks_p1x, crate::syntax::lexer::Tok{.kind_p = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KEof{}), .span_p = end_p2x, .touches_p = false, .line_start_p = false})), [=](Ps new_ps_f_4565) {
        return ({
            auto q_p3 = new_ps_f_4565;
            (prism_rtl::finished(({
            Ps this_ = q_p3;
            this_.step_mode_p = prism_rtl::deref(p_p0x).step_mode_p;
            (std::move(this_));
        })));
        });
    });
}


/// `Start Sub, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ps> start_sub_f(Ps p_p0, Array<crate::syntax::lexer::Tok> toks_p1, crate::syntax::Range end_p2) {
    return prism_rtl::make_rc<Sub>(p_p0, toks_p1, end_p2);
}


/// Absorb: fn Ps, Ps -> Ps
Ps absorb_f(const Ps& p_p0, const Ps& sub_p1) {
    Ps this_ = p_p0;
    this_.diags_p = crate::prelude::append(this_.diags_p, sub_p1.diags_p);
    this_.out_p = crate::prelude::append(this_.out_p, sub_p1.out_p);
    return this_;
}


/// FinishDiags: fn [Diag] -> [Diag]
Array<crate::syntax::Diag> finish_diags_f(const Array<crate::syntax::Diag>& ds_p0) {
    auto sorted_p1 = crate::prelude::fold(ds_p0, Array<crate::syntax::Diag>{}, insert_diag_f);
    return crate::prelude::fold(sorted_p1, Array<crate::syntax::Diag>{}, [&](const Array<crate::syntax::Diag>& acc_p2, const crate::syntax::Diag& d_p3) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::syntax::Diag>> _v;
            auto&& _m = crate::syntax::lexer::chars::last_o(acc_p2);
            if (prism_rtl::is_some(_m)) {
                auto&& e_p4 = prism_rtl::some_of(_m);
                if ((prism_rtl::deref(e_p4).span_p == prism_rtl::deref(d_p3).span_p) && (prism_rtl::deref(e_p4).message_p == prism_rtl::deref(d_p3).message_p)) {
                    _v.set(acc_p2);
                    goto _done;
                }
            }
            {
                _v.set(crate::prelude::push(acc_p2, d_p3));
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// StageRank: fn Text -> Nat
Nat stage_rank_f(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("lex")) {
            return Nat(0u);
        }
    }
    {
        auto&& c1_0 = text0;
        if (c1_0 == Text::lit("parse")) {
            return Nat(1u);
        }
    }
    {
        return Nat(2u);
    }
}


/// DiagBefore: fn Diag, Diag -> Bool
bool diag_before_f(const crate::syntax::Diag& a_p0, const crate::syntax::Diag& b_p1) {
    return (prism_rtl::deref(a_p0.span_p).start_p < prism_rtl::deref(b_p1.span_p).start_p) || ((prism_rtl::deref(a_p0.span_p).start_p == prism_rtl::deref(b_p1.span_p).start_p) && (stage_rank_f(a_p0.stage_p) < stage_rank_f(b_p1.stage_p)));
}


/// InsertDiag: fn [Diag], Diag -> [Diag]
Array<crate::syntax::Diag> insert_diag_f(const Array<crate::syntax::Diag>& sorted_p0, const crate::syntax::Diag& d_p1) {
    auto before_p2 = crate::prelude::fold(sorted_p0, Array<crate::syntax::Diag>{}, [&](const Array<crate::syntax::Diag>& acc_p4, const crate::syntax::Diag& e_p5) { return diag_before_f(d_p1, e_p5) ? acc_p4 : crate::prelude::push(acc_p4, e_p5); });
    auto after_p3 = crate::prelude::fold(sorted_p0, Array<crate::syntax::Diag>{}, [&](const Array<crate::syntax::Diag>& acc_p6, const crate::syntax::Diag& e_p7) { return diag_before_f(d_p1, e_p7) ? crate::prelude::push(acc_p6, e_p7) : acc_p6; });
    return crate::prelude::append(crate::prelude::push(before_p2, d_p1), after_p3);
}


/// PairBrackets: unbounded fn [Tok] -> [Pair]
Array<Pair> pair_brackets_f(const Array<crate::syntax::lexer::Tok>& toks_p0) {
    Array<Pair> this_ = crate::prelude::each(toks_p0, [&](const crate::syntax::lexer::Tok& t_p1) { return no_pair_p(); });
    Array<std::tuple<Nat, Text>> stack_p2 = Array<std::tuple<Nat, Text>>{};
    for (auto&& [i6317, v6317] : prism_rtl::enumerate(toks_p0)) {
        auto k6317 = crate::prelude::nat_of(i6317);
        auto t_p3 = v6317;
        if (auto&& _m = open_kind_of_o(prism_rtl::deref(t_p3).kind_p); prism_rtl::is_some(_m)) {
            auto&& k_p4 = prism_rtl::some_of(_m);
            stack_p2 = crate::prelude::push(stack_p2, std::tuple{k6317, k_p4});
        }
        if (auto&& _m = close_kind_of_o(prism_rtl::deref(t_p3).kind_p); prism_rtl::is_some(_m)) {
            auto&& k_p5 = prism_rtl::some_of(_m);
            if (auto&& _m = crate::syntax::lexer::chars::last_o(stack_p2); prism_rtl::is_some(_m)) {
                auto&& j_p6 = std::get<0>(prism_rtl::some_of(_m));
                auto&& k2_p7 = std::get<1>(prism_rtl::some_of(_m));
                if (k2_p7 == k_p5) {
                    stack_p2 = crate::syntax::lexer::chars::pop_f(stack_p2);
                    prism_rtl::deref(prism_rtl::deref(at_mut(this_, k6317))).partner_o = std::optional(j_p6);
                    prism_rtl::deref(prism_rtl::deref(at_mut(this_, j_p6))).partner_o = std::optional(k6317);
                }
            }
        }
    }
    for (auto&& [i6778, v6778] : prism_rtl::enumerate(toks_p0)) {
        auto k6778 = crate::prelude::nat_of(i6778);
        auto t_p8 = v6778;
        auto i_p9 = k6778;
        if (auto&& _m = open_kind_of_o(prism_rtl::deref(t_p8).kind_p); prism_rtl::is_some(_m)) {
            auto&& kind_pa = prism_rtl::some_of(_m);
            if ((kind_pa != Text::lit("{")) && (!prism_rtl::deref(crate::prelude::or_(crate::prelude::index(this_, i_p9), no_pair_p())).inner_p)) {
                if (auto&& _m = prism_rtl::deref(crate::prelude::or_(crate::prelude::index(this_, i_p9), no_pair_p())).partner_o; prism_rtl::is_some(_m)) {
                    auto&& j_pb = prism_rtl::some_of(_m);
                    if (double_at_f(this_, toks_p0, i_p9, j_pb, kind_pa)) {
                        prism_rtl::deref(prism_rtl::deref(at_mut(this_, i_p9))).outer_p = true;
                        prism_rtl::deref(prism_rtl::deref(at_mut(this_, j_pb))).outer_p = true;
                        prism_rtl::deref(prism_rtl::deref(at_mut(this_, i_p9 + Nat(1u)))).inner_p = true;
                        prism_rtl::deref(prism_rtl::deref(at_mut(this_, crate::syntax::lexer::chars::dec_f(j_pb)))).inner_p = true;
                    }
                }
            }
        }
    }
    return this_;
}


prism_rtl::Turn<Array<Pair>> PairBrackets::cycle() const {
    const auto& toks_p0 = this->toks_p0;
    return prism_rtl::finished(({
        Array<Pair> this_ = crate::prelude::each(toks_p0, [&](const crate::syntax::lexer::Tok& t_p1) { return no_pair_p(); });
        Array<std::tuple<Nat, Text>> stack_p2 = Array<std::tuple<Nat, Text>>{};
        for (auto&& [i6317, v6317] : prism_rtl::enumerate(toks_p0)) {
            auto k6317 = crate::prelude::nat_of(i6317);
            auto t_p3 = v6317;
            if (auto&& _m = open_kind_of_o(prism_rtl::deref(t_p3).kind_p); prism_rtl::is_some(_m)) {
                auto&& k_p4 = prism_rtl::some_of(_m);
                stack_p2 = crate::prelude::push(stack_p2, std::tuple{k6317, k_p4});
            }
            if (auto&& _m = close_kind_of_o(prism_rtl::deref(t_p3).kind_p); prism_rtl::is_some(_m)) {
                auto&& k_p5 = prism_rtl::some_of(_m);
                if (auto&& _m = crate::syntax::lexer::chars::last_o(stack_p2); prism_rtl::is_some(_m)) {
                    auto&& j_p6 = std::get<0>(prism_rtl::some_of(_m));
                    auto&& k2_p7 = std::get<1>(prism_rtl::some_of(_m));
                    if (k2_p7 == k_p5) {
                        stack_p2 = crate::syntax::lexer::chars::pop_f(stack_p2);
                        prism_rtl::deref(prism_rtl::deref(at_mut(this_, k6317))).partner_o = std::optional(j_p6);
                        prism_rtl::deref(prism_rtl::deref(at_mut(this_, j_p6))).partner_o = std::optional(k6317);
                    }
                }
            }
        }
        for (auto&& [i6778, v6778] : prism_rtl::enumerate(toks_p0)) {
            auto k6778 = crate::prelude::nat_of(i6778);
            auto t_p8 = v6778;
            auto i_p9 = k6778;
            if (auto&& _m = open_kind_of_o(prism_rtl::deref(t_p8).kind_p); prism_rtl::is_some(_m)) {
                auto&& kind_pa = prism_rtl::some_of(_m);
                if ((kind_pa != Text::lit("{")) && (!prism_rtl::deref(crate::prelude::or_(crate::prelude::index(this_, i_p9), no_pair_p())).inner_p)) {
                    if (auto&& _m = prism_rtl::deref(crate::prelude::or_(crate::prelude::index(this_, i_p9), no_pair_p())).partner_o; prism_rtl::is_some(_m)) {
                        auto&& j_pb = prism_rtl::some_of(_m);
                        if (double_at_f(this_, toks_p0, i_p9, j_pb, kind_pa)) {
                            prism_rtl::deref(prism_rtl::deref(at_mut(this_, i_p9))).outer_p = true;
                            prism_rtl::deref(prism_rtl::deref(at_mut(this_, j_pb))).outer_p = true;
                            prism_rtl::deref(prism_rtl::deref(at_mut(this_, i_p9 + Nat(1u)))).inner_p = true;
                            prism_rtl::deref(prism_rtl::deref(at_mut(this_, crate::syntax::lexer::chars::dec_f(j_pb)))).inner_p = true;
                        }
                    }
                }
            }
        }
        (std::move(this_));
    }));
}


/// `Start PairBrackets, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Pair>> start_pair_brackets_f(Array<crate::syntax::lexer::Tok> toks_p0) {
    return prism_rtl::make_rc<PairBrackets>(toks_p0);
}


/// DoubleAt: fn [Pair], [Tok], Nat, Nat, Text -> Bool
bool double_at_f(const Array<Pair>& pairs_p0, const Array<crate::syntax::lexer::Tok>& toks_p1, const Nat& i_p2, const Nat& j_p3, const Text& kind_p4) {
    auto next_p5 = crate::prelude::or_(crate::prelude::index(toks_p1, i_p2 + Nat(1u)), eof_tok_p());
    auto inner_close_o6 = prism_rtl::deref(crate::prelude::or_(crate::prelude::index(pairs_p0, i_p2 + Nat(1u)), no_pair_p())).partner_o;
    return ((is_open_of_f(prism_rtl::deref(next_p5).kind_p, kind_p4) && prism_rtl::deref(next_p5).touches_p) && (inner_close_o6 == std::optional(crate::syntax::lexer::chars::dec_f(j_p3)))) && prism_rtl::deref(crate::prelude::or_(crate::prelude::index(toks_p1, j_p3), eof_tok_p())).touches_p;
}


/// ?OpenKindOf: fn TokKind -> ?Text
std::optional<Text> open_kind_of_o(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(tok_kind0)) {
        auto&& k_p0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(tok_kind0).a0;
        return std::optional(k_p0);
    }
    {
        return std::optional<Text>{};
    }
}


/// ?CloseKindOf: fn TokKind -> ?Text
std::optional<Text> close_kind_of_o(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KClose>(tok_kind0)) {
        auto&& k_p0 = prism_rtl::as<crate::syntax::lexer::TokKind::KClose>(tok_kind0).a0;
        return std::optional(k_p0);
    }
    {
        return std::optional<Text>{};
    }
}


/// IsOpenOf: fn TokKind, Text -> Bool
bool is_open_of_f(const crate::syntax::lexer::TokKind& tok_kind0, const Text& text1) {
    auto&& _m = std::tuple{tok_kind0, text1};
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(std::get<0>(_m))) {
        auto&& k_p0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(std::get<0>(_m)).a0;
        auto&& kind_p1 = std::get<1>(_m);
        return k_p0 == kind_p1;
    }
    {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// Tk: fn Ps -> Tok
crate::syntax::lexer::Tok tk_f(const Ps& p_p0) {
    return p_p0.bad_p
        ? eof_tok_p()
        : crate::prelude::or_(crate::prelude::index(p_p0.toks_p, crate::prelude::min(p_p0.pos_p, crate::syntax::lexer::chars::dec_f(crate::prelude::len(p_p0.toks_p)))), eof_tok_p());
}


/// TkAt: fn Ps, Nat -> Tok
crate::syntax::lexer::Tok tk_at_f(const Ps& p_p0, const Nat& n_p1) {
    return p_p0.bad_p
        ? eof_tok_p()
        : crate::prelude::or_(crate::prelude::index(p_p0.toks_p, crate::prelude::min(p_p0.pos_p + n_p1, crate::syntax::lexer::chars::dec_f(crate::prelude::len(p_p0.toks_p)))), eof_tok_p());
}


/// Kind: fn Ps -> TokKind
crate::syntax::lexer::TokKind kind_f(const Ps& p_p0) {
    return prism_rtl::deref(tk_f(p_p0)).kind_p;
}


/// KindAt: fn Ps, Nat -> TokKind
crate::syntax::lexer::TokKind kind_at_f(const Ps& p_p0, const Nat& n_p1) {
    return prism_rtl::deref(tk_at_f(p_p0, n_p1)).kind_p;
}


/// Here: fn Ps -> Range
crate::syntax::Range here_f(const Ps& p_p0) {
    return prism_rtl::deref(tk_f(p_p0)).span_p;
}


/// Prev: fn Ps -> Range
crate::syntax::Range prev_f(const Ps& p_p0) {
    return prism_rtl::deref(crate::prelude::or_(crate::prelude::index(p_p0.toks_p, crate::syntax::lexer::chars::dec_f(p_p0.pos_p)), eof_tok_p())).span_p;
}


/// To: fn Range, Range -> Range
crate::syntax::Range to_f(const crate::syntax::Range& a_p0, const crate::syntax::Range& b_p1) {
    return crate::syntax::Range{.start_p = crate::prelude::min(a_p0.start_p, b_p1.start_p), .end_p = crate::prelude::max(a_p0.end_p, b_p1.end_p)};
}


/// AtEnd: fn Range -> Range
crate::syntax::Range at_end_f(const crate::syntax::Range& r_p0) {
    return crate::syntax::Range{.start_p = r_p0.end_p, .end_p = r_p0.end_p};
}


/// Adv: fn Ps -> Ps
Ps adv_f(const Ps& p_p0) {
    return p_p0.bad_p || ((p_p0.pos_p + Nat(1u)) >= crate::prelude::len(p_p0.toks_p))
        ? p_p0
        : ({
        Ps this_ = p_p0;
        this_.pos_p = this_.pos_p + Nat(1u);
        (std::move(this_));
    });
}


/// PairAt: fn Ps -> Pair
Pair pair_at_f(const Ps& p_p0) {
    return crate::prelude::or_(crate::prelude::index(p_p0.pairs_p, crate::prelude::min(p_p0.pos_p, crate::syntax::lexer::chars::dec_f(crate::prelude::len(p_p0.pairs_p)))), no_pair_p());
}


/// AtEof: fn Ps -> Bool
bool at_eof_f(const Ps& p_p0) {
    return kind_f(p_p0) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KEof{});
}


/// AtKw: fn Ps, Text -> Bool
bool at_kw_f(const Ps& p_p0, const Text& w_p1) {
    return kind_f(p_p0) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KKw{w_p1, Text::lit("")});
}


/// AtOp: fn Ps, Text -> Bool
bool at_op_f(const Ps& p_p0, const Text& op_p1) {
    auto&& _m = kind_f(p_p0);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(_m)) {
        auto&& o_p2 = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
        return o_p2 == op_p1;
    }
    {
        return false;
    }
}


/// AtSep: fn Ps -> Bool
bool at_sep_f(const Ps& p_p0) {
    return kind_f(p_p0) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLaySep{});
}


/// AtOpenL: fn Ps -> Bool
bool at_open_l_f(const Ps& p_p0) {
    return kind_f(p_p0) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLayOpen{});
}


/// AtCloseL: fn Ps -> Bool
bool at_close_l_f(const Ps& p_p0) {
    return kind_f(p_p0) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLayClose{});
}


/// AtComma: fn Ps -> Bool
bool at_comma_f(const Ps& p_p0) {
    return kind_f(p_p0) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KComma{});
}


/// AtColon: fn Ps -> Bool
bool at_colon_f(const Ps& p_p0) {
    return kind_f(p_p0) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KColon{});
}


/// IsOpenKind: fn TokKind, Text -> Bool
bool is_open_kind_f(const crate::syntax::lexer::TokKind& tok_kind0, const Text& text1) {
    auto&& _m = std::tuple{tok_kind0, text1};
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(std::get<0>(_m))) {
        auto&& k_p0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(std::get<0>(_m)).a0;
        auto&& kind_p1 = std::get<1>(_m);
        return k_p0 == kind_p1;
    }
    {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// AtDoubleOpen: fn Ps, Text -> Bool
bool at_double_open_f(const Ps& p_p0, const Text& kind_p1) {
    return is_open_kind_f(kind_f(p_p0), kind_p1) && prism_rtl::deref(pair_at_f(p_p0)).outer_p;
}


/// AtSingleOpen: fn Ps, Text -> Bool
bool at_single_open_f(const Ps& p_p0, const Text& kind_p1) {
    return is_open_kind_f(kind_f(p_p0), kind_p1) && (!prism_rtl::deref(pair_at_f(p_p0)).outer_p);
}


/// AtClose: fn Ps, Text -> Bool
bool at_close_f(const Ps& p_p0, const Text& kind_p1) {
    return kind_f(p_p0) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KClose{kind_p1});
}


/// OpenDouble: fn Ps -> Ps
Ps open_double_f(const Ps& p_p0) {
    return adv_f(adv_f(p_p0));
}


/// CloseDouble: fn Ps, Text -> Ps
Ps close_double_f(const Ps& p_p0, const Text& kind_p1) {
    auto c_p2 = crate::syntax::lexer::close_char_f(kind_p1);
    auto p1_p3 = adv_f(p_p0);
    return ((at_close_f(p_p0, kind_p1) && prism_rtl::deref(pair_at_f(p_p0)).inner_p) && at_close_f(p1_p3, kind_p1)) && prism_rtl::deref(pair_at_f(p1_p3)).outer_p
        ? adv_f(p1_p3)
        : at_close_f(p_p0, kind_p1) && prism_rtl::deref(pair_at_f(p_p0)).inner_p
        ? error_here_f(p1_p3, prism_rtl::cat("expected `", c_p2, c_p2, "` to close the double bracket"))
        : error_here_f(p_p0, prism_rtl::cat("expected `", c_p2, c_p2, "` to close the double bracket"));
}


/// ExpectClose: fn Ps, Text -> Ps
Ps expect_close_f(const Ps& p_p0, const Text& kind_p1) {
    return at_close_f(p_p0, kind_p1)
        ? adv_f(p_p0)
        : error_here_f(p_p0, prism_rtl::cat("expected `", crate::syntax::lexer::close_char_f(kind_p1), "`"));
}


/// ParseDiag: fn Range, Text -> Diag
crate::syntax::Diag parse_diag_f(const crate::syntax::Range& span_p0, const Text& message_p1) {
    return crate::syntax::Diag{.stage_p = Text::lit("parse"), .span_p = span_p0, .message_p = message_p1, .feature_o = std::optional<Text>{}};
}


/// ErrorAt: fn Ps, Range, Text -> Ps
Ps error_at_f(const Ps& p_p0, const crate::syntax::Range& span_p1, const Text& message_p2) {
    return p_p0.bad_p
        ? p_p0
        : ({
        Ps this_ = p_p0;
        this_.diags_p = crate::prelude::push(this_.diags_p, parse_diag_f(span_p1, message_p2));
        this_.bad_p = true;
        (std::move(this_));
    });
}


/// ErrorHere: fn Ps, Text -> Ps
Ps error_here_f(const Ps& p_p0, const Text& message_p1) {
    return error_at_f(p_p0, here_f(p_p0), prism_rtl::cat(message_p1, ", found ", describe_f(kind_f(p_p0))));
}


/// Fail: fn Ps -> Ps
Ps fail_f(const Ps& p_p0) {
    Ps this_ = p_p0;
    this_.bad_p = true;
    return this_;
}


/// Unbad: fn Ps -> Ps
Ps unbad_f(const Ps& p_p0) {
    Ps this_ = p_p0;
    this_.bad_p = false;
    return this_;
}


/// NoteError: fn Ps, Range, Text -> Ps
Ps note_error_f(const Ps& p_p0, const crate::syntax::Range& span_p1, const Text& message_p2) {
    return p_p0.bad_p
        ? p_p0
        : ({
        Ps this_ = p_p0;
        this_.diags_p = crate::prelude::push(this_.diags_p, parse_diag_f(span_p1, message_p2));
        (std::move(this_));
    });
}


/// Complain: fn Ps, Text -> Ps
Ps complain_f(const Ps& p_p0, const Text& message_p1) {
    return unbad_f(error_here_f(p_p0, message_p1));
}


/// OutOfScope: fn Ps, Range, Text, Text -> Ps
Ps out_of_scope_f(const Ps& p_p0, const crate::syntax::Range& span_p1, const Text& feature_p2, const Text& message_p3) {
    return p_p0.bad_p
        ? p_p0
        : ({
        Ps this_ = p_p0;
        this_.out_p = crate::prelude::push(this_.out_p, crate::syntax::Diag{.stage_p = Text::lit("out"), .span_p = span_p1, .message_p = message_p3, .feature_o = std::optional(feature_p2)});
        (std::move(this_));
    });
}


/// ExpectColon: fn Ps -> Ps
Ps expect_colon_f(const Ps& p_p0) {
    return at_colon_f(p_p0)
        ? adv_f(p_p0)
        : error_here_f(p_p0, Text::lit("expected `:`"));
}


/// ExpectOp: fn Ps, Text -> Ps
Ps expect_op_f(const Ps& p_p0, const Text& op_p1) {
    return at_op_f(p_p0, op_p1)
        ? adv_f(p_p0)
        : error_here_f(p_p0, prism_rtl::cat("expected `", op_p1, "`"));
}


/// ExpectKw: fn Ps, Text -> Ps
Ps expect_kw_f(const Ps& p_p0, const Text& w_p1) {
    return at_kw_f(p_p0, w_p1)
        ? adv_f(p_p0)
        : error_here_f(p_p0, prism_rtl::cat("expected `", w_p1, "`"));
}


/// Recover: unbounded fn Ps -> Ps
Ps recover_f(const Ps& p0_p0) {
    Ps this_ = unbad_f(p0_p0);
    Nat depth_p1 = Nat(0u);
    bool going_p2 = true;
    while (std::move(going_p2)) {
        ({
            __label__ _done;
            prism_rtl::Slot<Unit> _v;
            auto&& _m = kind_f(this_);
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KEof>(_m)) {
                _v.set(({
                    going_p2 = false;
                    Unit{};
                }));
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayOpen>(_m)) {
                _v.set(({
                    depth_p1 = depth_p1 + Nat(1u);
                    this_ = adv_f(this_);
                    Unit{};
                }));
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayClose>(_m)) {
                _v.set(({
                    if (depth_p1 == Nat(0u)) {
                        going_p2 = false;
                    } else  {
                        depth_p1 = crate::syntax::lexer::chars::dec_f(depth_p1);
                        this_ = adv_f(this_);
                    }
                    Unit{};
                }));
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KLaySep>(_m)) {
                if (depth_p1 == Nat(0u)) {
                    _v.set(({
                        going_p2 = false;
                        Unit{};
                    }));
                    goto _done;
                }
            }
            {
                _v.set(({
                    this_ = adv_f(this_);
                    Unit{};
                }));
                goto _done;
            }
        _done:
            _v.take();
        });
    }
    return this_;
}


prism_rtl::Turn<Ps> Recover::cycle() const {
    const auto& p0_p0 = this->p0_p0;
    Ps this_ = unbad_f(p0_p0);
    Nat depth_p1 = Nat(0u);
    bool going_p2 = true;
    return crate::prelude::call_then(crate::prelude::loop_job(std::tuple{std::move(this_), std::move(depth_p1), std::move(going_p2)}, [=](std::tuple<Ps, Nat, bool> _p0) {
        auto this_ = std::get<0>(_p0);
        auto depth_p1 = std::get<1>(_p0);
        auto going_p2 = std::get<2>(_p0);
        return going_p2
            ? ({
            ({
                __label__ _done;
                prism_rtl::Slot<Unit> _v;
                auto&& _m = kind_f(this_);
                if (prism_rtl::is<crate::syntax::lexer::TokKind::KEof>(_m)) {
                    _v.set(({
                        going_p2 = false;
                        Unit{};
                    }));
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayOpen>(_m)) {
                    _v.set(({
                        depth_p1 = depth_p1 + Nat(1u);
                        this_ = adv_f(this_);
                        Unit{};
                    }));
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayClose>(_m)) {
                    _v.set(({
                        if (depth_p1 == Nat(0u)) {
                            going_p2 = false;
                        } else  {
                            depth_p1 = crate::syntax::lexer::chars::dec_f(depth_p1);
                            this_ = adv_f(this_);
                        }
                        Unit{};
                    }));
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::lexer::TokKind::KLaySep>(_m)) {
                    if (depth_p1 == Nat(0u)) {
                        _v.set(({
                            going_p2 = false;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    _v.set(({
                        this_ = adv_f(this_);
                        Unit{};
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            });
            Expected<std::tuple<Ps, Nat, bool>, std::tuple<Ps, Nat, bool>>(std::tuple{this_, depth_p1, going_p2});
        })
            : Expected<std::tuple<Ps, Nat, bool>, std::tuple<Ps, Nat, bool>>(unexpected(std::tuple{this_, depth_p1, going_p2}));
    }), [=](std::tuple<Ps, Nat, bool> _p0) {
        auto this_ = std::get<0>(_p0);
        auto depth_p1 = std::get<1>(_p0);
        auto going_p2 = std::get<2>(_p0);
        return prism_rtl::finished(this_);
    });
}


/// `Start Recover, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ps> start_recover_f(Ps p0_p0) {
    return prism_rtl::make_rc<Recover>(p0_p0);
}


/// Recovered: unbounded fn Ps -> Ps
Ps recovered_f(const Ps& p_p0) {
    return p_p0.bad_p ? recover_f(p_p0) : p_p0;
}


prism_rtl::Turn<Ps> Recovered::cycle() const {
    const auto& p_p0 = this->p_p0;
    return prism_rtl::deref(p_p0).bad_p
        ? prism_rtl::more(prism_rtl::rc(Recover(p_p0)))
        : prism_rtl::finished(p_p0);
}


/// `Start Recovered, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ps> start_recovered_f(Ps p_p0) {
    return prism_rtl::make_rc<Recovered>(p_p0);
}


/// AtStmtBoundary: fn Ps -> Bool
bool at_stmt_boundary_f(const Ps& p_p0) {
    auto&& _m = kind_f(p_p0);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLaySep>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayClose>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KEof>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// ExpectStmtEnd: unbounded fn Ps, Text -> Ps
Ps expect_stmt_end_f(const Ps& p_p0, const Text& what_p1) {
    return at_stmt_boundary_f(p_p0)
        ? p_p0
        : recover_f(note_error_f(p_p0, here_f(p_p0), prism_rtl::cat("expected the end of the ", what_p1, ", found ", describe_f(kind_f(p_p0)))));
}


prism_rtl::Turn<Ps> ExpectStmtEnd::cycle() const {
    const auto& p_p0 = this->p_p0;
    const auto& what_p1 = this->what_p1;
    return at_stmt_boundary_f(p_p0)
        ? prism_rtl::finished(p_p0)
        : prism_rtl::more(prism_rtl::rc(Recover(note_error_f(p_p0, here_f(p_p0), prism_rtl::cat("expected the end of the ", what_p1, ", found ", describe_f(kind_f(p_p0)))))));
}


/// `Start ExpectStmtEnd, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ps> start_expect_stmt_end_f(Ps p_p0, Text what_p1) {
    return prism_rtl::make_rc<ExpectStmtEnd>(p_p0, what_p1);
}


/// Describe: fn TokKind -> Text
Text describe_f(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayOpen>(tok_kind0)) {
        return Text::lit("an indented block");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLaySep>(tok_kind0)) {
        return Text::lit("the end of the line");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayClose>(tok_kind0)) {
        return Text::lit("the end of the block");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KEof>(tok_kind0)) {
        return Text::lit("the end of the input");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KText>(tok_kind0)) {
        return Text::lit("a text literal");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KRegex>(tok_kind0)) {
        return Text::lit("a regular expression");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KTemplate>(tok_kind0)) {
        return Text::lit("a template");
    }
    {
        auto&& k_p0 = tok_kind0;
        return prism_rtl::cat("`", crate::syntax::lexer::corpus::token_text_f(k_p0), "`");
    }
}


/// WithStepMode: fn Ps, Bool -> Ps
Ps with_step_mode_f(const Ps& p_p0, const bool& flag_p1) {
    Ps this_ = p_p0;
    this_.step_mode_p = flag_p1;
    return this_;
}


/// let noSName
crate::syntax::SName no_sname_p() {
    return crate::syntax::SName{.sigils_p = Text::lit(""), .path_p = Array<Text>{}, .span_p = no_range_p()};
}


/// let noIdent
crate::syntax::Ident no_ident_p() {
    return crate::syntax::Ident{.name_p = Text::lit(""), .span_p = no_range_p()};
}


/// IsUpperName: fn SName -> Bool
bool is_upper_name_f(const crate::syntax::SName& n_p0) {
    return crate::syntax::lexer::chars::is_upper_f(crate::syntax::lexer::chars::head_f(crate::prelude::or_(crate::syntax::lexer::chars::last_o(n_p0.path_p), Text::lit(""))));
}


/// IsCallee: fn SName -> Bool
bool is_callee_f(const crate::syntax::SName& n_p0) {
    return is_upper_name_f(n_p0) || crate::syntax::lexer::chars::is_reserved_ctor_f(crate::prelude::or_(crate::syntax::lexer::chars::last_o(n_p0.path_p), Text::lit("")));
}


/// IsTopic: fn SName -> Bool
bool is_topic_f(const crate::syntax::SName& n_p0) {
    return n_p0.path_p == Array(std::vector{Text::lit("_")});
}


/// NameText: fn SName -> Text
Text name_text_f(const crate::syntax::SName& n_p0) {
    return prism_rtl::cat(n_p0.sigils_p, crate::syntax::lexer::chars::join_f(n_p0.path_p, Text::lit(".")));
}


/// ParseSName: fn Ps -> ((SName, Ps))
std::tuple<crate::syntax::SName, Ps> parse_sname_f(const Ps& p_p0) {
    auto&& _m = kind_f(p_p0);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        return std::tuple{crate::syntax::SName{.sigils_p = prism_rtl::deref(n_p1).sigils_p, .path_p = prism_rtl::deref(n_p1).path_p, .span_p = here_f(p_p0)}, adv_f(p_p0)};
    }
    {
        return std::tuple{no_sname_p(), error_here_f(p_p0, Text::lit("expected a name"))};
    }
}


/// ParseIdent: fn Ps -> ((Ident, Ps))
std::tuple<crate::syntax::Ident, Ps> parse_ident_f(const Ps& p_p0) {
    auto&& _m = kind_f(p_p0);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        if (((prism_rtl::deref(n_p1).sigils_p == Text::lit("")) && (crate::prelude::len(prism_rtl::deref(n_p1).path_p) == Nat(1u))) && (prism_rtl::deref(n_p1).case_p == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseLower{}))) {
            return std::tuple{crate::syntax::Ident{.name_p = crate::prelude::or_(crate::prelude::index(prism_rtl::deref(n_p1).path_p, Nat(0u)), Text::lit("")), .span_p = here_f(p_p0)}, adv_f(p_p0)};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m16396_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m16396_1_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m16396_1_0 == Text::lit("key")) {
            if (m16396_1_1 == Text::lit("")) {
                return std::tuple{crate::syntax::Ident{.name_p = Text::lit("key"), .span_p = here_f(p_p0)}, adv_f(p_p0)};
            }
        }
    }
    {
        return std::tuple{no_ident_p(), error_here_f(p_p0, Text::lit("expected a lowercase name"))};
    }
}


/// ParseQualName: fn Ps -> ((QualName, Ps))
std::tuple<crate::syntax::QualName, Ps> parse_qual_name_f(const Ps& p_p0) {
    auto&& _m = kind_f(p_p0);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        if ((prism_rtl::deref(n_p1).sigils_p == Text::lit("")) && (prism_rtl::deref(n_p1).case_p == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseUpper{}))) {
            return std::tuple{crate::syntax::QualName{.path_p = prism_rtl::deref(n_p1).path_p, .span_p = here_f(p_p0)}, adv_f(p_p0)};
        }
    }
    {
        return std::tuple{crate::syntax::QualName{.path_p = Array<Text>{}, .span_p = no_range_p()}, error_here_f(p_p0, Text::lit("expected an uppercase name"))};
    }
}


/// ParseTraitRef: fn Ps -> ((TraitRef, Ps))
std::tuple<crate::syntax::TraitRef, Ps> parse_trait_ref_f(const Ps& p_p0) {
    auto&& _m = kind_f(p_p0);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KTrait>(_m)) {
        auto&& path_p1 = prism_rtl::as<crate::syntax::lexer::TokKind::KTrait>(_m).a0;
        auto span_p2 = here_f(p_p0);
        auto q_p3 = path_p1 == Array(std::vector{Text::lit("Monad")})
            ? out_of_scope_f(p_p0, span_p2, Text::lit("`T monad:` blocks and `^Monad`"), Text::lit("`^Monad` is out of this compiler"))
            : p_p0;
        return std::tuple{crate::syntax::TraitRef{.path_p = path_p1, .span_p = span_p2}, adv_f(q_p3)};
    }
    {
        return std::tuple{crate::syntax::TraitRef{.path_p = Array<Text>{}, .span_p = no_range_p()}, error_here_f(p_p0, Text::lit("expected a trait, `^Name`"))};
    }
}


/// CheckNameScope: fn Ps, SName -> Ps
Ps check_name_scope_f(const Ps& p_p0, const crate::syntax::SName& name_p1) {
    auto text_p2 = name_text_f(name_p1);
    auto feature_p3 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        {
            auto&& m17559_0 = text_p2;
            if (m17559_0 == Text::lit("!Align")) {
                _v.set(Text::lit("`!Align`"));
                goto _done;
            }
        }
        {
            auto&& m17559_1 = text_p2;
            if (m17559_1 == Text::lit("@Collect")) {
                _v.set(Text::lit("POD hosting (`@Collect`, `@View`, `@Edit`, `@Translate`)"));
                goto _done;
            }
        }
        {
            auto&& m17559_2 = text_p2;
            if (m17559_2 == Text::lit("@View")) {
                _v.set(Text::lit("POD hosting (`@Collect`, `@View`, `@Edit`, `@Translate`)"));
                goto _done;
            }
        }
        {
            auto&& m17559_3 = text_p2;
            if (m17559_3 == Text::lit("@Edit")) {
                _v.set(Text::lit("POD hosting (`@Collect`, `@View`, `@Edit`, `@Translate`)"));
                goto _done;
            }
        }
        {
            auto&& m17559_4 = text_p2;
            if (m17559_4 == Text::lit("@Translate")) {
                _v.set(Text::lit("POD hosting (`@Collect`, `@View`, `@Edit`, `@Translate`)"));
                goto _done;
            }
        }
        {
            auto&& m17559_5 = text_p2;
            if (m17559_5 == Text::lit("Over")) {
                _v.set(Text::lit("named lenses `&Home` and `Over`"));
                goto _done;
            }
        }
        {
            _v.set(Text::lit(""));
            goto _done;
        }
    _done:
        _v.take();
    });
    return feature_p3 == Text::lit("")
        ? p_p0
        : out_of_scope_f(p_p0, name_p1.span_p, feature_p3, prism_rtl::cat("`", text_p2, "` is out of this compiler"));
}


/// CheckTypeNameScope: fn Ps, SName -> Ps
Ps check_type_name_scope_f(const Ps& p_p0, const crate::syntax::SName& name_p1) {
    auto b_p2 = crate::prelude::or_(crate::syntax::lexer::chars::last_o(name_p1.path_p), Text::lit(""));
    auto sized_p3 = crate::prelude::fold(Array(std::vector{Text::lit("U16"), Text::lit("U32"), Text::lit("U64"), Text::lit("U128"), Text::lit("I8"), Text::lit("I16"), Text::lit("I32"), Text::lit("I64"), Text::lit("I128")}), false, [&](const bool& seen_p4, const Text& s_p5) { return prism_rtl::deref(seen_p4) || (s_p5 == b_p2); });
    return crate::prelude::len(name_p1.path_p) != Nat(1u)
        ? p_p0
        : std::move(sized_p3)
        ? out_of_scope_f(p_p0, name_p1.span_p, Text::lit("sized ints other than `U8`"), prism_rtl::cat("`", b_p2, "` is out of this compiler: the sized integer it has is `U8`"))
        : b_p2 == Text::lit("Instant")
        ? out_of_scope_f(p_p0, name_p1.span_p, Text::lit("`Instant`"), Text::lit("`Instant` is out of this compiler"))
        : p_p0;
}

}  // namespace crate::syntax::parser
