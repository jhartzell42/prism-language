// The module `Lower.Node.Switch`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <lower/node_/switch_/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/model/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Lower.Node.Switch`, from `target/bootstrap/cpp-src/prismc/lower/node/switch.prism`.
namespace crate::lower::node_::switch_ {



Pod GenCase::to_pod() const {
    return Pod::record("GenCase", {{"node", prism_rtl::to_pod(node_p)}, {"params", prism_rtl::to_pod(params_p)}, {"pat", prism_rtl::to_pod(pat_p)}, {"conds", prism_rtl::to_pod(conds_p)}, {"passed", prism_rtl::to_pod(passed_p)}});
}

Result<GenCase> GenCase::from_pod(const Pod& whole) {
    return GenCase{.node_p = TRY(prism_rtl::from_pod<crate::lower::model::NodeDef>(TRY(crate::prelude::field(whole, "node")))), .params_p = TRY(prism_rtl::from_pod<Array<std::tuple<Text, crate::lower::model::OutTy>>>(TRY(crate::prelude::field(whole, "params")))), .pat_p = TRY(prism_rtl::from_pod<crate::lower::model::Pa>(TRY(crate::prelude::field(whole, "pat")))), .conds_p = TRY(prism_rtl::from_pod<Array<crate::lower::model::Cc>>(TRY(crate::prelude::field(whole, "conds")))), .passed_p = TRY(prism_rtl::from_pod<Array<crate::lower::model::Ex>>(TRY(crate::prelude::field(whole, "passed"))))};
}




/// RowEnv: unbounded fn Wx, Wx, Env, Block -> ((Wx, Wx, Env))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env> row_env_f(const crate::lower::node_::Wx& parent_p0, const crate::lower::node_::Wx& row_wx_p1, const crate::lower::types::Env& menv_p2, const crate::syntax::Block& body_p3) {
    auto names_p4 = crate::lower::expr::read_names_f(crate::check::typed::print::block_exprs_f(body_p3));
    return crate::prelude::fold(names_p4, std::tuple{parent_p0, row_wx_p1, crate::lower::types::empty_env_p()}, [&](const std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env>& _p0, const Text& n_p8) {
        auto&& p_p5 = std::get<0>(_p0);
        auto&& r_p6 = std::get<1>(_p0);
        auto&& env_p7 = std::get<2>(_p0);
        return ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env>> _v;
            auto&& _m = crate::prelude::get(menv_p2.names_p, n_p8);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs_p9 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& mode_pa = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                auto&& t_pb = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(std::tuple{p_p5, r_p6, crate::lower::types::bind_f(env_p7, n_p8, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{over_parent_f(rs_p9), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t_pb}))});
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(_m))) {
                auto&& er_pc = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(_m)).a0;
                auto&& t_pd = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(_m)).a1;
                _v.set(({
                    auto pname_pe = prism_rtl::deref(crate::lower::node_::gn_of_f(p_p5, prism_rtl::deref(er_pc).node_p)).name_p;
                    auto [rs_ph, r1_pi] = crate::lower::node_::fresh_name_f(r_p6, crate::lower::snake_f(n_p8));
                    auto [id_pj, r2_pk] = crate::lower::node_::add_gn_f(r1_pi, rs_ph, t_pd, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnPort{}), Nat(0u));
                    auto r3_pf = ({
                        crate::lower::node_::Wx this_ = r2_pk;
                        this_.subs_p = crate::prelude::push(this_.subs_p, std::tuple{pname_pe, rs_ph, t_pd});
                        (std::move(this_));
                    });
                    auto p2_pg = crate::check::types::has_text_f(prism_rtl::deref(p_p5).ports_p, pname_pe)
                        ? p_p5
                        : crate::lower::node_::connect_f(with_port_f(p_p5, pname_pe), crate::lower::node_::ev_ref_of_f(p_p5, prism_rtl::deref(er_pc).node_p), crate::lower::node_::Sk(crate::lower::node_::Sk::SkPort{pname_pe}));
                    std::tuple{p2_pg, r3_pf, crate::lower::types::bind_f(env_p7, n_p8, crate::lower::types::Bn(crate::lower::types::Bn::BnEv{crate::lower::node_::ev_ref_of_f(r3_pf, id_pj), t_pd}))};
                }));
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)) && prism_rtl::is<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0)) {
                auto&& recv_pl = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a0;
                auto&& m_pm = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a1;
                auto&& xs_pn = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a2;
                auto&& t_po = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a2;
                _v.set(prism_rtl::deref(recv_pl) == crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})
                    ? std::tuple{p_p5, r_p6, crate::lower::types::bind_f(env_p7, n_p8, crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(parent_ref_p()), m_pm, xs_pn}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{m_pm})}), t_po}))}
                    : row_param_env_f(p_p5, r_p6, env_p7, menv_p2, n_p8));
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m))) {
                _v.set(row_param_env_f(p_p5, r_p6, env_p7, menv_p2, n_p8));
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(_m))) {
                auto&& f_pp = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(_m)).a0;
                auto&& t_pq = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(_m)).a1;
                _v.set(std::tuple{p_p5, r_p6, crate::lower::types::bind_f(env_p7, n_p8, crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(parent_ref_p()), f_pp})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{f_pp})}), t_pq}))});
                goto _done;
            }
            {
                _v.set(std::tuple{p_p5, r_p6, env_p7});
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// RowParamEnv: fn Wx, Wx, Env, Env, Text -> ((Wx, Wx, Env))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env> row_param_env_f(const crate::lower::node_::Wx& p_p0, const crate::lower::node_::Wx& r_p1, const crate::lower::types::Env& env_p2, const crate::lower::types::Env& menv_p3, const Text& n_p4) {
    auto&& _m = crate::prelude::get(menv_p3.names_p, prism_rtl::cat(n_p4, "#row"));
    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)) && prism_rtl::is<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0)) {
        auto&& m_p5 = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a1;
        auto&& xs_p6 = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a2;
        auto&& t_p7 = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a2;
        return std::tuple{p_p0, r_p1, crate::lower::types::bind_f(env_p2, n_p4, crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(parent_ref_p()), m_p5, xs_p6}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{m_p5})}), t_p7}))};
    }
    {
        return std::tuple{p_p0, r_p1, env_p2};
    }
}


/// OverParent: fn Ex -> Ex
crate::lower::model::Ex over_parent_f(const crate::lower::model::Ex& x_p0) {
    if (prism_rtl::is<crate::lower::model::Ex::XSelf>(x_p0)) {
        return parent_ref_p();
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x_p0)) {
        auto&& y_p1 = prism_rtl::as<crate::lower::model::Ex::XField>(x_p0).a0;
        auto&& f_p2 = prism_rtl::as<crate::lower::model::Ex::XField>(x_p0).a1;
        return crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(over_parent_f(prism_rtl::deref(prism_rtl::deref(y_p1)))), f_p2});
    }
    if (prism_rtl::is<crate::lower::model::Ex::XPart>(x_p0)) {
        auto&& y_p3 = prism_rtl::as<crate::lower::model::Ex::XPart>(x_p0).a0;
        auto&& k_p4 = prism_rtl::as<crate::lower::model::Ex::XPart>(x_p0).a1;
        return crate::lower::model::Ex(crate::lower::model::Ex::XPart{prism_rtl::rc(over_parent_f(prism_rtl::deref(prism_rtl::deref(y_p3)))), k_p4});
    }
    if (prism_rtl::is<crate::lower::model::Ex::XMethod>(x_p0)) {
        auto&& y_p5 = prism_rtl::as<crate::lower::model::Ex::XMethod>(x_p0).a0;
        auto&& m_p6 = prism_rtl::as<crate::lower::model::Ex::XMethod>(x_p0).a1;
        auto&& xs_p7 = prism_rtl::as<crate::lower::model::Ex::XMethod>(x_p0).a2;
        return crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(over_parent_f(prism_rtl::deref(prism_rtl::deref(y_p5)))), m_p6, xs_p7});
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUpgrade>(x_p0)) {
        auto&& y_p8 = prism_rtl::as<crate::lower::model::Ex::XUpgrade>(x_p0).a0;
        return crate::lower::model::Ex(crate::lower::model::Ex::XUpgrade{prism_rtl::rc(over_parent_f(prism_rtl::deref(prism_rtl::deref(y_p8))))});
    }
    {
        return crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(parent_ref_p()), crate::lower::types::place_stem_f(x_p0)});
    }
}


/// let parentRef
crate::lower::model::Ex parent_ref_p() {
    return crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XUpgrade{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("parent")}))})), Text::lit("expect"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{Text::lit("the block outlives its rows")})})});
}


/// let parentArg
crate::lower::model::Ex parent_arg_p() {
    return crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XUpgrade{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("parent")}))})), Text::lit("expect"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{Text::lit("the block outlives its rows")})})});
}


/// WithPort: fn Wx, Text -> Wx
crate::lower::node_::Wx with_port_f(const crate::lower::node_::Wx& wx_p0, const Text& pname_p1) {
    crate::lower::node_::Wx this_ = wx_p0;
    this_.ports_p = crate::prelude::push(this_.ports_p, pname_p1);
    return this_;
}


/// RebuildLine: unbounded fn Wx, Env, Env, Expr, Block, Expr, ?Bn -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> rebuild_line_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const crate::syntax::Expr& scrut_p3, const crate::syntax::Block& body_p4, const crate::syntax::Expr& e_p5, const std::optional<crate::lower::types::Bn>& bound_o6) {
    auto lx_p7 = wx_p0.lx_p;
    auto pos_p8 = wx_p0.pos_p;
    auto wx1_p9 = ({
        crate::lower::node_::Wx this_ = wx_p0;
        this_.pos_p = crate::lower::model::next_pos_f(this_.pos_p);
        (std::move(this_));
    });
    auto [src_ex_pb, reads_pc] = crate::lower::node_::dynamics::dynamic_expr_f(wx1_p9, menv_p2, scrut_p3);
    auto vt_pa = crate::lower::types::out_ty_of_f(lx_p7, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p7, scrut_p3.span_p)));
    auto [name_pd, wx2_pe] = crate::lower::node_::fresh_name_f(wx1_p9, Text::lit("generation"));
    return gives_dynamic_f(crate::lower::type_at_f(lx_p7, e_p5.span_p))
        ? rebuild_dynamic_f(wx2_pe, menv_p2, body_p4, src_ex_pb, reads_pc, vt_pa, name_pd, pos_p8)
        : ({
        auto [up_id_pj, wx3_pk] = ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Nat, crate::lower::node_::Wx>> _v;
            if (prism_rtl::is_some(bound_o6) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_o6))) {
                auto&& er_pi = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_o6)).a0;
                _v.set(std::tuple{prism_rtl::deref(er_pi).node_p, wx2_pe});
                goto _done;
            }
            {
                _v.set(crate::lower::node_::add_gn_f(wx2_pe, prism_rtl::cat(name_pd, "_fired"), crate::lower::types::out_ty_of_f(lx_p7, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p7, e_p5.span_p))), crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnNamed{}), Nat(0u)));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto [cases_pl, wx4_pm] = gen_cases_f(wx3_pk, menv_p2, body_p4, vt_pa, name_pd);
        auto row_defs_pf = crate::prelude::each(cases_pl, [&](const GenCase& c_pn) { return prism_rtl::deref(c_pn).node_p; });
        auto select_pg = gen_select_f(wx4_pm, menv_p2, body_p4, cases_pl, pos_p8);
        auto wx5_ph = ({
            crate::lower::node_::Wx this_ = wx4_pm;
            this_.gens_p = crate::prelude::push(this_.gens_p, crate::lower::model::GenDef{.name_p = name_pd, .pos_p = pos_p8, .at_p = crate::lower::node_::finish::place_at_f(wx_p0, Text::lit("self"), pos_p8), .source_p = src_ex_pb, .value_ty_p = vt_pa, .select_p = select_pg, .transparent_p = false, .width_p = Nat(0u), .moved_p = crate::prelude::or_(crate::lower::node_::finish::hosted_rows_o(wx_p0), Text::lit(""))});
            this_.gen_holds_p = crate::prelude::push(this_.gen_holds_p, std::tuple{name_pd, reads_pc});
            this_.rows_p = crate::prelude::fold(row_defs_pf, this_.rows_p, [&](const Array<crate::lower::model::NodeDef>& acc_po, const crate::lower::model::NodeDef& rd_pp) { return crate::prelude::append(crate::prelude::push(acc_po, rd_pp), prism_rtl::deref(rd_pp).children_p); });
            this_.getters_p = crate::prelude::push(this_.getters_p, gen_up_f(name_pd, prism_rtl::deref(crate::lower::node_::gn_of_f(wx4_pm, up_id_pj)).name_p, prism_rtl::deref(crate::lower::node_::gn_of_f(wx4_pm, up_id_pj)).ty_p));
            (std::move(this_));
        });
        std::tuple{wx5_ph, crate::lower::node_::Wres(crate::lower::node_::Wres::WrEv{crate::lower::node_::ev_ref_of_f(wx5_ph, up_id_pj)})};
    });
}


prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> RebuildLine::cycle() const {
    const auto& wx_p0 = this->wx_p0;
    const auto& benv_p1 = this->benv_p1;
    const auto& menv_p2 = this->menv_p2;
    const auto& scrut_p3 = this->scrut_p3;
    const auto& body_p4 = this->body_p4;
    const auto& e_p5 = this->e_p5;
    const auto& bound_o6 = this->bound_o6;
    auto lx_p7 = prism_rtl::deref(wx_p0).lx_p;
    auto pos_p8 = prism_rtl::deref(wx_p0).pos_p;
    auto wx1_p9 = ({
        crate::lower::node_::Wx this_ = wx_p0;
        this_.pos_p = crate::lower::model::next_pos_f(this_.pos_p);
        (std::move(this_));
    });
    auto bound_o6x = bound_o6;
    auto body_p4x = body_p4;
    auto e_p5x = e_p5;
    auto menv_p2x = menv_p2;
    auto scrut_p3x = scrut_p3;
    auto wx_p0x = wx_p0;
    return crate::prelude::call_then(crate::lower::node_::dynamics::start_dynamic_expr_f(wx1_p9, menv_p2x, scrut_p3x), [=](std::tuple<crate::lower::model::Ex, Array<crate::lower::node_::Read>> dynamic_expr_f_4431) {
        return ({
            auto [src_ex_pb, reads_pc] = dynamic_expr_f_4431;
            (crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p7, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p7, prism_rtl::deref(scrut_p3x).span_p))), [=](crate::lower::model::OutTy out_ty_of_f_4473) {
            return ({
                auto vt_pa = out_ty_of_f_4473;
                auto [name_pd, wx2_pe] = crate::lower::node_::fresh_name_f(wx1_p9, Text::lit("generation"));
                gives_dynamic_f(crate::lower::type_at_f(lx_p7, prism_rtl::deref(e_p5x).span_p))
                ? prism_rtl::finished(rebuild_dynamic_f(wx2_pe, menv_p2x, body_p4x, src_ex_pb, reads_pc, vt_pa, name_pd, pos_p8))
                : ({
                auto [up_id_pj, wx3_pk] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<Nat, crate::lower::node_::Wx>> _v;
                    if (prism_rtl::is_some(bound_o6x) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_o6x))) {
                        auto&& er_pi = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_o6x)).a0;
                        _v.set(std::tuple{prism_rtl::deref(er_pi).node_p, wx2_pe});
                        goto _done;
                    }
                    {
                        _v.set(crate::lower::node_::add_gn_f(wx2_pe, prism_rtl::cat(name_pd, "_fired"), crate::lower::types::out_ty_of_f(lx_p7, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p7, prism_rtl::deref(e_p5x).span_p))), crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnNamed{}), Nat(0u)));
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto [cases_pl, wx4_pm] = gen_cases_f(wx3_pk, menv_p2x, body_p4x, vt_pa, name_pd);
                auto row_defs_pf = crate::prelude::each(cases_pl, [&](const GenCase& c_pn) { return prism_rtl::deref(c_pn).node_p; });
                auto select_pg = gen_select_f(wx4_pm, menv_p2x, body_p4x, cases_pl, pos_p8);
                auto wx5_ph = ({
                    crate::lower::node_::Wx this_ = wx4_pm;
                    this_.gens_p = crate::prelude::push(this_.gens_p, crate::lower::model::GenDef{.name_p = name_pd, .pos_p = pos_p8, .at_p = crate::lower::node_::finish::place_at_f(wx_p0x, Text::lit("self"), pos_p8), .source_p = src_ex_pb, .value_ty_p = vt_pa, .select_p = select_pg, .transparent_p = false, .width_p = Nat(0u), .moved_p = crate::prelude::or_(crate::lower::node_::finish::hosted_rows_o(wx_p0x), Text::lit(""))});
                    this_.gen_holds_p = crate::prelude::push(this_.gen_holds_p, std::tuple{name_pd, reads_pc});
                    this_.rows_p = crate::prelude::fold(row_defs_pf, this_.rows_p, [&](const Array<crate::lower::model::NodeDef>& acc_po, const crate::lower::model::NodeDef& rd_pp) { return crate::prelude::append(crate::prelude::push(acc_po, rd_pp), prism_rtl::deref(rd_pp).children_p); });
                    this_.getters_p = crate::prelude::push(this_.getters_p, gen_up_f(name_pd, prism_rtl::deref(crate::lower::node_::gn_of_f(wx4_pm, up_id_pj)).name_p, prism_rtl::deref(crate::lower::node_::gn_of_f(wx4_pm, up_id_pj)).ty_p));
                    (std::move(this_));
                });
                (prism_rtl::finished(std::tuple{wx5_ph, crate::lower::node_::Wres(crate::lower::node_::Wres::WrEv{crate::lower::node_::ev_ref_of_f(wx5_ph, up_id_pj)})}));
            });
            });
        }));
        });
    });
}


/// `Start RebuildLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> start_rebuild_line_f(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::Expr scrut_p3, crate::syntax::Block body_p4, crate::syntax::Expr e_p5, std::optional<crate::lower::types::Bn> bound_o6) {
    return prism_rtl::make_rc<RebuildLine>(wx_p0, benv_p1, menv_p2, scrut_p3, body_p4, e_p5, bound_o6);
}


/// GivesDynamic: fn Ty -> Bool
bool gives_dynamic_f(const crate::check::types::Ty& t_p0) {
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& m5725_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a0;
        auto&& m5725_0_1 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        if (m5725_0_0 == Text::lit("$")) {
            if (prism_rtl::is<crate::check::types::Ty::TySig>(prism_rtl::deref(prism_rtl::deref(m5725_0_1)))) {
                auto&& m5725_0_1_r_0 = prism_rtl::as<crate::check::types::Ty::TySig>(prism_rtl::deref(prism_rtl::deref(m5725_0_1))).a0;
                if (m5725_0_1_r_0 == Text::lit("$")) {
                    return true;
                }
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p0)) {
        auto&& i_p1 = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p0).a0;
        return gives_dynamic_f(prism_rtl::deref(prism_rtl::deref(i_p1)));
    }
    {
        return false;
    }
}


/// RebuildDynamic: unbounded fn Wx, Env, Block, Ex, [Read], OutTy, Text, Pos -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> rebuild_dynamic_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const crate::syntax::Block& body_p2, const crate::lower::model::Ex& src_ex_p3, const Array<crate::lower::node_::Read>& reads_p4, const crate::lower::model::OutTy& vt_p5, const Text& name_p6, const crate::lower::model::Pos_& pos_p7) {
    auto row_name_p8 = prism_rtl::cat(wx_p0.node_p, "Gen", crate::lower::node_::keyed::row_suffix_f(wx_p0));
    auto whole_p9 = gen_row_of_f(wx_p0, menv_p1, body_p2, vt_p5, row_name_p8, name_p6);
    auto&& _m = prism_rtl::deref(whole_p9).dyn_result_o;
    if (prism_rtl::is_none(_m)) {
        auto wx2_pa = ({
            crate::lower::node_::Wx this_ = prism_rtl::deref(whole_p9).parent_p;
            this_.build_p = crate::prelude::push(this_.build_p, crate::lower::expr::refusal_do_f(Text::lit("a `rebuild` whose generation gives a dynamic it does not lower")));
            (std::move(this_));
        });
        return std::tuple{wx2_pa, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& rt_pb = prism_rtl::some_of(_m);
        auto dyn_ty_pc = crate::lower::model::OutTy(crate::lower::model::OutTy::OutDyn{prism_rtl::rc(rt_pb)});
        auto result_pd = prism_rtl::cat(name_p6, "_result");
        auto live_pe = prism_rtl::cat(result_pd, "_live");
        auto what_pf = prism_rtl::cat("the dynamic of the `rebuild` at place ", crate::lower::model::place_text_f(pos_p7));
        auto tail_pg = crate::prelude::append(crate::prelude::append(Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XWeak{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})}), crate::lower::node_::keyed::hosted_passed_f(wx_p0)), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})}));
        auto built_ph = crate::lower::expr::try_of_f(crate::lower::model::Ex(crate::lower::model::Ex::XCall{prism_rtl::cat(prism_rtl::deref(prism_rtl::deref(whole_p9).node_p).name_p, "::build"), crate::prelude::append(Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("path")}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("value")})}), tail_pg)}));
        auto kept_pi = crate::lower::model::Do(crate::lower::model::Do::DoAssign{crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), live_pe})), Text::lit("borrow_mut"), Array<crate::lower::model::Ex>{}}))}), crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")})), Text::lit("result_dynamic"), Array<crate::lower::model::Ex>{}})})})});
        auto marked_pj = crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(result_pd, "_snap")})), Text::lit("mark"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
        auto select_pk = crate::lower::model::Ex(crate::lower::model::Ex::XBlock{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")}), built_ph}), kept_pi, marked_pj}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")}))});
        auto current_pl = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(live_pe)})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}}))})), Text::lit("expect"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{Text::lit("a `rebuild` has a generation from its build on")})})});
        auto wx2_pm = ({
            crate::lower::node_::Wx this_ = prism_rtl::deref(whole_p9).parent_p;
            this_.gens_p = crate::prelude::push(this_.gens_p, crate::lower::model::GenDef{.name_p = name_p6, .pos_p = pos_p7, .at_p = crate::lower::node_::finish::place_at_f(wx_p0, Text::lit("self"), pos_p7), .source_p = src_ex_p3, .value_ty_p = vt_p5, .select_p = select_pk, .transparent_p = false, .width_p = Nat(0u), .moved_p = crate::prelude::or_(crate::lower::node_::finish::hosted_rows_o(wx_p0), Text::lit(""))});
            this_.gen_holds_p = crate::prelude::push(this_.gen_holds_p, std::tuple{name_p6, reads_p4});
            this_.rows_p = crate::prelude::append(crate::prelude::push(this_.rows_p, prism_rtl::deref(whole_p9).node_p), prism_rtl::deref(prism_rtl::deref(whole_p9).node_p).children_p);
            this_.taken_p = crate::prelude::append(this_.taken_p, Array(std::vector{result_pd, live_pe, prism_rtl::cat(result_pd, "_now"), prism_rtl::cat(result_pd, "_snap"), prism_rtl::cat(result_pd, "_publish"), prism_rtl::cat(result_pd, "_moved")}));
            this_.fields_p = crate::prelude::append(this_.fields_p, Array(std::vector{std::tuple{live_pe, crate::lower::model::OutTy(crate::lower::model::OutTy::OutCell{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(dyn_ty_pc)}))}), Text::lit("the current generation\'s result, which the snapshot of the `rebuild`\'s dynamic is taken from")}, std::tuple{prism_rtl::cat(result_pd, "_snap"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutSnapshot{prism_rtl::rc(dyn_ty_pc)}), prism_rtl::cat("the `rebuild` at place ", crate::lower::model::place_text_f(pos_p7), "\'s dynamic, structural: its snapshots, the generations\' results and the lagged dynamic (pick ST)")}}));
            this_.moves_p = crate::prelude::push(this_.moves_p, std::tuple{live_pe, crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("RefCell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XNone{})})})});
            this_.inits_p = crate::prelude::push(this_.inits_p, std::tuple{prism_rtl::cat(result_pd, "_snap"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Snapshot::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{what_pf})})})});
            this_.getters_p = crate::prelude::append(this_.getters_p, Array(std::vector{crate::lower::model::MethDef{.name_p = prism_rtl::cat(result_pd, "_now"), .recv_p = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params_p = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_p = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret_p = dyn_ty_pc, .body_p = Array<crate::lower::model::Do>{}, .tail_p = current_pl, .doc_p = Text::lit("The current generation\'s result: what the snapshot of the `rebuild`\'s dynamic is taken from (pick ST).")}, crate::lower::node_::static_::snap_getter_f(result_pd, dyn_ty_pc, Text::lit("The `rebuild`\'s dynamic, its generation\'s result, a structural dynamic (pick ST): one tick behind the generations, the snapshot of the tick before the tick the read point is after."))}));
            this_.snaps_p = crate::prelude::push(this_.snaps_p, crate::lower::node_::SnapDef{.name_p = result_pd, .live_p = prism_rtl::cat(result_pd, "_now"), .ty_p = dyn_ty_pc, .eq_p = false, .builder_p = name_p6, .before_p = false, .what_p = what_pf});
            (std::move(this_));
        });
        return std::tuple{wx2_pm, crate::lower::node_::Wres(crate::lower::node_::Wres::WrDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), result_pd, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{result_pd})}), dyn_ty_pc})};
    }
    prism_rtl::unreachable("no arm matched");
}


/// ClauseWidgetLine: unbounded fn Wx, Env, Expr, Block, Text, ValInfo, Expr -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> clause_widget_line_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const crate::syntax::Expr& scrut_p2, const crate::syntax::Block& call_p3, const Text& qk_p4, const crate::check::env::ValInfo& v_p5, const crate::syntax::Expr& e_p6) {
    auto lx_p7 = wx_p0.lx_p;
    auto pos_p8 = wx_p0.pos_p;
    auto [src_ex_pe, reads_pf] = crate::lower::node_::dynamics::dynamic_expr_f(wx_p0, menv_p1, scrut_p2);
    auto vt_p9 = crate::lower::types::out_ty_of_f(lx_p7, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p7, scrut_p2.span_p)));
    auto [name_pg, wx1_ph] = crate::lower::node_::fresh_name_f(wx_p0, Text::lit("generation"));
    auto [up_id_pi, wx2_pj] = crate::lower::node_::add_gn_f(wx1_ph, prism_rtl::cat(name_pg, "_fired"), crate::lower::types::out_ty_of_f(lx_p7, crate::lower::types::out_of_f(crate::lower::type_at_f(lx_p7, e_p6.span_p))), crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnNamed{}), Nat(0u));
    auto clauses_pa = crate::lower::jobs::clauses_of_f(prism_rtl::deref(lx_p7).g_p, qk_p4);
    auto row_name_pb = prism_rtl::cat(wx_p0.node_p, "Gen", crate::lower::node_::keyed::row_suffix_f(wx_p0));
    auto [rows_pp, wx3_pq] = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(clauses_pa)), std::tuple{Array<ClauseRow>{}, wx2_pj}, ({
        auto clauses_pax = clauses_pa;
        auto menv_p1x = menv_p1;
        auto v_p5x = v_p5;
        auto row_name_pbx = row_name_pb;
        auto name_pgx = name_pg;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<ClauseRow>, crate::lower::node_::Wx>>(std::tuple<std::tuple<Array<ClauseRow>, crate::lower::node_::Wx>, Nat>)>>(prism_rtl::rc([=, clauses_pax = std::move(clauses_pax), menv_p1x = std::move(menv_p1x), v_p5x = std::move(v_p5x), row_name_pbx = std::move(row_name_pbx), name_pgx = std::move(name_pgx)](std::tuple<std::tuple<Array<ClauseRow>, crate::lower::node_::Wx>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto clauses_paxy = clauses_pax;
            auto menv_p1xy = menv_p1x;
            auto v_p5xy = v_p5x;
            auto row_name_pbxy = row_name_pbx;
            auto name_pgxy = name_pgx;
            (crate::prelude::entered(crate::prelude::once_job([=, clauses_paxy = std::move(clauses_paxy), menv_p1xy = std::move(menv_p1xy), v_p5xy = std::move(v_p5xy), row_name_pbxy = std::move(row_name_pbxy), name_pgxy = std::move(name_pgxy)]() {
            return ({
                auto [acc_pk, w_pl] = p0;
                auto i_pm = p1;
                ({
                auto c_pn = crate::prelude::or_(crate::prelude::index(clauses_paxy, i_pm), crate::lower::functions::dummy_clause_p());
                auto cr_po = clause_row_of_f(w_pl, menv_p1xy, c_pn, v_p5xy, prism_rtl::cat(row_name_pbxy, i_pm), name_pgxy, true);
                (prism_rtl::finished(std::tuple{crate::prelude::push(acc_pk, cr_po), prism_rtl::deref(cr_po).parent_p}));
            });
            });
        })));
        });
    }));
    })));
    auto width_pc = crate::prelude::fold(rows_pp, Nat(0u), [&](const Nat& acc_pr, const ClauseRow& cr_ps) { return crate::prelude::max(acc_pr, prism_rtl::deref(cr_ps).width_p); });
    auto cases_pd = crate::prelude::each(rows_pp, [&](const ClauseRow& cr_pt) { return prism_rtl::deref(cr_pt).case_p; });
    return is_hosted_scope_f(wx_p0)
        ? ({
        auto wx4_pu = ({
            crate::lower::node_::Wx this_ = wx3_pq;
            this_.build_p = crate::prelude::push(this_.build_p, crate::lower::expr::refusal_do_f(Text::lit("a widget of several clauses in a static position of a hosted scope")));
            (std::move(this_));
        });
        std::tuple{wx4_pu, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
    })
        : ({
        auto select_pv = gen_select_f(wx3_pq, menv_p1, call_p3, cases_pd, pos_p8);
        auto wx4_p10 = ({
            crate::lower::node_::Wx this_ = wx3_pq;
            this_.pos_p = crate::lower::model::Pos_{.scope_p = prism_rtl::deref(pos_p8).scope_p, .at_p = prism_rtl::deref(pos_p8).at_p + width_pc};
            this_.gens_p = crate::prelude::push(this_.gens_p, crate::lower::model::GenDef{.name_p = name_pg, .pos_p = pos_p8, .at_p = crate::lower::node_::finish::place_at_f(wx_p0, Text::lit("self"), pos_p8), .source_p = src_ex_pe, .value_ty_p = vt_p9, .select_p = select_pv, .transparent_p = true, .width_p = width_pc, .moved_p = crate::prelude::or_(crate::lower::node_::finish::hosted_rows_o(wx_p0), Text::lit(""))});
            this_.gen_holds_p = crate::prelude::push(this_.gen_holds_p, std::tuple{name_pg, reads_pf});
            this_.rows_p = crate::prelude::fold(cases_pd, this_.rows_p, [&](const Array<crate::lower::model::NodeDef>& acc_p11, const GenCase& gc_p12) { return crate::prelude::append(crate::prelude::push(acc_p11, prism_rtl::deref(gc_p12).node_p), prism_rtl::deref(prism_rtl::deref(gc_p12).node_p).children_p); });
            this_.getters_p = crate::prelude::push(this_.getters_p, gen_up_f(name_pg, prism_rtl::deref(crate::lower::node_::gn_of_f(wx3_pq, up_id_pi)).name_p, prism_rtl::deref(crate::lower::node_::gn_of_f(wx3_pq, up_id_pi)).ty_p));
            (std::move(this_));
        });
        std::tuple{wx4_p10, crate::lower::node_::Wres(crate::lower::node_::Wres::WrEv{crate::lower::node_::ev_ref_of_f(wx4_p10, up_id_pi)})};
    });
}


/// IsHostedScope: fn Wx -> Bool
bool is_hosted_scope_f(const crate::lower::node_::Wx& wx_p0) {
    return (prism_rtl::deref(wx_p0.pos_p).scope_p > Nat(0u)) || is_some_f(wx_p0.hosted_by_o);
}


/// GenCases: unbounded fn Wx, Env, Block, OutTy, Text -> (([GenCase], Wx))
std::tuple<Array<GenCase>, crate::lower::node_::Wx> gen_cases_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const crate::syntax::Block& body_p2, const crate::lower::model::OutTy& vt_p3, const Text& name_p4) {
    auto lx_p5 = wx_p0.lx_p;
    auto row_name_p6 = prism_rtl::cat(wx_p0.node_p, "Gen", crate::lower::node_::keyed::row_suffix_f(wx_p0));
    auto&& _m = clause_call_o(lx_p5, body_p2);
    if (prism_rtl::is_some(_m)) {
        auto&& qk_p7 = std::get<0>(prism_rtl::some_of(_m));
        auto&& args_p8 = std::get<1>(prism_rtl::some_of(_m));
        auto clauses_p9 = crate::lower::jobs::clauses_of_f(prism_rtl::deref(lx_p5).g_p, qk_p7);
        auto v_pa = crate::lower::program::val_of_f(lx_p5, qk_p7);
        return crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(clauses_p9)), std::tuple{Array<GenCase>{}, wx_p0}, ({
            auto clauses_p9x = clauses_p9;
            auto menv_p1x = menv_p1;
            auto v_pax = v_pa;
            auto row_name_p6x = row_name_p6;
            auto name_p4x = name_p4;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<GenCase>, crate::lower::node_::Wx>>(std::tuple<std::tuple<Array<GenCase>, crate::lower::node_::Wx>, Nat>)>>(prism_rtl::rc([=, clauses_p9x = std::move(clauses_p9x), menv_p1x = std::move(menv_p1x), v_pax = std::move(v_pax), row_name_p6x = std::move(row_name_p6x), name_p4x = std::move(name_p4x)](std::tuple<std::tuple<Array<GenCase>, crate::lower::node_::Wx>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto clauses_p9xy = clauses_p9x;
                auto menv_p1xy = menv_p1x;
                auto v_paxy = v_pax;
                auto row_name_p6xy = row_name_p6x;
                auto name_p4xy = name_p4x;
                (crate::prelude::entered(crate::prelude::once_job([=, clauses_p9xy = std::move(clauses_p9xy), menv_p1xy = std::move(menv_p1xy), v_paxy = std::move(v_paxy), row_name_p6xy = std::move(row_name_p6xy), name_p4xy = std::move(name_p4xy)]() {
                return ({
                    auto [acc_pb, w_pc] = p0;
                    auto i_pd = p1;
                    ({
                    auto c_pe = crate::prelude::or_(crate::prelude::index(clauses_p9xy, i_pd), crate::lower::functions::dummy_clause_p());
                    auto cr_pf = clause_row_of_f(w_pc, menv_p1xy, c_pe, v_paxy, prism_rtl::cat(row_name_p6xy, i_pd), name_p4xy, false);
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc_pb, prism_rtl::deref(cr_pf).case_p), prism_rtl::deref(cr_pf).parent_p}));
                });
                });
            })));
            });
        }));
        })));
    }
    if (prism_rtl::is_none(_m)) {
        auto whole_pg = gen_row_of_f(wx_p0, menv_p1, body_p2, vt_p3, row_name_p6, name_p4);
        return std::tuple{Array(std::vector{GenCase{.node_p = prism_rtl::deref(whole_pg).node_p, .params_p = Array(std::vector{std::tuple{Text::lit("value"), vt_p3}}), .pat_p = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds_p = Array<crate::lower::model::Cc>{}, .passed_p = Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("value")})})}}), prism_rtl::deref(whole_pg).parent_p};
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?ClauseCall: fn Lx, Block -> ?((Text, [Arg]))
std::optional<std::tuple<Text, Array<crate::syntax::Arg>>> clause_call_o(const crate::lower::Lx& lx_p0, const crate::syntax::Block& body_p1) {
    auto&& _m = body_p1.stmts_p;
    {
        auto&& m13740_0 = _m;
        if (m13740_0.size() == 1u) {
            {
                auto&& _c1 = crate::prelude::index(m13740_0, Nat(0u));
                if (prism_rtl::is_some(_c1)) {
                    auto&& st_p2 = prism_rtl::some_of(_c1);
                    auto&& _m = prism_rtl::deref(st_p2).kind_p;
                    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
                        auto&& x_p3 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                        return clause_call_x_o(lx_p0, x_p3);
                    }
                    if (prism_rtl::is<crate::syntax::StmtKind::SIgnore>(_m)) {
                        auto&& x_p4 = prism_rtl::as<crate::syntax::StmtKind::SIgnore>(_m).a0;
                        return clause_call_x_o(lx_p0, x_p4);
                    }
                    {
                        return std::optional<std::tuple<Text, Array<crate::syntax::Arg>>>{};
                    }
                }
            }
        }
    }
    {
        return std::optional<std::tuple<Text, Array<crate::syntax::Arg>>>{};
    }
}


/// ?ClauseCallX: fn Lx, Expr -> ?((Text, [Arg]))
std::optional<std::tuple<Text, Array<crate::syntax::Arg>>> clause_call_x_o(const crate::lower::Lx& lx_p0, const crate::syntax::Expr& x_p1) {
    auto&& _m = prism_rtl::deref(x_p1.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c_p2 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args_p3 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        auto qk_p4 = crate::lower::program::blueprint_qk_f(lx_p0, prism_rtl::deref(prism_rtl::deref(c_p2)));
        return crate::prelude::len(crate::lower::jobs::clauses_of_f(lx_p0.g_p, qk_p4)) > Nat(1u)
            ? std::optional(std::tuple{qk_p4, args_p3})
            : std::optional<std::tuple<Text, Array<crate::syntax::Arg>>>{};
    }
    {
        return std::optional<std::tuple<Text, Array<crate::syntax::Arg>>>{};
    }
}


/// ClauseRowOf: unbounded fn Wx, Env, FnClause, ValInfo, Text, Text, Bool -> ClauseRow
ClauseRow clause_row_of_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const crate::syntax::decls::FnClause& c_p2, const crate::check::env::ValInfo& v_p3, const Text& row_name_p4, const Text& gen_name_p5, const bool& transparent_p6) {
    auto up_name_p7 = prism_rtl::cat(gen_name_p5, "_up");
    auto lx_p8 = wx_p0.lx_p;
    auto lxc_p9 = crate::lower::program::in_module_at_f(lx_p8, v_p3.file_p, v_p3.home_p, prism_rtl::deref(lx_p8).site_p);
    auto ptys_pa = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
        auto&& _m = prism_rtl::deref(v_p3.scheme_p).ty_p;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& ps_pr = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            _v.set(ps_pr);
            goto _done;
        }
        {
            _v.set(Array<crate::check::types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto pos_pb = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(c_p2.params_p)), ({
        auto lxc_p9x = lxc_p9;
        auto c_p2x = c_p2;
        auto ptys_pax = ptys_pa;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::patterns::PatOut>(Nat)>>(prism_rtl::rc([=, lxc_p9x = std::move(lxc_p9x), c_p2x = std::move(c_p2x), ptys_pax = std::move(ptys_pax)](Nat p0) {
        return ({
            auto lxc_p9xy = lxc_p9x;
            auto c_p2xy = c_p2x;
            auto ptys_paxy = ptys_pax;
            (crate::prelude::entered(crate::prelude::once_job([=, lxc_p9xy = std::move(lxc_p9xy), c_p2xy = std::move(c_p2xy), ptys_paxy = std::move(ptys_paxy)]() {
            return ({
                auto i_ps = p0;
                (prism_rtl::more(prism_rtl::rc(crate::lower::patterns::RustPat(lxc_p9xy, crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_p2xy).params_p, i_ps), crate::lower::patterns::dummy_pat_p()), crate::prelude::or_(crate::prelude::index(ptys_paxy, i_ps), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), prism_rtl::cat("c", i_ps)))));
            });
        })));
        });
    })));
    })));
    auto pa_pc = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{crate::prelude::each(pos_pb, [&](const crate::lower::patterns::PatOut& o_pt) { return prism_rtl::deref(o_pt).pa_p; })});
    auto binds_pd = crate::prelude::fold(pos_pb, Map<Text, crate::lower::types::Bn>{}, [&](const Map<Text, crate::lower::types::Bn>& m_pu, const crate::lower::patterns::PatOut& o_pv) {
        return crate::prelude::fold(prism_rtl::deref(o_pv).binds_p, m_pu, [&](const Map<Text, crate::lower::types::Bn>& m2_p10, const std::tuple<Text, crate::lower::types::Bn>& _p1) {
            auto&& n_p11 = std::get<0>(_p1);
            auto&& b_p12 = std::get<1>(_p1);
            return crate::prelude::insert(m2_p10, n_p11, b_p12);
        });
    });
    auto binders_pe = crate::prelude::filter(crate::prelude::run_to_end(crate::prelude::fold_job(c_p2.params_p, Array<std::tuple<Text, crate::syntax::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_p13 = p0;
                auto p_p14 = p1;
                (crate::prelude::call_then(crate::check::env::names::start_pattern_binders_f(p_p14), [=, acc_p13 = std::move(acc_p13)](Array<std::tuple<Text, crate::syntax::Range>> pattern_binders_f_15253) { return prism_rtl::finished(crate::prelude::append(acc_p13, pattern_binders_f_15253)); }));
            });
        }));
    })))), [&](const std::tuple<Text, crate::syntax::Range>& _p0) {
        auto&& bn_p15 = std::get<0>(_p0);
        return crate::check::env::has_key_f(binds_pd, bn_p15);
    });
    auto fields_pf = crate::prelude::run_to_end(crate::prelude::each_job(binders_pe, ({
        auto lxc_p9x = lxc_p9;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::lower::model::OutTy, Text>>(std::tuple<Text, crate::syntax::Range>)>>(prism_rtl::rc([=, lxc_p9x = std::move(lxc_p9x)](std::tuple<Text, crate::syntax::Range> p0) {
        return ({
            auto lxc_p9xy = lxc_p9x;
            (crate::prelude::entered(crate::prelude::once_job([=, lxc_p9xy = std::move(lxc_p9xy)]() {
            return ({
                auto [bn_p16, r_p17] = p0;
                (crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lxc_p9xy, crate::lower::types::peel_f(crate::lower::binder_ty_f(lxc_p9xy, r_p17))), [=](crate::lower::model::OutTy out_ty_of_f_15367) { return prism_rtl::finished(std::tuple{crate::lower::snake_f(bn_p16), out_ty_of_f_15367, bn_p16}); }));
            });
        })));
        });
    }));
    })));
    auto row_fields_pg = crate::prelude::push(crate::prelude::each(fields_pf, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& f_p18 = std::get<0>(_p0);
        auto&& t_p19 = std::get<1>(_p0);
        auto&& bn_p1a = std::get<2>(_p0);
        return std::tuple{f_p18, t_p19, prism_rtl::cat("`", bn_p1a, "`")};
    }), std::tuple{Text::lit("parent"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutWeak{wx_p0.node_p}), Text::lit("the node of the `rebuild`")});
    auto row_inits_ph = crate::prelude::each(fields_pf, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& f_p1b = std::get<0>(_p0);
        return std::tuple{f_p1b, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{f_p1b}))})};
    });
    auto row_taken_pi = crate::prelude::append(crate::lower::node_::node_hooks_p(), crate::prelude::push(crate::prelude::each(fields_pf, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& f_p1c = std::get<0>(_p0);
        return f_p1c;
    }), Text::lit("parent")));
    auto r00_pj = crate::lower::node_::new_wx_f(lxc_p9, row_name_p4, row_fields_pg, row_inits_ph, Array(std::vector{std::tuple{Text::lit("parent"), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("parent")})}}), Array<crate::lower::model::MethDef>{}, Map<Text, Array<crate::lower::node_::Read>>{}, row_taken_pi, wx_p0.inlining_p, crate::lower::node_::finish::hosted_rows_o(wx_p0));
    auto r0_pk = transparent_p6
        ? ({
        crate::lower::node_::Wx this_ = r00_pj;
        this_.pos_p = wx_p0.pos_p;
        (std::move(this_));
    })
        : r00_pj;
    auto body_pl = ({
        __label__ _done;
        prism_rtl::Slot<crate::syntax::Block> _v;
        auto&& _m = c_p2.body_p;
        if (prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(_m)) {
            auto&& b_p1d = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(_m).a0;
            _v.set(b_p1d);
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(_m)) {
            auto&& x_p1e = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(_m).a0;
            _v.set(crate::syntax::Block{.stmts_p = Array(std::vector{crate::syntax::Stmt{.kind_p = crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{x_p1e}), .span_p = prism_rtl::deref(x_p1e).span_p}}), .inline_p = true, .span_p = prism_rtl::deref(x_p1e).span_p});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto [p1_p1f, r1_p1g, ports_p1h] = row_env_f(wx_p0, r0_pk, menv_p1, body_pl);
    auto [be_p1n, me_p1o] = crate::prelude::fold(fields_pf, std::tuple{crate::lower::types::empty_env_p(), crate::lower::types::empty_env_p()}, [&](const std::tuple<crate::lower::types::Env, crate::lower::types::Env>& _p0, const std::tuple<Text, crate::lower::model::OutTy, Text>& _p1) {
        auto&& b_p1i = std::get<0>(_p0);
        auto&& m_p1j = std::get<1>(_p0);
        auto&& f_p1k = std::get<0>(_p1);
        auto&& t_p1l = std::get<1>(_p1);
        auto&& bn_p1m = std::get<2>(_p1);
        return crate::lower::node_::bind_plain_f(b_p1i, m_p1j, bn_p1m, f_p1k, t_p1l);
    });
    auto r2_pm = crate::lower::node_::def::block_into_f(r1_p1g, be_p1n, me_p1o, body_pl);
    auto r3_pn = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::node_::Wx> _v;
        auto&& _m = prism_rtl::deref(r2_pm).result_p;
        if (prism_rtl::is<crate::lower::node_::Wres::WrEv>(_m)) {
            auto&& r_p1p = prism_rtl::as<crate::lower::node_::Wres::WrEv>(_m).a0;
            _v.set(crate::lower::node_::connect_f(r2_pm, r_p1p, crate::lower::node_::Sk(crate::lower::node_::Sk::SkUp{up_name_p7})));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::node_::Wres::WrParts>(_m)) {
            _v.set(({
                crate::lower::node_::Wx this_ = r2_pm;
                this_.build_p = crate::prelude::push(this_.build_p, crate::lower::expr::refusal_do_f(Text::lit("a widget of several clauses whose clause ends on a bundle")));
                (std::move(this_));
            }));
            goto _done;
        }
        {
            _v.set(r2_pm);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto node_po = crate::lower::node_::finish::finish_node_f(r3_pn, row_name_p4, crate::prelude::append(crate::prelude::push(crate::prelude::each(fields_pf, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& f_p1q = std::get<0>(_p0);
        auto&& t_p1r = std::get<1>(_p0);
        return std::tuple{f_p1q, t_p1r};
    }), std::tuple{Text::lit("parent"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutWeak{wx_p0.node_p})}), crate::lower::node_::keyed::hosted_params_f(wx_p0)), true);
    auto p2_pp = gen_marked_f(p1_p1f, gen_name_p5, r3_pn);
    auto passed_pq = crate::prelude::each(fields_pf, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& f_p1s = std::get<0>(_p0);
        auto&& t_p1t = std::get<1>(_p0);
        auto&& bn_p1u = std::get<2>(_p0);
        return ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::Ex> _v;
            auto&& _m = crate::prelude::get(binds_pd, bn_p1u);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs_p1v = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& mode_p20 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                auto&& bt_p21 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(crate::lower::types::own_f(crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{rs_p1v, mode_p20, bt_p21})));
                goto _done;
            }
            {
                _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{f_p1s}))}));
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return ClauseRow{.case_p = GenCase{.node_p = node_po, .params_p = crate::prelude::each(fields_pf, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& f_p22 = std::get<0>(_p0);
        auto&& t_p23 = std::get<1>(_p0);
        return std::tuple{f_p22, t_p23};
    }), .pat_p = pa_pc, .conds_p = crate::prelude::fold(pos_pb, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc_p24, const crate::lower::patterns::PatOut& o_p25) { return crate::prelude::append(acc_p24, prism_rtl::deref(o_p25).conds_p); }), .passed_p = passed_pq}, .parent_p = p2_pp, .width_p = crate::prelude::or_(prism_rtl::deref(prism_rtl::deref(r2_pm).pos_p).at_p.checked_sub(prism_rtl::deref(prism_rtl::deref(r0_pk).pos_p).at_p), Nat(0u))};
}


/// GenRowOf: unbounded fn Wx, Env, Block, OutTy, Text, Text -> GenRow
GenRow gen_row_of_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const crate::syntax::Block& body_p2, const crate::lower::model::OutTy& vt_p3, const Text& row_name_p4, const Text& gen_name_p5) {
    auto lx_p6 = wx_p0.lx_p;
    auto up_name_p7 = prism_rtl::cat(gen_name_p5, "_up");
    auto r0_p8 = crate::lower::node_::new_wx_f(lx_p6, row_name_p4, Array(std::vector{std::tuple{Text::lit("value"), vt_p3, Text::lit("the generation\'s value, `_`")}, std::tuple{Text::lit("parent"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutWeak{wx_p0.node_p}), Text::lit("the node of the `rebuild`")}}), Array(std::vector{std::tuple{Text::lit("value"), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("value")}))})}}), Array(std::vector{std::tuple{Text::lit("parent"), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("parent")})}}), Array<crate::lower::model::MethDef>{}, Map<Text, Array<crate::lower::node_::Read>>{}, crate::prelude::append(crate::lower::node_::node_hooks_p(), Array(std::vector{Text::lit("value"), Text::lit("parent"), Text::lit("result"), Text::lit("result_dynamic")})), wx_p0.inlining_p, crate::lower::node_::finish::hosted_rows_o(wx_p0));
    auto [p1_pc, r1_pd, ports_pe] = row_env_f(wx_p0, r0_p8, menv_p1, body_p2);
    auto be_p9 = crate::lower::types::bind_f(build_spelling_f(ports_pe), Text::lit("_"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("value")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), vt_p3}));
    auto me_pa = crate::lower::types::bind_f(ports_pe, Text::lit("_"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("value")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), vt_p3}));
    auto r2_pb = crate::lower::node_::def::block_into_f(r1_pd, be_p9, me_pa, body_p2);
    auto [r3_pk, dyn_result_ol] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::lower::node_::Wx, std::optional<crate::lower::model::OutTy>>> _v;
        auto&& _m = prism_rtl::deref(r2_pb).result_p;
        if (prism_rtl::is<crate::lower::node_::Wres::WrEv>(_m)) {
            auto&& r_pf = prism_rtl::as<crate::lower::node_::Wres::WrEv>(_m).a0;
            _v.set(std::tuple{crate::lower::node_::connect_f(r2_pb, r_pf, crate::lower::node_::Sk(crate::lower::node_::Sk::SkUp{up_name_p7})), std::optional<crate::lower::model::OutTy>{}});
            goto _done;
        }
        if (prism_rtl::is<crate::lower::node_::Wres::WrDyn>(_m)) {
            auto&& ex_pg = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(_m).a0;
            auto&& result_reads_ph = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(_m).a1;
            auto&& rt_pi = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(_m).a2;
            _v.set(std::tuple{gen_result_f(r2_pb, gen_name_p5, ex_pg, result_reads_ph, rt_pi), std::optional(rt_pi)});
            goto _done;
        }
        if (prism_rtl::is<crate::lower::node_::Wres::WrParts>(_m)) {
            _v.set(({
                auto r2b_pj = ({
                    crate::lower::node_::Wx this_ = r2_pb;
                    this_.build_p = crate::prelude::push(this_.build_p, crate::lower::expr::refusal_do_f(Text::lit("a `rebuild` whose block ends on a bundle")));
                    (std::move(this_));
                });
                std::tuple{r2b_pj, std::optional<crate::lower::model::OutTy>{}};
            }));
            goto _done;
        }
        {
            _v.set(std::tuple{r2_pb, std::optional<crate::lower::model::OutTy>{}});
            goto _done;
        }
    _done:
        _v.take();
    });
    return GenRow{.node_p = crate::lower::node_::finish::finish_node_f(r3_pk, row_name_p4, crate::prelude::append(Array(std::vector{std::tuple{Text::lit("value"), vt_p3}, std::tuple{Text::lit("parent"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutWeak{wx_p0.node_p})}}), crate::lower::node_::keyed::hosted_params_f(wx_p0)), true), .parent_p = gen_marked_f(p1_pc, gen_name_p5, r3_pk), .dyn_result_o = dyn_result_ol};
}


/// GenResult: fn Wx, Text, Ex, [Read], OutTy -> Wx
crate::lower::node_::Wx gen_result_f(const crate::lower::node_::Wx& r_p0, const Text& gen_name_p1, const crate::lower::model::Ex& ex_p2, const Array<crate::lower::node_::Read>& result_reads_p3, const crate::lower::model::OutTy& rt_p4) {
    auto own_behind_p5 = crate::prelude::filter(crate::lower::node_::finish::reads_closed_f(r_p0.dyn_reads_p, result_reads_p3), [&](const crate::lower::node_::Read& rd_p8) {
        return ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            if (prism_rtl::is<crate::lower::node_::Read::OwnRead>(rd_p8)) {
                _v.set(true);
                goto _done;
            }
            if (prism_rtl::is<crate::lower::node_::Read::ParentRead>(rd_p8)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    auto made_p6 = crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Dynamic::of"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("cx")})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("me")})), Text::lit("result"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Port::new"), Array<crate::lower::model::Ex>{}})})}))})})});
    auto doc_p7 = prism_rtl::cat("The generation\'s result as a dynamic, which the block keeps while the generation is current; the block hears it move through `", gen_name_p1, "_result_moved`, not through the dynamic\'s port.");
    crate::lower::node_::Wx this_ = r_p0;
    this_.getters_p = crate::prelude::append(this_.getters_p, Array(std::vector{crate::lower::model::MethDef{.name_p = Text::lit("result"), .recv_p = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params_p = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_p = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret_p = rt_p4, .body_p = Array<crate::lower::model::Do>{}, .tail_p = ex_p2, .doc_p = Text::lit("The generation\'s result, which the `rebuild` hands back.")}, crate::lower::model::MethDef{.name_p = Text::lit("result_dynamic"), .recv_p = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params_p = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_p = crate::lower::model::CxArg(crate::lower::model::CxArg::CxNone{}), .ret_p = crate::lower::model::OutTy(crate::lower::model::OutTy::OutDyn{prism_rtl::rc(rt_p4)}), .body_p = Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("me")}), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})})}), .tail_p = made_p6, .doc_p = doc_p7}}));
    this_.result_moved_o = crate::prelude::len(own_behind_p5) > Nat(0u)
        ? std::optional(std::tuple{prism_rtl::cat(gen_name_p1, "_result_moved"), own_behind_p5})
        : std::optional<std::tuple<Text, Array<crate::lower::node_::Read>>>{};
    return this_;
}


/// GenMarked: fn Wx, Text, Wx -> Wx
crate::lower::node_::Wx gen_marked_f(const crate::lower::node_::Wx& parent_p0, const Text& gen_name_p1, const crate::lower::node_::Wx& row_wx_p2) {
    auto reads_p3 = crate::lower::node_::keyed::row_place_reads_f(row_wx_p2);
    return crate::prelude::len(reads_p3) == Nat(0u)
        ? parent_p0
        : ({
        crate::lower::node_::Wx this_ = parent_p0;
        this_.row_marks_p = crate::prelude::push(this_.row_marks_p, crate::lower::node_::RowMarks{.builder_p = gen_name_p1, .reads_p = reads_p3, .wrote_p = Array<Text>{}, .kind_p = crate::lower::model::RowKind(crate::lower::model::RowKind::GenerationRow{})});
        (std::move(this_));
    });
}


/// BuildSpelling: fn Env -> Env
crate::lower::types::Env build_spelling_f(const crate::lower::types::Env& env_p0) {
    return crate::prelude::fold(crate::prelude::keys(env_p0.names_p), env_p0, [&](const crate::lower::types::Env& en_p1, const Text& k_p2) {
        return ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::types::Env> _v;
            auto&& _m = crate::prelude::get(env_p0.names_p, k_p2);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs_p3 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& mode_p4 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                auto&& t_p5 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<crate::lower::types::Env> _v;
                    auto&& _m = crate::lower::types::through_parent_o(rs_p3);
                    if (prism_rtl::is_some(_m)) {
                        auto&& x_p6 = prism_rtl::some_of(_m);
                        _v.set(crate::lower::types::bind_f(en_p1, k_p2, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{x_p6, mode_p4, t_p5})));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(en_p1);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)) && prism_rtl::is<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0)) {
                auto&& rs_p7 = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a0;
                auto&& m_p8 = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a1;
                auto&& xs_p9 = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a2;
                auto&& ds_pa = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a1;
                auto&& t_pb = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a2;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<crate::lower::types::Env> _v;
                    auto&& _m = crate::lower::types::through_parent_o(prism_rtl::deref(rs_p7));
                    if (prism_rtl::is_some(_m)) {
                        auto&& x_pc = prism_rtl::some_of(_m);
                        _v.set(crate::lower::types::bind_f(en_p1, k_p2, crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(x_pc), m_p8, xs_p9}), ds_pa, t_pb})));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(en_p1);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(en_p1);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// GenSelect: unbounded fn Wx, Env, Block, [GenCase], Pos -> Ex
crate::lower::model::Ex gen_select_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const crate::syntax::Block& body_p2, const Array<GenCase>& cases_p3, const crate::lower::model::Pos_& pos_p4) {
    auto tail_p5 = crate::prelude::append(crate::prelude::append(Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XWeak{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})}), crate::lower::node_::keyed::hosted_passed_f(wx_p0)), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})}));
    auto&& _m = clause_call_o(wx_p0.lx_p, body_p2);
    if (prism_rtl::is_none(_m)) {
        auto&& _m = crate::prelude::index(cases_p3, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& c_p6 = prism_rtl::some_of(_m);
            return crate::lower::expr::try_of_f(crate::lower::model::Ex(crate::lower::model::Ex::XCall{prism_rtl::cat(prism_rtl::deref(prism_rtl::deref(c_p6).node_p).name_p, "::build"), crate::prelude::append(Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("path")}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("value")})}), tail_p5)}));
        }
        if (prism_rtl::is_none(_m)) {
            return crate::lower::expr::refusal_f(Text::lit("a `rebuild` with no generation"));
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_some(_m)) {
        auto&& qk_p7 = std::get<0>(prism_rtl::some_of(_m));
        auto&& args_p8 = std::get<1>(prism_rtl::some_of(_m));
        auto env_p9 = crate::lower::types::bind_f(menv_p1, Text::lit("_"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("value")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}));
        auto scrut_pa = crate::lower::model::Ex(crate::lower::model::Ex::XTuple{crate::prelude::run_to_end(crate::prelude::each_job(args_p8, ({
            auto wx_p0x = wx_p0;
            auto env_p9x = env_p9;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=, wx_p0x = std::move(wx_p0x), env_p9x = std::move(env_p9x)](crate::syntax::Arg p0) {
            return ({
                auto wx_p0xy = wx_p0x;
                auto env_p9xy = env_p9x;
                (crate::prelude::entered(crate::prelude::once_job([=, wx_p0xy = std::move(wx_p0xy), env_p9xy = std::move(env_p9xy)]() {
                return ({
                    auto a_pc = p0;
                    (prism_rtl::more(prism_rtl::rc(crate::lower::expr::Argument(prism_rtl::deref(wx_p0xy).lx_p, env_p9xy, prism_rtl::deref(a_pc).value_p))));
                });
            })));
            });
        })));
        })))});
        auto arms_pb = crate::prelude::each(cases_p3, [&](const GenCase& c_pd) {
            return ({
                auto made_pe = crate::lower::expr::try_of_f(crate::lower::model::Ex(crate::lower::model::Ex::XCall{prism_rtl::cat(prism_rtl::deref(prism_rtl::deref(c_pd).node_p).name_p, "::build"), crate::prelude::append(crate::prelude::append(Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("path")}))})}), prism_rtl::deref(c_pd).passed_p), tail_p5)}));
                crate::lower::model::XArm{.pat_p = prism_rtl::deref(c_pd).pat_p, .conds_p = prism_rtl::deref(c_pd).conds_p, .body_p = crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(made_pe), crate::lower::model::OutTy(crate::lower::model::OutTy::OutObj{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Row"), Array<crate::lower::model::OutTy>{}}))})})};
            });
        });
        return crate::lower::types::own_f(crate::lower::expr::arms_value_f(scrut_pa, arms_pb, Text::lit("\'select"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutObj{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Row"), Array<crate::lower::model::OutTy>{}}))})));
    }
    prism_rtl::unreachable("no arm matched");
}


/// GenUp: fn Text, Text, OutTy -> MethDef
crate::lower::model::MethDef gen_up_f(const Text& name_p0, const Text& up_name_p1, const crate::lower::model::OutTy& t_p2) {
    return crate::lower::model::MethDef{.name_p = prism_rtl::cat(name_p0, "_up"), .recv_p = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params_p = Array(std::vector{std::tuple{Text::lit("v"), t_p2}}), .cx_p = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret_p = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body_p = Array(std::vector{crate::lower::node_::finish::self_call_f(up_name_p1, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")})}))}), .tail_p = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc_p = Text::lit("The current generation\'s result fires the `rebuild`\'s.")};
}


/// GenForwards: fn GenDef -> [((Pa, Ex))]
Array<std::tuple<crate::lower::model::Pa, crate::lower::model::Ex>> gen_forwards_f(const crate::lower::model::GenDef& gd_p0) {
    return gd_p0.transparent_p
        ? crate::prelude::each(crate::check::errors::range0_f(gd_p0.width_p), [&](const Nat& i_p1) {
        return ({
            auto current_p2 = crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(gd_p0.name_p)})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}}))});
            auto body_p3 = crate::lower::model::Ex(crate::lower::model::Ex::XBlock{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")}), current_p2}), crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::expr::try_of_f(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")})), Text::lit("answer"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("at")}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))})}), Array<crate::lower::model::Do>{}})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}))});
            std::tuple{crate::lower::node_::finish::pos_pat_f(crate::lower::model::Pos_{.scope_p = prism_rtl::deref(gd_p0.pos_p).scope_p, .at_p = prism_rtl::deref(gd_p0.pos_p).at_p + i_p1}, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaRest{Text::lit("")})})), body_p3};
        });
    })
        : Array(std::vector{std::tuple{crate::lower::node_::finish::pos_pat_f(gd_p0.pos_p, crate::lower::node_::finish::gen_tail_p()), forward_gen_f(gd_p0)}});
}


/// ForwardGen: fn GenDef -> Ex
crate::lower::model::Ex forward_gen_f(const crate::lower::model::GenDef& gd_p0) {
    auto current_p1 = crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(gd_p0.name_p)})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}}))});
    auto is_current_p2 = crate::lower::model::Ex(crate::lower::model::Ex::XBin{crate::lower::model::BinOp(crate::lower::model::BinOp::OpEq{}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XBin{crate::lower::model::BinOp(crate::lower::model::BinOp::OpAdd{}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("g")}))})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XIndex{Nat(1u)}))})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(gd_p0.name_p, "_count")})), Text::lit("get"), Array<crate::lower::model::Ex>{}}))});
    return crate::lower::model::Ex(crate::lower::model::Ex::XBlock{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")}), current_p1}), crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIf{is_current_p2, Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::expr::try_of_f(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")})), Text::lit("answer"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("rest")}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))})}), Array<crate::lower::model::Do>{}})}), Array<crate::lower::model::Do>{}})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}))});
}


/// FlattenLine: unbounded fn Wx, Env, [Arg], ?Bn -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> flatten_line_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const Array<crate::syntax::Arg>& args_p2, const std::optional<crate::lower::types::Bn>& bound_o3) {
    auto named_o4 = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<std::tuple<Text, crate::lower::model::OutTy>>> _v;
        auto&& _m = crate::prelude::index(args_p2, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& a_p6 = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::optional<std::tuple<Text, crate::lower::model::OutTy>>> _v;
                auto&& _m = prism_rtl::deref(prism_rtl::deref(prism_rtl::deref(a_p6).value_p).kind_p);
                if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                    auto&& n_p7 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::optional<std::tuple<Text, crate::lower::model::OutTy>>> _v;
                        auto&& _m = crate::prelude::get(menv_p1.names_p, crate::check::env::sname_key_f(n_p7));
                        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)) && prism_rtl::is<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0) && prism_rtl::is<crate::lower::model::OutTy::OutDyn>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a2)) {
                            auto&& m24386_0_0_0 = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a0;
                            auto&& m_p8 = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a1;
                            auto&& t_p9 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a2).a0;
                            if (prism_rtl::is<crate::lower::model::Ex::XSelf>(prism_rtl::deref(prism_rtl::deref(m24386_0_0_0)))) {
                                _v.set(std::optional(std::tuple{m_p8, prism_rtl::deref(prism_rtl::deref(t_p9))}));
                                goto _done;
                            }
                        }
                        {
                            _v.set(std::optional<std::tuple<Text, crate::lower::model::OutTy>>{});
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                {
                    _v.set(std::optional<std::tuple<Text, crate::lower::model::OutTy>>{});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::optional<std::tuple<Text, crate::lower::model::OutTy>>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto outer_o5 = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<std::tuple<Text, Text, crate::lower::model::OutTy>>> _v;
        if (prism_rtl::is_some(named_o4)) {
            auto&& m_pa = std::get<0>(prism_rtl::some_of(named_o4));
            auto&& t_pb = std::get<1>(prism_rtl::some_of(named_o4));
            _v.set(crate::prelude::fold(wx_p0.gens_p, std::optional<std::tuple<Text, Text, crate::lower::model::OutTy>>{}, [&](const std::optional<std::tuple<Text, Text, crate::lower::model::OutTy>>& acc_oc, const crate::lower::model::GenDef& gd_pd) {
                return prism_rtl::cat(prism_rtl::deref(gd_pd).name_p, "_result") == m_pa
                    ? std::optional(std::tuple{m_pa, prism_rtl::deref(gd_pd).name_p, t_pb})
                    : acc_oc;
            }));
            goto _done;
        }
        if (prism_rtl::is_none(named_o4)) {
            _v.set(std::optional<std::tuple<Text, Text, crate::lower::model::OutTy>>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    if (prism_rtl::is_none(outer_o5)) {
        auto wx2_pe = ({
            crate::lower::node_::Wx this_ = wx_p0;
            this_.build_p = crate::prelude::push(this_.build_p, crate::lower::expr::refusal_do_f(Text::lit("`@Flatten` of a dynamic that is not a `rebuild`\'s (a `for` over a map of dynamics binds the value under the key, `for k, $v <- $each:`, ruling FV)")));
            (std::move(this_));
        });
        return std::tuple{wx2_pe, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
    }
    if (prism_rtl::is_some(outer_o5)) {
        auto&& m_pf = std::get<0>(prism_rtl::some_of(outer_o5));
        auto&& gen_pg = std::get<1>(prism_rtl::some_of(outer_o5));
        auto&& t_ph = std::get<2>(prism_rtl::some_of(outer_o5));
        auto [name_po, wx1_pp] = ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Text, crate::lower::node_::Wx>> _v;
            if (prism_rtl::is_some(bound_o3) && prism_rtl::is<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(bound_o3))) {
                auto&& f_pm = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(bound_o3)).a0;
                _v.set(std::tuple{f_pm, wx_p0});
                goto _done;
            }
            if (prism_rtl::is_some(bound_o3) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_o3)) && prism_rtl::is<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_o3)).a0)) {
                auto&& m25089_1_0_0 = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_o3)).a0).a0;
                auto&& f_pn = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_o3)).a0).a1;
                if (prism_rtl::is<crate::lower::model::Ex::XSelf>(prism_rtl::deref(prism_rtl::deref(m25089_1_0_0)))) {
                    _v.set(std::tuple{f_pn, wx_p0});
                    goto _done;
                }
            }
            {
                _v.set(crate::lower::node_::fresh_name_f(wx_p0, Text::lit("flatten")));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto inner_pi = prism_rtl::cat(name_po, "_inner");
        auto first_pj = crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), prism_rtl::cat(inner_pi)})), Text::lit("set"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), m_pf, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
        auto sample_pk = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(inner_pi)})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})), Text::lit("expect"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{Text::lit("`@Flatten` adopts its first inner at the build")})})})), Text::lit("sample"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})});
        auto wx2_pl = ({
            crate::lower::node_::Wx this_ = wx1_pp;
            this_.taken_p = crate::prelude::append(this_.taken_p, Array(std::vector{inner_pi, prism_rtl::cat(name_po, "_adopt")}));
            this_.fields_p = crate::prelude::push(this_.fields_p, std::tuple{inner_pi, crate::lower::model::OutTy(crate::lower::model::OutTy::OutHold{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutDyn{prism_rtl::rc(t_ph)}))}))}), Text::lit("`@Flatten`\'s current inner: the dynamic of the generation it adopted")});
            this_.moves_p = crate::prelude::push(this_.moves_p, std::tuple{inner_pi, crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Hold::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XNone{}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
            this_.build_p = crate::prelude::push(this_.build_p, first_pj);
            this_.getters_p = crate::prelude::push(this_.getters_p, crate::lower::model::MethDef{.name_p = name_po, .recv_p = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params_p = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_p = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret_p = t_ph, .body_p = Array<crate::lower::model::Do>{}, .tail_p = sample_pk, .doc_p = Text::lit("`@Flatten`\'s dynamic: its current inner at the read point.")});
            this_.dyn_reads_p = crate::prelude::insert(this_.dyn_reads_p, name_po, Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{inner_pi})}));
            this_.flattens_p = crate::prelude::push(this_.flattens_p, crate::lower::node_::FlatDef{.name_p = name_po, .outer_p = m_pf, .generation_p = gen_pg, .ty_p = t_ph});
            (std::move(this_));
        });
        return std::tuple{wx2_pl, crate::lower::node_::Wres(crate::lower::node_::Wres::WrDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), name_po, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{inner_pi})}), t_ph})};
    }
    prism_rtl::unreachable("no arm matched");
}


/// EntryFlatten: unbounded fn Wx, OutTy, ?Bn -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> entry_flatten_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::model::OutTy& t_p1, const std::optional<crate::lower::types::Bn>& bound_o2) {
    auto [name_pa, wx1_pb] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Text, crate::lower::node_::Wx>> _v;
        if (prism_rtl::is_some(bound_o2) && prism_rtl::is<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(bound_o2))) {
            auto&& f_p8 = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(bound_o2)).a0;
            _v.set(std::tuple{f_p8, wx_p0});
            goto _done;
        }
        if (prism_rtl::is_some(bound_o2) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_o2)) && prism_rtl::is<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_o2)).a0)) {
            auto&& m27626_1_0_0 = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_o2)).a0).a0;
            auto&& f_p9 = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_o2)).a0).a1;
            if (prism_rtl::is<crate::lower::model::Ex::XSelf>(prism_rtl::deref(prism_rtl::deref(m27626_1_0_0)))) {
                _v.set(std::tuple{f_p9, wx_p0});
                goto _done;
            }
        }
        {
            _v.set(crate::lower::node_::fresh_name_f(wx_p0, Text::lit("flatten")));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto inner_p3 = prism_rtl::cat(name_pa, "_inner");
    auto follow_p4 = prism_rtl::cat(name_pa, "_follow");
    auto followed_p5 = crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), follow_p4})), Text::lit("follow"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), Text::lit("entry"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})), Text::lit("updates")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XPath{prism_rtl::cat(wx_p0.node_p, "::", name_pa, "_moved")})})})});
    auto sample_p6 = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(inner_p3)})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})), Text::lit("expect"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{Text::lit("`@Flatten` adopts its first inner at the build")})})})), Text::lit("sample"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})});
    auto wx2_p7 = ({
        crate::lower::node_::Wx this_ = wx1_pb;
        this_.taken_p = crate::prelude::append(this_.taken_p, Array(std::vector{inner_p3, follow_p4, prism_rtl::cat(name_pa, "_adopt"), prism_rtl::cat(name_pa, "_moved"), prism_rtl::cat(name_pa, "_replaced")}));
        this_.fields_p = crate::prelude::append(this_.fields_p, Array(std::vector{std::tuple{inner_p3, crate::lower::model::OutTy(crate::lower::model::OutTy::OutHold{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutDyn{prism_rtl::rc(t_p1)}))}))}), Text::lit("`@Flatten`\'s current inner: the row\'s entry it adopted")}, std::tuple{follow_p4, crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("prism_rtl::Follow"), Array<crate::lower::model::OutTy>{}}), Text::lit("the subscription to the inner\'s update event")}}));
        this_.moves_p = crate::prelude::append(this_.moves_p, Array(std::vector{std::tuple{inner_p3, crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Hold::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("value")}))})})}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})}, std::tuple{follow_p4, crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::Follow::new"), Array<crate::lower::model::Ex>{}})}}));
        this_.build_p = crate::prelude::push(this_.build_p, followed_p5);
        this_.getters_p = crate::prelude::push(this_.getters_p, crate::lower::model::MethDef{.name_p = name_pa, .recv_p = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params_p = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_p = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret_p = t_p1, .body_p = Array<crate::lower::model::Do>{}, .tail_p = sample_p6, .doc_p = Text::lit("`@Flatten`\'s dynamic: its current inner at the read point.")});
        this_.dyn_reads_p = crate::prelude::insert(this_.dyn_reads_p, name_pa, Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{inner_p3})}));
        this_.flattens_p = crate::prelude::push(this_.flattens_p, crate::lower::node_::FlatDef{.name_p = name_pa, .outer_p = Text::lit("entry"), .generation_p = Text::lit(""), .ty_p = t_p1});
        (std::move(this_));
    });
    return std::tuple{wx2_p7, crate::lower::node_::Wres(crate::lower::node_::Wres::WrDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), name_pa, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{inner_p3})}), t_p1})};
}


/// SwitchLine: unbounded fn Wx, Env, [Arg] -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> switch_line_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const Array<crate::syntax::Arg>& args_p2) {
    auto&& _m = crate::prelude::index(args_p2, Nat(0u));
    if (prism_rtl::is_some(_m)) {
        auto&& a_p3 = prism_rtl::some_of(_m);
        auto [r_p4, wx2_p5] = crate::lower::node_::dynamics::event_ref_f(wx_p0, menv_p1, prism_rtl::deref(a_p3).value_p);
        return std::tuple{wx2_p5, crate::lower::node_::Wres(crate::lower::node_::Wres::WrEv{r_p4})};
    }
    if (prism_rtl::is_none(_m)) {
        return std::tuple{wx_p0, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
    }
    prism_rtl::unreachable("no arm matched");
}

}  // namespace crate::lower::node_::switch_
