// The module `Lower.Program`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <lower/program/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Lower.Program`, from `target/bootstrap/cpp-src/prismc/lower/program.prism`.
namespace crate::lower::program {

/// InModule: fn Lx, Nat, Text -> Lx
crate::lower::Lx in_module(const crate::lower::Lx& lx_p0, const Nat& file_p1, const Text& home_p2) {
    crate::lower::Lx this_ = lx_p0;
    this_.file = file_p1;
    this_.home = home_p2;
    this_.site = home_p2;
    return this_;
}


/// InModuleAt: fn Lx, Nat, Text, Text -> Lx
crate::lower::Lx in_module_at(const crate::lower::Lx& lx_p0, const Nat& file_p1, const Text& home_p2, const Text& site_p3) {
    crate::lower::Lx this_ = lx_p0;
    this_.file = file_p1;
    this_.home = home_p2;
    this_.site = site_p3;
    return this_;
}


/// LowerProgram: unbounded fn [Src], [Module], Nat, TProgram, Text -> Model
crate::lower::model::Model lower_program(const Array<crate::check::errors::Src>& srcs_p0, const Array<crate::syntax::Module>& trees_p1, const Nat& shown_p2, const crate::check::typed::TProgram& tp_p3, const Text& name_p4) {
    auto&& _g_pt = crate::check::env::build_g(srcs_p0, trees_p1);
    auto&& g_pt = std::get<0>(_g_pt);
    auto [tys_pu, apps_pv, bs_p10, ims_p11] = crate::lower::typed_tables(tp_p3);
    auto gens_p5 = fold(tp_p3.gens, Map<Text, crate::check::typed::GenNote>{}, [&](const Map<Text, crate::check::typed::GenNote>& m_p12, const crate::check::typed::GenNote& n_p13) { return insert(m_p12, crate::check::typed::at_key(prism_rtl::deref(n_p13).at), n_p13); });
    auto insts_p6 = fold(tp_p3.insts, Map<Text, Array<crate::check::typed::InstNote>>{}, [&](const Map<Text, Array<crate::check::typed::InstNote>>& m_p14, const crate::check::typed::InstNote& n_p15) { return insert(m_p14, crate::lower::expr::inst_key(n_p15), crate::prelude::push(or_(crate::prelude::get(m_p14, crate::lower::expr::inst_key(n_p15)), Array<crate::check::typed::InstNote>{}), n_p15)); });
    auto quants_p7 = fold(tp_p3.gens, Map<Text, Text>{}, [&](const Map<Text, Text>& m_p16, const crate::check::typed::GenNote& n_p17) { return fold(append(prism_rtl::deref(n_p17).tys, prism_rtl::deref(n_p17).cols), m_p16, [&](const Map<Text, Text>& m2_p18, const Text& q_p19) { return insert(m2_p18, q_p19, prism_rtl::deref(n_p17).name); }); });
    auto gen_of_q_p8 = fold(tp_p3.gens, Map<Text, crate::check::typed::GenNote>{}, [&](const Map<Text, crate::check::typed::GenNote>& m_p1a, const crate::check::typed::GenNote& n_p1b) { return fold(append(prism_rtl::deref(n_p1b).tys, prism_rtl::deref(n_p1b).cols), m_p1a, [&](const Map<Text, crate::check::typed::GenNote>& m2_p1c, const Text& q_p1d) { return insert(m2_p1c, q_p1d, n_p1b); }); });
    auto use_insts_p9 = fold(tp_p3.insts, Map<Text, crate::check::typed::InstNote>{}, [&](const Map<Text, crate::check::typed::InstNote>& m_p1e, const crate::check::typed::InstNote& n_p1f) { return insert(m_p1e, crate::check::typed::at_key(prism_rtl::deref(n_p1f).at), n_p1f); });
    auto mods_pa = needed_mods(g_pt, shown_p2);
    auto rs_mods_pb = fold(mods_pa, Map<Text, Text>{}, [&](const Map<Text, Text>& acc_p1g, const Text& m_p1h) { return insert(acc_p1g, m_p1h, crate::lower::rust_mod_name(m_p1h)); });
    auto mod_segments_pc = fold(values(rs_mods_pb), Map<Text, bool>{}, [&](const Map<Text, bool>& acc_p1i, const Text& p_p1j) { return fold(split_on(p_p1j, Text::lit("::")), acc_p1i, [&](const Map<Text, bool>& a2_p1k, const Text& seg_p1l) { return insert(a2_p1k, seg_p1l, true); }); });
    auto lx0_pd = crate::lower::Lx{.g = g_pt, .tys = tys_pu, .apps = apps_pv, .lifts = fold(tp_p3.lifts, Map<Text, crate::check::typed::LiftNote>{}, [&](const Map<Text, crate::check::typed::LiftNote>& m_p1m, const crate::check::typed::LiftNote& n_p1n) { return insert(m_p1m, crate::check::typed::at_key(prism_rtl::deref(n_p1n).at), n_p1n); }), .binders = bs_p10, .impls = ims_p11, .file = Nat(0u), .home = Text::lit(""), .site = Text::lit(""), .rs_mods = rs_mods_pb, .mod_segments = mod_segments_pc, .rs_names = crate::lower::value_names(g_pt), .layouts = crate::lower::types::layouts(g_pt), .unbs = Array<Text>{}, .notes = Array<Text>{}, .globals = crate::lower::global_names(g_pt), .in_node = false, .unshrunk = fold(tp_p3.unshrunk, Map<Text, bool>{}, [&](const Map<Text, bool>& m_p1o, const crate::check::typed::SrcAt& a_p1p) { return insert(m_p1o, crate::check::typed::at_key(a_p1p), true); }), .gens = gens_p5, .insts = insts_p6, .quants = quants_p7, .gen_of_q = gen_of_q_p8, .use_insts = use_insts_p9, .local_ids = fold(tp_p3.locals, Map<Text, Nat>{}, [&](const Map<Text, Nat>& m_p1q, const crate::check::typed::LocalNote& n_p1r) { return insert(m_p1q, crate::check::typed::at_key(prism_rtl::deref(n_p1r).at), prism_rtl::deref(n_p1r).id); }), .use_ids = fold(tp_p3.uses, Map<Text, Nat>{}, [&](const Map<Text, Nat>& m_p1s, const crate::check::typed::LocalNote& n_p1t) { return insert(m_p1s, crate::check::typed::at_key(prism_rtl::deref(n_p1t).at), prism_rtl::deref(n_p1t).id); }), .subst = Map<Text, crate::check::types::Ty>{}, .csubst = Map<Text, crate::check::types::Col>{}};
    auto lx_pe = ({
        crate::lower::Lx this_ = lx0_pd;
        this_.unbs = job_roots(lx0_pd);
        (std::move(this_));
    });
    auto roots_pf = root_widgets(lx_pe);
    auto mod_defs_pg = run_to_end(each_job(mods_pa, ({
        auto lx_pe_1 = lx_pe;
        auto roots_pf_2 = roots_pf;
        auto g_pt_3 = g_pt;
        auto mods_pa_4 = mods_pa;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::ModDef>(Text)>>(prism_rtl::rc([=, lx_pe_1 = std::move(lx_pe_1), roots_pf_2 = std::move(roots_pf_2), g_pt_3 = std::move(g_pt_3), mods_pa_4 = std::move(mods_pa_4)](Text p0) {
        return ({
            auto lx_pe_1_5 = lx_pe_1;
            auto roots_pf_2_5 = roots_pf_2;
            auto g_pt_3_5 = g_pt_3;
            auto mods_pa_4_5 = mods_pa_4;
            entered(once_job([=, lx_pe_1_5 = std::move(lx_pe_1_5), roots_pf_2_5 = std::move(roots_pf_2_5), g_pt_3_5 = std::move(g_pt_3_5), mods_pa_4_5 = std::move(mods_pa_4_5)]() {
            return ({
                auto m_p1u = p0;
                (prism_rtl::more(prism_rtl::rc(ModDefOf(lx_pe_1_5, m_p1u, roots_pf_2_5, or_(crate::prelude::get(prism_rtl::deref(g_pt_3_5).mods, m_p1u), crate::check::env::reading::dummy_mod()), mods_pa_4_5))));
            });
        }));
        });
    })));
    })));
    auto programs_ph = run_to_end(each_job(roots_pf, ({
        auto lx_pe_1 = lx_pe;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::ProgDef>(std::tuple<Text, bool>)>>(prism_rtl::rc([=, lx_pe_1 = std::move(lx_pe_1)](std::tuple<Text, bool> p0) {
        return ({
            auto lx_pe_1_2 = lx_pe_1;
            entered(once_job([=, lx_pe_1_2 = std::move(lx_pe_1_2)]() {
            return ({
                auto&& _qk_p1v = p0;
                auto&& qk_p1v = std::get<0>(_qk_p1v);
                (prism_rtl::more(prism_rtl::rc(ProgDefOf(lx_pe_1_2, qk_p1v))));
            });
        }));
        });
    })));
    })));
    auto main_qk_pi = fold(prism_rtl::deref(g_pt).defs, Text::lit(""), [&](const Text& found_p20, const crate::check::env::Def& d_p21) {
        return (found_p20 == Text::lit("")) && is_main(prism_rtl::deref(d_p21).qk)
            ? prism_rtl::deref(d_p21).qk
            : found_p20;
    });
    auto root_oj = main_qk_pi == Text::lit("")
        ? std::optional<crate::lower::model::ProgDef>{}
        : std::optional(prog_def_of(lx_pe, main_qk_pi));
    auto checks_pk = run_to_end(fold_job(prism_rtl::deref(g_pt).defs, Array<crate::lower::model::CheckDef>{}, ({
        auto lx_pe_1 = lx_pe;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::CheckDef>>(std::tuple<Array<crate::lower::model::CheckDef>, crate::check::env::Def>)>>(prism_rtl::rc([=, lx_pe_1 = std::move(lx_pe_1)](std::tuple<Array<crate::lower::model::CheckDef>, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_pe_1_2 = lx_pe_1;
            entered(once_job([=, lx_pe_1_2 = std::move(lx_pe_1_2)]() {
            return ({
                auto acc_p22 = p0;
                auto d_p23 = p1;
                ({
                auto&& _m = prism_rtl::deref(d_p23).body;
                prism_rtl::is<crate::check::env::DefBody::DbCheck>(_m) ? ({
                auto&& c_p24 = prism_rtl::as<crate::check::env::DefBody::DbCheck>(_m).a0;
                ({
                auto c_p24_2 = c_p24;
                call_then(start_check_def_of(in_module_at(lx_pe_1_2, d_p23->file, prism_rtl::deref(d_p23).home, Text::lit("\000main"sv)), c_p24_2), [=](crate::lower::model::CheckDef check_def_of_3751) { return prism_rtl::finished(crate::prelude::push(acc_p22, check_def_of_3751)); });
            });
            })
                : prism_rtl::finished(acc_p22);
            });
            });
        }));
        });
    })));
    })));
    auto with_needs_pl = with_groups(with_needs(g_pt, srcs_p0, tp_p3, mod_defs_pg));
    auto elem_pm = elem_row(lx_pe, mods_pa);
    auto answer_pn = answer_enum(in_module_at(lx_pe, Nat(0u), Text::lit(""), Text::lit("\000main"sv)), mods_pa);
    auto names_po = each(with_needs_pl, [&](const crate::lower::model::ModDef& d_p25) { return prism_rtl::deref(d_p25).name; });
    auto value_tys_pp = value_types(with_needs_pl);
    auto elem_held_pq = fold(prism_rtl::deref(elem_pm).cases_, Array<Text>{}, [&](const Array<Text>& acc_p26, const std::tuple<Text, Text>& _p1) {
        auto&& sp_p27 = std::get<1>(_p1);
        return crate::check::types::union_texts(acc_p26, held_in(names_po, value_tys_pp, Text::lit(""), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{sp_p27, Array<crate::lower::model::OutTy>{}})));
    });
    auto answer_held_pr = fold(prism_rtl::deref(answer_pn).cases_, elem_held_pq, [&](const Array<Text>& acc_p28, const crate::lower::model::AnswerCase& k_p29) { return crate::check::types::union_texts(acc_p28, held_in(names_po, value_tys_pp, Text::lit(""), prism_rtl::deref(k_p29).ty)); });
    auto answer_named_ps = fold(prism_rtl::deref(answer_pn).cases_, Array<Text>{}, [&](const Array<Text>& acc_p2a, const crate::lower::model::AnswerCase& k_p2b) { return crate::check::types::union_texts(acc_p2a, named_in(names_po, Text::lit(""), prism_rtl::deref(k_p2b).ty)); });
    return crate::lower::model::Model{.name = name_p4, .mods = with_needs_pl, .programs = programs_ph, .root = root_oj, .checks = checks_pk, .elem = elem_pm, .answer = answer_pn, .elem_complete = answer_held_pr, .elem_declared = crate::check::types::minus_texts(answer_named_ps, answer_held_pr), .scripts = Array<Text>{}, .notes = Array<Text>{}};
}


prism_rtl::Turn<crate::lower::model::Model> LowerProgram::cycle() const {
    const auto& srcs_p0 = this->srcs_p0;
    const auto& trees_p1 = this->trees_p1;
    const auto& shown_p2 = this->shown_p2;
    const auto& tp_p3 = this->tp_p3;
    const auto& name_p4 = this->name_p4;
    auto name_p4_1 = name_p4;
    auto shown_p2_2 = shown_p2;
    auto srcs_p0_3 = srcs_p0;
    auto tp_p3_4 = tp_p3;
    auto trees_p1_5 = trees_p1;
    return call_then(crate::check::env::start_build_g(srcs_p0_3, trees_p1_5), [=](std::tuple<crate::check::env::G, crate::check::types::St> build_g_1920) {
        return ({
            auto&& _g_pt = build_g_1920;
            auto&& g_pt = std::get<0>(_g_pt);
            auto [tys_pu, apps_pv, bs_p10, ims_p11] = crate::lower::typed_tables(tp_p3_4);
            auto gens_p5 = fold(prism_rtl::deref(tp_p3_4).gens, Map<Text, crate::check::typed::GenNote>{}, [&](const Map<Text, crate::check::typed::GenNote>& m_p12, const crate::check::typed::GenNote& n_p13) { return insert(m_p12, crate::check::typed::at_key(prism_rtl::deref(n_p13).at), n_p13); });
            auto insts_p6 = fold(prism_rtl::deref(tp_p3_4).insts, Map<Text, Array<crate::check::typed::InstNote>>{}, [&](const Map<Text, Array<crate::check::typed::InstNote>>& m_p14, const crate::check::typed::InstNote& n_p15) { return insert(m_p14, crate::lower::expr::inst_key(n_p15), crate::prelude::push(or_(crate::prelude::get(m_p14, crate::lower::expr::inst_key(n_p15)), Array<crate::check::typed::InstNote>{}), n_p15)); });
            auto quants_p7 = fold(prism_rtl::deref(tp_p3_4).gens, Map<Text, Text>{}, [&](const Map<Text, Text>& m_p16, const crate::check::typed::GenNote& n_p17) { return fold(append(prism_rtl::deref(n_p17).tys, prism_rtl::deref(n_p17).cols), m_p16, [&](const Map<Text, Text>& m2_p18, const Text& q_p19) { return insert(m2_p18, q_p19, prism_rtl::deref(n_p17).name); }); });
            auto gen_of_q_p8 = fold(prism_rtl::deref(tp_p3_4).gens, Map<Text, crate::check::typed::GenNote>{}, [&](const Map<Text, crate::check::typed::GenNote>& m_p1a, const crate::check::typed::GenNote& n_p1b) { return fold(append(prism_rtl::deref(n_p1b).tys, prism_rtl::deref(n_p1b).cols), m_p1a, [&](const Map<Text, crate::check::typed::GenNote>& m2_p1c, const Text& q_p1d) { return insert(m2_p1c, q_p1d, n_p1b); }); });
            auto use_insts_p9 = fold(prism_rtl::deref(tp_p3_4).insts, Map<Text, crate::check::typed::InstNote>{}, [&](const Map<Text, crate::check::typed::InstNote>& m_p1e, const crate::check::typed::InstNote& n_p1f) { return insert(m_p1e, crate::check::typed::at_key(prism_rtl::deref(n_p1f).at), n_p1f); });
            call_then(start_needed_mods(g_pt, shown_p2_2), [=, gens_p5 = std::move(gens_p5), insts_p6 = std::move(insts_p6), quants_p7 = std::move(quants_p7), gen_of_q_p8 = std::move(gen_of_q_p8), use_insts_p9 = std::move(use_insts_p9)](Array<Text> needed_mods_2446) {
            return ({
                auto mods_pa = needed_mods_2446;
                auto rs_mods_pb = fold(mods_pa, Map<Text, Text>{}, [&](const Map<Text, Text>& acc_p1g, const Text& m_p1h) { return insert(acc_p1g, m_p1h, crate::lower::rust_mod_name(m_p1h)); });
                auto mod_segments_pc = fold(values(rs_mods_pb), Map<Text, bool>{}, [&](const Map<Text, bool>& acc_p1i, const Text& p_p1j) { return fold(split_on(p_p1j, Text::lit("::")), acc_p1i, [&](const Map<Text, bool>& a2_p1k, const Text& seg_p1l) { return insert(a2_p1k, seg_p1l, true); }); });
                call_then(crate::lower::types::start_layouts(g_pt), [=, mods_pa = std::move(mods_pa), rs_mods_pb = std::move(rs_mods_pb), mod_segments_pc = std::move(mod_segments_pc)](Map<Text, Array<bool>> layouts_2884) {
                return ({
                    auto lx0_pd = crate::lower::Lx{.g = g_pt, .tys = tys_pu, .apps = apps_pv, .lifts = fold(prism_rtl::deref(tp_p3_4).lifts, Map<Text, crate::check::typed::LiftNote>{}, [&](const Map<Text, crate::check::typed::LiftNote>& m_p1m, const crate::check::typed::LiftNote& n_p1n) { return insert(m_p1m, crate::check::typed::at_key(prism_rtl::deref(n_p1n).at), n_p1n); }), .binders = bs_p10, .impls = ims_p11, .file = Nat(0u), .home = Text::lit(""), .site = Text::lit(""), .rs_mods = rs_mods_pb, .mod_segments = mod_segments_pc, .rs_names = crate::lower::value_names(g_pt), .layouts = layouts_2884, .unbs = Array<Text>{}, .notes = Array<Text>{}, .globals = crate::lower::global_names(g_pt), .in_node = false, .unshrunk = fold(prism_rtl::deref(tp_p3_4).unshrunk, Map<Text, bool>{}, [&](const Map<Text, bool>& m_p1o, const crate::check::typed::SrcAt& a_p1p) { return insert(m_p1o, crate::check::typed::at_key(a_p1p), true); }), .gens = gens_p5, .insts = insts_p6, .quants = quants_p7, .gen_of_q = gen_of_q_p8, .use_insts = use_insts_p9, .local_ids = fold(prism_rtl::deref(tp_p3_4).locals, Map<Text, Nat>{}, [&](const Map<Text, Nat>& m_p1q, const crate::check::typed::LocalNote& n_p1r) { return insert(m_p1q, crate::check::typed::at_key(prism_rtl::deref(n_p1r).at), prism_rtl::deref(n_p1r).id); }), .use_ids = fold(prism_rtl::deref(tp_p3_4).uses, Map<Text, Nat>{}, [&](const Map<Text, Nat>& m_p1s, const crate::check::typed::LocalNote& n_p1t) { return insert(m_p1s, crate::check::typed::at_key(prism_rtl::deref(n_p1t).at), prism_rtl::deref(n_p1t).id); }), .subst = Map<Text, crate::check::types::Ty>{}, .csubst = Map<Text, crate::check::types::Col>{}};
                    auto lx_pe = ({
                        crate::lower::Lx this_ = lx0_pd;
                        this_.unbs = job_roots(lx0_pd);
                        (std::move(this_));
                    });
                    auto roots_pf = root_widgets(lx_pe);
                    call_value(each_job(mods_pa, ({
                    auto lx_pe_6 = lx_pe;
                    auto roots_pf_7 = roots_pf;
                    auto g_pt_8 = g_pt;
                    auto mods_pa_9 = mods_pa;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::ModDef>(Text)>>(prism_rtl::rc([=, lx_pe_6 = std::move(lx_pe_6), roots_pf_7 = std::move(roots_pf_7), g_pt_8 = std::move(g_pt_8), mods_pa_9 = std::move(mods_pa_9)](Text p0) {
                    return ({
                        auto lx_pe_6_10 = lx_pe_6;
                        auto roots_pf_7_10 = roots_pf_7;
                        auto g_pt_8_10 = g_pt_8;
                        auto mods_pa_9_10 = mods_pa_9;
                        entered(once_job([=, lx_pe_6_10 = std::move(lx_pe_6_10), roots_pf_7_10 = std::move(roots_pf_7_10), g_pt_8_10 = std::move(g_pt_8_10), mods_pa_9_10 = std::move(mods_pa_9_10)]() {
                        return ({
                            auto m_p1u = p0;
                            (prism_rtl::more(prism_rtl::rc(ModDefOf(lx_pe_6_10, m_p1u, roots_pf_7_10, or_(crate::prelude::get(prism_rtl::deref(g_pt_8_10).mods, m_p1u), crate::check::env::reading::dummy_mod()), mods_pa_9_10))));
                        });
                    }));
                    });
                })));
                })), [=](Array<crate::lower::model::ModDef> each_3360) {
                    return ({
                        auto mod_defs_pg = each_3360;
                        call_value(each_job(roots_pf, ({
                        auto lx_pe_6 = lx_pe;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::ProgDef>(std::tuple<Text, bool>)>>(prism_rtl::rc([=, lx_pe_6 = std::move(lx_pe_6)](std::tuple<Text, bool> p0) {
                        return ({
                            auto lx_pe_6_7 = lx_pe_6;
                            entered(once_job([=, lx_pe_6_7 = std::move(lx_pe_6_7)]() {
                            return ({
                                auto&& _qk_p1v = p0;
                                auto&& qk_p1v = std::get<0>(_qk_p1v);
                                (prism_rtl::more(prism_rtl::rc(ProgDefOf(lx_pe_6_7, qk_p1v))));
                            });
                        }));
                        });
                    })));
                    })), [=, mod_defs_pg = std::move(mod_defs_pg)](Array<crate::lower::model::ProgDef> each_3449) {
                        return ({
                            auto programs_ph = each_3449;
                            auto main_qk_pi = fold(prism_rtl::deref(g_pt).defs, Text::lit(""), [&](const Text& found_p20, const crate::check::env::Def& d_p21) {
                                return (found_p20 == Text::lit("")) && is_main(prism_rtl::deref(d_p21).qk)
                                    ? prism_rtl::deref(d_p21).qk
                                    : found_p20;
                            });
                            auto root_oj = main_qk_pi == Text::lit("")
                                ? std::optional<crate::lower::model::ProgDef>{}
                                : std::optional(prog_def_of(lx_pe, main_qk_pi));
                            call_value(fold_job(prism_rtl::deref(g_pt).defs, Array<crate::lower::model::CheckDef>{}, ({
                            auto lx_pe_6 = lx_pe;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::CheckDef>>(std::tuple<Array<crate::lower::model::CheckDef>, crate::check::env::Def>)>>(prism_rtl::rc([=, lx_pe_6 = std::move(lx_pe_6)](std::tuple<Array<crate::lower::model::CheckDef>, crate::check::env::Def> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto lx_pe_6_7 = lx_pe_6;
                                entered(once_job([=, lx_pe_6_7 = std::move(lx_pe_6_7)]() {
                                return ({
                                    auto acc_p22 = p0;
                                    auto d_p23 = p1;
                                    ({
                                    auto&& _m = prism_rtl::deref(d_p23).body;
                                    prism_rtl::is<crate::check::env::DefBody::DbCheck>(_m) ? ({
                                    auto&& c_p24 = prism_rtl::as<crate::check::env::DefBody::DbCheck>(_m).a0;
                                    ({
                                    auto c_p24_7 = c_p24;
                                    call_then(start_check_def_of(in_module_at(lx_pe_6_7, d_p23->file, prism_rtl::deref(d_p23).home, Text::lit("\000main"sv)), c_p24_7), [=](crate::lower::model::CheckDef check_def_of_3751) { return prism_rtl::finished(crate::prelude::push(acc_p22, check_def_of_3751)); });
                                });
                                })
                                    : prism_rtl::finished(acc_p22);
                                });
                                });
                            }));
                            });
                        })));
                        })), [=, programs_ph = std::move(programs_ph), root_oj = std::move(root_oj)](Array<crate::lower::model::CheckDef> fold_3678) {
                            return ({
                                auto checks_pk = fold_3678;
                                call_then(start_with_needs(g_pt, srcs_p0_3, tp_p3_4, mod_defs_pg), [=, checks_pk = std::move(checks_pk)](Array<crate::lower::model::ModDef> with_needs_3866) {
                                return call_then(start_with_groups(with_needs_3866), [=](Array<crate::lower::model::ModDef> with_groups_3854) {
                                    return ({
                                        auto with_needs_pl = with_groups_3854;
                                        call_then(start_elem_row(lx_pe, mods_pa), [=, with_needs_pl = std::move(with_needs_pl)](crate::lower::model::RowDef elem_row_3913) {
                                        return ({
                                            auto elem_pm = elem_row_3913;
                                            call_then(start_answer_enum(in_module_at(lx_pe, Nat(0u), Text::lit(""), Text::lit("\000main"sv)), mods_pa), [=, elem_pm = std::move(elem_pm)](crate::lower::model::AnswerDef answer_enum_3947) {
                                            return ({
                                                auto answer_pn = answer_enum_3947;
                                                auto names_po = each(with_needs_pl, [&](const crate::lower::model::ModDef& d_p25) { return prism_rtl::deref(d_p25).name; });
                                                auto value_tys_pp = value_types(with_needs_pl);
                                                auto elem_held_pq = fold(prism_rtl::deref(elem_pm).cases_, Array<Text>{}, [&](const Array<Text>& acc_p26, const std::tuple<Text, Text>& _p1) {
                                                    auto&& sp_p27 = std::get<1>(_p1);
                                                    return crate::check::types::union_texts(acc_p26, held_in(names_po, value_tys_pp, Text::lit(""), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{sp_p27, Array<crate::lower::model::OutTy>{}})));
                                                });
                                                auto answer_held_pr = fold(prism_rtl::deref(answer_pn).cases_, elem_held_pq, [&](const Array<Text>& acc_p28, const crate::lower::model::AnswerCase& k_p29) { return crate::check::types::union_texts(acc_p28, held_in(names_po, value_tys_pp, Text::lit(""), prism_rtl::deref(k_p29).ty)); });
                                                auto answer_named_ps = fold(prism_rtl::deref(answer_pn).cases_, Array<Text>{}, [&](const Array<Text>& acc_p2a, const crate::lower::model::AnswerCase& k_p2b) { return crate::check::types::union_texts(acc_p2a, named_in(names_po, Text::lit(""), prism_rtl::deref(k_p2b).ty)); });
                                                (prism_rtl::finished(crate::lower::model::Model{.name = name_p4_1, .mods = with_needs_pl, .programs = programs_ph, .root = root_oj, .checks = checks_pk, .elem = elem_pm, .answer = answer_pn, .elem_complete = answer_held_pr, .elem_declared = crate::check::types::minus_texts(answer_named_ps, answer_held_pr), .scripts = Array<Text>{}, .notes = Array<Text>{}}));
                                            });
                                        });
                                        });
                                    });
                                    });
                                });
                            });
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start LowerProgram, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Model> start_lower_program(Array<crate::check::errors::Src> srcs_p0, Array<crate::syntax::Module> trees_p1, Nat shown_p2, crate::check::typed::TProgram tp_p3, Text name_p4) {
    return prism_rtl::make_rc<LowerProgram>(srcs_p0, trees_p1, shown_p2, tp_p3, name_p4);
}


/// WithNeeds: unbounded fn G, [Src], TProgram, [ModDef] -> [ModDef]
Array<crate::lower::model::ModDef> with_needs(const crate::check::env::G& g_p0, const Array<crate::check::errors::Src>& srcs_p1, const crate::check::typed::TProgram& tp_p2, const Array<crate::lower::model::ModDef>& defs_p3) {
    auto names_p4 = each(defs_p3, [&](const crate::lower::model::ModDef& d_p7) { return prism_rtl::deref(d_p7).name; });
    auto value_tys_p5 = value_types(defs_p3);
    auto refs_p6 = named_mods(g_p0, srcs_p1, tp_p2, each(defs_p3, [&](const crate::lower::model::ModDef& d_p8) { return prism_rtl::deref(d_p8).prism; }));
    return run_to_end(each_job(defs_p3, ({
        auto names_p4_1 = names_p4;
        auto value_tys_p5_2 = value_tys_p5;
        auto refs_p6_3 = refs_p6;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::ModDef>(crate::lower::model::ModDef)>>(prism_rtl::rc([=, names_p4_1 = std::move(names_p4_1), value_tys_p5_2 = std::move(value_tys_p5_2), refs_p6_3 = std::move(refs_p6_3)](crate::lower::model::ModDef p0) {
        return ({
            auto names_p4_1_4 = names_p4_1;
            auto value_tys_p5_2_4 = value_tys_p5_2;
            auto refs_p6_3_4 = refs_p6_3;
            entered(once_job([=, names_p4_1_4 = std::move(names_p4_1_4), value_tys_p5_2_4 = std::move(value_tys_p5_2_4), refs_p6_3_4 = std::move(refs_p6_3_4)]() {
            return ({
                auto d_p9 = p0;
                ({
                auto held_pa = fold(prism_rtl::deref(d_p9).items, Array<Text>{}, [&](const Array<Text>& acc_pe, const crate::lower::model::Item& it_pf) { return crate::check::types::union_texts(acc_pe, item_held(names_p4_1_4, value_tys_p5_2_4, prism_rtl::deref(d_p9).name, it_pf)); });
                auto complete_pb = filter(held_pa, [&](const Text& n_pg) { return n_pg != prism_rtl::deref(d_p9).name; });
                call_then(start_reached_by(refs_p6_3_4, Array(std::vector{prism_rtl::deref(d_p9).prism}), Array<Text>{}), [=, complete_pb = std::move(complete_pb)](Array<Text> reached_by_5161) {
                return ({
                    auto reached_pc = each(reached_by_5161, [&](const Text& m_ph) { return crate::lower::rust_mod_name(m_ph); });
                    auto declared_pd = filter(names_p4_1_4, [&](const Text& n_pi) { return ((n_pi != prism_rtl::deref(d_p9).name) && crate::check::types::has_text(reached_pc, n_pi)) && (!crate::check::types::has_text(complete_pb, n_pi)); });
                    (prism_rtl::finished(({
                    crate::lower::model::ModDef this_ = d_p9;
                    this_.complete = complete_pb;
                    this_.declared = declared_pd;
                    (std::move(this_));
                })));
                });
            });
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<crate::lower::model::ModDef>> WithNeeds::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& srcs_p1 = this->srcs_p1;
    const auto& tp_p2 = this->tp_p2;
    const auto& defs_p3 = this->defs_p3;
    auto names_p4 = each(defs_p3, [&](const crate::lower::model::ModDef& d_p7) { return prism_rtl::deref(d_p7).name; });
    auto value_tys_p5 = value_types(defs_p3);
    auto defs_p3_1 = defs_p3;
    auto g_p0_2 = g_p0;
    auto srcs_p1_3 = srcs_p1;
    auto tp_p2_4 = tp_p2;
    return call_then(start_named_mods(g_p0_2, srcs_p1_3, tp_p2_4, each(defs_p3_1, [&](const crate::lower::model::ModDef& d_p8) { return prism_rtl::deref(d_p8).prism; })), [=](Map<Text, Array<Text>> named_mods_4906) {
        return ({
            auto refs_p6 = named_mods_4906;
            each_job(defs_p3_1, ({
            auto names_p4_5 = names_p4;
            auto value_tys_p5_6 = value_tys_p5;
            auto refs_p6_7 = refs_p6;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::ModDef>(crate::lower::model::ModDef)>>(prism_rtl::rc([=, names_p4_5 = std::move(names_p4_5), value_tys_p5_6 = std::move(value_tys_p5_6), refs_p6_7 = std::move(refs_p6_7)](crate::lower::model::ModDef p0) {
            return ({
                auto names_p4_5_8 = names_p4_5;
                auto value_tys_p5_6_8 = value_tys_p5_6;
                auto refs_p6_7_8 = refs_p6_7;
                entered(once_job([=, names_p4_5_8 = std::move(names_p4_5_8), value_tys_p5_6_8 = std::move(value_tys_p5_6_8), refs_p6_7_8 = std::move(refs_p6_7_8)]() {
                return ({
                    auto d_p9 = p0;
                    ({
                    auto held_pa = fold(prism_rtl::deref(d_p9).items, Array<Text>{}, [&](const Array<Text>& acc_pe, const crate::lower::model::Item& it_pf) { return crate::check::types::union_texts(acc_pe, item_held(names_p4_5_8, value_tys_p5_6_8, prism_rtl::deref(d_p9).name, it_pf)); });
                    auto complete_pb = filter(held_pa, [&](const Text& n_pg) { return n_pg != prism_rtl::deref(d_p9).name; });
                    call_then(start_reached_by(refs_p6_7_8, Array(std::vector{prism_rtl::deref(d_p9).prism}), Array<Text>{}), [=, complete_pb = std::move(complete_pb)](Array<Text> reached_by_5161) {
                    return ({
                        auto reached_pc = each(reached_by_5161, [&](const Text& m_ph) { return crate::lower::rust_mod_name(m_ph); });
                        auto declared_pd = filter(names_p4_5_8, [&](const Text& n_pi) { return ((n_pi != prism_rtl::deref(d_p9).name) && crate::check::types::has_text(reached_pc, n_pi)) && (!crate::check::types::has_text(complete_pb, n_pi)); });
                        (prism_rtl::finished(({
                        crate::lower::model::ModDef this_ = d_p9;
                        this_.complete = complete_pb;
                        this_.declared = declared_pd;
                        (std::move(this_));
                    })));
                    });
                });
                });
                });
            }));
            });
        })));
        }))->cycle();
        });
    });
}


/// `Start WithNeeds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::ModDef>> start_with_needs(crate::check::env::G g_p0, Array<crate::check::errors::Src> srcs_p1, crate::check::typed::TProgram tp_p2, Array<crate::lower::model::ModDef> defs_p3) {
    return prism_rtl::make_rc<WithNeeds>(g_p0, srcs_p1, tp_p2, defs_p3);
}


/// NamedMods: unbounded fn G, [Src], TProgram, [Text] -> (Text ==> [Text])
Map<Text, Array<Text>> named_mods(const crate::check::env::G& g_p0, const Array<crate::check::errors::Src>& srcs_p1, const crate::check::typed::TProgram& tp_p2, const Array<Text>& ms_p3) {
    auto by_path_p4 = fold(values(g_p0.mods), Map<Text, Text>{}, [&](const Map<Text, Text>& acc_p7, const crate::check::env::ModInfo& info_p8) { return insert(acc_p7, or_(index(srcs_p1, info_p8->file), crate::check::errors::mk_src(Text::lit(""), Text::lit("")))->path_, prism_rtl::deref(info_p8).name); });
    auto by_file_p5 = fold(values(g_p0.mods), Map<Nat, Text>{}, [&](const Map<Nat, Text>& acc_p9, const crate::check::env::ModInfo& info_pa) { return insert(acc_p9, info_pa->file, prism_rtl::deref(info_pa).name); });
    auto solved_p6 = fold(tp_p2.impls, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& acc_pb, const crate::check::typed::ImplNote& n_pc) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, Array<Text>>> _v;
            auto&& _m = crate::prelude::get(by_file_p5, prism_rtl::deref(n_pc).at->file);
            if (prism_rtl::is_some(_m)) {
                auto&& site_pd = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Map<Text, Array<Text>>> _v;
                    auto&& _m = crate::prelude::get(by_path_p4, impl_path(prism_rtl::deref(n_pc).how));
                    if (prism_rtl::is_some(_m)) {
                        auto&& home_pe = prism_rtl::some_of(_m);
                        _v.set((home_pe == site_pd) || crate::check::types::has_text(or_(crate::prelude::get(acc_pb, site_pd), Array<Text>{}), home_pe)
                            ? acc_pb
                            : insert(acc_pb, site_pd, crate::prelude::push(or_(crate::prelude::get(acc_pb, site_pd), Array<Text>{}), home_pe)));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc_pb);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(acc_pb);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    return run_to_end(fold_job(ms_p3, Map<Text, Array<Text>>{}, ({
        auto g_p0_1 = g_p0;
        auto srcs_p1_2 = srcs_p1;
        auto ms_p3_3 = ms_p3;
        auto solved_p6_4 = solved_p6;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, Text>)>>(prism_rtl::rc([=, g_p0_1 = std::move(g_p0_1), srcs_p1_2 = std::move(srcs_p1_2), ms_p3_3 = std::move(ms_p3_3), solved_p6_4 = std::move(solved_p6_4)](std::tuple<Map<Text, Array<Text>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0_1_5 = g_p0_1;
            auto srcs_p1_2_5 = srcs_p1_2;
            auto ms_p3_3_5 = ms_p3_3;
            auto solved_p6_4_5 = solved_p6_4;
            entered(once_job([=, g_p0_1_5 = std::move(g_p0_1_5), srcs_p1_2_5 = std::move(srcs_p1_2_5), ms_p3_3_5 = std::move(ms_p3_3_5), solved_p6_4_5 = std::move(solved_p6_4_5)]() {
            return ({
                auto acc_pf = p0;
                auto m_pg = p1;
                ({
                auto&& _m = crate::prelude::get(g_p0_1_5.mods, m_pg);
                prism_rtl::is_some(_m) ? ({
                auto&& info_ph = prism_rtl::some_of(_m);
                ({
                auto code_pi = crate::syntax::lexer::chars::join(filter(split_on(or_(index(srcs_p1_2_5, info_ph->file), crate::check::errors::mk_src(Text::lit(""), Text::lit("")))->text, Text::lit("\n")), [&](const Text& l_pk) { return !crate::syntax::lexer::chars::has_prefix(crate::syntax::lexer::chars::trim_start(l_pk), Text::lit("#")); }), Text::lit("\n"));
                auto qualified_pj = filter(ms_p3_3_5, [&](const Text& o_pl) { return ((o_pl != m_pg) && (o_pl != Text::lit(""))) && crate::syntax::lexer::chars::contains(code_pi, prism_rtl::cat(o_pl, ".")); });
                call_then(start_mod_refs(g_p0_1_5, m_pg), [=, qualified_pj = std::move(qualified_pj)](Array<Text> mod_refs_6810) { return prism_rtl::finished(insert(acc_pf, m_pg, crate::check::types::union_texts(crate::check::types::union_texts(mod_refs_6810, qualified_pj), or_(crate::prelude::get(solved_p6_4_5, m_pg), Array<Text>{})))); });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(acc_pf)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<Map<Text, Array<Text>>> NamedMods::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& srcs_p1 = this->srcs_p1;
    const auto& tp_p2 = this->tp_p2;
    const auto& ms_p3 = this->ms_p3;
    auto by_path_p4 = fold(values(prism_rtl::deref(g_p0).mods), Map<Text, Text>{}, [&](const Map<Text, Text>& acc_p7, const crate::check::env::ModInfo& info_p8) { return insert(acc_p7, or_(index(srcs_p1, info_p8->file), crate::check::errors::mk_src(Text::lit(""), Text::lit("")))->path_, prism_rtl::deref(info_p8).name); });
    auto by_file_p5 = fold(values(prism_rtl::deref(g_p0).mods), Map<Nat, Text>{}, [&](const Map<Nat, Text>& acc_p9, const crate::check::env::ModInfo& info_pa) { return insert(acc_p9, info_pa->file, prism_rtl::deref(info_pa).name); });
    auto solved_p6 = fold(prism_rtl::deref(tp_p2).impls, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& acc_pb, const crate::check::typed::ImplNote& n_pc) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, Array<Text>>> _v;
            auto&& _m = crate::prelude::get(by_file_p5, prism_rtl::deref(n_pc).at->file);
            if (prism_rtl::is_some(_m)) {
                auto&& site_pd = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Map<Text, Array<Text>>> _v;
                    auto&& _m = crate::prelude::get(by_path_p4, impl_path(prism_rtl::deref(n_pc).how));
                    if (prism_rtl::is_some(_m)) {
                        auto&& home_pe = prism_rtl::some_of(_m);
                        _v.set((home_pe == site_pd) || crate::check::types::has_text(or_(crate::prelude::get(acc_pb, site_pd), Array<Text>{}), home_pe)
                            ? acc_pb
                            : insert(acc_pb, site_pd, crate::prelude::push(or_(crate::prelude::get(acc_pb, site_pd), Array<Text>{}), home_pe)));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc_pb);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(acc_pb);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    return fold_job(ms_p3, Map<Text, Array<Text>>{}, ({
        auto g_p0_1 = g_p0;
        auto srcs_p1_2 = srcs_p1;
        auto ms_p3_3 = ms_p3;
        auto solved_p6_4 = solved_p6;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, Text>)>>(prism_rtl::rc([=, g_p0_1 = std::move(g_p0_1), srcs_p1_2 = std::move(srcs_p1_2), ms_p3_3 = std::move(ms_p3_3), solved_p6_4 = std::move(solved_p6_4)](std::tuple<Map<Text, Array<Text>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0_1_5 = g_p0_1;
            auto srcs_p1_2_5 = srcs_p1_2;
            auto ms_p3_3_5 = ms_p3_3;
            auto solved_p6_4_5 = solved_p6_4;
            entered(once_job([=, g_p0_1_5 = std::move(g_p0_1_5), srcs_p1_2_5 = std::move(srcs_p1_2_5), ms_p3_3_5 = std::move(ms_p3_3_5), solved_p6_4_5 = std::move(solved_p6_4_5)]() {
            return ({
                auto acc_pf = p0;
                auto m_pg = p1;
                ({
                auto&& _m = crate::prelude::get(prism_rtl::deref(g_p0_1_5).mods, m_pg);
                prism_rtl::is_some(_m) ? ({
                auto&& info_ph = prism_rtl::some_of(_m);
                ({
                auto code_pi = crate::syntax::lexer::chars::join(filter(split_on(or_(index(srcs_p1_2_5, info_ph->file), crate::check::errors::mk_src(Text::lit(""), Text::lit("")))->text, Text::lit("\n")), [&](const Text& l_pk) { return !crate::syntax::lexer::chars::has_prefix(crate::syntax::lexer::chars::trim_start(l_pk), Text::lit("#")); }), Text::lit("\n"));
                auto qualified_pj = filter(ms_p3_3_5, [&](const Text& o_pl) { return ((o_pl != m_pg) && (o_pl != Text::lit(""))) && crate::syntax::lexer::chars::contains(code_pi, prism_rtl::cat(o_pl, ".")); });
                call_then(start_mod_refs(g_p0_1_5, m_pg), [=, qualified_pj = std::move(qualified_pj)](Array<Text> mod_refs_6810) { return prism_rtl::finished(insert(acc_pf, m_pg, crate::check::types::union_texts(crate::check::types::union_texts(mod_refs_6810, qualified_pj), or_(crate::prelude::get(solved_p6_4_5, m_pg), Array<Text>{})))); });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(acc_pf)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start NamedMods, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Array<Text>>> start_named_mods(crate::check::env::G g_p0, Array<crate::check::errors::Src> srcs_p1, crate::check::typed::TProgram tp_p2, Array<Text> ms_p3) {
    return prism_rtl::make_rc<NamedMods>(g_p0, srcs_p1, tp_p2, ms_p3);
}


/// ImplPath: fn Text -> Text
Text impl_path(const Text& how_p0) {
    auto rest_p1 = or_(crate::syntax::lexer::chars::after_prefix(how_p0, Text::lit("impl ")), or_(crate::syntax::lexer::chars::after_prefix(how_p0, Text::lit("derived ")), Text::lit("")));
    auto parts_p2 = split_on(rest_p1, Text::lit(":"));
    return crate::syntax::lexer::chars::join(take(parts_p2, crate::syntax::lexer::chars::dec(len(parts_p2))), Text::lit(":"));
}


/// ValueTypes: fn [ModDef] -> (Text ==> Bool)
Map<Text, bool> value_types(const Array<crate::lower::model::ModDef>& defs_p0) {
    return fold(defs_p0, Map<Text, bool>{}, [&](const Map<Text, bool>& acc_p1, const crate::lower::model::ModDef& d_p2) {
        return fold(prism_rtl::deref(d_p2).items, acc_p1, [&](const Map<Text, bool>& a_p3, const crate::lower::model::Item& it_p4) {
            return ({
                __label__ _done;
                prism_rtl::Slot<Map<Text, bool>> _v;
                if (prism_rtl::is<crate::lower::model::Item::ItType>(it_p4)) {
                    auto&& t_p5 = prism_rtl::as<crate::lower::model::Item::ItType>(it_p4).a0;
                    _v.set(insert(a_p3, prism_rtl::cat(prism_rtl::deref(d_p2).name, "::", prism_rtl::deref(t_p5).name), true));
                    goto _done;
                }
                if (prism_rtl::is<crate::lower::model::Item::ItTag>(it_p4)) {
                    auto&& t_p6 = prism_rtl::as<crate::lower::model::Item::ItTag>(it_p4).a0;
                    _v.set(insert(a_p3, prism_rtl::cat(prism_rtl::deref(d_p2).name, "::", prism_rtl::deref(t_p6).name), true));
                    goto _done;
                }
                {
                    _v.set(a_p3);
                    goto _done;
                }
            _done:
                _v.take();
            });
        });
    });
}


/// ItemHeld: fn [Text], (Text ==> Bool), Text, Item -> [Text]
Array<Text> item_held(const Array<Text>& names_p0, const Map<Text, bool>& value_tys_p1, const Text& home_p2, const crate::lower::model::Item& it_p3) {
    if (prism_rtl::is<crate::lower::model::Item::ItType>(it_p3)) {
        auto&& t_p4 = prism_rtl::as<crate::lower::model::Item::ItType>(it_p3).a0;
        return fold(prism_rtl::deref(t_p4).cases_, Array<Text>{}, [&](const Array<Text>& acc_p5, const crate::lower::model::CaseDef& c_p6) {
            return fold(prism_rtl::deref(c_p6).fields, acc_p5, [&](const Array<Text>& a_p7, const std::tuple<Text, crate::lower::model::OutTy>& _p1) {
                auto&& ft_p8 = std::get<1>(_p1);
                return crate::check::types::union_texts(a_p7, held_in(names_p0, value_tys_p1, home_p2, ft_p8));
            });
        });
    }
    if (prism_rtl::is<crate::lower::model::Item::ItTag>(it_p3)) {
        auto&& t_p9 = prism_rtl::as<crate::lower::model::Item::ItTag>(it_p3).a0;
        return fold(prism_rtl::deref(t_p9).fields, Array<Text>{}, [&](const Array<Text>& acc_pa, const std::tuple<Text, Text, crate::lower::model::OutTy>& _p1) {
            auto&& ft_pb = std::get<2>(_p1);
            return crate::check::types::union_texts(acc_pa, held_in(names_p0, value_tys_p1, home_p2, ft_pb));
        });
    }
    if (prism_rtl::is<crate::lower::model::Item::ItRow>(it_p3)) {
        auto&& r_pc = prism_rtl::as<crate::lower::model::Item::ItRow>(it_p3).a0;
        return fold(prism_rtl::deref(r_pc).cases_, Array<Text>{}, [&](const Array<Text>& acc_pd, const std::tuple<Text, Text>& _p1) {
            auto&& sp_pe = std::get<1>(_p1);
            return crate::check::types::union_texts(acc_pd, held_in(names_p0, value_tys_p1, home_p2, crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{sp_pe, Array<crate::lower::model::OutTy>{}})));
        });
    }
    {
        return Array<Text>{};
    }
}


/// HeldIn: fn [Text], (Text ==> Bool), Text, OutTy -> [Text]
Array<Text> held_in(const Array<Text>& names_p0, const Map<Text, bool>& value_tys_p1, const Text& home_p2, const crate::lower::model::OutTy& t_p3) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p3)) {
        auto&& n_p4 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p3).a0;
        auto&& args_p5 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p3).a1;
        auto p_p6 = path_from(names_p0, home_p2, n_p4);
        auto own_p7 = crate::check::env::has_key(value_tys_p1, p_p6)
            ? Array(std::vector{parent_of(p_p6)})
            : Array<Text>{};
        return fold(args_p5, own_p7, [&](const Array<Text>& acc_p8, const crate::lower::model::OutTy& a_p9) { return crate::check::types::union_texts(acc_p8, held_in(names_p0, value_tys_p1, home_p2, a_p9)); });
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t_p3)) {
        auto&& i_pa = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t_p3).a0;
        return held_in(names_p0, value_tys_p1, home_p2, prism_rtl::deref(prism_rtl::deref(i_pa)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p3)) {
        auto&& i_pb = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t_p3).a0;
        return held_in(names_p0, value_tys_p1, home_p2, prism_rtl::deref(prism_rtl::deref(i_pb)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutCell>(t_p3)) {
        auto&& i_pc = prism_rtl::as<crate::lower::model::OutTy::OutCell>(t_p3).a0;
        return held_in(names_p0, value_tys_p1, home_p2, prism_rtl::deref(prism_rtl::deref(i_pc)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p3)) {
        auto&& ts_pd = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p3).a0;
        return fold(ts_pd, Array<Text>{}, [&](const Array<Text>& acc_pe, const crate::lower::model::OutTy& a_pf) { return crate::check::types::union_texts(acc_pe, held_in(names_p0, value_tys_p1, home_p2, a_pf)); });
    }
    {
        return Array<Text>{};
    }
}


/// NamedIn: fn [Text], Text, OutTy -> [Text]
Array<Text> named_in(const Array<Text>& names_p0, const Text& home_p1, const crate::lower::model::OutTy& t_p2) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p2)) {
        auto&& n_p3 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p2).a0;
        auto&& args_p4 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p2).a1;
        auto p_p5 = path_from(names_p0, home_p1, n_p3);
        auto own_p6 = crate::check::types::has_text(names_p0, parent_of(p_p5))
            ? Array(std::vector{parent_of(p_p5)})
            : Array<Text>{};
        return fold(args_p4, own_p6, [&](const Array<Text>& acc_p7, const crate::lower::model::OutTy& a_p8) { return crate::check::types::union_texts(acc_p7, named_in(names_p0, home_p1, a_p8)); });
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t_p2)) {
        auto&& i_p9 = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t_p2).a0;
        return named_in(names_p0, home_p1, prism_rtl::deref(prism_rtl::deref(i_p9)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p2)) {
        auto&& i_pa = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t_p2).a0;
        return named_in(names_p0, home_p1, prism_rtl::deref(prism_rtl::deref(i_pa)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutCell>(t_p2)) {
        auto&& i_pb = prism_rtl::as<crate::lower::model::OutTy::OutCell>(t_p2).a0;
        return named_in(names_p0, home_p1, prism_rtl::deref(prism_rtl::deref(i_pb)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutArray>(t_p2)) {
        auto&& i_pc = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t_p2).a0;
        return named_in(names_p0, home_p1, prism_rtl::deref(prism_rtl::deref(i_pc)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRc>(t_p2)) {
        auto&& i_pd = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t_p2).a0;
        return named_in(names_p0, home_p1, prism_rtl::deref(prism_rtl::deref(i_pd)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t_p2)) {
        auto&& i_pe = prism_rtl::as<crate::lower::model::OutTy::OutEvent>(t_p2).a0;
        return named_in(names_p0, home_p1, prism_rtl::deref(prism_rtl::deref(i_pe)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(t_p2)) {
        auto&& i_pf = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(t_p2).a0;
        return named_in(names_p0, home_p1, prism_rtl::deref(prism_rtl::deref(i_pf)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(t_p2)) {
        auto&& k_pg = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p2).a0;
        auto&& v_ph = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p2).a1;
        return crate::check::types::union_texts(named_in(names_p0, home_p1, prism_rtl::deref(prism_rtl::deref(k_pg))), named_in(names_p0, home_p1, prism_rtl::deref(prism_rtl::deref(v_ph))));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p2)) {
        auto&& ts_pi = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p2).a0;
        return fold(ts_pi, Array<Text>{}, [&](const Array<Text>& acc_pj, const crate::lower::model::OutTy& a_pk) { return crate::check::types::union_texts(acc_pj, named_in(names_p0, home_p1, a_pk)); });
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(t_p2)) {
        auto&& ps_pl = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p2).a0;
        auto&& r_pm = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p2).a1;
        return fold(ps_pl, named_in(names_p0, home_p1, prism_rtl::deref(prism_rtl::deref(r_pm))), [&](const Array<Text>& acc_pn, const crate::lower::model::OutTy& a_po) { return crate::check::types::union_texts(acc_pn, named_in(names_p0, home_p1, a_po)); });
    }
    {
        return Array<Text>{};
    }
}


/// PathFrom: fn [Text], Text, Text -> Text
Text path_from(const Array<Text>& names_p0, const Text& home_p1, const Text& n_p2) {
    auto q_p3 = crate::syntax::lexer::chars::drop_prefix(n_p2, Text::lit("crate::"));
    return starts_with_module(names_p0, q_p3)
        ? q_p3
        : home_p1 == Text::lit("") ? q_p3 : prism_rtl::cat(home_p1, "::", q_p3);
}


/// StartsWithModule: fn [Text], Text -> Bool
bool starts_with_module(const Array<Text>& names_p0, const Text& q_p1) {
    return fold(names_p0, false, [&](const bool& f_p2, const Text& n_p3) { return prism_rtl::deref(f_p2) || ((n_p3 != Text::lit("")) && crate::syntax::lexer::chars::has_prefix(q_p1, prism_rtl::cat(n_p3, "::"))); });
}


/// ParentOf: fn Text -> Text
Text parent_of(const Text& p_p0) {
    auto segs_p1 = split_on(p_p0, Text::lit("::"));
    return crate::syntax::lexer::chars::join(take(segs_p1, crate::syntax::lexer::chars::dec(len(segs_p1))), Text::lit("::"));
}


/// WithGroups: unbounded fn [ModDef] -> [ModDef]
Array<crate::lower::model::ModDef> with_groups(const Array<crate::lower::model::ModDef>& defs_p0) {
    auto edges_p1 = fold(defs_p0, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& m_p3, const crate::lower::model::ModDef& d_p4) { return insert(m_p3, prism_rtl::deref(d_p4).name, prism_rtl::deref(d_p4).complete); });
    auto reach_p2 = run_to_end(fold_job(defs_p0, Map<Text, Array<Text>>{}, ({
        auto edges_p1_1 = edges_p1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, crate::lower::model::ModDef>)>>(prism_rtl::rc([=, edges_p1_1 = std::move(edges_p1_1)](std::tuple<Map<Text, Array<Text>>, crate::lower::model::ModDef> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto edges_p1_1_2 = edges_p1_1;
            entered(once_job([=, edges_p1_1_2 = std::move(edges_p1_1_2)]() {
            return ({
                auto m_p5 = p0;
                auto d_p6 = p1;
                call_then(start_reached_by(edges_p1_1_2, Array(std::vector{prism_rtl::deref(d_p6).name}), Array<Text>{}), [=, m_p5 = std::move(m_p5)](Array<Text> reached_by_11263) { return prism_rtl::finished(insert(m_p5, prism_rtl::deref(d_p6).name, reached_by_11263)); });
            });
        }));
        });
    }));
    })));
    return each(defs_p0, [&](const crate::lower::model::ModDef& d_p7) {
        return ({
            auto mine_p8 = or_(crate::prelude::get(reach_p2, prism_rtl::deref(d_p7).name), Array<Text>{});
            ({
            crate::lower::model::ModDef this_ = d_p7;
            this_.types_with = filter(each(defs_p0, [&](const crate::lower::model::ModDef& o_p9) { return prism_rtl::deref(o_p9).name; }), [&](const Text& n_pa) { return (n_pa == prism_rtl::deref(d_p7).name) || (crate::check::types::has_text(mine_p8, n_pa) && crate::check::types::has_text(or_(crate::prelude::get(reach_p2, n_pa), Array<Text>{}), prism_rtl::deref(d_p7).name)); });
            (std::move(this_));
        });
        });
    });
}


prism_rtl::Turn<Array<crate::lower::model::ModDef>> WithGroups::cycle() const {
    const auto& defs_p0 = this->defs_p0;
    auto edges_p1 = fold(defs_p0, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& m_p3, const crate::lower::model::ModDef& d_p4) { return insert(m_p3, prism_rtl::deref(d_p4).name, prism_rtl::deref(d_p4).complete); });
    auto defs_p0_1 = defs_p0;
    return call_value(fold_job(defs_p0_1, Map<Text, Array<Text>>{}, ({
        auto edges_p1_2 = edges_p1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, crate::lower::model::ModDef>)>>(prism_rtl::rc([=, edges_p1_2 = std::move(edges_p1_2)](std::tuple<Map<Text, Array<Text>>, crate::lower::model::ModDef> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto edges_p1_2_3 = edges_p1_2;
            entered(once_job([=, edges_p1_2_3 = std::move(edges_p1_2_3)]() {
            return ({
                auto m_p5 = p0;
                auto d_p6 = p1;
                call_then(start_reached_by(edges_p1_2_3, Array(std::vector{prism_rtl::deref(d_p6).name}), Array<Text>{}), [=, m_p5 = std::move(m_p5)](Array<Text> reached_by_11263) { return prism_rtl::finished(insert(m_p5, prism_rtl::deref(d_p6).name, reached_by_11263)); });
            });
        }));
        });
    }));
    })), [=](Map<Text, Array<Text>> fold_11221) {
        return ({
            auto reach_p2 = fold_11221;
            (prism_rtl::finished(each(defs_p0_1, [&](const crate::lower::model::ModDef& d_p7) {
            return ({
                auto mine_p8 = or_(crate::prelude::get(reach_p2, prism_rtl::deref(d_p7).name), Array<Text>{});
                ({
                crate::lower::model::ModDef this_ = d_p7;
                this_.types_with = filter(each(defs_p0_1, [&](const crate::lower::model::ModDef& o_p9) { return prism_rtl::deref(o_p9).name; }), [&](const Text& n_pa) { return (n_pa == prism_rtl::deref(d_p7).name) || (crate::check::types::has_text(mine_p8, n_pa) && crate::check::types::has_text(or_(crate::prelude::get(reach_p2, n_pa), Array<Text>{}), prism_rtl::deref(d_p7).name)); });
                (std::move(this_));
            });
            });
        })));
        });
    });
}


/// `Start WithGroups, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::ModDef>> start_with_groups(Array<crate::lower::model::ModDef> defs_p0) {
    return prism_rtl::make_rc<WithGroups>(defs_p0);
}


/// ReachedBy: unbounded fn (Text ==> [Text]), [Text], [Text] -> [Text]
Array<Text> reached_by(const Map<Text, Array<Text>>& edges_p0, const Array<Text>& todo_p1, const Array<Text>& seen_p2) {
    auto&& _m = index(todo_p1, Nat(0u));
    if (prism_rtl::is_none(_m)) {
        return seen_p2;
    }
    if (prism_rtl::is_some(_m)) {
        auto&& m_p3 = prism_rtl::some_of(_m);
        return crate::check::types::has_text(seen_p2, m_p3)
            ? reached_by(edges_p0, drop(todo_p1, Nat(1u)), seen_p2)
            : reached_by(edges_p0, append(drop(todo_p1, Nat(1u)), or_(crate::prelude::get(edges_p0, m_p3), Array<Text>{})), crate::prelude::push(seen_p2, m_p3));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> ReachedBy::cycle() const {
    const auto& edges_p0 = this->edges_p0;
    const auto& todo_p1 = this->todo_p1;
    const auto& seen_p2 = this->seen_p2;
    return ({
        auto&& _m = index(todo_p1, Nat(0u));
        prism_rtl::is_none(_m) ? prism_rtl::finished(seen_p2)
        : prism_rtl::is_some(_m) ? ({
        auto&& m_p3 = prism_rtl::some_of(_m);
        crate::check::types::has_text(seen_p2, m_p3)
        ? prism_rtl::more(prism_rtl::rc(ReachedBy(edges_p0, drop(todo_p1, Nat(1u)), seen_p2)))
        : prism_rtl::more(prism_rtl::rc(ReachedBy(edges_p0, append(drop(todo_p1, Nat(1u)), or_(crate::prelude::get(edges_p0, m_p3), Array<Text>{})), crate::prelude::push(seen_p2, m_p3))));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ReachedBy, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_reached_by(Map<Text, Array<Text>> edges_p0, Array<Text> todo_p1, Array<Text> seen_p2) {
    return prism_rtl::make_rc<ReachedBy>(edges_p0, todo_p1, seen_p2);
}


/// NeededMods: unbounded fn G, Nat -> [Text]
Array<Text> needed_mods(const crate::check::env::G& g_p0, const Nat& shown_p1) {
    auto own_p2 = filter(keys(g_p0.mods), [&](const Text& m_p4) { return (or_(crate::prelude::get(g_p0.mods, m_p4), crate::check::env::reading::dummy_mod())->file < shown_p1) && (m_p4 != Text::lit("Prelude")); });
    auto grown_p3 = run_to_end(fold_job(crate::check::errors::range0(Nat(6u)), own_p2, ({
        auto g_p0_1 = g_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Nat>)>>(prism_rtl::rc([=, g_p0_1 = std::move(g_p0_1)](std::tuple<Array<Text>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0_1_2 = g_p0_1;
            entered(once_job([=, g_p0_1_2 = std::move(g_p0_1_2)]() {
            return ({
                auto acc_p5 = p0;
                static_cast<void>(p1);
                fold_job(acc_p5, acc_p5, ({
                auto g_p0_1_2_2 = g_p0_1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=, g_p0_1_2_2 = std::move(g_p0_1_2_2)](std::tuple<Array<Text>, Text> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto g_p0_1_2_2_2 = g_p0_1_2_2;
                    entered(once_job([=, g_p0_1_2_2_2 = std::move(g_p0_1_2_2_2)]() {
                    return ({
                        auto a_p6 = p0;
                        auto m_p7 = p1;
                        call_then(start_mod_refs(g_p0_1_2_2_2, m_p7), [=, a_p6 = std::move(a_p6)](Array<Text> mod_refs_12286) { return prism_rtl::finished(crate::check::types::union_texts(a_p6, mod_refs_12286)); });
                    });
                }));
                });
            })));
            }))->cycle();
            });
        }));
        });
    })));
    })));
    return filter(keys(g_p0.mods), [&](const Text& m_p8) { return (m_p8 != Text::lit("Prelude")) && crate::check::types::has_text(grown_p3, m_p8); });
}


prism_rtl::Turn<Array<Text>> NeededMods::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& shown_p1 = this->shown_p1;
    auto own_p2 = filter(keys(prism_rtl::deref(g_p0).mods), [&](const Text& m_p4) { return (or_(crate::prelude::get(prism_rtl::deref(g_p0).mods, m_p4), crate::check::env::reading::dummy_mod())->file < shown_p1) && (m_p4 != Text::lit("Prelude")); });
    auto g_p0_1 = g_p0;
    return call_value(fold_job(crate::check::errors::range0(Nat(6u)), own_p2, ({
        auto g_p0_1_2 = g_p0_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Nat>)>>(prism_rtl::rc([=, g_p0_1_2 = std::move(g_p0_1_2)](std::tuple<Array<Text>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0_1_2_2 = g_p0_1_2;
            entered(once_job([=, g_p0_1_2_2 = std::move(g_p0_1_2_2)]() {
            return ({
                auto acc_p5 = p0;
                static_cast<void>(p1);
                fold_job(acc_p5, acc_p5, ({
                auto g_p0_1_2_2_2 = g_p0_1_2_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=, g_p0_1_2_2_2 = std::move(g_p0_1_2_2_2)](std::tuple<Array<Text>, Text> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto g_p0_1_2_2_2_2 = g_p0_1_2_2_2;
                    entered(once_job([=, g_p0_1_2_2_2_2 = std::move(g_p0_1_2_2_2_2)]() {
                    return ({
                        auto a_p6 = p0;
                        auto m_p7 = p1;
                        call_then(start_mod_refs(g_p0_1_2_2_2_2, m_p7), [=, a_p6 = std::move(a_p6)](Array<Text> mod_refs_12286) { return prism_rtl::finished(crate::check::types::union_texts(a_p6, mod_refs_12286)); });
                    });
                }));
                });
            })));
            }))->cycle();
            });
        }));
        });
    })));
    })), [=](Array<Text> fold_12211) {
        return ({
            auto grown_p3 = fold_12211;
            (prism_rtl::finished(filter(keys(prism_rtl::deref(g_p0_1).mods), [&](const Text& m_p8) { return (m_p8 != Text::lit("Prelude")) && crate::check::types::has_text(grown_p3, m_p8); })));
        });
    });
}


/// `Start NeededMods, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_needed_mods(crate::check::env::G g_p0, Nat shown_p1) {
    return prism_rtl::make_rc<NeededMods>(g_p0, shown_p1);
}


/// ModRefs: unbounded fn G, Text -> [Text]
Array<Text> mod_refs(const crate::check::env::G& g_p0, const Text& m_p1) {
    auto&& _m = crate::prelude::get(g_p0.mods, m_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& info_p2 = prism_rtl::some_of(_m);
        auto used_p3 = each(prism_rtl::deref(info_p2).uses, [&](const std::tuple<Text, bool>& _p0) {
            auto&& u_p5 = std::get<0>(_p0);
            return u_p5;
        });
        auto fams_p4 = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(info_p2).tree).emit_row;
            if (prism_rtl::is_some(_m)) {
                auto&& rw_p6 = prism_rtl::some_of(_m);
                _v.set(fold(prism_rtl::deref(rw_p6).terms, Array<Text>{}, [&](const Array<Text>& acc_p7, const crate::syntax::RowTerm& t_p8) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Text>> _v;
                        if (prism_rtl::is<crate::syntax::RowTerm::RFamily>(t_p8)) {
                            auto&& q_p9 = prism_rtl::as<crate::syntax::RowTerm::RFamily>(t_p8).a0;
                            _v.set(crate::prelude::push(acc_p7, or_(crate::prelude::get(g_p0.fam_owner, crate::check::env::dotted(q_p9->path_)), crate::check::env::dotted(q_p9->path_))));
                            goto _done;
                        }
                        {
                            _v.set(acc_p7);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return filter(append(used_p3, fams_p4), [&](const Text& x_pa) { return crate::check::env::has_key(g_p0.mods, x_pa); });
    }
    if (prism_rtl::is_none(_m)) {
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> ModRefs::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& m_p1 = this->m_p1;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(g_p0).mods, m_p1);
        prism_rtl::is_some(_m) ? ({
        auto&& info_p2 = prism_rtl::some_of(_m);
        ({
        auto used_p3 = each(prism_rtl::deref(info_p2).uses, [&](const std::tuple<Text, bool>& _p0) {
            auto&& u_p5 = std::get<0>(_p0);
            return u_p5;
        });
        auto fams_p4 = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(info_p2).tree).emit_row;
            if (prism_rtl::is_some(_m)) {
                auto&& rw_p6 = prism_rtl::some_of(_m);
                _v.set(fold(prism_rtl::deref(rw_p6).terms, Array<Text>{}, [&](const Array<Text>& acc_p7, const crate::syntax::RowTerm& t_p8) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Text>> _v;
                        if (prism_rtl::is<crate::syntax::RowTerm::RFamily>(t_p8)) {
                            auto&& q_p9 = prism_rtl::as<crate::syntax::RowTerm::RFamily>(t_p8).a0;
                            _v.set(crate::prelude::push(acc_p7, or_(crate::prelude::get(prism_rtl::deref(g_p0).fam_owner, crate::check::env::dotted(q_p9->path_)), crate::check::env::dotted(q_p9->path_))));
                            goto _done;
                        }
                        {
                            _v.set(acc_p7);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        (prism_rtl::finished(filter(append(used_p3, fams_p4), [&](const Text& x_pa) { return crate::check::env::has_key(prism_rtl::deref(g_p0).mods, x_pa); })));
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ModRefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_mod_refs(crate::check::env::G g_p0, Text m_p1) {
    return prism_rtl::make_rc<ModRefs>(g_p0, m_p1);
}


/// RootWidgets: fn Lx -> [((Text, Bool))]
Array<std::tuple<Text, bool>> root_widgets(const crate::lower::Lx& lx_p0) {
    auto tested_p1 = fold(prism_rtl::deref(lx_p0.g).defs, Array<std::tuple<Text, bool>>{}, [&](const Array<std::tuple<Text, bool>>& acc_p3, const crate::check::env::Def& d_p4) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, bool>>> _v;
            auto&& _m = prism_rtl::deref(d_p4).body;
            if (prism_rtl::is<crate::check::env::DefBody::DbTest>(_m)) {
                auto&& t_p5 = prism_rtl::as<crate::check::env::DefBody::DbTest>(_m).a0;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<std::tuple<Text, bool>>> _v;
                    auto&& _m = blueprint_qk(in_module(lx_p0, d_p4->file, prism_rtl::deref(d_p4).home), prism_rtl::deref(t_p5).blueprint);
                    {
                        auto&& m13040_0 = _m;
                        if (m13040_0 == Text::lit("")) {
                            _v.set(acc_p3);
                            goto _done;
                        }
                    }
                    {
                        auto&& qk_p6 = _m;
                        _v.set(crate::check::types::has_text(each(acc_p3, [&](const std::tuple<Text, bool>& _p0) {
                            auto&& q_p7 = std::get<0>(_p0);
                            return q_p7;
                        }), qk_p6)
                            ? acc_p3
                            : crate::prelude::push(acc_p3, std::tuple{qk_p6, true}));
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(acc_p3);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto main_p2 = fold(prism_rtl::deref(lx_p0.g).defs, Array<std::tuple<Text, bool>>{}, [&](const Array<std::tuple<Text, bool>>& acc_p8, const crate::check::env::Def& d_p9) {
        return is_main(prism_rtl::deref(d_p9).qk)
            ? crate::prelude::push(acc_p8, std::tuple{prism_rtl::deref(d_p9).qk, false})
            : acc_p8;
    });
    return fold(main_p2, tested_p1, [&](const Array<std::tuple<Text, bool>>& acc_pa, const std::tuple<Text, bool>& _p1) {
        auto&& k_pb = std::get<0>(_p1);
        auto&& b_pc = std::get<1>(_p1);
        return crate::check::types::has_text(each(acc_pa, [&](const std::tuple<Text, bool>& _p0) {
            auto&& q_pd = std::get<0>(_p0);
            return q_pd;
        }), k_pb)
            ? acc_pa
            : crate::prelude::push(acc_pa, std::tuple{k_pb, prism_rtl::deref(b_pc)});
    });
}


/// IsMain: fn Text -> Bool
bool is_main(const Text& qk_p0) {
    return ((crate::lower::owner_of(qk_p0) == Text::lit("")) && (crate::lower::base(crate::check::types::bare_name(qk_p0)) == Text::lit("main"))) && crate::syntax::lexer::chars::has_prefix(crate::check::types::bare_name(qk_p0), Text::lit("@"));
}


/// BlueprintQk: fn Lx, Expr -> Text
Text blueprint_qk(const crate::lower::Lx& lx_p0, const crate::syntax::Expr& e_p1) {
    auto&& _m = prism_rtl::deref(e_p1.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c_p2 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        return blueprint_qk(lx_p0, prism_rtl::deref(prism_rtl::deref(c_p2)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p3 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return blueprint_qk(lx_p0, prism_rtl::deref(prism_rtl::deref(x_p3)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p4 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        auto&& _q_o5 = crate::check::env::names::resolve_value(lx_p0.g, lx_p0.home, n_p4);
        auto&& q_o5 = std::get<0>(_q_o5);
        return or_(q_o5, Text::lit(""));
    }
    {
        return Text::lit("");
    }
}


/// ValOf: fn Lx, Text -> ValInfo
crate::check::env::ValInfo val_of(const crate::lower::Lx& lx_p0, const Text& qk_p1) {
    auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g).vals, qk_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& v_p2 = prism_rtl::some_of(_m);
        return v_p2;
    }
    if (prism_rtl::is_none(_m)) {
        auto d_p3 = fold(prism_rtl::deref(lx_p0.g).defs, crate::check::env::decls::dummy_def(), [&](const crate::check::env::Def& found_p4, const crate::check::env::Def& df_p5) { return prism_rtl::deref(df_p5).qk == qk_p1 ? df_p5 : found_p4; });
        return crate::check::env::ValInfo{.qk = qk_p1, .scheme = crate::check::types::schemes::mono(crate::check::types::Ty(crate::check::types::Ty::TyErr{})), .sort = Text::lit("fn"), .has_sig = false, .home = prism_rtl::deref(d_p3).home, .file = d_p3->file, .span = prism_rtl::deref(d_p3).span};
    }
    prism_rtl::unreachable("no arm matched");
}


/// ProgDefOf: unbounded fn Lx, Text -> ProgDef
crate::lower::model::ProgDef prog_def_of(const crate::lower::Lx& lx_p0, const Text& qk_p1) {
    auto v_p2 = val_of(lx_p0, qk_p1);
    auto ptys_p3 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(v_p2).scheme).ty;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& ps_p9 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            _v.set(ps_p9);
            goto _done;
        }
        {
            _v.set(Array<crate::check::types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto lxm_p4 = in_module_at(lx_p0, v_p2->file, prism_rtl::deref(v_p2).home, Text::lit("\000main"sv));
    auto params_p5 = run_to_end(each_job(crate::check::errors::range0(len(ptys_p3)), ({
        auto lxm_p4_1 = lxm_p4;
        auto ptys_p3_2 = ptys_p3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::lower::model::OutTy>>(Nat)>>(prism_rtl::rc([=, lxm_p4_1 = std::move(lxm_p4_1), ptys_p3_2 = std::move(ptys_p3_2)](Nat p0) {
        return ({
            auto lxm_p4_1_3 = lxm_p4_1;
            auto ptys_p3_2_3 = ptys_p3_2;
            entered(once_job([=, lxm_p4_1_3 = std::move(lxm_p4_1_3), ptys_p3_2_3 = std::move(ptys_p3_2_3)]() {
            return ({
                auto i_pa = p0;
                call_then(crate::lower::types::start_out_ty_of(lxm_p4_1_3, crate::lower::types::peel(or_(index(ptys_p3_2_3, i_pa), crate::check::types::Ty(crate::check::types::Ty::TyErr{})))), [=](crate::lower::model::OutTy out_ty_of_14615) { return prism_rtl::finished(std::tuple{prism_rtl::cat("arg", i_pa), out_ty_of_14615}); });
            });
        }));
        });
    }));
    })));
    auto node_p6 = prism_rtl::cat(crate::lower::rust_mod_name(prism_rtl::deref(v_p2).home), "::", crate::lower::camel(crate::check::types::bare_name(qk_p1)));
    auto fams_p7 = prism_rtl::deref(prism_rtl::deref(or_(crate::prelude::get(prism_rtl::deref(lx_p0.g).mods, prism_rtl::deref(v_p2).home), crate::check::env::reading::dummy_mod())).emit_rw).fams;
    auto world_p8 = crate::check::types::has_text(fams_p7, Text::lit("Gui"))
        ? Text::lit("canvas")
        : crate::check::types::has_text(fams_p7, Text::lit("Ui"))
        ? Text::lit("none")
        : Text::lit("cli");
    return crate::lower::model::ProgDef{.name = prism_rtl::cat(crate::lower::camel(crate::check::types::bare_name(qk_p1)), "Program"), .prism = crate::syntax::lexer::chars::after_first(crate::check::types::bare_name(qk_p1)), .node_ = node_p6, .params = params_p5, .fallible = true, .world = world_p8};
}


prism_rtl::Turn<crate::lower::model::ProgDef> ProgDefOf::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& qk_p1 = this->qk_p1;
    auto v_p2 = val_of(lx_p0, qk_p1);
    auto ptys_p3 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(v_p2).scheme).ty;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& ps_p9 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            _v.set(ps_p9);
            goto _done;
        }
        {
            _v.set(Array<crate::check::types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto lxm_p4 = in_module_at(lx_p0, v_p2->file, prism_rtl::deref(v_p2).home, Text::lit("\000main"sv));
    auto lx_p0_1 = lx_p0;
    auto qk_p1_2 = qk_p1;
    return call_value(each_job(crate::check::errors::range0(len(ptys_p3)), ({
        auto lxm_p4_3 = lxm_p4;
        auto ptys_p3_4 = ptys_p3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::lower::model::OutTy>>(Nat)>>(prism_rtl::rc([=, lxm_p4_3 = std::move(lxm_p4_3), ptys_p3_4 = std::move(ptys_p3_4)](Nat p0) {
        return ({
            auto lxm_p4_3_5 = lxm_p4_3;
            auto ptys_p3_4_5 = ptys_p3_4;
            entered(once_job([=, lxm_p4_3_5 = std::move(lxm_p4_3_5), ptys_p3_4_5 = std::move(ptys_p3_4_5)]() {
            return ({
                auto i_pa = p0;
                call_then(crate::lower::types::start_out_ty_of(lxm_p4_3_5, crate::lower::types::peel(or_(index(ptys_p3_4_5, i_pa), crate::check::types::Ty(crate::check::types::Ty::TyErr{})))), [=](crate::lower::model::OutTy out_ty_of_14615) { return prism_rtl::finished(std::tuple{prism_rtl::cat("arg", i_pa), out_ty_of_14615}); });
            });
        }));
        });
    }));
    })), [=](Array<std::tuple<Text, crate::lower::model::OutTy>> each_14571) {
        return ({
            auto params_p5 = each_14571;
            auto node_p6 = prism_rtl::cat(crate::lower::rust_mod_name(prism_rtl::deref(v_p2).home), "::", crate::lower::camel(crate::check::types::bare_name(qk_p1_2)));
            auto fams_p7 = prism_rtl::deref(prism_rtl::deref(or_(crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0_1).g).mods, prism_rtl::deref(v_p2).home), crate::check::env::reading::dummy_mod())).emit_rw).fams;
            auto world_p8 = crate::check::types::has_text(fams_p7, Text::lit("Gui"))
                ? Text::lit("canvas")
                : crate::check::types::has_text(fams_p7, Text::lit("Ui"))
                ? Text::lit("none")
                : Text::lit("cli");
            (prism_rtl::finished(crate::lower::model::ProgDef{.name = prism_rtl::cat(crate::lower::camel(crate::check::types::bare_name(qk_p1_2)), "Program"), .prism = crate::syntax::lexer::chars::after_first(crate::check::types::bare_name(qk_p1_2)), .node_ = node_p6, .params = params_p5, .fallible = true, .world = world_p8}));
        });
    });
}


/// `Start ProgDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::ProgDef> start_prog_def_of(crate::lower::Lx lx_p0, Text qk_p1) {
    return prism_rtl::make_rc<ProgDefOf>(lx_p0, qk_p1);
}


/// JobRoots: unbounded fn Lx -> [Text]
Array<Text> job_roots(const crate::lower::Lx& lx_p0) {
    auto direct_p1 = run_to_end(fold_job(prism_rtl::deref(lx_p0.g).defs, Array<Text>{}, ({
        auto lx_p0_1 = lx_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::env::Def>)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1)](std::tuple<Array<Text>, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0_1_2 = lx_p0_1;
            entered(once_job([=, lx_p0_1_2 = std::move(lx_p0_1_2)]() {
            return ({
                auto acc_p2 = p0;
                auto d_p3 = p1;
                ({
                auto lxd_p4 = in_module(lx_p0_1_2, d_p3->file, prism_rtl::deref(d_p3).home);
                call_then(start_run_targets(lxd_p4, d_p3), [=](Array<Text> run_targets_15450) { return call_then(start_unbounded_values(lxd_p4, d_p3), [=](Array<Text> unbounded_values_15472) { return prism_rtl::finished(crate::check::types::union_texts(crate::check::types::union_texts(acc_p2, run_targets_15450), unbounded_values_15472)); }); });
            });
            });
        }));
        });
    })));
    })));
    return run_to_end(fold_job(crate::check::errors::range0(Nat(8u)), direct_p1, ({
        auto lx_p0_1 = lx_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Nat>)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1)](std::tuple<Array<Text>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0_1_2 = lx_p0_1;
            entered(once_job([=, lx_p0_1_2 = std::move(lx_p0_1_2)]() {
            return ({
                auto acc_p5 = p0;
                static_cast<void>(p1);
                fold_job(acc_p5, acc_p5, ({
                auto lx_p0_1_2_2 = lx_p0_1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=, lx_p0_1_2_2 = std::move(lx_p0_1_2_2)](std::tuple<Array<Text>, Text> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto lx_p0_1_2_2_2 = lx_p0_1_2_2;
                    entered(once_job([=, lx_p0_1_2_2_2 = std::move(lx_p0_1_2_2_2)]() {
                    return ({
                        auto a_p6 = p0;
                        auto qk_p7 = p1;
                        call_then(start_tail_targets(lx_p0_1_2_2_2, qk_p7), [=, a_p6 = std::move(a_p6)](Array<Text> tail_targets_15579) { return prism_rtl::finished(crate::check::types::union_texts(a_p6, tail_targets_15579)); });
                    });
                }));
                });
            })));
            }))->cycle();
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Text>> JobRoots::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    auto lx_p0_1 = lx_p0;
    return call_value(fold_job(prism_rtl::deref(prism_rtl::deref(lx_p0_1).g).defs, Array<Text>{}, ({
        auto lx_p0_1_2 = lx_p0_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::env::Def>)>>(prism_rtl::rc([=, lx_p0_1_2 = std::move(lx_p0_1_2)](std::tuple<Array<Text>, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0_1_2_2 = lx_p0_1_2;
            entered(once_job([=, lx_p0_1_2_2 = std::move(lx_p0_1_2_2)]() {
            return ({
                auto acc_p2 = p0;
                auto d_p3 = p1;
                ({
                auto lxd_p4 = in_module(lx_p0_1_2_2, d_p3->file, prism_rtl::deref(d_p3).home);
                call_then(start_run_targets(lxd_p4, d_p3), [=](Array<Text> run_targets_15450) { return call_then(start_unbounded_values(lxd_p4, d_p3), [=](Array<Text> unbounded_values_15472) { return prism_rtl::finished(crate::check::types::union_texts(crate::check::types::union_texts(acc_p2, run_targets_15450), unbounded_values_15472)); }); });
            });
            });
        }));
        });
    })));
    })), [=](Array<Text> fold_15335) {
        return ({
            auto direct_p1 = fold_15335;
            fold_job(crate::check::errors::range0(Nat(8u)), direct_p1, ({
            auto lx_p0_1_2 = lx_p0_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Nat>)>>(prism_rtl::rc([=, lx_p0_1_2 = std::move(lx_p0_1_2)](std::tuple<Array<Text>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_p0_1_2_2 = lx_p0_1_2;
                entered(once_job([=, lx_p0_1_2_2 = std::move(lx_p0_1_2_2)]() {
                return ({
                    auto acc_p5 = p0;
                    static_cast<void>(p1);
                    fold_job(acc_p5, acc_p5, ({
                    auto lx_p0_1_2_2_2 = lx_p0_1_2_2;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=, lx_p0_1_2_2_2 = std::move(lx_p0_1_2_2_2)](std::tuple<Array<Text>, Text> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto lx_p0_1_2_2_2_2 = lx_p0_1_2_2_2;
                        entered(once_job([=, lx_p0_1_2_2_2_2 = std::move(lx_p0_1_2_2_2_2)]() {
                        return ({
                            auto a_p6 = p0;
                            auto qk_p7 = p1;
                            call_then(start_tail_targets(lx_p0_1_2_2_2_2, qk_p7), [=, a_p6 = std::move(a_p6)](Array<Text> tail_targets_15579) { return prism_rtl::finished(crate::check::types::union_texts(a_p6, tail_targets_15579)); });
                        });
                    }));
                    });
                })));
                }))->cycle();
                });
            }));
            });
        })));
        }))->cycle();
        });
    });
}


/// `Start JobRoots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_job_roots(crate::lower::Lx lx_p0) {
    return prism_rtl::make_rc<JobRoots>(lx_p0);
}


/// UnboundedValues: unbounded fn Lx, Def -> [Text]
Array<Text> unbounded_values(const crate::lower::Lx& lx_p0, const crate::check::env::Def& d_p1) {
    auto es_p2 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
        auto&& _m = d_p1.body;
        if (prism_rtl::is<crate::check::env::DefBody::DbWidget>(_m)) {
            auto&& w_p4 = prism_rtl::as<crate::check::env::DefBody::DbWidget>(_m).a0;
            _v.set(crate::check::typed::print::block_exprs(prism_rtl::deref(w_p4).body));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
            auto&& cs_p5 = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
            _v.set(run_to_end(fold_job(cs_p5, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::FnClause> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc_p6 = p0;
                        auto c_p7 = p1;
                        call_then(crate::check::typed::print::start_body_exprs(prism_rtl::deref(c_p7).body), [=, acc_p6 = std::move(acc_p6)](Array<crate::syntax::Expr> body_exprs_15930) { return prism_rtl::finished(append(acc_p6, body_exprs_15930)); });
                    });
                }));
            })))));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbLet>(_m)) {
            auto&& l_p8 = prism_rtl::as<crate::check::env::DefBody::DbLet>(_m).a0;
            _v.set(crate::check::typed::print::exprs_in(l_p8->value));
            goto _done;
        }
        {
            _v.set(Array<crate::syntax::Expr>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto callees_p3 = fold(es_p2, Array<Text>{}, [&](const Array<Text>& acc_p9, const crate::syntax::Expr& e_pa) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(e_pa).kind);
            if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
                auto&& c_pb = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
                _v.set(crate::prelude::push(acc_p9, crate::lower::place_key(lx_p0, prism_rtl::deref(c_pb).span)));
                goto _done;
            }
            {
                _v.set(acc_p9);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return fold(es_p2, Array<Text>{}, [&](const Array<Text>& acc_pc, const crate::syntax::Expr& e_pd) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(e_pd).kind);
            if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                auto&& n_pe = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                _v.set(crate::check::types::has_text(callees_p3, crate::lower::place_key(lx_p0, prism_rtl::deref(e_pd).span))
                    ? acc_pc
                    : ({
                    auto&& _q_of = crate::check::env::names::resolve_value(lx_p0.g, lx_p0.home, n_pe);
                    auto&& q_of = std::get<0>(_q_of);
                    ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    if (prism_rtl::is_some(q_of)) {
                        auto&& q_pg = prism_rtl::some_of(q_of);
                        _v.set(is_unbounded(lx_p0, q_pg)
                            ? crate::check::types::add_text(acc_pc, q_pg)
                            : acc_pc);
                        goto _done;
                    }
                    if (prism_rtl::is_none(q_of)) {
                        _v.set(acc_pc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                }));
                goto _done;
            }
            {
                _v.set(acc_pc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Array<Text>> UnboundedValues::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& d_p1 = this->d_p1;
    auto es_p2 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
        auto&& _m = prism_rtl::deref(d_p1).body;
        if (prism_rtl::is<crate::check::env::DefBody::DbWidget>(_m)) {
            auto&& w_p4 = prism_rtl::as<crate::check::env::DefBody::DbWidget>(_m).a0;
            _v.set(crate::check::typed::print::block_exprs(prism_rtl::deref(w_p4).body));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
            auto&& cs_p5 = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
            _v.set(run_to_end(fold_job(cs_p5, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::FnClause> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc_p6 = p0;
                        auto c_p7 = p1;
                        call_then(crate::check::typed::print::start_body_exprs(prism_rtl::deref(c_p7).body), [=, acc_p6 = std::move(acc_p6)](Array<crate::syntax::Expr> body_exprs_15930) { return prism_rtl::finished(append(acc_p6, body_exprs_15930)); });
                    });
                }));
            })))));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbLet>(_m)) {
            auto&& l_p8 = prism_rtl::as<crate::check::env::DefBody::DbLet>(_m).a0;
            _v.set(crate::check::typed::print::exprs_in(l_p8->value));
            goto _done;
        }
        {
            _v.set(Array<crate::syntax::Expr>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto callees_p3 = fold(es_p2, Array<Text>{}, [&](const Array<Text>& acc_p9, const crate::syntax::Expr& e_pa) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(e_pa).kind);
            if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
                auto&& c_pb = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
                _v.set(crate::prelude::push(acc_p9, crate::lower::place_key(lx_p0, prism_rtl::deref(c_pb).span)));
                goto _done;
            }
            {
                _v.set(acc_p9);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return prism_rtl::finished(fold(es_p2, Array<Text>{}, [&](const Array<Text>& acc_pc, const crate::syntax::Expr& e_pd) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(e_pd).kind);
            if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                auto&& n_pe = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                _v.set(crate::check::types::has_text(callees_p3, crate::lower::place_key(lx_p0, prism_rtl::deref(e_pd).span))
                    ? acc_pc
                    : ({
                    auto&& _q_of = crate::check::env::names::resolve_value(prism_rtl::deref(lx_p0).g, prism_rtl::deref(lx_p0).home, n_pe);
                    auto&& q_of = std::get<0>(_q_of);
                    ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    if (prism_rtl::is_some(q_of)) {
                        auto&& q_pg = prism_rtl::some_of(q_of);
                        _v.set(is_unbounded(lx_p0, q_pg)
                            ? crate::check::types::add_text(acc_pc, q_pg)
                            : acc_pc);
                        goto _done;
                    }
                    if (prism_rtl::is_none(q_of)) {
                        _v.set(acc_pc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                }));
                goto _done;
            }
            {
                _v.set(acc_pc);
                goto _done;
            }
        _done:
            _v.take();
        });
    }));
}


/// `Start UnboundedValues, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_unbounded_values(crate::lower::Lx lx_p0, crate::check::env::Def d_p1) {
    return prism_rtl::make_rc<UnboundedValues>(lx_p0, d_p1);
}


/// InPrelude: fn Lx, Text -> Bool
bool in_prelude(const crate::lower::Lx& lx_p0, const Text& q_p1) {
    auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g).vals, q_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& v_p2 = prism_rtl::some_of(_m);
        return prism_rtl::deref(v_p2).home == Text::lit("Prelude");
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// IsColorPoly: fn Lx, Text -> Bool
bool is_color_poly(const crate::lower::Lx& lx_p0, const Text& q_p1) {
    auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g).vals, q_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& v_p2 = prism_rtl::some_of(_m);
        auto&& _m = prism_rtl::deref(prism_rtl::deref(v_p2).scheme).ty;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CQ>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0)) {
            return true;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CRigid>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0)) {
            return true;
        }
        {
            return false;
        }
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// EntersAtOnce: fn Lx, Text, [Arg] -> Bool
bool enters_at_once(const crate::lower::Lx& lx_p0, const Text& q_p1, const Array<crate::syntax::Arg>& args_p2) {
    return is_color_poly(lx_p0, q_p1) && (!fold(args_p2, false, [&](const bool& seen_p3, const crate::syntax::Arg& a_p4) { return prism_rtl::deref(seen_p3) || is_unbounded_arg(lx_p0, a_p4); }));
}


/// IsUnboundedArg: fn Lx, Arg -> Bool
bool is_unbounded_arg(const crate::lower::Lx& lx_p0, const crate::syntax::Arg& a_p1) {
    auto&& _m = crate::lower::types::peel(crate::lower::type_at(lx_p0, prism_rtl::deref(a_p1.value).span));
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CUnbound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0)) {
        return true;
    }
    {
        return false;
    }
}


/// IsUnbounded: fn Lx, Text -> Bool
bool is_unbounded(const crate::lower::Lx& lx_p0, const Text& q_p1) {
    auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g).vals, q_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& v_p2 = prism_rtl::some_of(_m);
        auto&& _m = prism_rtl::deref(prism_rtl::deref(v_p2).scheme).ty;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CBound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0)) {
            return false;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            return true;
        }
        {
            return false;
        }
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// RunTargets: unbounded fn Lx, Def -> [Text]
Array<Text> run_targets(const crate::lower::Lx& lx_p0, const crate::check::env::Def& d_p1) {
    auto es_p2 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
        auto&& _m = d_p1.body;
        if (prism_rtl::is<crate::check::env::DefBody::DbWidget>(_m)) {
            auto&& w_p3 = prism_rtl::as<crate::check::env::DefBody::DbWidget>(_m).a0;
            _v.set(crate::check::typed::print::block_exprs(prism_rtl::deref(w_p3).body));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
            auto&& cs_p4 = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
            _v.set(run_to_end(fold_job(cs_p4, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::FnClause> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc_p5 = p0;
                        auto c_p6 = p1;
                        call_then(crate::check::typed::print::start_body_exprs(prism_rtl::deref(c_p6).body), [=, acc_p5 = std::move(acc_p5)](Array<crate::syntax::Expr> body_exprs_18159) { return prism_rtl::finished(append(acc_p5, body_exprs_18159)); });
                    });
                }));
            })))));
            goto _done;
        }
        {
            _v.set(Array<crate::syntax::Expr>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return fold(es_p2, Array<Text>{}, [&](const Array<Text>& acc_p7, const crate::syntax::Expr& e_p8) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p8).kind);
            if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
                auto&& c_p9 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
                auto&& args_pa = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
                _v.set(blueprint_qk(lx_p0, prism_rtl::deref(prism_rtl::deref(c_p9))) == Text::lit("Prelude.@Run")
                    ? ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    auto&& _m = index(args_pa, Nat(0u));
                    if (prism_rtl::is_some(_m)) {
                        auto&& a_pb = prism_rtl::some_of(_m);
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Array<Text>> _v;
                            auto&& _m = prism_rtl::deref(prism_rtl::deref(a_pb->value).kind);
                            if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                                auto&& n_pc = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                                _v.set(({
                                    auto&& _q_od = crate::check::env::names::resolve_value(lx_p0.g, lx_p0.home, n_pc);
                                    auto&& q_od = std::get<0>(_q_od);
                                    ({
                                    __label__ _done;
                                    prism_rtl::Slot<Array<Text>> _v;
                                    if (prism_rtl::is_some(q_od)) {
                                        auto&& q_pe = prism_rtl::some_of(q_od);
                                        _v.set(crate::check::types::add_text(acc_p7, q_pe));
                                        goto _done;
                                    }
                                    if (prism_rtl::is_none(q_od)) {
                                        _v.set(acc_p7);
                                        goto _done;
                                    }
                                    prism_rtl::unreachable("no arm matched");
                                _done:
                                    _v.take();
                                });
                                }));
                                goto _done;
                            }
                            {
                                _v.set(acc_p7);
                                goto _done;
                            }
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc_p7);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                })
                    : acc_p7);
                goto _done;
            }
            {
                _v.set(acc_p7);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Array<Text>> RunTargets::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& d_p1 = this->d_p1;
    auto es_p2 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
        auto&& _m = prism_rtl::deref(d_p1).body;
        if (prism_rtl::is<crate::check::env::DefBody::DbWidget>(_m)) {
            auto&& w_p3 = prism_rtl::as<crate::check::env::DefBody::DbWidget>(_m).a0;
            _v.set(crate::check::typed::print::block_exprs(prism_rtl::deref(w_p3).body));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
            auto&& cs_p4 = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
            _v.set(run_to_end(fold_job(cs_p4, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::FnClause> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc_p5 = p0;
                        auto c_p6 = p1;
                        call_then(crate::check::typed::print::start_body_exprs(prism_rtl::deref(c_p6).body), [=, acc_p5 = std::move(acc_p5)](Array<crate::syntax::Expr> body_exprs_18159) { return prism_rtl::finished(append(acc_p5, body_exprs_18159)); });
                    });
                }));
            })))));
            goto _done;
        }
        {
            _v.set(Array<crate::syntax::Expr>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return prism_rtl::finished(fold(es_p2, Array<Text>{}, [&](const Array<Text>& acc_p7, const crate::syntax::Expr& e_p8) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p8).kind);
            if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
                auto&& c_p9 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
                auto&& args_pa = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
                _v.set(blueprint_qk(lx_p0, prism_rtl::deref(prism_rtl::deref(c_p9))) == Text::lit("Prelude.@Run")
                    ? ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    auto&& _m = index(args_pa, Nat(0u));
                    if (prism_rtl::is_some(_m)) {
                        auto&& a_pb = prism_rtl::some_of(_m);
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Array<Text>> _v;
                            auto&& _m = prism_rtl::deref(prism_rtl::deref(a_pb->value).kind);
                            if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                                auto&& n_pc = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                                _v.set(({
                                    auto&& _q_od = crate::check::env::names::resolve_value(prism_rtl::deref(lx_p0).g, prism_rtl::deref(lx_p0).home, n_pc);
                                    auto&& q_od = std::get<0>(_q_od);
                                    ({
                                    __label__ _done;
                                    prism_rtl::Slot<Array<Text>> _v;
                                    if (prism_rtl::is_some(q_od)) {
                                        auto&& q_pe = prism_rtl::some_of(q_od);
                                        _v.set(crate::check::types::add_text(acc_p7, q_pe));
                                        goto _done;
                                    }
                                    if (prism_rtl::is_none(q_od)) {
                                        _v.set(acc_p7);
                                        goto _done;
                                    }
                                    prism_rtl::unreachable("no arm matched");
                                _done:
                                    _v.take();
                                });
                                }));
                                goto _done;
                            }
                            {
                                _v.set(acc_p7);
                                goto _done;
                            }
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc_p7);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                })
                    : acc_p7);
                goto _done;
            }
            {
                _v.set(acc_p7);
                goto _done;
            }
        _done:
            _v.take();
        });
    }));
}


/// `Start RunTargets, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_run_targets(crate::lower::Lx lx_p0, crate::check::env::Def d_p1) {
    return prism_rtl::make_rc<RunTargets>(lx_p0, d_p1);
}


/// TailTargets: unbounded fn Lx, Text -> [Text]
Array<Text> tail_targets(const crate::lower::Lx& lx_p0, const Text& qk_p1) {
    auto v_p2 = or_(crate::prelude::get(prism_rtl::deref(lx_p0.g).vals, qk_p1), crate::check::env::builtin(qk_p1, crate::check::types::schemes::mono(crate::check::types::Ty(crate::check::types::Ty::TyErr{}))));
    auto lxm_p3 = in_module(lx_p0, v_p2->file, prism_rtl::deref(v_p2).home);
    return run_to_end(fold_job(crate::lower::jobs::clauses_of(lx_p0.g, qk_p1), Array<Text>{}, ({
        auto lxm_p3_1 = lxm_p3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, lxm_p3_1 = std::move(lxm_p3_1)](std::tuple<Array<Text>, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lxm_p3_1_2 = lxm_p3_1;
            entered(once_job([=, lxm_p3_1_2 = std::move(lxm_p3_1_2)]() {
            return ({
                auto acc_p4 = p0;
                auto c_p5 = p1;
                call_then(start_tails_of_body(lxm_p3_1_2, prism_rtl::deref(c_p5).body), [=, acc_p4 = std::move(acc_p4)](Array<Text> tails_of_body_19038) { return prism_rtl::finished(crate::check::types::union_texts(acc_p4, tails_of_body_19038)); });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Text>> TailTargets::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& qk_p1 = this->qk_p1;
    auto v_p2 = or_(crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0).g).vals, qk_p1), crate::check::env::builtin(qk_p1, crate::check::types::schemes::mono(crate::check::types::Ty(crate::check::types::Ty::TyErr{}))));
    auto lxm_p3 = in_module(lx_p0, v_p2->file, prism_rtl::deref(v_p2).home);
    return fold_job(crate::lower::jobs::clauses_of(prism_rtl::deref(lx_p0).g, qk_p1), Array<Text>{}, ({
        auto lxm_p3_1 = lxm_p3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, lxm_p3_1 = std::move(lxm_p3_1)](std::tuple<Array<Text>, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lxm_p3_1_2 = lxm_p3_1;
            entered(once_job([=, lxm_p3_1_2 = std::move(lxm_p3_1_2)]() {
            return ({
                auto acc_p4 = p0;
                auto c_p5 = p1;
                call_then(start_tails_of_body(lxm_p3_1_2, prism_rtl::deref(c_p5).body), [=, acc_p4 = std::move(acc_p4)](Array<Text> tails_of_body_19038) { return prism_rtl::finished(crate::check::types::union_texts(acc_p4, tails_of_body_19038)); });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start TailTargets, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_tail_targets(crate::lower::Lx lx_p0, Text qk_p1) {
    return prism_rtl::make_rc<TailTargets>(lx_p0, qk_p1);
}


/// TailsOfBody: unbounded fn Lx, FnBody -> [Text]
Array<Text> tails_of_body(const crate::lower::Lx& lx_p0, const crate::syntax::decls::FnBody& body_p1) {
    return fold(crate::check::typed::print::body_exprs(body_p1), Array<Text>{}, [&](const Array<Text>& acc_p2, const crate::syntax::Expr& e_p3) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p3).kind);
            if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
                auto&& c_p4 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
                _v.set(({
                    auto q_p5 = blueprint_qk(lx_p0, prism_rtl::deref(prism_rtl::deref(c_p4)));
                    ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g).vals, q_p5);
                    if (prism_rtl::is_some(_m)) {
                        auto&& v_p6 = prism_rtl::some_of(_m);
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Array<Text>> _v;
                            auto&& _m = prism_rtl::deref(prism_rtl::deref(v_p6).scheme).ty;
                            if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CBound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0)) {
                                _v.set(acc_p2);
                                goto _done;
                            }
                            if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
                                _v.set(crate::check::types::add_text(acc_p2, q_p5));
                                goto _done;
                            }
                            {
                                _v.set(acc_p2);
                                goto _done;
                            }
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc_p2);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                }));
                goto _done;
            }
            {
                _v.set(acc_p2);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Array<Text>> TailsOfBody::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& body_p1 = this->body_p1;
    auto body_p1_1 = body_p1;
    auto lx_p0_2 = lx_p0;
    return call_then(crate::check::typed::print::start_body_exprs(body_p1_1), [=](Array<crate::syntax::Expr> body_exprs_19143) {
        return prism_rtl::finished(fold(body_exprs_19143, Array<Text>{}, [&](const Array<Text>& acc_p2, const crate::syntax::Expr& e_p3) {
            return ({
                __label__ _done;
                prism_rtl::Slot<Array<Text>> _v;
                auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p3).kind);
                if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
                    auto&& c_p4 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
                    _v.set(({
                        auto q_p5 = blueprint_qk(lx_p0_2, prism_rtl::deref(prism_rtl::deref(c_p4)));
                        ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Text>> _v;
                        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0_2).g).vals, q_p5);
                        if (prism_rtl::is_some(_m)) {
                            auto&& v_p6 = prism_rtl::some_of(_m);
                            _v.set(({
                                __label__ _done;
                                prism_rtl::Slot<Array<Text>> _v;
                                auto&& _m = prism_rtl::deref(prism_rtl::deref(v_p6).scheme).ty;
                                if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CBound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0)) {
                                    _v.set(acc_p2);
                                    goto _done;
                                }
                                if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
                                    _v.set(crate::check::types::add_text(acc_p2, q_p5));
                                    goto _done;
                                }
                                {
                                    _v.set(acc_p2);
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(acc_p2);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    }));
                    goto _done;
                }
                {
                    _v.set(acc_p2);
                    goto _done;
                }
            _done:
                _v.take();
            });
        }));
    });
}


/// `Start TailsOfBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_tails_of_body(crate::lower::Lx lx_p0, crate::syntax::decls::FnBody body_p1) {
    return prism_rtl::make_rc<TailsOfBody>(lx_p0, body_p1);
}


/// ModDefOf: unbounded fn Lx, Text, [((Text, Bool))], ModInfo, [Text] -> ModDef
crate::lower::model::ModDef mod_def_of(const crate::lower::Lx& lx0_p0, const Text& m_p1, const Array<std::tuple<Text, bool>>& roots_p2, const crate::check::env::ModInfo& info_p3, const Array<Text>& mods_p4) {
    auto lx_p5 = in_module(lx0_p0, info_p3.file, m_p1);
    auto path_p6 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(prism_rtl::deref(prism_rtl::deref(lx_p5).g).srcs, info_p3.file);
        if (prism_rtl::is_some(_m)) {
            auto&& src_pd = prism_rtl::some_of(_m);
            _v.set(src_pd->path_);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto types_p7 = run_to_end(fold_job(values(prism_rtl::deref(prism_rtl::deref(lx_p5).g).types), Array<crate::lower::model::Item>{}, ({
        auto m_p1_1 = m_p1;
        auto lx_p5_2 = lx_p5;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Item>>(std::tuple<Array<crate::lower::model::Item>, crate::check::env::TyInfo>)>>(prism_rtl::rc([=, m_p1_1 = std::move(m_p1_1), lx_p5_2 = std::move(lx_p5_2)](std::tuple<Array<crate::lower::model::Item>, crate::check::env::TyInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_p1_1_3 = m_p1_1;
            auto lx_p5_2_3 = lx_p5_2;
            entered(once_job([=, m_p1_1_3 = std::move(m_p1_1_3), lx_p5_2_3 = std::move(lx_p5_2_3)]() {
            return ({
                auto acc_pe = p0;
                auto ti_pf = p1;
                (prism_rtl::deref(ti_pf).home == m_p1_1_3
                ? call_then(start_ty_defs(lx_p5_2_3, ti_pf), [=](Array<crate::lower::model::Item> ty_defs_19868) { return prism_rtl::finished(append(acc_pe, ty_defs_19868)); })
                : prism_rtl::finished(acc_pe));
            });
        }));
        });
    })));
    })));
    auto tags_p8 = run_to_end(fold_job(values(prism_rtl::deref(prism_rtl::deref(lx_p5).g).tags), Array<crate::lower::model::Item>{}, ({
        auto m_p1_1 = m_p1;
        auto lx_p5_2 = lx_p5;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Item>>(std::tuple<Array<crate::lower::model::Item>, crate::check::env::TagInfo>)>>(prism_rtl::rc([=, m_p1_1 = std::move(m_p1_1), lx_p5_2 = std::move(lx_p5_2)](std::tuple<Array<crate::lower::model::Item>, crate::check::env::TagInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_p1_1_3 = m_p1_1;
            auto lx_p5_2_3 = lx_p5_2;
            entered(once_job([=, m_p1_1_3 = std::move(m_p1_1_3), lx_p5_2_3 = std::move(lx_p5_2_3)]() {
            return ({
                auto acc_pg = p0;
                auto tg_ph = p1;
                (prism_rtl::deref(tg_ph).home == m_p1_1_3) && (prism_rtl::deref(tg_ph).kind != Text::lit("Prelude.Fault"))
                ? call_then(start_tag_def_of(lx_p5_2_3, tg_ph), [=](crate::lower::model::TagDef tag_def_of_20016) { return prism_rtl::finished(crate::prelude::push(acc_pg, crate::lower::model::Item(crate::lower::model::Item::ItTag{tag_def_of_20016}))); })
                : prism_rtl::finished(acc_pg);
            });
        }));
        });
    })));
    })));
    auto defs_p9 = run_to_end(fold_job(prism_rtl::deref(prism_rtl::deref(lx_p5).g).defs, Array<crate::lower::model::Item>{}, ({
        auto m_p1_1 = m_p1;
        auto lx_p5_2 = lx_p5;
        auto roots_p2_3 = roots_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Item>>(std::tuple<Array<crate::lower::model::Item>, crate::check::env::Def>)>>(prism_rtl::rc([=, m_p1_1 = std::move(m_p1_1), lx_p5_2 = std::move(lx_p5_2), roots_p2_3 = std::move(roots_p2_3)](std::tuple<Array<crate::lower::model::Item>, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_p1_1_4 = m_p1_1;
            auto lx_p5_2_4 = lx_p5_2;
            auto roots_p2_3_4 = roots_p2_3;
            entered(once_job([=, m_p1_1_4 = std::move(m_p1_1_4), lx_p5_2_4 = std::move(lx_p5_2_4), roots_p2_3_4 = std::move(roots_p2_3_4)]() {
            return ({
                auto acc_pi = p0;
                auto d_pj = p1;
                (prism_rtl::deref(d_pj).home == m_p1_1_4
                ? call_then(start_def_items(in_module(lx_p5_2_4, d_pj->file, m_p1_1_4), d_pj, roots_p2_3_4), [=](Array<crate::lower::model::Item> def_items_20120) { return prism_rtl::finished(append(acc_pi, def_items_20120)); })
                : prism_rtl::finished(acc_pi));
            });
        }));
        });
    })));
    })));
    auto traits_pa = run_to_end(fold_job(values(prism_rtl::deref(prism_rtl::deref(lx_p5).g).traits), Array<crate::lower::model::Item>{}, ({
        auto m_p1_1 = m_p1;
        auto lx_p5_2 = lx_p5;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Item>>(std::tuple<Array<crate::lower::model::Item>, crate::check::env::TraitInfo>)>>(prism_rtl::rc([=, m_p1_1 = std::move(m_p1_1), lx_p5_2 = std::move(lx_p5_2)](std::tuple<Array<crate::lower::model::Item>, crate::check::env::TraitInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_p1_1_3 = m_p1_1;
            auto lx_p5_2_3 = lx_p5_2;
            entered(once_job([=, m_p1_1_3 = std::move(m_p1_1_3), lx_p5_2_3 = std::move(lx_p5_2_3)]() {
            return ({
                auto acc_pk = p0;
                auto tr_pl = p1;
                (prism_rtl::deref(tr_pl).home == m_p1_1_3
                ? call_then(crate::lower::functions::start_trait_def_of(lx_p5_2_3, tr_pl), [=](crate::lower::model::TraitDef trait_def_of_20273) { return prism_rtl::finished(crate::prelude::push(acc_pk, crate::lower::model::Item(crate::lower::model::Item::ItTrait{trait_def_of_20273}))); })
                : prism_rtl::finished(acc_pk));
            });
        }));
        });
    })));
    })));
    auto impls_pb = run_to_end(fold_job(values(prism_rtl::deref(prism_rtl::deref(lx_p5).g).impls), Array<crate::lower::model::Item>{}, ({
        auto m_p1_1 = m_p1;
        auto lx_p5_2 = lx_p5;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Item>>(std::tuple<Array<crate::lower::model::Item>, Array<crate::check::env::ImplInfo>>)>>(prism_rtl::rc([=, m_p1_1 = std::move(m_p1_1), lx_p5_2 = std::move(lx_p5_2)](std::tuple<Array<crate::lower::model::Item>, Array<crate::check::env::ImplInfo>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_p1_1_3 = m_p1_1;
            auto lx_p5_2_3 = lx_p5_2;
            entered(once_job([=, m_p1_1_3 = std::move(m_p1_1_3), lx_p5_2_3 = std::move(lx_p5_2_3)]() {
            return ({
                auto acc_pm = p0;
                auto ims_pn = p1;
                fold_job(ims_pn, acc_pm, ({
                auto m_p1_1_3_3 = m_p1_1_3;
                auto lx_p5_2_3_3 = lx_p5_2_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Item>>(std::tuple<Array<crate::lower::model::Item>, crate::check::env::ImplInfo>)>>(prism_rtl::rc([=, m_p1_1_3_3 = std::move(m_p1_1_3_3), lx_p5_2_3_3 = std::move(lx_p5_2_3_3)](std::tuple<Array<crate::lower::model::Item>, crate::check::env::ImplInfo> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto m_p1_1_3_3_3 = m_p1_1_3_3;
                    auto lx_p5_2_3_3_3 = lx_p5_2_3_3;
                    entered(once_job([=, m_p1_1_3_3_3 = std::move(m_p1_1_3_3_3), lx_p5_2_3_3_3 = std::move(lx_p5_2_3_3_3)]() {
                    return ({
                        auto a_po = p0;
                        auto im_pp = p1;
                        (prism_rtl::deref(im_pp).home == m_p1_1_3_3_3) && (!prism_rtl::deref(im_pp).derived)
                        ? call_then(crate::lower::functions::start_impl_def_of(in_module(lx_p5_2_3_3_3, im_pp->file, m_p1_1_3_3_3), im_pp), [=](crate::lower::model::ImplDef impl_def_of_20440) { return prism_rtl::finished(crate::prelude::push(a_po, crate::lower::model::Item(crate::lower::model::Item::ItImpl{impl_def_of_20440}))); })
                        : prism_rtl::finished(a_po);
                    });
                }));
                });
            })));
            }))->cycle();
            });
        }));
        });
    })));
    })));
    auto uses_pc = filter(each(mods_p4, [&](const Text& o_pq) { return crate::lower::rust_mod_name(o_pq); }), [&](const Text& o_pr) { return o_pr != crate::lower::rust_mod_name(m_p1); });
    return crate::lower::model::ModDef{.name = crate::lower::rust_mod_name(m_p1), .prism = m_p1, .path_ = path_p6, .uses = uses_pc, .complete = Array<Text>{}, .declared = Array<Text>{}, .types_with = Array<Text>{}, .items = append(append(append(append(types_p7, tags_p8), traits_pa), impls_pb), defs_p9)};
}


prism_rtl::Turn<crate::lower::model::ModDef> ModDefOf::cycle() const {
    const auto& lx0_p0 = this->lx0_p0;
    const auto& m_p1 = this->m_p1;
    const auto& roots_p2 = this->roots_p2;
    const auto& info_p3 = this->info_p3;
    const auto& mods_p4 = this->mods_p4;
    auto lx_p5 = in_module(lx0_p0, info_p3->file, m_p1);
    auto path_p6 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(prism_rtl::deref(prism_rtl::deref(lx_p5).g).srcs, info_p3->file);
        if (prism_rtl::is_some(_m)) {
            auto&& src_pd = prism_rtl::some_of(_m);
            _v.set(src_pd->path_);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto m_p1_1 = m_p1;
    auto mods_p4_2 = mods_p4;
    auto roots_p2_3 = roots_p2;
    return call_value(fold_job(values(prism_rtl::deref(prism_rtl::deref(lx_p5).g).types), Array<crate::lower::model::Item>{}, ({
        auto m_p1_1_4 = m_p1_1;
        auto lx_p5_4 = lx_p5;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Item>>(std::tuple<Array<crate::lower::model::Item>, crate::check::env::TyInfo>)>>(prism_rtl::rc([=, m_p1_1_4 = std::move(m_p1_1_4), lx_p5_4 = std::move(lx_p5_4)](std::tuple<Array<crate::lower::model::Item>, crate::check::env::TyInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_p1_1_4_5 = m_p1_1_4;
            auto lx_p5_4_5 = lx_p5_4;
            entered(once_job([=, m_p1_1_4_5 = std::move(m_p1_1_4_5), lx_p5_4_5 = std::move(lx_p5_4_5)]() {
            return ({
                auto acc_pe = p0;
                auto ti_pf = p1;
                (prism_rtl::deref(ti_pf).home == m_p1_1_4_5
                ? call_then(start_ty_defs(lx_p5_4_5, ti_pf), [=](Array<crate::lower::model::Item> ty_defs_19868) { return prism_rtl::finished(append(acc_pe, ty_defs_19868)); })
                : prism_rtl::finished(acc_pe));
            });
        }));
        });
    })));
    })), [=](Array<crate::lower::model::Item> fold_19795) {
        return ({
            auto types_p7 = fold_19795;
            call_value(fold_job(values(prism_rtl::deref(prism_rtl::deref(lx_p5).g).tags), Array<crate::lower::model::Item>{}, ({
            auto m_p1_1_4 = m_p1_1;
            auto lx_p5_4 = lx_p5;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Item>>(std::tuple<Array<crate::lower::model::Item>, crate::check::env::TagInfo>)>>(prism_rtl::rc([=, m_p1_1_4 = std::move(m_p1_1_4), lx_p5_4 = std::move(lx_p5_4)](std::tuple<Array<crate::lower::model::Item>, crate::check::env::TagInfo> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto m_p1_1_4_5 = m_p1_1_4;
                auto lx_p5_4_5 = lx_p5_4;
                entered(once_job([=, m_p1_1_4_5 = std::move(m_p1_1_4_5), lx_p5_4_5 = std::move(lx_p5_4_5)]() {
                return ({
                    auto acc_pg = p0;
                    auto tg_ph = p1;
                    (prism_rtl::deref(tg_ph).home == m_p1_1_4_5) && (prism_rtl::deref(tg_ph).kind != Text::lit("Prelude.Fault"))
                    ? call_then(start_tag_def_of(lx_p5_4_5, tg_ph), [=](crate::lower::model::TagDef tag_def_of_20016) { return prism_rtl::finished(crate::prelude::push(acc_pg, crate::lower::model::Item(crate::lower::model::Item::ItTag{tag_def_of_20016}))); })
                    : prism_rtl::finished(acc_pg);
                });
            }));
            });
        })));
        })), [=, types_p7 = std::move(types_p7)](Array<crate::lower::model::Item> fold_19908) {
            return ({
                auto tags_p8 = fold_19908;
                call_value(fold_job(prism_rtl::deref(prism_rtl::deref(lx_p5).g).defs, Array<crate::lower::model::Item>{}, ({
                auto m_p1_1_4 = m_p1_1;
                auto lx_p5_4 = lx_p5;
                auto roots_p2_3_5 = roots_p2_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Item>>(std::tuple<Array<crate::lower::model::Item>, crate::check::env::Def>)>>(prism_rtl::rc([=, m_p1_1_4 = std::move(m_p1_1_4), lx_p5_4 = std::move(lx_p5_4), roots_p2_3_5 = std::move(roots_p2_3_5)](std::tuple<Array<crate::lower::model::Item>, crate::check::env::Def> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto m_p1_1_4_5 = m_p1_1_4;
                    auto lx_p5_4_5 = lx_p5_4;
                    auto roots_p2_3_5_5 = roots_p2_3_5;
                    entered(once_job([=, m_p1_1_4_5 = std::move(m_p1_1_4_5), lx_p5_4_5 = std::move(lx_p5_4_5), roots_p2_3_5_5 = std::move(roots_p2_3_5_5)]() {
                    return ({
                        auto acc_pi = p0;
                        auto d_pj = p1;
                        (prism_rtl::deref(d_pj).home == m_p1_1_4_5
                        ? call_then(start_def_items(in_module(lx_p5_4_5, d_pj->file, m_p1_1_4_5), d_pj, roots_p2_3_5_5), [=](Array<crate::lower::model::Item> def_items_20120) { return prism_rtl::finished(append(acc_pi, def_items_20120)); })
                        : prism_rtl::finished(acc_pi));
                    });
                }));
                });
            })));
            })), [=, tags_p8 = std::move(tags_p8)](Array<crate::lower::model::Item> fold_20059) {
                return ({
                    auto defs_p9 = fold_20059;
                    call_value(fold_job(values(prism_rtl::deref(prism_rtl::deref(lx_p5).g).traits), Array<crate::lower::model::Item>{}, ({
                    auto m_p1_1_4 = m_p1_1;
                    auto lx_p5_4 = lx_p5;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Item>>(std::tuple<Array<crate::lower::model::Item>, crate::check::env::TraitInfo>)>>(prism_rtl::rc([=, m_p1_1_4 = std::move(m_p1_1_4), lx_p5_4 = std::move(lx_p5_4)](std::tuple<Array<crate::lower::model::Item>, crate::check::env::TraitInfo> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto m_p1_1_4_5 = m_p1_1_4;
                        auto lx_p5_4_5 = lx_p5_4;
                        entered(once_job([=, m_p1_1_4_5 = std::move(m_p1_1_4_5), lx_p5_4_5 = std::move(lx_p5_4_5)]() {
                        return ({
                            auto acc_pk = p0;
                            auto tr_pl = p1;
                            (prism_rtl::deref(tr_pl).home == m_p1_1_4_5
                            ? call_then(crate::lower::functions::start_trait_def_of(lx_p5_4_5, tr_pl), [=](crate::lower::model::TraitDef trait_def_of_20273) { return prism_rtl::finished(crate::prelude::push(acc_pk, crate::lower::model::Item(crate::lower::model::Item::ItTrait{trait_def_of_20273}))); })
                            : prism_rtl::finished(acc_pk));
                        });
                    }));
                    });
                })));
                })), [=, defs_p9 = std::move(defs_p9)](Array<crate::lower::model::Item> fold_20192) {
                    return ({
                        auto traits_pa = fold_20192;
                        call_value(fold_job(values(prism_rtl::deref(prism_rtl::deref(lx_p5).g).impls), Array<crate::lower::model::Item>{}, ({
                        auto m_p1_1_4 = m_p1_1;
                        auto lx_p5_4 = lx_p5;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Item>>(std::tuple<Array<crate::lower::model::Item>, Array<crate::check::env::ImplInfo>>)>>(prism_rtl::rc([=, m_p1_1_4 = std::move(m_p1_1_4), lx_p5_4 = std::move(lx_p5_4)](std::tuple<Array<crate::lower::model::Item>, Array<crate::check::env::ImplInfo>> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto m_p1_1_4_5 = m_p1_1_4;
                            auto lx_p5_4_5 = lx_p5_4;
                            entered(once_job([=, m_p1_1_4_5 = std::move(m_p1_1_4_5), lx_p5_4_5 = std::move(lx_p5_4_5)]() {
                            return ({
                                auto acc_pm = p0;
                                auto ims_pn = p1;
                                fold_job(ims_pn, acc_pm, ({
                                auto m_p1_1_4_5_5 = m_p1_1_4_5;
                                auto lx_p5_4_5_5 = lx_p5_4_5;
                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Item>>(std::tuple<Array<crate::lower::model::Item>, crate::check::env::ImplInfo>)>>(prism_rtl::rc([=, m_p1_1_4_5_5 = std::move(m_p1_1_4_5_5), lx_p5_4_5_5 = std::move(lx_p5_4_5_5)](std::tuple<Array<crate::lower::model::Item>, crate::check::env::ImplInfo> _p0) {
                                auto&& p0 = std::get<0>(_p0);
                                auto&& p1 = std::get<1>(_p0);
                                return ({
                                    auto m_p1_1_4_5_5_5 = m_p1_1_4_5_5;
                                    auto lx_p5_4_5_5_5 = lx_p5_4_5_5;
                                    entered(once_job([=, m_p1_1_4_5_5_5 = std::move(m_p1_1_4_5_5_5), lx_p5_4_5_5_5 = std::move(lx_p5_4_5_5_5)]() {
                                    return ({
                                        auto a_po = p0;
                                        auto im_pp = p1;
                                        (prism_rtl::deref(im_pp).home == m_p1_1_4_5_5_5) && (!prism_rtl::deref(im_pp).derived)
                                        ? call_then(crate::lower::functions::start_impl_def_of(in_module(lx_p5_4_5_5_5, im_pp->file, m_p1_1_4_5_5_5), im_pp), [=](crate::lower::model::ImplDef impl_def_of_20440) { return prism_rtl::finished(crate::prelude::push(a_po, crate::lower::model::Item(crate::lower::model::Item::ItImpl{impl_def_of_20440}))); })
                                        : prism_rtl::finished(a_po);
                                    });
                                }));
                                });
                            })));
                            }))->cycle();
                            });
                        }));
                        });
                    })));
                    })), [=, traits_pa = std::move(traits_pa)](Array<crate::lower::model::Item> fold_20319) {
                        return ({
                            auto impls_pb = fold_20319;
                            auto uses_pc = filter(each(mods_p4_2, [&](const Text& o_pq) { return crate::lower::rust_mod_name(o_pq); }), [&](const Text& o_pr) { return o_pr != crate::lower::rust_mod_name(m_p1_1); });
                            (prism_rtl::finished(crate::lower::model::ModDef{.name = crate::lower::rust_mod_name(m_p1_1), .prism = m_p1_1, .path_ = path_p6, .uses = uses_pc, .complete = Array<Text>{}, .declared = Array<Text>{}, .types_with = Array<Text>{}, .items = append(append(append(append(types_p7, tags_p8), traits_pa), impls_pb), defs_p9)}));
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start ModDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::ModDef> start_mod_def_of(crate::lower::Lx lx0_p0, Text m_p1, Array<std::tuple<Text, bool>> roots_p2, crate::check::env::ModInfo info_p3, Array<Text> mods_p4) {
    return prism_rtl::make_rc<ModDefOf>(lx0_p0, m_p1, roots_p2, info_p3, mods_p4);
}


/// DefItems: unbounded fn Lx, Def, [((Text, Bool))] -> [Item]
Array<crate::lower::model::Item> def_items(const crate::lower::Lx& lx_p0, const crate::check::env::Def& d_p1, const Array<std::tuple<Text, bool>>& roots_p2) {
    auto is_root_p3 = crate::check::types::has_text(each(roots_p2, [&](const std::tuple<Text, bool>& _p0) {
        auto&& q_p4 = std::get<0>(_p0);
        return q_p4;
    }), d_p1.qk);
    auto&& _m = d_p1.body;
    if (prism_rtl::is<crate::check::env::DefBody::DbWidget>(_m)) {
        auto&& w_p5 = prism_rtl::as<crate::check::env::DefBody::DbWidget>(_m).a0;
        return std::move(is_root_p3)
            ? node_items(crate::lower::node_::def::node_def_of(lx_p0, d_p1.qk, Array<crate::syntax::Pattern_>{}, prism_rtl::deref(w_p5).body, prism_rtl::deref(or_(crate::prelude::get(prism_rtl::deref(lx_p0.g).vals, d_p1.qk), crate::check::env::builtin(d_p1.qk, crate::check::types::schemes::mono(crate::check::types::Ty(crate::check::types::Ty::TyErr{}))))).scheme, true))
            : Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItNote{prism_rtl::cat("`", d_p1.name, "` is inlined where it is applied.")})});
    }
    if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
        auto&& clauses_p6 = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
        auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g).vals, d_p1.qk);
        if (prism_rtl::is_none(_m)) {
            return Array<crate::lower::model::Item>{};
        }
        if (prism_rtl::is_some(_m)) {
            auto&& v_p7 = prism_rtl::some_of(_m);
            auto&& _m = prism_rtl::deref(prism_rtl::deref(v_p7).scheme).ty;
            if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
                auto&& m21358_0_2 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
                if (prism_rtl::is<crate::check::types::Ty::TyAt>(prism_rtl::deref(prism_rtl::deref(m21358_0_2)))) {
                    return !std::move(is_root_p3)
                        ? Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItNote{prism_rtl::cat("`", d_p1.name, "` is inlined where it is applied.")})})
                        : ({
                        __label__ _done;
                        prism_rtl::Slot<Array<crate::lower::model::Item>> _v;
                        {
                            auto&& m21554_0 = clauses_p6;
                            if (m21554_0.size() == 1u) {
                                {
                                    auto&& _c1 = index(m21554_0, Nat(0u));
                                    if (prism_rtl::is_some(_c1)) {
                                        auto&& c_p8 = prism_rtl::some_of(_c1);
                                        _v.set(({
                                            __label__ _done;
                                            prism_rtl::Slot<Array<crate::lower::model::Item>> _v;
                                            auto&& _m = prism_rtl::deref(c_p8).body;
                                            if (prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(_m)) {
                                                auto&& b_p9 = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(_m).a0;
                                                _v.set(node_items(crate::lower::node_::def::node_def_of(lx_p0, d_p1.qk, prism_rtl::deref(c_p8).params, b_p9, prism_rtl::deref(v_p7).scheme, true)));
                                                goto _done;
                                            }
                                            {
                                                _v.set(Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItRefused{prism_rtl::cat("`", d_p1.name, "`, a root widget whose body is one expression")})}));
                                                goto _done;
                                            }
                                        _done:
                                            _v.take();
                                        }));
                                        goto _done;
                                    }
                                }
                            }
                        }
                        {
                            _v.set(Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItRefused{prism_rtl::cat("`", d_p1.name, "`, a root widget of several clauses")})}));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                }
            }
            {
                auto f_pa = crate::lower::model::Item(crate::lower::model::Item::ItFn{crate::lower::functions::fn_def_of(lx_p0, d_p1.qk, clauses_p6, prism_rtl::deref(v_p7).scheme)});
                return crate::check::types::has_text(lx_p0.unbs, d_p1.qk)
                    ? Array(std::vector{f_pa, crate::lower::model::Item(crate::lower::model::Item::ItJob{crate::lower::jobs::job_def_of(lx_p0, d_p1.qk, clauses_p6, prism_rtl::deref(v_p7).scheme)})})
                    : Array(std::vector{f_pa});
            }
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::check::env::DefBody::DbLet>(_m)) {
        auto&& l_pb = prism_rtl::as<crate::check::env::DefBody::DbLet>(_m).a0;
        return Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItFn{crate::lower::functions::let_getter(lx_p0, d_p1.qk, l_pb)})});
    }
    {
        return Array<crate::lower::model::Item>{};
    }
}


prism_rtl::Turn<Array<crate::lower::model::Item>> DefItems::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& d_p1 = this->d_p1;
    const auto& roots_p2 = this->roots_p2;
    auto is_root_p3 = crate::check::types::has_text(each(roots_p2, [&](const std::tuple<Text, bool>& _p0) {
        auto&& q_p4 = std::get<0>(_p0);
        return q_p4;
    }), prism_rtl::deref(d_p1).qk);
    return ({
        auto&& _m = prism_rtl::deref(d_p1).body;
        prism_rtl::is<crate::check::env::DefBody::DbWidget>(_m) ? ({
        auto&& w_p5 = prism_rtl::as<crate::check::env::DefBody::DbWidget>(_m).a0;
        std::move(is_root_p3)
        ? ({
        auto d_p1_1 = d_p1;
        auto lx_p0_2 = lx_p0;
        auto w_p5_3 = w_p5;
        call_then(crate::lower::node_::def::start_node_def_of(lx_p0_2, prism_rtl::deref(d_p1_1).qk, Array<crate::syntax::Pattern_>{}, prism_rtl::deref(w_p5_3).body, prism_rtl::deref(or_(crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0_2).g).vals, prism_rtl::deref(d_p1_1).qk), crate::check::env::builtin(prism_rtl::deref(d_p1_1).qk, crate::check::types::schemes::mono(crate::check::types::Ty(crate::check::types::Ty::TyErr{}))))).scheme, true), [=](crate::lower::model::NodeDef node_def_of_21101) { return prism_rtl::finished(node_items(node_def_of_21101)); });
    })
        : prism_rtl::finished(Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItNote{prism_rtl::cat("`", prism_rtl::deref(d_p1).name, "` is inlined where it is applied.")})}));
    })
        : prism_rtl::is<crate::check::env::DefBody::DbFn>(_m) ? ({
        auto&& clauses_p6 = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
        ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0).g).vals, prism_rtl::deref(d_p1).qk);
        prism_rtl::is_none(_m) ? prism_rtl::finished(Array<crate::lower::model::Item>{})
        : prism_rtl::is_some(_m) ? ({
        auto&& v_p7 = prism_rtl::some_of(_m);
        ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(v_p7).scheme).ty;
        prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && ({
        auto&& m21358_0_2 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
        prism_rtl::is<crate::check::types::Ty::TyAt>(prism_rtl::deref(prism_rtl::deref(m21358_0_2)));
    }) ? ({
        auto&& m21358_0_2 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
        !std::move(is_root_p3)
        ? prism_rtl::finished(Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItNote{prism_rtl::cat("`", prism_rtl::deref(d_p1).name, "` is inlined where it is applied.")})}))
        : ({
        ({
        auto&& m21554_0 = clauses_p6;
        (m21554_0.size() == 1u) && ({
        auto&& _c1 = index(m21554_0, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m21554_0 = clauses_p6;
        auto&& _c1 = index(m21554_0, Nat(0u));
        auto&& c_p8 = prism_rtl::some_of(_c1);
        ({
        auto&& _m = prism_rtl::deref(c_p8).body;
        prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(_m) ? ({
        auto&& b_p9 = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(_m).a0;
        ({
        auto b_p9_1 = b_p9;
        auto d_p1_2 = d_p1;
        auto lx_p0_3 = lx_p0;
        call_then(crate::lower::node_::def::start_node_def_of(lx_p0_3, prism_rtl::deref(d_p1_2).qk, prism_rtl::deref(c_p8).params, b_p9_1, prism_rtl::deref(v_p7).scheme, true), [=](crate::lower::model::NodeDef node_def_of_21666) { return prism_rtl::finished(node_items(node_def_of_21666)); });
    });
    })
        : prism_rtl::finished(Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItRefused{prism_rtl::cat("`", prism_rtl::deref(d_p1).name, "`, a root widget whose body is one expression")})}));
    });
    })
        : prism_rtl::finished(Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItRefused{prism_rtl::cat("`", prism_rtl::deref(d_p1).name, "`, a root widget of several clauses")})}));
    });
    })
        : ({
        auto clauses_p6_1 = clauses_p6;
        auto d_p1_2 = d_p1;
        auto lx_p0_3 = lx_p0;
        call_then(crate::lower::functions::start_fn_def_of(lx_p0_3, prism_rtl::deref(d_p1_2).qk, clauses_p6_1, prism_rtl::deref(v_p7).scheme), [=](crate::lower::model::FnDef fn_def_of_21982) {
        return ({
            auto f_pa = crate::lower::model::Item(crate::lower::model::Item::ItFn{fn_def_of_21982});
            (crate::check::types::has_text(prism_rtl::deref(lx_p0_3).unbs, prism_rtl::deref(d_p1_2).qk)
            ? call_then(crate::lower::jobs::start_job_def_of(lx_p0_3, prism_rtl::deref(d_p1_2).qk, clauses_p6_1, prism_rtl::deref(v_p7).scheme), [=](crate::lower::model::JobDef job_def_of_22077) { return prism_rtl::finished(Array(std::vector{f_pa, crate::lower::model::Item(crate::lower::model::Item::ItJob{job_def_of_22077})})); })
            : prism_rtl::finished(Array(std::vector{f_pa})));
        });
    });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is<crate::check::env::DefBody::DbLet>(_m) ? ({
        auto&& l_pb = prism_rtl::as<crate::check::env::DefBody::DbLet>(_m).a0;
        ({
        auto d_p1_1 = d_p1;
        auto l_pb_2 = l_pb;
        auto lx_p0_3 = lx_p0;
        call_then(crate::lower::functions::start_let_getter(lx_p0_3, prism_rtl::deref(d_p1_1).qk, l_pb_2), [=](crate::lower::model::FnDef let_getter_22154) { return prism_rtl::finished(Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItFn{let_getter_22154})})); });
    });
    })
        : prism_rtl::finished(Array<crate::lower::model::Item>{});
    });
}


/// `Start DefItems, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::Item>> start_def_items(crate::lower::Lx lx_p0, crate::check::env::Def d_p1, Array<std::tuple<Text, bool>> roots_p2) {
    return prism_rtl::make_rc<DefItems>(lx_p0, d_p1, roots_p2);
}


/// NodeItems: fn NodeDef -> [Item]
Array<crate::lower::model::Item> node_items(const crate::lower::model::NodeDef& n_p0) {
    return append(Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItNode{n_p0})}), each(n_p0.children, [&](const crate::lower::model::NodeDef& c_p1) { return crate::lower::model::Item(crate::lower::model::Item::ItNode{c_p1}); }));
}


/// TyDefs: unbounded fn Lx, TyInfo -> [Item]
Array<crate::lower::model::Item> ty_defs(const crate::lower::Lx& lx_p0, const crate::check::env::TyInfo& ti_p1) {
    auto derives_p2 = each(ti_p1.derives, [&](const Text& dn_p6) { return crate::check::types::bare_name(dn_p6); });
    auto params_p3 = each(ti_p1.params, [&](const Text& p_p7) { return crate::lower::camel(p_p7); });
    auto bare_p4 = crate::check::types::bare_name(ti_p1.name);
    auto mk_f5 = ({
        auto bare_p4_1 = bare_p4;
        auto params_p3_2 = params_p3;
        auto derives_p2_3 = derives_p2;
        auto lx_p0_4 = lx_p0;
        auto ti_p1_5 = ti_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::TyDef>(std::tuple<crate::lower::model::TyShape, Array<crate::lower::model::CaseDef>>)>>(prism_rtl::rc([=, bare_p4_1 = std::move(bare_p4_1), params_p3_2 = std::move(params_p3_2), derives_p2_3 = std::move(derives_p2_3), lx_p0_4 = std::move(lx_p0_4), ti_p1_5 = std::move(ti_p1_5)](std::tuple<crate::lower::model::TyShape, Array<crate::lower::model::CaseDef>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto bare_p4_1_6 = bare_p4_1;
            auto params_p3_2_6 = params_p3_2;
            auto derives_p2_3_6 = derives_p2_3;
            auto lx_p0_4_6 = lx_p0_4;
            auto ti_p1_5_6 = ti_p1_5;
            entered(once_job([=, bare_p4_1_6 = std::move(bare_p4_1_6), params_p3_2_6 = std::move(params_p3_2_6), derives_p2_3_6 = std::move(derives_p2_3_6), lx_p0_4_6 = std::move(lx_p0_4_6), ti_p1_5_6 = std::move(ti_p1_5_6)]() {
            return ({
                auto shape_p8 = p0;
                auto cases_p9 = p1;
                call_then(start_ty_podable(lx_p0_4_6, crate::check::types::Ty(crate::check::types::Ty::TyCon{ti_p1_5_6.name, Array<crate::check::types::Ty>{}}), Array<Text>{}), [=, shape_p8 = std::move(shape_p8), cases_p9 = std::move(cases_p9)](bool ty_podable_22873) {
                return prism_rtl::finished(crate::lower::model::TyDef{.name = crate::lower::camel(bare_p4_1_6), .prism = bare_p4_1_6, .params = params_p3_2_6, .shape = shape_p8, .cases_ = cases_p9, .eq = crate::check::types::has_text(derives_p2_3_6, Text::lit("Eq")), .ord = crate::check::types::has_text(derives_p2_3_6, Text::lit("Ord")), .show_ = crate::lower::functions::has_own_show(lx_p0_4_6, ti_p1_5_6.name)
                    ? crate::lower::model::Shown(crate::lower::model::Shown::ShownOwn{})
                    : crate::check::types::has_text(derives_p2_3_6, Text::lit("Show"))
                    ? crate::lower::model::Shown(crate::lower::model::Shown::ShownDerived{})
                    : crate::lower::model::Shown(crate::lower::model::Shown::NotShown{}), .pod = ty_podable_22873 && run_to_end(fold_job(cases_p9, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::CaseDef>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::CaseDef> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return entered(once_job([=]() {
                        return ({
                            auto ok_pa = p0;
                            auto c_pb = p1;
                            (prism_rtl::finished(std::move(ok_pa) && run_to_end(fold_job(prism_rtl::deref(c_pb).fields, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, crate::lower::model::OutTy>> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return entered(once_job([=]() {
                                return ({
                                    auto ok2_pc = p0;
                                    auto&& _ft_pd = p1;
                                    auto&& ft_pd = std::get<1>(_ft_pd);
                                    (prism_rtl::finished(std::move(ok2_pc) && crate::lower::types::podable(ft_pd)));
                                });
                            }));
                        }))))));
                        });
                    }));
                })))), .doc = type_doc(lx_p0_4_6, ti_p1_5_6)});
            });
            });
        }));
        });
    })));
    });
    auto&& _m = ti_p1.body;
    if (prism_rtl::is<crate::check::env::TyBody::BRecord>(_m)) {
        auto&& fs_pe = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
        auto fields_pf = run_to_end(each_job(crate::check::errors::range0(len(fs_pe)), ({
            auto fs_pe_1 = fs_pe;
            auto lx_p0_2 = lx_p0;
            auto ti_p1_3 = ti_p1;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::lower::model::OutTy>>(Nat)>>(prism_rtl::rc([=, fs_pe_1 = std::move(fs_pe_1), lx_p0_2 = std::move(lx_p0_2), ti_p1_3 = std::move(ti_p1_3)](Nat p0) {
            return ({
                auto fs_pe_1_4 = fs_pe_1;
                auto lx_p0_2_4 = lx_p0_2;
                auto ti_p1_3_4 = ti_p1_3;
                entered(once_job([=, fs_pe_1_4 = std::move(fs_pe_1_4), lx_p0_2_4 = std::move(lx_p0_2_4), ti_p1_3_4 = std::move(ti_p1_3_4)]() {
                return ({
                    auto i_pg = p0;
                    ({
                    auto [fname_pi, ft_pj] = or_(index(fs_pe_1_4, i_pg), std::tuple{Text::lit(""), crate::check::types::Ty(crate::check::types::Ty::TyErr{})});
                    call_then(crate::lower::types::start_out_ty_of(lx_p0_2_4, ft_pj), [=](crate::lower::model::OutTy out_ty_of_23219) {
                    return ({
                        auto rt_ph = out_ty_of_23219;
                        (prism_rtl::finished(std::tuple{crate::lower::snake(fname_pi), crate::lower::types::rc_field(lx_p0_2_4, ti_p1_3_4.name, i_pg)
                        ? crate::lower::model::OutTy(crate::lower::model::OutTy::OutRc{prism_rtl::rc(rt_ph)})
                        : rt_ph}));
                    });
                });
                });
                });
            }));
            });
        }));
        })));
        return Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItType{run_to_end(mk_f5(std::tuple{crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeRecord{}), Array(std::vector{crate::lower::model::CaseDef{.name = crate::lower::camel(bare_p4), .prism = bare_p4, .fields = fields_pf}})}))})});
    }
    if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
        auto&& cases_pk = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
        auto defs_pl = run_to_end(each_job(cases_pk, ({
            auto ti_p1_1 = ti_p1;
            auto lx_p0_2 = lx_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::CaseDef>(std::tuple<Text, Array<crate::check::types::Ty>>)>>(prism_rtl::rc([=, ti_p1_1 = std::move(ti_p1_1), lx_p0_2 = std::move(lx_p0_2)](std::tuple<Text, Array<crate::check::types::Ty>> p0) {
            return ({
                auto ti_p1_1_3 = ti_p1_1;
                auto lx_p0_2_3 = lx_p0_2;
                entered(once_job([=, ti_p1_1_3 = std::move(ti_p1_1_3), lx_p0_2_3 = std::move(lx_p0_2_3)]() {
                return ({
                    auto [cn_pn, ats_po] = p0;
                    ({
                    auto ck_pp = crate::check::env::qual_key(ti_p1_1_3.home, cn_pn);
                    call_value(each_job(crate::check::errors::range0(len(ats_po)), ({
                    auto lx_p0_2_3_3 = lx_p0_2_3;
                    auto ck_pp_3 = ck_pp;
                    auto ats_po_4 = ats_po;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::lower::model::OutTy>>(Nat)>>(prism_rtl::rc([=, lx_p0_2_3_3 = std::move(lx_p0_2_3_3), ck_pp_3 = std::move(ck_pp_3), ats_po_4 = std::move(ats_po_4)](Nat p0) {
                    return ({
                        auto lx_p0_2_3_3_5 = lx_p0_2_3_3;
                        auto ck_pp_3_5 = ck_pp_3;
                        auto ats_po_4_5 = ats_po_4;
                        entered(once_job([=, lx_p0_2_3_3_5 = std::move(lx_p0_2_3_3_5), ck_pp_3_5 = std::move(ck_pp_3_5), ats_po_4_5 = std::move(ats_po_4_5)]() {
                        return ({
                            auto i_pq = p0;
                            call_then(start_case_field(lx_p0_2_3_3_5, ck_pp_3_5, i_pq, or_(index(ats_po_4_5, i_pq), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::lower::model::OutTy case_field_23627) { return prism_rtl::finished(std::tuple{Text::lit(""), case_field_23627}); });
                        });
                    }));
                    });
                }));
                })), [=](Array<std::tuple<Text, crate::lower::model::OutTy>> each_23590) { return prism_rtl::finished(crate::lower::model::CaseDef{.name = crate::lower::camel(cn_pn), .prism = cn_pn, .fields = each_23590}); });
                });
                });
            }));
            });
        })));
        })));
        auto shape_pm = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::TyShape> _v;
            {
                auto&& m23696_0 = cases_pk;
                if (m23696_0.size() == 1u) {
                    {
                        auto&& _c2 = index(m23696_0, Nat(0u));
                        if (prism_rtl::is_some(_c2)) {
                            auto&& cn_pr = std::get<0>(prism_rtl::some_of(_c2));
                            auto&& m23696_0_0_1 = std::get<1>(prism_rtl::some_of(_c2));
                            if (m23696_0_0_1.size() == 0u) {
                                _v.set(crate::check::env::is_lower_text(cn_pr)
                                    ? crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeUnit{})
                                    : crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeChoice{}));
                                goto _done;
                            }
                        }
                    }
                }
            }
            {
                auto&& m23696_1 = cases_pk;
                if (m23696_1.size() == 1u) {
                    {
                        auto&& _c1 = index(m23696_1, Nat(0u));
                        if (prism_rtl::is_some(_c1)) {
                            auto&& cn_ps = std::get<0>(prism_rtl::some_of(_c1));
                            _v.set(cn_ps == bare_p4
                                ? crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeNewtype{})
                                : crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeChoice{}));
                            goto _done;
                        }
                    }
                }
            }
            {
                _v.set(crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeChoice{}));
                goto _done;
            }
        _done:
            _v.take();
        });
        return Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItType{run_to_end(mk_f5(std::tuple{shape_pm, defs_pl}))})});
    }
    if (prism_rtl::is<crate::check::env::TyBody::BRowKind>(_m)) {
        return ti_p1.name == Text::lit("Prelude.Fault")
            ? Array<crate::lower::model::Item>{}
            : Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItRow{row_def_of(lx_p0, ti_p1)})});
    }
    {
        return Array<crate::lower::model::Item>{};
    }
}


prism_rtl::Turn<Array<crate::lower::model::Item>> TyDefs::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& ti_p1 = this->ti_p1;
    auto derives_p2 = each(prism_rtl::deref(ti_p1).derives, [&](const Text& dn_p6) { return crate::check::types::bare_name(dn_p6); });
    auto params_p3 = each(prism_rtl::deref(ti_p1).params, [&](const Text& p_p7) { return crate::lower::camel(p_p7); });
    auto bare_p4 = crate::check::types::bare_name(prism_rtl::deref(ti_p1).name);
    auto mk_f5 = ({
        auto bare_p4_1 = bare_p4;
        auto params_p3_2 = params_p3;
        auto derives_p2_3 = derives_p2;
        auto lx_p0_4 = lx_p0;
        auto ti_p1_5 = ti_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::TyDef>(std::tuple<crate::lower::model::TyShape, Array<crate::lower::model::CaseDef>>)>>(prism_rtl::rc([=, bare_p4_1 = std::move(bare_p4_1), params_p3_2 = std::move(params_p3_2), derives_p2_3 = std::move(derives_p2_3), lx_p0_4 = std::move(lx_p0_4), ti_p1_5 = std::move(ti_p1_5)](std::tuple<crate::lower::model::TyShape, Array<crate::lower::model::CaseDef>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto bare_p4_1_6 = bare_p4_1;
            auto params_p3_2_6 = params_p3_2;
            auto derives_p2_3_6 = derives_p2_3;
            auto lx_p0_4_6 = lx_p0_4;
            auto ti_p1_5_6 = ti_p1_5;
            entered(once_job([=, bare_p4_1_6 = std::move(bare_p4_1_6), params_p3_2_6 = std::move(params_p3_2_6), derives_p2_3_6 = std::move(derives_p2_3_6), lx_p0_4_6 = std::move(lx_p0_4_6), ti_p1_5_6 = std::move(ti_p1_5_6)]() {
            return ({
                auto shape_p8 = p0;
                auto cases_p9 = p1;
                call_then(start_ty_podable(lx_p0_4_6, crate::check::types::Ty(crate::check::types::Ty::TyCon{prism_rtl::deref(ti_p1_5_6).name, Array<crate::check::types::Ty>{}}), Array<Text>{}), [=, shape_p8 = std::move(shape_p8), cases_p9 = std::move(cases_p9)](bool ty_podable_22873) {
                return prism_rtl::finished(crate::lower::model::TyDef{.name = crate::lower::camel(bare_p4_1_6), .prism = bare_p4_1_6, .params = params_p3_2_6, .shape = shape_p8, .cases_ = cases_p9, .eq = crate::check::types::has_text(derives_p2_3_6, Text::lit("Eq")), .ord = crate::check::types::has_text(derives_p2_3_6, Text::lit("Ord")), .show_ = crate::lower::functions::has_own_show(lx_p0_4_6, prism_rtl::deref(ti_p1_5_6).name)
                    ? crate::lower::model::Shown(crate::lower::model::Shown::ShownOwn{})
                    : crate::check::types::has_text(derives_p2_3_6, Text::lit("Show"))
                    ? crate::lower::model::Shown(crate::lower::model::Shown::ShownDerived{})
                    : crate::lower::model::Shown(crate::lower::model::Shown::NotShown{}), .pod = ty_podable_22873 && run_to_end(fold_job(cases_p9, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::CaseDef>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::CaseDef> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return entered(once_job([=]() {
                        return ({
                            auto ok_pa = p0;
                            auto c_pb = p1;
                            (prism_rtl::finished(std::move(ok_pa) && run_to_end(fold_job(prism_rtl::deref(c_pb).fields, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, crate::lower::model::OutTy>> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return entered(once_job([=]() {
                                return ({
                                    auto ok2_pc = p0;
                                    auto&& _ft_pd = p1;
                                    auto&& ft_pd = std::get<1>(_ft_pd);
                                    (prism_rtl::finished(std::move(ok2_pc) && crate::lower::types::podable(ft_pd)));
                                });
                            }));
                        }))))));
                        });
                    }));
                })))), .doc = type_doc(lx_p0_4_6, ti_p1_5_6)});
            });
            });
        }));
        });
    })));
    });
    return ({
        auto&& _m = prism_rtl::deref(ti_p1).body;
        prism_rtl::is<crate::check::env::TyBody::BRecord>(_m) ? ({
        auto&& fs_pe = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
        ({
        auto fs_pe_1 = fs_pe;
        auto lx_p0_2 = lx_p0;
        auto ti_p1_3 = ti_p1;
        call_value(each_job(crate::check::errors::range0(len(fs_pe_1)), ({
        auto fs_pe_1_4 = fs_pe_1;
        auto lx_p0_2_4 = lx_p0_2;
        auto ti_p1_3_4 = ti_p1_3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::lower::model::OutTy>>(Nat)>>(prism_rtl::rc([=, fs_pe_1_4 = std::move(fs_pe_1_4), lx_p0_2_4 = std::move(lx_p0_2_4), ti_p1_3_4 = std::move(ti_p1_3_4)](Nat p0) {
        return ({
            auto fs_pe_1_4_4 = fs_pe_1_4;
            auto lx_p0_2_4_4 = lx_p0_2_4;
            auto ti_p1_3_4_4 = ti_p1_3_4;
            entered(once_job([=, fs_pe_1_4_4 = std::move(fs_pe_1_4_4), lx_p0_2_4_4 = std::move(lx_p0_2_4_4), ti_p1_3_4_4 = std::move(ti_p1_3_4_4)]() {
            return ({
                auto i_pg = p0;
                ({
                auto [fname_pi, ft_pj] = or_(index(fs_pe_1_4_4, i_pg), std::tuple{Text::lit(""), crate::check::types::Ty(crate::check::types::Ty::TyErr{})});
                call_then(crate::lower::types::start_out_ty_of(lx_p0_2_4_4, ft_pj), [=](crate::lower::model::OutTy out_ty_of_23219) {
                return ({
                    auto rt_ph = out_ty_of_23219;
                    (prism_rtl::finished(std::tuple{crate::lower::snake(fname_pi), crate::lower::types::rc_field(lx_p0_2_4_4, prism_rtl::deref(ti_p1_3_4_4).name, i_pg)
                    ? crate::lower::model::OutTy(crate::lower::model::OutTy::OutRc{prism_rtl::rc(rt_ph)})
                    : rt_ph}));
                });
            });
            });
            });
        }));
        });
    }));
    })), [=](Array<std::tuple<Text, crate::lower::model::OutTy>> each_23105) {
        return ({
            auto fields_pf = each_23105;
            call_value(mk_f5(std::tuple{crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeRecord{}), Array(std::vector{crate::lower::model::CaseDef{.name = crate::lower::camel(bare_p4), .prism = bare_p4, .fields = fields_pf}})}), [=](crate::lower::model::TyDef mk_23336) { return prism_rtl::finished(Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItType{mk_23336})})); });
        });
    });
    });
    })
        : prism_rtl::is<crate::check::env::TyBody::BChoice>(_m) ? ({
        auto&& cases_pk = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
        ({
        auto cases_pk_1 = cases_pk;
        auto lx_p0_2 = lx_p0;
        auto ti_p1_3 = ti_p1;
        call_value(each_job(cases_pk_1, ({
        auto ti_p1_3_4 = ti_p1_3;
        auto lx_p0_2_4 = lx_p0_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::CaseDef>(std::tuple<Text, Array<crate::check::types::Ty>>)>>(prism_rtl::rc([=, ti_p1_3_4 = std::move(ti_p1_3_4), lx_p0_2_4 = std::move(lx_p0_2_4)](std::tuple<Text, Array<crate::check::types::Ty>> p0) {
        return ({
            auto ti_p1_3_4_4 = ti_p1_3_4;
            auto lx_p0_2_4_4 = lx_p0_2_4;
            entered(once_job([=, ti_p1_3_4_4 = std::move(ti_p1_3_4_4), lx_p0_2_4_4 = std::move(lx_p0_2_4_4)]() {
            return ({
                auto [cn_pn, ats_po] = p0;
                ({
                auto ck_pp = crate::check::env::qual_key(prism_rtl::deref(ti_p1_3_4_4).home, cn_pn);
                call_value(each_job(crate::check::errors::range0(len(ats_po)), ({
                auto lx_p0_2_4_4_4 = lx_p0_2_4_4;
                auto ck_pp_4 = ck_pp;
                auto ats_po_5 = ats_po;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::lower::model::OutTy>>(Nat)>>(prism_rtl::rc([=, lx_p0_2_4_4_4 = std::move(lx_p0_2_4_4_4), ck_pp_4 = std::move(ck_pp_4), ats_po_5 = std::move(ats_po_5)](Nat p0) {
                return ({
                    auto lx_p0_2_4_4_4_6 = lx_p0_2_4_4_4;
                    auto ck_pp_4_6 = ck_pp_4;
                    auto ats_po_5_6 = ats_po_5;
                    entered(once_job([=, lx_p0_2_4_4_4_6 = std::move(lx_p0_2_4_4_4_6), ck_pp_4_6 = std::move(ck_pp_4_6), ats_po_5_6 = std::move(ats_po_5_6)]() {
                    return ({
                        auto i_pq = p0;
                        call_then(start_case_field(lx_p0_2_4_4_4_6, ck_pp_4_6, i_pq, or_(index(ats_po_5_6, i_pq), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::lower::model::OutTy case_field_23627) { return prism_rtl::finished(std::tuple{Text::lit(""), case_field_23627}); });
                    });
                }));
                });
            }));
            })), [=](Array<std::tuple<Text, crate::lower::model::OutTy>> each_23590) { return prism_rtl::finished(crate::lower::model::CaseDef{.name = crate::lower::camel(cn_pn), .prism = cn_pn, .fields = each_23590}); });
            });
            });
        }));
        });
    })));
    })), [=](Array<crate::lower::model::CaseDef> each_23459) {
        return ({
            auto defs_pl = each_23459;
            auto shape_pm = ({
                __label__ _done;
                prism_rtl::Slot<crate::lower::model::TyShape> _v;
                {
                    auto&& m23696_0 = cases_pk_1;
                    if (m23696_0.size() == 1u) {
                        {
                            auto&& _c2 = index(m23696_0, Nat(0u));
                            if (prism_rtl::is_some(_c2)) {
                                auto&& cn_pr = std::get<0>(prism_rtl::some_of(_c2));
                                auto&& m23696_0_0_1 = std::get<1>(prism_rtl::some_of(_c2));
                                if (m23696_0_0_1.size() == 0u) {
                                    _v.set(crate::check::env::is_lower_text(cn_pr)
                                        ? crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeUnit{})
                                        : crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeChoice{}));
                                    goto _done;
                                }
                            }
                        }
                    }
                }
                {
                    auto&& m23696_1 = cases_pk_1;
                    if (m23696_1.size() == 1u) {
                        {
                            auto&& _c1 = index(m23696_1, Nat(0u));
                            if (prism_rtl::is_some(_c1)) {
                                auto&& cn_ps = std::get<0>(prism_rtl::some_of(_c1));
                                _v.set(cn_ps == bare_p4
                                    ? crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeNewtype{})
                                    : crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeChoice{}));
                                goto _done;
                            }
                        }
                    }
                }
                {
                    _v.set(crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeChoice{}));
                    goto _done;
                }
            _done:
                _v.take();
            });
            call_value(mk_f5(std::tuple{shape_pm, defs_pl}), [=](crate::lower::model::TyDef mk_23933) { return prism_rtl::finished(Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItType{mk_23933})})); });
        });
    });
    });
    })
        : prism_rtl::is<crate::check::env::TyBody::BRowKind>(_m) ? prism_rtl::deref(ti_p1).name == Text::lit("Prelude.Fault")
        ? prism_rtl::finished(Array<crate::lower::model::Item>{})
        : ({
        auto lx_p0_1 = lx_p0;
        auto ti_p1_2 = ti_p1;
        call_then(start_row_def_of(lx_p0_1, ti_p1_2), [=](crate::lower::model::RowDef row_def_of_24020) { return prism_rtl::finished(Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItRow{row_def_of_24020})})); });
    })
        : prism_rtl::finished(Array<crate::lower::model::Item>{});
    });
}


/// `Start TyDefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::Item>> start_ty_defs(crate::lower::Lx lx_p0, crate::check::env::TyInfo ti_p1) {
    return prism_rtl::make_rc<TyDefs>(lx_p0, ti_p1);
}


/// TyPodable: unbounded fn Lx, Ty, [Text] -> Bool
bool ty_podable(const crate::lower::Lx& lx_p0, const crate::check::types::Ty& t_p1, const Array<Text>& seen_p2) {
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p1)) {
        return false;
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p1)) {
        return false;
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p1)) {
        auto&& m24341_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        if (m24341_2_0 == Text::lit("!")) {
            return false;
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p1)) {
        auto&& m24341_3_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        if (m24341_3_0 == Text::lit("$")) {
            return false;
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p1)) {
        auto&& i_p3 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        return ty_podable(lx_p0, prism_rtl::deref(prism_rtl::deref(i_p3)), seen_p2);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p1)) {
        auto&& ts_p4 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p1).a0;
        return run_to_end(fold_job(ts_p4, true, ({
            auto lx_p0_1 = lx_p0;
            auto seen_p2_2 = seen_p2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1), seen_p2_2 = std::move(seen_p2_2)](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_p0_1_3 = lx_p0_1;
                auto seen_p2_2_3 = seen_p2_2;
                entered(once_job([=, lx_p0_1_3 = std::move(lx_p0_1_3), seen_p2_2_3 = std::move(seen_p2_2_3)]() {
                return ({
                    auto ok_p5 = p0;
                    auto x_p6 = p1;
                    (prism_rtl::finished(std::move(ok_p5) && ty_podable(lx_p0_1_3, x_p6, seen_p2_2_3)));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p1)) {
        auto&& e_p7 = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p1).a0;
        return ty_podable(lx_p0, prism_rtl::deref(prism_rtl::deref(e_p7)), seen_p2);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p1)) {
        auto&& k_p8 = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a0;
        auto&& v_p9 = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a1;
        return ty_podable(lx_p0, prism_rtl::deref(prism_rtl::deref(k_p8)), seen_p2) && ty_podable(lx_p0, prism_rtl::deref(prism_rtl::deref(v_p9)), seen_p2);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1)) {
        auto&& n_pa = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& args_pb = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        return crate::check::types::has_text(seen_p2, n_pa)
            ? true
            : ({
            auto more_pc = crate::prelude::push(seen_p2, n_pa);
            auto args_ok_pd = run_to_end(fold_job(args_pb, true, ({
                auto lx_p0_1 = lx_p0;
                auto more_pc_2 = more_pc;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1), more_pc_2 = std::move(more_pc_2)](std::tuple<bool, crate::check::types::Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto lx_p0_1_3 = lx_p0_1;
                    auto more_pc_2_3 = more_pc_2;
                    entered(once_job([=, lx_p0_1_3 = std::move(lx_p0_1_3), more_pc_2_3 = std::move(more_pc_2_3)]() {
                    return ({
                        auto ok_pe = p0;
                        auto x_pf = p1;
                        (prism_rtl::finished(std::move(ok_pe) && ty_podable(lx_p0_1_3, x_pf, more_pc_2_3)));
                    });
                }));
                });
            })));
            })));
            (std::move(args_ok_pd) && ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g).types, n_pa);
            if (prism_rtl::is_some(_m)) {
                auto&& ti_pg = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = prism_rtl::deref(ti_pg).body;
                    if (prism_rtl::is<crate::check::env::TyBody::BRecord>(_m)) {
                        auto&& fs_ph = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
                        _v.set(run_to_end(fold_job(fs_ph, true, ({
                            auto lx_p0_1 = lx_p0;
                            auto more_pc_2 = more_pc;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, crate::check::types::Ty>>)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1), more_pc_2 = std::move(more_pc_2)](std::tuple<bool, std::tuple<Text, crate::check::types::Ty>> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto lx_p0_1_3 = lx_p0_1;
                                auto more_pc_2_3 = more_pc_2;
                                entered(once_job([=, lx_p0_1_3 = std::move(lx_p0_1_3), more_pc_2_3 = std::move(more_pc_2_3)]() {
                                return ({
                                    auto ok_pi = p0;
                                    auto&& _ft_pj = p1;
                                    auto&& ft_pj = std::get<1>(_ft_pj);
                                    (prism_rtl::finished(std::move(ok_pi) && ty_podable(lx_p0_1_3, ft_pj, more_pc_2_3)));
                                });
                            }));
                            });
                        })));
                        }))));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
                        auto&& cs_pk = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
                        _v.set(run_to_end(fold_job(cs_pk, true, ({
                            auto lx_p0_1 = lx_p0;
                            auto more_pc_2 = more_pc;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Array<crate::check::types::Ty>>>)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1), more_pc_2 = std::move(more_pc_2)](std::tuple<bool, std::tuple<Text, Array<crate::check::types::Ty>>> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto lx_p0_1_3 = lx_p0_1;
                                auto more_pc_2_3 = more_pc_2;
                                entered(once_job([=, lx_p0_1_3 = std::move(lx_p0_1_3), more_pc_2_3 = std::move(more_pc_2_3)]() {
                                return ({
                                    auto ok_pl = p0;
                                    auto&& _ats_pm = p1;
                                    auto&& ats_pm = std::get<1>(_ats_pm);
                                    (prism_rtl::finished(std::move(ok_pl) && run_to_end(fold_job(ats_pm, true, ({
                                    auto lx_p0_1_3_3 = lx_p0_1_3;
                                    auto more_pc_2_3_3 = more_pc_2_3;
                                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=, lx_p0_1_3_3 = std::move(lx_p0_1_3_3), more_pc_2_3_3 = std::move(more_pc_2_3_3)](std::tuple<bool, crate::check::types::Ty> _p0) {
                                    auto&& p0 = std::get<0>(_p0);
                                    auto&& p1 = std::get<1>(_p0);
                                    return ({
                                        auto lx_p0_1_3_3_3 = lx_p0_1_3_3;
                                        auto more_pc_2_3_3_3 = more_pc_2_3_3;
                                        entered(once_job([=, lx_p0_1_3_3_3 = std::move(lx_p0_1_3_3_3), more_pc_2_3_3_3 = std::move(more_pc_2_3_3_3)]() {
                                        return ({
                                            auto ok2_pn = p0;
                                            auto x_po = p1;
                                            (prism_rtl::finished(std::move(ok2_pn) && ty_podable(lx_p0_1_3_3_3, x_po, more_pc_2_3_3_3)));
                                        });
                                    }));
                                    });
                                })));
                                })))));
                                });
                            }));
                            });
                        })));
                        }))));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::env::TyBody::BAlias>(_m)) {
                        auto&& a_pp = prism_rtl::as<crate::check::env::TyBody::BAlias>(_m).a0;
                        _v.set(ty_podable(lx_p0, a_pp, more_pc));
                        goto _done;
                    }
                    {
                        _v.set(true);
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(true);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        }));
        });
    }
    {
        return true;
    }
}


prism_rtl::Turn<bool> TyPodable::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& t_p1 = this->t_p1;
    const auto& seen_p2 = this->seen_p2;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyFn>(t_p1) ? prism_rtl::finished(false)
        : prism_rtl::is<crate::check::types::Ty::TyAt>(t_p1) ? prism_rtl::finished(false)
        : prism_rtl::is<crate::check::types::Ty::TySig>(t_p1) && ({
        auto&& m24341_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        (m24341_2_0 == Text::lit("!"));
    }) ? ({
        auto&& m24341_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        prism_rtl::finished(false);
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t_p1) && ({
        auto&& m24341_3_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        (m24341_3_0 == Text::lit("$"));
    }) ? ({
        auto&& m24341_3_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        prism_rtl::finished(false);
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t_p1) ? ({
        auto&& i_p3 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        prism_rtl::more(prism_rtl::rc(TyPodable(lx_p0, prism_rtl::deref(prism_rtl::deref(i_p3)), seen_p2)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p1) ? ({
        auto&& ts_p4 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p1).a0;
        fold_job(ts_p4, true, ({
        auto lx_p0_1 = lx_p0;
        auto seen_p2_2 = seen_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1), seen_p2_2 = std::move(seen_p2_2)](std::tuple<bool, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0_1_3 = lx_p0_1;
            auto seen_p2_2_3 = seen_p2_2;
            entered(once_job([=, lx_p0_1_3 = std::move(lx_p0_1_3), seen_p2_2_3 = std::move(seen_p2_2_3)]() {
            return ({
                auto ok_p5 = p0;
                auto x_p6 = p1;
                (prism_rtl::finished(std::move(ok_p5) && ty_podable(lx_p0_1_3, x_p6, seen_p2_2_3)));
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t_p1) ? ({
        auto&& e_p7 = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p1).a0;
        prism_rtl::more(prism_rtl::rc(TyPodable(lx_p0, prism_rtl::deref(prism_rtl::deref(e_p7)), seen_p2)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t_p1) ? ({
        auto&& k_p8 = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a0;
        auto&& v_p9 = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a1;
        ({
        auto k_p8_1 = prism_rtl::deref(prism_rtl::deref(k_p8));
        auto lx_p0_2 = lx_p0;
        auto seen_p2_3 = seen_p2;
        auto v_p9_4 = prism_rtl::deref(prism_rtl::deref(v_p9));
        call_then(start_ty_podable(lx_p0_2, k_p8_1, seen_p2_3), [=, v_p9_4 = std::move(v_p9_4)](bool ty_podable_24644) { return prism_rtl::finished(ty_podable_24644 && ty_podable(lx_p0_2, v_p9_4, seen_p2_3)); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1) ? ({
        auto&& n_pa = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& args_pb = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        crate::check::types::has_text(seen_p2, n_pa)
        ? prism_rtl::finished(true)
        : ({
        auto more_pc = crate::prelude::push(seen_p2, n_pa);
        auto args_pb_1 = args_pb;
        auto lx_p0_2 = lx_p0;
        auto n_pa_3 = n_pa;
        call_value(fold_job(args_pb_1, true, ({
        auto lx_p0_2_4 = lx_p0_2;
        auto more_pc_4 = more_pc;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=, lx_p0_2_4 = std::move(lx_p0_2_4), more_pc_4 = std::move(more_pc_4)](std::tuple<bool, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0_2_4_5 = lx_p0_2_4;
            auto more_pc_4_5 = more_pc_4;
            entered(once_job([=, lx_p0_2_4_5 = std::move(lx_p0_2_4_5), more_pc_4_5 = std::move(more_pc_4_5)]() {
            return ({
                auto ok_pe = p0;
                auto x_pf = p1;
                (prism_rtl::finished(std::move(ok_pe) && ty_podable(lx_p0_2_4_5, x_pf, more_pc_4_5)));
            });
        }));
        });
    })));
    })), [=, n_pa_3 = std::move(n_pa_3)](bool fold_24820) {
        return ({
            auto args_ok_pd = fold_24820;
            (prism_rtl::finished(std::move(args_ok_pd) && ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0_2).g).types, n_pa_3);
            if (prism_rtl::is_some(_m)) {
                auto&& ti_pg = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = prism_rtl::deref(ti_pg).body;
                    if (prism_rtl::is<crate::check::env::TyBody::BRecord>(_m)) {
                        auto&& fs_ph = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
                        _v.set(run_to_end(fold_job(fs_ph, true, ({
                            auto lx_p0_2_4 = lx_p0_2;
                            auto more_pc_4 = more_pc;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, crate::check::types::Ty>>)>>(prism_rtl::rc([=, lx_p0_2_4 = std::move(lx_p0_2_4), more_pc_4 = std::move(more_pc_4)](std::tuple<bool, std::tuple<Text, crate::check::types::Ty>> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto lx_p0_2_4_5 = lx_p0_2_4;
                                auto more_pc_4_5 = more_pc_4;
                                entered(once_job([=, lx_p0_2_4_5 = std::move(lx_p0_2_4_5), more_pc_4_5 = std::move(more_pc_4_5)]() {
                                return ({
                                    auto ok_pi = p0;
                                    auto&& _ft_pj = p1;
                                    auto&& ft_pj = std::get<1>(_ft_pj);
                                    (prism_rtl::finished(std::move(ok_pi) && ty_podable(lx_p0_2_4_5, ft_pj, more_pc_4_5)));
                                });
                            }));
                            });
                        })));
                        }))));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
                        auto&& cs_pk = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
                        _v.set(run_to_end(fold_job(cs_pk, true, ({
                            auto lx_p0_2_4 = lx_p0_2;
                            auto more_pc_4 = more_pc;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Array<crate::check::types::Ty>>>)>>(prism_rtl::rc([=, lx_p0_2_4 = std::move(lx_p0_2_4), more_pc_4 = std::move(more_pc_4)](std::tuple<bool, std::tuple<Text, Array<crate::check::types::Ty>>> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto lx_p0_2_4_5 = lx_p0_2_4;
                                auto more_pc_4_5 = more_pc_4;
                                entered(once_job([=, lx_p0_2_4_5 = std::move(lx_p0_2_4_5), more_pc_4_5 = std::move(more_pc_4_5)]() {
                                return ({
                                    auto ok_pl = p0;
                                    auto&& _ats_pm = p1;
                                    auto&& ats_pm = std::get<1>(_ats_pm);
                                    (prism_rtl::finished(std::move(ok_pl) && run_to_end(fold_job(ats_pm, true, ({
                                    auto lx_p0_2_4_5_5 = lx_p0_2_4_5;
                                    auto more_pc_4_5_5 = more_pc_4_5;
                                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=, lx_p0_2_4_5_5 = std::move(lx_p0_2_4_5_5), more_pc_4_5_5 = std::move(more_pc_4_5_5)](std::tuple<bool, crate::check::types::Ty> _p0) {
                                    auto&& p0 = std::get<0>(_p0);
                                    auto&& p1 = std::get<1>(_p0);
                                    return ({
                                        auto lx_p0_2_4_5_5_5 = lx_p0_2_4_5_5;
                                        auto more_pc_4_5_5_5 = more_pc_4_5_5;
                                        entered(once_job([=, lx_p0_2_4_5_5_5 = std::move(lx_p0_2_4_5_5_5), more_pc_4_5_5_5 = std::move(more_pc_4_5_5_5)]() {
                                        return ({
                                            auto ok2_pn = p0;
                                            auto x_po = p1;
                                            (prism_rtl::finished(std::move(ok2_pn) && ty_podable(lx_p0_2_4_5_5_5, x_po, more_pc_4_5_5_5)));
                                        });
                                    }));
                                    });
                                })));
                                })))));
                                });
                            }));
                            });
                        })));
                        }))));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::env::TyBody::BAlias>(_m)) {
                        auto&& a_pp = prism_rtl::as<crate::check::env::TyBody::BAlias>(_m).a0;
                        _v.set(ty_podable(lx_p0_2, a_pp, more_pc));
                        goto _done;
                    }
                    {
                        _v.set(true);
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(true);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        })));
        });
    });
    });
    })
        : prism_rtl::finished(true);
    });
}


/// `Start TyPodable, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_ty_podable(crate::lower::Lx lx_p0, crate::check::types::Ty t_p1, Array<Text> seen_p2) {
    return prism_rtl::make_rc<TyPodable>(lx_p0, t_p1, seen_p2);
}


/// TyHasEq: unbounded fn Lx, Ty, [Text] -> Bool
bool ty_has_eq(const crate::lower::Lx& lx_p0, const crate::check::types::Ty& t_p1, const Array<Text>& seen_p2) {
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p1)) {
        return false;
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p1)) {
        return false;
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p1)) {
        auto&& m25774_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        if (m25774_2_0 == Text::lit("!")) {
            return false;
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p1)) {
        auto&& m25774_3_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        if (m25774_3_0 == Text::lit("$")) {
            return false;
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p1)) {
        auto&& i_p3 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        return ty_has_eq(lx_p0, prism_rtl::deref(prism_rtl::deref(i_p3)), seen_p2);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p1)) {
        auto&& ts_p4 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p1).a0;
        return run_to_end(fold_job(ts_p4, true, ({
            auto lx_p0_1 = lx_p0;
            auto seen_p2_2 = seen_p2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1), seen_p2_2 = std::move(seen_p2_2)](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_p0_1_3 = lx_p0_1;
                auto seen_p2_2_3 = seen_p2_2;
                entered(once_job([=, lx_p0_1_3 = std::move(lx_p0_1_3), seen_p2_2_3 = std::move(seen_p2_2_3)]() {
                return ({
                    auto ok_p5 = p0;
                    auto x_p6 = p1;
                    (prism_rtl::finished(std::move(ok_p5) && ty_has_eq(lx_p0_1_3, x_p6, seen_p2_2_3)));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p1)) {
        auto&& e_p7 = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p1).a0;
        return ty_has_eq(lx_p0, prism_rtl::deref(prism_rtl::deref(e_p7)), seen_p2);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p1)) {
        auto&& k_p8 = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a0;
        auto&& v_p9 = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a1;
        return ty_has_eq(lx_p0, prism_rtl::deref(prism_rtl::deref(k_p8)), seen_p2) && ty_has_eq(lx_p0, prism_rtl::deref(prism_rtl::deref(v_p9)), seen_p2);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t_p1)) {
        return true;
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(t_p1)) {
        return true;
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1)) {
        auto&& n_pa = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& args_pb = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        return crate::check::types::has_text(seen_p2, n_pa)
            ? true
            : ({
            auto args_ok_pc = run_to_end(fold_job(args_pb, true, ({
                auto lx_p0_1 = lx_p0;
                auto seen_p2_2 = seen_p2;
                auto n_pa_3 = n_pa;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1), seen_p2_2 = std::move(seen_p2_2), n_pa_3 = std::move(n_pa_3)](std::tuple<bool, crate::check::types::Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto lx_p0_1_4 = lx_p0_1;
                    auto seen_p2_2_4 = seen_p2_2;
                    auto n_pa_3_4 = n_pa_3;
                    entered(once_job([=, lx_p0_1_4 = std::move(lx_p0_1_4), seen_p2_2_4 = std::move(seen_p2_2_4), n_pa_3_4 = std::move(n_pa_3_4)]() {
                    return ({
                        auto ok_pd = p0;
                        auto x_pe = p1;
                        (prism_rtl::finished(std::move(ok_pd) && ty_has_eq(lx_p0_1_4, x_pe, crate::prelude::push(seen_p2_2_4, n_pa_3_4))));
                    });
                }));
                });
            })));
            })));
            (std::move(args_ok_pc) && ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g).types, n_pa);
            if (prism_rtl::is_some(_m)) {
                auto&& ti_pf = prism_rtl::some_of(_m);
                _v.set(fold(prism_rtl::deref(ti_pf).derives, false, [&](const bool& f_pg, const Text& d_ph) { return prism_rtl::deref(f_pg) || (crate::check::types::bare_name(d_ph) == Text::lit("Eq")); }) || has_own_eq(lx_p0, n_pa));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(true);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        }));
        });
    }
    {
        return false;
    }
}


/// HasOwnEq: fn Lx, Text -> Bool
bool has_own_eq(const crate::lower::Lx& lx_p0, const Text& tn_p1) {
    return fold(or_(crate::prelude::get(prism_rtl::deref(lx_p0.g).impls, Text::lit("Prelude.Eq")), Array<crate::check::env::ImplInfo>{}), false, [&](const bool& f_p2, const crate::check::env::ImplInfo& im_p3) { return prism_rtl::deref(f_p2) || (crate::lower::functions::head_name(prism_rtl::deref(im_p3).head) == tn_p1); });
}


/// CaseField: unbounded fn Lx, Text, Nat, Ty -> OutTy
crate::lower::model::OutTy case_field(const crate::lower::Lx& lx_p0, const Text& ck_p1, const Nat& i_p2, const crate::check::types::Ty& t_p3) {
    auto rt_p4 = crate::lower::types::out_ty_of(lx_p0, t_p3);
    return crate::lower::types::rc_field(lx_p0, ck_p1, i_p2)
        ? crate::lower::model::OutTy(crate::lower::model::OutTy::OutRc{prism_rtl::rc(rt_p4)})
        : rt_p4;
}


prism_rtl::Turn<crate::lower::model::OutTy> CaseField::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& ck_p1 = this->ck_p1;
    const auto& i_p2 = this->i_p2;
    const auto& t_p3 = this->t_p3;
    auto ck_p1_1 = ck_p1;
    auto i_p2_2 = i_p2;
    auto lx_p0_3 = lx_p0;
    auto t_p3_4 = t_p3;
    return call_then(crate::lower::types::start_out_ty_of(lx_p0_3, t_p3_4), [=](crate::lower::model::OutTy out_ty_of_26752) {
        return ({
            auto rt_p4 = out_ty_of_26752;
            (crate::lower::types::rc_field(lx_p0_3, ck_p1_1, i_p2_2)
            ? prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutRc{prism_rtl::rc(rt_p4)}))
            : prism_rtl::finished(rt_p4));
        });
    });
}


/// `Start CaseField, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::OutTy> start_case_field(crate::lower::Lx lx_p0, Text ck_p1, Nat i_p2, crate::check::types::Ty t_p3) {
    return prism_rtl::make_rc<CaseField>(lx_p0, ck_p1, i_p2, t_p3);
}


/// TypeDoc: fn Lx, TyInfo -> Text
Text type_doc(const crate::lower::Lx& lx_p0, const crate::check::env::TyInfo& ti_p1) {
    auto&& _m = index(prism_rtl::deref(lx_p0.g).srcs, ti_p1.file);
    if (prism_rtl::is_some(_m)) {
        auto&& src_p2 = prism_rtl::some_of(_m);
        return crate::syntax::lexer::chars::trim(crate::check::errors::line_text(src_p2, crate::check::errors::cline_of(prism_rtl::deref(src_p2).starts, prism_rtl::deref(ti_p1.span).start)));
    }
    if (prism_rtl::is_none(_m)) {
        return ti_p1.name;
    }
    prism_rtl::unreachable("no arm matched");
}


/// TagDefOf: unbounded fn Lx, TagInfo -> TagDef
crate::lower::model::TagDef tag_def_of(const crate::lower::Lx& lx_p0, const crate::check::env::TagInfo& tg_p1) {
    auto fields_p2 = run_to_end(each_job(level_fields(tg_p1), ({
        auto lx_p0_1 = lx_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text, crate::lower::model::OutTy>>(std::tuple<Text, crate::check::types::Ty>)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1)](std::tuple<Text, crate::check::types::Ty> p0) {
        return ({
            auto lx_p0_1_2 = lx_p0_1;
            entered(once_job([=, lx_p0_1_2 = std::move(lx_p0_1_2)]() {
            return ({
                auto [fname_p3, ft_p4] = p0;
                call_then(crate::lower::types::start_out_ty_of(lx_p0_1_2, crate::lower::types::peel(ft_p4)), [=](crate::lower::model::OutTy out_ty_of_27262) { return prism_rtl::finished(std::tuple{fname_p3, crate::lower::snake(fname_p3), out_ty_of_27262}); });
            });
        }));
        });
    }));
    })));
    return crate::lower::model::TagDef{.name = crate::lower::tag_struct(tg_p1.name), .tag_name = tg_p1.name, .fields = fields_p2, .doc = type_doc(lx_p0, crate::check::env::TyInfo{.name = tg_p1.name, .home = tg_p1.home, .params = Array<Text>{}, .body = crate::check::env::TyBody(crate::check::env::TyBody::BOpaque{}), .derives = Array<Text>{}, .file = tg_p1.file, .span = tg_p1.span}), .pod = run_to_end(fold_job(fields_p2, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto ok_p5 = p0;
                auto&& _t_p6 = p1;
                auto&& t_p6 = std::get<2>(_t_p6);
                (prism_rtl::finished(std::move(ok_p5) && crate::lower::types::podable(t_p6)));
            });
        }));
    })))), .eq = run_to_end(fold_job(fields_p2, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto ok_p7 = p0;
                auto&& _t_p8 = p1;
                auto&& t_p8 = std::get<2>(_t_p8);
                (prism_rtl::finished(std::move(ok_p7) && crate::lower::types::runtime_eq(t_p8)));
            });
        }));
    }))))};
}


prism_rtl::Turn<crate::lower::model::TagDef> TagDefOf::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& tg_p1 = this->tg_p1;
    auto lx_p0_1 = lx_p0;
    auto tg_p1_2 = tg_p1;
    return call_value(each_job(level_fields(tg_p1_2), ({
        auto lx_p0_1_3 = lx_p0_1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text, crate::lower::model::OutTy>>(std::tuple<Text, crate::check::types::Ty>)>>(prism_rtl::rc([=, lx_p0_1_3 = std::move(lx_p0_1_3)](std::tuple<Text, crate::check::types::Ty> p0) {
        return ({
            auto lx_p0_1_3_3 = lx_p0_1_3;
            entered(once_job([=, lx_p0_1_3_3 = std::move(lx_p0_1_3_3)]() {
            return ({
                auto [fname_p3, ft_p4] = p0;
                call_then(crate::lower::types::start_out_ty_of(lx_p0_1_3_3, crate::lower::types::peel(ft_p4)), [=](crate::lower::model::OutTy out_ty_of_27262) { return prism_rtl::finished(std::tuple{fname_p3, crate::lower::snake(fname_p3), out_ty_of_27262}); });
            });
        }));
        });
    }));
    })), [=](Array<std::tuple<Text, Text, crate::lower::model::OutTy>> each_27197) {
        return ({
            auto fields_p2 = each_27197;
            call_value(fold_job(fields_p2, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto ok_p5 = p0;
                    auto&& _t_p6 = p1;
                    auto&& t_p6 = std::get<2>(_t_p6);
                    (prism_rtl::finished(std::move(ok_p5) && crate::lower::types::podable(t_p6)));
                });
            }));
        }))), [=](bool fold_27486) {
            return call_value(fold_job(fields_p2, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto ok_p7 = p0;
                        auto&& _t_p8 = p1;
                        auto&& t_p8 = std::get<2>(_t_p8);
                        (prism_rtl::finished(std::move(ok_p7) && crate::lower::types::runtime_eq(t_p8)));
                    });
                }));
            }))), [=](bool fold_27557) { return prism_rtl::finished(crate::lower::model::TagDef{.name = crate::lower::tag_struct(prism_rtl::deref(tg_p1_2).name), .tag_name = prism_rtl::deref(tg_p1_2).name, .fields = fields_p2, .doc = type_doc(lx_p0_1, crate::check::env::TyInfo{.name = prism_rtl::deref(tg_p1_2).name, .home = prism_rtl::deref(tg_p1_2).home, .params = Array<Text>{}, .body = crate::check::env::TyBody(crate::check::env::TyBody::BOpaque{}), .derives = Array<Text>{}, .file = tg_p1_2->file, .span = prism_rtl::deref(tg_p1_2).span}), .pod = fold_27486, .eq = fold_27557}); });
        });
        });
    });
}


/// `Start TagDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::TagDef> start_tag_def_of(crate::lower::Lx lx_p0, crate::check::env::TagInfo tg_p1) {
    return prism_rtl::make_rc<TagDefOf>(lx_p0, tg_p1);
}


/// LevelFields: fn TagInfo -> [((Text, Ty))]
Array<std::tuple<Text, crate::check::types::Ty>> level_fields(const crate::check::env::TagInfo& tg_p0) {
    return filter(tg_p0.fields, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
        auto&& ft_p1 = std::get<1>(_p0);
        return crate::lower::types::layer_of(ft_p1) != crate::lower::types::Layer(crate::lower::types::Layer::LyEv{});
    });
}


/// KindTags: fn Lx, Text, [Text] -> [TagInfo]
Array<crate::check::env::TagInfo> kind_tags(const crate::lower::Lx& lx_p0, const Text& kind_p1, const Array<Text>& mods_p2) {
    return filter(values(prism_rtl::deref(lx_p0.g).tags), [&](const crate::check::env::TagInfo& tg_p3) { return (prism_rtl::deref(tg_p3).kind == kind_p1) && crate::check::types::has_text(mods_p2, prism_rtl::deref(tg_p3).home); });
}


/// RowDefOf: unbounded fn Lx, TyInfo -> RowDef
crate::lower::model::RowDef row_def_of(const crate::lower::Lx& lx_p0, const crate::check::env::TyInfo& ti_p1) {
    auto tags_p2 = kind_tags(lx_p0, ti_p1.name, keys(lx_p0.rs_mods));
    auto cases_p3 = each(tags_p2, [&](const crate::check::env::TagInfo& tg_p6) { return std::tuple{crate::lower::tag_struct(prism_rtl::deref(tg_p6).name), crate::lower::path_in(lx_p0, prism_rtl::deref(tg_p6).home, crate::lower::tag_struct(prism_rtl::deref(tg_p6).name))}; });
    auto pod_p4 = run_to_end(fold_job(tags_p2, true, ({
        auto lx_p0_1 = lx_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::env::TagInfo>)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1)](std::tuple<bool, crate::check::env::TagInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0_1_2 = lx_p0_1;
            entered(once_job([=, lx_p0_1_2 = std::move(lx_p0_1_2)]() {
            return ({
                auto ok_p7 = p0;
                auto tg_p8 = p1;
                (prism_rtl::finished(std::move(ok_p7) && prism_rtl::deref(tag_def_of(lx_p0_1_2, tg_p8)).pod));
            });
        }));
        });
    })));
    })));
    auto eq_p5 = run_to_end(fold_job(tags_p2, true, ({
        auto lx_p0_1 = lx_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::env::TagInfo>)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1)](std::tuple<bool, crate::check::env::TagInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0_1_2 = lx_p0_1;
            entered(once_job([=, lx_p0_1_2 = std::move(lx_p0_1_2)]() {
            return ({
                auto ok_p9 = p0;
                auto tg_pa = p1;
                (prism_rtl::finished(std::move(ok_p9) && prism_rtl::deref(tag_def_of(lx_p0_1_2, tg_pa)).eq));
            });
        }));
        });
    })));
    })));
    return crate::lower::model::RowDef{.name = crate::lower::camel(crate::check::types::bare_name(ti_p1.name)), .prism = ti_p1.name, .cases_ = cases_p3, .pod = std::move(pod_p4), .doc = type_doc(lx_p0, ti_p1), .eq = std::move(eq_p5), .level = false, .deep = Array<Text>{}};
}


prism_rtl::Turn<crate::lower::model::RowDef> RowDefOf::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& ti_p1 = this->ti_p1;
    auto tags_p2 = kind_tags(lx_p0, prism_rtl::deref(ti_p1).name, keys(prism_rtl::deref(lx_p0).rs_mods));
    auto cases_p3 = each(tags_p2, [&](const crate::check::env::TagInfo& tg_p6) { return std::tuple{crate::lower::tag_struct(prism_rtl::deref(tg_p6).name), crate::lower::path_in(lx_p0, prism_rtl::deref(tg_p6).home, crate::lower::tag_struct(prism_rtl::deref(tg_p6).name))}; });
    auto lx_p0_1 = lx_p0;
    auto ti_p1_2 = ti_p1;
    return call_value(fold_job(tags_p2, true, ({
        auto lx_p0_1_3 = lx_p0_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::env::TagInfo>)>>(prism_rtl::rc([=, lx_p0_1_3 = std::move(lx_p0_1_3)](std::tuple<bool, crate::check::env::TagInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0_1_3_3 = lx_p0_1_3;
            entered(once_job([=, lx_p0_1_3_3 = std::move(lx_p0_1_3_3)]() {
            return ({
                auto ok_p7 = p0;
                auto tg_p8 = p1;
                (prism_rtl::finished(std::move(ok_p7) && prism_rtl::deref(tag_def_of(lx_p0_1_3_3, tg_p8)).pod));
            });
        }));
        });
    })));
    })), [=](bool fold_28273) {
        return ({
            auto pod_p4 = fold_28273;
            call_value(fold_job(tags_p2, true, ({
            auto lx_p0_1_3 = lx_p0_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::env::TagInfo>)>>(prism_rtl::rc([=, lx_p0_1_3 = std::move(lx_p0_1_3)](std::tuple<bool, crate::check::env::TagInfo> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_p0_1_3_3 = lx_p0_1_3;
                entered(once_job([=, lx_p0_1_3_3 = std::move(lx_p0_1_3_3)]() {
                return ({
                    auto ok_p9 = p0;
                    auto tg_pa = p1;
                    (prism_rtl::finished(std::move(ok_p9) && prism_rtl::deref(tag_def_of(lx_p0_1_3_3, tg_pa)).eq));
                });
            }));
            });
        })));
        })), [=, pod_p4 = std::move(pod_p4)](bool fold_28342) {
            return ({
                auto eq_p5 = fold_28342;
                (prism_rtl::finished(crate::lower::model::RowDef{.name = crate::lower::camel(crate::check::types::bare_name(prism_rtl::deref(ti_p1_2).name)), .prism = prism_rtl::deref(ti_p1_2).name, .cases_ = cases_p3, .pod = pod_p4, .doc = type_doc(lx_p0_1, ti_p1_2), .eq = std::move(eq_p5), .level = false, .deep = Array<Text>{}}));
            });
        });
        });
    });
}


/// `Start RowDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::RowDef> start_row_def_of(crate::lower::Lx lx_p0, crate::check::env::TyInfo ti_p1) {
    return prism_rtl::make_rc<RowDefOf>(lx_p0, ti_p1);
}


/// ElemRow: unbounded fn Lx, [Text] -> RowDef
crate::lower::model::RowDef elem_row(const crate::lower::Lx& lx_p0, const Array<Text>& mods_p1) {
    auto tags_p2 = kind_tags(lx_p0, Text::lit("Element"), crate::prelude::push(mods_p1, Text::lit("Prelude")));
    auto cases_p3 = each(tags_p2, [&](const crate::check::env::TagInfo& tg_p7) { return std::tuple{crate::lower::tag_struct(prism_rtl::deref(tg_p7).name), prism_rtl::cat(crate::lower::rust_mod_name(prism_rtl::deref(tg_p7).home), "::", crate::lower::tag_struct(prism_rtl::deref(tg_p7).name))}; });
    auto pod_p4 = run_to_end(fold_job(tags_p2, true, ({
        auto lx_p0_1 = lx_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::env::TagInfo>)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1)](std::tuple<bool, crate::check::env::TagInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0_1_2 = lx_p0_1;
            entered(once_job([=, lx_p0_1_2 = std::move(lx_p0_1_2)]() {
            return ({
                auto ok_p8 = p0;
                auto tg_p9 = p1;
                (prism_rtl::finished(std::move(ok_p8) && prism_rtl::deref(tag_def_of(lx_p0_1_2, tg_p9)).pod));
            });
        }));
        });
    })));
    })));
    auto eq_p5 = run_to_end(fold_job(tags_p2, true, ({
        auto lx_p0_1 = lx_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::env::TagInfo>)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1)](std::tuple<bool, crate::check::env::TagInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0_1_2 = lx_p0_1;
            entered(once_job([=, lx_p0_1_2 = std::move(lx_p0_1_2)]() {
            return ({
                auto ok_pa = p0;
                auto tg_pb = p1;
                (prism_rtl::finished(std::move(ok_pa) && prism_rtl::deref(tag_def_of(lx_p0_1_2, tg_pb)).eq));
            });
        }));
        });
    })));
    })));
    auto deep_p6 = run_to_end(fold_job(tags_p2, Array<Text>{}, ({
        auto lx_p0_1 = lx_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::env::TagInfo>)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1)](std::tuple<Array<Text>, crate::check::env::TagInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0_1_2 = lx_p0_1;
            entered(once_job([=, lx_p0_1_2 = std::move(lx_p0_1_2)]() {
            return ({
                auto acc_pc = p0;
                auto tg_pd = p1;
                call_then(start_tag_holds_dyn(lx_p0_1_2, tg_pd), [=, acc_pc = std::move(acc_pc)](bool tag_holds_dyn_29144) {
                return tag_holds_dyn_29144
                    ? prism_rtl::finished(crate::prelude::push(acc_pc, crate::lower::tag_struct(prism_rtl::deref(tg_pd).name)))
                    : prism_rtl::finished(acc_pc);
            });
            });
        }));
        });
    })));
    })));
    return crate::lower::model::RowDef{.name = Text::lit("Elem"), .prism = Text::lit("Elem"), .cases_ = cases_p3, .pod = std::move(pod_p4), .doc = Text::lit("`Elem r`: an element as a document holds it, its `Level` in a tick."), .eq = std::move(eq_p5), .level = true, .deep = deep_p6};
}


prism_rtl::Turn<crate::lower::model::RowDef> ElemRow::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& mods_p1 = this->mods_p1;
    auto tags_p2 = kind_tags(lx_p0, Text::lit("Element"), crate::prelude::push(mods_p1, Text::lit("Prelude")));
    auto cases_p3 = each(tags_p2, [&](const crate::check::env::TagInfo& tg_p7) { return std::tuple{crate::lower::tag_struct(prism_rtl::deref(tg_p7).name), prism_rtl::cat(crate::lower::rust_mod_name(prism_rtl::deref(tg_p7).home), "::", crate::lower::tag_struct(prism_rtl::deref(tg_p7).name))}; });
    auto lx_p0_1 = lx_p0;
    return call_value(fold_job(tags_p2, true, ({
        auto lx_p0_1_2 = lx_p0_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::env::TagInfo>)>>(prism_rtl::rc([=, lx_p0_1_2 = std::move(lx_p0_1_2)](std::tuple<bool, crate::check::env::TagInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0_1_2_2 = lx_p0_1_2;
            entered(once_job([=, lx_p0_1_2_2 = std::move(lx_p0_1_2_2)]() {
            return ({
                auto ok_p8 = p0;
                auto tg_p9 = p1;
                (prism_rtl::finished(std::move(ok_p8) && prism_rtl::deref(tag_def_of(lx_p0_1_2_2, tg_p9)).pod));
            });
        }));
        });
    })));
    })), [=](bool fold_28974) {
        return ({
            auto pod_p4 = fold_28974;
            call_value(fold_job(tags_p2, true, ({
            auto lx_p0_1_2 = lx_p0_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::env::TagInfo>)>>(prism_rtl::rc([=, lx_p0_1_2 = std::move(lx_p0_1_2)](std::tuple<bool, crate::check::env::TagInfo> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_p0_1_2_2 = lx_p0_1_2;
                entered(once_job([=, lx_p0_1_2_2 = std::move(lx_p0_1_2_2)]() {
                return ({
                    auto ok_pa = p0;
                    auto tg_pb = p1;
                    (prism_rtl::finished(std::move(ok_pa) && prism_rtl::deref(tag_def_of(lx_p0_1_2_2, tg_pb)).eq));
                });
            }));
            });
        })));
        })), [=, pod_p4 = std::move(pod_p4)](bool fold_29043) {
            return ({
                auto eq_p5 = fold_29043;
                call_value(fold_job(tags_p2, Array<Text>{}, ({
                auto lx_p0_1_2 = lx_p0_1;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::env::TagInfo>)>>(prism_rtl::rc([=, lx_p0_1_2 = std::move(lx_p0_1_2)](std::tuple<Array<Text>, crate::check::env::TagInfo> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto lx_p0_1_2_2 = lx_p0_1_2;
                    entered(once_job([=, lx_p0_1_2_2 = std::move(lx_p0_1_2_2)]() {
                    return ({
                        auto acc_pc = p0;
                        auto tg_pd = p1;
                        call_then(start_tag_holds_dyn(lx_p0_1_2_2, tg_pd), [=, acc_pc = std::move(acc_pc)](bool tag_holds_dyn_29144) {
                        return tag_holds_dyn_29144
                            ? prism_rtl::finished(crate::prelude::push(acc_pc, crate::lower::tag_struct(prism_rtl::deref(tg_pd).name)))
                            : prism_rtl::finished(acc_pc);
                    });
                    });
                }));
                });
            })));
            })), [=, eq_p5 = std::move(eq_p5)](Array<Text> fold_29113) {
                return ({
                    auto deep_p6 = fold_29113;
                    (prism_rtl::finished(crate::lower::model::RowDef{.name = Text::lit("Elem"), .prism = Text::lit("Elem"), .cases_ = cases_p3, .pod = pod_p4, .doc = Text::lit("`Elem r`: an element as a document holds it, its `Level` in a tick."), .eq = eq_p5, .level = true, .deep = deep_p6}));
                });
            });
            });
        });
        });
    });
}


/// `Start ElemRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::RowDef> start_elem_row(crate::lower::Lx lx_p0, Array<Text> mods_p1) {
    return prism_rtl::make_rc<ElemRow>(lx_p0, mods_p1);
}


/// TagHoldsDyn: unbounded fn Lx, TagInfo -> Bool
bool tag_holds_dyn(const crate::lower::Lx& lx_p0, const crate::check::env::TagInfo& tg_p1) {
    return run_to_end(fold_job(prism_rtl::deref(tag_def_of(lx_p0, tg_p1)).fields, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto f_p2 = p0;
                auto&& _t_p3 = p1;
                auto&& t_p3 = std::get<2>(_t_p3);
                (prism_rtl::finished(std::move(f_p2) || crate::lower::types::holds_dyn(t_p3)));
            });
        }));
    }))));
}


prism_rtl::Turn<bool> TagHoldsDyn::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& tg_p1 = this->tg_p1;
    auto lx_p0_1 = lx_p0;
    auto tg_p1_2 = tg_p1;
    return call_then(start_tag_def_of(lx_p0_1, tg_p1_2), [=](crate::lower::model::TagDef tag_def_of_29565) {
        return fold_job(prism_rtl::deref(tag_def_of_29565).fields, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto f_p2 = p0;
                    auto&& _t_p3 = p1;
                    auto&& t_p3 = std::get<2>(_t_p3);
                    (prism_rtl::finished(std::move(f_p2) || crate::lower::types::holds_dyn(t_p3)));
                });
            }));
        })))->cycle();
    });
}


/// `Start TagHoldsDyn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_tag_holds_dyn(crate::lower::Lx lx_p0, crate::check::env::TagInfo tg_p1) {
    return prism_rtl::make_rc<TagHoldsDyn>(lx_p0, tg_p1);
}


/// AnswerEnum: unbounded fn Lx, [Text] -> AnswerDef
crate::lower::model::AnswerDef answer_enum(const crate::lower::Lx& lx_p0, const Array<Text>& mods_p1) {
    auto tags_p2 = kind_tags(lx_p0, Text::lit("Element"), crate::prelude::push(mods_p1, Text::lit("Prelude")));
    return crate::lower::model::AnswerDef{.cases_ = run_to_end(each_job(tags_p2, ({
        auto lx_p0_1 = lx_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::AnswerCase>(crate::check::env::TagInfo)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1)](crate::check::env::TagInfo p0) {
        return ({
            auto lx_p0_1_2 = lx_p0_1;
            entered(once_job([=, lx_p0_1_2 = std::move(lx_p0_1_2)]() {
            return ({
                auto tg_p3 = p0;
                call_then(start_answer_ty(lx_p0_1_2, tg_p3), [=](crate::lower::model::OutTy answer_ty_30041) { return prism_rtl::finished(crate::lower::model::AnswerCase{.variant = crate::lower::tag_struct(prism_rtl::deref(tg_p3).name), .accessor = crate::lower::node_::elements::answer_accessor(tg_p3), .struct_path = prism_rtl::cat(crate::lower::rust_mod_name(prism_rtl::deref(tg_p3).home), "::", crate::lower::tag_struct(prism_rtl::deref(tg_p3).name)), .tag_name = prism_rtl::deref(tg_p3).name, .ty = answer_ty_30041}); });
            });
        }));
        });
    })));
    })))};
}


prism_rtl::Turn<crate::lower::model::AnswerDef> AnswerEnum::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& mods_p1 = this->mods_p1;
    auto tags_p2 = kind_tags(lx_p0, Text::lit("Element"), crate::prelude::push(mods_p1, Text::lit("Prelude")));
    auto lx_p0_1 = lx_p0;
    return call_value(each_job(tags_p2, ({
        auto lx_p0_1_2 = lx_p0_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::AnswerCase>(crate::check::env::TagInfo)>>(prism_rtl::rc([=, lx_p0_1_2 = std::move(lx_p0_1_2)](crate::check::env::TagInfo p0) {
        return ({
            auto lx_p0_1_2_2 = lx_p0_1_2;
            entered(once_job([=, lx_p0_1_2_2 = std::move(lx_p0_1_2_2)]() {
            return ({
                auto tg_p3 = p0;
                call_then(start_answer_ty(lx_p0_1_2_2, tg_p3), [=](crate::lower::model::OutTy answer_ty_30041) { return prism_rtl::finished(crate::lower::model::AnswerCase{.variant = crate::lower::tag_struct(prism_rtl::deref(tg_p3).name), .accessor = crate::lower::node_::elements::answer_accessor(tg_p3), .struct_path = prism_rtl::cat(crate::lower::rust_mod_name(prism_rtl::deref(tg_p3).home), "::", crate::lower::tag_struct(prism_rtl::deref(tg_p3).name)), .tag_name = prism_rtl::deref(tg_p3).name, .ty = answer_ty_30041}); });
            });
        }));
        });
    })));
    })), [=](Array<crate::lower::model::AnswerCase> each_29876) { return prism_rtl::finished(crate::lower::model::AnswerDef{.cases_ = each_29876}); });
}


/// `Start AnswerEnum, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::AnswerDef> start_answer_enum(crate::lower::Lx lx_p0, Array<Text> mods_p1) {
    return prism_rtl::make_rc<AnswerEnum>(lx_p0, mods_p1);
}


/// AnswerTy: unbounded fn Lx, TagInfo -> OutTy
crate::lower::model::OutTy answer_ty(const crate::lower::Lx& lx_p0, const crate::check::env::TagInfo& tg_p1) {
    auto out_p2 = crate::lower::types::peel(tg_p1.out);
    auto part_p3 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::Ty> _v;
        if (prism_rtl::is<crate::check::types::Ty::TyTuple>(out_p2)) {
            auto&& cs_p4 = prism_rtl::as<crate::check::types::Ty::TyTuple>(out_p2).a0;
            _v.set(fold(cs_p4, out_p2, [&](const crate::check::types::Ty& found_p5, const crate::check::types::Ty& c_p6) {
                return crate::lower::types::layer_of(c_p6) == crate::lower::types::Layer(crate::lower::types::Layer::LyEv{})
                    ? crate::lower::types::peel(c_p6)
                    : found_p5;
            }));
            goto _done;
        }
        {
            _v.set(out_p2);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto&& _m = crate::lower::types::out_ty_of(lx_p0, part_p3);
    if (prism_rtl::is<crate::lower::model::OutTy::OutGen>(_m)) {
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutPod{});
    }
    {
        auto&& t_p7 = _m;
        return t_p7;
    }
}


prism_rtl::Turn<crate::lower::model::OutTy> AnswerTy::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& tg_p1 = this->tg_p1;
    auto out_p2 = crate::lower::types::peel(tg_p1->out);
    auto part_p3 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::Ty> _v;
        if (prism_rtl::is<crate::check::types::Ty::TyTuple>(out_p2)) {
            auto&& cs_p4 = prism_rtl::as<crate::check::types::Ty::TyTuple>(out_p2).a0;
            _v.set(fold(cs_p4, out_p2, [&](const crate::check::types::Ty& found_p5, const crate::check::types::Ty& c_p6) {
                return crate::lower::types::layer_of(c_p6) == crate::lower::types::Layer(crate::lower::types::Layer::LyEv{})
                    ? crate::lower::types::peel(c_p6)
                    : found_p5;
            }));
            goto _done;
        }
        {
            _v.set(out_p2);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto lx_p0_1 = lx_p0;
    return call_then(crate::lower::types::start_out_ty_of(lx_p0_1, part_p3), [=](crate::lower::model::OutTy out_ty_of_30568) {
        return ({
            prism_rtl::is<crate::lower::model::OutTy::OutGen>(out_ty_of_30568) ? prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutPod{}))
            : ({
            auto&& t_p7 = out_ty_of_30568;
            prism_rtl::finished(t_p7);
        });
        });
    });
}


/// `Start AnswerTy, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::OutTy> start_answer_ty(crate::lower::Lx lx_p0, crate::check::env::TagInfo tg_p1) {
    return prism_rtl::make_rc<AnswerTy>(lx_p0, tg_p1);
}


/// TagPaths: fn Lx, TagInfo -> ((Text, Text))
std::tuple<Text, Text> tag_paths(const crate::lower::Lx& lx_p0, const crate::check::env::TagInfo& tg_p1) {
    auto st_p2 = crate::lower::tag_struct(tg_p1.name);
    auto struct_path_p3 = crate::lower::path_in(lx_p0, tg_p1.home, st_p2);
    return std::tuple{prism_rtl::cat(kind_path(lx_p0, tg_p1.kind), "::", st_p2), struct_path_p3};
}


/// VariantOf: fn Lx, TagInfo -> Text
Text variant_of(const crate::lower::Lx& lx_p0, const crate::check::env::TagInfo& tg_p1) {
    return prism_rtl::cat(kind_path(lx_p0, tg_p1.kind), "::", crate::lower::tag_struct(tg_p1.name));
}


/// KindPath: fn Lx, Text -> Text
Text kind_path(const crate::lower::Lx& lx_p0, const Text& kind_p1) {
    return kind_p1 == Text::lit("Element")
        ? Text::lit("crate::Elem")
        : crate::lower::path_in(lx_p0, prism_rtl::deref(or_(crate::prelude::get(prism_rtl::deref(lx_p0.g).types, kind_p1), crate::check::env::names::dummy_ty_info())).home, crate::lower::camel(crate::check::types::bare_name(kind_p1)));
}


/// CheckDefOf: unbounded fn Lx, CheckDecl -> CheckDef
crate::lower::model::CheckDef check_def_of(const crate::lower::Lx& lx_p0, const crate::syntax::decls::CheckDecl& c_p1) {
    return crate::lower::model::CheckDef{.name = prism_rtl::deref(c_p1.name).name, .lines = run_to_end(each_job(c_p1.lines, ({
        auto lx_p0_1 = lx_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::decls::CheckLine)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1)](crate::syntax::decls::CheckLine p0) {
        return ({
            auto lx_p0_1_2 = lx_p0_1;
            entered(once_job([=, lx_p0_1_2 = std::move(lx_p0_1_2)]() {
            return ({
                auto l_p2 = p0;
                call_then(crate::lower::expr::start_value_of(lx_p0_1_2, crate::lower::types::empty_env(), prism_rtl::deref(l_p2).expr), [=](crate::lower::types::Vl value_of_31416) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Ok"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::types::own(value_of_31416)), Text::lit("to_pod"), Array<crate::lower::model::Ex>{}})})})); });
            });
        }));
        });
    })));
    })))};
}


prism_rtl::Turn<crate::lower::model::CheckDef> CheckDefOf::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& c_p1 = this->c_p1;
    auto c_p1_1 = c_p1;
    auto lx_p0_2 = lx_p0;
    return call_value(each_job(prism_rtl::deref(c_p1_1).lines, ({
        auto lx_p0_2_3 = lx_p0_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::decls::CheckLine)>>(prism_rtl::rc([=, lx_p0_2_3 = std::move(lx_p0_2_3)](crate::syntax::decls::CheckLine p0) {
        return ({
            auto lx_p0_2_3_3 = lx_p0_2_3;
            entered(once_job([=, lx_p0_2_3_3 = std::move(lx_p0_2_3_3)]() {
            return ({
                auto l_p2 = p0;
                call_then(crate::lower::expr::start_value_of(lx_p0_2_3_3, crate::lower::types::empty_env(), prism_rtl::deref(l_p2).expr), [=](crate::lower::types::Vl value_of_31416) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Ok"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::types::own(value_of_31416)), Text::lit("to_pod"), Array<crate::lower::model::Ex>{}})})})); });
            });
        }));
        });
    })));
    })), [=](Array<crate::lower::model::Ex> each_31368) { return prism_rtl::finished(crate::lower::model::CheckDef{.name = prism_rtl::deref(prism_rtl::deref(c_p1_1).name).name, .lines = each_31368}); });
}


/// `Start CheckDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::CheckDef> start_check_def_of(crate::lower::Lx lx_p0, crate::syntax::decls::CheckDecl c_p1) {
    return prism_rtl::make_rc<CheckDefOf>(lx_p0, c_p1);
}

}  // namespace crate::lower::program
