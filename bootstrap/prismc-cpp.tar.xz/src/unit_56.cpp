// The modules `Syntax.Lexer.Literals`, `Syntax.Lexer.Regexes`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <syntax/lexer/literals/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Syntax.Lexer.Literals`, from `target/bootstrap/cpp-src/prismc/syntax/lexer/literals.prism`.
namespace crate::syntax::lexer::literals {

/// LexNumber: unbounded fn Lex, Text -> ((TokKind, Lex))
std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> lex_number(const crate::syntax::lexer::Lex& l, const Text& sigils) {
    return (crate::syntax::lexer::chars::peek(l) == Text::lit("0")) && crate::syntax::lexer::chars::contains(Text::lit("xob"), crate::syntax::lexer::chars::peek_at(l, Nat(1u)))
        ? lex_radix(l, sigils)
        : lex_decimal(l, sigils);
}


prism_rtl::Turn<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> LexNumber::cycle() const {
    const auto& l = this->l;
    const auto& sigils = this->sigils;
    return (crate::syntax::lexer::chars::peek(l) == Text::lit("0")) && crate::syntax::lexer::chars::contains(Text::lit("xob"), crate::syntax::lexer::chars::peek_at(l, Nat(1u)))
        ? prism_rtl::more(prism_rtl::rc(LexRadix(l, sigils)))
        : prism_rtl::more(prism_rtl::rc(LexDecimal(l, sigils)));
}


/// `Start LexNumber, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> start_lex_number(crate::syntax::lexer::Lex l, Text sigils) {
    return prism_rtl::make_rc<LexNumber>(l, sigils);
}


/// LexRadix: unbounded fn Lex, Text -> ((TokKind, Lex))
std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> lex_radix(const crate::syntax::lexer::Lex& l0, const Text& sigils) {
    auto start = l0.pos;
    auto radix = crate::syntax::lexer::chars::peek_at(l0, Nat(1u));
    auto l1 = crate::syntax::lexer::chars::forward(l0, Nat(2u));
    auto digits = radix == Text::lit("x")
        ? ([]() -> const Regex& { static const Regex r = Regex::lit("[0-9a-fA-F_]*", ""); return r; }())
        : radix == Text::lit("o")
        ? ([]() -> const Regex& { static const Regex r = Regex::lit("[0-7_]*", ""); return r; }())
        : ([]() -> const Regex& { static const Regex r = Regex::lit("[01_]*", ""); return r; }());
    auto l2 = ({
        crate::syntax::lexer::Lex this_ = l1;
        this_.pos = crate::syntax::lexer::chars::match_end(digits, this_.src, this_.pos);
        (std::move(this_));
    });
    auto l3 = prism_rtl::deref(l2).pos == prism_rtl::deref(l1).pos
        ? crate::syntax::lexer::chars::lex_err(l2, start, prism_rtl::deref(l2).pos, Text::lit("a radix prefix needs digits after it"))
        : l2;
    auto l4 = check_no_suffix(l3, start);
    auto kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KInt{sigils, crate::syntax::lexer::chars::slice(l4, start, prism_rtl::deref(l4).pos)});
    return std::tuple{kind, l4};
}


prism_rtl::Turn<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> LexRadix::cycle() const {
    const auto& l0 = this->l0;
    const auto& sigils = this->sigils;
    auto start = prism_rtl::deref(l0).pos;
    auto radix = crate::syntax::lexer::chars::peek_at(l0, Nat(1u));
    auto l1 = crate::syntax::lexer::chars::forward(l0, Nat(2u));
    auto digits = radix == Text::lit("x")
        ? ([]() -> const Regex& { static const Regex r = Regex::lit("[0-9a-fA-F_]*", ""); return r; }())
        : radix == Text::lit("o")
        ? ([]() -> const Regex& { static const Regex r = Regex::lit("[0-7_]*", ""); return r; }())
        : ([]() -> const Regex& { static const Regex r = Regex::lit("[01_]*", ""); return r; }());
    auto l2 = ({
        crate::syntax::lexer::Lex this_ = l1;
        this_.pos = crate::syntax::lexer::chars::match_end(digits, this_.src, this_.pos);
        (std::move(this_));
    });
    auto l3 = prism_rtl::deref(l2).pos == prism_rtl::deref(l1).pos
        ? crate::syntax::lexer::chars::lex_err(l2, start, prism_rtl::deref(l2).pos, Text::lit("a radix prefix needs digits after it"))
        : l2;
    auto sigils_1 = sigils;
    return call_then(start_check_no_suffix(l3, start), [=](crate::syntax::lexer::Lex check_no_suffix_1221) {
        return ({
            auto l4 = check_no_suffix_1221;
            auto kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KInt{sigils_1, crate::syntax::lexer::chars::slice(l4, start, prism_rtl::deref(l4).pos)});
            (prism_rtl::finished(std::tuple{kind, l4}));
        });
    });
}


/// `Start LexRadix, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> start_lex_radix(crate::syntax::lexer::Lex l0, Text sigils) {
    return prism_rtl::make_rc<LexRadix>(l0, sigils);
}


/// SkipDigits: unbounded fn Lex -> Lex
crate::syntax::lexer::Lex skip_digits(const crate::syntax::lexer::Lex& l) {
    crate::syntax::lexer::Lex this_ = l;
    this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[0-9_]*", ""); return r; }()), this_.src, this_.pos);
    return this_;
}


prism_rtl::Turn<crate::syntax::lexer::Lex> SkipDigits::cycle() const {
    const auto& l = this->l;
    return prism_rtl::finished(({
        crate::syntax::lexer::Lex this_ = l;
        this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[0-9_]*", ""); return r; }()), this_.src, this_.pos);
        (std::move(this_));
    }));
}


/// `Start SkipDigits, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_skip_digits(crate::syntax::lexer::Lex l) {
    return prism_rtl::make_rc<SkipDigits>(l);
}


/// LexDecimal: unbounded fn Lex, Text -> ((TokKind, Lex))
std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> lex_decimal(const crate::syntax::lexer::Lex& l0, const Text& sigils) {
    auto start = l0.pos;
    auto l1 = skip_digits(l0);
    auto next_ = crate::syntax::lexer::chars::peek_at(l1, Nat(1u));
    return (crate::syntax::lexer::chars::peek(l1) == Text::lit(".")) && crate::syntax::lexer::chars::is_digit(next_)
        ? number_tail(skip_digits(crate::syntax::lexer::chars::bump(l1)), sigils, start, true)
        : (((crate::syntax::lexer::chars::peek(l1) == Text::lit(".")) && (next_ != Text::lit("."))) && (next_ != Text::lit(""))) && (!crate::syntax::lexer::chars::is_ident_start(next_))
        ? ({
        auto l2 = crate::syntax::lexer::chars::bump(l1);
        auto l3 = crate::syntax::lexer::chars::lex_err(l2, start, prism_rtl::deref(l2).pos, prism_rtl::cat("`", crate::syntax::lexer::chars::slice(l2, start, prism_rtl::deref(l2).pos), "` is not a number: a decimal literal has digits on both sides of its point"));
        auto kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KFloat{sigils, crate::syntax::lexer::chars::slice(l3, start, crate::syntax::lexer::chars::dec(prism_rtl::deref(l2).pos))});
        std::tuple{kind, l3};
    })
        : number_tail(l1, sigils, start, false);
}


prism_rtl::Turn<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> LexDecimal::cycle() const {
    const auto& l0 = this->l0;
    const auto& sigils = this->sigils;
    auto start = prism_rtl::deref(l0).pos;
    auto l0_1 = l0;
    auto sigils_2 = sigils;
    return call_then(start_skip_digits(l0_1), [=](crate::syntax::lexer::Lex skip_digits_1549) {
        return ({
            auto l1 = skip_digits_1549;
            auto next_ = crate::syntax::lexer::chars::peek_at(l1, Nat(1u));
            (crate::syntax::lexer::chars::peek(l1) == Text::lit(".")) && crate::syntax::lexer::chars::is_digit(next_)
            ? call_then(start_skip_digits(crate::syntax::lexer::chars::bump(l1)), [=](crate::syntax::lexer::Lex skip_digits_1647) { return prism_rtl::more(prism_rtl::rc(NumberTail(skip_digits_1647, sigils_2, start, true))); })
            : (((crate::syntax::lexer::chars::peek(l1) == Text::lit(".")) && (next_ != Text::lit("."))) && (next_ != Text::lit(""))) && (!crate::syntax::lexer::chars::is_ident_start(next_))
            ? ({
            auto l2 = crate::syntax::lexer::chars::bump(l1);
            auto l3 = crate::syntax::lexer::chars::lex_err(l2, start, prism_rtl::deref(l2).pos, prism_rtl::cat("`", crate::syntax::lexer::chars::slice(l2, start, prism_rtl::deref(l2).pos), "` is not a number: a decimal literal has digits on both sides of its point"));
            auto kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KFloat{sigils_2, crate::syntax::lexer::chars::slice(l3, start, crate::syntax::lexer::chars::dec(prism_rtl::deref(l2).pos))});
            (prism_rtl::finished(std::tuple{kind, l3}));
        })
            : prism_rtl::more(prism_rtl::rc(NumberTail(l1, sigils_2, start, false)));
        });
    });
}


/// `Start LexDecimal, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> start_lex_decimal(crate::syntax::lexer::Lex l0, Text sigils) {
    return prism_rtl::make_rc<LexDecimal>(l0, sigils);
}


/// let durationUnits
Array<std::tuple<Text, Nat>> duration_units() {
    return Array(std::vector{std::tuple{Text::lit("ns"), Nat(1u)}, std::tuple{Text::lit("us"), Nat(1000u)}, std::tuple{Text::lit("ms"), Nat(1000000u)}, std::tuple{Text::lit("min"), *Nat::from_int(Int(60000000000ll))}, std::tuple{Text::lit("s"), *Nat::from_int(Int(1000000000ll))}, std::tuple{Text::lit("h"), *Nat::from_int(Int(3600000000000ll))}});
}


/// ?UnitAt: fn Lex -> ?((Text, Nat))
std::optional<std::tuple<Text, Nat>> unit_at(const crate::syntax::lexer::Lex& l) {
    auto&& _m = crate::syntax::lexer::chars::match_here(([]() -> const Regex& { static const Regex r = Regex::lit("(?:ns|us|ms|min|s|h)\\b", ""); return r; }()), l);
    {
        auto&& m2712_0 = _m;
        if (m2712_0 == Text::lit("")) {
            return std::optional<std::tuple<Text, Nat>>{};
        }
    }
    {
        auto&& u = _m;
        return fold(duration_units(), std::optional<std::tuple<Text, Nat>>{}, [&](const std::optional<std::tuple<Text, Nat>>& found_opt, const std::tuple<Text, Nat>& _p1) {
            auto&& name = std::get<0>(_p1);
            auto&& scale = std::get<1>(_p1);
            return name == u ? std::optional(std::tuple{name, scale}) : found_opt;
        });
    }
}


/// NumberTail: unbounded fn Lex, Text, Nat, Bool -> ((TokKind, Lex))
std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> number_tail(const crate::syntax::lexer::Lex& l, const Text& sigils, const Nat& start, const bool& decimal) {
    auto&& _m = unit_at(l);
    if (prism_rtl::is_some(_m)) {
        auto&& u = std::get<0>(prism_rtl::some_of(_m));
        auto&& scale = std::get<1>(prism_rtl::some_of(_m));
        auto digits = crate::syntax::lexer::chars::slice(l, start, l.pos);
        auto l2 = crate::syntax::lexer::chars::forward(l, len_text(u));
        auto l3 = whole_nanoseconds(digits, scale)
            ? l2
            : crate::syntax::lexer::chars::lex_err(l2, start, prism_rtl::deref(l2).pos, prism_rtl::cat("`", digits, u, "` does not name a whole number of nanoseconds"));
        auto kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KDuration{sigils, digits, u});
        return std::tuple{kind, l3};
    }
    if (prism_rtl::is_none(_m)) {
        auto [dec, l2] = exponent(l, decimal);
        auto l3 = check_no_suffix(l2, start);
        auto text_ = crate::syntax::lexer::chars::slice(l3, start, prism_rtl::deref(l3).pos);
        auto kind = dec
            ? crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KFloat{sigils, text_})
            : crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KInt{sigils, text_});
        return std::tuple{kind, l3};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> NumberTail::cycle() const {
    const auto& l = this->l;
    const auto& sigils = this->sigils;
    const auto& start = this->start;
    const auto& decimal = this->decimal;
    return ({
        auto&& _m = unit_at(l);
        prism_rtl::is_some(_m) ? ({
        auto&& u = std::get<0>(prism_rtl::some_of(_m));
        auto&& scale = std::get<1>(prism_rtl::some_of(_m));
        ({
        auto digits = crate::syntax::lexer::chars::slice(l, start, prism_rtl::deref(l).pos);
        auto l2 = crate::syntax::lexer::chars::forward(l, len_text(u));
        auto l3 = whole_nanoseconds(digits, scale)
            ? l2
            : crate::syntax::lexer::chars::lex_err(l2, start, prism_rtl::deref(l2).pos, prism_rtl::cat("`", digits, u, "` does not name a whole number of nanoseconds"));
        auto kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KDuration{sigils, digits, u});
        (prism_rtl::finished(std::tuple{kind, l3}));
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto decimal_1 = prism_rtl::deref(decimal);
        auto l_2 = l;
        auto sigils_3 = sigils;
        auto start_4 = start;
        call_then(start_exponent(l_2, std::move(decimal_1)), [=, sigils_3 = std::move(sigils_3), start_4 = std::move(start_4)](std::tuple<bool, crate::syntax::lexer::Lex> exponent_3556) {
        return ({
            auto [dec, l2] = exponent_3556;
            call_then(start_check_no_suffix(l2, start_4), [=](crate::syntax::lexer::Lex check_no_suffix_3593) {
            return ({
                auto l3 = check_no_suffix_3593;
                auto text_ = crate::syntax::lexer::chars::slice(l3, start_4, prism_rtl::deref(l3).pos);
                auto kind = dec
                    ? crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KFloat{sigils_3, text_})
                    : crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KInt{sigils_3, text_});
                (prism_rtl::finished(std::tuple{kind, l3}));
            });
        });
        });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start NumberTail, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> start_number_tail(crate::syntax::lexer::Lex l, Text sigils, Nat start, bool decimal) {
    return prism_rtl::make_rc<NumberTail>(l, sigils, start, decimal);
}


/// Exponent: unbounded fn Lex, Bool -> ((Bool, Lex))
std::tuple<bool, crate::syntax::lexer::Lex> exponent(const crate::syntax::lexer::Lex& l, const bool& decimal) {
    auto end = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[eE][+-]?[0-9][0-9_]*", ""); return r; }()), l.src, l.pos);
    return end > l.pos
        ? ({
        auto l2 = ({
            crate::syntax::lexer::Lex this_ = l;
            this_.pos = end;
            (std::move(this_));
        });
        std::tuple{true, l2};
    })
        : std::tuple{decimal, l};
}


prism_rtl::Turn<std::tuple<bool, crate::syntax::lexer::Lex>> Exponent::cycle() const {
    const auto& l = this->l;
    const auto& decimal = this->decimal;
    auto end = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[eE][+-]?[0-9][0-9_]*", ""); return r; }()), prism_rtl::deref(l).src, prism_rtl::deref(l).pos);
    return end > prism_rtl::deref(l).pos
        ? ({
        auto l2 = ({
            crate::syntax::lexer::Lex this_ = l;
            this_.pos = end;
            (std::move(this_));
        });
        (prism_rtl::finished(std::tuple{true, l2}));
    })
        : prism_rtl::finished(std::tuple{prism_rtl::deref(decimal), l});
}


/// `Start Exponent, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<bool, crate::syntax::lexer::Lex>> start_exponent(crate::syntax::lexer::Lex l, bool decimal) {
    return prism_rtl::make_rc<Exponent>(l, decimal);
}


/// WholeNanoseconds: fn Text, Nat -> Bool
bool whole_nanoseconds(const Text& text_, const Nat& scale) {
    auto parts = split_on(concat(split_on(text_, Text::lit("_"))), Text::lit("."));
    auto&& _m = index(parts, Nat(1u));
    if (prism_rtl::is_none(_m)) {
        return true;
    }
    if (prism_rtl::is_some(_m)) {
        auto&& frac0 = prism_rtl::some_of(_m);
        auto frac = trim_zeros(frac0);
        auto k = len_text(frac);
        auto f = frac == Text::lit("") ? Nat(0u) : or_(parse_nat_opt(frac), Nat(1u));
        auto tens = crate::syntax::lexer::chars::fold_chars(frac, Nat(1u), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Nat>(std::tuple<Nat, Text>)>>(prism_rtl::rc([=](std::tuple<Nat, Text> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return once_job([=]() {
                return ({
                    auto p_ = p0;
                    static_cast<void>(p1);
                    (prism_rtl::finished(p_ * Nat(10u)));
                });
            });
        })));
        return (k <= Nat(30u)) && (or_(mod_(f * scale, tens), Nat(1u)) == Nat(0u));
    }
    prism_rtl::unreachable("no arm matched");
}


/// TrimZeros: fn Text -> Text
Text trim_zeros(const Text& t) {
    return crate::syntax::lexer::chars::trim_trailing(t, Text::lit("0"));
}


/// CheckNoSuffix: unbounded fn Lex, Nat -> Lex
crate::syntax::lexer::Lex check_no_suffix(const crate::syntax::lexer::Lex& l0, const Nat& start) {
    return crate::syntax::lexer::chars::is_ident_char(crate::syntax::lexer::chars::peek(l0))
        ? ({
        auto l = ({
            crate::syntax::lexer::Lex this_ = l0;
            this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[A-Za-z0-9_]*", ""); return r; }()), this_.src, this_.pos);
            (std::move(this_));
        });
        (crate::syntax::lexer::chars::lex_err(l, start, prism_rtl::deref(l).pos, prism_rtl::cat("`", crate::syntax::lexer::chars::slice(l, start, prism_rtl::deref(l).pos), "` is not a token: a number literal has no suffix (write a type annotation)")));
    })
        : l0;
}


prism_rtl::Turn<crate::syntax::lexer::Lex> CheckNoSuffix::cycle() const {
    const auto& l0 = this->l0;
    const auto& start = this->start;
    return crate::syntax::lexer::chars::is_ident_char(crate::syntax::lexer::chars::peek(l0))
        ? ({
        auto l = ({
            crate::syntax::lexer::Lex this_ = l0;
            this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[A-Za-z0-9_]*", ""); return r; }()), this_.src, this_.pos);
            (std::move(this_));
        });
        (prism_rtl::finished(crate::syntax::lexer::chars::lex_err(l, start, prism_rtl::deref(l).pos, prism_rtl::cat("`", crate::syntax::lexer::chars::slice(l, start, prism_rtl::deref(l).pos), "` is not a token: a number literal has no suffix (write a type annotation)"))));
    })
        : prism_rtl::finished(l0);
}


/// `Start CheckNoSuffix, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_check_no_suffix(crate::syntax::lexer::Lex l0, Nat start) {
    return prism_rtl::make_rc<CheckNoSuffix>(l0, start);
}


/// LexEscape: unbounded fn Lex -> ((Text, Lex))
std::tuple<Text, crate::syntax::lexer::Lex> lex_escape(const crate::syntax::lexer::Lex& l0) {
    auto start = l0.pos;
    auto l1 = crate::syntax::lexer::chars::bump(l0);
    auto c = crate::syntax::lexer::chars::peek(l1);
    auto l2 = crate::syntax::lexer::chars::bump(l1);
    {
        auto&& m5231_0 = c;
        if (m5231_0 == Text::lit("\\")) {
            return std::tuple{Text::lit("\\"), l2};
        }
    }
    {
        auto&& m5231_1 = c;
        if (m5231_1 == Text::lit("\"")) {
            return std::tuple{Text::lit("\""), l2};
        }
    }
    {
        auto&& m5231_2 = c;
        if (m5231_2 == Text::lit("\'")) {
            return std::tuple{Text::lit("\'"), l2};
        }
    }
    {
        auto&& m5231_3 = c;
        if (m5231_3 == Text::lit("n")) {
            return std::tuple{Text::lit("\n"), l2};
        }
    }
    {
        auto&& m5231_4 = c;
        if (m5231_4 == Text::lit("t")) {
            return std::tuple{Text::lit("\t"), l2};
        }
    }
    {
        auto&& m5231_5 = c;
        if (m5231_5 == Text::lit("{")) {
            return std::tuple{Text::lit("{"), l2};
        }
    }
    {
        auto&& m5231_6 = c;
        if (m5231_6 == Text::lit("}")) {
            return std::tuple{Text::lit("}"), l2};
        }
    }
    {
        auto&& m5231_7 = c;
        if (m5231_7 == Text::lit("u")) {
            return unicode_escape(l2, start);
        }
    }
    {
        auto&& m5231_8 = c;
        if (m5231_8 == Text::lit("")) {
            return std::tuple{Text::lit(""), crate::syntax::lexer::chars::lex_err(l1, start, prism_rtl::deref(l1).pos, Text::lit("a text literal ends inside an escape"))};
        }
    }
    {
        return std::tuple{Text::lit(""), crate::syntax::lexer::chars::lex_err(l2, start, prism_rtl::deref(l2).pos, prism_rtl::cat("`\\", c, "` is not an escape: the escapes are \\\\ \\\" \\n \\t \\{ \\} \\u{hex}"))};
    }
}


prism_rtl::Turn<std::tuple<Text, crate::syntax::lexer::Lex>> LexEscape::cycle() const {
    const auto& l0 = this->l0;
    auto start = prism_rtl::deref(l0).pos;
    auto l1 = crate::syntax::lexer::chars::bump(l0);
    auto c = crate::syntax::lexer::chars::peek(l1);
    auto l2 = crate::syntax::lexer::chars::bump(l1);
    return ({
        ({
        auto&& m5231_0 = c;
        (m5231_0 == Text::lit("\\"));
    }) ? ({
        auto&& m5231_0 = c;
        prism_rtl::finished(std::tuple{Text::lit("\\"), l2});
    })
        : ({
        auto&& m5231_1 = c;
        (m5231_1 == Text::lit("\""));
    }) ? ({
        auto&& m5231_1 = c;
        prism_rtl::finished(std::tuple{Text::lit("\""), l2});
    })
        : ({
        auto&& m5231_2 = c;
        (m5231_2 == Text::lit("\'"));
    }) ? ({
        auto&& m5231_2 = c;
        prism_rtl::finished(std::tuple{Text::lit("\'"), l2});
    })
        : ({
        auto&& m5231_3 = c;
        (m5231_3 == Text::lit("n"));
    }) ? ({
        auto&& m5231_3 = c;
        prism_rtl::finished(std::tuple{Text::lit("\n"), l2});
    })
        : ({
        auto&& m5231_4 = c;
        (m5231_4 == Text::lit("t"));
    }) ? ({
        auto&& m5231_4 = c;
        prism_rtl::finished(std::tuple{Text::lit("\t"), l2});
    })
        : ({
        auto&& m5231_5 = c;
        (m5231_5 == Text::lit("{"));
    }) ? ({
        auto&& m5231_5 = c;
        prism_rtl::finished(std::tuple{Text::lit("{"), l2});
    })
        : ({
        auto&& m5231_6 = c;
        (m5231_6 == Text::lit("}"));
    }) ? ({
        auto&& m5231_6 = c;
        prism_rtl::finished(std::tuple{Text::lit("}"), l2});
    })
        : ({
        auto&& m5231_7 = c;
        (m5231_7 == Text::lit("u"));
    }) ? ({
        auto&& m5231_7 = c;
        prism_rtl::more(prism_rtl::rc(UnicodeEscape(l2, start)));
    })
        : ({
        auto&& m5231_8 = c;
        (m5231_8 == Text::lit(""));
    }) ? ({
        auto&& m5231_8 = c;
        prism_rtl::finished(std::tuple{Text::lit(""), crate::syntax::lexer::chars::lex_err(l1, start, prism_rtl::deref(l1).pos, Text::lit("a text literal ends inside an escape"))});
    })
        : prism_rtl::finished(std::tuple{Text::lit(""), crate::syntax::lexer::chars::lex_err(l2, start, prism_rtl::deref(l2).pos, prism_rtl::cat("`\\", c, "` is not an escape: the escapes are \\\\ \\\" \\n \\t \\{ \\} \\u{hex}"))});
    });
}


/// `Start LexEscape, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::syntax::lexer::Lex>> start_lex_escape(crate::syntax::lexer::Lex l0) {
    return prism_rtl::make_rc<LexEscape>(l0);
}


/// UnicodeEscape: unbounded fn Lex, Nat -> ((Text, Lex))
std::tuple<Text, crate::syntax::lexer::Lex> unicode_escape(const crate::syntax::lexer::Lex& l, const Nat& start) {
    return crate::syntax::lexer::chars::peek(l) != Text::lit("{")
        ? std::tuple{Text::lit(""), crate::syntax::lexer::chars::lex_err(l, start, l.pos, Text::lit("`\\u` is written `\\u{hex}`"))}
        : ({
        auto hs = l.pos + Nat(1u);
        auto l1 = ({
            crate::syntax::lexer::Lex this_ = crate::syntax::lexer::chars::bump(l);
            this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[0-9a-fA-F]*", ""); return r; }()), this_.src, this_.pos);
            (std::move(this_));
        });
        auto hex = crate::syntax::lexer::chars::slice(l1, hs, prism_rtl::deref(l1).pos);
        (crate::syntax::lexer::chars::peek(l1) != Text::lit("}")
        ? std::tuple{Text::lit(""), crate::syntax::lexer::chars::lex_err(l1, start, prism_rtl::deref(l1).pos, Text::lit("`\\u{` needs its closing `}`"))}
        : ({
        auto l2 = crate::syntax::lexer::chars::bump(l1);
        ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Text, crate::syntax::lexer::Lex>> _v;
        auto&& _m = crate::syntax::lexer::chars::ascii_char(or_(crate::syntax::lexer::chars::parse_hex(hex), Nat(1114112u)));
        if (prism_rtl::is_some(_m)) {
            auto&& ch = prism_rtl::some_of(_m);
            _v.set(std::tuple{ch, l2});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::tuple{Text::lit(""), crate::syntax::lexer::chars::lex_err(l2, start, prism_rtl::deref(l2).pos, prism_rtl::cat("`\\u{", hex, "}` is past ASCII, which prismc cannot write yet (prismc/README.md, gap UC)"))});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    }));
    });
}


prism_rtl::Turn<std::tuple<Text, crate::syntax::lexer::Lex>> UnicodeEscape::cycle() const {
    const auto& l = this->l;
    const auto& start = this->start;
    return crate::syntax::lexer::chars::peek(l) != Text::lit("{")
        ? prism_rtl::finished(std::tuple{Text::lit(""), crate::syntax::lexer::chars::lex_err(l, start, prism_rtl::deref(l).pos, Text::lit("`\\u` is written `\\u{hex}`"))})
        : ({
        auto hs = prism_rtl::deref(l).pos + Nat(1u);
        auto l1 = ({
            crate::syntax::lexer::Lex this_ = crate::syntax::lexer::chars::bump(l);
            this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[0-9a-fA-F]*", ""); return r; }()), this_.src, this_.pos);
            (std::move(this_));
        });
        auto hex = crate::syntax::lexer::chars::slice(l1, hs, prism_rtl::deref(l1).pos);
        (crate::syntax::lexer::chars::peek(l1) != Text::lit("}")
        ? prism_rtl::finished(std::tuple{Text::lit(""), crate::syntax::lexer::chars::lex_err(l1, start, prism_rtl::deref(l1).pos, Text::lit("`\\u{` needs its closing `}`"))})
        : ({
        auto l2 = crate::syntax::lexer::chars::bump(l1);
        ({
        auto&& _m = crate::syntax::lexer::chars::ascii_char(or_(crate::syntax::lexer::chars::parse_hex(hex), Nat(1114112u)));
        prism_rtl::is_some(_m) ? ({
        auto&& ch = prism_rtl::some_of(_m);
        prism_rtl::finished(std::tuple{ch, l2});
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{Text::lit(""), crate::syntax::lexer::chars::lex_err(l2, start, prism_rtl::deref(l2).pos, prism_rtl::cat("`\\u{", hex, "}` is past ASCII, which prismc cannot write yet (prismc/README.md, gap UC)"))})
        : throw prism_rtl::Panic("no arm matched");
    });
    }));
    });
}


/// `Start UnicodeEscape, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::syntax::lexer::Lex>> start_unicode_escape(crate::syntax::lexer::Lex l, Nat start) {
    return prism_rtl::make_rc<UnicodeEscape>(l, start);
}


/// LexText: unbounded fn Lex -> (([TextSegTok], Lex))
std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex> lex_text(const crate::syntax::lexer::Lex& l0) {
    std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex> this_ = std::tuple{Array<crate::syntax::lexer::TextSegTok>{}, l0};
    auto start = l0.pos;
    crate::syntax::lexer::Lex l = crate::syntax::lexer::chars::bump(l0);
    Array<crate::syntax::lexer::TextSegTok> segs = Array<crate::syntax::lexer::TextSegTok>{};
    Text cur = Text::lit("");
    bool going = true;
    while (std::move(going)) {
        auto c = crate::syntax::lexer::chars::peek(l);
        if ((c == Text::lit("")) || (c == Text::lit("\n"))) {
            l = crate::syntax::lexer::chars::lex_err(l, start, l.pos, Text::lit("a text literal ends on its line: close it with `\"`, or write a multiline text as `raw <markdown>...</markdown>`"));
            going = false;
        } else  {
            ({
                __label__ _done;
                prism_rtl::Slot<Unit> _v;
                {
                    auto&& u6966_0 = c;
                    if (u6966_0 == Text::lit("\"")) {
                        _v.set(({
                            l = crate::syntax::lexer::chars::bump(l);
                            going = false;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u6966_1 = c;
                    if (u6966_1 == Text::lit("\\")) {
                        _v.set(({
                            auto [s, l2] = lex_escape(l);
                            cur = prism_rtl::cat(cur, s);
                            l = l2;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u6966_2 = c;
                    if (u6966_2 == Text::lit("{")) {
                        _v.set(({
                            if (cur != Text::lit("")) {
                                segs = crate::prelude::push(segs, crate::syntax::lexer::TextSegTok(crate::syntax::lexer::TextSegTok::TsPlain{cur}));
                                cur = Text::lit("");
                            }
                            auto ps = l.pos;
                            auto [toks, l2] = crate::syntax::lexer::layout::nested(crate::syntax::lexer::chars::bump(l), crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MPlaceholder{Text::lit("single")}));
                            segs = crate::prelude::push(segs, crate::syntax::lexer::TextSegTok(crate::syntax::lexer::TextSegTok::TsPlaceholder{toks, crate::syntax::Range{.start = ps, .end = prism_rtl::deref(l2).pos}}));
                            l = l2;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u6966_3 = c;
                    if (u6966_3 == Text::lit("}")) {
                        _v.set(({
                            l = crate::syntax::lexer::chars::lex_err(crate::syntax::lexer::chars::bump(l), l.pos, l.pos + Nat(1u), Text::lit("a `}` in text is written `\\}`"));
                            cur = prism_rtl::cat(cur, "}");
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    _v.set(({
                        auto run_ = crate::syntax::lexer::chars::match_here(([]() -> const Regex& { static const Regex r = Regex::lit("[^\"\\\\{}\\n]+", ""); return r; }()), l);
                        l.pos = l.pos + len_text(run_);
                        cur = prism_rtl::cat(cur, run_);
                        Unit{};
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            });
        }
    }
    if (cur != Text::lit("")) {
        segs = crate::prelude::push(segs, crate::syntax::lexer::TextSegTok(crate::syntax::lexer::TextSegTok::TsPlain{cur}));
    }
    this_ = std::tuple{segs, l};
    return this_;
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex>> LexText::cycle() const {
    const auto& l0 = this->l0;
    std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex> this_ = std::tuple{Array<crate::syntax::lexer::TextSegTok>{}, l0};
    auto start = prism_rtl::deref(l0).pos;
    crate::syntax::lexer::Lex l = crate::syntax::lexer::chars::bump(l0);
    Array<crate::syntax::lexer::TextSegTok> segs = Array<crate::syntax::lexer::TextSegTok>{};
    Text cur = Text::lit("");
    bool going = true;
    return call_then(loop_job(std::tuple{std::move(this_), std::move(cur), std::move(going), std::move(l), std::move(segs)}, ({
        auto start_1 = start;
        [=, start_1 = std::move(start_1)](std::tuple<std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex>, Text, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::TextSegTok>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto cur = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto l = std::get<3>(_p0);
        auto segs = std::get<4>(_p0);
        return going
            ? ({
            auto c = crate::syntax::lexer::chars::peek(l);
            if ((c == Text::lit("")) || (c == Text::lit("\n"))) {
                l = crate::syntax::lexer::chars::lex_err(l, start_1, prism_rtl::deref(l).pos, Text::lit("a text literal ends on its line: close it with `\"`, or write a multiline text as `raw <markdown>...</markdown>`"));
                going = false;
            } else  {
                ({
                    __label__ _done;
                    prism_rtl::Slot<Unit> _v;
                    {
                        auto&& u6966_0 = c;
                        if (u6966_0 == Text::lit("\"")) {
                            _v.set(({
                                l = crate::syntax::lexer::chars::bump(l);
                                going = false;
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        auto&& u6966_1 = c;
                        if (u6966_1 == Text::lit("\\")) {
                            _v.set(({
                                auto [s, l2] = lex_escape(l);
                                cur = prism_rtl::cat(cur, s);
                                l = l2;
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        auto&& u6966_2 = c;
                        if (u6966_2 == Text::lit("{")) {
                            _v.set(({
                                if (cur != Text::lit("")) {
                                    segs = crate::prelude::push(segs, crate::syntax::lexer::TextSegTok(crate::syntax::lexer::TextSegTok::TsPlain{cur}));
                                    cur = Text::lit("");
                                }
                                auto ps = prism_rtl::deref(l).pos;
                                auto [toks, l2] = crate::syntax::lexer::layout::nested(crate::syntax::lexer::chars::bump(l), crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MPlaceholder{Text::lit("single")}));
                                segs = crate::prelude::push(segs, crate::syntax::lexer::TextSegTok(crate::syntax::lexer::TextSegTok::TsPlaceholder{toks, crate::syntax::Range{.start = ps, .end = prism_rtl::deref(l2).pos}}));
                                l = l2;
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        auto&& u6966_3 = c;
                        if (u6966_3 == Text::lit("}")) {
                            _v.set(({
                                l = crate::syntax::lexer::chars::lex_err(crate::syntax::lexer::chars::bump(l), prism_rtl::deref(l).pos, prism_rtl::deref(l).pos + Nat(1u), Text::lit("a `}` in text is written `\\}`"));
                                cur = prism_rtl::cat(cur, "}");
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        _v.set(({
                            auto run_ = crate::syntax::lexer::chars::match_here(([]() -> const Regex& { static const Regex r = Regex::lit("[^\"\\\\{}\\n]+", ""); return r; }()), l);
                            prism_rtl::deref(l).pos = prism_rtl::deref(l).pos + len_text(run_);
                            cur = prism_rtl::cat(cur, run_);
                            Unit{};
                        }));
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            }
            Expected<std::tuple<std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex>, Text, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::TextSegTok>>, std::tuple<std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex>, Text, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::TextSegTok>>>(std::tuple{this_, cur, going, l, segs});
        })
            : Expected<std::tuple<std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex>, Text, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::TextSegTok>>, std::tuple<std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex>, Text, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::TextSegTok>>>(unexpected(std::tuple{this_, cur, going, l, segs}));
    };
    })), [=](std::tuple<std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex>, Text, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::TextSegTok>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto cur = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto l = std::get<3>(_p0);
        auto segs = std::get<4>(_p0);
        return ({
            if (cur != Text::lit("")) {
                segs = crate::prelude::push(segs, crate::syntax::lexer::TextSegTok(crate::syntax::lexer::TextSegTok::TsPlain{cur}));
            }
            this_ = std::tuple{segs, l};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start LexText, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex>> start_lex_text(crate::syntax::lexer::Lex l0) {
    return prism_rtl::make_rc<LexText>(l0);
}


/// LexChar: unbounded fn Lex -> ((Text, Lex))
std::tuple<Text, crate::syntax::lexer::Lex> lex_char(const crate::syntax::lexer::Lex& l0) {
    auto start = l0.pos;
    auto l1 = crate::syntax::lexer::chars::bump(l0);
    auto c = crate::syntax::lexer::chars::peek(l1);
    auto [s, l2] = c == Text::lit("\\")
        ? lex_escape(l1)
        : ((c == Text::lit("\'")) || (c == Text::lit("\n"))) || (c == Text::lit(""))
        ? std::tuple{Text::lit(""), l1}
        : std::tuple{c, crate::syntax::lexer::chars::bump(l1)};
    auto ok_ = crate::syntax::lexer::chars::peek(l2) == Text::lit("\'");
    auto l3 = std::move(ok_)
        ? crate::syntax::lexer::chars::bump(l2)
        : char_tail(l2, start);
    auto l4 = s == Text::lit("")
        ? crate::syntax::lexer::chars::lex_err(l3, start, prism_rtl::deref(l3).pos, Text::lit("a character literal holds one code point: `\'c\'`"))
        : l3;
    auto ch = s == Text::lit("") ? Text::lit("\000"sv) : s;
    return std::tuple{ch, l4};
}


prism_rtl::Turn<std::tuple<Text, crate::syntax::lexer::Lex>> LexChar::cycle() const {
    const auto& l0 = this->l0;
    auto start = prism_rtl::deref(l0).pos;
    auto l1 = crate::syntax::lexer::chars::bump(l0);
    auto c = crate::syntax::lexer::chars::peek(l1);
    auto [s, l2] = c == Text::lit("\\")
        ? lex_escape(l1)
        : ((c == Text::lit("\'")) || (c == Text::lit("\n"))) || (c == Text::lit(""))
        ? std::tuple{Text::lit(""), l1}
        : std::tuple{c, crate::syntax::lexer::chars::bump(l1)};
    auto ok_ = crate::syntax::lexer::chars::peek(l2) == Text::lit("\'");
    auto l3 = std::move(ok_)
        ? crate::syntax::lexer::chars::bump(l2)
        : char_tail(l2, start);
    auto l4 = s == Text::lit("")
        ? crate::syntax::lexer::chars::lex_err(l3, start, prism_rtl::deref(l3).pos, Text::lit("a character literal holds one code point: `\'c\'`"))
        : l3;
    auto ch = s == Text::lit("") ? Text::lit("\000"sv) : s;
    return prism_rtl::finished(std::tuple{ch, l4});
}


/// `Start LexChar, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::syntax::lexer::Lex>> start_lex_char(crate::syntax::lexer::Lex l0) {
    return prism_rtl::make_rc<LexChar>(l0);
}


/// CharTail: unbounded fn Lex, Nat -> Lex
crate::syntax::lexer::Lex char_tail(const crate::syntax::lexer::Lex& l0, const Nat& start) {
    auto l1 = ({
        crate::syntax::lexer::Lex this_ = l0;
        this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[^\'\\n]*", ""); return r; }()), this_.src, this_.pos);
        (std::move(this_));
    });
    auto l2 = crate::syntax::lexer::chars::peek(l1) == Text::lit("\'")
        ? crate::syntax::lexer::chars::bump(l1)
        : l1;
    return crate::syntax::lexer::chars::lex_err(l2, start, prism_rtl::deref(l2).pos, Text::lit("a character literal holds one code point: `\'c\'`"));
}


prism_rtl::Turn<crate::syntax::lexer::Lex> CharTail::cycle() const {
    const auto& l0 = this->l0;
    const auto& start = this->start;
    auto l1 = ({
        crate::syntax::lexer::Lex this_ = l0;
        this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[^\'\\n]*", ""); return r; }()), this_.src, this_.pos);
        (std::move(this_));
    });
    auto l2 = crate::syntax::lexer::chars::peek(l1) == Text::lit("\'")
        ? crate::syntax::lexer::chars::bump(l1)
        : l1;
    return prism_rtl::finished(crate::syntax::lexer::chars::lex_err(l2, start, prism_rtl::deref(l2).pos, Text::lit("a character literal holds one code point: `\'c\'`")));
}


/// `Start CharTail, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_char_tail(crate::syntax::lexer::Lex l0, Nat start) {
    return prism_rtl::make_rc<CharTail>(l0, start);
}


/// LexPath: unbounded fn Lex -> (([PathSegTok], Lex))
std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex> lex_path(const crate::syntax::lexer::Lex& l0) {
    std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex> this_ = std::tuple{Array<crate::syntax::lexer::PathSegTok>{}, l0};
    crate::syntax::lexer::Lex l = l0;
    Array<crate::syntax::lexer::PathSegTok> segs = Array<crate::syntax::lexer::PathSegTok>{};
    bool going = true;
    while (std::move(going)) {
        auto s = l.pos;
        auto c = crate::syntax::lexer::chars::peek(l);
        if (c == Text::lit("#")) {
            auto digits = ({
                crate::syntax::lexer::Lex this_ = crate::syntax::lexer::chars::bump(l);
                this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[0-9]*", ""); return r; }()), this_.src, this_.pos);
                (std::move(this_));
            });
            auto text_ = crate::syntax::lexer::chars::slice(digits, s + Nat(1u), prism_rtl::deref(digits).pos);
            l = text_ == Text::lit("")
                ? crate::syntax::lexer::chars::lex_err(digits, s, prism_rtl::deref(digits).pos, Text::lit("a generation segment is `#` and a number"))
                : digits;
            segs = crate::prelude::push(segs, crate::syntax::lexer::PathSegTok(crate::syntax::lexer::PathSegTok::PstGen{or_(parse_nat_opt(text_), Nat(0u))}));
        } else if (crate::syntax::lexer::chars::is_digit(c)) {
            auto digits = ({
                crate::syntax::lexer::Lex this_ = l;
                this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[0-9]*", ""); return r; }()), this_.src, this_.pos);
                (std::move(this_));
            });
            segs = crate::prelude::push(segs, crate::syntax::lexer::PathSegTok(crate::syntax::lexer::PathSegTok::PstNum{or_(parse_nat_opt(crate::syntax::lexer::chars::slice(digits, s, prism_rtl::deref(digits).pos)), Nat(0u))}));
            l = digits;
        } else if (c == Text::lit("[")) {
            auto [toks, l2] = crate::syntax::lexer::layout::nested(crate::syntax::lexer::chars::bump(l), crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MPathKey{}));
            segs = crate::prelude::push(segs, crate::syntax::lexer::PathSegTok(crate::syntax::lexer::PathSegTok::PstKey{toks}));
            l = l2;
        } else  {
            l = crate::syntax::lexer::chars::lex_err(l, s, s, Text::lit("expected a path segment: a number, `#` and a number, or `[key]`"));
            going = false;
        }
        if (std::move(going)) {
            if (crate::syntax::lexer::chars::peek(l) == Text::lit("/")) {
                l = crate::syntax::lexer::chars::bump(l);
            } else  {
                going = false;
            }
        }
    }
    this_ = std::tuple{segs, l};
    return this_;
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex>> LexPath::cycle() const {
    const auto& l0 = this->l0;
    std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex> this_ = std::tuple{Array<crate::syntax::lexer::PathSegTok>{}, l0};
    crate::syntax::lexer::Lex l = l0;
    Array<crate::syntax::lexer::PathSegTok> segs = Array<crate::syntax::lexer::PathSegTok>{};
    bool going = true;
    return call_then(loop_job(std::tuple{std::move(this_), std::move(going), std::move(l), std::move(segs)}, [=](std::tuple<std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::PathSegTok>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going = std::get<1>(_p0);
        auto l = std::get<2>(_p0);
        auto segs = std::get<3>(_p0);
        return going
            ? ({
            auto s = prism_rtl::deref(l).pos;
            auto c = crate::syntax::lexer::chars::peek(l);
            if (c == Text::lit("#")) {
                auto digits = ({
                    crate::syntax::lexer::Lex this_ = crate::syntax::lexer::chars::bump(l);
                    this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[0-9]*", ""); return r; }()), this_.src, this_.pos);
                    (std::move(this_));
                });
                auto text_ = crate::syntax::lexer::chars::slice(digits, s + Nat(1u), prism_rtl::deref(digits).pos);
                l = text_ == Text::lit("")
                    ? crate::syntax::lexer::chars::lex_err(digits, s, prism_rtl::deref(digits).pos, Text::lit("a generation segment is `#` and a number"))
                    : digits;
                segs = crate::prelude::push(segs, crate::syntax::lexer::PathSegTok(crate::syntax::lexer::PathSegTok::PstGen{or_(parse_nat_opt(text_), Nat(0u))}));
            } else if (crate::syntax::lexer::chars::is_digit(c)) {
                auto digits = ({
                    crate::syntax::lexer::Lex this_ = l;
                    this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[0-9]*", ""); return r; }()), this_.src, this_.pos);
                    (std::move(this_));
                });
                segs = crate::prelude::push(segs, crate::syntax::lexer::PathSegTok(crate::syntax::lexer::PathSegTok::PstNum{or_(parse_nat_opt(crate::syntax::lexer::chars::slice(digits, s, prism_rtl::deref(digits).pos)), Nat(0u))}));
                l = digits;
            } else if (c == Text::lit("[")) {
                auto [toks, l2] = crate::syntax::lexer::layout::nested(crate::syntax::lexer::chars::bump(l), crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MPathKey{}));
                segs = crate::prelude::push(segs, crate::syntax::lexer::PathSegTok(crate::syntax::lexer::PathSegTok::PstKey{toks}));
                l = l2;
            } else  {
                l = crate::syntax::lexer::chars::lex_err(l, s, s, Text::lit("expected a path segment: a number, `#` and a number, or `[key]`"));
                going = false;
            }
            if (going) {
                if (crate::syntax::lexer::chars::peek(l) == Text::lit("/")) {
                    l = crate::syntax::lexer::chars::bump(l);
                } else  {
                    going = false;
                }
            }
            Expected<std::tuple<std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::PathSegTok>>, std::tuple<std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::PathSegTok>>>(std::tuple{this_, going, l, segs});
        })
            : Expected<std::tuple<std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::PathSegTok>>, std::tuple<std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::PathSegTok>>>(unexpected(std::tuple{this_, going, l, segs}));
    }), [=](std::tuple<std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::PathSegTok>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going = std::get<1>(_p0);
        auto l = std::get<2>(_p0);
        auto segs = std::get<3>(_p0);
        return ({
            this_ = std::tuple{segs, l};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start LexPath, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex>> start_lex_path(crate::syntax::lexer::Lex l0) {
    return prism_rtl::make_rc<LexPath>(l0);
}

}  // namespace crate::syntax::lexer::literals


// The module `Syntax.Lexer.Regexes`, from `target/bootstrap/cpp-src/prismc/syntax/lexer/regexes.prism`.
namespace crate::syntax::lexer::regexes {

/// let percentMessage
Text percent_message() {
    return Text::lit("`%` is no operator: the remainder is `mod`, and `%` begins a regular expression only as `%/` or `%#/`");
}


/// LexRegex: unbounded fn Lex, Text, Nat -> Lex
crate::syntax::lexer::Lex lex_regex(const crate::syntax::lexer::Lex& l, const Text& sigils, const Nat& start) {
    auto pct = l.pos;
    auto open = hashes_end(l.src, pct + Nat(1u));
    auto hashes = crate::syntax::lexer::chars::between(l.src, pct + Nat(1u), open);
    return crate::syntax::lexer::chars::char_at_byte(l.src, open) != Text::lit("/")
        ? no_regex(l, pct, open, hashes)
        : ({
        auto close = prism_rtl::cat("/", hashes);
        auto end_opt = hashes == Text::lit("")
            ? plain_end(l.src, open + Nat(1u))
            : hashed_end(l.src, open + Nat(1u), close);
        ({
        __label__ _done;
        prism_rtl::Slot<crate::syntax::lexer::Lex> _v;
        if (prism_rtl::is_some(end_opt)) {
            auto&& e = prism_rtl::some_of(end_opt);
            _v.set(after_pattern(l, sigils, start, open + Nat(1u), e, close));
            goto _done;
        }
        if (prism_rtl::is_none(end_opt)) {
            _v.set(unclosed(l, sigils, start, crate::syntax::lexer::chars::between(l.src, open + Nat(1u), line_end_at(l.src, open)), open + Nat(1u), std::optional<Text>{}, Text::lit("pattern"), close));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    });
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexRegex::cycle() const {
    const auto& l = this->l;
    const auto& sigils = this->sigils;
    const auto& start = this->start;
    auto pct = prism_rtl::deref(l).pos;
    auto open = hashes_end(prism_rtl::deref(l).src, pct + Nat(1u));
    auto hashes = crate::syntax::lexer::chars::between(prism_rtl::deref(l).src, pct + Nat(1u), open);
    return crate::syntax::lexer::chars::char_at_byte(prism_rtl::deref(l).src, open) != Text::lit("/")
        ? prism_rtl::finished(no_regex(l, pct, open, hashes))
        : ({
        auto close = prism_rtl::cat("/", hashes);
        auto end_opt = hashes == Text::lit("")
            ? plain_end(prism_rtl::deref(l).src, open + Nat(1u))
            : hashed_end(prism_rtl::deref(l).src, open + Nat(1u), close);
        ({
        prism_rtl::is_some(end_opt) ? ({
        auto&& e = prism_rtl::some_of(end_opt);
        prism_rtl::more(prism_rtl::rc(AfterPattern(l, sigils, start, open + Nat(1u), e, close)));
    })
        : prism_rtl::is_none(end_opt) ? prism_rtl::more(prism_rtl::rc(Unclosed(l, sigils, start, crate::syntax::lexer::chars::between(prism_rtl::deref(l).src, open + Nat(1u), line_end_at(prism_rtl::deref(l).src, open)), open + Nat(1u), std::optional<Text>{}, Text::lit("pattern"), close)))
        : throw prism_rtl::Panic("no arm matched");
    });
    });
}


/// `Start LexRegex, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_regex(crate::syntax::lexer::Lex l, Text sigils, Nat start) {
    return prism_rtl::make_rc<LexRegex>(l, sigils, start);
}


/// NoRegex: fn Lex, Nat, Nat, Text -> Lex
crate::syntax::lexer::Lex no_regex(const crate::syntax::lexer::Lex& l, const Nat& pct, const Nat& open, const Text& hashes) {
    auto end = hashes == Text::lit("") ? pct + Nat(1u) : open;
    auto message = hashes == Text::lit("")
        ? percent_message()
        : Text::lit("a hashed regular expression opens with `%`, its hashes and `/`: `%#/.../#`");
    auto l1 = ({
        crate::syntax::lexer::Lex this_ = l;
        this_.pos = end;
        (std::move(this_));
    });
    auto l2 = crate::syntax::lexer::chars::lex_err(l1, pct, end, message);
    crate::syntax::lexer::Lex this_ = l2;
    this_.last_ws = true;
    return this_;
}


/// AfterPattern: unbounded fn Lex, Text, Nat, Nat, Nat, Text -> Lex
crate::syntax::lexer::Lex after_pattern(const crate::syntax::lexer::Lex& l, const Text& sigils, const Nat& start, const Nat& at_, const Nat& end, const Text& close) {
    auto src = l.src;
    auto pattern = crate::syntax::lexer::chars::between(src, at_, end);
    auto after_ = end + len_text(close);
    auto run_end = letters_end(src, after_);
    auto run_ = crate::syntax::lexer::chars::between(src, after_, run_end);
    auto c = crate::syntax::lexer::chars::char_at_byte(src, run_end);
    auto plain = close == Text::lit("/");
    return (((c == Text::lit("")) || (c == Text::lit("\n"))) || crate::syntax::lexer::chars::contains(Text::lit(",)]}:;"), c)) || (std::move(plain) && crate::syntax::lexer::chars::is_space_char(c))
        ? finish(l, sigils, start, pattern, at_, std::optional<Text>{}, Nat(0u), after_)
        : crate::syntax::lexer::chars::has_prefix(text_from(src, run_end), close)
        ? finish(l, sigils, start, pattern, at_, std::optional(run_), after_, run_end + len_text(close))
        : std::move(plain) && (run_ == Text::lit(""))
        ? ({
        __label__ _done;
        prism_rtl::Slot<crate::syntax::lexer::Lex> _v;
        auto&& _m = plain_end(src, after_);
        if (prism_rtl::is_some(_m)) {
            auto&& e = prism_rtl::some_of(_m);
            _v.set(finish(l, sigils, start, pattern, at_, std::optional(crate::syntax::lexer::chars::between(src, after_, e)), after_, e + Nat(1u)));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(unclosed(l, sigils, start, pattern, at_, std::optional(crate::syntax::lexer::chars::between(src, after_, line_end_at(src, after_))), Text::lit("replacement"), close));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    })
        : (!std::move(plain)) && ((run_ == Text::lit("")) || crate::syntax::lexer::chars::is_space_char(c))
        ? ({
        __label__ _done;
        prism_rtl::Slot<crate::syntax::lexer::Lex> _v;
        auto&& _m = hashed_end(src, after_, close);
        if (prism_rtl::is_some(_m)) {
            auto&& e = prism_rtl::some_of(_m);
            _v.set(finish(l, sigils, start, pattern, at_, std::optional(crate::syntax::lexer::chars::between(src, after_, e)), after_, e + len_text(close)));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(finish(l, sigils, start, pattern, at_, std::optional<Text>{}, Nat(0u), after_));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    })
        : finish(l, sigils, start, pattern, at_, std::optional<Text>{}, Nat(0u), after_);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> AfterPattern::cycle() const {
    const auto& l = this->l;
    const auto& sigils = this->sigils;
    const auto& start = this->start;
    const auto& at_ = this->at_;
    const auto& end = this->end;
    const auto& close = this->close;
    auto src = prism_rtl::deref(l).src;
    auto pattern = crate::syntax::lexer::chars::between(src, at_, end);
    auto after_ = end + len_text(close);
    auto run_end = letters_end(src, after_);
    auto run_ = crate::syntax::lexer::chars::between(src, after_, run_end);
    auto c = crate::syntax::lexer::chars::char_at_byte(src, run_end);
    auto plain = close == Text::lit("/");
    return (((c == Text::lit("")) || (c == Text::lit("\n"))) || crate::syntax::lexer::chars::contains(Text::lit(",)]}:;"), c)) || (std::move(plain) && crate::syntax::lexer::chars::is_space_char(c))
        ? prism_rtl::more(prism_rtl::rc(Finish(l, sigils, start, pattern, at_, std::optional<Text>{}, Nat(0u), after_)))
        : crate::syntax::lexer::chars::has_prefix(text_from(src, run_end), close)
        ? prism_rtl::more(prism_rtl::rc(Finish(l, sigils, start, pattern, at_, std::optional(run_), after_, run_end + len_text(close))))
        : std::move(plain) && (run_ == Text::lit(""))
        ? ({
        auto&& _m = plain_end(src, after_);
        prism_rtl::is_some(_m) ? ({
        auto&& e = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(Finish(l, sigils, start, pattern, at_, std::optional(crate::syntax::lexer::chars::between(src, after_, e)), after_, e + Nat(1u))));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(Unclosed(l, sigils, start, pattern, at_, std::optional(crate::syntax::lexer::chars::between(src, after_, line_end_at(src, after_))), Text::lit("replacement"), close)))
        : throw prism_rtl::Panic("no arm matched");
    })
        : (!std::move(plain)) && ((run_ == Text::lit("")) || crate::syntax::lexer::chars::is_space_char(c))
        ? ({
        auto at__1 = at_;
        auto close_2 = close;
        auto l_3 = l;
        auto sigils_4 = sigils;
        auto start_5 = start;
        call_then(start_hashed_end(src, after_, close_2), [=, at__1 = std::move(at__1), l_3 = std::move(l_3), sigils_4 = std::move(sigils_4), start_5 = std::move(start_5)](std::optional<Nat> hashed_end_3454) {
        return ({
            prism_rtl::is_some(hashed_end_3454) ? ({
            auto&& e = prism_rtl::some_of(hashed_end_3454);
            prism_rtl::more(prism_rtl::rc(Finish(l_3, sigils_4, start_5, pattern, at__1, std::optional(crate::syntax::lexer::chars::between(src, after_, e)), after_, e + len_text(close_2))));
        })
            : prism_rtl::is_none(hashed_end_3454) ? prism_rtl::more(prism_rtl::rc(Finish(l_3, sigils_4, start_5, pattern, at__1, std::optional<Text>{}, Nat(0u), after_)))
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    })
        : prism_rtl::more(prism_rtl::rc(Finish(l, sigils, start, pattern, at_, std::optional<Text>{}, Nat(0u), after_)));
}


/// `Start AfterPattern, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_after_pattern(crate::syntax::lexer::Lex l, Text sigils, Nat start, Nat at_, Nat end, Text close) {
    return prism_rtl::make_rc<AfterPattern>(l, sigils, start, at_, end, close);
}


/// Finish: unbounded fn Lex, Text, Nat, Text, Nat, ?Text, Nat, Nat -> Lex
crate::syntax::lexer::Lex finish(const crate::syntax::lexer::Lex& l, const Text& sigils, const Nat& start, const Text& pattern, const Nat& at_, const std::optional<Text>& replacement_opt, const Nat& replacement_at, const Nat& flags_at) {
    auto src = l.src;
    auto flags_end = letters_end(src, flags_at);
    auto lit = crate::syntax::RegexLit{.pattern = pattern, .pattern_at = at_, .replacement = replacement_opt, .replacement_at = replacement_at, .flags = crate::syntax::lexer::chars::between(src, flags_at, flags_end), .flags_at = flags_at};
    auto tail = ident_end(src, flags_end);
    auto l1 = ({
        crate::syntax::lexer::Lex this_ = l;
        this_.pos = tail;
        (std::move(this_));
    });
    auto l2 = tail > flags_end
        ? crate::syntax::lexer::chars::lex_err(l1, flags_end, tail, prism_rtl::cat("`", crate::syntax::lexer::chars::between(src, flags_end, tail), "` touches the flags of a regular expression: the flags are letters, and no name character follows them"))
        : l1;
    return crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KRegex{sigils, lit}), start, flags_end);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> Finish::cycle() const {
    const auto& l = this->l;
    const auto& sigils = this->sigils;
    const auto& start = this->start;
    const auto& pattern = this->pattern;
    const auto& at_ = this->at_;
    const auto& replacement_opt = this->replacement_opt;
    const auto& replacement_at = this->replacement_at;
    const auto& flags_at = this->flags_at;
    auto src = prism_rtl::deref(l).src;
    auto flags_end = letters_end(src, flags_at);
    auto lit = crate::syntax::RegexLit{.pattern = pattern, .pattern_at = at_, .replacement = replacement_opt, .replacement_at = replacement_at, .flags = crate::syntax::lexer::chars::between(src, flags_at, flags_end), .flags_at = flags_at};
    auto tail = ident_end(src, flags_end);
    auto l1 = ({
        crate::syntax::lexer::Lex this_ = l;
        this_.pos = tail;
        (std::move(this_));
    });
    auto l2 = tail > flags_end
        ? crate::syntax::lexer::chars::lex_err(l1, flags_end, tail, prism_rtl::cat("`", crate::syntax::lexer::chars::between(src, flags_end, tail), "` touches the flags of a regular expression: the flags are letters, and no name character follows them"))
        : l1;
    return prism_rtl::finished(crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KRegex{sigils, lit}), start, flags_end));
}


/// `Start Finish, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_finish(crate::syntax::lexer::Lex l, Text sigils, Nat start, Text pattern, Nat at_, std::optional<Text> replacement_opt, Nat replacement_at, Nat flags_at) {
    return prism_rtl::make_rc<Finish>(l, sigils, start, pattern, at_, replacement_opt, replacement_at, flags_at);
}


/// Unclosed: unbounded fn Lex, Text, Nat, Text, Nat, ?Text, Text, Text -> Lex
crate::syntax::lexer::Lex unclosed(const crate::syntax::lexer::Lex& l, const Text& sigils, const Nat& start, const Text& pattern, const Nat& at_, const std::optional<Text>& replacement_opt, const Text& what, const Text& close) {
    auto end = line_end_at(l.src, at_);
    auto lit_1 = crate::syntax::RegexLit{.pattern = pattern, .pattern_at = at_, .replacement = replacement_opt, .replacement_at = at_, .flags = Text::lit(""), .flags_at = end};
    auto l1 = ({
        crate::syntax::lexer::Lex this_ = l;
        this_.pos = end;
        (std::move(this_));
    });
    auto l2 = crate::syntax::lexer::chars::lex_err(l1, start, end, prism_rtl::cat("a regular expression ends on its line: close its ", what, " with `", close, "`"));
    return crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KRegex{sigils, lit_1}), start, end);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> Unclosed::cycle() const {
    const auto& l = this->l;
    const auto& sigils = this->sigils;
    const auto& start = this->start;
    const auto& pattern = this->pattern;
    const auto& at_ = this->at_;
    const auto& replacement_opt = this->replacement_opt;
    const auto& what = this->what;
    const auto& close = this->close;
    auto end = line_end_at(prism_rtl::deref(l).src, at_);
    auto lit_1 = crate::syntax::RegexLit{.pattern = pattern, .pattern_at = at_, .replacement = replacement_opt, .replacement_at = at_, .flags = Text::lit(""), .flags_at = end};
    auto l1 = ({
        crate::syntax::lexer::Lex this_ = l;
        this_.pos = end;
        (std::move(this_));
    });
    auto l2 = crate::syntax::lexer::chars::lex_err(l1, start, end, prism_rtl::cat("a regular expression ends on its line: close its ", what, " with `", close, "`"));
    return prism_rtl::finished(crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KRegex{sigils, lit_1}), start, end));
}


/// `Start Unclosed, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_unclosed(crate::syntax::lexer::Lex l, Text sigils, Nat start, Text pattern, Nat at_, std::optional<Text> replacement_opt, Text what, Text close) {
    return prism_rtl::make_rc<Unclosed>(l, sigils, start, pattern, at_, replacement_opt, what, close);
}


/// ?PlainEnd: fn Text, Nat -> ?Nat
std::optional<Nat> plain_end(const Text& src, const Nat& at_) {
    auto&& _m = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("(?:[^\\/\\\\\\n]|\\\\[^\\n])*\\/", ""); return r; }()), src, at_);
    {
        auto&& e = _m;
        if (e > at_) {
            return e.checked_sub(Nat(1u));
        }
    }
    {
        return std::optional<Nat>{};
    }
}


/// ?HashedEnd: unbounded fn Text, Nat, Text -> ?Nat
std::optional<Nat> hashed_end(const Text& src, const Nat& at_, const Text& close) {
    auto&& _found_opt = ({
        std::tuple<std::optional<Nat>, Nat, bool> this_ = std::tuple{std::optional<Nat>{}, at_, true};
        Nat i = at_;
        bool going = true;
        std::optional<Nat> found_opt = std::optional<Nat>{};
        while (std::move(going)) {
            auto c = crate::syntax::lexer::chars::char_at_byte(src, i);
            if ((c == Text::lit("")) || (c == Text::lit("\n"))) {
                going = false;
            } else if ((c == Text::lit("/")) && crate::syntax::lexer::chars::has_prefix(text_from(src, i), close)) {
                found_opt = std::optional(i);
                going = false;
            } else  {
                i = i + len_text(c);
            }
        }
        this_ = std::tuple{found_opt, i, std::move(going)};
        (std::move(this_));
    });
    auto&& found_opt = std::get<0>(_found_opt);
    return found_opt;
}


prism_rtl::Turn<std::optional<Nat>> HashedEnd::cycle() const {
    const auto& src = this->src;
    const auto& at_ = this->at_;
    const auto& close = this->close;
    std::tuple<std::optional<Nat>, Nat, bool> this_ = std::tuple{std::optional<Nat>{}, at_, true};
    Nat i = at_;
    bool going = true;
    std::optional<Nat> found_opt = std::optional<Nat>{};
    auto at__1 = at_;
    return call_then(loop_job(std::tuple{std::move(found_opt), std::move(this_), std::move(going), std::move(i)}, ({
        auto close_2 = close;
        auto src_3 = src;
        [=, close_2 = std::move(close_2), src_3 = std::move(src_3)](std::tuple<std::optional<Nat>, std::tuple<std::optional<Nat>, Nat, bool>, bool, Nat> _p0) {
        auto found_opt = std::get<0>(_p0);
        auto this_ = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto i = std::get<3>(_p0);
        return going
            ? ({
            auto c = crate::syntax::lexer::chars::char_at_byte(src_3, i);
            if ((c == Text::lit("")) || (c == Text::lit("\n"))) {
                going = false;
            } else if ((c == Text::lit("/")) && crate::syntax::lexer::chars::has_prefix(text_from(src_3, i), close_2)) {
                found_opt = std::optional(i);
                going = false;
            } else  {
                i = i + len_text(c);
            }
            Expected<std::tuple<std::optional<Nat>, std::tuple<std::optional<Nat>, Nat, bool>, bool, Nat>, std::tuple<std::optional<Nat>, std::tuple<std::optional<Nat>, Nat, bool>, bool, Nat>>(std::tuple{found_opt, this_, going, i});
        })
            : Expected<std::tuple<std::optional<Nat>, std::tuple<std::optional<Nat>, Nat, bool>, bool, Nat>, std::tuple<std::optional<Nat>, std::tuple<std::optional<Nat>, Nat, bool>, bool, Nat>>(unexpected(std::tuple{found_opt, this_, going, i}));
    };
    })), [=](std::tuple<std::optional<Nat>, std::tuple<std::optional<Nat>, Nat, bool>, bool, Nat> _p0) {
        auto found_opt = std::get<0>(_p0);
        auto this_ = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto i = std::get<3>(_p0);
        return ({
            this_ = std::tuple{found_opt, i, going};
            auto&& _found_opt = this_;
            auto&& found_opt = std::get<0>(_found_opt);
            (prism_rtl::finished(found_opt));
        });
    });
}


/// `Start HashedEnd, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Nat>> start_hashed_end(Text src, Nat at_, Text close) {
    return prism_rtl::make_rc<HashedEnd>(src, at_, close);
}


/// HashesEnd: fn Text, Nat -> Nat
Nat hashes_end(const Text& src, const Nat& at_) {
    return crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("#*", ""); return r; }()), src, at_);
}


/// LettersEnd: fn Text, Nat -> Nat
Nat letters_end(const Text& src, const Nat& at_) {
    return crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[A-Za-z]*", ""); return r; }()), src, at_);
}


/// IdentEnd: fn Text, Nat -> Nat
Nat ident_end(const Text& src, const Nat& at_) {
    return crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[A-Za-z0-9_]*", ""); return r; }()), src, at_);
}


/// LineEndAt: fn Text, Nat -> Nat
Nat line_end_at(const Text& src, const Nat& at_) {
    return crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[^\\n]*", ""); return r; }()), src, at_);
}


/// TextFrom: fn Text, Nat -> Text
Text text_from(const Text& src, const Nat& at_) {
    auto&& _m = cursor_at(src, at_);
    if (prism_rtl::is_some(_m)) {
        auto&& c = prism_rtl::some_of(_m);
        return after(c);
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}

}  // namespace crate::syntax::lexer::regexes
