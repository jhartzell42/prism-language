// The modules `Syntax.Lexer.Literals`, `Syntax.Lexer.Regexes`, `Syntax.Lexer.Templates`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <syntax/lexer/literals/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Syntax.Lexer.Literals`, from `target/bootstrap/cpp-src/prismc/syntax/lexer/literals.prism`.
namespace crate::syntax::lexer::literals {

/// LexNumber: unbounded fn Lex, Text -> ((TokKind, Lex))
std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> lex_number(const crate::syntax::lexer::Lex& l, const Text& sigils) {
    return (crate::syntax::lexer::chars::peek(l) == Text::lit("0")) && crate::syntax::lexer::chars::contains(Text::lit("xob"), crate::syntax::lexer::chars::peek_at(l, Nat(1u)))
        ? lex_radix(l, sigils)
        : lex_decimal(l, sigils);
}


prism_rtl::Turn<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> LexNumber::cycle() const {
    const auto& l = this->l;
    const auto& sigils = this->sigils;
    return (crate::syntax::lexer::chars::peek(l) == Text::lit("0")) && crate::syntax::lexer::chars::contains(Text::lit("xob"), crate::syntax::lexer::chars::peek_at(l, Nat(1u)))
        ? prism_rtl::more(prism_rtl::rc(LexRadix(l, sigils)))
        : prism_rtl::more(prism_rtl::rc(LexDecimal(l, sigils)));
}


/// `Start LexNumber, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> start_lex_number(crate::syntax::lexer::Lex l, Text sigils) {
    return prism_rtl::make_rc<LexNumber>(l, sigils);
}


/// LexRadix: unbounded fn Lex, Text -> ((TokKind, Lex))
std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> lex_radix(const crate::syntax::lexer::Lex& l0, const Text& sigils) {
    auto start = l0.pos;
    auto radix = crate::syntax::lexer::chars::peek_at(l0, Nat(1u));
    auto l1 = crate::syntax::lexer::chars::forward(l0, Nat(2u));
    auto digits = radix == Text::lit("x")
        ? ([]() -> const Regex& { static const Regex r = Regex::lit("[0-9a-fA-F_]*", ""); return r; }())
        : radix == Text::lit("o")
        ? ([]() -> const Regex& { static const Regex r = Regex::lit("[0-7_]*", ""); return r; }())
        : ([]() -> const Regex& { static const Regex r = Regex::lit("[01_]*", ""); return r; }());
    auto l2 = ({
        crate::syntax::lexer::Lex this_ = l1;
        this_.pos = crate::syntax::lexer::chars::match_end(digits, this_.src, this_.pos);
        this_;
    });
    auto l3 = l2.pos == l1.pos
        ? crate::syntax::lexer::chars::lex_err(l2, start, l2.pos, Text::lit("a radix prefix needs digits after it"))
        : l2;
    auto l4 = check_no_suffix(l3, start);
    auto kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KInt{sigils, crate::syntax::lexer::chars::slice(l4, start, l4.pos)});
    return std::tuple{kind, l4};
}


prism_rtl::Turn<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> LexRadix::cycle() const {
    const auto& l0 = this->l0;
    const auto& sigils = this->sigils;
    auto start = l0.pos;
    auto radix = crate::syntax::lexer::chars::peek_at(l0, Nat(1u));
    auto l1 = crate::syntax::lexer::chars::forward(l0, Nat(2u));
    auto digits = radix == Text::lit("x")
        ? ([]() -> const Regex& { static const Regex r = Regex::lit("[0-9a-fA-F_]*", ""); return r; }())
        : radix == Text::lit("o")
        ? ([]() -> const Regex& { static const Regex r = Regex::lit("[0-7_]*", ""); return r; }())
        : ([]() -> const Regex& { static const Regex r = Regex::lit("[01_]*", ""); return r; }());
    auto l2 = ({
        crate::syntax::lexer::Lex this_ = l1;
        this_.pos = crate::syntax::lexer::chars::match_end(digits, this_.src, this_.pos);
        this_;
    });
    auto l3 = l2.pos == l1.pos
        ? crate::syntax::lexer::chars::lex_err(l2, start, l2.pos, Text::lit("a radix prefix needs digits after it"))
        : l2;
    auto sigils_1 = sigils;
    return call_then(start_check_no_suffix(l3, start), [=](crate::syntax::lexer::Lex check_no_suffix_1221) {
        return ({
            auto l4 = check_no_suffix_1221;
            auto kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KInt{sigils_1, crate::syntax::lexer::chars::slice(l4, start, l4.pos)});
            (prism_rtl::finished(std::tuple{kind, l4}));
        });
    });
}


/// `Start LexRadix, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> start_lex_radix(crate::syntax::lexer::Lex l0, Text sigils) {
    return prism_rtl::make_rc<LexRadix>(l0, sigils);
}


/// SkipDigits: unbounded fn Lex -> Lex
crate::syntax::lexer::Lex skip_digits(const crate::syntax::lexer::Lex& l) {
    crate::syntax::lexer::Lex this_ = l;
    this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[0-9_]*", ""); return r; }()), this_.src, this_.pos);
    return this_;
}


prism_rtl::Turn<crate::syntax::lexer::Lex> SkipDigits::cycle() const {
    const auto& l = this->l;
    return prism_rtl::finished(({
        crate::syntax::lexer::Lex this_ = l;
        this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[0-9_]*", ""); return r; }()), this_.src, this_.pos);
        this_;
    }));
}


/// `Start SkipDigits, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_skip_digits(crate::syntax::lexer::Lex l) {
    return prism_rtl::make_rc<SkipDigits>(l);
}


/// LexDecimal: unbounded fn Lex, Text -> ((TokKind, Lex))
std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> lex_decimal(const crate::syntax::lexer::Lex& l0, const Text& sigils) {
    auto start = l0.pos;
    auto l1 = skip_digits(l0);
    auto next_ = crate::syntax::lexer::chars::peek_at(l1, Nat(1u));
    return (crate::syntax::lexer::chars::peek(l1) == Text::lit(".")) && crate::syntax::lexer::chars::is_digit(next_)
        ? number_tail(skip_digits(crate::syntax::lexer::chars::bump(l1)), sigils, start, true)
        : (((crate::syntax::lexer::chars::peek(l1) == Text::lit(".")) && (next_ != Text::lit("."))) && (next_ != Text::lit(""))) && (!crate::syntax::lexer::chars::is_ident_start(next_))
        ? ({
        auto l2 = crate::syntax::lexer::chars::bump(l1);
        auto l3 = crate::syntax::lexer::chars::lex_err(l2, start, l2.pos, prism_rtl::cat("`", crate::syntax::lexer::chars::slice(l2, start, l2.pos), "` is not a number: a decimal literal has digits on both sides of its point"));
        auto kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KFloat{sigils, crate::syntax::lexer::chars::slice(l3, start, crate::syntax::lexer::chars::dec(l2.pos))});
        std::tuple{kind, l3};
    })
        : number_tail(l1, sigils, start, false);
}


prism_rtl::Turn<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> LexDecimal::cycle() const {
    const auto& l0 = this->l0;
    const auto& sigils = this->sigils;
    auto start = l0.pos;
    auto l0_1 = l0;
    auto sigils_2 = sigils;
    return call_then(start_skip_digits(l0_1), [=](crate::syntax::lexer::Lex skip_digits_1549) {
        return ({
            auto l1 = skip_digits_1549;
            auto next_ = crate::syntax::lexer::chars::peek_at(l1, Nat(1u));
            (crate::syntax::lexer::chars::peek(l1) == Text::lit(".")) && crate::syntax::lexer::chars::is_digit(next_)
            ? call_then(start_skip_digits(crate::syntax::lexer::chars::bump(l1)), [=](crate::syntax::lexer::Lex skip_digits_1647) { return prism_rtl::more(prism_rtl::rc(NumberTail(skip_digits_1647, sigils_2, start, true))); })
            : (((crate::syntax::lexer::chars::peek(l1) == Text::lit(".")) && (next_ != Text::lit("."))) && (next_ != Text::lit(""))) && (!crate::syntax::lexer::chars::is_ident_start(next_))
            ? ({
            auto l2 = crate::syntax::lexer::chars::bump(l1);
            auto l3 = crate::syntax::lexer::chars::lex_err(l2, start, l2.pos, prism_rtl::cat("`", crate::syntax::lexer::chars::slice(l2, start, l2.pos), "` is not a number: a decimal literal has digits on both sides of its point"));
            auto kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KFloat{sigils_2, crate::syntax::lexer::chars::slice(l3, start, crate::syntax::lexer::chars::dec(l2.pos))});
            (prism_rtl::finished(std::tuple{kind, l3}));
        })
            : prism_rtl::more(prism_rtl::rc(NumberTail(l1, sigils_2, start, false)));
        });
    });
}


/// `Start LexDecimal, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> start_lex_decimal(crate::syntax::lexer::Lex l0, Text sigils) {
    return prism_rtl::make_rc<LexDecimal>(l0, sigils);
}


/// let durationUnits
Array<std::tuple<Text, Nat>> duration_units() {
    return Array(std::vector{std::tuple{Text::lit("ns"), Nat(1u)}, std::tuple{Text::lit("us"), Nat(1000u)}, std::tuple{Text::lit("ms"), Nat(1000000u)}, std::tuple{Text::lit("min"), *Nat::from_int(Int(60000000000ll))}, std::tuple{Text::lit("s"), *Nat::from_int(Int(1000000000ll))}, std::tuple{Text::lit("h"), *Nat::from_int(Int(3600000000000ll))}});
}


/// ?UnitAt: fn Lex -> ?((Text, Nat))
std::optional<std::tuple<Text, Nat>> unit_at(const crate::syntax::lexer::Lex& l) {
    auto&& _m = crate::syntax::lexer::chars::match_here(([]() -> const Regex& { static const Regex r = Regex::lit("(?:ns|us|ms|min|s|h)\\b", ""); return r; }()), l);
    {
        auto&& m2712_0 = _m;
        if (m2712_0 == Text::lit("")) {
            return std::optional<std::tuple<Text, Nat>>{};
        }
    }
    {
        auto&& u = _m;
        return fold(duration_units(), std::optional<std::tuple<Text, Nat>>{}, [&](const std::optional<std::tuple<Text, Nat>>& found_opt, const std::tuple<Text, Nat>& _p1) {
            auto&& name = std::get<0>(_p1);
            auto&& scale = std::get<1>(_p1);
            return name == u ? std::optional(std::tuple{name, scale}) : found_opt;
        });
    }
}


/// NumberTail: unbounded fn Lex, Text, Nat, Bool -> ((TokKind, Lex))
std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> number_tail(const crate::syntax::lexer::Lex& l, const Text& sigils, const Nat& start, const bool& decimal) {
    auto&& _m = unit_at(l);
    if (prism_rtl::is_some(_m)) {
        auto&& u = std::get<0>(prism_rtl::some_of(_m));
        auto&& scale = std::get<1>(prism_rtl::some_of(_m));
        auto digits = crate::syntax::lexer::chars::slice(l, start, l.pos);
        auto l2 = crate::syntax::lexer::chars::forward(l, len_text(u));
        auto l3 = whole_nanoseconds(digits, scale)
            ? l2
            : crate::syntax::lexer::chars::lex_err(l2, start, l2.pos, prism_rtl::cat("`", digits, u, "` does not name a whole number of nanoseconds"));
        auto kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KDuration{sigils, digits, u});
        return std::tuple{kind, l3};
    }
    if (prism_rtl::is_none(_m)) {
        auto [dec, l2] = exponent(l, decimal);
        auto l3 = check_no_suffix(l2, start);
        auto text_ = crate::syntax::lexer::chars::slice(l3, start, l3.pos);
        auto kind = dec
            ? crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KFloat{sigils, text_})
            : crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KInt{sigils, text_});
        return std::tuple{kind, l3};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> NumberTail::cycle() const {
    const auto& l = this->l;
    const auto& sigils = this->sigils;
    const auto& start = this->start;
    const auto& decimal = this->decimal;
    return ({
        auto&& _m = unit_at(l);
        prism_rtl::is_some(_m) ? ({
        auto&& u = std::get<0>(prism_rtl::some_of(_m));
        auto&& scale = std::get<1>(prism_rtl::some_of(_m));
        ({
        auto digits = crate::syntax::lexer::chars::slice(l, start, l.pos);
        auto l2 = crate::syntax::lexer::chars::forward(l, len_text(u));
        auto l3 = whole_nanoseconds(digits, scale)
            ? l2
            : crate::syntax::lexer::chars::lex_err(l2, start, l2.pos, prism_rtl::cat("`", digits, u, "` does not name a whole number of nanoseconds"));
        auto kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KDuration{sigils, digits, u});
        (prism_rtl::finished(std::tuple{kind, l3}));
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto decimal_1 = decimal;
        auto l_2 = l;
        auto sigils_3 = sigils;
        auto start_4 = start;
        call_then(start_exponent(l_2, decimal_1), [=](std::tuple<bool, crate::syntax::lexer::Lex> exponent_3556) {
        return ({
            auto [dec, l2] = exponent_3556;
            call_then(start_check_no_suffix(l2, start_4), [=](crate::syntax::lexer::Lex check_no_suffix_3593) {
            return ({
                auto l3 = check_no_suffix_3593;
                auto text_ = crate::syntax::lexer::chars::slice(l3, start_4, l3.pos);
                auto kind = dec
                    ? crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KFloat{sigils_3, text_})
                    : crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KInt{sigils_3, text_});
                (prism_rtl::finished(std::tuple{kind, l3}));
            });
        });
        });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start NumberTail, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> start_number_tail(crate::syntax::lexer::Lex l, Text sigils, Nat start, bool decimal) {
    return prism_rtl::make_rc<NumberTail>(l, sigils, start, decimal);
}


/// Exponent: unbounded fn Lex, Bool -> ((Bool, Lex))
std::tuple<bool, crate::syntax::lexer::Lex> exponent(const crate::syntax::lexer::Lex& l, const bool& decimal) {
    auto end = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[eE][+-]?[0-9][0-9_]*", ""); return r; }()), l.src, l.pos);
    return end > l.pos
        ? ({
        auto l2 = ({
            crate::syntax::lexer::Lex this_ = l;
            this_.pos = end;
            this_;
        });
        std::tuple{true, l2};
    })
        : std::tuple{decimal, l};
}


prism_rtl::Turn<std::tuple<bool, crate::syntax::lexer::Lex>> Exponent::cycle() const {
    const auto& l = this->l;
    const auto& decimal = this->decimal;
    auto end = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[eE][+-]?[0-9][0-9_]*", ""); return r; }()), l.src, l.pos);
    return end > l.pos
        ? ({
        auto l2 = ({
            crate::syntax::lexer::Lex this_ = l;
            this_.pos = end;
            this_;
        });
        (prism_rtl::finished(std::tuple{true, l2}));
    })
        : prism_rtl::finished(std::tuple{decimal, l});
}


/// `Start Exponent, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<bool, crate::syntax::lexer::Lex>> start_exponent(crate::syntax::lexer::Lex l, bool decimal) {
    return prism_rtl::make_rc<Exponent>(l, decimal);
}


/// WholeNanoseconds: fn Text, Nat -> Bool
bool whole_nanoseconds(const Text& text_, const Nat& scale) {
    auto parts = split_on(concat(split_on(text_, Text::lit("_"))), Text::lit("."));
    auto&& _m = index(parts, Nat(1u));
    if (prism_rtl::is_none(_m)) {
        return true;
    }
    if (prism_rtl::is_some(_m)) {
        auto&& frac0 = prism_rtl::some_of(_m);
        auto frac = trim_zeros(frac0);
        auto k = len_text(frac);
        auto f = frac == Text::lit("") ? Nat(0u) : or_(parse_nat_opt(frac), Nat(1u));
        auto tens = crate::syntax::lexer::chars::fold_chars(frac, Nat(1u), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Nat>(std::tuple<Nat, Text>)>>(prism_rtl::rc([=](std::tuple<Nat, Text> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return once_job([=]() {
                return ({
                    auto p_ = p0;
                    static_cast<void>(p1);
                    (prism_rtl::finished(p_ * Nat(10u)));
                });
            });
        })));
        return (k <= Nat(30u)) && (or_(mod_(f * scale, tens), Nat(1u)) == Nat(0u));
    }
    prism_rtl::unreachable("no arm matched");
}


/// TrimZeros: fn Text -> Text
Text trim_zeros(const Text& t) {
    return crate::syntax::lexer::chars::trim_trailing(t, Text::lit("0"));
}


/// CheckNoSuffix: unbounded fn Lex, Nat -> Lex
crate::syntax::lexer::Lex check_no_suffix(const crate::syntax::lexer::Lex& l0, const Nat& start) {
    return crate::syntax::lexer::chars::is_ident_char(crate::syntax::lexer::chars::peek(l0))
        ? ({
        auto l = ({
            crate::syntax::lexer::Lex this_ = l0;
            this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[A-Za-z0-9_]*", ""); return r; }()), this_.src, this_.pos);
            this_;
        });
        (crate::syntax::lexer::chars::lex_err(l, start, l.pos, prism_rtl::cat("`", crate::syntax::lexer::chars::slice(l, start, l.pos), "` is not a token: a number literal has no suffix (write a type annotation)")));
    })
        : l0;
}


prism_rtl::Turn<crate::syntax::lexer::Lex> CheckNoSuffix::cycle() const {
    const auto& l0 = this->l0;
    const auto& start = this->start;
    return crate::syntax::lexer::chars::is_ident_char(crate::syntax::lexer::chars::peek(l0))
        ? ({
        auto l = ({
            crate::syntax::lexer::Lex this_ = l0;
            this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[A-Za-z0-9_]*", ""); return r; }()), this_.src, this_.pos);
            this_;
        });
        (prism_rtl::finished(crate::syntax::lexer::chars::lex_err(l, start, l.pos, prism_rtl::cat("`", crate::syntax::lexer::chars::slice(l, start, l.pos), "` is not a token: a number literal has no suffix (write a type annotation)"))));
    })
        : prism_rtl::finished(l0);
}


/// `Start CheckNoSuffix, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_check_no_suffix(crate::syntax::lexer::Lex l0, Nat start) {
    return prism_rtl::make_rc<CheckNoSuffix>(l0, start);
}


/// LexEscape: unbounded fn Lex -> ((Text, Lex))
std::tuple<Text, crate::syntax::lexer::Lex> lex_escape(const crate::syntax::lexer::Lex& l0) {
    auto start = l0.pos;
    auto l1 = crate::syntax::lexer::chars::bump(l0);
    auto c = crate::syntax::lexer::chars::peek(l1);
    auto l2 = crate::syntax::lexer::chars::bump(l1);
    {
        auto&& m5231_0 = c;
        if (m5231_0 == Text::lit("\\")) {
            return std::tuple{Text::lit("\\"), l2};
        }
    }
    {
        auto&& m5231_1 = c;
        if (m5231_1 == Text::lit("\"")) {
            return std::tuple{Text::lit("\""), l2};
        }
    }
    {
        auto&& m5231_2 = c;
        if (m5231_2 == Text::lit("\'")) {
            return std::tuple{Text::lit("\'"), l2};
        }
    }
    {
        auto&& m5231_3 = c;
        if (m5231_3 == Text::lit("n")) {
            return std::tuple{Text::lit("\n"), l2};
        }
    }
    {
        auto&& m5231_4 = c;
        if (m5231_4 == Text::lit("t")) {
            return std::tuple{Text::lit("\t"), l2};
        }
    }
    {
        auto&& m5231_5 = c;
        if (m5231_5 == Text::lit("{")) {
            return std::tuple{Text::lit("{"), l2};
        }
    }
    {
        auto&& m5231_6 = c;
        if (m5231_6 == Text::lit("}")) {
            return std::tuple{Text::lit("}"), l2};
        }
    }
    {
        auto&& m5231_7 = c;
        if (m5231_7 == Text::lit("u")) {
            return unicode_escape(l2, start);
        }
    }
    {
        auto&& m5231_8 = c;
        if (m5231_8 == Text::lit("")) {
            return std::tuple{Text::lit(""), crate::syntax::lexer::chars::lex_err(l1, start, l1.pos, Text::lit("a text literal ends inside an escape"))};
        }
    }
    {
        return std::tuple{Text::lit(""), crate::syntax::lexer::chars::lex_err(l2, start, l2.pos, prism_rtl::cat("`\\", c, "` is not an escape: the escapes are \\\\ \\\" \\n \\t \\{ \\} \\u{hex}"))};
    }
}


prism_rtl::Turn<std::tuple<Text, crate::syntax::lexer::Lex>> LexEscape::cycle() const {
    const auto& l0 = this->l0;
    auto start = l0.pos;
    auto l1 = crate::syntax::lexer::chars::bump(l0);
    auto c = crate::syntax::lexer::chars::peek(l1);
    auto l2 = crate::syntax::lexer::chars::bump(l1);
    return ({
        ({
        auto&& m5231_0 = c;
        (m5231_0 == Text::lit("\\"));
    }) ? ({
        auto&& m5231_0 = c;
        prism_rtl::finished(std::tuple{Text::lit("\\"), l2});
    })
        : ({
        auto&& m5231_1 = c;
        (m5231_1 == Text::lit("\""));
    }) ? ({
        auto&& m5231_1 = c;
        prism_rtl::finished(std::tuple{Text::lit("\""), l2});
    })
        : ({
        auto&& m5231_2 = c;
        (m5231_2 == Text::lit("\'"));
    }) ? ({
        auto&& m5231_2 = c;
        prism_rtl::finished(std::tuple{Text::lit("\'"), l2});
    })
        : ({
        auto&& m5231_3 = c;
        (m5231_3 == Text::lit("n"));
    }) ? ({
        auto&& m5231_3 = c;
        prism_rtl::finished(std::tuple{Text::lit("\n"), l2});
    })
        : ({
        auto&& m5231_4 = c;
        (m5231_4 == Text::lit("t"));
    }) ? ({
        auto&& m5231_4 = c;
        prism_rtl::finished(std::tuple{Text::lit("\t"), l2});
    })
        : ({
        auto&& m5231_5 = c;
        (m5231_5 == Text::lit("{"));
    }) ? ({
        auto&& m5231_5 = c;
        prism_rtl::finished(std::tuple{Text::lit("{"), l2});
    })
        : ({
        auto&& m5231_6 = c;
        (m5231_6 == Text::lit("}"));
    }) ? ({
        auto&& m5231_6 = c;
        prism_rtl::finished(std::tuple{Text::lit("}"), l2});
    })
        : ({
        auto&& m5231_7 = c;
        (m5231_7 == Text::lit("u"));
    }) ? ({
        auto&& m5231_7 = c;
        prism_rtl::more(prism_rtl::rc(UnicodeEscape(l2, start)));
    })
        : ({
        auto&& m5231_8 = c;
        (m5231_8 == Text::lit(""));
    }) ? ({
        auto&& m5231_8 = c;
        prism_rtl::finished(std::tuple{Text::lit(""), crate::syntax::lexer::chars::lex_err(l1, start, l1.pos, Text::lit("a text literal ends inside an escape"))});
    })
        : prism_rtl::finished(std::tuple{Text::lit(""), crate::syntax::lexer::chars::lex_err(l2, start, l2.pos, prism_rtl::cat("`\\", c, "` is not an escape: the escapes are \\\\ \\\" \\n \\t \\{ \\} \\u{hex}"))});
    });
}


/// `Start LexEscape, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::syntax::lexer::Lex>> start_lex_escape(crate::syntax::lexer::Lex l0) {
    return prism_rtl::make_rc<LexEscape>(l0);
}


/// UnicodeEscape: unbounded fn Lex, Nat -> ((Text, Lex))
std::tuple<Text, crate::syntax::lexer::Lex> unicode_escape(const crate::syntax::lexer::Lex& l, const Nat& start) {
    return crate::syntax::lexer::chars::peek(l) != Text::lit("{")
        ? std::tuple{Text::lit(""), crate::syntax::lexer::chars::lex_err(l, start, l.pos, Text::lit("`\\u` is written `\\u{hex}`"))}
        : ({
        auto hs = l.pos + Nat(1u);
        auto l1 = ({
            crate::syntax::lexer::Lex this_ = crate::syntax::lexer::chars::bump(l);
            this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[0-9a-fA-F]*", ""); return r; }()), this_.src, this_.pos);
            this_;
        });
        auto hex = crate::syntax::lexer::chars::slice(l1, hs, l1.pos);
        (crate::syntax::lexer::chars::peek(l1) != Text::lit("}")
        ? std::tuple{Text::lit(""), crate::syntax::lexer::chars::lex_err(l1, start, l1.pos, Text::lit("`\\u{` needs its closing `}`"))}
        : ({
        auto l2 = crate::syntax::lexer::chars::bump(l1);
        ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Text, crate::syntax::lexer::Lex>> _v;
        auto&& _m = crate::syntax::lexer::chars::ascii_char(or_(crate::syntax::lexer::chars::parse_hex(hex), Nat(1114112u)));
        if (prism_rtl::is_some(_m)) {
            auto&& ch = prism_rtl::some_of(_m);
            _v.set(std::tuple{ch, l2});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::tuple{Text::lit(""), crate::syntax::lexer::chars::lex_err(l2, start, l2.pos, prism_rtl::cat("`\\u{", hex, "}` is past ASCII, which prismc cannot write yet (prismc/README.md, gap UC)"))});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    }));
    });
}


prism_rtl::Turn<std::tuple<Text, crate::syntax::lexer::Lex>> UnicodeEscape::cycle() const {
    const auto& l = this->l;
    const auto& start = this->start;
    return crate::syntax::lexer::chars::peek(l) != Text::lit("{")
        ? prism_rtl::finished(std::tuple{Text::lit(""), crate::syntax::lexer::chars::lex_err(l, start, l.pos, Text::lit("`\\u` is written `\\u{hex}`"))})
        : ({
        auto hs = l.pos + Nat(1u);
        auto l1 = ({
            crate::syntax::lexer::Lex this_ = crate::syntax::lexer::chars::bump(l);
            this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[0-9a-fA-F]*", ""); return r; }()), this_.src, this_.pos);
            this_;
        });
        auto hex = crate::syntax::lexer::chars::slice(l1, hs, l1.pos);
        (crate::syntax::lexer::chars::peek(l1) != Text::lit("}")
        ? prism_rtl::finished(std::tuple{Text::lit(""), crate::syntax::lexer::chars::lex_err(l1, start, l1.pos, Text::lit("`\\u{` needs its closing `}`"))})
        : ({
        auto l2 = crate::syntax::lexer::chars::bump(l1);
        ({
        auto&& _m = crate::syntax::lexer::chars::ascii_char(or_(crate::syntax::lexer::chars::parse_hex(hex), Nat(1114112u)));
        prism_rtl::is_some(_m) ? ({
        auto&& ch = prism_rtl::some_of(_m);
        prism_rtl::finished(std::tuple{ch, l2});
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{Text::lit(""), crate::syntax::lexer::chars::lex_err(l2, start, l2.pos, prism_rtl::cat("`\\u{", hex, "}` is past ASCII, which prismc cannot write yet (prismc/README.md, gap UC)"))})
        : throw prism_rtl::Panic("no arm matched");
    });
    }));
    });
}


/// `Start UnicodeEscape, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::syntax::lexer::Lex>> start_unicode_escape(crate::syntax::lexer::Lex l, Nat start) {
    return prism_rtl::make_rc<UnicodeEscape>(l, start);
}


/// LexText: unbounded fn Lex -> (([TextSegTok], Lex))
std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex> lex_text(const crate::syntax::lexer::Lex& l0) {
    std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex> this_ = std::tuple{Array<crate::syntax::lexer::TextSegTok>{}, l0};
    auto start = l0.pos;
    crate::syntax::lexer::Lex l = crate::syntax::lexer::chars::bump(l0);
    Array<crate::syntax::lexer::TextSegTok> segs = Array<crate::syntax::lexer::TextSegTok>{};
    Text cur = Text::lit("");
    bool going = true;
    while (going) {
        auto c = crate::syntax::lexer::chars::peek(l);
        if ((c == Text::lit("")) || (c == Text::lit("\n"))) {
            l = crate::syntax::lexer::chars::lex_err(l, start, l.pos, Text::lit("a text literal ends on its line: close it with `\"`, or write a multiline text as `raw <markdown>...</markdown>`"));
            going = false;
        } else  {
            ({
                __label__ _done;
                prism_rtl::Slot<Unit> _v;
                {
                    auto&& u6966_0 = c;
                    if (u6966_0 == Text::lit("\"")) {
                        _v.set(({
                            l = crate::syntax::lexer::chars::bump(l);
                            going = false;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u6966_1 = c;
                    if (u6966_1 == Text::lit("\\")) {
                        _v.set(({
                            auto [s, l2] = lex_escape(l);
                            cur = prism_rtl::cat(cur, s);
                            l = l2;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u6966_2 = c;
                    if (u6966_2 == Text::lit("{")) {
                        _v.set(({
                            if (cur != Text::lit("")) {
                                segs = crate::prelude::push(segs, crate::syntax::lexer::TextSegTok(crate::syntax::lexer::TextSegTok::TsPlain{cur}));
                                cur = Text::lit("");
                            }
                            auto ps = l.pos;
                            auto [toks, l2] = crate::syntax::lexer::layout::nested(crate::syntax::lexer::chars::bump(l), crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MPlaceholder{Text::lit("single")}));
                            segs = crate::prelude::push(segs, crate::syntax::lexer::TextSegTok(crate::syntax::lexer::TextSegTok::TsPlaceholder{toks, crate::syntax::Range{.start = ps, .end = l2.pos}}));
                            l = l2;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u6966_3 = c;
                    if (u6966_3 == Text::lit("}")) {
                        _v.set(({
                            l = crate::syntax::lexer::chars::lex_err(crate::syntax::lexer::chars::bump(l), l.pos, l.pos + Nat(1u), Text::lit("a `}` in text is written `\\}`"));
                            cur = prism_rtl::cat(cur, "}");
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    _v.set(({
                        auto run_ = crate::syntax::lexer::chars::match_here(([]() -> const Regex& { static const Regex r = Regex::lit("[^\"\\\\{}\\n]+", ""); return r; }()), l);
                        l.pos = l.pos + len_text(run_);
                        cur = prism_rtl::cat(cur, run_);
                        Unit{};
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            });
        }
    }
    if (cur != Text::lit("")) {
        segs = crate::prelude::push(segs, crate::syntax::lexer::TextSegTok(crate::syntax::lexer::TextSegTok::TsPlain{cur}));
    }
    this_ = std::tuple{segs, l};
    return this_;
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex>> LexText::cycle() const {
    const auto& l0 = this->l0;
    std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex> this_ = std::tuple{Array<crate::syntax::lexer::TextSegTok>{}, l0};
    auto start = l0.pos;
    crate::syntax::lexer::Lex l = crate::syntax::lexer::chars::bump(l0);
    Array<crate::syntax::lexer::TextSegTok> segs = Array<crate::syntax::lexer::TextSegTok>{};
    Text cur = Text::lit("");
    bool going = true;
    return call_then(loop_job(std::tuple{this_, cur, going, l, segs}, ({
        auto start_1 = start;
        [=](std::tuple<std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex>, Text, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::TextSegTok>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto cur = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto l = std::get<3>(_p0);
        auto segs = std::get<4>(_p0);
        return going
            ? ({
            auto c = crate::syntax::lexer::chars::peek(l);
            if ((c == Text::lit("")) || (c == Text::lit("\n"))) {
                l = crate::syntax::lexer::chars::lex_err(l, start_1, l.pos, Text::lit("a text literal ends on its line: close it with `\"`, or write a multiline text as `raw <markdown>...</markdown>`"));
                going = false;
            } else  {
                ({
                    __label__ _done;
                    prism_rtl::Slot<Unit> _v;
                    {
                        auto&& u6966_0 = c;
                        if (u6966_0 == Text::lit("\"")) {
                            _v.set(({
                                l = crate::syntax::lexer::chars::bump(l);
                                going = false;
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        auto&& u6966_1 = c;
                        if (u6966_1 == Text::lit("\\")) {
                            _v.set(({
                                auto [s, l2] = lex_escape(l);
                                cur = prism_rtl::cat(cur, s);
                                l = l2;
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        auto&& u6966_2 = c;
                        if (u6966_2 == Text::lit("{")) {
                            _v.set(({
                                if (cur != Text::lit("")) {
                                    segs = crate::prelude::push(segs, crate::syntax::lexer::TextSegTok(crate::syntax::lexer::TextSegTok::TsPlain{cur}));
                                    cur = Text::lit("");
                                }
                                auto ps = l.pos;
                                auto [toks, l2] = crate::syntax::lexer::layout::nested(crate::syntax::lexer::chars::bump(l), crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MPlaceholder{Text::lit("single")}));
                                segs = crate::prelude::push(segs, crate::syntax::lexer::TextSegTok(crate::syntax::lexer::TextSegTok::TsPlaceholder{toks, crate::syntax::Range{.start = ps, .end = l2.pos}}));
                                l = l2;
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        auto&& u6966_3 = c;
                        if (u6966_3 == Text::lit("}")) {
                            _v.set(({
                                l = crate::syntax::lexer::chars::lex_err(crate::syntax::lexer::chars::bump(l), l.pos, l.pos + Nat(1u), Text::lit("a `}` in text is written `\\}`"));
                                cur = prism_rtl::cat(cur, "}");
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        _v.set(({
                            auto run_ = crate::syntax::lexer::chars::match_here(([]() -> const Regex& { static const Regex r = Regex::lit("[^\"\\\\{}\\n]+", ""); return r; }()), l);
                            l.pos = l.pos + len_text(run_);
                            cur = prism_rtl::cat(cur, run_);
                            Unit{};
                        }));
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            }
            Expected<std::tuple<std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex>, Text, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::TextSegTok>>, std::tuple<std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex>, Text, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::TextSegTok>>>(std::tuple{this_, cur, going, l, segs});
        })
            : Expected<std::tuple<std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex>, Text, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::TextSegTok>>, std::tuple<std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex>, Text, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::TextSegTok>>>(unexpected(std::tuple{this_, cur, going, l, segs}));
    };
    })), [=](std::tuple<std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex>, Text, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::TextSegTok>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto cur = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto l = std::get<3>(_p0);
        auto segs = std::get<4>(_p0);
        return ({
            if (cur != Text::lit("")) {
                segs = crate::prelude::push(segs, crate::syntax::lexer::TextSegTok(crate::syntax::lexer::TextSegTok::TsPlain{cur}));
            }
            this_ = std::tuple{segs, l};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start LexText, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex>> start_lex_text(crate::syntax::lexer::Lex l0) {
    return prism_rtl::make_rc<LexText>(l0);
}


/// LexChar: unbounded fn Lex -> ((Text, Lex))
std::tuple<Text, crate::syntax::lexer::Lex> lex_char(const crate::syntax::lexer::Lex& l0) {
    auto start = l0.pos;
    auto l1 = crate::syntax::lexer::chars::bump(l0);
    auto c = crate::syntax::lexer::chars::peek(l1);
    auto [s, l2] = c == Text::lit("\\")
        ? lex_escape(l1)
        : ((c == Text::lit("\'")) || (c == Text::lit("\n"))) || (c == Text::lit(""))
        ? std::tuple{Text::lit(""), l1}
        : std::tuple{c, crate::syntax::lexer::chars::bump(l1)};
    auto ok_ = crate::syntax::lexer::chars::peek(l2) == Text::lit("\'");
    auto l3 = ok_ ? crate::syntax::lexer::chars::bump(l2) : char_tail(l2, start);
    auto l4 = s == Text::lit("")
        ? crate::syntax::lexer::chars::lex_err(l3, start, l3.pos, Text::lit("a character literal holds one code point: `\'c\'`"))
        : l3;
    auto ch = s == Text::lit("") ? Text::lit("\000"sv) : s;
    return std::tuple{ch, l4};
}


prism_rtl::Turn<std::tuple<Text, crate::syntax::lexer::Lex>> LexChar::cycle() const {
    const auto& l0 = this->l0;
    auto start = l0.pos;
    auto l1 = crate::syntax::lexer::chars::bump(l0);
    auto c = crate::syntax::lexer::chars::peek(l1);
    auto [s, l2] = c == Text::lit("\\")
        ? lex_escape(l1)
        : ((c == Text::lit("\'")) || (c == Text::lit("\n"))) || (c == Text::lit(""))
        ? std::tuple{Text::lit(""), l1}
        : std::tuple{c, crate::syntax::lexer::chars::bump(l1)};
    auto ok_ = crate::syntax::lexer::chars::peek(l2) == Text::lit("\'");
    auto l3 = ok_ ? crate::syntax::lexer::chars::bump(l2) : char_tail(l2, start);
    auto l4 = s == Text::lit("")
        ? crate::syntax::lexer::chars::lex_err(l3, start, l3.pos, Text::lit("a character literal holds one code point: `\'c\'`"))
        : l3;
    auto ch = s == Text::lit("") ? Text::lit("\000"sv) : s;
    return prism_rtl::finished(std::tuple{ch, l4});
}


/// `Start LexChar, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::syntax::lexer::Lex>> start_lex_char(crate::syntax::lexer::Lex l0) {
    return prism_rtl::make_rc<LexChar>(l0);
}


/// CharTail: unbounded fn Lex, Nat -> Lex
crate::syntax::lexer::Lex char_tail(const crate::syntax::lexer::Lex& l0, const Nat& start) {
    auto l1 = ({
        crate::syntax::lexer::Lex this_ = l0;
        this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[^\'\\n]*", ""); return r; }()), this_.src, this_.pos);
        this_;
    });
    auto l2 = crate::syntax::lexer::chars::peek(l1) == Text::lit("\'")
        ? crate::syntax::lexer::chars::bump(l1)
        : l1;
    return crate::syntax::lexer::chars::lex_err(l2, start, l2.pos, Text::lit("a character literal holds one code point: `\'c\'`"));
}


prism_rtl::Turn<crate::syntax::lexer::Lex> CharTail::cycle() const {
    const auto& l0 = this->l0;
    const auto& start = this->start;
    auto l1 = ({
        crate::syntax::lexer::Lex this_ = l0;
        this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[^\'\\n]*", ""); return r; }()), this_.src, this_.pos);
        this_;
    });
    auto l2 = crate::syntax::lexer::chars::peek(l1) == Text::lit("\'")
        ? crate::syntax::lexer::chars::bump(l1)
        : l1;
    return prism_rtl::finished(crate::syntax::lexer::chars::lex_err(l2, start, l2.pos, Text::lit("a character literal holds one code point: `\'c\'`")));
}


/// `Start CharTail, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_char_tail(crate::syntax::lexer::Lex l0, Nat start) {
    return prism_rtl::make_rc<CharTail>(l0, start);
}


/// LexPath: unbounded fn Lex -> (([PathSegTok], Lex))
std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex> lex_path(const crate::syntax::lexer::Lex& l0) {
    std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex> this_ = std::tuple{Array<crate::syntax::lexer::PathSegTok>{}, l0};
    crate::syntax::lexer::Lex l = l0;
    Array<crate::syntax::lexer::PathSegTok> segs = Array<crate::syntax::lexer::PathSegTok>{};
    bool going = true;
    while (going) {
        auto s = l.pos;
        auto c = crate::syntax::lexer::chars::peek(l);
        if (c == Text::lit("#")) {
            auto digits = ({
                crate::syntax::lexer::Lex this_ = crate::syntax::lexer::chars::bump(l);
                this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[0-9]*", ""); return r; }()), this_.src, this_.pos);
                this_;
            });
            auto text_ = crate::syntax::lexer::chars::slice(digits, s + Nat(1u), digits.pos);
            l = text_ == Text::lit("")
                ? crate::syntax::lexer::chars::lex_err(digits, s, digits.pos, Text::lit("a generation segment is `#` and a number"))
                : digits;
            segs = crate::prelude::push(segs, crate::syntax::lexer::PathSegTok(crate::syntax::lexer::PathSegTok::PstGen{or_(parse_nat_opt(text_), Nat(0u))}));
        } else if (crate::syntax::lexer::chars::is_digit(c)) {
            auto digits = ({
                crate::syntax::lexer::Lex this_ = l;
                this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[0-9]*", ""); return r; }()), this_.src, this_.pos);
                this_;
            });
            segs = crate::prelude::push(segs, crate::syntax::lexer::PathSegTok(crate::syntax::lexer::PathSegTok::PstNum{or_(parse_nat_opt(crate::syntax::lexer::chars::slice(digits, s, digits.pos)), Nat(0u))}));
            l = digits;
        } else if (c == Text::lit("[")) {
            auto [toks, l2] = crate::syntax::lexer::layout::nested(crate::syntax::lexer::chars::bump(l), crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MPathKey{}));
            segs = crate::prelude::push(segs, crate::syntax::lexer::PathSegTok(crate::syntax::lexer::PathSegTok::PstKey{toks}));
            l = l2;
        } else  {
            l = crate::syntax::lexer::chars::lex_err(l, s, s, Text::lit("expected a path segment: a number, `#` and a number, or `[key]`"));
            going = false;
        }
        if (going) {
            if (crate::syntax::lexer::chars::peek(l) == Text::lit("/")) {
                l = crate::syntax::lexer::chars::bump(l);
            } else  {
                going = false;
            }
        }
    }
    this_ = std::tuple{segs, l};
    return this_;
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex>> LexPath::cycle() const {
    const auto& l0 = this->l0;
    std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex> this_ = std::tuple{Array<crate::syntax::lexer::PathSegTok>{}, l0};
    crate::syntax::lexer::Lex l = l0;
    Array<crate::syntax::lexer::PathSegTok> segs = Array<crate::syntax::lexer::PathSegTok>{};
    bool going = true;
    return call_then(loop_job(std::tuple{this_, going, l, segs}, [=](std::tuple<std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::PathSegTok>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going = std::get<1>(_p0);
        auto l = std::get<2>(_p0);
        auto segs = std::get<3>(_p0);
        return going
            ? ({
            auto s = l.pos;
            auto c = crate::syntax::lexer::chars::peek(l);
            if (c == Text::lit("#")) {
                auto digits = ({
                    crate::syntax::lexer::Lex this_ = crate::syntax::lexer::chars::bump(l);
                    this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[0-9]*", ""); return r; }()), this_.src, this_.pos);
                    this_;
                });
                auto text_ = crate::syntax::lexer::chars::slice(digits, s + Nat(1u), digits.pos);
                l = text_ == Text::lit("")
                    ? crate::syntax::lexer::chars::lex_err(digits, s, digits.pos, Text::lit("a generation segment is `#` and a number"))
                    : digits;
                segs = crate::prelude::push(segs, crate::syntax::lexer::PathSegTok(crate::syntax::lexer::PathSegTok::PstGen{or_(parse_nat_opt(text_), Nat(0u))}));
            } else if (crate::syntax::lexer::chars::is_digit(c)) {
                auto digits = ({
                    crate::syntax::lexer::Lex this_ = l;
                    this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[0-9]*", ""); return r; }()), this_.src, this_.pos);
                    this_;
                });
                segs = crate::prelude::push(segs, crate::syntax::lexer::PathSegTok(crate::syntax::lexer::PathSegTok::PstNum{or_(parse_nat_opt(crate::syntax::lexer::chars::slice(digits, s, digits.pos)), Nat(0u))}));
                l = digits;
            } else if (c == Text::lit("[")) {
                auto [toks, l2] = crate::syntax::lexer::layout::nested(crate::syntax::lexer::chars::bump(l), crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MPathKey{}));
                segs = crate::prelude::push(segs, crate::syntax::lexer::PathSegTok(crate::syntax::lexer::PathSegTok::PstKey{toks}));
                l = l2;
            } else  {
                l = crate::syntax::lexer::chars::lex_err(l, s, s, Text::lit("expected a path segment: a number, `#` and a number, or `[key]`"));
                going = false;
            }
            if (going) {
                if (crate::syntax::lexer::chars::peek(l) == Text::lit("/")) {
                    l = crate::syntax::lexer::chars::bump(l);
                } else  {
                    going = false;
                }
            }
            Expected<std::tuple<std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::PathSegTok>>, std::tuple<std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::PathSegTok>>>(std::tuple{this_, going, l, segs});
        })
            : Expected<std::tuple<std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::PathSegTok>>, std::tuple<std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::PathSegTok>>>(unexpected(std::tuple{this_, going, l, segs}));
    }), [=](std::tuple<std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::PathSegTok>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going = std::get<1>(_p0);
        auto l = std::get<2>(_p0);
        auto segs = std::get<3>(_p0);
        return ({
            this_ = std::tuple{segs, l};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start LexPath, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex>> start_lex_path(crate::syntax::lexer::Lex l0) {
    return prism_rtl::make_rc<LexPath>(l0);
}

}  // namespace crate::syntax::lexer::literals


// The module `Syntax.Lexer.Regexes`, from `target/bootstrap/cpp-src/prismc/syntax/lexer/regexes.prism`.
namespace crate::syntax::lexer::regexes {

/// let percentMessage
Text percent_message() {
    return Text::lit("`%` is no operator: the remainder is `mod`, and `%` begins a regular expression only as `%/` or `%#/`");
}


/// LexRegex: unbounded fn Lex, Text, Nat -> Lex
crate::syntax::lexer::Lex lex_regex(const crate::syntax::lexer::Lex& l, const Text& sigils, const Nat& start) {
    auto pct = l.pos;
    auto open = hashes_end(l.src, pct + Nat(1u));
    auto hashes = crate::syntax::lexer::chars::between(l.src, pct + Nat(1u), open);
    return crate::syntax::lexer::chars::char_at_byte(l.src, open) != Text::lit("/")
        ? no_regex(l, pct, open, hashes)
        : ({
        auto close = prism_rtl::cat("/", hashes);
        auto end_opt = hashes == Text::lit("")
            ? plain_end(l.src, open + Nat(1u))
            : hashed_end(l.src, open + Nat(1u), close);
        ({
        __label__ _done;
        prism_rtl::Slot<crate::syntax::lexer::Lex> _v;
        if (prism_rtl::is_some(end_opt)) {
            auto&& e = prism_rtl::some_of(end_opt);
            _v.set(after_pattern(l, sigils, start, open + Nat(1u), e, close));
            goto _done;
        }
        if (prism_rtl::is_none(end_opt)) {
            _v.set(unclosed(l, sigils, start, crate::syntax::lexer::chars::between(l.src, open + Nat(1u), line_end_at(l.src, open)), open + Nat(1u), std::optional<Text>{}, Text::lit("pattern"), close));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    });
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexRegex::cycle() const {
    const auto& l = this->l;
    const auto& sigils = this->sigils;
    const auto& start = this->start;
    auto pct = l.pos;
    auto open = hashes_end(l.src, pct + Nat(1u));
    auto hashes = crate::syntax::lexer::chars::between(l.src, pct + Nat(1u), open);
    return crate::syntax::lexer::chars::char_at_byte(l.src, open) != Text::lit("/")
        ? prism_rtl::finished(no_regex(l, pct, open, hashes))
        : ({
        auto close = prism_rtl::cat("/", hashes);
        auto end_opt = hashes == Text::lit("")
            ? plain_end(l.src, open + Nat(1u))
            : hashed_end(l.src, open + Nat(1u), close);
        ({
        prism_rtl::is_some(end_opt) ? ({
        auto&& e = prism_rtl::some_of(end_opt);
        prism_rtl::more(prism_rtl::rc(AfterPattern(l, sigils, start, open + Nat(1u), e, close)));
    })
        : prism_rtl::is_none(end_opt) ? prism_rtl::more(prism_rtl::rc(Unclosed(l, sigils, start, crate::syntax::lexer::chars::between(l.src, open + Nat(1u), line_end_at(l.src, open)), open + Nat(1u), std::optional<Text>{}, Text::lit("pattern"), close)))
        : throw prism_rtl::Panic("no arm matched");
    });
    });
}


/// `Start LexRegex, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_regex(crate::syntax::lexer::Lex l, Text sigils, Nat start) {
    return prism_rtl::make_rc<LexRegex>(l, sigils, start);
}


/// NoRegex: fn Lex, Nat, Nat, Text -> Lex
crate::syntax::lexer::Lex no_regex(const crate::syntax::lexer::Lex& l, const Nat& pct, const Nat& open, const Text& hashes) {
    auto end = hashes == Text::lit("") ? pct + Nat(1u) : open;
    auto message = hashes == Text::lit("")
        ? percent_message()
        : Text::lit("a hashed regular expression opens with `%`, its hashes and `/`: `%#/.../#`");
    auto l1 = ({
        crate::syntax::lexer::Lex this_ = l;
        this_.pos = end;
        this_;
    });
    auto l2 = crate::syntax::lexer::chars::lex_err(l1, pct, end, message);
    crate::syntax::lexer::Lex this_ = l2;
    this_.last_ws = true;
    return this_;
}


/// AfterPattern: unbounded fn Lex, Text, Nat, Nat, Nat, Text -> Lex
crate::syntax::lexer::Lex after_pattern(const crate::syntax::lexer::Lex& l, const Text& sigils, const Nat& start, const Nat& at_, const Nat& end, const Text& close) {
    auto src = l.src;
    auto pattern = crate::syntax::lexer::chars::between(src, at_, end);
    auto after_ = end + len_text(close);
    auto run_end = letters_end(src, after_);
    auto run_ = crate::syntax::lexer::chars::between(src, after_, run_end);
    auto c = crate::syntax::lexer::chars::char_at_byte(src, run_end);
    auto plain = close == Text::lit("/");
    return (((c == Text::lit("")) || (c == Text::lit("\n"))) || crate::syntax::lexer::chars::contains(Text::lit(",)]}:;"), c)) || (plain && crate::syntax::lexer::chars::is_space_char(c))
        ? finish(l, sigils, start, pattern, at_, std::optional<Text>{}, Nat(0u), after_)
        : crate::syntax::lexer::chars::has_prefix(text_from(src, run_end), close)
        ? finish(l, sigils, start, pattern, at_, std::optional(run_), after_, run_end + len_text(close))
        : plain && (run_ == Text::lit(""))
        ? ({
        __label__ _done;
        prism_rtl::Slot<crate::syntax::lexer::Lex> _v;
        auto&& _m = plain_end(src, after_);
        if (prism_rtl::is_some(_m)) {
            auto&& e = prism_rtl::some_of(_m);
            _v.set(finish(l, sigils, start, pattern, at_, std::optional(crate::syntax::lexer::chars::between(src, after_, e)), after_, e + Nat(1u)));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(unclosed(l, sigils, start, pattern, at_, std::optional(crate::syntax::lexer::chars::between(src, after_, line_end_at(src, after_))), Text::lit("replacement"), close));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    })
        : (!plain) && ((run_ == Text::lit("")) || crate::syntax::lexer::chars::is_space_char(c))
        ? ({
        __label__ _done;
        prism_rtl::Slot<crate::syntax::lexer::Lex> _v;
        auto&& _m = hashed_end(src, after_, close);
        if (prism_rtl::is_some(_m)) {
            auto&& e = prism_rtl::some_of(_m);
            _v.set(finish(l, sigils, start, pattern, at_, std::optional(crate::syntax::lexer::chars::between(src, after_, e)), after_, e + len_text(close)));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(finish(l, sigils, start, pattern, at_, std::optional<Text>{}, Nat(0u), after_));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    })
        : finish(l, sigils, start, pattern, at_, std::optional<Text>{}, Nat(0u), after_);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> AfterPattern::cycle() const {
    const auto& l = this->l;
    const auto& sigils = this->sigils;
    const auto& start = this->start;
    const auto& at_ = this->at_;
    const auto& end = this->end;
    const auto& close = this->close;
    auto src = l.src;
    auto pattern = crate::syntax::lexer::chars::between(src, at_, end);
    auto after_ = end + len_text(close);
    auto run_end = letters_end(src, after_);
    auto run_ = crate::syntax::lexer::chars::between(src, after_, run_end);
    auto c = crate::syntax::lexer::chars::char_at_byte(src, run_end);
    auto plain = close == Text::lit("/");
    return (((c == Text::lit("")) || (c == Text::lit("\n"))) || crate::syntax::lexer::chars::contains(Text::lit(",)]}:;"), c)) || (plain && crate::syntax::lexer::chars::is_space_char(c))
        ? prism_rtl::more(prism_rtl::rc(Finish(l, sigils, start, pattern, at_, std::optional<Text>{}, Nat(0u), after_)))
        : crate::syntax::lexer::chars::has_prefix(text_from(src, run_end), close)
        ? prism_rtl::more(prism_rtl::rc(Finish(l, sigils, start, pattern, at_, std::optional(run_), after_, run_end + len_text(close))))
        : plain && (run_ == Text::lit(""))
        ? ({
        auto&& _m = plain_end(src, after_);
        prism_rtl::is_some(_m) ? ({
        auto&& e = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(Finish(l, sigils, start, pattern, at_, std::optional(crate::syntax::lexer::chars::between(src, after_, e)), after_, e + Nat(1u))));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(Unclosed(l, sigils, start, pattern, at_, std::optional(crate::syntax::lexer::chars::between(src, after_, line_end_at(src, after_))), Text::lit("replacement"), close)))
        : throw prism_rtl::Panic("no arm matched");
    })
        : (!plain) && ((run_ == Text::lit("")) || crate::syntax::lexer::chars::is_space_char(c))
        ? ({
        auto at__1 = at_;
        auto close_2 = close;
        auto l_3 = l;
        auto sigils_4 = sigils;
        auto start_5 = start;
        call_then(start_hashed_end(src, after_, close_2), [=](std::optional<Nat> hashed_end_3454) {
        return ({
            prism_rtl::is_some(hashed_end_3454) ? ({
            auto&& e = prism_rtl::some_of(hashed_end_3454);
            prism_rtl::more(prism_rtl::rc(Finish(l_3, sigils_4, start_5, pattern, at__1, std::optional(crate::syntax::lexer::chars::between(src, after_, e)), after_, e + len_text(close_2))));
        })
            : prism_rtl::is_none(hashed_end_3454) ? prism_rtl::more(prism_rtl::rc(Finish(l_3, sigils_4, start_5, pattern, at__1, std::optional<Text>{}, Nat(0u), after_)))
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    })
        : prism_rtl::more(prism_rtl::rc(Finish(l, sigils, start, pattern, at_, std::optional<Text>{}, Nat(0u), after_)));
}


/// `Start AfterPattern, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_after_pattern(crate::syntax::lexer::Lex l, Text sigils, Nat start, Nat at_, Nat end, Text close) {
    return prism_rtl::make_rc<AfterPattern>(l, sigils, start, at_, end, close);
}


/// Finish: unbounded fn Lex, Text, Nat, Text, Nat, ?Text, Nat, Nat -> Lex
crate::syntax::lexer::Lex finish(const crate::syntax::lexer::Lex& l, const Text& sigils, const Nat& start, const Text& pattern, const Nat& at_, const std::optional<Text>& replacement_opt, const Nat& replacement_at, const Nat& flags_at) {
    auto src = l.src;
    auto flags_end = letters_end(src, flags_at);
    auto lit = crate::syntax::RegexLit{.pattern = pattern, .pattern_at = at_, .replacement = replacement_opt, .replacement_at = replacement_at, .flags = crate::syntax::lexer::chars::between(src, flags_at, flags_end), .flags_at = flags_at};
    auto tail = ident_end(src, flags_end);
    auto l1 = ({
        crate::syntax::lexer::Lex this_ = l;
        this_.pos = tail;
        this_;
    });
    auto l2 = tail > flags_end
        ? crate::syntax::lexer::chars::lex_err(l1, flags_end, tail, prism_rtl::cat("`", crate::syntax::lexer::chars::between(src, flags_end, tail), "` touches the flags of a regular expression: the flags are letters, and no name character follows them"))
        : l1;
    return crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KRegex{sigils, lit}), start, flags_end);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> Finish::cycle() const {
    const auto& l = this->l;
    const auto& sigils = this->sigils;
    const auto& start = this->start;
    const auto& pattern = this->pattern;
    const auto& at_ = this->at_;
    const auto& replacement_opt = this->replacement_opt;
    const auto& replacement_at = this->replacement_at;
    const auto& flags_at = this->flags_at;
    auto src = l.src;
    auto flags_end = letters_end(src, flags_at);
    auto lit = crate::syntax::RegexLit{.pattern = pattern, .pattern_at = at_, .replacement = replacement_opt, .replacement_at = replacement_at, .flags = crate::syntax::lexer::chars::between(src, flags_at, flags_end), .flags_at = flags_at};
    auto tail = ident_end(src, flags_end);
    auto l1 = ({
        crate::syntax::lexer::Lex this_ = l;
        this_.pos = tail;
        this_;
    });
    auto l2 = tail > flags_end
        ? crate::syntax::lexer::chars::lex_err(l1, flags_end, tail, prism_rtl::cat("`", crate::syntax::lexer::chars::between(src, flags_end, tail), "` touches the flags of a regular expression: the flags are letters, and no name character follows them"))
        : l1;
    return prism_rtl::finished(crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KRegex{sigils, lit}), start, flags_end));
}


/// `Start Finish, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_finish(crate::syntax::lexer::Lex l, Text sigils, Nat start, Text pattern, Nat at_, std::optional<Text> replacement_opt, Nat replacement_at, Nat flags_at) {
    return prism_rtl::make_rc<Finish>(l, sigils, start, pattern, at_, replacement_opt, replacement_at, flags_at);
}


/// Unclosed: unbounded fn Lex, Text, Nat, Text, Nat, ?Text, Text, Text -> Lex
crate::syntax::lexer::Lex unclosed(const crate::syntax::lexer::Lex& l, const Text& sigils, const Nat& start, const Text& pattern, const Nat& at_, const std::optional<Text>& replacement_opt, const Text& what, const Text& close) {
    auto end = line_end_at(l.src, at_);
    auto lit_1 = crate::syntax::RegexLit{.pattern = pattern, .pattern_at = at_, .replacement = replacement_opt, .replacement_at = at_, .flags = Text::lit(""), .flags_at = end};
    auto l1 = ({
        crate::syntax::lexer::Lex this_ = l;
        this_.pos = end;
        this_;
    });
    auto l2 = crate::syntax::lexer::chars::lex_err(l1, start, end, prism_rtl::cat("a regular expression ends on its line: close its ", what, " with `", close, "`"));
    return crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KRegex{sigils, lit_1}), start, end);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> Unclosed::cycle() const {
    const auto& l = this->l;
    const auto& sigils = this->sigils;
    const auto& start = this->start;
    const auto& pattern = this->pattern;
    const auto& at_ = this->at_;
    const auto& replacement_opt = this->replacement_opt;
    const auto& what = this->what;
    const auto& close = this->close;
    auto end = line_end_at(l.src, at_);
    auto lit_1 = crate::syntax::RegexLit{.pattern = pattern, .pattern_at = at_, .replacement = replacement_opt, .replacement_at = at_, .flags = Text::lit(""), .flags_at = end};
    auto l1 = ({
        crate::syntax::lexer::Lex this_ = l;
        this_.pos = end;
        this_;
    });
    auto l2 = crate::syntax::lexer::chars::lex_err(l1, start, end, prism_rtl::cat("a regular expression ends on its line: close its ", what, " with `", close, "`"));
    return prism_rtl::finished(crate::syntax::lexer::push_tok(l2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KRegex{sigils, lit_1}), start, end));
}


/// `Start Unclosed, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_unclosed(crate::syntax::lexer::Lex l, Text sigils, Nat start, Text pattern, Nat at_, std::optional<Text> replacement_opt, Text what, Text close) {
    return prism_rtl::make_rc<Unclosed>(l, sigils, start, pattern, at_, replacement_opt, what, close);
}


/// ?PlainEnd: fn Text, Nat -> ?Nat
std::optional<Nat> plain_end(const Text& src, const Nat& at_) {
    auto&& _m = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("(?:[^\\/\\\\\\n]|\\\\[^\\n])*\\/", ""); return r; }()), src, at_);
    {
        auto&& e = _m;
        if (e > at_) {
            return e.checked_sub(Nat(1u));
        }
    }
    {
        return std::optional<Nat>{};
    }
}


/// ?HashedEnd: unbounded fn Text, Nat, Text -> ?Nat
std::optional<Nat> hashed_end(const Text& src, const Nat& at_, const Text& close) {
    auto&& _found_opt = ({
        std::tuple<std::optional<Nat>, Nat, bool> this_ = std::tuple{std::optional<Nat>{}, at_, true};
        Nat i = at_;
        bool going = true;
        std::optional<Nat> found_opt = std::optional<Nat>{};
        while (going) {
            auto c = crate::syntax::lexer::chars::char_at_byte(src, i);
            if ((c == Text::lit("")) || (c == Text::lit("\n"))) {
                going = false;
            } else if ((c == Text::lit("/")) && crate::syntax::lexer::chars::has_prefix(text_from(src, i), close)) {
                found_opt = std::optional(i);
                going = false;
            } else  {
                i = i + len_text(c);
            }
        }
        this_ = std::tuple{found_opt, i, going};
        this_;
    });
    auto&& found_opt = std::get<0>(_found_opt);
    return found_opt;
}


prism_rtl::Turn<std::optional<Nat>> HashedEnd::cycle() const {
    const auto& src = this->src;
    const auto& at_ = this->at_;
    const auto& close = this->close;
    std::tuple<std::optional<Nat>, Nat, bool> this_ = std::tuple{std::optional<Nat>{}, at_, true};
    Nat i = at_;
    bool going = true;
    std::optional<Nat> found_opt = std::optional<Nat>{};
    auto at__1 = at_;
    return call_then(loop_job(std::tuple{found_opt, this_, going, i}, ({
        auto close_2 = close;
        auto src_3 = src;
        [=](std::tuple<std::optional<Nat>, std::tuple<std::optional<Nat>, Nat, bool>, bool, Nat> _p0) {
        auto found_opt = std::get<0>(_p0);
        auto this_ = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto i = std::get<3>(_p0);
        return going
            ? ({
            auto c = crate::syntax::lexer::chars::char_at_byte(src_3, i);
            if ((c == Text::lit("")) || (c == Text::lit("\n"))) {
                going = false;
            } else if ((c == Text::lit("/")) && crate::syntax::lexer::chars::has_prefix(text_from(src_3, i), close_2)) {
                found_opt = std::optional(i);
                going = false;
            } else  {
                i = i + len_text(c);
            }
            Expected<std::tuple<std::optional<Nat>, std::tuple<std::optional<Nat>, Nat, bool>, bool, Nat>, std::tuple<std::optional<Nat>, std::tuple<std::optional<Nat>, Nat, bool>, bool, Nat>>(std::tuple{found_opt, this_, going, i});
        })
            : Expected<std::tuple<std::optional<Nat>, std::tuple<std::optional<Nat>, Nat, bool>, bool, Nat>, std::tuple<std::optional<Nat>, std::tuple<std::optional<Nat>, Nat, bool>, bool, Nat>>(unexpected(std::tuple{found_opt, this_, going, i}));
    };
    })), [=](std::tuple<std::optional<Nat>, std::tuple<std::optional<Nat>, Nat, bool>, bool, Nat> _p0) {
        auto found_opt = std::get<0>(_p0);
        auto this_ = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto i = std::get<3>(_p0);
        return ({
            this_ = std::tuple{found_opt, i, going};
            auto&& _found_opt = this_;
            auto&& found_opt = std::get<0>(_found_opt);
            (prism_rtl::finished(found_opt));
        });
    });
}


/// `Start HashedEnd, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Nat>> start_hashed_end(Text src, Nat at_, Text close) {
    return prism_rtl::make_rc<HashedEnd>(src, at_, close);
}


/// HashesEnd: fn Text, Nat -> Nat
Nat hashes_end(const Text& src, const Nat& at_) {
    return crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("#*", ""); return r; }()), src, at_);
}


/// LettersEnd: fn Text, Nat -> Nat
Nat letters_end(const Text& src, const Nat& at_) {
    return crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[A-Za-z]*", ""); return r; }()), src, at_);
}


/// IdentEnd: fn Text, Nat -> Nat
Nat ident_end(const Text& src, const Nat& at_) {
    return crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[A-Za-z0-9_]*", ""); return r; }()), src, at_);
}


/// LineEndAt: fn Text, Nat -> Nat
Nat line_end_at(const Text& src, const Nat& at_) {
    return crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[^\\n]*", ""); return r; }()), src, at_);
}


/// TextFrom: fn Text, Nat -> Text
Text text_from(const Text& src, const Nat& at_) {
    auto&& _m = cursor_at(src, at_);
    if (prism_rtl::is_some(_m)) {
        auto&& c = prism_rtl::some_of(_m);
        return after(c);
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}

}  // namespace crate::syntax::lexer::regexes


// The module `Syntax.Lexer.Templates`, from `target/bootstrap/cpp-src/prismc/syntax/lexer/templates.prism`.
namespace crate::syntax::lexer::templates {

void CallRead::show(Printer& p) const {
    p.record("CallRead", {{"l", l}, {"attrs", attrs}, {"body", body}, {"going", going}});
}

Pod CallRead::to_pod() const {
    return Pod::record("CallRead", {{"l", prism_rtl::to_pod(l)}, {"attrs", prism_rtl::to_pod(attrs)}, {"body", prism_rtl::to_pod(body)}, {"going", prism_rtl::to_pod(going)}});
}

Result<CallRead> CallRead::from_pod(const Pod& whole) {
    return CallRead{.l = TRY(prism_rtl::from_pod<crate::syntax::lexer::Lex>(TRY(crate::prelude::field(whole, "l")))), .attrs = TRY(prism_rtl::from_pod<Array<crate::syntax::lexer::AttrTok>>(TRY(crate::prelude::field(whole, "attrs")))), .body = TRY(prism_rtl::from_pod<std::optional<Array<crate::syntax::lexer::TPartTok>>>(TRY(crate::prelude::field(whole, "body")))), .going = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "going"))))};
}


void RawItem::show(Printer& p) const {
    if (auto c = std::get_if<RiText>(&cases())) p.choice("RiText", {c->a0});
    else if (auto c = std::get_if<RiPlaceholder>(&cases())) p.choice("RiPlaceholder", {c->a0, c->a1});
    else if (auto c = std::get_if<RiBlock>(&cases())) p.choice("RiBlock", {c->a0, c->a1});
    else if (auto c = std::get_if<RiCall>(&cases())) p.choice("RiCall", {c->a0, c->a1, c->a2, c->a3});
}

Pod RawItem::to_pod() const {
    return std::holds_alternative<RiText>(cases()) ? Pod::choice("RiText", {prism_rtl::to_pod(std::get<RiText>(cases()).a0)})
        : std::holds_alternative<RiPlaceholder>(cases()) ? Pod::choice("RiPlaceholder", {prism_rtl::to_pod(std::get<RiPlaceholder>(cases()).a0), prism_rtl::to_pod(std::get<RiPlaceholder>(cases()).a1)})
        : std::holds_alternative<RiBlock>(cases()) ? Pod::choice("RiBlock", {prism_rtl::to_pod(std::get<RiBlock>(cases()).a0), prism_rtl::to_pod(std::get<RiBlock>(cases()).a1)})
        : std::holds_alternative<RiCall>(cases()) ? Pod::choice("RiCall", {prism_rtl::to_pod(std::get<RiCall>(cases()).a0), prism_rtl::to_pod(std::get<RiCall>(cases()).a1), prism_rtl::to_pod(std::get<RiCall>(cases()).a2), prism_rtl::to_pod(std::get<RiCall>(cases()).a3)})
        : Pod();
}

Result<RawItem> RawItem::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "RiText" && c->args.size() == 1) return RawItem(RiText{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "RiPlaceholder" && c->args.size() == 2) return RawItem(RiPlaceholder{TRY(prism_rtl::from_pod<Array<crate::syntax::lexer::Tok>>(c->args[0])), TRY(prism_rtl::from_pod<crate::syntax::Range>(c->args[1]))});
        if (c->ctor == "RiBlock" && c->args.size() == 2) return RawItem(RiBlock{TRY(prism_rtl::from_pod<Array<crate::syntax::lexer::Tok>>(c->args[0])), TRY(prism_rtl::from_pod<crate::syntax::Range>(c->args[1]))});
        if (c->ctor == "RiCall" && c->args.size() == 4) return RawItem(RiCall{TRY(prism_rtl::from_pod<crate::syntax::lexer::NameTok>(c->args[0])), TRY(prism_rtl::from_pod<Array<crate::syntax::lexer::AttrTok>>(c->args[1])), TRY(prism_rtl::from_pod<std::optional<Array<crate::syntax::lexer::TPartTok>>>(c->args[2])), TRY(prism_rtl::from_pod<crate::syntax::Range>(c->args[3]))});
    }
    return mismatch<RawItem>("a RawItem", p);
}


void RawLine::show(Printer& p) const {
    p.record("RawLine", {{"items", items}, {"newline", newline}, {"block", block}});
}

Pod RawLine::to_pod() const {
    return Pod::record("RawLine", {{"items", prism_rtl::to_pod(items)}, {"newline", prism_rtl::to_pod(newline)}, {"block", prism_rtl::to_pod(block)}});
}

Result<RawLine> RawLine::from_pod(const Pod& whole) {
    return RawLine{.items = TRY(prism_rtl::from_pod<Array<RawItem>>(TRY(crate::prelude::field(whole, "items")))), .newline = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "newline")))), .block = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "block"))))};
}


void TplHow::show(Printer& p) const {
    p.record("TplHow", {{"close", close}, {"delims", delims}, {"open", open}, {"is_raw", is_raw}, {"first_continues", first_continues}});
}

Pod TplHow::to_pod() const {
    return Pod::record("TplHow", {{"close", prism_rtl::to_pod(close)}, {"delims", prism_rtl::to_pod(delims)}, {"open", prism_rtl::to_pod(open)}, {"is_raw", prism_rtl::to_pod(is_raw)}, {"first_continues", prism_rtl::to_pod(first_continues)}});
}

Result<TplHow> TplHow::from_pod(const Pod& whole) {
    return TplHow{.close = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "close")))), .delims = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "delims")))), .open = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "open")))), .is_raw = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "is_raw")))), .first_continues = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "first_continues"))))};
}


void TplRead::show(Printer& p) const {
    p.record("TplRead", {{"l", l}, {"lines", lines}, {"cur", cur}, {"closing_col", closing_col}, {"closed", closed}, {"at_line_start", at_line_start}, {"going", going}});
}

Pod TplRead::to_pod() const {
    return Pod::record("TplRead", {{"l", prism_rtl::to_pod(l)}, {"lines", prism_rtl::to_pod(lines)}, {"cur", prism_rtl::to_pod(cur)}, {"closing_col", prism_rtl::to_pod(closing_col)}, {"closed", prism_rtl::to_pod(closed)}, {"at_line_start", prism_rtl::to_pod(at_line_start)}, {"going", prism_rtl::to_pod(going)}});
}

Result<TplRead> TplRead::from_pod(const Pod& whole) {
    return TplRead{.l = TRY(prism_rtl::from_pod<crate::syntax::lexer::Lex>(TRY(crate::prelude::field(whole, "l")))), .lines = TRY(prism_rtl::from_pod<Array<RawLine>>(TRY(crate::prelude::field(whole, "lines")))), .cur = TRY(prism_rtl::from_pod<RawLine>(TRY(crate::prelude::field(whole, "cur")))), .closing_col = TRY(prism_rtl::from_pod<std::optional<Nat>>(TRY(crate::prelude::field(whole, "closing_col")))), .closed = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "closed")))), .at_line_start = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "at_line_start")))), .going = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "going"))))};
}


/// MaybeTemplate: unbounded fn Lex, Text -> Lex
crate::syntax::lexer::Lex maybe_template(const crate::syntax::lexer::Lex& l0, const Text& kw) {
    auto l = ({
        crate::syntax::lexer::Lex this_ = l0;
        this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit(" *", ""); return r; }()), this_.src, this_.pos);
        this_;
    });
    return (crate::syntax::lexer::chars::peek(l) == Text::lit("<")) && (template_tag_ahead(l) != Text::lit(""))
        ? ({
        auto keyword = kw == Text::lit("output")
            ? Text::lit("Output")
            : kw == Text::lit("inline_text") ? Text::lit("InlineText") : Text::lit("Raw");
        auto [kind, l2] = lex_template(l, keyword, l.pos);
        auto l3 = ({
            crate::syntax::lexer::Lex this_ = l2;
            this_.last_ws = true;
            this_;
        });
        (crate::syntax::lexer::push_tok(l3, kind, l.pos, l3.pos));
    })
        : crate::syntax::lexer::chars::lex_err(l0, l0.pos, l0.pos, prism_rtl::cat("`", kw, "` is followed by a language tag, `<rust>`"));
}


prism_rtl::Turn<crate::syntax::lexer::Lex> MaybeTemplate::cycle() const {
    const auto& l0 = this->l0;
    const auto& kw = this->kw;
    auto l = ({
        crate::syntax::lexer::Lex this_ = l0;
        this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit(" *", ""); return r; }()), this_.src, this_.pos);
        this_;
    });
    return (crate::syntax::lexer::chars::peek(l) == Text::lit("<")) && (template_tag_ahead(l) != Text::lit(""))
        ? ({
        auto keyword = kw == Text::lit("output")
            ? Text::lit("Output")
            : kw == Text::lit("inline_text") ? Text::lit("InlineText") : Text::lit("Raw");
        call_then(start_lex_template(l, keyword, l.pos), [=](std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> lex_template_1019) {
        return ({
            auto [kind, l2] = lex_template_1019;
            auto l3 = ({
                crate::syntax::lexer::Lex this_ = l2;
                this_.last_ws = true;
                this_;
            });
            (prism_rtl::finished(crate::syntax::lexer::push_tok(l3, kind, l.pos, l3.pos)));
        });
    });
    })
        : prism_rtl::finished(crate::syntax::lexer::chars::lex_err(l0, l0.pos, l0.pos, prism_rtl::cat("`", kw, "` is followed by a language tag, `<rust>`")));
}


/// `Start MaybeTemplate, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_maybe_template(crate::syntax::lexer::Lex l0, Text kw) {
    return prism_rtl::make_rc<MaybeTemplate>(l0, kw);
}


/// TemplateTagAhead: unbounded fn Lex -> Text
Text template_tag_ahead(const crate::syntax::lexer::Lex& l) {
    auto&& _name = crate::syntax::lexer::words::lex_ident(crate::syntax::lexer::chars::bump(l));
    auto&& name = std::get<0>(_name);
    auto after_ = crate::syntax::lexer::chars::peek_at(l, len_text(name) + Nat(1u));
    return (((crate::syntax::lexer::chars::peek(l) == Text::lit("<")) && (name != Text::lit(""))) && crate::syntax::lexer::chars::is_lower(crate::syntax::lexer::chars::head(name))) && (after_ == Text::lit(">"))
        ? name
        : Text::lit("");
}


prism_rtl::Turn<Text> TemplateTagAhead::cycle() const {
    const auto& l = this->l;
    auto l_1 = l;
    return call_then(crate::syntax::lexer::words::start_lex_ident(crate::syntax::lexer::chars::bump(l_1)), [=](std::tuple<Text, crate::syntax::lexer::Lex> lex_ident_1410) {
        return ({
            auto&& _name = lex_ident_1410;
            auto&& name = std::get<0>(_name);
            auto after_ = crate::syntax::lexer::chars::peek_at(l_1, len_text(name) + Nat(1u));
            (((crate::syntax::lexer::chars::peek(l_1) == Text::lit("<")) && (name != Text::lit(""))) && crate::syntax::lexer::chars::is_lower(crate::syntax::lexer::chars::head(name))) && (after_ == Text::lit(">"))
            ? prism_rtl::finished(name)
            : prism_rtl::finished(Text::lit(""));
        });
    });
}


/// `Start TemplateTagAhead, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_template_tag_ahead(crate::syntax::lexer::Lex l) {
    return prism_rtl::make_rc<TemplateTagAhead>(l);
}


/// LexTemplate: unbounded fn Lex, Text, Nat -> ((TokKind, Lex))
std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> lex_template(const crate::syntax::lexer::Lex& l0, const Text& keyword, const Nat& start) {
    auto lang = template_tag_ahead(l0);
    auto l1 = crate::syntax::lexer::chars::forward(l0, len_text(lang) + Nat(2u));
    auto delims = (lang == Text::lit("markdown")) || (lang == Text::lit("html"))
        ? Text::lit("single")
        : Text::lit("double");
    auto ends_line = (crate::syntax::lexer::chars::peek(l1) == Text::lit("\n")) || crate::syntax::lexer::chars::starts_with(l1, Text::lit("\r\n"));
    auto skip = crate::syntax::lexer::chars::peek(l1) == Text::lit("\r")
        ? Nat(2u)
        : Nat(1u);
    auto l2 = ends_line ? crate::syntax::lexer::chars::forward(l1, skip) : l1;
    auto [parts, l3] = template_body(l2, prism_rtl::cat("</", lang, ">"), delims, keyword == Text::lit("Raw"), !ends_line, start);
    auto kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KTemplate{crate::syntax::lexer::TemplateTok{.keyword = keyword, .lang = lang, .delims = delims, .parts = parts}});
    return std::tuple{kind, l3};
}


prism_rtl::Turn<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> LexTemplate::cycle() const {
    const auto& l0 = this->l0;
    const auto& keyword = this->keyword;
    const auto& start = this->start;
    auto keyword_1 = keyword;
    auto l0_2 = l0;
    auto start_3 = start;
    return call_then(start_template_tag_ahead(l0_2), [=](Text template_tag_ahead_1743) {
        return ({
            auto lang = template_tag_ahead_1743;
            auto l1 = crate::syntax::lexer::chars::forward(l0_2, len_text(lang) + Nat(2u));
            auto delims = (lang == Text::lit("markdown")) || (lang == Text::lit("html"))
                ? Text::lit("single")
                : Text::lit("double");
            auto ends_line = (crate::syntax::lexer::chars::peek(l1) == Text::lit("\n")) || crate::syntax::lexer::chars::starts_with(l1, Text::lit("\r\n"));
            auto skip = crate::syntax::lexer::chars::peek(l1) == Text::lit("\r")
                ? Nat(2u)
                : Nat(1u);
            auto l2 = ends_line ? crate::syntax::lexer::chars::forward(l1, skip) : l1;
            call_then(start_template_body(l2, prism_rtl::cat("</", lang, ">"), delims, keyword_1 == Text::lit("Raw"), !ends_line, start_3), [=](std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex> template_body_2157) {
            return ({
                auto [parts, l3] = template_body_2157;
                auto kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KTemplate{crate::syntax::lexer::TemplateTok{.keyword = keyword_1, .lang = lang, .delims = delims, .parts = parts}});
                (prism_rtl::finished(std::tuple{kind, l3}));
            });
        });
        });
    });
}


/// `Start LexTemplate, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> start_lex_template(crate::syntax::lexer::Lex l0, Text keyword, Nat start) {
    return prism_rtl::make_rc<LexTemplate>(l0, keyword, start);
}


/// let emptyLine
RawLine empty_line() {
    return RawLine{.items = Array<RawItem>{}, .newline = false, .block = false};
}


/// AddItem: fn RawLine, RawItem -> RawLine
RawLine add_item(const RawLine& line, const RawItem& item) {
    RawLine this_ = line;
    this_.items = add_raw(this_.items, item);
    return this_;
}


/// AddRaw: fn [RawItem], RawItem -> [RawItem]
Array<RawItem> add_raw(const Array<RawItem>& items, const RawItem& raw_item1) {
    if (prism_rtl::is<RawItem::RiText>(raw_item1)) {
        auto&& t = prism_rtl::as<RawItem::RiText>(raw_item1).a0;
        auto&& _m = crate::syntax::lexer::chars::last(items);
        if (prism_rtl::is_some(_m) && prism_rtl::is<RawItem::RiText>(prism_rtl::some_of(_m))) {
            auto&& s = prism_rtl::as<RawItem::RiText>(prism_rtl::some_of(_m)).a0;
            return crate::prelude::push(crate::syntax::lexer::chars::pop(items), RawItem(RawItem::RiText{prism_rtl::cat(s, t)}));
        }
        {
            return crate::prelude::push(items, RawItem(RawItem::RiText{t}));
        }
    }
    {
        auto&& item = raw_item1;
        return crate::prelude::push(items, item);
    }
}


/// OnlyWhitespace: fn RawLine -> Bool
bool only_whitespace(const RawLine& line) {
    return fold(line.items, true, [&](const bool& ok_, const RawItem& it) { return ok_ && is_blank_text(it); });
}


/// IsBlankText: fn RawItem -> Bool
bool is_blank_text(const RawItem& raw_item0) {
    if (prism_rtl::is<RawItem::RiText>(raw_item0)) {
        auto&& s = prism_rtl::as<RawItem::RiText>(raw_item0).a0;
        return crate::syntax::lexer::chars::all_chars(s, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text p0) {
            return once_job([=]() {
                return ({
                    auto c = p0;
                    (prism_rtl::finished((c == Text::lit(" ")) || (c == Text::lit("\r"))));
                });
            });
        })));
    }
    {
        return false;
    }
}


/// TextLen: fn RawLine -> Nat
Nat text_len(const RawLine& line) {
    return fold(line.items, Nat(0u), [&](const Nat& n, const RawItem& it) { return n + text_len_of(it); });
}


/// TextLenOf: fn RawItem -> Nat
Nat text_len_of(const RawItem& raw_item0) {
    if (prism_rtl::is<RawItem::RiText>(raw_item0)) {
        auto&& s = prism_rtl::as<RawItem::RiText>(raw_item0).a0;
        return len_text(s);
    }
    {
        return Nat(0u);
    }
}


/// TemplateBody: unbounded fn Lex, Text, Text, Bool, Bool, Nat -> (([TPartTok], Lex))
std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex> template_body(const crate::syntax::lexer::Lex& l0, const Text& close, const Text& delims, const bool& is_raw, const bool& first_continues, const Nat& open_start) {
    auto open = delims == Text::lit("double") ? Text::lit("{{") : Text::lit("{");
    auto how = TplHow{.close = close, .delims = delims, .open = open, .is_raw = is_raw, .first_continues = first_continues};
    auto start = TplRead{.l = l0, .lines = Array<RawLine>{}, .cur = empty_line(), .closing_col = std::optional<Nat>{}, .closed = false, .at_line_start = !first_continues, .going = true};
    auto r = ({
        TplRead this_ = start;
        while (this_.going) {
            this_ = template_step(this_, how);
        }
        this_;
    });
    auto l1 = r.closed
        ? r.l
        : crate::syntax::lexer::chars::lex_err(r.l, open_start, r.l.pos, prism_rtl::cat("a template never closes: expected `", close, "`"));
    return finish_template_lines(l1, crate::prelude::push(r.lines, r.cur), or_(r.closing_col, Nat(0u)), first_continues);
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex>> TemplateBody::cycle() const {
    const auto& l0 = this->l0;
    const auto& close = this->close;
    const auto& delims = this->delims;
    const auto& is_raw = this->is_raw;
    const auto& first_continues = this->first_continues;
    const auto& open_start = this->open_start;
    auto open = delims == Text::lit("double") ? Text::lit("{{") : Text::lit("{");
    auto how = TplHow{.close = close, .delims = delims, .open = open, .is_raw = is_raw, .first_continues = first_continues};
    auto start = TplRead{.l = l0, .lines = Array<RawLine>{}, .cur = empty_line(), .closing_col = std::optional<Nat>{}, .closed = false, .at_line_start = !first_continues, .going = true};
    TplRead this_ = start;
    auto close_1 = close;
    auto first_continues_2 = first_continues;
    auto open_start_3 = open_start;
    return call_then(loop_job(std::tuple{this_}, ({
        auto how_4 = how;
        [=](std::tuple<TplRead> _p0) {
        auto this_ = std::get<0>(_p0);
        return this_.going
            ? ({
            this_ = template_step(this_, how_4);
            Expected<std::tuple<TplRead>, std::tuple<TplRead>>(std::tuple{this_});
        })
            : Expected<std::tuple<TplRead>, std::tuple<TplRead>>(unexpected(std::tuple{this_}));
    };
    })), [=](std::tuple<TplRead> _p0) {
        auto this_ = std::get<0>(_p0);
        return ({
            auto r = this_;
            auto l1 = r.closed
                ? r.l
                : crate::syntax::lexer::chars::lex_err(r.l, open_start_3, r.l.pos, prism_rtl::cat("a template never closes: expected `", close_1, "`"));
            (prism_rtl::finished(finish_template_lines(l1, crate::prelude::push(r.lines, r.cur), or_(r.closing_col, Nat(0u)), first_continues_2)));
        });
    });
}


/// `Start TemplateBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex>> start_template_body(crate::syntax::lexer::Lex l0, Text close, Text delims, bool is_raw, bool first_continues, Nat open_start) {
    return prism_rtl::make_rc<TemplateBody>(l0, close, delims, is_raw, first_continues, open_start);
}


/// TemplateStep: unbounded fn TplRead, TplHow -> TplRead
TplRead template_step(const TplRead& s, const TplHow& how) {
    auto c = crate::syntax::lexer::chars::peek(s.l);
    return (s.at_line_start && (!how.is_raw)) && (crate::syntax::lexer::chars::trim(crate::syntax::lexer::chars::rest_of_line(s.l)) == how.open)
        ? brace_block_line(s, crate::syntax::lexer::chars::rest_of_line(s.l), how)
        : crate::syntax::lexer::chars::starts_with(s.l, how.close)
        ? close_template(s, how)
        : c == Text::lit("")
        ? ({
        TplRead this_ = s;
        this_.at_line_start = false;
        this_.going = false;
        this_;
    })
        : c == Text::lit("\n")
        ? ({
        TplRead this_ = s;
        this_.l = crate::syntax::lexer::chars::bump(this_.l);
        this_.cur.newline = true;
        this_.lines = crate::prelude::push(this_.lines, this_.cur);
        this_.cur = empty_line();
        this_.at_line_start = true;
        this_;
    })
        : ({
        auto [item, l2] = template_item(s.l, how);
        ({
        TplRead this_ = s;
        this_.at_line_start = false;
        this_.l = l2;
        this_.cur = add_item(this_.cur, item);
        this_;
    });
    });
}


prism_rtl::Turn<TplRead> TemplateStep::cycle() const {
    const auto& s = this->s;
    const auto& how = this->how;
    auto c = crate::syntax::lexer::chars::peek(s.l);
    return (s.at_line_start && (!how.is_raw)) && (crate::syntax::lexer::chars::trim(crate::syntax::lexer::chars::rest_of_line(s.l)) == how.open)
        ? ({
        auto how_1 = how;
        auto s_2 = s;
        call_then(crate::syntax::lexer::chars::start_rest_of_line(s_2.l), [=](Text rest_of_line_5173) { return prism_rtl::more(prism_rtl::rc(BraceBlockLine(s_2, rest_of_line_5173, how_1))); });
    })
        : crate::syntax::lexer::chars::starts_with(s.l, how.close)
        ? prism_rtl::finished(close_template(s, how))
        : c == Text::lit("")
        ? prism_rtl::finished(({
        TplRead this_ = s;
        this_.at_line_start = false;
        this_.going = false;
        this_;
    }))
        : c == Text::lit("\n")
        ? prism_rtl::finished(({
        TplRead this_ = s;
        this_.l = crate::syntax::lexer::chars::bump(this_.l);
        this_.cur.newline = true;
        this_.lines = crate::prelude::push(this_.lines, this_.cur);
        this_.cur = empty_line();
        this_.at_line_start = true;
        this_;
    }))
        : ({
        auto how_1 = how;
        auto s_2 = s;
        call_then(start_template_item(s_2.l, how_1), [=](std::tuple<RawItem, crate::syntax::lexer::Lex> template_item_5618) {
        return ({
            auto [item, l2] = template_item_5618;
            (prism_rtl::finished(({
            TplRead this_ = s_2;
            this_.at_line_start = false;
            this_.l = l2;
            this_.cur = add_item(this_.cur, item);
            this_;
        })));
        });
    });
    });
}


/// `Start TemplateStep, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<TplRead> start_template_step(TplRead s, TplHow how) {
    return prism_rtl::make_rc<TemplateStep>(s, how);
}


/// BraceBlockLine: unbounded fn TplRead, Text, TplHow -> TplRead
TplRead brace_block_line(const TplRead& s, const Text& rest, const TplHow& how) {
    auto bs = s.l.pos;
    auto past = crate::syntax::lexer::chars::forward(s.l, len_text(rest));
    auto at_ = crate::syntax::lexer::chars::peek(past) == Text::lit("\n")
        ? crate::syntax::lexer::chars::bump(past)
        : past;
    auto [toks, l2] = crate::syntax::lexer::layout::nested(at_, crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MBrace{how.delims}));
    auto line = RawLine{.items = Array(std::vector{RawItem(RawItem::RiBlock{toks, crate::syntax::Range{.start = bs, .end = l2.pos}})}), .newline = false, .block = true};
    TplRead this_ = s;
    this_.lines = crate::prelude::push(this_.lines, line);
    this_.l = l2;
    return this_;
}


prism_rtl::Turn<TplRead> BraceBlockLine::cycle() const {
    const auto& s = this->s;
    const auto& rest = this->rest;
    const auto& how = this->how;
    auto bs = s.l.pos;
    auto past = crate::syntax::lexer::chars::forward(s.l, len_text(rest));
    auto at_ = crate::syntax::lexer::chars::peek(past) == Text::lit("\n")
        ? crate::syntax::lexer::chars::bump(past)
        : past;
    auto how_1 = how;
    auto s_2 = s;
    return call_then(crate::syntax::lexer::layout::start_nested(at_, crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MBrace{how_1.delims})), [=](std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex> nested_5996) {
        return ({
            auto [toks, l2] = nested_5996;
            auto line = RawLine{.items = Array(std::vector{RawItem(RawItem::RiBlock{toks, crate::syntax::Range{.start = bs, .end = l2.pos}})}), .newline = false, .block = true};
            (prism_rtl::finished(({
            TplRead this_ = s_2;
            this_.lines = crate::prelude::push(this_.lines, line);
            this_.l = l2;
            this_;
        })));
        });
    });
}


/// `Start BraceBlockLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<TplRead> start_brace_block_line(TplRead s, Text rest, TplHow how) {
    return prism_rtl::make_rc<BraceBlockLine>(s, rest, how);
}


/// CloseTemplate: fn TplRead, TplHow -> TplRead
TplRead close_template(const TplRead& s, const TplHow& how) {
    TplRead this_ = s;
    this_.at_line_start = false;
    if (only_whitespace(this_.cur) && ((len(this_.lines) > Nat(0u)) || (!how.first_continues))) {
        this_.closing_col = std::optional(text_len(this_.cur));
        this_.cur.items = Array<RawItem>{};
    }
    this_.l = crate::syntax::lexer::chars::forward(this_.l, len_text(how.close));
    this_.closed = true;
    this_.going = false;
    return this_;
}


/// TemplateItem: unbounded fn Lex, TplHow -> ((RawItem, Lex))
std::tuple<RawItem, crate::syntax::lexer::Lex> template_item(const crate::syntax::lexer::Lex& l, const TplHow& how) {
    auto live = !how.is_raw;
    return (live && (how.delims == Text::lit("double"))) && crate::syntax::lexer::chars::starts_with(l, Text::lit("\\{{"))
        ? std::tuple{RawItem(RawItem::RiText{Text::lit("{{")}), crate::syntax::lexer::chars::forward(l, Nat(3u))}
        : (live && (how.delims == Text::lit("single"))) && crate::syntax::lexer::chars::starts_with(l, Text::lit("\\{"))
        ? std::tuple{RawItem(RawItem::RiText{Text::lit("{")}), crate::syntax::lexer::chars::forward(l, Nat(2u))}
        : live && crate::syntax::lexer::chars::starts_with(l, how.open)
        ? ({
        auto ps = l.pos;
        auto [toks, l2] = crate::syntax::lexer::layout::nested(crate::syntax::lexer::chars::forward(l, len_text(how.open)), crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MPlaceholder{how.delims}));
        auto item = RawItem(RawItem::RiPlaceholder{toks, crate::syntax::Range{.start = ps, .end = l2.pos}});
        std::tuple{item, l2};
    })
        : (live && crate::syntax::lexer::chars::starts_with(l, Text::lit("<@"))) && crate::syntax::lexer::chars::is_upper(crate::syntax::lexer::chars::peek_at(l, Nat(2u)))
        ? template_call(l, how.delims, how.open)
        : ({
        auto run_ = crate::syntax::lexer::chars::match_here(([]() -> const Regex& { static const Regex r = Regex::lit("[^\\\\{<\\n]+", ""); return r; }()), l);
        auto n = run_ == Text::lit("")
            ? len_text(crate::syntax::lexer::chars::peek(l))
            : len_text(run_);
        auto l2 = ({
            crate::syntax::lexer::Lex this_ = l;
            this_.pos = this_.pos + n;
            this_;
        });
        std::tuple{RawItem(RawItem::RiText{crate::syntax::lexer::chars::slice(l, l.pos, l2.pos)}), l2};
    });
}


prism_rtl::Turn<std::tuple<RawItem, crate::syntax::lexer::Lex>> TemplateItem::cycle() const {
    const auto& l = this->l;
    const auto& how = this->how;
    auto live = !how.is_raw;
    return (live && (how.delims == Text::lit("double"))) && crate::syntax::lexer::chars::starts_with(l, Text::lit("\\{{"))
        ? prism_rtl::finished(std::tuple{RawItem(RawItem::RiText{Text::lit("{{")}), crate::syntax::lexer::chars::forward(l, Nat(3u))})
        : (live && (how.delims == Text::lit("single"))) && crate::syntax::lexer::chars::starts_with(l, Text::lit("\\{"))
        ? prism_rtl::finished(std::tuple{RawItem(RawItem::RiText{Text::lit("{")}), crate::syntax::lexer::chars::forward(l, Nat(2u))})
        : live && crate::syntax::lexer::chars::starts_with(l, how.open)
        ? ({
        auto ps = l.pos;
        auto how_1 = how;
        auto l_2 = l;
        call_then(crate::syntax::lexer::layout::start_nested(crate::syntax::lexer::chars::forward(l_2, len_text(how_1.open)), crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MPlaceholder{how_1.delims})), [=](std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex> nested_7242) {
        return ({
            auto [toks, l2] = nested_7242;
            auto item = RawItem(RawItem::RiPlaceholder{toks, crate::syntax::Range{.start = ps, .end = l2.pos}});
            (prism_rtl::finished(std::tuple{item, l2}));
        });
    });
    })
        : (live && crate::syntax::lexer::chars::starts_with(l, Text::lit("<@"))) && crate::syntax::lexer::chars::is_upper(crate::syntax::lexer::chars::peek_at(l, Nat(2u)))
        ? prism_rtl::more(prism_rtl::rc(TemplateCall(l, how.delims, how.open)))
        : ({
        auto run_ = crate::syntax::lexer::chars::match_here(([]() -> const Regex& { static const Regex r = Regex::lit("[^\\\\{<\\n]+", ""); return r; }()), l);
        auto n = run_ == Text::lit("")
            ? len_text(crate::syntax::lexer::chars::peek(l))
            : len_text(run_);
        auto l2 = ({
            crate::syntax::lexer::Lex this_ = l;
            this_.pos = this_.pos + n;
            this_;
        });
        (prism_rtl::finished(std::tuple{RawItem(RawItem::RiText{crate::syntax::lexer::chars::slice(l, l.pos, l2.pos)}), l2}));
    });
}


/// `Start TemplateItem, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<RawItem, crate::syntax::lexer::Lex>> start_template_item(crate::syntax::lexer::Lex l, TplHow how) {
    return prism_rtl::make_rc<TemplateItem>(l, how);
}


/// TemplateCall: unbounded fn Lex, Text, Text -> ((RawItem, Lex))
std::tuple<RawItem, crate::syntax::lexer::Lex> template_call(const crate::syntax::lexer::Lex& l0, const Text& delims, const Text& open) {
    auto start = l0.pos;
    auto&& _sigils = crate::syntax::lexer::words::read_sigils(crate::syntax::lexer::chars::bump(l0));
    auto&& sigils = std::get<0>(_sigils);
    auto&& l1 = std::get<2>(_sigils);
    auto [path_, l2] = crate::syntax::lexer::words::lex_qualified_path(l1);
    auto name = crate::syntax::lexer::NameTok{.sigils = sigils, .path_ = path_, .case_ = crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseUpper{})};
    auto close = prism_rtl::cat("</", sigils, crate::syntax::lexer::chars::join(path_, Text::lit(".")), ">");
    auto r = ({
        CallRead this_ = CallRead{.l = l2, .attrs = Array<crate::syntax::lexer::AttrTok>{}, .body = std::optional<Array<crate::syntax::lexer::TPartTok>>{}, .going = true};
        while (this_.going) {
            this_ = call_step(this_, start, close, delims, open);
        }
        this_;
    });
    auto item = RawItem(RawItem::RiCall{name, r.attrs, r.body, crate::syntax::Range{.start = start, .end = r.l.pos}});
    return std::tuple{item, r.l};
}


prism_rtl::Turn<std::tuple<RawItem, crate::syntax::lexer::Lex>> TemplateCall::cycle() const {
    const auto& l0 = this->l0;
    const auto& delims = this->delims;
    const auto& open = this->open;
    auto start = l0.pos;
    auto delims_1 = delims;
    auto l0_2 = l0;
    auto open_3 = open;
    return call_then(crate::syntax::lexer::words::start_read_sigils(crate::syntax::lexer::chars::bump(l0_2)), [=](std::tuple<Text, bool, crate::syntax::lexer::Lex> read_sigils_8234) {
        return ({
            auto&& _sigils = read_sigils_8234;
            auto&& sigils = std::get<0>(_sigils);
            auto&& l1 = std::get<2>(_sigils);
            call_then(crate::syntax::lexer::words::start_lex_qualified_path(l1), [=](std::tuple<Array<Text>, crate::syntax::lexer::Lex> lex_qualified_path_8278) {
            return ({
                auto [path_, l2] = lex_qualified_path_8278;
                auto name = crate::syntax::lexer::NameTok{.sigils = sigils, .path_ = path_, .case_ = crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseUpper{})};
                auto close = prism_rtl::cat("</", sigils, crate::syntax::lexer::chars::join(path_, Text::lit(".")), ">");
                CallRead this_ = CallRead{.l = l2, .attrs = Array<crate::syntax::lexer::AttrTok>{}, .body = std::optional<Array<crate::syntax::lexer::TPartTok>>{}, .going = true};
                auto name_4 = name;
                auto start_5 = start;
                call_then(loop_job(std::tuple{this_}, ({
                auto close_6 = close;
                auto delims_1_7 = delims_1;
                auto open_3_7 = open_3;
                auto start_5_7 = start_5;
                [=](std::tuple<CallRead> _p0) {
                auto this_ = std::get<0>(_p0);
                return this_.going
                    ? ({
                    this_ = call_step(this_, start_5_7, close_6, delims_1_7, open_3_7);
                    Expected<std::tuple<CallRead>, std::tuple<CallRead>>(std::tuple{this_});
                })
                    : Expected<std::tuple<CallRead>, std::tuple<CallRead>>(unexpected(std::tuple{this_}));
            };
            })), [=](std::tuple<CallRead> _p0) {
                auto this_ = std::get<0>(_p0);
                return ({
                    auto r = this_;
                    auto item = RawItem(RawItem::RiCall{name_4, r.attrs, r.body, crate::syntax::Range{.start = start_5, .end = r.l.pos}});
                    (prism_rtl::finished(std::tuple{item, r.l}));
                });
            });
            });
        });
        });
    });
}


/// `Start TemplateCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<RawItem, crate::syntax::lexer::Lex>> start_template_call(crate::syntax::lexer::Lex l0, Text delims, Text open) {
    return prism_rtl::make_rc<TemplateCall>(l0, delims, open);
}


/// CallStep: unbounded fn CallRead, Nat, Text, Text, Text -> CallRead
CallRead call_step(const CallRead& s0, const Nat& start, const Text& close, const Text& delims, const Text& open) {
    auto l = ({
        crate::syntax::lexer::Lex this_ = s0.l;
        this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[ \\n\\r]*", ""); return r; }()), this_.src, this_.pos);
        this_;
    });
    auto s = ({
        CallRead this_ = s0;
        this_.l = l;
        this_;
    });
    auto at_ = l.pos;
    return crate::syntax::lexer::chars::starts_with(l, Text::lit("/>"))
        ? ({
        CallRead this_ = s;
        this_.l = crate::syntax::lexer::chars::forward(l, Nat(2u));
        this_.going = false;
        this_;
    })
        : crate::syntax::lexer::chars::peek(l) == Text::lit(">")
        ? ({
        auto past = crate::syntax::lexer::chars::bump(l);
        auto continues = crate::syntax::lexer::chars::peek(past) != Text::lit("\n");
        auto from = continues ? past : crate::syntax::lexer::chars::bump(past);
        auto [parts, l3] = template_body(from, close, delims, false, continues, start);
        ({
        CallRead this_ = s;
        this_.body = std::optional(parts);
        this_.l = l3;
        this_.going = false;
        this_;
    });
    })
        : !crate::syntax::lexer::chars::is_ident_start(crate::syntax::lexer::chars::peek(l))
        ? ({
        CallRead this_ = s;
        this_.l = crate::syntax::lexer::chars::lex_err(l, at_, at_ + Nat(1u), Text::lit("expected an attribute `name=value`, `/>` or `>` in a template call"));
        this_.going = false;
        this_;
    })
        : ({
        auto [aname, l3] = crate::syntax::lexer::words::lex_ident(l);
        (crate::syntax::lexer::chars::peek(l3) != Text::lit("=")
        ? ({
        CallRead this_ = s;
        this_.l = crate::syntax::lexer::chars::lex_err(l3, at_, l3.pos, Text::lit("an attribute is `name=value`"));
        this_;
    })
        : ({
        auto [tokens, l4] = attr_value(crate::syntax::lexer::chars::bump(l3), delims, open);
        ({
        CallRead this_ = s;
        this_.attrs = crate::prelude::push(this_.attrs, crate::syntax::lexer::AttrTok{.name = aname, .tokens = tokens, .span = crate::syntax::Range{.start = at_, .end = l4.pos}});
        this_.l = l4;
        this_;
    });
    }));
    });
}


prism_rtl::Turn<CallRead> CallStep::cycle() const {
    const auto& s0 = this->s0;
    const auto& start = this->start;
    const auto& close = this->close;
    const auto& delims = this->delims;
    const auto& open = this->open;
    auto l = ({
        crate::syntax::lexer::Lex this_ = s0.l;
        this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[ \\n\\r]*", ""); return r; }()), this_.src, this_.pos);
        this_;
    });
    auto s = ({
        CallRead this_ = s0;
        this_.l = l;
        this_;
    });
    auto at_ = l.pos;
    return crate::syntax::lexer::chars::starts_with(l, Text::lit("/>"))
        ? prism_rtl::finished(({
        CallRead this_ = s;
        this_.l = crate::syntax::lexer::chars::forward(l, Nat(2u));
        this_.going = false;
        this_;
    }))
        : crate::syntax::lexer::chars::peek(l) == Text::lit(">")
        ? ({
        auto past = crate::syntax::lexer::chars::bump(l);
        auto continues = crate::syntax::lexer::chars::peek(past) != Text::lit("\n");
        auto from = continues ? past : crate::syntax::lexer::chars::bump(past);
        auto close_1 = close;
        auto delims_2 = delims;
        auto start_3 = start;
        call_then(start_template_body(from, close_1, delims_2, false, continues, start_3), [=](std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex> template_body_9198) {
        return ({
            auto [parts, l3] = template_body_9198;
            (prism_rtl::finished(({
            CallRead this_ = s;
            this_.body = std::optional(parts);
            this_.l = l3;
            this_.going = false;
            this_;
        })));
        });
    });
    })
        : !crate::syntax::lexer::chars::is_ident_start(crate::syntax::lexer::chars::peek(l))
        ? prism_rtl::finished(({
        CallRead this_ = s;
        this_.l = crate::syntax::lexer::chars::lex_err(l, at_, at_ + Nat(1u), Text::lit("expected an attribute `name=value`, `/>` or `>` in a template call"));
        this_.going = false;
        this_;
    }))
        : ({
        auto delims_1 = delims;
        auto open_2 = open;
        auto start_3 = start;
        call_then(crate::syntax::lexer::words::start_lex_ident(l), [=](std::tuple<Text, crate::syntax::lexer::Lex> lex_ident_9597) {
        return ({
            auto [aname, l3] = lex_ident_9597;
            (crate::syntax::lexer::chars::peek(l3) != Text::lit("=")
            ? prism_rtl::finished(({
            CallRead this_ = s;
            this_.l = crate::syntax::lexer::chars::lex_err(l3, at_, l3.pos, Text::lit("an attribute is `name=value`"));
            this_;
        }))
            : ({
            auto [tokens, l4] = attr_value(crate::syntax::lexer::chars::bump(l3), delims_1, open_2);
            (prism_rtl::finished(({
            CallRead this_ = s;
            this_.attrs = crate::prelude::push(this_.attrs, crate::syntax::lexer::AttrTok{.name = aname, .tokens = tokens, .span = crate::syntax::Range{.start = at_, .end = l4.pos}});
            this_.l = l4;
            this_;
        })));
        }));
        });
    });
    });
}


/// `Start CallStep, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<CallRead> start_call_step(CallRead s0, Nat start, Text close, Text delims, Text open) {
    return prism_rtl::make_rc<CallStep>(s0, start, close, delims, open);
}


/// AttrValue: unbounded fn Lex, Text, Text -> (([Tok], Lex))
std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex> attr_value(const crate::syntax::lexer::Lex& l, const Text& delims, const Text& open) {
    return crate::syntax::lexer::chars::starts_with(l, open)
        ? crate::syntax::lexer::layout::nested(crate::syntax::lexer::chars::forward(l, len_text(open)), crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MPlaceholder{delims}))
        : crate::syntax::lexer::chars::peek(l) == Text::lit("\"")
        ? ({
        auto [text_, l2] = crate::syntax::lexer::literals::lex_text(l);
        auto tok = crate::syntax::lexer::Tok{.kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KText{Text::lit(""), text_}), .span = crate::syntax::Range{.start = l.pos, .end = l2.pos}, .touches = false, .line_start = false};
        std::tuple{Array(std::vector{tok}), l2};
    })
        : std::tuple{Array<crate::syntax::lexer::Tok>{}, crate::syntax::lexer::chars::lex_err(l, l.pos, l.pos, prism_rtl::cat("an attribute\'s value is a placeholder `", open, "...` or a text literal"))};
}


/// FinishTemplateLines: fn Lex, [RawLine], Nat, Bool -> (([TPartTok], Lex))
std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex> finish_template_lines(const crate::syntax::lexer::Lex& l0, const Array<RawLine>& lines, const Nat& strip, const bool& first_continues) {
    std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex> this_ = std::tuple{Array<crate::syntax::lexer::TPartTok>{}, l0};
    crate::syntax::lexer::Lex l = l0;
    Array<crate::syntax::lexer::TPartTok> parts = Array<crate::syntax::lexer::TPartTok>{};
    for (auto&& [i10950, v10950] : prism_rtl::enumerate(lines)) {
        auto k10950 = nat_of(i10950);
        auto line = v10950;
        if (line.block) {
            parts = append(parts, block_parts(line.items));
        } else  {
            auto first_ = (k10950 == Nat(0u)) && first_continues;
            auto [items, l2] = (!first_) && (strip > Nat(0u))
                ? strip_line(line, strip, l)
                : std::tuple{line.items, l};
            l = l2;
            auto non_blank = fold(items, Array<RawItem>{}, [&](const Array<RawItem>& acc, const RawItem& it) { return is_blank_or_empty(it) ? acc : crate::prelude::push(acc, it); });
            auto alone = (((!first_) && line.newline) && (len(non_blank) == Nat(1u))) && is_placeholder_item(or_(index(non_blank, Nat(0u)), RawItem(RawItem::RiText{Text::lit("")})));
            if (alone) {
                parts = crate::prelude::push(parts, alone_placeholder(items));
            } else  {
                parts = fold(items, parts, push_part);
                if (line.newline) {
                    parts = push_part(parts, RawItem(RawItem::RiText{Text::lit("\n")}));
                }
            }
        }
    }
    this_ = std::tuple{parts, l};
    return this_;
}


/// BlockParts: fn [RawItem] -> [TPartTok]
Array<crate::syntax::lexer::TPartTok> block_parts(const Array<RawItem>& items) {
    return fold(items, Array<crate::syntax::lexer::TPartTok>{}, [&](const Array<crate::syntax::lexer::TPartTok>& acc, const RawItem& it) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::syntax::lexer::TPartTok>> _v;
            if (prism_rtl::is<RawItem::RiBlock>(it)) {
                auto&& tokens = prism_rtl::as<RawItem::RiBlock>(it).a0;
                auto&& span = prism_rtl::as<RawItem::RiBlock>(it).a1;
                _v.set(crate::prelude::push(acc, crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptBlock{tokens, span})));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// StripLine: fn RawLine, Nat, Lex -> (([RawItem], Lex))
std::tuple<Array<RawItem>, crate::syntax::lexer::Lex> strip_line(const RawLine& line, const Nat& strip, const crate::syntax::lexer::Lex& l) {
    auto blank = only_whitespace(line);
    auto n = ({
        __label__ _done;
        prism_rtl::Slot<Nat> _v;
        auto&& _m = index(line.items, Nat(0u));
        if (prism_rtl::is_some(_m) && prism_rtl::is<RawItem::RiText>(prism_rtl::some_of(_m))) {
            auto&& s = prism_rtl::as<RawItem::RiText>(prism_rtl::some_of(_m)).a0;
            _v.set(crate::syntax::lexer::chars::leading_in(s, Text::lit(" ")));
            goto _done;
        }
        {
            _v.set(Nat(0u));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto items = ({
        __label__ _done;
        prism_rtl::Slot<Array<RawItem>> _v;
        auto&& _m = index(line.items, Nat(0u));
        if (prism_rtl::is_some(_m) && prism_rtl::is<RawItem::RiText>(prism_rtl::some_of(_m))) {
            auto&& s = prism_rtl::as<RawItem::RiText>(prism_rtl::some_of(_m)).a0;
            _v.set(({
                auto rest = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = cursor_at(s, crate::prelude::min(n, strip));
                    if (prism_rtl::is_some(_m)) {
                        auto&& c = prism_rtl::some_of(_m);
                        _v.set(after(c));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(s);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                append(Array(std::vector{RawItem(RawItem::RiText{rest})}), drop(line.items, Nat(1u)));
            }));
            goto _done;
        }
        {
            _v.set(line.items);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto l2 = (n < strip) && (!blank)
        ? crate::syntax::lexer::chars::lex_err(l, first_item_span(items).start, first_item_span(items).end, Text::lit("a template line is indented less than its closing tag (Q-CT3)"))
        : l;
    auto kept = index(items, Nat(0u)) == std::optional(RawItem(RawItem::RiText{Text::lit("")}))
        ? drop(items, Nat(1u))
        : items;
    return std::tuple{kept, l2};
}


/// IsBlankOrEmpty: fn RawItem -> Bool
bool is_blank_or_empty(const RawItem& raw_item0) {
    if (prism_rtl::is<RawItem::RiText>(raw_item0)) {
        auto&& s = prism_rtl::as<RawItem::RiText>(raw_item0).a0;
        return crate::syntax::lexer::chars::trim(s) == Text::lit("");
    }
    {
        return false;
    }
}


/// IsPlaceholderItem: fn RawItem -> Bool
bool is_placeholder_item(const RawItem& raw_item0) {
    if (prism_rtl::is<RawItem::RiPlaceholder>(raw_item0)) {
        return true;
    }
    {
        return false;
    }
}


/// FirstItemSpan: fn [RawItem] -> Range
crate::syntax::Range first_item_span(const Array<RawItem>& items) {
    return or_(fold(items, std::optional<crate::syntax::Range>{}, [&](const std::optional<crate::syntax::Range>& found_opt, const RawItem& it) {
        return found_opt != std::optional<crate::syntax::Range>{}
            ? found_opt
            : item_span(it);
    }), crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)});
}


/// ?ItemSpan: fn RawItem -> ?Range
std::optional<crate::syntax::Range> item_span(const RawItem& raw_item0) {
    if (prism_rtl::is<RawItem::RiPlaceholder>(raw_item0)) {
        auto&& span = prism_rtl::as<RawItem::RiPlaceholder>(raw_item0).a1;
        return std::optional(span);
    }
    if (prism_rtl::is<RawItem::RiBlock>(raw_item0)) {
        auto&& span = prism_rtl::as<RawItem::RiBlock>(raw_item0).a1;
        return std::optional(span);
    }
    if (prism_rtl::is<RawItem::RiCall>(raw_item0)) {
        auto&& span = prism_rtl::as<RawItem::RiCall>(raw_item0).a3;
        return std::optional(span);
    }
    {
        return std::optional<crate::syntax::Range>{};
    }
}


/// AlonePlaceholder: fn [RawItem] -> TPartTok
crate::syntax::lexer::TPartTok alone_placeholder(const Array<RawItem>& items) {
    auto&& _part = fold(items, std::tuple{Nat(0u), crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptText{Text::lit("")})}, [&](const std::tuple<Nat, crate::syntax::lexer::TPartTok>& _p0, const RawItem& it) {
        auto&& c = std::get<0>(_p0);
        auto&& p_ = std::get<1>(_p0);
        return alone_step(c, p_, it);
    });
    auto&& part = std::get<1>(_part);
    return part;
}


/// AloneStep: fn Nat, TPartTok, RawItem -> ((Nat, TPartTok))
std::tuple<Nat, crate::syntax::lexer::TPartTok> alone_step(const Nat& c, const crate::syntax::lexer::TPartTok& tpart_tok1, const RawItem& raw_item2) {
    auto&& _m = std::tuple{tpart_tok1, raw_item2};
    if (prism_rtl::is<crate::syntax::lexer::TPartTok::TptText>(std::get<0>(_m)) && prism_rtl::is<RawItem::RiText>(std::get<1>(_m))) {
        auto&& c0_1_0 = prism_rtl::as<crate::syntax::lexer::TPartTok::TptText>(std::get<0>(_m)).a0;
        auto&& s = prism_rtl::as<RawItem::RiText>(std::get<1>(_m)).a0;
        if (c0_1_0 == Text::lit("")) {
            return c == Nat(0u)
                ? std::tuple{crate::syntax::lexer::chars::leading_in(s, Text::lit(" ")), crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptText{Text::lit("")})}
                : std::tuple{c, crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptText{Text::lit("")})};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TPartTok::TptText>(std::get<0>(_m)) && prism_rtl::is<RawItem::RiPlaceholder>(std::get<1>(_m))) {
        auto&& c1_1_0 = prism_rtl::as<crate::syntax::lexer::TPartTok::TptText>(std::get<0>(_m)).a0;
        auto&& tokens = prism_rtl::as<RawItem::RiPlaceholder>(std::get<1>(_m)).a0;
        auto&& span = prism_rtl::as<RawItem::RiPlaceholder>(std::get<1>(_m)).a1;
        if (c1_1_0 == Text::lit("")) {
            return std::tuple{c, crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptPlaceholder{tokens, std::optional(c), span})};
        }
    }
    {
        auto&& p_ = std::get<0>(_m);
        return std::tuple{c, p_};
    }
    prism_rtl::unreachable("no arm matched");
}


/// PushPart: fn [TPartTok], RawItem -> [TPartTok]
Array<crate::syntax::lexer::TPartTok> push_part(const Array<crate::syntax::lexer::TPartTok>& parts, const RawItem& raw_item1) {
    if (prism_rtl::is<RawItem::RiText>(raw_item1)) {
        auto&& c0_1_0 = prism_rtl::as<RawItem::RiText>(raw_item1).a0;
        if (c0_1_0 == Text::lit("")) {
            return parts;
        }
    }
    if (prism_rtl::is<RawItem::RiText>(raw_item1)) {
        auto&& t = prism_rtl::as<RawItem::RiText>(raw_item1).a0;
        auto&& _m = crate::syntax::lexer::chars::last(parts);
        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::syntax::lexer::TPartTok::TptText>(prism_rtl::some_of(_m))) {
            auto&& s = prism_rtl::as<crate::syntax::lexer::TPartTok::TptText>(prism_rtl::some_of(_m)).a0;
            return crate::prelude::push(crate::syntax::lexer::chars::pop(parts), crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptText{prism_rtl::cat(s, t)}));
        }
        {
            return crate::prelude::push(parts, crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptText{t}));
        }
    }
    if (prism_rtl::is<RawItem::RiPlaceholder>(raw_item1)) {
        auto&& tokens = prism_rtl::as<RawItem::RiPlaceholder>(raw_item1).a0;
        auto&& span = prism_rtl::as<RawItem::RiPlaceholder>(raw_item1).a1;
        return crate::prelude::push(parts, crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptPlaceholder{tokens, std::optional<Nat>{}, span}));
    }
    if (prism_rtl::is<RawItem::RiBlock>(raw_item1)) {
        auto&& tokens = prism_rtl::as<RawItem::RiBlock>(raw_item1).a0;
        auto&& span = prism_rtl::as<RawItem::RiBlock>(raw_item1).a1;
        return crate::prelude::push(parts, crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptBlock{tokens, span}));
    }
    if (prism_rtl::is<RawItem::RiCall>(raw_item1)) {
        auto&& name = prism_rtl::as<RawItem::RiCall>(raw_item1).a0;
        auto&& attrs = prism_rtl::as<RawItem::RiCall>(raw_item1).a1;
        auto&& body_opt = prism_rtl::as<RawItem::RiCall>(raw_item1).a2;
        auto&& span = prism_rtl::as<RawItem::RiCall>(raw_item1).a3;
        return crate::prelude::push(parts, crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptCall{name, attrs, body_opt, span}));
    }
    prism_rtl::unreachable("no arm matched");
}

}  // namespace crate::syntax::lexer::templates
