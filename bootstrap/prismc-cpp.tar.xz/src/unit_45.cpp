// The module `Lower.Expr`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <lower/expr/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <lower/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Lower.Expr`, from `target/bootstrap/cpp-src/prismc/lower/expr.prism`.
namespace crate::lower::expr {

/// IsLetCond: fn Cc -> Bool
bool is_let_cond_f(const crate::lower::model::Cc& cc0) {
    if (prism_rtl::is<crate::lower::model::Cc::CcLet>(cc0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Cc::CcIf>(cc0)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// MatchValue: unbounded fn Lx, Env, Expr, [Arm], OutTy, Range -> Vl
crate::lower::types::Vl match_value_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& s_p2, const Array<crate::syntax::Arm>& arms_p3, const crate::lower::model::OutTy& t_p4, const crate::syntax::Range& span_p5) {
    auto sv_p6 = value_of_f(lx_p0, env_p1, s_p2);
    auto sty_p7 = crate::lower::type_at_f(lx_p0, s_p2.span_p);
    auto label_p8 = prism_rtl::cat("m", span_p5.start_p);
    auto by_ref_p9 = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(arms_p3)), ({
        auto lx_p0x = lx_p0;
        auto arms_p3x = arms_p3;
        auto sty_p7x = sty_p7;
        auto label_p8x = label_p8;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::patterns::PatOut>(Nat)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), arms_p3x = std::move(arms_p3x), sty_p7x = std::move(sty_p7x), label_p8x = std::move(label_p8x)](Nat p0) {
        return ({
            auto lx_p0xy = lx_p0x;
            auto arms_p3xy = arms_p3x;
            auto sty_p7xy = sty_p7x;
            auto label_p8xy = label_p8x;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), arms_p3xy = std::move(arms_p3xy), sty_p7xy = std::move(sty_p7xy), label_p8xy = std::move(label_p8xy)]() {
            return ({
                auto i_pf = p0;
                (prism_rtl::more(prism_rtl::rc(ArmPat(lx_p0xy, prism_rtl::deref(crate::prelude::or_(crate::prelude::index(arms_p3xy, i_pf), dummy_arm_p())).pattern_o, sty_p7xy, crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), prism_rtl::cat(label_p8xy, "_", i_pf)))));
            });
        })));
        });
    })));
    })));
    auto chain_pa = crate::prelude::fold(by_ref_p9, false, [&](const bool& f_pg, const crate::lower::patterns::PatOut& po_ph) { return prism_rtl::deref(f_pg) || crate::prelude::fold(prism_rtl::deref(po_ph).conds_p, false, [&](const bool& f2_pi, const crate::lower::model::Cc& c_pj) { return prism_rtl::deref(f2_pi) || is_let_cond_f(c_pj); }); });
    auto owned_pb = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<crate::lower::types::Vl::VlOwned>(sv_p6)) {
            _v.set(!std::move(chain_pa));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto pats_pc = std::move(owned_pb)
        ? crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(arms_p3)), ({
        auto lx_p0x = lx_p0;
        auto arms_p3x = arms_p3;
        auto sty_p7x = sty_p7;
        auto label_p8x = label_p8;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::patterns::PatOut>(Nat)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), arms_p3x = std::move(arms_p3x), sty_p7x = std::move(sty_p7x), label_p8x = std::move(label_p8x)](Nat p0) {
        return ({
            auto lx_p0xy = lx_p0x;
            auto arms_p3xy = arms_p3x;
            auto sty_p7xy = sty_p7x;
            auto label_p8xy = label_p8x;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), arms_p3xy = std::move(arms_p3xy), sty_p7xy = std::move(sty_p7xy), label_p8xy = std::move(label_p8xy)]() {
            return ({
                auto i_pk = p0;
                (prism_rtl::more(prism_rtl::rc(ArmPat(lx_p0xy, prism_rtl::deref(crate::prelude::or_(crate::prelude::index(arms_p3xy, i_pk), dummy_arm_p())).pattern_o, sty_p7xy, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat(label_p8xy, "_", i_pk)))));
            });
        })));
        });
    })));
    })))
        : by_ref_p9;
    auto xarms_pd = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(arms_p3)), ({
        auto arms_p3x = arms_p3;
        auto pats_pcx = pats_pc;
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        auto owned_pbx = std::move(owned_pb);
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::XArm>(Nat)>>(prism_rtl::rc([=, arms_p3x = std::move(arms_p3x), pats_pcx = std::move(pats_pcx), env_p1x = std::move(env_p1x), lx_p0x = std::move(lx_p0x), owned_pbx = std::move(owned_pbx)](Nat p0) {
        return ({
            auto arms_p3xy = arms_p3x;
            auto pats_pcxy = pats_pcx;
            auto env_p1xy = env_p1x;
            auto lx_p0xy = lx_p0x;
            auto owned_pbxy = owned_pbx;
            (crate::prelude::entered(crate::prelude::once_job([=, arms_p3xy = std::move(arms_p3xy), pats_pcxy = std::move(pats_pcxy), env_p1xy = std::move(env_p1xy), lx_p0xy = std::move(lx_p0xy), owned_pbxy = std::move(owned_pbxy)]() {
            return ({
                auto i_pl = p0;
                ({
                auto arm_pm = crate::prelude::or_(crate::prelude::index(arms_p3xy, i_pl), dummy_arm_p());
                auto po_pn = crate::prelude::or_(crate::prelude::index(pats_pcxy, i_pl), crate::lower::patterns::PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds_p = Array<crate::lower::model::Cc>{}, .binds_p = Array<std::tuple<Text, crate::lower::types::Bn>>{}});
                auto env2_po = bind_all_f(env_p1xy, prism_rtl::deref(po_pn).binds_p);
                auto guard_pp = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::lower::model::Cc>> _v;
                    auto&& _m = prism_rtl::deref(arm_pm).guard_o;
                    if (prism_rtl::is_some(_m)) {
                        auto&& ge_pr = prism_rtl::some_of(_m);
                        _v.set(Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::types::as_bool_f(value_of_f(lx_p0xy, env2_po, ge_pr))})}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Array<crate::lower::model::Cc>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto env3_pq = owned_pbxy
                    ? moved_once_f(lx_p0xy, env2_po, arm_pm, prism_rtl::deref(po_pn).binds_p)
                    : env2_po;
                (crate::prelude::call_then(start_block_value_f(lx_p0xy, env3_pq, prism_rtl::deref(arm_pm).body_p), [=, po_pn = std::move(po_pn), guard_pp = std::move(guard_pp)](crate::lower::types::Vl block_value_f_69416) { return prism_rtl::finished(crate::lower::model::XArm{.pat_p = prism_rtl::deref(po_pn).pa_p, .conds_p = crate::prelude::append(prism_rtl::deref(po_pn).conds_p, guard_pp), .body_p = crate::lower::types::own_f(block_value_f_69416)}); }));
            });
            });
        })));
        });
    })));
    })));
    auto scrut_pe = std::move(owned_pb)
        ? crate::lower::types::own_f(sv_p6)
        : crate::lower::types::ref_f(sv_p6);
    return arms_value_f(scrut_pe, xarms_pd, label_p8, t_p4);
}


prism_rtl::Turn<crate::lower::types::Vl> MatchValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& s_p2 = this->s_p2;
    const auto& arms_p3 = this->arms_p3;
    const auto& t_p4 = this->t_p4;
    const auto& span_p5 = this->span_p5;
    auto arms_p3x = arms_p3;
    auto env_p1x = env_p1;
    auto lx_p0x = lx_p0;
    auto s_p2x = s_p2;
    auto span_p5x = span_p5;
    auto t_p4x = t_p4;
    return crate::prelude::call_then(start_value_of_f(lx_p0x, env_p1x, s_p2x), [=](crate::lower::types::Vl value_of_f_68427) {
        return ({
            auto sv_p6 = value_of_f_68427;
            auto sty_p7 = crate::lower::type_at_f(lx_p0x, prism_rtl::deref(s_p2x).span_p);
            auto label_p8 = prism_rtl::cat("m", prism_rtl::deref(span_p5x).start_p);
            (crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(arms_p3x)), ({
            auto lx_p0xx = lx_p0x;
            auto arms_p3xx = arms_p3x;
            auto sty_p7x = sty_p7;
            auto label_p8x = label_p8;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::patterns::PatOut>(Nat)>>(prism_rtl::rc([=, lx_p0xx = std::move(lx_p0xx), arms_p3xx = std::move(arms_p3xx), sty_p7x = std::move(sty_p7x), label_p8x = std::move(label_p8x)](Nat p0) {
            return ({
                auto lx_p0xxy = lx_p0xx;
                auto arms_p3xxy = arms_p3xx;
                auto sty_p7xy = sty_p7x;
                auto label_p8xy = label_p8x;
                (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxy = std::move(lx_p0xxy), arms_p3xxy = std::move(arms_p3xxy), sty_p7xy = std::move(sty_p7xy), label_p8xy = std::move(label_p8xy)]() {
                return ({
                    auto i_pf = p0;
                    (prism_rtl::more(prism_rtl::rc(ArmPat(lx_p0xxy, prism_rtl::deref(crate::prelude::or_(crate::prelude::index(arms_p3xxy, i_pf), dummy_arm_p())).pattern_o, sty_p7xy, crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), prism_rtl::cat(label_p8xy, "_", i_pf)))));
                });
            })));
            });
        })));
        })), [=, sv_p6 = std::move(sv_p6)](Array<crate::lower::patterns::PatOut> each_68526) {
            return ({
                auto by_ref_p9 = each_68526;
                auto chain_pa = crate::prelude::fold(by_ref_p9, false, [&](const bool& f_pg, const crate::lower::patterns::PatOut& po_ph) { return prism_rtl::deref(f_pg) || crate::prelude::fold(prism_rtl::deref(po_ph).conds_p, false, [&](const bool& f2_pi, const crate::lower::model::Cc& c_pj) { return prism_rtl::deref(f2_pi) || is_let_cond_f(c_pj); }); });
                auto owned_pb = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    if (prism_rtl::is<crate::lower::types::Vl::VlOwned>(sv_p6)) {
                        _v.set(!std::move(chain_pa));
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto pats_pc = std::move(owned_pb)
                    ? crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(arms_p3x)), ({
                    auto lx_p0xx = lx_p0x;
                    auto arms_p3xx = arms_p3x;
                    auto sty_p7x = sty_p7;
                    auto label_p8x = label_p8;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::patterns::PatOut>(Nat)>>(prism_rtl::rc([=, lx_p0xx = std::move(lx_p0xx), arms_p3xx = std::move(arms_p3xx), sty_p7x = std::move(sty_p7x), label_p8x = std::move(label_p8x)](Nat p0) {
                    return ({
                        auto lx_p0xxy = lx_p0xx;
                        auto arms_p3xxy = arms_p3xx;
                        auto sty_p7xy = sty_p7x;
                        auto label_p8xy = label_p8x;
                        (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxy = std::move(lx_p0xxy), arms_p3xxy = std::move(arms_p3xxy), sty_p7xy = std::move(sty_p7xy), label_p8xy = std::move(label_p8xy)]() {
                        return ({
                            auto i_pk = p0;
                            (prism_rtl::more(prism_rtl::rc(ArmPat(lx_p0xxy, prism_rtl::deref(crate::prelude::or_(crate::prelude::index(arms_p3xxy, i_pk), dummy_arm_p())).pattern_o, sty_p7xy, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat(label_p8xy, "_", i_pk)))));
                        });
                    })));
                    });
                })));
                })))
                    : by_ref_p9;
                (crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(arms_p3x)), ({
                auto arms_p3xx = arms_p3x;
                auto pats_pcx = pats_pc;
                auto env_p1xx = env_p1x;
                auto lx_p0xx = lx_p0x;
                auto owned_pbx = std::move(owned_pb);
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::XArm>(Nat)>>(prism_rtl::rc([=, arms_p3xx = std::move(arms_p3xx), pats_pcx = std::move(pats_pcx), env_p1xx = std::move(env_p1xx), lx_p0xx = std::move(lx_p0xx), owned_pbx = std::move(owned_pbx)](Nat p0) {
                return ({
                    auto arms_p3xxy = arms_p3xx;
                    auto pats_pcxy = pats_pcx;
                    auto env_p1xxy = env_p1xx;
                    auto lx_p0xxy = lx_p0xx;
                    auto owned_pbxy = owned_pbx;
                    (crate::prelude::entered(crate::prelude::once_job([=, arms_p3xxy = std::move(arms_p3xxy), pats_pcxy = std::move(pats_pcxy), env_p1xxy = std::move(env_p1xxy), lx_p0xxy = std::move(lx_p0xxy), owned_pbxy = std::move(owned_pbxy)]() {
                    return ({
                        auto i_pl = p0;
                        ({
                        auto arm_pm = crate::prelude::or_(crate::prelude::index(arms_p3xxy, i_pl), dummy_arm_p());
                        auto po_pn = crate::prelude::or_(crate::prelude::index(pats_pcxy, i_pl), crate::lower::patterns::PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds_p = Array<crate::lower::model::Cc>{}, .binds_p = Array<std::tuple<Text, crate::lower::types::Bn>>{}});
                        auto env2_po = bind_all_f(env_p1xxy, prism_rtl::deref(po_pn).binds_p);
                        auto guard_pp = ({
                            __label__ _done;
                            prism_rtl::Slot<Array<crate::lower::model::Cc>> _v;
                            auto&& _m = prism_rtl::deref(arm_pm).guard_o;
                            if (prism_rtl::is_some(_m)) {
                                auto&& ge_pr = prism_rtl::some_of(_m);
                                _v.set(Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::types::as_bool_f(value_of_f(lx_p0xxy, env2_po, ge_pr))})}));
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(Array<crate::lower::model::Cc>{});
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        });
                        auto env3_pq = owned_pbxy
                            ? moved_once_f(lx_p0xxy, env2_po, arm_pm, prism_rtl::deref(po_pn).binds_p)
                            : env2_po;
                        (crate::prelude::call_then(start_block_value_f(lx_p0xxy, env3_pq, prism_rtl::deref(arm_pm).body_p), [=, po_pn = std::move(po_pn), guard_pp = std::move(guard_pp)](crate::lower::types::Vl block_value_f_69416) { return prism_rtl::finished(crate::lower::model::XArm{.pat_p = prism_rtl::deref(po_pn).pa_p, .conds_p = crate::prelude::append(prism_rtl::deref(po_pn).conds_p, guard_pp), .body_p = crate::lower::types::own_f(block_value_f_69416)}); }));
                    });
                    });
                })));
                });
            })));
            })), [=](Array<crate::lower::model::XArm> each_68972) {
                return ({
                    auto xarms_pd = each_68972;
                    auto scrut_pe = owned_pb
                        ? crate::lower::types::own_f(sv_p6)
                        : crate::lower::types::ref_f(sv_p6);
                    (prism_rtl::finished(arms_value_f(scrut_pe, xarms_pd, label_p8, t_p4x)));
                });
            }));
            });
        }));
        });
    });
}


/// `Start MatchValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_match_value_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr s_p2, Array<crate::syntax::Arm> arms_p3, crate::lower::model::OutTy t_p4, crate::syntax::Range span_p5) {
    return prism_rtl::make_rc<MatchValue>(lx_p0, env_p1, s_p2, arms_p3, t_p4, span_p5);
}


/// MovedOnce: unbounded fn Lx, Env, Arm, [((Text, Bn))] -> Env
crate::lower::types::Env moved_once_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Arm& arm_p2, const Array<std::tuple<Text, crate::lower::types::Bn>>& binds_p3) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(binds_p3, env_p1, ({
        auto lx_p0x = lx_p0;
        auto arm_p2x = arm_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::types::Env>(std::tuple<crate::lower::types::Env, std::tuple<Text, crate::lower::types::Bn>>)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), arm_p2x = std::move(arm_p2x)](std::tuple<crate::lower::types::Env, std::tuple<Text, crate::lower::types::Bn>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0xy = lx_p0x;
            auto arm_p2xy = arm_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), arm_p2xy = std::move(arm_p2xy)]() {
            return ({
                auto en_p4 = p0;
                auto [nkey_p5, bn_p6] = p1;
                ({
                prism_rtl::is<crate::lower::types::Bn::BnLocal>(bn_p6) && prism_rtl::is<crate::lower::model::Ex::XVar>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(bn_p6).a0) && prism_rtl::is<crate::lower::types::Holding::Owned>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(bn_p6).a1) ? ({
                auto&& rs_p7 = prism_rtl::as<crate::lower::model::Ex::XVar>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(bn_p6).a0).a0;
                auto&& bt_p8 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(bn_p6).a2;
                ({
                auto bt_p8x = bt_p8;
                auto rs_p7x = rs_p7;
                (crate::prelude::call_then(start_only_read_o(lx_p0xy, arm_p2xy, nkey_p5), [=, bt_p8x = std::move(bt_p8x), rs_p7x = std::move(rs_p7x)](std::optional<crate::syntax::Expr> only_read_o_70065) {
                return ({
                    prism_rtl::is_some(only_read_o_70065) ? ({
                    auto&& x_p9 = prism_rtl::some_of(only_read_o_70065);
                    prism_rtl::finished(crate::lower::types::bind_span_f(en_p4, crate::lower::place_key_f(lx_p0xy, prism_rtl::deref(x_p9).span_p), crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs_p7x}), bt_p8x})));
                })
                    : prism_rtl::is_none(only_read_o_70065) ? prism_rtl::finished(en_p4)
                    : throw prism_rtl::Panic("no arm matched");
                });
            }));
            });
            })
                : prism_rtl::finished(en_p4);
            });
            });
        })));
        });
    })));
    })));
}


prism_rtl::Turn<crate::lower::types::Env> MovedOnce::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& arm_p2 = this->arm_p2;
    const auto& binds_p3 = this->binds_p3;
    return crate::prelude::fold_job(binds_p3, env_p1, ({
        auto lx_p0x = lx_p0;
        auto arm_p2x = arm_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::types::Env>(std::tuple<crate::lower::types::Env, std::tuple<Text, crate::lower::types::Bn>>)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), arm_p2x = std::move(arm_p2x)](std::tuple<crate::lower::types::Env, std::tuple<Text, crate::lower::types::Bn>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0xy = lx_p0x;
            auto arm_p2xy = arm_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), arm_p2xy = std::move(arm_p2xy)]() {
            return ({
                auto en_p4 = p0;
                auto [nkey_p5, bn_p6] = p1;
                ({
                prism_rtl::is<crate::lower::types::Bn::BnLocal>(bn_p6) && prism_rtl::is<crate::lower::model::Ex::XVar>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(bn_p6).a0) && prism_rtl::is<crate::lower::types::Holding::Owned>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(bn_p6).a1) ? ({
                auto&& rs_p7 = prism_rtl::as<crate::lower::model::Ex::XVar>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(bn_p6).a0).a0;
                auto&& bt_p8 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(bn_p6).a2;
                ({
                auto bt_p8x = bt_p8;
                auto rs_p7x = rs_p7;
                (crate::prelude::call_then(start_only_read_o(lx_p0xy, arm_p2xy, nkey_p5), [=, bt_p8x = std::move(bt_p8x), rs_p7x = std::move(rs_p7x)](std::optional<crate::syntax::Expr> only_read_o_70065) {
                return ({
                    prism_rtl::is_some(only_read_o_70065) ? ({
                    auto&& x_p9 = prism_rtl::some_of(only_read_o_70065);
                    prism_rtl::finished(crate::lower::types::bind_span_f(en_p4, crate::lower::place_key_f(lx_p0xy, prism_rtl::deref(x_p9).span_p), crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs_p7x}), bt_p8x})));
                })
                    : prism_rtl::is_none(only_read_o_70065) ? prism_rtl::finished(en_p4)
                    : throw prism_rtl::Panic("no arm matched");
                });
            }));
            });
            })
                : prism_rtl::finished(en_p4);
            });
            });
        })));
        });
    })));
    }))->cycle();
}


/// `Start MovedOnce, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Env> start_moved_once_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Arm arm_p2, Array<std::tuple<Text, crate::lower::types::Bn>> binds_p3) {
    return prism_rtl::make_rc<MovedOnce>(lx_p0, env_p1, arm_p2, binds_p3);
}


/// ?OnlyRead: unbounded fn Lx, Arm, Text -> ?Expr
std::optional<crate::syntax::Expr> only_read_o(const crate::lower::Lx& lx_p0, const crate::syntax::Arm& arm_p1, const Text& nkey_p2) {
    auto text_p3 = crate::lower::functions::src_text_f(lx_p0, lx_p0.file_p, prism_rtl::deref(arm_p1.body_p).span_p);
    auto in_guard_p5 = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = arm_p1.guard_o;
        if (prism_rtl::is_some(_m)) {
            auto&& ge_p4 = prism_rtl::some_of(_m);
            _v.set(word_count_f(crate::lower::functions::src_text_f(lx_p0, lx_p0.file_p, prism_rtl::deref(ge_p4).span_p), nkey_p2) > Nat(0u));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto reads_p8 = crate::prelude::filter(crate::check::typed::print::block_exprs_f(arm_p1.body_p), [&](const crate::syntax::Expr& x_p6) {
        return ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(x_p6).kind_p);
            if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                auto&& n_p7 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                _v.set((crate::prelude::len(prism_rtl::deref(n_p7).path_p) == Nat(1u)) && (crate::check::env::sname_key_f(n_p7) == nkey_p2));
                goto _done;
            }
            {
                _v.set(false);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto plain_p9 = (((!std::move(in_guard_p5)) && (word_count_f(text_p3, nkey_p2) == Nat(1u))) && (!crate::syntax::lexer::chars::contains_f(text_p3, Text::lit("\\|")))) && (crate::prelude::len(crate::prelude::matches(([]() -> const Regex& { static const Regex r = Regex::lit("\\b(while|for)\\b", ""); return r; }()), text_p3)) == Nat(0u));
    return std::move(plain_p9) && (crate::prelude::len(reads_p8) == Nat(1u))
        ? crate::prelude::index(reads_p8, Nat(0u))
        : std::optional<crate::syntax::Expr>{};
}


prism_rtl::Turn<std::optional<crate::syntax::Expr>> OnlyRead::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& arm_p1 = this->arm_p1;
    const auto& nkey_p2 = this->nkey_p2;
    auto text_p3 = crate::lower::functions::src_text_f(lx_p0, prism_rtl::deref(lx_p0).file_p, prism_rtl::deref(prism_rtl::deref(arm_p1).body_p).span_p);
    auto in_guard_p5 = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = prism_rtl::deref(arm_p1).guard_o;
        if (prism_rtl::is_some(_m)) {
            auto&& ge_p4 = prism_rtl::some_of(_m);
            _v.set(word_count_f(crate::lower::functions::src_text_f(lx_p0, prism_rtl::deref(lx_p0).file_p, prism_rtl::deref(ge_p4).span_p), nkey_p2) > Nat(0u));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto arm_p1x = arm_p1;
    auto nkey_p2x = nkey_p2;
    return crate::prelude::call_then(crate::check::typed::print::start_block_exprs_f(prism_rtl::deref(arm_p1x).body_p), [=](Array<crate::syntax::Expr> block_exprs_f_70469) {
        return ({
            auto reads_p8 = crate::prelude::filter(block_exprs_f_70469, [&](const crate::syntax::Expr& x_p6) {
                return ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = prism_rtl::deref(prism_rtl::deref(x_p6).kind_p);
                    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                        auto&& n_p7 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                        _v.set((crate::prelude::len(prism_rtl::deref(n_p7).path_p) == Nat(1u)) && (crate::check::env::sname_key_f(n_p7) == nkey_p2x));
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            });
            auto plain_p9 = (((!in_guard_p5) && (word_count_f(text_p3, nkey_p2x) == Nat(1u))) && (!crate::syntax::lexer::chars::contains_f(text_p3, Text::lit("\\|")))) && (crate::prelude::len(crate::prelude::matches(([]() -> const Regex& { static const Regex r = Regex::lit("\\b(while|for)\\b", ""); return r; }()), text_p3)) == Nat(0u));
            (std::move(plain_p9) && (crate::prelude::len(reads_p8) == Nat(1u))
            ? prism_rtl::finished(crate::prelude::index(reads_p8, Nat(0u)))
            : prism_rtl::finished(std::optional<crate::syntax::Expr>{}));
        });
    });
}


/// `Start OnlyRead, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<crate::syntax::Expr>> start_only_read_o(crate::lower::Lx lx_p0, crate::syntax::Arm arm_p1, Text nkey_p2) {
    return prism_rtl::make_rc<OnlyRead>(lx_p0, arm_p1, nkey_p2);
}


/// WordCount: fn Text, Text -> Nat
Nat word_count_f(const Text& text_p0, const Text& name_p1) {
    return crate::prelude::len(crate::prelude::filter(crate::prelude::matches(([]() -> const Regex& { static const Regex r = Regex::lit("[?~$!@&]*[A-Za-z_][A-Za-z0-9_]*", ""); return r; }()), text_p0), [&](const crate::prelude::Match& m_p2) { return prism_rtl::deref(m_p2).text_p == name_p1; }));
}


/// let dummyArm
crate::syntax::Arm dummy_arm_p() {
    return crate::syntax::Arm{.pattern_o = std::optional<crate::syntax::Pattern_>{}, .guard_o = std::optional<crate::syntax::Expr>{}, .body_p = crate::syntax::Block{.stmts_p = Array<crate::syntax::Stmt>{}, .inline_p = true, .span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}}, .span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}};
}


/// ArmPat: unbounded fn Lx, ?Pattern, Ty, Holding, Text -> PatOut
crate::lower::patterns::PatOut arm_pat_f(const crate::lower::Lx& lx_p0, const std::optional<crate::syntax::Pattern_>& opt1, const crate::check::types::Ty& ty_p2, const crate::lower::types::Holding& mode_p3, const Text& fresh_p4) {
    if (prism_rtl::is_some(opt1)) {
        auto&& p_p1 = prism_rtl::some_of(opt1);
        return crate::lower::patterns::rust_pat_f(lx_p0, p_p1, ty_p2, mode_p3, fresh_p4);
    }
    if (prism_rtl::is_none(opt1)) {
        return crate::lower::patterns::PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds_p = Array<crate::lower::model::Cc>{}, .binds_p = Array<std::tuple<Text, crate::lower::types::Bn>>{}};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::patterns::PatOut> ArmPat::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& opt1 = this->opt1;
    const auto& ty_p2 = this->ty_p2;
    const auto& mode_p3 = this->mode_p3;
    const auto& fresh_p4 = this->fresh_p4;
    return ({
        prism_rtl::is_some(opt1) ? ({
        auto&& p_p1 = prism_rtl::some_of(opt1);
        prism_rtl::more(prism_rtl::rc(crate::lower::patterns::RustPat(lx_p0, p_p1, ty_p2, mode_p3, fresh_p4)));
    })
        : prism_rtl::is_none(opt1) ? prism_rtl::finished(crate::lower::patterns::PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds_p = Array<crate::lower::model::Cc>{}, .binds_p = Array<std::tuple<Text, crate::lower::types::Bn>>{}})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ArmPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::patterns::PatOut> start_arm_pat_f(crate::lower::Lx lx_p0, std::optional<crate::syntax::Pattern_> opt1, crate::check::types::Ty ty_p2, crate::lower::types::Holding mode_p3, Text fresh_p4) {
    return prism_rtl::make_rc<ArmPat>(lx_p0, opt1, ty_p2, mode_p3, fresh_p4);
}


/// BlockValue: unbounded fn Lx, Env, Block -> Vl
crate::lower::types::Vl block_value_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Block& b_p2) {
    return is_given_block_f(b_p2.stmts_p)
        ? crate::lower::templates::given_value_f(lx_p0, env_p1, b_p2, block_ty_f(lx_p0, b_p2), b_p2.span_p)
        : plain_block_value_f(lx_p0, env_p1, b_p2);
}


prism_rtl::Turn<crate::lower::types::Vl> BlockValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& b_p2 = this->b_p2;
    return is_given_block_f(prism_rtl::deref(b_p2).stmts_p)
        ? ({
        auto b_p2x = b_p2;
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        (crate::prelude::call_then(start_block_ty_f(lx_p0x, b_p2x), [=, env_p1x = std::move(env_p1x)](crate::lower::model::OutTy block_ty_f_71619) { return prism_rtl::more(prism_rtl::rc(crate::lower::templates::GivenValue(lx_p0x, env_p1x, b_p2x, block_ty_f_71619, prism_rtl::deref(b_p2x).span_p))); }));
    })
        : prism_rtl::more(prism_rtl::rc(PlainBlockValue(lx_p0, env_p1, b_p2)));
}


/// `Start BlockValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_block_value_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Block b_p2) {
    return prism_rtl::make_rc<BlockValue>(lx_p0, env_p1, b_p2);
}


/// IsGivenBlock: fn [Stmt] -> Bool
bool is_given_block_f(const Array<crate::syntax::Stmt>& stmts_p0) {
    return crate::prelude::fold(stmts_p0, false, [&](const bool& f_p1, const crate::syntax::Stmt& s_p2) { return prism_rtl::deref(f_p1) || is_guardish_f(s_p2); });
}


/// IsGuardish: fn Stmt -> Bool
bool is_guardish_f(const crate::syntax::Stmt& s_p0) {
    auto&& _m = s_p0.kind_p;
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SRequire>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SForbid>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// BlockTy: unbounded fn Lx, Block -> OutTy
crate::lower::model::OutTy block_ty_f(const crate::lower::Lx& lx_p0, const crate::syntax::Block& b_p1) {
    auto&& _m = prism_rtl::deref(crate::prelude::or_(crate::prelude::index(b_p1.stmts_p, crate::syntax::lexer::chars::dec_f(crate::prelude::len(b_p1.stmts_p))), dummy_stmt_l_p())).kind_p;
    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
        auto&& x_p2 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        return crate::lower::types::out_ty_of_f(lx_p0, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0, prism_rtl::deref(x_p2).span_p)));
    }
    {
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{});
    }
}


prism_rtl::Turn<crate::lower::model::OutTy> BlockTy::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& b_p1 = this->b_p1;
    return ({
        auto&& _m = prism_rtl::deref(crate::prelude::or_(crate::prelude::index(prism_rtl::deref(b_p1).stmts_p, crate::syntax::lexer::chars::dec_f(crate::prelude::len(prism_rtl::deref(b_p1).stmts_p))), dummy_stmt_l_p())).kind_p;
        prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
        auto&& x_p2 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        prism_rtl::more(prism_rtl::rc(crate::lower::types::OutTyOf(lx_p0, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0, prism_rtl::deref(x_p2).span_p)))));
    })
        : prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
    });
}


/// `Start BlockTy, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::OutTy> start_block_ty_f(crate::lower::Lx lx_p0, crate::syntax::Block b_p1) {
    return prism_rtl::make_rc<BlockTy>(lx_p0, b_p1);
}


/// PlainBlockValue: unbounded fn Lx, Env, Block -> Vl
crate::lower::types::Vl plain_block_value_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Block& b_p2) {
    auto n_p3 = crate::prelude::len(b_p2.stmts_p);
    auto [dos_pf, env2_pg, last_oh] = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(n_p3), std::tuple{Array<crate::lower::model::Do>{}, env_p1, std::optional<crate::lower::types::Vl>{}}, ({
        auto b_p2x = b_p2;
        auto n_p3x = n_p3;
        auto lx_p0x = lx_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env, std::optional<crate::lower::types::Vl>>>(std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env, std::optional<crate::lower::types::Vl>>, Nat>)>>(prism_rtl::rc([=, b_p2x = std::move(b_p2x), n_p3x = std::move(n_p3x), lx_p0x = std::move(lx_p0x)](std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env, std::optional<crate::lower::types::Vl>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto b_p2xy = b_p2x;
            auto n_p3xy = n_p3x;
            auto lx_p0xy = lx_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, b_p2xy = std::move(b_p2xy), n_p3xy = std::move(n_p3xy), lx_p0xy = std::move(lx_p0xy)]() {
            return ({
                auto [acc_p5, en_p6, lv_o7] = p0;
                auto i_p8 = p1;
                ({
                auto s_p9 = crate::prelude::or_(crate::prelude::index(prism_rtl::deref(b_p2xy).stmts_p, i_p8), dummy_stmt_l_p());
                (i_p8 + Nat(1u)) == n_p3xy
                ? ({
                auto&& _m = prism_rtl::deref(s_p9).kind_p;
                prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
                auto&& x_pa = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                prism_rtl::finished(std::tuple{acc_p5, en_p6, std::optional(value_of_f(lx_p0xy, en_p6, x_pa))});
            })
                : crate::prelude::call_then(start_block_stmt_f(lx_p0xy, en_p6, s_p9), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> block_stmt_f_72661) {
                return ({
                    auto [more_pb, en2_pc] = block_stmt_f_72661;
                    (prism_rtl::finished(std::tuple{crate::prelude::append(acc_p5, more_pb), en2_pc, std::optional<crate::lower::types::Vl>{}}));
                });
            });
            })
                : crate::prelude::call_then(start_block_stmt_f(lx_p0xy, en_p6, s_p9), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> block_stmt_f_72776) {
                return ({
                    auto [more_pd, en2_pe] = block_stmt_f_72776;
                    (prism_rtl::finished(std::tuple{crate::prelude::append(acc_p5, more_pd), en2_pe, lv_o7}));
                });
            });
            });
            });
        })));
        });
    }));
    })));
    auto last_p4 = crate::prelude::or_(last_oh, crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}));
    return crate::prelude::len(dos_pf) == Nat(0u)
        ? last_p4
        : crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos_pf, prism_rtl::rc(crate::lower::types::own_f(last_p4))}), crate::lower::types::value_ty_f(last_p4)});
}


prism_rtl::Turn<crate::lower::types::Vl> PlainBlockValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& b_p2 = this->b_p2;
    auto n_p3 = crate::prelude::len(prism_rtl::deref(b_p2).stmts_p);
    auto b_p2x = b_p2;
    auto env_p1x = env_p1;
    auto lx_p0x = lx_p0;
    return crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(n_p3), std::tuple{Array<crate::lower::model::Do>{}, env_p1x, std::optional<crate::lower::types::Vl>{}}, ({
        auto b_p2xx = b_p2x;
        auto n_p3x = n_p3;
        auto lx_p0xx = lx_p0x;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env, std::optional<crate::lower::types::Vl>>>(std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env, std::optional<crate::lower::types::Vl>>, Nat>)>>(prism_rtl::rc([=, b_p2xx = std::move(b_p2xx), n_p3x = std::move(n_p3x), lx_p0xx = std::move(lx_p0xx)](std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env, std::optional<crate::lower::types::Vl>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto b_p2xxy = b_p2xx;
            auto n_p3xy = n_p3x;
            auto lx_p0xxy = lx_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, b_p2xxy = std::move(b_p2xxy), n_p3xy = std::move(n_p3xy), lx_p0xxy = std::move(lx_p0xxy)]() {
            return ({
                auto [acc_p5, en_p6, lv_o7] = p0;
                auto i_p8 = p1;
                ({
                auto s_p9 = crate::prelude::or_(crate::prelude::index(prism_rtl::deref(b_p2xxy).stmts_p, i_p8), dummy_stmt_l_p());
                (i_p8 + Nat(1u)) == n_p3xy
                ? ({
                auto&& _m = prism_rtl::deref(s_p9).kind_p;
                prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
                auto&& x_pa = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                prism_rtl::finished(std::tuple{acc_p5, en_p6, std::optional(value_of_f(lx_p0xxy, en_p6, x_pa))});
            })
                : crate::prelude::call_then(start_block_stmt_f(lx_p0xxy, en_p6, s_p9), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> block_stmt_f_72661) {
                return ({
                    auto [more_pb, en2_pc] = block_stmt_f_72661;
                    (prism_rtl::finished(std::tuple{crate::prelude::append(acc_p5, more_pb), en2_pc, std::optional<crate::lower::types::Vl>{}}));
                });
            });
            })
                : crate::prelude::call_then(start_block_stmt_f(lx_p0xxy, en_p6, s_p9), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> block_stmt_f_72776) {
                return ({
                    auto [more_pd, en2_pe] = block_stmt_f_72776;
                    (prism_rtl::finished(std::tuple{crate::prelude::append(acc_p5, more_pd), en2_pe, lv_o7}));
                });
            });
            });
            });
        })));
        });
    }));
    })), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env, std::optional<crate::lower::types::Vl>> fold_72407) {
        return ({
            auto [dos_pf, env2_pg, last_oh] = fold_72407;
            auto last_p4 = crate::prelude::or_(last_oh, crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}));
            (crate::prelude::len(dos_pf) == Nat(0u)
            ? prism_rtl::finished(last_p4)
            : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos_pf, prism_rtl::rc(crate::lower::types::own_f(last_p4))}), crate::lower::types::value_ty_f(last_p4)})));
        });
    });
}


/// `Start PlainBlockValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_plain_block_value_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Block b_p2) {
    return prism_rtl::make_rc<PlainBlockValue>(lx_p0, env_p1, b_p2);
}


/// let dummyStmtL
crate::syntax::Stmt dummy_stmt_l_p() {
    return crate::syntax::Stmt{.kind_p = crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}}}), .span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}};
}


/// BlockStmt: unbounded fn Lx, Env, Stmt -> (([Do], Env))
std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> block_stmt_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Stmt& s_p2) {
    auto&& _m = s_p2.kind_p;
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_p3 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& x_p4 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p3).kind_p);
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            auto&& n_p5 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            auto&& _m = crate::prelude::get(lx_p0.gens_p, crate::lower::place_key_f(lx_p0, prism_rtl::deref(n_p5).span_p));
            if (prism_rtl::is_some(_m)) {
                auto&& gn_p6 = prism_rtl::some_of(_m);
                return generic_let_f(lx_p0, env_p1, n_p5, gn_p6, x_p4);
            }
            if (prism_rtl::is_none(_m)) {
                return plain_let_f(lx_p0, env_p1, s_p2, p_p3, x_p4);
            }
            prism_rtl::unreachable("no arm matched");
        }
        {
            return plain_let_f(lx_p0, env_p1, s_p2, p_p3, x_p4);
        }
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
        auto&& x_p7 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        return std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::types::own_f(value_of_f(lx_p0, env_p1, x_p7))})}), env_p1};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m)) {
        return std::tuple{Array<crate::lower::model::Do>{}, env_p1};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        auto&& f_p8 = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        return std::tuple{Array(std::vector{refusal_do_f(prism_rtl::cat("a local function ", crate::check::env::def_name_text_f(prism_rtl::deref(f_p8).name_p), ": not lowered yet"))}), env_p1};
    }
    {
        return std::tuple{Array(std::vector{refusal_do_f(Text::lit("a statement this back end does not lower yet"))}), env_p1};
    }
}


prism_rtl::Turn<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> BlockStmt::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& s_p2 = this->s_p2;
    return ({
        auto&& _m = prism_rtl::deref(s_p2).kind_p;
        prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& p_p3 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& x_p4 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p3).kind_p);
        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n_p5 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0).gens_p, crate::lower::place_key_f(lx_p0, prism_rtl::deref(n_p5).span_p));
        prism_rtl::is_some(_m) ? ({
        auto&& gn_p6 = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(GenericLet(lx_p0, env_p1, n_p5, gn_p6, x_p4)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(PlainLet(lx_p0, env_p1, s_p2, p_p3, x_p4)))
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::more(prism_rtl::rc(PlainLet(lx_p0, env_p1, s_p2, p_p3, x_p4)));
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
        auto&& x_p7 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        ({
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        auto x_p7x = x_p7;
        (crate::prelude::call_then(start_value_of_f(lx_p0x, env_p1x, x_p7x), [=](crate::lower::types::Vl value_of_f_73484) { return prism_rtl::finished(std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::types::own_f(value_of_f_73484)})}), env_p1x}); }));
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m) ? prism_rtl::finished(std::tuple{Array<crate::lower::model::Do>{}, env_p1})
        : prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? ({
        auto&& f_p8 = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        prism_rtl::finished(std::tuple{Array(std::vector{refusal_do_f(prism_rtl::cat("a local function ", crate::check::env::def_name_text_f(prism_rtl::deref(f_p8).name_p), ": not lowered yet"))}), env_p1});
    })
        : prism_rtl::finished(std::tuple{Array(std::vector{refusal_do_f(Text::lit("a statement this back end does not lower yet"))}), env_p1});
    });
}


/// `Start BlockStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> start_block_stmt_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Stmt s_p2) {
    return prism_rtl::make_rc<BlockStmt>(lx_p0, env_p1, s_p2);
}


/// GenericLet: unbounded fn Lx, Env, SName, GenNote, Expr -> (([Do], Env))
std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> generic_let_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::SName& n_p2, const crate::check::typed::GenNote& gn_p3, const crate::syntax::Expr& x_p4) {
    auto nkey_p5 = crate::check::env::sname_key_f(n_p2);
    auto distinct_p6 = instantiations_f(lx_p0, gn_p3);
    auto one_p7 = crate::prelude::len(distinct_p6) == Nat(1u);
    auto rs_p8 = crate::lower::local_name_at_f(lx_p0, nkey_p5, n_p2.span_p);
    return crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(distinct_p6)), std::tuple{Array<crate::lower::model::Do>{}, env_p1}, ({
        auto distinct_p6x = distinct_p6;
        auto lx_p0x = lx_p0;
        auto one_p7x = std::move(one_p7);
        auto rs_p8x = rs_p8;
        auto nkey_p5x = nkey_p5;
        auto n_p2x = n_p2;
        auto env_p1x = env_p1;
        auto x_p4x = x_p4;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>>(std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>, Nat>)>>(prism_rtl::rc([=, distinct_p6x = std::move(distinct_p6x), lx_p0x = std::move(lx_p0x), one_p7x = std::move(one_p7x), rs_p8x = std::move(rs_p8x), nkey_p5x = std::move(nkey_p5x), n_p2x = std::move(n_p2x), env_p1x = std::move(env_p1x), x_p4x = std::move(x_p4x)](std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto distinct_p6xy = distinct_p6x;
            auto lx_p0xy = lx_p0x;
            auto one_p7xy = one_p7x;
            auto rs_p8xy = rs_p8x;
            auto nkey_p5xy = nkey_p5x;
            auto n_p2xy = n_p2x;
            auto env_p1xy = env_p1x;
            auto x_p4xy = x_p4x;
            (crate::prelude::entered(crate::prelude::once_job([=, distinct_p6xy = std::move(distinct_p6xy), lx_p0xy = std::move(lx_p0xy), one_p7xy = std::move(one_p7xy), rs_p8xy = std::move(rs_p8xy), nkey_p5xy = std::move(nkey_p5xy), n_p2xy = std::move(n_p2xy), env_p1xy = std::move(env_p1xy), x_p4xy = std::move(x_p4xy)]() {
            return ({
                auto [dos_p9, en_pa] = p0;
                auto k_pb = p1;
                ({
                auto [tys_pk, cols_pl] = crate::prelude::or_(crate::prelude::index(distinct_p6xy, k_pb), std::tuple{Array<std::tuple<Text, crate::check::types::Ty>>{}, Array<std::tuple<Text, crate::check::types::Col>>{}});
                auto lxk_pc = at_instance_f(lx_p0xy, std::tuple{tys_pk, cols_pl});
                auto rk_pd = one_p7xy ? rs_p8xy : prism_rtl::cat(rs_p8xy, "w", k_pb);
                auto bkey_pe = k_pb == Nat(0u) ? nkey_p5xy : prism_rtl::cat(nkey_p5xy, "#inst", k_pb);
                (crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lxk_pc, crate::lower::types::peel_f(crate::lower::binder_ty_f(lxk_pc, prism_rtl::deref(n_p2xy).span_p))), [=, rk_pd = std::move(rk_pd), bkey_pe = std::move(bkey_pe)](crate::lower::model::OutTy out_ty_of_f_74656) {
                return ({
                    auto bt_pf = out_ty_of_f_74656;
                    (crate::prelude::call_then(start_value_of_f(lxk_pc, env_p1xy, x_p4xy), [=, bt_pf = std::move(bt_pf)](crate::lower::types::Vl value_of_f_74715) {
                    return ({
                        auto v_pg = value_of_f_74715;
                        auto en1_ph = crate::lower::types::bind_f(en_pa, bkey_pe, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rk_pd}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt_pf}));
                        auto en2_pi = ({
                            crate::lower::types::Env this_ = en1_ph;
                            this_.uses_p = crate::prelude::insert(this_.uses_p, prism_rtl::cat(nkey_p5xy, "#", crate::prelude::show_text(std::tuple{tys_pk, cols_pl})), bkey_pe);
                            (std::move(this_));
                        });
                        auto d_pj = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{rk_pd}), crate::lower::types::own_f(v_pg)});
                        (prism_rtl::finished(std::tuple{crate::prelude::push(dos_p9, d_pj), en2_pi}));
                    });
                }));
                });
            }));
            });
            });
        })));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> GenericLet::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& n_p2 = this->n_p2;
    const auto& gn_p3 = this->gn_p3;
    const auto& x_p4 = this->x_p4;
    auto nkey_p5 = crate::check::env::sname_key_f(n_p2);
    auto env_p1x = env_p1;
    auto gn_p3x = gn_p3;
    auto lx_p0x = lx_p0;
    auto n_p2x = n_p2;
    auto x_p4x = x_p4;
    return crate::prelude::call_then(start_instantiations_f(lx_p0x, gn_p3x), [=](Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> instantiations_f_74265) {
        return ({
            auto distinct_p6 = instantiations_f_74265;
            auto one_p7 = crate::prelude::len(distinct_p6) == Nat(1u);
            (crate::prelude::call_then(crate::lower::start_local_name_at_f(lx_p0x, nkey_p5, prism_rtl::deref(n_p2x).span_p), [=, distinct_p6 = std::move(distinct_p6), one_p7 = std::move(one_p7)](Text local_name_at_f_74334) {
            return ({
                auto rs_p8 = local_name_at_f_74334;
                (crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(distinct_p6)), std::tuple{Array<crate::lower::model::Do>{}, env_p1x}, ({
                auto distinct_p6x = distinct_p6;
                auto lx_p0xx = lx_p0x;
                auto one_p7x = one_p7;
                auto rs_p8x = rs_p8;
                auto nkey_p5x = nkey_p5;
                auto n_p2xx = n_p2x;
                auto env_p1xx = env_p1x;
                auto x_p4xx = x_p4x;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>>(std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>, Nat>)>>(prism_rtl::rc([=, distinct_p6x = std::move(distinct_p6x), lx_p0xx = std::move(lx_p0xx), one_p7x = std::move(one_p7x), rs_p8x = std::move(rs_p8x), nkey_p5x = std::move(nkey_p5x), n_p2xx = std::move(n_p2xx), env_p1xx = std::move(env_p1xx), x_p4xx = std::move(x_p4xx)](std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto distinct_p6xy = distinct_p6x;
                    auto lx_p0xxy = lx_p0xx;
                    auto one_p7xy = one_p7x;
                    auto rs_p8xy = rs_p8x;
                    auto nkey_p5xy = nkey_p5x;
                    auto n_p2xxy = n_p2xx;
                    auto env_p1xxy = env_p1xx;
                    auto x_p4xxy = x_p4xx;
                    (crate::prelude::entered(crate::prelude::once_job([=, distinct_p6xy = std::move(distinct_p6xy), lx_p0xxy = std::move(lx_p0xxy), one_p7xy = std::move(one_p7xy), rs_p8xy = std::move(rs_p8xy), nkey_p5xy = std::move(nkey_p5xy), n_p2xxy = std::move(n_p2xxy), env_p1xxy = std::move(env_p1xxy), x_p4xxy = std::move(x_p4xxy)]() {
                    return ({
                        auto [dos_p9, en_pa] = p0;
                        auto k_pb = p1;
                        ({
                        auto [tys_pk, cols_pl] = crate::prelude::or_(crate::prelude::index(distinct_p6xy, k_pb), std::tuple{Array<std::tuple<Text, crate::check::types::Ty>>{}, Array<std::tuple<Text, crate::check::types::Col>>{}});
                        auto lxk_pc = at_instance_f(lx_p0xxy, std::tuple{tys_pk, cols_pl});
                        auto rk_pd = one_p7xy ? rs_p8xy : prism_rtl::cat(rs_p8xy, "w", k_pb);
                        auto bkey_pe = k_pb == Nat(0u) ? nkey_p5xy : prism_rtl::cat(nkey_p5xy, "#inst", k_pb);
                        (crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lxk_pc, crate::lower::types::peel_f(crate::lower::binder_ty_f(lxk_pc, prism_rtl::deref(n_p2xxy).span_p))), [=, rk_pd = std::move(rk_pd), bkey_pe = std::move(bkey_pe)](crate::lower::model::OutTy out_ty_of_f_74656) {
                        return ({
                            auto bt_pf = out_ty_of_f_74656;
                            (crate::prelude::call_then(start_value_of_f(lxk_pc, env_p1xxy, x_p4xxy), [=, bt_pf = std::move(bt_pf)](crate::lower::types::Vl value_of_f_74715) {
                            return ({
                                auto v_pg = value_of_f_74715;
                                auto en1_ph = crate::lower::types::bind_f(en_pa, bkey_pe, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rk_pd}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt_pf}));
                                auto en2_pi = ({
                                    crate::lower::types::Env this_ = en1_ph;
                                    this_.uses_p = crate::prelude::insert(this_.uses_p, prism_rtl::cat(nkey_p5xy, "#", crate::prelude::show_text(std::tuple{tys_pk, cols_pl})), bkey_pe);
                                    (std::move(this_));
                                });
                                auto d_pj = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{rk_pd}), crate::lower::types::own_f(v_pg)});
                                (prism_rtl::finished(std::tuple{crate::prelude::push(dos_p9, d_pj), en2_pi}));
                            });
                        }));
                        });
                    }));
                    });
                    });
                })));
                });
            }));
            }))->cycle());
            });
        }));
        });
    });
}


/// `Start GenericLet, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> start_generic_let_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::SName n_p2, crate::check::typed::GenNote gn_p3, crate::syntax::Expr x_p4) {
    return prism_rtl::make_rc<GenericLet>(lx_p0, env_p1, n_p2, gn_p3, x_p4);
}


/// Instantiations: unbounded fn Lx, GenNote -> [(([((Text, Ty))], [((Text, Col))]))]
Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> instantiations_f(const crate::lower::Lx& lx_p0, const crate::check::typed::GenNote& gn_p1) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::or_(crate::prelude::get(lx_p0.insts_p, gen_key_f(gn_p1)), Array<crate::check::typed::InstNote>{}), Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>{}, ({
        auto lx_p0x = lx_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>(std::tuple<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>, crate::check::typed::InstNote>)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x)](std::tuple<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>, crate::check::typed::InstNote> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0xy = lx_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy)]() {
            return ({
                auto acc_p2 = p0;
                auto u_p3 = p1;
                (crate::prelude::call_then(start_expanded_f(lx_p0xy, inst_at_f(lx_p0xy, u_p3)), [=, acc_p2 = std::move(acc_p2)](Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> expanded_f_75380) {
                return prism_rtl::finished(crate::prelude::fold(expanded_f_75380, acc_p2, [&](const Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>& a_p4, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& i_p5) {
                    return crate::prelude::fold(a_p4, false, [&](const bool& seen_p6, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& j_p7) { return prism_rtl::deref(seen_p6) || (crate::prelude::show_text(j_p7) == crate::prelude::show_text(i_p5)); })
                        ? a_p4
                        : crate::prelude::push(a_p4, i_p5);
                }));
            }));
            });
        })));
        });
    }));
    })));
}


prism_rtl::Turn<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> Instantiations::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& gn_p1 = this->gn_p1;
    return crate::prelude::fold_job(crate::prelude::or_(crate::prelude::get(prism_rtl::deref(lx_p0).insts_p, gen_key_f(gn_p1)), Array<crate::check::typed::InstNote>{}), Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>{}, ({
        auto lx_p0x = lx_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>(std::tuple<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>, crate::check::typed::InstNote>)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x)](std::tuple<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>, crate::check::typed::InstNote> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0xy = lx_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy)]() {
            return ({
                auto acc_p2 = p0;
                auto u_p3 = p1;
                (crate::prelude::call_then(start_expanded_f(lx_p0xy, inst_at_f(lx_p0xy, u_p3)), [=, acc_p2 = std::move(acc_p2)](Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> expanded_f_75380) {
                return prism_rtl::finished(crate::prelude::fold(expanded_f_75380, acc_p2, [&](const Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>& a_p4, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& i_p5) {
                    return crate::prelude::fold(a_p4, false, [&](const bool& seen_p6, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& j_p7) { return prism_rtl::deref(seen_p6) || (crate::prelude::show_text(j_p7) == crate::prelude::show_text(i_p5)); })
                        ? a_p4
                        : crate::prelude::push(a_p4, i_p5);
                }));
            }));
            });
        })));
        });
    }));
    }))->cycle();
}


/// `Start Instantiations, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> start_instantiations_f(crate::lower::Lx lx_p0, crate::check::typed::GenNote gn_p1) {
    return prism_rtl::make_rc<Instantiations>(lx_p0, gn_p1);
}


/// Expanded: unbounded fn Lx, (([((Text, Ty))], [((Text, Col))])) -> [(([((Text, Ty))], [((Text, Col))]))]
Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> expanded_f(const crate::lower::Lx& lx_p0, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& i_p1) {
    auto&& _m = open_q_o(lx_p0, i_p1);
    if (prism_rtl::is_none(_m)) {
        return Array(std::vector{i_p1});
    }
    if (prism_rtl::is_some(_m)) {
        auto&& q_p2 = prism_rtl::some_of(_m);
        auto&& _m = crate::prelude::get(lx_p0.gen_of_q_p, q_p2);
        if (prism_rtl::is_some(_m)) {
            auto&& g_p3 = prism_rtl::some_of(_m);
            return crate::prelude::run_to_end(crate::prelude::fold_job(instantiations_f(lx_p0, g_p3), Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>{}, ({
                auto lx_p0x = lx_p0;
                auto i_p1x = i_p1;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>(std::tuple<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>, std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), i_p1x = std::move(i_p1x)](std::tuple<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>, std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto lx_p0xy = lx_p0x;
                    auto i_p1xy = i_p1x;
                    (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), i_p1xy = std::move(i_p1xy)]() {
                    return ({
                        auto acc_p4 = p0;
                        auto gi_p5 = p1;
                        ({
                        auto lx2_p6 = at_instance_f(lx_p0xy, gi_p5);
                        (crate::prelude::call_then(start_expanded_f(lx2_p6, subst_inst_f(lx2_p6, i_p1xy)), [=](Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> expanded_f_75813) { return prism_rtl::finished(crate::prelude::append(acc_p4, expanded_f_75813)); }));
                    });
                    });
                })));
                });
            }));
            })));
        }
        if (prism_rtl::is_none(_m)) {
            return Array(std::vector{i_p1});
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> Expanded::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& i_p1 = this->i_p1;
    auto i_p1x = i_p1;
    auto lx_p0x = lx_p0;
    return crate::prelude::call_then(start_open_q_o(lx_p0x, i_p1x), [=](std::optional<Text> open_q_o_75631) {
        return ({
            prism_rtl::is_none(open_q_o_75631) ? prism_rtl::finished(Array(std::vector{i_p1x}))
            : prism_rtl::is_some(open_q_o_75631) ? ({
            auto&& q_p2 = prism_rtl::some_of(open_q_o_75631);
            ({
            auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0x).gen_of_q_p, q_p2);
            prism_rtl::is_some(_m) ? ({
            auto&& g_p3 = prism_rtl::some_of(_m);
            crate::prelude::call_then(start_instantiations_f(lx_p0x, g_p3), [=](Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> instantiations_f_75708) {
            return crate::prelude::fold_job(instantiations_f_75708, Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>{}, ({
                auto lx_p0xx = lx_p0x;
                auto i_p1xx = i_p1x;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>(std::tuple<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>, std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>)>>(prism_rtl::rc([=, lx_p0xx = std::move(lx_p0xx), i_p1xx = std::move(i_p1xx)](std::tuple<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>, std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto lx_p0xxy = lx_p0xx;
                    auto i_p1xxy = i_p1xx;
                    (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxy = std::move(lx_p0xxy), i_p1xxy = std::move(i_p1xxy)]() {
                    return ({
                        auto acc_p4 = p0;
                        auto gi_p5 = p1;
                        ({
                        auto lx2_p6 = at_instance_f(lx_p0xxy, gi_p5);
                        (crate::prelude::call_then(start_expanded_f(lx2_p6, subst_inst_f(lx2_p6, i_p1xxy)), [=](Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> expanded_f_75813) { return prism_rtl::finished(crate::prelude::append(acc_p4, expanded_f_75813)); }));
                    });
                    });
                })));
                });
            }));
            }))->cycle();
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(Array(std::vector{i_p1x}))
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
    });
}


/// `Start Expanded, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> start_expanded_f(crate::lower::Lx lx_p0, std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>> i_p1) {
    return prism_rtl::make_rc<Expanded>(lx_p0, i_p1);
}


/// SubstInst: fn Lx, (([((Text, Ty))], [((Text, Col))])) -> (([((Text, Ty))], [((Text, Col))]))
std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>> subst_inst_f(const crate::lower::Lx& lx_p0, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& arg1) {
    {
        auto&& tys_p1 = std::get<0>(arg1);
        auto&& cols_p2 = std::get<1>(arg1);
        auto tys2_p3 = crate::prelude::each(tys_p1, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
            auto&& q_p5 = std::get<0>(_p0);
            auto&& t_p6 = std::get<1>(_p0);
            return std::tuple{q_p5, crate::lower::subst_ty_f(lx_p0, t_p6)};
        });
        auto cols2_p4 = crate::prelude::each(cols_p2, [&](const std::tuple<Text, crate::check::types::Col>& _p0) {
            auto&& q_p7 = std::get<0>(_p0);
            auto&& c_p8 = std::get<1>(_p0);
            return std::tuple{q_p7, crate::lower::inst_col_f(lx_p0, c_p8)};
        });
        return std::tuple{tys2_p3, cols2_p4};
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?OpenQ: unbounded fn Lx, (([((Text, Ty))], [((Text, Col))])) -> ?Text
std::optional<Text> open_q_o(const crate::lower::Lx& lx_p0, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& arg1) {
    {
        auto&& tys_p1 = std::get<0>(arg1);
        auto&& cols_p2 = std::get<1>(arg1);
        auto from_cols_p5 = crate::prelude::fold(cols_p2, Array<Text>{}, [&](const Array<Text>& acc_p3, const std::tuple<Text, crate::check::types::Col>& _p1) {
            auto&& c_p4 = std::get<1>(_p1);
            return crate::prelude::append(acc_p3, open_cols_f(lx_p0, c_p4));
        });
        auto all_p8 = crate::prelude::run_to_end(crate::prelude::fold_job(tys_p1, from_cols_p5, ({
            auto lx_p0x = lx_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, std::tuple<Text, crate::check::types::Ty>>)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x)](std::tuple<Array<Text>, std::tuple<Text, crate::check::types::Ty>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_p0xy = lx_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy)]() {
                return ({
                    auto acc_p6 = p0;
                    auto&& _t_p7 = p1;
                    auto&& t_p7 = std::get<1>(_t_p7);
                    (crate::prelude::call_then(start_open_ty_qs_f(lx_p0xy, t_p7), [=, acc_p6 = std::move(acc_p6)](Array<Text> open_ty_qs_f_76494) { return prism_rtl::finished(crate::prelude::append(acc_p6, open_ty_qs_f_76494)); }));
                });
            })));
            });
        })));
        })));
        return crate::prelude::index(all_p8, Nat(0u));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::optional<Text>> OpenQ::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& arg1 = this->arg1;
    return ({
        ({
        auto&& tys_p1 = std::get<0>(arg1);
        auto&& cols_p2 = std::get<1>(arg1);
        ({
        auto from_cols_p5 = crate::prelude::fold(cols_p2, Array<Text>{}, [&](const Array<Text>& acc_p3, const std::tuple<Text, crate::check::types::Col>& _p1) {
            auto&& c_p4 = std::get<1>(_p1);
            return crate::prelude::append(acc_p3, open_cols_f(lx_p0, c_p4));
        });
        auto lx_p0x = lx_p0;
        auto tys_p1x = tys_p1;
        (crate::prelude::call_value(crate::prelude::fold_job(tys_p1x, from_cols_p5, ({
        auto lx_p0xx = lx_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, std::tuple<Text, crate::check::types::Ty>>)>>(prism_rtl::rc([=, lx_p0xx = std::move(lx_p0xx)](std::tuple<Array<Text>, std::tuple<Text, crate::check::types::Ty>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0xxy = lx_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxy = std::move(lx_p0xxy)]() {
            return ({
                auto acc_p6 = p0;
                auto&& _t_p7 = p1;
                auto&& t_p7 = std::get<1>(_t_p7);
                (crate::prelude::call_then(start_open_ty_qs_f(lx_p0xxy, t_p7), [=, acc_p6 = std::move(acc_p6)](Array<Text> open_ty_qs_f_76494) { return prism_rtl::finished(crate::prelude::append(acc_p6, open_ty_qs_f_76494)); }));
            });
        })));
        });
    })));
    })), [=](Array<Text> fold_76439) {
        return ({
            auto all_p8 = fold_76439;
            (prism_rtl::finished(crate::prelude::index(all_p8, Nat(0u))));
        });
    }));
    });
    });
    });
}


/// `Start OpenQ, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Text>> start_open_q_o(crate::lower::Lx lx_p0, std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>> arg1) {
    return prism_rtl::make_rc<OpenQ>(lx_p0, arg1);
}


/// OpenCols: fn Lx, Col -> [Text]
Array<Text> open_cols_f(const crate::lower::Lx& lx_p0, const crate::check::types::Col& col1) {
    if (prism_rtl::is<crate::check::types::Col::CQ>(col1)) {
        auto&& q_p1 = prism_rtl::as<crate::check::types::Col::CQ>(col1).a0;
        return crate::check::env::has_key_f(lx_p0.gen_of_q_p, q_p1) && (!crate::check::env::has_key_f(lx_p0.csubst_p, q_p1))
            ? Array(std::vector{q_p1})
            : Array<Text>{};
    }
    {
        auto&& c_p3 = col1;
        return Array<Text>{};
    }
}


/// OpenTyQs: unbounded fn Lx, Ty -> [Text]
Array<Text> open_ty_qs_f(const crate::lower::Lx& lx_p0, const crate::check::types::Ty& t_p1) {
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(t_p1)) {
        auto&& n_p2 = prism_rtl::as<crate::check::types::Ty::TyFlex>(t_p1).a0;
        return crate::check::env::has_key_f(lx_p0.gen_of_q_p, prism_rtl::cat("\'", n_p2)) && (!crate::check::env::has_key_f(lx_p0.subst_p, prism_rtl::cat("\'", n_p2)))
            ? Array(std::vector{prism_rtl::cat("\'", n_p2)})
            : Array<Text>{};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p1)) {
        auto&& c_p3 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a0;
        auto&& ps_p4 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a1;
        auto&& res_p5 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a2;
        return crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::push(ps_p4, prism_rtl::deref(prism_rtl::deref(res_p5))), open_cols_f(lx_p0, c_p3), ({
            auto lx_p0x = lx_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x)](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_p0xy = lx_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy)]() {
                return ({
                    auto acc_p6 = p0;
                    auto x_p7 = p1;
                    (crate::prelude::call_then(start_open_ty_qs_f(lx_p0xy, x_p7), [=, acc_p6 = std::move(acc_p6)](Array<Text> open_ty_qs_f_76930) { return prism_rtl::finished(crate::prelude::append(acc_p6, open_ty_qs_f_76930)); }));
                });
            })));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1)) {
        auto&& args_p8 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        return crate::prelude::run_to_end(crate::prelude::fold_job(args_p8, Array<Text>{}, ({
            auto lx_p0x = lx_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x)](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_p0xy = lx_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy)]() {
                return ({
                    auto acc_p9 = p0;
                    auto x_pa = p1;
                    (crate::prelude::call_then(start_open_ty_qs_f(lx_p0xy, x_pa), [=, acc_p9 = std::move(acc_p9)](Array<Text> open_ty_qs_f_77010) { return prism_rtl::finished(crate::prelude::append(acc_p9, open_ty_qs_f_77010)); }));
                });
            })));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p1)) {
        auto&& ts_pb = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p1).a0;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ts_pb, Array<Text>{}, ({
            auto lx_p0x = lx_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x)](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_p0xy = lx_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy)]() {
                return ({
                    auto acc_pc = p0;
                    auto x_pd = p1;
                    (crate::prelude::call_then(start_open_ty_qs_f(lx_p0xy, x_pd), [=, acc_pc = std::move(acc_pc)](Array<Text> open_ty_qs_f_77080) { return prism_rtl::finished(crate::prelude::append(acc_pc, open_ty_qs_f_77080)); }));
                });
            })));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p1)) {
        auto&& e_pe = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p1).a0;
        return open_ty_qs_f(lx_p0, prism_rtl::deref(prism_rtl::deref(e_pe)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p1)) {
        auto&& k_pf = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a0;
        auto&& v_pg = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a1;
        return crate::prelude::append(open_ty_qs_f(lx_p0, prism_rtl::deref(prism_rtl::deref(k_pf))), open_ty_qs_f(lx_p0, prism_rtl::deref(prism_rtl::deref(v_pg))));
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p1)) {
        auto&& i_ph = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        return open_ty_qs_f(lx_p0, prism_rtl::deref(prism_rtl::deref(i_ph)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p1)) {
        auto&& i_pi = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p1).a0;
        return open_ty_qs_f(lx_p0, prism_rtl::deref(prism_rtl::deref(i_pi)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t_p1)) {
        auto&& o_pj = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p1).a1;
        return open_ty_qs_f(lx_p0, prism_rtl::deref(prism_rtl::deref(o_pj)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p1)) {
        auto&& a_pk = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p1).a1;
        return open_ty_qs_f(lx_p0, prism_rtl::deref(prism_rtl::deref(a_pk)));
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> OpenTyQs::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& t_p1 = this->t_p1;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyFlex>(t_p1) ? ({
        auto&& n_p2 = prism_rtl::as<crate::check::types::Ty::TyFlex>(t_p1).a0;
        crate::check::env::has_key_f(prism_rtl::deref(lx_p0).gen_of_q_p, prism_rtl::cat("\'", n_p2)) && (!crate::check::env::has_key_f(prism_rtl::deref(lx_p0).subst_p, prism_rtl::cat("\'", n_p2)))
        ? prism_rtl::finished(Array(std::vector{prism_rtl::cat("\'", n_p2)}))
        : prism_rtl::finished(Array<Text>{});
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(t_p1) ? ({
        auto&& c_p3 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a0;
        auto&& ps_p4 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a1;
        auto&& res_p5 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a2;
        crate::prelude::fold_job(crate::prelude::push(ps_p4, prism_rtl::deref(prism_rtl::deref(res_p5))), open_cols_f(lx_p0, c_p3), ({
        auto lx_p0x = lx_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x)](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0xy = lx_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy)]() {
            return ({
                auto acc_p6 = p0;
                auto x_p7 = p1;
                (crate::prelude::call_then(start_open_ty_qs_f(lx_p0xy, x_p7), [=, acc_p6 = std::move(acc_p6)](Array<Text> open_ty_qs_f_76930) { return prism_rtl::finished(crate::prelude::append(acc_p6, open_ty_qs_f_76930)); }));
            });
        })));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1) ? ({
        auto&& args_p8 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        crate::prelude::fold_job(args_p8, Array<Text>{}, ({
        auto lx_p0x = lx_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x)](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0xy = lx_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy)]() {
            return ({
                auto acc_p9 = p0;
                auto x_pa = p1;
                (crate::prelude::call_then(start_open_ty_qs_f(lx_p0xy, x_pa), [=, acc_p9 = std::move(acc_p9)](Array<Text> open_ty_qs_f_77010) { return prism_rtl::finished(crate::prelude::append(acc_p9, open_ty_qs_f_77010)); }));
            });
        })));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p1) ? ({
        auto&& ts_pb = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p1).a0;
        crate::prelude::fold_job(ts_pb, Array<Text>{}, ({
        auto lx_p0x = lx_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x)](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0xy = lx_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy)]() {
            return ({
                auto acc_pc = p0;
                auto x_pd = p1;
                (crate::prelude::call_then(start_open_ty_qs_f(lx_p0xy, x_pd), [=, acc_pc = std::move(acc_pc)](Array<Text> open_ty_qs_f_77080) { return prism_rtl::finished(crate::prelude::append(acc_pc, open_ty_qs_f_77080)); }));
            });
        })));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t_p1) ? ({
        auto&& e_pe = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p1).a0;
        prism_rtl::more(prism_rtl::rc(OpenTyQs(lx_p0, prism_rtl::deref(prism_rtl::deref(e_pe)))));
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t_p1) ? ({
        auto&& k_pf = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a0;
        auto&& v_pg = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a1;
        ({
        auto k_pfx = prism_rtl::deref(prism_rtl::deref(k_pf));
        auto lx_p0x = lx_p0;
        auto v_pgx = prism_rtl::deref(prism_rtl::deref(v_pg));
        (crate::prelude::call_then(start_open_ty_qs_f(lx_p0x, k_pfx), [=, v_pgx = std::move(v_pgx)](Array<Text> open_ty_qs_f_77150) { return crate::prelude::call_then(start_open_ty_qs_f(lx_p0x, v_pgx), [=](Array<Text> open_ty_qs_f_77168) { return prism_rtl::finished(crate::prelude::append(open_ty_qs_f_77150, open_ty_qs_f_77168)); }); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t_p1) ? ({
        auto&& i_ph = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        prism_rtl::more(prism_rtl::rc(OpenTyQs(lx_p0, prism_rtl::deref(prism_rtl::deref(i_ph)))));
    })
        : prism_rtl::is<crate::check::types::Ty::TyAt>(t_p1) ? ({
        auto&& i_pi = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p1).a0;
        prism_rtl::more(prism_rtl::rc(OpenTyQs(lx_p0, prism_rtl::deref(prism_rtl::deref(i_pi)))));
    })
        : prism_rtl::is<crate::check::types::Ty::TyElem>(t_p1) ? ({
        auto&& o_pj = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p1).a1;
        prism_rtl::more(prism_rtl::rc(OpenTyQs(lx_p0, prism_rtl::deref(prism_rtl::deref(o_pj)))));
    })
        : prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p1) ? ({
        auto&& a_pk = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p1).a1;
        prism_rtl::more(prism_rtl::rc(OpenTyQs(lx_p0, prism_rtl::deref(prism_rtl::deref(a_pk)))));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start OpenTyQs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_open_ty_qs_f(crate::lower::Lx lx_p0, crate::check::types::Ty t_p1) {
    return prism_rtl::make_rc<OpenTyQs>(lx_p0, t_p1);
}


/// AtInstance: fn Lx, (([((Text, Ty))], [((Text, Col))])) -> Lx
crate::lower::Lx at_instance_f(const crate::lower::Lx& lx_p0, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& arg1) {
    {
        auto&& tys_p1 = std::get<0>(arg1);
        auto&& cols_p2 = std::get<1>(arg1);
        crate::lower::Lx this_ = lx_p0;
        this_.subst_p = crate::prelude::fold(tys_p1, this_.subst_p, [&](const Map<Text, crate::check::types::Ty>& m_p3, const std::tuple<Text, crate::check::types::Ty>& _p1) {
            auto&& q_p4 = std::get<0>(_p1);
            auto&& t_p5 = std::get<1>(_p1);
            return crate::prelude::insert(m_p3, q_p4, t_p5);
        });
        this_.csubst_p = crate::prelude::fold(cols_p2, this_.csubst_p, [&](const Map<Text, crate::check::types::Col>& m_p6, const std::tuple<Text, crate::check::types::Col>& _p1) {
            auto&& q_p7 = std::get<0>(_p1);
            auto&& c_p8 = std::get<1>(_p1);
            return crate::prelude::insert(m_p6, q_p7, c_p8);
        });
        return this_;
    }
    prism_rtl::unreachable("no arm matched");
}


/// WidgetLetLx: unbounded fn Lx, Range -> Lx
crate::lower::Lx widget_let_lx_f(const crate::lower::Lx& lx_p0, const crate::syntax::Range& span_p1) {
    auto&& _m = crate::prelude::get(lx_p0.gens_p, crate::lower::place_key_f(lx_p0, span_p1));
    if (prism_rtl::is_some(_m)) {
        auto&& gn_p2 = prism_rtl::some_of(_m);
        auto&& _m = instantiations_f(lx_p0, gn_p2);
        {
            auto&& m77989_0 = _m;
            if (m77989_0.size() == 1u) {
                {
                    auto&& _c1 = crate::prelude::index(m77989_0, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& i_p3 = prism_rtl::some_of(_c1);
                        return at_instance_f(lx_p0, i_p3);
                    }
                }
            }
        }
        {
            return lx_p0;
        }
    }
    if (prism_rtl::is_none(_m)) {
        return lx_p0;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::Lx> WidgetLetLx::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& span_p1 = this->span_p1;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0).gens_p, crate::lower::place_key_f(lx_p0, span_p1));
        prism_rtl::is_some(_m) ? ({
        auto&& gn_p2 = prism_rtl::some_of(_m);
        ({
        auto lx_p0x = lx_p0;
        (crate::prelude::call_then(start_instantiations_f(lx_p0x, gn_p2), [=](Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> instantiations_f_77995) {
        return ({
            ({
            auto&& m77989_0 = instantiations_f_77995;
            (m77989_0.size() == 1u) && ({
            auto&& _c1 = crate::prelude::index(m77989_0, Nat(0u));
            prism_rtl::is_some(_c1);
        });
        }) ? ({
            auto&& m77989_0 = instantiations_f_77995;
            auto&& _c1 = crate::prelude::index(m77989_0, Nat(0u));
            auto&& i_p3 = prism_rtl::some_of(_c1);
            prism_rtl::finished(at_instance_f(lx_p0x, i_p3));
        })
            : prism_rtl::finished(lx_p0x);
        });
    }));
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(lx_p0)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start WidgetLetLx, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::Lx> start_widget_let_lx_f(crate::lower::Lx lx_p0, crate::syntax::Range span_p1) {
    return prism_rtl::make_rc<WidgetLetLx>(lx_p0, span_p1);
}


/// InstAt: fn Lx, InstNote -> (([((Text, Ty))], [((Text, Col))]))
std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>> inst_at_f(const crate::lower::Lx& lx_p0, const crate::check::typed::InstNote& u_p1) {
    auto tys_p2 = crate::prelude::each(u_p1.tys_p, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
        auto&& q_p4 = std::get<0>(_p0);
        auto&& t_p5 = std::get<1>(_p0);
        return std::tuple{q_p4, crate::lower::subst_ty_f(lx_p0, t_p5)};
    });
    auto cols_p3 = crate::prelude::each(u_p1.cols_p, [&](const std::tuple<Text, crate::check::types::Col>& _p0) {
        auto&& q_p6 = std::get<0>(_p0);
        auto&& c_p7 = std::get<1>(_p0);
        return std::tuple{q_p6, crate::lower::inst_col_f(lx_p0, c_p7)};
    });
    return std::tuple{tys_p2, cols_p3};
}


/// GenKey: fn GenNote -> Text
Text gen_key_f(const crate::check::typed::GenNote& gn_p0) {
    return crate::prelude::or_(crate::prelude::index(crate::prelude::append(gn_p0.tys_p, gn_p0.cols_p), Nat(0u)), Text::lit(""));
}


/// InstKey: fn InstNote -> Text
Text inst_key_f(const crate::check::typed::InstNote& u_p0) {
    return crate::prelude::or_(crate::prelude::index(crate::prelude::append(crate::prelude::each(u_p0.tys_p, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
        auto&& q_p1 = std::get<0>(_p0);
        return q_p1;
    }), crate::prelude::each(u_p0.cols_p, [&](const std::tuple<Text, crate::check::types::Col>& _p0) {
        auto&& q_p2 = std::get<0>(_p0);
        return q_p2;
    })), Nat(0u)), Text::lit(""));
}


/// ColName: fn Col -> Text
Text col_name_f(const crate::check::types::Col& col0) {
    if (prism_rtl::is<crate::check::types::Col::CQ>(col0)) {
        auto&& q_p0 = prism_rtl::as<crate::check::types::Col::CQ>(col0).a0;
        return q_p0;
    }
    {
        auto&& c_p1 = col0;
        return Text::lit("");
    }
}


/// PlainLet: unbounded fn Lx, Env, Stmt, Pattern, Expr -> (([Do], Env))
std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> plain_let_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Stmt& s_p2, const crate::syntax::Pattern_& p_p3, const crate::syntax::Expr& x_p4) {
    auto v_p5 = value_of_f(lx_p0, env_p1, x_p4);
    auto po_p6 = crate::lower::patterns::rust_pat_f(lx_p0, p_p3, crate::lower::type_at_f(lx_p0, x_p4.span_p), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("l", prism_rtl::deref(s_p2.span_p).start_p));
    return std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{prism_rtl::deref(po_p6).pa_p, crate::lower::types::own_f(v_p5)})}), bind_all_f(env_p1, prism_rtl::deref(po_p6).binds_p)};
}


prism_rtl::Turn<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> PlainLet::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& s_p2 = this->s_p2;
    const auto& p_p3 = this->p_p3;
    const auto& x_p4 = this->x_p4;
    auto env_p1x = env_p1;
    auto lx_p0x = lx_p0;
    auto p_p3x = p_p3;
    auto s_p2x = s_p2;
    auto x_p4x = x_p4;
    return crate::prelude::call_then(start_value_of_f(lx_p0x, env_p1x, x_p4x), [=](crate::lower::types::Vl value_of_f_78780) {
        return ({
            auto v_p5 = value_of_f_78780;
            (crate::prelude::call_then(crate::lower::patterns::start_rust_pat_f(lx_p0x, p_p3x, crate::lower::type_at_f(lx_p0x, prism_rtl::deref(x_p4x).span_p), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("l", prism_rtl::deref(prism_rtl::deref(s_p2x).span_p).start_p)), [=, v_p5 = std::move(v_p5)](crate::lower::patterns::PatOut rust_pat_f_78816) {
            return ({
                auto po_p6 = rust_pat_f_78816;
                (prism_rtl::finished(std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{prism_rtl::deref(po_p6).pa_p, crate::lower::types::own_f(v_p5)})}), bind_all_f(env_p1x, prism_rtl::deref(po_p6).binds_p)}));
            });
        }));
        });
    });
}


/// `Start PlainLet, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> start_plain_let_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Stmt s_p2, crate::syntax::Pattern_ p_p3, crate::syntax::Expr x_p4) {
    return prism_rtl::make_rc<PlainLet>(lx_p0, env_p1, s_p2, p_p3, x_p4);
}

}  // namespace crate::lower::expr
