// The module `Lower.Expr`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <lower/expr/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Lower.Expr`, from `target/bootstrap/cpp-src/prismc/lower/expr.prism`.
namespace crate::lower::expr {

/// `Start PlainBlockValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_plain_block_value(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Block b_p2) {
    return prism_rtl::make_rc<PlainBlockValue>(lx_p0, env_p1, b_p2);
}


/// let dummyStmtL
crate::syntax::Stmt dummy_stmt_l() {
    return crate::syntax::Stmt{.kind = crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}}}), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// BlockStmt: unbounded fn Lx, Env, Stmt -> (([Do], Env))
std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> block_stmt(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Stmt& s_p2) {
    auto&& _m = s_p2.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_p3 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& x_p4 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p3).kind);
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            auto&& n_p5 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            auto&& _m = crate::prelude::get(lx_p0.gens, crate::lower::place_key(lx_p0, prism_rtl::deref(n_p5).span));
            if (prism_rtl::is_some(_m)) {
                auto&& gn_p6 = prism_rtl::some_of(_m);
                return generic_let(lx_p0, env_p1, n_p5, gn_p6, x_p4);
            }
            if (prism_rtl::is_none(_m)) {
                return plain_let(lx_p0, env_p1, s_p2, p_p3, x_p4);
            }
            prism_rtl::unreachable("no arm matched");
        }
        {
            return plain_let(lx_p0, env_p1, s_p2, p_p3, x_p4);
        }
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
        auto&& x_p7 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        return std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::types::own(value_of(lx_p0, env_p1, x_p7))})}), env_p1};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m)) {
        return std::tuple{Array<crate::lower::model::Do>{}, env_p1};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        auto&& f_p8 = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        return std::tuple{Array(std::vector{refusal_do(prism_rtl::cat("a local function ", crate::check::env::def_name_text(prism_rtl::deref(f_p8).name), ": not lowered yet"))}), env_p1};
    }
    {
        return std::tuple{Array(std::vector{refusal_do(Text::lit("a statement this back end does not lower yet"))}), env_p1};
    }
}


prism_rtl::Turn<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> BlockStmt::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& s_p2 = this->s_p2;
    return ({
        auto&& _m = prism_rtl::deref(s_p2).kind;
        prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& p_p3 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& x_p4 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p3).kind);
        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n_p5 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0).gens, crate::lower::place_key(lx_p0, prism_rtl::deref(n_p5).span));
        prism_rtl::is_some(_m) ? ({
        auto&& gn_p6 = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(GenericLet(lx_p0, env_p1, n_p5, gn_p6, x_p4)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(PlainLet(lx_p0, env_p1, s_p2, p_p3, x_p4)))
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::more(prism_rtl::rc(PlainLet(lx_p0, env_p1, s_p2, p_p3, x_p4)));
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
        auto&& x_p7 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        ({
        auto env_p1_1 = env_p1;
        auto lx_p0_2 = lx_p0;
        auto x_p7_3 = x_p7;
        call_then(start_value_of(lx_p0_2, env_p1_1, x_p7_3), [=](crate::lower::types::Vl value_of_70316) { return prism_rtl::finished(std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::types::own(value_of_70316)})}), env_p1_1}); });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m) ? prism_rtl::finished(std::tuple{Array<crate::lower::model::Do>{}, env_p1})
        : prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? ({
        auto&& f_p8 = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        prism_rtl::finished(std::tuple{Array(std::vector{refusal_do(prism_rtl::cat("a local function ", crate::check::env::def_name_text(prism_rtl::deref(f_p8).name), ": not lowered yet"))}), env_p1});
    })
        : prism_rtl::finished(std::tuple{Array(std::vector{refusal_do(Text::lit("a statement this back end does not lower yet"))}), env_p1});
    });
}


/// `Start BlockStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> start_block_stmt(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Stmt s_p2) {
    return prism_rtl::make_rc<BlockStmt>(lx_p0, env_p1, s_p2);
}


/// GenericLet: unbounded fn Lx, Env, SName, GenNote, Expr -> (([Do], Env))
std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> generic_let(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::SName& n_p2, const crate::check::typed::GenNote& gn_p3, const crate::syntax::Expr& x_p4) {
    auto nkey_p5 = crate::check::env::sname_key(n_p2);
    auto distinct_p6 = instantiations(lx_p0, gn_p3);
    auto one_p7 = len(distinct_p6) == Nat(1u);
    auto rs_p8 = crate::lower::local_name_at(lx_p0, nkey_p5, n_p2.span);
    return run_to_end(fold_job(crate::check::errors::range0(len(distinct_p6)), std::tuple{Array<crate::lower::model::Do>{}, env_p1}, ({
        auto distinct_p6_1 = distinct_p6;
        auto lx_p0_2 = lx_p0;
        auto one_p7_3 = std::move(one_p7);
        auto rs_p8_4 = rs_p8;
        auto nkey_p5_5 = nkey_p5;
        auto n_p2_6 = n_p2;
        auto env_p1_7 = env_p1;
        auto x_p4_8 = x_p4;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>>(std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>, Nat>)>>(prism_rtl::rc([=, distinct_p6_1 = std::move(distinct_p6_1), lx_p0_2 = std::move(lx_p0_2), one_p7_3 = std::move(one_p7_3), rs_p8_4 = std::move(rs_p8_4), nkey_p5_5 = std::move(nkey_p5_5), n_p2_6 = std::move(n_p2_6), env_p1_7 = std::move(env_p1_7), x_p4_8 = std::move(x_p4_8)](std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto distinct_p6_1_9 = distinct_p6_1;
            auto lx_p0_2_9 = lx_p0_2;
            auto one_p7_3_9 = one_p7_3;
            auto rs_p8_4_9 = rs_p8_4;
            auto nkey_p5_5_9 = nkey_p5_5;
            auto n_p2_6_9 = n_p2_6;
            auto env_p1_7_9 = env_p1_7;
            auto x_p4_8_9 = x_p4_8;
            entered(once_job([=, distinct_p6_1_9 = std::move(distinct_p6_1_9), lx_p0_2_9 = std::move(lx_p0_2_9), one_p7_3_9 = std::move(one_p7_3_9), rs_p8_4_9 = std::move(rs_p8_4_9), nkey_p5_5_9 = std::move(nkey_p5_5_9), n_p2_6_9 = std::move(n_p2_6_9), env_p1_7_9 = std::move(env_p1_7_9), x_p4_8_9 = std::move(x_p4_8_9)]() {
            return ({
                auto [dos_p9, en_pa] = p0;
                auto k_pb = p1;
                ({
                auto [tys_pk, cols_pl] = or_(index(distinct_p6_1_9, k_pb), std::tuple{Array<std::tuple<Text, crate::check::types::Ty>>{}, Array<std::tuple<Text, crate::check::types::Col>>{}});
                auto lxk_pc = at_instance(lx_p0_2_9, std::tuple{tys_pk, cols_pl});
                auto rk_pd = one_p7_3_9 ? rs_p8_4_9 : prism_rtl::cat(rs_p8_4_9, "w", k_pb);
                auto bkey_pe = k_pb == Nat(0u) ? nkey_p5_5_9 : prism_rtl::cat(nkey_p5_5_9, "#inst", k_pb);
                call_then(crate::lower::types::start_out_ty_of(lxk_pc, crate::lower::types::peel(crate::lower::binder_ty(lxk_pc, n_p2_6_9.span))), [=, rk_pd = std::move(rk_pd), bkey_pe = std::move(bkey_pe)](crate::lower::model::OutTy out_ty_of_71488) {
                return ({
                    auto bt_pf = out_ty_of_71488;
                    call_then(start_value_of(lxk_pc, env_p1_7_9, x_p4_8_9), [=, bt_pf = std::move(bt_pf)](crate::lower::types::Vl value_of_71547) {
                    return ({
                        auto v_pg = value_of_71547;
                        auto en1_ph = crate::lower::types::bind(en_pa, bkey_pe, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rk_pd}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt_pf}));
                        auto en2_pi = ({
                            crate::lower::types::Env this_ = en1_ph;
                            this_.uses = insert(this_.uses, prism_rtl::cat(nkey_p5_5_9, "#", show_text(std::tuple{tys_pk, cols_pl})), bkey_pe);
                            (std::move(this_));
                        });
                        auto d_pj = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{rk_pd}), crate::lower::types::own(v_pg)});
                        (prism_rtl::finished(std::tuple{crate::prelude::push(dos_p9, d_pj), en2_pi}));
                    });
                });
                });
            });
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> GenericLet::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& n_p2 = this->n_p2;
    const auto& gn_p3 = this->gn_p3;
    const auto& x_p4 = this->x_p4;
    auto nkey_p5 = crate::check::env::sname_key(n_p2);
    auto env_p1_1 = env_p1;
    auto gn_p3_2 = gn_p3;
    auto lx_p0_3 = lx_p0;
    auto n_p2_4 = n_p2;
    auto x_p4_5 = x_p4;
    return call_then(start_instantiations(lx_p0_3, gn_p3_2), [=](Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> instantiations_71097) {
        return ({
            auto distinct_p6 = instantiations_71097;
            auto one_p7 = len(distinct_p6) == Nat(1u);
            call_then(crate::lower::start_local_name_at(lx_p0_3, nkey_p5, prism_rtl::deref(n_p2_4).span), [=, distinct_p6 = std::move(distinct_p6), one_p7 = std::move(one_p7)](Text local_name_at_71166) {
            return ({
                auto rs_p8 = local_name_at_71166;
                fold_job(crate::check::errors::range0(len(distinct_p6)), std::tuple{Array<crate::lower::model::Do>{}, env_p1_1}, ({
                auto distinct_p6_6 = distinct_p6;
                auto lx_p0_3_7 = lx_p0_3;
                auto one_p7_7 = one_p7;
                auto rs_p8_8 = rs_p8;
                auto nkey_p5_9 = nkey_p5;
                auto n_p2_4_10 = n_p2_4;
                auto env_p1_1_10 = env_p1_1;
                auto x_p4_5_10 = x_p4_5;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>>(std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>, Nat>)>>(prism_rtl::rc([=, distinct_p6_6 = std::move(distinct_p6_6), lx_p0_3_7 = std::move(lx_p0_3_7), one_p7_7 = std::move(one_p7_7), rs_p8_8 = std::move(rs_p8_8), nkey_p5_9 = std::move(nkey_p5_9), n_p2_4_10 = std::move(n_p2_4_10), env_p1_1_10 = std::move(env_p1_1_10), x_p4_5_10 = std::move(x_p4_5_10)](std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto distinct_p6_6_10 = distinct_p6_6;
                    auto lx_p0_3_7_10 = lx_p0_3_7;
                    auto one_p7_7_10 = one_p7_7;
                    auto rs_p8_8_10 = rs_p8_8;
                    auto nkey_p5_9_10 = nkey_p5_9;
                    auto n_p2_4_10_10 = n_p2_4_10;
                    auto env_p1_1_10_10 = env_p1_1_10;
                    auto x_p4_5_10_10 = x_p4_5_10;
                    entered(once_job([=, distinct_p6_6_10 = std::move(distinct_p6_6_10), lx_p0_3_7_10 = std::move(lx_p0_3_7_10), one_p7_7_10 = std::move(one_p7_7_10), rs_p8_8_10 = std::move(rs_p8_8_10), nkey_p5_9_10 = std::move(nkey_p5_9_10), n_p2_4_10_10 = std::move(n_p2_4_10_10), env_p1_1_10_10 = std::move(env_p1_1_10_10), x_p4_5_10_10 = std::move(x_p4_5_10_10)]() {
                    return ({
                        auto [dos_p9, en_pa] = p0;
                        auto k_pb = p1;
                        ({
                        auto [tys_pk, cols_pl] = or_(index(distinct_p6_6_10, k_pb), std::tuple{Array<std::tuple<Text, crate::check::types::Ty>>{}, Array<std::tuple<Text, crate::check::types::Col>>{}});
                        auto lxk_pc = at_instance(lx_p0_3_7_10, std::tuple{tys_pk, cols_pl});
                        auto rk_pd = one_p7_7_10 ? rs_p8_8_10 : prism_rtl::cat(rs_p8_8_10, "w", k_pb);
                        auto bkey_pe = k_pb == Nat(0u)
                            ? nkey_p5_9_10
                            : prism_rtl::cat(nkey_p5_9_10, "#inst", k_pb);
                        call_then(crate::lower::types::start_out_ty_of(lxk_pc, crate::lower::types::peel(crate::lower::binder_ty(lxk_pc, prism_rtl::deref(n_p2_4_10_10).span))), [=, rk_pd = std::move(rk_pd), bkey_pe = std::move(bkey_pe)](crate::lower::model::OutTy out_ty_of_71488) {
                        return ({
                            auto bt_pf = out_ty_of_71488;
                            call_then(start_value_of(lxk_pc, env_p1_1_10_10, x_p4_5_10_10), [=, bt_pf = std::move(bt_pf)](crate::lower::types::Vl value_of_71547) {
                            return ({
                                auto v_pg = value_of_71547;
                                auto en1_ph = crate::lower::types::bind(en_pa, bkey_pe, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rk_pd}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt_pf}));
                                auto en2_pi = ({
                                    crate::lower::types::Env this_ = en1_ph;
                                    this_.uses = insert(this_.uses, prism_rtl::cat(nkey_p5_9_10, "#", show_text(std::tuple{tys_pk, cols_pl})), bkey_pe);
                                    (std::move(this_));
                                });
                                auto d_pj = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{rk_pd}), crate::lower::types::own(v_pg)});
                                (prism_rtl::finished(std::tuple{crate::prelude::push(dos_p9, d_pj), en2_pi}));
                            });
                        });
                        });
                    });
                    });
                    });
                }));
                });
            }));
            }))->cycle();
            });
        });
        });
    });
}


/// `Start GenericLet, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> start_generic_let(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::SName n_p2, crate::check::typed::GenNote gn_p3, crate::syntax::Expr x_p4) {
    return prism_rtl::make_rc<GenericLet>(lx_p0, env_p1, n_p2, gn_p3, x_p4);
}


/// Instantiations: unbounded fn Lx, GenNote -> [(([((Text, Ty))], [((Text, Col))]))]
Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> instantiations(const crate::lower::Lx& lx_p0, const crate::check::typed::GenNote& gn_p1) {
    return run_to_end(fold_job(or_(crate::prelude::get(lx_p0.insts, gen_key(gn_p1)), Array<crate::check::typed::InstNote>{}), Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>{}, ({
        auto lx_p0_1 = lx_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>(std::tuple<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>, crate::check::typed::InstNote>)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1)](std::tuple<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>, crate::check::typed::InstNote> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0_1_2 = lx_p0_1;
            entered(once_job([=, lx_p0_1_2 = std::move(lx_p0_1_2)]() {
            return ({
                auto acc_p2 = p0;
                auto u_p3 = p1;
                call_then(start_expanded(lx_p0_1_2, inst_at(lx_p0_1_2, u_p3)), [=, acc_p2 = std::move(acc_p2)](Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> expanded_72212) {
                return prism_rtl::finished(fold(expanded_72212, acc_p2, [&](const Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>& a_p4, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& i_p5) {
                    return fold(a_p4, false, [&](const bool& seen_p6, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& j_p7) { return prism_rtl::deref(seen_p6) || (show_text(j_p7) == show_text(i_p5)); })
                        ? a_p4
                        : crate::prelude::push(a_p4, i_p5);
                }));
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> Instantiations::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& gn_p1 = this->gn_p1;
    return fold_job(or_(crate::prelude::get(prism_rtl::deref(lx_p0).insts, gen_key(gn_p1)), Array<crate::check::typed::InstNote>{}), Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>{}, ({
        auto lx_p0_1 = lx_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>(std::tuple<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>, crate::check::typed::InstNote>)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1)](std::tuple<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>, crate::check::typed::InstNote> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0_1_2 = lx_p0_1;
            entered(once_job([=, lx_p0_1_2 = std::move(lx_p0_1_2)]() {
            return ({
                auto acc_p2 = p0;
                auto u_p3 = p1;
                call_then(start_expanded(lx_p0_1_2, inst_at(lx_p0_1_2, u_p3)), [=, acc_p2 = std::move(acc_p2)](Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> expanded_72212) {
                return prism_rtl::finished(fold(expanded_72212, acc_p2, [&](const Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>& a_p4, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& i_p5) {
                    return fold(a_p4, false, [&](const bool& seen_p6, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& j_p7) { return prism_rtl::deref(seen_p6) || (show_text(j_p7) == show_text(i_p5)); })
                        ? a_p4
                        : crate::prelude::push(a_p4, i_p5);
                }));
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start Instantiations, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> start_instantiations(crate::lower::Lx lx_p0, crate::check::typed::GenNote gn_p1) {
    return prism_rtl::make_rc<Instantiations>(lx_p0, gn_p1);
}


/// Expanded: unbounded fn Lx, (([((Text, Ty))], [((Text, Col))])) -> [(([((Text, Ty))], [((Text, Col))]))]
Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> expanded(const crate::lower::Lx& lx_p0, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& i_p1) {
    auto&& _m = open_q(lx_p0, i_p1);
    if (prism_rtl::is_none(_m)) {
        return Array(std::vector{i_p1});
    }
    if (prism_rtl::is_some(_m)) {
        auto&& q_p2 = prism_rtl::some_of(_m);
        auto&& _m = crate::prelude::get(lx_p0.gen_of_q, q_p2);
        if (prism_rtl::is_some(_m)) {
            auto&& g_p3 = prism_rtl::some_of(_m);
            return run_to_end(fold_job(instantiations(lx_p0, g_p3), Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>{}, ({
                auto lx_p0_1 = lx_p0;
                auto i_p1_2 = i_p1;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>(std::tuple<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>, std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1), i_p1_2 = std::move(i_p1_2)](std::tuple<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>, std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto lx_p0_1_3 = lx_p0_1;
                    auto i_p1_2_3 = i_p1_2;
                    entered(once_job([=, lx_p0_1_3 = std::move(lx_p0_1_3), i_p1_2_3 = std::move(i_p1_2_3)]() {
                    return ({
                        auto acc_p4 = p0;
                        auto gi_p5 = p1;
                        ({
                        auto lx2_p6 = at_instance(lx_p0_1_3, gi_p5);
                        call_then(start_expanded(lx2_p6, subst_inst(lx2_p6, i_p1_2_3)), [=](Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> expanded_72645) { return prism_rtl::finished(append(acc_p4, expanded_72645)); });
                    });
                    });
                }));
                });
            }));
            })));
        }
        if (prism_rtl::is_none(_m)) {
            return Array(std::vector{i_p1});
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> Expanded::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& i_p1 = this->i_p1;
    auto i_p1_1 = i_p1;
    auto lx_p0_2 = lx_p0;
    return call_then(start_open_q(lx_p0_2, i_p1_1), [=](std::optional<Text> open_q_72463) {
        return ({
            prism_rtl::is_none(open_q_72463) ? prism_rtl::finished(Array(std::vector{i_p1_1}))
            : prism_rtl::is_some(open_q_72463) ? ({
            auto&& q_p2 = prism_rtl::some_of(open_q_72463);
            ({
            auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0_2).gen_of_q, q_p2);
            prism_rtl::is_some(_m) ? ({
            auto&& g_p3 = prism_rtl::some_of(_m);
            call_then(start_instantiations(lx_p0_2, g_p3), [=](Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> instantiations_72540) {
            return fold_job(instantiations_72540, Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>{}, ({
                auto lx_p0_2_3 = lx_p0_2;
                auto i_p1_1_3 = i_p1_1;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>(std::tuple<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>, std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>)>>(prism_rtl::rc([=, lx_p0_2_3 = std::move(lx_p0_2_3), i_p1_1_3 = std::move(i_p1_1_3)](std::tuple<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>, std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto lx_p0_2_3_3 = lx_p0_2_3;
                    auto i_p1_1_3_3 = i_p1_1_3;
                    entered(once_job([=, lx_p0_2_3_3 = std::move(lx_p0_2_3_3), i_p1_1_3_3 = std::move(i_p1_1_3_3)]() {
                    return ({
                        auto acc_p4 = p0;
                        auto gi_p5 = p1;
                        ({
                        auto lx2_p6 = at_instance(lx_p0_2_3_3, gi_p5);
                        call_then(start_expanded(lx2_p6, subst_inst(lx2_p6, i_p1_1_3_3)), [=](Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> expanded_72645) { return prism_rtl::finished(append(acc_p4, expanded_72645)); });
                    });
                    });
                }));
                });
            }));
            }))->cycle();
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(Array(std::vector{i_p1_1}))
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
    });
}


/// `Start Expanded, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> start_expanded(crate::lower::Lx lx_p0, std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>> i_p1) {
    return prism_rtl::make_rc<Expanded>(lx_p0, i_p1);
}


/// SubstInst: fn Lx, (([((Text, Ty))], [((Text, Col))])) -> (([((Text, Ty))], [((Text, Col))]))
std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>> subst_inst(const crate::lower::Lx& lx_p0, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& arg1) {
    {
        auto&& tys_p1 = std::get<0>(arg1);
        auto&& cols_p2 = std::get<1>(arg1);
        auto tys2_p3 = each(tys_p1, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
            auto&& q_p5 = std::get<0>(_p0);
            auto&& t_p6 = std::get<1>(_p0);
            return std::tuple{q_p5, crate::lower::subst_ty(lx_p0, t_p6)};
        });
        auto cols2_p4 = each(cols_p2, [&](const std::tuple<Text, crate::check::types::Col>& _p0) {
            auto&& q_p7 = std::get<0>(_p0);
            auto&& c_p8 = std::get<1>(_p0);
            return std::tuple{q_p7, crate::lower::inst_col(lx_p0, c_p8)};
        });
        return std::tuple{tys2_p3, cols2_p4};
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?OpenQ: unbounded fn Lx, (([((Text, Ty))], [((Text, Col))])) -> ?Text
std::optional<Text> open_q(const crate::lower::Lx& lx_p0, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& arg1) {
    {
        auto&& tys_p1 = std::get<0>(arg1);
        auto&& cols_p2 = std::get<1>(arg1);
        auto from_cols_p5 = fold(cols_p2, Array<Text>{}, [&](const Array<Text>& acc_p3, const std::tuple<Text, crate::check::types::Col>& _p1) {
            auto&& c_p4 = std::get<1>(_p1);
            return append(acc_p3, open_cols(lx_p0, c_p4));
        });
        auto all_p8 = run_to_end(fold_job(tys_p1, from_cols_p5, ({
            auto lx_p0_1 = lx_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, std::tuple<Text, crate::check::types::Ty>>)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1)](std::tuple<Array<Text>, std::tuple<Text, crate::check::types::Ty>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_p0_1_2 = lx_p0_1;
                entered(once_job([=, lx_p0_1_2 = std::move(lx_p0_1_2)]() {
                return ({
                    auto acc_p6 = p0;
                    auto&& _t_p7 = p1;
                    auto&& t_p7 = std::get<1>(_t_p7);
                    call_then(start_open_ty_qs(lx_p0_1_2, t_p7), [=, acc_p6 = std::move(acc_p6)](Array<Text> open_ty_qs_73326) { return prism_rtl::finished(append(acc_p6, open_ty_qs_73326)); });
                });
            }));
            });
        })));
        })));
        return index(all_p8, Nat(0u));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::optional<Text>> OpenQ::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& arg1 = this->arg1;
    return ({
        ({
        auto&& tys_p1 = std::get<0>(arg1);
        auto&& cols_p2 = std::get<1>(arg1);
        ({
        auto from_cols_p5 = fold(cols_p2, Array<Text>{}, [&](const Array<Text>& acc_p3, const std::tuple<Text, crate::check::types::Col>& _p1) {
            auto&& c_p4 = std::get<1>(_p1);
            return append(acc_p3, open_cols(lx_p0, c_p4));
        });
        auto lx_p0_1 = lx_p0;
        auto tys_p1_2 = tys_p1;
        call_value(fold_job(tys_p1_2, from_cols_p5, ({
        auto lx_p0_1_3 = lx_p0_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, std::tuple<Text, crate::check::types::Ty>>)>>(prism_rtl::rc([=, lx_p0_1_3 = std::move(lx_p0_1_3)](std::tuple<Array<Text>, std::tuple<Text, crate::check::types::Ty>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0_1_3_3 = lx_p0_1_3;
            entered(once_job([=, lx_p0_1_3_3 = std::move(lx_p0_1_3_3)]() {
            return ({
                auto acc_p6 = p0;
                auto&& _t_p7 = p1;
                auto&& t_p7 = std::get<1>(_t_p7);
                call_then(start_open_ty_qs(lx_p0_1_3_3, t_p7), [=, acc_p6 = std::move(acc_p6)](Array<Text> open_ty_qs_73326) { return prism_rtl::finished(append(acc_p6, open_ty_qs_73326)); });
            });
        }));
        });
    })));
    })), [=](Array<Text> fold_73271) {
        return ({
            auto all_p8 = fold_73271;
            (prism_rtl::finished(index(all_p8, Nat(0u))));
        });
    });
    });
    });
    });
}


/// `Start OpenQ, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Text>> start_open_q(crate::lower::Lx lx_p0, std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>> arg1) {
    return prism_rtl::make_rc<OpenQ>(lx_p0, arg1);
}


/// OpenCols: fn Lx, Col -> [Text]
Array<Text> open_cols(const crate::lower::Lx& lx_p0, const crate::check::types::Col& col1) {
    if (prism_rtl::is<crate::check::types::Col::CQ>(col1)) {
        auto&& q_p1 = prism_rtl::as<crate::check::types::Col::CQ>(col1).a0;
        return crate::check::env::has_key(lx_p0.gen_of_q, q_p1) && (!crate::check::env::has_key(lx_p0.csubst, q_p1))
            ? Array(std::vector{q_p1})
            : Array<Text>{};
    }
    {
        auto&& c_p3 = col1;
        return Array<Text>{};
    }
}


/// OpenTyQs: unbounded fn Lx, Ty -> [Text]
Array<Text> open_ty_qs(const crate::lower::Lx& lx_p0, const crate::check::types::Ty& t_p1) {
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(t_p1)) {
        auto&& n_p2 = prism_rtl::as<crate::check::types::Ty::TyFlex>(t_p1).a0;
        return crate::check::env::has_key(lx_p0.gen_of_q, prism_rtl::cat("\'", n_p2)) && (!crate::check::env::has_key(lx_p0.subst, prism_rtl::cat("\'", n_p2)))
            ? Array(std::vector{prism_rtl::cat("\'", n_p2)})
            : Array<Text>{};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p1)) {
        auto&& c_p3 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a0;
        auto&& ps_p4 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a1;
        auto&& res_p5 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a2;
        return run_to_end(fold_job(crate::prelude::push(ps_p4, prism_rtl::deref(prism_rtl::deref(res_p5))), open_cols(lx_p0, c_p3), ({
            auto lx_p0_1 = lx_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1)](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_p0_1_2 = lx_p0_1;
                entered(once_job([=, lx_p0_1_2 = std::move(lx_p0_1_2)]() {
                return ({
                    auto acc_p6 = p0;
                    auto x_p7 = p1;
                    call_then(start_open_ty_qs(lx_p0_1_2, x_p7), [=, acc_p6 = std::move(acc_p6)](Array<Text> open_ty_qs_73762) { return prism_rtl::finished(append(acc_p6, open_ty_qs_73762)); });
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1)) {
        auto&& args_p8 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        return run_to_end(fold_job(args_p8, Array<Text>{}, ({
            auto lx_p0_1 = lx_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1)](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_p0_1_2 = lx_p0_1;
                entered(once_job([=, lx_p0_1_2 = std::move(lx_p0_1_2)]() {
                return ({
                    auto acc_p9 = p0;
                    auto x_pa = p1;
                    call_then(start_open_ty_qs(lx_p0_1_2, x_pa), [=, acc_p9 = std::move(acc_p9)](Array<Text> open_ty_qs_73842) { return prism_rtl::finished(append(acc_p9, open_ty_qs_73842)); });
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p1)) {
        auto&& ts_pb = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p1).a0;
        return run_to_end(fold_job(ts_pb, Array<Text>{}, ({
            auto lx_p0_1 = lx_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1)](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_p0_1_2 = lx_p0_1;
                entered(once_job([=, lx_p0_1_2 = std::move(lx_p0_1_2)]() {
                return ({
                    auto acc_pc = p0;
                    auto x_pd = p1;
                    call_then(start_open_ty_qs(lx_p0_1_2, x_pd), [=, acc_pc = std::move(acc_pc)](Array<Text> open_ty_qs_73912) { return prism_rtl::finished(append(acc_pc, open_ty_qs_73912)); });
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p1)) {
        auto&& e_pe = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p1).a0;
        return open_ty_qs(lx_p0, prism_rtl::deref(prism_rtl::deref(e_pe)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p1)) {
        auto&& k_pf = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a0;
        auto&& v_pg = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a1;
        return append(open_ty_qs(lx_p0, prism_rtl::deref(prism_rtl::deref(k_pf))), open_ty_qs(lx_p0, prism_rtl::deref(prism_rtl::deref(v_pg))));
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p1)) {
        auto&& i_ph = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        return open_ty_qs(lx_p0, prism_rtl::deref(prism_rtl::deref(i_ph)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p1)) {
        auto&& i_pi = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p1).a0;
        return open_ty_qs(lx_p0, prism_rtl::deref(prism_rtl::deref(i_pi)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t_p1)) {
        auto&& o_pj = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p1).a1;
        return open_ty_qs(lx_p0, prism_rtl::deref(prism_rtl::deref(o_pj)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p1)) {
        auto&& a_pk = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p1).a1;
        return open_ty_qs(lx_p0, prism_rtl::deref(prism_rtl::deref(a_pk)));
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> OpenTyQs::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& t_p1 = this->t_p1;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyFlex>(t_p1) ? ({
        auto&& n_p2 = prism_rtl::as<crate::check::types::Ty::TyFlex>(t_p1).a0;
        crate::check::env::has_key(prism_rtl::deref(lx_p0).gen_of_q, prism_rtl::cat("\'", n_p2)) && (!crate::check::env::has_key(prism_rtl::deref(lx_p0).subst, prism_rtl::cat("\'", n_p2)))
        ? prism_rtl::finished(Array(std::vector{prism_rtl::cat("\'", n_p2)}))
        : prism_rtl::finished(Array<Text>{});
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(t_p1) ? ({
        auto&& c_p3 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a0;
        auto&& ps_p4 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a1;
        auto&& res_p5 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a2;
        fold_job(crate::prelude::push(ps_p4, prism_rtl::deref(prism_rtl::deref(res_p5))), open_cols(lx_p0, c_p3), ({
        auto lx_p0_1 = lx_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1)](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0_1_2 = lx_p0_1;
            entered(once_job([=, lx_p0_1_2 = std::move(lx_p0_1_2)]() {
            return ({
                auto acc_p6 = p0;
                auto x_p7 = p1;
                call_then(start_open_ty_qs(lx_p0_1_2, x_p7), [=, acc_p6 = std::move(acc_p6)](Array<Text> open_ty_qs_73762) { return prism_rtl::finished(append(acc_p6, open_ty_qs_73762)); });
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1) ? ({
        auto&& args_p8 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        fold_job(args_p8, Array<Text>{}, ({
        auto lx_p0_1 = lx_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1)](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0_1_2 = lx_p0_1;
            entered(once_job([=, lx_p0_1_2 = std::move(lx_p0_1_2)]() {
            return ({
                auto acc_p9 = p0;
                auto x_pa = p1;
                call_then(start_open_ty_qs(lx_p0_1_2, x_pa), [=, acc_p9 = std::move(acc_p9)](Array<Text> open_ty_qs_73842) { return prism_rtl::finished(append(acc_p9, open_ty_qs_73842)); });
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p1) ? ({
        auto&& ts_pb = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p1).a0;
        fold_job(ts_pb, Array<Text>{}, ({
        auto lx_p0_1 = lx_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1)](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0_1_2 = lx_p0_1;
            entered(once_job([=, lx_p0_1_2 = std::move(lx_p0_1_2)]() {
            return ({
                auto acc_pc = p0;
                auto x_pd = p1;
                call_then(start_open_ty_qs(lx_p0_1_2, x_pd), [=, acc_pc = std::move(acc_pc)](Array<Text> open_ty_qs_73912) { return prism_rtl::finished(append(acc_pc, open_ty_qs_73912)); });
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t_p1) ? ({
        auto&& e_pe = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p1).a0;
        prism_rtl::more(prism_rtl::rc(OpenTyQs(lx_p0, prism_rtl::deref(prism_rtl::deref(e_pe)))));
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t_p1) ? ({
        auto&& k_pf = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a0;
        auto&& v_pg = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a1;
        ({
        auto k_pf_1 = prism_rtl::deref(prism_rtl::deref(k_pf));
        auto lx_p0_2 = lx_p0;
        auto v_pg_3 = prism_rtl::deref(prism_rtl::deref(v_pg));
        call_then(start_open_ty_qs(lx_p0_2, k_pf_1), [=, v_pg_3 = std::move(v_pg_3)](Array<Text> open_ty_qs_73982) { return call_then(start_open_ty_qs(lx_p0_2, v_pg_3), [=](Array<Text> open_ty_qs_74000) { return prism_rtl::finished(append(open_ty_qs_73982, open_ty_qs_74000)); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t_p1) ? ({
        auto&& i_ph = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        prism_rtl::more(prism_rtl::rc(OpenTyQs(lx_p0, prism_rtl::deref(prism_rtl::deref(i_ph)))));
    })
        : prism_rtl::is<crate::check::types::Ty::TyAt>(t_p1) ? ({
        auto&& i_pi = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p1).a0;
        prism_rtl::more(prism_rtl::rc(OpenTyQs(lx_p0, prism_rtl::deref(prism_rtl::deref(i_pi)))));
    })
        : prism_rtl::is<crate::check::types::Ty::TyElem>(t_p1) ? ({
        auto&& o_pj = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p1).a1;
        prism_rtl::more(prism_rtl::rc(OpenTyQs(lx_p0, prism_rtl::deref(prism_rtl::deref(o_pj)))));
    })
        : prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p1) ? ({
        auto&& a_pk = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p1).a1;
        prism_rtl::more(prism_rtl::rc(OpenTyQs(lx_p0, prism_rtl::deref(prism_rtl::deref(a_pk)))));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start OpenTyQs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_open_ty_qs(crate::lower::Lx lx_p0, crate::check::types::Ty t_p1) {
    return prism_rtl::make_rc<OpenTyQs>(lx_p0, t_p1);
}


/// AtInstance: fn Lx, (([((Text, Ty))], [((Text, Col))])) -> Lx
crate::lower::Lx at_instance(const crate::lower::Lx& lx_p0, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& arg1) {
    {
        auto&& tys_p1 = std::get<0>(arg1);
        auto&& cols_p2 = std::get<1>(arg1);
        crate::lower::Lx this_ = lx_p0;
        this_.subst = fold(tys_p1, this_.subst, [&](const Map<Text, crate::check::types::Ty>& m_p3, const std::tuple<Text, crate::check::types::Ty>& _p1) {
            auto&& q_p4 = std::get<0>(_p1);
            auto&& t_p5 = std::get<1>(_p1);
            return insert(m_p3, q_p4, t_p5);
        });
        this_.csubst = fold(cols_p2, this_.csubst, [&](const Map<Text, crate::check::types::Col>& m_p6, const std::tuple<Text, crate::check::types::Col>& _p1) {
            auto&& q_p7 = std::get<0>(_p1);
            auto&& c_p8 = std::get<1>(_p1);
            return insert(m_p6, q_p7, c_p8);
        });
        return this_;
    }
    prism_rtl::unreachable("no arm matched");
}


/// WidgetLetLx: unbounded fn Lx, Range -> Lx
crate::lower::Lx widget_let_lx(const crate::lower::Lx& lx_p0, const crate::syntax::Range& span_p1) {
    auto&& _m = crate::prelude::get(lx_p0.gens, crate::lower::place_key(lx_p0, span_p1));
    if (prism_rtl::is_some(_m)) {
        auto&& gn_p2 = prism_rtl::some_of(_m);
        auto&& _m = instantiations(lx_p0, gn_p2);
        {
            auto&& m74821_0 = _m;
            if (m74821_0.size() == 1u) {
                {
                    auto&& _c1 = index(m74821_0, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& i_p3 = prism_rtl::some_of(_c1);
                        return at_instance(lx_p0, i_p3);
                    }
                }
            }
        }
        {
            return lx_p0;
        }
    }
    if (prism_rtl::is_none(_m)) {
        return lx_p0;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::Lx> WidgetLetLx::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& span_p1 = this->span_p1;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0).gens, crate::lower::place_key(lx_p0, span_p1));
        prism_rtl::is_some(_m) ? ({
        auto&& gn_p2 = prism_rtl::some_of(_m);
        ({
        auto lx_p0_1 = lx_p0;
        call_then(start_instantiations(lx_p0_1, gn_p2), [=](Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> instantiations_74827) {
        return ({
            ({
            auto&& m74821_0 = instantiations_74827;
            (m74821_0.size() == 1u) && ({
            auto&& _c1 = index(m74821_0, Nat(0u));
            prism_rtl::is_some(_c1);
        });
        }) ? ({
            auto&& m74821_0 = instantiations_74827;
            auto&& _c1 = index(m74821_0, Nat(0u));
            auto&& i_p3 = prism_rtl::some_of(_c1);
            prism_rtl::finished(at_instance(lx_p0_1, i_p3));
        })
            : prism_rtl::finished(lx_p0_1);
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(lx_p0)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start WidgetLetLx, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::Lx> start_widget_let_lx(crate::lower::Lx lx_p0, crate::syntax::Range span_p1) {
    return prism_rtl::make_rc<WidgetLetLx>(lx_p0, span_p1);
}


/// InstAt: fn Lx, InstNote -> (([((Text, Ty))], [((Text, Col))]))
std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>> inst_at(const crate::lower::Lx& lx_p0, const crate::check::typed::InstNote& u_p1) {
    auto tys_p2 = each(u_p1.tys, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
        auto&& q_p4 = std::get<0>(_p0);
        auto&& t_p5 = std::get<1>(_p0);
        return std::tuple{q_p4, crate::lower::subst_ty(lx_p0, t_p5)};
    });
    auto cols_p3 = each(u_p1.cols, [&](const std::tuple<Text, crate::check::types::Col>& _p0) {
        auto&& q_p6 = std::get<0>(_p0);
        auto&& c_p7 = std::get<1>(_p0);
        return std::tuple{q_p6, crate::lower::inst_col(lx_p0, c_p7)};
    });
    return std::tuple{tys_p2, cols_p3};
}


/// GenKey: fn GenNote -> Text
Text gen_key(const crate::check::typed::GenNote& gn_p0) {
    return or_(index(append(gn_p0.tys, gn_p0.cols), Nat(0u)), Text::lit(""));
}


/// InstKey: fn InstNote -> Text
Text inst_key(const crate::check::typed::InstNote& u_p0) {
    return or_(index(append(each(u_p0.tys, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
        auto&& q_p1 = std::get<0>(_p0);
        return q_p1;
    }), each(u_p0.cols, [&](const std::tuple<Text, crate::check::types::Col>& _p0) {
        auto&& q_p2 = std::get<0>(_p0);
        return q_p2;
    })), Nat(0u)), Text::lit(""));
}


/// ColName: fn Col -> Text
Text col_name(const crate::check::types::Col& col0) {
    if (prism_rtl::is<crate::check::types::Col::CQ>(col0)) {
        auto&& q_p0 = prism_rtl::as<crate::check::types::Col::CQ>(col0).a0;
        return q_p0;
    }
    {
        auto&& c_p1 = col0;
        return Text::lit("");
    }
}


/// PlainLet: unbounded fn Lx, Env, Stmt, Pattern, Expr -> (([Do], Env))
std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> plain_let(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Stmt& s_p2, const crate::syntax::Pattern_& p_p3, const crate::syntax::Expr& x_p4) {
    auto v_p5 = value_of(lx_p0, env_p1, x_p4);
    auto po_p6 = crate::lower::patterns::rust_pat(lx_p0, p_p3, crate::lower::type_at(lx_p0, x_p4.span), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("l", prism_rtl::deref(s_p2.span).start));
    return std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{prism_rtl::deref(po_p6).pa, crate::lower::types::own(v_p5)})}), bind_all(env_p1, prism_rtl::deref(po_p6).binds)};
}


prism_rtl::Turn<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> PlainLet::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& s_p2 = this->s_p2;
    const auto& p_p3 = this->p_p3;
    const auto& x_p4 = this->x_p4;
    auto env_p1_1 = env_p1;
    auto lx_p0_2 = lx_p0;
    auto p_p3_3 = p_p3;
    auto s_p2_4 = s_p2;
    auto x_p4_5 = x_p4;
    return call_then(start_value_of(lx_p0_2, env_p1_1, x_p4_5), [=](crate::lower::types::Vl value_of_75612) {
        return ({
            auto v_p5 = value_of_75612;
            call_then(crate::lower::patterns::start_rust_pat(lx_p0_2, p_p3_3, crate::lower::type_at(lx_p0_2, prism_rtl::deref(x_p4_5).span), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("l", prism_rtl::deref(prism_rtl::deref(s_p2_4).span).start)), [=, v_p5 = std::move(v_p5)](crate::lower::patterns::PatOut rust_pat_75648) {
            return ({
                auto po_p6 = rust_pat_75648;
                (prism_rtl::finished(std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{prism_rtl::deref(po_p6).pa, crate::lower::types::own(v_p5)})}), bind_all(env_p1_1, prism_rtl::deref(po_p6).binds)}));
            });
        });
        });
    });
}


/// `Start PlainLet, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> start_plain_let(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Stmt s_p2, crate::syntax::Pattern_ p_p3, crate::syntax::Expr x_p4) {
    return prism_rtl::make_rc<PlainLet>(lx_p0, env_p1, s_p2, p_p3, x_p4);
}

}  // namespace crate::lower::expr
