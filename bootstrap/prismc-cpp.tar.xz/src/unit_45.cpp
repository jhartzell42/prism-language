// The module `Lower.Node.Finish`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <lower/node_/finish/module.hpp>
#include <lower/node_/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Lower.Node.Finish`, from `target/bootstrap/cpp-src/prismc/lower/node/finish.prism`.
namespace crate::lower::node_::finish {



/// Heights: fn [Gn] -> [Gn]
Array<crate::lower::node_::Gn> heights(const Array<crate::lower::node_::Gn>& gns) {
    return fold(gns, gns, [&](const Array<crate::lower::node_::Gn>& cur, const crate::lower::node_::Gn& _p1) { return each(cur, [&](const crate::lower::node_::Gn& n) { return height_step(cur, n); }); });
}


/// HeightStep: fn [Gn], Gn -> Gn
crate::lower::node_::Gn height_step(const Array<crate::lower::node_::Gn>& gns, const crate::lower::node_::Gn& n) {
    auto feeders = filter(gns, [&](const crate::lower::node_::Gn& m) { return fold(prism_rtl::val(m).outs, false, [&](const bool& f, const crate::lower::node_::Out& o) { return prism_rtl::val(f) || feeds(prism_rtl::val(o).sink, n); }); });
    auto top = fold(feeders, Nat(0u), [&](const Nat& hi, const crate::lower::node_::Gn& m) { return crate::prelude::max(hi, prism_rtl::val(m).height); });
    auto h = ({
        __label__ _done;
        prism_rtl::Slot<Nat> _v;
        auto&& _m = n.kind;
        if (prism_rtl::is<crate::lower::node_::GnKind::GnNamed>(_m)) {
            _v.set(top);
            goto _done;
        }
        {
            auto&& kind = _m;
            _v.set(is_comb(kind) ? crate::prelude::max(top + Nat(1u), n.floor) : n.height);
            goto _done;
        }
    _done:
        _v.take();
    });
    crate::lower::node_::Gn this_ = n;
    this_.height = h;
    return this_;
}


/// IsComb: fn GnKind -> Bool
bool is_comb(const crate::lower::node_::GnKind& k) {
    if (prism_rtl::is<crate::lower::node_::GnKind::GnMerge>(k)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::node_::GnKind::GnUnion>(k)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::node_::GnKind::GnBoth>(k)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::node_::GnKind::GnExcept>(k)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::node_::GnKind::GnMergeAll>(k)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::node_::GnKind::GnUpdated>(k)) {
        return true;
    }
    {
        return false;
    }
}


/// Feeds: fn Sk, Gn -> Bool
bool feeds(const crate::lower::node_::Sk& sk0, const crate::lower::node_::Gn& n) {
    if (prism_rtl::is<crate::lower::node_::Sk::SkNode>(sk0)) {
        auto&& m = prism_rtl::as<crate::lower::node_::Sk::SkNode>(sk0).a0;
        return m == n.id;
    }
    if (prism_rtl::is<crate::lower::node_::Sk::SkIn>(sk0)) {
        auto&& m = prism_rtl::as<crate::lower::node_::Sk::SkIn>(sk0).a0;
        return m == n.id;
    }
    if (prism_rtl::is<crate::lower::node_::Sk::SkCycle>(sk0)) {
        auto&& m = prism_rtl::as<crate::lower::node_::Sk::SkCycle>(sk0).a2;
        return m == n.id;
    }
    if (prism_rtl::is<crate::lower::node_::Sk::SkMachine>(sk0)) {
        auto&& f = prism_rtl::as<crate::lower::node_::Sk::SkMachine>(sk0).a0;
        auto&& m = prism_rtl::as<crate::lower::node_::Sk::SkMachine>(sk0).a2;
        return (m == n.id) || writes(f, n);
    }
    if (prism_rtl::is<crate::lower::node_::Sk::SkHold>(sk0)) {
        auto&& f = prism_rtl::as<crate::lower::node_::Sk::SkHold>(sk0).a0;
        return writes(f, n);
    }
    if (prism_rtl::is<crate::lower::node_::Sk::SkDistinct>(sk0)) {
        auto&& f = prism_rtl::as<crate::lower::node_::Sk::SkDistinct>(sk0).a0;
        return writes(f, n);
    }
    if (prism_rtl::is<crate::lower::node_::Sk::SkPerKey>(sk0)) {
        auto&& f = prism_rtl::as<crate::lower::node_::Sk::SkPerKey>(sk0).a0;
        return writes(f, n);
    }
    {
        auto&& other = sk0;
        return false;
    }
}


/// Writes: fn Text, Gn -> Bool
bool writes(const Text& f, const crate::lower::node_::Gn& n) {
    return moves(crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{f}), n);
}


/// Moves: fn Read, Gn -> Bool
bool moves(const crate::lower::node_::Read& r, const crate::lower::node_::Gn& n) {
    return (n.kind == crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnUpdated{})) && crate::lower::node_::has_read(n.reads, r);
}


/// ReadsClosed: fn (Text ==> [Read]), [Read] -> [Read]
Array<crate::lower::node_::Read> reads_closed(const Map<Text, Array<crate::lower::node_::Read>>& dyn_, const Array<crate::lower::node_::Read>& reads) {
    return fold(crate::check::errors::range0(Nat(4u)), reads, [&](const Array<crate::lower::node_::Read>& acc, const Nat& _p1) { return fold(acc, acc, [&](const Array<crate::lower::node_::Read>& a, const crate::lower::node_::Read& r) { return crate::lower::node_::union_reads(a, getter_reads(dyn_, r)); }); });
}


/// GetterReads: fn (Text ==> [Read]), Read -> [Read]
Array<crate::lower::node_::Read> getter_reads(const Map<Text, Array<crate::lower::node_::Read>>& dyn_, const crate::lower::node_::Read& read1) {
    if (prism_rtl::is<crate::lower::node_::Read::OwnRead>(read1)) {
        auto&& n = prism_rtl::as<crate::lower::node_::Read::OwnRead>(read1).a0;
        return or_(crate::prelude::get(dyn_, n), Array<crate::lower::node_::Read>{});
    }
    if (prism_rtl::is<crate::lower::node_::Read::ParentRead>(read1)) {
        return Array<crate::lower::node_::Read>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// ReachesSnap: fn [Text], [Read] -> Bool
bool reaches_snap(const Array<Text>& roots, const Array<crate::lower::node_::Read>& reads) {
    return fold(reads, false, [&](const bool& f, const crate::lower::node_::Read& r) {
        return prism_rtl::val(f) || ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            if (prism_rtl::is<crate::lower::node_::Read::OwnRead>(r)) {
                auto&& n = prism_rtl::as<crate::lower::node_::Read::OwnRead>(r).a0;
                _v.set(crate::check::types::has_text(roots, n));
                goto _done;
            }
            if (prism_rtl::is<crate::lower::node_::Read::ParentRead>(r)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// SnapNames: fn Wx -> [Text]
Array<Text> snap_names(const crate::lower::node_::Wx& wx) {
    return each(wx.snaps, [&](const crate::lower::node_::SnapDef& sn) { return prism_rtl::val(sn).name; });
}


/// WakeConst: fn [Nat], Nat -> Text
Text wake_const(const Array<Nat>& heights_, const Nat& h) {
    return len(heights_) <= Nat(1u) ? Text::lit("WAKE") : prism_rtl::cat("WAKE_", h);
}


/// SelfCall: fn Text, [Ex] -> Do
crate::lower::model::Do self_call(const Text& m, const Array<crate::lower::model::Ex>& args) {
    return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), m, crate::prelude::push(args, crate::lower::model::Ex(crate::lower::model::Ex::XCx{}))})});
}


/// SinkCode: fn Sinks, Sk, Ex -> [Do]
Array<crate::lower::model::Do> sink_code(const Sinks& sk, const crate::lower::node_::Sk& target, const crate::lower::model::Ex& y) {
    if (prism_rtl::is<crate::lower::node_::Sk::SkNode>(target)) {
        auto&& m = prism_rtl::as<crate::lower::node_::Sk::SkNode>(target).a0;
        return Array(std::vector{self_call(prism_rtl::val(crate::lower::node_::gn_of(sk.wx, m)).name, Array(std::vector{y}))});
    }
    if (prism_rtl::is<crate::lower::node_::Sk::SkIn>(target)) {
        auto&& m = prism_rtl::as<crate::lower::node_::Sk::SkIn>(target).a0;
        auto&& i = prism_rtl::as<crate::lower::node_::Sk::SkIn>(target).a1;
        auto g = crate::lower::node_::gn_of(sk.wx, m);
        return append(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(or_(index(prism_rtl::val(g).inputs, i), Text::lit("")))})), Text::lit("set"), Array(std::vector{y, crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})}), ask_wake(sk, prism_rtl::val(g).height));
    }
    if (prism_rtl::is<crate::lower::node_::Sk::SkHold>(target)) {
        auto&& f = prism_rtl::as<crate::lower::node_::Sk::SkHold>(target).a0;
        return append(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f)})), Text::lit("set"), Array(std::vector{y, crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})}), hold_written(sk, f));
    }
    if (prism_rtl::is<crate::lower::node_::Sk::SkDistinct>(target)) {
        auto&& f = prism_rtl::as<crate::lower::node_::Sk::SkDistinct>(target).a0;
        auto differs = crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("!="), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f)})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(y)})})}))});
        auto write = crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f)})), Text::lit("set"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(y)})})}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
        return Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIf{differs, append(Array(std::vector{write}), hold_written(sk, f)), Array<crate::lower::model::Do>{}})});
    }
    if (prism_rtl::is<crate::lower::node_::Sk::SkPerKey>(target)) {
        auto&& f = prism_rtl::as<crate::lower::node_::Sk::SkPerKey>(target).a0;
        return Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f)})), Text::lit("written"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(y)}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), hold_written(sk, f), Array<crate::lower::model::Do>{}})});
    }
    if (prism_rtl::is<crate::lower::node_::Sk::SkRequest>(target)) {
        auto&& pos = prism_rtl::as<crate::lower::node_::Sk::SkRequest>(target).a0;
        auto&& field_ = prism_rtl::as<crate::lower::node_::Sk::SkRequest>(target).a1;
        auto field_ex = field_ == Text::lit("")
            ? crate::lower::model::Ex(crate::lower::model::Ex::XNone{})
            : crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{field_})})});
        return emits(sk.wx, pos)
            ? Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("request"), Array(std::vector{place_at(sk.wx, Text::lit("self"), pos), field_ex, crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(y), Text::lit("to_pod"), Array<crate::lower::model::Ex>{}})})})})})
            : Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("requested")}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(host_field_ex(sk.wx, pos)), Text::lit("request"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(place_at(sk.wx, Text::lit("self"), pos))}), field_ex, crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(y), Text::lit("to_pod"), Array<crate::lower::model::Ex>{}}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})}), crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("keep"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("requested")})})})})});
    }
    if (prism_rtl::is<crate::lower::node_::Sk::SkResult>(target)) {
        return Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("result"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Outcome::Fired"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(y), Text::lit("to_pod"), Array<crate::lower::model::Ex>{}})})})})})})});
    }
    if (prism_rtl::is<crate::lower::node_::Sk::SkArm>(target)) {
        auto&& f = prism_rtl::as<crate::lower::node_::Sk::SkArm>(target).a0;
        return Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f)})), Text::lit("arm"), Array(std::vector{y, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})});
    }
    if (prism_rtl::is<crate::lower::node_::Sk::SkMachine>(target)) {
        auto&& f = prism_rtl::as<crate::lower::node_::Sk::SkMachine>(target).a0;
        auto&& step_ = prism_rtl::as<crate::lower::node_::Sk::SkMachine>(target).a1;
        auto&& out = prism_rtl::as<crate::lower::node_::Sk::SkMachine>(target).a2;
        auto stepped = crate::lower::model::Ex(crate::lower::model::Ex::XCall{step_, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), f})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(y)})})});
        return append(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("machine_s")}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("machine_b")})})}), stepped}), crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f)})), Text::lit("set"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("machine_s")}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})}), crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("machine_b")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("machine_b")}), Array(std::vector{self_call(prism_rtl::val(crate::lower::node_::gn_of(sk.wx, out)).name, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("machine_b")})}))}), Array<crate::lower::model::Do>{}})}), moved_marks(sk, f));
    }
    if (prism_rtl::is<crate::lower::node_::Sk::SkPort>(target)) {
        auto&& f = prism_rtl::as<crate::lower::node_::Sk::SkPort>(target).a0;
        return Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f, "_port")})), Text::lit("fire"), Array(std::vector{y, crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})), Text::lit("ok"), Array<crate::lower::model::Ex>{}})})});
    }
    if (prism_rtl::is<crate::lower::node_::Sk::SkUp>(target)) {
        auto&& m = prism_rtl::as<crate::lower::node_::Sk::SkUp>(target).a0;
        auto keyed = len(filter(prism_rtl::val(sk.wx).fields, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
            auto&& f = std::get<0>(_p0);
            return f == Text::lit("key");
        })) > Nat(0u);
        auto args = keyed
            ? Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("key")}))}), y, crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})
            : Array(std::vector{y, crate::lower::model::Ex(crate::lower::model::Ex::XCx{})});
        return Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("parent")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XUpgrade{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("parent")}))}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("parent")})), m, args})})}), Array<crate::lower::model::Do>{}})});
    }
    if (prism_rtl::is<crate::lower::node_::Sk::SkCycle>(target)) {
        auto&& job = prism_rtl::as<crate::lower::node_::Sk::SkCycle>(target).a0;
        auto&& again = prism_rtl::as<crate::lower::node_::Sk::SkCycle>(target).a1;
        auto&& res = prism_rtl::as<crate::lower::node_::Sk::SkCycle>(target).a2;
        auto more_ = Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(job)})), Text::lit("set"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("next")}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})}), crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(again)})), Text::lit("arm"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})});
        auto fin = Array(std::vector{self_call(prism_rtl::val(crate::lower::node_::gn_of(sk.wx, res)).name, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("b")})}))});
        return Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoMatch{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(job)})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})), Text::lit("cycle"), Array<crate::lower::model::Ex>{}}), Array(std::vector{std::tuple{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("prism_rtl::Turn::More"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("next")})})}), more_}, std::tuple{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("b")})})}), fin}})})});
    }
    prism_rtl::unreachable("no arm matched");
}


/// HoldWritten: fn Sinks, Text -> [Do]
Array<crate::lower::model::Do> hold_written(const Sinks& sk, const Text& f) {
    auto r = crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{f});
    auto read_by_place = crate::lower::node_::has_read(sk.dirty, r);
    auto dirty_1 = read_by_place
        ? Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("dirty"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})})})})})
        : Array<crate::lower::model::Do>{};
    auto told = Array<crate::lower::model::Do>{};
    auto stales = fold(prism_rtl::val(sk.wx).gen_holds, Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc, const std::tuple<Text, Array<crate::lower::node_::Read>>& _p1) {
        auto&& gname = std::get<0>(_p1);
        auto&& hs = std::get<1>(_p1);
        return crate::lower::node_::has_read(reads_closed(prism_rtl::val(sk.wx).dyn_reads, hs), r)
            ? crate::prelude::push(acc, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(gname, "_stale")})), Text::lit("set"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XBool{true})})})}))
            : acc;
    });
    auto row_marks = fold(prism_rtl::val(sk.wx).row_marks, Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc, const crate::lower::node_::RowMarks& rm) { return append(acc, row_written(sk.wx, rm, r)); });
    auto builds = crate::lower::node_::has_read(sk.builds, r) || (len(stales) > Nat(0u));
    auto rebuild_it = builds && (!lists_build(sk, r))
        ? append(stales, Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("build_later"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})})})})}))
        : stales;
    auto gathered = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::Do>> _v;
        auto&& _m = prism_rtl::val(sk.wx).result_moved;
        if (prism_rtl::is_some(_m)) {
            auto&& m = std::get<0>(prism_rtl::some_of(_m));
            auto&& rds = std::get<1>(prism_rtl::some_of(_m));
            _v.set(crate::lower::node_::has_read(rds, r)
                ? Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("parent")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XUpgrade{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("parent")}))}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("parent")})), m, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})}), Array<crate::lower::model::Do>{}})})
                : Array<crate::lower::model::Do>{});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<crate::lower::model::Do>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return append(append(append(append(append(dirty_1, told), rebuild_it), row_marks), gathered), moved_marks(sk, f));
}


/// HostFieldEx: fn Wx, Pos -> Ex
crate::lower::model::Ex host_field_ex(const crate::lower::node_::Wx& wx, const crate::lower::model::Pos_& pos) {
    return crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), crate::lower::node_::elements::host_local(wx, pos)});
}


/// MovedMarks: fn Sinks, Text -> [Do]
Array<crate::lower::model::Do> moved_marks(const Sinks& sk, const Text& f) {
    return moved_by(sk, crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{f}));
}


/// MovedBy: fn Sinks, Read -> [Do]
Array<crate::lower::model::Do> moved_by(const Sinks& sk, const crate::lower::node_::Read& r) {
    auto moved = filter(prism_rtl::val(sk.wx).gns, [&](const crate::lower::node_::Gn& g) { return moves(r, g); });
    auto flags = each(moved, [&](const crate::lower::node_::Gn& g) { return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(prism_rtl::val(g).name, "_moved")})), Text::lit("set"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XBool{true})})})}); });
    auto heights_ = sort_nats(fold(moved, Array<Nat>{}, [&](const Array<Nat>& acc, const crate::lower::node_::Gn& g) { return crate::check::types::add_nat(acc, prism_rtl::val(g).height); }));
    auto marks = each(snaps_behind(sk.wx, r), [&](const crate::lower::node_::SnapDef& sn) { return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(prism_rtl::val(sn).name, "_snap")})), Text::lit("mark"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})}); });
    auto listed = lists_build(sk, r)
        ? Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("build_later"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})})})})})
        : Array<crate::lower::model::Do>{};
    auto answers = each(filter(prism_rtl::val(sk.wx).dyn_answers, [&](const std::tuple<Text, Array<crate::lower::node_::Read>>& _p0) {
        auto&& rds = std::get<1>(_p0);
        return crate::lower::node_::has_read(reads_closed(prism_rtl::val(sk.wx).dyn_reads, rds), r);
    }), [&](const std::tuple<Text, Array<crate::lower::node_::Read>>& _p0) {
        auto&& name = std::get<0>(_p0);
        return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(name, "_port")})), Text::lit("fire"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})), Text::lit("ok"), Array<crate::lower::model::Ex>{}})});
    });
    auto adoptions = each(filter(prism_rtl::val(sk.wx).flattens, [&](const crate::lower::node_::FlatDef& fl) { return (fl->generation != Text::lit("")) && (r == crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{prism_rtl::val(fl).outer})); }), [&](const crate::lower::node_::FlatDef& fl) { return crate::lower::model::Do(crate::lower::model::Do::DoScope{adoption(fl)}); });
    return append(append(append(append(append(fold(heights_, flags, [&](const Array<crate::lower::model::Do>& acc, const Nat& h) { return append(acc, ask_wake(sk, h)); }), marks), listed), answers), adoptions), source_marks(sk.wx, r));
}


/// SourceMarks: fn Wx, Read -> [Do]
Array<crate::lower::model::Do> source_marks(const crate::lower::node_::Wx& wx, const crate::lower::node_::Read& r) {
    auto fors = fold(wx.builders, Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc, const crate::lower::model::ForDef& b) {
        return crate::lower::node_::has_read(reads_closed(wx.dyn_reads, or_(crate::prelude::get(wx.dyn_reads, b->source), Array<crate::lower::node_::Read>{})), r)
            ? crate::prelude::push(acc, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(b->source, "_cache")})), Text::lit("mark"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})}))
            : acc;
    });
    return fold(wx.let_caches, fors, [&](const Array<crate::lower::model::Do>& acc, const Text& c) {
        return crate::lower::node_::has_read(reads_all(wx.dyn_reads, or_(crate::prelude::get(wx.dyn_reads, c), Array<crate::lower::node_::Read>{})), r)
            ? crate::prelude::push(acc, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(c, "_cache")})), Text::lit("mark"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})}))
            : acc;
    });
}


/// ReadsAll: fn (Text ==> [Read]), [Read] -> [Read]
Array<crate::lower::node_::Read> reads_all(const Map<Text, Array<crate::lower::node_::Read>>& dyn_, const Array<crate::lower::node_::Read>& reads) {
    return fold(crate::check::errors::range0(crate::prelude::size(dyn_) + Nat(1u)), reads, [&](const Array<crate::lower::node_::Read>& acc, const Nat& _p1) { return fold(acc, acc, [&](const Array<crate::lower::node_::Read>& a, const crate::lower::node_::Read& r) { return crate::lower::node_::union_reads(a, getter_reads(dyn_, r)); }); });
}


/// IsOwnRead: fn Read -> Bool
bool is_own_read(const crate::lower::node_::Read& r) {
    if (prism_rtl::is<crate::lower::node_::Read::OwnRead>(r)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::node_::Read::ParentRead>(r)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// SnapsBehind: fn Wx, Read -> [SnapDef]
Array<crate::lower::node_::SnapDef> snaps_behind(const crate::lower::node_::Wx& wx, const crate::lower::node_::Read& r) {
    return filter(wx.snaps, [&](const crate::lower::node_::SnapDef& sn) { return (r == crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{prism_rtl::val(sn).live})) || crate::lower::node_::has_read(reads_closed(wx.dyn_reads, Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{prism_rtl::val(sn).live})})), r); });
}


/// ListsBuild: fn Sinks, Read -> Bool
bool lists_build(const Sinks& sk, const crate::lower::node_::Read& r) {
    return len(snaps_behind(sk.wx, r)) > Nat(0u);
}


/// FiringCode: unbounded fn Sinks, Gn, Ex -> [Do]
Array<crate::lower::model::Do> firing_code(const Sinks& sk, const crate::lower::node_::Gn& g, const crate::lower::model::Ex& x) {
    auto many = (len(g.outs) > Nat(1u)) && (!crate::lower::types::is_copy(g.ty));
    auto xv = many
        ? crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(x)})
        : x;
    return run_to_end(fold_job(g.outs, Array<crate::lower::model::Do>{}, ({
        auto xv_1 = xv;
        auto sk_2 = sk;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<Array<crate::lower::model::Do>, crate::lower::node_::Out>)>>(prism_rtl::rc([=](std::tuple<Array<crate::lower::model::Do>, crate::lower::node_::Out> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto xv_1_3 = xv_1;
            auto sk_2_3 = sk_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto o = p1;
                call_value(prism_rtl::val(o).pipe(std::tuple{xv_1_3, ({
                auto sk_2_3_3 = sk_2_3;
                auto o_3 = o;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>(prism_rtl::rc([=](crate::lower::model::Ex p0) {
                return ({
                    auto sk_2_3_3_4 = sk_2_3_3;
                    auto o_3_4 = o_3;
                    once_job([=]() {
                    return ({
                        auto y = p0;
                        (prism_rtl::finished(sink_code(sk_2_3_3_4, prism_rtl::val(o_3_4).sink, y)));
                    });
                });
                });
            })));
            })}), [=](Array<crate::lower::model::Do> call_13560) { return prism_rtl::finished(append(acc, call_13560)); });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<crate::lower::model::Do>> FiringCode::cycle() const {
    const auto& sk = this->sk;
    const auto& g = this->g;
    const auto& x = this->x;
    auto many = (len(prism_rtl::val(g).outs) > Nat(1u)) && (!crate::lower::types::is_copy(prism_rtl::val(g).ty));
    auto xv = many
        ? crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(x)})
        : x;
    return fold_job(prism_rtl::val(g).outs, Array<crate::lower::model::Do>{}, ({
        auto xv_1 = xv;
        auto sk_2 = sk;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<Array<crate::lower::model::Do>, crate::lower::node_::Out>)>>(prism_rtl::rc([=](std::tuple<Array<crate::lower::model::Do>, crate::lower::node_::Out> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto xv_1_3 = xv_1;
            auto sk_2_3 = sk_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto o = p1;
                call_value(prism_rtl::val(o).pipe(std::tuple{xv_1_3, ({
                auto sk_2_3_3 = sk_2_3;
                auto o_3 = o;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>(prism_rtl::rc([=](crate::lower::model::Ex p0) {
                return ({
                    auto sk_2_3_3_4 = sk_2_3_3;
                    auto o_3_4 = o_3;
                    once_job([=]() {
                    return ({
                        auto y = p0;
                        (prism_rtl::finished(sink_code(sk_2_3_3_4, prism_rtl::val(o_3_4).sink, y)));
                    });
                });
                });
            })));
            })}), [=](Array<crate::lower::model::Do> call_13560) { return prism_rtl::finished(append(acc, call_13560)); });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start FiringCode, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::Do>> start_firing_code(Sinks sk, crate::lower::node_::Gn g, crate::lower::model::Ex x) {
    return prism_rtl::make_rc<FiringCode>(sk, g, x);
}


/// FinishNode: unbounded fn Wx, Text, [((Text, OutTy))], Bool -> NodeDef
crate::lower::model::NodeDef finish_node(const crate::lower::node_::Wx& wx0, const Text& qk, const Array<std::tuple<Text, crate::lower::model::OutTy>>& params, const bool& is_row) {
    auto closed_gns = each(wx0.gns, [&](const crate::lower::node_::Gn& g) {
        return prism_rtl::val(g).kind == crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnUpdated{})
            ? crate::lower::node_::dynamics::with_reads(g, reads_closed(wx0.dyn_reads, prism_rtl::val(g).reads))
            : g;
    });
    auto [row_defs, gns2] = finish_pending(wx0, heights(closed_gns));
    auto is_gen = prism_rtl::val(is_row) && (len(filter(wx0.fields, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& f = std::get<0>(_p0);
        return f == Text::lit("key");
    })) == Nat(0u));
    auto wx = ({
        crate::lower::node_::Wx this_ = wx0;
        this_.gns = heights(gns2);
        this_.build = append(this_.build, updated_gaps(wx0, closed_gns, is_gen));
        this_.rows = fold(row_defs, this_.rows, [&](const Array<crate::lower::model::NodeDef>& acc, const crate::lower::model::NodeDef& rd) { return append(crate::prelude::push(acc, rd), prism_rtl::val(rd).children); });
        this_;
    });
    auto combs = filter(prism_rtl::val(wx).gns, [&](const crate::lower::node_::Gn& g) { return is_comb(prism_rtl::val(g).kind) || (prism_rtl::val(g).kind == crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnGather{})); });
    auto heights_ = sort_nats(fold(combs, Array<Nat>{}, [&](const Array<Nat>& acc, const crate::lower::node_::Gn& g) { return crate::check::types::add_nat(acc, prism_rtl::val(g).height); }));
    auto many = len(heights_) > Nat(1u);
    auto consts = each(heights_, [&](const Nat& h) { return std::tuple{wake_const(heights_, h), h, Text::lit("merges\' height above the node\'s inputs")}; });
    auto live = filter(prism_rtl::val(wx).places, [&](const crate::lower::node_::Place& p_) { return prism_rtl::val(p_).getter != Text::lit(""); });
    auto root_reads = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::node_::Read>> _v;
        auto&& _m = prism_rtl::val(wx).root_dyn;
        if (prism_rtl::is_some(_m)) {
            auto&& rds = std::get<1>(prism_rtl::some_of(_m));
            _v.set(reads_closed(prism_rtl::val(wx).dyn_reads, rds));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<crate::lower::node_::Read>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto dirty_holds = fold(live, root_reads, [&](const Array<crate::lower::node_::Read>& acc, const crate::lower::node_::Place& p_) { return crate::lower::node_::union_reads(acc, reads_closed(prism_rtl::val(wx).dyn_reads, prism_rtl::val(p_).reads)); });
    auto build_holds = reads_closed(prism_rtl::val(wx).dyn_reads, prism_rtl::val(wx).build_holds);
    auto sinks = Sinks{.wx = wx, .dirty = dirty_holds, .builds = build_holds, .heights = heights_, .many = many};
    auto ev_methods = run_to_end(each_job(filter(prism_rtl::val(wx).gns, [&](const crate::lower::node_::Gn& g) { return prism_rtl::val(g).kind != crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnNever{}); }), ({
        auto sinks_1 = sinks;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::MethDef>(crate::lower::node_::Gn)>>(prism_rtl::rc([=](crate::lower::node_::Gn p0) {
        return ({
            auto sinks_1_2 = sinks_1;
            entered(once_job([=]() {
            return ({
                auto g = p0;
                call_then(start_firing_code(sinks_1_2, g, crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")})), [=](Array<crate::lower::model::Do> firing_code_15352) { return prism_rtl::finished(crate::lower::model::MethDef{.name = prism_rtl::val(g).name, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array(std::vector{std::tuple{Text::lit("v"), prism_rtl::val(g).ty}}), .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = firing_code_15352, .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = gn_doc(g)}); });
            });
        }));
        });
    })));
    })));
    auto gather_ins = each(filter(prism_rtl::val(wx).gns, [&](const crate::lower::node_::Gn& g) { return prism_rtl::val(g).kind == crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnGather{}); }), [&](const crate::lower::node_::Gn& g) { return gather_in(sinks, g); });
    auto place_getters = each(live, [&](const crate::lower::node_::Place& p_) { return crate::lower::model::MethDef{.name = prism_rtl::val(p_).getter, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = crate::lower::types::elem_ty(), .body = Array<crate::lower::model::Do>{}, .tail = prism_rtl::val(p_).level, .doc = prism_rtl::cat("Place ", crate::lower::model::place_text(prism_rtl::val(p_).pos), "\'s level, read at the read point.")}; });
    auto wake_body = many
        ? Array(std::vector{wake_by_height(combs, heights_)})
        : each(combs, [&](const crate::lower::node_::Gn& g) { return decide(g); });
    auto started_body = each(wx->started, [&](const Nat& st) { return self_call(prism_rtl::val(crate::lower::node_::gn_of(wx, st)).name, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})})); });
    auto deferred_body = each(prism_rtl::val(wx).defers, [&](const std::tuple<Text, Nat>& _p0) {
        auto&& f = std::get<0>(_p0);
        auto&& id = std::get<1>(_p0);
        return crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("v")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f)})), Text::lit("fired"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{self_call(prism_rtl::val(crate::lower::node_::gn_of(wx, id)).name, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")})}))}), Array<crate::lower::model::Do>{}});
    });
    auto patch_body0 = fold(live, Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc, const crate::lower::node_::Place& p_) {
        return append(acc, emits(wx, prism_rtl::val(p_).pos)
            ? patch_place(wx, p_)
            : Array(std::vector{entry_take(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}), p_)}));
    });
    auto patch_body = append(patch_body0, root_dyn_patch(wx));
    auto build_body = build_steps(sinks, false);
    auto push_body = each(filter(prism_rtl::val(wx).dyn_places, [&](const std::tuple<crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        return emits(wx, pos);
    }), [&](const std::tuple<crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        auto&& f = std::get<1>(_p0);
        auto&& t = std::get<2>(_p0);
        return crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("=="), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("element")})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f, "_element")}))}))}), dyn_place_write(sinks, f, crate::lower::model::Ex(crate::lower::model::Ex::XDecode{t, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}))})), Array<crate::lower::model::Do>{}});
    });
    auto hooks = filter(Array(std::vector{std::tuple{Text::lit("wake"), wake_body}, std::tuple{Text::lit("started"), started_body}, std::tuple{Text::lit("deferred"), deferred_body}, std::tuple{Text::lit("build"), build_body}, std::tuple{Text::lit("push"), push_body}, std::tuple{Text::lit("patch"), patch_body}}), [&](const std::tuple<Text, Array<crate::lower::model::Do>>& _p0) {
        auto&& b = std::get<1>(_p0);
        return len(b) > Nat(0u);
    });
    auto started_reg = len(wx->started) > Nat(0u)
        ? Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("on_started"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")}))})})})})})
        : Array<crate::lower::model::Do>{};
    auto links = each(prism_rtl::val(wx).hosts, [&](const crate::lower::node_::HostDef& h) { return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), prism_rtl::cat(prism_rtl::val(h).name)})), Text::lit("link"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")}))})})})}); });
    auto rows_built = append(links, build_steps(sinks, true));
    auto subscribed = each(prism_rtl::val(wx).subs, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& ev = std::get<0>(_p0);
        auto&& m = std::get<1>(_p0);
        auto&& t = std::get<2>(_p0);
        return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("subscribe_row"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XUpgrade{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), Text::lit("parent")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("p")})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("p")})), prism_rtl::cat(ev, "_port")}))}))}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("n")}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("v")}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("cx")})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("n")})), m, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), prism_rtl::cat(m, "_sub")}))})})})});
    });
    auto answers = append(each(filter(prism_rtl::val(wx).answers, [&](const std::tuple<crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        return emits(wx, pos);
    }), [&](const std::tuple<crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        auto&& id = std::get<1>(_p0);
        auto&& t = std::get<2>(_p0);
        return answer_arm(wx, pos, id, t);
    }), each(filter(prism_rtl::val(wx).dyn_places, [&](const std::tuple<crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        return emits(wx, pos);
    }), [&](const std::tuple<crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        auto&& f = std::get<1>(_p0);
        auto&& t = std::get<2>(_p0);
        return dyn_answer_arm(sinks, pos, f, t);
    }));
    auto forwards = append(each(filter(prism_rtl::val(wx).builders, [&](const crate::lower::model::ForDef& b) { return emits(wx, prism_rtl::val(b).pos); }), [&](const crate::lower::model::ForDef& b) { return std::tuple{pos_pat(prism_rtl::val(b).pos, key_tail()), forward_answer(b)}; }), fold(filter(prism_rtl::val(wx).gens, [&](const crate::lower::model::GenDef& gd) { return emits(wx, prism_rtl::val(gd).pos); }), Array<std::tuple<crate::lower::model::Pa, crate::lower::model::Ex>>{}, [&](const Array<std::tuple<crate::lower::model::Pa, crate::lower::model::Ex>>& acc, const crate::lower::model::GenDef& gd) { return append(acc, crate::lower::node_::switch_::gen_forwards(gd)); }));
    auto host_methods = fold(prism_rtl::val(wx).hosts, Array<crate::lower::model::MethDef>{}, [&](const Array<crate::lower::model::MethDef>& acc, const crate::lower::node_::HostDef& h) { return append(acc, Array(std::vector{typed_dispatch(sinks, prism_rtl::cat(prism_rtl::val(h).name, "_answer"), prism_rtl::val(h).scope), host_moved(sinks, h)})); });
    auto gathered = filter(prism_rtl::val(wx).snaps, [&](const crate::lower::node_::SnapDef& sn) { return !(prism_rtl::val(sn).before || is_generation(wx, prism_rtl::val(sn).builder)); });
    auto gathered_moved_ = append(append(each(gathered, [&](const crate::lower::node_::SnapDef& sn) { return gathered_moved(sn); }), each(prism_rtl::val(wx).snaps, [&](const crate::lower::node_::SnapDef& sn) { return snap_publish(sinks, sn); })), flatten_methods(sinks));
    auto hosted_methods = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::MethDef>> _v;
        auto&& _m = prism_rtl::val(wx).hosted_by;
        if (prism_rtl::is_some(_m)) {
            _v.set(Array(std::vector{typed_dispatch(sinks, Text::lit("deliver"), Nat(0u)), document_getter(wx)}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<crate::lower::model::MethDef>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto moved_method = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::MethDef>> _v;
        auto&& _m = prism_rtl::val(wx).hosted_by;
        if (prism_rtl::is_some(_m)) {
            auto&& m = prism_rtl::some_of(_m);
            _v.set(Array(std::vector{crate::lower::node_::finish::document_moved(m)}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<crate::lower::model::MethDef>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto row_methods_ = prism_rtl::val(is_row)
        ? row_methods(wx)
        : Array<crate::lower::model::MethDef>{};
    auto heard_build_fn = ({
        auto wx_1 = wx;
        auto sinks_2 = sinks;
        (prism_rtl::rc([=](const Text& m) {
        return ({
            auto stales = fold(prism_rtl::val(wx_1).gen_holds, Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc, const std::tuple<Text, Array<crate::lower::node_::Read>>& _p1) {
                auto&& gname = std::get<0>(_p1);
                auto&& hs = std::get<1>(_p1);
                return crate::lower::node_::has_read(reads_closed(prism_rtl::val(wx_1).dyn_reads, hs), crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{m}))
                    ? crate::prelude::push(acc, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(gname, "_stale")})), Text::lit("set"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XBool{true})})})}))
                    : acc;
            });
            auto builds = crate::lower::node_::has_read(prism_rtl::val(sinks_2).builds, crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{m})) || (len(stales) > Nat(0u));
            builds && (!lists_build(sinks_2, crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{m})))
            ? append(stales, Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("build_later"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})})})})}))
            : stales;
        });
    }));
    });
    auto heard = each(row_hears(wx), [&](const Text& m) { return crate::lower::model::MethDef{.name = prism_rtl::cat("parent_wrote_", m), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = append(append(moved_by(sinks, crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{m})), heard_build_fn(m)), fold(prism_rtl::val(wx).row_marks, Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc, const crate::lower::node_::RowMarks& rm) { return append(acc, row_written(wx, rm, crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{m}))); })), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = prism_rtl::cat("The block wrote behind its `", m, "`, which this row reads through the parent: the `!Updated` nodes over it are told and the wake asked at their heights; the row\'s own builders over it are listed for the build; the rows of this row\'s own `for`s that read it are marked.")}; });
    auto top = fold(prism_rtl::val(wx).gns, Nat(0u), [&](const Nat& hi, const crate::lower::node_::Gn& g) { return crate::prelude::max(hi, prism_rtl::val(g).height); });
    auto wakes_field = many
        ? Array(std::vector{std::tuple{Text::lit("wakes"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutWakes{}), Text::lit("the heights asked for this tick, lowest first")}})
        : Array<std::tuple<Text, crate::lower::model::OutTy, Text>>{};
    auto wakes_init = many
        ? Array(std::vector{std::tuple{Text::lit("wakes"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Wakes::default"), Array<crate::lower::model::Ex>{}})}})
        : Array<std::tuple<Text, crate::lower::model::Ex>>{};
    auto gen_fields = fold(prism_rtl::val(wx).gens, Array<std::tuple<Text, crate::lower::model::OutTy, Text>>{}, [&](const Array<std::tuple<Text, crate::lower::model::OutTy, Text>>& acc, const crate::lower::model::GenDef& gd) { return append(acc, Array(std::vector{std::tuple{prism_rtl::val(gd).name, crate::lower::model::OutTy(crate::lower::model::OutTy::OutCell{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutObj{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Row"), Array<crate::lower::model::OutTy>{}}))}))}))}), prism_rtl::cat("the current generation of the `rebuild` at place ", crate::lower::model::place_text(prism_rtl::val(gd).pos))}, std::tuple{prism_rtl::cat(prism_rtl::val(gd).name, "_count"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Cell"), Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutCount{})})}), Text::lit("how many generations it has built")}, std::tuple{prism_rtl::cat(prism_rtl::val(gd).name, "_stale"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Cell"), Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})})}), Text::lit("its source changed since it was built")}})); });
    auto gen_inits = fold(prism_rtl::val(wx).gens, Array<std::tuple<Text, crate::lower::model::Ex>>{}, [&](const Array<std::tuple<Text, crate::lower::model::Ex>>& acc, const crate::lower::model::GenDef& gd) { return append(acc, Array(std::vector{std::tuple{prism_rtl::val(gd).name, crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("RefCell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XNone{})})})}, std::tuple{prism_rtl::cat(prism_rtl::val(gd).name, "_count"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Cell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XIndex{Nat(0u)})})})}, std::tuple{prism_rtl::cat(prism_rtl::val(gd).name, "_stale"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Cell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XBool{false})})})}})); });
    auto port_fields = each(prism_rtl::val(wx).ports, [&](const Text& pn) { return std::tuple{prism_rtl::cat(pn, "_port"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutPort{prism_rtl::rc(crate::lower::node_::keyed::gn_ty_named(wx, pn))}), prism_rtl::cat("`!", pn, "`, which rows subscribe to")}; });
    auto port_inits = each(prism_rtl::val(wx).ports, [&](const Text& pn) { return std::tuple{prism_rtl::cat(pn, "_port"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Port::new"), Array<crate::lower::model::Ex>{}})}; });
    auto sub_fields = each(prism_rtl::val(wx).subs, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& ev = std::get<0>(_p0);
        auto&& m = std::get<1>(_p0);
        auto&& t = std::get<2>(_p0);
        return std::tuple{prism_rtl::cat(m, "_sub"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Cell"), Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Handle"), Array<crate::lower::model::OutTy>{}}))})})}), prism_rtl::cat("the subscription to the parent\'s `!", ev, "`")};
    });
    auto sub_inits = each(prism_rtl::val(wx).subs, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& ev = std::get<0>(_p0);
        auto&& m = std::get<1>(_p0);
        auto&& t = std::get<2>(_p0);
        return std::tuple{prism_rtl::cat(m, "_sub"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Cell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XNone{})})})};
    });
    auto fallible = ((prism_rtl::val(wx).fallible || prism_rtl::val(is_row)) || (len(prism_rtl::val(wx).builders) > Nat(0u))) || (len(prism_rtl::val(wx).gens) > Nat(0u));
    return crate::lower::model::NodeDef{.name = prism_rtl::val(wx).node_, .prism = crate::check::types::bare_name(qk), .doc = crate::lower::functions::definition_text(prism_rtl::val(wx).lx, qk), .params = params, .fields = append(append(append(append(prism_rtl::val(wx).fields, wakes_field), gen_fields), port_fields), sub_fields), .consts = consts, .lets = prism_rtl::val(wx).lets, .inits = append(prism_rtl::val(wx).inits, append(append(append(append(prism_rtl::val(wx).moves, wakes_init), gen_inits), port_inits), sub_inits)), .build = append(append(append(rows_built, wx->build), subscribed), started_reg), .fallible = fallible, .methods = append(append(append(append(append(append(append(append(ev_methods, gather_ins), place_getters), prism_rtl::val(wx).getters), row_methods_), heard), host_methods), gathered_moved_), moved_method), .answers = append(answers, forwards), .hooks = hooks, .builders = prism_rtl::val(wx).builders, .wakes = many, .children = wx->rows, .gens = prism_rtl::val(wx).gens, .subs = prism_rtl::val(wx).subs, .top = top, .row_kind = prism_rtl::val(is_row)
        ? is_gen
        ? crate::lower::model::RowKind(crate::lower::model::RowKind::GenerationRow{})
        : crate::lower::model::RowKind(crate::lower::model::RowKind::ForRow{})
        : crate::lower::model::RowKind(crate::lower::model::RowKind::NotARow{}), .hosted = hosted_methods};
}


prism_rtl::Turn<crate::lower::model::NodeDef> FinishNode::cycle() const {
    const auto& wx0 = this->wx0;
    const auto& qk = this->qk;
    const auto& params = this->params;
    const auto& is_row = this->is_row;
    auto closed_gns = each(prism_rtl::val(wx0).gns, [&](const crate::lower::node_::Gn& g) {
        return prism_rtl::val(g).kind == crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnUpdated{})
            ? crate::lower::node_::dynamics::with_reads(g, reads_closed(prism_rtl::val(wx0).dyn_reads, prism_rtl::val(g).reads))
            : g;
    });
    auto is_row_1 = prism_rtl::val(is_row);
    auto params_2 = params;
    auto qk_3 = qk;
    auto wx0_4 = wx0;
    return call_then(start_finish_pending(wx0_4, heights(closed_gns)), [=](std::tuple<Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>> finish_pending_14117) {
        return ({
            auto [row_defs, gns2] = finish_pending_14117;
            auto is_gen = is_row_1 && (len(filter(prism_rtl::val(wx0_4).fields, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
                auto&& f = std::get<0>(_p0);
                return f == Text::lit("key");
            })) == Nat(0u));
            auto wx = ({
                crate::lower::node_::Wx this_ = wx0_4;
                this_.gns = heights(gns2);
                this_.build = append(this_.build, updated_gaps(wx0_4, closed_gns, is_gen));
                this_.rows = fold(row_defs, this_.rows, [&](const Array<crate::lower::model::NodeDef>& acc, const crate::lower::model::NodeDef& rd) { return append(crate::prelude::push(acc, rd), prism_rtl::val(rd).children); });
                this_;
            });
            auto combs = filter(prism_rtl::val(wx).gns, [&](const crate::lower::node_::Gn& g) { return is_comb(prism_rtl::val(g).kind) || (prism_rtl::val(g).kind == crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnGather{})); });
            auto heights_ = sort_nats(fold(combs, Array<Nat>{}, [&](const Array<Nat>& acc, const crate::lower::node_::Gn& g) { return crate::check::types::add_nat(acc, prism_rtl::val(g).height); }));
            auto many = len(heights_) > Nat(1u);
            auto consts = each(heights_, [&](const Nat& h) { return std::tuple{wake_const(heights_, h), h, Text::lit("merges\' height above the node\'s inputs")}; });
            auto live = filter(prism_rtl::val(wx).places, [&](const crate::lower::node_::Place& p_) { return prism_rtl::val(p_).getter != Text::lit(""); });
            auto root_reads = ({
                __label__ _done;
                prism_rtl::Slot<Array<crate::lower::node_::Read>> _v;
                auto&& _m = prism_rtl::val(wx).root_dyn;
                if (prism_rtl::is_some(_m)) {
                    auto&& rds = std::get<1>(prism_rtl::some_of(_m));
                    _v.set(reads_closed(prism_rtl::val(wx).dyn_reads, rds));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Array<crate::lower::node_::Read>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto dirty_holds = fold(live, root_reads, [&](const Array<crate::lower::node_::Read>& acc, const crate::lower::node_::Place& p_) { return crate::lower::node_::union_reads(acc, reads_closed(prism_rtl::val(wx).dyn_reads, prism_rtl::val(p_).reads)); });
            auto build_holds = reads_closed(prism_rtl::val(wx).dyn_reads, prism_rtl::val(wx).build_holds);
            auto sinks = Sinks{.wx = wx, .dirty = dirty_holds, .builds = build_holds, .heights = heights_, .many = many};
            call_value(each_job(filter(prism_rtl::val(wx).gns, [&](const crate::lower::node_::Gn& g) { return prism_rtl::val(g).kind != crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnNever{}); }), ({
            auto sinks_5 = sinks;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::MethDef>(crate::lower::node_::Gn)>>(prism_rtl::rc([=](crate::lower::node_::Gn p0) {
            return ({
                auto sinks_5_6 = sinks_5;
                entered(once_job([=]() {
                return ({
                    auto g = p0;
                    call_then(start_firing_code(sinks_5_6, g, crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")})), [=](Array<crate::lower::model::Do> firing_code_15352) { return prism_rtl::finished(crate::lower::model::MethDef{.name = prism_rtl::val(g).name, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array(std::vector{std::tuple{Text::lit("v"), prism_rtl::val(g).ty}}), .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = firing_code_15352, .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = gn_doc(g)}); });
                });
            }));
            });
        })));
        })), [=](Array<crate::lower::model::MethDef> each_15212) {
            return ({
                auto ev_methods = each_15212;
                auto gather_ins = each(filter(prism_rtl::val(wx).gns, [&](const crate::lower::node_::Gn& g) { return prism_rtl::val(g).kind == crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnGather{}); }), [&](const crate::lower::node_::Gn& g) { return gather_in(sinks, g); });
                auto place_getters = each(live, [&](const crate::lower::node_::Place& p_) { return crate::lower::model::MethDef{.name = prism_rtl::val(p_).getter, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = crate::lower::types::elem_ty(), .body = Array<crate::lower::model::Do>{}, .tail = prism_rtl::val(p_).level, .doc = prism_rtl::cat("Place ", crate::lower::model::place_text(prism_rtl::val(p_).pos), "\'s level, read at the read point.")}; });
                auto wake_body = many
                    ? Array(std::vector{wake_by_height(combs, heights_)})
                    : each(combs, [&](const crate::lower::node_::Gn& g) { return decide(g); });
                auto started_body = each(wx->started, [&](const Nat& st) { return self_call(prism_rtl::val(crate::lower::node_::gn_of(wx, st)).name, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})})); });
                auto deferred_body = each(prism_rtl::val(wx).defers, [&](const std::tuple<Text, Nat>& _p0) {
                    auto&& f = std::get<0>(_p0);
                    auto&& id = std::get<1>(_p0);
                    return crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("v")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f)})), Text::lit("fired"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{self_call(prism_rtl::val(crate::lower::node_::gn_of(wx, id)).name, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")})}))}), Array<crate::lower::model::Do>{}});
                });
                auto patch_body0 = fold(live, Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc, const crate::lower::node_::Place& p_) {
                    return append(acc, emits(wx, prism_rtl::val(p_).pos)
                        ? patch_place(wx, p_)
                        : Array(std::vector{entry_take(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}), p_)}));
                });
                auto patch_body = append(patch_body0, root_dyn_patch(wx));
                auto build_body = build_steps(sinks, false);
                auto push_body = each(filter(prism_rtl::val(wx).dyn_places, [&](const std::tuple<crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text>& _p0) {
                    auto&& pos = std::get<0>(_p0);
                    return emits(wx, pos);
                }), [&](const std::tuple<crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text>& _p0) {
                    auto&& pos = std::get<0>(_p0);
                    auto&& f = std::get<1>(_p0);
                    auto&& t = std::get<2>(_p0);
                    return crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("=="), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("element")})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f, "_element")}))}))}), dyn_place_write(sinks, f, crate::lower::model::Ex(crate::lower::model::Ex::XDecode{t, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}))})), Array<crate::lower::model::Do>{}});
                });
                auto hooks = filter(Array(std::vector{std::tuple{Text::lit("wake"), wake_body}, std::tuple{Text::lit("started"), started_body}, std::tuple{Text::lit("deferred"), deferred_body}, std::tuple{Text::lit("build"), build_body}, std::tuple{Text::lit("push"), push_body}, std::tuple{Text::lit("patch"), patch_body}}), [&](const std::tuple<Text, Array<crate::lower::model::Do>>& _p0) {
                    auto&& b = std::get<1>(_p0);
                    return len(b) > Nat(0u);
                });
                auto started_reg = len(wx->started) > Nat(0u)
                    ? Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("on_started"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")}))})})})})})
                    : Array<crate::lower::model::Do>{};
                auto links = each(prism_rtl::val(wx).hosts, [&](const crate::lower::node_::HostDef& h) { return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), prism_rtl::cat(prism_rtl::val(h).name)})), Text::lit("link"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")}))})})})}); });
                auto rows_built = append(links, build_steps(sinks, true));
                auto subscribed = each(prism_rtl::val(wx).subs, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
                    auto&& ev = std::get<0>(_p0);
                    auto&& m = std::get<1>(_p0);
                    auto&& t = std::get<2>(_p0);
                    return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("subscribe_row"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XUpgrade{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), Text::lit("parent")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("p")})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("p")})), prism_rtl::cat(ev, "_port")}))}))}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("n")}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("v")}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("cx")})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("n")})), m, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), prism_rtl::cat(m, "_sub")}))})})})});
                });
                auto answers = append(each(filter(prism_rtl::val(wx).answers, [&](const std::tuple<crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text>& _p0) {
                    auto&& pos = std::get<0>(_p0);
                    return emits(wx, pos);
                }), [&](const std::tuple<crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text>& _p0) {
                    auto&& pos = std::get<0>(_p0);
                    auto&& id = std::get<1>(_p0);
                    auto&& t = std::get<2>(_p0);
                    return answer_arm(wx, pos, id, t);
                }), each(filter(prism_rtl::val(wx).dyn_places, [&](const std::tuple<crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text>& _p0) {
                    auto&& pos = std::get<0>(_p0);
                    return emits(wx, pos);
                }), [&](const std::tuple<crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text>& _p0) {
                    auto&& pos = std::get<0>(_p0);
                    auto&& f = std::get<1>(_p0);
                    auto&& t = std::get<2>(_p0);
                    return dyn_answer_arm(sinks, pos, f, t);
                }));
                auto forwards = append(each(filter(prism_rtl::val(wx).builders, [&](const crate::lower::model::ForDef& b) { return emits(wx, prism_rtl::val(b).pos); }), [&](const crate::lower::model::ForDef& b) { return std::tuple{pos_pat(prism_rtl::val(b).pos, key_tail()), forward_answer(b)}; }), fold(filter(prism_rtl::val(wx).gens, [&](const crate::lower::model::GenDef& gd) { return emits(wx, prism_rtl::val(gd).pos); }), Array<std::tuple<crate::lower::model::Pa, crate::lower::model::Ex>>{}, [&](const Array<std::tuple<crate::lower::model::Pa, crate::lower::model::Ex>>& acc, const crate::lower::model::GenDef& gd) { return append(acc, crate::lower::node_::switch_::gen_forwards(gd)); }));
                auto host_methods = fold(prism_rtl::val(wx).hosts, Array<crate::lower::model::MethDef>{}, [&](const Array<crate::lower::model::MethDef>& acc, const crate::lower::node_::HostDef& h) { return append(acc, Array(std::vector{typed_dispatch(sinks, prism_rtl::cat(prism_rtl::val(h).name, "_answer"), prism_rtl::val(h).scope), host_moved(sinks, h)})); });
                auto gathered = filter(prism_rtl::val(wx).snaps, [&](const crate::lower::node_::SnapDef& sn) { return !(prism_rtl::val(sn).before || is_generation(wx, prism_rtl::val(sn).builder)); });
                auto gathered_moved_ = append(append(each(gathered, [&](const crate::lower::node_::SnapDef& sn) { return gathered_moved(sn); }), each(prism_rtl::val(wx).snaps, [&](const crate::lower::node_::SnapDef& sn) { return snap_publish(sinks, sn); })), flatten_methods(sinks));
                auto hosted_methods = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::lower::model::MethDef>> _v;
                    auto&& _m = prism_rtl::val(wx).hosted_by;
                    if (prism_rtl::is_some(_m)) {
                        _v.set(Array(std::vector{typed_dispatch(sinks, Text::lit("deliver"), Nat(0u)), document_getter(wx)}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Array<crate::lower::model::MethDef>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto moved_method = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::lower::model::MethDef>> _v;
                    auto&& _m = prism_rtl::val(wx).hosted_by;
                    if (prism_rtl::is_some(_m)) {
                        auto&& m = prism_rtl::some_of(_m);
                        _v.set(Array(std::vector{crate::lower::node_::finish::document_moved(m)}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Array<crate::lower::model::MethDef>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto row_methods_ = is_row_1 ? row_methods(wx) : Array<crate::lower::model::MethDef>{};
                auto heard_build_fn = ({
                    auto wx_5 = wx;
                    auto sinks_6 = sinks;
                    (prism_rtl::rc([=](const Text& m) {
                    return ({
                        auto stales = fold(prism_rtl::val(wx_5).gen_holds, Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc, const std::tuple<Text, Array<crate::lower::node_::Read>>& _p1) {
                            auto&& gname = std::get<0>(_p1);
                            auto&& hs = std::get<1>(_p1);
                            return crate::lower::node_::has_read(reads_closed(prism_rtl::val(wx_5).dyn_reads, hs), crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{m}))
                                ? crate::prelude::push(acc, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(gname, "_stale")})), Text::lit("set"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XBool{true})})})}))
                                : acc;
                        });
                        auto builds = crate::lower::node_::has_read(prism_rtl::val(sinks_6).builds, crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{m})) || (len(stales) > Nat(0u));
                        builds && (!lists_build(sinks_6, crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{m})))
                        ? append(stales, Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("build_later"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})})})})}))
                        : stales;
                    });
                }));
                });
                auto heard = each(row_hears(wx), [&](const Text& m) { return crate::lower::model::MethDef{.name = prism_rtl::cat("parent_wrote_", m), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = append(append(moved_by(sinks, crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{m})), heard_build_fn(m)), fold(prism_rtl::val(wx).row_marks, Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc, const crate::lower::node_::RowMarks& rm) { return append(acc, row_written(wx, rm, crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{m}))); })), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = prism_rtl::cat("The block wrote behind its `", m, "`, which this row reads through the parent: the `!Updated` nodes over it are told and the wake asked at their heights; the row\'s own builders over it are listed for the build; the rows of this row\'s own `for`s that read it are marked.")}; });
                auto top = fold(prism_rtl::val(wx).gns, Nat(0u), [&](const Nat& hi, const crate::lower::node_::Gn& g) { return crate::prelude::max(hi, prism_rtl::val(g).height); });
                auto wakes_field = many
                    ? Array(std::vector{std::tuple{Text::lit("wakes"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutWakes{}), Text::lit("the heights asked for this tick, lowest first")}})
                    : Array<std::tuple<Text, crate::lower::model::OutTy, Text>>{};
                auto wakes_init = many
                    ? Array(std::vector{std::tuple{Text::lit("wakes"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Wakes::default"), Array<crate::lower::model::Ex>{}})}})
                    : Array<std::tuple<Text, crate::lower::model::Ex>>{};
                auto gen_fields = fold(prism_rtl::val(wx).gens, Array<std::tuple<Text, crate::lower::model::OutTy, Text>>{}, [&](const Array<std::tuple<Text, crate::lower::model::OutTy, Text>>& acc, const crate::lower::model::GenDef& gd) { return append(acc, Array(std::vector{std::tuple{prism_rtl::val(gd).name, crate::lower::model::OutTy(crate::lower::model::OutTy::OutCell{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutObj{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Row"), Array<crate::lower::model::OutTy>{}}))}))}))}), prism_rtl::cat("the current generation of the `rebuild` at place ", crate::lower::model::place_text(prism_rtl::val(gd).pos))}, std::tuple{prism_rtl::cat(prism_rtl::val(gd).name, "_count"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Cell"), Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutCount{})})}), Text::lit("how many generations it has built")}, std::tuple{prism_rtl::cat(prism_rtl::val(gd).name, "_stale"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Cell"), Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})})}), Text::lit("its source changed since it was built")}})); });
                auto gen_inits = fold(prism_rtl::val(wx).gens, Array<std::tuple<Text, crate::lower::model::Ex>>{}, [&](const Array<std::tuple<Text, crate::lower::model::Ex>>& acc, const crate::lower::model::GenDef& gd) { return append(acc, Array(std::vector{std::tuple{prism_rtl::val(gd).name, crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("RefCell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XNone{})})})}, std::tuple{prism_rtl::cat(prism_rtl::val(gd).name, "_count"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Cell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XIndex{Nat(0u)})})})}, std::tuple{prism_rtl::cat(prism_rtl::val(gd).name, "_stale"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Cell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XBool{false})})})}})); });
                auto port_fields = each(prism_rtl::val(wx).ports, [&](const Text& pn) { return std::tuple{prism_rtl::cat(pn, "_port"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutPort{prism_rtl::rc(crate::lower::node_::keyed::gn_ty_named(wx, pn))}), prism_rtl::cat("`!", pn, "`, which rows subscribe to")}; });
                auto port_inits = each(prism_rtl::val(wx).ports, [&](const Text& pn) { return std::tuple{prism_rtl::cat(pn, "_port"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Port::new"), Array<crate::lower::model::Ex>{}})}; });
                auto sub_fields = each(prism_rtl::val(wx).subs, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
                    auto&& ev = std::get<0>(_p0);
                    auto&& m = std::get<1>(_p0);
                    auto&& t = std::get<2>(_p0);
                    return std::tuple{prism_rtl::cat(m, "_sub"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Cell"), Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Handle"), Array<crate::lower::model::OutTy>{}}))})})}), prism_rtl::cat("the subscription to the parent\'s `!", ev, "`")};
                });
                auto sub_inits = each(prism_rtl::val(wx).subs, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
                    auto&& ev = std::get<0>(_p0);
                    auto&& m = std::get<1>(_p0);
                    auto&& t = std::get<2>(_p0);
                    return std::tuple{prism_rtl::cat(m, "_sub"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Cell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XNone{})})})};
                });
                auto fallible = ((prism_rtl::val(wx).fallible || is_row_1) || (len(prism_rtl::val(wx).builders) > Nat(0u))) || (len(prism_rtl::val(wx).gens) > Nat(0u));
                (prism_rtl::finished(crate::lower::model::NodeDef{.name = prism_rtl::val(wx).node_, .prism = crate::check::types::bare_name(qk_3), .doc = crate::lower::functions::definition_text(prism_rtl::val(wx).lx, qk_3), .params = params_2, .fields = append(append(append(append(prism_rtl::val(wx).fields, wakes_field), gen_fields), port_fields), sub_fields), .consts = consts, .lets = prism_rtl::val(wx).lets, .inits = append(prism_rtl::val(wx).inits, append(append(append(append(prism_rtl::val(wx).moves, wakes_init), gen_inits), port_inits), sub_inits)), .build = append(append(append(rows_built, wx->build), subscribed), started_reg), .fallible = fallible, .methods = append(append(append(append(append(append(append(append(ev_methods, gather_ins), place_getters), prism_rtl::val(wx).getters), row_methods_), heard), host_methods), gathered_moved_), moved_method), .answers = append(answers, forwards), .hooks = hooks, .builders = prism_rtl::val(wx).builders, .wakes = many, .children = wx->rows, .gens = prism_rtl::val(wx).gens, .subs = prism_rtl::val(wx).subs, .top = top, .row_kind = is_row_1
                ? is_gen
                ? crate::lower::model::RowKind(crate::lower::model::RowKind::GenerationRow{})
                : crate::lower::model::RowKind(crate::lower::model::RowKind::ForRow{})
                : crate::lower::model::RowKind(crate::lower::model::RowKind::NotARow{}), .hosted = hosted_methods}));
            });
        });
        });
    });
}


/// `Start FinishNode, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::NodeDef> start_finish_node(crate::lower::node_::Wx wx0, Text qk, Array<std::tuple<Text, crate::lower::model::OutTy>> params, bool is_row) {
    return prism_rtl::make_rc<FinishNode>(wx0, qk, params, is_row);
}


/// IsGeneration: fn Wx, Text -> Bool
bool is_generation(const crate::lower::node_::Wx& wx, const Text& name) {
    return len(filter(wx.gens, [&](const crate::lower::model::GenDef& gd) { return prism_rtl::val(gd).name == name; })) > Nat(0u);
}


/// FlattenMethods: fn Sinks -> [MethDef]
Array<crate::lower::model::MethDef> flatten_methods(const Sinks& sk) {
    auto wx = sk.wx;
    auto entries = fold(filter(prism_rtl::val(wx).flattens, [&](const crate::lower::node_::FlatDef& fl) { return fl->generation == Text::lit(""); }), Array<crate::lower::model::MethDef>{}, [&](const Array<crate::lower::model::MethDef>& acc, const crate::lower::node_::FlatDef& fl) {
        return ({
            auto set_1 = crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(prism_rtl::val(fl).name, "_inner")})), Text::lit("set"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("entry"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
            auto followed = crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(prism_rtl::val(fl).name, "_follow")})), Text::lit("follow"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("entry"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})), Text::lit("updates")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))}))}), crate::lower::model::Ex(crate::lower::model::Ex::XPath{prism_rtl::cat(prism_rtl::val(wx).node_, "::", prism_rtl::val(fl).name, "_moved")})})})});
            auto moved_2 = crate::lower::model::MethDef{.name = prism_rtl::cat(prism_rtl::val(fl).name, "_moved"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = hold_written(sk, prism_rtl::cat(prism_rtl::val(fl).name, "_inner")), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = prism_rtl::cat("`", prism_rtl::val(fl).name, "`\'s inner moved: what reads it reads it again.")};
            auto replaced = crate::lower::model::MethDef{.name = prism_rtl::cat(prism_rtl::val(fl).name, "_replaced"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = adoption(fl), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = prism_rtl::cat("The `for`\'s builder found another dynamic than `", prism_rtl::val(fl).name, "`\'s inner under this row\'s key: the adoption is queued for the first firings of the next tick, which is owed (Semantics ch. 4).")};
            auto adopt = crate::lower::model::MethDef{.name = prism_rtl::cat(prism_rtl::val(fl).name, "_adopt"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = append(Array(std::vector{set_1, followed}), hold_written(sk, prism_rtl::cat(prism_rtl::val(fl).name, "_inner"))), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = prism_rtl::cat("`", prism_rtl::val(fl).name, "` adopts the dynamic under its row\'s key as the tick before left it, among this tick\'s first firings: from here on it reads that inner (Semantics ch. 4).")};
            append(acc, Array(std::vector{moved_2, replaced, adopt}));
        });
    });
    auto adopts0 = each(filter(prism_rtl::val(wx).flattens, [&](const crate::lower::node_::FlatDef& fl) { return fl->generation != Text::lit(""); }), [&](const crate::lower::node_::FlatDef& fl) {
        return ({
            auto set_1 = crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(prism_rtl::val(fl).name, "_inner")})), Text::lit("set"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::val(fl).outer, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
            crate::lower::model::MethDef{.name = prism_rtl::cat(prism_rtl::val(fl).name, "_adopt"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = append(Array(std::vector{set_1}), hold_written(sk, prism_rtl::cat(prism_rtl::val(fl).name, "_inner"))), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = Text::lit("`@Flatten` adopts the inner its `rebuild`\'s dynamic held after the tick before, among this tick\'s first firings: from here on it reads that inner (Semantics ch. 7).")};
        });
    });
    auto adopts = append(adopts0, entries);
    auto dyn_gens = filter(prism_rtl::val(wx).gens, [&](const crate::lower::model::GenDef& gd) { return len(filter(prism_rtl::val(wx).snaps, [&](const crate::lower::node_::SnapDef& sn) { return prism_rtl::val(sn).builder == prism_rtl::val(gd).name; })) > Nat(0u); });
    auto moved_1 = each(dyn_gens, [&](const crate::lower::model::GenDef& gd) {
        return ({
            auto marks = fold(filter(prism_rtl::val(wx).flattens, [&](const crate::lower::node_::FlatDef& fl) { return fl->generation == prism_rtl::val(gd).name; }), Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc, const crate::lower::node_::FlatDef& fl) { return append(acc, hold_written(sk, prism_rtl::cat(prism_rtl::val(fl).name, "_inner"))); });
            auto live = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(prism_rtl::val(gd).name, "_result_live")})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}})), Text::lit("as_ref"), Array<crate::lower::model::Ex>{}});
            auto port = crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("d")})), Text::lit("updates")});
            auto fire_1 = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(port), Text::lit("fire"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})), Text::lit("ok"), Array<crate::lower::model::Ex>{}});
            auto fired = crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("d")})})}), live, Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{fire_1})}), Array<crate::lower::model::Do>{}});
            crate::lower::model::MethDef{.name = prism_rtl::cat(prism_rtl::val(gd).name, "_result_moved"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = crate::prelude::push(marks, fired), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = Text::lit("The current generation\'s result moved: what reads a `@Flatten` over it reads it again, and the dynamic kept for it fires its update event for whoever follows it outside this node.")};
        });
    });
    return append(adopts, moved_1);
}


/// HostMoved: fn Sinks, HostDef -> MethDef
crate::lower::model::MethDef host_moved(const Sinks& sk, const crate::lower::node_::HostDef& h) {
    return crate::lower::model::MethDef{.name = prism_rtl::cat(h.name, "_moved"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = hold_written(sk, prism_rtl::cat(h.name, "_doc_now")), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = prism_rtl::cat("A node of the child hosted at place ", crate::lower::model::place_text(h.pos), " wrote behind its document: the structure is marked as for a write of a hold it reads (pick HO), the snapshot listed to be taken; the program\'s `$doc` moves when it is published, the tick after (pick ST).")};
}


/// BuildSteps: fn Sinks, Bool -> [Do]
Array<crate::lower::model::Do> build_steps(const Sinks& sk, const bool& at_build) {
    auto wx = sk.wx;
    auto recv = prism_rtl::val(at_build)
        ? crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})
        : crate::lower::model::Ex(crate::lower::model::Ex::XSelf{});
    auto take_fn = ({
        auto at_build_1 = prism_rtl::val(at_build);
        auto sk_2 = sk;
        (prism_rtl::rc([=](const crate::lower::node_::SnapDef& sn) { return at_build_1 ? snap_take_at_build(sn) : snap_take(sk_2, sn); }));
    });
    auto builder_fn = ({
        auto wx_1 = wx;
        auto take_fn_2 = take_fn;
        auto recv_3 = recv;
        (prism_rtl::rc([=](const crate::lower::model::ForDef& b) {
        return ({
            auto before_ = each(filter(prism_rtl::val(wx_1).snaps, [&](const crate::lower::node_::SnapDef& sn) { return prism_rtl::val(sn).before && (prism_rtl::val(sn).builder == prism_rtl::val(b).name); }), prism_rtl::val(take_fn_2));
            auto after_ = each(filter(prism_rtl::val(wx_1).snaps, [&](const crate::lower::node_::SnapDef& sn) { return (!prism_rtl::val(sn).before) && (prism_rtl::val(sn).builder == prism_rtl::val(b).name); }), prism_rtl::val(take_fn_2));
            append(crate::prelude::push(before_, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::expr::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(recv_3), prism_rtl::cat(prism_rtl::val(b).name, "_build"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))})), after_);
        });
    }));
    });
    auto gen__fn = ({
        auto at_build_1 = prism_rtl::val(at_build);
        auto recv_2 = recv;
        auto wx_3 = wx;
        auto take_fn_4 = take_fn;
        (prism_rtl::rc([=](const crate::lower::model::GenDef& gd) {
        return ({
            auto built = at_build_1
                ? crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::expr::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(recv_2), prism_rtl::cat(prism_rtl::val(gd).name, "_build"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))})
                : crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(prism_rtl::val(gd).name, "_stale")})), Text::lit("replace"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XBool{false})})}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::expr::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(prism_rtl::val(gd).name, "_build"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))})}), Array<crate::lower::model::Do>{}});
            append(Array(std::vector{built}), each(filter(prism_rtl::val(wx_3).snaps, [&](const crate::lower::node_::SnapDef& sn) { return (!prism_rtl::val(sn).before) && (prism_rtl::val(sn).builder == prism_rtl::val(gd).name); }), prism_rtl::val(take_fn_4)));
        });
    }));
    });
    auto entries_fn = ({
        auto at_build_1 = prism_rtl::val(at_build);
        auto wx_2 = wx;
        auto recv_3 = recv;
        (prism_rtl::rc([=](const Nat& k) {
        return at_build_1
            ? each(filter(prism_rtl::val(wx_2).places, [&](const crate::lower::node_::Place& pl) { return ((prism_rtl::val(prism_rtl::val(pl).pos).scope == k) && (pl->entry != Text::lit(""))) && (prism_rtl::val(pl).getter != Text::lit("")); }), [&](const crate::lower::node_::Place& pl) { return entry_take(recv_3, pl); })
            : Array<crate::lower::model::Do>{};
    }));
    });
    return fold(crate::check::errors::range0(len(prism_rtl::val(wx).scopes) + Nat(1u)), Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc, const Nat& i) {
        return ({
            auto k = or_(len(prism_rtl::val(wx).scopes).checked_sub(i), Nat(0u));
            auto builders = fold(filter(prism_rtl::val(wx).builders, [&](const crate::lower::model::ForDef& b) { return prism_rtl::val(prism_rtl::val(b).pos).scope == k; }), Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& a, const crate::lower::model::ForDef& b) { return append(a, builder_fn(b)); });
            append(append(append(acc, builders), fold(filter(prism_rtl::val(wx).gens, [&](const crate::lower::model::GenDef& gd) { return prism_rtl::val(prism_rtl::val(gd).pos).scope == k; }), Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& a, const crate::lower::model::GenDef& gd) { return append(a, gen__fn(gd)); })), entries_fn(k));
        });
    });
}


/// EntryTake: fn Ex, Place -> Do
crate::lower::model::Do entry_take(const crate::lower::model::Ex& recv, const crate::lower::node_::Place& pl) {
    return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(recv), pl.entry})), Text::lit("take"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(recv), pl.getter, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
}


/// SnapTakeAtBuild: fn SnapDef -> Do
crate::lower::model::Do snap_take_at_build(const crate::lower::node_::SnapDef& sn) {
    return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), prism_rtl::cat(sn.name, "_snap")})), Text::lit("take"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), prism_rtl::cat(sn.name, "_now"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
}


/// SnapTake: fn Sinks, SnapDef -> Do
crate::lower::model::Do snap_take(const Sinks& sk, const crate::lower::node_::SnapDef& sn) {
    auto now = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(sn.name, "_now"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})});
    auto take_ = crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(sn.name, "_snap")})), sn.eq ? Text::lit("take_compared") : Text::lit("take"), Array(std::vector{now, crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
    auto queue = crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("answer_later"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XLater{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), prism_rtl::cat(sn.name, "_publish"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))})})})});
    auto queued = crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(sn.name, "_snap")})), Text::lit("queue"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("node")}), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})}), queue}), Array<crate::lower::model::Do>{}});
    return crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(sn.name, "_snap")})), Text::lit("marked"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{take_, queued}), Array<crate::lower::model::Do>{}});
}


/// SnapPublish: fn Sinks, SnapDef -> MethDef
crate::lower::model::MethDef snap_publish(const Sinks& sk, const crate::lower::node_::SnapDef& sn) {
    return crate::lower::model::MethDef{.name = prism_rtl::cat(sn.name, "_publish"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(sn.name, "_snap")})), Text::lit("published"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), hold_written(sk, sn.name), Array<crate::lower::model::Do>{}})}), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = prism_rtl::cat(sn.what, ", published: its snapshot of the tick before moved it, written as a hold is (pick ST).")};
}


/// GatheredMoved: fn SnapDef -> MethDef
crate::lower::model::MethDef gathered_moved(const crate::lower::node_::SnapDef& sn) {
    return crate::lower::model::MethDef{.name = prism_rtl::cat(sn.name, "_moved"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(sn.name, "_snap")})), Text::lit("mark"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})}), crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("build_later"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})})})})}), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = Text::lit("A row\'s result moved: the `for`\'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).")};
}


/// DocumentGetter: fn Wx -> MethDef
crate::lower::model::MethDef document_getter(const crate::lower::node_::Wx& wx) {
    auto is_own_fn = prism_rtl::rc([=](const crate::lower::model::Pos_& p_) { return prism_rtl::val(p_).scope == Nat(0u); });
    auto body = document_body(({
        auto f = prism_rtl::rc(vec_push);
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Do>(std::tuple<crate::lower::model::Ex, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<crate::lower::model::Ex, crate::lower::model::Ex> _p0) {
        auto&& a0 = std::get<0>(_p0);
        auto&& a1 = std::get<1>(_p0);
        return ({
            auto f_1 = f;
            once_job([=]() { return prism_rtl::finished(f_1(a0, a1)); });
        });
    })));
    }), filter(wx.places, [&](const crate::lower::node_::Place& pl) { return is_own_fn(prism_rtl::val(pl).pos); }), filter(wx.builders, [&](const crate::lower::model::ForDef& b) { return is_own_fn(prism_rtl::val(b).pos); }), filter(wx.gens, [&](const crate::lower::model::GenDef& gd) { return is_own_fn(prism_rtl::val(gd).pos); }));
    return crate::lower::model::MethDef{.name = Text::lit("document"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Vec"), Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutPath{}), crate::lower::types::entry_ty()})})})}), .body = append(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("doc")})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Vec"), Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutPath{}), crate::lower::types::entry_ty()})})})})}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Vec::new"), Array<crate::lower::model::Ex>{}})})}), body), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("doc")}), .doc = Text::lit("The row\'s own places, entries of its host\'s document, by their paths relative to the row (pick HO).")};
}


/// DocumentMoved: fn Text -> MethDef
crate::lower::model::MethDef document_moved(const Text& m) {
    return crate::lower::model::MethDef{.name = Text::lit("document_moved"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("parent")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XUpgrade{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("parent")}))}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("parent")})), m, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})}), Array<crate::lower::model::Do>{}})}), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = Text::lit("A place of this row may have moved: its host\'s document moved, and the host\'s readers and rows are marked (pick HO).")};
}


/// DocumentBody: fn (fn Ex, Ex -> Do), [Place], [ForDef], [GenDef] -> [Do]
Array<crate::lower::model::Do> document_body(const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Do>(std::tuple<crate::lower::model::Ex, crate::lower::model::Ex>)>& add_fn, const Array<crate::lower::node_::Place>& places, const Array<crate::lower::model::ForDef>& builders, const Array<crate::lower::model::GenDef>& gens) {
    auto statics = run_to_end(each_job(places, ({
        auto add_fn_1 = add_fn;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Do>(crate::lower::node_::Place)>>(prism_rtl::rc([=](crate::lower::node_::Place p0) {
        return ({
            auto add_fn_1_2 = add_fn_1;
            entered(once_job([=]() {
            return ({
                auto pl = p0;
                add_fn_1_2(std::tuple{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Path::root"), Array<crate::lower::model::Ex>{}})), Text::lit("at"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XIndex{prism_rtl::val(prism_rtl::val(pl).pos).at})})}), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), pl->entry}))})})->cycle();
            });
        }));
        });
    })));
    })));
    auto row_doc_fn = static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::lower::model::ForDef)>>(prism_rtl::rc([=](crate::lower::model::ForDef p0) {
        return entered(once_job([=]() {
            return ({
                auto b = p0;
                (crate::syntax::lexer::chars::has_prefix(prism_rtl::val(b).row_node, Text::lit("prism_rtl::HostRow"))
                ? prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")})), Text::lit("entries"), Array<crate::lower::model::Ex>{}}))
                : prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")})), Text::lit("document"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})));
            });
        }));
    }));
    auto rows = run_to_end(each_job(builders, ({
        auto row_doc_fn_1 = row_doc_fn;
        auto add_fn_2 = add_fn;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Do>(crate::lower::model::ForDef)>>(prism_rtl::rc([=](crate::lower::model::ForDef p0) {
        return ({
            auto row_doc_fn_1_3 = row_doc_fn_1;
            auto add_fn_2_3 = add_fn_2;
            entered(once_job([=]() {
            return ({
                auto b = p0;
                call_value(row_doc_fn_1_3(b), [=](crate::lower::model::Ex row_doc_35051) { return call_value(add_fn_2_3(std::tuple{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Path::root"), Array<crate::lower::model::Ex>{}})), Text::lit("at"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XIndex{prism_rtl::val(prism_rtl::val(b).pos).at})})})), Text::lit("child"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Segment::Key"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("k")})), Text::lit("to_pod"), Array<crate::lower::model::Ex>{}})})})})})), Text::lit("join"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("p")}))})})}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("e")})}), [=](crate::lower::model::Do add_35065) { return prism_rtl::finished(crate::lower::model::Do(crate::lower::model::Do::DoFor{crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("k")}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::val(b).name})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}})), Text::lit("iter"), Array<crate::lower::model::Ex>{}}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoFor{crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("p")}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("e")})})}), row_doc_35051, Array(std::vector{add_35065})})})})); }); });
            });
        }));
        });
    })));
    })));
    auto generations = run_to_end(each_job(gens, ({
        auto add_fn_1 = add_fn;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Do>(crate::lower::model::GenDef)>>(prism_rtl::rc([=](crate::lower::model::GenDef p0) {
        return ({
            auto add_fn_1_2 = add_fn_1;
            entered(once_job([=]() {
            return ({
                auto gd = p0;
                call_value(add_fn_1_2(std::tuple{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Path::root"), Array<crate::lower::model::Ex>{}})), Text::lit("at"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XIndex{prism_rtl::val(prism_rtl::val(gd).pos).at})})})), Text::lit("child"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Segment::Gen"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("g")})})})})})), Text::lit("join"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("p")}))})})}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("e")})}), [=](crate::lower::model::Do add_35637) { return prism_rtl::finished(crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::val(gd).name})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}})), Text::lit("as_ref"), Array<crate::lower::model::Ex>{}}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("g")}), crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("-"), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(prism_rtl::val(gd).name, "_count")})), Text::lit("get"), Array<crate::lower::model::Ex>{}})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XIndex{Nat(1u)}))})}), crate::lower::model::Do(crate::lower::model::Do::DoFor{crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("p")}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("e")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")})), Text::lit("document"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{add_35637})})}), Array<crate::lower::model::Do>{}})); });
            });
        }));
        });
    })));
    })));
    return append(append(statics, rows), generations);
}


/// MapInsert: fn Ex, Ex -> Do
crate::lower::model::Do map_insert(const crate::lower::model::Ex& path_, const crate::lower::model::Ex& e) {
    return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("doc")})), Text::lit("insert"), Array(std::vector{path_, e})})});
}


/// VecPush: fn Ex, Ex -> Do
crate::lower::model::Do vec_push(const crate::lower::model::Ex& path_, const crate::lower::model::Ex& e) {
    return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("doc")})), Text::lit("push"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XTuple{Array(std::vector{path_, e})})})})});
}


/// DynAnswerArm: fn Sinks, Pos, Text, OutTy -> ((Pa, Ex))
std::tuple<crate::lower::model::Pa, crate::lower::model::Ex> dyn_answer_arm(const Sinks& sk, const crate::lower::model::Pos_& pos, const Text& f, const crate::lower::model::OutTy& t) {
    return std::tuple{pos_pat(pos, Array<crate::lower::model::Pa>{}), crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dyn_place_write(sk, f, crate::lower::model::Ex(crate::lower::model::Ex::XDecode{t, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}))})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}))})};
}


/// DynPlaceWrite: fn Sinks, Text, Ex -> [Do]
Array<crate::lower::model::Do> dyn_place_write(const Sinks& sk, const Text& f, const crate::lower::model::Ex& value) {
    return append(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f)})), Text::lit("set"), Array(std::vector{value, crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})}), hold_written(sk, f));
}


/// UpdatedGaps: fn Wx, [Gn], Bool -> [Do]
Array<crate::lower::model::Do> updated_gaps(const crate::lower::node_::Wx& wx, const Array<crate::lower::node_::Gn>& gns, const bool& is_gen) {
    auto holds = fold(wx.fields, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, crate::lower::model::OutTy, Text>& _p1) {
        auto&& f = std::get<0>(_p1);
        auto&& t = std::get<1>(_p1);
        return is_hold(t) ? crate::prelude::push(acc, f) : acc;
    });
    auto derived = keys(wx.dyn_reads);
    auto roots = snap_names(wx);
    auto own = fold(filter(gns, [&](const crate::lower::node_::Gn& g) { return prism_rtl::val(g).kind == crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnUpdated{}); }), Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc, const crate::lower::node_::Gn& g) {
        return fold(prism_rtl::val(g).reads, acc, [&](const Array<crate::lower::model::Do>& a, const crate::lower::node_::Read& r) {
            return ({
                __label__ _done;
                prism_rtl::Slot<Array<crate::lower::model::Do>> _v;
                if (prism_rtl::is<crate::lower::node_::Read::ParentRead>(r)) {
                    auto&& f = prism_rtl::as<crate::lower::node_::Read::ParentRead>(r).a0;
                    _v.set(prism_rtl::val(is_gen)
                        ? crate::prelude::push(a, crate::lower::expr::refusal_do(prism_rtl::cat("`!Updated` of a dynamic in a generation that reads its block\'s `", f, "`, which the block does not tell a generation of (gap DY)")))
                        : a);
                    goto _done;
                }
                if (prism_rtl::is<crate::lower::node_::Read::OwnRead>(r)) {
                    auto&& f = prism_rtl::as<crate::lower::node_::Read::OwnRead>(r).a0;
                    _v.set((crate::check::types::has_text(holds, f) || crate::check::types::has_text(derived, f)) || crate::check::types::has_text(roots, f)
                        ? a
                        : crate::prelude::push(a, crate::lower::expr::refusal_do(prism_rtl::cat("`!Updated` of a dynamic that reads `", f, "`, which no sink of this node writes (no height for its event)"))));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        });
    });
    return fold(wx.pending, own, [&](const Array<crate::lower::model::Do>& acc, const crate::lower::node_::PendingRow& p_) {
        return fold(updated_hears(prism_rtl::val(p_).wx), acc, [&](const Array<crate::lower::model::Do>& a, const Text& m) {
            return ({
                auto behind = reads_closed(wx.dyn_reads, Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{m})}));
                auto written = fold(behind, false, [&](const bool& w, const crate::lower::node_::Read& r) {
                    return prism_rtl::val(w) || ({
                        __label__ _done;
                        prism_rtl::Slot<bool> _v;
                        if (prism_rtl::is<crate::lower::node_::Read::OwnRead>(r)) {
                            auto&& h = prism_rtl::as<crate::lower::node_::Read::OwnRead>(r).a0;
                            _v.set(crate::check::types::has_text(holds, h));
                            goto _done;
                        }
                        if (prism_rtl::is<crate::lower::node_::Read::ParentRead>(r)) {
                            _v.set(true);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                });
                (crate::check::types::has_text(roots, m) || reaches_snap(roots, behind)
                ? crate::prelude::push(a, crate::lower::expr::refusal_do(prism_rtl::cat("`!Updated` of a dynamic in a row that reads its block\'s `", m, "`, a structural dynamic the block publishes at the start of a tick, not lowered for a row\'s `!Updated` (gap SU)")))
                : written || crate::check::types::has_text(derived, m)
                ? a
                : crate::prelude::push(a, crate::lower::expr::refusal_do(prism_rtl::cat("`!Updated` of a dynamic in a row that reads its block\'s `", m, "`, which no sink of the block writes (no height for its event)"))));
            });
        });
    });
}


/// FinishPending: unbounded fn Wx, [Gn] -> (([NodeDef], [Gn]))
std::tuple<Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>> finish_pending(const crate::lower::node_::Wx& wx, const Array<crate::lower::node_::Gn>& gns) {
    return run_to_end(fold_job(wx.pending, std::tuple{Array<crate::lower::model::NodeDef>{}, gns}, ({
        auto wx_1 = wx;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>>>(std::tuple<std::tuple<Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>>, crate::lower::node_::PendingRow>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>>, crate::lower::node_::PendingRow> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto wx_1_2 = wx_1;
            entered(once_job([=]() {
            return ({
                auto [defs, cur] = p0;
                auto p_ = p1;
                ({
                auto floors = fold(row_hears(prism_rtl::val(p_).wx), Map<Text, Nat>{}, [&](const Map<Text, Nat>& acc, const Text& m) { return insert(acc, m, parent_floor(wx_1_2, cur, Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{m})}))); });
                auto floored = ({
                    crate::lower::node_::Wx this_ = prism_rtl::val(p_).wx;
                    this_.floors = floors;
                    this_.gns = each(this_.gns, [&](const crate::lower::node_::Gn& g) {
                        return prism_rtl::val(g).kind == crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnUpdated{})
                            ? with_floor(g, parent_floor(wx_1_2, cur, reads_closed(prism_rtl::val(prism_rtl::val(p_).wx).dyn_reads, prism_rtl::val(g).reads)))
                            : g;
                    });
                    this_;
                });
                call_then(start_finish_node(floored, prism_rtl::val(p_).qk, prism_rtl::val(p_).params, true), [=](crate::lower::model::NodeDef finish_node_39907) {
                return ({
                    auto def = finish_node_39907;
                    auto next_ = ({
                        __label__ _done;
                        prism_rtl::Slot<Array<crate::lower::node_::Gn>> _v;
                        auto&& _m = prism_rtl::val(p_).gather;
                        if (prism_rtl::is_some(_m)) {
                            auto&& gid = prism_rtl::some_of(_m);
                            _v.set(each(cur, [&](const crate::lower::node_::Gn& g) {
                                return prism_rtl::val(g).id == gid
                                    ? with_height(g, prism_rtl::val(def).top + Nat(1u))
                                    : g;
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(cur);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    (prism_rtl::finished(std::tuple{crate::prelude::push(defs, def), next_}));
                });
            });
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>>> FinishPending::cycle() const {
    const auto& wx = this->wx;
    const auto& gns = this->gns;
    return fold_job(prism_rtl::val(wx).pending, std::tuple{Array<crate::lower::model::NodeDef>{}, gns}, ({
        auto wx_1 = wx;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>>>(std::tuple<std::tuple<Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>>, crate::lower::node_::PendingRow>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>>, crate::lower::node_::PendingRow> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto wx_1_2 = wx_1;
            entered(once_job([=]() {
            return ({
                auto [defs, cur] = p0;
                auto p_ = p1;
                ({
                auto floors = fold(row_hears(prism_rtl::val(p_).wx), Map<Text, Nat>{}, [&](const Map<Text, Nat>& acc, const Text& m) { return insert(acc, m, parent_floor(wx_1_2, cur, Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{m})}))); });
                auto floored = ({
                    crate::lower::node_::Wx this_ = prism_rtl::val(p_).wx;
                    this_.floors = floors;
                    this_.gns = each(this_.gns, [&](const crate::lower::node_::Gn& g) {
                        return prism_rtl::val(g).kind == crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnUpdated{})
                            ? with_floor(g, parent_floor(wx_1_2, cur, reads_closed(prism_rtl::val(prism_rtl::val(p_).wx).dyn_reads, prism_rtl::val(g).reads)))
                            : g;
                    });
                    this_;
                });
                call_then(start_finish_node(floored, prism_rtl::val(p_).qk, prism_rtl::val(p_).params, true), [=](crate::lower::model::NodeDef finish_node_39907) {
                return ({
                    auto def = finish_node_39907;
                    auto next_ = ({
                        __label__ _done;
                        prism_rtl::Slot<Array<crate::lower::node_::Gn>> _v;
                        auto&& _m = prism_rtl::val(p_).gather;
                        if (prism_rtl::is_some(_m)) {
                            auto&& gid = prism_rtl::some_of(_m);
                            _v.set(each(cur, [&](const crate::lower::node_::Gn& g) {
                                return prism_rtl::val(g).id == gid
                                    ? with_height(g, prism_rtl::val(def).top + Nat(1u))
                                    : g;
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(cur);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    (prism_rtl::finished(std::tuple{crate::prelude::push(defs, def), next_}));
                });
            });
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start FinishPending, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>>> start_finish_pending(crate::lower::node_::Wx wx, Array<crate::lower::node_::Gn> gns) {
    return prism_rtl::make_rc<FinishPending>(wx, gns);
}


/// ParentFloor: fn Wx, [Gn], [Read] -> Nat
Nat parent_floor(const crate::lower::node_::Wx& wx, const Array<crate::lower::node_::Gn>& gns, const Array<crate::lower::node_::Read>& reads) {
    return fold(reads, Nat(0u), [&](const Nat& hi, const crate::lower::node_::Read& r) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Nat> _v;
            if (prism_rtl::is<crate::lower::node_::Read::ParentRead>(r)) {
                auto&& m = prism_rtl::as<crate::lower::node_::Read::ParentRead>(r).a0;
                _v.set(fold(reads_closed(wx.dyn_reads, Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{m})})), hi, [&](const Nat& h2, const crate::lower::node_::Read& hr) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Nat> _v;
                        if (prism_rtl::is<crate::lower::node_::Read::OwnRead>(hr)) {
                            auto&& f = prism_rtl::as<crate::lower::node_::Read::OwnRead>(hr).a0;
                            _v.set(fold(gns, h2, [&](const Nat& h3, const crate::lower::node_::Gn& g) {
                                return writes_hold(g, f)
                                    ? crate::prelude::max(h3, prism_rtl::val(g).height + Nat(1u))
                                    : h3;
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is<crate::lower::node_::Read::ParentRead>(hr)) {
                            auto&& up = prism_rtl::as<crate::lower::node_::Read::ParentRead>(hr).a0;
                            _v.set(crate::prelude::max(h2, or_(crate::prelude::get(wx.floors, up), Nat(0u))));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                }));
                goto _done;
            }
            if (prism_rtl::is<crate::lower::node_::Read::OwnRead>(r)) {
                _v.set(hi);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// WritesHold: fn Gn, Text -> Bool
bool writes_hold(const crate::lower::node_::Gn& g, const Text& f) {
    return fold(g.outs, false, [&](const bool& acc, const crate::lower::node_::Out& o) { return prism_rtl::val(acc) || sink_writes_hold(prism_rtl::val(o).sink, f); });
}


/// SinkWritesHold: fn Sk, Text -> Bool
bool sink_writes_hold(const crate::lower::node_::Sk& sk0, const Text& f) {
    if (prism_rtl::is<crate::lower::node_::Sk::SkHold>(sk0)) {
        auto&& h = prism_rtl::as<crate::lower::node_::Sk::SkHold>(sk0).a0;
        return h == f;
    }
    if (prism_rtl::is<crate::lower::node_::Sk::SkDistinct>(sk0)) {
        auto&& h = prism_rtl::as<crate::lower::node_::Sk::SkDistinct>(sk0).a0;
        return h == f;
    }
    if (prism_rtl::is<crate::lower::node_::Sk::SkPerKey>(sk0)) {
        auto&& h = prism_rtl::as<crate::lower::node_::Sk::SkPerKey>(sk0).a0;
        return h == f;
    }
    if (prism_rtl::is<crate::lower::node_::Sk::SkMachine>(sk0)) {
        auto&& h = prism_rtl::as<crate::lower::node_::Sk::SkMachine>(sk0).a0;
        return h == f;
    }
    {
        auto&& other = sk0;
        return false;
    }
}


/// WithFloor: fn Gn, Nat -> Gn
crate::lower::node_::Gn with_floor(const crate::lower::node_::Gn& g, const Nat& h) {
    crate::lower::node_::Gn this_ = g;
    this_.floor = h;
    return this_;
}


/// WithHeight: fn Gn, Nat -> Gn
crate::lower::node_::Gn with_height(const crate::lower::node_::Gn& g, const Nat& h) {
    crate::lower::node_::Gn this_ = g;
    this_.height = h;
    return this_;
}


/// RowHears: fn Wx -> [Text]
Array<Text> row_hears(const crate::lower::node_::Wx& wx) {
    auto from_updated = fold(filter(wx.gns, [&](const crate::lower::node_::Gn& g) { return prism_rtl::val(g).kind == crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnUpdated{}); }), Array<crate::lower::node_::Read>{}, [&](const Array<crate::lower::node_::Read>& acc, const crate::lower::node_::Gn& g) { return crate::lower::node_::union_reads(acc, reads_closed(wx.dyn_reads, prism_rtl::val(g).reads)); });
    auto from_rows = fold(wx.row_marks, Array<crate::lower::node_::Read>{}, [&](const Array<crate::lower::node_::Read>& acc, const crate::lower::node_::RowMarks& rm) { return crate::lower::node_::union_reads(acc, reads_closed(wx.dyn_reads, append(prism_rtl::val(rm).reads, each(prism_rtl::val(rm).wrote, [&](const Text& m) { return crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{m}); })))); });
    auto from_builds = reads_closed(wx.dyn_reads, wx.build_holds);
    auto from_gens = fold(wx.gen_holds, Array<crate::lower::node_::Read>{}, [&](const Array<crate::lower::node_::Read>& acc, const std::tuple<Text, Array<crate::lower::node_::Read>>& _p1) {
        auto&& hs = std::get<1>(_p1);
        return crate::lower::node_::union_reads(acc, reads_closed(wx.dyn_reads, hs));
    });
    return fold(crate::lower::node_::union_reads(crate::lower::node_::union_reads(crate::lower::node_::union_reads(from_updated, from_rows), from_builds), from_gens), Array<Text>{}, [&](const Array<Text>& acc, const crate::lower::node_::Read& r) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            if (prism_rtl::is<crate::lower::node_::Read::ParentRead>(r)) {
                auto&& m = prism_rtl::as<crate::lower::node_::Read::ParentRead>(r).a0;
                _v.set(crate::check::types::add_text(acc, m));
                goto _done;
            }
            if (prism_rtl::is<crate::lower::node_::Read::OwnRead>(r)) {
                _v.set(acc);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// UpdatedHears: fn Wx -> [Text]
Array<Text> updated_hears(const crate::lower::node_::Wx& wx) {
    return fold(filter(wx.gns, [&](const crate::lower::node_::Gn& g) { return prism_rtl::val(g).kind == crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnUpdated{}); }), Array<Text>{}, [&](const Array<Text>& acc, const crate::lower::node_::Gn& g) {
        return fold(reads_closed(wx.dyn_reads, prism_rtl::val(g).reads), acc, [&](const Array<Text>& a, const crate::lower::node_::Read& r) {
            return ({
                __label__ _done;
                prism_rtl::Slot<Array<Text>> _v;
                if (prism_rtl::is<crate::lower::node_::Read::ParentRead>(r)) {
                    auto&& m = prism_rtl::as<crate::lower::node_::Read::ParentRead>(r).a0;
                    _v.set(crate::check::types::add_text(a, m));
                    goto _done;
                }
                if (prism_rtl::is<crate::lower::node_::Read::OwnRead>(r)) {
                    _v.set(a);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        });
    });
}


/// RowWritten: fn Wx, RowMarks, Read -> [Do]
Array<crate::lower::model::Do> row_written(const crate::lower::node_::Wx& wx, const crate::lower::node_::RowMarks& rm, const crate::lower::node_::Read& r) {
    auto dirty_1 = crate::lower::node_::has_read(reads_closed(wx.dyn_reads, rm.reads), r)
        ? Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("dirty"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")}))})})})})})
        : Array<crate::lower::model::Do>{};
    auto told = fold(rm.wrote, Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc, const Text& m) {
        return crate::lower::node_::has_read(reads_closed(wx.dyn_reads, Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{m})})), r)
            ? crate::prelude::push(acc, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")})), prism_rtl::cat("parent_wrote_", m), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})}))
            : acc;
    });
    auto body = append(dirty_1, told);
    return len(body) == Nat(0u)
        ? Array<crate::lower::model::Do>{}
        : ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::Do>> _v;
        auto&& _m = rm.kind;
        if (prism_rtl::is<crate::lower::model::RowKind::GenerationRow>(_m)) {
            _v.set(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), rm.builder})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}})), Text::lit("as_ref"), Array<crate::lower::model::Ex>{}}), body, Array<crate::lower::model::Do>{}})}));
            goto _done;
        }
        {
            _v.set(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoFor{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), rm.builder})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}})), Text::lit("values"), Array<crate::lower::model::Ex>{}}), body})}));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// PatchPlace: fn Wx, Place -> [Do]
Array<crate::lower::model::Do> patch_place(const crate::lower::node_::Wx& wx, const crate::lower::node_::Place& p_) {
    auto pull = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{p_.getter}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), p_.getter, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
    auto at_ = place_at(wx, Text::lit("self"), p_.pos);
    auto sent = crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("changed"), Array(std::vector{at_, crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{p_.getter})), Text::lit("level_pod"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})})});
    auto renew_1 = p_.watch == Text::lit("")
        ? Array<crate::lower::model::Do>{}
        : Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), p_.watch})), Text::lit("renew"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{p_.getter}))}), crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutObj{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Node"), Array<crate::lower::model::OutTy>{}}))})}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})});
    return append(Array(std::vector{pull, sent}), renew_1);
}


/// Emits: fn Wx, Pos -> Bool
bool emits(const crate::lower::node_::Wx& wx, const crate::lower::model::Pos_& pos) {
    return (pos.scope == Nat(0u)) && (wx.hosted_by == std::optional<Text>{});
}


/// ResultTold: fn Ex -> [Do]
Array<crate::lower::model::Do> result_told(const crate::lower::model::Ex& node_) {
    auto r_1 = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("r")}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(node_), Text::lit("result_value"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
    return Array(std::vector{r_1, result_kept(node_), result_tell()});
}


/// ResultMoved: fn Ex -> [Do]
Array<crate::lower::model::Do> result_moved(const crate::lower::model::Ex& node_) {
    auto r_1 = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("r")}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(node_), Text::lit("result_value"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
    auto last = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(node_), Text::lit("result_last")})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}})), Text::lit("as_ref"), Array<crate::lower::model::Ex>{}});
    auto differs = crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("!="), prism_rtl::rc(last), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("r")}))})})}))});
    return Array(std::vector{r_1, crate::lower::model::Do(crate::lower::model::Do::DoIf{differs, Array(std::vector{result_kept(node_), result_tell()}), Array<crate::lower::model::Do>{}})});
}


/// ResultKept: fn Ex -> Do
crate::lower::model::Do result_kept(const crate::lower::model::Ex& node_) {
    return crate::lower::model::Do(crate::lower::model::Do::DoAssign{crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(node_), Text::lit("result_last")})), Text::lit("borrow_mut"), Array<crate::lower::model::Ex>{}}))}), crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("r")}))})})})});
}


/// let resultTell
crate::lower::model::Do result_tell() {
    return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("result"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Outcome::Value"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("r")})})})})})});
}


/// Adoption: fn FlatDef -> [Do]
Array<crate::lower::model::Do> adoption(const crate::lower::node_::FlatDef& fl) {
    auto adopt = crate::lower::model::Ex(crate::lower::model::Ex::XLater{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), prism_rtl::cat(fl.name, "_adopt"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))});
    return Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("node")}), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})}), crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("answer_later"), Array(std::vector{adopt})})})});
}


/// PlaceAt: fn Wx, Text, Pos -> Ex
crate::lower::model::Ex place_at(const crate::lower::node_::Wx& wx, const Text& recv, const crate::lower::model::Pos_& pos) {
    auto at_ = Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XIndex{pos.at})});
    return emits(wx, pos)
        ? crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(recv == Text::lit("")
        ? crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("path")})
        : recv == Text::lit("self")
        ? crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("path")})
        : crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{recv})), Text::lit("path")})), Text::lit("at"), at_})
        : crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Path::root"), Array<crate::lower::model::Ex>{}})), Text::lit("at"), at_});
}


/// PosPat: fn Pos, [Pa] -> Pa
crate::lower::model::Pa pos_pat(const crate::lower::model::Pos_& pos, const Array<crate::lower::model::Pa>& tail) {
    return crate::lower::model::Pa(crate::lower::model::Pa::PaSlice{append(Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Segment::Pos"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaIndex{pos.at})})})}), tail)});
}


/// let keyTail
Array<crate::lower::model::Pa> key_tail() {
    return Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Segment::Key"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("k")})})}), crate::lower::model::Pa(crate::lower::model::Pa::PaRest{Text::lit("rest")})});
}


/// let genTail
Array<crate::lower::model::Pa> gen_tail() {
    return Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Segment::Gen"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("g")})})}), crate::lower::model::Pa(crate::lower::model::Pa::PaRest{Text::lit("rest")})});
}


/// ?HostedRows: fn Wx -> ?Text
std::optional<Text> hosted_rows(const crate::lower::node_::Wx& wx) {
    return prism_rtl::val(wx.pos).scope > Nat(0u)
        ? std::optional(prism_rtl::cat(or_(index(wx.scopes, crate::syntax::lexer::chars::dec(prism_rtl::val(wx.pos).scope)), Text::lit("")), "_moved"))
        : ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Text>> _v;
        auto&& _m = wx.hosted_by;
        if (prism_rtl::is_some(_m)) {
            _v.set(std::optional(Text::lit("document_moved")));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::optional<Text>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// RootDynPatch: fn Wx -> [Do]
Array<crate::lower::model::Do> root_dyn_patch(const crate::lower::node_::Wx& wx) {
    auto&& _m = wx.root_dyn;
    if (prism_rtl::is_some(_m)) {
        return Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLine{result_moved(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})});
    }
    if (prism_rtl::is_none(_m)) {
        return Array<crate::lower::model::Do>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// AnswerArm: fn Wx, Pos, Nat, OutTy -> ((Pa, Ex))
std::tuple<crate::lower::model::Pa, crate::lower::model::Ex> answer_arm(const crate::lower::node_::Wx& wx, const crate::lower::model::Pos_& pos, const Nat& id, const crate::lower::model::OutTy& t) {
    auto call = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::val(crate::lower::node_::gn_of(wx, id)).name, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XDecode{t, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})});
    return std::tuple{pos_pat(pos, Array<crate::lower::model::Pa>{}), call};
}


/// TypedAnswerArm: fn Wx, Pos, Nat, Text -> ((Pa, [Do]))
std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>> typed_answer_arm(const crate::lower::node_::Wx& wx, const crate::lower::model::Pos_& pos, const Nat& id, const Text& acc) {
    return std::tuple{pos_pat(pos, Array<crate::lower::model::Pa>{}), Array(std::vector{self_call(prism_rtl::val(crate::lower::node_::gn_of(wx, id)).name, Array(std::vector{crate::lower::expr::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")})), acc, Array<crate::lower::model::Ex>{}}))}))})};
}


/// TypedDynArm: fn Sinks, Pos, Text, Text -> ((Pa, [Do]))
std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>> typed_dyn_arm(const Sinks& sk, const crate::lower::model::Pos_& pos, const Text& f, const Text& acc) {
    return std::tuple{pos_pat(pos, Array<crate::lower::model::Pa>{}), dyn_place_write(sk, f, crate::lower::expr::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")})), acc, Array<crate::lower::model::Ex>{}})))};
}


/// TypedForwardArm: fn ForDef, Ex -> ((Pa, [Do]))
std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>> typed_forward_arm(const crate::lower::model::ForDef& b, const crate::lower::model::Ex& segs) {
    auto row_of = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(b.name)})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDecode{b.key_ty, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("k")}))}))})})})), Text::lit("cloned"), Array<crate::lower::model::Ex>{}});
    return std::tuple{pos_pat(b.pos, key_tail()), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")}), row_of}), crate::lower::model::Do(crate::lower::model::Do::DoMatch{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")}), Array(std::vector{std::tuple{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")})})}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::expr::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")})), Text::lit("deliver"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("rest")}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))})})}, std::tuple{crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{Text::lit("None")}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoReturn{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Fault::answer"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XFormatStr{Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XText{Text::lit("no row ")}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("k")}), crate::lower::model::Ex(crate::lower::model::Ex::XText{Text::lit(" under the hosted place ")}), crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Path"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(segs), Text::lit("to_vec"), Array<crate::lower::model::Ex>{}})})})})})})})})})})})}})})})};
}


/// TypedGenArm: fn GenDef -> ((Pa, [Do]))
std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>> typed_gen_arm(const crate::lower::model::GenDef& gd) {
    auto current = crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(gd.name)})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}}))});
    auto is_current = crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("=="), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("+"), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("g")}))})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XIndex{Nat(1u)}))})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(gd.name, "_count")})), Text::lit("get"), Array<crate::lower::model::Ex>{}}))});
    return std::tuple{pos_pat(gd.pos, gen_tail()), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")}), current}), crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIf{is_current, Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::expr::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")})), Text::lit("deliver"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("rest")}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))})}), Array<crate::lower::model::Do>{}})}), Array<crate::lower::model::Do>{}})})};
}


/// TypedDispatch: fn Sinks, Text, Nat -> MethDef
crate::lower::model::MethDef typed_dispatch(const Sinks& sk, const Text& name, const Nat& scope) {
    auto wx = sk.wx;
    auto in_scope_fn = ({
        auto scope_1 = scope;
        (prism_rtl::rc([=](const crate::lower::model::Pos_& p_) { return prism_rtl::val(p_).scope == scope_1; }));
    });
    auto [recv, param, segs, doc] = scope > Nat(0u)
        ? std::tuple{crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), std::tuple{Text::lit("place"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutPath{}))})}, crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("place")})), Text::lit("segments"), Array<crate::lower::model::Ex>{}}), prism_rtl::cat("The host at place ", crate::lower::model::place_text(prism_rtl::val(or_(index(prism_rtl::val(wx).hosts, crate::syntax::lexer::chars::dec(scope)), dummy_host())).pos), " answers its child\'s place `place` (pick HO): into the child\'s input method, a hold the place\'s element answers, or the row of a `for` or `rebuild` under it.")}
        : std::tuple{crate::lower::model::Recv(crate::lower::model::Recv::RecvOwned{}), std::tuple{Text::lit("at"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutSlice{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Segment"), Array<crate::lower::model::OutTy>{}}))}))})}, crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("at")}), Text::lit("A host\'s answer to a place of this row\'s own, `at` under the row (pick HO): into the input method, a hold, or a row under it.")};
    auto answers = each(filter(prism_rtl::val(wx).answers, [&](const std::tuple<crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        return in_scope_fn(pos);
    }), [&](const std::tuple<crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        auto&& id = std::get<1>(_p0);
        auto&& acc = std::get<3>(_p0);
        return typed_answer_arm(wx, pos, id, acc);
    });
    auto dyns = each(filter(prism_rtl::val(wx).dyn_places, [&](const std::tuple<crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        return in_scope_fn(pos);
    }), [&](const std::tuple<crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        auto&& f = std::get<1>(_p0);
        auto&& acc = std::get<3>(_p0);
        return typed_dyn_arm(sk, pos, f, acc);
    });
    auto rows = each(filter(prism_rtl::val(wx).builders, [&](const crate::lower::model::ForDef& b) { return in_scope_fn(prism_rtl::val(b).pos); }), [&](const crate::lower::model::ForDef& b) { return typed_forward_arm(b, segs); });
    auto gens = each(filter(prism_rtl::val(wx).gens, [&](const crate::lower::model::GenDef& gd) { return in_scope_fn(prism_rtl::val(gd).pos); }), [&](const crate::lower::model::GenDef& gd) { return typed_gen_arm(gd); });
    auto none = std::tuple{crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoReturn{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Fault::answer"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XFormatStr{Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XText{Text::lit("no hosted place at ")}), crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Path"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(segs), Text::lit("to_vec"), Array<crate::lower::model::Ex>{}})})}), crate::lower::model::Ex(crate::lower::model::Ex::XText{Text::lit(" to answer")})})})})})})})})})};
    auto arms = crate::prelude::push(append(append(append(answers, dyns), rows), gens), none);
    return crate::lower::model::MethDef{.name = name, .recv = recv, .params = Array(std::vector{param, std::tuple{Text::lit("v"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(crate::lower::types::answer_ty())})}}), .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Done"), Array<crate::lower::model::OutTy>{}}), .body = Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoMatch{segs, arms})}), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Ok"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})})}), .doc = doc};
}


/// let dummyHost
crate::lower::node_::HostDef dummy_host() {
    return crate::lower::node_::HostDef{.pos = crate::lower::model::pos0(), .name = Text::lit(""), .scope = Nat(0u)};
}


/// SortNats: fn [Nat] -> [Nat]
Array<Nat> sort_nats(const Array<Nat>& xs) {
    return fold(xs, Array<Nat>{}, [&](const Array<Nat>& acc, const Nat& x) { return append(crate::prelude::push(filter(acc, [&](const Nat& y) { return y < x; }), x), filter(acc, [&](const Nat& y) { return !(y < x); })); });
}


/// AskWake: fn Sinks, Nat -> [Do]
Array<crate::lower::model::Do> ask_wake(const Sinks& sk, const Nat& h) {
    auto c = crate::lower::model::Ex(crate::lower::model::Ex::XConst{wake_const(sk.heights, h)});
    auto ask_ = crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("wakes")})), Text::lit("ask"), Array(std::vector{c})})});
    auto wake_1 = crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("wake"), Array(std::vector{c, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})})})});
    return sk.many ? Array(std::vector{ask_, wake_1}) : Array(std::vector{wake_1});
}


/// GatherIn: fn Sinks, Gn -> MethDef
crate::lower::model::MethDef gather_in(const Sinks& sk, const crate::lower::node_::Gn& g) {
    auto field_ = or_(index(g.inputs, Nat(0u)), Text::lit(""));
    auto kt = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::OutTy> _v;
        auto&& _m = g.ty;
        if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(_m)) {
            auto&& k = prism_rtl::as<crate::lower::model::OutTy::OutMap>(_m).a0;
            _v.set(prism_rtl::val(prism_rtl::val(k)));
            goto _done;
        }
        {
            _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto vt = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::OutTy> _v;
        auto&& _m = g.ty;
        if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(_m)) {
            auto&& v_ = prism_rtl::as<crate::lower::model::OutTy::OutMap>(_m).a1;
            _v.set(prism_rtl::val(prism_rtl::val(v_)));
            goto _done;
        }
        {
            _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto current = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(field_)})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})), Text::lit("unwrap_or_default"), Array<crate::lower::model::Ex>{}});
    auto collect = Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("all")}), current}), crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("all")})), Text::lit("insert"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("k")}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")})})})}), crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(field_)})), Text::lit("set"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("all")}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})});
    auto body = append(collect, ask_wake(sk, g.height));
    return crate::lower::model::MethDef{.name = prism_rtl::cat(g.name, "_in"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array(std::vector{std::tuple{Text::lit("k"), kt}, std::tuple{Text::lit("v"), vt}}), .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = body, .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = Text::lit("A row\'s firing, gathered by its key.")};
}


/// Decide: fn Gn -> Do
crate::lower::model::Do decide(const crate::lower::node_::Gn& g) {
    auto&& _m = g.kind;
    if (prism_rtl::is<crate::lower::node_::GnKind::GnGather>(_m)) {
        return crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("v")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(or_(index(g.inputs, Nat(0u)), Text::lit("")))})), Text::lit("take"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{self_call(g.name, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")})}))}), Array<crate::lower::model::Do>{}});
    }
    if (prism_rtl::is<crate::lower::node_::GnKind::GnMerge>(_m)) {
        return merge_decide(g);
    }
    if (prism_rtl::is<crate::lower::node_::GnKind::GnUpdated>(_m)) {
        return updated_decide(g);
    }
    if (prism_rtl::is<crate::lower::node_::GnKind::GnMergeAll>(_m)) {
        auto pushes = each(g.inputs, [&](const Text& f) { return crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("x")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f)})), Text::lit("take"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("all")})), Text::lit("push_back"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("x")})})})})}), Array<crate::lower::model::Do>{}}); });
        auto start = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("all")})), g.ty}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Array::new"), Array<crate::lower::model::Ex>{}})});
        auto fire = crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{Text::lit("!"), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("all")})), Text::lit("is_empty"), Array<crate::lower::model::Ex>{}}))}), Array(std::vector{self_call(g.name, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("all")})}))}), Array<crate::lower::model::Do>{}});
        return crate::lower::model::Do(crate::lower::model::Do::DoBlock{crate::prelude::push(append(Array(std::vector{start}), pushes), fire)});
    }
    {
        auto&& kind = _m;
        return pair_decide(g, kind);
    }
}


/// UpdatedDecide: fn Gn -> Do
crate::lower::model::Do updated_decide(const crate::lower::node_::Gn& g) {
    return crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(g.name, "_moved")})), Text::lit("replace"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XBool{false})})}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("after")}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("after"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("cx")})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(g.name, "_value"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))})})})}), self_call(g.name, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("after")})}))}), Array<crate::lower::model::Do>{}});
}


/// PairDecide: fn Gn, GnKind -> Do
crate::lower::model::Do pair_decide(const crate::lower::node_::Gn& g, const crate::lower::node_::GnKind& kind) {
    auto get_l = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(or_(index(g.inputs, Nat(0u)), Text::lit("")))})), Text::lit("take"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})});
    auto get_r = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(or_(index(g.inputs, Nat(1u)), Text::lit("")))})), Text::lit("take"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})});
    auto both_ = crate::lower::model::Ex(crate::lower::model::Ex::XTuple{Array(std::vector{get_l, get_r})});
    auto fire_fn = ({
        auto g_1 = g;
        (prism_rtl::rc([=](const crate::lower::model::Ex& x) { return Array(std::vector{self_call(g_1.name, Array(std::vector{x}))}); }));
    });
    auto sa = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("a")})})});
    auto sb = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("b")})})});
    auto some2 = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{sa, sb})});
    auto left = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{sa, crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{Text::lit("None")})})});
    auto right = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{Text::lit("None")}), sb})});
    auto cases = ({
        __label__ _done;
        prism_rtl::Slot<Array<std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>>>> _v;
        if (prism_rtl::is<crate::lower::node_::GnKind::GnUnion>(kind)) {
            _v.set(Array(std::vector{std::tuple{some2, fire_fn(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("union"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("a")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("b")}))})})}))}, std::tuple{left, fire_fn(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("a")}))}, std::tuple{right, fire_fn(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("b")}))}, std::tuple{crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), Array<crate::lower::model::Do>{}}}));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::node_::GnKind::GnBoth>(kind)) {
            _v.set(Array(std::vector{std::tuple{some2, fire_fn(crate::lower::model::Ex(crate::lower::model::Ex::XTuple{Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("a")}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("b")})})}))}, std::tuple{crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), Array<crate::lower::model::Do>{}}}));
            goto _done;
        }
        {
            _v.set(Array(std::vector{std::tuple{left, fire_fn(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("a")}))}, std::tuple{crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), Array<crate::lower::model::Do>{}}}));
            goto _done;
        }
    _done:
        _v.take();
    });
    return crate::lower::model::Do(crate::lower::model::Do::DoMatch{both_, cases});
}


/// WakeByHeight: fn [Gn], [Nat] -> Do
crate::lower::model::Do wake_by_height(const Array<crate::lower::node_::Gn>& combs, const Array<Nat>& heights_) {
    return crate::lower::model::Do(crate::lower::model::Do::DoMatch{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("wakes")})), Text::lit("next"), Array<crate::lower::model::Ex>{}}), crate::prelude::push(each(heights_, [&](const Nat& h) { return std::tuple{crate::lower::model::Pa(crate::lower::model::Pa::PaConst{wake_const(heights_, h)}), each(filter(combs, [&](const crate::lower::node_::Gn& g) { return prism_rtl::val(g).height == h; }), [&](const crate::lower::node_::Gn& g) { return decide(g); })}; }), std::tuple{crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), Array<crate::lower::model::Do>{}})});
}


/// ForwardAnswer: fn ForDef -> Ex
crate::lower::model::Ex forward_answer(const crate::lower::model::ForDef& b) {
    auto row_of = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(b.name)})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDecode{b.key_ty, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("k")}))}))})})})), Text::lit("cloned"), Array<crate::lower::model::Ex>{}});
    return crate::lower::model::Ex(crate::lower::model::Ex::XBlock{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")}), row_of}), crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::expr::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")})), Text::lit("answer"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("rest")}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))})}), Array<crate::lower::model::Do>{}})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}))});
}


/// IsHold: fn OutTy -> Bool
bool is_hold(const crate::lower::model::OutTy& out_ty0) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutHold>(out_ty0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(out_ty0)) {
        auto&& c1_0_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(out_ty0).a0;
        if (c1_0_0 == Text::lit("prism_rtl::PerKey")) {
            return true;
        }
    }
    {
        auto&& other = out_ty0;
        return false;
    }
}


/// RowMethods: fn Wx -> [MethDef]
Array<crate::lower::model::MethDef> row_methods(const crate::lower::node_::Wx& wx) {
    auto removes = fold(filter(wx.places, [&](const crate::lower::node_::Place& p_) { return emits(wx, prism_rtl::val(p_).pos); }), Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc, const crate::lower::node_::Place& p_) {
        return append(acc, append(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("removed"), Array(std::vector{place_at(wx, Text::lit("self"), prism_rtl::val(p_).pos)})})})}), prism_rtl::val(p_).watch == Text::lit("")
            ? Array<crate::lower::model::Do>{}
            : Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::val(p_).watch})), Text::lit("drop_all"), Array<crate::lower::model::Ex>{}})})})));
    });
    auto nested = append(each(wx.builders, [&](const crate::lower::model::ForDef& b) { return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::val(b).name})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}})), Text::lit("values"), Array<crate::lower::model::Ex>{}})), Text::lit("for_each"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")})), Text::lit("leave_row"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))})})})}); }), each(wx.gens, [&](const crate::lower::model::GenDef& gd) { return crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::val(gd).name})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}})), Text::lit("as_ref"), Array<crate::lower::model::Ex>{}}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")})), Text::lit("leave_row"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})}), Array<crate::lower::model::Do>{}}); }));
    return Array(std::vector{crate::lower::model::MethDef{.name = Text::lit("remove_places"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = append(removes, nested), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = Text::lit("The row left: its places are torn down.")}});
}


/// GnDoc: fn Gn -> Text
Text gn_doc(const crate::lower::node_::Gn& g) {
    auto&& _m = g.kind;
    if (prism_rtl::is<crate::lower::node_::GnKind::GnAnswer>(_m)) {
        return prism_rtl::cat("`", g.name, "`: an answer at its place.");
    }
    if (prism_rtl::is<crate::lower::node_::GnKind::GnStarted>(_m)) {
        return Text::lit("`@started`, the tick after the build.");
    }
    if (prism_rtl::is<crate::lower::node_::GnKind::GnDeferred>(_m)) {
        return Text::lit("An `@Defer` firing, the tick after it was armed.");
    }
    if (prism_rtl::is<crate::lower::node_::GnKind::GnMerge>(_m)) {
        return prism_rtl::cat("The merge `", g.name, "`, decided in the wake.");
    }
    if (prism_rtl::is<crate::lower::node_::GnKind::GnUpdated>(_m)) {
        return Text::lit("`!Updated`: the dynamic\'s value after the tick, fired in the wake when a hold it reads was written (or a structural dynamic it reads was published, pick ST).");
    }
    {
        return prism_rtl::cat("`!", g.name, "`.");
    }
}


/// MergeDecide: fn Gn -> Do
crate::lower::model::Do merge_decide(const crate::lower::node_::Gn& g) {
    auto call = Array(std::vector{self_call(g.name, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")})}))});
    auto take_l = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("left")}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(or_(index(g.inputs, Nat(0u)), Text::lit("")))})), Text::lit("take"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
    auto take_r = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("right")}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(or_(index(g.inputs, Nat(1u)), Text::lit("")))})), Text::lit("take"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
    auto right_1 = crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("v")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("right")}), call, Array<crate::lower::model::Do>{}});
    return crate::lower::model::Do(crate::lower::model::Do::DoBlock{Array(std::vector{take_l, take_r, crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("v")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("left")}), call, Array(std::vector{right_1})})})});
}

}  // namespace crate::lower::node_::finish
