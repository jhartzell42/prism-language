// The module `Emit.Rust.Items`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <emit/rust/items/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Emit.Rust.Items`, from `target/bootstrap/cpp-src/prismc/emit/rust/items.prism`.
namespace crate::emit::rust::items {

/// Generics: fn [((Text, [Text]))] -> Text
Text generics(const Array<std::tuple<Text, Array<Text>>>& xs0) {
    {
        auto&& c0_0 = xs0;
        if (c0_0.size() == 0u) {
            return Text::lit("");
        }
    }
    {
        auto&& gs = xs0;
        return prism_rtl::cat("<", crate::syntax::lexer::chars::join(each(gs, [&](const std::tuple<Text, Array<Text>>& _p0) {
            auto&& g = std::get<0>(_p0);
            auto&& bs = std::get<1>(_p0);
            return len(bs) == Nat(0u)
                ? g
                : prism_rtl::cat(g, ": ", crate::syntax::lexer::chars::join(bs, Text::lit(" + ")));
        }), Text::lit(", ")), ">");
    }
}


/// GenericNames: fn [Text] -> Text
Text generic_names(const Array<Text>& xs0) {
    {
        auto&& c0_0 = xs0;
        if (c0_0.size() == 0u) {
            return Text::lit("");
        }
    }
    {
        auto&& ps = xs0;
        return prism_rtl::cat("<", crate::syntax::lexer::chars::join(ps, Text::lit(", ")), ">");
    }
}


/// Bounded: fn [Text], Text -> Text
Text bounded(const Array<Text>& xs0, const Text& text1) {
    auto&& _m = std::tuple{xs0, text1};
    {
        auto&& c0_0 = std::get<0>(_m);
        if (c0_0.size() == 0u) {
            return Text::lit("");
        }
    }
    {
        auto&& ps = std::get<0>(_m);
        auto&& tr = std::get<1>(_m);
        return prism_rtl::cat("<", crate::syntax::lexer::chars::join(each(ps, [&](const Text& p_) { return prism_rtl::cat(p_, ": ", tr); }), Text::lit(", ")), ">");
    }
    prism_rtl::unreachable("no arm matched");
}


/// RustItem: unbounded fn Item -> Text
Text rust_item(const crate::lower::model::Item& it) {
    if (prism_rtl::is<crate::lower::model::Item::ItTrait>(it)) {
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItTrait>(it).a0;
        return rust_trait(t);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItImpl>(it)) {
        auto&& i = prism_rtl::as<crate::lower::model::Item::ItImpl>(it).a0;
        return rust_impl(i);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItType>(it)) {
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItType>(it).a0;
        return type_decl(t);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItTag>(it)) {
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItTag>(it).a0;
        return rust_tag(t);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItRow>(it)) {
        auto&& r = prism_rtl::as<crate::lower::model::Item::ItRow>(it).a0;
        return rust_row(r);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItFn>(it)) {
        auto&& f = prism_rtl::as<crate::lower::model::Item::ItFn>(it).a0;
        return rust_fn(f);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItJob>(it)) {
        auto&& j = prism_rtl::as<crate::lower::model::Item::ItJob>(it).a0;
        return rust_job(j);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItNode>(it)) {
        auto&& n = prism_rtl::as<crate::lower::model::Item::ItNode>(it).a0;
        return rust_node(n);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItNote>(it)) {
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItNote>(it).a0;
        return prism_rtl::cat("// ", t, "\n");
    }
    if (prism_rtl::is<crate::lower::model::Item::ItRefused>(it)) {
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItRefused>(it).a0;
        return prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal(), crate::lower::expr::escape(t), "\");\n");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> RustItem::cycle() const {
    const auto& it = this->it;
    return ({
        prism_rtl::is<crate::lower::model::Item::ItTrait>(it) ? ({
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItTrait>(it).a0;
        prism_rtl::more(prism_rtl::rc(RustTrait(t)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItImpl>(it) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::Item::ItImpl>(it).a0;
        prism_rtl::more(prism_rtl::rc(RustImpl(i)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItType>(it) ? ({
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItType>(it).a0;
        prism_rtl::more(prism_rtl::rc(TypeDecl(t)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItTag>(it) ? ({
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItTag>(it).a0;
        prism_rtl::more(prism_rtl::rc(RustTag(t)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItRow>(it) ? ({
        auto&& r = prism_rtl::as<crate::lower::model::Item::ItRow>(it).a0;
        prism_rtl::more(prism_rtl::rc(RustRow(r)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItFn>(it) ? ({
        auto&& f = prism_rtl::as<crate::lower::model::Item::ItFn>(it).a0;
        prism_rtl::more(prism_rtl::rc(RustFn(f)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItJob>(it) ? ({
        auto&& j = prism_rtl::as<crate::lower::model::Item::ItJob>(it).a0;
        prism_rtl::more(prism_rtl::rc(RustJob(j)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItNode>(it) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Item::ItNode>(it).a0;
        prism_rtl::more(prism_rtl::rc(RustNode(n)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItNote>(it) ? ({
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItNote>(it).a0;
        prism_rtl::finished(prism_rtl::cat("// ", t, "\n"));
    })
        : prism_rtl::is<crate::lower::model::Item::ItRefused>(it) ? ({
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItRefused>(it).a0;
        prism_rtl::finished(prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal(), crate::lower::expr::escape(t), "\");\n"));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start RustItem, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_item(crate::lower::model::Item it) {
    return prism_rtl::make_rc<RustItem>(it);
}


/// RustTrait: unbounded fn TraitDef -> Text
Text rust_trait(const crate::lower::model::TraitDef& t) {
    auto ms = crate::syntax::lexer::chars::join(run_to_end(each_job(t.methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
        return entered(once_job([=]() {
            return ({
                auto f = p0;
                (prism_rtl::more(prism_rtl::rc(TraitMethod(f))));
            });
        }));
    })))), Text::lit("\n"));
    return prism_rtl::cat(crate::emit::rust::templates::source_doc(Text::lit(""), t.doc), "pub trait ", t.name, " {\n", crate::emit::rust::indent(ms), "\n}\n");
}


prism_rtl::Turn<Text> RustTrait::cycle() const {
    const auto& t = this->t;
    auto t_1 = t;
    return call_value(each_job(prism_rtl::val(t_1).methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
        return entered(once_job([=]() {
            return ({
                auto f = p0;
                (prism_rtl::more(prism_rtl::rc(TraitMethod(f))));
            });
        }));
    }))), [=](Array<Text> each_1796) {
        return ({
            auto ms = crate::syntax::lexer::chars::join(each_1796, Text::lit("\n"));
            (prism_rtl::finished(prism_rtl::cat(crate::emit::rust::templates::source_doc(Text::lit(""), prism_rtl::val(t_1).doc), "pub trait ", prism_rtl::val(t_1).name, " {\n", crate::emit::rust::indent(ms), "\n}\n")));
        });
    });
}


/// `Start RustTrait, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_trait(crate::lower::model::TraitDef t) {
    return prism_rtl::make_rc<RustTrait>(t);
}


/// Signature: unbounded fn FnDef, Text -> Text
Text signature(const crate::lower::model::FnDef& f, const Text& vis) {
    auto params = crate::syntax::lexer::chars::join(run_to_end(each_job(f.params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(crate::emit::rust::start_type_(t), [=](Text type__2029) { return prism_rtl::finished(prism_rtl::cat(n, ": ", type__2029)); });
            });
        }));
    })))), Text::lit(", "));
    return prism_rtl::cat(vis, "fn ", f.name, generics(f.generics), "(", params, ") -> ", crate::emit::rust::type_(f.ret));
}


prism_rtl::Turn<Text> Signature::cycle() const {
    const auto& f = this->f;
    const auto& vis = this->vis;
    auto f_1 = f;
    auto vis_2 = vis;
    return call_value(each_job(prism_rtl::val(f_1).params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(crate::emit::rust::start_type_(t), [=](Text type__2029) { return prism_rtl::finished(prism_rtl::cat(n, ": ", type__2029)); });
            });
        }));
    }))), [=](Array<Text> each_1995) {
        return ({
            auto params = crate::syntax::lexer::chars::join(each_1995, Text::lit(", "));
            call_then(crate::emit::rust::start_type_(prism_rtl::val(f_1).ret), [=](Text type__2102) { return prism_rtl::finished(prism_rtl::cat(vis_2, "fn ", prism_rtl::val(f_1).name, generics(prism_rtl::val(f_1).generics), "(", params, ") -> ", type__2102)); });
        });
    });
}


/// `Start Signature, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_signature(crate::lower::model::FnDef f, Text vis) {
    return prism_rtl::make_rc<Signature>(f, vis);
}


/// TraitMethod: unbounded fn FnDef -> Text
Text trait_method(const crate::lower::model::FnDef& f) {
    return f.public_
        ? crate::emit::rust::templates::items::fn_(Text::lit(""), signature(f, Text::lit("")), crate::emit::rust::body_lines(f.body))
        : prism_rtl::cat(signature(f, Text::lit("")), ";");
}


prism_rtl::Turn<Text> TraitMethod::cycle() const {
    const auto& f = this->f;
    return prism_rtl::val(f).public_
        ? ({
        auto f_1 = f;
        call_then(start_signature(f_1, Text::lit("")), [=](Text signature_2196) { return call_then(crate::emit::rust::start_body_lines(prism_rtl::val(f_1).body), [=](Text body_lines_2215) { return prism_rtl::finished(crate::emit::rust::templates::items::fn_(Text::lit(""), signature_2196, body_lines_2215)); }); });
    })
        : ({
        auto f_1 = f;
        call_then(start_signature(f_1, Text::lit("")), [=](Text signature_2241) { return prism_rtl::finished(prism_rtl::cat(signature_2241, ";")); });
    });
}


/// `Start TraitMethod, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_trait_method(crate::lower::model::FnDef f) {
    return prism_rtl::make_rc<TraitMethod>(f);
}


/// RustImpl: unbounded fn ImplDef -> Text
Text rust_impl(const crate::lower::model::ImplDef& i) {
    auto head = crate::emit::rust::type_(i.head);
    auto gens = generics(i.generics);
    auto&& _m = i.cls;
    {
        auto&& m2516_0 = _m;
        if (m2516_0 == Text::lit("Prelude.Show")) {
            auto fns = crate::syntax::lexer::chars::join(run_to_end(each_job(i.methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
                return entered(once_job([=]() {
                    return ({
                        auto f = p0;
                        (prism_rtl::more(prism_rtl::rc(RustFn(f))));
                    });
                }));
            })))), Text::lit("\n"));
            auto shown = or_(index(each(i.methods, [&](const crate::lower::model::FnDef& f) { return prism_rtl::val(f).name; }), Nat(0u)), Text::lit("show"));
            return prism_rtl::cat(fns, "\n", crate::emit::rust::templates::items::impl_(gens, Text::lit("Show"), head, Text::lit("fn show(&self, p: &mut Printer)"), prism_rtl::cat("p.raw(&", shown, "(self).to_string());")));
        }
    }
    {
        auto&& m2516_1 = _m;
        if (m2516_1 == Text::lit("Prelude.Eq")) {
            auto fns = crate::syntax::lexer::chars::join(run_to_end(each_job(i.methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
                return entered(once_job([=]() {
                    return ({
                        auto f = p0;
                        (prism_rtl::more(prism_rtl::rc(RustFn(f))));
                    });
                }));
            })))), Text::lit("\n"));
            auto eq = fold(i.methods, Text::lit(""), [&](const Text& acc, const crate::lower::model::FnDef& f) {
                return (!crate::syntax::lexer::chars::has_prefix(prism_rtl::val(f).name, Text::lit("ne"))) && (acc == Text::lit(""))
                    ? prism_rtl::val(f).name
                    : acc;
            });
            return prism_rtl::cat(fns, "\n", crate::emit::rust::templates::items::impl_(gens, Text::lit("PartialEq"), head, Text::lit("fn eq(&self, other: &Self) -> bool"), prism_rtl::cat(eq, "(self, other)")));
        }
    }
    {
        return prism_rtl::cat("impl", gens, " ", i.tr, " for ", head, " {\n", crate::emit::rust::indent(crate::syntax::lexer::chars::join(run_to_end(each_job(i.methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
            return entered(once_job([=]() {
                return ({
                    auto f = p0;
                    call_then(start_signature(f, Text::lit("")), [=](Text signature_3218) { return call_then(crate::emit::rust::start_body_lines(prism_rtl::val(f).body), [=](Text body_lines_3237) { return prism_rtl::finished(crate::emit::rust::templates::items::fn_(Text::lit(""), signature_3218, body_lines_3237)); }); });
                });
            }));
        })))), Text::lit("\n"))), "\n}\n");
    }
}


prism_rtl::Turn<Text> RustImpl::cycle() const {
    const auto& i = this->i;
    auto i_1 = i;
    return call_then(crate::emit::rust::start_type_(prism_rtl::val(i_1).head), [=](Text type__2465) {
        return ({
            auto head = type__2465;
            auto gens = generics(prism_rtl::val(i_1).generics);
            ({
            auto&& _m = prism_rtl::val(i_1).cls;
            ({
            auto&& m2516_0 = _m;
            (m2516_0 == Text::lit("Prelude.Show"));
        }) ? ({
            auto&& m2516_0 = _m;
            call_value(each_job(prism_rtl::val(i_1).methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
            return entered(once_job([=]() {
                return ({
                    auto f = p0;
                    (prism_rtl::more(prism_rtl::rc(RustFn(f))));
                });
            }));
        }))), [=](Array<Text> each_2581) {
            return ({
                auto fns = crate::syntax::lexer::chars::join(each_2581, Text::lit("\n"));
                auto shown = or_(index(each(prism_rtl::val(i_1).methods, [&](const crate::lower::model::FnDef& f) { return prism_rtl::val(f).name; }), Nat(0u)), Text::lit("show"));
                (prism_rtl::finished(prism_rtl::cat(fns, "\n", crate::emit::rust::templates::items::impl_(gens, Text::lit("Show"), head, Text::lit("fn show(&self, p: &mut Printer)"), prism_rtl::cat("p.raw(&", shown, "(self).to_string());")))));
            });
        });
        })
            : ({
            auto&& m2516_1 = _m;
            (m2516_1 == Text::lit("Prelude.Eq"));
        }) ? ({
            auto&& m2516_1 = _m;
            call_value(each_job(prism_rtl::val(i_1).methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
            return entered(once_job([=]() {
                return ({
                    auto f = p0;
                    (prism_rtl::more(prism_rtl::rc(RustFn(f))));
                });
            }));
        }))), [=](Array<Text> each_2856) {
            return ({
                auto fns = crate::syntax::lexer::chars::join(each_2856, Text::lit("\n"));
                auto eq = fold(prism_rtl::val(i_1).methods, Text::lit(""), [&](const Text& acc, const crate::lower::model::FnDef& f) {
                    return (!crate::syntax::lexer::chars::has_prefix(prism_rtl::val(f).name, Text::lit("ne"))) && (acc == Text::lit(""))
                        ? prism_rtl::val(f).name
                        : acc;
                });
                (prism_rtl::finished(prism_rtl::cat(fns, "\n", crate::emit::rust::templates::items::impl_(gens, Text::lit("PartialEq"), head, Text::lit("fn eq(&self, other: &Self) -> bool"), prism_rtl::cat(eq, "(self, other)")))));
            });
        });
        })
            : call_value(each_job(prism_rtl::val(i_1).methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
            return entered(once_job([=]() {
                return ({
                    auto f = p0;
                    call_then(start_signature(f, Text::lit("")), [=](Text signature_3218) { return call_then(crate::emit::rust::start_body_lines(prism_rtl::val(f).body), [=](Text body_lines_3237) { return prism_rtl::finished(crate::emit::rust::templates::items::fn_(Text::lit(""), signature_3218, body_lines_3237)); }); });
                });
            }));
        }))), [=](Array<Text> each_3189) { return prism_rtl::finished(prism_rtl::cat("impl", gens, " ", prism_rtl::val(i_1).tr, " for ", head, " {\n", crate::emit::rust::indent(crate::syntax::lexer::chars::join(each_3189, Text::lit("\n"))), "\n}\n")); });
        });
        });
    });
}


/// `Start RustImpl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_impl(crate::lower::model::ImplDef i) {
    return prism_rtl::make_rc<RustImpl>(i);
}


/// RustFn: unbounded fn FnDef -> Text
Text rust_fn(const crate::lower::model::FnDef& f) {
    auto params = crate::syntax::lexer::chars::join(run_to_end(each_job(f.params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(crate::emit::rust::start_type_(t), [=](Text type__3377) { return prism_rtl::finished(prism_rtl::cat(n, ": ", type__3377)); });
            });
        }));
    })))), Text::lit(", "));
    auto sig = prism_rtl::cat("pub fn ", f.name, static_generics(f.generics), "(", params, ") -> ", crate::emit::rust::type_(f.ret));
    return crate::emit::rust::templates::items::fn_(crate::emit::rust::templates::source_doc(Text::lit(""), f.doc), sig, crate::emit::rust::body_lines(f.body));
}


prism_rtl::Turn<Text> RustFn::cycle() const {
    const auto& f = this->f;
    auto f_1 = f;
    return call_value(each_job(prism_rtl::val(f_1).params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(crate::emit::rust::start_type_(t), [=](Text type__3377) { return prism_rtl::finished(prism_rtl::cat(n, ": ", type__3377)); });
            });
        }));
    }))), [=](Array<Text> each_3343) {
        return ({
            auto params = crate::syntax::lexer::chars::join(each_3343, Text::lit(", "));
            call_then(crate::emit::rust::start_type_(prism_rtl::val(f_1).ret), [=](Text type__3607) {
            return ({
                auto sig = prism_rtl::cat("pub fn ", prism_rtl::val(f_1).name, static_generics(prism_rtl::val(f_1).generics), "(", params, ") -> ", type__3607);
                call_then(crate::emit::rust::start_body_lines(prism_rtl::val(f_1).body), [=](Text body_lines_3656) { return prism_rtl::finished(crate::emit::rust::templates::items::fn_(crate::emit::rust::templates::source_doc(Text::lit(""), prism_rtl::val(f_1).doc), sig, body_lines_3656)); });
            });
        });
        });
    });
}


/// `Start RustFn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_fn(crate::lower::model::FnDef f) {
    return prism_rtl::make_rc<RustFn>(f);
}


/// StaticGenerics: fn [((Text, [Text]))] -> Text
Text static_generics(const Array<std::tuple<Text, Array<Text>>>& gs) {
    return generics(each(gs, [&](const std::tuple<Text, Array<Text>>& _p0) {
        auto&& g = std::get<0>(_p0);
        auto&& bs = std::get<1>(_p0);
        return std::tuple{g, crate::prelude::push(bs, Text::lit("\'static"))};
    }));
}


/// RustJob: unbounded fn JobDef -> Text
Text rust_job(const crate::lower::model::JobDef& j) {
    auto gnames = generic_names(each(j.generics, [&](const std::tuple<Text, Array<Text>>& _p0) {
        auto&& g = std::get<0>(_p0);
        return g;
    }));
    auto fields = crate::syntax::lexer::chars::join(run_to_end(each_job(j.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(crate::emit::rust::start_type_(t), [=](Text type__4062) { return prism_rtl::finished(prism_rtl::cat("pub ", n, ": ", type__4062, ",")); });
            });
        }));
    })))), Text::lit("\n"));
    auto params = crate::syntax::lexer::chars::join(run_to_end(each_job(j.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(crate::emit::rust::start_type_(t), [=](Text type__4136) { return prism_rtl::finished(prism_rtl::cat(n, ": ", type__4136)); });
            });
        }));
    })))), Text::lit(", "));
    auto bounded_ = static_generics(j.generics);
    auto start = prism_rtl::cat("pub fn ", j.start, bounded_, "(", params, ") -> Rc<dyn prism_rtl::Job<", crate::emit::rust::type_(j.ret), ">>");
    auto start_body = prism_rtl::cat("Rc::new(", j.name, " { ", crate::syntax::lexer::chars::join(each(j.fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
        auto&& n = std::get<0>(_p0);
        return n;
    }), Text::lit(", ")), " })");
    return crate::emit::rust::templates::items::job(crate::emit::rust::templates::source_doc(Text::lit(""), j.doc), j.name, gnames, bounded_, fields, crate::emit::rust::type_(j.ret), crate::emit::rust::body_lines(j.body), start, start_body);
}


prism_rtl::Turn<Text> RustJob::cycle() const {
    const auto& j = this->j;
    auto gnames = generic_names(each(prism_rtl::val(j).generics, [&](const std::tuple<Text, Array<Text>>& _p0) {
        auto&& g = std::get<0>(_p0);
        return g;
    }));
    auto j_1 = j;
    return call_value(each_job(prism_rtl::val(j_1).fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(crate::emit::rust::start_type_(t), [=](Text type__4062) { return prism_rtl::finished(prism_rtl::cat("pub ", n, ": ", type__4062, ",")); });
            });
        }));
    }))), [=](Array<Text> each_4024) {
        return ({
            auto fields = crate::syntax::lexer::chars::join(each_4024, Text::lit("\n"));
            call_value(each_job(prism_rtl::val(j_1).fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
            return entered(once_job([=]() {
                return ({
                    auto [n, t] = p0;
                    call_then(crate::emit::rust::start_type_(t), [=](Text type__4136) { return prism_rtl::finished(prism_rtl::cat(n, ": ", type__4136)); });
                });
            }));
        }))), [=](Array<Text> each_4102) {
            return ({
                auto params = crate::syntax::lexer::chars::join(each_4102, Text::lit(", "));
                auto bounded_ = static_generics(prism_rtl::val(j_1).generics);
                call_then(crate::emit::rust::start_type_(prism_rtl::val(j_1).ret), [=](Text type__4360) {
                return ({
                    auto start = prism_rtl::cat("pub fn ", prism_rtl::val(j_1).start, bounded_, "(", params, ") -> Rc<dyn prism_rtl::Job<", type__4360, ">>");
                    auto start_body = prism_rtl::cat("Rc::new(", prism_rtl::val(j_1).name, " { ", crate::syntax::lexer::chars::join(each(prism_rtl::val(j_1).fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                        auto&& n = std::get<0>(_p0);
                        return n;
                    }), Text::lit(", ")), " })");
                    call_then(crate::emit::rust::start_type_(prism_rtl::val(j_1).ret), [=](Text type__4535) { return call_then(crate::emit::rust::start_body_lines(prism_rtl::val(j_1).body), [=](Text body_lines_4549) { return prism_rtl::finished(crate::emit::rust::templates::items::job(crate::emit::rust::templates::source_doc(Text::lit(""), prism_rtl::val(j_1).doc), prism_rtl::val(j_1).name, gnames, bounded_, fields, type__4535, body_lines_4549, start, start_body)); }); });
                });
            });
            });
        });
        });
    });
}


/// `Start RustJob, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_job(crate::lower::model::JobDef j) {
    return prism_rtl::make_rc<RustJob>(j);
}


/// TypeDecl: unbounded fn TyDef -> Text
Text type_decl(const crate::lower::model::TyDef& t) {
    auto eq = t.eq && (!t.floaty);
    auto ord = t.ord && (!t.floaty);
    auto derives = crate::syntax::lexer::chars::join(filter(Array(std::vector{Text::lit("Clone"), t.eq || t.ord ? Text::lit("PartialEq") : Text::lit(""), eq || ord ? Text::lit("Eq") : Text::lit(""), t.ord ? Text::lit("PartialOrd") : Text::lit(""), ord ? Text::lit("Ord") : Text::lit("")}), [&](const Text& d) { return d != Text::lit(""); }), Text::lit(", "));
    auto head = prism_rtl::cat(t.name, generic_names(t.params));
    auto doc = crate::emit::rust::templates::source_doc(prism_rtl::cat("`", t.prism, "`:"), t.doc);
    auto decl = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                (crate::emit::rust::templates::items::struct_(doc, derives, head, crate::syntax::lexer::chars::join(run_to_end(each_job(prism_rtl::val(c).fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
                return entered(once_job([=]() {
                    return ({
                        auto [f, ft] = p0;
                        call_then(crate::emit::rust::start_type_(ft), [=](Text type__5309) { return prism_rtl::finished(prism_rtl::cat("pub ", f, ": ", type__5309, ",")); });
                    });
                }));
            })))), Text::lit("\n"))));
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeUnit>(_m)) {
            _v.set(crate::emit::rust::templates::items::tuple_struct(doc, derives, head, Text::lit("")));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                (crate::emit::rust::templates::items::tuple_struct(doc, derives, head, prism_rtl::cat("(", crate::syntax::lexer::chars::join(run_to_end(each_job(prism_rtl::val(c).fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
                return entered(once_job([=]() {
                    return ({
                        auto&& _ft = p0;
                        auto&& ft = std::get<1>(_ft);
                        call_then(crate::emit::rust::start_type_(ft), [=](Text type__5573) { return prism_rtl::finished(prism_rtl::cat("pub ", type__5573)); });
                    });
                }));
            })))), Text::lit(", ")), ")")));
            }));
            goto _done;
        }
        {
            _v.set(crate::emit::rust::templates::items::enum_(doc, derives, head, crate::syntax::lexer::chars::join(run_to_end(each_job(t.cases_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CaseDef)>>(prism_rtl::rc([=](crate::lower::model::CaseDef p0) {
                return entered(once_job([=]() {
                    return ({
                        auto c = p0;
                        (prism_rtl::more(prism_rtl::rc(EnumCase(c))));
                    });
                }));
            })))), Text::lit("\n"))));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto show_ = t.show_ == crate::lower::model::Shown(crate::lower::model::Shown::ShownDerived{})
        ? prism_rtl::cat("\n", show_impl(t, head))
        : Text::lit("");
    auto pod = t.pod
        ? prism_rtl::cat("\n", to_pod_impl(t, head), "\n", from_pod_impl(t, head))
        : Text::lit("");
    return prism_rtl::cat(decl, show_, pod);
}


prism_rtl::Turn<Text> TypeDecl::cycle() const {
    const auto& t = this->t;
    auto eq = prism_rtl::val(t).eq && (!prism_rtl::val(t).floaty);
    auto ord = prism_rtl::val(t).ord && (!prism_rtl::val(t).floaty);
    auto derives = crate::syntax::lexer::chars::join(filter(Array(std::vector{Text::lit("Clone"), prism_rtl::val(t).eq || prism_rtl::val(t).ord
        ? Text::lit("PartialEq")
        : Text::lit(""), eq || ord ? Text::lit("Eq") : Text::lit(""), prism_rtl::val(t).ord ? Text::lit("PartialOrd") : Text::lit(""), ord ? Text::lit("Ord") : Text::lit("")}), [&](const Text& d) { return d != Text::lit(""); }), Text::lit(", "));
    auto head = prism_rtl::cat(prism_rtl::val(t).name, generic_names(prism_rtl::val(t).params));
    auto doc = crate::emit::rust::templates::source_doc(prism_rtl::cat("`", prism_rtl::val(t).prism, "`:"), prism_rtl::val(t).doc);
    auto decl = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = prism_rtl::val(t).shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(prism_rtl::val(t).cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                (crate::emit::rust::templates::items::struct_(doc, derives, head, crate::syntax::lexer::chars::join(run_to_end(each_job(prism_rtl::val(c).fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
                return entered(once_job([=]() {
                    return ({
                        auto [f, ft] = p0;
                        call_then(crate::emit::rust::start_type_(ft), [=](Text type__5309) { return prism_rtl::finished(prism_rtl::cat("pub ", f, ": ", type__5309, ",")); });
                    });
                }));
            })))), Text::lit("\n"))));
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeUnit>(_m)) {
            _v.set(crate::emit::rust::templates::items::tuple_struct(doc, derives, head, Text::lit("")));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
            _v.set(({
                auto c = or_(index(prism_rtl::val(t).cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                (crate::emit::rust::templates::items::tuple_struct(doc, derives, head, prism_rtl::cat("(", crate::syntax::lexer::chars::join(run_to_end(each_job(prism_rtl::val(c).fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
                return entered(once_job([=]() {
                    return ({
                        auto&& _ft = p0;
                        auto&& ft = std::get<1>(_ft);
                        call_then(crate::emit::rust::start_type_(ft), [=](Text type__5573) { return prism_rtl::finished(prism_rtl::cat("pub ", type__5573)); });
                    });
                }));
            })))), Text::lit(", ")), ")")));
            }));
            goto _done;
        }
        {
            _v.set(crate::emit::rust::templates::items::enum_(doc, derives, head, crate::syntax::lexer::chars::join(run_to_end(each_job(prism_rtl::val(t).cases_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CaseDef)>>(prism_rtl::rc([=](crate::lower::model::CaseDef p0) {
                return entered(once_job([=]() {
                    return ({
                        auto c = p0;
                        (prism_rtl::more(prism_rtl::rc(EnumCase(c))));
                    });
                }));
            })))), Text::lit("\n"))));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto show_ = prism_rtl::val(t).show_ == crate::lower::model::Shown(crate::lower::model::Shown::ShownDerived{})
        ? prism_rtl::cat("\n", show_impl(t, head))
        : Text::lit("");
    auto pod = prism_rtl::val(t).pod
        ? prism_rtl::cat("\n", to_pod_impl(t, head), "\n", from_pod_impl(t, head))
        : Text::lit("");
    return prism_rtl::finished(prism_rtl::cat(decl, show_, pod));
}


/// `Start TypeDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_type_decl(crate::lower::model::TyDef t) {
    return prism_rtl::make_rc<TypeDecl>(t);
}


/// EnumCase: unbounded fn CaseDef -> Text
Text enum_case(const crate::lower::model::CaseDef& c) {
    return len(c.fields) == Nat(0u)
        ? prism_rtl::cat(c.name, ",")
        : prism_rtl::cat(c.name, "(", crate::syntax::lexer::chars::join(run_to_end(each_job(c.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto&& _ft = p0;
                auto&& ft = std::get<1>(_ft);
                (prism_rtl::more(prism_rtl::rc(crate::emit::rust::Type(ft))));
            });
        }));
    })))), Text::lit(", ")), "),");
}


prism_rtl::Turn<Text> EnumCase::cycle() const {
    const auto& c = this->c;
    return len(prism_rtl::val(c).fields) == Nat(0u)
        ? prism_rtl::finished(prism_rtl::cat(prism_rtl::val(c).name, ","))
        : ({
        auto c_1 = c;
        call_value(each_job(prism_rtl::val(c_1).fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto&& _ft = p0;
                auto&& ft = std::get<1>(_ft);
                (prism_rtl::more(prism_rtl::rc(crate::emit::rust::Type(ft))));
            });
        }));
    }))), [=](Array<Text> each_5975) { return prism_rtl::finished(prism_rtl::cat(prism_rtl::val(c_1).name, "(", crate::syntax::lexer::chars::join(each_5975, Text::lit(", ")), "),")); });
    });
}


/// `Start EnumCase, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_enum_case(crate::lower::model::CaseDef c) {
    return prism_rtl::make_rc<EnumCase>(c);
}


/// Binders: fn Nat -> [Text]
Array<Text> binders(const Nat& n) {
    return each(crate::check::errors::range0(n), [&](const Nat& i) { return prism_rtl::cat("a", i); });
}


/// CasePattern: fn TyDef, CaseDef -> Text
Text case_pattern(const crate::lower::model::TyDef& t, const crate::lower::model::CaseDef& c) {
    auto&& _m = t.shape;
    if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
        return prism_rtl::cat(t.name, "(", crate::syntax::lexer::chars::join(binders(len(c.fields)), Text::lit(", ")), ")");
    }
    if (prism_rtl::is<crate::lower::model::TyShape::ShapeUnit>(_m)) {
        return t.name;
    }
    {
        return len(c.fields) == Nat(0u)
            ? prism_rtl::cat(t.name, "::", c.name)
            : prism_rtl::cat(t.name, "::", c.name, "(", crate::syntax::lexer::chars::join(binders(len(c.fields)), Text::lit(", ")), ")");
    }
}


/// ShowImpl: unbounded fn TyDef, Text -> Text
Text show_impl(const crate::lower::model::TyDef& t, const Text& head) {
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                (prism_rtl::cat("p.record(\"", t.prism, "\", &[", crate::syntax::lexer::chars::join(each(prism_rtl::val(c).fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                auto&& f = std::get<0>(_p0);
                return prism_rtl::cat("(\"", prism_field(f), "\", &self.", f, ")");
            }), Text::lit(", ")), "]);"));
            }));
            goto _done;
        }
        {
            _v.set(crate::emit::rust::templates::items::match_self(crate::syntax::lexer::chars::join(each(t.cases_, [&](const crate::lower::model::CaseDef& c) { return prism_rtl::cat(case_pattern(t, c), " => p.choice(\"", prism_rtl::val(c).prism, "\", &[", crate::syntax::lexer::chars::join(binders(len(prism_rtl::val(c).fields)), Text::lit(", ")), "]),"); }), Text::lit("\n"))));
            goto _done;
        }
    _done:
        _v.take();
    });
    return crate::emit::rust::templates::items::impl_(bounded(t.params, Text::lit("Show")), Text::lit("Show"), head, Text::lit("fn show(&self, p: &mut Printer)"), body);
}


prism_rtl::Turn<Text> ShowImpl::cycle() const {
    const auto& t = this->t;
    const auto& head = this->head;
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = prism_rtl::val(t).shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(prism_rtl::val(t).cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                (prism_rtl::cat("p.record(\"", prism_rtl::val(t).prism, "\", &[", crate::syntax::lexer::chars::join(each(prism_rtl::val(c).fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                auto&& f = std::get<0>(_p0);
                return prism_rtl::cat("(\"", prism_field(f), "\", &self.", f, ")");
            }), Text::lit(", ")), "]);"));
            }));
            goto _done;
        }
        {
            _v.set(crate::emit::rust::templates::items::match_self(crate::syntax::lexer::chars::join(each(prism_rtl::val(t).cases_, [&](const crate::lower::model::CaseDef& c) { return prism_rtl::cat(case_pattern(t, c), " => p.choice(\"", prism_rtl::val(c).prism, "\", &[", crate::syntax::lexer::chars::join(binders(len(prism_rtl::val(c).fields)), Text::lit(", ")), "]),"); }), Text::lit("\n"))));
            goto _done;
        }
    _done:
        _v.take();
    });
    return prism_rtl::finished(crate::emit::rust::templates::items::impl_(bounded(prism_rtl::val(t).params, Text::lit("Show")), Text::lit("Show"), head, Text::lit("fn show(&self, p: &mut Printer)"), body));
}


/// `Start ShowImpl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_show_impl(crate::lower::model::TyDef t, Text head) {
    return prism_rtl::make_rc<ShowImpl>(t, head);
}


/// PrismField: fn Text -> Text
Text prism_field(const Text& f) {
    return crate::syntax::lexer::chars::last_char(f) == Text::lit("_")
        ? crate::syntax::lexer::chars::before_last(f)
        : f;
}


/// ToPodImpl: unbounded fn TyDef, Text -> Text
Text to_pod_impl(const crate::lower::model::TyDef& t, const Text& head) {
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                (prism_rtl::cat("Pod::record(\"", t.prism, "\", vec![", crate::syntax::lexer::chars::join(each(prism_rtl::val(c).fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                auto&& f = std::get<0>(_p0);
                return prism_rtl::cat("(\"", prism_field(f), "\", self.", f, ".to_pod())");
            }), Text::lit(", ")), "])"));
            }));
            goto _done;
        }
        {
            _v.set(crate::emit::rust::templates::items::match_self(crate::syntax::lexer::chars::join(each(t.cases_, [&](const crate::lower::model::CaseDef& c) { return prism_rtl::cat(case_pattern(t, c), " => Pod::Choice(\"", prism_rtl::val(c).prism, "\".into(), vec![", crate::syntax::lexer::chars::join(each(binders(len(prism_rtl::val(c).fields)), [&](const Text& b) { return prism_rtl::cat(b, ".to_pod()"); }), Text::lit(", ")), "]),"); }), Text::lit("\n"))));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto shown = t.show_ == crate::lower::model::Shown(crate::lower::model::Shown::ShownOwn{})
        ? crate::emit::rust::templates::items::shown_pod(body)
        : body;
    return crate::emit::rust::templates::items::impl_(bounded(t.params, Text::lit("ToPod")), Text::lit("ToPod"), head, Text::lit("fn to_pod(&self) -> Pod"), shown);
}


prism_rtl::Turn<Text> ToPodImpl::cycle() const {
    const auto& t = this->t;
    const auto& head = this->head;
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = prism_rtl::val(t).shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(prism_rtl::val(t).cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                (prism_rtl::cat("Pod::record(\"", prism_rtl::val(t).prism, "\", vec![", crate::syntax::lexer::chars::join(each(prism_rtl::val(c).fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                auto&& f = std::get<0>(_p0);
                return prism_rtl::cat("(\"", prism_field(f), "\", self.", f, ".to_pod())");
            }), Text::lit(", ")), "])"));
            }));
            goto _done;
        }
        {
            _v.set(crate::emit::rust::templates::items::match_self(crate::syntax::lexer::chars::join(each(prism_rtl::val(t).cases_, [&](const crate::lower::model::CaseDef& c) { return prism_rtl::cat(case_pattern(t, c), " => Pod::Choice(\"", prism_rtl::val(c).prism, "\".into(), vec![", crate::syntax::lexer::chars::join(each(binders(len(prism_rtl::val(c).fields)), [&](const Text& b) { return prism_rtl::cat(b, ".to_pod()"); }), Text::lit(", ")), "]),"); }), Text::lit("\n"))));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto shown = prism_rtl::val(t).show_ == crate::lower::model::Shown(crate::lower::model::Shown::ShownOwn{})
        ? crate::emit::rust::templates::items::shown_pod(body)
        : body;
    return prism_rtl::finished(crate::emit::rust::templates::items::impl_(bounded(prism_rtl::val(t).params, Text::lit("ToPod")), Text::lit("ToPod"), head, Text::lit("fn to_pod(&self) -> Pod"), shown));
}


/// `Start ToPodImpl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_to_pod_impl(crate::lower::model::TyDef t, Text head) {
    return prism_rtl::make_rc<ToPodImpl>(t, head);
}


/// FromPodImpl: unbounded fn TyDef, Text -> Text
Text from_pod_impl(const crate::lower::model::TyDef& t, const Text& head) {
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                (prism_rtl::cat("Ok(", t.name, " { ", crate::syntax::lexer::chars::join(each(prism_rtl::val(c).fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                auto&& f = std::get<0>(_p0);
                return prism_rtl::cat(f, ": FromPod::from_pod(field(p, \"", prism_field(f), "\")?)?");
            }), Text::lit(", ")), " })"));
            }));
            goto _done;
        }
        {
            _v.set(({
                auto arms = each(t.cases_, [&](const crate::lower::model::CaseDef& c) {
                    return ({
                        auto n = len(prism_rtl::val(c).fields);
                        auto made = n == Nat(0u)
                            ? t.shape == crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeUnit{})
                            ? t.name
                            : prism_rtl::cat(t.name, "::", prism_rtl::val(c).name)
                            : prism_rtl::cat(t.shape == crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeNewtype{})
                            ? t.name
                            : prism_rtl::cat(t.name, "::", prism_rtl::val(c).name), "(", crate::syntax::lexer::chars::join(each(crate::check::errors::range0(n), [&](const Nat& i) { return prism_rtl::cat("FromPod::from_pod(&a[", i, "])?"); }), Text::lit(", ")), ")");
                        (prism_rtl::cat("Pod::Choice(c, a) if &**c == \"", prism_rtl::val(c).prism, "\" && a.len() == ", n, " => Ok(", made, "),"));
                    });
                });
                (crate::emit::rust::templates::items::from_pod_body(crate::syntax::lexer::chars::join(arms, Text::lit("\n")), prism_rtl::cat("a ", t.prism)));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
    return crate::emit::rust::templates::items::impl_(bounded(t.params, Text::lit("FromPod")), Text::lit("FromPod"), head, Text::lit("fn from_pod(p: &Pod) -> Result<Self, Fault>"), body);
}


prism_rtl::Turn<Text> FromPodImpl::cycle() const {
    const auto& t = this->t;
    const auto& head = this->head;
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = prism_rtl::val(t).shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(prism_rtl::val(t).cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                (prism_rtl::cat("Ok(", prism_rtl::val(t).name, " { ", crate::syntax::lexer::chars::join(each(prism_rtl::val(c).fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                auto&& f = std::get<0>(_p0);
                return prism_rtl::cat(f, ": FromPod::from_pod(field(p, \"", prism_field(f), "\")?)?");
            }), Text::lit(", ")), " })"));
            }));
            goto _done;
        }
        {
            _v.set(({
                auto arms = each(prism_rtl::val(t).cases_, [&](const crate::lower::model::CaseDef& c) {
                    return ({
                        auto n = len(prism_rtl::val(c).fields);
                        auto made = n == Nat(0u)
                            ? prism_rtl::val(t).shape == crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeUnit{})
                            ? prism_rtl::val(t).name
                            : prism_rtl::cat(prism_rtl::val(t).name, "::", prism_rtl::val(c).name)
                            : prism_rtl::cat(prism_rtl::val(t).shape == crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeNewtype{})
                            ? prism_rtl::val(t).name
                            : prism_rtl::cat(prism_rtl::val(t).name, "::", prism_rtl::val(c).name), "(", crate::syntax::lexer::chars::join(each(crate::check::errors::range0(n), [&](const Nat& i) { return prism_rtl::cat("FromPod::from_pod(&a[", i, "])?"); }), Text::lit(", ")), ")");
                        (prism_rtl::cat("Pod::Choice(c, a) if &**c == \"", prism_rtl::val(c).prism, "\" && a.len() == ", n, " => Ok(", made, "),"));
                    });
                });
                (crate::emit::rust::templates::items::from_pod_body(crate::syntax::lexer::chars::join(arms, Text::lit("\n")), prism_rtl::cat("a ", prism_rtl::val(t).prism)));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
    return prism_rtl::finished(crate::emit::rust::templates::items::impl_(bounded(prism_rtl::val(t).params, Text::lit("FromPod")), Text::lit("FromPod"), head, Text::lit("fn from_pod(p: &Pod) -> Result<Self, Fault>"), body));
}


/// `Start FromPodImpl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_from_pod_impl(crate::lower::model::TyDef t, Text head) {
    return prism_rtl::make_rc<FromPodImpl>(t, head);
}


/// RustTag: unbounded fn TagDef -> Text
Text rust_tag(const crate::lower::model::TagDef& t) {
    auto fields = crate::syntax::lexer::chars::join(run_to_end(each_job(t.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto&& _f = p0;
                auto&& f = std::get<1>(_f);
                auto&& ft = std::get<2>(_f);
                call_then(crate::emit::rust::start_type_(ft), [=](Text type__8982) { return prism_rtl::finished(prism_rtl::cat("pub ", f, ": ", type__8982, ",")); });
            });
        }));
    })))), Text::lit("\n"));
    auto pods = crate::syntax::lexer::chars::join(each(t.fields, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& p_ = std::get<0>(_p0);
        auto&& f = std::get<1>(_p0);
        return prism_rtl::cat("(\"", p_, "\", self.", f, ".to_pod())");
    }), Text::lit(", "));
    auto derives = t.eq ? Text::lit("Clone, PartialEq") : Text::lit("Clone");
    auto reads = crate::syntax::lexer::chars::join(each(t.fields, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& p_ = std::get<0>(_p0);
        auto&& f = std::get<1>(_p0);
        return prism_rtl::cat(f, ": FromPod::from_pod(field(p, \"", p_, "\")?)?");
    }), Text::lit(", "));
    auto back_ = t.pod
        ? prism_rtl::cat("\n", crate::emit::rust::templates::items::tag_from_pod(t.name, t.tag_name, reads))
        : Text::lit("");
    auto deep = run_to_end(fold_job(t.fields, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto d = p0;
                auto&& _ft = p1;
                auto&& ft = std::get<2>(_ft);
                (prism_rtl::finished(d || crate::lower::types::holds_dyn(ft)));
            });
        }));
    }))));
    auto deep_pods = crate::syntax::lexer::chars::join(run_to_end(each_job(t.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [p_, f, ft] = p0;
                (prism_rtl::more(prism_rtl::rc(DeepField(p_, f, ft))));
            });
        }));
    })))), Text::lit(", "));
    auto deep_ports_ = concat(run_to_end(each_job(t.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto&& _f = p0;
                auto&& f = std::get<1>(_f);
                auto&& ft = std::get<2>(_f);
                (prism_rtl::more(prism_rtl::rc(DeepPorts(f, ft))));
            });
        }));
    })))));
    auto levels = deep
        ? prism_rtl::cat("\n", crate::emit::rust::templates::items::tag_level(t.name, t.tag_name, deep_pods, deep_ports_))
        : Text::lit("");
    return prism_rtl::cat(crate::emit::rust::templates::items::tag(crate::emit::rust::templates::source_doc(prism_rtl::cat("The `Level` of `", t.tag_name, "`:"), t.doc), derives, t.name, fields, t.tag_name, pods), back_, levels);
}


prism_rtl::Turn<Text> RustTag::cycle() const {
    const auto& t = this->t;
    auto t_1 = t;
    return call_value(each_job(prism_rtl::val(t_1).fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto&& _f = p0;
                auto&& f = std::get<1>(_f);
                auto&& ft = std::get<2>(_f);
                call_then(crate::emit::rust::start_type_(ft), [=](Text type__8982) { return prism_rtl::finished(prism_rtl::cat("pub ", f, ": ", type__8982, ",")); });
            });
        }));
    }))), [=](Array<Text> each_8935) {
        return ({
            auto fields = crate::syntax::lexer::chars::join(each_8935, Text::lit("\n"));
            auto pods = crate::syntax::lexer::chars::join(each(prism_rtl::val(t_1).fields, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
                auto&& p_ = std::get<0>(_p0);
                auto&& f = std::get<1>(_p0);
                return prism_rtl::cat("(\"", p_, "\", self.", f, ".to_pod())");
            }), Text::lit(", "));
            auto derives = prism_rtl::val(t_1).eq ? Text::lit("Clone, PartialEq") : Text::lit("Clone");
            auto reads = crate::syntax::lexer::chars::join(each(prism_rtl::val(t_1).fields, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
                auto&& p_ = std::get<0>(_p0);
                auto&& f = std::get<1>(_p0);
                return prism_rtl::cat(f, ": FromPod::from_pod(field(p, \"", p_, "\")?)?");
            }), Text::lit(", "));
            auto back_ = prism_rtl::val(t_1).pod
                ? prism_rtl::cat("\n", crate::emit::rust::templates::items::tag_from_pod(prism_rtl::val(t_1).name, prism_rtl::val(t_1).tag_name, reads))
                : Text::lit("");
            call_value(fold_job(prism_rtl::val(t_1).fields, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto d = p0;
                    auto&& _ft = p1;
                    auto&& ft = std::get<2>(_ft);
                    (prism_rtl::finished(d || crate::lower::types::holds_dyn(ft)));
                });
            }));
        }))), [=](bool fold_9355) {
            return ({
                auto deep = fold_9355;
                call_value(each_job(prism_rtl::val(t_1).fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
                return entered(once_job([=]() {
                    return ({
                        auto [p_, f, ft] = p0;
                        (prism_rtl::more(prism_rtl::rc(DeepField(p_, f, ft))));
                    });
                }));
            }))), [=](Array<Text> each_9448) {
                return ({
                    auto deep_pods = crate::syntax::lexer::chars::join(each_9448, Text::lit(", "));
                    call_value(each_job(prism_rtl::val(t_1).fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
                    return entered(once_job([=]() {
                        return ({
                            auto&& _f = p0;
                            auto&& f = std::get<1>(_f);
                            auto&& ft = std::get<2>(_f);
                            (prism_rtl::more(prism_rtl::rc(DeepPorts(f, ft))));
                        });
                    }));
                }))), [=](Array<Text> each_9533) {
                    return ({
                        auto deep_ports_ = concat(each_9533);
                        auto levels = deep
                            ? prism_rtl::cat("\n", crate::emit::rust::templates::items::tag_level(prism_rtl::val(t_1).name, prism_rtl::val(t_1).tag_name, deep_pods, deep_ports_))
                            : Text::lit("");
                        (prism_rtl::finished(prism_rtl::cat(crate::emit::rust::templates::items::tag(crate::emit::rust::templates::source_doc(prism_rtl::cat("The `Level` of `", prism_rtl::val(t_1).tag_name, "`:"), prism_rtl::val(t_1).doc), derives, prism_rtl::val(t_1).name, fields, prism_rtl::val(t_1).tag_name, pods), back_, levels)));
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start RustTag, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_tag(crate::lower::model::TagDef t) {
    return prism_rtl::make_rc<RustTag>(t);
}


/// DeepField: unbounded fn Text, Text, OutTy -> Text
Text deep_field(const Text& p_, const Text& f, const crate::lower::model::OutTy& ft) {
    return prism_rtl::cat("(\"", p_, "\", ", deep_pod(f, ft), ")");
}


prism_rtl::Turn<Text> DeepField::cycle() const {
    const auto& p_ = this->p_;
    const auto& f = this->f;
    const auto& ft = this->ft;
    auto f_1 = f;
    auto ft_2 = ft;
    auto p__3 = p_;
    return call_then(start_deep_pod(f_1, ft_2), [=](Text deep_pod_9881) { return prism_rtl::finished(prism_rtl::cat("(\"", p__3, "\", ", deep_pod_9881, ")")); });
}


/// `Start DeepField, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_deep_field(Text p_, Text f, crate::lower::model::OutTy ft) {
    return prism_rtl::make_rc<DeepField>(p_, f, ft);
}


/// DeepPod: unbounded fn Text, OutTy -> Text
Text deep_pod(const Text& f, const crate::lower::model::OutTy& ft) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(ft)) {
        auto&& m10135_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(ft).a1;
        if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(prism_rtl::val(prism_rtl::val(m10135_0_1)))) {
            auto&& m10135_0_1_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(prism_rtl::val(prism_rtl::val(m10135_0_1))).a0;
            if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::val(prism_rtl::val(m10135_0_1_r_0)))) {
                auto&& m10135_0_1_r_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::val(prism_rtl::val(m10135_0_1_r_0))).a0;
                if (m10135_0_1_r_0_r_0 == Text::lit("crate::Elem")) {
                    return prism_rtl::cat("prism_rtl::dynamics_pod(&self.", f, ", cx)");
                }
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(ft)) {
        auto&& m10135_1_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(ft).a0;
        if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::val(prism_rtl::val(m10135_1_0)))) {
            auto&& m10135_1_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::val(prism_rtl::val(m10135_1_0))).a0;
            if (m10135_1_0_r_0 == Text::lit("crate::Elem")) {
                return prism_rtl::cat("prism_rtl::Level::level_pod(&self.", f, ".sample(cx), cx)");
            }
        }
    }
    {
        auto&& other = ft;
        return crate::lower::types::holds_dyn(other)
            ? Text::lit("compile_error!(\"prismc: a tag field holding a dynamic other than `$Elem` or a map of them is not read deep (claude/incremental-host-document.md, doubt WD)\")")
            : prism_rtl::cat("self.", f, ".to_pod()");
    }
}


prism_rtl::Turn<Text> DeepPod::cycle() const {
    const auto& f = this->f;
    const auto& ft = this->ft;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutMap>(ft) && ({
        auto&& m10135_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(ft).a1;
        prism_rtl::is<crate::lower::model::OutTy::OutDyn>(prism_rtl::val(prism_rtl::val(m10135_0_1))) && ({
        auto&& m10135_0_1_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(prism_rtl::val(prism_rtl::val(m10135_0_1))).a0;
        prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::val(prism_rtl::val(m10135_0_1_r_0))) && ({
        auto&& m10135_0_1_r_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::val(prism_rtl::val(m10135_0_1_r_0))).a0;
        (m10135_0_1_r_0_r_0 == Text::lit("crate::Elem"));
    });
    });
    }) ? ({
        auto&& m10135_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(ft).a1;
        auto&& m10135_0_1_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(prism_rtl::val(prism_rtl::val(m10135_0_1))).a0;
        auto&& m10135_0_1_r_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::val(prism_rtl::val(m10135_0_1_r_0))).a0;
        prism_rtl::finished(prism_rtl::cat("prism_rtl::dynamics_pod(&self.", f, ", cx)"));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutDyn>(ft) && ({
        auto&& m10135_1_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(ft).a0;
        prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::val(prism_rtl::val(m10135_1_0))) && ({
        auto&& m10135_1_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::val(prism_rtl::val(m10135_1_0))).a0;
        (m10135_1_0_r_0 == Text::lit("crate::Elem"));
    });
    }) ? ({
        auto&& m10135_1_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(ft).a0;
        auto&& m10135_1_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::val(prism_rtl::val(m10135_1_0))).a0;
        prism_rtl::finished(prism_rtl::cat("prism_rtl::Level::level_pod(&self.", f, ".sample(cx), cx)"));
    })
        : ({
        auto&& other = ft;
        ({
        auto f_1 = f;
        auto other_2 = other;
        call_then(crate::lower::types::start_holds_dyn(other_2), [=](bool holds_dyn_10363) {
        return holds_dyn_10363
            ? prism_rtl::finished(Text::lit("compile_error!(\"prismc: a tag field holding a dynamic other than `$Elem` or a map of them is not read deep (claude/incremental-host-document.md, doubt WD)\")"))
            : prism_rtl::finished(prism_rtl::cat("self.", f_1, ".to_pod()"));
    });
    });
    });
    });
}


/// `Start DeepPod, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_deep_pod(Text f, crate::lower::model::OutTy ft) {
    return prism_rtl::make_rc<DeepPod>(f, ft);
}


/// DeepPorts: unbounded fn Text, OutTy -> Text
Text deep_ports(const Text& f, const crate::lower::model::OutTy& ft) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(ft)) {
        auto&& m10632_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(ft).a1;
        if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(prism_rtl::val(prism_rtl::val(m10632_0_1)))) {
            auto&& m10632_0_1_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(prism_rtl::val(prism_rtl::val(m10632_0_1))).a0;
            if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::val(prism_rtl::val(m10632_0_1_r_0)))) {
                auto&& m10632_0_1_r_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::val(prism_rtl::val(m10632_0_1_r_0))).a0;
                if (m10632_0_1_r_0_r_0 == Text::lit("crate::Elem")) {
                    return prism_rtl::cat("\n        prism_rtl::dynamics_ports(&self.", f, ", cx, out);");
                }
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(ft)) {
        auto&& m10632_1_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(ft).a0;
        if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::val(prism_rtl::val(m10632_1_0)))) {
            auto&& m10632_1_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::val(prism_rtl::val(m10632_1_0))).a0;
            if (m10632_1_0_r_0 == Text::lit("crate::Elem")) {
                return prism_rtl::cat("\n        out.push(self.", f, ".updates.clone());\n        prism_rtl::Level::level_ports(&self.", f, ".sample(cx), cx, out);");
            }
        }
    }
    {
        return Text::lit("");
    }
}


prism_rtl::Turn<Text> DeepPorts::cycle() const {
    const auto& f = this->f;
    const auto& ft = this->ft;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutMap>(ft) && ({
        auto&& m10632_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(ft).a1;
        prism_rtl::is<crate::lower::model::OutTy::OutDyn>(prism_rtl::val(prism_rtl::val(m10632_0_1))) && ({
        auto&& m10632_0_1_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(prism_rtl::val(prism_rtl::val(m10632_0_1))).a0;
        prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::val(prism_rtl::val(m10632_0_1_r_0))) && ({
        auto&& m10632_0_1_r_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::val(prism_rtl::val(m10632_0_1_r_0))).a0;
        (m10632_0_1_r_0_r_0 == Text::lit("crate::Elem"));
    });
    });
    }) ? ({
        auto&& m10632_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(ft).a1;
        auto&& m10632_0_1_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(prism_rtl::val(prism_rtl::val(m10632_0_1))).a0;
        auto&& m10632_0_1_r_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::val(prism_rtl::val(m10632_0_1_r_0))).a0;
        prism_rtl::finished(prism_rtl::cat("\n        prism_rtl::dynamics_ports(&self.", f, ", cx, out);"));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutDyn>(ft) && ({
        auto&& m10632_1_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(ft).a0;
        prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::val(prism_rtl::val(m10632_1_0))) && ({
        auto&& m10632_1_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::val(prism_rtl::val(m10632_1_0))).a0;
        (m10632_1_0_r_0 == Text::lit("crate::Elem"));
    });
    }) ? ({
        auto&& m10632_1_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(ft).a0;
        auto&& m10632_1_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::val(prism_rtl::val(m10632_1_0))).a0;
        prism_rtl::finished(prism_rtl::cat("\n        out.push(self.", f, ".updates.clone());\n        prism_rtl::Level::level_ports(&self.", f, ".sample(cx), cx, out);"));
    })
        : prism_rtl::finished(Text::lit(""));
    });
}


/// `Start DeepPorts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_deep_ports(Text f, crate::lower::model::OutTy ft) {
    return prism_rtl::make_rc<DeepPorts>(f, ft);
}


/// RustRow: unbounded fn RowDef -> Text
Text rust_row(const crate::lower::model::RowDef& r) {
    auto derives = r.eq ? Text::lit("Clone, PartialEq") : Text::lit("Clone");
    auto cases = crate::syntax::lexer::chars::join(each(r.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        auto&& st = std::get<1>(_p0);
        return prism_rtl::cat(v_, "(", st, "),");
    }), Text::lit("\n"));
    auto pods = crate::syntax::lexer::chars::join(each(r.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        return prism_rtl::cat(r.name, "::", v_, "(x) => x.to_pod(),");
    }), Text::lit("\n"));
    auto reads = crate::syntax::lexer::chars::join(each(r.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        auto&& st = std::get<1>(_p0);
        return prism_rtl::cat("Some(t) if t == ", st, "::TAG => Ok(", r.name, "::", v_, "(FromPod::from_pod(p)?)),");
    }), Text::lit("\n"));
    auto back_ = r.pod
        ? prism_rtl::cat("\n", crate::emit::rust::templates::items::row_from_pod(r.name, reads))
        : Text::lit("");
    auto pods2 = len(r.cases_) == Nat(0u) ? Text::lit("_ => unreachable!(),") : pods;
    auto deep_pods = concat(each(r.deep, [&](const Text& v_) { return prism_rtl::cat(r.name, "::", v_, "(x) => x.level_pod(cx),\n            "); }));
    auto deep_ports_ = concat(each(r.deep, [&](const Text& v_) { return prism_rtl::cat(r.name, "::", v_, "(x) => x.level_ports(cx, out),\n            "); }));
    auto level = r.level
        ? prism_rtl::cat("\n", crate::emit::rust::templates::items::row_level(r.name, deep_pods, deep_ports_))
        : Text::lit("");
    return prism_rtl::cat(crate::emit::rust::templates::items::row(crate::emit::rust::templates::source_doc(prism_rtl::cat("`", r.prism, "`, a row kind\'s values:"), r.doc), derives, r.name, cases, pods2), back_, level);
}


prism_rtl::Turn<Text> RustRow::cycle() const {
    const auto& r = this->r;
    auto derives = prism_rtl::val(r).eq ? Text::lit("Clone, PartialEq") : Text::lit("Clone");
    auto cases = crate::syntax::lexer::chars::join(each(prism_rtl::val(r).cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        auto&& st = std::get<1>(_p0);
        return prism_rtl::cat(v_, "(", st, "),");
    }), Text::lit("\n"));
    auto pods = crate::syntax::lexer::chars::join(each(prism_rtl::val(r).cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        return prism_rtl::cat(prism_rtl::val(r).name, "::", v_, "(x) => x.to_pod(),");
    }), Text::lit("\n"));
    auto reads = crate::syntax::lexer::chars::join(each(prism_rtl::val(r).cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        auto&& st = std::get<1>(_p0);
        return prism_rtl::cat("Some(t) if t == ", st, "::TAG => Ok(", prism_rtl::val(r).name, "::", v_, "(FromPod::from_pod(p)?)),");
    }), Text::lit("\n"));
    auto back_ = prism_rtl::val(r).pod
        ? prism_rtl::cat("\n", crate::emit::rust::templates::items::row_from_pod(prism_rtl::val(r).name, reads))
        : Text::lit("");
    auto pods2 = len(prism_rtl::val(r).cases_) == Nat(0u)
        ? Text::lit("_ => unreachable!(),")
        : pods;
    auto deep_pods = concat(each(prism_rtl::val(r).deep, [&](const Text& v_) { return prism_rtl::cat(prism_rtl::val(r).name, "::", v_, "(x) => x.level_pod(cx),\n            "); }));
    auto deep_ports_ = concat(each(prism_rtl::val(r).deep, [&](const Text& v_) { return prism_rtl::cat(prism_rtl::val(r).name, "::", v_, "(x) => x.level_ports(cx, out),\n            "); }));
    auto level = prism_rtl::val(r).level
        ? prism_rtl::cat("\n", crate::emit::rust::templates::items::row_level(prism_rtl::val(r).name, deep_pods, deep_ports_))
        : Text::lit("");
    return prism_rtl::finished(prism_rtl::cat(crate::emit::rust::templates::items::row(crate::emit::rust::templates::source_doc(prism_rtl::cat("`", prism_rtl::val(r).prism, "`, a row kind\'s values:"), prism_rtl::val(r).doc), derives, prism_rtl::val(r).name, cases, pods2), back_, level));
}


/// `Start RustRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_row(crate::lower::model::RowDef r) {
    return prism_rtl::make_rc<RustRow>(r);
}


/// RustAnswer: unbounded fn AnswerDef -> Text
Text rust_answer(const crate::lower::model::AnswerDef& a) {
    auto cases = crate::syntax::lexer::chars::join(run_to_end(each_job(a.cases_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=](crate::lower::model::AnswerCase p0) {
        return entered(once_job([=]() {
            return ({
                auto c = p0;
                call_then(crate::emit::rust::start_type_(prism_rtl::val(c).ty), [=](Text type__12424) { return prism_rtl::finished(prism_rtl::cat(prism_rtl::val(c).variant, "(", type__12424, "),")); });
            });
        }));
    })))), Text::lit("\n"));
    auto tags = len(a.cases_) == Nat(0u)
        ? Text::lit("_ => unreachable!(),")
        : crate::syntax::lexer::chars::join(each(a.cases_, [&](const crate::lower::model::AnswerCase& c) { return prism_rtl::cat("Answer::", prism_rtl::val(c).variant, "(_) => ", prism_rtl::val(c).struct_path, "::TAG,"); }), Text::lit("\n"));
    auto accessors = crate::syntax::lexer::chars::join(run_to_end(each_job(a.cases_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=](crate::lower::model::AnswerCase p0) {
        return entered(once_job([=]() {
            return ({
                auto c = p0;
                call_then(crate::emit::rust::start_type_(prism_rtl::val(c).ty), [=](Text type__12686) { return prism_rtl::finished(crate::emit::rust::templates::items::answer_getter(prism_rtl::val(c).accessor, prism_rtl::val(c).variant, prism_rtl::val(c).tag_name, type__12686)); });
            });
        }));
    })))), Text::lit("\n"));
    auto decodes = len(a.cases_) == Nat(0u)
        ? Text::lit("_ => unreachable!(),")
        : crate::syntax::lexer::chars::join(run_to_end(each_job(a.cases_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=](crate::lower::model::AnswerCase p0) {
        return entered(once_job([=]() {
            return ({
                auto c = p0;
                call_then(crate::emit::rust::start_decode_head(prism_rtl::val(c).ty), [=](Text decode_head_12849) { return prism_rtl::finished(prism_rtl::cat("Elem::", prism_rtl::val(c).variant, "(..) => Ok(Answer::", prism_rtl::val(c).variant, "(", decode_head_12849, "::from_pod(v)?)),")); });
            });
        }));
    })))), Text::lit("\n"));
    return crate::emit::rust::templates::items::answer_type(cases, tags, accessors, decodes);
}


prism_rtl::Turn<Text> RustAnswer::cycle() const {
    const auto& a = this->a;
    auto a_1 = a;
    return call_value(each_job(prism_rtl::val(a_1).cases_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=](crate::lower::model::AnswerCase p0) {
        return entered(once_job([=]() {
            return ({
                auto c = p0;
                call_then(crate::emit::rust::start_type_(prism_rtl::val(c).ty), [=](Text type__12424) { return prism_rtl::finished(prism_rtl::cat(prism_rtl::val(c).variant, "(", type__12424, "),")); });
            });
        }));
    }))), [=](Array<Text> each_12391) {
        return ({
            auto cases = crate::syntax::lexer::chars::join(each_12391, Text::lit("\n"));
            auto tags = len(prism_rtl::val(a_1).cases_) == Nat(0u)
                ? Text::lit("_ => unreachable!(),")
                : crate::syntax::lexer::chars::join(each(prism_rtl::val(a_1).cases_, [&](const crate::lower::model::AnswerCase& c) { return prism_rtl::cat("Answer::", prism_rtl::val(c).variant, "(_) => ", prism_rtl::val(c).struct_path, "::TAG,"); }), Text::lit("\n"));
            call_value(each_job(prism_rtl::val(a_1).cases_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=](crate::lower::model::AnswerCase p0) {
            return entered(once_job([=]() {
                return ({
                    auto c = p0;
                    call_then(crate::emit::rust::start_type_(prism_rtl::val(c).ty), [=](Text type__12686) { return prism_rtl::finished(crate::emit::rust::templates::items::answer_getter(prism_rtl::val(c).accessor, prism_rtl::val(c).variant, prism_rtl::val(c).tag_name, type__12686)); });
                });
            }));
        }))), [=](Array<Text> each_12619) {
            return ({
                auto accessors = crate::syntax::lexer::chars::join(each_12619, Text::lit("\n"));
                auto decodes = len(prism_rtl::val(a_1).cases_) == Nat(0u)
                    ? Text::lit("_ => unreachable!(),")
                    : crate::syntax::lexer::chars::join(run_to_end(each_job(prism_rtl::val(a_1).cases_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=](crate::lower::model::AnswerCase p0) {
                    return entered(once_job([=]() {
                        return ({
                            auto c = p0;
                            call_then(crate::emit::rust::start_decode_head(prism_rtl::val(c).ty), [=](Text decode_head_12849) { return prism_rtl::finished(prism_rtl::cat("Elem::", prism_rtl::val(c).variant, "(..) => Ok(Answer::", prism_rtl::val(c).variant, "(", decode_head_12849, "::from_pod(v)?)),")); });
                        });
                    }));
                })))), Text::lit("\n"));
                (prism_rtl::finished(crate::emit::rust::templates::items::answer_type(cases, tags, accessors, decodes)));
            });
        });
        });
    });
}


/// `Start RustAnswer, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_answer(crate::lower::model::AnswerDef a) {
    return prism_rtl::make_rc<RustAnswer>(a);
}


/// RustNode: unbounded fn NodeDef -> Text
Text rust_node(const crate::lower::model::NodeDef& n) {
    auto fields = crate::syntax::lexer::chars::join(run_to_end(each_job(n.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy, Text>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy, Text> p0) {
        return entered(once_job([=]() {
            return ({
                auto [f, t, doc] = p0;
                call_then(crate::emit::rust::start_type_(t), [=](Text type__13266) { return prism_rtl::finished(prism_rtl::cat(crate::emit::rust::templates::doc(doc), f, ": ", type__13266, ",")); });
            });
        }));
    })))), Text::lit("\n"));
    auto consts = concat(each(n.consts, [&](const std::tuple<Text, Nat, Text>& _p0) {
        auto&& c = std::get<0>(_p0);
        auto&& h = std::get<1>(_p0);
        auto&& doc = std::get<2>(_p0);
        return prism_rtl::cat(crate::emit::rust::templates::doc(prism_rtl::cat("The ", doc, ".")), "const ", c, ": u32 = ", h, ";\n");
    }));
    auto params = concat(run_to_end(each_job(n.params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [p_, t] = p0;
                call_then(crate::emit::rust::start_type_(t), [=](Text type__13444) { return prism_rtl::finished(prism_rtl::cat(p_, ": ", type__13444, ", ")); });
            });
        }));
    })))));
    auto ret = n.fallible
        ? prism_rtl::cat("Result<Rc<", n.name, ">, Fault>")
        : prism_rtl::cat("Rc<", n.name, ">");
    auto inits = crate::syntax::lexer::chars::join(append(Array(std::vector{Text::lit("path")}), run_to_end(each_job(n.inits, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::Ex> p0) {
        return entered(once_job([=]() {
            return ({
                auto [f, v_] = p0;
                (prism_rtl::more(prism_rtl::rc(crate::emit::rust::FieldInit(f, v_))));
            });
        }));
    }))))), Text::lit(", "));
    auto tail = n.fallible ? Text::lit("Ok(node)") : Text::lit("node");
    auto rest_text = len(n.build) == Nat(0u)
        ? tail
        : prism_rtl::cat(crate::emit::rust::statements(n.build), "\n", tail);
    auto build_1 = crate::emit::rust::templates::items::build(n.name, params, ret, crate::emit::rust::statements(n.lets), inits, rest_text);
    auto methods = crate::syntax::lexer::chars::join(run_to_end(each_job(n.methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::MethDef)>>(prism_rtl::rc([=](crate::lower::model::MethDef p0) {
        return entered(once_job([=]() {
            return ({
                auto m = p0;
                (prism_rtl::more(prism_rtl::rc(RustMethod(m))));
            });
        }));
    })))), Text::lit("\n"));
    auto answer_2 = len(n.answers) == Nat(0u)
        ? Text::lit("")
        : crate::emit::rust::templates::items::answer(crate::syntax::lexer::chars::join(run_to_end(each_job(n.answers, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<crate::lower::model::Pa, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<crate::lower::model::Pa, crate::lower::model::Ex> p0) {
        return entered(once_job([=]() {
            return ({
                auto [pat, call] = p0;
                call_then(crate::emit::rust::start_pattern(pat), [=](Text pattern_14010) { return call_then(crate::emit::rust::start_expression(call), [=](Text expression_14027) { return prism_rtl::finished(prism_rtl::cat(pattern_14010, " => ", expression_14027, ",")); }); });
            });
        }));
    })))), Text::lit("\n")));
    auto builders = concat(append(run_to_end(each_job(n.builders, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::ForDef)>>(prism_rtl::rc([=](crate::lower::model::ForDef p0) {
        return entered(once_job([=]() {
            return ({
                auto b = p0;
                call_then(start_for_builder(b), [=](Text for_builder_14115) { return prism_rtl::finished(prism_rtl::cat("\n", for_builder_14115)); });
            });
        }));
    })))), run_to_end(each_job(n.gens, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::GenDef)>>(prism_rtl::rc([=](crate::lower::model::GenDef p0) {
        return entered(once_job([=]() {
            return ({
                auto gd = p0;
                call_then(start_gen_builder(gd), [=](Text gen_builder_14156) { return prism_rtl::finished(prism_rtl::cat("\n", gen_builder_14156)); });
            });
        }));
    }))))));
    auto row_impl = n.row_kind == crate::lower::model::RowKind(crate::lower::model::RowKind::NotARow{})
        ? Text::lit("")
        : prism_rtl::cat("\n", rust_row_impl(n));
    auto hooks = crate::syntax::lexer::chars::join(run_to_end(each_job(n.hooks, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Array<crate::lower::model::Do>>)>>(prism_rtl::rc([=](std::tuple<Text, Array<crate::lower::model::Do>> p0) {
        return entered(once_job([=]() {
            return ({
                auto [h, body] = p0;
                h == Text::lit("push")
                ? call_then(crate::emit::rust::start_statements(body), [=](Text statements_14323) { return prism_rtl::finished(crate::emit::rust::templates::items::push_hook(statements_14323)); })
                : call_then(crate::emit::rust::start_statements(body), [=](Text statements_14355) { return prism_rtl::finished(crate::emit::rust::templates::items::hook(h, statements_14355)); });
            });
        }));
    })))), Text::lit("\n"));
    auto doc = crate::emit::rust::templates::source_doc(prism_rtl::cat("`", n.prism, "`: a node of its own (claude/backend.md, \"A widget block\")."), n.doc);
    return prism_rtl::cat(crate::emit::rust::templates::items::node_(doc, n.name, fields, consts, build_1, prism_rtl::cat(methods, builders), hooks, answer_2), row_impl);
}


prism_rtl::Turn<Text> RustNode::cycle() const {
    const auto& n = this->n;
    auto n_1 = n;
    return call_value(each_job(prism_rtl::val(n_1).fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy, Text>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy, Text> p0) {
        return entered(once_job([=]() {
            return ({
                auto [f, t, doc] = p0;
                call_then(crate::emit::rust::start_type_(t), [=](Text type__13266) { return prism_rtl::finished(prism_rtl::cat(crate::emit::rust::templates::doc(doc), f, ": ", type__13266, ",")); });
            });
        }));
    }))), [=](Array<Text> each_13218) {
        return ({
            auto fields = crate::syntax::lexer::chars::join(each_13218, Text::lit("\n"));
            auto consts = concat(each(prism_rtl::val(n_1).consts, [&](const std::tuple<Text, Nat, Text>& _p0) {
                auto&& c = std::get<0>(_p0);
                auto&& h = std::get<1>(_p0);
                auto&& doc = std::get<2>(_p0);
                return prism_rtl::cat(crate::emit::rust::templates::doc(prism_rtl::cat("The ", doc, ".")), "const ", c, ": u32 = ", h, ";\n");
            }));
            call_value(each_job(prism_rtl::val(n_1).params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
            return entered(once_job([=]() {
                return ({
                    auto [p_, t] = p0;
                    call_then(crate::emit::rust::start_type_(t), [=](Text type__13444) { return prism_rtl::finished(prism_rtl::cat(p_, ": ", type__13444, ", ")); });
                });
            }));
        }))), [=](Array<Text> each_13410) {
            return ({
                auto params = concat(each_13410);
                auto ret = prism_rtl::val(n_1).fallible
                    ? prism_rtl::cat("Result<Rc<", prism_rtl::val(n_1).name, ">, Fault>")
                    : prism_rtl::cat("Rc<", prism_rtl::val(n_1).name, ">");
                call_value(each_job(prism_rtl::val(n_1).inits, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::Ex> p0) {
                return entered(once_job([=]() {
                    return ({
                        auto [f, v_] = p0;
                        (prism_rtl::more(prism_rtl::rc(crate::emit::rust::FieldInit(f, v_))));
                    });
                }));
            }))), [=](Array<Text> each_13578) {
                return ({
                    auto inits = crate::syntax::lexer::chars::join(append(Array(std::vector{Text::lit("path")}), each_13578), Text::lit(", "));
                    auto tail = prism_rtl::val(n_1).fallible ? Text::lit("Ok(node)") : Text::lit("node");
                    auto rest_text = len(n_1->build) == Nat(0u)
                        ? tail
                        : prism_rtl::cat(crate::emit::rust::statements(n_1->build), "\n", tail);
                    call_then(crate::emit::rust::start_statements(prism_rtl::val(n_1).lets), [=](Text statements_13809) {
                    return ({
                        auto build_2 = crate::emit::rust::templates::items::build(prism_rtl::val(n_1).name, params, ret, statements_13809, inits, rest_text);
                        call_value(each_job(prism_rtl::val(n_1).methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::MethDef)>>(prism_rtl::rc([=](crate::lower::model::MethDef p0) {
                        return entered(once_job([=]() {
                            return ({
                                auto m = p0;
                                (prism_rtl::more(prism_rtl::rc(RustMethod(m))));
                            });
                        }));
                    }))), [=](Array<Text> each_13869) {
                        return ({
                            auto methods = crate::syntax::lexer::chars::join(each_13869, Text::lit("\n"));
                            auto answer_3 = len(prism_rtl::val(n_1).answers) == Nat(0u)
                                ? Text::lit("")
                                : crate::emit::rust::templates::items::answer(crate::syntax::lexer::chars::join(run_to_end(each_job(prism_rtl::val(n_1).answers, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<crate::lower::model::Pa, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<crate::lower::model::Pa, crate::lower::model::Ex> p0) {
                                return entered(once_job([=]() {
                                    return ({
                                        auto [pat, call] = p0;
                                        call_then(crate::emit::rust::start_pattern(pat), [=](Text pattern_14010) { return call_then(crate::emit::rust::start_expression(call), [=](Text expression_14027) { return prism_rtl::finished(prism_rtl::cat(pattern_14010, " => ", expression_14027, ",")); }); });
                                    });
                                }));
                            })))), Text::lit("\n")));
                            call_value(each_job(prism_rtl::val(n_1).builders, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::ForDef)>>(prism_rtl::rc([=](crate::lower::model::ForDef p0) {
                            return entered(once_job([=]() {
                                return ({
                                    auto b = p0;
                                    call_then(start_for_builder(b), [=](Text for_builder_14115) { return prism_rtl::finished(prism_rtl::cat("\n", for_builder_14115)); });
                                });
                            }));
                        }))), [=](Array<Text> each_14089) {
                            return call_value(each_job(prism_rtl::val(n_1).gens, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::GenDef)>>(prism_rtl::rc([=](crate::lower::model::GenDef p0) {
                                return entered(once_job([=]() {
                                    return ({
                                        auto gd = p0;
                                        call_then(start_gen_builder(gd), [=](Text gen_builder_14156) { return prism_rtl::finished(prism_rtl::cat("\n", gen_builder_14156)); });
                                    });
                                }));
                            }))), [=](Array<Text> each_14133) {
                                return ({
                                    auto builders = concat(append(each_14089, each_14133));
                                    auto row_impl = prism_rtl::val(n_1).row_kind == crate::lower::model::RowKind(crate::lower::model::RowKind::NotARow{})
                                        ? Text::lit("")
                                        : prism_rtl::cat("\n", rust_row_impl(n_1));
                                    call_value(each_job(prism_rtl::val(n_1).hooks, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Array<crate::lower::model::Do>>)>>(prism_rtl::rc([=](std::tuple<Text, Array<crate::lower::model::Do>> p0) {
                                    return entered(once_job([=]() {
                                        return ({
                                            auto [h, body] = p0;
                                            h == Text::lit("push")
                                            ? call_then(crate::emit::rust::start_statements(body), [=](Text statements_14323) { return prism_rtl::finished(crate::emit::rust::templates::items::push_hook(statements_14323)); })
                                            : call_then(crate::emit::rust::start_statements(body), [=](Text statements_14355) { return prism_rtl::finished(crate::emit::rust::templates::items::hook(h, statements_14355)); });
                                        });
                                    }));
                                }))), [=](Array<Text> each_14268) {
                                    return ({
                                        auto hooks = crate::syntax::lexer::chars::join(each_14268, Text::lit("\n"));
                                        auto doc = crate::emit::rust::templates::source_doc(prism_rtl::cat("`", prism_rtl::val(n_1).prism, "`: a node of its own (claude/backend.md, \"A widget block\")."), prism_rtl::val(n_1).doc);
                                        (prism_rtl::finished(prism_rtl::cat(crate::emit::rust::templates::items::node_(doc, prism_rtl::val(n_1).name, fields, consts, build_2, prism_rtl::cat(methods, builders), hooks, answer_3), row_impl)));
                                    });
                                });
                                });
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start RustNode, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_node(crate::lower::model::NodeDef n) {
    return prism_rtl::make_rc<RustNode>(n);
}


/// ForBuilder: unbounded fn ForDef -> Text
Text for_builder(const crate::lower::model::ForDef& b) {
    return crate::emit::rust::templates::items::for_build(b.name, crate::emit::rust::expression(b.at), crate::emit::rust::type_(b.key_ty), crate::emit::rust::type_(b.value_ty), b.row_node, b.source, crate::emit::rust::expression(b.parent), concat(run_to_end(each_job(b.passed, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=](crate::lower::model::Ex p0) {
        return entered(once_job([=]() {
            return ({
                auto x = p0;
                call_then(crate::emit::rust::start_expression(x), [=](Text expression_14848) { return prism_rtl::finished(prism_rtl::cat(", ", expression_14848)); });
            });
        }));
    }))))), moved_call(b.name, b.moved), from_kept(b.name, b.replaced), replaced_call(b.replaced));
}


prism_rtl::Turn<Text> ForBuilder::cycle() const {
    const auto& b = this->b;
    auto b_1 = b;
    return call_then(crate::emit::rust::start_expression(prism_rtl::val(b_1).at), [=](Text expression_14719) {
        return call_then(crate::emit::rust::start_type_(prism_rtl::val(b_1).key_ty), [=](Text type__14738) {
            return call_then(crate::emit::rust::start_type_(prism_rtl::val(b_1).value_ty), [=](Text type__14754) {
                return call_then(crate::emit::rust::start_expression(b_1->parent), [=](Text expression_14793) {
                    return call_value(each_job(prism_rtl::val(b_1).passed, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=](crate::lower::model::Ex p0) {
                        return entered(once_job([=]() {
                            return ({
                                auto x = p0;
                                call_then(crate::emit::rust::start_expression(x), [=](Text expression_14848) { return prism_rtl::finished(prism_rtl::cat(", ", expression_14848)); });
                            });
                        }));
                    }))), [=](Array<Text> each_14824) { return prism_rtl::finished(crate::emit::rust::templates::items::for_build(prism_rtl::val(b_1).name, expression_14719, type__14738, type__14754, prism_rtl::val(b_1).row_node, b_1->source, expression_14793, concat(each_14824), moved_call(prism_rtl::val(b_1).name, prism_rtl::val(b_1).moved), from_kept(prism_rtl::val(b_1).name, prism_rtl::val(b_1).replaced), replaced_call(prism_rtl::val(b_1).replaced))); });
                });
            });
        });
    });
}


/// `Start ForBuilder, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_for_builder(crate::lower::model::ForDef b) {
    return prism_rtl::make_rc<ForBuilder>(b);
}


/// FromKept: fn Text, [Text] -> Text
Text from_kept(const Text& name, const Array<Text>& replaced) {
    return len(replaced) == Nat(0u)
        ? prism_rtl::cat("*self.", name, "_from.borrow_mut() = items.clone();")
        : prism_rtl::cat("let from = std::mem::replace(&mut *self.", name, "_from.borrow_mut(), items.clone());");
}


/// ReplacedCall: fn [Text] -> Text
Text replaced_call(const Array<Text>& replaced) {
    return len(replaced) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" else if from.get(k) != items.get(k) {\n            // the dynamic under a kept key was replaced: that row follows it from the next tick\n", concat(each(replaced, [&](const Text& m) { return prism_rtl::cat("            row.", m, "(cx);\n"); })), "        }");
}


/// MovedCall: fn Text, Text -> Text
Text moved_call(const Text& name, const Text& m) {
    return m == Text::lit("")
        ? Text::lit("")
        : prism_rtl::cat("\n    // the places of the host\'s child came or went: its document\'s outer moves\n    if !prism_rtl::same_keys(&self.", name, ".borrow(), &old) {\n        self.", m, "(cx);\n    }");
}


/// GenMovedCall: fn Text -> Text
Text gen_moved_call(const Text& m) {
    return m == Text::lit("")
        ? Text::lit("")
        : prism_rtl::cat("\n    // the places of the host\'s child came or went: its document\'s outer moves\n    self.", m, "(cx);");
}


/// GenBuilder: unbounded fn GenDef -> Text
Text gen_builder(const crate::lower::model::GenDef& gd) {
    auto path_ = gd.transparent
        ? Text::lit("self.path.clone()")
        : prism_rtl::cat(crate::emit::rust::expression(gd.at), ".child(Segment::Gen(g))");
    return crate::emit::rust::templates::items::gen_build(gd.name, crate::emit::rust::expression(gd.at), path_, crate::emit::rust::expression(gd.source), crate::emit::rust::type_(gd.value_ty), crate::emit::rust::expression(gd.select), gen_moved_call(gd.moved));
}


prism_rtl::Turn<Text> GenBuilder::cycle() const {
    const auto& gd = this->gd;
    auto path_ = prism_rtl::val(gd).transparent
        ? Text::lit("self.path.clone()")
        : prism_rtl::cat(crate::emit::rust::expression(prism_rtl::val(gd).at), ".child(Segment::Gen(g))");
    auto gd_1 = gd;
    return call_then(crate::emit::rust::start_expression(prism_rtl::val(gd_1).at), [=](Text expression_16835) { return call_then(crate::emit::rust::start_expression(gd_1->source), [=](Text expression_16861) { return call_then(crate::emit::rust::start_type_(prism_rtl::val(gd_1).value_ty), [=](Text type__16885) { return call_then(crate::emit::rust::start_expression(prism_rtl::val(gd_1).select), [=](Text expression_16904) { return prism_rtl::finished(crate::emit::rust::templates::items::gen_build(prism_rtl::val(gd_1).name, expression_16835, path_, expression_16861, type__16885, expression_16904, gen_moved_call(prism_rtl::val(gd_1).moved))); }); }); }); });
}


/// `Start GenBuilder, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_gen_builder(crate::lower::model::GenDef gd) {
    return prism_rtl::make_rc<GenBuilder>(gd);
}


/// RustRowImpl: unbounded fn NodeDef -> Text
Text rust_row_impl(const crate::lower::model::NodeDef& n) {
    auto kept = n.row_kind == crate::lower::model::RowKind(crate::lower::model::RowKind::ForRow{})
        ? Array(std::vector{Text::lit("*self.left_entry.borrow_mut() = Some(self.entry(cx));")})
        : Array<Text>{};
    auto unsubscribe = each(n.subs, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& ev = std::get<0>(_p0);
        auto&& m = std::get<1>(_p0);
        return prism_rtl::cat("if let (Some(p), Some(h)) = (self.parent.upgrade(), self.", m, "_sub.take()) {\n    p.", ev, "_port.unsubscribe(h);\n}");
    });
    return crate::emit::rust::templates::items::row_impl(n.name, crate::syntax::lexer::chars::join(append(crate::prelude::push(kept, Text::lit("self.remove_places(cx);")), unsubscribe), Text::lit("\n")), crate::syntax::lexer::chars::join(run_to_end(each_job(n.hosted, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::MethDef)>>(prism_rtl::rc([=](crate::lower::model::MethDef p0) {
        return entered(once_job([=]() {
            return ({
                auto m = p0;
                (prism_rtl::more(prism_rtl::rc(RustMethod(m))));
            });
        }));
    })))), Text::lit("\n")));
}


prism_rtl::Turn<Text> RustRowImpl::cycle() const {
    const auto& n = this->n;
    auto kept = prism_rtl::val(n).row_kind == crate::lower::model::RowKind(crate::lower::model::RowKind::ForRow{})
        ? Array(std::vector{Text::lit("*self.left_entry.borrow_mut() = Some(self.entry(cx));")})
        : Array<Text>{};
    auto unsubscribe = each(prism_rtl::val(n).subs, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& ev = std::get<0>(_p0);
        auto&& m = std::get<1>(_p0);
        return prism_rtl::cat("if let (Some(p), Some(h)) = (self.parent.upgrade(), self.", m, "_sub.take()) {\n    p.", ev, "_port.unsubscribe(h);\n}");
    });
    auto n_1 = n;
    return call_value(each_job(prism_rtl::val(n_1).hosted, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::MethDef)>>(prism_rtl::rc([=](crate::lower::model::MethDef p0) {
        return entered(once_job([=]() {
            return ({
                auto m = p0;
                (prism_rtl::more(prism_rtl::rc(RustMethod(m))));
            });
        }));
    }))), [=](Array<Text> each_17627) { return prism_rtl::finished(crate::emit::rust::templates::items::row_impl(prism_rtl::val(n_1).name, crate::syntax::lexer::chars::join(append(crate::prelude::push(kept, Text::lit("self.remove_places(cx);")), unsubscribe), Text::lit("\n")), crate::syntax::lexer::chars::join(each_17627, Text::lit("\n")))); });
}


/// `Start RustRowImpl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_row_impl(crate::lower::model::NodeDef n) {
    return prism_rtl::make_rc<RustRowImpl>(n);
}


/// RustMethod: unbounded fn MethDef -> Text
Text rust_method(const crate::lower::model::MethDef& m) {
    auto recv = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = m.recv;
        if (prism_rtl::is<crate::lower::model::Recv::RecvRc>(_m)) {
            _v.set(Text::lit("self: &Rc<Self>"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::Recv::RecvRef>(_m)) {
            _v.set(Text::lit("&self"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::Recv::RecvOwned>(_m)) {
            _v.set(Text::lit("self: Rc<Self>"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto cx_ = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = m.cx_;
        if (prism_rtl::is<crate::lower::model::CxArg::CxMut>(_m)) {
            _v.set(Text::lit(", cx: &mut Cx"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::CxArg::CxRef>(_m)) {
            _v.set(Text::lit(", cx: &Cx"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::CxArg::CxNone>(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto params = concat(run_to_end(each_job(m.params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [p_, t] = p0;
                call_then(crate::emit::rust::start_type_(t), [=](Text type__18014) { return prism_rtl::finished(prism_rtl::cat(", ", p_, ": ", type__18014)); });
            });
        }));
    })))));
    auto ret = m.ret == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})
        ? Text::lit("")
        : prism_rtl::cat(" -> ", crate::emit::rust::type_(m.ret));
    auto sig = prism_rtl::cat("fn ", m.name, "(", recv, params, cx_, ")", ret);
    auto body = m.ret == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})
        ? crate::emit::rust::statements(m.body)
        : len(m.body) == Nat(0u)
        ? crate::emit::rust::body_lines(m.tail)
        : prism_rtl::cat(crate::emit::rust::statements(m.body), "\n", crate::emit::rust::body_lines(m.tail));
    return crate::emit::rust::templates::items::method(crate::emit::rust::templates::doc(m.doc), sig, body);
}


prism_rtl::Turn<Text> RustMethod::cycle() const {
    const auto& m = this->m;
    auto recv = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = prism_rtl::val(m).recv;
        if (prism_rtl::is<crate::lower::model::Recv::RecvRc>(_m)) {
            _v.set(Text::lit("self: &Rc<Self>"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::Recv::RecvRef>(_m)) {
            _v.set(Text::lit("&self"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::Recv::RecvOwned>(_m)) {
            _v.set(Text::lit("self: Rc<Self>"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto cx_ = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = prism_rtl::val(m).cx_;
        if (prism_rtl::is<crate::lower::model::CxArg::CxMut>(_m)) {
            _v.set(Text::lit(", cx: &mut Cx"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::CxArg::CxRef>(_m)) {
            _v.set(Text::lit(", cx: &Cx"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::CxArg::CxNone>(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto m_1 = m;
    return call_value(each_job(prism_rtl::val(m_1).params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [p_, t] = p0;
                call_then(crate::emit::rust::start_type_(t), [=](Text type__18014) { return prism_rtl::finished(prism_rtl::cat(", ", p_, ": ", type__18014)); });
            });
        }));
    }))), [=](Array<Text> each_17978) {
        return ({
            auto params = concat(each_17978);
            auto ret = prism_rtl::val(m_1).ret == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})
                ? Text::lit("")
                : prism_rtl::cat(" -> ", crate::emit::rust::type_(prism_rtl::val(m_1).ret));
            auto sig = prism_rtl::cat("fn ", prism_rtl::val(m_1).name, "(", recv, params, cx_, ")", ret);
            auto body = prism_rtl::val(m_1).ret == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})
                ? crate::emit::rust::statements(prism_rtl::val(m_1).body)
                : len(prism_rtl::val(m_1).body) == Nat(0u)
                ? crate::emit::rust::body_lines(prism_rtl::val(m_1).tail)
                : prism_rtl::cat(crate::emit::rust::statements(prism_rtl::val(m_1).body), "\n", crate::emit::rust::body_lines(prism_rtl::val(m_1).tail));
            (prism_rtl::finished(crate::emit::rust::templates::items::method(crate::emit::rust::templates::doc(prism_rtl::val(m_1).doc), sig, body)));
        });
    });
}


/// `Start RustMethod, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_method(crate::lower::model::MethDef m) {
    return prism_rtl::make_rc<RustMethod>(m);
}


/// RustProgram: unbounded fn ProgDef, Bool -> Text
Text rust_program(const crate::lower::model::ProgDef& p_, const bool& fallible) {
    auto n = len(p_.params);
    auto names = each(p_.params, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
        auto&& a = std::get<0>(_p0);
        return a;
    });
    auto decode = n == Nat(0u) ? Text::lit("let _ = args;") : decode_args(p_, names);
    auto call = prism_rtl::cat(p_.node_, "::build(Path::root(), ", concat(each(names, [&](const Text& a) { return prism_rtl::cat(a, ", "); })), "&mut cx)", prism_rtl::val(fallible) ? Text::lit("?") : Text::lit(""));
    return crate::emit::rust::templates::items::program(p_.name, p_.prism, p_.node_, decode, call);
}


prism_rtl::Turn<Text> RustProgram::cycle() const {
    const auto& p_ = this->p_;
    const auto& fallible = this->fallible;
    auto n = len(prism_rtl::val(p_).params);
    auto names = each(prism_rtl::val(p_).params, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
        auto&& a = std::get<0>(_p0);
        return a;
    });
    auto decode = n == Nat(0u) ? Text::lit("let _ = args;") : decode_args(p_, names);
    auto call = prism_rtl::cat(prism_rtl::val(p_).node_, "::build(Path::root(), ", concat(each(names, [&](const Text& a) { return prism_rtl::cat(a, ", "); })), "&mut cx)", prism_rtl::val(fallible) ? Text::lit("?") : Text::lit(""));
    return prism_rtl::finished(crate::emit::rust::templates::items::program(prism_rtl::val(p_).name, prism_rtl::val(p_).prism, prism_rtl::val(p_).node_, decode, call));
}


/// `Start RustProgram, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_program(crate::lower::model::ProgDef p_, bool fallible) {
    return prism_rtl::make_rc<RustProgram>(p_, fallible);
}


/// DecodeArgs: unbounded fn ProgDef, [Text] -> Text
Text decode_args(const crate::lower::model::ProgDef& p_, const Array<Text>& names) {
    auto n = len(names);
    auto plural = n == Nat(1u) ? Text::lit("") : Text::lit("s");
    auto head = prism_rtl::cat("let [", crate::syntax::lexer::chars::join(names, Text::lit(", ")), "] = args else { return Err(Fault::answer(\"@", p_.prism, " takes ", n, " argument", plural, "\")) };");
    return crate::syntax::lexer::chars::join(append(Array(std::vector{head}), run_to_end(each_job(p_.params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [a, t] = p0;
                call_then(crate::emit::rust::start_decode_head(t), [=](Text decode_head_19045) { return prism_rtl::finished(prism_rtl::cat("let ", a, " = ", decode_head_19045, "::from_pod(", a, ")?;")); });
            });
        }));
    }))))), Text::lit("\n"));
}


prism_rtl::Turn<Text> DecodeArgs::cycle() const {
    const auto& p_ = this->p_;
    const auto& names = this->names;
    auto n = len(names);
    auto plural = n == Nat(1u) ? Text::lit("") : Text::lit("s");
    auto head = prism_rtl::cat("let [", crate::syntax::lexer::chars::join(names, Text::lit(", ")), "] = args else { return Err(Fault::answer(\"@", prism_rtl::val(p_).prism, " takes ", n, " argument", plural, "\")) };");
    auto p__1 = p_;
    return call_value(each_job(prism_rtl::val(p__1).params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [a, t] = p0;
                call_then(crate::emit::rust::start_decode_head(t), [=](Text decode_head_19045) { return prism_rtl::finished(prism_rtl::cat("let ", a, " = ", decode_head_19045, "::from_pod(", a, ")?;")); });
            });
        }));
    }))), [=](Array<Text> each_19006) { return prism_rtl::finished(crate::syntax::lexer::chars::join(append(Array(std::vector{head}), each_19006), Text::lit("\n"))); });
}


/// `Start DecodeArgs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_decode_args(crate::lower::model::ProgDef p_, Array<Text> names) {
    return prism_rtl::make_rc<DecodeArgs>(p_, names);
}


/// RustModule: unbounded fn ModDef, Text -> Text
Text rust_module(const crate::lower::model::ModDef& m, const Text& kids) {
    return crate::emit::rust::templates::module(m.prism == Text::lit("")
        ? Text::lit("The root module")
        : prism_rtl::cat("The module `", m.prism, "`"), m.path_, kids, crate::syntax::lexer::chars::join(run_to_end(each_job(m.items, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Item)>>(prism_rtl::rc([=](crate::lower::model::Item p0) {
        return entered(once_job([=]() {
            return ({
                auto it = p0;
                (prism_rtl::more(prism_rtl::rc(RustItem(it))));
            });
        }));
    })))), Text::lit("\n")));
}


prism_rtl::Turn<Text> RustModule::cycle() const {
    const auto& m = this->m;
    const auto& kids = this->kids;
    auto kids_1 = kids;
    auto m_2 = m;
    return call_value(each_job(prism_rtl::val(m_2).items, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Item)>>(prism_rtl::rc([=](crate::lower::model::Item p0) {
        return entered(once_job([=]() {
            return ({
                auto it = p0;
                (prism_rtl::more(prism_rtl::rc(RustItem(it))));
            });
        }));
    }))), [=](Array<Text> each_19618) {
        return prism_rtl::finished(crate::emit::rust::templates::module(prism_rtl::val(m_2).prism == Text::lit("")
            ? Text::lit("The root module")
            : prism_rtl::cat("The module `", prism_rtl::val(m_2).prism, "`"), m_2->path_, kids_1, crate::syntax::lexer::chars::join(each_19618, Text::lit("\n"))));
    });
}


/// `Start RustModule, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_module(crate::lower::model::ModDef m, Text kids) {
    return prism_rtl::make_rc<RustModule>(m, kids);
}


/// NodeFallible: fn Model, Text -> Bool
bool node_fallible(const crate::lower::model::Model& model, const Text& path_) {
    return fold(model.mods, false, [&](const bool& f, const crate::lower::model::ModDef& m) {
        return fold(prism_rtl::val(m).items, f, [&](const bool& f2, const crate::lower::model::Item& it) {
            return ({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                if (prism_rtl::is<crate::lower::model::Item::ItNode>(it)) {
                    auto&& n = prism_rtl::as<crate::lower::model::Item::ItNode>(it).a0;
                    _v.set(prism_rtl::val(f2) || ((prism_rtl::cat(prism_rtl::val(m).name, "::", prism_rtl::val(n).name) == path_) && prism_rtl::val(n).fallible));
                    goto _done;
                }
                {
                    _v.set(prism_rtl::val(f2));
                    goto _done;
                }
            _done:
                _v.take();
            });
        });
    });
}


/// EmitCrate: unbounded fn Model, Text, [Text] -> [((Text, Text))]
Array<std::tuple<Text, Text>> emit_crate(const crate::lower::model::Model& model, const Text& runtime, const Array<Text>& scripts) {
    auto gui = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = model.root;
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(r->world == Text::lit("canvas"));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto cargo_1 = crate::emit::rust::templates::cargo(model.name, runtime, gui ? Text::lit("\"canvas\"") : Text::lit(""));
    auto paths = rust_mod_paths(model.mods);
    auto mods = concat(each(filter(paths, [&](const Text& p_) { return !crate::syntax::lexer::chars::contains(p_, Text::lit(":")); }), [&](const Text& p_) { return prism_rtl::cat("mod ", p_, ";\n"); }));
    auto programs = crate::syntax::lexer::chars::join(run_to_end(each_job(all_programs(model), ({
        auto model_2 = model;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::ProgDef)>>(prism_rtl::rc([=](crate::lower::model::ProgDef p0) {
        return ({
            auto model_2_3 = model_2;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(RustProgram(p_, node_fallible(model_2_3, prism_rtl::val(p_).node_)))));
            });
        }));
        });
    })));
    }))), Text::lit("\n"));
    auto regs = concat(each(model.programs, [&](const crate::lower::model::ProgDef& p_) { return prism_rtl::cat(".program::<", prism_rtl::val(p_).name, ">(\"", prism_rtl::val(p_).prism, "\")\n"); }));
    auto checks = concat(run_to_end(each_job(model.checks, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CheckDef)>>(prism_rtl::rc([=](crate::lower::model::CheckDef p0) {
        return entered(once_job([=]() {
            return ({
                auto c = p0;
                call_value(each_job(prism_rtl::val(c).lines, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=](crate::lower::model::Ex p0) {
                return entered(once_job([=]() {
                    return ({
                        auto l = p0;
                        (prism_rtl::more(prism_rtl::rc(crate::emit::rust::Expression(l))));
                    });
                }));
            }))), [=](Array<Text> each_20647) { return prism_rtl::finished(prism_rtl::cat(".check(\"", prism_rtl::val(c).name, "\", || vec![", crate::syntax::lexer::chars::join(each_20647, Text::lit(", ")), "])\n")); });
            });
        }));
    })))));
    auto script_list = concat(each(scripts, [&](const Text& s) { return prism_rtl::cat("\"", crate::lower::expr::escape(s), "\",\n"); }));
    auto run_root_2 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = model.root;
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(crate::emit::rust::templates::run_root(prism_rtl::val(r).name));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::emit::rust::templates::no_root(model.name));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto world = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = model.root;
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(r->world);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit("test"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto main_3 = crate::emit::rust::templates::main(model.name, prism_rtl::cat("mod prelude;\n", mods), prism_rtl::cat(rust_row(model.elem), "\n", rust_answer(model.answer), "\n", programs), prism_rtl::cat(regs, checks), script_list, run_root_2, world);
    auto files = run_to_end(each_job(model.mods, ({
        auto paths_4 = paths;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text>>(crate::lower::model::ModDef)>>(prism_rtl::rc([=](crate::lower::model::ModDef p0) {
        return ({
            auto paths_4_5 = paths_4;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                call_then(start_rust_module(m, kids_of(paths_4_5, prism_rtl::val(m).name)), [=](Text rust_module_21161) { return prism_rtl::finished(std::tuple{rust_mod_file(prism_rtl::val(m).name), rust_module_21161}); });
            });
        }));
        });
    }));
    })));
    auto named_ = each(model.mods, [&](const crate::lower::model::ModDef& m) { return prism_rtl::val(m).name; });
    auto bare = each(filter(paths, [&](const Text& p_) { return !fold(named_, false, [&](const bool& f, const Text& n) { return prism_rtl::val(f) || (n == p_); }); }), [&](const Text& p_) { return std::tuple{rust_mod_file(p_), prism_rtl::cat("//! Emitted by prismc: the modules under `", p_, "`, which declares nothing of its own.\n\n", kids_of(paths, p_))}; });
    return append(Array(std::vector{std::tuple{Text::lit("Cargo.toml"), cargo_1}, std::tuple{Text::lit("src/main.rs"), main_3}, std::tuple{Text::lit("src/prelude.rs"), crate::emit::rust::prelude::prelude_source(Text::lit(""))}}), append(files, bare));
}


prism_rtl::Turn<Array<std::tuple<Text, Text>>> EmitCrate::cycle() const {
    const auto& model = this->model;
    const auto& runtime = this->runtime;
    const auto& scripts = this->scripts;
    auto gui = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = model->root;
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(r->world == Text::lit("canvas"));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto cargo_1 = crate::emit::rust::templates::cargo(prism_rtl::val(model).name, runtime, gui ? Text::lit("\"canvas\"") : Text::lit(""));
    auto paths = rust_mod_paths(prism_rtl::val(model).mods);
    auto mods = concat(each(filter(paths, [&](const Text& p_) { return !crate::syntax::lexer::chars::contains(p_, Text::lit(":")); }), [&](const Text& p_) { return prism_rtl::cat("mod ", p_, ";\n"); }));
    auto model_2 = model;
    auto scripts_3 = scripts;
    return call_value(each_job(all_programs(model_2), ({
        auto model_2_4 = model_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::ProgDef)>>(prism_rtl::rc([=](crate::lower::model::ProgDef p0) {
        return ({
            auto model_2_4_4 = model_2_4;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(RustProgram(p_, node_fallible(model_2_4_4, prism_rtl::val(p_).node_)))));
            });
        }));
        });
    })));
    })), [=](Array<Text> each_20389) {
        return ({
            auto programs = crate::syntax::lexer::chars::join(each_20389, Text::lit("\n"));
            auto regs = concat(each(prism_rtl::val(model_2).programs, [&](const crate::lower::model::ProgDef& p_) { return prism_rtl::cat(".program::<", prism_rtl::val(p_).name, ">(\"", prism_rtl::val(p_).prism, "\")\n"); }));
            call_value(each_job(prism_rtl::val(model_2).checks, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CheckDef)>>(prism_rtl::rc([=](crate::lower::model::CheckDef p0) {
            return entered(once_job([=]() {
                return ({
                    auto c = p0;
                    call_value(each_job(prism_rtl::val(c).lines, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=](crate::lower::model::Ex p0) {
                    return entered(once_job([=]() {
                        return ({
                            auto l = p0;
                            (prism_rtl::more(prism_rtl::rc(crate::emit::rust::Expression(l))));
                        });
                    }));
                }))), [=](Array<Text> each_20647) { return prism_rtl::finished(prism_rtl::cat(".check(\"", prism_rtl::val(c).name, "\", || vec![", crate::syntax::lexer::chars::join(each_20647, Text::lit(", ")), "])\n")); });
                });
            }));
        }))), [=](Array<Text> each_20586) {
            return ({
                auto checks = concat(each_20586);
                auto script_list = concat(each(scripts_3, [&](const Text& s) { return prism_rtl::cat("\"", crate::lower::expr::escape(s), "\",\n"); }));
                auto run_root_4 = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = model_2->root;
                    if (prism_rtl::is_some(_m)) {
                        auto&& r = prism_rtl::some_of(_m);
                        _v.set(crate::emit::rust::templates::run_root(prism_rtl::val(r).name));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(crate::emit::rust::templates::no_root(prism_rtl::val(model_2).name));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto world = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = model_2->root;
                    if (prism_rtl::is_some(_m)) {
                        auto&& r = prism_rtl::some_of(_m);
                        _v.set(r->world);
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Text::lit("test"));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                call_then(start_rust_row(prism_rtl::val(model_2).elem), [=](Text rust_row_20992) {
                return call_then(start_rust_answer(model_2->answer), [=](Text rust_answer_21014) {
                    return ({
                        auto main_5 = crate::emit::rust::templates::main(prism_rtl::val(model_2).name, prism_rtl::cat("mod prelude;\n", mods), prism_rtl::cat(rust_row_20992, "\n", rust_answer_21014, "\n", programs), prism_rtl::cat(regs, checks), script_list, run_root_4, world);
                        call_value(each_job(prism_rtl::val(model_2).mods, ({
                        auto paths_6 = paths;
                        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text>>(crate::lower::model::ModDef)>>(prism_rtl::rc([=](crate::lower::model::ModDef p0) {
                        return ({
                            auto paths_6_7 = paths_6;
                            entered(once_job([=]() {
                            return ({
                                auto m = p0;
                                call_then(start_rust_module(m, kids_of(paths_6_7, prism_rtl::val(m).name)), [=](Text rust_module_21161) { return prism_rtl::finished(std::tuple{rust_mod_file(prism_rtl::val(m).name), rust_module_21161}); });
                            });
                        }));
                        });
                    }));
                    })), [=](Array<std::tuple<Text, Text>> each_21114) {
                        return ({
                            auto files = each_21114;
                            auto named_ = each(prism_rtl::val(model_2).mods, [&](const crate::lower::model::ModDef& m) { return prism_rtl::val(m).name; });
                            auto bare = each(filter(paths, [&](const Text& p_) { return !fold(named_, false, [&](const bool& f, const Text& n) { return prism_rtl::val(f) || (n == p_); }); }), [&](const Text& p_) { return std::tuple{rust_mod_file(p_), prism_rtl::cat("//! Emitted by prismc: the modules under `", p_, "`, which declares nothing of its own.\n\n", kids_of(paths, p_))}; });
                            (prism_rtl::finished(append(Array(std::vector{std::tuple{Text::lit("Cargo.toml"), cargo_1}, std::tuple{Text::lit("src/main.rs"), main_5}, std::tuple{Text::lit("src/prelude.rs"), crate::emit::rust::prelude::prelude_source(Text::lit(""))}}), append(files, bare))));
                        });
                    });
                    });
                });
            });
            });
        });
        });
    });
}


/// `Start EmitCrate, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Text, Text>>> start_emit_crate(crate::lower::model::Model model, Text runtime, Array<Text> scripts) {
    return prism_rtl::make_rc<EmitCrate>(model, runtime, scripts);
}


/// RustModPaths: fn [ModDef] -> [Text]
Array<Text> rust_mod_paths(const Array<crate::lower::model::ModDef>& mods) {
    return fold(mods, Array<Text>{}, [&](const Array<Text>& acc, const crate::lower::model::ModDef& m) {
        return ({
            auto segs = split_on(prism_rtl::val(m).name, Text::lit("::"));
            fold(crate::check::errors::range0(len(segs)), acc, [&](const Array<Text>& a, const Nat& i) { return add_path(a, crate::syntax::lexer::chars::join(take(segs, i + Nat(1u)), Text::lit("::"))); });
        });
    });
}


/// AddPath: fn [Text], Text -> [Text]
Array<Text> add_path(const Array<Text>& ps, const Text& p_) {
    return fold(ps, false, [&](const bool& f, const Text& q) { return prism_rtl::val(f) || (q == p_); })
        ? ps
        : crate::prelude::push(ps, p_);
}


/// RustModFile: fn Text -> Text
Text rust_mod_file(const Text& p_) {
    return p_ == Text::lit("program")
        ? Text::lit("src/program.rs")
        : prism_rtl::cat("src/", crate::syntax::lexer::chars::join(split_on(p_, Text::lit("::")), Text::lit("/")), "/mod.rs");
}


/// KidsOf: fn [Text], Text -> Text
Text kids_of(const Array<Text>& paths, const Text& p_) {
    return concat(each(filter(paths, [&](const Text& q) { return crate::syntax::lexer::chars::has_prefix(q, prism_rtl::cat(p_, "::")) && (!crate::syntax::lexer::chars::contains(crate::syntax::lexer::chars::drop_prefix(q, prism_rtl::cat(p_, "::")), Text::lit(":"))); }), [&](const Text& q) { return prism_rtl::cat("pub mod ", crate::syntax::lexer::chars::drop_prefix(q, prism_rtl::cat(p_, "::")), ";\n"); }));
}


/// AllPrograms: fn Model -> [ProgDef]
Array<crate::lower::model::ProgDef> all_programs(const crate::lower::model::Model& model) {
    auto&& _m = model.root;
    if (prism_rtl::is_some(_m)) {
        auto&& r = prism_rtl::some_of(_m);
        return fold(model.programs, false, [&](const bool& f, const crate::lower::model::ProgDef& p_) { return prism_rtl::val(f) || (prism_rtl::val(p_).name == prism_rtl::val(r).name); })
            ? model.programs
            : crate::prelude::push(model.programs, r);
    }
    if (prism_rtl::is_none(_m)) {
        return model.programs;
    }
    prism_rtl::unreachable("no arm matched");
}

}  // namespace crate::emit::rust::items
