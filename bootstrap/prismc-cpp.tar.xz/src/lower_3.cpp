// The module `Lower`, from `target/bootstrap/cpp-src/prismc/lower.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include "lower.hpp"
#include "ast.hpp"
#include "check_env.hpp"
#include "check_errors.hpp"
#include "check_types.hpp"
#include "lexer.hpp"
#include "typed.hpp"
#include "lower.generic.hpp"
#include "check_env.generic.hpp"
#include "lexer.generic.hpp"

namespace crate::lower {

/// `Start MatchValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_match_value(Lx lx, Env env, ast::Expr s, Array<ast::Arm> arms, OutTy t, ast::Range span) {
    return prism_rtl::make_rc<MatchValue>(lx, env, s, arms, t, span);
}


/// let dummyArm
ast::Arm dummy_arm() {
    return ast::Arm{.pattern = std::optional<ast::Pattern_>{}, .guard = std::optional<ast::Expr>{}, .body = ast::Block{.stmts = Array<ast::Stmt>{}, .inline_ = true, .span = ast::Range{.start = Nat(0u), .end = Nat(0u)}}, .span = ast::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// ArmPat: unbounded fn Lx, ?Pattern, Ty, Holding, Text -> PatOut
PatOut arm_pat(const Lx& lx, const std::optional<ast::Pattern_>& opt1, const check_types::Ty& ty, const Holding& mode, const Text& fresh) {
    if (prism_rtl::is_some(opt1)) {
        auto&& p_ = prism_rtl::some_of(opt1);
        return rust_pat(lx, p_, ty, mode, fresh);
    }
    if (prism_rtl::is_none(opt1)) {
        return PatOut{.pa = Pa(Pa::PaWild{}), .conds = Array<Cc>{}, .binds = Array<std::tuple<Text, Bn>>{}};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<PatOut> ArmPat::cycle() const {
    const auto& lx = this->lx;
    const auto& opt1 = this->opt1;
    const auto& ty = this->ty;
    const auto& mode = this->mode;
    const auto& fresh = this->fresh;
    return ({
        prism_rtl::is_some(opt1) ? ({
        auto&& p_ = prism_rtl::some_of(opt1);
        prism_rtl::more(prism_rtl::rc(RustPat(lx, p_, ty, mode, fresh)));
    })
        : prism_rtl::is_none(opt1) ? prism_rtl::finished(PatOut{.pa = Pa(Pa::PaWild{}), .conds = Array<Cc>{}, .binds = Array<std::tuple<Text, Bn>>{}})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ArmPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_arm_pat(Lx lx, std::optional<ast::Pattern_> opt1, check_types::Ty ty, Holding mode, Text fresh) {
    return prism_rtl::make_rc<ArmPat>(lx, opt1, ty, mode, fresh);
}


/// BlockValue: unbounded fn Lx, Env, Block -> Vl
Vl block_value(const Lx& lx, const Env& env, const ast::Block& b) {
    return is_given_block(b.stmts)
        ? given_value(lx, env, b, block_ty(lx, b), b.span)
        : plain_block_value(lx, env, b);
}


prism_rtl::Turn<Vl> BlockValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& b = this->b;
    return is_given_block(b.stmts)
        ? ({
        auto b_1 = b;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(start_block_ty(lx_3, b_1), [=](OutTy block_ty_97037) { return prism_rtl::more(prism_rtl::rc(GivenValue(lx_3, env_2, b_1, block_ty_97037, b_1.span))); });
    })
        : prism_rtl::more(prism_rtl::rc(PlainBlockValue(lx, env, b)));
}


/// `Start BlockValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_block_value(Lx lx, Env env, ast::Block b) {
    return prism_rtl::make_rc<BlockValue>(lx, env, b);
}


/// IsGivenBlock: fn [Stmt] -> Bool
bool is_given_block(const Array<ast::Stmt>& stmts) {
    return fold(stmts, false, [&](const bool& f, const ast::Stmt& s) { return f || is_guardish(s); });
}


/// IsGuardish: fn Stmt -> Bool
bool is_guardish(const ast::Stmt& s) {
    auto&& _m = s.kind;
    if (prism_rtl::is<ast::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<ast::StmtKind::SBind>(_m).a2)) {
        return true;
    }
    if (prism_rtl::is<ast::StmtKind::SRequire>(_m)) {
        return true;
    }
    if (prism_rtl::is<ast::StmtKind::SForbid>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// BlockTy: unbounded fn Lx, Block -> OutTy
OutTy block_ty(const Lx& lx, const ast::Block& b) {
    auto&& _m = or_(index(b.stmts, lexer::dec(len(b.stmts))), dummy_stmt_l()).kind;
    if (prism_rtl::is<ast::StmtKind::SExpr>(_m)) {
        auto&& x = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
        return out_ty_of(lx, peel(type_at(lx, x.span)));
    }
    {
        return OutTy(OutTy::OutUnit{});
    }
}


prism_rtl::Turn<OutTy> BlockTy::cycle() const {
    const auto& lx = this->lx;
    const auto& b = this->b;
    return ({
        auto&& _m = or_(index(b.stmts, lexer::dec(len(b.stmts))), dummy_stmt_l()).kind;
        prism_rtl::is<ast::StmtKind::SExpr>(_m) ? ({
        auto&& x = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
        prism_rtl::more(prism_rtl::rc(OutTyOf(lx, peel(type_at(lx, x.span)))));
    })
        : prism_rtl::finished(OutTy(OutTy::OutUnit{}));
    });
}


/// `Start BlockTy, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<OutTy> start_block_ty(Lx lx, ast::Block b) {
    return prism_rtl::make_rc<BlockTy>(lx, b);
}


/// PlainBlockValue: unbounded fn Lx, Env, Block -> Vl
Vl plain_block_value(const Lx& lx, const Env& env, const ast::Block& b) {
    auto n = len(b.stmts);
    auto [dos, env2, last_opt] = run_to_end(fold_job(check_errors::range0(n), std::tuple{Array<Do>{}, env, std::optional<Vl>{}}, ({
        auto b_1 = b;
        auto n_2 = n;
        auto lx_3 = lx;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Do>, Env, std::optional<Vl>>>(std::tuple<std::tuple<Array<Do>, Env, std::optional<Vl>>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Do>, Env, std::optional<Vl>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto b_1_4 = b_1;
            auto n_2_4 = n_2;
            auto lx_3_4 = lx_3;
            entered(once_job([=]() {
            return ({
                auto [acc, en, lv_opt] = p0;
                auto i = p1;
                ({
                auto s = or_(index(b_1_4.stmts, i), dummy_stmt_l());
                (i + Nat(1u)) == n_2_4
                ? ({
                auto&& _m = s.kind;
                prism_rtl::is<ast::StmtKind::SExpr>(_m) ? ({
                auto&& x = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
                prism_rtl::finished(std::tuple{acc, en, std::optional(value_of(lx_3_4, en, x))});
            })
                : call_then(start_block_stmt(lx_3_4, en, s), [=](std::tuple<Array<Do>, Env> block_stmt_98079) {
                return ({
                    auto [more, en2] = block_stmt_98079;
                    (prism_rtl::finished(std::tuple{append(acc, more), en2, std::optional<Vl>{}}));
                });
            });
            })
                : call_then(start_block_stmt(lx_3_4, en, s), [=](std::tuple<Array<Do>, Env> block_stmt_98194) {
                return ({
                    auto [more, en2] = block_stmt_98194;
                    (prism_rtl::finished(std::tuple{append(acc, more), en2, lv_opt}));
                });
            });
            });
            });
        }));
        });
    }));
    })));
    auto last = or_(last_opt, Vl(Vl::VlOwned{Ex(Ex::XUnit{}), OutTy(OutTy::OutUnit{})}));
    return len(dos) == Nat(0u)
        ? last
        : Vl(Vl::VlOwned{Ex(Ex::XBlock{dos, prism_rtl::rc(own(last))}), value_ty(last)});
}


prism_rtl::Turn<Vl> PlainBlockValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& b = this->b;
    auto n = len(b.stmts);
    auto b_1 = b;
    auto env_2 = env;
    auto lx_3 = lx;
    return call_value(fold_job(check_errors::range0(n), std::tuple{Array<Do>{}, env_2, std::optional<Vl>{}}, ({
        auto b_1_4 = b_1;
        auto n_4 = n;
        auto lx_3_5 = lx_3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Do>, Env, std::optional<Vl>>>(std::tuple<std::tuple<Array<Do>, Env, std::optional<Vl>>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Do>, Env, std::optional<Vl>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto b_1_4_5 = b_1_4;
            auto n_4_5 = n_4;
            auto lx_3_5_5 = lx_3_5;
            entered(once_job([=]() {
            return ({
                auto [acc, en, lv_opt] = p0;
                auto i = p1;
                ({
                auto s = or_(index(b_1_4_5.stmts, i), dummy_stmt_l());
                (i + Nat(1u)) == n_4_5
                ? ({
                auto&& _m = s.kind;
                prism_rtl::is<ast::StmtKind::SExpr>(_m) ? ({
                auto&& x = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
                prism_rtl::finished(std::tuple{acc, en, std::optional(value_of(lx_3_5_5, en, x))});
            })
                : call_then(start_block_stmt(lx_3_5_5, en, s), [=](std::tuple<Array<Do>, Env> block_stmt_98079) {
                return ({
                    auto [more, en2] = block_stmt_98079;
                    (prism_rtl::finished(std::tuple{append(acc, more), en2, std::optional<Vl>{}}));
                });
            });
            })
                : call_then(start_block_stmt(lx_3_5_5, en, s), [=](std::tuple<Array<Do>, Env> block_stmt_98194) {
                return ({
                    auto [more, en2] = block_stmt_98194;
                    (prism_rtl::finished(std::tuple{append(acc, more), en2, lv_opt}));
                });
            });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<Do>, Env, std::optional<Vl>> fold_97825) {
        return ({
            auto [dos, env2, last_opt] = fold_97825;
            auto last = or_(last_opt, Vl(Vl::VlOwned{Ex(Ex::XUnit{}), OutTy(OutTy::OutUnit{})}));
            len(dos) == Nat(0u)
            ? prism_rtl::finished(last)
            : prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XBlock{dos, prism_rtl::rc(own(last))}), value_ty(last)}));
        });
    });
}


/// `Start PlainBlockValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_plain_block_value(Lx lx, Env env, ast::Block b) {
    return prism_rtl::make_rc<PlainBlockValue>(lx, env, b);
}


/// let dummyStmtL
ast::Stmt dummy_stmt_l() {
    return ast::Stmt{.kind = ast::StmtKind(ast::StmtKind::SExpr{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EError{})), .span = ast::Range{.start = Nat(0u), .end = Nat(0u)}}}), .span = ast::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// BlockStmt: unbounded fn Lx, Env, Stmt -> (([Do], Env))
std::tuple<Array<Do>, Env> block_stmt(const Lx& lx, const Env& env, const ast::Stmt& s) {
    auto&& _m = s.kind;
    if (prism_rtl::is<ast::StmtKind::SLet>(_m)) {
        auto&& p_ = prism_rtl::as<ast::StmtKind::SLet>(_m).a0;
        auto&& x = prism_rtl::as<ast::StmtKind::SLet>(_m).a2;
        auto&& _m = p_.kind;
        if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
            auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
            auto&& _m = prelude::get(lx.gens, place_key(lx, n.span));
            if (prism_rtl::is_some(_m)) {
                auto&& gn = prism_rtl::some_of(_m);
                return generic_let(lx, env, n, gn, x);
            }
            if (prism_rtl::is_none(_m)) {
                return plain_let(lx, env, s, p_, x);
            }
            prism_rtl::unreachable("no arm matched");
        }
        {
            return plain_let(lx, env, s, p_, x);
        }
    }
    if (prism_rtl::is<ast::StmtKind::SExpr>(_m)) {
        auto&& x = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
        return std::tuple{Array(std::vector{Do(Do::DoExpr{own(value_of(lx, env, x))})}), env};
    }
    if (prism_rtl::is<ast::StmtKind::SSignature>(_m)) {
        return std::tuple{Array<Do>{}, env};
    }
    if (prism_rtl::is<ast::StmtKind::SFn>(_m)) {
        auto&& f = prism_rtl::as<ast::StmtKind::SFn>(_m).a0;
        return std::tuple{Array(std::vector{refusal_do(prism_rtl::cat("a local function ", check_env::def_name_text(f.name), ": not lowered yet"))}), env};
    }
    {
        return std::tuple{Array(std::vector{refusal_do(Text::lit("a statement this back end does not lower yet"))}), env};
    }
}


prism_rtl::Turn<std::tuple<Array<Do>, Env>> BlockStmt::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& s = this->s;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<ast::StmtKind::SLet>(_m) ? ({
        auto&& p_ = prism_rtl::as<ast::StmtKind::SLet>(_m).a0;
        auto&& x = prism_rtl::as<ast::StmtKind::SLet>(_m).a2;
        ({
        auto&& _m = p_.kind;
        prism_rtl::is<ast::PatternKind::PName>(_m) ? ({
        auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
        ({
        auto&& _m = prelude::get(lx.gens, place_key(lx, n.span));
        prism_rtl::is_some(_m) ? ({
        auto&& gn = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(GenericLet(lx, env, n, gn, x)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(PlainLet(lx, env, s, p_, x)))
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::more(prism_rtl::rc(PlainLet(lx, env, s, p_, x)));
    });
    })
        : prism_rtl::is<ast::StmtKind::SExpr>(_m) ? ({
        auto&& x = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
        ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto x_3 = x;
        call_then(start_value_of(lx_2, env_1, x_3), [=](Vl value_of_98902) { return prism_rtl::finished(std::tuple{Array(std::vector{Do(Do::DoExpr{own(value_of_98902)})}), env_1}); });
    });
    })
        : prism_rtl::is<ast::StmtKind::SSignature>(_m) ? prism_rtl::finished(std::tuple{Array<Do>{}, env})
        : prism_rtl::is<ast::StmtKind::SFn>(_m) ? ({
        auto&& f = prism_rtl::as<ast::StmtKind::SFn>(_m).a0;
        prism_rtl::finished(std::tuple{Array(std::vector{refusal_do(prism_rtl::cat("a local function ", check_env::def_name_text(f.name), ": not lowered yet"))}), env});
    })
        : prism_rtl::finished(std::tuple{Array(std::vector{refusal_do(Text::lit("a statement this back end does not lower yet"))}), env});
    });
}


/// `Start BlockStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<Do>, Env>> start_block_stmt(Lx lx, Env env, ast::Stmt s) {
    return prism_rtl::make_rc<BlockStmt>(lx, env, s);
}


/// GenericLet: unbounded fn Lx, Env, SName, GenNote, Expr -> (([Do], Env))
std::tuple<Array<Do>, Env> generic_let(const Lx& lx, const Env& env, const ast::SName& n, const typed::GenNote& gn, const ast::Expr& x) {
    auto nkey = check_env::sname_key(n);
    auto distinct = instantiations(lx, gn);
    auto one = len(distinct) == Nat(1u);
    auto rs = local_name(lx, nkey);
    return run_to_end(fold_job(check_errors::range0(len(distinct)), std::tuple{Array<Do>{}, env}, ({
        auto distinct_1 = distinct;
        auto lx_2 = lx;
        auto one_3 = one;
        auto rs_4 = rs;
        auto nkey_5 = nkey;
        auto n_6 = n;
        auto env_7 = env;
        auto x_8 = x;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Do>, Env>>(std::tuple<std::tuple<Array<Do>, Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Do>, Env>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto distinct_1_9 = distinct_1;
            auto lx_2_9 = lx_2;
            auto one_3_9 = one_3;
            auto rs_4_9 = rs_4;
            auto nkey_5_9 = nkey_5;
            auto n_6_9 = n_6;
            auto env_7_9 = env_7;
            auto x_8_9 = x_8;
            entered(once_job([=]() {
            return ({
                auto [dos, en] = p0;
                auto k = p1;
                ({
                auto [tys, cols] = or_(index(distinct_1_9, k), std::tuple{Array<std::tuple<Text, check_types::Ty>>{}, Array<std::tuple<Text, check_types::Col>>{}});
                auto lxk = at_instance(lx_2_9, std::tuple{tys, cols});
                auto rk = one_3_9 ? rs_4_9 : prism_rtl::cat(rs_4_9, "_", k);
                auto bkey = k == Nat(0u) ? nkey_5_9 : prism_rtl::cat(nkey_5_9, "#inst", k);
                call_then(start_out_ty_of(lxk, peel(binder_ty(lxk, n_6_9.span))), [=](OutTy out_ty_of_100064) {
                return ({
                    auto bt = out_ty_of_100064;
                    call_then(start_value_of(lxk, env_7_9, x_8_9), [=](Vl value_of_100123) {
                    return ({
                        auto v_ = value_of_100123;
                        auto en1 = bind(en, bkey, Bn(Bn::BnLocal{Ex(Ex::XVar{rk}), Holding(Holding::Owned{}), bt}));
                        auto en2 = ({
                            Env this_ = en1;
                            this_.uses = insert(this_.uses, prism_rtl::cat(nkey_5_9, "#", show_text(std::tuple{tys, cols})), bkey);
                            this_;
                        });
                        auto d = Do(Do::DoLet{Pa(Pa::PaBind{rk}), own(v_)});
                        (prism_rtl::finished(std::tuple{prelude::push(dos, d), en2}));
                    });
                });
                });
            });
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Array<Do>, Env>> GenericLet::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& n = this->n;
    const auto& gn = this->gn;
    const auto& x = this->x;
    auto nkey = check_env::sname_key(n);
    auto env_1 = env;
    auto gn_2 = gn;
    auto lx_3 = lx;
    auto n_4 = n;
    auto x_5 = x;
    return call_then(start_instantiations(lx_3, gn_2), [=](Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>> instantiations_99683) {
        return ({
            auto distinct = instantiations_99683;
            auto one = len(distinct) == Nat(1u);
            auto rs = local_name(lx_3, nkey);
            fold_job(check_errors::range0(len(distinct)), std::tuple{Array<Do>{}, env_1}, ({
            auto distinct_6 = distinct;
            auto lx_3_7 = lx_3;
            auto one_7 = one;
            auto rs_8 = rs;
            auto nkey_9 = nkey;
            auto n_4_10 = n_4;
            auto env_1_10 = env_1;
            auto x_5_10 = x_5;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Do>, Env>>(std::tuple<std::tuple<Array<Do>, Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Do>, Env>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto distinct_6_10 = distinct_6;
                auto lx_3_7_10 = lx_3_7;
                auto one_7_10 = one_7;
                auto rs_8_10 = rs_8;
                auto nkey_9_10 = nkey_9;
                auto n_4_10_10 = n_4_10;
                auto env_1_10_10 = env_1_10;
                auto x_5_10_10 = x_5_10;
                entered(once_job([=]() {
                return ({
                    auto [dos, en] = p0;
                    auto k = p1;
                    ({
                    auto [tys, cols] = or_(index(distinct_6_10, k), std::tuple{Array<std::tuple<Text, check_types::Ty>>{}, Array<std::tuple<Text, check_types::Col>>{}});
                    auto lxk = at_instance(lx_3_7_10, std::tuple{tys, cols});
                    auto rk = one_7_10 ? rs_8_10 : prism_rtl::cat(rs_8_10, "_", k);
                    auto bkey = k == Nat(0u) ? nkey_9_10 : prism_rtl::cat(nkey_9_10, "#inst", k);
                    call_then(start_out_ty_of(lxk, peel(binder_ty(lxk, n_4_10_10.span))), [=](OutTy out_ty_of_100064) {
                    return ({
                        auto bt = out_ty_of_100064;
                        call_then(start_value_of(lxk, env_1_10_10, x_5_10_10), [=](Vl value_of_100123) {
                        return ({
                            auto v_ = value_of_100123;
                            auto en1 = bind(en, bkey, Bn(Bn::BnLocal{Ex(Ex::XVar{rk}), Holding(Holding::Owned{}), bt}));
                            auto en2 = ({
                                Env this_ = en1;
                                this_.uses = insert(this_.uses, prism_rtl::cat(nkey_9_10, "#", show_text(std::tuple{tys, cols})), bkey);
                                this_;
                            });
                            auto d = Do(Do::DoLet{Pa(Pa::PaBind{rk}), own(v_)});
                            (prism_rtl::finished(std::tuple{prelude::push(dos, d), en2}));
                        });
                    });
                    });
                });
                });
                });
            }));
            });
        }));
        }))->cycle();
        });
    });
}


/// `Start GenericLet, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<Do>, Env>> start_generic_let(Lx lx, Env env, ast::SName n, typed::GenNote gn, ast::Expr x) {
    return prism_rtl::make_rc<GenericLet>(lx, env, n, gn, x);
}


/// Instantiations: unbounded fn Lx, GenNote -> [(([((Text, Ty))], [((Text, Col))]))]
Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>> instantiations(const Lx& lx, const typed::GenNote& gn) {
    return run_to_end(fold_job(or_(prelude::get(lx.insts, gen_key(gn)), Array<typed::InstNote>{}), Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>{}, ({
        auto lx_1 = lx;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>>(std::tuple<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>, typed::InstNote>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>, typed::InstNote> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto u = p1;
                call_then(start_expanded(lx_1_2, inst_at(lx_1_2, u)), [=](Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>> expanded_100788) {
                return prism_rtl::finished(fold(expanded_100788, acc, [&](const Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>& a, const std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>& i) {
                    return fold(a, false, [&](const bool& seen, const std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>& j) { return seen || (show_text(j) == show_text(i)); })
                        ? a
                        : prelude::push(a, i);
                }));
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>> Instantiations::cycle() const {
    const auto& lx = this->lx;
    const auto& gn = this->gn;
    return fold_job(or_(prelude::get(lx.insts, gen_key(gn)), Array<typed::InstNote>{}), Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>{}, ({
        auto lx_1 = lx;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>>(std::tuple<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>, typed::InstNote>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>, typed::InstNote> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto u = p1;
                call_then(start_expanded(lx_1_2, inst_at(lx_1_2, u)), [=](Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>> expanded_100788) {
                return prism_rtl::finished(fold(expanded_100788, acc, [&](const Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>& a, const std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>& i) {
                    return fold(a, false, [&](const bool& seen, const std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>& j) { return seen || (show_text(j) == show_text(i)); })
                        ? a
                        : prelude::push(a, i);
                }));
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start Instantiations, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>> start_instantiations(Lx lx, typed::GenNote gn) {
    return prism_rtl::make_rc<Instantiations>(lx, gn);
}


/// Expanded: unbounded fn Lx, (([((Text, Ty))], [((Text, Col))])) -> [(([((Text, Ty))], [((Text, Col))]))]
Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>> expanded(const Lx& lx, const std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>& i) {
    auto&& _m = open_q(lx, i);
    if (prism_rtl::is_none(_m)) {
        return Array(std::vector{i});
    }
    if (prism_rtl::is_some(_m)) {
        auto&& q = prism_rtl::some_of(_m);
        auto&& _m = prelude::get(lx.gen_of_q, q);
        if (prism_rtl::is_some(_m)) {
            auto&& g = prism_rtl::some_of(_m);
            return run_to_end(fold_job(instantiations(lx, g), Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>{}, ({
                auto lx_1 = lx;
                auto i_2 = i;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>>(std::tuple<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>, std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>, std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto lx_1_3 = lx_1;
                    auto i_2_3 = i_2;
                    entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto gi = p1;
                        ({
                        auto lx2 = at_instance(lx_1_3, gi);
                        call_then(start_expanded(lx2, subst_inst(lx2, i_2_3)), [=](Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>> expanded_101221) { return prism_rtl::finished(append(acc, expanded_101221)); });
                    });
                    });
                }));
                });
            }));
            })));
        }
        if (prism_rtl::is_none(_m)) {
            return Array(std::vector{i});
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>> Expanded::cycle() const {
    const auto& lx = this->lx;
    const auto& i = this->i;
    auto i_1 = i;
    auto lx_2 = lx;
    return call_then(start_open_q(lx_2, i_1), [=](std::optional<Text> open_q_101039) {
        return ({
            prism_rtl::is_none(open_q_101039) ? prism_rtl::finished(Array(std::vector{i_1}))
            : prism_rtl::is_some(open_q_101039) ? ({
            auto&& q = prism_rtl::some_of(open_q_101039);
            ({
            auto&& _m = prelude::get(lx_2.gen_of_q, q);
            prism_rtl::is_some(_m) ? ({
            auto&& g = prism_rtl::some_of(_m);
            call_then(start_instantiations(lx_2, g), [=](Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>> instantiations_101116) {
            return fold_job(instantiations_101116, Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>{}, ({
                auto lx_2_3 = lx_2;
                auto i_1_3 = i_1;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>>(std::tuple<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>, std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>, std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto lx_2_3_3 = lx_2_3;
                    auto i_1_3_3 = i_1_3;
                    entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto gi = p1;
                        ({
                        auto lx2 = at_instance(lx_2_3_3, gi);
                        call_then(start_expanded(lx2, subst_inst(lx2, i_1_3_3)), [=](Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>> expanded_101221) { return prism_rtl::finished(append(acc, expanded_101221)); });
                    });
                    });
                }));
                });
            }));
            }))->cycle();
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(Array(std::vector{i_1}))
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
    });
}


/// `Start Expanded, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>> start_expanded(Lx lx, std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>> i) {
    return prism_rtl::make_rc<Expanded>(lx, i);
}


/// SubstInst: fn Lx, (([((Text, Ty))], [((Text, Col))])) -> (([((Text, Ty))], [((Text, Col))]))
std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>> subst_inst(const Lx& lx, const std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>& arg1) {
    {
        auto&& tys = std::get<0>(arg1);
        auto&& cols = std::get<1>(arg1);
        auto tys2 = each(tys, [&](const std::tuple<Text, check_types::Ty>& _p0) {
            auto&& q = std::get<0>(_p0);
            auto&& t = std::get<1>(_p0);
            return std::tuple{q, subst_ty(lx, t)};
        });
        auto cols2 = each(cols, [&](const std::tuple<Text, check_types::Col>& _p0) {
            auto&& q = std::get<0>(_p0);
            auto&& c = std::get<1>(_p0);
            return std::tuple{q, inst_col(lx, c)};
        });
        return std::tuple{tys2, cols2};
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?OpenQ: unbounded fn Lx, (([((Text, Ty))], [((Text, Col))])) -> ?Text
std::optional<Text> open_q(const Lx& lx, const std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>& arg1) {
    {
        auto&& tys = std::get<0>(arg1);
        auto&& cols = std::get<1>(arg1);
        auto from_cols = fold(cols, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, check_types::Col>& _p1) {
            auto&& c = std::get<1>(_p1);
            return append(acc, open_cols(lx, c));
        });
        auto all = run_to_end(fold_job(tys, from_cols, ({
            auto lx_1 = lx;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, std::tuple<Text, check_types::Ty>>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, std::tuple<Text, check_types::Ty>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_1_2 = lx_1;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto&& _t = p1;
                    auto&& t = std::get<1>(_t);
                    call_then(start_open_ty_qs(lx_1_2, t), [=](Array<Text> open_ty_qs_101902) { return prism_rtl::finished(append(acc, open_ty_qs_101902)); });
                });
            }));
            });
        })));
        })));
        return index(all, Nat(0u));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::optional<Text>> OpenQ::cycle() const {
    const auto& lx = this->lx;
    const auto& arg1 = this->arg1;
    return ({
        ({
        auto&& tys = std::get<0>(arg1);
        auto&& cols = std::get<1>(arg1);
        ({
        auto from_cols = fold(cols, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, check_types::Col>& _p1) {
            auto&& c = std::get<1>(_p1);
            return append(acc, open_cols(lx, c));
        });
        auto lx_1 = lx;
        auto tys_2 = tys;
        call_value(fold_job(tys_2, from_cols, ({
        auto lx_1_3 = lx_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, std::tuple<Text, check_types::Ty>>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, std::tuple<Text, check_types::Ty>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_3_3 = lx_1_3;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto&& _t = p1;
                auto&& t = std::get<1>(_t);
                call_then(start_open_ty_qs(lx_1_3_3, t), [=](Array<Text> open_ty_qs_101902) { return prism_rtl::finished(append(acc, open_ty_qs_101902)); });
            });
        }));
        });
    })));
    })), [=](Array<Text> fold_101847) {
        return ({
            auto all = fold_101847;
            (prism_rtl::finished(index(all, Nat(0u))));
        });
    });
    });
    });
    });
}


/// `Start OpenQ, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Text>> start_open_q(Lx lx, std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>> arg1) {
    return prism_rtl::make_rc<OpenQ>(lx, arg1);
}


/// OpenCols: fn Lx, Col -> [Text]
Array<Text> open_cols(const Lx& lx, const check_types::Col& col1) {
    if (prism_rtl::is<check_types::Col::CQ>(col1)) {
        auto&& q = prism_rtl::as<check_types::Col::CQ>(col1).a0;
        return check_env::has_key(lx.gen_of_q, q) && (!check_env::has_key(lx.csubst, q))
            ? Array(std::vector{q})
            : Array<Text>{};
    }
    {
        auto&& c = col1;
        return Array<Text>{};
    }
}


/// OpenTyQs: unbounded fn Lx, Ty -> [Text]
Array<Text> open_ty_qs(const Lx& lx, const check_types::Ty& t) {
    if (prism_rtl::is<check_types::Ty::TyFlex>(t)) {
        auto&& n = prism_rtl::as<check_types::Ty::TyFlex>(t).a0;
        return check_env::has_key(lx.gen_of_q, prism_rtl::cat("'", n)) && (!check_env::has_key(lx.subst, prism_rtl::cat("'", n)))
            ? Array(std::vector{prism_rtl::cat("'", n)})
            : Array<Text>{};
    }
    if (prism_rtl::is<check_types::Ty::TyFn>(t)) {
        auto&& c = prism_rtl::as<check_types::Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<check_types::Ty::TyFn>(t).a2;
        return run_to_end(fold_job(prelude::push(ps, res), open_cols(lx, c), ({
            auto lx_1 = lx;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, check_types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_1_2 = lx_1;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto x = p1;
                    call_then(start_open_ty_qs(lx_1_2, x), [=](Array<Text> open_ty_qs_102338) { return prism_rtl::finished(append(acc, open_ty_qs_102338)); });
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<check_types::Ty::TyCon>(t)) {
        auto&& args = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        return run_to_end(fold_job(args, Array<Text>{}, ({
            auto lx_1 = lx;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, check_types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_1_2 = lx_1;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto x = p1;
                    call_then(start_open_ty_qs(lx_1_2, x), [=](Array<Text> open_ty_qs_102418) { return prism_rtl::finished(append(acc, open_ty_qs_102418)); });
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<check_types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<check_types::Ty::TyTuple>(t).a0;
        return run_to_end(fold_job(ts, Array<Text>{}, ({
            auto lx_1 = lx;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, check_types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_1_2 = lx_1;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto x = p1;
                    call_then(start_open_ty_qs(lx_1_2, x), [=](Array<Text> open_ty_qs_102488) { return prism_rtl::finished(append(acc, open_ty_qs_102488)); });
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<check_types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<check_types::Ty::TyArray>(t).a0;
        return open_ty_qs(lx, e);
    }
    if (prism_rtl::is<check_types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<check_types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(t).a1;
        return append(open_ty_qs(lx, k), open_ty_qs(lx, v_));
    }
    if (prism_rtl::is<check_types::Ty::TySig>(t)) {
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        return open_ty_qs(lx, i);
    }
    if (prism_rtl::is<check_types::Ty::TyAt>(t)) {
        auto&& i = prism_rtl::as<check_types::Ty::TyAt>(t).a0;
        return open_ty_qs(lx, i);
    }
    if (prism_rtl::is<check_types::Ty::TyElem>(t)) {
        auto&& o = prism_rtl::as<check_types::Ty::TyElem>(t).a1;
        return open_ty_qs(lx, o);
    }
    if (prism_rtl::is<check_types::Ty::TyAssoc>(t)) {
        auto&& a = prism_rtl::as<check_types::Ty::TyAssoc>(t).a1;
        return open_ty_qs(lx, a);
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> OpenTyQs::cycle() const {
    const auto& lx = this->lx;
    const auto& t = this->t;
    return ({
        prism_rtl::is<check_types::Ty::TyFlex>(t) ? ({
        auto&& n = prism_rtl::as<check_types::Ty::TyFlex>(t).a0;
        check_env::has_key(lx.gen_of_q, prism_rtl::cat("'", n)) && (!check_env::has_key(lx.subst, prism_rtl::cat("'", n)))
        ? prism_rtl::finished(Array(std::vector{prism_rtl::cat("'", n)}))
        : prism_rtl::finished(Array<Text>{});
    })
        : prism_rtl::is<check_types::Ty::TyFn>(t) ? ({
        auto&& c = prism_rtl::as<check_types::Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<check_types::Ty::TyFn>(t).a2;
        fold_job(prelude::push(ps, res), open_cols(lx, c), ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, check_types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto x = p1;
                call_then(start_open_ty_qs(lx_1_2, x), [=](Array<Text> open_ty_qs_102338) { return prism_rtl::finished(append(acc, open_ty_qs_102338)); });
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<check_types::Ty::TyCon>(t) ? ({
        auto&& args = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        fold_job(args, Array<Text>{}, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, check_types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto x = p1;
                call_then(start_open_ty_qs(lx_1_2, x), [=](Array<Text> open_ty_qs_102418) { return prism_rtl::finished(append(acc, open_ty_qs_102418)); });
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<check_types::Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<check_types::Ty::TyTuple>(t).a0;
        fold_job(ts, Array<Text>{}, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, check_types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto x = p1;
                call_then(start_open_ty_qs(lx_1_2, x), [=](Array<Text> open_ty_qs_102488) { return prism_rtl::finished(append(acc, open_ty_qs_102488)); });
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<check_types::Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<check_types::Ty::TyArray>(t).a0;
        prism_rtl::more(prism_rtl::rc(OpenTyQs(lx, e)));
    })
        : prism_rtl::is<check_types::Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<check_types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(t).a1;
        ({
        auto k_1 = k;
        auto lx_2 = lx;
        auto v__3 = v_;
        call_then(start_open_ty_qs(lx_2, k_1), [=](Array<Text> open_ty_qs_102558) { return call_then(start_open_ty_qs(lx_2, v__3), [=](Array<Text> open_ty_qs_102576) { return prism_rtl::finished(append(open_ty_qs_102558, open_ty_qs_102576)); }); });
    });
    })
        : prism_rtl::is<check_types::Ty::TySig>(t) ? ({
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        prism_rtl::more(prism_rtl::rc(OpenTyQs(lx, i)));
    })
        : prism_rtl::is<check_types::Ty::TyAt>(t) ? ({
        auto&& i = prism_rtl::as<check_types::Ty::TyAt>(t).a0;
        prism_rtl::more(prism_rtl::rc(OpenTyQs(lx, i)));
    })
        : prism_rtl::is<check_types::Ty::TyElem>(t) ? ({
        auto&& o = prism_rtl::as<check_types::Ty::TyElem>(t).a1;
        prism_rtl::more(prism_rtl::rc(OpenTyQs(lx, o)));
    })
        : prism_rtl::is<check_types::Ty::TyAssoc>(t) ? ({
        auto&& a = prism_rtl::as<check_types::Ty::TyAssoc>(t).a1;
        prism_rtl::more(prism_rtl::rc(OpenTyQs(lx, a)));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start OpenTyQs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_open_ty_qs(Lx lx, check_types::Ty t) {
    return prism_rtl::make_rc<OpenTyQs>(lx, t);
}


/// AtInstance: fn Lx, (([((Text, Ty))], [((Text, Col))])) -> Lx
Lx at_instance(const Lx& lx, const std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>& arg1) {
    {
        auto&& tys = std::get<0>(arg1);
        auto&& cols = std::get<1>(arg1);
        Lx this_ = lx;
        this_.subst = fold(tys, this_.subst, [&](const Map<Text, check_types::Ty>& m, const std::tuple<Text, check_types::Ty>& _p1) {
            auto&& q = std::get<0>(_p1);
            auto&& t = std::get<1>(_p1);
            return insert(m, q, t);
        });
        this_.csubst = fold(cols, this_.csubst, [&](const Map<Text, check_types::Col>& m, const std::tuple<Text, check_types::Col>& _p1) {
            auto&& q = std::get<0>(_p1);
            auto&& c = std::get<1>(_p1);
            return insert(m, q, c);
        });
        return this_;
    }
    prism_rtl::unreachable("no arm matched");
}


/// WidgetLetLx: unbounded fn Lx, Range -> Lx
Lx widget_let_lx(const Lx& lx, const ast::Range& span) {
    auto&& _m = prelude::get(lx.gens, place_key(lx, span));
    if (prism_rtl::is_some(_m)) {
        auto&& gn = prism_rtl::some_of(_m);
        auto&& _m = instantiations(lx, gn);
        {
            auto&& m103397_0 = _m;
            if (m103397_0.size() == 1u) {
                {
                    auto&& _c1 = index(m103397_0, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& i = prism_rtl::some_of(_c1);
                        return at_instance(lx, i);
                    }
                }
            }
        }
        {
            return lx;
        }
    }
    if (prism_rtl::is_none(_m)) {
        return lx;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Lx> WidgetLetLx::cycle() const {
    const auto& lx = this->lx;
    const auto& span = this->span;
    return ({
        auto&& _m = prelude::get(lx.gens, place_key(lx, span));
        prism_rtl::is_some(_m) ? ({
        auto&& gn = prism_rtl::some_of(_m);
        ({
        auto lx_1 = lx;
        call_then(start_instantiations(lx_1, gn), [=](Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>> instantiations_103403) {
        return ({
            ({
            auto&& m103397_0 = instantiations_103403;
            (m103397_0.size() == 1u) && ({
            auto&& _c1 = index(m103397_0, Nat(0u));
            prism_rtl::is_some(_c1);
        });
        }) ? ({
            auto&& m103397_0 = instantiations_103403;
            auto&& _c1 = index(m103397_0, Nat(0u));
            auto&& i = prism_rtl::some_of(_c1);
            prism_rtl::finished(at_instance(lx_1, i));
        })
            : prism_rtl::finished(lx_1);
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(lx)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start WidgetLetLx, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Lx> start_widget_let_lx(Lx lx, ast::Range span) {
    return prism_rtl::make_rc<WidgetLetLx>(lx, span);
}


/// InstAt: fn Lx, InstNote -> (([((Text, Ty))], [((Text, Col))]))
std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>> inst_at(const Lx& lx, const typed::InstNote& u) {
    auto tys = each(u.tys, [&](const std::tuple<Text, check_types::Ty>& _p0) {
        auto&& q = std::get<0>(_p0);
        auto&& t = std::get<1>(_p0);
        return std::tuple{q, subst_ty(lx, t)};
    });
    auto cols = each(u.cols, [&](const std::tuple<Text, check_types::Col>& _p0) {
        auto&& q = std::get<0>(_p0);
        auto&& c = std::get<1>(_p0);
        return std::tuple{q, inst_col(lx, c)};
    });
    return std::tuple{tys, cols};
}


/// GenKey: fn GenNote -> Text
Text gen_key(const typed::GenNote& gn) {
    return or_(index(append(gn.tys, gn.cols), Nat(0u)), Text::lit(""));
}


/// InstKey: fn InstNote -> Text
Text inst_key(const typed::InstNote& u) {
    return or_(index(append(each(u.tys, [&](const std::tuple<Text, check_types::Ty>& _p0) {
        auto&& q = std::get<0>(_p0);
        return q;
    }), each(u.cols, [&](const std::tuple<Text, check_types::Col>& _p0) {
        auto&& q = std::get<0>(_p0);
        return q;
    })), Nat(0u)), Text::lit(""));
}


/// ColName: fn Col -> Text
Text col_name(const check_types::Col& col0) {
    if (prism_rtl::is<check_types::Col::CQ>(col0)) {
        auto&& q = prism_rtl::as<check_types::Col::CQ>(col0).a0;
        return q;
    }
    {
        auto&& c = col0;
        return Text::lit("");
    }
}


/// PlainLet: unbounded fn Lx, Env, Stmt, Pattern, Expr -> (([Do], Env))
std::tuple<Array<Do>, Env> plain_let(const Lx& lx, const Env& env, const ast::Stmt& s, const ast::Pattern_& p_, const ast::Expr& x) {
    auto v_ = value_of(lx, env, x);
    auto po = rust_pat(lx, p_, type_at(lx, x.span), Holding(Holding::Owned{}), prism_rtl::cat("l", s.span.start));
    return std::tuple{Array(std::vector{Do(Do::DoLet{po.pa, own(v_)})}), bind_all(env, po.binds)};
}


prism_rtl::Turn<std::tuple<Array<Do>, Env>> PlainLet::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& s = this->s;
    const auto& p_ = this->p_;
    const auto& x = this->x;
    auto env_1 = env;
    auto lx_2 = lx;
    auto p__3 = p_;
    auto s_4 = s;
    auto x_5 = x;
    return call_then(start_value_of(lx_2, env_1, x_5), [=](Vl value_of_104188) {
        return ({
            auto v_ = value_of_104188;
            call_then(start_rust_pat(lx_2, p__3, type_at(lx_2, x_5.span), Holding(Holding::Owned{}), prism_rtl::cat("l", s_4.span.start)), [=](PatOut rust_pat_104224) {
            return ({
                auto po = rust_pat_104224;
                (prism_rtl::finished(std::tuple{Array(std::vector{Do(Do::DoLet{po.pa, own(v_)})}), bind_all(env_1, po.binds)}));
            });
        });
        });
    });
}


/// `Start PlainLet, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<Do>, Env>> start_plain_let(Lx lx, Env env, ast::Stmt s, ast::Pattern_ p_, ast::Expr x) {
    return prism_rtl::make_rc<PlainLet>(lx, env, s, p_, x);
}


/// PatOnly: fn Pa -> PatOut
PatOut pat_only(const Pa& pa) {
    return PatOut{.pa = pa, .conds = Array<Cc>{}, .binds = Array<std::tuple<Text, Bn>>{}};
}


/// RustPat: unbounded fn Lx, Pattern, Ty, Holding, Text -> PatOut
PatOut rust_pat(const Lx& lx, const ast::Pattern_& p_, const check_types::Ty& ty, const Holding& mode, const Text& fresh) {
    auto&& _m = p_.kind;
    if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
        auto nkey = check_env::sname_key(n);
        auto [qk_opt, why] = check_env::resolve_value(lx.g, lx.home, n);
        auto is_ctor = ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& qk = prism_rtl::some_of(qk_opt);
                _v.set(check_env::has_key(lx.g.ctors, qk) && ((check_env::is_upper_text(base(nkey)) || (len(n->path_) > Nat(1u))) || is_unit_ctor(lx, qk)));
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto tagged_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<check_env::TagInfo>> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& qk = prism_rtl::some_of(qk_opt);
                _v.set(prelude::get(lx.g.tags, qk));
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(std::optional<check_env::TagInfo>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return is_ctor
            ? ctor_pat(lx, n, Array<ast::Pattern_>{}, ty, mode, fresh)
            : (why == Text::lit("tag")) && (tagged_opt != std::optional<check_env::TagInfo>{})
            ? tag_pat(lx, or_(tagged_opt, dummy_tag_info()), Array<ast::FieldPat>{}, true, ty, mode, fresh)
            : ({
            auto rs = local_name(lx, nkey);
            auto bt = out_ty_of(lx, peel(binder_ty(lx, n.span)));
            PatOut{.pa = Pa(Pa::PaBind{rs}), .conds = Array<Cc>{}, .binds = Array(std::vector{std::tuple{nkey, Bn(Bn::BnLocal{Ex(Ex::XVar{rs}), mode, bt})}})};
        });
    }
    if (prism_rtl::is<ast::PatternKind::PIgnore>(_m)) {
        return pat_only(Pa(Pa::PaWild{}));
    }
    if (prism_rtl::is<ast::PatternKind::PUnit>(_m)) {
        return pat_only(Pa(Pa::PaWild{}));
    }
    if (prism_rtl::is<ast::PatternKind::PNil>(_m)) {
        return pat_only(Pa(Pa::PaUnit{Text::lit("None")}));
    }
    if (prism_rtl::is<ast::PatternKind::PLit>(_m)) {
        auto&& l = prism_rtl::as<ast::PatternKind::PLit>(_m).a0;
        return lit_pat(lx, l, ty, mode, fresh, false);
    }
    if (prism_rtl::is<ast::PatternKind::PNeg>(_m)) {
        auto&& l = prism_rtl::as<ast::PatternKind::PNeg>(_m).a0;
        return lit_pat(lx, l, ty, mode, fresh, true);
    }
    if (prism_rtl::is<ast::PatternKind::PSigil>(_m)) {
        auto&& m105043_6_0 = prism_rtl::as<ast::PatternKind::PSigil>(_m).a0;
        auto&& q = prism_rtl::as<ast::PatternKind::PSigil>(_m).a1;
        if (m105043_6_0 == Text::lit("?")) {
            return wrap_pat(lx, Text::lit("Some"), q, inner_ty(ty), mode, fresh);
        }
    }
    if (prism_rtl::is<ast::PatternKind::PSigil>(_m)) {
        auto&& m105043_7_0 = prism_rtl::as<ast::PatternKind::PSigil>(_m).a0;
        auto&& q = prism_rtl::as<ast::PatternKind::PSigil>(_m).a1;
        if (m105043_7_0 == Text::lit("~")) {
            return wrap_pat(lx, Text::lit("Ok"), q, inner_ty(ty), mode, fresh);
        }
    }
    if (prism_rtl::is<ast::PatternKind::PSigil>(_m)) {
        auto&& q = prism_rtl::as<ast::PatternKind::PSigil>(_m).a1;
        return rust_pat(lx, q, ty, mode, fresh);
    }
    if (prism_rtl::is<ast::PatternKind::PGroup>(_m)) {
        auto&& q = prism_rtl::as<ast::PatternKind::PGroup>(_m).a0;
        return rust_pat(lx, q, ty, mode, fresh);
    }
    if (prism_rtl::is<ast::PatternKind::PCtor>(_m)) {
        auto&& n = prism_rtl::as<ast::PatternKind::PCtor>(_m).a0;
        auto&& ps = prism_rtl::as<ast::PatternKind::PCtor>(_m).a1;
        return ctor_pat(lx, n, ps, ty, mode, fresh);
    }
    if (prism_rtl::is<ast::PatternKind::PRecord>(_m)) {
        auto&& n = prism_rtl::as<ast::PatternKind::PRecord>(_m).a0;
        auto&& fps = prism_rtl::as<ast::PatternKind::PRecord>(_m).a1;
        auto&& rest = prism_rtl::as<ast::PatternKind::PRecord>(_m).a2;
        return record_pat(lx, n, fps, rest, ty, mode, fresh);
    }
    if (prism_rtl::is<ast::PatternKind::PTuple>(_m)) {
        auto&& ps = prism_rtl::as<ast::PatternKind::PTuple>(_m).a0;
        auto ts = ({
            __label__ _done;
            prism_rtl::Slot<Array<check_types::Ty>> _v;
            auto&& _m = peel(ty);
            if (prism_rtl::is<check_types::Ty::TyTuple>(_m)) {
                auto&& xs = prism_rtl::as<check_types::Ty::TyTuple>(_m).a0;
                _v.set(xs);
                goto _done;
            }
            {
                _v.set(Array<check_types::Ty>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto subs = run_to_end(each_job(check_errors::range0(len(ps)), ({
            auto lx_1 = lx;
            auto ps_2 = ps;
            auto ts_3 = ts;
            auto mode_4 = mode;
            auto fresh_5 = fresh;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto lx_1_6 = lx_1;
                auto ps_2_6 = ps_2;
                auto ts_3_6 = ts_3;
                auto mode_4_6 = mode_4;
                auto fresh_5_6 = fresh_5;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    (prism_rtl::more(prism_rtl::rc(RustPat(lx_1_6, or_(index(ps_2_6, i), dummy_pat()), or_(index(ts_3_6, i), check_types::Ty(check_types::Ty::TyErr{})), mode_4_6, prism_rtl::cat(fresh_5_6, "_", i)))));
                });
            }));
            });
        })));
        })));
        return PatOut{.pa = Pa(Pa::PaTuple{each(subs, [&](const PatOut& o) { return o.pa; })}), .conds = fold(subs, Array<Cc>{}, [&](const Array<Cc>& acc, const PatOut& o) { return append(acc, o.conds); }), .binds = fold(subs, Array<std::tuple<Text, Bn>>{}, [&](const Array<std::tuple<Text, Bn>>& acc, const PatOut& o) { return append(acc, o.binds); })};
    }
    if (prism_rtl::is<ast::PatternKind::PArray>(_m)) {
        auto&& ps = prism_rtl::as<ast::PatternKind::PArray>(_m).a0;
        return array_pat(lx, ps, ty, mode, fresh);
    }
    if (prism_rtl::is<ast::PatternKind::PFamily>(_m)) {
        auto&& q = prism_rtl::as<ast::PatternKind::PFamily>(_m).a0;
        return family_pat(lx, q, ty, fresh);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<PatOut> RustPat::cycle() const {
    const auto& lx = this->lx;
    const auto& p_ = this->p_;
    const auto& ty = this->ty;
    const auto& mode = this->mode;
    const auto& fresh = this->fresh;
    return ({
        auto&& _m = p_.kind;
        prism_rtl::is<ast::PatternKind::PName>(_m) ? ({
        auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
        ({
        auto nkey = check_env::sname_key(n);
        auto [qk_opt, why] = check_env::resolve_value(lx.g, lx.home, n);
        auto is_ctor = ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& qk = prism_rtl::some_of(qk_opt);
                _v.set(check_env::has_key(lx.g.ctors, qk) && ((check_env::is_upper_text(base(nkey)) || (len(n->path_) > Nat(1u))) || is_unit_ctor(lx, qk)));
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto tagged_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<check_env::TagInfo>> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& qk = prism_rtl::some_of(qk_opt);
                _v.set(prelude::get(lx.g.tags, qk));
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(std::optional<check_env::TagInfo>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        is_ctor
        ? prism_rtl::more(prism_rtl::rc(CtorPat(lx, n, Array<ast::Pattern_>{}, ty, mode, fresh)))
        : (why == Text::lit("tag")) && (tagged_opt != std::optional<check_env::TagInfo>{})
        ? prism_rtl::more(prism_rtl::rc(TagPat(lx, or_(tagged_opt, dummy_tag_info()), Array<ast::FieldPat>{}, true, ty, mode, fresh)))
        : ({
        auto rs = local_name(lx, nkey);
        auto lx_1 = lx;
        auto mode_2 = mode;
        auto n_3 = n;
        call_then(start_out_ty_of(lx_1, peel(binder_ty(lx_1, n_3.span))), [=](OutTy out_ty_of_105661) {
        return ({
            auto bt = out_ty_of_105661;
            (prism_rtl::finished(PatOut{.pa = Pa(Pa::PaBind{rs}), .conds = Array<Cc>{}, .binds = Array(std::vector{std::tuple{nkey, Bn(Bn::BnLocal{Ex(Ex::XVar{rs}), mode_2, bt})}})}));
        });
    });
    });
    });
    })
        : prism_rtl::is<ast::PatternKind::PIgnore>(_m) ? prism_rtl::finished(pat_only(Pa(Pa::PaWild{})))
        : prism_rtl::is<ast::PatternKind::PUnit>(_m) ? prism_rtl::finished(pat_only(Pa(Pa::PaWild{})))
        : prism_rtl::is<ast::PatternKind::PNil>(_m) ? prism_rtl::finished(pat_only(Pa(Pa::PaUnit{Text::lit("None")})))
        : prism_rtl::is<ast::PatternKind::PLit>(_m) ? ({
        auto&& l = prism_rtl::as<ast::PatternKind::PLit>(_m).a0;
        prism_rtl::more(prism_rtl::rc(LitPat(lx, l, ty, mode, fresh, false)));
    })
        : prism_rtl::is<ast::PatternKind::PNeg>(_m) ? ({
        auto&& l = prism_rtl::as<ast::PatternKind::PNeg>(_m).a0;
        prism_rtl::more(prism_rtl::rc(LitPat(lx, l, ty, mode, fresh, true)));
    })
        : prism_rtl::is<ast::PatternKind::PSigil>(_m) && ({
        auto&& m105043_6_0 = prism_rtl::as<ast::PatternKind::PSigil>(_m).a0;
        auto&& q = prism_rtl::as<ast::PatternKind::PSigil>(_m).a1;
        (m105043_6_0 == Text::lit("?"));
    }) ? ({
        auto&& m105043_6_0 = prism_rtl::as<ast::PatternKind::PSigil>(_m).a0;
        auto&& q = prism_rtl::as<ast::PatternKind::PSigil>(_m).a1;
        prism_rtl::more(prism_rtl::rc(WrapPat(lx, Text::lit("Some"), q, inner_ty(ty), mode, fresh)));
    })
        : prism_rtl::is<ast::PatternKind::PSigil>(_m) && ({
        auto&& m105043_7_0 = prism_rtl::as<ast::PatternKind::PSigil>(_m).a0;
        auto&& q = prism_rtl::as<ast::PatternKind::PSigil>(_m).a1;
        (m105043_7_0 == Text::lit("~"));
    }) ? ({
        auto&& m105043_7_0 = prism_rtl::as<ast::PatternKind::PSigil>(_m).a0;
        auto&& q = prism_rtl::as<ast::PatternKind::PSigil>(_m).a1;
        prism_rtl::more(prism_rtl::rc(WrapPat(lx, Text::lit("Ok"), q, inner_ty(ty), mode, fresh)));
    })
        : prism_rtl::is<ast::PatternKind::PSigil>(_m) ? ({
        auto&& q = prism_rtl::as<ast::PatternKind::PSigil>(_m).a1;
        prism_rtl::more(prism_rtl::rc(RustPat(lx, q, ty, mode, fresh)));
    })
        : prism_rtl::is<ast::PatternKind::PGroup>(_m) ? ({
        auto&& q = prism_rtl::as<ast::PatternKind::PGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(RustPat(lx, q, ty, mode, fresh)));
    })
        : prism_rtl::is<ast::PatternKind::PCtor>(_m) ? ({
        auto&& n = prism_rtl::as<ast::PatternKind::PCtor>(_m).a0;
        auto&& ps = prism_rtl::as<ast::PatternKind::PCtor>(_m).a1;
        prism_rtl::more(prism_rtl::rc(CtorPat(lx, n, ps, ty, mode, fresh)));
    })
        : prism_rtl::is<ast::PatternKind::PRecord>(_m) ? ({
        auto&& n = prism_rtl::as<ast::PatternKind::PRecord>(_m).a0;
        auto&& fps = prism_rtl::as<ast::PatternKind::PRecord>(_m).a1;
        auto&& rest = prism_rtl::as<ast::PatternKind::PRecord>(_m).a2;
        prism_rtl::more(prism_rtl::rc(RecordPat(lx, n, fps, rest, ty, mode, fresh)));
    })
        : prism_rtl::is<ast::PatternKind::PTuple>(_m) ? ({
        auto&& ps = prism_rtl::as<ast::PatternKind::PTuple>(_m).a0;
        ({
        auto ts = ({
            __label__ _done;
            prism_rtl::Slot<Array<check_types::Ty>> _v;
            auto&& _m = peel(ty);
            if (prism_rtl::is<check_types::Ty::TyTuple>(_m)) {
                auto&& xs = prism_rtl::as<check_types::Ty::TyTuple>(_m).a0;
                _v.set(xs);
                goto _done;
            }
            {
                _v.set(Array<check_types::Ty>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto fresh_1 = fresh;
        auto lx_2 = lx;
        auto mode_3 = mode;
        auto ps_4 = ps;
        call_value(each_job(check_errors::range0(len(ps_4)), ({
        auto lx_2_5 = lx_2;
        auto ps_4_5 = ps_4;
        auto ts_5 = ts;
        auto mode_3_6 = mode_3;
        auto fresh_1_6 = fresh_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto lx_2_5_6 = lx_2_5;
            auto ps_4_5_6 = ps_4_5;
            auto ts_5_6 = ts_5;
            auto mode_3_6_6 = mode_3_6;
            auto fresh_1_6_6 = fresh_1_6;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(RustPat(lx_2_5_6, or_(index(ps_4_5_6, i), dummy_pat()), or_(index(ts_5_6, i), check_types::Ty(check_types::Ty::TyErr{})), mode_3_6_6, prism_rtl::cat(fresh_1_6_6, "_", i)))));
            });
        }));
        });
    })));
    })), [=](Array<PatOut> each_106460) {
        return ({
            auto subs = each_106460;
            (prism_rtl::finished(PatOut{.pa = Pa(Pa::PaTuple{each(subs, [&](const PatOut& o) { return o.pa; })}), .conds = fold(subs, Array<Cc>{}, [&](const Array<Cc>& acc, const PatOut& o) { return append(acc, o.conds); }), .binds = fold(subs, Array<std::tuple<Text, Bn>>{}, [&](const Array<std::tuple<Text, Bn>>& acc, const PatOut& o) { return append(acc, o.binds); })}));
        });
    });
    });
    })
        : prism_rtl::is<ast::PatternKind::PArray>(_m) ? ({
        auto&& ps = prism_rtl::as<ast::PatternKind::PArray>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ArrayPat(lx, ps, ty, mode, fresh)));
    })
        : prism_rtl::is<ast::PatternKind::PFamily>(_m) ? ({
        auto&& q = prism_rtl::as<ast::PatternKind::PFamily>(_m).a0;
        prism_rtl::more(prism_rtl::rc(FamilyPat(lx, q, ty, fresh)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start RustPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_rust_pat(Lx lx, ast::Pattern_ p_, check_types::Ty ty, Holding mode, Text fresh) {
    return prism_rtl::make_rc<RustPat>(lx, p_, ty, mode, fresh);
}


/// let dummyPat
ast::Pattern_ dummy_pat() {
    return ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PIgnore{})), .span = ast::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// InnerTy: fn Ty -> Ty
check_types::Ty inner_ty(const check_types::Ty& t) {
    auto&& _m = peel(t);
    if (prism_rtl::is<check_types::Ty::TySig>(_m)) {
        auto&& m106919_0_0 = prism_rtl::as<check_types::Ty::TySig>(_m).a0;
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(_m).a1;
        if (m106919_0_0 == Text::lit("?")) {
            return i;
        }
    }
    if (prism_rtl::is<check_types::Ty::TySig>(_m)) {
        auto&& m106919_1_0 = prism_rtl::as<check_types::Ty::TySig>(_m).a0;
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(_m).a1;
        if (m106919_1_0 == Text::lit("~")) {
            return i;
        }
    }
    {
        return check_types::Ty(check_types::Ty::TyErr{});
    }
}


/// IsUnitCtor: fn Lx, Text -> Bool
bool is_unit_ctor(const Lx& lx, const Text& qk) {
    auto&& _m = prelude::get(lx.g.ctors, qk);
    if (prism_rtl::is_some(_m)) {
        auto&& c = prism_rtl::some_of(_m);
        auto&& _m = or_(prelude::get(lx.g.types, c.owner), check_env::dummy_ty_info()).body;
        if (prism_rtl::is<check_env::TyBody::BChoice>(_m)) {
            auto&& m107172_0_0 = prism_rtl::as<check_env::TyBody::BChoice>(_m).a0;
            if (m107172_0_0.size() == 1u) {
                {
                    auto&& _c2 = index(m107172_0_0, Nat(0u));
                    if (prism_rtl::is_some(_c2)) {
                        auto&& m107172_0_0_0_1 = std::get<1>(prism_rtl::some_of(_c2));
                        if (m107172_0_0_0_1.size() == 0u) {
                            return check_env::is_lower_text(check_types::bare_name(qk));
                        }
                    }
                }
            }
        }
        {
            return false;
        }
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// WrapPat: unbounded fn Lx, Text, Pattern, Ty, Holding, Text -> PatOut
PatOut wrap_pat(const Lx& lx, const Text& ctor, const ast::Pattern_& q, const check_types::Ty& inner, const Holding& mode, const Text& fresh) {
    auto o = rust_pat(lx, q, inner, mode, fresh);
    PatOut this_ = o;
    this_.pa = Pa(Pa::PaCtor{ctor, Array(std::vector{this_.pa})});
    return this_;
}


prism_rtl::Turn<PatOut> WrapPat::cycle() const {
    const auto& lx = this->lx;
    const auto& ctor = this->ctor;
    const auto& q = this->q;
    const auto& inner = this->inner;
    const auto& mode = this->mode;
    const auto& fresh = this->fresh;
    auto ctor_1 = ctor;
    auto fresh_2 = fresh;
    auto inner_3 = inner;
    auto lx_4 = lx;
    auto mode_5 = mode;
    auto q_6 = q;
    return call_then(start_rust_pat(lx_4, q_6, inner_3, mode_5, fresh_2), [=](PatOut rust_pat_107452) {
        return ({
            auto o = rust_pat_107452;
            (prism_rtl::finished(({
            PatOut this_ = o;
            this_.pa = Pa(Pa::PaCtor{ctor_1, Array(std::vector{this_.pa})});
            this_;
        })));
        });
    });
}


/// `Start WrapPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_wrap_pat(Lx lx, Text ctor, ast::Pattern_ q, check_types::Ty inner, Holding mode, Text fresh) {
    return prism_rtl::make_rc<WrapPat>(lx, ctor, q, inner, mode, fresh);
}


/// LitPat: unbounded fn Lx, Literal, Ty, Holding, Text, Bool -> PatOut
PatOut lit_pat(const Lx& lx, const ast::Literal& l, const check_types::Ty& ty, const Holding& mode, const Text& fresh, const bool& neg) {
    auto t = out_ty_of(lx, peel(ty));
    auto&& _m = l.kind;
    if (prism_rtl::is<ast::LitKind::LChar>(_m)) {
        auto&& c = prism_rtl::as<ast::LitKind::LChar>(_m).a0;
        return pat_only(Pa(Pa::PaChar{c}));
    }
    {
        auto lit = ({
            __label__ _done;
            prism_rtl::Slot<Vl> _v;
            auto&& _m = l.kind;
            if (prism_rtl::is<ast::LitKind::LInt>(_m)) {
                auto&& d = prism_rtl::as<ast::LitKind::LInt>(_m).a0;
                _v.set((((t == OutTy(OutTy::OutNat{})) || (t == OutTy(OutTy::OutInt{}))) || (t == OutTy(OutTy::OutU8{}))) || (t == OutTy(OutTy::OutFloat{}))
                    ? Vl(Vl::VlOwned{number(t, d, neg), t})
                    : literal_value(lx, empty_env(), l, l.span, neg));
                goto _done;
            }
            {
                _v.set(literal_value(lx, empty_env(), l, l.span, neg));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto lv = Vl(Vl::VlOwned{own(lit), t});
        auto b = local_place(Ex(Ex::XVar{fresh}), mode, t);
        return PatOut{.pa = Pa(Pa::PaBind{fresh}), .conds = Array(std::vector{Cc(Cc::CcIf{Ex(Ex::XBin{Text::lit("=="), prism_rtl::rc(ref_(b)), prism_rtl::rc(ref_(lv))})})}), .binds = Array<std::tuple<Text, Bn>>{}};
    }
}


prism_rtl::Turn<PatOut> LitPat::cycle() const {
    const auto& lx = this->lx;
    const auto& l = this->l;
    const auto& ty = this->ty;
    const auto& mode = this->mode;
    const auto& fresh = this->fresh;
    const auto& neg = this->neg;
    auto fresh_1 = fresh;
    auto l_2 = l;
    auto lx_3 = lx;
    auto mode_4 = mode;
    auto neg_5 = neg;
    auto ty_6 = ty;
    return call_then(start_out_ty_of(lx_3, peel(ty_6)), [=](OutTy out_ty_of_107764) {
        return ({
            auto t = out_ty_of_107764;
            ({
            auto&& _m = l_2.kind;
            prism_rtl::is<ast::LitKind::LChar>(_m) ? ({
            auto&& c = prism_rtl::as<ast::LitKind::LChar>(_m).a0;
            prism_rtl::finished(pat_only(Pa(Pa::PaChar{c})));
        })
            : ({
            auto lit = ({
                __label__ _done;
                prism_rtl::Slot<Vl> _v;
                auto&& _m = l_2.kind;
                if (prism_rtl::is<ast::LitKind::LInt>(_m)) {
                    auto&& d = prism_rtl::as<ast::LitKind::LInt>(_m).a0;
                    _v.set((((t == OutTy(OutTy::OutNat{})) || (t == OutTy(OutTy::OutInt{}))) || (t == OutTy(OutTy::OutU8{}))) || (t == OutTy(OutTy::OutFloat{}))
                        ? Vl(Vl::VlOwned{number(t, d, neg_5), t})
                        : literal_value(lx_3, empty_env(), l_2, l_2.span, neg_5));
                    goto _done;
                }
                {
                    _v.set(literal_value(lx_3, empty_env(), l_2, l_2.span, neg_5));
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto lv = Vl(Vl::VlOwned{own(lit), t});
            auto b = local_place(Ex(Ex::XVar{fresh_1}), mode_4, t);
            (prism_rtl::finished(PatOut{.pa = Pa(Pa::PaBind{fresh_1}), .conds = Array(std::vector{Cc(Cc::CcIf{Ex(Ex::XBin{Text::lit("=="), prism_rtl::rc(ref_(b)), prism_rtl::rc(ref_(lv))})})}), .binds = Array<std::tuple<Text, Bn>>{}}));
        });
        });
        });
    });
}


/// `Start LitPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_lit_pat(Lx lx, ast::Literal l, check_types::Ty ty, Holding mode, Text fresh, bool neg) {
    return prism_rtl::make_rc<LitPat>(lx, l, ty, mode, fresh, neg);
}


/// CtorPat: unbounded fn Lx, SName, [Pattern], Ty, Holding, Text -> PatOut
PatOut ctor_pat(const Lx& lx, const ast::SName& n, const Array<ast::Pattern_>& ps, const check_types::Ty& ty, const Holding& mode, const Text& fresh) {
    auto&& _qk_opt = check_env::resolve_value(lx.g, lx.home, n);
    auto&& qk_opt = std::get<0>(_qk_opt);
    if (prism_rtl::is_some(qk_opt)) {
        auto&& m108807_0 = prism_rtl::some_of(qk_opt);
        if (m108807_0 == Text::lit("True")) {
            return pat_only(Pa(Pa::PaBool{true}));
        }
    }
    if (prism_rtl::is_some(qk_opt)) {
        auto&& m108807_1 = prism_rtl::some_of(qk_opt);
        if (m108807_1 == Text::lit("False")) {
            return pat_only(Pa(Pa::PaBool{false}));
        }
    }
    if (prism_rtl::is_some(qk_opt)) {
        auto&& qk = prism_rtl::some_of(qk_opt);
        auto&& _m = prelude::get(lx.g.ctors, qk);
        if (prism_rtl::is_some(_m)) {
            auto&& c = prism_rtl::some_of(_m);
            auto owner = or_(prelude::get(lx.g.types, c.owner), check_env::dummy_ty_info());
            auto ty_path = path_in(lx, owner.home, camel(check_types::bare_name(c.owner)));
            auto args = ({
                __label__ _done;
                prism_rtl::Slot<Array<check_types::Ty>> _v;
                auto&& _m = peel(ty);
                if (prism_rtl::is<check_types::Ty::TyCon>(_m)) {
                    auto&& xs = prism_rtl::as<check_types::Ty::TyCon>(_m).a1;
                    _v.set(xs);
                    goto _done;
                }
                {
                    _v.set(Array<check_types::Ty>{});
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto subs = run_to_end(each_job(check_errors::range0(len(ps)), ({
                auto lx_1 = lx;
                auto c_2 = c;
                auto ps_3 = ps;
                auto args_4 = args;
                auto mode_5 = mode;
                auto fresh_6 = fresh;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                return ({
                    auto lx_1_7 = lx_1;
                    auto c_2_7 = c_2;
                    auto ps_3_7 = ps_3;
                    auto args_4_7 = args_4;
                    auto mode_5_7 = mode_5;
                    auto fresh_6_7 = fresh_6;
                    entered(once_job([=]() {
                    return ({
                        auto i = p0;
                        call_then(start_instantiated(or_(index(c_2_7->args, i), check_types::Ty(check_types::Ty::TyErr{})), c_2_7.params, args_4_7), [=](check_types::Ty instantiated_109311) { return prism_rtl::more(prism_rtl::rc(SubPat(lx_1_7, c_2_7, i, or_(index(ps_3_7, i), dummy_pat()), instantiated_109311, mode_5_7, prism_rtl::cat(fresh_6_7, "_", i)))); });
                    });
                }));
                });
            })));
            })));
            auto conds = fold(subs, Array<Cc>{}, [&](const Array<Cc>& acc, const PatOut& o) { return append(acc, o.conds); });
            auto binds = fold(subs, Array<std::tuple<Text, Bn>>{}, [&](const Array<std::tuple<Text, Bn>>& acc, const PatOut& o) { return append(acc, o.binds); });
            auto pas = each(subs, [&](const PatOut& o) { return o.pa; });
            auto&& _m = owner.body;
            if (prism_rtl::is<check_env::TyBody::BRecord>(_m)) {
                auto&& fs = prism_rtl::as<check_env::TyBody::BRecord>(_m).a0;
                return PatOut{.pa = Pa(Pa::PaRecord{ty_path, each(check_errors::range0(len(pas)), [&](const Nat& i) { return std::tuple{snake(or_(index(c.fields, i), Text::lit(""))), or_(index(pas, i), Pa(Pa::PaWild{}))}; }), len(pas) < len(c.fields)}), .conds = conds, .binds = binds};
            }
            {
                auto is_unit_type = (len(c->args) == Nat(0u)) && is_unit_ctor(lx, qk);
                auto is_newtype = (check_types::bare_name(c.name) == check_types::bare_name(c.owner)) && ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = owner.body;
                    if (prism_rtl::is<check_env::TyBody::BChoice>(_m)) {
                        auto&& cases = prism_rtl::as<check_env::TyBody::BChoice>(_m).a0;
                        _v.set(len(cases) == Nat(1u));
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto path_ = is_unit_type || is_newtype
                    ? ty_path
                    : prism_rtl::cat(ty_path, "::", camel(check_types::bare_name(c.name)));
                return len(c->args) == Nat(0u)
                    ? PatOut{.pa = Pa(Pa::PaUnit{path_}), .conds = Array<Cc>{}, .binds = Array<std::tuple<Text, Bn>>{}}
                    : PatOut{.pa = Pa(Pa::PaCtor{path_, pas}), .conds = conds, .binds = binds};
            }
        }
        if (prism_rtl::is_none(_m)) {
            return PatOut{.pa = Pa(Pa::PaWild{}), .conds = Array(std::vector{Cc(Cc::CcIf{refusal(prism_rtl::cat("a pattern of ", qk))})}), .binds = Array<std::tuple<Text, Bn>>{}};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_none(qk_opt)) {
        return PatOut{.pa = Pa(Pa::PaWild{}), .conds = Array(std::vector{Cc(Cc::CcIf{refusal(Text::lit("a pattern of an unknown constructor"))})}), .binds = Array<std::tuple<Text, Bn>>{}};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<PatOut> CtorPat::cycle() const {
    const auto& lx = this->lx;
    const auto& n = this->n;
    const auto& ps = this->ps;
    const auto& ty = this->ty;
    const auto& mode = this->mode;
    const auto& fresh = this->fresh;
    auto&& _qk_opt = check_env::resolve_value(lx.g, lx.home, n);
    auto&& qk_opt = std::get<0>(_qk_opt);
    return ({
        prism_rtl::is_some(qk_opt) && ({
        auto&& m108807_0 = prism_rtl::some_of(qk_opt);
        (m108807_0 == Text::lit("True"));
    }) ? ({
        auto&& m108807_0 = prism_rtl::some_of(qk_opt);
        prism_rtl::finished(pat_only(Pa(Pa::PaBool{true})));
    })
        : prism_rtl::is_some(qk_opt) && ({
        auto&& m108807_1 = prism_rtl::some_of(qk_opt);
        (m108807_1 == Text::lit("False"));
    }) ? ({
        auto&& m108807_1 = prism_rtl::some_of(qk_opt);
        prism_rtl::finished(pat_only(Pa(Pa::PaBool{false})));
    })
        : prism_rtl::is_some(qk_opt) ? ({
        auto&& qk = prism_rtl::some_of(qk_opt);
        ({
        auto&& _m = prelude::get(lx.g.ctors, qk);
        prism_rtl::is_some(_m) ? ({
        auto&& c = prism_rtl::some_of(_m);
        ({
        auto owner = or_(prelude::get(lx.g.types, c.owner), check_env::dummy_ty_info());
        auto ty_path = path_in(lx, owner.home, camel(check_types::bare_name(c.owner)));
        auto args = ({
            __label__ _done;
            prism_rtl::Slot<Array<check_types::Ty>> _v;
            auto&& _m = peel(ty);
            if (prism_rtl::is<check_types::Ty::TyCon>(_m)) {
                auto&& xs = prism_rtl::as<check_types::Ty::TyCon>(_m).a1;
                _v.set(xs);
                goto _done;
            }
            {
                _v.set(Array<check_types::Ty>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto fresh_1 = fresh;
        auto lx_2 = lx;
        auto mode_3 = mode;
        auto ps_4 = ps;
        auto qk_5 = qk;
        call_value(each_job(check_errors::range0(len(ps_4)), ({
        auto lx_2_6 = lx_2;
        auto c_6 = c;
        auto ps_4_7 = ps_4;
        auto args_7 = args;
        auto mode_3_8 = mode_3;
        auto fresh_1_8 = fresh_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto lx_2_6_8 = lx_2_6;
            auto c_6_8 = c_6;
            auto ps_4_7_8 = ps_4_7;
            auto args_7_8 = args_7;
            auto mode_3_8_8 = mode_3_8;
            auto fresh_1_8_8 = fresh_1_8;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                call_then(start_instantiated(or_(index(c_6_8->args, i), check_types::Ty(check_types::Ty::TyErr{})), c_6_8.params, args_7_8), [=](check_types::Ty instantiated_109311) { return prism_rtl::more(prism_rtl::rc(SubPat(lx_2_6_8, c_6_8, i, or_(index(ps_4_7_8, i), dummy_pat()), instantiated_109311, mode_3_8_8, prism_rtl::cat(fresh_1_8_8, "_", i)))); });
            });
        }));
        });
    })));
    })), [=](Array<PatOut> each_109242) {
        return ({
            auto subs = each_109242;
            auto conds = fold(subs, Array<Cc>{}, [&](const Array<Cc>& acc, const PatOut& o) { return append(acc, o.conds); });
            auto binds = fold(subs, Array<std::tuple<Text, Bn>>{}, [&](const Array<std::tuple<Text, Bn>>& acc, const PatOut& o) { return append(acc, o.binds); });
            auto pas = each(subs, [&](const PatOut& o) { return o.pa; });
            ({
            auto&& _m = owner.body;
            prism_rtl::is<check_env::TyBody::BRecord>(_m) ? ({
            auto&& fs = prism_rtl::as<check_env::TyBody::BRecord>(_m).a0;
            prism_rtl::finished(PatOut{.pa = Pa(Pa::PaRecord{ty_path, each(check_errors::range0(len(pas)), [&](const Nat& i) { return std::tuple{snake(or_(index(c.fields, i), Text::lit(""))), or_(index(pas, i), Pa(Pa::PaWild{}))}; }), len(pas) < len(c.fields)}), .conds = conds, .binds = binds});
        })
            : ({
            auto is_unit_type = (len(c->args) == Nat(0u)) && is_unit_ctor(lx_2, qk_5);
            auto is_newtype = (check_types::bare_name(c.name) == check_types::bare_name(c.owner)) && ({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = owner.body;
                if (prism_rtl::is<check_env::TyBody::BChoice>(_m)) {
                    auto&& cases = prism_rtl::as<check_env::TyBody::BChoice>(_m).a0;
                    _v.set(len(cases) == Nat(1u));
                    goto _done;
                }
                {
                    _v.set(false);
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto path_ = is_unit_type || is_newtype
                ? ty_path
                : prism_rtl::cat(ty_path, "::", camel(check_types::bare_name(c.name)));
            len(c->args) == Nat(0u)
            ? prism_rtl::finished(PatOut{.pa = Pa(Pa::PaUnit{path_}), .conds = Array<Cc>{}, .binds = Array<std::tuple<Text, Bn>>{}})
            : prism_rtl::finished(PatOut{.pa = Pa(Pa::PaCtor{path_, pas}), .conds = conds, .binds = binds});
        });
        });
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(PatOut{.pa = Pa(Pa::PaWild{}), .conds = Array(std::vector{Cc(Cc::CcIf{refusal(prism_rtl::cat("a pattern of ", qk))})}), .binds = Array<std::tuple<Text, Bn>>{}})
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is_none(qk_opt) ? prism_rtl::finished(PatOut{.pa = Pa(Pa::PaWild{}), .conds = Array(std::vector{Cc(Cc::CcIf{refusal(Text::lit("a pattern of an unknown constructor"))})}), .binds = Array<std::tuple<Text, Bn>>{}})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CtorPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_ctor_pat(Lx lx, ast::SName n, Array<ast::Pattern_> ps, check_types::Ty ty, Holding mode, Text fresh) {
    return prism_rtl::make_rc<CtorPat>(lx, n, ps, ty, mode, fresh);
}


/// SubPat: unbounded fn Lx, CtorInfo, Nat, Pattern, Ty, Holding, Text -> PatOut
PatOut sub_pat(const Lx& lx, const check_env::CtorInfo& c, const Nat& i, const ast::Pattern_& p_, const check_types::Ty& ty, const Holding& mode, const Text& fresh) {
    return !rc_field(lx, c.name, i)
        ? rust_pat(lx, p_, ty, mode, fresh)
        : ({
        auto rc_mode = mode == Holding(Holding::Owned{})
            ? Holding(Holding::RcOwned{})
            : Holding(Holding::RcRef{});
        ({
        __label__ _done;
        prism_rtl::Slot<PatOut> _v;
        auto&& _m = p_.kind;
        if (prism_rtl::is<ast::PatternKind::PIgnore>(_m)) {
            _v.set(pat_only(Pa(Pa::PaWild{})));
            goto _done;
        }
        if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
            auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
            _v.set(({
                auto o = rust_pat(lx, p_, ty, rc_mode, fresh);
                ({
                __label__ _done;
                prism_rtl::Slot<PatOut> _v;
                auto&& _m = o.pa;
                if (prism_rtl::is<Pa::PaBind>(_m)) {
                    _v.set(o);
                    goto _done;
                }
                {
                    _v.set(behind_rc(lx, p_, ty, rc_mode, fresh));
                    goto _done;
                }
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        {
            _v.set(behind_rc(lx, p_, ty, rc_mode, fresh));
            goto _done;
        }
    _done:
        _v.take();
    });
    });
}


prism_rtl::Turn<PatOut> SubPat::cycle() const {
    const auto& lx = this->lx;
    const auto& c = this->c;
    const auto& i = this->i;
    const auto& p_ = this->p_;
    const auto& ty = this->ty;
    const auto& mode = this->mode;
    const auto& fresh = this->fresh;
    return !rc_field(lx, c.name, i)
        ? prism_rtl::more(prism_rtl::rc(RustPat(lx, p_, ty, mode, fresh)))
        : ({
        auto rc_mode = mode == Holding(Holding::Owned{})
            ? Holding(Holding::RcOwned{})
            : Holding(Holding::RcRef{});
        ({
        auto&& _m = p_.kind;
        prism_rtl::is<ast::PatternKind::PIgnore>(_m) ? prism_rtl::finished(pat_only(Pa(Pa::PaWild{})))
        : prism_rtl::is<ast::PatternKind::PName>(_m) ? ({
        auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
        ({
        auto fresh_1 = fresh;
        auto lx_2 = lx;
        auto p__3 = p_;
        auto ty_4 = ty;
        call_then(start_rust_pat(lx_2, p__3, ty_4, rc_mode, fresh_1), [=](PatOut rust_pat_111205) {
        return ({
            auto o = rust_pat_111205;
            ({
            auto&& _m = o.pa;
            prism_rtl::is<Pa::PaBind>(_m) ? prism_rtl::finished(o)
            : prism_rtl::more(prism_rtl::rc(BehindRc(lx_2, p__3, ty_4, rc_mode, fresh_1)));
        });
        });
    });
    });
    })
        : prism_rtl::more(prism_rtl::rc(BehindRc(lx, p_, ty, rc_mode, fresh)));
    });
    });
}


/// `Start SubPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_sub_pat(Lx lx, check_env::CtorInfo c, Nat i, ast::Pattern_ p_, check_types::Ty ty, Holding mode, Text fresh) {
    return prism_rtl::make_rc<SubPat>(lx, c, i, p_, ty, mode, fresh);
}


/// BehindRc: unbounded fn Lx, Pattern, Ty, Holding, Text -> PatOut
PatOut behind_rc(const Lx& lx, const ast::Pattern_& p_, const check_types::Ty& ty, const Holding& rc_mode, const Text& fresh) {
    auto inner = rust_pat(lx, p_, ty, Holding(Holding::ByRef{}), prism_rtl::cat(fresh, "_r"));
    auto place = ref_(local_place(Ex(Ex::XVar{fresh}), rc_mode, OutTy(OutTy::OutUnknown{Text::lit("a payload")})));
    return PatOut{.pa = Pa(Pa::PaBind{fresh}), .conds = append(Array(std::vector{Cc(Cc::CcLet{inner.pa, place})}), inner.conds), .binds = inner.binds};
}


prism_rtl::Turn<PatOut> BehindRc::cycle() const {
    const auto& lx = this->lx;
    const auto& p_ = this->p_;
    const auto& ty = this->ty;
    const auto& rc_mode = this->rc_mode;
    const auto& fresh = this->fresh;
    auto fresh_1 = fresh;
    auto lx_2 = lx;
    auto p__3 = p_;
    auto rc_mode_4 = rc_mode;
    auto ty_5 = ty;
    return call_then(start_rust_pat(lx_2, p__3, ty_5, Holding(Holding::ByRef{}), prism_rtl::cat(fresh_1, "_r")), [=](PatOut rust_pat_111544) {
        return ({
            auto inner = rust_pat_111544;
            auto place = ref_(local_place(Ex(Ex::XVar{fresh_1}), rc_mode_4, OutTy(OutTy::OutUnknown{Text::lit("a payload")})));
            (prism_rtl::finished(PatOut{.pa = Pa(Pa::PaBind{fresh_1}), .conds = append(Array(std::vector{Cc(Cc::CcLet{inner.pa, place})}), inner.conds), .binds = inner.binds}));
        });
    });
}


/// `Start BehindRc, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_behind_rc(Lx lx, ast::Pattern_ p_, check_types::Ty ty, Holding rc_mode, Text fresh) {
    return prism_rtl::make_rc<BehindRc>(lx, p_, ty, rc_mode, fresh);
}


/// RecordPat: unbounded fn Lx, SName, [FieldPat], Bool, Ty, Holding, Text -> PatOut
PatOut record_pat(const Lx& lx, const ast::SName& n, const Array<ast::FieldPat>& fps, const bool& rest, const check_types::Ty& ty, const Holding& mode, const Text& fresh) {
    auto [qk_opt, why] = check_env::resolve_value(lx.g, lx.home, n);
    auto qk = or_(qk_opt, Text::lit(""));
    return qk == Text::lit("Prelude.Error")
        ? error_pat(lx, fps, ty, mode, fresh)
        : (why == Text::lit("tag")) && check_env::has_key(lx.g.tags, qk)
        ? tag_pat(lx, or_(prelude::get(lx.g.tags, qk), dummy_tag_info()), fps, rest, ty, mode, fresh)
        : ({
        __label__ _done;
        prism_rtl::Slot<PatOut> _v;
        auto&& _m = prelude::get(lx.g.ctors, qk);
        if (prism_rtl::is_some(_m)) {
            auto&& c = prism_rtl::some_of(_m);
            _v.set(({
                auto owner = or_(prelude::get(lx.g.types, c.owner), check_env::dummy_ty_info());
                auto ty_path = path_in(lx, owner.home, camel(check_types::bare_name(c.owner)));
                ({
                __label__ _done;
                prism_rtl::Slot<PatOut> _v;
                auto&& _m = owner.body;
                if (prism_rtl::is<check_env::TyBody::BChoice>(_m)) {
                    auto&& cases = prism_rtl::as<check_env::TyBody::BChoice>(_m).a0;
                    if (len(fps) == Nat(0u)) {
                        _v.set(rest_case_pat(c, cases, ty_path));
                        goto _done;
                    }
                }
                {
                    _v.set(fields_pat(lx, c, fps, rest, ty, mode, fresh, ty_path));
                    goto _done;
                }
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<PatOut> _v;
                auto&& _m = prelude::get(lx.g.tags, qk);
                if (prism_rtl::is_some(_m)) {
                    auto&& tg = prism_rtl::some_of(_m);
                    _v.set(tag_pat(lx, tg, fps, rest, ty, mode, fresh));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(PatOut{.pa = Pa(Pa::PaWild{}), .conds = Array(std::vector{Cc(Cc::CcIf{refusal(prism_rtl::cat("a pattern of ", qk))})}), .binds = Array<std::tuple<Text, Bn>>{}});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<PatOut> RecordPat::cycle() const {
    const auto& lx = this->lx;
    const auto& n = this->n;
    const auto& fps = this->fps;
    const auto& rest = this->rest;
    const auto& ty = this->ty;
    const auto& mode = this->mode;
    const auto& fresh = this->fresh;
    auto [qk_opt, why] = check_env::resolve_value(lx.g, lx.home, n);
    auto qk = or_(qk_opt, Text::lit(""));
    return qk == Text::lit("Prelude.Error")
        ? prism_rtl::more(prism_rtl::rc(ErrorPat(lx, fps, ty, mode, fresh)))
        : (why == Text::lit("tag")) && check_env::has_key(lx.g.tags, qk)
        ? prism_rtl::more(prism_rtl::rc(TagPat(lx, or_(prelude::get(lx.g.tags, qk), dummy_tag_info()), fps, rest, ty, mode, fresh)))
        : ({
        auto&& _m = prelude::get(lx.g.ctors, qk);
        prism_rtl::is_some(_m) ? ({
        auto&& c = prism_rtl::some_of(_m);
        ({
        auto owner = or_(prelude::get(lx.g.types, c.owner), check_env::dummy_ty_info());
        auto ty_path = path_in(lx, owner.home, camel(check_types::bare_name(c.owner)));
        ({
        auto&& _m = owner.body;
        prism_rtl::is<check_env::TyBody::BChoice>(_m) && ({
        auto&& cases = prism_rtl::as<check_env::TyBody::BChoice>(_m).a0;
        (len(fps) == Nat(0u));
    }) ? ({
        auto&& cases = prism_rtl::as<check_env::TyBody::BChoice>(_m).a0;
        prism_rtl::finished(rest_case_pat(c, cases, ty_path));
    })
        : prism_rtl::more(prism_rtl::rc(FieldsPat(lx, c, fps, rest, ty, mode, fresh, ty_path)));
    });
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto&& _m = prelude::get(lx.g.tags, qk);
        prism_rtl::is_some(_m) ? ({
        auto&& tg = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(TagPat(lx, tg, fps, rest, ty, mode, fresh)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(PatOut{.pa = Pa(Pa::PaWild{}), .conds = Array(std::vector{Cc(Cc::CcIf{refusal(prism_rtl::cat("a pattern of ", qk))})}), .binds = Array<std::tuple<Text, Bn>>{}})
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start RecordPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_record_pat(Lx lx, ast::SName n, Array<ast::FieldPat> fps, bool rest, check_types::Ty ty, Holding mode, Text fresh) {
    return prism_rtl::make_rc<RecordPat>(lx, n, fps, rest, ty, mode, fresh);
}


/// RestCasePat: fn CtorInfo, [((Text, [Ty]))], Text -> PatOut
PatOut rest_case_pat(const check_env::CtorInfo& c, const Array<std::tuple<Text, Array<check_types::Ty>>>& cases, const Text& ty_path) {
    auto is_newtype = (len(cases) == Nat(1u)) && (check_types::bare_name(c.name) == check_types::bare_name(c.owner));
    auto path_ = is_newtype
        ? ty_path
        : prism_rtl::cat(ty_path, "::", camel(check_types::bare_name(c.name)));
    return len(c->args) == Nat(0u)
        ? PatOut{.pa = Pa(Pa::PaUnit{path_}), .conds = Array<Cc>{}, .binds = Array<std::tuple<Text, Bn>>{}}
        : PatOut{.pa = Pa(Pa::PaCtor{path_, each(c->args, [&](const check_types::Ty& _p0) { return Pa(Pa::PaWild{}); })}), .conds = Array<Cc>{}, .binds = Array<std::tuple<Text, Bn>>{}};
}


/// FieldsPat: unbounded fn Lx, CtorInfo, [FieldPat], Bool, Ty, Holding, Text, Text -> PatOut
PatOut fields_pat(const Lx& lx, const check_env::CtorInfo& c, const Array<ast::FieldPat>& fps, const bool& rest, const check_types::Ty& ty, const Holding& mode, const Text& fresh, const Text& ty_path) {
    auto args = ({
        __label__ _done;
        prism_rtl::Slot<Array<check_types::Ty>> _v;
        auto&& _m = peel(ty);
        if (prism_rtl::is<check_types::Ty::TyCon>(_m)) {
            auto&& xs = prism_rtl::as<check_types::Ty::TyCon>(_m).a1;
            _v.set(xs);
            goto _done;
        }
        {
            _v.set(Array<check_types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto subs = run_to_end(each_job(check_errors::range0(len(fps)), ({
        auto fps_1 = fps;
        auto c_2 = c;
        auto lx_3 = lx;
        auto args_4 = args;
        auto mode_5 = mode;
        auto fresh_6 = fresh;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, PatOut>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto fps_1_7 = fps_1;
            auto c_2_7 = c_2;
            auto lx_3_7 = lx_3;
            auto args_4_7 = args_4;
            auto mode_5_7 = mode_5;
            auto fresh_6_7 = fresh_6;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto fp = or_(index(fps_1_7, i), dummy_field_pat());
                auto fname = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = fp.name;
                    if (prism_rtl::is_some(_m)) {
                        auto&& id = prism_rtl::some_of(_m);
                        _v.set(id.name);
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(or_(index(c_2_7.fields, i), Text::lit("")));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto fix = fold(check_errors::range0(len(c_2_7.fields)), i, [&](const Nat& found, const Nat& j) { return or_(index(c_2_7.fields, j), Text::lit("")) == fname ? j : found; });
                call_then(start_instantiated(or_(index(c_2_7->args, fix), check_types::Ty(check_types::Ty::TyErr{})), c_2_7.params, args_4_7), [=](check_types::Ty instantiated_114051) { return call_then(start_sub_pat(lx_3_7, c_2_7, fix, fp.pattern, instantiated_114051, mode_5_7, prism_rtl::cat(fresh_6_7, "_", i)), [=](PatOut sub_pat_114019) { return prism_rtl::finished(std::tuple{snake(fname), sub_pat_114019}); }); });
            });
            });
        }));
        });
    }));
    })));
    auto conds = fold(subs, Array<Cc>{}, [&](const Array<Cc>& acc, const std::tuple<Text, PatOut>& _p1) {
        auto&& o = std::get<1>(_p1);
        return append(acc, o.conds);
    });
    auto binds = fold(subs, Array<std::tuple<Text, Bn>>{}, [&](const Array<std::tuple<Text, Bn>>& acc, const std::tuple<Text, PatOut>& _p1) {
        auto&& o = std::get<1>(_p1);
        return append(acc, o.binds);
    });
    return PatOut{.pa = Pa(Pa::PaRecord{ty_path, each(subs, [&](const std::tuple<Text, PatOut>& _p0) {
        auto&& f = std::get<0>(_p0);
        auto&& o = std::get<1>(_p0);
        return std::tuple{f, o.pa};
    }), rest || (len(subs) < len(c.fields))}), .conds = conds, .binds = binds};
}


prism_rtl::Turn<PatOut> FieldsPat::cycle() const {
    const auto& lx = this->lx;
    const auto& c = this->c;
    const auto& fps = this->fps;
    const auto& rest = this->rest;
    const auto& ty = this->ty;
    const auto& mode = this->mode;
    const auto& fresh = this->fresh;
    const auto& ty_path = this->ty_path;
    auto args = ({
        __label__ _done;
        prism_rtl::Slot<Array<check_types::Ty>> _v;
        auto&& _m = peel(ty);
        if (prism_rtl::is<check_types::Ty::TyCon>(_m)) {
            auto&& xs = prism_rtl::as<check_types::Ty::TyCon>(_m).a1;
            _v.set(xs);
            goto _done;
        }
        {
            _v.set(Array<check_types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto c_1 = c;
    auto fps_2 = fps;
    auto fresh_3 = fresh;
    auto lx_4 = lx;
    auto mode_5 = mode;
    auto rest_6 = rest;
    auto ty_path_7 = ty_path;
    return call_value(each_job(check_errors::range0(len(fps_2)), ({
        auto fps_2_8 = fps_2;
        auto c_1_8 = c_1;
        auto lx_4_8 = lx_4;
        auto args_8 = args;
        auto mode_5_9 = mode_5;
        auto fresh_3_9 = fresh_3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, PatOut>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto fps_2_8_9 = fps_2_8;
            auto c_1_8_9 = c_1_8;
            auto lx_4_8_9 = lx_4_8;
            auto args_8_9 = args_8;
            auto mode_5_9_9 = mode_5_9;
            auto fresh_3_9_9 = fresh_3_9;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto fp = or_(index(fps_2_8_9, i), dummy_field_pat());
                auto fname = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = fp.name;
                    if (prism_rtl::is_some(_m)) {
                        auto&& id = prism_rtl::some_of(_m);
                        _v.set(id.name);
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(or_(index(c_1_8_9.fields, i), Text::lit("")));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto fix = fold(check_errors::range0(len(c_1_8_9.fields)), i, [&](const Nat& found, const Nat& j) { return or_(index(c_1_8_9.fields, j), Text::lit("")) == fname ? j : found; });
                call_then(start_instantiated(or_(index(c_1_8_9->args, fix), check_types::Ty(check_types::Ty::TyErr{})), c_1_8_9.params, args_8_9), [=](check_types::Ty instantiated_114051) { return call_then(start_sub_pat(lx_4_8_9, c_1_8_9, fix, fp.pattern, instantiated_114051, mode_5_9_9, prism_rtl::cat(fresh_3_9_9, "_", i)), [=](PatOut sub_pat_114019) { return prism_rtl::finished(std::tuple{snake(fname), sub_pat_114019}); }); });
            });
            });
        }));
        });
    }));
    })), [=](Array<std::tuple<Text, PatOut>> each_113666) {
        return ({
            auto subs = each_113666;
            auto conds = fold(subs, Array<Cc>{}, [&](const Array<Cc>& acc, const std::tuple<Text, PatOut>& _p1) {
                auto&& o = std::get<1>(_p1);
                return append(acc, o.conds);
            });
            auto binds = fold(subs, Array<std::tuple<Text, Bn>>{}, [&](const Array<std::tuple<Text, Bn>>& acc, const std::tuple<Text, PatOut>& _p1) {
                auto&& o = std::get<1>(_p1);
                return append(acc, o.binds);
            });
            (prism_rtl::finished(PatOut{.pa = Pa(Pa::PaRecord{ty_path_7, each(subs, [&](const std::tuple<Text, PatOut>& _p0) {
            auto&& f = std::get<0>(_p0);
            auto&& o = std::get<1>(_p0);
            return std::tuple{f, o.pa};
        }), rest_6 || (len(subs) < len(c_1.fields))}), .conds = conds, .binds = binds}));
        });
    });
}


/// `Start FieldsPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_fields_pat(Lx lx, check_env::CtorInfo c, Array<ast::FieldPat> fps, bool rest, check_types::Ty ty, Holding mode, Text fresh, Text ty_path) {
    return prism_rtl::make_rc<FieldsPat>(lx, c, fps, rest, ty, mode, fresh, ty_path);
}


/// let dummyFieldPat
ast::FieldPat dummy_field_pat() {
    return ast::FieldPat{.name = std::optional<ast::Ident>{}, .pattern = dummy_pat(), .span = ast::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// let dummyTagInfo
check_env::TagInfo dummy_tag_info() {
    return check_env::TagInfo{.name = Text::lit(""), .family = Text::lit(""), .kind = Text::lit(""), .out = check_types::Ty(check_types::Ty::TyErr{}), .qs = Array<Text>{}, .rqs = Array<Text>{}, .bounds = Array<std::tuple<Text, Text>>{}, .fields = Array<std::tuple<Text, check_types::Ty>>{}, .home = Text::lit(""), .file = Nat(0u), .span = ast::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// IsLive: fn Ty -> Bool
bool is_live(const check_types::Ty& t) {
    auto&& _m = peel(t);
    if (prism_rtl::is<check_types::Ty::TyElem>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// TagFieldName: fn FieldPat, [Text], Nat -> Text
Text tag_field_name(const ast::FieldPat& fp, const Array<Text>& names, const Nat& i) {
    auto&& _m = fp.name;
    if (prism_rtl::is_some(_m)) {
        auto&& id = prism_rtl::some_of(_m);
        return id.name;
    }
    if (prism_rtl::is_none(_m)) {
        auto&& _m = fp.pattern.kind;
        if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
            auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
            return check_types::has_text(names, check_env::sname_key(n))
                ? check_env::sname_key(n)
                : or_(index(names, i), Text::lit(""));
        }
        {
            return or_(index(names, i), Text::lit(""));
        }
    }
    prism_rtl::unreachable("no arm matched");
}


/// TagPat: unbounded fn Lx, TagInfo, [FieldPat], Bool, Ty, Holding, Text -> PatOut
PatOut tag_pat(const Lx& lx, const check_env::TagInfo& tg, const Array<ast::FieldPat>& fps, const bool& rest, const check_types::Ty& ty, const Holding& mode, const Text& fresh) {
    auto [variant, struct_path] = tag_paths(lx, tg);
    auto live = is_live(ty);
    auto names = each(tg.fields, [&](const std::tuple<Text, check_types::Ty>& _p0) {
        auto&& f = std::get<0>(_p0);
        return f;
    });
    auto sub_mode = live ? Holding(Holding::ByRef{}) : mode;
    auto parts = run_to_end(each_job(check_errors::range0(len(fps)), ({
        auto fps_1 = fps;
        auto names_2 = names;
        auto tg_3 = tg;
        auto live_4 = live;
        auto lx_5 = lx;
        auto variant_6 = variant;
        auto fresh_7 = fresh;
        auto sub_mode_8 = sub_mode;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<std::optional<Text>, PatOut>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto fps_1_9 = fps_1;
            auto names_2_9 = names_2;
            auto tg_3_9 = tg_3;
            auto live_4_9 = live_4;
            auto lx_5_9 = lx_5;
            auto variant_6_9 = variant_6;
            auto fresh_7_9 = fresh_7;
            auto sub_mode_8_9 = sub_mode_8;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto fp = or_(index(fps_1_9, i), dummy_field_pat());
                auto fname = tag_field_name(fp, names_2_9, i);
                auto ft = fold(tg_3_9.fields, check_types::Ty(check_types::Ty::TyErr{}), [&](const check_types::Ty& found, const std::tuple<Text, check_types::Ty>& _p1) {
                    auto&& f = std::get<0>(_p1);
                    auto&& t = std::get<1>(_p1);
                    return f == fname ? t : found;
                });
                ({
                auto&& _m = layer_of(ft);
                prism_rtl::is<Layer::LyEv>(_m) ? prism_rtl::finished(std::tuple{std::optional<Text>{}, PatOut{.pa = Pa(Pa::PaWild{}), .conds = Array(std::vector{Cc(Cc::CcIf{refusal(prism_rtl::cat("an event field in an element pattern (", tg_3_9.name, ".", fname, ")"))})}), .binds = Array<std::tuple<Text, Bn>>{}}})
                : prism_rtl::is<Layer::LyDyn>(_m) && ({
                live_4_9;
            }) ? call_then(start_live_field_pat(lx_5_9, fp.pattern, variant_6_9, fname, ft, fresh_7_9), [=](PatOut live_field_pat_116426) { return prism_rtl::finished(std::tuple{std::optional<Text>{}, live_field_pat_116426}); })
                : call_then(start_rust_pat(lx_5_9, fp.pattern, peel(ft), sub_mode_8_9, prism_rtl::cat(fresh_7_9, "_", i)), [=](PatOut rust_pat_116531) {
                return ({
                    auto o = rust_pat_116531;
                    (prism_rtl::finished(std::tuple{std::optional(snake(fname)), o}));
                });
            });
            });
            });
            });
        }));
        });
    }));
    })));
    auto field_pas = fold(parts, Array<std::tuple<Text, Pa>>{}, [&](const Array<std::tuple<Text, Pa>>& acc, const std::tuple<std::optional<Text>, PatOut>& _p1) {
        auto&& f_opt = std::get<0>(_p1);
        auto&& o = std::get<1>(_p1);
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, Pa>>> _v;
            if (prism_rtl::is_some(f_opt)) {
                auto&& f = prism_rtl::some_of(f_opt);
                _v.set(prelude::push(acc, std::tuple{f, o.pa}));
                goto _done;
            }
            if (prism_rtl::is_none(f_opt)) {
                _v.set(acc);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    auto conds = fold(parts, Array<Cc>{}, [&](const Array<Cc>& acc, const std::tuple<std::optional<Text>, PatOut>& _p1) {
        auto&& o = std::get<1>(_p1);
        return append(acc, o.conds);
    });
    auto binds = fold(parts, Array<std::tuple<Text, Bn>>{}, [&](const Array<std::tuple<Text, Bn>>& acc, const std::tuple<std::optional<Text>, PatOut>& _p1) {
        auto&& o = std::get<1>(_p1);
        return append(acc, o.binds);
    });
    auto level = Pa(Pa::PaCtor{variant, Array(std::vector{Pa(Pa::PaRecord{struct_path, field_pas, true})})});
    auto tagged = prelude::push(binds, std::tuple{Text::lit("#tag"), Bn(Bn::BnLocal{Ex(Ex::XPath{answer_variant(tg)}), Holding(Holding::Owned{}), OutTy(OutTy::OutUnit{})})});
    return live
        ? PatOut{.pa = Pa(Pa::PaBind{fresh}), .conds = append(Array(std::vector{Cc(Cc::CcLet{level, Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XVar{fresh})), Text::lit("identity")}))})})}), conds), .binds = tagged}
        : PatOut{.pa = level, .conds = conds, .binds = binds};
}


prism_rtl::Turn<PatOut> TagPat::cycle() const {
    const auto& lx = this->lx;
    const auto& tg = this->tg;
    const auto& fps = this->fps;
    const auto& rest = this->rest;
    const auto& ty = this->ty;
    const auto& mode = this->mode;
    const auto& fresh = this->fresh;
    auto [variant, struct_path] = tag_paths(lx, tg);
    auto live = is_live(ty);
    auto names = each(tg.fields, [&](const std::tuple<Text, check_types::Ty>& _p0) {
        auto&& f = std::get<0>(_p0);
        return f;
    });
    auto sub_mode = live ? Holding(Holding::ByRef{}) : mode;
    auto fps_1 = fps;
    auto fresh_2 = fresh;
    auto lx_3 = lx;
    auto tg_4 = tg;
    return call_value(each_job(check_errors::range0(len(fps_1)), ({
        auto fps_1_5 = fps_1;
        auto names_5 = names;
        auto tg_4_6 = tg_4;
        auto live_6 = live;
        auto lx_3_7 = lx_3;
        auto variant_7 = variant;
        auto fresh_2_8 = fresh_2;
        auto sub_mode_8 = sub_mode;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<std::optional<Text>, PatOut>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto fps_1_5_9 = fps_1_5;
            auto names_5_9 = names_5;
            auto tg_4_6_9 = tg_4_6;
            auto live_6_9 = live_6;
            auto lx_3_7_9 = lx_3_7;
            auto variant_7_9 = variant_7;
            auto fresh_2_8_9 = fresh_2_8;
            auto sub_mode_8_9 = sub_mode_8;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto fp = or_(index(fps_1_5_9, i), dummy_field_pat());
                auto fname = tag_field_name(fp, names_5_9, i);
                auto ft = fold(tg_4_6_9.fields, check_types::Ty(check_types::Ty::TyErr{}), [&](const check_types::Ty& found, const std::tuple<Text, check_types::Ty>& _p1) {
                    auto&& f = std::get<0>(_p1);
                    auto&& t = std::get<1>(_p1);
                    return f == fname ? t : found;
                });
                ({
                auto&& _m = layer_of(ft);
                prism_rtl::is<Layer::LyEv>(_m) ? prism_rtl::finished(std::tuple{std::optional<Text>{}, PatOut{.pa = Pa(Pa::PaWild{}), .conds = Array(std::vector{Cc(Cc::CcIf{refusal(prism_rtl::cat("an event field in an element pattern (", tg_4_6_9.name, ".", fname, ")"))})}), .binds = Array<std::tuple<Text, Bn>>{}}})
                : prism_rtl::is<Layer::LyDyn>(_m) && ({
                live_6_9;
            }) ? call_then(start_live_field_pat(lx_3_7_9, fp.pattern, variant_7_9, fname, ft, fresh_2_8_9), [=](PatOut live_field_pat_116426) { return prism_rtl::finished(std::tuple{std::optional<Text>{}, live_field_pat_116426}); })
                : call_then(start_rust_pat(lx_3_7_9, fp.pattern, peel(ft), sub_mode_8_9, prism_rtl::cat(fresh_2_8_9, "_", i)), [=](PatOut rust_pat_116531) {
                return ({
                    auto o = rust_pat_116531;
                    (prism_rtl::finished(std::tuple{std::optional(snake(fname)), o}));
                });
            });
            });
            });
            });
        }));
        });
    }));
    })), [=](Array<std::tuple<std::optional<Text>, PatOut>> each_116015) {
        return ({
            auto parts = each_116015;
            auto field_pas = fold(parts, Array<std::tuple<Text, Pa>>{}, [&](const Array<std::tuple<Text, Pa>>& acc, const std::tuple<std::optional<Text>, PatOut>& _p1) {
                auto&& f_opt = std::get<0>(_p1);
                auto&& o = std::get<1>(_p1);
                return ({
                    __label__ _done;
                    prism_rtl::Slot<Array<std::tuple<Text, Pa>>> _v;
                    if (prism_rtl::is_some(f_opt)) {
                        auto&& f = prism_rtl::some_of(f_opt);
                        _v.set(prelude::push(acc, std::tuple{f, o.pa}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(f_opt)) {
                        _v.set(acc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
            });
            auto conds = fold(parts, Array<Cc>{}, [&](const Array<Cc>& acc, const std::tuple<std::optional<Text>, PatOut>& _p1) {
                auto&& o = std::get<1>(_p1);
                return append(acc, o.conds);
            });
            auto binds = fold(parts, Array<std::tuple<Text, Bn>>{}, [&](const Array<std::tuple<Text, Bn>>& acc, const std::tuple<std::optional<Text>, PatOut>& _p1) {
                auto&& o = std::get<1>(_p1);
                return append(acc, o.binds);
            });
            auto level = Pa(Pa::PaCtor{variant, Array(std::vector{Pa(Pa::PaRecord{struct_path, field_pas, true})})});
            auto tagged = prelude::push(binds, std::tuple{Text::lit("#tag"), Bn(Bn::BnLocal{Ex(Ex::XPath{answer_variant(tg_4)}), Holding(Holding::Owned{}), OutTy(OutTy::OutUnit{})})});
            live
            ? prism_rtl::finished(PatOut{.pa = Pa(Pa::PaBind{fresh_2}), .conds = append(Array(std::vector{Cc(Cc::CcLet{level, Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XVar{fresh_2})), Text::lit("identity")}))})})}), conds), .binds = tagged})
            : prism_rtl::finished(PatOut{.pa = level, .conds = conds, .binds = binds});
        });
    });
}


/// `Start TagPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_tag_pat(Lx lx, check_env::TagInfo tg, Array<ast::FieldPat> fps, bool rest, check_types::Ty ty, Holding mode, Text fresh) {
    return prism_rtl::make_rc<TagPat>(lx, tg, fps, rest, ty, mode, fresh);
}


/// LiveFieldPat: unbounded fn Lx, Pattern, Text, Text, Ty, Text -> PatOut
PatOut live_field_pat(const Lx& lx, const ast::Pattern_& p_, const Text& variant, const Text& fname, const check_types::Ty& ft, const Text& fresh) {
    auto&& _m = p_.kind;
    if (prism_rtl::is<ast::PatternKind::PIgnore>(_m)) {
        return pat_only(Pa(Pa::PaWild{}));
    }
    if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
        auto rs = lx.in_node
            ? live_projection(fresh, variant, fname, out_ty_of(lx, peel(ft)))
            : refusal(prism_rtl::cat("a live element's `$` field (", fname, ") in a plain function, which has no read point (gap LE)"));
        return PatOut{.pa = Pa(Pa::PaWild{}), .conds = Array<Cc>{}, .binds = Array(std::vector{std::tuple{check_env::sname_key(n), Bn(Bn::BnLocal{rs, Holding(Holding::Owned{}), OutTy(OutTy::OutDyn{prism_rtl::rc(out_ty_of(lx, peel(ft)))})})}})};
    }
    if (prism_rtl::is<ast::PatternKind::PGroup>(_m)) {
        auto&& q = prism_rtl::as<ast::PatternKind::PGroup>(_m).a0;
        return live_field_pat(lx, q, variant, fname, ft, fresh);
    }
    {
        return PatOut{.pa = Pa(Pa::PaWild{}), .conds = Array(std::vector{Cc(Cc::CcIf{refusal(prism_rtl::cat("a pattern inside a live element's `$` field (", fname, ")"))})}), .binds = Array<std::tuple<Text, Bn>>{}};
    }
}


prism_rtl::Turn<PatOut> LiveFieldPat::cycle() const {
    const auto& lx = this->lx;
    const auto& p_ = this->p_;
    const auto& variant = this->variant;
    const auto& fname = this->fname;
    const auto& ft = this->ft;
    const auto& fresh = this->fresh;
    return ({
        auto&& _m = p_.kind;
        prism_rtl::is<ast::PatternKind::PIgnore>(_m) ? prism_rtl::finished(pat_only(Pa(Pa::PaWild{})))
        : prism_rtl::is<ast::PatternKind::PName>(_m) ? ({
        auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
        ({
        auto rs = lx.in_node
            ? live_projection(fresh, variant, fname, out_ty_of(lx, peel(ft)))
            : refusal(prism_rtl::cat("a live element's `$` field (", fname, ") in a plain function, which has no read point (gap LE)"));
        auto ft_1 = ft;
        auto lx_2 = lx;
        auto n_3 = n;
        call_then(start_out_ty_of(lx_2, peel(ft_1)), [=](OutTy out_ty_of_118143) { return prism_rtl::finished(PatOut{.pa = Pa(Pa::PaWild{}), .conds = Array<Cc>{}, .binds = Array(std::vector{std::tuple{check_env::sname_key(n_3), Bn(Bn::BnLocal{rs, Holding(Holding::Owned{}), OutTy(OutTy::OutDyn{prism_rtl::rc(out_ty_of_118143)})})}})}); });
    });
    })
        : prism_rtl::is<ast::PatternKind::PGroup>(_m) ? ({
        auto&& q = prism_rtl::as<ast::PatternKind::PGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(LiveFieldPat(lx, q, variant, fname, ft, fresh)));
    })
        : prism_rtl::finished(PatOut{.pa = Pa(Pa::PaWild{}), .conds = Array(std::vector{Cc(Cc::CcIf{refusal(prism_rtl::cat("a pattern inside a live element's `$` field (", fname, ")"))})}), .binds = Array<std::tuple<Text, Bn>>{}});
    });
}


/// `Start LiveFieldPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_live_field_pat(Lx lx, ast::Pattern_ p_, Text variant, Text fname, check_types::Ty ft, Text fresh) {
    return prism_rtl::make_rc<LiveFieldPat>(lx, p_, variant, fname, ft, fresh);
}


/// LiveProjection: fn Text, Text, Text, OutTy -> Ex
Ex live_projection(const Text& fresh, const Text& variant, const Text& fname, const OutTy& ft) {
    auto arm = XArm{.pat = Pa(Pa::PaCtor{variant, Array(std::vector{Pa(Pa::PaBind{Text::lit("x")})})}), .conds = Array<Cc>{}, .body = Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XVar{Text::lit("x")})), snake(fname)}))})};
    auto other = XArm{.pat = Pa(Pa::PaWild{}), .conds = Array<Cc>{}, .body = Ex(Ex::XUnreachable{})};
    return Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XVar{fresh})), Text::lit("level")})), Text::lit("map"), Array(std::vector{Ex(Ex::XClosure{true, Array(std::vector{Pa(Pa::PaBind{Text::lit("l")})}), prism_rtl::rc(Ex(Ex::XMatch{prism_rtl::rc(Ex(Ex::XVar{Text::lit("l")})), Array(std::vector{arm, other}), false, ft}))})})});
}


/// FamilyPat: unbounded fn Lx, QualName, Ty, Text -> PatOut
PatOut family_pat(const Lx& lx, const ast::QualName& q, const check_types::Ty& ty, const Text& fresh) {
    auto fam = check_env::dotted(filter(q->path_, [&](const Text& x) { return x != Text::lit("*"); }));
    auto kind = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = peel(ty);
        if (prism_rtl::is<check_types::Ty::TyElem>(_m)) {
            _v.set(Text::lit("Element"));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyElemAny>(_m)) {
            _v.set(Text::lit("Element"));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyCon>(_m)) {
            auto&& k = prism_rtl::as<check_types::Ty::TyCon>(_m).a0;
            _v.set(k);
            goto _done;
        }
        {
            _v.set(Text::lit(""));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto tags = filter(kind_tags(lx, kind, keys(lx.rs_mods)), [&](const check_env::TagInfo& tg) { return tg.family == fam; });
    auto place = is_live(ty)
        ? Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XVar{fresh})), Text::lit("identity")})
        : Ex(Ex::XVar{fresh});
    return PatOut{.pa = Pa(Pa::PaBind{fresh}), .conds = Array(std::vector{Cc(Cc::CcIf{Ex(Ex::XIsCase{prism_rtl::rc(place), each(tags, [&](const check_env::TagInfo& tg) { return variant_of(lx, tg); })})})}), .binds = Array<std::tuple<Text, Bn>>{}};
}


prism_rtl::Turn<PatOut> FamilyPat::cycle() const {
    const auto& lx = this->lx;
    const auto& q = this->q;
    const auto& ty = this->ty;
    const auto& fresh = this->fresh;
    auto fam = check_env::dotted(filter(q->path_, [&](const Text& x) { return x != Text::lit("*"); }));
    auto kind = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = peel(ty);
        if (prism_rtl::is<check_types::Ty::TyElem>(_m)) {
            _v.set(Text::lit("Element"));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyElemAny>(_m)) {
            _v.set(Text::lit("Element"));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyCon>(_m)) {
            auto&& k = prism_rtl::as<check_types::Ty::TyCon>(_m).a0;
            _v.set(k);
            goto _done;
        }
        {
            _v.set(Text::lit(""));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto tags = filter(kind_tags(lx, kind, keys(lx.rs_mods)), [&](const check_env::TagInfo& tg) { return tg.family == fam; });
    auto place = is_live(ty)
        ? Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XVar{fresh})), Text::lit("identity")})
        : Ex(Ex::XVar{fresh});
    return prism_rtl::finished(PatOut{.pa = Pa(Pa::PaBind{fresh}), .conds = Array(std::vector{Cc(Cc::CcIf{Ex(Ex::XIsCase{prism_rtl::rc(place), each(tags, [&](const check_env::TagInfo& tg) { return variant_of(lx, tg); })})})}), .binds = Array<std::tuple<Text, Bn>>{}});
}


/// `Start FamilyPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_family_pat(Lx lx, ast::QualName q, check_types::Ty ty, Text fresh) {
    return prism_rtl::make_rc<FamilyPat>(lx, q, ty, fresh);
}


/// ErrorPat: unbounded fn Lx, [FieldPat], Ty, Holding, Text -> PatOut
PatOut error_pat(const Lx& lx, const Array<ast::FieldPat>& fps, const check_types::Ty& ty, const Holding& mode, const Text& fresh) {
    auto e = local_place(Ex(Ex::XVar{fresh}), mode, OutTy(OutTy::OutError{}));
    auto parts = each(fps, [&](const ast::FieldPat& fp) {
        return ({
            auto fname = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = fp.name;
                if (prism_rtl::is_some(_m)) {
                    auto&& id = prism_rtl::some_of(_m);
                    _v.set(id.name);
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Text::lit(""));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Array<Cc>, Array<std::tuple<Text, Bn>>>> _v;
            {
                auto&& m119758_0 = fname;
                if (m119758_0 == Text::lit("kind")) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<Array<Cc>, Array<std::tuple<Text, Bn>>>> _v;
                        auto&& _m = fp.pattern.kind;
                        if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
                            auto&& k = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
                            _v.set(({
                                auto&& _kq_opt = check_env::resolve_value(lx.g, lx.home, k);
                                auto&& kq_opt = std::get<0>(_kq_opt);
                                ({
                                __label__ _done;
                                prism_rtl::Slot<std::tuple<Array<Cc>, Array<std::tuple<Text, Bn>>>> _v;
                                if (prism_rtl::is_some(kq_opt)) {
                                    auto&& kq = prism_rtl::some_of(kq_opt);
                                    _v.set(check_env::has_key(lx.g.tags, kq)
                                        ? std::tuple{Array(std::vector{Cc(Cc::CcIf{Ex(Ex::XBin{Text::lit("=="), prism_rtl::rc(Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XDeref{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XVar{fresh})), Text::lit("kind")}))}))})), prism_rtl::rc(Ex(Ex::XStr{kq}))})})}), Array<std::tuple<Text, Bn>>{}}
                                        : std::tuple{Array<Cc>{}, Array(std::vector{std::tuple{check_env::sname_key(k), Bn(Bn::BnLocal{Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XVar{fresh})), Text::lit("kind")}), Holding(Holding::Owned{}), OutTy(OutTy::OutText{})})}})});
                                    goto _done;
                                }
                                if (prism_rtl::is_none(kq_opt)) {
                                    _v.set(std::tuple{Array<Cc>{}, Array(std::vector{std::tuple{check_env::sname_key(k), Bn(Bn::BnLocal{Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XVar{fresh})), Text::lit("kind")}), Holding(Holding::Owned{}), OutTy(OutTy::OutText{})})}})});
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            });
                            }));
                            goto _done;
                        }
                        {
                            _v.set(std::tuple{Array<Cc>{}, Array<std::tuple<Text, Bn>>{}});
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
            }
            {
                auto&& m119758_1 = fname;
                if (m119758_1 == Text::lit("message")) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<Array<Cc>, Array<std::tuple<Text, Bn>>>> _v;
                        auto&& _m = fp.pattern.kind;
                        if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
                            auto&& m = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
                            _v.set(std::tuple{Array<Cc>{}, Array(std::vector{std::tuple{check_env::sname_key(m), Bn(Bn::BnLocal{Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XVar{fresh})), Text::lit("message")}), Holding(Holding::Owned{}), OutTy(OutTy::OutText{})})}})});
                            goto _done;
                        }
                        {
                            _v.set(std::tuple{Array<Cc>{}, Array<std::tuple<Text, Bn>>{}});
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
            }
            {
                _v.set(std::tuple{Array<Cc>{}, Array<std::tuple<Text, Bn>>{}});
                goto _done;
            }
        _done:
            _v.take();
        });
        });
    });
    auto wrapped = ({
        __label__ _done;
        prism_rtl::Slot<Pa> _v;
        auto&& _m = peel(ty);
        if (prism_rtl::is<check_types::Ty::TySig>(_m)) {
            auto&& m120595_0_0 = prism_rtl::as<check_types::Ty::TySig>(_m).a0;
            if (m120595_0_0 == Text::lit("~")) {
                _v.set(Pa(Pa::PaCtor{Text::lit("Err"), Array(std::vector{Pa(Pa::PaBind{fresh})})}));
                goto _done;
            }
        }
        {
            _v.set(Pa(Pa::PaBind{fresh}));
            goto _done;
        }
    _done:
        _v.take();
    });
    return PatOut{.pa = wrapped, .conds = fold(parts, Array<Cc>{}, [&](const Array<Cc>& acc, const std::tuple<Array<Cc>, Array<std::tuple<Text, Bn>>>& _p1) {
        auto&& cs = std::get<0>(_p1);
        return append(acc, cs);
    }), .binds = fold(parts, Array<std::tuple<Text, Bn>>{}, [&](const Array<std::tuple<Text, Bn>>& acc, const std::tuple<Array<Cc>, Array<std::tuple<Text, Bn>>>& _p1) {
        auto&& bs = std::get<1>(_p1);
        return append(acc, bs);
    })};
}


prism_rtl::Turn<PatOut> ErrorPat::cycle() const {
    const auto& lx = this->lx;
    const auto& fps = this->fps;
    const auto& ty = this->ty;
    const auto& mode = this->mode;
    const auto& fresh = this->fresh;
    auto e = local_place(Ex(Ex::XVar{fresh}), mode, OutTy(OutTy::OutError{}));
    auto parts = each(fps, [&](const ast::FieldPat& fp) {
        return ({
            auto fname = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = fp.name;
                if (prism_rtl::is_some(_m)) {
                    auto&& id = prism_rtl::some_of(_m);
                    _v.set(id.name);
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Text::lit(""));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Array<Cc>, Array<std::tuple<Text, Bn>>>> _v;
            {
                auto&& m119758_0 = fname;
                if (m119758_0 == Text::lit("kind")) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<Array<Cc>, Array<std::tuple<Text, Bn>>>> _v;
                        auto&& _m = fp.pattern.kind;
                        if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
                            auto&& k = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
                            _v.set(({
                                auto&& _kq_opt = check_env::resolve_value(lx.g, lx.home, k);
                                auto&& kq_opt = std::get<0>(_kq_opt);
                                ({
                                __label__ _done;
                                prism_rtl::Slot<std::tuple<Array<Cc>, Array<std::tuple<Text, Bn>>>> _v;
                                if (prism_rtl::is_some(kq_opt)) {
                                    auto&& kq = prism_rtl::some_of(kq_opt);
                                    _v.set(check_env::has_key(lx.g.tags, kq)
                                        ? std::tuple{Array(std::vector{Cc(Cc::CcIf{Ex(Ex::XBin{Text::lit("=="), prism_rtl::rc(Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XDeref{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XVar{fresh})), Text::lit("kind")}))}))})), prism_rtl::rc(Ex(Ex::XStr{kq}))})})}), Array<std::tuple<Text, Bn>>{}}
                                        : std::tuple{Array<Cc>{}, Array(std::vector{std::tuple{check_env::sname_key(k), Bn(Bn::BnLocal{Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XVar{fresh})), Text::lit("kind")}), Holding(Holding::Owned{}), OutTy(OutTy::OutText{})})}})});
                                    goto _done;
                                }
                                if (prism_rtl::is_none(kq_opt)) {
                                    _v.set(std::tuple{Array<Cc>{}, Array(std::vector{std::tuple{check_env::sname_key(k), Bn(Bn::BnLocal{Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XVar{fresh})), Text::lit("kind")}), Holding(Holding::Owned{}), OutTy(OutTy::OutText{})})}})});
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            });
                            }));
                            goto _done;
                        }
                        {
                            _v.set(std::tuple{Array<Cc>{}, Array<std::tuple<Text, Bn>>{}});
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
            }
            {
                auto&& m119758_1 = fname;
                if (m119758_1 == Text::lit("message")) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<Array<Cc>, Array<std::tuple<Text, Bn>>>> _v;
                        auto&& _m = fp.pattern.kind;
                        if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
                            auto&& m = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
                            _v.set(std::tuple{Array<Cc>{}, Array(std::vector{std::tuple{check_env::sname_key(m), Bn(Bn::BnLocal{Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XVar{fresh})), Text::lit("message")}), Holding(Holding::Owned{}), OutTy(OutTy::OutText{})})}})});
                            goto _done;
                        }
                        {
                            _v.set(std::tuple{Array<Cc>{}, Array<std::tuple<Text, Bn>>{}});
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
            }
            {
                _v.set(std::tuple{Array<Cc>{}, Array<std::tuple<Text, Bn>>{}});
                goto _done;
            }
        _done:
            _v.take();
        });
        });
    });
    auto wrapped = ({
        __label__ _done;
        prism_rtl::Slot<Pa> _v;
        auto&& _m = peel(ty);
        if (prism_rtl::is<check_types::Ty::TySig>(_m)) {
            auto&& m120595_0_0 = prism_rtl::as<check_types::Ty::TySig>(_m).a0;
            if (m120595_0_0 == Text::lit("~")) {
                _v.set(Pa(Pa::PaCtor{Text::lit("Err"), Array(std::vector{Pa(Pa::PaBind{fresh})})}));
                goto _done;
            }
        }
        {
            _v.set(Pa(Pa::PaBind{fresh}));
            goto _done;
        }
    _done:
        _v.take();
    });
    return prism_rtl::finished(PatOut{.pa = wrapped, .conds = fold(parts, Array<Cc>{}, [&](const Array<Cc>& acc, const std::tuple<Array<Cc>, Array<std::tuple<Text, Bn>>>& _p1) {
        auto&& cs = std::get<0>(_p1);
        return append(acc, cs);
    }), .binds = fold(parts, Array<std::tuple<Text, Bn>>{}, [&](const Array<std::tuple<Text, Bn>>& acc, const std::tuple<Array<Cc>, Array<std::tuple<Text, Bn>>>& _p1) {
        auto&& bs = std::get<1>(_p1);
        return append(acc, bs);
    })});
}


/// `Start ErrorPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_error_pat(Lx lx, Array<ast::FieldPat> fps, check_types::Ty ty, Holding mode, Text fresh) {
    return prism_rtl::make_rc<ErrorPat>(lx, fps, ty, mode, fresh);
}


/// ArrayPat: unbounded fn Lx, [Pattern], Ty, Holding, Text -> PatOut
PatOut array_pat(const Lx& lx, const Array<ast::Pattern_>& ps, const check_types::Ty& ty, const Holding& mode, const Text& fresh) {
    auto et = ({
        __label__ _done;
        prism_rtl::Slot<check_types::Ty> _v;
        auto&& _m = peel(ty);
        if (prism_rtl::is<check_types::Ty::TyArray>(_m)) {
            auto&& x = prism_rtl::as<check_types::Ty::TyArray>(_m).a0;
            _v.set(x);
            goto _done;
        }
        {
            _v.set(check_types::Ty(check_types::Ty::TyErr{}));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto arr = local_place(Ex(Ex::XVar{fresh}), mode, out_ty_of(lx, peel(ty)));
    auto len_cond = Cc(Cc::CcIf{Ex(Ex::XBin{Text::lit("=="), prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(ref_(arr)), Text::lit("len"), Array<Ex>{}})), prism_rtl::rc(Ex(Ex::XIndex{len(ps)}))})});
    auto subs = run_to_end(each_job(check_errors::range0(len(ps)), ({
        auto lx_1 = lx;
        auto ps_2 = ps;
        auto et_3 = et;
        auto fresh_4 = fresh;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Nat, PatOut>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto lx_1_5 = lx_1;
            auto ps_2_5 = ps_2;
            auto et_3_5 = et_3;
            auto fresh_4_5 = fresh_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                call_then(start_rust_pat(lx_1_5, or_(index(ps_2_5, i), dummy_pat()), et_3_5, Holding(Holding::Owned{}), prism_rtl::cat(fresh_4_5, "_", i)), [=](PatOut rust_pat_121292) { return prism_rtl::finished(std::tuple{i, rust_pat_121292}); });
            });
        }));
        });
    }));
    })));
    auto conds = fold(subs, Array(std::vector{len_cond}), [&](const Array<Cc>& acc, const std::tuple<Nat, PatOut>& _p1) {
        auto&& i = std::get<0>(_p1);
        auto&& o = std::get<1>(_p1);
        return append(prelude::push(acc, Cc(Cc::CcLet{Pa(Pa::PaCtor{Text::lit("Some"), Array(std::vector{o.pa})}), Ex(Ex::XCall{Text::lit("index"), Array(std::vector{ref_(arr), Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XNat{prism_rtl::cat(i)}))})})})})), o.conds);
    });
    auto binds = fold(subs, Array<std::tuple<Text, Bn>>{}, [&](const Array<std::tuple<Text, Bn>>& acc, const std::tuple<Nat, PatOut>& _p1) {
        auto&& o = std::get<1>(_p1);
        return append(acc, o.binds);
    });
    return PatOut{.pa = Pa(Pa::PaBind{fresh}), .conds = conds, .binds = binds};
}


prism_rtl::Turn<PatOut> ArrayPat::cycle() const {
    const auto& lx = this->lx;
    const auto& ps = this->ps;
    const auto& ty = this->ty;
    const auto& mode = this->mode;
    const auto& fresh = this->fresh;
    auto et = ({
        __label__ _done;
        prism_rtl::Slot<check_types::Ty> _v;
        auto&& _m = peel(ty);
        if (prism_rtl::is<check_types::Ty::TyArray>(_m)) {
            auto&& x = prism_rtl::as<check_types::Ty::TyArray>(_m).a0;
            _v.set(x);
            goto _done;
        }
        {
            _v.set(check_types::Ty(check_types::Ty::TyErr{}));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto fresh_1 = fresh;
    auto lx_2 = lx;
    auto mode_3 = mode;
    auto ps_4 = ps;
    auto ty_5 = ty;
    return call_then(start_out_ty_of(lx_2, peel(ty_5)), [=](OutTy out_ty_of_121131) {
        return ({
            auto arr = local_place(Ex(Ex::XVar{fresh_1}), mode_3, out_ty_of_121131);
            auto len_cond = Cc(Cc::CcIf{Ex(Ex::XBin{Text::lit("=="), prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(ref_(arr)), Text::lit("len"), Array<Ex>{}})), prism_rtl::rc(Ex(Ex::XIndex{len(ps_4)}))})});
            call_value(each_job(check_errors::range0(len(ps_4)), ({
            auto lx_2_6 = lx_2;
            auto ps_4_6 = ps_4;
            auto et_6 = et;
            auto fresh_1_7 = fresh_1;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Nat, PatOut>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto lx_2_6_7 = lx_2_6;
                auto ps_4_6_7 = ps_4_6;
                auto et_6_7 = et_6;
                auto fresh_1_7_7 = fresh_1_7;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    call_then(start_rust_pat(lx_2_6_7, or_(index(ps_4_6_7, i), dummy_pat()), et_6_7, Holding(Holding::Owned{}), prism_rtl::cat(fresh_1_7_7, "_", i)), [=](PatOut rust_pat_121292) { return prism_rtl::finished(std::tuple{i, rust_pat_121292}); });
                });
            }));
            });
        }));
        })), [=](Array<std::tuple<Nat, PatOut>> each_121257) {
            return ({
                auto subs = each_121257;
                auto conds = fold(subs, Array(std::vector{len_cond}), [&](const Array<Cc>& acc, const std::tuple<Nat, PatOut>& _p1) {
                    auto&& i = std::get<0>(_p1);
                    auto&& o = std::get<1>(_p1);
                    return append(prelude::push(acc, Cc(Cc::CcLet{Pa(Pa::PaCtor{Text::lit("Some"), Array(std::vector{o.pa})}), Ex(Ex::XCall{Text::lit("index"), Array(std::vector{ref_(arr), Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XNat{prism_rtl::cat(i)}))})})})})), o.conds);
                });
                auto binds = fold(subs, Array<std::tuple<Text, Bn>>{}, [&](const Array<std::tuple<Text, Bn>>& acc, const std::tuple<Nat, PatOut>& _p1) {
                    auto&& o = std::get<1>(_p1);
                    return append(acc, o.binds);
                });
                (prism_rtl::finished(PatOut{.pa = Pa(Pa::PaBind{fresh_1}), .conds = conds, .binds = binds}));
            });
        });
        });
    });
}


/// `Start ArrayPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_array_pat(Lx lx, Array<ast::Pattern_> ps, check_types::Ty ty, Holding mode, Text fresh) {
    return prism_rtl::make_rc<ArrayPat>(lx, ps, ty, mode, fresh);
}


/// TemplateValue: unbounded fn Lx, Env, Template -> Vl
Vl template_value(const Lx& lx, const Env& env, const ast::Template& tp) {
    auto start = Array(std::vector{Do(Do::DoLet{Pa(Pa::PaMut{Text::lit("out")}), Ex(Ex::XCall{Text::lit("String::new"), Array<Ex>{}})})});
    auto dos = run_to_end(fold_job(tp.parts, start, ({
        auto lx_1 = lx;
        auto env_2 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(std::tuple<Array<Do>, ast::TemplatePart>)>>(prism_rtl::rc([=](std::tuple<Array<Do>, ast::TemplatePart> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_3 = lx_1;
            auto env_2_3 = env_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto part = p1;
                call_then(start_template_part_dos(lx_1_3, env_2_3, part), [=](Array<Do> template_part_dos_122298) { return prism_rtl::finished(append(acc, template_part_dos_122298)); });
            });
        }));
        });
    })));
    })));
    return Vl(Vl::VlOwned{Ex(Ex::XBlock{dos, prism_rtl::rc(Ex(Ex::XCall{Text::lit("Text::from"), Array(std::vector{Ex(Ex::XVar{Text::lit("out")})})}))}), OutTy(OutTy::OutText{})});
}


prism_rtl::Turn<Vl> TemplateValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& tp = this->tp;
    auto start = Array(std::vector{Do(Do::DoLet{Pa(Pa::PaMut{Text::lit("out")}), Ex(Ex::XCall{Text::lit("String::new"), Array<Ex>{}})})});
    auto env_1 = env;
    auto lx_2 = lx;
    auto tp_3 = tp;
    return call_value(fold_job(tp_3.parts, start, ({
        auto lx_2_4 = lx_2;
        auto env_1_4 = env_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(std::tuple<Array<Do>, ast::TemplatePart>)>>(prism_rtl::rc([=](std::tuple<Array<Do>, ast::TemplatePart> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_2_4_4 = lx_2_4;
            auto env_1_4_4 = env_1_4;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto part = p1;
                call_then(start_template_part_dos(lx_2_4_4, env_1_4_4, part), [=](Array<Do> template_part_dos_122298) { return prism_rtl::finished(append(acc, template_part_dos_122298)); });
            });
        }));
        });
    })));
    })), [=](Array<Do> fold_122250) {
        return ({
            auto dos = fold_122250;
            (prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XBlock{dos, prism_rtl::rc(Ex(Ex::XCall{Text::lit("Text::from"), Array(std::vector{Ex(Ex::XVar{Text::lit("out")})})}))}), OutTy(OutTy::OutText{})})));
        });
    });
}


/// `Start TemplateValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_template_value(Lx lx, Env env, ast::Template tp) {
    return prism_rtl::make_rc<TemplateValue>(lx, env, tp);
}


/// TemplatePartDos: unbounded fn Lx, Env, TemplatePart -> [Do]
Array<Do> template_part_dos(const Lx& lx, const Env& env, const ast::TemplatePart& part) {
    if (prism_rtl::is<ast::TemplatePart::TpText>(part)) {
        auto&& t = prism_rtl::as<ast::TemplatePart::TpText>(part).a0;
        return Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text::lit("out")})), Text::lit("push_str"), Array(std::vector{Ex(Ex::XStr{t})})})})});
    }
    if (prism_rtl::is<ast::TemplatePart::TpPlaceholder>(part)) {
        auto&& x = prism_rtl::as<ast::TemplatePart::TpPlaceholder>(part).a0;
        auto&& col_opt = prism_rtl::as<ast::TemplatePart::TpPlaceholder>(part).a1;
        auto v_ = value_of(lx, env, x);
        auto column = ({
            __label__ _done;
            prism_rtl::Slot<Ex> _v;
            if (prism_rtl::is_some(col_opt)) {
                auto&& c = prism_rtl::some_of(col_opt);
                _v.set(Ex(Ex::XCtor{Text::lit("Some"), Array(std::vector{Ex(Ex::XIndex{c})})}));
                goto _done;
            }
            if (prism_rtl::is_none(col_opt)) {
                _v.set(Ex(Ex::XNone{}));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return Array(std::vector{Do(Do::DoExpr{Ex(Ex::XCall{Text::lit("place"), Array(std::vector{Ex(Ex::XRefMut{prism_rtl::rc(Ex(Ex::XVar{Text::lit("out")}))}), shown_text(v_), column})})})});
    }
    if (prism_rtl::is<ast::TemplatePart::TpBlock>(part)) {
        auto&& b = prism_rtl::as<ast::TemplatePart::TpBlock>(part).a0;
        auto v_ = block_value(lx, env, b);
        return value_ty(v_) == OutTy(OutTy::OutUnit{})
            ? Array(std::vector{Do(Do::DoExpr{own(v_)})})
            : Array(std::vector{Do(Do::DoExpr{Ex(Ex::XCall{Text::lit("place"), Array(std::vector{Ex(Ex::XRefMut{prism_rtl::rc(Ex(Ex::XVar{Text::lit("out")}))}), shown_text(v_), Ex(Ex::XNone{})})})})});
    }
    if (prism_rtl::is<ast::TemplatePart::TpCall>(part)) {
        auto&& n = prism_rtl::as<ast::TemplatePart::TpCall>(part).a0;
        auto&& args = prism_rtl::as<ast::TemplatePart::TpCall>(part).a1;
        auto&& parts_opt = prism_rtl::as<ast::TemplatePart::TpCall>(part).a2;
        auto plain = ast::SName{.sigils = lexer::after_first(n.sigils), .path_ = n->path_, .span = n.span};
        auto&& _qk_opt = check_env::resolve_value(lx.g, lx.home, n);
        auto&& qk_opt = std::get<0>(_qk_opt);
        auto&& _qk2_opt = check_env::resolve_value(lx.g, lx.home, plain);
        auto&& qk2_opt = std::get<0>(_qk2_opt);
        auto callee = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& q = prism_rtl::some_of(qk_opt);
                _v.set(value_path(lx, q));
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    if (prism_rtl::is_some(qk2_opt)) {
                        auto&& q = prism_rtl::some_of(qk2_opt);
                        _v.set(value_path(lx, q));
                        goto _done;
                    }
                    if (prism_rtl::is_none(qk2_opt)) {
                        _v.set(snake(check_env::sname_key(n)));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto body = ({
            __label__ _done;
            prism_rtl::Slot<Array<Ex>> _v;
            if (prism_rtl::is_some(parts_opt)) {
                auto&& ps = prism_rtl::some_of(parts_opt);
                _v.set(({
                    auto inner = run_to_end(fold_job(ps, Array(std::vector{Do(Do::DoLet{Pa(Pa::PaMut{Text::lit("out")}), Ex(Ex::XCall{Text::lit("String::new"), Array<Ex>{}})})}), ({
                        auto lx_1 = lx;
                        auto env_2 = env;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(std::tuple<Array<Do>, ast::TemplatePart>)>>(prism_rtl::rc([=](std::tuple<Array<Do>, ast::TemplatePart> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto lx_1_3 = lx_1;
                            auto env_2_3 = env_2;
                            entered(once_job([=]() {
                            return ({
                                auto acc = p0;
                                auto p_ = p1;
                                call_then(start_template_part_dos(lx_1_3, env_2_3, p_), [=](Array<Do> template_part_dos_123608) { return prism_rtl::finished(append(acc, template_part_dos_123608)); });
                            });
                        }));
                        });
                    })));
                    })));
                    (Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XBlock{inner, prism_rtl::rc(Ex(Ex::XCall{Text::lit("Text::from"), Array(std::vector{Ex(Ex::XVar{Text::lit("out")})})}))}))})}));
                }));
                goto _done;
            }
            if (prism_rtl::is_none(parts_opt)) {
                _v.set(Array<Ex>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto passed = ({
            __label__ _done;
            prism_rtl::Slot<Array<Ex>> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& q = prism_rtl::some_of(qk_opt);
                _v.set(template_args(lx, env, q, args, body));
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<Ex>> _v;
                    if (prism_rtl::is_some(qk2_opt)) {
                        auto&& q = prism_rtl::some_of(qk2_opt);
                        _v.set(template_args(lx, env, q, args, body));
                        goto _done;
                    }
                    if (prism_rtl::is_none(qk2_opt)) {
                        _v.set(append(run_to_end(each_job(args, ({
                            auto lx_1 = lx;
                            auto env_2 = env;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(ast::Arg)>>(prism_rtl::rc([=](ast::Arg p0) {
                            return ({
                                auto lx_1_3 = lx_1;
                                auto env_2_3 = env_2;
                                entered(once_job([=]() {
                                return ({
                                    auto a = p0;
                                    (prism_rtl::more(prism_rtl::rc(Argument(lx_1_3, env_2_3, a->value))));
                                });
                            }));
                            });
                        })));
                        }))), body));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto call = Ex(Ex::XCall{callee, passed});
        return Array(std::vector{Do(Do::DoExpr{Ex(Ex::XCall{Text::lit("place"), Array(std::vector{Ex(Ex::XRefMut{prism_rtl::rc(Ex(Ex::XVar{Text::lit("out")}))}), Ex(Ex::XRef{prism_rtl::rc(call)}), Ex(Ex::XNone{})})})})});
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Do>> TemplatePartDos::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& part = this->part;
    return ({
        prism_rtl::is<ast::TemplatePart::TpText>(part) ? ({
        auto&& t = prism_rtl::as<ast::TemplatePart::TpText>(part).a0;
        prism_rtl::finished(Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text::lit("out")})), Text::lit("push_str"), Array(std::vector{Ex(Ex::XStr{t})})})})}));
    })
        : prism_rtl::is<ast::TemplatePart::TpPlaceholder>(part) ? ({
        auto&& x = prism_rtl::as<ast::TemplatePart::TpPlaceholder>(part).a0;
        auto&& col_opt = prism_rtl::as<ast::TemplatePart::TpPlaceholder>(part).a1;
        ({
        auto col_opt_1 = col_opt;
        auto env_2 = env;
        auto lx_3 = lx;
        auto x_4 = x;
        call_then(start_value_of(lx_3, env_2, x_4), [=](Vl value_of_122628) {
        return ({
            auto v_ = value_of_122628;
            auto column = ({
                __label__ _done;
                prism_rtl::Slot<Ex> _v;
                if (prism_rtl::is_some(col_opt)) {
                    auto&& c = prism_rtl::some_of(col_opt);
                    _v.set(Ex(Ex::XCtor{Text::lit("Some"), Array(std::vector{Ex(Ex::XIndex{c})})}));
                    goto _done;
                }
                if (prism_rtl::is_none(col_opt)) {
                    _v.set(Ex(Ex::XNone{}));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (prism_rtl::finished(Array(std::vector{Do(Do::DoExpr{Ex(Ex::XCall{Text::lit("place"), Array(std::vector{Ex(Ex::XRefMut{prism_rtl::rc(Ex(Ex::XVar{Text::lit("out")}))}), shown_text(v_), column})})})})));
        });
    });
    });
    })
        : prism_rtl::is<ast::TemplatePart::TpBlock>(part) ? ({
        auto&& b = prism_rtl::as<ast::TemplatePart::TpBlock>(part).a0;
        ({
        auto b_1 = b;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(start_block_value(lx_3, env_2, b_1), [=](Vl block_value_122862) {
        return ({
            auto v_ = block_value_122862;
            value_ty(v_) == OutTy(OutTy::OutUnit{})
            ? prism_rtl::finished(Array(std::vector{Do(Do::DoExpr{own(v_)})}))
            : prism_rtl::finished(Array(std::vector{Do(Do::DoExpr{Ex(Ex::XCall{Text::lit("place"), Array(std::vector{Ex(Ex::XRefMut{prism_rtl::rc(Ex(Ex::XVar{Text::lit("out")}))}), shown_text(v_), Ex(Ex::XNone{})})})})}));
        });
    });
    });
    })
        : prism_rtl::is<ast::TemplatePart::TpCall>(part) ? ({
        auto&& n = prism_rtl::as<ast::TemplatePart::TpCall>(part).a0;
        auto&& args = prism_rtl::as<ast::TemplatePart::TpCall>(part).a1;
        auto&& parts_opt = prism_rtl::as<ast::TemplatePart::TpCall>(part).a2;
        ({
        auto plain = ast::SName{.sigils = lexer::after_first(n.sigils), .path_ = n->path_, .span = n.span};
        auto&& _qk_opt = check_env::resolve_value(lx.g, lx.home, n);
        auto&& qk_opt = std::get<0>(_qk_opt);
        auto&& _qk2_opt = check_env::resolve_value(lx.g, lx.home, plain);
        auto&& qk2_opt = std::get<0>(_qk2_opt);
        auto callee = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& q = prism_rtl::some_of(qk_opt);
                _v.set(value_path(lx, q));
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    if (prism_rtl::is_some(qk2_opt)) {
                        auto&& q = prism_rtl::some_of(qk2_opt);
                        _v.set(value_path(lx, q));
                        goto _done;
                    }
                    if (prism_rtl::is_none(qk2_opt)) {
                        _v.set(snake(check_env::sname_key(n)));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto body = ({
            __label__ _done;
            prism_rtl::Slot<Array<Ex>> _v;
            if (prism_rtl::is_some(parts_opt)) {
                auto&& ps = prism_rtl::some_of(parts_opt);
                _v.set(({
                    auto inner = run_to_end(fold_job(ps, Array(std::vector{Do(Do::DoLet{Pa(Pa::PaMut{Text::lit("out")}), Ex(Ex::XCall{Text::lit("String::new"), Array<Ex>{}})})}), ({
                        auto lx_1 = lx;
                        auto env_2 = env;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(std::tuple<Array<Do>, ast::TemplatePart>)>>(prism_rtl::rc([=](std::tuple<Array<Do>, ast::TemplatePart> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto lx_1_3 = lx_1;
                            auto env_2_3 = env_2;
                            entered(once_job([=]() {
                            return ({
                                auto acc = p0;
                                auto p_ = p1;
                                call_then(start_template_part_dos(lx_1_3, env_2_3, p_), [=](Array<Do> template_part_dos_123608) { return prism_rtl::finished(append(acc, template_part_dos_123608)); });
                            });
                        }));
                        });
                    })));
                    })));
                    (Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XBlock{inner, prism_rtl::rc(Ex(Ex::XCall{Text::lit("Text::from"), Array(std::vector{Ex(Ex::XVar{Text::lit("out")})})}))}))})}));
                }));
                goto _done;
            }
            if (prism_rtl::is_none(parts_opt)) {
                _v.set(Array<Ex>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto passed = ({
            __label__ _done;
            prism_rtl::Slot<Array<Ex>> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& q = prism_rtl::some_of(qk_opt);
                _v.set(template_args(lx, env, q, args, body));
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<Ex>> _v;
                    if (prism_rtl::is_some(qk2_opt)) {
                        auto&& q = prism_rtl::some_of(qk2_opt);
                        _v.set(template_args(lx, env, q, args, body));
                        goto _done;
                    }
                    if (prism_rtl::is_none(qk2_opt)) {
                        _v.set(append(run_to_end(each_job(args, ({
                            auto lx_1 = lx;
                            auto env_2 = env;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(ast::Arg)>>(prism_rtl::rc([=](ast::Arg p0) {
                            return ({
                                auto lx_1_3 = lx_1;
                                auto env_2_3 = env_2;
                                entered(once_job([=]() {
                                return ({
                                    auto a = p0;
                                    (prism_rtl::more(prism_rtl::rc(Argument(lx_1_3, env_2_3, a->value))));
                                });
                            }));
                            });
                        })));
                        }))), body));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto call = Ex(Ex::XCall{callee, passed});
        (prism_rtl::finished(Array(std::vector{Do(Do::DoExpr{Ex(Ex::XCall{Text::lit("place"), Array(std::vector{Ex(Ex::XRefMut{prism_rtl::rc(Ex(Ex::XVar{Text::lit("out")}))}), Ex(Ex::XRef{prism_rtl::rc(call)}), Ex(Ex::XNone{})})})})})));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TemplatePartDos, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Do>> start_template_part_dos(Lx lx, Env env, ast::TemplatePart part) {
    return prism_rtl::make_rc<TemplatePartDos>(lx, env, part);
}


/// TemplateArgs: unbounded fn Lx, Env, Text, [Arg], [Ex] -> [Ex]
Array<Ex> template_args(const Lx& lx, const Env& env, const Text& qk, const Array<ast::Arg>& args, const Array<Ex>& body) {
    auto clauses = clauses_of(lx.g, qk);
    auto arity = len(or_(index(clauses, Nat(0u)), dummy_clause()).params);
    return run_to_end(each_job(check_errors::range0(arity), ({
        auto body_1 = body;
        auto arity_2 = arity;
        auto clauses_3 = clauses;
        auto args_4 = args;
        auto lx_5 = lx;
        auto env_6 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto body_1_7 = body_1;
            auto arity_2_7 = arity_2;
            auto clauses_3_7 = clauses_3;
            auto args_4_7 = args_4;
            auto lx_5_7 = lx_5;
            auto env_6_7 = env_6;
            entered(once_job([=]() {
            return ({
                auto j = p0;
                (len(body_1_7) > Nat(0u)) && ((j + Nat(1u)) == arity_2_7)
                ? prism_rtl::finished(or_(index(body_1_7, Nat(0u)), Ex(Ex::XUnit{})))
                : ({
                auto&& _m = attr_at(clauses_3_7, j, args_4_7);
                prism_rtl::is_some(_m) ? ({
                auto&& a = prism_rtl::some_of(_m);
                prism_rtl::more(prism_rtl::rc(Argument(lx_5_7, env_6_7, a->value)));
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(refusal(prism_rtl::cat("a template call that fills no argument at place ", j)))
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Ex>> TemplateArgs::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& qk = this->qk;
    const auto& args = this->args;
    const auto& body = this->body;
    auto clauses = clauses_of(lx.g, qk);
    auto arity = len(or_(index(clauses, Nat(0u)), dummy_clause()).params);
    return each_job(check_errors::range0(arity), ({
        auto body_1 = body;
        auto arity_2 = arity;
        auto clauses_3 = clauses;
        auto args_4 = args;
        auto lx_5 = lx;
        auto env_6 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto body_1_7 = body_1;
            auto arity_2_7 = arity_2;
            auto clauses_3_7 = clauses_3;
            auto args_4_7 = args_4;
            auto lx_5_7 = lx_5;
            auto env_6_7 = env_6;
            entered(once_job([=]() {
            return ({
                auto j = p0;
                (len(body_1_7) > Nat(0u)) && ((j + Nat(1u)) == arity_2_7)
                ? prism_rtl::finished(or_(index(body_1_7, Nat(0u)), Ex(Ex::XUnit{})))
                : ({
                auto&& _m = attr_at(clauses_3_7, j, args_4_7);
                prism_rtl::is_some(_m) ? ({
                auto&& a = prism_rtl::some_of(_m);
                prism_rtl::more(prism_rtl::rc(Argument(lx_5_7, env_6_7, a->value)));
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(refusal(prism_rtl::cat("a template call that fills no argument at place ", j)))
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start TemplateArgs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Ex>> start_template_args(Lx lx, Env env, Text qk, Array<ast::Arg> args, Array<Ex> body) {
    return prism_rtl::make_rc<TemplateArgs>(lx, env, qk, args, body);
}


/// ?AttrAt: fn [FnClause], Nat, [Arg] -> ?Arg
std::optional<ast::Arg> attr_at(const Array<ast::FnClause>& clauses, const Nat& j, const Array<ast::Arg>& args) {
    auto names = fold(clauses, Array<Text>{}, [&](const Array<Text>& acc, const ast::FnClause& c) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = index(c.params, j);
            if (prism_rtl::is_some(_m)) {
                auto&& p_ = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    auto&& _m = place_name(p_);
                    if (prism_rtl::is_some(_m)) {
                        auto&& n = prism_rtl::some_of(_m);
                        _v.set(check_types::add_text(acc, n));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(acc);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    return fold(args, std::optional<ast::Arg>{}, [&](const std::optional<ast::Arg>& found_opt, const ast::Arg& a) {
        return ({
            __label__ _done;
            prism_rtl::Slot<std::optional<ast::Arg>> _v;
            auto&& _m = a.name;
            if (prism_rtl::is_some(_m)) {
                auto&& n = prism_rtl::some_of(_m);
                _v.set(check_types::has_text(names, n.name) ? std::optional(a) : found_opt);
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(found_opt);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// ?PlaceName: fn Pattern -> ?Text
std::optional<Text> place_name(const ast::Pattern_& p_) {
    auto&& _m = p_.kind;
    if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
        return std::optional(check_env::dotted(n->path_));
    }
    if (prism_rtl::is<ast::PatternKind::PGroup>(_m)) {
        auto&& q = prism_rtl::as<ast::PatternKind::PGroup>(_m).a0;
        return place_name(q);
    }
    {
        return std::optional<Text>{};
    }
}


/// ShownText: fn Vl -> Ex
Ex shown_text(const Vl& v_) {
    auto&& _m = value_ty(v_);
    if (prism_rtl::is<OutTy::OutText>(_m)) {
        return ref_(v_);
    }
    {
        return Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XCall{Text::lit("show_text"), Array(std::vector{ref_(v_)})}))});
    }
}


/// GivenValue: unbounded fn Lx, Env, Block, OutTy, Range -> Vl
Vl given_value(const Lx& lx, const Env& env, const ast::Block& b, const OutTy& t, const ast::Range& span) {
    auto label = prism_rtl::cat("'g", span.start);
    auto is_try = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<OutTy::OutRes>(t)) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto n = len(b.stmts);
    auto [dos, env2, last_opt] = run_to_end(fold_job(check_errors::range0(n), std::tuple{Array<Do>{}, env, std::optional<Vl>{}}, ({
        auto b_1 = b;
        auto is_try_2 = is_try;
        auto lx_3 = lx;
        auto label_4 = label;
        auto n_5 = n;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Do>, Env, std::optional<Vl>>>(std::tuple<std::tuple<Array<Do>, Env, std::optional<Vl>>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Do>, Env, std::optional<Vl>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto b_1_6 = b_1;
            auto is_try_2_6 = is_try_2;
            auto lx_3_6 = lx_3;
            auto label_4_6 = label_4;
            auto n_5_6 = n_5;
            entered(once_job([=]() {
            return ({
                auto [acc, en, lv_opt] = p0;
                auto i = p1;
                ({
                auto s = or_(index(b_1_6.stmts, i), dummy_stmt_l());
                auto fail = is_try_2_6
                    ? Ex(Ex::XCtor{Text::lit("Err"), Array(std::vector{Ex(Ex::XCall{Text::lit("Error::new"), Array(std::vector{Ex(Ex::XStr{Text::lit("Prelude.Unmet")}), Ex(Ex::XStr{source_text(lx_3_6, s.span)})})})})})
                    : Ex(Ex::XNone{});
                ({
                auto&& _m = s.kind;
                prism_rtl::is<ast::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<ast::StmtKind::SBind>(_m).a2) ? ({
                auto&& p_ = prism_rtl::as<ast::StmtKind::SBind>(_m).a0;
                auto&& x = prism_rtl::as<ast::StmtKind::SBind>(_m).a1;
                ({
                auto p__6 = p_;
                auto x_7 = x;
                call_then(start_value_of(lx_3_6, en, x_7), [=](Vl value_of_126542) {
                return ({
                    auto v_ = value_of_126542;
                    call_then(start_rust_pat(lx_3_6, p__6, inner_ty(type_at(lx_3_6, x_7.span)), Holding(Holding::Owned{}), prism_rtl::cat("g", s.span.start)), [=](PatOut rust_pat_126585) {
                    return ({
                        auto po = rust_pat_126585;
                        call_then(start_out_ty_of(lx_3_6, inner_ty(type_at(lx_3_6, x_7.span))), [=](OutTy out_ty_of_126727) { return prism_rtl::finished(std::tuple{prelude::push(acc, given_bind(is_try_2_6, po.pa, own(v_), label_4_6, out_ty_of_126727)), bind_all(en, po.binds), lv_opt}); });
                    });
                });
                });
            });
            });
            })
                : prism_rtl::is<ast::StmtKind::SRequire>(_m) ? ({
                auto&& c = prism_rtl::as<ast::StmtKind::SRequire>(_m).a0;
                ({
                auto c_6 = c;
                call_then(start_value_of(lx_3_6, en, c_6), [=](Vl value_of_126868) { return prism_rtl::finished(std::tuple{prelude::push(acc, Do(Do::DoIf{Ex(Ex::XUnary{Text::lit("!"), prism_rtl::rc(as_bool(value_of_126868))}), Array(std::vector{Do(Do::DoExpr{Ex(Ex::XBreak{label_4_6, prism_rtl::rc(fail)})})}), Array<Do>{}})), en, lv_opt}); });
            });
            })
                : prism_rtl::is<ast::StmtKind::SForbid>(_m) ? ({
                auto&& c = prism_rtl::as<ast::StmtKind::SForbid>(_m).a0;
                ({
                auto c_6 = c;
                call_then(start_value_of(lx_3_6, en, c_6), [=](Vl value_of_126992) { return prism_rtl::finished(std::tuple{prelude::push(acc, Do(Do::DoIf{as_bool(value_of_126992), Array(std::vector{Do(Do::DoExpr{Ex(Ex::XBreak{label_4_6, prism_rtl::rc(fail)})})}), Array<Do>{}})), en, lv_opt}); });
            });
            })
                : prism_rtl::is<ast::StmtKind::SExpr>(_m) ? ({
                auto&& x = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
                (i + Nat(1u)) == n_5_6
                ? prism_rtl::finished(std::tuple{acc, en, std::optional(value_of(lx_3_6, en, x))})
                : ({
                auto x_6 = x;
                call_then(start_value_of(lx_3_6, en, x_6), [=](Vl value_of_127200) { return prism_rtl::finished(std::tuple{prelude::push(acc, Do(Do::DoExpr{own(value_of_127200)})), en, lv_opt}); });
            });
            })
                : call_then(start_block_stmt(lx_3_6, en, s), [=](std::tuple<Array<Do>, Env> block_stmt_127292) {
                return ({
                    auto [more, en2] = block_stmt_127292;
                    (prism_rtl::finished(std::tuple{append(acc, more), en2, lv_opt}));
                });
            });
            });
            });
            });
        }));
        });
    }));
    })));
    auto last = or_(last_opt, Vl(Vl::VlOwned{Ex(Ex::XNone{}), t}));
    return Vl(Vl::VlOwned{Ex(Ex::XLabeled{label, dos, prism_rtl::rc(own(last)), t}), t});
}


prism_rtl::Turn<Vl> GivenValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& b = this->b;
    const auto& t = this->t;
    const auto& span = this->span;
    auto label = prism_rtl::cat("'g", span.start);
    auto is_try = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<OutTy::OutRes>(t)) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto n = len(b.stmts);
    auto b_1 = b;
    auto env_2 = env;
    auto lx_3 = lx;
    auto span_4 = span;
    auto t_5 = t;
    return call_value(fold_job(check_errors::range0(n), std::tuple{Array<Do>{}, env_2, std::optional<Vl>{}}, ({
        auto b_1_6 = b_1;
        auto is_try_6 = is_try;
        auto lx_3_7 = lx_3;
        auto label_7 = label;
        auto n_8 = n;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Do>, Env, std::optional<Vl>>>(std::tuple<std::tuple<Array<Do>, Env, std::optional<Vl>>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Do>, Env, std::optional<Vl>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto b_1_6_9 = b_1_6;
            auto is_try_6_9 = is_try_6;
            auto lx_3_7_9 = lx_3_7;
            auto label_7_9 = label_7;
            auto n_8_9 = n_8;
            entered(once_job([=]() {
            return ({
                auto [acc, en, lv_opt] = p0;
                auto i = p1;
                ({
                auto s = or_(index(b_1_6_9.stmts, i), dummy_stmt_l());
                auto fail = is_try_6_9
                    ? Ex(Ex::XCtor{Text::lit("Err"), Array(std::vector{Ex(Ex::XCall{Text::lit("Error::new"), Array(std::vector{Ex(Ex::XStr{Text::lit("Prelude.Unmet")}), Ex(Ex::XStr{source_text(lx_3_7_9, s.span)})})})})})
                    : Ex(Ex::XNone{});
                ({
                auto&& _m = s.kind;
                prism_rtl::is<ast::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<ast::StmtKind::SBind>(_m).a2) ? ({
                auto&& p_ = prism_rtl::as<ast::StmtKind::SBind>(_m).a0;
                auto&& x = prism_rtl::as<ast::StmtKind::SBind>(_m).a1;
                ({
                auto p__9 = p_;
                auto x_10 = x;
                call_then(start_value_of(lx_3_7_9, en, x_10), [=](Vl value_of_126542) {
                return ({
                    auto v_ = value_of_126542;
                    call_then(start_rust_pat(lx_3_7_9, p__9, inner_ty(type_at(lx_3_7_9, x_10.span)), Holding(Holding::Owned{}), prism_rtl::cat("g", s.span.start)), [=](PatOut rust_pat_126585) {
                    return ({
                        auto po = rust_pat_126585;
                        call_then(start_out_ty_of(lx_3_7_9, inner_ty(type_at(lx_3_7_9, x_10.span))), [=](OutTy out_ty_of_126727) { return prism_rtl::finished(std::tuple{prelude::push(acc, given_bind(is_try_6_9, po.pa, own(v_), label_7_9, out_ty_of_126727)), bind_all(en, po.binds), lv_opt}); });
                    });
                });
                });
            });
            });
            })
                : prism_rtl::is<ast::StmtKind::SRequire>(_m) ? ({
                auto&& c = prism_rtl::as<ast::StmtKind::SRequire>(_m).a0;
                ({
                auto c_9 = c;
                call_then(start_value_of(lx_3_7_9, en, c_9), [=](Vl value_of_126868) { return prism_rtl::finished(std::tuple{prelude::push(acc, Do(Do::DoIf{Ex(Ex::XUnary{Text::lit("!"), prism_rtl::rc(as_bool(value_of_126868))}), Array(std::vector{Do(Do::DoExpr{Ex(Ex::XBreak{label_7_9, prism_rtl::rc(fail)})})}), Array<Do>{}})), en, lv_opt}); });
            });
            })
                : prism_rtl::is<ast::StmtKind::SForbid>(_m) ? ({
                auto&& c = prism_rtl::as<ast::StmtKind::SForbid>(_m).a0;
                ({
                auto c_9 = c;
                call_then(start_value_of(lx_3_7_9, en, c_9), [=](Vl value_of_126992) { return prism_rtl::finished(std::tuple{prelude::push(acc, Do(Do::DoIf{as_bool(value_of_126992), Array(std::vector{Do(Do::DoExpr{Ex(Ex::XBreak{label_7_9, prism_rtl::rc(fail)})})}), Array<Do>{}})), en, lv_opt}); });
            });
            })
                : prism_rtl::is<ast::StmtKind::SExpr>(_m) ? ({
                auto&& x = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
                (i + Nat(1u)) == n_8_9
                ? prism_rtl::finished(std::tuple{acc, en, std::optional(value_of(lx_3_7_9, en, x))})
                : ({
                auto x_9 = x;
                call_then(start_value_of(lx_3_7_9, en, x_9), [=](Vl value_of_127200) { return prism_rtl::finished(std::tuple{prelude::push(acc, Do(Do::DoExpr{own(value_of_127200)})), en, lv_opt}); });
            });
            })
                : call_then(start_block_stmt(lx_3_7_9, en, s), [=](std::tuple<Array<Do>, Env> block_stmt_127292) {
                return ({
                    auto [more, en2] = block_stmt_127292;
                    (prism_rtl::finished(std::tuple{append(acc, more), en2, lv_opt}));
                });
            });
            });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<Do>, Env, std::optional<Vl>> fold_126226) {
        return ({
            auto [dos, env2, last_opt] = fold_126226;
            auto last = or_(last_opt, Vl(Vl::VlOwned{Ex(Ex::XNone{}), t_5}));
            (prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XLabeled{label, dos, prism_rtl::rc(own(last)), t_5}), t_5})));
        });
    });
}


/// `Start GivenValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_given_value(Lx lx, Env env, ast::Block b, OutTy t, ast::Range span) {
    return prism_rtl::make_rc<GivenValue>(lx, env, b, t, span);
}


/// GivenBind: fn Bool, Pa, Ex, Text, OutTy -> Do
Do given_bind(const bool& is_try, const Pa& pa, const Ex& x, const Text& label, const OutTy& t) {
    return is_try
        ? Do(Do::DoLet{pa, Ex(Ex::XMatch{prism_rtl::rc(x), Array(std::vector{XArm{.pat = Pa(Pa::PaCtor{Text::lit("Ok"), Array(std::vector{Pa(Pa::PaBind{Text::lit("v")})})}), .conds = Array<Cc>{}, .body = Ex(Ex::XVar{Text::lit("v")})}, XArm{.pat = Pa(Pa::PaCtor{Text::lit("Err"), Array(std::vector{Pa(Pa::PaBind{Text::lit("e")})})}), .conds = Array<Cc>{}, .body = Ex(Ex::XBreak{label, prism_rtl::rc(Ex(Ex::XCtor{Text::lit("Err"), Array(std::vector{Ex(Ex::XVar{Text::lit("e")})})}))})}}), false, t})})
        : Do(Do::DoLetElse{Pa(Pa::PaCtor{Text::lit("Some"), Array(std::vector{pa})}), x, Ex(Ex::XBreak{label, prism_rtl::rc(Ex(Ex::XNone{}))})});
}


/// SourceText: fn Lx, Range -> Text
Text source_text(const Lx& lx, const ast::Range& r) {
    auto&& _m = index(lx.g.srcs, lx->file);
    if (prism_rtl::is_some(_m)) {
        auto&& src = prism_rtl::some_of(_m);
        return check_errors::span_text(src, r);
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// UpdateValue: unbounded fn Lx, Env, Expr, Block, OutTy, Range -> Vl
Vl update_value(const Lx& lx, const Env& env, const ast::Expr& target, const ast::Block& b, const OutTy& t, const ast::Range& span) {
    auto tv = value_of(lx, env, target);
    auto env1 = bind(env, Text::lit("&_"), Bn(Bn::BnLocal{Ex(Ex::XVar{Text::lit("this")}), Holding(Holding::Owned{}), t}));
    auto&& _dos = upd_stmts(lx, env1, b.stmts);
    auto&& dos = std::get<0>(_dos);
    return Vl(Vl::VlOwned{Ex(Ex::XBlock{append(Array(std::vector{Do(Do::DoLet{Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaMut{Text::lit("this")})), t}), own(tv)})}), dos), prism_rtl::rc(Ex(Ex::XVar{Text::lit("this")}))}), t});
}


prism_rtl::Turn<Vl> UpdateValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& target = this->target;
    const auto& b = this->b;
    const auto& t = this->t;
    const auto& span = this->span;
    auto b_1 = b;
    auto env_2 = env;
    auto lx_3 = lx;
    auto t_4 = t;
    auto target_5 = target;
    return call_then(start_value_of(lx_3, env_2, target_5), [=](Vl value_of_128491) {
        return ({
            auto tv = value_of_128491;
            auto env1 = bind(env_2, Text::lit("&_"), Bn(Bn::BnLocal{Ex(Ex::XVar{Text::lit("this")}), Holding(Holding::Owned{}), t_4}));
            call_then(start_upd_stmts(lx_3, env1, b_1.stmts), [=](std::tuple<Array<Do>, Env> upd_stmts_128606) {
            return ({
                auto&& _dos = upd_stmts_128606;
                auto&& dos = std::get<0>(_dos);
                (prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XBlock{append(Array(std::vector{Do(Do::DoLet{Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaMut{Text::lit("this")})), t_4}), own(tv)})}), dos), prism_rtl::rc(Ex(Ex::XVar{Text::lit("this")}))}), t_4})));
            });
        });
        });
    });
}


/// `Start UpdateValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_update_value(Lx lx, Env env, ast::Expr target, ast::Block b, OutTy t, ast::Range span) {
    return prism_rtl::make_rc<UpdateValue>(lx, env, target, b, t, span);
}


/// UpdStmts: unbounded fn Lx, Env, [Stmt] -> (([Do], Env))
std::tuple<Array<Do>, Env> upd_stmts(const Lx& lx, const Env& env, const Array<ast::Stmt>& stmts) {
    return run_to_end(fold_job(stmts, std::tuple{Array<Do>{}, env}, ({
        auto lx_1 = lx;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Do>, Env>>(std::tuple<std::tuple<Array<Do>, Env>, ast::Stmt>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Do>, Env>, ast::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto [acc, en] = p0;
                auto s = p1;
                call_then(start_upd_stmt(lx_1_2, en, s), [=](std::tuple<Array<Do>, Env> upd_stmt_128891) {
                return ({
                    auto [more, en2] = upd_stmt_128891;
                    (prism_rtl::finished(std::tuple{append(acc, more), en2}));
                });
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Array<Do>, Env>> UpdStmts::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& stmts = this->stmts;
    return fold_job(stmts, std::tuple{Array<Do>{}, env}, ({
        auto lx_1 = lx;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Do>, Env>>(std::tuple<std::tuple<Array<Do>, Env>, ast::Stmt>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Do>, Env>, ast::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto [acc, en] = p0;
                auto s = p1;
                call_then(start_upd_stmt(lx_1_2, en, s), [=](std::tuple<Array<Do>, Env> upd_stmt_128891) {
                return ({
                    auto [more, en2] = upd_stmt_128891;
                    (prism_rtl::finished(std::tuple{append(acc, more), en2}));
                });
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start UpdStmts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<Do>, Env>> start_upd_stmts(Lx lx, Env env, Array<ast::Stmt> stmts) {
    return prism_rtl::make_rc<UpdStmts>(lx, env, stmts);
}


/// UpdStmt: unbounded fn Lx, Env, Stmt -> (([Do], Env))
std::tuple<Array<Do>, Env> upd_stmt(const Lx& lx, const Env& env, const ast::Stmt& s) {
    auto&& _m = s.kind;
    if (prism_rtl::is<ast::StmtKind::SSet>(_m)) {
        auto&& target = prism_rtl::as<ast::StmtKind::SSet>(_m).a0;
        auto&& value = prism_rtl::as<ast::StmtKind::SSet>(_m).a1;
        auto v_ = own(value_of(lx, env, value));
        return std::tuple{Array(std::vector{assign(lx, env, target, v_)}), env};
    }
    if (prism_rtl::is<ast::StmtKind::SAccum>(_m)) {
        auto&& target = prism_rtl::as<ast::StmtKind::SAccum>(_m).a0;
        auto&& op = prism_rtl::as<ast::StmtKind::SAccum>(_m).a1;
        auto&& value = prism_rtl::as<ast::StmtKind::SAccum>(_m).a2;
        auto cur = place_of(lx, env, target);
        auto tt = out_ty_of(lx, peel(type_at(lx, target.span)));
        auto rv = value_of(lx, env, value);
        auto bin = lexer::head(op);
        auto next = op_value(lx, bin, Vl(Vl::VlPlace{cur, Holding(Holding::Owned{}), tt}), rv, s.span, tt);
        return std::tuple{Array(std::vector{assign(lx, env, target, own(next))}), env};
    }
    if (prism_rtl::is<ast::StmtKind::SLet>(_m)) {
        auto&& p_ = prism_rtl::as<ast::StmtKind::SLet>(_m).a0;
        auto&& x = prism_rtl::as<ast::StmtKind::SLet>(_m).a2;
        auto v_ = own(value_of(lx, env, x));
        auto&& _m = p_.kind;
        if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
            auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
            return lexer::has_prefix(n.sigils, Text::lit("&"))
                ? ({
                auto rs = local_name(lx, check_env::sname_key(n));
                auto bt = out_ty_of(lx, peel(binder_ty(lx, n.span)));
                auto pa = is_known_ty(bt)
                    ? Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaMut{prism_rtl::cat(rs)})), bt})
                    : Pa(Pa::PaMut{prism_rtl::cat(rs)});
                std::tuple{Array(std::vector{Do(Do::DoLet{pa, v_})}), bind(env, check_env::sname_key(n), Bn(Bn::BnLocal{Ex(Ex::XVar{rs}), Holding(Holding::Owned{}), bt}))};
            })
                : block_stmt(lx, env, s);
        }
        {
            return block_stmt(lx, env, s);
        }
    }
    if (prism_rtl::is<ast::StmtKind::SWhile>(_m)) {
        auto&& c = prism_rtl::as<ast::StmtKind::SWhile>(_m).a0;
        auto&& body = prism_rtl::as<ast::StmtKind::SWhile>(_m).a1;
        auto&& _inner = upd_stmts(lx, env, body.stmts);
        auto&& inner = std::get<0>(_inner);
        if (prism_rtl::is<ast::Cond::CondExpr>(c)) {
            auto&& x = prism_rtl::as<ast::Cond::CondExpr>(c).a0;
            return std::tuple{Array(std::vector{Do(Do::DoWhile{as_bool(value_of(lx, env, x)), inner})}), env};
        }
        if (prism_rtl::is<ast::Cond::CondBind>(c)) {
            auto&& p_ = prism_rtl::as<ast::Cond::CondBind>(c).a0;
            auto&& x = prism_rtl::as<ast::Cond::CondBind>(c).a1;
            auto&& g_opt = prism_rtl::as<ast::Cond::CondBind>(c).a2;
            auto po = rust_pat(lx, p_, type_at(lx, x.span), Holding(Holding::Owned{}), prism_rtl::cat("w", s.span.start));
            auto env_b = bind_all(env, po.binds);
            auto&& _inner2 = upd_stmts(lx, env_b, body.stmts);
            auto&& inner2 = std::get<0>(_inner2);
            auto conds = append(po.conds, guard_conds(lx, env_b, g_opt));
            auto tests = fold(conds, Array<Ex>{}, [&](const Array<Ex>& acc, const Cc& c) {
                return ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Ex>> _v;
                    if (prism_rtl::is<Cc::CcIf>(c)) {
                        auto&& t = prism_rtl::as<Cc::CcIf>(c).a0;
                        _v.set(prelude::push(acc, t));
                        goto _done;
                    }
                    {
                        _v.set(acc);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            });
            auto lets = fold(conds, false, [&](const bool& f, const Cc& c) { return f || is_let_cond(c); });
            auto stop = len(tests) == Nat(0u)
                ? Array<Do>{}
                : Array(std::vector{Do(Do::DoIf{Ex(Ex::XUnary{Text::lit("!"), prism_rtl::rc(all_of(tests))}), Array(std::vector{Do(Do::DoExpr{Ex(Ex::XVar{Text::lit("break")})})}), Array<Do>{}})});
            auto body2 = lets
                ? Array(std::vector{refusal_do(Text::lit("a `while` whose pattern matches through an `Rc`"))})
                : append(stop, inner2);
            return std::tuple{Array(std::vector{Do(Do::DoWhileLet{po.pa, own(value_of(lx, env, x)), body2})}), env};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<ast::StmtKind::SExpr>(_m)) {
        auto&& x = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
        auto&& _m = x.kind;
        if (prism_rtl::is<ast::ExprKind::EIf>(_m)) {
            auto&& c = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
            auto&& then_b = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
            auto&& else_b_opt = prism_rtl::as<ast::ExprKind::EIf>(_m).a2;
            return std::tuple{Array(std::vector{upd_if(lx, env, c, then_b, else_b_opt)}), env};
        }
        if (prism_rtl::is<ast::ExprKind::EMatch>(_m)) {
            auto&& scrut = prism_rtl::as<ast::ExprKind::EMatch>(_m).a0;
            auto&& arms = prism_rtl::as<ast::ExprKind::EMatch>(_m).a1;
            return std::tuple{Array(std::vector{upd_match(lx, env, scrut, arms)}), env};
        }
        if (prism_rtl::is<ast::ExprKind::EFor>(_m)) {
            auto&& binders_opt = prism_rtl::as<ast::ExprKind::EFor>(_m).a0;
            auto&& source = prism_rtl::as<ast::ExprKind::EFor>(_m).a1;
            auto&& body = prism_rtl::as<ast::ExprKind::EFor>(_m).a2;
            return std::tuple{Array(std::vector{upd_for(lx, env, binders_opt, source, body, x.span)}), env};
        }
        {
            return std::tuple{Array(std::vector{Do(Do::DoExpr{own(value_of(lx, env, x))})}), env};
        }
    }
    {
        return block_stmt(lx, env, s);
    }
}


prism_rtl::Turn<std::tuple<Array<Do>, Env>> UpdStmt::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& s = this->s;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<ast::StmtKind::SSet>(_m) ? ({
        auto&& target = prism_rtl::as<ast::StmtKind::SSet>(_m).a0;
        auto&& value = prism_rtl::as<ast::StmtKind::SSet>(_m).a1;
        ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto target_3 = target;
        auto value_4 = value;
        call_then(start_value_of(lx_2, env_1, value_4), [=](Vl value_of_129078) {
        return ({
            auto v_ = own(value_of_129078);
            call_then(start_assign(lx_2, env_1, target_3, v_), [=](Do assign_129115) { return prism_rtl::finished(std::tuple{Array(std::vector{assign_129115}), env_1}); });
        });
    });
    });
    })
        : prism_rtl::is<ast::StmtKind::SAccum>(_m) ? ({
        auto&& target = prism_rtl::as<ast::StmtKind::SAccum>(_m).a0;
        auto&& op = prism_rtl::as<ast::StmtKind::SAccum>(_m).a1;
        auto&& value = prism_rtl::as<ast::StmtKind::SAccum>(_m).a2;
        ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto op_3 = op;
        auto s_4 = s;
        auto target_5 = target;
        auto value_6 = value;
        call_then(start_place_of(lx_2, env_1, target_5), [=](Ex place_of_129199) {
        return ({
            auto cur = place_of_129199;
            call_then(start_out_ty_of(lx_2, peel(type_at(lx_2, target_5.span))), [=](OutTy out_ty_of_129240) {
            return ({
                auto tt = out_ty_of_129240;
                call_then(start_value_of(lx_2, env_1, value_6), [=](Vl value_of_129301) {
                return ({
                    auto rv = value_of_129301;
                    auto bin = lexer::head(op_3);
                    auto next = op_value(lx_2, bin, Vl(Vl::VlPlace{cur, Holding(Holding::Owned{}), tt}), rv, s_4.span, tt);
                    call_then(start_assign(lx_2, env_1, target_5, own(next)), [=](Do assign_129440) { return prism_rtl::finished(std::tuple{Array(std::vector{assign_129440}), env_1}); });
                });
            });
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<ast::StmtKind::SLet>(_m) ? ({
        auto&& p_ = prism_rtl::as<ast::StmtKind::SLet>(_m).a0;
        auto&& x = prism_rtl::as<ast::StmtKind::SLet>(_m).a2;
        ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto p__3 = p_;
        auto s_4 = s;
        auto x_5 = x;
        call_then(start_value_of(lx_2, env_1, x_5), [=](Vl value_of_129529) {
        return ({
            auto v_ = own(value_of_129529);
            ({
            auto&& _m = p__3.kind;
            prism_rtl::is<ast::PatternKind::PName>(_m) ? ({
            auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
            lexer::has_prefix(n.sigils, Text::lit("&"))
            ? ({
            auto rs = local_name(lx_2, check_env::sname_key(n));
            auto n_6 = n;
            call_then(start_out_ty_of(lx_2, peel(binder_ty(lx_2, n_6.span))), [=](OutTy out_ty_of_129723) {
            return ({
                auto bt = out_ty_of_129723;
                call_then(start_is_known_ty(bt), [=](bool is_known_ty_129796) {
                return ({
                    auto pa = is_known_ty_129796
                        ? Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaMut{prism_rtl::cat(rs)})), bt})
                        : Pa(Pa::PaMut{prism_rtl::cat(rs)});
                    (prism_rtl::finished(std::tuple{Array(std::vector{Do(Do::DoLet{pa, v_})}), bind(env_1, check_env::sname_key(n_6), Bn(Bn::BnLocal{Ex(Ex::XVar{rs}), Holding(Holding::Owned{}), bt}))}));
                });
            });
            });
        });
        })
            : prism_rtl::more(prism_rtl::rc(BlockStmt(lx_2, env_1, s_4)));
        })
            : prism_rtl::more(prism_rtl::rc(BlockStmt(lx_2, env_1, s_4)));
        });
        });
    });
    });
    })
        : prism_rtl::is<ast::StmtKind::SWhile>(_m) ? ({
        auto&& c = prism_rtl::as<ast::StmtKind::SWhile>(_m).a0;
        auto&& body = prism_rtl::as<ast::StmtKind::SWhile>(_m).a1;
        ({
        auto body_1 = body;
        auto c_2 = c;
        auto env_3 = env;
        auto lx_4 = lx;
        auto s_5 = s;
        call_then(start_upd_stmts(lx_4, env_3, body_1.stmts), [=](std::tuple<Array<Do>, Env> upd_stmts_130095) {
        return ({
            auto&& _inner = upd_stmts_130095;
            auto&& inner = std::get<0>(_inner);
            ({
            prism_rtl::is<ast::Cond::CondExpr>(c_2) ? ({
            auto&& x = prism_rtl::as<ast::Cond::CondExpr>(c_2).a0;
            ({
            auto x_6 = x;
            call_then(start_value_of(lx_4, env_3, x_6), [=](Vl value_of_130187) { return prism_rtl::finished(std::tuple{Array(std::vector{Do(Do::DoWhile{as_bool(value_of_130187), inner})}), env_3}); });
        });
        })
            : prism_rtl::is<ast::Cond::CondBind>(c_2) ? ({
            auto&& p_ = prism_rtl::as<ast::Cond::CondBind>(c_2).a0;
            auto&& x = prism_rtl::as<ast::Cond::CondBind>(c_2).a1;
            auto&& g_opt = prism_rtl::as<ast::Cond::CondBind>(c_2).a2;
            ({
            auto g_opt_6 = g_opt;
            auto p__7 = p_;
            auto x_8 = x;
            call_then(start_rust_pat(lx_4, p__7, type_at(lx_4, x_8.span), Holding(Holding::Owned{}), prism_rtl::cat("w", s_5.span.start)), [=](PatOut rust_pat_130281) {
            return ({
                auto po = rust_pat_130281;
                auto env_b = bind_all(env_3, po.binds);
                call_then(start_upd_stmts(lx_4, env_b, body_1.stmts), [=](std::tuple<Array<Do>, Env> upd_stmts_130432) {
                return ({
                    auto&& _inner2 = upd_stmts_130432;
                    auto&& inner2 = std::get<0>(_inner2);
                    call_then(start_guard_conds(lx_4, env_b, g_opt_6), [=](Array<Cc> guard_conds_130690) {
                    return ({
                        auto conds = append(po.conds, guard_conds_130690);
                        auto tests = fold(conds, Array<Ex>{}, [&](const Array<Ex>& acc, const Cc& c) {
                            return ({
                                __label__ _done;
                                prism_rtl::Slot<Array<Ex>> _v;
                                if (prism_rtl::is<Cc::CcIf>(c)) {
                                    auto&& t = prism_rtl::as<Cc::CcIf>(c).a0;
                                    _v.set(prelude::push(acc, t));
                                    goto _done;
                                }
                                {
                                    _v.set(acc);
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            });
                        });
                        auto lets = fold(conds, false, [&](const bool& f, const Cc& c) { return f || is_let_cond(c); });
                        auto stop = len(tests) == Nat(0u)
                            ? Array<Do>{}
                            : Array(std::vector{Do(Do::DoIf{Ex(Ex::XUnary{Text::lit("!"), prism_rtl::rc(all_of(tests))}), Array(std::vector{Do(Do::DoExpr{Ex(Ex::XVar{Text::lit("break")})})}), Array<Do>{}})});
                        auto body2 = lets
                            ? Array(std::vector{refusal_do(Text::lit("a `while` whose pattern matches through an `Rc`"))})
                            : append(stop, inner2);
                        call_then(start_value_of(lx_4, env_3, x_8), [=](Vl value_of_131229) { return prism_rtl::finished(std::tuple{Array(std::vector{Do(Do::DoWhileLet{po.pa, own(value_of_131229), body2})}), env_3}); });
                    });
                });
                });
            });
            });
        });
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
    });
    })
        : prism_rtl::is<ast::StmtKind::SExpr>(_m) ? ({
        auto&& x = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
        ({
        auto&& _m = x.kind;
        prism_rtl::is<ast::ExprKind::EIf>(_m) ? ({
        auto&& c = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
        auto&& else_b_opt = prism_rtl::as<ast::ExprKind::EIf>(_m).a2;
        ({
        auto else_b_opt_1 = else_b_opt;
        auto c_2 = c;
        auto env_3 = env;
        auto lx_4 = lx;
        auto then_b_5 = then_b;
        call_then(start_upd_if(lx_4, env_3, c_2, then_b_5, else_b_opt_1), [=](Do upd_if_131329) { return prism_rtl::finished(std::tuple{Array(std::vector{upd_if_131329}), env_3}); });
    });
    })
        : prism_rtl::is<ast::ExprKind::EMatch>(_m) ? ({
        auto&& scrut = prism_rtl::as<ast::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<ast::ExprKind::EMatch>(_m).a1;
        ({
        auto arms_1 = arms;
        auto env_2 = env;
        auto lx_3 = lx;
        auto scrut_4 = scrut;
        call_then(start_upd_match(lx_3, env_2, scrut_4, arms_1), [=](Do upd_match_131404) { return prism_rtl::finished(std::tuple{Array(std::vector{upd_match_131404}), env_2}); });
    });
    })
        : prism_rtl::is<ast::ExprKind::EFor>(_m) ? ({
        auto&& binders_opt = prism_rtl::as<ast::ExprKind::EFor>(_m).a0;
        auto&& source = prism_rtl::as<ast::ExprKind::EFor>(_m).a1;
        auto&& body = prism_rtl::as<ast::ExprKind::EFor>(_m).a2;
        ({
        auto binders_opt_1 = binders_opt;
        auto body_2 = body;
        auto env_3 = env;
        auto lx_4 = lx;
        auto source_5 = source;
        auto x_6 = x;
        call_then(start_upd_for(lx_4, env_3, binders_opt_1, source_5, body_2, x_6.span), [=](Do upd_for_131486) { return prism_rtl::finished(std::tuple{Array(std::vector{upd_for_131486}), env_3}); });
    });
    })
        : ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto x_3 = x;
        call_then(start_value_of(lx_2, env_1, x_3), [=](Vl value_of_131579) { return prism_rtl::finished(std::tuple{Array(std::vector{Do(Do::DoExpr{own(value_of_131579)})}), env_1}); });
    });
    });
    })
        : prism_rtl::more(prism_rtl::rc(BlockStmt(lx, env, s)));
    });
}


/// `Start UpdStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<Do>, Env>> start_upd_stmt(Lx lx, Env env, ast::Stmt s) {
    return prism_rtl::make_rc<UpdStmt>(lx, env, s);
}


/// UpdFor: unbounded fn Lx, Env, ?ForBinders, Expr, Block, Range -> Do
Do upd_for(const Lx& lx, const Env& env, const std::optional<ast::ForBinders>& binders_opt, const ast::Expr& source, const ast::Block& body, const ast::Range& span) {
    auto sty = peel(type_at(lx, source.span));
    auto&& _m = ref_binder(binders_opt);
    if (prism_rtl::is_some(_m)) {
        auto&& n = prism_rtl::some_of(_m);
        return is_ref_path(source)
            ? upd_for_refs(lx, env, n, source, body, span, sty)
            : upd_for_values(lx, env, binders_opt, source, body, span, sty);
    }
    if (prism_rtl::is_none(_m)) {
        return upd_for_values(lx, env, binders_opt, source, body, span, sty);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Do> UpdFor::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& binders_opt = this->binders_opt;
    const auto& source = this->source;
    const auto& body = this->body;
    const auto& span = this->span;
    auto sty = peel(type_at(lx, source.span));
    return ({
        auto&& _m = ref_binder(binders_opt);
        prism_rtl::is_some(_m) ? ({
        auto&& n = prism_rtl::some_of(_m);
        is_ref_path(source)
        ? prism_rtl::more(prism_rtl::rc(UpdForRefs(lx, env, n, source, body, span, sty)))
        : prism_rtl::more(prism_rtl::rc(UpdForValues(lx, env, binders_opt, source, body, span, sty)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(UpdForValues(lx, env, binders_opt, source, body, span, sty)))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start UpdFor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Do> start_upd_for(Lx lx, Env env, std::optional<ast::ForBinders> binders_opt, ast::Expr source, ast::Block body, ast::Range span) {
    return prism_rtl::make_rc<UpdFor>(lx, env, binders_opt, source, body, span);
}


/// UpdForRefs: unbounded fn Lx, Env, SName, Expr, Block, Range, Ty -> Do
Do upd_for_refs(const Lx& lx, const Env& env, const ast::SName& n, const ast::Expr& source, const ast::Block& body, const ast::Range& span, const check_types::Ty& sty) {
    if (prism_rtl::is<check_types::Ty::TyArray>(sty)) {
        auto&& v_ = prism_rtl::as<check_types::Ty::TyArray>(sty).a0;
        auto key_name = prism_rtl::cat("k", span.start);
        auto ref_name = prism_rtl::cat("r", span.start);
        auto env1 = bind(bind(bind(env, Text::lit("key"), Bn(Bn::BnLocal{Ex(Ex::XVar{key_name}), Holding(Holding::Owned{}), OutTy(OutTy::OutNat{})})), Text::lit("ix"), Bn(Bn::BnLocal{Ex(Ex::XVar{key_name}), Holding(Holding::Owned{}), OutTy(OutTy::OutNat{})})), check_env::sname_key(n), Bn(Bn::BnLocal{Ex(Ex::XTarget{prism_rtl::rc(Ex(Ex::XVar{ref_name}))}), Holding(Holding::Owned{}), out_ty_of(lx, v_)}));
        auto&& _dos = upd_stmts(lx, env1, body.stmts);
        auto&& dos = std::get<0>(_dos);
        auto head = Do(Do::DoLet{Pa(Pa::PaBind{key_name}), Ex(Ex::XCall{Text::lit("nat_of"), Array(std::vector{Ex(Ex::XVar{prism_rtl::cat("i", span.start)})})})});
        return Do(Do::DoFor{Pa(Pa::PaTuple{Array(std::vector{Pa(Pa::PaBind{prism_rtl::cat("i", span.start)}), Pa(Pa::PaBind{ref_name})})}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(place_of(lx, env, source)), Text::lit("iter_mut"), Array<Ex>{}})), Text::lit("enumerate"), Array<Ex>{}}), append(Array(std::vector{head}), dos)});
    }
    {
        return refusal_do(Text::lit("a `for` by reference over what is not an array"));
    }
}


prism_rtl::Turn<Do> UpdForRefs::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& n = this->n;
    const auto& source = this->source;
    const auto& body = this->body;
    const auto& span = this->span;
    const auto& sty = this->sty;
    return ({
        prism_rtl::is<check_types::Ty::TyArray>(sty) ? ({
        auto&& v_ = prism_rtl::as<check_types::Ty::TyArray>(sty).a0;
        ({
        auto key_name = prism_rtl::cat("k", span.start);
        auto ref_name = prism_rtl::cat("r", span.start);
        auto body_1 = body;
        auto env_2 = env;
        auto lx_3 = lx;
        auto n_4 = n;
        auto source_5 = source;
        auto span_6 = span;
        auto v__7 = v_;
        call_then(start_out_ty_of(lx_3, v__7), [=](OutTy out_ty_of_132939) {
        return ({
            auto env1 = bind(bind(bind(env_2, Text::lit("key"), Bn(Bn::BnLocal{Ex(Ex::XVar{key_name}), Holding(Holding::Owned{}), OutTy(OutTy::OutNat{})})), Text::lit("ix"), Bn(Bn::BnLocal{Ex(Ex::XVar{key_name}), Holding(Holding::Owned{}), OutTy(OutTy::OutNat{})})), check_env::sname_key(n_4), Bn(Bn::BnLocal{Ex(Ex::XTarget{prism_rtl::rc(Ex(Ex::XVar{ref_name}))}), Holding(Holding::Owned{}), out_ty_of_132939}));
            call_then(start_upd_stmts(lx_3, env1, body_1.stmts), [=](std::tuple<Array<Do>, Env> upd_stmts_132985) {
            return ({
                auto&& _dos = upd_stmts_132985;
                auto&& dos = std::get<0>(_dos);
                auto head = Do(Do::DoLet{Pa(Pa::PaBind{key_name}), Ex(Ex::XCall{Text::lit("nat_of"), Array(std::vector{Ex(Ex::XVar{prism_rtl::cat("i", span_6.start)})})})});
                call_then(start_place_of(lx_3, env_2, source_5), [=](Ex place_of_133194) { return prism_rtl::finished(Do(Do::DoFor{Pa(Pa::PaTuple{Array(std::vector{Pa(Pa::PaBind{prism_rtl::cat("i", span_6.start)}), Pa(Pa::PaBind{ref_name})})}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(place_of_133194), Text::lit("iter_mut"), Array<Ex>{}})), Text::lit("enumerate"), Array<Ex>{}}), append(Array(std::vector{head}), dos)})); });
            });
        });
        });
    });
    });
    })
        : prism_rtl::finished(refusal_do(Text::lit("a `for` by reference over what is not an array")));
    });
}


/// `Start UpdForRefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Do> start_upd_for_refs(Lx lx, Env env, ast::SName n, ast::Expr source, ast::Block body, ast::Range span, check_types::Ty sty) {
    return prism_rtl::make_rc<UpdForRefs>(lx, env, n, source, body, span, sty);
}


/// ?RefBinder: fn ?ForBinders -> ?SName
std::optional<ast::SName> ref_binder(const std::optional<ast::ForBinders>& opt0) {
    if (prism_rtl::is_some(opt0)) {
        auto&& fb = prism_rtl::some_of(opt0);
        auto&& _m = fb.second;
        if (prism_rtl::is_none(_m)) {
            auto&& _m = fb.first.kind;
            if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
                auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
                return lexer::has_prefix(n.sigils, Text::lit("&"))
                    ? std::optional(n)
                    : std::optional<ast::SName>{};
            }
            {
                return std::optional<ast::SName>{};
            }
        }
        {
            return std::optional<ast::SName>{};
        }
    }
    if (prism_rtl::is_none(opt0)) {
        return std::optional<ast::SName>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// IsRefPath: fn Expr -> Bool
bool is_ref_path(const ast::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
        return lexer::has_prefix(n.sigils, Text::lit("&"));
    }
    if (prism_rtl::is<ast::ExprKind::EField>(_m)) {
        auto&& r = prism_rtl::as<ast::ExprKind::EField>(_m).a0;
        return is_ref_path(r);
    }
    if (prism_rtl::is<ast::ExprKind::EIndex>(_m)) {
        auto&& r = prism_rtl::as<ast::ExprKind::EIndex>(_m).a0;
        return is_ref_path(r);
    }
    if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        return is_ref_path(x);
    }
    {
        return false;
    }
}


/// UpdForValues: unbounded fn Lx, Env, ?ForBinders, Expr, Block, Range, Ty -> Do
Do upd_for_values(const Lx& lx, const Env& env, const std::optional<ast::ForBinders>& binders_opt, const ast::Expr& source, const ast::Block& body, const ast::Range& span, const check_types::Ty& sty) {
    auto src = own(value_of(lx, env, source));
    auto [kt, vt, is_array] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<OutTy, OutTy, bool>> _v;
        if (prism_rtl::is<check_types::Ty::TyArray>(sty)) {
            auto&& v_ = prism_rtl::as<check_types::Ty::TyArray>(sty).a0;
            _v.set(std::tuple{OutTy(OutTy::OutNat{}), out_ty_of(lx, v_), true});
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyMap>(sty)) {
            auto&& k = prism_rtl::as<check_types::Ty::TyMap>(sty).a0;
            auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(sty).a1;
            _v.set(std::tuple{out_ty_of(lx, k), out_ty_of(lx, v_), false});
            goto _done;
        }
        {
            _v.set(std::tuple{OutTy(OutTy::OutUnit{}), OutTy(OutTy::OutUnit{}), true});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [vty, kty] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<check_types::Ty, check_types::Ty>> _v;
        if (prism_rtl::is<check_types::Ty::TyArray>(sty)) {
            auto&& v_ = prism_rtl::as<check_types::Ty::TyArray>(sty).a0;
            _v.set(std::tuple{v_, check_types::Ty(check_types::Ty::TyCon{Text::lit("Nat"), Array<check_types::Ty>{}})});
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyMap>(sty)) {
            auto&& k = prism_rtl::as<check_types::Ty::TyMap>(sty).a0;
            auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(sty).a1;
            _v.set(std::tuple{v_, k});
            goto _done;
        }
        {
            _v.set(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::Ty(check_types::Ty::TyErr{})});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto key_name = prism_rtl::cat("k", span.start);
    auto val_name = prism_rtl::cat("v", span.start);
    auto env1 = bind(bind(env, Text::lit("key"), Bn(Bn::BnLocal{Ex(Ex::XVar{key_name}), Holding(Holding::Owned{}), kt})), Text::lit("_"), Bn(Bn::BnLocal{Ex(Ex::XVar{val_name}), Holding(Holding::Owned{}), vt}));
    auto env2 = is_array
        ? bind(env1, Text::lit("ix"), Bn(Bn::BnLocal{Ex(Ex::XVar{key_name}), Holding(Holding::Owned{}), kt}))
        : env1;
    auto [binds, env3] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<Do>, Env>> _v;
        if (prism_rtl::is_none(binders_opt)) {
            _v.set(std::tuple{Array<Do>{}, env2});
            goto _done;
        }
        if (prism_rtl::is_some(binders_opt)) {
            auto&& fb = prism_rtl::some_of(binders_opt);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<Do>, Env>> _v;
                auto&& _m = fb.second;
                if (prism_rtl::is_none(_m)) {
                    _v.set(({
                        auto po = rust_pat(lx, fb.first, vty, Holding(Holding::Owned{}), prism_rtl::cat("e", span.start));
                        std::tuple{Array(std::vector{Do(Do::DoLet{po.pa, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{val_name}))})})}), bind_all(env2, po.binds)};
                    }));
                    goto _done;
                }
                if (prism_rtl::is_some(_m)) {
                    auto&& second = prism_rtl::some_of(_m);
                    _v.set(({
                        auto pk = rust_pat(lx, fb.first, kty, Holding(Holding::Owned{}), prism_rtl::cat("k", span.start, "_"));
                        auto pv = rust_pat(lx, second, vty, Holding(Holding::Owned{}), prism_rtl::cat("e", span.start));
                        std::tuple{Array(std::vector{Do(Do::DoLet{pk.pa, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{key_name}))})}), Do(Do::DoLet{pv.pa, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{val_name}))})})}), bind_all(bind_all(env2, pk.binds), pv.binds)};
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& _dos = upd_stmts(lx, env3, body.stmts);
    auto&& dos = std::get<0>(_dos);
    return is_array
        ? ({
        auto head = Do(Do::DoLet{Pa(Pa::PaBind{key_name}), Ex(Ex::XCall{Text::lit("nat_of"), Array(std::vector{Ex(Ex::XVar{prism_rtl::cat("i", span.start)})})})});
        (Do(Do::DoFor{Pa(Pa::PaTuple{Array(std::vector{Pa(Pa::PaBind{prism_rtl::cat("i", span.start)}), Pa(Pa::PaBind{val_name})})}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(src), Text::lit("into_iter"), Array<Ex>{}})), Text::lit("enumerate"), Array<Ex>{}}), append(prelude::push(Array<Do>{}, head), append(binds, dos))}));
    })
        : Do(Do::DoFor{Pa(Pa::PaTuple{Array(std::vector{Pa(Pa::PaBind{key_name}), Pa(Pa::PaBind{val_name})})}), Ex(Ex::XMethod{prism_rtl::rc(src), Text::lit("into_iter"), Array<Ex>{}}), append(binds, dos)});
}


prism_rtl::Turn<Do> UpdForValues::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& binders_opt = this->binders_opt;
    const auto& source = this->source;
    const auto& body = this->body;
    const auto& span = this->span;
    const auto& sty = this->sty;
    auto binders_opt_1 = binders_opt;
    auto body_2 = body;
    auto env_3 = env;
    auto lx_4 = lx;
    auto source_5 = source;
    auto span_6 = span;
    auto sty_7 = sty;
    return call_then(start_value_of(lx_4, env_3, source_5), [=](Vl value_of_134089) {
        return ({
            auto src = own(value_of_134089);
            auto [kt, vt, is_array] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<OutTy, OutTy, bool>> _v;
                if (prism_rtl::is<check_types::Ty::TyArray>(sty)) {
                    auto&& v_ = prism_rtl::as<check_types::Ty::TyArray>(sty).a0;
                    _v.set(std::tuple{OutTy(OutTy::OutNat{}), out_ty_of(lx_4, v_), true});
                    goto _done;
                }
                if (prism_rtl::is<check_types::Ty::TyMap>(sty)) {
                    auto&& k = prism_rtl::as<check_types::Ty::TyMap>(sty).a0;
                    auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(sty).a1;
                    _v.set(std::tuple{out_ty_of(lx_4, k), out_ty_of(lx_4, v_), false});
                    goto _done;
                }
                {
                    _v.set(std::tuple{OutTy(OutTy::OutUnit{}), OutTy(OutTy::OutUnit{}), true});
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto [vty, kty] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<check_types::Ty, check_types::Ty>> _v;
                if (prism_rtl::is<check_types::Ty::TyArray>(sty)) {
                    auto&& v_ = prism_rtl::as<check_types::Ty::TyArray>(sty).a0;
                    _v.set(std::tuple{v_, check_types::Ty(check_types::Ty::TyCon{Text::lit("Nat"), Array<check_types::Ty>{}})});
                    goto _done;
                }
                if (prism_rtl::is<check_types::Ty::TyMap>(sty)) {
                    auto&& k = prism_rtl::as<check_types::Ty::TyMap>(sty).a0;
                    auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(sty).a1;
                    _v.set(std::tuple{v_, k});
                    goto _done;
                }
                {
                    _v.set(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::Ty(check_types::Ty::TyErr{})});
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto key_name = prism_rtl::cat("k", span_6.start);
            auto val_name = prism_rtl::cat("v", span_6.start);
            auto env1 = bind(bind(env_3, Text::lit("key"), Bn(Bn::BnLocal{Ex(Ex::XVar{key_name}), Holding(Holding::Owned{}), kt})), Text::lit("_"), Bn(Bn::BnLocal{Ex(Ex::XVar{val_name}), Holding(Holding::Owned{}), vt}));
            auto env2 = is_array
                ? bind(env1, Text::lit("ix"), Bn(Bn::BnLocal{Ex(Ex::XVar{key_name}), Holding(Holding::Owned{}), kt}))
                : env1;
            auto [binds, env3] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<Do>, Env>> _v;
                if (prism_rtl::is_none(binders_opt)) {
                    _v.set(std::tuple{Array<Do>{}, env2});
                    goto _done;
                }
                if (prism_rtl::is_some(binders_opt)) {
                    auto&& fb = prism_rtl::some_of(binders_opt);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<Array<Do>, Env>> _v;
                        auto&& _m = fb.second;
                        if (prism_rtl::is_none(_m)) {
                            _v.set(({
                                auto po = rust_pat(lx_4, fb.first, vty, Holding(Holding::Owned{}), prism_rtl::cat("e", span_6.start));
                                std::tuple{Array(std::vector{Do(Do::DoLet{po.pa, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{val_name}))})})}), bind_all(env2, po.binds)};
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_some(_m)) {
                            auto&& second = prism_rtl::some_of(_m);
                            _v.set(({
                                auto pk = rust_pat(lx_4, fb.first, kty, Holding(Holding::Owned{}), prism_rtl::cat("k", span_6.start, "_"));
                                auto pv = rust_pat(lx_4, second, vty, Holding(Holding::Owned{}), prism_rtl::cat("e", span_6.start));
                                std::tuple{Array(std::vector{Do(Do::DoLet{pk.pa, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{key_name}))})}), Do(Do::DoLet{pv.pa, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{val_name}))})})}), bind_all(bind_all(env2, pk.binds), pv.binds)};
                            }));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            call_then(start_upd_stmts(lx_4, env3, body_2.stmts), [=](std::tuple<Array<Do>, Env> upd_stmts_135370) {
            return ({
                auto&& _dos = upd_stmts_135370;
                auto&& dos = std::get<0>(_dos);
                is_array
                ? ({
                auto head = Do(Do::DoLet{Pa(Pa::PaBind{key_name}), Ex(Ex::XCall{Text::lit("nat_of"), Array(std::vector{Ex(Ex::XVar{prism_rtl::cat("i", span_6.start)})})})});
                (prism_rtl::finished(Do(Do::DoFor{Pa(Pa::PaTuple{Array(std::vector{Pa(Pa::PaBind{prism_rtl::cat("i", span_6.start)}), Pa(Pa::PaBind{val_name})})}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(src), Text::lit("into_iter"), Array<Ex>{}})), Text::lit("enumerate"), Array<Ex>{}}), append(prelude::push(Array<Do>{}, head), append(binds, dos))})));
            })
                : prism_rtl::finished(Do(Do::DoFor{Pa(Pa::PaTuple{Array(std::vector{Pa(Pa::PaBind{key_name}), Pa(Pa::PaBind{val_name})})}), Ex(Ex::XMethod{prism_rtl::rc(src), Text::lit("into_iter"), Array<Ex>{}}), append(binds, dos)}));
            });
        });
        });
    });
}


/// `Start UpdForValues, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Do> start_upd_for_values(Lx lx, Env env, std::optional<ast::ForBinders> binders_opt, ast::Expr source, ast::Block body, ast::Range span, check_types::Ty sty) {
    return prism_rtl::make_rc<UpdForValues>(lx, env, binders_opt, source, body, span, sty);
}


/// UpdIf: unbounded fn Lx, Env, Cond, Block, ?Block -> Do
Do upd_if(const Lx& lx, const Env& env, const ast::Cond& c, const ast::Block& then_b, const std::optional<ast::Block>& else_b_opt) {
    auto&& _else_dos = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<Do>, Env>> _v;
        if (prism_rtl::is_some(else_b_opt)) {
            auto&& b = prism_rtl::some_of(else_b_opt);
            _v.set(upd_stmts(lx, env, b.stmts));
            goto _done;
        }
        if (prism_rtl::is_none(else_b_opt)) {
            _v.set(std::tuple{Array<Do>{}, env});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& else_dos = std::get<0>(_else_dos);
    if (prism_rtl::is<ast::Cond::CondExpr>(c)) {
        auto&& x = prism_rtl::as<ast::Cond::CondExpr>(c).a0;
        auto&& _then_dos = upd_stmts(lx, env, then_b.stmts);
        auto&& then_dos = std::get<0>(_then_dos);
        return Do(Do::DoIf{as_bool(value_of(lx, env, x)), then_dos, else_dos});
    }
    if (prism_rtl::is<ast::Cond::CondBind>(c)) {
        auto&& p_ = prism_rtl::as<ast::Cond::CondBind>(c).a0;
        auto&& x = prism_rtl::as<ast::Cond::CondBind>(c).a1;
        auto po = rust_pat(lx, p_, type_at(lx, x.span), Holding(Holding::Owned{}), prism_rtl::cat("u", x.span.start));
        auto&& _then_dos = upd_stmts(lx, bind_all(env, po.binds), then_b.stmts);
        auto&& then_dos = std::get<0>(_then_dos);
        return Do(Do::DoIfLet{po.pa, own(value_of(lx, env, x)), then_dos, else_dos});
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Do> UpdIf::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& c = this->c;
    const auto& then_b = this->then_b;
    const auto& else_b_opt = this->else_b_opt;
    auto&& _else_dos = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<Do>, Env>> _v;
        if (prism_rtl::is_some(else_b_opt)) {
            auto&& b = prism_rtl::some_of(else_b_opt);
            _v.set(upd_stmts(lx, env, b.stmts));
            goto _done;
        }
        if (prism_rtl::is_none(else_b_opt)) {
            _v.set(std::tuple{Array<Do>{}, env});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& else_dos = std::get<0>(_else_dos);
    return ({
        prism_rtl::is<ast::Cond::CondExpr>(c) ? ({
        auto&& x = prism_rtl::as<ast::Cond::CondExpr>(c).a0;
        ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto then_b_3 = then_b;
        auto x_4 = x;
        call_then(start_upd_stmts(lx_2, env_1, then_b_3.stmts), [=](std::tuple<Array<Do>, Env> upd_stmts_136080) {
        return ({
            auto&& _then_dos = upd_stmts_136080;
            auto&& then_dos = std::get<0>(_then_dos);
            call_then(start_value_of(lx_2, env_1, x_4), [=](Vl value_of_136136) { return prism_rtl::finished(Do(Do::DoIf{as_bool(value_of_136136), then_dos, else_dos})); });
        });
    });
    });
    })
        : prism_rtl::is<ast::Cond::CondBind>(c) ? ({
        auto&& p_ = prism_rtl::as<ast::Cond::CondBind>(c).a0;
        auto&& x = prism_rtl::as<ast::Cond::CondBind>(c).a1;
        ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto p__3 = p_;
        auto then_b_4 = then_b;
        auto x_5 = x;
        call_then(start_rust_pat(lx_2, p__3, type_at(lx_2, x_5.span), Holding(Holding::Owned{}), prism_rtl::cat("u", x_5.span.start)), [=](PatOut rust_pat_136227) {
        return ({
            auto po = rust_pat_136227;
            call_then(start_upd_stmts(lx_2, bind_all(env_1, po.binds), then_b_4.stmts), [=](std::tuple<Array<Do>, Env> upd_stmts_136326) {
            return ({
                auto&& _then_dos = upd_stmts_136326;
                auto&& then_dos = std::get<0>(_then_dos);
                call_then(start_value_of(lx_2, env_1, x_5), [=](Vl value_of_136409) { return prism_rtl::finished(Do(Do::DoIfLet{po.pa, own(value_of_136409), then_dos, else_dos})); });
            });
        });
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start UpdIf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Do> start_upd_if(Lx lx, Env env, ast::Cond c, ast::Block then_b, std::optional<ast::Block> else_b_opt) {
    return prism_rtl::make_rc<UpdIf>(lx, env, c, then_b, else_b_opt);
}


/// UpdMatch: unbounded fn Lx, Env, Expr, [Arm] -> Do
Do upd_match(const Lx& lx, const Env& env, const ast::Expr& scrut, const Array<ast::Arm>& arms) {
    auto sv = value_of(lx, env, scrut);
    auto sty = type_at(lx, scrut.span);
    auto arms3 = run_to_end(each_job(check_errors::range0(len(arms)), ({
        auto arms_1 = arms;
        auto lx_2 = lx;
        auto sty_3 = sty;
        auto scrut_4 = scrut;
        auto env_5 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<XArm>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto arms_1_6 = arms_1;
            auto lx_2_6 = lx_2;
            auto sty_3_6 = sty_3;
            auto scrut_4_6 = scrut_4;
            auto env_5_6 = env_5;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto arm = or_(index(arms_1_6, i), dummy_arm());
                call_then(start_arm_pat(lx_2_6, arm.pattern, sty_3_6, Holding(Holding::ByRef{}), prism_rtl::cat("u", scrut_4_6.span.start, "_", i)), [=](PatOut arm_pat_136708) {
                return ({
                    auto po = arm_pat_136708;
                    call_then(start_upd_stmts(lx_2_6, bind_all(env_5_6, po.binds), arm.body.stmts), [=](std::tuple<Array<Do>, Env> upd_stmts_136801) {
                    return ({
                        auto&& _dos = upd_stmts_136801;
                        auto&& dos = std::get<0>(_dos);
                        call_then(start_guard_conds(lx_2_6, bind_all(env_5_6, po.binds), arm.guard), [=](Array<Cc> guard_conds_136894) {
                        return ({
                            auto guarded = append(po.conds, guard_conds_136894);
                            (prism_rtl::finished(XArm{.pat = po.pa, .conds = guarded, .body = Ex(Ex::XBlock{dos, prism_rtl::rc(Ex(Ex::XUnit{}))})}));
                        });
                    });
                    });
                });
                });
            });
            });
            });
        }));
        });
    })));
    })));
    return fold(arms3, false, [&](const bool& f, const XArm& a) { return f || (len(a.conds) > Nat(0u)); })
        ? Do(Do::DoExpr{own(arms_value(ref_(sv), arms3, prism_rtl::cat("'u", scrut.span.start), OutTy(OutTy::OutUnit{})))})
        : Do(Do::DoMatch{ref_(sv), each(arms3, [&](const XArm& a) { return std::tuple{a.pat, arm_dos(a.body)}; })});
}


prism_rtl::Turn<Do> UpdMatch::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& scrut = this->scrut;
    const auto& arms = this->arms;
    auto arms_1 = arms;
    auto env_2 = env;
    auto lx_3 = lx;
    auto scrut_4 = scrut;
    return call_then(start_value_of(lx_3, env_2, scrut_4), [=](Vl value_of_136546) {
        return ({
            auto sv = value_of_136546;
            auto sty = type_at(lx_3, scrut_4.span);
            call_value(each_job(check_errors::range0(len(arms_1)), ({
            auto arms_1_5 = arms_1;
            auto lx_3_5 = lx_3;
            auto sty_5 = sty;
            auto scrut_4_6 = scrut_4;
            auto env_2_6 = env_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<XArm>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto arms_1_5_6 = arms_1_5;
                auto lx_3_5_6 = lx_3_5;
                auto sty_5_6 = sty_5;
                auto scrut_4_6_6 = scrut_4_6;
                auto env_2_6_6 = env_2_6;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    ({
                    auto arm = or_(index(arms_1_5_6, i), dummy_arm());
                    call_then(start_arm_pat(lx_3_5_6, arm.pattern, sty_5_6, Holding(Holding::ByRef{}), prism_rtl::cat("u", scrut_4_6_6.span.start, "_", i)), [=](PatOut arm_pat_136708) {
                    return ({
                        auto po = arm_pat_136708;
                        call_then(start_upd_stmts(lx_3_5_6, bind_all(env_2_6_6, po.binds), arm.body.stmts), [=](std::tuple<Array<Do>, Env> upd_stmts_136801) {
                        return ({
                            auto&& _dos = upd_stmts_136801;
                            auto&& dos = std::get<0>(_dos);
                            call_then(start_guard_conds(lx_3_5_6, bind_all(env_2_6_6, po.binds), arm.guard), [=](Array<Cc> guard_conds_136894) {
                            return ({
                                auto guarded = append(po.conds, guard_conds_136894);
                                (prism_rtl::finished(XArm{.pat = po.pa, .conds = guarded, .body = Ex(Ex::XBlock{dos, prism_rtl::rc(Ex(Ex::XUnit{}))})}));
                            });
                        });
                        });
                    });
                    });
                });
                });
                });
            }));
            });
        })));
        })), [=](Array<XArm> each_136621) {
            return ({
                auto arms3 = each_136621;
                fold(arms3, false, [&](const bool& f, const XArm& a) { return f || (len(a.conds) > Nat(0u)); })
                ? prism_rtl::finished(Do(Do::DoExpr{own(arms_value(ref_(sv), arms3, prism_rtl::cat("'u", scrut_4.span.start), OutTy(OutTy::OutUnit{})))}))
                : prism_rtl::finished(Do(Do::DoMatch{ref_(sv), each(arms3, [&](const XArm& a) { return std::tuple{a.pat, arm_dos(a.body)}; })}));
            });
        });
        });
    });
}


/// `Start UpdMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Do> start_upd_match(Lx lx, Env env, ast::Expr scrut, Array<ast::Arm> arms) {
    return prism_rtl::make_rc<UpdMatch>(lx, env, scrut, arms);
}


/// AllOf: fn [Ex] -> Ex
Ex all_of(const Array<Ex>& xs0) {
    {
        auto&& c0_0 = xs0;
        if (c0_0.size() == 1u) {
            {
                auto&& _c1 = index(c0_0, Nat(0u));
                if (prism_rtl::is_some(_c1)) {
                    auto&& one = prism_rtl::some_of(_c1);
                    return one;
                }
            }
        }
    }
    {
        auto&& xs = xs0;
        return fold(drop(xs, Nat(1u)), or_(index(xs, Nat(0u)), Ex(Ex::XBool{true})), [&](const Ex& acc, const Ex& x) { return Ex(Ex::XBin{Text::lit("&&"), prism_rtl::rc(acc), prism_rtl::rc(x)}); });
    }
}


/// ArmDos: fn Ex -> [Do]
Array<Do> arm_dos(const Ex& ex0) {
    if (prism_rtl::is<Ex::XBlock>(ex0)) {
        auto&& dos = prism_rtl::as<Ex::XBlock>(ex0).a0;
        return dos;
    }
    {
        auto&& x = ex0;
        return Array(std::vector{Do(Do::DoExpr{x})});
    }
}


/// GuardConds: unbounded fn Lx, Env, ?Expr -> [Cc]
Array<Cc> guard_conds(const Lx& lx, const Env& env, const std::optional<ast::Expr>& opt2) {
    if (prism_rtl::is_some(opt2)) {
        auto&& ge = prism_rtl::some_of(opt2);
        return Array(std::vector{Cc(Cc::CcIf{as_bool(value_of(lx, env, ge))})});
    }
    if (prism_rtl::is_none(opt2)) {
        return Array<Cc>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Cc>> GuardConds::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& opt2 = this->opt2;
    return ({
        prism_rtl::is_some(opt2) ? ({
        auto&& ge = prism_rtl::some_of(opt2);
        ({
        auto env_1 = env;
        auto ge_2 = ge;
        auto lx_3 = lx;
        call_then(start_value_of(lx_3, env_1, ge_2), [=](Vl value_of_137736) { return prism_rtl::finished(Array(std::vector{Cc(Cc::CcIf{as_bool(value_of_137736)})})); });
    });
    })
        : prism_rtl::is_none(opt2) ? prism_rtl::finished(Array<Cc>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start GuardConds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Cc>> start_guard_conds(Lx lx, Env env, std::optional<ast::Expr> opt2) {
    return prism_rtl::make_rc<GuardConds>(lx, env, opt2);
}


/// PlaceOf: unbounded fn Lx, Env, Expr -> Ex
Ex place_of(const Lx& lx, const Env& env, const ast::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
        auto&& _m = prelude::get(env->names, check_env::sname_key(n));
        if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
            auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
            return rs;
        }
        {
            return Ex(Ex::XVar{snake(check_env::sname_key(n))});
        }
    }
    if (prism_rtl::is<ast::ExprKind::EField>(_m)) {
        auto&& r = prism_rtl::as<ast::ExprKind::EField>(_m).a0;
        auto&& name = prism_rtl::as<ast::ExprKind::EField>(_m).a2;
        return Ex(Ex::XField{prism_rtl::rc(place_of(lx, env, r)), snake(name.name)});
    }
    if (prism_rtl::is<ast::ExprKind::EIndex>(_m)) {
        auto&& r = prism_rtl::as<ast::ExprKind::EIndex>(_m).a0;
        auto&& k = prism_rtl::as<ast::ExprKind::EIndex>(_m).a1;
        auto rt = out_ty_of(lx, peel(type_at(lx, r.span)));
        auto f = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is<OutTy::OutMap>(rt)) {
                _v.set(Text::lit("at_mut_map"));
                goto _done;
            }
            {
                _v.set(Text::lit("at_mut"));
                goto _done;
            }
        _done:
            _v.take();
        });
        return Ex(Ex::XDeref{prism_rtl::rc(Ex(Ex::XCall{f, Array(std::vector{Ex(Ex::XRefMut{prism_rtl::rc(place_of(lx, env, r))}), argument(lx, env, k)})}))});
    }
    if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        return place_of(lx, env, x);
    }
    {
        return refusal(Text::lit("a reference path this back end does not lower"));
    }
}


prism_rtl::Turn<Ex> PlaceOf::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<ast::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
        ({
        auto&& _m = prelude::get(env->names, check_env::sname_key(n));
        prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m)) ? ({
        auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
        prism_rtl::finished(rs);
    })
        : prism_rtl::finished(Ex(Ex::XVar{snake(check_env::sname_key(n))}));
    });
    })
        : prism_rtl::is<ast::ExprKind::EField>(_m) ? ({
        auto&& r = prism_rtl::as<ast::ExprKind::EField>(_m).a0;
        auto&& name = prism_rtl::as<ast::ExprKind::EField>(_m).a2;
        ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto name_3 = name;
        auto r_4 = r;
        call_then(start_place_of(lx_2, env_1, r_4), [=](Ex place_of_138104) { return prism_rtl::finished(Ex(Ex::XField{prism_rtl::rc(place_of_138104), snake(name_3.name)})); });
    });
    })
        : prism_rtl::is<ast::ExprKind::EIndex>(_m) ? ({
        auto&& r = prism_rtl::as<ast::ExprKind::EIndex>(_m).a0;
        auto&& k = prism_rtl::as<ast::ExprKind::EIndex>(_m).a1;
        ({
        auto env_1 = env;
        auto k_2 = k;
        auto lx_3 = lx;
        auto r_4 = r;
        call_then(start_out_ty_of(lx_3, peel(type_at(lx_3, r_4.span))), [=](OutTy out_ty_of_138177) {
        return ({
            auto rt = out_ty_of_138177;
            auto f = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                if (prism_rtl::is<OutTy::OutMap>(rt)) {
                    _v.set(Text::lit("at_mut_map"));
                    goto _done;
                }
                {
                    _v.set(Text::lit("at_mut"));
                    goto _done;
                }
            _done:
                _v.take();
            });
            call_then(start_place_of(lx_3, env_1, r_4), [=](Ex place_of_138359) { return call_then(start_argument(lx_3, env_1, k_2), [=](Ex argument_138382) { return prism_rtl::finished(Ex(Ex::XDeref{prism_rtl::rc(Ex(Ex::XCall{f, Array(std::vector{Ex(Ex::XRefMut{prism_rtl::rc(place_of_138359)}), argument_138382})}))})); }); });
        });
    });
    });
    })
        : prism_rtl::is<ast::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(PlaceOf(lx, env, x)));
    })
        : prism_rtl::finished(refusal(Text::lit("a reference path this back end does not lower")));
    });
}


/// `Start PlaceOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ex> start_place_of(Lx lx, Env env, ast::Expr e) {
    return prism_rtl::make_rc<PlaceOf>(lx, env, e);
}


/// Assign: unbounded fn Lx, Env, Expr, Ex -> Do
Do assign(const Lx& lx, const Env& env, const ast::Expr& target, const Ex& v_) {
    auto&& _m = target.kind;
    if (prism_rtl::is<ast::ExprKind::EIndex>(_m)) {
        auto&& r = prism_rtl::as<ast::ExprKind::EIndex>(_m).a0;
        auto&& k = prism_rtl::as<ast::ExprKind::EIndex>(_m).a1;
        auto rt = out_ty_of(lx, peel(type_at(lx, r.span)));
        auto f = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is<OutTy::OutMap>(rt)) {
                _v.set(Text::lit("set_key"));
                goto _done;
            }
            {
                _v.set(Text::lit("set_index"));
                goto _done;
            }
        _done:
            _v.take();
        });
        return Do(Do::DoExpr{Ex(Ex::XCall{f, Array(std::vector{Ex(Ex::XRefMut{prism_rtl::rc(place_of(lx, env, r))}), argument(lx, env, k), v_})})});
    }
    if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        return assign(lx, env, x, v_);
    }
    {
        return Do(Do::DoAssign{place_of(lx, env, target), v_});
    }
}


prism_rtl::Turn<Do> Assign::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& target = this->target;
    const auto& v_ = this->v_;
    return ({
        auto&& _m = target.kind;
        prism_rtl::is<ast::ExprKind::EIndex>(_m) ? ({
        auto&& r = prism_rtl::as<ast::ExprKind::EIndex>(_m).a0;
        auto&& k = prism_rtl::as<ast::ExprKind::EIndex>(_m).a1;
        ({
        auto env_1 = env;
        auto k_2 = k;
        auto lx_3 = lx;
        auto r_4 = r;
        auto v__5 = v_;
        call_then(start_out_ty_of(lx_3, peel(type_at(lx_3, r_4.span))), [=](OutTy out_ty_of_138790) {
        return ({
            auto rt = out_ty_of_138790;
            auto f = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                if (prism_rtl::is<OutTy::OutMap>(rt)) {
                    _v.set(Text::lit("set_key"));
                    goto _done;
                }
                {
                    _v.set(Text::lit("set_index"));
                    goto _done;
                }
            _done:
                _v.take();
            });
            call_then(start_place_of(lx_3, env_1, r_4), [=](Ex place_of_138972) { return call_then(start_argument(lx_3, env_1, k_2), [=](Ex argument_138995) { return prism_rtl::finished(Do(Do::DoExpr{Ex(Ex::XCall{f, Array(std::vector{Ex(Ex::XRefMut{prism_rtl::rc(place_of_138972)}), argument_138995, v__5})})})); }); });
        });
    });
    });
    })
        : prism_rtl::is<ast::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(Assign(lx, env, x, v_)));
    })
        : ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto target_3 = target;
        auto v__4 = v_;
        call_then(start_place_of(lx_2, env_1, target_3), [=](Ex place_of_139082) { return prism_rtl::finished(Do(Do::DoAssign{place_of_139082, v__4})); });
    });
    });
}


/// `Start Assign, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Do> start_assign(Lx lx, Env env, ast::Expr target, Ex v_) {
    return prism_rtl::make_rc<Assign>(lx, env, target, v_);
}


/// BoundOf: fn Lx, Text -> [Text]
Array<Text> bound_of(const Lx& lx, const Text& text1) {
    {
        auto&& c0_1 = text1;
        if (c0_1 == Text::lit("Prelude.Eq")) {
            return Array(std::vector{Text::lit("PartialEq")});
        }
    }
    {
        auto&& c1_1 = text1;
        if (c1_1 == Text::lit("Prelude.Ord")) {
            return Array(std::vector{Text::lit("PartialOrd")});
        }
    }
    {
        auto&& c2_1 = text1;
        if (c2_1 == Text::lit("Prelude.Show")) {
            return Array(std::vector{Text::lit("Show")});
        }
    }
    {
        auto&& c3_1 = text1;
        if (c3_1 == Text::lit("Prelude.Num")) {
            return Array(std::vector{Text::lit("Num")});
        }
    }
    {
        auto&& c4_1 = text1;
        if (c4_1 == Text::lit("Prelude.Pod")) {
            return Array(std::vector{Text::lit("ToPod"), Text::lit("FromPod")});
        }
    }
    {
        auto&& cls = text1;
        auto&& _m = prelude::get(lx.g.traits, cls);
        if (prism_rtl::is_some(_m)) {
            auto&& tr = prism_rtl::some_of(_m);
            return Array(std::vector{path_in(lx, tr.home, camel(check_types::bare_name(cls)))});
        }
        if (prism_rtl::is_none(_m)) {
            return Array<Text>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
}


/// SchemeGenerics: fn Lx, Scheme -> [((Text, [Text]))]
Array<std::tuple<Text, Array<Text>>> scheme_generics(const Lx& lx, const check_types::Scheme& sc) {
    return each(sc.qs, [&](const Text& q) {
        return ({
            auto bs = fold(sc.bounds, Array(std::vector{Text::lit("Clone")}), [&](const Array<Text>& acc, const std::tuple<Text, Text>& _p1) {
                auto&& v_ = std::get<0>(_p1);
                auto&& cls = std::get<1>(_p1);
                return v_ == q ? check_types::union_texts(acc, bound_of(lx, cls)) : acc;
            });
            std::tuple{camel(q), bs};
        });
    });
}


/// ParamNames: fn Lx, [FnClause], [OutTy] -> [((Text, Bool))]
Array<std::tuple<Text, bool>> param_names(const Lx& lx, const Array<ast::FnClause>& clauses, const Array<OutTy>& pts) {
    return each(check_errors::range0(len(pts)), [&](const Nat& i) {
        return ({
            auto names = each(clauses, [&](const ast::FnClause& c) { return plain_binder(lx, or_(index(c.params, i), dummy_pat())); });
            auto first_ = or_(index(names, Nat(0u)), Text::lit(""));
            auto same = (first_ != Text::lit("")) && fold(names, true, [&](const bool& ok, const Text& n) { return ok && (n == first_); });
            same
            ? std::tuple{local_name(lx, first_), false}
            : std::tuple{param_word(or_(index(pts, i), OutTy(OutTy::OutUnit{})), i), true};
        });
    });
}


/// PlainBinder: fn Lx, Pattern -> Text
Text plain_binder(const Lx& lx, const ast::Pattern_& p_) {
    auto&& _m = p_.kind;
    if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
        auto [qk_opt, why] = check_env::resolve_value(lx.g, lx.home, n);
        auto is_ctor = ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& qk = prism_rtl::some_of(qk_opt);
                _v.set(check_env::has_key(lx.g.ctors, qk) && (check_env::is_upper_text(base(check_env::sname_key(n))) || is_unit_ctor(lx, qk)));
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return is_ctor ? Text::lit("") : check_env::sname_key(n);
    }
    if (prism_rtl::is<ast::PatternKind::PGroup>(_m)) {
        auto&& q = prism_rtl::as<ast::PatternKind::PGroup>(_m).a0;
        return plain_binder(lx, q);
    }
    {
        return Text::lit("");
    }
}


/// ParamWord: fn OutTy, Nat -> Text
Text param_word(const OutTy& t, const Nat& i) {
    auto base_ = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<OutTy::OutNamed>(t)) {
            auto&& n = prism_rtl::as<OutTy::OutNamed>(t).a0;
            _v.set(snake(or_(lexer::last(split(n, Text::lit("::"))), Text::lit("arg"))));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutText>(t)) {
            _v.set(Text::lit("text"));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutNat>(t)) {
            _v.set(Text::lit("n"));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutInt>(t)) {
            _v.set(Text::lit("i"));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutArray>(t)) {
            _v.set(Text::lit("xs"));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutMap>(t)) {
            _v.set(Text::lit("map"));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutOpt>(t)) {
            _v.set(Text::lit("opt"));
            goto _done;
        }
        {
            _v.set(Text::lit("arg"));
            goto _done;
        }
    _done:
        _v.take();
    });
    return prism_rtl::cat(base_, i);
}


/// ClausesBody: unbounded fn Lx, Env, [FnClause], [((Text, Bool))], [Ty], (fn Lx, Env, FnBody -> Ex), Text, OutTy -> Ex
Ex clauses_body(const Lx& lx, const Env& env, const Array<ast::FnClause>& clauses, const Array<std::tuple<Text, bool>>& names, const Array<check_types::Ty>& ptys, const prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Lx, Env, ast::FnBody>)>& body_fn, const Text& label, const OutTy& t) {
    auto env1 = run_to_end(fold_job(check_errors::range0(len(names)), env, ({
        auto names_1 = names;
        auto lx_2 = lx;
        auto clauses_3 = clauses;
        auto ptys_4 = ptys;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Env>(std::tuple<Env, Nat>)>>(prism_rtl::rc([=](std::tuple<Env, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto names_1_5 = names_1;
            auto lx_2_5 = lx_2;
            auto clauses_3_5 = clauses_3;
            auto ptys_4_5 = ptys_4;
            entered(once_job([=]() {
            return ({
                auto en = p0;
                auto i = p1;
                ({
                auto [rs, matched] = or_(index(names_1_5, i), std::tuple{Text::lit(""), true});
                matched
                ? prism_rtl::finished(en)
                : call_then(start_out_ty_of(lx_2_5, peel(or_(index(ptys_4_5, i), check_types::Ty(check_types::Ty::TyErr{})))), [=](OutTy out_ty_of_142267) { return prism_rtl::finished(bind(en, plain_binder(lx_2_5, or_(index(or_(index(clauses_3_5, Nat(0u)), dummy_clause()).params, i), dummy_pat())), Bn(Bn::BnLocal{Ex(Ex::XVar{rs}), Holding(Holding::ByRef{}), out_ty_of_142267}))); });
            });
            });
        }));
        });
    })));
    })));
    auto scrut_ix = filter(check_errors::range0(len(names)), [&](const Nat& i) {
        return ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = index(names, i);
            if (prism_rtl::is_some(_m) && std::get<1>(prism_rtl::some_of(_m))) {
                _v.set(true);
                goto _done;
            }
            {
                _v.set(false);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return len(scrut_ix) == Nat(0u)
        ? ({
        auto c = or_(index(clauses, Nat(0u)), dummy_clause());
        run_to_end(body_fn(std::tuple{lx, env1, c.body}));
    })
        : ({
        auto scrut = ({
            __label__ _done;
            prism_rtl::Slot<Ex> _v;
            {
                auto&& m142564_0 = scrut_ix;
                if (m142564_0.size() == 1u) {
                    {
                        auto&& _c1 = index(m142564_0, Nat(0u));
                        if (prism_rtl::is_some(_c1)) {
                            auto&& i = prism_rtl::some_of(_c1);
                            _v.set(Ex(Ex::XVar{or_(index(each(names, [&](const std::tuple<Text, bool>& _p0) {
                                auto&& n = std::get<0>(_p0);
                                return n;
                            }), i), Text::lit("arg"))}));
                            goto _done;
                        }
                    }
                }
            }
            {
                _v.set(Ex(Ex::XTuple{each(scrut_ix, [&](const Nat& i) {
                    return Ex(Ex::XVar{or_(index(each(names, [&](const std::tuple<Text, bool>& _p0) {
                        auto&& n = std::get<0>(_p0);
                        return n;
                    }), i), Text::lit("arg"))});
                })}));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto arms = run_to_end(each_job(check_errors::range0(len(clauses)), ({
            auto clauses_1 = clauses;
            auto scrut_ix_2 = scrut_ix;
            auto lx_3 = lx;
            auto ptys_4 = ptys;
            auto label_5 = label;
            auto body_fn_6 = body_fn;
            auto env1_7 = env1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<XArm>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto clauses_1_8 = clauses_1;
                auto scrut_ix_2_8 = scrut_ix_2;
                auto lx_3_8 = lx_3;
                auto ptys_4_8 = ptys_4;
                auto label_5_8 = label_5;
                auto body_fn_6_8 = body_fn_6;
                auto env1_7_8 = env1_7;
                entered(once_job([=]() {
                return ({
                    auto ci = p0;
                    ({
                    auto c = or_(index(clauses_1_8, ci), dummy_clause());
                    call_value(each_job(scrut_ix_2_8, ({
                    auto lx_3_8_8 = lx_3_8;
                    auto c_8 = c;
                    auto ptys_4_8_9 = ptys_4_8;
                    auto label_5_8_9 = label_5_8;
                    auto ci_9 = ci;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                    return ({
                        auto lx_3_8_8_10 = lx_3_8_8;
                        auto c_8_10 = c_8;
                        auto ptys_4_8_9_10 = ptys_4_8_9;
                        auto label_5_8_9_10 = label_5_8_9;
                        auto ci_9_10 = ci_9;
                        entered(once_job([=]() {
                        return ({
                            auto i = p0;
                            (prism_rtl::more(prism_rtl::rc(RustPat(lx_3_8_8_10, or_(index(c_8_10.params, i), dummy_pat()), or_(index(ptys_4_8_9_10, i), check_types::Ty(check_types::Ty::TyErr{})), Holding(Holding::ByRef{}), prism_rtl::cat(label_5_8_9_10, ci_9_10, "_", i)))));
                        });
                    }));
                    });
                })));
                })), [=](Array<PatOut> each_142879) {
                    return ({
                        auto pos = each_142879;
                        auto pa = ({
                            __label__ _done;
                            prism_rtl::Slot<Pa> _v;
                            {
                                auto&& m143005_0 = pos;
                                if (m143005_0.size() == 1u) {
                                    {
                                        auto&& _c1 = index(m143005_0, Nat(0u));
                                        if (prism_rtl::is_some(_c1)) {
                                            auto&& o = prism_rtl::some_of(_c1);
                                            _v.set(o.pa);
                                            goto _done;
                                        }
                                    }
                                }
                            }
                            {
                                _v.set(Pa(Pa::PaTuple{each(pos, [&](const PatOut& o) { return o.pa; })}));
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                        auto conds = fold(pos, Array<Cc>{}, [&](const Array<Cc>& acc, const PatOut& o) { return append(acc, o.conds); });
                        auto binds = fold(pos, Array<std::tuple<Text, Bn>>{}, [&](const Array<std::tuple<Text, Bn>>& acc, const PatOut& o) { return append(acc, o.binds); });
                        call_value(body_fn_6_8(std::tuple{lx_3_8, bind_all(env1_7_8, binds), c.body}), [=](Ex body_143285) { return prism_rtl::finished(XArm{.pat = pa, .conds = conds, .body = body_143285}); });
                    });
                });
                });
                });
            }));
            });
        })));
        })));
        own(arms_value(scrut, arms, prism_rtl::cat("'", label), t));
    });
}

}  // namespace crate::lower
