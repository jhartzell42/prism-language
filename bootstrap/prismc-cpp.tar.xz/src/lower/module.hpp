// The module `Lower`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <lower/types.hpp>
#include "elem.types.hpp"
#include <check/env/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace lower {

Text place_key_f(const Lx& lx_p0, const crate::syntax::Range& r_p1);

crate::check::types::Ty type_at_f(const Lx& lx_p0, const crate::syntax::Range& r_p1);

crate::check::types::Ty binder_ty_f(const Lx& lx_p0, const crate::syntax::Range& r_p1);

crate::check::types::Ty subst_ty_f(const Lx& lx_p0, const crate::check::types::Ty& t_p1);

crate::check::types::Ty subst_ty_in_f(const Lx& lx_p0, const crate::check::types::Ty& t_p1);

crate::check::types::Col inst_col_f(const Lx& lx_p0, const crate::check::types::Col& col1);

bool is_quant_col_f(const Lx& lx_p0, const crate::check::types::Col& col1);

std::tuple<Map<Text, crate::check::types::Ty>, Map<Text, crate::check::typed::AppNote>, Map<Text, crate::check::types::Ty>, Map<Text, Array<crate::check::typed::ImplNote>>> typed_tables_f(const crate::check::typed::TProgram& tp_p0);

Array<Text> rust_keywords_p();

Text base_f(const Text& name_p0);

Text snake_f(const Text& name_p0);

Text lower_char_f(const Text& c_p0);

Text camel_f(const Text& name_p0);

Array<Text> runtime_names_p();

Text rust_mod_name_f(const Text& m_p0);

Text mod_segment_f(const Text& s_p0);

Array<Text> cpp_keywords_p();

Text path_in_f(const Lx& lx_p0, const Text& owner_p1, const Text& name_p2);

Text prelude_path_f(const Lx& lx0, const Text& name_p0);

Text helper_f(const Text& n_p0);

Map<Text, Text> value_names_f(const crate::check::env::G& g_p0);

prism_rtl::JobRef<Map<Text, Text>> start_value_names_f(crate::check::env::G g_p0);

Text global_base_f(const Text& k_p0);

prism_rtl::JobRef<Text> start_global_base_f(Text k_p0);

Text field_spell_f(const Text& text0, const Text& fname_p0, const crate::check::types::Ty& ft_p1);

prism_rtl::JobRef<Text> start_field_spell_f(Text text0, Text fname_p0, crate::check::types::Ty ft_p1);

Text sigil_or_kind_f(const Text& name_p0, const crate::check::types::Ty& t_p1);

Text global_letter_f(const crate::check::env::G& g_p0, const Text& k_p1);

Map<Text, bool> global_names_f(const crate::check::env::G& g_p0);

prism_rtl::JobRef<Map<Text, bool>> start_global_names_f(crate::check::env::G g_p0);

Text local_name_f(const Lx& lx_p0, const Text& nkey_p1);

Text local_name_at_f(const Lx& lx_p0, const Text& nkey_p1, const crate::syntax::Range& span_p2);

prism_rtl::JobRef<Text> start_local_name_at_f(Lx lx_p0, Text nkey_p1, crate::syntax::Range span_p2);

Text local_base_f(const Text& nkey_p0);

prism_rtl::JobRef<Text> start_local_base_f(Text nkey_p0);

Text trim_underscores_f(const Text& t_p0);

prism_rtl::JobRef<Text> start_trim_underscores_f(Text t_p0);

Text kind_letter_f(const crate::check::types::Ty& t_p0);

Text base32_f(const Nat& n_p0);

prism_rtl::JobRef<Text> start_base32_f(Nat n_p0);

Text base_key_f(const Text& k_p0);

Text value_name_f(const Text& k_p0, const Nat& count_p1);

Text sigil_word_f(const Text& text0);

Text value_path_f(const Lx& lx_p0, const Text& qk_p1);

Text owner_of_f(const Text& qk_p0);

Text tag_struct_f(const Text& tn_p0);

}  // namespace lower


namespace lower {

/// The step machine of `ValueNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ValueNames: unbounded fn G -> (Text ==> Text)
struct ValueNames : prism_rtl::Job<Map<Text, Text>> {
    crate::check::env::G g_p0;
    ValueNames(crate::check::env::G g_p0) : g_p0(std::move(g_p0)) {}
    prism_rtl::Turn<Map<Text, Text>> cycle() const override;
};


/// The step machine of `GlobalBase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GlobalBase: unbounded fn Text -> Text
struct GlobalBase : prism_rtl::Job<Text> {
    Text k_p0;
    GlobalBase(Text k_p0) : k_p0(std::move(k_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `FieldSpell`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FieldSpell: unbounded fn Text, Text, Ty -> Text
struct FieldSpell : prism_rtl::Job<Text> {
    Text text0;
    Text fname_p0;
    crate::check::types::Ty ft_p1;
    FieldSpell(Text text0, Text fname_p0, crate::check::types::Ty ft_p1) : text0(std::move(text0)), fname_p0(std::move(fname_p0)), ft_p1(std::move(ft_p1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `GlobalNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GlobalNames: unbounded fn G -> (Text ==> Bool)
struct GlobalNames : prism_rtl::Job<Map<Text, bool>> {
    crate::check::env::G g_p0;
    GlobalNames(crate::check::env::G g_p0) : g_p0(std::move(g_p0)) {}
    prism_rtl::Turn<Map<Text, bool>> cycle() const override;
};


/// The step machine of `LocalNameAt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LocalNameAt: unbounded fn Lx, Text, Range -> Text
struct LocalNameAt : prism_rtl::Job<Text> {
    Lx lx_p0;
    Text nkey_p1;
    crate::syntax::Range span_p2;
    LocalNameAt(Lx lx_p0, Text nkey_p1, crate::syntax::Range span_p2) : lx_p0(std::move(lx_p0)), nkey_p1(std::move(nkey_p1)), span_p2(std::move(span_p2)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `LocalBase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LocalBase: unbounded fn Text -> Text
struct LocalBase : prism_rtl::Job<Text> {
    Text nkey_p0;
    LocalBase(Text nkey_p0) : nkey_p0(std::move(nkey_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `TrimUnderscores`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TrimUnderscores: unbounded fn Text -> Text
struct TrimUnderscores : prism_rtl::Job<Text> {
    Text t_p0;
    TrimUnderscores(Text t_p0) : t_p0(std::move(t_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Base32`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Base32: unbounded fn Nat -> Text
struct Base32 : prism_rtl::Job<Text> {
    Nat n_p0;
    Base32(Nat n_p0) : n_p0(std::move(n_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


}  // namespace lower

}  // namespace crate
