// The module `Lower`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <lower/types.hpp>
#include "elem.types.hpp"
#include <check/env/types.hpp>
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace lower {

Text place_key(const Lx& lx_p0, const crate::syntax::Range& r_p1);

crate::check::types::Ty type_at(const Lx& lx_p0, const crate::syntax::Range& r_p1);

crate::check::types::Ty binder_ty(const Lx& lx_p0, const crate::syntax::Range& r_p1);

crate::check::types::Ty subst_ty(const Lx& lx_p0, const crate::check::types::Ty& t_p1);

crate::check::types::Ty subst_ty_in(const Lx& lx_p0, const crate::check::types::Ty& t_p1);

crate::check::types::Col inst_col(const Lx& lx_p0, const crate::check::types::Col& col1);

bool is_quant_col(const Lx& lx_p0, const crate::check::types::Col& col1);

std::tuple<Map<Text, crate::check::types::Ty>, Map<Text, crate::check::typed::AppNote>, Map<Text, crate::check::types::Ty>, Map<Text, Array<crate::check::typed::ImplNote>>> typed_tables(const crate::check::typed::TProgram& tp_p0);

Array<Text> rust_keywords();

Text base(const Text& name_p0);

Text snake(const Text& name_p0);

Text lower_char(const Text& c_p0);

Text camel(const Text& name_p0);

Array<Text> runtime_names();

Map<Text, bool> runtime_fns();

Text unclash(const Text& n_p0);

Text rust_mod_name(const Text& m_p0);

Text mod_segment(const Text& s_p0);

Array<Text> cpp_keywords();

Text path_in(const Lx& lx_p0, const Text& owner_p1, const Text& name_p2);

Text prelude_path(const Lx& lx_p0, const Text& name_p1);

Map<Text, Text> value_names(const crate::check::env::G& g_p0);

Map<Text, bool> global_names(const crate::check::env::G& g_p0);

Text local_name(const Lx& lx_p0, const Text& nkey_p1);

Text local_name_at(const Lx& lx_p0, const Text& nkey_p1, const crate::syntax::Range& span_p2);

prism_rtl::JobRef<Text> start_local_name_at(Lx lx_p0, Text nkey_p1, crate::syntax::Range span_p2);

Text local_base(const Text& nkey_p0);

prism_rtl::JobRef<Text> start_local_base(Text nkey_p0);

Text trim_underscores(const Text& t_p0);

prism_rtl::JobRef<Text> start_trim_underscores(Text t_p0);

Text kind_letter(const crate::check::types::Ty& t_p0);

Text base32(const Nat& n_p0);

prism_rtl::JobRef<Text> start_base32(Nat n_p0);

Text base_key(const Text& k_p0);

Text value_name(const Text& k_p0, const Nat& count_p1);

Text sigil_word(const Text& text0);

Text value_path(const Lx& lx_p0, const Text& qk_p1);

Text owner_of(const Text& qk_p0);

Text tag_struct(const Text& tn_p0);

}  // namespace lower


namespace lower {

/// The step machine of `LocalNameAt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LocalNameAt: unbounded fn Lx, Text, Range -> Text
struct LocalNameAt : prism_rtl::Job<Text> {
    Lx lx_p0;
    Text nkey_p1;
    crate::syntax::Range span_p2;
    LocalNameAt(Lx lx_p0, Text nkey_p1, crate::syntax::Range span_p2) : lx_p0(std::move(lx_p0)), nkey_p1(std::move(nkey_p1)), span_p2(std::move(span_p2)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `LocalBase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LocalBase: unbounded fn Text -> Text
struct LocalBase : prism_rtl::Job<Text> {
    Text nkey_p0;
    LocalBase(Text nkey_p0) : nkey_p0(std::move(nkey_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `TrimUnderscores`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TrimUnderscores: unbounded fn Text -> Text
struct TrimUnderscores : prism_rtl::Job<Text> {
    Text t_p0;
    TrimUnderscores(Text t_p0) : t_p0(std::move(t_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Base32`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Base32: unbounded fn Nat -> Text
struct Base32 : prism_rtl::Job<Text> {
    Nat n_p0;
    Base32(Nat n_p0) : n_p0(std::move(n_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


}  // namespace lower

}  // namespace crate
