// The module `Lower`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include <lower/types.hpp>
#include "elem.types.hpp"
#include <lower/node_/types.hpp>
#include <syntax/types.hpp>
#include <check/env/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/passes/types.hpp>
#include <check/shrink/types.hpp>
#include <check/typed/types.hpp>
#include <check/types/types.hpp>
#include <lower/model/types.hpp>
#include <syntax/lexer/types.hpp>

namespace crate {

using namespace prelude;

namespace lower {

Text place_key(const Lx& lx, const crate::syntax::Range& r);

crate::check::types::Ty type_at(const Lx& lx, const crate::syntax::Range& r);

crate::check::types::Ty binder_ty(const Lx& lx, const crate::syntax::Range& r);

crate::check::types::Ty subst_ty(const Lx& lx, const crate::check::types::Ty& t);

crate::check::types::Ty subst_ty_in(const Lx& lx, const crate::check::types::Ty& t);

crate::check::types::Col inst_col(const Lx& lx, const crate::check::types::Col& col1);

bool is_quant_col(const Lx& lx, const crate::check::types::Col& col1);

std::tuple<Map<Text, crate::check::types::Ty>, Map<Text, crate::check::typed::AppNote>, Map<Text, crate::check::types::Ty>, Map<Text, Array<crate::check::typed::ImplNote>>> typed_tables(const crate::check::typed::TProgram& tp);

Array<Text> rust_keywords();

Text base(const Text& name);

Text snake(const Text& name);

Text lower_char(const Text& c);

Text camel(const Text& name);

Array<Text> runtime_names();

Text rust_mod_name(const Text& m);

Text path_in(const Lx& lx, const Text& owner, const Text& name);

Text prelude_path(const Lx& lx, const Text& name);

Map<Text, Text> value_names(const crate::check::env::G& g);

Map<Text, bool> global_names(const crate::check::env::G& g);

Text local_name(const Lx& lx, const Text& nkey);

Text base_key(const Text& k);

Text value_name(const Text& k, const Nat& count);

Text sigil_word(const Text& text0);

Text value_path(const Lx& lx, const Text& qk);

Text owner_of(const Text& qk);

Text tag_struct(const Text& tn);

crate::lower::model::OutTy out_ty_of(const Lx& lx, const crate::check::types::Ty& t);

prism_rtl::JobRef<crate::lower::model::OutTy> start_out_ty_of(Lx lx, crate::check::types::Ty t);

crate::lower::model::OutTy blueprint_ty();

crate::lower::model::OutTy elem_ty();

crate::lower::model::OutTy answer_ty_value();

crate::lower::model::OutTy host_of_ty();

bool has_blueprint(const crate::check::types::Ty& t);

crate::check::types::Ty event_param(const crate::check::types::Ty& t);

crate::check::types::Ty job_param(const crate::check::types::Ty& ty0);

crate::lower::model::OutTy rust_ty_of_params(const Lx& lx, const Array<crate::check::types::Ty>& ps);

prism_rtl::JobRef<crate::lower::model::OutTy> start_rust_ty_of_params(Lx lx, Array<crate::check::types::Ty> ps);

crate::lower::model::OutTy named_ty(const Lx& lx, const Text& n, const Array<crate::lower::model::OutTy>& args);

prism_rtl::JobRef<crate::lower::model::OutTy> start_named_ty(Lx lx, Text n, Array<crate::lower::model::OutTy> args);

crate::check::types::Ty peel(const crate::check::types::Ty& t);

crate::check::types::Ty out_of(const crate::check::types::Ty& t);

Layer layer_of(const crate::check::types::Ty& t);

Map<Text, Array<bool>> layouts(const crate::check::env::G& g);

prism_rtl::JobRef<Map<Text, Array<bool>>> start_layouts(crate::check::env::G g);

bool reaches(const crate::check::env::G& g, const crate::check::types::Ty& t, const Text& target, const Array<Text>& seen);

prism_rtl::JobRef<bool> start_reaches(crate::check::env::G g, crate::check::types::Ty t, Text target, Array<Text> seen);

bool rc_field(const Lx& lx, const Text& ctor, const Nat& i);

bool floaty(const crate::check::env::G& g, const crate::check::types::Ty& t, const Array<Text>& seen);

prism_rtl::JobRef<bool> start_floaty(crate::check::env::G g, crate::check::types::Ty t, Array<Text> seen);

bool podable(const crate::lower::model::OutTy& t);

prism_rtl::JobRef<bool> start_podable(crate::lower::model::OutTy t);

Env empty_env();

Text name_key_at(const Lx& lx, const Env& env, const crate::syntax::SName& n, const crate::syntax::Range& span);

Array<Text> with_instances(const Env& env, const Array<Text>& names);

Env bind_span(const Env& env, const Text& nkey, const Vl& v_);

Env bind(const Env& env, const Text& name, const Bn& b);

crate::lower::model::OutTy value_ty(const Vl& vl0);

Vl local_place(const crate::lower::model::Ex& x, const Holding& mode, const crate::lower::model::OutTy& t);

Text place_stem(const crate::lower::model::Ex& x);

bool on_self(const crate::lower::model::Ex& x);

std::optional<crate::lower::model::Ex> through_parent(const crate::lower::model::Ex& x);

crate::lower::model::Ex own(const Vl& vl0);

crate::lower::model::Ex ref_(const Vl& vl0);

crate::lower::model::Ex copy(const Vl& vl0);

bool is_copy(const crate::lower::model::OutTy& t);

crate::lower::model::Ex as_bool(const Vl& v_);

Text escape(const Text& t);

Text char_escape(const Text& text0);

crate::lower::model::Ex number(const crate::lower::model::OutTy& t, const Text& digits, const bool& neg);

Text decimal_digits(const Text& d);

Vl literal_value(const Lx& lx, const Env& env, const crate::syntax::Literal& l, const crate::syntax::Range& span, const bool& neg);

prism_rtl::JobRef<Vl> start_literal_value(Lx lx, Env env, crate::syntax::Literal l, crate::syntax::Range span, bool neg);

Vl text_value(const Lx& lx, const Env& env, const Array<crate::syntax::TextSeg>& segs);

prism_rtl::JobRef<Vl> start_text_value(Lx lx, Env env, Array<crate::syntax::TextSeg> segs);

bool is_plain_seg(const crate::syntax::TextSeg& text_seg0);

Text plain_text(const crate::syntax::TextSeg& text_seg0);

crate::lower::model::Ex seg_ex(const Lx& lx, const Env& env, const crate::syntax::TextSeg& text_seg2);

prism_rtl::JobRef<crate::lower::model::Ex> start_seg_ex(Lx lx, Env env, crate::syntax::TextSeg text_seg2);

crate::lower::model::Ex shown_part(const Vl& v_);

crate::lower::model::Ex refusal(const Text& what);

crate::lower::model::Ex try_of(const crate::lower::model::Ex& x);

bool is_named_place(const crate::lower::model::Ex& x);

Text lowering_refusal();

crate::lower::model::Do refusal_do(const Text& what);

Vl value_of(const Lx& lx, const Env& env, const crate::syntax::Expr& e);

prism_rtl::JobRef<Vl> start_value_of(Lx lx, Env env, crate::syntax::Expr e);

Vl unbound_value_of(const Lx& lx, const Env& env, const crate::syntax::Expr& e);

prism_rtl::JobRef<Vl> start_unbound_value_of(Lx lx, Env env, crate::syntax::Expr e);

bool is_event_value(const Lx& lx, const Env& env, const crate::syntax::Expr& e);

prism_rtl::JobRef<bool> start_is_event_value(Lx lx, Env env, crate::syntax::Expr e);

bool has_event_source(const Lx& lx, const Env& env, const crate::syntax::Expr& e);

prism_rtl::JobRef<bool> start_has_event_source(Lx lx, Env env, crate::syntax::Expr e);

bool is_event_source(const Lx& lx, const Env& env, const crate::syntax::Expr& c);

prism_rtl::JobRef<bool> start_is_event_source(Lx lx, Env env, crate::syntax::Expr c);

Vl event_value_of(const Lx& lx, const Env& env, const crate::syntax::Expr& e);

prism_rtl::JobRef<Vl> start_event_value_of(Lx lx, Env env, crate::syntax::Expr e);

Vl value_by_kind(const Lx& lx, const Env& env, const crate::syntax::Expr& e);

prism_rtl::JobRef<Vl> start_value_by_kind(Lx lx, Env env, crate::syntax::Expr e);

Vl pure_blueprint(const Lx& lx, const Env& env, const crate::syntax::Expr& x, const crate::lower::model::OutTy& t);

prism_rtl::JobRef<Vl> start_pure_blueprint(Lx lx, Env env, crate::syntax::Expr x, crate::lower::model::OutTy t);

Vl plain_blueprint(const Lx& lx, const Env& env, const crate::syntax::Expr& x, const Text& variant, const crate::lower::model::OutTy& t);

prism_rtl::JobRef<Vl> start_plain_blueprint(Lx lx, Env env, crate::syntax::Expr x, Text variant, crate::lower::model::OutTy t);

Vl dynamic_blueprint(const Lx& lx, const Env& env, const crate::syntax::Expr& x, const crate::syntax::Expr& d, const Text& variant, const crate::lower::model::OutTy& t);

prism_rtl::JobRef<Vl> start_dynamic_blueprint(Lx lx, Env env, crate::syntax::Expr x, crate::syntax::Expr d, Text variant, crate::lower::model::OutTy t);

Vl element_blueprint(const Lx& lx, const Env& env, const Array<crate::syntax::Arg>& args, const crate::lower::model::OutTy& t);

prism_rtl::JobRef<Vl> start_element_blueprint(Lx lx, Env env, Array<crate::syntax::Arg> args, crate::lower::model::OutTy t);

Text kind_words(const crate::syntax::ExprKind& k);

Vl name_value(const Lx& lx, const Env& env, const crate::syntax::SName& n, const crate::syntax::Range& span);

prism_rtl::JobRef<Vl> start_name_value(Lx lx, Env env, crate::syntax::SName n, crate::syntax::Range span);

Vl global_value(const Lx& lx, const Text& qk, const crate::syntax::Range& span, const crate::lower::model::OutTy& t);

prism_rtl::JobRef<Vl> start_global_value(Lx lx, Text qk, crate::syntax::Range span, crate::lower::model::OutTy t);

bool is_let_def(const crate::check::env::Def& d);

Text start_path(const Lx& lx, const Text& qk);

Vl application(const Lx& lx, const Env& env, const crate::syntax::Expr& callee, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span);

prism_rtl::JobRef<Vl> start_application(Lx lx, Env env, crate::syntax::Expr callee, Array<crate::syntax::Arg> args, crate::syntax::Range span);

Vl inline_local_fn(const Lx& lx, const Env& env, const crate::syntax::FnClause& c, const Array<crate::syntax::Arg>& args, const crate::lower::model::OutTy& t);

prism_rtl::JobRef<Vl> start_inline_local_fn(Lx lx, Env env, crate::syntax::FnClause c, Array<crate::syntax::Arg> args, crate::lower::model::OutTy t);

crate::lower::model::Ex argument(const Lx& lx, const Env& env, const crate::syntax::Expr& e);

prism_rtl::JobRef<crate::lower::model::Ex> start_argument(Lx lx, Env env, crate::syntax::Expr e);

crate::lower::model::Ex argument_by_kind(const Lx& lx, const Env& env, const crate::syntax::Expr& e);

prism_rtl::JobRef<crate::lower::model::Ex> start_argument_by_kind(Lx lx, Env env, crate::syntax::Expr e);

crate::lower::model::Ex closure_ref(const Vl& vl0);

Vl tag_value(const Lx& lx, const Env& env, const crate::check::env::TagInfo& tg, const Array<crate::syntax::Arg>& args);

prism_rtl::JobRef<Vl> start_tag_value(Lx lx, Env env, crate::check::env::TagInfo tg, Array<crate::syntax::Arg> args);

Vl global_call(const Lx& lx, const Env& env, const Text& qk, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span, const crate::lower::model::OutTy& t);

prism_rtl::JobRef<Vl> start_global_call(Lx lx, Env env, Text qk, Array<crate::syntax::Arg> args, crate::syntax::Range span, crate::lower::model::OutTy t);

Array<crate::lower::model::Ex> args_for(const Lx& lx, const Env& env, const crate::check::env::ValInfo& v_, const Array<crate::syntax::Arg>& args);

prism_rtl::JobRef<Array<crate::lower::model::Ex>> start_args_for(Lx lx, Env env, crate::check::env::ValInfo v_, Array<crate::syntax::Arg> args);

crate::syntax::Expr dummy_expr();

Vl ctor_app(const Lx& lx, const Env& env, const crate::check::env::CtorInfo& c, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span);

prism_rtl::JobRef<Vl> start_ctor_app(Lx lx, Env env, crate::check::env::CtorInfo c, Array<crate::syntax::Arg> args, crate::syntax::Range span);

Vl ctor_fn(const Lx& lx, const crate::check::env::CtorInfo& c, const Array<crate::lower::model::OutTy>& pts, const crate::syntax::Range& span, const crate::lower::model::OutTy& t, const bool& job);

prism_rtl::JobRef<Vl> start_ctor_fn(Lx lx, crate::check::env::CtorInfo c, Array<crate::lower::model::OutTy> pts, crate::syntax::Range span, crate::lower::model::OutTy t, bool job);

bool is_named_arg(const crate::syntax::Arg& a);

Array<crate::lower::model::Ex> ctor_args(const Lx& lx, const Env& env, const crate::check::env::CtorInfo& c, const Array<crate::syntax::Arg>& args);

prism_rtl::JobRef<Array<crate::lower::model::Ex>> start_ctor_args(Lx lx, Env env, crate::check::env::CtorInfo c, Array<crate::syntax::Arg> args);

Vl method_call(const Lx& lx, const Env& env, const crate::check::env::ValInfo& v_, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span, const crate::lower::model::OutTy& t);

prism_rtl::JobRef<Vl> start_method_call(Lx lx, Env env, crate::check::env::ValInfo v_, Array<crate::syntax::Arg> args, crate::syntax::Range span, crate::lower::model::OutTy t);

crate::check::env::TraitInfo dummy_trait_info();

Vl prelude_method(const Lx& lx, const Text& cls, const Text& m, const Array<Vl>& vals, const crate::syntax::Range& span, const crate::lower::model::OutTy& t);

prism_rtl::JobRef<Vl> start_prelude_method(Lx lx, Text cls, Text m, Array<Vl> vals, crate::syntax::Range span, crate::lower::model::OutTy t);

Vl binary_value(const Lx& lx, const Env& env, const Text& op, const crate::syntax::Expr& l, const crate::syntax::Expr& r, const crate::syntax::Range& span);

prism_rtl::JobRef<Vl> start_binary_value(Lx lx, Env env, Text op, crate::syntax::Expr l, crate::syntax::Expr r, crate::syntax::Range span);

Vl op_value(const Lx& lx, const Text& op, const Vl& a, const Vl& b, const crate::syntax::Range& span, const crate::lower::model::OutTy& t);

Text num_method(const Text& text0);

Vl prelude_call(const Lx& lx, const Env& env, const Text& qk, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span, const crate::lower::model::OutTy& t);

prism_rtl::JobRef<Vl> start_prelude_call(Lx lx, Env env, Text qk, Array<crate::syntax::Arg> args, crate::syntax::Range span, crate::lower::model::OutTy t);

std::optional<crate::lower::model::Ex> prelude_job(const Lx& lx, const Env& env, const Text& variant, const Array<crate::syntax::Arg>& args);

prism_rtl::JobRef<std::optional<crate::lower::model::Ex>> start_prelude_job(Lx lx, Env env, Text variant, Array<crate::syntax::Arg> args);

std::optional<crate::lower::model::Ex> prelude_job_call(const Lx& lx, const Env& env, const crate::syntax::Expr& e);

prism_rtl::JobRef<std::optional<crate::lower::model::Ex>> start_prelude_job_call(Lx lx, Env env, crate::syntax::Expr e);

crate::lower::model::Ex as_job_value(const Lx& lx, const Env& env, const crate::syntax::Expr& e);

prism_rtl::JobRef<crate::lower::model::Ex> start_as_job_value(Lx lx, Env env, crate::syntax::Expr e);

crate::lower::model::Ex wrap_as_job(const crate::lower::model::Ex& f, const Array<crate::lower::model::OutTy>& pts, const crate::lower::model::OutTy& target, const crate::lower::model::OutTy& a);

Array<crate::lower::model::Ex> named_args_owned(const Lx& lx, const Env& env, const Text& qk, const Array<crate::syntax::Arg>& args);

prism_rtl::JobRef<Array<crate::lower::model::Ex>> start_named_args_owned(Lx lx, Env env, Text qk, Array<crate::syntax::Arg> args);

Array<crate::lower::model::Ex> start_args(const Lx& lx, const Env& env, const Vl& f, const Array<crate::syntax::Arg>& args);

prism_rtl::JobRef<Array<crate::lower::model::Ex>> start_start_args(Lx lx, Env env, Vl f, Array<crate::syntax::Arg> args);

Text prelude_variant(const Text& name, const crate::lower::model::OutTy& first_);

Vl field_value(const Lx& lx, const Env& env, const crate::syntax::Expr& r, const Text& name);

prism_rtl::JobRef<Vl> start_field_value(Lx lx, Env env, crate::syntax::Expr r, Text name);

std::tuple<crate::lower::model::OutTy, bool> field_info(const Lx& lx, const crate::check::types::Ty& rty, const Text& name);

prism_rtl::JobRef<std::tuple<crate::lower::model::OutTy, bool>> start_field_info(Lx lx, crate::check::types::Ty rty, Text name);

crate::check::types::Ty instantiated(const crate::check::types::Ty& t, const Array<Text>& params, const Array<crate::check::types::Ty>& args);

prism_rtl::JobRef<crate::check::types::Ty> start_instantiated(crate::check::types::Ty t, Array<Text> params, Array<crate::check::types::Ty> args);

Vl index_value(const Lx& lx, const Env& env, const crate::syntax::Expr& r, const crate::syntax::Expr& i, const crate::lower::model::OutTy& t);

prism_rtl::JobRef<Vl> start_index_value(Lx lx, Env env, crate::syntax::Expr r, crate::syntax::Expr i, crate::lower::model::OutTy t);

Array<Text> read_names(const Array<crate::syntax::Expr>& es);

prism_rtl::JobRef<Array<Text>> start_read_names(Array<crate::syntax::Expr> es);

Array<crate::syntax::Expr> lambda_exprs(const crate::syntax::LambdaBody& lambda_body0);

prism_rtl::JobRef<Array<crate::syntax::Expr>> start_lambda_exprs(crate::syntax::LambdaBody lambda_body0);

Vl lambda_value(const Lx& lx, const Env& env, const crate::syntax::Expr& e, const Array<crate::syntax::Pattern_>& ps, const crate::syntax::LambdaBody& body);

prism_rtl::JobRef<Vl> start_lambda_value(Lx lx, Env env, crate::syntax::Expr e, Array<crate::syntax::Pattern_> ps, crate::syntax::LambdaBody body);

Vl plain_lambda(const Lx& lx, const Env& env, const Array<crate::syntax::Pattern_>& ps, const crate::syntax::LambdaBody& body, const crate::lower::model::OutTy& ft);

prism_rtl::JobRef<Vl> start_plain_lambda(Lx lx, Env env, Array<crate::syntax::Pattern_> ps, crate::syntax::LambdaBody body, crate::lower::model::OutTy ft);

Array<crate::lower::model::OutTy> lambda_param_tys(const Lx& lx, const crate::syntax::Expr& e, const Nat& n);

prism_rtl::JobRef<Array<crate::lower::model::OutTy>> start_lambda_param_tys(Lx lx, crate::syntax::Expr e, Nat n);

bool is_known_ty(const crate::lower::model::OutTy& t);

prism_rtl::JobRef<bool> start_is_known_ty(crate::lower::model::OutTy t);

Vl job_lambda(const Lx& lx, const Env& env, const Array<crate::syntax::Pattern_>& ps, const crate::syntax::LambdaBody& body, const crate::lower::model::OutTy& ft, const crate::lower::model::OutTy& a, const bool& enter);

prism_rtl::JobRef<Vl> start_job_lambda(Lx lx, Env env, Array<crate::syntax::Pattern_> ps, crate::syntax::LambdaBody body, crate::lower::model::OutTy ft, crate::lower::model::OutTy a, bool enter);

bool enters_lambda(const Lx& lx, const crate::syntax::Expr& e);

Env only_captured(const Env& env, const Array<Text>& caps);

crate::lower::model::Do cond_as_let(const crate::lower::model::Cc& cc0);

crate::lower::model::Ex lambda_arg(const Lx& lx, const Env& env, const Array<crate::syntax::Pattern_>& ps, const crate::syntax::LambdaBody& body, const Array<crate::lower::model::OutTy>& pts);

prism_rtl::JobRef<crate::lower::model::Ex> start_lambda_arg(Lx lx, Env env, Array<crate::syntax::Pattern_> ps, crate::syntax::LambdaBody body, Array<crate::lower::model::OutTy> pts);

Vl lambda_body_value(const Lx& lx, const Env& env, const crate::syntax::LambdaBody& lambda_body2);

prism_rtl::JobRef<Vl> start_lambda_body_value(Lx lx, Env env, crate::syntax::LambdaBody lambda_body2);

std::tuple<Array<crate::lower::model::Pa>, Env> closure_params(const Lx& lx, const Env& env, const Array<crate::syntax::Pattern_>& ps, const Array<crate::lower::model::OutTy>& pts, const bool& typed);

prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Pa>, Env>> start_closure_params(Lx lx, Env env, Array<crate::syntax::Pattern_> ps, Array<crate::lower::model::OutTy> pts, bool typed);

Env bind_all(const Env& env, const Array<std::tuple<Text, Bn>>& bs);

crate::check::types::Ty binder_ty_of_pattern(const Lx& lx, const crate::syntax::Pattern_& p_);

Vl if_value(const Lx& lx, const Env& env, const crate::syntax::Cond& c, const crate::syntax::Block& then_b, const std::optional<crate::syntax::Block>& else_b_opt, const crate::lower::model::OutTy& t);

prism_rtl::JobRef<Vl> start_if_value(Lx lx, Env env, crate::syntax::Cond c, crate::syntax::Block then_b, std::optional<crate::syntax::Block> else_b_opt, crate::lower::model::OutTy t);

Vl arms_value(const crate::lower::model::Ex& scrut, const Array<crate::lower::model::XArm>& arms, const Text& label, const crate::lower::model::OutTy& t);

bool is_let_cond(const crate::lower::model::Cc& cc0);

Vl match_value(const Lx& lx, const Env& env, const crate::syntax::Expr& s, const Array<crate::syntax::Arm>& arms, const crate::lower::model::OutTy& t, const crate::syntax::Range& span);

prism_rtl::JobRef<Vl> start_match_value(Lx lx, Env env, crate::syntax::Expr s, Array<crate::syntax::Arm> arms, crate::lower::model::OutTy t, crate::syntax::Range span);

crate::syntax::Arm dummy_arm();

PatOut arm_pat(const Lx& lx, const std::optional<crate::syntax::Pattern_>& opt1, const crate::check::types::Ty& ty, const Holding& mode, const Text& fresh);

prism_rtl::JobRef<PatOut> start_arm_pat(Lx lx, std::optional<crate::syntax::Pattern_> opt1, crate::check::types::Ty ty, Holding mode, Text fresh);

Vl block_value(const Lx& lx, const Env& env, const crate::syntax::Block& b);

prism_rtl::JobRef<Vl> start_block_value(Lx lx, Env env, crate::syntax::Block b);

bool is_given_block(const Array<crate::syntax::Stmt>& stmts);

bool is_guardish(const crate::syntax::Stmt& s);

crate::lower::model::OutTy block_ty(const Lx& lx, const crate::syntax::Block& b);

prism_rtl::JobRef<crate::lower::model::OutTy> start_block_ty(Lx lx, crate::syntax::Block b);

Vl plain_block_value(const Lx& lx, const Env& env, const crate::syntax::Block& b);

prism_rtl::JobRef<Vl> start_plain_block_value(Lx lx, Env env, crate::syntax::Block b);

crate::syntax::Stmt dummy_stmt_l();

std::tuple<Array<crate::lower::model::Do>, Env> block_stmt(const Lx& lx, const Env& env, const crate::syntax::Stmt& s);

prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, Env>> start_block_stmt(Lx lx, Env env, crate::syntax::Stmt s);

std::tuple<Array<crate::lower::model::Do>, Env> generic_let(const Lx& lx, const Env& env, const crate::syntax::SName& n, const crate::check::typed::GenNote& gn, const crate::syntax::Expr& x);

prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, Env>> start_generic_let(Lx lx, Env env, crate::syntax::SName n, crate::check::typed::GenNote gn, crate::syntax::Expr x);

Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> instantiations(const Lx& lx, const crate::check::typed::GenNote& gn);

prism_rtl::JobRef<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> start_instantiations(Lx lx, crate::check::typed::GenNote gn);

Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> expanded(const Lx& lx, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& i);

prism_rtl::JobRef<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> start_expanded(Lx lx, std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>> i);

std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>> subst_inst(const Lx& lx, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& arg1);

std::optional<Text> open_q(const Lx& lx, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& arg1);

prism_rtl::JobRef<std::optional<Text>> start_open_q(Lx lx, std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>> arg1);

Array<Text> open_cols(const Lx& lx, const crate::check::types::Col& col1);

Array<Text> open_ty_qs(const Lx& lx, const crate::check::types::Ty& t);

prism_rtl::JobRef<Array<Text>> start_open_ty_qs(Lx lx, crate::check::types::Ty t);

Lx at_instance(const Lx& lx, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& arg1);

Lx widget_let_lx(const Lx& lx, const crate::syntax::Range& span);

prism_rtl::JobRef<Lx> start_widget_let_lx(Lx lx, crate::syntax::Range span);

std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>> inst_at(const Lx& lx, const crate::check::typed::InstNote& u);

Text gen_key(const crate::check::typed::GenNote& gn);

Text inst_key(const crate::check::typed::InstNote& u);

Text col_name(const crate::check::types::Col& col0);

std::tuple<Array<crate::lower::model::Do>, Env> plain_let(const Lx& lx, const Env& env, const crate::syntax::Stmt& s, const crate::syntax::Pattern_& p_, const crate::syntax::Expr& x);

prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, Env>> start_plain_let(Lx lx, Env env, crate::syntax::Stmt s, crate::syntax::Pattern_ p_, crate::syntax::Expr x);

PatOut pat_only(const crate::lower::model::Pa& pa);

PatOut rust_pat(const Lx& lx, const crate::syntax::Pattern_& p_, const crate::check::types::Ty& ty, const Holding& mode, const Text& fresh);

prism_rtl::JobRef<PatOut> start_rust_pat(Lx lx, crate::syntax::Pattern_ p_, crate::check::types::Ty ty, Holding mode, Text fresh);

crate::syntax::Pattern_ dummy_pat();

crate::check::types::Ty inner_ty(const crate::check::types::Ty& t);

bool is_unit_ctor(const Lx& lx, const Text& qk);

PatOut wrap_pat(const Lx& lx, const Text& ctor, const crate::syntax::Pattern_& q, const crate::check::types::Ty& inner, const Holding& mode, const Text& fresh);

prism_rtl::JobRef<PatOut> start_wrap_pat(Lx lx, Text ctor, crate::syntax::Pattern_ q, crate::check::types::Ty inner, Holding mode, Text fresh);

PatOut lit_pat(const Lx& lx, const crate::syntax::Literal& l, const crate::check::types::Ty& ty, const Holding& mode, const Text& fresh, const bool& neg);

prism_rtl::JobRef<PatOut> start_lit_pat(Lx lx, crate::syntax::Literal l, crate::check::types::Ty ty, Holding mode, Text fresh, bool neg);

PatOut ctor_pat(const Lx& lx, const crate::syntax::SName& n, const Array<crate::syntax::Pattern_>& ps, const crate::check::types::Ty& ty, const Holding& mode, const Text& fresh);

prism_rtl::JobRef<PatOut> start_ctor_pat(Lx lx, crate::syntax::SName n, Array<crate::syntax::Pattern_> ps, crate::check::types::Ty ty, Holding mode, Text fresh);

PatOut sub_pat(const Lx& lx, const crate::check::env::CtorInfo& c, const Nat& i, const crate::syntax::Pattern_& p_, const crate::check::types::Ty& ty, const Holding& mode, const Text& fresh);

prism_rtl::JobRef<PatOut> start_sub_pat(Lx lx, crate::check::env::CtorInfo c, Nat i, crate::syntax::Pattern_ p_, crate::check::types::Ty ty, Holding mode, Text fresh);

PatOut behind_rc(const Lx& lx, const crate::syntax::Pattern_& p_, const crate::check::types::Ty& ty, const Holding& rc_mode, const Text& fresh);

prism_rtl::JobRef<PatOut> start_behind_rc(Lx lx, crate::syntax::Pattern_ p_, crate::check::types::Ty ty, Holding rc_mode, Text fresh);

PatOut record_pat(const Lx& lx, const crate::syntax::SName& n, const Array<crate::syntax::FieldPat>& fps, const bool& rest, const crate::check::types::Ty& ty, const Holding& mode, const Text& fresh);

prism_rtl::JobRef<PatOut> start_record_pat(Lx lx, crate::syntax::SName n, Array<crate::syntax::FieldPat> fps, bool rest, crate::check::types::Ty ty, Holding mode, Text fresh);

PatOut rest_case_pat(const crate::check::env::CtorInfo& c, const Array<std::tuple<Text, Array<crate::check::types::Ty>>>& cases, const Text& ty_path);

PatOut fields_pat(const Lx& lx, const crate::check::env::CtorInfo& c, const Array<crate::syntax::FieldPat>& fps, const bool& rest, const crate::check::types::Ty& ty, const Holding& mode, const Text& fresh, const Text& ty_path);

prism_rtl::JobRef<PatOut> start_fields_pat(Lx lx, crate::check::env::CtorInfo c, Array<crate::syntax::FieldPat> fps, bool rest, crate::check::types::Ty ty, Holding mode, Text fresh, Text ty_path);

crate::syntax::FieldPat dummy_field_pat();

crate::check::env::TagInfo dummy_tag_info();

bool is_live(const crate::check::types::Ty& t);

Text tag_field_name(const crate::syntax::FieldPat& fp, const Array<Text>& names, const Nat& i);

PatOut tag_pat(const Lx& lx, const crate::check::env::TagInfo& tg, const Array<crate::syntax::FieldPat>& fps, const bool& rest, const crate::check::types::Ty& ty, const Holding& mode, const Text& fresh);

prism_rtl::JobRef<PatOut> start_tag_pat(Lx lx, crate::check::env::TagInfo tg, Array<crate::syntax::FieldPat> fps, bool rest, crate::check::types::Ty ty, Holding mode, Text fresh);

PatOut live_field_pat(const Lx& lx, const crate::syntax::Pattern_& p_, const Text& variant, const Text& fname, const crate::check::types::Ty& ft, const Text& fresh);

prism_rtl::JobRef<PatOut> start_live_field_pat(Lx lx, crate::syntax::Pattern_ p_, Text variant, Text fname, crate::check::types::Ty ft, Text fresh);

crate::lower::model::Ex live_projection(const Text& fresh, const Text& variant, const Text& fname, const crate::lower::model::OutTy& ft);

PatOut family_pat(const Lx& lx, const crate::syntax::QualName& q, const crate::check::types::Ty& ty, const Text& fresh);

prism_rtl::JobRef<PatOut> start_family_pat(Lx lx, crate::syntax::QualName q, crate::check::types::Ty ty, Text fresh);

PatOut error_pat(const Lx& lx, const Array<crate::syntax::FieldPat>& fps, const crate::check::types::Ty& ty, const Holding& mode, const Text& fresh);

prism_rtl::JobRef<PatOut> start_error_pat(Lx lx, Array<crate::syntax::FieldPat> fps, crate::check::types::Ty ty, Holding mode, Text fresh);

PatOut array_pat(const Lx& lx, const Array<crate::syntax::Pattern_>& ps, const crate::check::types::Ty& ty, const Holding& mode, const Text& fresh);

prism_rtl::JobRef<PatOut> start_array_pat(Lx lx, Array<crate::syntax::Pattern_> ps, crate::check::types::Ty ty, Holding mode, Text fresh);

Vl template_value(const Lx& lx, const Env& env, const crate::syntax::Template& tp);

prism_rtl::JobRef<Vl> start_template_value(Lx lx, Env env, crate::syntax::Template tp);

Array<crate::lower::model::Do> template_part_dos(const Lx& lx, const Env& env, const crate::syntax::TemplatePart& part);

prism_rtl::JobRef<Array<crate::lower::model::Do>> start_template_part_dos(Lx lx, Env env, crate::syntax::TemplatePart part);

Array<crate::lower::model::Ex> template_args(const Lx& lx, const Env& env, const Text& qk, const Array<crate::syntax::Arg>& args, const Array<crate::lower::model::Ex>& body);

prism_rtl::JobRef<Array<crate::lower::model::Ex>> start_template_args(Lx lx, Env env, Text qk, Array<crate::syntax::Arg> args, Array<crate::lower::model::Ex> body);

std::optional<crate::syntax::Arg> attr_at(const Array<crate::syntax::FnClause>& clauses, const Nat& j, const Array<crate::syntax::Arg>& args);

std::optional<Text> place_name(const crate::syntax::Pattern_& p_);

crate::lower::model::Ex shown_text(const Vl& v_);

Vl given_value(const Lx& lx, const Env& env, const crate::syntax::Block& b, const crate::lower::model::OutTy& t, const crate::syntax::Range& span);

prism_rtl::JobRef<Vl> start_given_value(Lx lx, Env env, crate::syntax::Block b, crate::lower::model::OutTy t, crate::syntax::Range span);

crate::lower::model::Do given_bind(const bool& is_try, const crate::lower::model::Pa& pa, const crate::lower::model::Ex& x, const Text& label, const crate::lower::model::OutTy& t);

Text source_text(const Lx& lx, const crate::syntax::Range& r);

Vl update_value(const Lx& lx, const Env& env, const crate::syntax::Expr& target, const crate::syntax::Block& b, const crate::lower::model::OutTy& t, const crate::syntax::Range& span);

prism_rtl::JobRef<Vl> start_update_value(Lx lx, Env env, crate::syntax::Expr target, crate::syntax::Block b, crate::lower::model::OutTy t, crate::syntax::Range span);

std::tuple<Array<crate::lower::model::Do>, Env> upd_stmts(const Lx& lx, const Env& env, const Array<crate::syntax::Stmt>& stmts);

prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, Env>> start_upd_stmts(Lx lx, Env env, Array<crate::syntax::Stmt> stmts);

std::tuple<Array<crate::lower::model::Do>, Env> upd_stmt(const Lx& lx, const Env& env, const crate::syntax::Stmt& s);

prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, Env>> start_upd_stmt(Lx lx, Env env, crate::syntax::Stmt s);

crate::lower::model::Do upd_for(const Lx& lx, const Env& env, const std::optional<crate::syntax::ForBinders>& binders_opt, const crate::syntax::Expr& source, const crate::syntax::Block& body, const crate::syntax::Range& span);

prism_rtl::JobRef<crate::lower::model::Do> start_upd_for(Lx lx, Env env, std::optional<crate::syntax::ForBinders> binders_opt, crate::syntax::Expr source, crate::syntax::Block body, crate::syntax::Range span);

crate::lower::model::Do upd_for_refs(const Lx& lx, const Env& env, const crate::syntax::SName& n, const crate::syntax::Expr& source, const crate::syntax::Block& body, const crate::syntax::Range& span, const crate::check::types::Ty& sty);

prism_rtl::JobRef<crate::lower::model::Do> start_upd_for_refs(Lx lx, Env env, crate::syntax::SName n, crate::syntax::Expr source, crate::syntax::Block body, crate::syntax::Range span, crate::check::types::Ty sty);

std::optional<crate::syntax::SName> ref_binder(const std::optional<crate::syntax::ForBinders>& opt0);

bool is_ref_path(const crate::syntax::Expr& e);

crate::lower::model::Do upd_for_values(const Lx& lx, const Env& env, const std::optional<crate::syntax::ForBinders>& binders_opt, const crate::syntax::Expr& source, const crate::syntax::Block& body, const crate::syntax::Range& span, const crate::check::types::Ty& sty);

prism_rtl::JobRef<crate::lower::model::Do> start_upd_for_values(Lx lx, Env env, std::optional<crate::syntax::ForBinders> binders_opt, crate::syntax::Expr source, crate::syntax::Block body, crate::syntax::Range span, crate::check::types::Ty sty);

crate::lower::model::Do upd_if(const Lx& lx, const Env& env, const crate::syntax::Cond& c, const crate::syntax::Block& then_b, const std::optional<crate::syntax::Block>& else_b_opt);

prism_rtl::JobRef<crate::lower::model::Do> start_upd_if(Lx lx, Env env, crate::syntax::Cond c, crate::syntax::Block then_b, std::optional<crate::syntax::Block> else_b_opt);

crate::lower::model::Do upd_match(const Lx& lx, const Env& env, const crate::syntax::Expr& scrut, const Array<crate::syntax::Arm>& arms);

prism_rtl::JobRef<crate::lower::model::Do> start_upd_match(Lx lx, Env env, crate::syntax::Expr scrut, Array<crate::syntax::Arm> arms);

crate::lower::model::Ex all_of(const Array<crate::lower::model::Ex>& xs0);

Array<crate::lower::model::Do> arm_dos(const crate::lower::model::Ex& ex0);

Array<crate::lower::model::Cc> guard_conds(const Lx& lx, const Env& env, const std::optional<crate::syntax::Expr>& opt2);

prism_rtl::JobRef<Array<crate::lower::model::Cc>> start_guard_conds(Lx lx, Env env, std::optional<crate::syntax::Expr> opt2);

crate::lower::model::Ex place_of(const Lx& lx, const Env& env, const crate::syntax::Expr& e);

prism_rtl::JobRef<crate::lower::model::Ex> start_place_of(Lx lx, Env env, crate::syntax::Expr e);

crate::lower::model::Do assign(const Lx& lx, const Env& env, const crate::syntax::Expr& target, const crate::lower::model::Ex& v_);

prism_rtl::JobRef<crate::lower::model::Do> start_assign(Lx lx, Env env, crate::syntax::Expr target, crate::lower::model::Ex v_);

Array<Text> bound_of(const Lx& lx, const Text& text1);

Array<std::tuple<Text, Array<Text>>> scheme_generics(const Lx& lx, const crate::check::types::Scheme& sc);

Array<std::tuple<Text, bool>> param_names(const Lx& lx, const Array<crate::syntax::FnClause>& clauses, const Array<crate::lower::model::OutTy>& pts);

Text plain_binder(const Lx& lx, const crate::syntax::Pattern_& p_);

Text param_word(const crate::lower::model::OutTy& t, const Nat& i);

crate::lower::model::Ex clauses_body(const Lx& lx, const Env& env, const Array<crate::syntax::FnClause>& clauses, const Array<std::tuple<Text, bool>>& names, const Array<crate::check::types::Ty>& ptys, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Lx, Env, crate::syntax::FnBody>)>& body_fn, const Text& label, const crate::lower::model::OutTy& t);

prism_rtl::JobRef<crate::lower::model::Ex> start_clauses_body(Lx lx, Env env, Array<crate::syntax::FnClause> clauses, Array<std::tuple<Text, bool>> names, Array<crate::check::types::Ty> ptys, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Lx, Env, crate::syntax::FnBody>)> body_fn, Text label, crate::lower::model::OutTy t);

crate::syntax::FnClause dummy_clause();

crate::lower::model::Ex fn_body_value(const Lx& lx, const Env& env, const crate::syntax::FnBody& fn_body2);

prism_rtl::JobRef<crate::lower::model::Ex> start_fn_body_value(Lx lx, Env env, crate::syntax::FnBody fn_body2);

crate::lower::model::FnDef fn_def_of(const Lx& lx, const Text& qk, const Array<crate::syntax::FnClause>& clauses, const crate::check::types::Scheme& sc);

prism_rtl::JobRef<crate::lower::model::FnDef> start_fn_def_of(Lx lx, Text qk, Array<crate::syntax::FnClause> clauses, crate::check::types::Scheme sc);

Array<Text> ty_params_in(const crate::lower::model::OutTy& t);

Text signature_text(const Lx& lx, const Text& qk);

Text definition_text(const Lx& lx, const Text& qk);

Text src_text(const Lx& lx, const Nat& f, const crate::syntax::Range& r);

Text drop_trailing_comments(const Text& t);

bool is_code_line(const Text& l);

crate::lower::model::FnDef let_getter(const Lx& lx, const Text& qk, const crate::syntax::LetDecl& l);

prism_rtl::JobRef<crate::lower::model::FnDef> start_let_getter(Lx lx, Text qk, crate::syntax::LetDecl l);

bool has_own_show(const Lx& lx, const Text& tn);

Text head_name(const crate::check::types::Ty& ty0);

crate::check::types::Ty self_in(const crate::check::types::Ty& t, const Text& param);

prism_rtl::JobRef<crate::check::types::Ty> start_self_in(crate::check::types::Ty t, Text param);

crate::lower::model::TraitDef trait_def_of(const Lx& lx0, const crate::check::env::TraitInfo& tr);

prism_rtl::JobRef<crate::lower::model::TraitDef> start_trait_def_of(Lx lx0, crate::check::env::TraitInfo tr);

Array<crate::syntax::FnClause> default_clauses(const crate::check::env::G& g, const Text& qk);

Array<crate::syntax::FnClause> default_of(const crate::check::env::Def& d, const Array<crate::syntax::FnClause>& other);

crate::lower::model::ImplDef impl_def_of(const Lx& lx, const crate::check::env::ImplInfo& im);

prism_rtl::JobRef<crate::lower::model::ImplDef> start_impl_def_of(Lx lx, crate::check::env::ImplInfo im);

crate::lower::model::FnDef renamed(const crate::lower::model::FnDef& fd, const Text& n);

bool is_method_of(const crate::check::env::Def& d, const crate::check::env::ImplInfo& im);

Array<crate::syntax::FnClause> method_clauses(const crate::check::env::Def& d);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> if_gen_line(const crate::lower::node_::Wx& wx, const Env& menv, const crate::syntax::Expr& c, const crate::syntax::Block& then_b, const crate::syntax::Block& else_b, const crate::syntax::Expr& e);

prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> start_if_gen_line(crate::lower::node_::Wx wx, Env menv, crate::syntax::Expr c, crate::syntax::Block then_b, crate::syntax::Block else_b, crate::syntax::Expr e);

crate::lower::model::Ex tail(const Lx& lx, const Env& env, const crate::syntax::Expr& e);

prism_rtl::JobRef<crate::lower::model::Ex> start_tail(Lx lx, Env env, crate::syntax::Expr e);

crate::lower::model::Ex tail_here(const Lx& lx, const Env& env, const crate::syntax::Expr& e);

prism_rtl::JobRef<crate::lower::model::Ex> start_tail_here(Lx lx, Env env, crate::syntax::Expr e);

crate::lower::model::Ex tail_block(const Lx& lx, const Env& env, const crate::syntax::Block& b);

prism_rtl::JobRef<crate::lower::model::Ex> start_tail_block(Lx lx, Env env, crate::syntax::Block b);

crate::lower::model::Ex tail_from(const Lx& lx, const Env& env, const crate::syntax::Block& b, const Nat& i);

prism_rtl::JobRef<crate::lower::model::Ex> start_tail_from(Lx lx, Env env, crate::syntax::Block b, Nat i);

bool has_top_while(const Lx& lx, const crate::syntax::Block& b);

bool is_cycle_while(const Lx& lx, const crate::syntax::Stmt& st);

bool else_has_top_while(const Lx& lx, const std::optional<crate::syntax::Block>& opt1);

bool holds_cycle_while(const Lx& lx, const crate::syntax::Stmt& st);

crate::lower::model::Ex upd_tail(const Lx& lx, const Env& env, const crate::syntax::Expr& target, const crate::syntax::Block& b, const crate::syntax::Range& to, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, crate::lower::model::Ex>)>& cont_fn);

prism_rtl::JobRef<crate::lower::model::Ex> start_upd_tail(Lx lx, Env env, crate::syntax::Expr target, crate::syntax::Block b, crate::syntax::Range to, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, crate::lower::model::Ex>)> cont_fn);

crate::lower::model::Ex upd_tail_from(const Lx& lx, const Env& outer, const Env& env, const crate::syntax::Block& b, const Nat& i, const crate::syntax::Range& to, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, crate::lower::model::Ex>)>& cont_fn);

prism_rtl::JobRef<crate::lower::model::Ex> start_upd_tail_from(Lx lx, Env outer, Env env, crate::syntax::Block b, Nat i, crate::syntax::Range to, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, crate::lower::model::Ex>)> cont_fn);

crate::lower::model::Ex stmt_job(const Lx& lx, const Env& outer, const Env& env, const crate::syntax::Stmt& s, const Text& rest, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, Env>)>& cont_fn);

prism_rtl::JobRef<crate::lower::model::Ex> start_stmt_job(Lx lx, Env outer, Env env, crate::syntax::Stmt s, Text rest, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, Env>)> cont_fn);

crate::lower::model::Ex prepend(const Array<crate::lower::model::Do>& dos, const crate::lower::model::Ex& ex1);

crate::lower::model::Ex while_job(const Lx& lx, const Env& outer, const Env& env, const crate::syntax::Cond& c, const crate::syntax::Block& wb, const crate::syntax::Range& span, const Text& rest_text_, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, Env>)>& cont_fn);

prism_rtl::JobRef<crate::lower::model::Ex> start_while_job(Lx lx, Env outer, Env env, crate::syntax::Cond c, crate::syntax::Block wb, crate::syntax::Range span, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, Env>)> cont_fn);

crate::lower::model::Ex stmts_then(const Lx& lx, const Env& env, const crate::syntax::Block& b, const crate::lower::model::Ex& last);

prism_rtl::JobRef<crate::lower::model::Ex> start_stmts_then(Lx lx, Env env, crate::syntax::Block b, crate::lower::model::Ex last);

crate::lower::model::Ex if_job(const Lx& lx, const Env& outer, const Env& env, const crate::syntax::Cond& c, const crate::syntax::Block& then_b, const std::optional<crate::syntax::Block>& else_b_opt, const crate::syntax::Range& span, const Text& rest_text_, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, Env>)>& cont_fn);

prism_rtl::JobRef<crate::lower::model::Ex> start_if_job(Lx lx, Env outer, Env env, crate::syntax::Cond c, crate::syntax::Block then_b, std::optional<crate::syntax::Block> else_b_opt, crate::syntax::Range span, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, Env>)> cont_fn);

crate::lower::model::Ex match_job(const Lx& lx, const Env& outer, const Env& env, const crate::syntax::Expr& scrut, const Array<crate::syntax::Arm>& arms, const crate::syntax::Range& span, const Text& rest_text_, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, Env>)>& cont_fn);

prism_rtl::JobRef<crate::lower::model::Ex> start_match_job(Lx lx, Env outer, Env env, crate::syntax::Expr scrut, Array<crate::syntax::Arm> arms, crate::syntax::Range span, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, Env>)> cont_fn);

crate::lower::model::Ex for_job(const Lx& lx, const Env& outer, const Env& env, const std::optional<crate::syntax::ForBinders>& binders_opt, const crate::syntax::Expr& source, const crate::syntax::Block& body, const crate::syntax::Range& span, const Text& rest_text_, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, Env>)>& cont_fn);

prism_rtl::JobRef<crate::lower::model::Ex> start_for_job(Lx lx, Env outer, Env env, std::optional<crate::syntax::ForBinders> binders_opt, crate::syntax::Expr source, crate::syntax::Block body, crate::syntax::Range span, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, Env>)> cont_fn);

Text instance_of(const Text& k);

Array<std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>> caps_in(const Env& env, const Text& text, const Array<Text>& skip);

std::optional<crate::syntax::Expr> frame_call(const Lx& lx, const Env& env, const crate::syntax::Expr& e, const bool& top);

prism_rtl::JobRef<std::optional<crate::syntax::Expr>> start_frame_call(Lx lx, Env env, crate::syntax::Expr e, bool top);

Array<crate::syntax::Expr> placeholders(const Array<crate::syntax::TextSeg>& segs);

std::optional<crate::syntax::Expr> first_frame(const Lx& lx, const Env& env, const Array<crate::syntax::Expr>& es);

prism_rtl::JobRef<std::optional<crate::syntax::Expr>> start_first_frame(Lx lx, Env env, Array<crate::syntax::Expr> es);

crate::lower::model::Ex frame(const Lx& lx, const Env& env, const crate::syntax::Expr& call, const Text& rest_text_, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Env)>& cont_fn);

prism_rtl::JobRef<crate::lower::model::Ex> start_frame(Lx lx, Env env, crate::syntax::Expr call, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Env)> cont_fn);

std::optional<Vl> local_job_fn(const Lx& lx, const Env& env, const crate::syntax::Expr& c);

prism_rtl::JobRef<std::optional<Vl>> start_local_job_fn(Lx lx, Env env, crate::syntax::Expr c);

std::optional<Vl> job_value(const Vl& f);

crate::lower::model::Ex start_call(const Vl& f, const Array<crate::lower::model::Ex>& vals);

crate::lower::model::Ex one_or_tuple(const Array<crate::lower::model::Ex>& xs0);

Text callee_text(const crate::syntax::Expr& c);

Text rest_text(const Lx& lx, const crate::syntax::Range& from, const crate::syntax::Range& call, const crate::syntax::Range& to);

bool mentions(const Text& text, const Text& name);

bool ends_ident(const Text& t);

bool starts_ident(const Text& t);

crate::lower::model::Ex tail_body(const Lx& lx, const Env& env, const crate::syntax::FnBody& fn_body2);

prism_rtl::JobRef<crate::lower::model::Ex> start_tail_body(Lx lx, Env env, crate::syntax::FnBody fn_body2);

crate::lower::model::Ex tail_match(const Lx& lx, const Env& env, const crate::syntax::Expr& s, const Array<crate::syntax::Arm>& arms, const crate::syntax::Range& span);

prism_rtl::JobRef<crate::lower::model::Ex> start_tail_match(Lx lx, Env env, crate::syntax::Expr s, Array<crate::syntax::Arm> arms, crate::syntax::Range span);

std::optional<Text> tail_callee(const Lx& lx, const Env& env, const crate::syntax::Expr& callee);

std::tuple<Array<crate::check::types::Ty>, crate::check::types::Ty> scheme_parts(const Lx& lx, const Text& qk);

Array<Text> job_field_names(const Lx& lx, const Text& qk);

prism_rtl::JobRef<Array<Text>> start_job_field_names(Lx lx, Text qk);

Array<crate::syntax::FnClause> clauses_of(const crate::check::env::G& g, const Text& qk);

Array<crate::syntax::FnClause> def_clauses(const crate::check::env::Def& d, const Array<crate::syntax::FnClause>& other);

crate::lower::model::JobDef job_def_of(const Lx& lx, const Text& qk, const Array<crate::syntax::FnClause>& clauses, const crate::check::types::Scheme& sc);

prism_rtl::JobRef<crate::lower::model::JobDef> start_job_def_of(Lx lx, Text qk, Array<crate::syntax::FnClause> clauses, crate::check::types::Scheme sc);

crate::lower::model::Ex job_clauses(const Lx& lx, const Array<crate::syntax::FnClause>& clauses, const Array<std::tuple<Text, bool>>& names, const Array<crate::check::types::Ty>& ptys, const Array<crate::lower::model::OutTy>& pts);

prism_rtl::JobRef<crate::lower::model::Ex> start_job_clauses(Lx lx, Array<crate::syntax::FnClause> clauses, Array<std::tuple<Text, bool>> names, Array<crate::check::types::Ty> ptys, Array<crate::lower::model::OutTy> pts);

Lx in_module(const Lx& lx, const Nat& file, const Text& home);

Lx in_module_at(const Lx& lx, const Nat& file, const Text& home, const Text& site);

crate::lower::model::Model lower_program(const Array<crate::check::errors::Src>& srcs, const Array<crate::syntax::Module>& trees, const Nat& shown, const crate::check::typed::TProgram& tp, const Text& name);

prism_rtl::JobRef<crate::lower::model::Model> start_lower_program(Array<crate::check::errors::Src> srcs, Array<crate::syntax::Module> trees, Nat shown, crate::check::typed::TProgram tp, Text name);

Array<crate::lower::model::ModDef> with_needs(const crate::check::env::G& g, const Array<crate::check::errors::Src>& srcs, const crate::check::typed::TProgram& tp, const Array<crate::lower::model::ModDef>& defs);

prism_rtl::JobRef<Array<crate::lower::model::ModDef>> start_with_needs(crate::check::env::G g, Array<crate::check::errors::Src> srcs, crate::check::typed::TProgram tp, Array<crate::lower::model::ModDef> defs);

Map<Text, Array<Text>> named_mods(const crate::check::env::G& g, const Array<crate::check::errors::Src>& srcs, const crate::check::typed::TProgram& tp, const Array<Text>& ms);

prism_rtl::JobRef<Map<Text, Array<Text>>> start_named_mods(crate::check::env::G g, Array<crate::check::errors::Src> srcs, crate::check::typed::TProgram tp, Array<Text> ms);

Text impl_path(const Text& how);

Map<Text, bool> value_types(const Array<crate::lower::model::ModDef>& defs);

Array<Text> item_held(const Array<Text>& names, const Map<Text, bool>& value_tys, const Text& home, const crate::lower::model::Item& it);

Array<Text> held_in(const Array<Text>& names, const Map<Text, bool>& value_tys, const Text& home, const crate::lower::model::OutTy& t);

Array<Text> named_in(const Array<Text>& names, const Text& home, const crate::lower::model::OutTy& t);

Text path_from(const Array<Text>& names, const Text& home, const Text& n);

bool starts_with_module(const Array<Text>& names, const Text& q);

Text parent_of(const Text& p_);

Array<crate::lower::model::ModDef> with_groups(const Array<crate::lower::model::ModDef>& defs);

prism_rtl::JobRef<Array<crate::lower::model::ModDef>> start_with_groups(Array<crate::lower::model::ModDef> defs);

Array<Text> reached_by(const Map<Text, Array<Text>>& edges, const Array<Text>& todo, const Array<Text>& seen);

prism_rtl::JobRef<Array<Text>> start_reached_by(Map<Text, Array<Text>> edges, Array<Text> todo, Array<Text> seen);

Array<Text> needed_mods(const crate::check::env::G& g, const Nat& shown);

prism_rtl::JobRef<Array<Text>> start_needed_mods(crate::check::env::G g, Nat shown);

Array<Text> mod_refs(const crate::check::env::G& g, const Text& m);

prism_rtl::JobRef<Array<Text>> start_mod_refs(crate::check::env::G g, Text m);

Array<std::tuple<Text, bool>> root_widgets(const Lx& lx);

bool is_main(const Text& qk);

Text blueprint_qk(const Lx& lx, const crate::syntax::Expr& e);

crate::check::env::ValInfo val_of(const Lx& lx, const Text& qk);

crate::lower::model::ProgDef prog_def_of(const Lx& lx, const Text& qk);

prism_rtl::JobRef<crate::lower::model::ProgDef> start_prog_def_of(Lx lx, Text qk);

Array<Text> job_roots(const Lx& lx);

prism_rtl::JobRef<Array<Text>> start_job_roots(Lx lx);

Array<Text> unbounded_values(const Lx& lx, const crate::check::env::Def& d);

prism_rtl::JobRef<Array<Text>> start_unbounded_values(Lx lx, crate::check::env::Def d);

bool in_prelude(const Lx& lx, const Text& q);

bool is_color_poly(const Lx& lx, const Text& q);

bool enters_at_once(const Lx& lx, const Text& q, const Array<crate::syntax::Arg>& args);

bool is_unbounded_arg(const Lx& lx, const crate::syntax::Arg& a);

bool is_unbounded(const Lx& lx, const Text& q);

Array<Text> run_targets(const Lx& lx, const crate::check::env::Def& d);

prism_rtl::JobRef<Array<Text>> start_run_targets(Lx lx, crate::check::env::Def d);

Array<Text> tail_targets(const Lx& lx, const Text& qk);

prism_rtl::JobRef<Array<Text>> start_tail_targets(Lx lx, Text qk);

Array<Text> tails_of_body(const Lx& lx, const crate::syntax::FnBody& body);

prism_rtl::JobRef<Array<Text>> start_tails_of_body(Lx lx, crate::syntax::FnBody body);

crate::lower::model::ModDef mod_def_of(const Lx& lx0, const Text& m, const Array<std::tuple<Text, bool>>& roots, const crate::check::env::ModInfo& info, const Array<Text>& mods);

prism_rtl::JobRef<crate::lower::model::ModDef> start_mod_def_of(Lx lx0, Text m, Array<std::tuple<Text, bool>> roots, crate::check::env::ModInfo info, Array<Text> mods);

Array<crate::lower::model::Item> def_items(const Lx& lx, const crate::check::env::Def& d, const Array<std::tuple<Text, bool>>& roots);

prism_rtl::JobRef<Array<crate::lower::model::Item>> start_def_items(Lx lx, crate::check::env::Def d, Array<std::tuple<Text, bool>> roots);

Array<crate::lower::model::Item> node_items(const crate::lower::model::NodeDef& n);

Array<crate::lower::model::Item> ty_defs(const Lx& lx, const crate::check::env::TyInfo& ti);

prism_rtl::JobRef<Array<crate::lower::model::Item>> start_ty_defs(Lx lx, crate::check::env::TyInfo ti);

bool ty_podable(const Lx& lx, const crate::check::types::Ty& t, const Array<Text>& seen);

prism_rtl::JobRef<bool> start_ty_podable(Lx lx, crate::check::types::Ty t, Array<Text> seen);

bool ty_has_eq(const Lx& lx, const crate::check::types::Ty& t, const Array<Text>& seen);

bool has_own_eq(const Lx& lx, const Text& tn);

crate::lower::model::OutTy case_field(const Lx& lx, const Text& ck, const Nat& i, const crate::check::types::Ty& t);

prism_rtl::JobRef<crate::lower::model::OutTy> start_case_field(Lx lx, Text ck, Nat i, crate::check::types::Ty t);

Text type_doc(const Lx& lx, const crate::check::env::TyInfo& ti);

crate::lower::model::TagDef tag_def_of(const Lx& lx, const crate::check::env::TagInfo& tg);

prism_rtl::JobRef<crate::lower::model::TagDef> start_tag_def_of(Lx lx, crate::check::env::TagInfo tg);

Array<std::tuple<Text, crate::check::types::Ty>> level_fields(const crate::check::env::TagInfo& tg);

Array<crate::check::env::TagInfo> kind_tags(const Lx& lx, const Text& kind, const Array<Text>& mods);

crate::lower::model::RowDef row_def_of(const Lx& lx, const crate::check::env::TyInfo& ti);

prism_rtl::JobRef<crate::lower::model::RowDef> start_row_def_of(Lx lx, crate::check::env::TyInfo ti);

crate::lower::model::RowDef elem_row(const Lx& lx, const Array<Text>& mods);

prism_rtl::JobRef<crate::lower::model::RowDef> start_elem_row(Lx lx, Array<Text> mods);

crate::lower::model::AnswerDef answer_enum(const Lx& lx, const Array<Text>& mods);

prism_rtl::JobRef<crate::lower::model::AnswerDef> start_answer_enum(Lx lx, Array<Text> mods);

crate::lower::model::OutTy answer_ty(const Lx& lx, const crate::check::env::TagInfo& tg);

prism_rtl::JobRef<crate::lower::model::OutTy> start_answer_ty(Lx lx, crate::check::env::TagInfo tg);

std::tuple<Text, Text> tag_paths(const Lx& lx, const crate::check::env::TagInfo& tg);

Text variant_of(const Lx& lx, const crate::check::env::TagInfo& tg);

Text kind_path(const Lx& lx, const Text& kind);

crate::lower::model::CheckDef check_def_of(const Lx& lx, const crate::syntax::CheckDecl& c);

prism_rtl::JobRef<crate::lower::model::CheckDef> start_check_def_of(Lx lx, crate::syntax::CheckDecl c);

}  // namespace lower


namespace lower {

/// The step machine of `OutTyOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OutTyOf: unbounded fn Lx, Ty -> OutTy
struct OutTyOf : prism_rtl::Job<crate::lower::model::OutTy> {
    Lx lx;
    crate::check::types::Ty t;
    OutTyOf(Lx lx, crate::check::types::Ty t) : lx(std::move(lx)), t(std::move(t)) {}
    prism_rtl::Turn<crate::lower::model::OutTy> cycle() const override;
};


/// The step machine of `RustTyOfParams`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustTyOfParams: unbounded fn Lx, [Ty] -> OutTy
struct RustTyOfParams : prism_rtl::Job<crate::lower::model::OutTy> {
    Lx lx;
    Array<crate::check::types::Ty> ps;
    RustTyOfParams(Lx lx, Array<crate::check::types::Ty> ps) : lx(std::move(lx)), ps(std::move(ps)) {}
    prism_rtl::Turn<crate::lower::model::OutTy> cycle() const override;
};


/// The step machine of `NamedTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NamedTy: unbounded fn Lx, Text, [OutTy] -> OutTy
struct NamedTy : prism_rtl::Job<crate::lower::model::OutTy> {
    Lx lx;
    Text n;
    Array<crate::lower::model::OutTy> args;
    NamedTy(Lx lx, Text n, Array<crate::lower::model::OutTy> args) : lx(std::move(lx)), n(std::move(n)), args(std::move(args)) {}
    prism_rtl::Turn<crate::lower::model::OutTy> cycle() const override;
};


/// The step machine of `Layouts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Layouts: unbounded fn G -> (Text ==> [Bool])
struct Layouts : prism_rtl::Job<Map<Text, Array<bool>>> {
    crate::check::env::G g;
    Layouts(crate::check::env::G g) : g(std::move(g)) {}
    prism_rtl::Turn<Map<Text, Array<bool>>> cycle() const override;
};


/// The step machine of `Reaches`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Reaches: unbounded fn G, Ty, Text, [Text] -> Bool
struct Reaches : prism_rtl::Job<bool> {
    crate::check::env::G g;
    crate::check::types::Ty t;
    Text target;
    Array<Text> seen;
    Reaches(crate::check::env::G g, crate::check::types::Ty t, Text target, Array<Text> seen) : g(std::move(g)), t(std::move(t)), target(std::move(target)), seen(std::move(seen)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `Floaty`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Floaty: unbounded fn G, Ty, [Text] -> Bool
struct Floaty : prism_rtl::Job<bool> {
    crate::check::env::G g;
    crate::check::types::Ty t;
    Array<Text> seen;
    Floaty(crate::check::env::G g, crate::check::types::Ty t, Array<Text> seen) : g(std::move(g)), t(std::move(t)), seen(std::move(seen)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `Podable`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Podable: unbounded fn OutTy -> Bool
struct Podable : prism_rtl::Job<bool> {
    crate::lower::model::OutTy t;
    Podable(crate::lower::model::OutTy t) : t(std::move(t)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `LiteralValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LiteralValue: unbounded fn Lx, Env, Literal, Range, Bool -> Vl
struct LiteralValue : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    crate::syntax::Literal l;
    crate::syntax::Range span;
    bool neg;
    LiteralValue(Lx lx, Env env, crate::syntax::Literal l, crate::syntax::Range span, bool neg) : lx(std::move(lx)), env(std::move(env)), l(std::move(l)), span(std::move(span)), neg(std::move(neg)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `TextValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TextValue: unbounded fn Lx, Env, [TextSeg] -> Vl
struct TextValue : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    Array<crate::syntax::TextSeg> segs;
    TextValue(Lx lx, Env env, Array<crate::syntax::TextSeg> segs) : lx(std::move(lx)), env(std::move(env)), segs(std::move(segs)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `SegEx`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SegEx: unbounded fn Lx, Env, TextSeg -> Ex
struct SegEx : prism_rtl::Job<crate::lower::model::Ex> {
    Lx lx;
    Env env;
    crate::syntax::TextSeg text_seg2;
    SegEx(Lx lx, Env env, crate::syntax::TextSeg text_seg2) : lx(std::move(lx)), env(std::move(env)), text_seg2(std::move(text_seg2)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `ValueOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ValueOf: unbounded fn Lx, Env, Expr -> Vl
struct ValueOf : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    crate::syntax::Expr e;
    ValueOf(Lx lx, Env env, crate::syntax::Expr e) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `UnboundValueOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UnboundValueOf: unbounded fn Lx, Env, Expr -> Vl
struct UnboundValueOf : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    crate::syntax::Expr e;
    UnboundValueOf(Lx lx, Env env, crate::syntax::Expr e) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `IsEventValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IsEventValue: unbounded fn Lx, Env, Expr -> Bool
struct IsEventValue : prism_rtl::Job<bool> {
    Lx lx;
    Env env;
    crate::syntax::Expr e;
    IsEventValue(Lx lx, Env env, crate::syntax::Expr e) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `HasEventSource`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// HasEventSource: unbounded fn Lx, Env, Expr -> Bool
struct HasEventSource : prism_rtl::Job<bool> {
    Lx lx;
    Env env;
    crate::syntax::Expr e;
    HasEventSource(Lx lx, Env env, crate::syntax::Expr e) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `IsEventSource`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IsEventSource: unbounded fn Lx, Env, Expr -> Bool
struct IsEventSource : prism_rtl::Job<bool> {
    Lx lx;
    Env env;
    crate::syntax::Expr c;
    IsEventSource(Lx lx, Env env, crate::syntax::Expr c) : lx(std::move(lx)), env(std::move(env)), c(std::move(c)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `EventValueOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// EventValueOf: unbounded fn Lx, Env, Expr -> Vl
struct EventValueOf : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    crate::syntax::Expr e;
    EventValueOf(Lx lx, Env env, crate::syntax::Expr e) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `ValueByKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ValueByKind: unbounded fn Lx, Env, Expr -> Vl
struct ValueByKind : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    crate::syntax::Expr e;
    ValueByKind(Lx lx, Env env, crate::syntax::Expr e) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `PureBlueprint`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PureBlueprint: unbounded fn Lx, Env, Expr, OutTy -> Vl
struct PureBlueprint : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    crate::syntax::Expr x;
    crate::lower::model::OutTy t;
    PureBlueprint(Lx lx, Env env, crate::syntax::Expr x, crate::lower::model::OutTy t) : lx(std::move(lx)), env(std::move(env)), x(std::move(x)), t(std::move(t)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `PlainBlueprint`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PlainBlueprint: unbounded fn Lx, Env, Expr, Text, OutTy -> Vl
struct PlainBlueprint : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    crate::syntax::Expr x;
    Text variant;
    crate::lower::model::OutTy t;
    PlainBlueprint(Lx lx, Env env, crate::syntax::Expr x, Text variant, crate::lower::model::OutTy t) : lx(std::move(lx)), env(std::move(env)), x(std::move(x)), variant(std::move(variant)), t(std::move(t)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `DynamicBlueprint`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DynamicBlueprint: unbounded fn Lx, Env, Expr, Expr, Text, OutTy -> Vl
struct DynamicBlueprint : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    crate::syntax::Expr x;
    crate::syntax::Expr d;
    Text variant;
    crate::lower::model::OutTy t;
    DynamicBlueprint(Lx lx, Env env, crate::syntax::Expr x, crate::syntax::Expr d, Text variant, crate::lower::model::OutTy t) : lx(std::move(lx)), env(std::move(env)), x(std::move(x)), d(std::move(d)), variant(std::move(variant)), t(std::move(t)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `ElementBlueprint`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ElementBlueprint: unbounded fn Lx, Env, [Arg], OutTy -> Vl
struct ElementBlueprint : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    Array<crate::syntax::Arg> args;
    crate::lower::model::OutTy t;
    ElementBlueprint(Lx lx, Env env, Array<crate::syntax::Arg> args, crate::lower::model::OutTy t) : lx(std::move(lx)), env(std::move(env)), args(std::move(args)), t(std::move(t)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `NameValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NameValue: unbounded fn Lx, Env, SName, Range -> Vl
struct NameValue : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    crate::syntax::SName n;
    crate::syntax::Range span;
    NameValue(Lx lx, Env env, crate::syntax::SName n, crate::syntax::Range span) : lx(std::move(lx)), env(std::move(env)), n(std::move(n)), span(std::move(span)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `GlobalValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GlobalValue: unbounded fn Lx, Text, Range, OutTy -> Vl
struct GlobalValue : prism_rtl::Job<Vl> {
    Lx lx;
    Text qk;
    crate::syntax::Range span;
    crate::lower::model::OutTy t;
    GlobalValue(Lx lx, Text qk, crate::syntax::Range span, crate::lower::model::OutTy t) : lx(std::move(lx)), qk(std::move(qk)), span(std::move(span)), t(std::move(t)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `Application`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Application: unbounded fn Lx, Env, Expr, [Arg], Range -> Vl
struct Application : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    crate::syntax::Expr callee;
    Array<crate::syntax::Arg> args;
    crate::syntax::Range span;
    Application(Lx lx, Env env, crate::syntax::Expr callee, Array<crate::syntax::Arg> args, crate::syntax::Range span) : lx(std::move(lx)), env(std::move(env)), callee(std::move(callee)), args(std::move(args)), span(std::move(span)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `InlineLocalFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InlineLocalFn: unbounded fn Lx, Env, FnClause, [Arg], OutTy -> Vl
struct InlineLocalFn : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    crate::syntax::FnClause c;
    Array<crate::syntax::Arg> args;
    crate::lower::model::OutTy t;
    InlineLocalFn(Lx lx, Env env, crate::syntax::FnClause c, Array<crate::syntax::Arg> args, crate::lower::model::OutTy t) : lx(std::move(lx)), env(std::move(env)), c(std::move(c)), args(std::move(args)), t(std::move(t)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `Argument`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Argument: unbounded fn Lx, Env, Expr -> Ex
struct Argument : prism_rtl::Job<crate::lower::model::Ex> {
    Lx lx;
    Env env;
    crate::syntax::Expr e;
    Argument(Lx lx, Env env, crate::syntax::Expr e) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `ArgumentByKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ArgumentByKind: unbounded fn Lx, Env, Expr -> Ex
struct ArgumentByKind : prism_rtl::Job<crate::lower::model::Ex> {
    Lx lx;
    Env env;
    crate::syntax::Expr e;
    ArgumentByKind(Lx lx, Env env, crate::syntax::Expr e) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `TagValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TagValue: unbounded fn Lx, Env, TagInfo, [Arg] -> Vl
struct TagValue : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    crate::check::env::TagInfo tg;
    Array<crate::syntax::Arg> args;
    TagValue(Lx lx, Env env, crate::check::env::TagInfo tg, Array<crate::syntax::Arg> args) : lx(std::move(lx)), env(std::move(env)), tg(std::move(tg)), args(std::move(args)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `GlobalCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GlobalCall: unbounded fn Lx, Env, Text, [Arg], Range, OutTy -> Vl
struct GlobalCall : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    Text qk;
    Array<crate::syntax::Arg> args;
    crate::syntax::Range span;
    crate::lower::model::OutTy t;
    GlobalCall(Lx lx, Env env, Text qk, Array<crate::syntax::Arg> args, crate::syntax::Range span, crate::lower::model::OutTy t) : lx(std::move(lx)), env(std::move(env)), qk(std::move(qk)), args(std::move(args)), span(std::move(span)), t(std::move(t)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `ArgsFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ArgsFor: unbounded fn Lx, Env, ValInfo, [Arg] -> [Ex]
struct ArgsFor : prism_rtl::Job<Array<crate::lower::model::Ex>> {
    Lx lx;
    Env env;
    crate::check::env::ValInfo v_;
    Array<crate::syntax::Arg> args;
    ArgsFor(Lx lx, Env env, crate::check::env::ValInfo v_, Array<crate::syntax::Arg> args) : lx(std::move(lx)), env(std::move(env)), v_(std::move(v_)), args(std::move(args)) {}
    prism_rtl::Turn<Array<crate::lower::model::Ex>> cycle() const override;
};


/// The step machine of `CtorApp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CtorApp: unbounded fn Lx, Env, CtorInfo, [Arg], Range -> Vl
struct CtorApp : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    crate::check::env::CtorInfo c;
    Array<crate::syntax::Arg> args;
    crate::syntax::Range span;
    CtorApp(Lx lx, Env env, crate::check::env::CtorInfo c, Array<crate::syntax::Arg> args, crate::syntax::Range span) : lx(std::move(lx)), env(std::move(env)), c(std::move(c)), args(std::move(args)), span(std::move(span)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `CtorFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CtorFn: unbounded fn Lx, CtorInfo, [OutTy], Range, OutTy, Bool -> Vl
struct CtorFn : prism_rtl::Job<Vl> {
    Lx lx;
    crate::check::env::CtorInfo c;
    Array<crate::lower::model::OutTy> pts;
    crate::syntax::Range span;
    crate::lower::model::OutTy t;
    bool job;
    CtorFn(Lx lx, crate::check::env::CtorInfo c, Array<crate::lower::model::OutTy> pts, crate::syntax::Range span, crate::lower::model::OutTy t, bool job) : lx(std::move(lx)), c(std::move(c)), pts(std::move(pts)), span(std::move(span)), t(std::move(t)), job(std::move(job)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `CtorArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CtorArgs: unbounded fn Lx, Env, CtorInfo, [Arg] -> [Ex]
struct CtorArgs : prism_rtl::Job<Array<crate::lower::model::Ex>> {
    Lx lx;
    Env env;
    crate::check::env::CtorInfo c;
    Array<crate::syntax::Arg> args;
    CtorArgs(Lx lx, Env env, crate::check::env::CtorInfo c, Array<crate::syntax::Arg> args) : lx(std::move(lx)), env(std::move(env)), c(std::move(c)), args(std::move(args)) {}
    prism_rtl::Turn<Array<crate::lower::model::Ex>> cycle() const override;
};


/// The step machine of `MethodCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MethodCall: unbounded fn Lx, Env, ValInfo, [Arg], Range, OutTy -> Vl
struct MethodCall : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    crate::check::env::ValInfo v_;
    Array<crate::syntax::Arg> args;
    crate::syntax::Range span;
    crate::lower::model::OutTy t;
    MethodCall(Lx lx, Env env, crate::check::env::ValInfo v_, Array<crate::syntax::Arg> args, crate::syntax::Range span, crate::lower::model::OutTy t) : lx(std::move(lx)), env(std::move(env)), v_(std::move(v_)), args(std::move(args)), span(std::move(span)), t(std::move(t)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `PreludeMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PreludeMethod: unbounded fn Lx, Text, Text, [Vl], Range, OutTy -> Vl
struct PreludeMethod : prism_rtl::Job<Vl> {
    Lx lx;
    Text cls;
    Text m;
    Array<Vl> vals;
    crate::syntax::Range span;
    crate::lower::model::OutTy t;
    PreludeMethod(Lx lx, Text cls, Text m, Array<Vl> vals, crate::syntax::Range span, crate::lower::model::OutTy t) : lx(std::move(lx)), cls(std::move(cls)), m(std::move(m)), vals(std::move(vals)), span(std::move(span)), t(std::move(t)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `BinaryValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BinaryValue: unbounded fn Lx, Env, Text, Expr, Expr, Range -> Vl
struct BinaryValue : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    Text op;
    crate::syntax::Expr l;
    crate::syntax::Expr r;
    crate::syntax::Range span;
    BinaryValue(Lx lx, Env env, Text op, crate::syntax::Expr l, crate::syntax::Expr r, crate::syntax::Range span) : lx(std::move(lx)), env(std::move(env)), op(std::move(op)), l(std::move(l)), r(std::move(r)), span(std::move(span)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `PreludeCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PreludeCall: unbounded fn Lx, Env, Text, [Arg], Range, OutTy -> Vl
struct PreludeCall : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    Text qk;
    Array<crate::syntax::Arg> args;
    crate::syntax::Range span;
    crate::lower::model::OutTy t;
    PreludeCall(Lx lx, Env env, Text qk, Array<crate::syntax::Arg> args, crate::syntax::Range span, crate::lower::model::OutTy t) : lx(std::move(lx)), env(std::move(env)), qk(std::move(qk)), args(std::move(args)), span(std::move(span)), t(std::move(t)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `PreludeJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?PreludeJob: unbounded fn Lx, Env, Text, [Arg] -> ?Ex
struct PreludeJob : prism_rtl::Job<std::optional<crate::lower::model::Ex>> {
    Lx lx;
    Env env;
    Text variant;
    Array<crate::syntax::Arg> args;
    PreludeJob(Lx lx, Env env, Text variant, Array<crate::syntax::Arg> args) : lx(std::move(lx)), env(std::move(env)), variant(std::move(variant)), args(std::move(args)) {}
    prism_rtl::Turn<std::optional<crate::lower::model::Ex>> cycle() const override;
};


/// The step machine of `PreludeJobCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?PreludeJobCall: unbounded fn Lx, Env, Expr -> ?Ex
struct PreludeJobCall : prism_rtl::Job<std::optional<crate::lower::model::Ex>> {
    Lx lx;
    Env env;
    crate::syntax::Expr e;
    PreludeJobCall(Lx lx, Env env, crate::syntax::Expr e) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)) {}
    prism_rtl::Turn<std::optional<crate::lower::model::Ex>> cycle() const override;
};


/// The step machine of `AsJobValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AsJobValue: unbounded fn Lx, Env, Expr -> Ex
struct AsJobValue : prism_rtl::Job<crate::lower::model::Ex> {
    Lx lx;
    Env env;
    crate::syntax::Expr e;
    AsJobValue(Lx lx, Env env, crate::syntax::Expr e) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `NamedArgsOwned`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NamedArgsOwned: unbounded fn Lx, Env, Text, [Arg] -> [Ex]
struct NamedArgsOwned : prism_rtl::Job<Array<crate::lower::model::Ex>> {
    Lx lx;
    Env env;
    Text qk;
    Array<crate::syntax::Arg> args;
    NamedArgsOwned(Lx lx, Env env, Text qk, Array<crate::syntax::Arg> args) : lx(std::move(lx)), env(std::move(env)), qk(std::move(qk)), args(std::move(args)) {}
    prism_rtl::Turn<Array<crate::lower::model::Ex>> cycle() const override;
};


/// The step machine of `StartArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StartArgs: unbounded fn Lx, Env, Vl, [Arg] -> [Ex]
struct StartArgs : prism_rtl::Job<Array<crate::lower::model::Ex>> {
    Lx lx;
    Env env;
    Vl f;
    Array<crate::syntax::Arg> args;
    StartArgs(Lx lx, Env env, Vl f, Array<crate::syntax::Arg> args) : lx(std::move(lx)), env(std::move(env)), f(std::move(f)), args(std::move(args)) {}
    prism_rtl::Turn<Array<crate::lower::model::Ex>> cycle() const override;
};


/// The step machine of `FieldValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FieldValue: unbounded fn Lx, Env, Expr, Text -> Vl
struct FieldValue : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    crate::syntax::Expr r;
    Text name;
    FieldValue(Lx lx, Env env, crate::syntax::Expr r, Text name) : lx(std::move(lx)), env(std::move(env)), r(std::move(r)), name(std::move(name)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `FieldInfo`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FieldInfo: unbounded fn Lx, Ty, Text -> ((OutTy, Bool))
struct FieldInfo : prism_rtl::Job<std::tuple<crate::lower::model::OutTy, bool>> {
    Lx lx;
    crate::check::types::Ty rty;
    Text name;
    FieldInfo(Lx lx, crate::check::types::Ty rty, Text name) : lx(std::move(lx)), rty(std::move(rty)), name(std::move(name)) {}
    prism_rtl::Turn<std::tuple<crate::lower::model::OutTy, bool>> cycle() const override;
};


/// The step machine of `Instantiated`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Instantiated: unbounded fn Ty, [Text], [Ty] -> Ty
struct Instantiated : prism_rtl::Job<crate::check::types::Ty> {
    crate::check::types::Ty t;
    Array<Text> params;
    Array<crate::check::types::Ty> args;
    Instantiated(crate::check::types::Ty t, Array<Text> params, Array<crate::check::types::Ty> args) : t(std::move(t)), params(std::move(params)), args(std::move(args)) {}
    prism_rtl::Turn<crate::check::types::Ty> cycle() const override;
};


/// The step machine of `IndexValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IndexValue: unbounded fn Lx, Env, Expr, Expr, OutTy -> Vl
struct IndexValue : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    crate::syntax::Expr r;
    crate::syntax::Expr i;
    crate::lower::model::OutTy t;
    IndexValue(Lx lx, Env env, crate::syntax::Expr r, crate::syntax::Expr i, crate::lower::model::OutTy t) : lx(std::move(lx)), env(std::move(env)), r(std::move(r)), i(std::move(i)), t(std::move(t)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `ReadNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ReadNames: unbounded fn [Expr] -> [Text]
struct ReadNames : prism_rtl::Job<Array<Text>> {
    Array<crate::syntax::Expr> es;
    ReadNames(Array<crate::syntax::Expr> es) : es(std::move(es)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `LambdaExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LambdaExprs: unbounded fn LambdaBody -> [Expr]
struct LambdaExprs : prism_rtl::Job<Array<crate::syntax::Expr>> {
    crate::syntax::LambdaBody lambda_body0;
    LambdaExprs(crate::syntax::LambdaBody lambda_body0) : lambda_body0(std::move(lambda_body0)) {}
    prism_rtl::Turn<Array<crate::syntax::Expr>> cycle() const override;
};


/// The step machine of `LambdaValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LambdaValue: unbounded fn Lx, Env, Expr, [Pattern], LambdaBody -> Vl
struct LambdaValue : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    crate::syntax::Expr e;
    Array<crate::syntax::Pattern_> ps;
    crate::syntax::LambdaBody body;
    LambdaValue(Lx lx, Env env, crate::syntax::Expr e, Array<crate::syntax::Pattern_> ps, crate::syntax::LambdaBody body) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)), ps(std::move(ps)), body(std::move(body)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `PlainLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PlainLambda: unbounded fn Lx, Env, [Pattern], LambdaBody, OutTy -> Vl
struct PlainLambda : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    Array<crate::syntax::Pattern_> ps;
    crate::syntax::LambdaBody body;
    crate::lower::model::OutTy ft;
    PlainLambda(Lx lx, Env env, Array<crate::syntax::Pattern_> ps, crate::syntax::LambdaBody body, crate::lower::model::OutTy ft) : lx(std::move(lx)), env(std::move(env)), ps(std::move(ps)), body(std::move(body)), ft(std::move(ft)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `LambdaParamTys`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LambdaParamTys: unbounded fn Lx, Expr, Nat -> [OutTy]
struct LambdaParamTys : prism_rtl::Job<Array<crate::lower::model::OutTy>> {
    Lx lx;
    crate::syntax::Expr e;
    Nat n;
    LambdaParamTys(Lx lx, crate::syntax::Expr e, Nat n) : lx(std::move(lx)), e(std::move(e)), n(std::move(n)) {}
    prism_rtl::Turn<Array<crate::lower::model::OutTy>> cycle() const override;
};


/// The step machine of `IsKnownTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IsKnownTy: unbounded fn OutTy -> Bool
struct IsKnownTy : prism_rtl::Job<bool> {
    crate::lower::model::OutTy t;
    IsKnownTy(crate::lower::model::OutTy t) : t(std::move(t)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `JobLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// JobLambda: unbounded fn Lx, Env, [Pattern], LambdaBody, OutTy, OutTy, Bool -> Vl
struct JobLambda : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    Array<crate::syntax::Pattern_> ps;
    crate::syntax::LambdaBody body;
    crate::lower::model::OutTy ft;
    crate::lower::model::OutTy a;
    bool enter;
    JobLambda(Lx lx, Env env, Array<crate::syntax::Pattern_> ps, crate::syntax::LambdaBody body, crate::lower::model::OutTy ft, crate::lower::model::OutTy a, bool enter) : lx(std::move(lx)), env(std::move(env)), ps(std::move(ps)), body(std::move(body)), ft(std::move(ft)), a(std::move(a)), enter(std::move(enter)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `LambdaArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LambdaArg: unbounded fn Lx, Env, [Pattern], LambdaBody, [OutTy] -> Ex
struct LambdaArg : prism_rtl::Job<crate::lower::model::Ex> {
    Lx lx;
    Env env;
    Array<crate::syntax::Pattern_> ps;
    crate::syntax::LambdaBody body;
    Array<crate::lower::model::OutTy> pts;
    LambdaArg(Lx lx, Env env, Array<crate::syntax::Pattern_> ps, crate::syntax::LambdaBody body, Array<crate::lower::model::OutTy> pts) : lx(std::move(lx)), env(std::move(env)), ps(std::move(ps)), body(std::move(body)), pts(std::move(pts)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `LambdaBodyValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LambdaBodyValue: unbounded fn Lx, Env, LambdaBody -> Vl
struct LambdaBodyValue : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    crate::syntax::LambdaBody lambda_body2;
    LambdaBodyValue(Lx lx, Env env, crate::syntax::LambdaBody lambda_body2) : lx(std::move(lx)), env(std::move(env)), lambda_body2(std::move(lambda_body2)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `ClosureParams`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClosureParams: unbounded fn Lx, Env, [Pattern], [OutTy], Bool -> (([Pa], Env))
struct ClosureParams : prism_rtl::Job<std::tuple<Array<crate::lower::model::Pa>, Env>> {
    Lx lx;
    Env env;
    Array<crate::syntax::Pattern_> ps;
    Array<crate::lower::model::OutTy> pts;
    bool typed;
    ClosureParams(Lx lx, Env env, Array<crate::syntax::Pattern_> ps, Array<crate::lower::model::OutTy> pts, bool typed) : lx(std::move(lx)), env(std::move(env)), ps(std::move(ps)), pts(std::move(pts)), typed(std::move(typed)) {}
    prism_rtl::Turn<std::tuple<Array<crate::lower::model::Pa>, Env>> cycle() const override;
};


/// The step machine of `IfValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IfValue: unbounded fn Lx, Env, Cond, Block, ?Block, OutTy -> Vl
struct IfValue : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    crate::syntax::Cond c;
    crate::syntax::Block then_b;
    std::optional<crate::syntax::Block> else_b_opt;
    crate::lower::model::OutTy t;
    IfValue(Lx lx, Env env, crate::syntax::Cond c, crate::syntax::Block then_b, std::optional<crate::syntax::Block> else_b_opt, crate::lower::model::OutTy t) : lx(std::move(lx)), env(std::move(env)), c(std::move(c)), then_b(std::move(then_b)), else_b_opt(std::move(else_b_opt)), t(std::move(t)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `MatchValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MatchValue: unbounded fn Lx, Env, Expr, [Arm], OutTy, Range -> Vl
struct MatchValue : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    crate::syntax::Expr s;
    Array<crate::syntax::Arm> arms;
    crate::lower::model::OutTy t;
    crate::syntax::Range span;
    MatchValue(Lx lx, Env env, crate::syntax::Expr s, Array<crate::syntax::Arm> arms, crate::lower::model::OutTy t, crate::syntax::Range span) : lx(std::move(lx)), env(std::move(env)), s(std::move(s)), arms(std::move(arms)), t(std::move(t)), span(std::move(span)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `ArmPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ArmPat: unbounded fn Lx, ?Pattern, Ty, Holding, Text -> PatOut
struct ArmPat : prism_rtl::Job<PatOut> {
    Lx lx;
    std::optional<crate::syntax::Pattern_> opt1;
    crate::check::types::Ty ty;
    Holding mode;
    Text fresh;
    ArmPat(Lx lx, std::optional<crate::syntax::Pattern_> opt1, crate::check::types::Ty ty, Holding mode, Text fresh) : lx(std::move(lx)), opt1(std::move(opt1)), ty(std::move(ty)), mode(std::move(mode)), fresh(std::move(fresh)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `BlockValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BlockValue: unbounded fn Lx, Env, Block -> Vl
struct BlockValue : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    crate::syntax::Block b;
    BlockValue(Lx lx, Env env, crate::syntax::Block b) : lx(std::move(lx)), env(std::move(env)), b(std::move(b)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `BlockTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BlockTy: unbounded fn Lx, Block -> OutTy
struct BlockTy : prism_rtl::Job<crate::lower::model::OutTy> {
    Lx lx;
    crate::syntax::Block b;
    BlockTy(Lx lx, crate::syntax::Block b) : lx(std::move(lx)), b(std::move(b)) {}
    prism_rtl::Turn<crate::lower::model::OutTy> cycle() const override;
};


/// The step machine of `PlainBlockValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PlainBlockValue: unbounded fn Lx, Env, Block -> Vl
struct PlainBlockValue : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    crate::syntax::Block b;
    PlainBlockValue(Lx lx, Env env, crate::syntax::Block b) : lx(std::move(lx)), env(std::move(env)), b(std::move(b)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `BlockStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BlockStmt: unbounded fn Lx, Env, Stmt -> (([Do], Env))
struct BlockStmt : prism_rtl::Job<std::tuple<Array<crate::lower::model::Do>, Env>> {
    Lx lx;
    Env env;
    crate::syntax::Stmt s;
    BlockStmt(Lx lx, Env env, crate::syntax::Stmt s) : lx(std::move(lx)), env(std::move(env)), s(std::move(s)) {}
    prism_rtl::Turn<std::tuple<Array<crate::lower::model::Do>, Env>> cycle() const override;
};


/// The step machine of `GenericLet`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GenericLet: unbounded fn Lx, Env, SName, GenNote, Expr -> (([Do], Env))
struct GenericLet : prism_rtl::Job<std::tuple<Array<crate::lower::model::Do>, Env>> {
    Lx lx;
    Env env;
    crate::syntax::SName n;
    crate::check::typed::GenNote gn;
    crate::syntax::Expr x;
    GenericLet(Lx lx, Env env, crate::syntax::SName n, crate::check::typed::GenNote gn, crate::syntax::Expr x) : lx(std::move(lx)), env(std::move(env)), n(std::move(n)), gn(std::move(gn)), x(std::move(x)) {}
    prism_rtl::Turn<std::tuple<Array<crate::lower::model::Do>, Env>> cycle() const override;
};


/// The step machine of `Instantiations`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Instantiations: unbounded fn Lx, GenNote -> [(([((Text, Ty))], [((Text, Col))]))]
struct Instantiations : prism_rtl::Job<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> {
    Lx lx;
    crate::check::typed::GenNote gn;
    Instantiations(Lx lx, crate::check::typed::GenNote gn) : lx(std::move(lx)), gn(std::move(gn)) {}
    prism_rtl::Turn<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> cycle() const override;
};


/// The step machine of `Expanded`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Expanded: unbounded fn Lx, (([((Text, Ty))], [((Text, Col))])) -> [(([((Text, Ty))], [((Text, Col))]))]
struct Expanded : prism_rtl::Job<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> {
    Lx lx;
    std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>> i;
    Expanded(Lx lx, std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>> i) : lx(std::move(lx)), i(std::move(i)) {}
    prism_rtl::Turn<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> cycle() const override;
};


/// The step machine of `OpenQ`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?OpenQ: unbounded fn Lx, (([((Text, Ty))], [((Text, Col))])) -> ?Text
struct OpenQ : prism_rtl::Job<std::optional<Text>> {
    Lx lx;
    std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>> arg1;
    OpenQ(Lx lx, std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>> arg1) : lx(std::move(lx)), arg1(std::move(arg1)) {}
    prism_rtl::Turn<std::optional<Text>> cycle() const override;
};


/// The step machine of `OpenTyQs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OpenTyQs: unbounded fn Lx, Ty -> [Text]
struct OpenTyQs : prism_rtl::Job<Array<Text>> {
    Lx lx;
    crate::check::types::Ty t;
    OpenTyQs(Lx lx, crate::check::types::Ty t) : lx(std::move(lx)), t(std::move(t)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `WidgetLetLx`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WidgetLetLx: unbounded fn Lx, Range -> Lx
struct WidgetLetLx : prism_rtl::Job<Lx> {
    Lx lx;
    crate::syntax::Range span;
    WidgetLetLx(Lx lx, crate::syntax::Range span) : lx(std::move(lx)), span(std::move(span)) {}
    prism_rtl::Turn<Lx> cycle() const override;
};


/// The step machine of `PlainLet`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PlainLet: unbounded fn Lx, Env, Stmt, Pattern, Expr -> (([Do], Env))
struct PlainLet : prism_rtl::Job<std::tuple<Array<crate::lower::model::Do>, Env>> {
    Lx lx;
    Env env;
    crate::syntax::Stmt s;
    crate::syntax::Pattern_ p_;
    crate::syntax::Expr x;
    PlainLet(Lx lx, Env env, crate::syntax::Stmt s, crate::syntax::Pattern_ p_, crate::syntax::Expr x) : lx(std::move(lx)), env(std::move(env)), s(std::move(s)), p_(std::move(p_)), x(std::move(x)) {}
    prism_rtl::Turn<std::tuple<Array<crate::lower::model::Do>, Env>> cycle() const override;
};


/// The step machine of `RustPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustPat: unbounded fn Lx, Pattern, Ty, Holding, Text -> PatOut
struct RustPat : prism_rtl::Job<PatOut> {
    Lx lx;
    crate::syntax::Pattern_ p_;
    crate::check::types::Ty ty;
    Holding mode;
    Text fresh;
    RustPat(Lx lx, crate::syntax::Pattern_ p_, crate::check::types::Ty ty, Holding mode, Text fresh) : lx(std::move(lx)), p_(std::move(p_)), ty(std::move(ty)), mode(std::move(mode)), fresh(std::move(fresh)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `WrapPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WrapPat: unbounded fn Lx, Text, Pattern, Ty, Holding, Text -> PatOut
struct WrapPat : prism_rtl::Job<PatOut> {
    Lx lx;
    Text ctor;
    crate::syntax::Pattern_ q;
    crate::check::types::Ty inner;
    Holding mode;
    Text fresh;
    WrapPat(Lx lx, Text ctor, crate::syntax::Pattern_ q, crate::check::types::Ty inner, Holding mode, Text fresh) : lx(std::move(lx)), ctor(std::move(ctor)), q(std::move(q)), inner(std::move(inner)), mode(std::move(mode)), fresh(std::move(fresh)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `LitPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LitPat: unbounded fn Lx, Literal, Ty, Holding, Text, Bool -> PatOut
struct LitPat : prism_rtl::Job<PatOut> {
    Lx lx;
    crate::syntax::Literal l;
    crate::check::types::Ty ty;
    Holding mode;
    Text fresh;
    bool neg;
    LitPat(Lx lx, crate::syntax::Literal l, crate::check::types::Ty ty, Holding mode, Text fresh, bool neg) : lx(std::move(lx)), l(std::move(l)), ty(std::move(ty)), mode(std::move(mode)), fresh(std::move(fresh)), neg(std::move(neg)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `CtorPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CtorPat: unbounded fn Lx, SName, [Pattern], Ty, Holding, Text -> PatOut
struct CtorPat : prism_rtl::Job<PatOut> {
    Lx lx;
    crate::syntax::SName n;
    Array<crate::syntax::Pattern_> ps;
    crate::check::types::Ty ty;
    Holding mode;
    Text fresh;
    CtorPat(Lx lx, crate::syntax::SName n, Array<crate::syntax::Pattern_> ps, crate::check::types::Ty ty, Holding mode, Text fresh) : lx(std::move(lx)), n(std::move(n)), ps(std::move(ps)), ty(std::move(ty)), mode(std::move(mode)), fresh(std::move(fresh)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `SubPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SubPat: unbounded fn Lx, CtorInfo, Nat, Pattern, Ty, Holding, Text -> PatOut
struct SubPat : prism_rtl::Job<PatOut> {
    Lx lx;
    crate::check::env::CtorInfo c;
    Nat i;
    crate::syntax::Pattern_ p_;
    crate::check::types::Ty ty;
    Holding mode;
    Text fresh;
    SubPat(Lx lx, crate::check::env::CtorInfo c, Nat i, crate::syntax::Pattern_ p_, crate::check::types::Ty ty, Holding mode, Text fresh) : lx(std::move(lx)), c(std::move(c)), i(std::move(i)), p_(std::move(p_)), ty(std::move(ty)), mode(std::move(mode)), fresh(std::move(fresh)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `BehindRc`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BehindRc: unbounded fn Lx, Pattern, Ty, Holding, Text -> PatOut
struct BehindRc : prism_rtl::Job<PatOut> {
    Lx lx;
    crate::syntax::Pattern_ p_;
    crate::check::types::Ty ty;
    Holding rc_mode;
    Text fresh;
    BehindRc(Lx lx, crate::syntax::Pattern_ p_, crate::check::types::Ty ty, Holding rc_mode, Text fresh) : lx(std::move(lx)), p_(std::move(p_)), ty(std::move(ty)), rc_mode(std::move(rc_mode)), fresh(std::move(fresh)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `RecordPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RecordPat: unbounded fn Lx, SName, [FieldPat], Bool, Ty, Holding, Text -> PatOut
struct RecordPat : prism_rtl::Job<PatOut> {
    Lx lx;
    crate::syntax::SName n;
    Array<crate::syntax::FieldPat> fps;
    bool rest;
    crate::check::types::Ty ty;
    Holding mode;
    Text fresh;
    RecordPat(Lx lx, crate::syntax::SName n, Array<crate::syntax::FieldPat> fps, bool rest, crate::check::types::Ty ty, Holding mode, Text fresh) : lx(std::move(lx)), n(std::move(n)), fps(std::move(fps)), rest(std::move(rest)), ty(std::move(ty)), mode(std::move(mode)), fresh(std::move(fresh)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `FieldsPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FieldsPat: unbounded fn Lx, CtorInfo, [FieldPat], Bool, Ty, Holding, Text, Text -> PatOut
struct FieldsPat : prism_rtl::Job<PatOut> {
    Lx lx;
    crate::check::env::CtorInfo c;
    Array<crate::syntax::FieldPat> fps;
    bool rest;
    crate::check::types::Ty ty;
    Holding mode;
    Text fresh;
    Text ty_path;
    FieldsPat(Lx lx, crate::check::env::CtorInfo c, Array<crate::syntax::FieldPat> fps, bool rest, crate::check::types::Ty ty, Holding mode, Text fresh, Text ty_path) : lx(std::move(lx)), c(std::move(c)), fps(std::move(fps)), rest(std::move(rest)), ty(std::move(ty)), mode(std::move(mode)), fresh(std::move(fresh)), ty_path(std::move(ty_path)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `TagPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TagPat: unbounded fn Lx, TagInfo, [FieldPat], Bool, Ty, Holding, Text -> PatOut
struct TagPat : prism_rtl::Job<PatOut> {
    Lx lx;
    crate::check::env::TagInfo tg;
    Array<crate::syntax::FieldPat> fps;
    bool rest;
    crate::check::types::Ty ty;
    Holding mode;
    Text fresh;
    TagPat(Lx lx, crate::check::env::TagInfo tg, Array<crate::syntax::FieldPat> fps, bool rest, crate::check::types::Ty ty, Holding mode, Text fresh) : lx(std::move(lx)), tg(std::move(tg)), fps(std::move(fps)), rest(std::move(rest)), ty(std::move(ty)), mode(std::move(mode)), fresh(std::move(fresh)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `LiveFieldPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LiveFieldPat: unbounded fn Lx, Pattern, Text, Text, Ty, Text -> PatOut
struct LiveFieldPat : prism_rtl::Job<PatOut> {
    Lx lx;
    crate::syntax::Pattern_ p_;
    Text variant;
    Text fname;
    crate::check::types::Ty ft;
    Text fresh;
    LiveFieldPat(Lx lx, crate::syntax::Pattern_ p_, Text variant, Text fname, crate::check::types::Ty ft, Text fresh) : lx(std::move(lx)), p_(std::move(p_)), variant(std::move(variant)), fname(std::move(fname)), ft(std::move(ft)), fresh(std::move(fresh)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `FamilyPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FamilyPat: unbounded fn Lx, QualName, Ty, Text -> PatOut
struct FamilyPat : prism_rtl::Job<PatOut> {
    Lx lx;
    crate::syntax::QualName q;
    crate::check::types::Ty ty;
    Text fresh;
    FamilyPat(Lx lx, crate::syntax::QualName q, crate::check::types::Ty ty, Text fresh) : lx(std::move(lx)), q(std::move(q)), ty(std::move(ty)), fresh(std::move(fresh)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `ErrorPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ErrorPat: unbounded fn Lx, [FieldPat], Ty, Holding, Text -> PatOut
struct ErrorPat : prism_rtl::Job<PatOut> {
    Lx lx;
    Array<crate::syntax::FieldPat> fps;
    crate::check::types::Ty ty;
    Holding mode;
    Text fresh;
    ErrorPat(Lx lx, Array<crate::syntax::FieldPat> fps, crate::check::types::Ty ty, Holding mode, Text fresh) : lx(std::move(lx)), fps(std::move(fps)), ty(std::move(ty)), mode(std::move(mode)), fresh(std::move(fresh)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `ArrayPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ArrayPat: unbounded fn Lx, [Pattern], Ty, Holding, Text -> PatOut
struct ArrayPat : prism_rtl::Job<PatOut> {
    Lx lx;
    Array<crate::syntax::Pattern_> ps;
    crate::check::types::Ty ty;
    Holding mode;
    Text fresh;
    ArrayPat(Lx lx, Array<crate::syntax::Pattern_> ps, crate::check::types::Ty ty, Holding mode, Text fresh) : lx(std::move(lx)), ps(std::move(ps)), ty(std::move(ty)), mode(std::move(mode)), fresh(std::move(fresh)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `TemplateValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplateValue: unbounded fn Lx, Env, Template -> Vl
struct TemplateValue : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    crate::syntax::Template tp;
    TemplateValue(Lx lx, Env env, crate::syntax::Template tp) : lx(std::move(lx)), env(std::move(env)), tp(std::move(tp)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `TemplatePartDos`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplatePartDos: unbounded fn Lx, Env, TemplatePart -> [Do]
struct TemplatePartDos : prism_rtl::Job<Array<crate::lower::model::Do>> {
    Lx lx;
    Env env;
    crate::syntax::TemplatePart part;
    TemplatePartDos(Lx lx, Env env, crate::syntax::TemplatePart part) : lx(std::move(lx)), env(std::move(env)), part(std::move(part)) {}
    prism_rtl::Turn<Array<crate::lower::model::Do>> cycle() const override;
};


/// The step machine of `TemplateArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplateArgs: unbounded fn Lx, Env, Text, [Arg], [Ex] -> [Ex]
struct TemplateArgs : prism_rtl::Job<Array<crate::lower::model::Ex>> {
    Lx lx;
    Env env;
    Text qk;
    Array<crate::syntax::Arg> args;
    Array<crate::lower::model::Ex> body;
    TemplateArgs(Lx lx, Env env, Text qk, Array<crate::syntax::Arg> args, Array<crate::lower::model::Ex> body) : lx(std::move(lx)), env(std::move(env)), qk(std::move(qk)), args(std::move(args)), body(std::move(body)) {}
    prism_rtl::Turn<Array<crate::lower::model::Ex>> cycle() const override;
};


/// The step machine of `GivenValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GivenValue: unbounded fn Lx, Env, Block, OutTy, Range -> Vl
struct GivenValue : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    crate::syntax::Block b;
    crate::lower::model::OutTy t;
    crate::syntax::Range span;
    GivenValue(Lx lx, Env env, crate::syntax::Block b, crate::lower::model::OutTy t, crate::syntax::Range span) : lx(std::move(lx)), env(std::move(env)), b(std::move(b)), t(std::move(t)), span(std::move(span)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `UpdateValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdateValue: unbounded fn Lx, Env, Expr, Block, OutTy, Range -> Vl
struct UpdateValue : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    crate::syntax::Expr target;
    crate::syntax::Block b;
    crate::lower::model::OutTy t;
    crate::syntax::Range span;
    UpdateValue(Lx lx, Env env, crate::syntax::Expr target, crate::syntax::Block b, crate::lower::model::OutTy t, crate::syntax::Range span) : lx(std::move(lx)), env(std::move(env)), target(std::move(target)), b(std::move(b)), t(std::move(t)), span(std::move(span)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `UpdStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdStmts: unbounded fn Lx, Env, [Stmt] -> (([Do], Env))
struct UpdStmts : prism_rtl::Job<std::tuple<Array<crate::lower::model::Do>, Env>> {
    Lx lx;
    Env env;
    Array<crate::syntax::Stmt> stmts;
    UpdStmts(Lx lx, Env env, Array<crate::syntax::Stmt> stmts) : lx(std::move(lx)), env(std::move(env)), stmts(std::move(stmts)) {}
    prism_rtl::Turn<std::tuple<Array<crate::lower::model::Do>, Env>> cycle() const override;
};


/// The step machine of `UpdStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdStmt: unbounded fn Lx, Env, Stmt -> (([Do], Env))
struct UpdStmt : prism_rtl::Job<std::tuple<Array<crate::lower::model::Do>, Env>> {
    Lx lx;
    Env env;
    crate::syntax::Stmt s;
    UpdStmt(Lx lx, Env env, crate::syntax::Stmt s) : lx(std::move(lx)), env(std::move(env)), s(std::move(s)) {}
    prism_rtl::Turn<std::tuple<Array<crate::lower::model::Do>, Env>> cycle() const override;
};


/// The step machine of `UpdFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdFor: unbounded fn Lx, Env, ?ForBinders, Expr, Block, Range -> Do
struct UpdFor : prism_rtl::Job<crate::lower::model::Do> {
    Lx lx;
    Env env;
    std::optional<crate::syntax::ForBinders> binders_opt;
    crate::syntax::Expr source;
    crate::syntax::Block body;
    crate::syntax::Range span;
    UpdFor(Lx lx, Env env, std::optional<crate::syntax::ForBinders> binders_opt, crate::syntax::Expr source, crate::syntax::Block body, crate::syntax::Range span) : lx(std::move(lx)), env(std::move(env)), binders_opt(std::move(binders_opt)), source(std::move(source)), body(std::move(body)), span(std::move(span)) {}
    prism_rtl::Turn<crate::lower::model::Do> cycle() const override;
};


/// The step machine of `UpdForRefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdForRefs: unbounded fn Lx, Env, SName, Expr, Block, Range, Ty -> Do
struct UpdForRefs : prism_rtl::Job<crate::lower::model::Do> {
    Lx lx;
    Env env;
    crate::syntax::SName n;
    crate::syntax::Expr source;
    crate::syntax::Block body;
    crate::syntax::Range span;
    crate::check::types::Ty sty;
    UpdForRefs(Lx lx, Env env, crate::syntax::SName n, crate::syntax::Expr source, crate::syntax::Block body, crate::syntax::Range span, crate::check::types::Ty sty) : lx(std::move(lx)), env(std::move(env)), n(std::move(n)), source(std::move(source)), body(std::move(body)), span(std::move(span)), sty(std::move(sty)) {}
    prism_rtl::Turn<crate::lower::model::Do> cycle() const override;
};


/// The step machine of `UpdForValues`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdForValues: unbounded fn Lx, Env, ?ForBinders, Expr, Block, Range, Ty -> Do
struct UpdForValues : prism_rtl::Job<crate::lower::model::Do> {
    Lx lx;
    Env env;
    std::optional<crate::syntax::ForBinders> binders_opt;
    crate::syntax::Expr source;
    crate::syntax::Block body;
    crate::syntax::Range span;
    crate::check::types::Ty sty;
    UpdForValues(Lx lx, Env env, std::optional<crate::syntax::ForBinders> binders_opt, crate::syntax::Expr source, crate::syntax::Block body, crate::syntax::Range span, crate::check::types::Ty sty) : lx(std::move(lx)), env(std::move(env)), binders_opt(std::move(binders_opt)), source(std::move(source)), body(std::move(body)), span(std::move(span)), sty(std::move(sty)) {}
    prism_rtl::Turn<crate::lower::model::Do> cycle() const override;
};


/// The step machine of `UpdIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdIf: unbounded fn Lx, Env, Cond, Block, ?Block -> Do
struct UpdIf : prism_rtl::Job<crate::lower::model::Do> {
    Lx lx;
    Env env;
    crate::syntax::Cond c;
    crate::syntax::Block then_b;
    std::optional<crate::syntax::Block> else_b_opt;
    UpdIf(Lx lx, Env env, crate::syntax::Cond c, crate::syntax::Block then_b, std::optional<crate::syntax::Block> else_b_opt) : lx(std::move(lx)), env(std::move(env)), c(std::move(c)), then_b(std::move(then_b)), else_b_opt(std::move(else_b_opt)) {}
    prism_rtl::Turn<crate::lower::model::Do> cycle() const override;
};


/// The step machine of `UpdMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdMatch: unbounded fn Lx, Env, Expr, [Arm] -> Do
struct UpdMatch : prism_rtl::Job<crate::lower::model::Do> {
    Lx lx;
    Env env;
    crate::syntax::Expr scrut;
    Array<crate::syntax::Arm> arms;
    UpdMatch(Lx lx, Env env, crate::syntax::Expr scrut, Array<crate::syntax::Arm> arms) : lx(std::move(lx)), env(std::move(env)), scrut(std::move(scrut)), arms(std::move(arms)) {}
    prism_rtl::Turn<crate::lower::model::Do> cycle() const override;
};


/// The step machine of `GuardConds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GuardConds: unbounded fn Lx, Env, ?Expr -> [Cc]
struct GuardConds : prism_rtl::Job<Array<crate::lower::model::Cc>> {
    Lx lx;
    Env env;
    std::optional<crate::syntax::Expr> opt2;
    GuardConds(Lx lx, Env env, std::optional<crate::syntax::Expr> opt2) : lx(std::move(lx)), env(std::move(env)), opt2(std::move(opt2)) {}
    prism_rtl::Turn<Array<crate::lower::model::Cc>> cycle() const override;
};


/// The step machine of `PlaceOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PlaceOf: unbounded fn Lx, Env, Expr -> Ex
struct PlaceOf : prism_rtl::Job<crate::lower::model::Ex> {
    Lx lx;
    Env env;
    crate::syntax::Expr e;
    PlaceOf(Lx lx, Env env, crate::syntax::Expr e) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `Assign`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Assign: unbounded fn Lx, Env, Expr, Ex -> Do
struct Assign : prism_rtl::Job<crate::lower::model::Do> {
    Lx lx;
    Env env;
    crate::syntax::Expr target;
    crate::lower::model::Ex v_;
    Assign(Lx lx, Env env, crate::syntax::Expr target, crate::lower::model::Ex v_) : lx(std::move(lx)), env(std::move(env)), target(std::move(target)), v_(std::move(v_)) {}
    prism_rtl::Turn<crate::lower::model::Do> cycle() const override;
};


/// The step machine of `ClausesBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClausesBody: unbounded fn Lx, Env, [FnClause], [((Text, Bool))], [Ty], (fn Lx, Env, FnBody -> Ex), Text, OutTy -> Ex
struct ClausesBody : prism_rtl::Job<crate::lower::model::Ex> {
    Lx lx;
    Env env;
    Array<crate::syntax::FnClause> clauses;
    Array<std::tuple<Text, bool>> names;
    Array<crate::check::types::Ty> ptys;
    prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Lx, Env, crate::syntax::FnBody>)> body_fn;
    Text label;
    crate::lower::model::OutTy t;
    ClausesBody(Lx lx, Env env, Array<crate::syntax::FnClause> clauses, Array<std::tuple<Text, bool>> names, Array<crate::check::types::Ty> ptys, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Lx, Env, crate::syntax::FnBody>)> body_fn, Text label, crate::lower::model::OutTy t) : lx(std::move(lx)), env(std::move(env)), clauses(std::move(clauses)), names(std::move(names)), ptys(std::move(ptys)), body_fn(std::move(body_fn)), label(std::move(label)), t(std::move(t)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `FnBodyValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FnBodyValue: unbounded fn Lx, Env, FnBody -> Ex
struct FnBodyValue : prism_rtl::Job<crate::lower::model::Ex> {
    Lx lx;
    Env env;
    crate::syntax::FnBody fn_body2;
    FnBodyValue(Lx lx, Env env, crate::syntax::FnBody fn_body2) : lx(std::move(lx)), env(std::move(env)), fn_body2(std::move(fn_body2)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `FnDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FnDefOf: unbounded fn Lx, Text, [FnClause], Scheme -> FnDef
struct FnDefOf : prism_rtl::Job<crate::lower::model::FnDef> {
    Lx lx;
    Text qk;
    Array<crate::syntax::FnClause> clauses;
    crate::check::types::Scheme sc;
    FnDefOf(Lx lx, Text qk, Array<crate::syntax::FnClause> clauses, crate::check::types::Scheme sc) : lx(std::move(lx)), qk(std::move(qk)), clauses(std::move(clauses)), sc(std::move(sc)) {}
    prism_rtl::Turn<crate::lower::model::FnDef> cycle() const override;
};


/// The step machine of `LetGetter`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LetGetter: unbounded fn Lx, Text, LetDecl -> FnDef
struct LetGetter : prism_rtl::Job<crate::lower::model::FnDef> {
    Lx lx;
    Text qk;
    crate::syntax::LetDecl l;
    LetGetter(Lx lx, Text qk, crate::syntax::LetDecl l) : lx(std::move(lx)), qk(std::move(qk)), l(std::move(l)) {}
    prism_rtl::Turn<crate::lower::model::FnDef> cycle() const override;
};


/// The step machine of `SelfIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SelfIn: unbounded fn Ty, Text -> Ty
struct SelfIn : prism_rtl::Job<crate::check::types::Ty> {
    crate::check::types::Ty t;
    Text param;
    SelfIn(crate::check::types::Ty t, Text param) : t(std::move(t)), param(std::move(param)) {}
    prism_rtl::Turn<crate::check::types::Ty> cycle() const override;
};


/// The step machine of `TraitDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TraitDefOf: unbounded fn Lx, TraitInfo -> TraitDef
struct TraitDefOf : prism_rtl::Job<crate::lower::model::TraitDef> {
    Lx lx0;
    crate::check::env::TraitInfo tr;
    TraitDefOf(Lx lx0, crate::check::env::TraitInfo tr) : lx0(std::move(lx0)), tr(std::move(tr)) {}
    prism_rtl::Turn<crate::lower::model::TraitDef> cycle() const override;
};


/// The step machine of `ImplDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ImplDefOf: unbounded fn Lx, ImplInfo -> ImplDef
struct ImplDefOf : prism_rtl::Job<crate::lower::model::ImplDef> {
    Lx lx;
    crate::check::env::ImplInfo im;
    ImplDefOf(Lx lx, crate::check::env::ImplInfo im) : lx(std::move(lx)), im(std::move(im)) {}
    prism_rtl::Turn<crate::lower::model::ImplDef> cycle() const override;
};


/// The step machine of `IfGenLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IfGenLine: unbounded fn Wx, Env, Expr, Block, Block, Expr -> ((Wx, Wres))
struct IfGenLine : prism_rtl::Job<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> {
    crate::lower::node_::Wx wx;
    Env menv;
    crate::syntax::Expr c;
    crate::syntax::Block then_b;
    crate::syntax::Block else_b;
    crate::syntax::Expr e;
    IfGenLine(crate::lower::node_::Wx wx, Env menv, crate::syntax::Expr c, crate::syntax::Block then_b, crate::syntax::Block else_b, crate::syntax::Expr e) : wx(std::move(wx)), menv(std::move(menv)), c(std::move(c)), then_b(std::move(then_b)), else_b(std::move(else_b)), e(std::move(e)) {}
    prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> cycle() const override;
};


/// The step machine of `Tail`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Tail: unbounded fn Lx, Env, Expr -> Ex
struct Tail : prism_rtl::Job<crate::lower::model::Ex> {
    Lx lx;
    Env env;
    crate::syntax::Expr e;
    Tail(Lx lx, Env env, crate::syntax::Expr e) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `TailHere`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TailHere: unbounded fn Lx, Env, Expr -> Ex
struct TailHere : prism_rtl::Job<crate::lower::model::Ex> {
    Lx lx;
    Env env;
    crate::syntax::Expr e;
    TailHere(Lx lx, Env env, crate::syntax::Expr e) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `TailBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TailBlock: unbounded fn Lx, Env, Block -> Ex
struct TailBlock : prism_rtl::Job<crate::lower::model::Ex> {
    Lx lx;
    Env env;
    crate::syntax::Block b;
    TailBlock(Lx lx, Env env, crate::syntax::Block b) : lx(std::move(lx)), env(std::move(env)), b(std::move(b)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `TailFrom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TailFrom: unbounded fn Lx, Env, Block, Nat -> Ex
struct TailFrom : prism_rtl::Job<crate::lower::model::Ex> {
    Lx lx;
    Env env;
    crate::syntax::Block b;
    Nat i;
    TailFrom(Lx lx, Env env, crate::syntax::Block b, Nat i) : lx(std::move(lx)), env(std::move(env)), b(std::move(b)), i(std::move(i)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `UpdTail`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdTail: unbounded fn Lx, Env, Expr, Block, Range, (unbounded fn Env, Ex -> Ex) -> Ex
struct UpdTail : prism_rtl::Job<crate::lower::model::Ex> {
    Lx lx;
    Env env;
    crate::syntax::Expr target;
    crate::syntax::Block b;
    crate::syntax::Range to;
    prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, crate::lower::model::Ex>)> cont_fn;
    UpdTail(Lx lx, Env env, crate::syntax::Expr target, crate::syntax::Block b, crate::syntax::Range to, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, crate::lower::model::Ex>)> cont_fn) : lx(std::move(lx)), env(std::move(env)), target(std::move(target)), b(std::move(b)), to(std::move(to)), cont_fn(std::move(cont_fn)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `UpdTailFrom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdTailFrom: unbounded fn Lx, Env, Env, Block, Nat, Range, (unbounded fn Env, Ex -> Ex) -> Ex
struct UpdTailFrom : prism_rtl::Job<crate::lower::model::Ex> {
    Lx lx;
    Env outer;
    Env env;
    crate::syntax::Block b;
    Nat i;
    crate::syntax::Range to;
    prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, crate::lower::model::Ex>)> cont_fn;
    UpdTailFrom(Lx lx, Env outer, Env env, crate::syntax::Block b, Nat i, crate::syntax::Range to, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, crate::lower::model::Ex>)> cont_fn) : lx(std::move(lx)), outer(std::move(outer)), env(std::move(env)), b(std::move(b)), i(std::move(i)), to(std::move(to)), cont_fn(std::move(cont_fn)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `StmtJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StmtJob: unbounded fn Lx, Env, Env, Stmt, Text, (unbounded fn Env, Env -> Ex) -> Ex
struct StmtJob : prism_rtl::Job<crate::lower::model::Ex> {
    Lx lx;
    Env outer;
    Env env;
    crate::syntax::Stmt s;
    Text rest;
    prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, Env>)> cont_fn;
    StmtJob(Lx lx, Env outer, Env env, crate::syntax::Stmt s, Text rest, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, Env>)> cont_fn) : lx(std::move(lx)), outer(std::move(outer)), env(std::move(env)), s(std::move(s)), rest(std::move(rest)), cont_fn(std::move(cont_fn)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `WhileJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WhileJob: unbounded fn Lx, Env, Env, Cond, Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
struct WhileJob : prism_rtl::Job<crate::lower::model::Ex> {
    Lx lx;
    Env outer;
    Env env;
    crate::syntax::Cond c;
    crate::syntax::Block wb;
    crate::syntax::Range span;
    Text rest_text_;
    prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, Env>)> cont_fn;
    WhileJob(Lx lx, Env outer, Env env, crate::syntax::Cond c, crate::syntax::Block wb, crate::syntax::Range span, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, Env>)> cont_fn) : lx(std::move(lx)), outer(std::move(outer)), env(std::move(env)), c(std::move(c)), wb(std::move(wb)), span(std::move(span)), rest_text_(std::move(rest_text_)), cont_fn(std::move(cont_fn)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `StmtsThen`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StmtsThen: unbounded fn Lx, Env, Block, Ex -> Ex
struct StmtsThen : prism_rtl::Job<crate::lower::model::Ex> {
    Lx lx;
    Env env;
    crate::syntax::Block b;
    crate::lower::model::Ex last;
    StmtsThen(Lx lx, Env env, crate::syntax::Block b, crate::lower::model::Ex last) : lx(std::move(lx)), env(std::move(env)), b(std::move(b)), last(std::move(last)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `IfJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IfJob: unbounded fn Lx, Env, Env, Cond, Block, ?Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
struct IfJob : prism_rtl::Job<crate::lower::model::Ex> {
    Lx lx;
    Env outer;
    Env env;
    crate::syntax::Cond c;
    crate::syntax::Block then_b;
    std::optional<crate::syntax::Block> else_b_opt;
    crate::syntax::Range span;
    Text rest_text_;
    prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, Env>)> cont_fn;
    IfJob(Lx lx, Env outer, Env env, crate::syntax::Cond c, crate::syntax::Block then_b, std::optional<crate::syntax::Block> else_b_opt, crate::syntax::Range span, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, Env>)> cont_fn) : lx(std::move(lx)), outer(std::move(outer)), env(std::move(env)), c(std::move(c)), then_b(std::move(then_b)), else_b_opt(std::move(else_b_opt)), span(std::move(span)), rest_text_(std::move(rest_text_)), cont_fn(std::move(cont_fn)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `MatchJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MatchJob: unbounded fn Lx, Env, Env, Expr, [Arm], Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
struct MatchJob : prism_rtl::Job<crate::lower::model::Ex> {
    Lx lx;
    Env outer;
    Env env;
    crate::syntax::Expr scrut;
    Array<crate::syntax::Arm> arms;
    crate::syntax::Range span;
    Text rest_text_;
    prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, Env>)> cont_fn;
    MatchJob(Lx lx, Env outer, Env env, crate::syntax::Expr scrut, Array<crate::syntax::Arm> arms, crate::syntax::Range span, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, Env>)> cont_fn) : lx(std::move(lx)), outer(std::move(outer)), env(std::move(env)), scrut(std::move(scrut)), arms(std::move(arms)), span(std::move(span)), rest_text_(std::move(rest_text_)), cont_fn(std::move(cont_fn)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `ForJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ForJob: unbounded fn Lx, Env, Env, ?ForBinders, Expr, Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
struct ForJob : prism_rtl::Job<crate::lower::model::Ex> {
    Lx lx;
    Env outer;
    Env env;
    std::optional<crate::syntax::ForBinders> binders_opt;
    crate::syntax::Expr source;
    crate::syntax::Block body;
    crate::syntax::Range span;
    Text rest_text_;
    prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, Env>)> cont_fn;
    ForJob(Lx lx, Env outer, Env env, std::optional<crate::syntax::ForBinders> binders_opt, crate::syntax::Expr source, crate::syntax::Block body, crate::syntax::Range span, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, Env>)> cont_fn) : lx(std::move(lx)), outer(std::move(outer)), env(std::move(env)), binders_opt(std::move(binders_opt)), source(std::move(source)), body(std::move(body)), span(std::move(span)), rest_text_(std::move(rest_text_)), cont_fn(std::move(cont_fn)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `FrameCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?FrameCall: unbounded fn Lx, Env, Expr, Bool -> ?Expr
struct FrameCall : prism_rtl::Job<std::optional<crate::syntax::Expr>> {
    Lx lx;
    Env env;
    crate::syntax::Expr e;
    bool top;
    FrameCall(Lx lx, Env env, crate::syntax::Expr e, bool top) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)), top(std::move(top)) {}
    prism_rtl::Turn<std::optional<crate::syntax::Expr>> cycle() const override;
};


/// The step machine of `FirstFrame`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?FirstFrame: unbounded fn Lx, Env, [Expr] -> ?Expr
struct FirstFrame : prism_rtl::Job<std::optional<crate::syntax::Expr>> {
    Lx lx;
    Env env;
    Array<crate::syntax::Expr> es;
    FirstFrame(Lx lx, Env env, Array<crate::syntax::Expr> es) : lx(std::move(lx)), env(std::move(env)), es(std::move(es)) {}
    prism_rtl::Turn<std::optional<crate::syntax::Expr>> cycle() const override;
};


/// The step machine of `Frame`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Frame: unbounded fn Lx, Env, Expr, Text, (unbounded fn Env -> Ex) -> Ex
struct Frame : prism_rtl::Job<crate::lower::model::Ex> {
    Lx lx;
    Env env;
    crate::syntax::Expr call;
    Text rest_text_;
    prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Env)> cont_fn;
    Frame(Lx lx, Env env, crate::syntax::Expr call, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Env)> cont_fn) : lx(std::move(lx)), env(std::move(env)), call(std::move(call)), rest_text_(std::move(rest_text_)), cont_fn(std::move(cont_fn)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `LocalJobFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?LocalJobFn: unbounded fn Lx, Env, Expr -> ?Vl
struct LocalJobFn : prism_rtl::Job<std::optional<Vl>> {
    Lx lx;
    Env env;
    crate::syntax::Expr c;
    LocalJobFn(Lx lx, Env env, crate::syntax::Expr c) : lx(std::move(lx)), env(std::move(env)), c(std::move(c)) {}
    prism_rtl::Turn<std::optional<Vl>> cycle() const override;
};


/// The step machine of `TailBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TailBody: unbounded fn Lx, Env, FnBody -> Ex
struct TailBody : prism_rtl::Job<crate::lower::model::Ex> {
    Lx lx;
    Env env;
    crate::syntax::FnBody fn_body2;
    TailBody(Lx lx, Env env, crate::syntax::FnBody fn_body2) : lx(std::move(lx)), env(std::move(env)), fn_body2(std::move(fn_body2)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `TailMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TailMatch: unbounded fn Lx, Env, Expr, [Arm], Range -> Ex
struct TailMatch : prism_rtl::Job<crate::lower::model::Ex> {
    Lx lx;
    Env env;
    crate::syntax::Expr s;
    Array<crate::syntax::Arm> arms;
    crate::syntax::Range span;
    TailMatch(Lx lx, Env env, crate::syntax::Expr s, Array<crate::syntax::Arm> arms, crate::syntax::Range span) : lx(std::move(lx)), env(std::move(env)), s(std::move(s)), arms(std::move(arms)), span(std::move(span)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `JobFieldNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// JobFieldNames: unbounded fn Lx, Text -> [Text]
struct JobFieldNames : prism_rtl::Job<Array<Text>> {
    Lx lx;
    Text qk;
    JobFieldNames(Lx lx, Text qk) : lx(std::move(lx)), qk(std::move(qk)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `JobDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// JobDefOf: unbounded fn Lx, Text, [FnClause], Scheme -> JobDef
struct JobDefOf : prism_rtl::Job<crate::lower::model::JobDef> {
    Lx lx;
    Text qk;
    Array<crate::syntax::FnClause> clauses;
    crate::check::types::Scheme sc;
    JobDefOf(Lx lx, Text qk, Array<crate::syntax::FnClause> clauses, crate::check::types::Scheme sc) : lx(std::move(lx)), qk(std::move(qk)), clauses(std::move(clauses)), sc(std::move(sc)) {}
    prism_rtl::Turn<crate::lower::model::JobDef> cycle() const override;
};


/// The step machine of `JobClauses`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// JobClauses: unbounded fn Lx, [FnClause], [((Text, Bool))], [Ty], [OutTy] -> Ex
struct JobClauses : prism_rtl::Job<crate::lower::model::Ex> {
    Lx lx;
    Array<crate::syntax::FnClause> clauses;
    Array<std::tuple<Text, bool>> names;
    Array<crate::check::types::Ty> ptys;
    Array<crate::lower::model::OutTy> pts;
    JobClauses(Lx lx, Array<crate::syntax::FnClause> clauses, Array<std::tuple<Text, bool>> names, Array<crate::check::types::Ty> ptys, Array<crate::lower::model::OutTy> pts) : lx(std::move(lx)), clauses(std::move(clauses)), names(std::move(names)), ptys(std::move(ptys)), pts(std::move(pts)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `LowerProgram`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LowerProgram: unbounded fn [Src], [Module], Nat, TProgram, Text -> Model
struct LowerProgram : prism_rtl::Job<crate::lower::model::Model> {
    Array<crate::check::errors::Src> srcs;
    Array<crate::syntax::Module> trees;
    Nat shown;
    crate::check::typed::TProgram tp;
    Text name;
    LowerProgram(Array<crate::check::errors::Src> srcs, Array<crate::syntax::Module> trees, Nat shown, crate::check::typed::TProgram tp, Text name) : srcs(std::move(srcs)), trees(std::move(trees)), shown(std::move(shown)), tp(std::move(tp)), name(std::move(name)) {}
    prism_rtl::Turn<crate::lower::model::Model> cycle() const override;
};


/// The step machine of `WithNeeds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WithNeeds: unbounded fn G, [Src], TProgram, [ModDef] -> [ModDef]
struct WithNeeds : prism_rtl::Job<Array<crate::lower::model::ModDef>> {
    crate::check::env::G g;
    Array<crate::check::errors::Src> srcs;
    crate::check::typed::TProgram tp;
    Array<crate::lower::model::ModDef> defs;
    WithNeeds(crate::check::env::G g, Array<crate::check::errors::Src> srcs, crate::check::typed::TProgram tp, Array<crate::lower::model::ModDef> defs) : g(std::move(g)), srcs(std::move(srcs)), tp(std::move(tp)), defs(std::move(defs)) {}
    prism_rtl::Turn<Array<crate::lower::model::ModDef>> cycle() const override;
};


/// The step machine of `NamedMods`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NamedMods: unbounded fn G, [Src], TProgram, [Text] -> (Text ==> [Text])
struct NamedMods : prism_rtl::Job<Map<Text, Array<Text>>> {
    crate::check::env::G g;
    Array<crate::check::errors::Src> srcs;
    crate::check::typed::TProgram tp;
    Array<Text> ms;
    NamedMods(crate::check::env::G g, Array<crate::check::errors::Src> srcs, crate::check::typed::TProgram tp, Array<Text> ms) : g(std::move(g)), srcs(std::move(srcs)), tp(std::move(tp)), ms(std::move(ms)) {}
    prism_rtl::Turn<Map<Text, Array<Text>>> cycle() const override;
};


/// The step machine of `WithGroups`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WithGroups: unbounded fn [ModDef] -> [ModDef]
struct WithGroups : prism_rtl::Job<Array<crate::lower::model::ModDef>> {
    Array<crate::lower::model::ModDef> defs;
    WithGroups(Array<crate::lower::model::ModDef> defs) : defs(std::move(defs)) {}
    prism_rtl::Turn<Array<crate::lower::model::ModDef>> cycle() const override;
};


/// The step machine of `ReachedBy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ReachedBy: unbounded fn (Text ==> [Text]), [Text], [Text] -> [Text]
struct ReachedBy : prism_rtl::Job<Array<Text>> {
    Map<Text, Array<Text>> edges;
    Array<Text> todo;
    Array<Text> seen;
    ReachedBy(Map<Text, Array<Text>> edges, Array<Text> todo, Array<Text> seen) : edges(std::move(edges)), todo(std::move(todo)), seen(std::move(seen)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `NeededMods`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NeededMods: unbounded fn G, Nat -> [Text]
struct NeededMods : prism_rtl::Job<Array<Text>> {
    crate::check::env::G g;
    Nat shown;
    NeededMods(crate::check::env::G g, Nat shown) : g(std::move(g)), shown(std::move(shown)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `ModRefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ModRefs: unbounded fn G, Text -> [Text]
struct ModRefs : prism_rtl::Job<Array<Text>> {
    crate::check::env::G g;
    Text m;
    ModRefs(crate::check::env::G g, Text m) : g(std::move(g)), m(std::move(m)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `ProgDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ProgDefOf: unbounded fn Lx, Text -> ProgDef
struct ProgDefOf : prism_rtl::Job<crate::lower::model::ProgDef> {
    Lx lx;
    Text qk;
    ProgDefOf(Lx lx, Text qk) : lx(std::move(lx)), qk(std::move(qk)) {}
    prism_rtl::Turn<crate::lower::model::ProgDef> cycle() const override;
};


/// The step machine of `JobRoots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// JobRoots: unbounded fn Lx -> [Text]
struct JobRoots : prism_rtl::Job<Array<Text>> {
    Lx lx;
    JobRoots(Lx lx) : lx(std::move(lx)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `UnboundedValues`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UnboundedValues: unbounded fn Lx, Def -> [Text]
struct UnboundedValues : prism_rtl::Job<Array<Text>> {
    Lx lx;
    crate::check::env::Def d;
    UnboundedValues(Lx lx, crate::check::env::Def d) : lx(std::move(lx)), d(std::move(d)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `RunTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RunTargets: unbounded fn Lx, Def -> [Text]
struct RunTargets : prism_rtl::Job<Array<Text>> {
    Lx lx;
    crate::check::env::Def d;
    RunTargets(Lx lx, crate::check::env::Def d) : lx(std::move(lx)), d(std::move(d)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `TailTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TailTargets: unbounded fn Lx, Text -> [Text]
struct TailTargets : prism_rtl::Job<Array<Text>> {
    Lx lx;
    Text qk;
    TailTargets(Lx lx, Text qk) : lx(std::move(lx)), qk(std::move(qk)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `TailsOfBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TailsOfBody: unbounded fn Lx, FnBody -> [Text]
struct TailsOfBody : prism_rtl::Job<Array<Text>> {
    Lx lx;
    crate::syntax::FnBody body;
    TailsOfBody(Lx lx, crate::syntax::FnBody body) : lx(std::move(lx)), body(std::move(body)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `ModDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ModDefOf: unbounded fn Lx, Text, [((Text, Bool))], ModInfo, [Text] -> ModDef
struct ModDefOf : prism_rtl::Job<crate::lower::model::ModDef> {
    Lx lx0;
    Text m;
    Array<std::tuple<Text, bool>> roots;
    crate::check::env::ModInfo info;
    Array<Text> mods;
    ModDefOf(Lx lx0, Text m, Array<std::tuple<Text, bool>> roots, crate::check::env::ModInfo info, Array<Text> mods) : lx0(std::move(lx0)), m(std::move(m)), roots(std::move(roots)), info(std::move(info)), mods(std::move(mods)) {}
    prism_rtl::Turn<crate::lower::model::ModDef> cycle() const override;
};


/// The step machine of `DefItems`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DefItems: unbounded fn Lx, Def, [((Text, Bool))] -> [Item]
struct DefItems : prism_rtl::Job<Array<crate::lower::model::Item>> {
    Lx lx;
    crate::check::env::Def d;
    Array<std::tuple<Text, bool>> roots;
    DefItems(Lx lx, crate::check::env::Def d, Array<std::tuple<Text, bool>> roots) : lx(std::move(lx)), d(std::move(d)), roots(std::move(roots)) {}
    prism_rtl::Turn<Array<crate::lower::model::Item>> cycle() const override;
};


/// The step machine of `TyDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TyDefs: unbounded fn Lx, TyInfo -> [Item]
struct TyDefs : prism_rtl::Job<Array<crate::lower::model::Item>> {
    Lx lx;
    crate::check::env::TyInfo ti;
    TyDefs(Lx lx, crate::check::env::TyInfo ti) : lx(std::move(lx)), ti(std::move(ti)) {}
    prism_rtl::Turn<Array<crate::lower::model::Item>> cycle() const override;
};


/// The step machine of `TyPodable`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TyPodable: unbounded fn Lx, Ty, [Text] -> Bool
struct TyPodable : prism_rtl::Job<bool> {
    Lx lx;
    crate::check::types::Ty t;
    Array<Text> seen;
    TyPodable(Lx lx, crate::check::types::Ty t, Array<Text> seen) : lx(std::move(lx)), t(std::move(t)), seen(std::move(seen)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `CaseField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CaseField: unbounded fn Lx, Text, Nat, Ty -> OutTy
struct CaseField : prism_rtl::Job<crate::lower::model::OutTy> {
    Lx lx;
    Text ck;
    Nat i;
    crate::check::types::Ty t;
    CaseField(Lx lx, Text ck, Nat i, crate::check::types::Ty t) : lx(std::move(lx)), ck(std::move(ck)), i(std::move(i)), t(std::move(t)) {}
    prism_rtl::Turn<crate::lower::model::OutTy> cycle() const override;
};


/// The step machine of `TagDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TagDefOf: unbounded fn Lx, TagInfo -> TagDef
struct TagDefOf : prism_rtl::Job<crate::lower::model::TagDef> {
    Lx lx;
    crate::check::env::TagInfo tg;
    TagDefOf(Lx lx, crate::check::env::TagInfo tg) : lx(std::move(lx)), tg(std::move(tg)) {}
    prism_rtl::Turn<crate::lower::model::TagDef> cycle() const override;
};


/// The step machine of `RowDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RowDefOf: unbounded fn Lx, TyInfo -> RowDef
struct RowDefOf : prism_rtl::Job<crate::lower::model::RowDef> {
    Lx lx;
    crate::check::env::TyInfo ti;
    RowDefOf(Lx lx, crate::check::env::TyInfo ti) : lx(std::move(lx)), ti(std::move(ti)) {}
    prism_rtl::Turn<crate::lower::model::RowDef> cycle() const override;
};


/// The step machine of `ElemRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ElemRow: unbounded fn Lx, [Text] -> RowDef
struct ElemRow : prism_rtl::Job<crate::lower::model::RowDef> {
    Lx lx;
    Array<Text> mods;
    ElemRow(Lx lx, Array<Text> mods) : lx(std::move(lx)), mods(std::move(mods)) {}
    prism_rtl::Turn<crate::lower::model::RowDef> cycle() const override;
};


/// The step machine of `AnswerEnum`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AnswerEnum: unbounded fn Lx, [Text] -> AnswerDef
struct AnswerEnum : prism_rtl::Job<crate::lower::model::AnswerDef> {
    Lx lx;
    Array<Text> mods;
    AnswerEnum(Lx lx, Array<Text> mods) : lx(std::move(lx)), mods(std::move(mods)) {}
    prism_rtl::Turn<crate::lower::model::AnswerDef> cycle() const override;
};


/// The step machine of `AnswerTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AnswerTy: unbounded fn Lx, TagInfo -> OutTy
struct AnswerTy : prism_rtl::Job<crate::lower::model::OutTy> {
    Lx lx;
    crate::check::env::TagInfo tg;
    AnswerTy(Lx lx, crate::check::env::TagInfo tg) : lx(std::move(lx)), tg(std::move(tg)) {}
    prism_rtl::Turn<crate::lower::model::OutTy> cycle() const override;
};


/// The step machine of `CheckDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckDefOf: unbounded fn Lx, CheckDecl -> CheckDef
struct CheckDefOf : prism_rtl::Job<crate::lower::model::CheckDef> {
    Lx lx;
    crate::syntax::CheckDecl c;
    CheckDefOf(Lx lx, crate::syntax::CheckDecl c) : lx(std::move(lx)), c(std::move(c)) {}
    prism_rtl::Turn<crate::lower::model::CheckDef> cycle() const override;
};


}  // namespace lower

}  // namespace crate
