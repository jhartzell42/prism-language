// The module `Lower.Model`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace lower::model {

struct AnswerCase;

struct AnswerDef;

struct CaseDef;

class Cc;

struct CheckDef;

class CxArg;

class Do;

class Ex;

struct FnDef;

struct ForDef;

struct GenDef;

struct ImplDef;

class Item;

struct JobDef;

struct MethDef;

struct ModDef;

struct Model;

struct NodeDef;

class OutTy;

class Pa;

struct Pos_;

struct ProgDef;

class Recv;

struct RowDef;

class RowKind;

class Shown;

struct TagDef;

struct TraitDef;

struct TyDef;

class TyShape;

struct XArm;

}  // namespace lower::model

namespace lower::model {

/// `Cc`:
///
/// ```prism
/// type Cc = choice:
/// ```
class Cc {
public:
    using prism_value = void;
    struct CcIf;
    struct CcLet;
    using Cases = std::variant<CcIf, CcLet>;
    template <class C>
        requires prism_rtl::one_of<C, CcIf, CcLet>
    Cc(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Cc> from_pod(const Pod& whole);
    friend inline bool operator==(const Cc& a, const Cc& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `CxArg`:
///
/// ```prism
/// type CxArg = choice:
/// ```
class CxArg {
public:
    using prism_value = void;
    struct CxMut;
    struct CxRef;
    struct CxNone;
    using Cases = std::variant<CxMut, CxRef, CxNone>;
    template <class C>
        requires prism_rtl::one_of<C, CxMut, CxRef, CxNone>
    CxArg(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<CxArg> from_pod(const Pod& whole);
    friend inline bool operator==(const CxArg& a, const CxArg& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `Do`:
///
/// ```prism
/// type Do = choice:
/// ```
class Do {
public:
    using prism_value = void;
    struct DoLet;
    struct DoLetElse;
    struct DoAssign;
    struct DoWhile;
    struct DoWhileLet;
    struct DoFor;
    struct DoExpr;
    struct DoIf;
    struct DoIfLet;
    struct DoMatch;
    struct DoReturn;
    struct DoBlock;
    struct DoScope;
    struct DoLine;
    struct DoNote;
    using Cases = std::variant<DoLet, DoLetElse, DoAssign, DoWhile, DoWhileLet, DoFor, DoExpr, DoIf, DoIfLet, DoMatch, DoReturn, DoBlock, DoScope, DoLine, DoNote>;
    template <class C>
        requires prism_rtl::one_of<C, DoLet, DoLetElse, DoAssign, DoWhile, DoWhileLet, DoFor, DoExpr, DoIf, DoIfLet, DoMatch, DoReturn, DoBlock, DoScope, DoLine, DoNote>
    Do(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Do> from_pod(const Pod& whole);
    friend inline bool operator==(const Do& a, const Do& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `Ex`:
///
/// ```prism
/// type Ex = choice:
/// ```
class Ex {
public:
    using prism_value = void;
    struct XVar;
    struct XPath;
    struct XSelf;
    struct XCx;
    struct XConst;
    struct XUnit;
    struct XNone;
    struct XBool;
    struct XNat;
    struct XInt;
    struct XByte;
    struct XFloat;
    struct XIndex;
    struct XChar;
    struct XStr;
    struct XRef;
    struct XRefMut;
    struct XDeref;
    struct XTarget;
    struct XClone;
    struct XWeak;
    struct XUpgrade;
    struct XBreak;
    struct XBreakLoop;
    struct XLater;
    struct XFormatStr;
    struct XIsCase;
    struct XRefusal;
    struct XUnreachable;
    struct XCall;
    struct XApply;
    struct XMethod;
    struct XBin;
    struct XUnary;
    struct XCtor;
    struct XRecord;
    struct XTuple;
    struct XVec;
    struct XText;
    struct XFormat;
    struct XMatch;
    struct XChain;
    struct XIf;
    struct XBlock;
    struct XLabeled;
    struct XClosure;
    struct XTry;
    struct XField;
    struct XPart;
    struct XDecode;
    struct XCast;
    struct XTyped;
    using Cases = std::variant<XVar, XPath, XSelf, XCx, XConst, XUnit, XNone, XBool, XNat, XInt, XByte, XFloat, XIndex, XChar, XStr, XRef, XRefMut, XDeref, XTarget, XClone, XWeak, XUpgrade, XBreak, XBreakLoop, XLater, XFormatStr, XIsCase, XRefusal, XUnreachable, XCall, XApply, XMethod, XBin, XUnary, XCtor, XRecord, XTuple, XVec, XText, XFormat, XMatch, XChain, XIf, XBlock, XLabeled, XClosure, XTry, XField, XPart, XDecode, XCast, XTyped>;
    template <class C>
        requires prism_rtl::one_of<C, XVar, XPath, XSelf, XCx, XConst, XUnit, XNone, XBool, XNat, XInt, XByte, XFloat, XIndex, XChar, XStr, XRef, XRefMut, XDeref, XTarget, XClone, XWeak, XUpgrade, XBreak, XBreakLoop, XLater, XFormatStr, XIsCase, XRefusal, XUnreachable, XCall, XApply, XMethod, XBin, XUnary, XCtor, XRecord, XTuple, XVec, XText, XFormat, XMatch, XChain, XIf, XBlock, XLabeled, XClosure, XTry, XField, XPart, XDecode, XCast, XTyped>
    Ex(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Ex> from_pod(const Pod& whole);
    friend inline bool operator==(const Ex& a, const Ex& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `Item`:
///
/// ```prism
/// type Item = choice:
/// ```
class Item {
public:
    using prism_value = void;
    struct ItTrait;
    struct ItImpl;
    struct ItType;
    struct ItTag;
    struct ItRow;
    struct ItFn;
    struct ItJob;
    struct ItNode;
    struct ItNote;
    struct ItRefused;
    using Cases = std::variant<ItTrait, ItImpl, ItType, ItTag, ItRow, ItFn, ItJob, ItNode, ItNote, ItRefused>;
    template <class C>
        requires prism_rtl::one_of<C, ItTrait, ItImpl, ItType, ItTag, ItRow, ItFn, ItJob, ItNode, ItNote, ItRefused>
    Item(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Item> from_pod(const Pod& whole);
    friend inline bool operator==(const Item& a, const Item& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `OutTy`:
///
/// ```prism
/// type OutTy = choice:
/// ```
class OutTy {
public:
    using prism_value = void;
    struct OutNat;
    struct OutInt;
    struct OutU8;
    struct OutFloat;
    struct OutBool;
    struct OutChar;
    struct OutText;
    struct OutCursor;
    struct OutUnit;
    struct OutPath;
    struct OutDuration;
    struct OutError;
    struct OutNamed;
    struct OutOpt;
    struct OutRes;
    struct OutTuple;
    struct OutArray;
    struct OutMap;
    struct OutFn;
    struct OutJobFn;
    struct OutJob;
    struct OutEvent;
    struct OutDyn;
    struct OutGen;
    struct OutRc;
    struct OutRef;
    struct OutPod;
    struct OutShowAny;
    struct OutHold;
    struct OutStamped;
    struct OutSnapshot;
    struct OutDefer;
    struct OutWeak;
    struct OutCell;
    struct OutWakes;
    struct OutCount;
    struct OutObj;
    struct OutSlice;
    struct OutPort;
    struct OutLive;
    struct OutQuantified;
    struct OutUnknown;
    using Cases = std::variant<OutNat, OutInt, OutU8, OutFloat, OutBool, OutChar, OutText, OutCursor, OutUnit, OutPath, OutDuration, OutError, OutNamed, OutOpt, OutRes, OutTuple, OutArray, OutMap, OutFn, OutJobFn, OutJob, OutEvent, OutDyn, OutGen, OutRc, OutRef, OutPod, OutShowAny, OutHold, OutStamped, OutSnapshot, OutDefer, OutWeak, OutCell, OutWakes, OutCount, OutObj, OutSlice, OutPort, OutLive, OutQuantified, OutUnknown>;
    template <class C>
        requires prism_rtl::one_of<C, OutNat, OutInt, OutU8, OutFloat, OutBool, OutChar, OutText, OutCursor, OutUnit, OutPath, OutDuration, OutError, OutNamed, OutOpt, OutRes, OutTuple, OutArray, OutMap, OutFn, OutJobFn, OutJob, OutEvent, OutDyn, OutGen, OutRc, OutRef, OutPod, OutShowAny, OutHold, OutStamped, OutSnapshot, OutDefer, OutWeak, OutCell, OutWakes, OutCount, OutObj, OutSlice, OutPort, OutLive, OutQuantified, OutUnknown>
    OutTy(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<OutTy> from_pod(const Pod& whole);
    friend inline bool operator==(const OutTy& a, const OutTy& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `Pa`:
///
/// ```prism
/// type Pa = choice:
/// ```
class Pa {
public:
    using prism_value = void;
    struct PaWild;
    struct PaBind;
    struct PaMut;
    struct PaCtor;
    struct PaUnit;
    struct PaRecord;
    struct PaTuple;
    struct PaChar;
    struct PaBool;
    struct PaIndex;
    struct PaConst;
    struct PaSlice;
    struct PaRest;
    struct PaTyped;
    using Cases = std::variant<PaWild, PaBind, PaMut, PaCtor, PaUnit, PaRecord, PaTuple, PaChar, PaBool, PaIndex, PaConst, PaSlice, PaRest, PaTyped>;
    template <class C>
        requires prism_rtl::one_of<C, PaWild, PaBind, PaMut, PaCtor, PaUnit, PaRecord, PaTuple, PaChar, PaBool, PaIndex, PaConst, PaSlice, PaRest, PaTyped>
    Pa(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Pa> from_pod(const Pod& whole);
    friend inline bool operator==(const Pa& a, const Pa& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `Recv`:
///
/// ```prism
/// type Recv = choice:
/// ```
class Recv {
public:
    using prism_value = void;
    struct RecvRc;
    struct RecvRef;
    struct RecvOwned;
    using Cases = std::variant<RecvRc, RecvRef, RecvOwned>;
    template <class C>
        requires prism_rtl::one_of<C, RecvRc, RecvRef, RecvOwned>
    Recv(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Recv> from_pod(const Pod& whole);
    friend inline bool operator==(const Recv& a, const Recv& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `RowKind`:
///
/// ```prism
/// type RowKind = choice:
/// ```
class RowKind {
public:
    using prism_value = void;
    struct ForRow;
    struct GenerationRow;
    struct NotARow;
    using Cases = std::variant<ForRow, GenerationRow, NotARow>;
    template <class C>
        requires prism_rtl::one_of<C, ForRow, GenerationRow, NotARow>
    RowKind(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<RowKind> from_pod(const Pod& whole);
    friend inline bool operator==(const RowKind& a, const RowKind& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `Shown`:
///
/// ```prism
/// type Shown = choice:
/// ```
class Shown {
public:
    using prism_value = void;
    struct ShownOwn;
    struct ShownDerived;
    struct NotShown;
    using Cases = std::variant<ShownOwn, ShownDerived, NotShown>;
    template <class C>
        requires prism_rtl::one_of<C, ShownOwn, ShownDerived, NotShown>
    Shown(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Shown> from_pod(const Pod& whole);
    friend inline bool operator==(const Shown& a, const Shown& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `TyShape`:
///
/// ```prism
/// type TyShape = choice:
/// ```
class TyShape {
public:
    using prism_value = void;
    struct ShapeRecord;
    struct ShapeChoice;
    struct ShapeNewtype;
    struct ShapeUnit;
    using Cases = std::variant<ShapeRecord, ShapeChoice, ShapeNewtype, ShapeUnit>;
    template <class C>
        requires prism_rtl::one_of<C, ShapeRecord, ShapeChoice, ShapeNewtype, ShapeUnit>
    TyShape(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TyShape> from_pod(const Pod& whole);
    friend inline bool operator==(const TyShape& a, const TyShape& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


}  // namespace lower::model

}  // namespace crate
