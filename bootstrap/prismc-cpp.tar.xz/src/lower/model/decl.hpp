// The module `Lower.Model`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace lower::model {

struct AnswerCase;

struct AnswerDef;

struct CaseDef;

class Cc;

struct CheckDef;

class CxArg;

class Do;

class Ex;

struct FnDef;

struct ForDef;

struct GenDef;

struct ImplDef;

class Item;

struct JobDef;

struct MethDef;

struct ModDef;

struct Model;

struct NodeDef;

class OutTy;

class Pa;

struct Pos_;

struct ProgDef;

class Recv;

struct RowDef;

class RowKind;

class Shown;

struct TagDef;

struct TraitDef;

struct TyDef;

class TyShape;

struct XArm;

}  // namespace lower::model

}  // namespace crate
