// The module `Lower.Model`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <lower/model/types.hpp>
#include "elem.types.hpp"
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/env/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/passes/types.hpp>
#include <check/shrink/types.hpp>
#include <check/typed/types.hpp>
#include <check/types/types.hpp>
#include <lower/types.hpp>
#include <lower/node_/types.hpp>
#include <syntax/types.hpp>
#include <syntax/lexer/types.hpp>

namespace crate {

using namespace prelude;

namespace lower::model {

Pos_ pos0();

Pos_ next_pos(const Pos_& p_);

Pos_ scope_pos(const Nat& k);

Text place_text(const Pos_& p_);

}  // namespace lower::model



}  // namespace crate
