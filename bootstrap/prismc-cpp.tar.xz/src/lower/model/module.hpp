// The module `Lower.Model`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <lower/model/types.hpp>
#include "elem.types.hpp"
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace lower::model {

Text bin_op_text_f(const BinOp& bin_op0);

Text un_op_text_f(const UnOp& un_op0);

std::optional<BinOp> bin_op_of_o(const Text& text0);

Pos_ pos0_p();

Pos_ next_pos_f(const Pos_& p_p0);

Pos_ scope_pos_f(const Nat& k_p0);

Text place_text_f(const Pos_& p_p0);

bool ex_reads_f(const Ex& x_p0, const Text& n_p1);

prism_rtl::JobRef<bool> start_ex_reads_f(Ex x_p0, Text n_p1);

bool any_reads_f(const Array<Ex>& xs_p0, const Text& n_p1);

prism_rtl::JobRef<bool> start_any_reads_f(Array<Ex> xs_p0, Text n_p1);

bool arms_read_f(const Array<XArm>& arms_p0, const Text& n_p1);

prism_rtl::JobRef<bool> start_arms_read_f(Array<XArm> arms_p0, Text n_p1);

bool dos_read_f(const Array<Do>& ds_p0, const Text& n_p1);

prism_rtl::JobRef<bool> start_dos_read_f(Array<Do> ds_p0, Text n_p1);

bool do_reads_f(const Do& d_p0, const Text& n_p1);

prism_rtl::JobRef<bool> start_do_reads_f(Do d_p0, Text n_p1);

}  // namespace lower::model


namespace lower::model {

/// The step machine of `ExReads`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ExReads: unbounded fn Ex, Text -> Bool
struct ExReads : prism_rtl::Job<bool> {
    Ex x_p0;
    Text n_p1;
    ExReads(Ex x_p0, Text n_p1) : x_p0(std::move(x_p0)), n_p1(std::move(n_p1)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `AnyReads`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AnyReads: unbounded fn [Ex], Text -> Bool
struct AnyReads : prism_rtl::Job<bool> {
    Array<Ex> xs_p0;
    Text n_p1;
    AnyReads(Array<Ex> xs_p0, Text n_p1) : xs_p0(std::move(xs_p0)), n_p1(std::move(n_p1)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `ArmsRead`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ArmsRead: unbounded fn [XArm], Text -> Bool
struct ArmsRead : prism_rtl::Job<bool> {
    Array<XArm> arms_p0;
    Text n_p1;
    ArmsRead(Array<XArm> arms_p0, Text n_p1) : arms_p0(std::move(arms_p0)), n_p1(std::move(n_p1)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `DosRead`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DosRead: unbounded fn [Do], Text -> Bool
struct DosRead : prism_rtl::Job<bool> {
    Array<Do> ds_p0;
    Text n_p1;
    DosRead(Array<Do> ds_p0, Text n_p1) : ds_p0(std::move(ds_p0)), n_p1(std::move(n_p1)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `DoReads`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DoReads: unbounded fn Do, Text -> Bool
struct DoReads : prism_rtl::Job<bool> {
    Do d_p0;
    Text n_p1;
    DoReads(Do d_p0, Text n_p1) : d_p0(std::move(d_p0)), n_p1(std::move(n_p1)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


}  // namespace lower::model

}  // namespace crate
