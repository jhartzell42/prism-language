// The module `Lower.Model`: its value types (records, tags, newtypes and choices with their cases), each
// after the types it holds by value, emitted by prismc (claude/backend.md). Edit the Prism
// source, not this file.
#pragma once

#include <lower/model/decl.hpp>
#include "elem.decl.hpp"
#include <check/decl.hpp>
#include <check/blocks/decl.hpp>
#include <check/blocks/borrows/decl.hpp>
#include <check/blocks/structure/decl.hpp>
#include <check/env/decl.hpp>
#include <check/env/decls/decl.hpp>
#include <check/env/names/decl.hpp>
#include <check/env/reading/decl.hpp>
#include <check/env/traits/decl.hpp>
#include <check/errors/decl.hpp>
#include <check/expr/decl.hpp>
#include <check/expr/calls/decl.hpp>
#include <check/expr/lets/decl.hpp>
#include <check/expr/lifting/decl.hpp>
#include <check/expr/operators/decl.hpp>
#include <check/expr/patterns/decl.hpp>
#include <check/passes/decl.hpp>
#include <check/passes/borrows/decl.hpp>
#include <check/passes/cycles/decl.hpp>
#include <check/regex/decl.hpp>
#include <check/shrink/decl.hpp>
#include <check/shrink/calls/decl.hpp>
#include <check/shrink/locals/decl.hpp>
#include <check/shrink/relations/decl.hpp>
#include <check/shrink/summaries/decl.hpp>
#include <check/shrink/types/decl.hpp>
#include <check/shrink/walk/decl.hpp>
#include <check/typed/decl.hpp>
#include <check/typed/print/decl.hpp>
#include <check/types/decl.hpp>
#include <check/types/colors/decl.hpp>
#include <check/types/recording/decl.hpp>
#include <check/types/schemes/decl.hpp>
#include <check/types/unify/decl.hpp>
#include <lower/decl.hpp>
#include <lower/expr/decl.hpp>
#include <lower/functions/decl.hpp>
#include <lower/jobs/decl.hpp>
#include <lower/node_/decl.hpp>
#include <lower/node_/def/decl.hpp>
#include <lower/node_/dynamics/decl.hpp>
#include <lower/node_/elements/decl.hpp>
#include <lower/node_/finish/decl.hpp>
#include <lower/node_/keyed/decl.hpp>
#include <lower/node_/static_/decl.hpp>
#include <lower/node_/switch_/decl.hpp>
#include <lower/patterns/decl.hpp>
#include <lower/program/decl.hpp>
#include <lower/templates/decl.hpp>
#include <lower/types/decl.hpp>
#include <syntax/decl.hpp>
#include <syntax/decls/decl.hpp>
#include <syntax/lexer/decl.hpp>
#include <syntax/lexer/chars/decl.hpp>
#include <syntax/lexer/corpus/decl.hpp>
#include <syntax/lexer/layout/decl.hpp>
#include <syntax/lexer/literals/decl.hpp>
#include <syntax/lexer/regexes/decl.hpp>
#include <syntax/lexer/templates/decl.hpp>
#include <syntax/lexer/words/decl.hpp>

namespace crate {

using namespace prelude;

namespace lower::model {

/// `AnswerDef`:
///
/// ```prism
/// type AnswerDef = record:
/// ```
struct AnswerDef {
    using prism_value = void;
    Array<AnswerCase> cases_p;
    const AnswerDef* operator->() const { return this; }
    AnswerDef* operator->() { return this; }
    bool operator==(const AnswerDef&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<AnswerDef> from_pod(const Pod& whole);
};


}  // namespace lower::model

namespace lower::model {

/// `BinOp`:
///
/// ```prism
/// type BinOp = choice:
/// ```
class BinOp {
public:
    using prism_value = void;
    struct OpAdd {
        bool operator==(const OpAdd&) const = default;
    };

    struct OpSub {
        bool operator==(const OpSub&) const = default;
    };

    struct OpMul {
        bool operator==(const OpMul&) const = default;
    };

    struct OpDiv {
        bool operator==(const OpDiv&) const = default;
    };

    struct OpEq {
        bool operator==(const OpEq&) const = default;
    };

    struct OpNe {
        bool operator==(const OpNe&) const = default;
    };

    struct OpLt {
        bool operator==(const OpLt&) const = default;
    };

    struct OpLe {
        bool operator==(const OpLe&) const = default;
    };

    struct OpGt {
        bool operator==(const OpGt&) const = default;
    };

    struct OpGe {
        bool operator==(const OpGe&) const = default;
    };

    struct OpAnd {
        bool operator==(const OpAnd&) const = default;
    };

    struct OpOr {
        bool operator==(const OpOr&) const = default;
    };
    using Cases = std::variant<OpAdd, OpSub, OpMul, OpDiv, OpEq, OpNe, OpLt, OpLe, OpGt, OpGe, OpAnd, OpOr>;
    template <class C>
        requires prism_rtl::one_of<C, OpAdd, OpSub, OpMul, OpDiv, OpEq, OpNe, OpLt, OpLe, OpGt, OpGe, OpAnd, OpOr>
    BinOp(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<BinOp> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const BinOp& a, const BinOp& b) { return a.cases() == b.cases(); }

}  // namespace lower::model

namespace lower::model {

/// `CaseDef`:
///
/// ```prism
/// type CaseDef = record:
/// ```
struct CaseDef {
    using prism_value = void;
    Text name_p;
    Text prism_p;
    Array<std::tuple<Text, OutTy>> fields_p;
    Array<Text> labels_p;
    const CaseDef* operator->() const { return this; }
    CaseDef* operator->() { return this; }
    bool operator==(const CaseDef&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<CaseDef> from_pod(const Pod& whole);
};


}  // namespace lower::model

namespace lower::model {

/// `CheckDef`:
///
/// ```prism
/// type CheckDef = record:
/// ```
struct CheckDef {
    using prism_value = void;
    Text name_p;
    Array<Ex> lines_p;
    const CheckDef* operator->() const { return this; }
    CheckDef* operator->() { return this; }
    bool operator==(const CheckDef&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<CheckDef> from_pod(const Pod& whole);
};


}  // namespace lower::model

namespace lower::model {

/// `CxArg`:
///
/// ```prism
/// type CxArg = choice:
/// ```
class CxArg {
public:
    using prism_value = void;
    struct CxMut {
        bool operator==(const CxMut&) const = default;
    };

    struct CxRef {
        bool operator==(const CxRef&) const = default;
    };

    struct CxNone {
        bool operator==(const CxNone&) const = default;
    };
    using Cases = std::variant<CxMut, CxRef, CxNone>;
    template <class C>
        requires prism_rtl::one_of<C, CxMut, CxRef, CxNone>
    CxArg(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<CxArg> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const CxArg& a, const CxArg& b) { return a.cases() == b.cases(); }

}  // namespace lower::model

namespace lower::model {

/// `ModDef`:
///
/// ```prism
/// type ModDef = record:
/// ```
struct ModDef {
    using prism_value = void;
    Text name_p;
    Text prism_p;
    Text path_p;
    Array<Text> uses_p;
    Array<Text> complete_p;
    Array<Text> declared_p;
    Array<Text> types_with_p;
    Array<Item> items_p;
    const ModDef* operator->() const { return this; }
    ModDef* operator->() { return this; }
    bool operator==(const ModDef&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ModDef> from_pod(const Pod& whole);
};


}  // namespace lower::model

namespace lower::model {

/// `OutTy`:
///
/// ```prism
/// type OutTy = choice:
/// ```
class OutTy {
public:
    using prism_value = void;
    struct OutNat {
        bool operator==(const OutNat&) const = default;
    };

    struct OutInt {
        bool operator==(const OutInt&) const = default;
    };

    struct OutU8 {
        bool operator==(const OutU8&) const = default;
    };

    struct OutFloat {
        bool operator==(const OutFloat&) const = default;
    };

    struct OutBool {
        bool operator==(const OutBool&) const = default;
    };

    struct OutChar {
        bool operator==(const OutChar&) const = default;
    };

    struct OutText {
        bool operator==(const OutText&) const = default;
    };

    struct OutCursor {
        bool operator==(const OutCursor&) const = default;
    };

    struct OutRegex {
        bool operator==(const OutRegex&) const = default;
    };

    struct OutReplacement {
        bool operator==(const OutReplacement&) const = default;
    };

    struct OutUnit {
        bool operator==(const OutUnit&) const = default;
    };

    struct OutPath {
        bool operator==(const OutPath&) const = default;
    };

    struct OutDuration {
        bool operator==(const OutDuration&) const = default;
    };

    struct OutError {
        bool operator==(const OutError&) const = default;
    };

    struct OutNamed {
        Text a0;
        Array<OutTy> a1;
        bool operator==(const OutNamed&) const;
    };

    struct OutOpt {
        prism_rtl::Rc<const OutTy> a0;
        bool operator==(const OutOpt&) const;
    };

    struct OutRes {
        prism_rtl::Rc<const OutTy> a0;
        bool operator==(const OutRes&) const;
    };

    struct OutTuple {
        Array<OutTy> a0;
        bool operator==(const OutTuple&) const;
    };

    struct OutArray {
        prism_rtl::Rc<const OutTy> a0;
        bool operator==(const OutArray&) const;
    };

    struct OutMap {
        prism_rtl::Rc<const OutTy> a0;
        prism_rtl::Rc<const OutTy> a1;
        bool operator==(const OutMap&) const;
    };

    struct OutFn {
        Array<OutTy> a0;
        prism_rtl::Rc<const OutTy> a1;
        bool operator==(const OutFn&) const;
    };

    struct OutJobFn {
        prism_rtl::Rc<const OutTy> a0;
        prism_rtl::Rc<const OutTy> a1;
        bool operator==(const OutJobFn&) const;
    };

    struct OutJob {
        prism_rtl::Rc<const OutTy> a0;
        bool operator==(const OutJob&) const;
    };

    struct OutEvent {
        prism_rtl::Rc<const OutTy> a0;
        bool operator==(const OutEvent&) const;
    };

    struct OutDyn {
        prism_rtl::Rc<const OutTy> a0;
        bool operator==(const OutDyn&) const;
    };

    struct OutGen {
        Text a0;
        bool operator==(const OutGen&) const = default;
    };

    struct OutRc {
        prism_rtl::Rc<const OutTy> a0;
        bool operator==(const OutRc&) const;
    };

    struct OutRef {
        prism_rtl::Rc<const OutTy> a0;
        bool operator==(const OutRef&) const;
    };

    struct OutPod {
        bool operator==(const OutPod&) const = default;
    };

    struct OutShowAny {
        bool operator==(const OutShowAny&) const = default;
    };

    struct OutHold {
        prism_rtl::Rc<const OutTy> a0;
        bool operator==(const OutHold&) const;
    };

    struct OutStamped {
        prism_rtl::Rc<const OutTy> a0;
        bool operator==(const OutStamped&) const;
    };

    struct OutSnapshot {
        prism_rtl::Rc<const OutTy> a0;
        bool operator==(const OutSnapshot&) const;
    };

    struct OutDefer {
        prism_rtl::Rc<const OutTy> a0;
        bool operator==(const OutDefer&) const;
    };

    struct OutWeak {
        Text a0;
        bool operator==(const OutWeak&) const = default;
    };

    struct OutCell {
        prism_rtl::Rc<const OutTy> a0;
        bool operator==(const OutCell&) const;
    };

    struct OutWakes {
        bool operator==(const OutWakes&) const = default;
    };

    struct OutCount {
        bool operator==(const OutCount&) const = default;
    };

    struct OutObj {
        prism_rtl::Rc<const OutTy> a0;
        bool operator==(const OutObj&) const;
    };

    struct OutSlice {
        prism_rtl::Rc<const OutTy> a0;
        bool operator==(const OutSlice&) const;
    };

    struct OutPort {
        prism_rtl::Rc<const OutTy> a0;
        bool operator==(const OutPort&) const;
    };

    struct OutLive {
        prism_rtl::Rc<const OutTy> a0;
        bool operator==(const OutLive&) const;
    };

    struct OutQuantified {
        Text a0;
        bool operator==(const OutQuantified&) const = default;
    };

    struct OutTurn {
        bool operator==(const OutTurn&) const = default;
    };

    struct OutRefused {
        Text a0;
        bool operator==(const OutRefused&) const = default;
    };
    using Cases = std::variant<OutNat, OutInt, OutU8, OutFloat, OutBool, OutChar, OutText, OutCursor, OutRegex, OutReplacement, OutUnit, OutPath, OutDuration, OutError, OutNamed, OutOpt, OutRes, OutTuple, OutArray, OutMap, OutFn, OutJobFn, OutJob, OutEvent, OutDyn, OutGen, OutRc, OutRef, OutPod, OutShowAny, OutHold, OutStamped, OutSnapshot, OutDefer, OutWeak, OutCell, OutWakes, OutCount, OutObj, OutSlice, OutPort, OutLive, OutQuantified, OutTurn, OutRefused>;
    template <class C>
        requires prism_rtl::one_of<C, OutNat, OutInt, OutU8, OutFloat, OutBool, OutChar, OutText, OutCursor, OutRegex, OutReplacement, OutUnit, OutPath, OutDuration, OutError, OutNamed, OutOpt, OutRes, OutTuple, OutArray, OutMap, OutFn, OutJobFn, OutJob, OutEvent, OutDyn, OutGen, OutRc, OutRef, OutPod, OutShowAny, OutHold, OutStamped, OutSnapshot, OutDefer, OutWeak, OutCell, OutWakes, OutCount, OutObj, OutSlice, OutPort, OutLive, OutQuantified, OutTurn, OutRefused>
    OutTy(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<OutTy> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const OutTy& a, const OutTy& b) { return a.cases() == b.cases(); }

}  // namespace lower::model

namespace lower::model {

/// `Pos`:
///
/// ```prism
/// type Pos = record:
/// ```
struct Pos_ {
    using prism_value = void;
    Nat scope_p;
    Nat at_p;
    const Pos_* operator->() const { return this; }
    Pos_* operator->() { return this; }
    bool operator==(const Pos_&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Pos_> from_pod(const Pod& whole);
};


}  // namespace lower::model

namespace lower::model {

/// `ProgDef`:
///
/// ```prism
/// type ProgDef = record:
/// ```
struct ProgDef {
    using prism_value = void;
    Text name_p;
    Text prism_p;
    Text node_p;
    Array<std::tuple<Text, OutTy>> params_p;
    bool fallible_p;
    Text world_p;
    const ProgDef* operator->() const { return this; }
    ProgDef* operator->() { return this; }
    bool operator==(const ProgDef&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ProgDef> from_pod(const Pod& whole);
};


}  // namespace lower::model

namespace lower::model {

/// `Recv`:
///
/// ```prism
/// type Recv = choice:
/// ```
class Recv {
public:
    using prism_value = void;
    struct RecvRc {
        bool operator==(const RecvRc&) const = default;
    };

    struct RecvRef {
        bool operator==(const RecvRef&) const = default;
    };

    struct RecvOwned {
        bool operator==(const RecvOwned&) const = default;
    };
    using Cases = std::variant<RecvRc, RecvRef, RecvOwned>;
    template <class C>
        requires prism_rtl::one_of<C, RecvRc, RecvRef, RecvOwned>
    Recv(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Recv> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const Recv& a, const Recv& b) { return a.cases() == b.cases(); }

}  // namespace lower::model

namespace lower::model {

/// `RowDef`:
///
/// ```prism
/// type RowDef = record:
/// ```
struct RowDef {
    using prism_value = void;
    Text name_p;
    Text prism_p;
    Array<std::tuple<Text, Text>> cases_p;
    bool pod_p;
    Text doc_p;
    bool eq_p;
    bool level_p;
    Array<Text> deep_p;
    const RowDef* operator->() const { return this; }
    RowDef* operator->() { return this; }
    bool operator==(const RowDef&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<RowDef> from_pod(const Pod& whole);
};


}  // namespace lower::model

namespace lower::model {

/// `RowKind`:
///
/// ```prism
/// type RowKind = choice:
/// ```
class RowKind {
public:
    using prism_value = void;
    struct ForRow {
        bool operator==(const ForRow&) const = default;
    };

    struct GenerationRow {
        bool operator==(const GenerationRow&) const = default;
    };

    struct NotARow {
        bool operator==(const NotARow&) const = default;
    };
    using Cases = std::variant<ForRow, GenerationRow, NotARow>;
    template <class C>
        requires prism_rtl::one_of<C, ForRow, GenerationRow, NotARow>
    RowKind(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<RowKind> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const RowKind& a, const RowKind& b) { return a.cases() == b.cases(); }

}  // namespace lower::model

namespace lower::model {

/// `Shown`:
///
/// ```prism
/// type Shown = choice:
/// ```
class Shown {
public:
    using prism_value = void;
    struct ShownOwn {
        bool operator==(const ShownOwn&) const = default;
    };

    struct ShownDerived {
        bool operator==(const ShownDerived&) const = default;
    };

    struct NotShown {
        bool operator==(const NotShown&) const = default;
    };
    using Cases = std::variant<ShownOwn, ShownDerived, NotShown>;
    template <class C>
        requires prism_rtl::one_of<C, ShownOwn, ShownDerived, NotShown>
    Shown(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Shown> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const Shown& a, const Shown& b) { return a.cases() == b.cases(); }

}  // namespace lower::model

namespace lower::model {

/// `TagDef`:
///
/// ```prism
/// type TagDef = record:
/// ```
struct TagDef {
    using prism_value = void;
    Text name_p;
    Text tag_name_p;
    Array<std::tuple<Text, Text, OutTy>> fields_p;
    Text doc_p;
    bool pod_p;
    bool eq_p;
    const TagDef* operator->() const { return this; }
    TagDef* operator->() { return this; }
    bool operator==(const TagDef&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TagDef> from_pod(const Pod& whole);
};


}  // namespace lower::model

namespace lower::model {

/// `TraitDef`:
///
/// ```prism
/// type TraitDef = record:
/// ```
struct TraitDef {
    using prism_value = void;
    Text name_p;
    Array<FnDef> methods_p;
    Array<Text> defaults_p;
    Text doc_p;
    const TraitDef* operator->() const { return this; }
    TraitDef* operator->() { return this; }
    bool operator==(const TraitDef&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TraitDef> from_pod(const Pod& whole);
};


}  // namespace lower::model

namespace lower::model {

/// `TyShape`:
///
/// ```prism
/// type TyShape = choice:
/// ```
class TyShape {
public:
    using prism_value = void;
    struct ShapeRecord {
        bool operator==(const ShapeRecord&) const = default;
    };

    struct ShapeChoice {
        bool operator==(const ShapeChoice&) const = default;
    };

    struct ShapeNewtype {
        bool operator==(const ShapeNewtype&) const = default;
    };

    struct ShapeUnit {
        bool operator==(const ShapeUnit&) const = default;
    };
    using Cases = std::variant<ShapeRecord, ShapeChoice, ShapeNewtype, ShapeUnit>;
    template <class C>
        requires prism_rtl::one_of<C, ShapeRecord, ShapeChoice, ShapeNewtype, ShapeUnit>
    TyShape(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TyShape> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const TyShape& a, const TyShape& b) { return a.cases() == b.cases(); }

}  // namespace lower::model

namespace lower::model {

/// `UnOp`:
///
/// ```prism
/// type UnOp = choice:
/// ```
class UnOp {
public:
    using prism_value = void;
    struct OpNot {
        bool operator==(const OpNot&) const = default;
    };

    struct OpNeg {
        bool operator==(const OpNeg&) const = default;
    };
    using Cases = std::variant<OpNot, OpNeg>;
    template <class C>
        requires prism_rtl::one_of<C, OpNot, OpNeg>
    UnOp(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<UnOp> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const UnOp& a, const UnOp& b) { return a.cases() == b.cases(); }

}  // namespace lower::model

namespace lower::model {

/// `AnswerCase`:
///
/// ```prism
/// type AnswerCase = record:
/// ```
struct AnswerCase {
    using prism_value = void;
    Text variant_p;
    Text accessor_p;
    Text struct_path_p;
    Text tag_name_p;
    OutTy ty_p;
    const AnswerCase* operator->() const { return this; }
    AnswerCase* operator->() { return this; }
    bool operator==(const AnswerCase&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<AnswerCase> from_pod(const Pod& whole);
};


}  // namespace lower::model

namespace lower::model {

/// `Ex`:
///
/// ```prism
/// type Ex = choice:
/// ```
class Ex {
public:
    using prism_value = void;
    struct XVar {
        Text a0;
        bool operator==(const XVar&) const = default;
    };

    struct XPath {
        Text a0;
        bool operator==(const XPath&) const = default;
    };

    struct XSelf {
        bool operator==(const XSelf&) const = default;
    };

    struct XCx {
        bool operator==(const XCx&) const = default;
    };

    struct XConst {
        Text a0;
        bool operator==(const XConst&) const = default;
    };

    struct XUnit {
        bool operator==(const XUnit&) const = default;
    };

    struct XNone {
        bool operator==(const XNone&) const = default;
    };

    struct XBool {
        bool a0;
        bool operator==(const XBool&) const = default;
    };

    struct XNat {
        Text a0;
        bool operator==(const XNat&) const = default;
    };

    struct XInt {
        Text a0;
        bool operator==(const XInt&) const = default;
    };

    struct XByte {
        Text a0;
        bool operator==(const XByte&) const = default;
    };

    struct XFloat {
        Text a0;
        bool operator==(const XFloat&) const = default;
    };

    struct XIndex {
        Nat a0;
        bool operator==(const XIndex&) const = default;
    };

    struct XChar {
        Text a0;
        bool operator==(const XChar&) const = default;
    };

    struct XStr {
        Text a0;
        bool operator==(const XStr&) const = default;
    };

    struct XRegex {
        Text a0;
        Text a1;
        bool operator==(const XRegex&) const = default;
    };

    struct XReplacement {
        Text a0;
        Text a1;
        Text a2;
        bool operator==(const XReplacement&) const = default;
    };

    struct XRef {
        prism_rtl::Rc<const Ex> a0;
        bool operator==(const XRef&) const;
    };

    struct XRefMut {
        prism_rtl::Rc<const Ex> a0;
        bool operator==(const XRefMut&) const;
    };

    struct XDeref {
        prism_rtl::Rc<const Ex> a0;
        bool operator==(const XDeref&) const;
    };

    struct XTarget {
        prism_rtl::Rc<const Ex> a0;
        bool operator==(const XTarget&) const;
    };

    struct XClone {
        prism_rtl::Rc<const Ex> a0;
        bool operator==(const XClone&) const;
    };

    struct XWeak {
        prism_rtl::Rc<const Ex> a0;
        bool operator==(const XWeak&) const;
    };

    struct XUpgrade {
        prism_rtl::Rc<const Ex> a0;
        bool operator==(const XUpgrade&) const;
    };

    struct XBreak {
        Text a0;
        prism_rtl::Rc<const Ex> a1;
        bool operator==(const XBreak&) const;
    };

    struct XBreakLoop {
        bool operator==(const XBreakLoop&) const = default;
    };

    struct XLater {
        prism_rtl::Rc<const Ex> a0;
        bool operator==(const XLater&) const;
    };

    struct XFormatStr {
        Array<Ex> a0;
        bool operator==(const XFormatStr&) const;
    };

    struct XIsCase {
        prism_rtl::Rc<const Ex> a0;
        Array<Text> a1;
        bool operator==(const XIsCase&) const;
    };

    struct XRefusal {
        Text a0;
        bool operator==(const XRefusal&) const = default;
    };

    struct XUnreachable {
        bool operator==(const XUnreachable&) const = default;
    };

    struct XCall {
        Text a0;
        Array<Ex> a1;
        bool operator==(const XCall&) const;
    };

    struct XApply {
        prism_rtl::Rc<const Ex> a0;
        Array<Ex> a1;
        bool operator==(const XApply&) const;
    };

    struct XMethod {
        prism_rtl::Rc<const Ex> a0;
        Text a1;
        Array<Ex> a2;
        bool operator==(const XMethod&) const;
    };

    struct XBin {
        BinOp a0;
        prism_rtl::Rc<const Ex> a1;
        prism_rtl::Rc<const Ex> a2;
        bool operator==(const XBin&) const;
    };

    struct XUnary {
        UnOp a0;
        prism_rtl::Rc<const Ex> a1;
        bool operator==(const XUnary&) const;
    };

    struct XCtor {
        Text a0;
        Array<Ex> a1;
        bool operator==(const XCtor&) const;
    };

    struct XRecord {
        Text a0;
        Array<std::tuple<Text, Ex>> a1;
        bool operator==(const XRecord&) const;
    };

    struct XTuple {
        Array<Ex> a0;
        bool operator==(const XTuple&) const;
    };

    struct XVec {
        Array<Ex> a0;
        bool operator==(const XVec&) const;
    };

    struct XText {
        Text a0;
        bool operator==(const XText&) const = default;
    };

    struct XFormat {
        Array<Ex> a0;
        bool operator==(const XFormat&) const;
    };

    struct XMatch {
        prism_rtl::Rc<const Ex> a0;
        Array<XArm> a1;
        bool a2;
        OutTy a3;
        bool operator==(const XMatch&) const;
    };

    struct XChain {
        Text a0;
        prism_rtl::Rc<const Ex> a1;
        Array<XArm> a2;
        OutTy a3;
        bool operator==(const XChain&) const;
    };

    struct XIf {
        prism_rtl::Rc<const Ex> a0;
        prism_rtl::Rc<const Ex> a1;
        prism_rtl::Rc<const Ex> a2;
        bool operator==(const XIf&) const;
    };

    struct XBlock {
        Array<Do> a0;
        prism_rtl::Rc<const Ex> a1;
        bool operator==(const XBlock&) const;
    };

    struct XLabeled {
        Text a0;
        Array<Do> a1;
        prism_rtl::Rc<const Ex> a2;
        OutTy a3;
        bool operator==(const XLabeled&) const;
    };

    struct XClosure {
        bool a0;
        Array<Pa> a1;
        prism_rtl::Rc<const Ex> a2;
        bool operator==(const XClosure&) const;
    };

    struct XTry {
        prism_rtl::Rc<const Ex> a0;
        bool operator==(const XTry&) const;
    };

    struct XField {
        prism_rtl::Rc<const Ex> a0;
        Text a1;
        bool operator==(const XField&) const;
    };

    struct XPart {
        prism_rtl::Rc<const Ex> a0;
        Nat a1;
        bool operator==(const XPart&) const;
    };

    struct XDecode {
        OutTy a0;
        prism_rtl::Rc<const Ex> a1;
        bool operator==(const XDecode&) const;
    };

    struct XCast {
        prism_rtl::Rc<const Ex> a0;
        OutTy a1;
        bool operator==(const XCast&) const;
    };

    struct XTyped {
        prism_rtl::Rc<const Ex> a0;
        OutTy a1;
        bool operator==(const XTyped&) const;
    };
    using Cases = std::variant<XVar, XPath, XSelf, XCx, XConst, XUnit, XNone, XBool, XNat, XInt, XByte, XFloat, XIndex, XChar, XStr, XRegex, XReplacement, XRef, XRefMut, XDeref, XTarget, XClone, XWeak, XUpgrade, XBreak, XBreakLoop, XLater, XFormatStr, XIsCase, XRefusal, XUnreachable, XCall, XApply, XMethod, XBin, XUnary, XCtor, XRecord, XTuple, XVec, XText, XFormat, XMatch, XChain, XIf, XBlock, XLabeled, XClosure, XTry, XField, XPart, XDecode, XCast, XTyped>;
    template <class C>
        requires prism_rtl::one_of<C, XVar, XPath, XSelf, XCx, XConst, XUnit, XNone, XBool, XNat, XInt, XByte, XFloat, XIndex, XChar, XStr, XRegex, XReplacement, XRef, XRefMut, XDeref, XTarget, XClone, XWeak, XUpgrade, XBreak, XBreakLoop, XLater, XFormatStr, XIsCase, XRefusal, XUnreachable, XCall, XApply, XMethod, XBin, XUnary, XCtor, XRecord, XTuple, XVec, XText, XFormat, XMatch, XChain, XIf, XBlock, XLabeled, XClosure, XTry, XField, XPart, XDecode, XCast, XTyped>
    Ex(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Ex> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const Ex& a, const Ex& b) { return a.cases() == b.cases(); }

}  // namespace lower::model

namespace lower::model {

/// `ImplDef`:
///
/// ```prism
/// type ImplDef = record:
/// ```
struct ImplDef {
    using prism_value = void;
    Text cls_p;
    Text tr_p;
    OutTy head_p;
    Array<std::tuple<Text, Array<Text>>> generics_p;
    Array<FnDef> methods_p;
    Text doc_p;
    const ImplDef* operator->() const { return this; }
    ImplDef* operator->() { return this; }
    bool operator==(const ImplDef&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ImplDef> from_pod(const Pod& whole);
};


}  // namespace lower::model

namespace lower::model {

/// `Model`:
///
/// ```prism
/// type Model = record:
/// ```
struct Model {
    using prism_value = void;
    Text name_p;
    Array<ModDef> mods_p;
    Array<ProgDef> programs_p;
    std::optional<ProgDef> root_o;
    Array<CheckDef> checks_p;
    RowDef elem_p;
    AnswerDef answer_p;
    Array<Text> elem_complete_p;
    Array<Text> elem_declared_p;
    Array<Text> scripts_p;
    Array<Text> notes_p;
    const Model* operator->() const { return this; }
    Model* operator->() { return this; }
    bool operator==(const Model&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Model> from_pod(const Pod& whole);
};


}  // namespace lower::model

namespace lower::model {

/// `NodeDef`:
///
/// ```prism
/// type NodeDef = record:
/// ```
struct NodeDef {
    using prism_value = void;
    Text name_p;
    Text prism_p;
    Text doc_p;
    Array<std::tuple<Text, OutTy>> params_p;
    Array<std::tuple<Text, OutTy, Text>> fields_p;
    Array<std::tuple<Text, Nat, Text>> consts_p;
    Array<Do> lets_p;
    Array<std::tuple<Text, Ex>> inits_p;
    Array<Do> build_p;
    bool fallible_p;
    Array<MethDef> methods_p;
    Array<std::tuple<Pa, Ex>> answers_p;
    Array<std::tuple<Text, Array<Do>>> hooks_p;
    Array<ForDef> builders_p;
    bool wakes_p;
    Array<NodeDef> children_p;
    Array<GenDef> gens_p;
    Array<std::tuple<Text, Text, OutTy>> subs_p;
    Nat top_p;
    RowKind row_kind_p;
    Array<MethDef> hosted_p;
    const NodeDef* operator->() const { return this; }
    NodeDef* operator->() { return this; }
    bool operator==(const NodeDef&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<NodeDef> from_pod(const Pod& whole);
};


}  // namespace lower::model

namespace lower::model {

/// `Pa`:
///
/// ```prism
/// type Pa = choice:
/// ```
class Pa {
public:
    using prism_value = void;
    struct PaWild {
        bool operator==(const PaWild&) const = default;
    };

    struct PaBind {
        Text a0;
        bool operator==(const PaBind&) const = default;
    };

    struct PaMut {
        Text a0;
        bool operator==(const PaMut&) const = default;
    };

    struct PaCtor {
        Text a0;
        Array<Pa> a1;
        bool operator==(const PaCtor&) const;
    };

    struct PaUnit {
        Text a0;
        bool operator==(const PaUnit&) const = default;
    };

    struct PaRecord {
        Text a0;
        Array<std::tuple<Text, Pa>> a1;
        bool a2;
        bool operator==(const PaRecord&) const;
    };

    struct PaTuple {
        Array<Pa> a0;
        bool operator==(const PaTuple&) const;
    };

    struct PaChar {
        Text a0;
        bool operator==(const PaChar&) const = default;
    };

    struct PaBool {
        bool a0;
        bool operator==(const PaBool&) const = default;
    };

    struct PaIndex {
        Nat a0;
        bool operator==(const PaIndex&) const = default;
    };

    struct PaConst {
        Text a0;
        bool operator==(const PaConst&) const = default;
    };

    struct PaSlice {
        Array<Pa> a0;
        bool operator==(const PaSlice&) const;
    };

    struct PaRest {
        Text a0;
        bool operator==(const PaRest&) const = default;
    };

    struct PaTyped {
        prism_rtl::Rc<const Pa> a0;
        OutTy a1;
        bool operator==(const PaTyped&) const;
    };
    using Cases = std::variant<PaWild, PaBind, PaMut, PaCtor, PaUnit, PaRecord, PaTuple, PaChar, PaBool, PaIndex, PaConst, PaSlice, PaRest, PaTyped>;
    template <class C>
        requires prism_rtl::one_of<C, PaWild, PaBind, PaMut, PaCtor, PaUnit, PaRecord, PaTuple, PaChar, PaBool, PaIndex, PaConst, PaSlice, PaRest, PaTyped>
    Pa(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Pa> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const Pa& a, const Pa& b) { return a.cases() == b.cases(); }

}  // namespace lower::model

namespace lower::model {

/// `TyDef`:
///
/// ```prism
/// type TyDef = record:
/// ```
struct TyDef {
    using prism_value = void;
    Text name_p;
    Text prism_p;
    Array<Text> params_p;
    TyShape shape_p;
    Array<CaseDef> cases_p;
    bool eq_p;
    bool ord_p;
    Shown show_p;
    bool pod_p;
    Text doc_p;
    const TyDef* operator->() const { return this; }
    TyDef* operator->() { return this; }
    bool operator==(const TyDef&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TyDef> from_pod(const Pod& whole);
};


}  // namespace lower::model

namespace lower::model {

/// `Cc`:
///
/// ```prism
/// type Cc = choice:
/// ```
class Cc {
public:
    using prism_value = void;
    struct CcIf {
        Ex a0;
        bool operator==(const CcIf&) const = default;
    };

    struct CcLet {
        Pa a0;
        Ex a1;
        bool operator==(const CcLet&) const = default;
    };
    using Cases = std::variant<CcIf, CcLet>;
    template <class C>
        requires prism_rtl::one_of<C, CcIf, CcLet>
    Cc(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Cc> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const Cc& a, const Cc& b) { return a.cases() == b.cases(); }

}  // namespace lower::model

namespace lower::model {

/// `Do`:
///
/// ```prism
/// type Do = choice:
/// ```
class Do {
public:
    using prism_value = void;
    struct DoLet {
        Pa a0;
        Ex a1;
        bool operator==(const DoLet&) const = default;
    };

    struct DoLetElse {
        Pa a0;
        Ex a1;
        Ex a2;
        bool operator==(const DoLetElse&) const = default;
    };

    struct DoAssign {
        Ex a0;
        Ex a1;
        bool operator==(const DoAssign&) const = default;
    };

    struct DoWhile {
        Ex a0;
        Array<Do> a1;
        bool operator==(const DoWhile&) const;
    };

    struct DoWhileLet {
        Pa a0;
        Ex a1;
        Array<Do> a2;
        bool operator==(const DoWhileLet&) const;
    };

    struct DoFor {
        Pa a0;
        Ex a1;
        Array<Do> a2;
        bool operator==(const DoFor&) const;
    };

    struct DoExpr {
        Ex a0;
        bool operator==(const DoExpr&) const = default;
    };

    struct DoIf {
        Ex a0;
        Array<Do> a1;
        Array<Do> a2;
        bool operator==(const DoIf&) const;
    };

    struct DoIfLet {
        Pa a0;
        Ex a1;
        Array<Do> a2;
        Array<Do> a3;
        bool operator==(const DoIfLet&) const;
    };

    struct DoMatch {
        Ex a0;
        Array<std::tuple<Pa, Array<Do>>> a1;
        bool operator==(const DoMatch&) const;
    };

    struct DoReturn {
        Ex a0;
        bool operator==(const DoReturn&) const = default;
    };

    struct DoBlock {
        Array<Do> a0;
        bool operator==(const DoBlock&) const;
    };

    struct DoScope {
        Array<Do> a0;
        bool operator==(const DoScope&) const;
    };

    struct DoLine {
        Array<Do> a0;
        bool operator==(const DoLine&) const;
    };

    struct DoNote {
        Text a0;
        bool operator==(const DoNote&) const = default;
    };
    using Cases = std::variant<DoLet, DoLetElse, DoAssign, DoWhile, DoWhileLet, DoFor, DoExpr, DoIf, DoIfLet, DoMatch, DoReturn, DoBlock, DoScope, DoLine, DoNote>;
    template <class C>
        requires prism_rtl::one_of<C, DoLet, DoLetElse, DoAssign, DoWhile, DoWhileLet, DoFor, DoExpr, DoIf, DoIfLet, DoMatch, DoReturn, DoBlock, DoScope, DoLine, DoNote>
    Do(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Do> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const Do& a, const Do& b) { return a.cases() == b.cases(); }

}  // namespace lower::model

namespace lower::model {

/// `FnDef`:
///
/// ```prism
/// type FnDef = record:
/// ```
struct FnDef {
    using prism_value = void;
    Text name_p;
    Array<std::tuple<Text, Array<Text>>> generics_p;
    Array<std::tuple<Text, OutTy>> params_p;
    OutTy ret_p;
    Ex body_p;
    Text doc_p;
    bool public_p;
    const FnDef* operator->() const { return this; }
    FnDef* operator->() { return this; }
    bool operator==(const FnDef&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<FnDef> from_pod(const Pod& whole);
};


}  // namespace lower::model

namespace lower::model {

/// `ForDef`:
///
/// ```prism
/// type ForDef = record:
/// ```
struct ForDef {
    using prism_value = void;
    Text name_p;
    Pos_ pos_p;
    Ex at_p;
    OutTy key_ty_p;
    OutTy value_ty_p;
    Text row_node_p;
    bool keyed_p;
    Text source_p;
    Ex parent_p;
    Array<Ex> passed_p;
    Text moved_p;
    Array<Text> replaced_p;
    const ForDef* operator->() const { return this; }
    ForDef* operator->() { return this; }
    bool operator==(const ForDef&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ForDef> from_pod(const Pod& whole);
};


}  // namespace lower::model

namespace lower::model {

/// `GenDef`:
///
/// ```prism
/// type GenDef = record:
/// ```
struct GenDef {
    using prism_value = void;
    Text name_p;
    Pos_ pos_p;
    Ex at_p;
    Ex source_p;
    OutTy value_ty_p;
    Ex select_p;
    bool transparent_p;
    Nat width_p;
    Text moved_p;
    const GenDef* operator->() const { return this; }
    GenDef* operator->() { return this; }
    bool operator==(const GenDef&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<GenDef> from_pod(const Pod& whole);
};


}  // namespace lower::model

namespace lower::model {

/// `JobDef`:
///
/// ```prism
/// type JobDef = record:
/// ```
struct JobDef {
    using prism_value = void;
    Text name_p;
    Text start_p;
    Array<std::tuple<Text, Array<Text>>> generics_p;
    Array<std::tuple<Text, OutTy>> fields_p;
    OutTy ret_p;
    Ex body_p;
    Text doc_p;
    const JobDef* operator->() const { return this; }
    JobDef* operator->() { return this; }
    bool operator==(const JobDef&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<JobDef> from_pod(const Pod& whole);
};


}  // namespace lower::model

namespace lower::model {

/// `MethDef`:
///
/// ```prism
/// type MethDef = record:
/// ```
struct MethDef {
    using prism_value = void;
    Text name_p;
    Recv recv_p;
    Array<std::tuple<Text, OutTy>> params_p;
    CxArg cx_p;
    OutTy ret_p;
    Array<Do> body_p;
    Ex tail_p;
    Text doc_p;
    const MethDef* operator->() const { return this; }
    MethDef* operator->() { return this; }
    bool operator==(const MethDef&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<MethDef> from_pod(const Pod& whole);
};


}  // namespace lower::model

namespace lower::model {

/// `XArm`:
///
/// ```prism
/// type XArm = record:
/// ```
struct XArm {
    using prism_value = void;
    Pa pat_p;
    Array<Cc> conds_p;
    Ex body_p;
    const XArm* operator->() const { return this; }
    XArm* operator->() { return this; }
    bool operator==(const XArm&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<XArm> from_pod(const Pod& whole);
};


}  // namespace lower::model

namespace lower::model {

/// `Item`:
///
/// ```prism
/// type Item = choice:
/// ```
class Item {
public:
    using prism_value = void;
    struct ItTrait {
        TraitDef a0;
        bool operator==(const ItTrait&) const = default;
    };

    struct ItImpl {
        ImplDef a0;
        bool operator==(const ItImpl&) const = default;
    };

    struct ItType {
        TyDef a0;
        bool operator==(const ItType&) const = default;
    };

    struct ItTag {
        TagDef a0;
        bool operator==(const ItTag&) const = default;
    };

    struct ItRow {
        RowDef a0;
        bool operator==(const ItRow&) const = default;
    };

    struct ItFn {
        FnDef a0;
        bool operator==(const ItFn&) const = default;
    };

    struct ItJob {
        JobDef a0;
        bool operator==(const ItJob&) const = default;
    };

    struct ItNode {
        NodeDef a0;
        bool operator==(const ItNode&) const = default;
    };

    struct ItNote {
        Text a0;
        bool operator==(const ItNote&) const = default;
    };

    struct ItRefused {
        Text a0;
        bool operator==(const ItRefused&) const = default;
    };
    using Cases = std::variant<ItTrait, ItImpl, ItType, ItTag, ItRow, ItFn, ItJob, ItNode, ItNote, ItRefused>;
    template <class C>
        requires prism_rtl::one_of<C, ItTrait, ItImpl, ItType, ItTag, ItRow, ItFn, ItJob, ItNode, ItNote, ItRefused>
    Item(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Item> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const Item& a, const Item& b) { return a.cases() == b.cases(); }

}  // namespace lower::model

}  // namespace crate
