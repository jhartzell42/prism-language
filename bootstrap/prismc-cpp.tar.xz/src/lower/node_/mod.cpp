// The module `Lower.Node`, from `target/bootstrap/cpp-src/prismc/lower/node/mod.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <lower/node_/module.hpp>
#include <lower/model/module.hpp>
#include <lower/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/env/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/passes/module.hpp>
#include <check/shrink/module.hpp>
#include <check/typed/module.hpp>
#include <check/types/module.hpp>
#include <syntax/module.hpp>
#include <syntax/lexer/module.hpp>
#include <lower/node_/generic.hpp>
#include <check/env/generic.hpp>
#include <syntax/lexer/generic.hpp>

namespace crate::lower::node_ {





Pod FlatDef::to_pod() const {
    return Pod::record("FlatDef", {{"name", prism_rtl::to_pod(name)}, {"outer", prism_rtl::to_pod(outer)}, {"generation", prism_rtl::to_pod(generation)}, {"ty", prism_rtl::to_pod(ty)}});
}

Result<FlatDef> FlatDef::from_pod(const Pod& whole) {
    return FlatDef{.name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .outer = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "outer")))), .generation = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "generation")))), .ty = TRY(prism_rtl::from_pod<crate::lower::model::OutTy>(TRY(crate::prelude::field(whole, "ty"))))};
}


Pod GenCase::to_pod() const {
    return Pod::record("GenCase", {{"node", prism_rtl::to_pod(node_)}, {"params", prism_rtl::to_pod(params)}, {"pat", prism_rtl::to_pod(pat)}, {"conds", prism_rtl::to_pod(conds)}, {"passed", prism_rtl::to_pod(passed)}});
}

Result<GenCase> GenCase::from_pod(const Pod& whole) {
    return GenCase{.node_ = TRY(prism_rtl::from_pod<crate::lower::model::NodeDef>(TRY(crate::prelude::field(whole, "node")))), .params = TRY(prism_rtl::from_pod<Array<std::tuple<Text, crate::lower::model::OutTy>>>(TRY(crate::prelude::field(whole, "params")))), .pat = TRY(prism_rtl::from_pod<crate::lower::model::Pa>(TRY(crate::prelude::field(whole, "pat")))), .conds = TRY(prism_rtl::from_pod<Array<crate::lower::model::Cc>>(TRY(crate::prelude::field(whole, "conds")))), .passed = TRY(prism_rtl::from_pod<Array<crate::lower::model::Ex>>(TRY(crate::prelude::field(whole, "passed"))))};
}






void GnKind::show(Printer& p) const {
    if (auto c = std::get_if<GnNamed>(&cases())) p.choice("GnNamed", {});
    else if (auto c = std::get_if<GnAnswer>(&cases())) p.choice("GnAnswer", {});
    else if (auto c = std::get_if<GnStarted>(&cases())) p.choice("GnStarted", {});
    else if (auto c = std::get_if<GnDeferred>(&cases())) p.choice("GnDeferred", {});
    else if (auto c = std::get_if<GnPort>(&cases())) p.choice("GnPort", {});
    else if (auto c = std::get_if<GnMerge>(&cases())) p.choice("GnMerge", {});
    else if (auto c = std::get_if<GnUnion>(&cases())) p.choice("GnUnion", {});
    else if (auto c = std::get_if<GnBoth>(&cases())) p.choice("GnBoth", {});
    else if (auto c = std::get_if<GnExcept>(&cases())) p.choice("GnExcept", {});
    else if (auto c = std::get_if<GnMergeAll>(&cases())) p.choice("GnMergeAll", {});
    else if (auto c = std::get_if<GnGather>(&cases())) p.choice("GnGather", {});
    else if (auto c = std::get_if<GnUpdated>(&cases())) p.choice("GnUpdated", {});
    else if (auto c = std::get_if<GnNever>(&cases())) p.choice("GnNever", {});
}

Pod GnKind::to_pod() const {
    return std::holds_alternative<GnNamed>(cases()) ? Pod::choice("GnNamed", {})
        : std::holds_alternative<GnAnswer>(cases()) ? Pod::choice("GnAnswer", {})
        : std::holds_alternative<GnStarted>(cases()) ? Pod::choice("GnStarted", {})
        : std::holds_alternative<GnDeferred>(cases()) ? Pod::choice("GnDeferred", {})
        : std::holds_alternative<GnPort>(cases()) ? Pod::choice("GnPort", {})
        : std::holds_alternative<GnMerge>(cases()) ? Pod::choice("GnMerge", {})
        : std::holds_alternative<GnUnion>(cases()) ? Pod::choice("GnUnion", {})
        : std::holds_alternative<GnBoth>(cases()) ? Pod::choice("GnBoth", {})
        : std::holds_alternative<GnExcept>(cases()) ? Pod::choice("GnExcept", {})
        : std::holds_alternative<GnMergeAll>(cases()) ? Pod::choice("GnMergeAll", {})
        : std::holds_alternative<GnGather>(cases()) ? Pod::choice("GnGather", {})
        : std::holds_alternative<GnUpdated>(cases()) ? Pod::choice("GnUpdated", {})
        : std::holds_alternative<GnNever>(cases()) ? Pod::choice("GnNever", {})
        : Pod();
}

Result<GnKind> GnKind::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "GnNamed" && c->args.size() == 0) return GnKind(GnNamed{});
        if (c->ctor == "GnAnswer" && c->args.size() == 0) return GnKind(GnAnswer{});
        if (c->ctor == "GnStarted" && c->args.size() == 0) return GnKind(GnStarted{});
        if (c->ctor == "GnDeferred" && c->args.size() == 0) return GnKind(GnDeferred{});
        if (c->ctor == "GnPort" && c->args.size() == 0) return GnKind(GnPort{});
        if (c->ctor == "GnMerge" && c->args.size() == 0) return GnKind(GnMerge{});
        if (c->ctor == "GnUnion" && c->args.size() == 0) return GnKind(GnUnion{});
        if (c->ctor == "GnBoth" && c->args.size() == 0) return GnKind(GnBoth{});
        if (c->ctor == "GnExcept" && c->args.size() == 0) return GnKind(GnExcept{});
        if (c->ctor == "GnMergeAll" && c->args.size() == 0) return GnKind(GnMergeAll{});
        if (c->ctor == "GnGather" && c->args.size() == 0) return GnKind(GnGather{});
        if (c->ctor == "GnUpdated" && c->args.size() == 0) return GnKind(GnUpdated{});
        if (c->ctor == "GnNever" && c->args.size() == 0) return GnKind(GnNever{});
    }
    return mismatch<GnKind>("a GnKind", p);
}


Pod HostDef::to_pod() const {
    return Pod::record("HostDef", {{"pos", prism_rtl::to_pod(pos)}, {"name", prism_rtl::to_pod(name)}, {"scope", prism_rtl::to_pod(scope)}});
}

Result<HostDef> HostDef::from_pod(const Pod& whole) {
    return HostDef{.pos = TRY(prism_rtl::from_pod<crate::lower::model::Pos_>(TRY(crate::prelude::field(whole, "pos")))), .name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .scope = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "scope"))))};
}


void HostForm::show(Printer& p) const {
    if (auto c = std::get_if<HostEach>(&cases())) p.choice("HostEach", {});
    else if (auto c = std::get_if<HostSome>(&cases())) p.choice("HostSome", {});
}

Pod HostForm::to_pod() const {
    return std::holds_alternative<HostEach>(cases()) ? Pod::choice("HostEach", {})
        : std::holds_alternative<HostSome>(cases()) ? Pod::choice("HostSome", {})
        : Pod();
}

Result<HostForm> HostForm::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "HostEach" && c->args.size() == 0) return HostForm(HostEach{});
        if (c->ctor == "HostSome" && c->args.size() == 0) return HostForm(HostSome{});
    }
    return mismatch<HostForm>("a HostForm", p);
}


void HowBound::show(Printer& p) const {
    if (auto c = std::get_if<AsHold>(&cases())) p.choice("AsHold", {});
    else if (auto c = std::get_if<AsBind>(&cases())) p.choice("AsBind", {});
    else if (auto c = std::get_if<AsLet>(&cases())) p.choice("AsLet", {});
}

Pod HowBound::to_pod() const {
    return std::holds_alternative<AsHold>(cases()) ? Pod::choice("AsHold", {})
        : std::holds_alternative<AsBind>(cases()) ? Pod::choice("AsBind", {})
        : std::holds_alternative<AsLet>(cases()) ? Pod::choice("AsLet", {})
        : Pod();
}

Result<HowBound> HowBound::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "AsHold" && c->args.size() == 0) return HowBound(AsHold{});
        if (c->ctor == "AsBind" && c->args.size() == 0) return HowBound(AsBind{});
        if (c->ctor == "AsLet" && c->args.size() == 0) return HowBound(AsLet{});
    }
    return mismatch<HowBound>("a HowBound", p);
}






Pod Place::to_pod() const {
    return Pod::record("Place", {{"pos", prism_rtl::to_pod(pos)}, {"level", prism_rtl::to_pod(level)}, {"getter", prism_rtl::to_pod(getter)}, {"reads", prism_rtl::to_pod(reads)}});
}

Result<Place> Place::from_pod(const Pod& whole) {
    return Place{.pos = TRY(prism_rtl::from_pod<crate::lower::model::Pos_>(TRY(crate::prelude::field(whole, "pos")))), .level = TRY(prism_rtl::from_pod<crate::lower::model::Ex>(TRY(crate::prelude::field(whole, "level")))), .getter = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "getter")))), .reads = TRY(prism_rtl::from_pod<Array<Read>>(TRY(crate::prelude::field(whole, "reads"))))};
}


void Read::show(Printer& p) const {
    if (auto c = std::get_if<OwnRead>(&cases())) p.choice("OwnRead", {c->a0});
    else if (auto c = std::get_if<ParentRead>(&cases())) p.choice("ParentRead", {c->a0});
}

Pod Read::to_pod() const {
    return std::holds_alternative<OwnRead>(cases()) ? Pod::choice("OwnRead", {prism_rtl::to_pod(std::get<OwnRead>(cases()).a0)})
        : std::holds_alternative<ParentRead>(cases()) ? Pod::choice("ParentRead", {prism_rtl::to_pod(std::get<ParentRead>(cases()).a0)})
        : Pod();
}

Result<Read> Read::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "OwnRead" && c->args.size() == 1) return Read(OwnRead{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "ParentRead" && c->args.size() == 1) return Read(ParentRead{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
    }
    return mismatch<Read>("a Read", p);
}


Pod RowLocal::to_pod() const {
    return Pod::record("RowLocal", {{"name", prism_rtl::to_pod(name)}, {"field", prism_rtl::to_pod(field)}, {"ty", prism_rtl::to_pod(ty)}, {"passed", prism_rtl::to_pod(passed)}});
}

Result<RowLocal> RowLocal::from_pod(const Pod& whole) {
    return RowLocal{.name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .field = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "field")))), .ty = TRY(prism_rtl::from_pod<crate::lower::model::OutTy>(TRY(crate::prelude::field(whole, "ty")))), .passed = TRY(prism_rtl::from_pod<crate::lower::model::Ex>(TRY(crate::prelude::field(whole, "passed"))))};
}


Pod RowMarks::to_pod() const {
    return Pod::record("RowMarks", {{"builder", prism_rtl::to_pod(builder)}, {"reads", prism_rtl::to_pod(reads)}, {"wrote", prism_rtl::to_pod(wrote)}, {"kind", prism_rtl::to_pod(kind)}});
}

Result<RowMarks> RowMarks::from_pod(const Pod& whole) {
    return RowMarks{.builder = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "builder")))), .reads = TRY(prism_rtl::from_pod<Array<Read>>(TRY(crate::prelude::field(whole, "reads")))), .wrote = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "wrote")))), .kind = TRY(prism_rtl::from_pod<crate::lower::model::RowKind>(TRY(crate::prelude::field(whole, "kind"))))};
}




Pod Sk::to_pod() const {
    return std::holds_alternative<SkNode>(cases()) ? Pod::choice("SkNode", {prism_rtl::to_pod(std::get<SkNode>(cases()).a0)})
        : std::holds_alternative<SkIn>(cases()) ? Pod::choice("SkIn", {prism_rtl::to_pod(std::get<SkIn>(cases()).a0), prism_rtl::to_pod(std::get<SkIn>(cases()).a1)})
        : std::holds_alternative<SkHold>(cases()) ? Pod::choice("SkHold", {prism_rtl::to_pod(std::get<SkHold>(cases()).a0)})
        : std::holds_alternative<SkRequest>(cases()) ? Pod::choice("SkRequest", {prism_rtl::to_pod(std::get<SkRequest>(cases()).a0), prism_rtl::to_pod(std::get<SkRequest>(cases()).a1)})
        : std::holds_alternative<SkResult>(cases()) ? Pod::choice("SkResult", {})
        : std::holds_alternative<SkArm>(cases()) ? Pod::choice("SkArm", {prism_rtl::to_pod(std::get<SkArm>(cases()).a0)})
        : std::holds_alternative<SkCycle>(cases()) ? Pod::choice("SkCycle", {prism_rtl::to_pod(std::get<SkCycle>(cases()).a0), prism_rtl::to_pod(std::get<SkCycle>(cases()).a1), prism_rtl::to_pod(std::get<SkCycle>(cases()).a2)})
        : std::holds_alternative<SkUp>(cases()) ? Pod::choice("SkUp", {prism_rtl::to_pod(std::get<SkUp>(cases()).a0)})
        : std::holds_alternative<SkPort>(cases()) ? Pod::choice("SkPort", {prism_rtl::to_pod(std::get<SkPort>(cases()).a0)})
        : std::holds_alternative<SkMachine>(cases()) ? Pod::choice("SkMachine", {prism_rtl::to_pod(std::get<SkMachine>(cases()).a0), prism_rtl::to_pod(std::get<SkMachine>(cases()).a1), prism_rtl::to_pod(std::get<SkMachine>(cases()).a2)})
        : Pod();
}

Result<Sk> Sk::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "SkNode" && c->args.size() == 1) return Sk(SkNode{TRY(prism_rtl::from_pod<Nat>(c->args[0]))});
        if (c->ctor == "SkIn" && c->args.size() == 2) return Sk(SkIn{TRY(prism_rtl::from_pod<Nat>(c->args[0])), TRY(prism_rtl::from_pod<Nat>(c->args[1]))});
        if (c->ctor == "SkHold" && c->args.size() == 1) return Sk(SkHold{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "SkRequest" && c->args.size() == 2) return Sk(SkRequest{TRY(prism_rtl::from_pod<crate::lower::model::Pos_>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1]))});
        if (c->ctor == "SkResult" && c->args.size() == 0) return Sk(SkResult{});
        if (c->ctor == "SkArm" && c->args.size() == 1) return Sk(SkArm{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "SkCycle" && c->args.size() == 3) return Sk(SkCycle{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1])), TRY(prism_rtl::from_pod<Nat>(c->args[2]))});
        if (c->ctor == "SkUp" && c->args.size() == 1) return Sk(SkUp{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "SkPort" && c->args.size() == 1) return Sk(SkPort{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "SkMachine" && c->args.size() == 3) return Sk(SkMachine{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1])), TRY(prism_rtl::from_pod<Nat>(c->args[2]))});
    }
    return mismatch<Sk>("a Sk", p);
}


Pod SnapDef::to_pod() const {
    return Pod::record("SnapDef", {{"name", prism_rtl::to_pod(name)}, {"live", prism_rtl::to_pod(live)}, {"ty", prism_rtl::to_pod(ty)}, {"eq", prism_rtl::to_pod(eq)}, {"builder", prism_rtl::to_pod(builder)}, {"before", prism_rtl::to_pod(before)}, {"what", prism_rtl::to_pod(what)}});
}

Result<SnapDef> SnapDef::from_pod(const Pod& whole) {
    return SnapDef{.name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .live = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "live")))), .ty = TRY(prism_rtl::from_pod<crate::lower::model::OutTy>(TRY(crate::prelude::field(whole, "ty")))), .eq = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "eq")))), .builder = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "builder")))), .before = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "before")))), .what = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "what"))))};
}






/// IdPipe: unbounded fn Ex, (unbounded fn Ex -> [Do]) -> [Do]
Array<crate::lower::model::Do> id_pipe(const crate::lower::model::Ex& x, const prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>& k_fn) {
    return run_to_end(k_fn(x));
}


prism_rtl::Turn<Array<crate::lower::model::Do>> IdPipe::cycle() const {
    const auto& x = this->x;
    const auto& k_fn = this->k_fn;
    return k_fn(x)->cycle();
}


/// `Start IdPipe, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::Do>> start_id_pipe(crate::lower::model::Ex x, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)> k_fn) {
    return prism_rtl::make_rc<IdPipe>(x, k_fn);
}


/// EvRefOf: fn Wx, Nat -> EvRef
EvRef ev_ref_of(const Wx& wx, const Nat& n) {
    return EvRef{.node_ = n, .owner = wx.node_, .pipe = static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>)>>(prism_rtl::rc([&](std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>> _p0) {
        auto&& a0 = std::get<0>(_p0);
        auto&& a1 = std::get<1>(_p0);
        return entered(start_id_pipe(a0, a1));
    }))};
}


/// KindWord: fn GnKind -> Text
Text kind_word(const GnKind& k) {
    if (prism_rtl::is<GnKind::GnNamed>(k)) {
        return Text::lit("named");
    }
    if (prism_rtl::is<GnKind::GnAnswer>(k)) {
        return Text::lit("answer");
    }
    if (prism_rtl::is<GnKind::GnStarted>(k)) {
        return Text::lit("started");
    }
    if (prism_rtl::is<GnKind::GnDeferred>(k)) {
        return Text::lit("deferred");
    }
    if (prism_rtl::is<GnKind::GnPort>(k)) {
        return Text::lit("port");
    }
    if (prism_rtl::is<GnKind::GnMerge>(k)) {
        return Text::lit("merge");
    }
    if (prism_rtl::is<GnKind::GnUnion>(k)) {
        return Text::lit("union");
    }
    if (prism_rtl::is<GnKind::GnBoth>(k)) {
        return Text::lit("both");
    }
    if (prism_rtl::is<GnKind::GnExcept>(k)) {
        return Text::lit("except");
    }
    if (prism_rtl::is<GnKind::GnMergeAll>(k)) {
        return Text::lit("mergeall");
    }
    if (prism_rtl::is<GnKind::GnGather>(k)) {
        return Text::lit("gather");
    }
    if (prism_rtl::is<GnKind::GnUpdated>(k)) {
        return Text::lit("updated");
    }
    if (prism_rtl::is<GnKind::GnNever>(k)) {
        return Text::lit("never");
    }
    prism_rtl::unreachable("no arm matched");
}


/// HasRead: fn [Read], Read -> Bool
bool has_read(const Array<Read>& rs, const Read& r) {
    return fold(rs, false, [&](const bool& seen, const Read& x) { return seen || (x == r); });
}


/// AddRead: fn [Read], Read -> [Read]
Array<Read> add_read(const Array<Read>& rs, const Read& r) {
    return has_read(rs, r) ? rs : crate::prelude::push(rs, r);
}


/// UnionReads: fn [Read], [Read] -> [Read]
Array<Read> union_reads(const Array<Read>& xs, const Array<Read>& ys) {
    return fold(ys, xs, [&](const Array<Read>& acc, const Read& y) { return add_read(acc, y); });
}


/// let nodeHooks
Array<Text> node_hooks() {
    return Array(std::vector{Text::lit("path"), Text::lit("build"), Text::lit("wake"), Text::lit("started"), Text::lit("deferred"), Text::lit("answer"), Text::lit("push"), Text::lit("swap"), Text::lit("leave"), Text::lit("patch"), Text::lit("clean_up"), Text::lit("edges"), Text::lit("release"), Text::lit("leave_row"), Text::lit("remove_places")});
}


/// NewWx: fn Lx, Text, [((Text, OutTy, Text))], [((Text, Ex))], [((Text, Ex))], [MethDef], (Text ==> [Read]), [Text], Nat, ?Text -> Wx
Wx new_wx(const crate::lower::Lx& lx, const Text& name, const Array<std::tuple<Text, crate::lower::model::OutTy, Text>>& fields, const Array<std::tuple<Text, crate::lower::model::Ex>>& inits, const Array<std::tuple<Text, crate::lower::model::Ex>>& moves_, const Array<crate::lower::model::MethDef>& getters, const Map<Text, Array<Read>>& dyn_reads, const Array<Text>& taken, const Nat& depth, const std::optional<Text>& hosted_by_opt) {
    auto hosted_fields = ({
        __label__ _done;
        prism_rtl::Slot<Array<std::tuple<Text, crate::lower::model::OutTy, Text>>> _v;
        if (prism_rtl::is_some(hosted_by_opt)) {
            _v.set(Array(std::vector{std::tuple{Text::lit("enclosing"), crate::lower::host_of_ty(), Text::lit("the host whose document this row's places are entries of (pick HO)")}}));
            goto _done;
        }
        if (prism_rtl::is_none(hosted_by_opt)) {
            _v.set(Array<std::tuple<Text, crate::lower::model::OutTy, Text>>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto hosted_inits = ({
        __label__ _done;
        prism_rtl::Slot<Array<std::tuple<Text, crate::lower::model::Ex>>> _v;
        if (prism_rtl::is_some(hosted_by_opt)) {
            _v.set(Array(std::vector{std::tuple{Text::lit("enclosing"), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("enclosing")})}}));
            goto _done;
        }
        if (prism_rtl::is_none(hosted_by_opt)) {
            _v.set(Array<std::tuple<Text, crate::lower::model::Ex>>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return Wx{.lx = lx, .node_ = name, .pos = crate::lower::model::pos0(), .gns = Array<Gn>{}, .fields = append(fields, hosted_fields), .inits = inits, .moves = append(moves_, hosted_inits), .lets = Array<crate::lower::model::Do>{}, .build = Array<crate::lower::model::Do>{}, .places = Array<Place>{}, .answers = Array<std::tuple<crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text>>{}, .started = Array<Nat>{}, .defers = Array<std::tuple<Text, Nat>>{}, .getters = getters, .dyn_reads = dyn_reads, .taken = crate::prelude::push(taken, Text::lit("enclosing")), .fallible = false, .depth = depth, .result = Wres(Wres::WrUnit{}), .rows = Array<crate::lower::model::NodeDef>{}, .builders = Array<crate::lower::model::ForDef>{}, .build_holds = Array<Read>{}, .up_sink = Text::lit(""), .gens = Array<crate::lower::model::GenDef>{}, .gen_holds = Array<std::tuple<Text, Array<Read>>>{}, .ports = Array<Text>{}, .subs = Array<std::tuple<Text, Text, crate::lower::model::OutTy>>{}, .parent_env = crate::lower::empty_env(), .hosts = Array<HostDef>{}, .dyn_places = Array<std::tuple<crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text>>{}, .scopes = Array<Text>{}, .hosted_by = hosted_by_opt, .root_dyn = std::optional<std::tuple<crate::lower::model::Ex, Array<Read>, crate::lower::model::OutTy>>{}, .row_marks = Array<RowMarks>{}, .pending = Array<PendingRow>{}, .floors = Map<Text, Nat>{}, .snaps = Array<SnapDef>{}, .result_moved = std::optional<std::tuple<Text, Array<Read>>>{}, .dyn_answers = Array<std::tuple<Text, Array<Read>>>{}, .inited = Array<Text>{}, .flattens = Array<FlatDef>{}};
}


/// FreshName: fn Wx, Text -> ((Text, Wx))
std::tuple<Text, Wx> fresh_name(const Wx& wx, const Text& base) {
    auto pick = !crate::check::types::has_text(wx.taken, base)
        ? base
        : prism_rtl::cat(base, "_", first_free(wx.taken, base, Nat(2u)));
    auto wx2 = ({
        Wx this_ = wx;
        this_.taken = crate::prelude::push(this_.taken, pick);
        this_;
    });
    return std::tuple{pick, wx2};
}


/// FirstFree: fn [Text], Text, Nat -> Nat
Nat first_free(const Array<Text>& taken, const Text& base, const Nat& from) {
    return fold(crate::check::errors::range0(len(taken)), from, [&](const Nat& n, const Nat& _p1) {
        return crate::check::types::has_text(taken, prism_rtl::cat(base, "_", n))
            ? n + Nat(1u)
            : n;
    });
}


/// AddGn: fn Wx, Text, OutTy, GnKind, Nat -> ((Nat, Wx))
std::tuple<Nat, Wx> add_gn(const Wx& wx, const Text& name, const crate::lower::model::OutTy& ty, const GnKind& kind, const Nat& height) {
    auto id = len(wx.gns);
    auto wx2 = ({
        Wx this_ = wx;
        this_.gns = crate::prelude::push(this_.gns, Gn{.id = id, .name = name, .ty = ty, .kind = kind, .height = height, .inputs = Array<Text>{}, .reads = Array<Read>{}, .floor = Nat(0u), .outs = Array<Out>{}});
        this_;
    });
    return std::tuple{id, wx2};
}


/// Connect: fn Wx, EvRef, Sk -> Wx
Wx connect(const Wx& wx, const EvRef& r, const Sk& sink) {
    return r.owner != wx.node_
        ? crossed(wx, prism_rtl::cat("an event of node `", r.owner, "` (its graph node ", r.node_, ")"))
        : ({
        Wx this_ = wx;
        this_.gns = each(this_.gns, [&](const Gn& n) { return n.id == r.node_ ? add_out(n, Out{.pipe = r.pipe, .sink = sink}) : n; });
        this_;
    });
}


/// Crossed: fn Wx, Text -> Wx
Wx crossed(const Wx& wx, const Text& what) {
    Wx this_ = wx;
    this_.build = crate::prelude::push(this_.build, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::refusal(prism_rtl::cat(what, " read in node `", wx.node_, "` without a port (a lowering bug)"))}));
    return this_;
}


/// AddOut: fn Gn, Out -> Gn
Gn add_out(const Gn& n, const Out& o) {
    Gn this_ = n;
    this_.outs = crate::prelude::push(this_.outs, o);
    return this_;
}


/// AddField: fn Wx, Text, OutTy, Text, Ex -> Wx
Wx add_field(const Wx& wx, const Text& name, const crate::lower::model::OutTy& t, const Text& doc, const crate::lower::model::Ex& init) {
    Wx this_ = wx;
    this_.fields = crate::prelude::push(this_.fields, std::tuple{name, t, doc});
    this_.inits = crate::prelude::push(this_.inits, std::tuple{name, init});
    return this_;
}


/// AddFieldLast: fn Wx, Text, OutTy, Text, Ex -> Wx
Wx add_field_last(const Wx& wx, const Text& name, const crate::lower::model::OutTy& t, const Text& doc, const crate::lower::model::Ex& init) {
    Wx this_ = wx;
    this_.fields = crate::prelude::push(this_.fields, std::tuple{name, t, doc});
    this_.moves = crate::prelude::push(this_.moves, std::tuple{name, init});
    return this_;
}


/// GnOf: fn Wx, Nat -> Gn
Gn gn_of(const Wx& wx, const Nat& n) {
    return or_(index(wx.gns, n), Gn{.id = n, .name = Text::lit("never"), .ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .kind = GnKind(GnKind::GnNever{}), .height = Nat(0u), .inputs = Array<Text>{}, .reads = Array<Read>{}, .floor = Nat(0u), .outs = Array<Out>{}});
}


/// BindPlain: fn Env, Env, Text, Text, OutTy -> ((Env, Env))
std::tuple<crate::lower::Env, crate::lower::Env> bind_plain(const crate::lower::Env& benv, const crate::lower::Env& menv, const Text& nkey, const Text& rs, const crate::lower::model::OutTy& t) {
    return std::tuple{crate::lower::bind(benv, nkey, crate::lower::Bn(crate::lower::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs}), crate::lower::Holding(crate::lower::Holding::Owned{}), t})), crate::lower::bind(menv, nkey, crate::lower::Bn(crate::lower::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), rs}), crate::lower::Holding(crate::lower::Holding::Owned{}), t}))};
}


/// NodeDefOf: unbounded fn Lx, Text, [Pattern], Block, Scheme, Bool -> NodeDef
crate::lower::model::NodeDef node_def_of(const crate::lower::Lx& lx, const Text& qk, const Array<crate::syntax::Pattern_>& params, const crate::syntax::Block& body, const crate::check::types::Scheme& sc, const bool& is_root) {
    auto name = crate::lower::camel(crate::check::types::bare_name(qk));
    auto ptys = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
        auto&& _m = sc.ty;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            _v.set(ps);
            goto _done;
        }
        {
            _v.set(Array<crate::check::types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto wx0 = new_wx(lx, name, Array<std::tuple<Text, crate::lower::model::OutTy, Text>>{}, Array<std::tuple<Text, crate::lower::model::Ex>>{}, Array<std::tuple<Text, crate::lower::model::Ex>>{}, Array<crate::lower::model::MethDef>{}, Map<Text, Array<Read>>{}, node_hooks(), Nat(0u), std::optional<Text>{});
    auto [ps, wx1, benv, menv] = run_to_end(fold_job(crate::check::errors::range0(len(params)), std::tuple{Array<std::tuple<Text, crate::lower::model::OutTy>>{}, wx0, crate::lower::empty_env(), crate::lower::empty_env()}, ({
        auto params_1 = params;
        auto lx_2 = lx;
        auto ptys_3 = ptys;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::lower::model::OutTy>>, Wx, crate::lower::Env, crate::lower::Env>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::lower::model::OutTy>>, Wx, crate::lower::Env, crate::lower::Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<Text, crate::lower::model::OutTy>>, Wx, crate::lower::Env, crate::lower::Env>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto params_1_4 = params_1;
            auto lx_2_4 = lx_2;
            auto ptys_3_4 = ptys_3;
            entered(once_job([=]() {
            return ({
                auto [acc, w, be, me] = p0;
                auto i = p1;
                ({
                auto p_ = or_(index(params_1_4, i), crate::lower::dummy_pat());
                auto nkey = crate::lower::plain_binder(lx_2_4, p_);
                auto base = nkey == Text::lit("")
                    ? prism_rtl::cat("arg", i)
                    : crate::lower::snake(nkey);
                auto [rs, w2] = fresh_name(w, base);
                call_then(crate::lower::start_out_ty_of(lx_2_4, crate::lower::peel(or_(index(ptys_3_4, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})))), [=](crate::lower::model::OutTy out_ty_of_16357) {
                return ({
                    auto t = out_ty_of_16357;
                    auto w3 = ({
                        Wx this_ = w2;
                        this_.fields = crate::prelude::push(this_.fields, std::tuple{rs, t, Text::lit("a parameter")});
                        this_.inits = crate::prelude::push(this_.inits, std::tuple{rs, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs}))})});
                        this_;
                    });
                    auto [be2, me2] = bind_plain(be, me, nkey, rs, t);
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc, std::tuple{rs, t}), w3, be2, me2}));
                });
            });
            });
            });
        }));
        });
    }));
    })));
    auto wx2 = block_into(wx1, benv, menv, body);
    auto wx3 = is_root ? root_result(wx2) : wx2;
    return finish_node(wx3, qk, ps, false);
}


prism_rtl::Turn<crate::lower::model::NodeDef> NodeDefOf::cycle() const {
    const auto& lx = this->lx;
    const auto& qk = this->qk;
    const auto& params = this->params;
    const auto& body = this->body;
    const auto& sc = this->sc;
    const auto& is_root = this->is_root;
    auto name = crate::lower::camel(crate::check::types::bare_name(qk));
    auto ptys = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
        auto&& _m = sc.ty;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            _v.set(ps);
            goto _done;
        }
        {
            _v.set(Array<crate::check::types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto wx0 = new_wx(lx, name, Array<std::tuple<Text, crate::lower::model::OutTy, Text>>{}, Array<std::tuple<Text, crate::lower::model::Ex>>{}, Array<std::tuple<Text, crate::lower::model::Ex>>{}, Array<crate::lower::model::MethDef>{}, Map<Text, Array<Read>>{}, node_hooks(), Nat(0u), std::optional<Text>{});
    auto body_1 = body;
    auto is_root_2 = is_root;
    auto lx_3 = lx;
    auto params_4 = params;
    auto qk_5 = qk;
    return call_value(fold_job(crate::check::errors::range0(len(params_4)), std::tuple{Array<std::tuple<Text, crate::lower::model::OutTy>>{}, wx0, crate::lower::empty_env(), crate::lower::empty_env()}, ({
        auto params_4_6 = params_4;
        auto lx_3_6 = lx_3;
        auto ptys_6 = ptys;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::lower::model::OutTy>>, Wx, crate::lower::Env, crate::lower::Env>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::lower::model::OutTy>>, Wx, crate::lower::Env, crate::lower::Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<Text, crate::lower::model::OutTy>>, Wx, crate::lower::Env, crate::lower::Env>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto params_4_6_7 = params_4_6;
            auto lx_3_6_7 = lx_3_6;
            auto ptys_6_7 = ptys_6;
            entered(once_job([=]() {
            return ({
                auto [acc, w, be, me] = p0;
                auto i = p1;
                ({
                auto p_ = or_(index(params_4_6_7, i), crate::lower::dummy_pat());
                auto nkey = crate::lower::plain_binder(lx_3_6_7, p_);
                auto base = nkey == Text::lit("")
                    ? prism_rtl::cat("arg", i)
                    : crate::lower::snake(nkey);
                auto [rs, w2] = fresh_name(w, base);
                call_then(crate::lower::start_out_ty_of(lx_3_6_7, crate::lower::peel(or_(index(ptys_6_7, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})))), [=](crate::lower::model::OutTy out_ty_of_16357) {
                return ({
                    auto t = out_ty_of_16357;
                    auto w3 = ({
                        Wx this_ = w2;
                        this_.fields = crate::prelude::push(this_.fields, std::tuple{rs, t, Text::lit("a parameter")});
                        this_.inits = crate::prelude::push(this_.inits, std::tuple{rs, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs}))})});
                        this_;
                    });
                    auto [be2, me2] = bind_plain(be, me, nkey, rs, t);
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc, std::tuple{rs, t}), w3, be2, me2}));
                });
            });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<std::tuple<Text, crate::lower::model::OutTy>>, Wx, crate::lower::Env, crate::lower::Env> fold_16074) {
        return ({
            auto [ps, wx1, benv, menv] = fold_16074;
            call_then(start_block_into(wx1, benv, menv, body_1), [=](Wx block_into_16675) {
            return ({
                auto wx2 = block_into_16675;
                auto wx3 = is_root_2 ? root_result(wx2) : wx2;
                (prism_rtl::more(prism_rtl::rc(FinishNode(wx3, qk_5, ps, false))));
            });
        });
        });
    });
}


/// `Start NodeDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::NodeDef> start_node_def_of(crate::lower::Lx lx, Text qk, Array<crate::syntax::Pattern_> params, crate::syntax::Block body, crate::check::types::Scheme sc, bool is_root) {
    return prism_rtl::make_rc<NodeDefOf>(lx, qk, params, body, sc, is_root);
}


/// RootResult: fn Wx -> Wx
Wx root_result(const Wx& wx) {
    auto&& _m = wx->result;
    if (prism_rtl::is<Wres::WrEv>(_m)) {
        auto&& r = prism_rtl::as<Wres::WrEv>(_m).a0;
        return connect(wx, r, Sk(Sk::SkResult{}));
    }
    if (prism_rtl::is<Wres::WrDyn>(_m)) {
        auto&& x = prism_rtl::as<Wres::WrDyn>(_m).a0;
        auto&& rds = prism_rtl::as<Wres::WrDyn>(_m).a1;
        auto&& t = prism_rtl::as<Wres::WrDyn>(_m).a2;
        Wx this_ = wx;
        this_.root_dyn = std::optional(std::tuple{x, rds, t});
        this_.getters = crate::prelude::push(this_.getters, crate::lower::model::MethDef{.name = Text::lit("result_value"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutPod{}), .body = Array<crate::lower::model::Do>{}, .tail = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(x), Text::lit("to_pod"), Array<crate::lower::model::Ex>{}}), .doc = Text::lit("The root's dynamic result, pulled after the tick.")});
        this_.fields = crate::prelude::push(this_.fields, std::tuple{Text::lit("result_last"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutCell{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutPod{}))}))}), Text::lit("the result the World last heard")});
        this_.moves = crate::prelude::push(this_.moves, std::tuple{Text::lit("result_last"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("RefCell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XNone{})})})});
        this_.build = crate::prelude::push(this_.build, crate::lower::model::Do(crate::lower::model::Do::DoScope{result_told(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")}))}));
        return this_;
    }
    if (prism_rtl::is<Wres::WrPlain>(_m)) {
        auto&& x = prism_rtl::as<Wres::WrPlain>(_m).a0;
        Wx this_ = wx;
        this_.build = crate::prelude::push(this_.build, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("result"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Outcome::Value"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(x), Text::lit("to_pod"), Array<crate::lower::model::Ex>{}})})})})})}));
        return this_;
    }
    {
        return wx;
    }
}


/// BlockInto: unbounded fn Wx, Env, Env, Block -> Wx
Wx block_into(const Wx& wx, const crate::lower::Env& benv, const crate::lower::Env& menv, const crate::syntax::Block& b) {
    auto [wx1, be1, me1] = run_to_end(fold_job(b.stmts, std::tuple{wx, benv, menv}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Wx, crate::lower::Env, crate::lower::Env>>(std::tuple<std::tuple<Wx, crate::lower::Env, crate::lower::Env>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Wx, crate::lower::Env, crate::lower::Env>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [w, be, me] = p0;
                auto s = p1;
                (prism_rtl::more(prism_rtl::rc(PreBind(w, be, me, s))));
            });
        }));
    }))));
    auto n = len(b.stmts);
    auto&& _wx2 = run_to_end(fold_job(crate::check::errors::range0(n), std::tuple{wx1, be1, me1}, ({
        auto b_1 = b;
        auto n_2 = n;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Wx, crate::lower::Env, crate::lower::Env>>(std::tuple<std::tuple<Wx, crate::lower::Env, crate::lower::Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Wx, crate::lower::Env, crate::lower::Env>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto b_1_3 = b_1;
            auto n_2_3 = n_2;
            entered(once_job([=]() {
            return ({
                auto [w, be, me] = p0;
                auto i = p1;
                (prism_rtl::more(prism_rtl::rc(WidgetStmt(w, be, me, or_(index(b_1_3.stmts, i), crate::lower::dummy_stmt_l()), (i + Nat(1u)) == n_2_3))));
            });
        }));
        });
    }));
    })));
    auto&& wx2 = std::get<0>(_wx2);
    return wx2;
}


prism_rtl::Turn<Wx> BlockInto::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& b = this->b;
    auto b_1 = b;
    auto benv_2 = benv;
    auto menv_3 = menv;
    auto wx_4 = wx;
    return call_value(fold_job(b_1.stmts, std::tuple{wx_4, benv_2, menv_3}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Wx, crate::lower::Env, crate::lower::Env>>(std::tuple<std::tuple<Wx, crate::lower::Env, crate::lower::Env>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Wx, crate::lower::Env, crate::lower::Env>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [w, be, me] = p0;
                auto s = p1;
                (prism_rtl::more(prism_rtl::rc(PreBind(w, be, me, s))));
            });
        }));
    }))), [=](std::tuple<Wx, crate::lower::Env, crate::lower::Env> fold_17998) {
        return ({
            auto [wx1, be1, me1] = fold_17998;
            auto n = len(b_1.stmts);
            call_value(fold_job(crate::check::errors::range0(n), std::tuple{wx1, be1, me1}, ({
            auto b_1_5 = b_1;
            auto n_5 = n;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Wx, crate::lower::Env, crate::lower::Env>>(std::tuple<std::tuple<Wx, crate::lower::Env, crate::lower::Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Wx, crate::lower::Env, crate::lower::Env>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto b_1_5_6 = b_1_5;
                auto n_5_6 = n_5;
                entered(once_job([=]() {
                return ({
                    auto [w, be, me] = p0;
                    auto i = p1;
                    (prism_rtl::more(prism_rtl::rc(WidgetStmt(w, be, me, or_(index(b_1_5_6.stmts, i), crate::lower::dummy_stmt_l()), (i + Nat(1u)) == n_5_6))));
                });
            }));
            });
        }));
        })), [=](std::tuple<Wx, crate::lower::Env, crate::lower::Env> fold_18131) {
            return ({
                auto&& _wx2 = fold_18131;
                auto&& wx2 = std::get<0>(_wx2);
                (prism_rtl::finished(wx2));
            });
        });
        });
    });
}


/// `Start BlockInto, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Wx> start_block_into(Wx wx, crate::lower::Env benv, crate::lower::Env menv, crate::syntax::Block b) {
    return prism_rtl::make_rc<BlockInto>(wx, benv, menv, b);
}


/// PreBind: unbounded fn Wx, Env, Env, Stmt -> ((Wx, Env, Env))
std::tuple<Wx, crate::lower::Env, crate::lower::Env> pre_bind(const Wx& wx, const crate::lower::Env& benv, const crate::lower::Env& menv, const crate::syntax::Stmt& s) {
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& init = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        auto&& step_opt = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2;
        auto&& _m = p_.kind;
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            return pre_bind_name(wx, benv, menv, n, how_bound(step_opt));
        }
        if (prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m)) {
            auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
            return run_to_end(fold_job(ps, std::tuple{wx, benv, menv}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Wx, crate::lower::Env, crate::lower::Env>>(std::tuple<std::tuple<Wx, crate::lower::Env, crate::lower::Env>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Wx, crate::lower::Env, crate::lower::Env>, crate::syntax::Pattern_> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto [w, be, me] = p0;
                        auto q = p1;
                        ({
                        auto&& _m = q.kind;
                        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
                        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                        prism_rtl::more(prism_rtl::rc(PreBindName(w, be, me, n, HowBound(HowBound::AsBind{}))));
                    })
                        : prism_rtl::finished(std::tuple{w, be, me});
                    });
                    });
                }));
            }))));
        }
        {
            return std::tuple{wx, benv, menv};
        }
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& _m = p_.kind;
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            return pre_bind_name(wx, benv, menv, n, HowBound(HowBound::AsLet{}));
        }
        {
            return std::tuple{wx, benv, menv};
        }
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        auto fname = crate::check::env::def_name_text(c.name);
        return std::tuple{wx, crate::lower::bind(benv, fname, crate::lower::Bn(crate::lower::Bn::BnLocalFn{c})), crate::lower::bind(menv, fname, crate::lower::Bn(crate::lower::Bn::BnLocalFn{c}))};
    }
    {
        return std::tuple{wx, benv, menv};
    }
}


prism_rtl::Turn<std::tuple<Wx, crate::lower::Env, crate::lower::Env>> PreBind::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& s = this->s;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& init = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        auto&& step_opt = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2;
        ({
        auto&& _m = p_.kind;
        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        prism_rtl::more(prism_rtl::rc(PreBindName(wx, benv, menv, n, how_bound(step_opt))));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m) ? ({
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        fold_job(ps, std::tuple{wx, benv, menv}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Wx, crate::lower::Env, crate::lower::Env>>(std::tuple<std::tuple<Wx, crate::lower::Env, crate::lower::Env>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Wx, crate::lower::Env, crate::lower::Env>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [w, be, me] = p0;
                auto q = p1;
                ({
                auto&& _m = q.kind;
                prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
                auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                prism_rtl::more(prism_rtl::rc(PreBindName(w, be, me, n, HowBound(HowBound::AsBind{}))));
            })
                : prism_rtl::finished(std::tuple{w, be, me});
            });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::finished(std::tuple{wx, benv, menv});
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        ({
        auto&& _m = p_.kind;
        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        prism_rtl::more(prism_rtl::rc(PreBindName(wx, benv, menv, n, HowBound(HowBound::AsLet{}))));
    })
        : prism_rtl::finished(std::tuple{wx, benv, menv});
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        ({
        auto fname = crate::check::env::def_name_text(c.name);
        (prism_rtl::finished(std::tuple{wx, crate::lower::bind(benv, fname, crate::lower::Bn(crate::lower::Bn::BnLocalFn{c})), crate::lower::bind(menv, fname, crate::lower::Bn(crate::lower::Bn::BnLocalFn{c}))}));
    });
    })
        : prism_rtl::finished(std::tuple{wx, benv, menv});
    });
}


/// `Start PreBind, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Wx, crate::lower::Env, crate::lower::Env>> start_pre_bind(Wx wx, crate::lower::Env benv, crate::lower::Env menv, crate::syntax::Stmt s) {
    return prism_rtl::make_rc<PreBind>(wx, benv, menv, s);
}


/// HowBound: fn ?Expr -> HowBound
HowBound how_bound(const std::optional<crate::syntax::Expr>& opt0) {
    if (prism_rtl::is_some(opt0)) {
        return HowBound(HowBound::AsHold{});
    }
    if (prism_rtl::is_none(opt0)) {
        return HowBound(HowBound::AsBind{});
    }
    prism_rtl::unreachable("no arm matched");
}


/// PreBindName: unbounded fn Wx, Env, Env, SName, HowBound -> ((Wx, Env, Env))
std::tuple<Wx, crate::lower::Env, crate::lower::Env> pre_bind_name(const Wx& wx, const crate::lower::Env& benv, const crate::lower::Env& menv, const crate::syntax::SName& n, const HowBound& how) {
    auto lx = crate::lower::widget_let_lx(wx.lx, n.span);
    auto nkey = crate::check::env::sname_key(n);
    auto full = crate::lower::binder_ty(lx, n.span);
    auto layer = crate::lower::layer_of(full);
    auto t = crate::lower::out_ty_of(lx, crate::lower::peel(full));
    auto [rs, wx1] = fresh_name(wx, crate::lower::snake(nkey));
    return (layer == crate::lower::Layer(crate::lower::Layer::LyEv{})) || is_switched(full)
        ? ({
        auto et = crate::lower::out_ty_of(lx, crate::lower::peel(crate::lower::peel(full)));
        auto [id, wx2] = add_gn(wx1, rs, et, GnKind(GnKind::GnNamed{}), Nat(0u));
        auto b = crate::lower::Bn(crate::lower::Bn::BnEv{ev_ref_of(wx2, id), t});
        auto pf = prism_rtl::cat(rs, "_v_port");
        auto pt = crate::lower::model::OutTy(crate::lower::model::OutTy::OutRc{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutPort{prism_rtl::rc(et)}))});
        auto wx3 = ({
            Wx this_ = connect(wx2, ev_ref_of(wx2, id), Sk(Sk::SkPort{prism_rtl::cat(rs, "_v")}));
            this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{pf})), pt}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Port::new"), Array<crate::lower::model::Ex>{}})})})}));
            this_.fields = crate::prelude::push(this_.fields, std::tuple{pf, pt, prism_rtl::cat("`", nkey, "` as a value: the port it fires")});
            this_.moves = crate::prelude::push(this_.moves, std::tuple{pf, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{pf}))})});
            this_;
        });
        auto be = crate::lower::bind(crate::lower::bind(benv, nkey, b), prism_rtl::cat(nkey, "#port"), crate::lower::Bn(crate::lower::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{pf}), crate::lower::Holding(crate::lower::Holding::Owned{}), pt}));
        auto me = crate::lower::bind(crate::lower::bind(menv, nkey, b), prism_rtl::cat(nkey, "#port"), crate::lower::Bn(crate::lower::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), pf}), crate::lower::Holding(crate::lower::Holding::Owned{}), pt}));
        std::tuple{wx3, be, me};
    })
        : ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Wx, crate::lower::Env, crate::lower::Env>> _v;
        auto&& _m = std::tuple{layer, how};
        if (prism_rtl::is<crate::lower::Layer::LyDyn>(std::get<0>(_m)) && prism_rtl::is<HowBound::AsLet>(std::get<1>(_m))) {
            _v.set(({
                auto b = crate::lower::Bn(crate::lower::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), rs, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{Read(Read::OwnRead{rs})}), t});
                std::tuple{wx1, crate::lower::bind(benv, nkey, b), crate::lower::bind(menv, nkey, b)};
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::Layer::LyDyn>(std::get<0>(_m))) {
            _v.set(({
                auto b = crate::lower::Bn(crate::lower::Bn::BnHold{rs, t});
                std::tuple{wx1, crate::lower::bind(benv, nkey, b), crate::lower::bind(menv, nkey, b)};
            }));
            goto _done;
        }
        {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Wx, crate::lower::Env, crate::lower::Env>> _v;
                auto&& _m = many_instances(wx.lx, n.span);
                if (prism_rtl::is_some(_m)) {
                    auto&& insts = prism_rtl::some_of(_m);
                    _v.set(run_to_end(fold_job(crate::check::errors::range0(len(insts)), std::tuple{wx1, benv, menv}, ({
                        auto insts_1 = insts;
                        auto wx_2 = wx;
                        auto n_3 = n;
                        auto rs_4 = rs;
                        auto nkey_5 = nkey;
                        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Wx, crate::lower::Env, crate::lower::Env>>(std::tuple<std::tuple<Wx, crate::lower::Env, crate::lower::Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Wx, crate::lower::Env, crate::lower::Env>, Nat> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto insts_1_6 = insts_1;
                            auto wx_2_6 = wx_2;
                            auto n_3_6 = n_3;
                            auto rs_4_6 = rs_4;
                            auto nkey_5_6 = nkey_5;
                            entered(once_job([=]() {
                            return ({
                                auto [w, be, me] = p0;
                                auto k = p1;
                                ({
                                auto inst = or_(index(insts_1_6, k), std::tuple{Array<std::tuple<Text, crate::check::types::Ty>>{}, Array<std::tuple<Text, crate::check::types::Col>>{}});
                                auto lxk = crate::lower::at_instance(wx_2_6.lx, inst);
                                call_then(crate::lower::start_out_ty_of(lxk, crate::lower::peel(crate::lower::binder_ty(lxk, n_3_6.span))), [=](crate::lower::model::OutTy out_ty_of_21493) {
                                return ({
                                    auto tk = out_ty_of_21493;
                                    auto [rk, w2] = k == Nat(0u)
                                        ? std::tuple{rs_4_6, w}
                                        : fresh_name(w, prism_rtl::cat(rs_4_6, "_", k));
                                    auto bkey = k == Nat(0u) ? nkey_5_6 : prism_rtl::cat(nkey_5_6, "#inst", k);
                                    auto [be2, me2] = bind_plain(be, me, bkey, rk, tk);
                                    auto ukey = prism_rtl::cat(nkey_5_6, "#", show_text(inst));
                                    (prism_rtl::finished(std::tuple{w2, with_use(be2, ukey, bkey), with_use(me2, ukey, bkey)}));
                                });
                            });
                            });
                            });
                        }));
                        });
                    }));
                    }))));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(({
                        auto [be, me] = bind_plain(benv, menv, nkey, rs, t);
                        std::tuple{wx1, be, me};
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<Wx, crate::lower::Env, crate::lower::Env>> PreBindName::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& n = this->n;
    const auto& how = this->how;
    auto benv_1 = benv;
    auto how_2 = how;
    auto menv_3 = menv;
    auto n_4 = n;
    auto wx_5 = wx;
    return call_then(crate::lower::start_widget_let_lx(wx_5.lx, n_4.span), [=](crate::lower::Lx widget_let_lx_19478) {
        return ({
            auto lx = widget_let_lx_19478;
            auto nkey = crate::check::env::sname_key(n_4);
            auto full = crate::lower::binder_ty(lx, n_4.span);
            auto layer = crate::lower::layer_of(full);
            call_then(crate::lower::start_out_ty_of(lx, crate::lower::peel(full)), [=](crate::lower::model::OutTy out_ty_of_19606) {
            return ({
                auto t = out_ty_of_19606;
                auto [rs, wx1] = fresh_name(wx_5, crate::lower::snake(nkey));
                (layer == crate::lower::Layer(crate::lower::Layer::LyEv{})) || is_switched(full)
                ? call_then(crate::lower::start_out_ty_of(lx, crate::lower::peel(crate::lower::peel(full))), [=](crate::lower::model::OutTy out_ty_of_19737) {
                return ({
                    auto et = out_ty_of_19737;
                    auto [id, wx2] = add_gn(wx1, rs, et, GnKind(GnKind::GnNamed{}), Nat(0u));
                    auto b = crate::lower::Bn(crate::lower::Bn::BnEv{ev_ref_of(wx2, id), t});
                    auto pf = prism_rtl::cat(rs, "_v_port");
                    auto pt = crate::lower::model::OutTy(crate::lower::model::OutTy::OutRc{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutPort{prism_rtl::rc(et)}))});
                    auto wx3 = ({
                        Wx this_ = connect(wx2, ev_ref_of(wx2, id), Sk(Sk::SkPort{prism_rtl::cat(rs, "_v")}));
                        this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{pf})), pt}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Port::new"), Array<crate::lower::model::Ex>{}})})})}));
                        this_.fields = crate::prelude::push(this_.fields, std::tuple{pf, pt, prism_rtl::cat("`", nkey, "` as a value: the port it fires")});
                        this_.moves = crate::prelude::push(this_.moves, std::tuple{pf, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{pf}))})});
                        this_;
                    });
                    auto be = crate::lower::bind(crate::lower::bind(benv_1, nkey, b), prism_rtl::cat(nkey, "#port"), crate::lower::Bn(crate::lower::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{pf}), crate::lower::Holding(crate::lower::Holding::Owned{}), pt}));
                    auto me = crate::lower::bind(crate::lower::bind(menv_3, nkey, b), prism_rtl::cat(nkey, "#port"), crate::lower::Bn(crate::lower::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), pf}), crate::lower::Holding(crate::lower::Holding::Owned{}), pt}));
                    (prism_rtl::finished(std::tuple{wx3, be, me}));
                });
            })
                : ({
                auto&& _m = std::tuple{layer, how_2};
                prism_rtl::is<crate::lower::Layer::LyDyn>(std::get<0>(_m)) && prism_rtl::is<HowBound::AsLet>(std::get<1>(_m)) ? ({
                auto b = crate::lower::Bn(crate::lower::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), rs, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{Read(Read::OwnRead{rs})}), t});
                (prism_rtl::finished(std::tuple{wx1, crate::lower::bind(benv_1, nkey, b), crate::lower::bind(menv_3, nkey, b)}));
            })
                : prism_rtl::is<crate::lower::Layer::LyDyn>(std::get<0>(_m)) ? ({
                auto b = crate::lower::Bn(crate::lower::Bn::BnHold{rs, t});
                (prism_rtl::finished(std::tuple{wx1, crate::lower::bind(benv_1, nkey, b), crate::lower::bind(menv_3, nkey, b)}));
            })
                : call_then(start_many_instances(wx_5.lx, n_4.span), [=](std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> many_instances_21025) {
                return ({
                    prism_rtl::is_some(many_instances_21025) ? ({
                    auto&& insts = prism_rtl::some_of(many_instances_21025);
                    fold_job(crate::check::errors::range0(len(insts)), std::tuple{wx1, benv_1, menv_3}, ({
                    auto insts_6 = insts;
                    auto wx_5_7 = wx_5;
                    auto n_4_7 = n_4;
                    auto rs_7 = rs;
                    auto nkey_8 = nkey;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Wx, crate::lower::Env, crate::lower::Env>>(std::tuple<std::tuple<Wx, crate::lower::Env, crate::lower::Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Wx, crate::lower::Env, crate::lower::Env>, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto insts_6_9 = insts_6;
                        auto wx_5_7_9 = wx_5_7;
                        auto n_4_7_9 = n_4_7;
                        auto rs_7_9 = rs_7;
                        auto nkey_8_9 = nkey_8;
                        entered(once_job([=]() {
                        return ({
                            auto [w, be, me] = p0;
                            auto k = p1;
                            ({
                            auto inst = or_(index(insts_6_9, k), std::tuple{Array<std::tuple<Text, crate::check::types::Ty>>{}, Array<std::tuple<Text, crate::check::types::Col>>{}});
                            auto lxk = crate::lower::at_instance(wx_5_7_9.lx, inst);
                            call_then(crate::lower::start_out_ty_of(lxk, crate::lower::peel(crate::lower::binder_ty(lxk, n_4_7_9.span))), [=](crate::lower::model::OutTy out_ty_of_21493) {
                            return ({
                                auto tk = out_ty_of_21493;
                                auto [rk, w2] = k == Nat(0u)
                                    ? std::tuple{rs_7_9, w}
                                    : fresh_name(w, prism_rtl::cat(rs_7_9, "_", k));
                                auto bkey = k == Nat(0u) ? nkey_8_9 : prism_rtl::cat(nkey_8_9, "#inst", k);
                                auto [be2, me2] = bind_plain(be, me, bkey, rk, tk);
                                auto ukey = prism_rtl::cat(nkey_8_9, "#", show_text(inst));
                                (prism_rtl::finished(std::tuple{w2, with_use(be2, ukey, bkey), with_use(me2, ukey, bkey)}));
                            });
                        });
                        });
                        });
                    }));
                    });
                }));
                }))->cycle();
                })
                    : prism_rtl::is_none(many_instances_21025) ? ({
                    auto [be, me] = bind_plain(benv_1, menv_3, nkey, rs, t);
                    (prism_rtl::finished(std::tuple{wx1, be, me}));
                })
                    : throw prism_rtl::Panic("no arm matched");
                });
            });
            });
            });
        });
        });
    });
}


/// `Start PreBindName, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Wx, crate::lower::Env, crate::lower::Env>> start_pre_bind_name(Wx wx, crate::lower::Env benv, crate::lower::Env menv, crate::syntax::SName n, HowBound how) {
    return prism_rtl::make_rc<PreBindName>(wx, benv, menv, n, how);
}


/// WithUse: fn Env, Text, Text -> Env
crate::lower::Env with_use(const crate::lower::Env& env, const Text& ukey, const Text& bkey) {
    crate::lower::Env this_ = env;
    this_.uses = insert(this_.uses, ukey, bkey);
    return this_;
}


/// ?ManyInstances: unbounded fn Lx, Range -> ?[(([((Text, Ty))], [((Text, Col))]))]
std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> many_instances(const crate::lower::Lx& lx, const crate::syntax::Range& span) {
    auto&& _m = crate::prelude::get(lx.gens, crate::lower::place_key(lx, span));
    if (prism_rtl::is_some(_m)) {
        auto&& gn = prism_rtl::some_of(_m);
        auto insts = crate::lower::instantiations(lx, gn);
        return len(insts) > Nat(1u)
            ? std::optional(insts)
            : std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>{};
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>> ManyInstances::cycle() const {
    const auto& lx = this->lx;
    const auto& span = this->span;
    return ({
        auto&& _m = crate::prelude::get(lx.gens, crate::lower::place_key(lx, span));
        prism_rtl::is_some(_m) ? ({
        auto&& gn = prism_rtl::some_of(_m);
        ({
        auto lx_1 = lx;
        call_then(crate::lower::start_instantiations(lx_1, gn), [=](Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> instantiations_22370) {
        return ({
            auto insts = instantiations_22370;
            len(insts) > Nat(1u)
            ? prism_rtl::finished(std::optional(insts))
            : prism_rtl::finished(std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>{});
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ManyInstances, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>> start_many_instances(crate::lower::Lx lx, crate::syntax::Range span) {
    return prism_rtl::make_rc<ManyInstances>(lx, span);
}


/// IsSwitched: fn Ty -> Bool
bool is_switched(const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& m22687_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& m22687_0_1 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        if (m22687_0_0 == Text::lit("$")) {
            if (prism_rtl::is<crate::check::types::Ty::TySig>(m22687_0_1)) {
                auto&& m22687_0_1_r_0 = prism_rtl::as<crate::check::types::Ty::TySig>(m22687_0_1).a0;
                if (m22687_0_1_r_0 == Text::lit("!")) {
                    return true;
                }
            }
        }
    }
    {
        return false;
    }
}


/// ?BindingOf: fn Env, Pattern -> ?Bn
std::optional<crate::lower::Bn> binding_of(const crate::lower::Env& env, const crate::syntax::Pattern_& p_) {
    auto&& _m = p_.kind;
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        return crate::prelude::get(env->names, crate::check::env::sname_key(n));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m)) {
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        return std::optional(crate::lower::Bn(crate::lower::Bn::BnParts{each(ps, [&](const crate::syntax::Pattern_& q) { return binding_of_name(env, q); })}));
    }
    {
        return std::optional<crate::lower::Bn>{};
    }
}


/// ?BindingOfName: fn Env, Pattern -> ?Bn
std::optional<crate::lower::Bn> binding_of_name(const crate::lower::Env& env, const crate::syntax::Pattern_& p_) {
    auto&& _m = p_.kind;
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        return crate::prelude::get(env->names, crate::check::env::sname_key(n));
    }
    {
        return std::optional<crate::lower::Bn>{};
    }
}


/// WidgetStmt: unbounded fn Wx, Env, Env, Stmt, Bool -> ((Wx, Env, Env))
std::tuple<Wx, crate::lower::Env, crate::lower::Env> widget_stmt(const Wx& wx, const crate::lower::Env& benv, const crate::lower::Env& menv, const crate::syntax::Stmt& s, const bool& last) {
    auto lx = wx.lx;
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        auto [wx2, res] = build_line(wx, benv, menv, e, binding_of(menv, p_));
        auto wx3 = bind_res(wx2, menv, p_, res);
        auto&& _m = std::tuple{res, p_.kind};
        if (prism_rtl::is<Wres::WrDyn>(std::get<0>(_m)) && prism_rtl::is<crate::syntax::PatternKind::PName>(std::get<1>(_m))) {
            auto&& ex = prism_rtl::as<Wres::WrDyn>(std::get<0>(_m)).a0;
            auto&& rds = prism_rtl::as<Wres::WrDyn>(std::get<0>(_m)).a1;
            auto&& t = prism_rtl::as<Wres::WrDyn>(std::get<0>(_m)).a2;
            auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(std::get<1>(_m)).a0;
            auto b = crate::lower::Bn(crate::lower::Bn::BnDyn{ex, rds, t});
            return std::tuple{wx3, crate::lower::bind(benv, crate::check::env::sname_key(n), b), crate::lower::bind(menv, crate::check::env::sname_key(n), b)};
        }
        if (prism_rtl::is<Wres::WrHosted>(std::get<0>(_m)) && prism_rtl::is<crate::syntax::PatternKind::PTuple>(std::get<1>(_m))) {
            auto&& inner = prism_rtl::as<Wres::WrHosted>(std::get<0>(_m)).a0;
            auto&& doc = prism_rtl::as<Wres::WrHosted>(std::get<0>(_m)).a1;
            auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PTuple>(std::get<1>(_m)).a0;
            return bind_hosted(wx3, benv, menv, inner, doc, ps);
        }
        {
            return std::tuple{wx3, benv, menv};
        }
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& init = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        auto&& step_ = prism_rtl::some_of(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2);
        auto [wx2, be2] = hold_line(wx, benv, menv, p_, init, step_);
        return std::tuple{wx2, be2, menv};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SIgnore>(_m)) {
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SIgnore>(_m).a0;
        auto&& _wx2 = build_line(wx, benv, menv, e, std::optional<crate::lower::Bn>{});
        auto&& wx2 = std::get<0>(_wx2);
        return std::tuple{wx2, benv, menv};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        auto [wx2, be2] = let_line(wx, benv, menv, p_, e);
        return std::tuple{wx2, be2, menv};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        auto&& _m = e.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
            auto&& m24204_0_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
            if (m24204_0_0 == Text::lit("@")) {
                auto [res, wx2] = result_of(wx, benv, menv, x);
                auto wx3 = ({
                    Wx this_ = wx2;
                    this_.result = res;
                    this_;
                });
                return std::tuple{wx3, benv, menv};
            }
        }
        {
            auto [wx2, res] = build_line(wx, benv, menv, e, std::optional<crate::lower::Bn>{});
            auto wx3 = last ? set_result(wx2, res) : wx2;
            return std::tuple{wx3, benv, menv};
        }
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SEmit>(_m)) {
        return std::tuple{wx, benv, menv};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m)) {
        return std::tuple{wx, benv, menv};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        return std::tuple{wx, benv, menv};
    }
    {
        auto wx2 = ({
            Wx this_ = wx;
            this_.build = crate::prelude::push(this_.build, crate::lower::refusal_do(Text::lit("a statement this back end does not lower yet")));
            this_;
        });
        return std::tuple{wx2, benv, menv};
    }
}


prism_rtl::Turn<std::tuple<Wx, crate::lower::Env, crate::lower::Env>> WidgetStmt::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& s = this->s;
    const auto& last = this->last;
    auto lx = wx.lx;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        ({
        auto benv_1 = benv;
        auto e_2 = e;
        auto menv_3 = menv;
        auto p__4 = p_;
        auto wx_5 = wx;
        call_then(start_build_line(wx_5, benv_1, menv_3, e_2, binding_of(menv_3, p__4)), [=](std::tuple<Wx, Wres> build_line_23358) {
        return ({
            auto [wx2, res] = build_line_23358;
            auto wx3 = bind_res(wx2, menv_3, p__4, res);
            ({
            auto&& _m = std::tuple{res, p__4.kind};
            prism_rtl::is<Wres::WrDyn>(std::get<0>(_m)) && prism_rtl::is<crate::syntax::PatternKind::PName>(std::get<1>(_m)) ? ({
            auto&& ex = prism_rtl::as<Wres::WrDyn>(std::get<0>(_m)).a0;
            auto&& rds = prism_rtl::as<Wres::WrDyn>(std::get<0>(_m)).a1;
            auto&& t = prism_rtl::as<Wres::WrDyn>(std::get<0>(_m)).a2;
            auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(std::get<1>(_m)).a0;
            ({
            auto b = crate::lower::Bn(crate::lower::Bn::BnDyn{ex, rds, t});
            (prism_rtl::finished(std::tuple{wx3, crate::lower::bind(benv_1, crate::check::env::sname_key(n), b), crate::lower::bind(menv_3, crate::check::env::sname_key(n), b)}));
        });
        })
            : prism_rtl::is<Wres::WrHosted>(std::get<0>(_m)) && prism_rtl::is<crate::syntax::PatternKind::PTuple>(std::get<1>(_m)) ? ({
            auto&& inner = prism_rtl::as<Wres::WrHosted>(std::get<0>(_m)).a0;
            auto&& doc = prism_rtl::as<Wres::WrHosted>(std::get<0>(_m)).a1;
            auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PTuple>(std::get<1>(_m)).a0;
            prism_rtl::finished(bind_hosted(wx3, benv_1, menv_3, inner, doc, ps));
        })
            : prism_rtl::finished(std::tuple{wx3, benv_1, menv_3});
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& init = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        auto&& step_ = prism_rtl::some_of(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2);
        ({
        auto benv_1 = benv;
        auto init_2 = init;
        auto menv_3 = menv;
        auto p__4 = p_;
        auto step__5 = step_;
        auto wx_6 = wx;
        call_then(start_hold_line(wx_6, benv_1, menv_3, p__4, init_2, step__5), [=](std::tuple<Wx, crate::lower::Env> hold_line_23881) {
        return ({
            auto [wx2, be2] = hold_line_23881;
            (prism_rtl::finished(std::tuple{wx2, be2, menv_3}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SIgnore>(_m) ? ({
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SIgnore>(_m).a0;
        ({
        auto benv_1 = benv;
        auto e_2 = e;
        auto menv_3 = menv;
        auto wx_4 = wx;
        call_then(start_build_line(wx_4, benv_1, menv_3, e_2, std::optional<crate::lower::Bn>{}), [=](std::tuple<Wx, Wres> build_line_24004) {
        return ({
            auto&& _wx2 = build_line_24004;
            auto&& wx2 = std::get<0>(_wx2);
            (prism_rtl::finished(std::tuple{wx2, benv_1, menv_3}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        ({
        auto benv_1 = benv;
        auto e_2 = e;
        auto menv_3 = menv;
        auto p__4 = p_;
        auto wx_5 = wx;
        call_then(start_let_line(wx_5, benv_1, menv_3, p__4, e_2), [=](std::tuple<Wx, crate::lower::Env> let_line_24127) {
        return ({
            auto [wx2, be2] = let_line_24127;
            (prism_rtl::finished(std::tuple{wx2, be2, menv_3}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m) && ({
        auto&& m24204_0_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        (m24204_0_0 == Text::lit("@"));
    }) ? ({
        auto&& m24204_0_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        ({
        auto benv_1 = benv;
        auto menv_2 = menv;
        auto wx_3 = wx;
        auto x_4 = x;
        call_then(start_result_of(wx_3, benv_1, menv_2, x_4), [=](std::tuple<Wres, Wx> result_of_24284) {
        return ({
            auto [res, wx2] = result_of_24284;
            auto wx3 = ({
                Wx this_ = wx2;
                this_.result = res;
                this_;
            });
            (prism_rtl::finished(std::tuple{wx3, benv_1, menv_2}));
        });
    });
    });
    })
        : ({
        auto benv_1 = benv;
        auto e_2 = e;
        auto last_3 = last;
        auto menv_4 = menv;
        auto wx_5 = wx;
        call_then(start_build_line(wx_5, benv_1, menv_4, e_2, std::optional<crate::lower::Bn>{}), [=](std::tuple<Wx, Wres> build_line_24480) {
        return ({
            auto [wx2, res] = build_line_24480;
            auto wx3 = last_3 ? set_result(wx2, res) : wx2;
            (prism_rtl::finished(std::tuple{wx3, benv_1, menv_4}));
        });
    });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SEmit>(_m) ? prism_rtl::finished(std::tuple{wx, benv, menv})
        : prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m) ? prism_rtl::finished(std::tuple{wx, benv, menv})
        : prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        prism_rtl::finished(std::tuple{wx, benv, menv});
    })
        : ({
        auto wx2 = ({
            Wx this_ = wx;
            this_.build = crate::prelude::push(this_.build, crate::lower::refusal_do(Text::lit("a statement this back end does not lower yet")));
            this_;
        });
        (prism_rtl::finished(std::tuple{wx2, benv, menv}));
    });
    });
}


/// `Start WidgetStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Wx, crate::lower::Env, crate::lower::Env>> start_widget_stmt(Wx wx, crate::lower::Env benv, crate::lower::Env menv, crate::syntax::Stmt s, bool last) {
    return prism_rtl::make_rc<WidgetStmt>(wx, benv, menv, s, last);
}


/// BindHosted: fn Wx, Env, Env, Wres, Bn, [Pattern] -> ((Wx, Env, Env))
std::tuple<Wx, crate::lower::Env, crate::lower::Env> bind_hosted(const Wx& wx, const crate::lower::Env& benv, const crate::lower::Env& menv, const Wres& res, const crate::lower::Bn& doc, const Array<crate::syntax::Pattern_>& ps) {
    auto r_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<crate::lower::Bn>> _v;
        if (prism_rtl::is<Wres::WrEv>(res)) {
            auto&& r = prism_rtl::as<Wres::WrEv>(res).a0;
            _v.set(std::optional(crate::lower::Bn(crate::lower::Bn::BnEv{r, crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})})));
            goto _done;
        }
        if (prism_rtl::is<Wres::WrDyn>(res)) {
            auto&& ex = prism_rtl::as<Wres::WrDyn>(res).a0;
            auto&& rds = prism_rtl::as<Wres::WrDyn>(res).a1;
            auto&& t = prism_rtl::as<Wres::WrDyn>(res).a2;
            _v.set(std::optional(crate::lower::Bn(crate::lower::Bn::BnDyn{ex, rds, t})));
            goto _done;
        }
        {
            _v.set(std::optional<crate::lower::Bn>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [be1, me1] = bind_part(benv, menv, index(ps, Nat(0u)), r_opt);
    return bind_part2(wx, be1, me1, index(ps, Nat(1u)), std::optional(doc));
}


/// BindPart: fn Env, Env, ?Pattern, ?Bn -> ((Env, Env))
std::tuple<crate::lower::Env, crate::lower::Env> bind_part(const crate::lower::Env& benv, const crate::lower::Env& menv, const std::optional<crate::syntax::Pattern_>& p__opt, const std::optional<crate::lower::Bn>& b_opt) {
    auto&& _m = std::tuple{p__opt, b_opt};
    if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
        auto&& p_ = prism_rtl::some_of(std::get<0>(_m));
        auto&& b = prism_rtl::some_of(std::get<1>(_m));
        auto&& _m = p_.kind;
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            return std::tuple{crate::lower::bind(benv, crate::check::env::sname_key(n), b), crate::lower::bind(menv, crate::check::env::sname_key(n), b)};
        }
        {
            return std::tuple{benv, menv};
        }
    }
    {
        return std::tuple{benv, menv};
    }
}


/// BindPart2: fn Wx, Env, Env, ?Pattern, ?Bn -> ((Wx, Env, Env))
std::tuple<Wx, crate::lower::Env, crate::lower::Env> bind_part2(const Wx& wx, const crate::lower::Env& benv, const crate::lower::Env& menv, const std::optional<crate::syntax::Pattern_>& p__opt, const std::optional<crate::lower::Bn>& b_opt) {
    auto [be, me] = bind_part(benv, menv, p__opt, b_opt);
    return std::tuple{wx, be, me};
}


/// SetResult: fn Wx, Wres -> Wx
Wx set_result(const Wx& wx, const Wres& res) {
    Wx this_ = wx;
    this_.result = res;
    return this_;
}


/// ResultOf: unbounded fn Wx, Env, Env, Expr -> ((Wres, Wx))
std::tuple<Wres, Wx> result_of(const Wx& wx, const crate::lower::Env& benv, const crate::lower::Env& menv, const crate::syntax::Expr& x) {
    auto lx = wx.lx;
    auto full = crate::lower::type_at(lx, x.span);
    auto t = crate::lower::out_ty_of(lx, crate::lower::peel(full));
    auto bound_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<crate::lower::Bn>> _v;
        auto&& _m = x.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            _v.set(len(n->path_) == Nat(1u)
                ? crate::prelude::get(menv->names, crate::check::env::sname_key(n))
                : std::optional<crate::lower::Bn>{});
            goto _done;
        }
        {
            _v.set(std::optional<crate::lower::Bn>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    if (prism_rtl::is_some(bound_opt) && prism_rtl::is<crate::lower::Bn::BnEv>(prism_rtl::some_of(bound_opt))) {
        auto&& r = prism_rtl::as<crate::lower::Bn::BnEv>(prism_rtl::some_of(bound_opt)).a0;
        return std::tuple{Wres(Wres::WrEv{r}), wx};
    }
    if (prism_rtl::is_some(bound_opt) && prism_rtl::is<crate::lower::Bn::BnDyn>(prism_rtl::some_of(bound_opt))) {
        auto&& ex = prism_rtl::as<crate::lower::Bn::BnDyn>(prism_rtl::some_of(bound_opt)).a0;
        auto&& rds = prism_rtl::as<crate::lower::Bn::BnDyn>(prism_rtl::some_of(bound_opt)).a1;
        auto&& bt = prism_rtl::as<crate::lower::Bn::BnDyn>(prism_rtl::some_of(bound_opt)).a2;
        return std::tuple{Wres(Wres::WrDyn{ex, rds, bt}), wx};
    }
    {
        return result_of_typed(wx, benv, menv, x, full, t);
    }
}


prism_rtl::Turn<std::tuple<Wres, Wx>> ResultOf::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& x = this->x;
    auto lx = wx.lx;
    auto full = crate::lower::type_at(lx, x.span);
    auto benv_1 = benv;
    auto menv_2 = menv;
    auto wx_3 = wx;
    auto x_4 = x;
    return call_then(crate::lower::start_out_ty_of(lx, crate::lower::peel(full)), [=](crate::lower::model::OutTy out_ty_of_26392) {
        return ({
            auto t = out_ty_of_26392;
            auto bound_opt = ({
                __label__ _done;
                prism_rtl::Slot<std::optional<crate::lower::Bn>> _v;
                auto&& _m = x_4.kind;
                if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                    auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                    _v.set(len(n->path_) == Nat(1u)
                        ? crate::prelude::get(menv_2->names, crate::check::env::sname_key(n))
                        : std::optional<crate::lower::Bn>{});
                    goto _done;
                }
                {
                    _v.set(std::optional<crate::lower::Bn>{});
                    goto _done;
                }
            _done:
                _v.take();
            });
            ({
            prism_rtl::is_some(bound_opt) && prism_rtl::is<crate::lower::Bn::BnEv>(prism_rtl::some_of(bound_opt)) ? ({
            auto&& r = prism_rtl::as<crate::lower::Bn::BnEv>(prism_rtl::some_of(bound_opt)).a0;
            prism_rtl::finished(std::tuple{Wres(Wres::WrEv{r}), wx_3});
        })
            : prism_rtl::is_some(bound_opt) && prism_rtl::is<crate::lower::Bn::BnDyn>(prism_rtl::some_of(bound_opt)) ? ({
            auto&& ex = prism_rtl::as<crate::lower::Bn::BnDyn>(prism_rtl::some_of(bound_opt)).a0;
            auto&& rds = prism_rtl::as<crate::lower::Bn::BnDyn>(prism_rtl::some_of(bound_opt)).a1;
            auto&& bt = prism_rtl::as<crate::lower::Bn::BnDyn>(prism_rtl::some_of(bound_opt)).a2;
            prism_rtl::finished(std::tuple{Wres(Wres::WrDyn{ex, rds, bt}), wx_3});
        })
            : prism_rtl::more(prism_rtl::rc(ResultOfTyped(wx_3, benv_1, menv_2, x_4, full, t)));
        });
        });
    });
}


/// `Start ResultOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Wres, Wx>> start_result_of(Wx wx, crate::lower::Env benv, crate::lower::Env menv, crate::syntax::Expr x) {
    return prism_rtl::make_rc<ResultOf>(wx, benv, menv, x);
}


/// ResultOfTyped: unbounded fn Wx, Env, Env, Expr, Ty, OutTy -> ((Wres, Wx))
std::tuple<Wres, Wx> result_of_typed(const Wx& wx, const crate::lower::Env& benv, const crate::lower::Env& menv, const crate::syntax::Expr& x, const crate::check::types::Ty& full, const crate::lower::model::OutTy& t) {
    auto lx = wx.lx;
    auto&& _m = crate::lower::layer_of(full);
    if (prism_rtl::is<crate::lower::Layer::LyEv>(_m)) {
        auto [r, wx2] = event_ref(wx, menv, x);
        return std::tuple{Wres(Wres::WrEv{r}), wx2};
    }
    if (prism_rtl::is<crate::lower::Layer::LyDyn>(_m)) {
        auto [ex, reads] = dynamic_expr(wx, menv, x);
        return std::tuple{Wres(Wres::WrDyn{ex, reads, t}), wx};
    }
    {
        return t == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})
            ? std::tuple{Wres(Wres::WrUnit{}), wx}
            : std::tuple{Wres(Wres::WrPlain{crate::lower::own(crate::lower::value_of(lx, benv, x)), t}), wx};
    }
}


prism_rtl::Turn<std::tuple<Wres, Wx>> ResultOfTyped::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& x = this->x;
    const auto& full = this->full;
    const auto& t = this->t;
    auto lx = wx.lx;
    return ({
        auto&& _m = crate::lower::layer_of(full);
        prism_rtl::is<crate::lower::Layer::LyEv>(_m) ? ({
        auto menv_1 = menv;
        auto wx_2 = wx;
        auto x_3 = x;
        call_then(start_event_ref(wx_2, menv_1, x_3), [=](std::tuple<EvRef, Wx> event_ref_26928) {
        return ({
            auto [r, wx2] = event_ref_26928;
            (prism_rtl::finished(std::tuple{Wres(Wres::WrEv{r}), wx2}));
        });
    });
    })
        : prism_rtl::is<crate::lower::Layer::LyDyn>(_m) ? ({
        auto menv_1 = menv;
        auto t_2 = t;
        auto wx_3 = wx;
        auto x_4 = x;
        call_then(start_dynamic_expr(wx_3, menv_1, x_4), [=](std::tuple<crate::lower::model::Ex, Array<Read>> dynamic_expr_27024) {
        return ({
            auto [ex, reads] = dynamic_expr_27024;
            (prism_rtl::finished(std::tuple{Wres(Wres::WrDyn{ex, reads, t_2}), wx_3}));
        });
    });
    })
        : t == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})
        ? prism_rtl::finished(std::tuple{Wres(Wres::WrUnit{}), wx})
        : ({
        auto benv_1 = benv;
        auto t_2 = t;
        auto wx_3 = wx;
        auto x_4 = x;
        call_then(crate::lower::start_value_of(lx, benv_1, x_4), [=](crate::lower::Vl value_of_27187) { return prism_rtl::finished(std::tuple{Wres(Wres::WrPlain{crate::lower::own(value_of_27187), t_2}), wx_3}); });
    });
    });
}


/// `Start ResultOfTyped, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Wres, Wx>> start_result_of_typed(Wx wx, crate::lower::Env benv, crate::lower::Env menv, crate::syntax::Expr x, crate::check::types::Ty full, crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<ResultOfTyped>(wx, benv, menv, x, full, t);
}


/// HoldLine: unbounded fn Wx, Env, Env, Pattern, Expr, Expr -> ((Wx, Env))
std::tuple<Wx, crate::lower::Env> hold_line(const Wx& wx, const crate::lower::Env& benv, const crate::lower::Env& menv, const crate::syntax::Pattern_& p_, const crate::syntax::Expr& init, const crate::syntax::Expr& step_) {
    auto lx = wx.lx;
    auto&& _m = binding_of(menv, p_);
    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::Bn::BnHold>(prism_rtl::some_of(_m))) {
        auto&& f = prism_rtl::as<crate::lower::Bn::BnHold>(prism_rtl::some_of(_m)).a0;
        auto&& t = prism_rtl::as<crate::lower::Bn::BnHold>(prism_rtl::some_of(_m)).a1;
        auto iv = crate::lower::own(crate::lower::value_of(lx, benv, init));
        auto wx1 = add_field(wx, f, crate::lower::model::OutTy(crate::lower::model::OutTy::OutHold{prism_rtl::rc(t)}), prism_rtl::cat("`", pat_text(p_), "`"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Hold::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat(f, "_init")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}));
        auto [r, wx2] = event_ref(wx1, menv, step_);
        auto wx3 = ({
            Wx this_ = connect(wx2, r, Sk(Sk::SkHold{f}));
            this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat(f, "_init")})), t}), iv}));
            this_.inited = crate::prelude::push(this_.inited, f);
            this_;
        });
        return std::tuple{wx3, crate::lower::bind(benv, prism_rtl::cat(pat_text(p_), "#init"), crate::lower::Bn(crate::lower::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat(f, "_init")}), crate::lower::Holding(crate::lower::Holding::Owned{}), t}))};
    }
    {
        return std::tuple{wx, benv};
    }
}


prism_rtl::Turn<std::tuple<Wx, crate::lower::Env>> HoldLine::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& p_ = this->p_;
    const auto& init = this->init;
    const auto& step_ = this->step_;
    auto lx = wx.lx;
    return ({
        auto&& _m = binding_of(menv, p_);
        prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::Bn::BnHold>(prism_rtl::some_of(_m)) ? ({
        auto&& f = prism_rtl::as<crate::lower::Bn::BnHold>(prism_rtl::some_of(_m)).a0;
        auto&& t = prism_rtl::as<crate::lower::Bn::BnHold>(prism_rtl::some_of(_m)).a1;
        ({
        auto benv_1 = benv;
        auto init_2 = init;
        auto menv_3 = menv;
        auto p__4 = p_;
        auto step__5 = step_;
        auto wx_6 = wx;
        call_then(crate::lower::start_value_of(lx, benv_1, init_2), [=](crate::lower::Vl value_of_27742) {
        return ({
            auto iv = crate::lower::own(value_of_27742);
            auto wx1 = add_field(wx_6, f, crate::lower::model::OutTy(crate::lower::model::OutTy::OutHold{prism_rtl::rc(t)}), prism_rtl::cat("`", pat_text(p__4), "`"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Hold::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat(f, "_init")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}));
            call_then(start_event_ref(wx1, menv_3, step__5), [=](std::tuple<EvRef, Wx> event_ref_27920) {
            return ({
                auto [r, wx2] = event_ref_27920;
                auto wx3 = ({
                    Wx this_ = connect(wx2, r, Sk(Sk::SkHold{f}));
                    this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat(f, "_init")})), t}), iv}));
                    this_.inited = crate::prelude::push(this_.inited, f);
                    this_;
                });
                (prism_rtl::finished(std::tuple{wx3, crate::lower::bind(benv_1, prism_rtl::cat(pat_text(p__4), "#init"), crate::lower::Bn(crate::lower::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat(f, "_init")}), crate::lower::Holding(crate::lower::Holding::Owned{}), t}))}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::finished(std::tuple{wx, benv});
    });
}


/// `Start HoldLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Wx, crate::lower::Env>> start_hold_line(Wx wx, crate::lower::Env benv, crate::lower::Env menv, crate::syntax::Pattern_ p_, crate::syntax::Expr init, crate::syntax::Expr step_) {
    return prism_rtl::make_rc<HoldLine>(wx, benv, menv, p_, init, step_);
}


/// InitEnv: fn Env -> Env
crate::lower::Env init_env(const crate::lower::Env& env) {
    return fold(keys(env->names), env, [&](const crate::lower::Env& en, const Text& k) {
        return ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::Env> _v;
            auto&& _m = std::tuple{crate::syntax::lexer::before_suffix(k, Text::lit("#init")), crate::prelude::get(env->names, k)};
            if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                auto&& name = prism_rtl::some_of(std::get<0>(_m));
                auto&& b = prism_rtl::some_of(std::get<1>(_m));
                _v.set(crate::lower::bind(en, name, b));
                goto _done;
            }
            {
                _v.set(en);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// AllInited: fn Wx, [Read] -> Bool
bool all_inited(const Wx& wx, const Array<Read>& reads) {
    return fold(reads_closed(wx.dyn_reads, reads), true, [&](const bool& ok, const Read& r) {
        return ok && ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            if (prism_rtl::is<Read::OwnRead>(r)) {
                auto&& f = prism_rtl::as<Read::OwnRead>(r).a0;
                _v.set(crate::check::types::has_text(wx.inited, f));
                goto _done;
            }
            if (prism_rtl::is<Read::ParentRead>(r)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// PatText: fn Pattern -> Text
Text pat_text(const crate::syntax::Pattern_& p_) {
    auto&& _m = p_.kind;
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        return crate::check::env::sname_key(n);
    }
    {
        return Text::lit("_");
    }
}


/// LetLine: unbounded fn Wx, Env, Env, Pattern, Expr -> ((Wx, Env))
std::tuple<Wx, crate::lower::Env> let_line(const Wx& wx, const crate::lower::Env& benv, const crate::lower::Env& menv, const crate::syntax::Pattern_& p_, const crate::syntax::Expr& e) {
    auto lx = wx.lx;
    auto&& _m = binding_of(menv, p_);
    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::Bn::BnEv>(prism_rtl::some_of(_m))) {
        auto&& er = prism_rtl::as<crate::lower::Bn::BnEv>(prism_rtl::some_of(_m)).a0;
        auto&& t = prism_rtl::as<crate::lower::Bn::BnEv>(prism_rtl::some_of(_m)).a1;
        auto [r, wx2] = event_ref(wx, menv, e);
        auto fed = crate::lower::out_ty_of(lx, crate::lower::peel(crate::lower::peel(crate::lower::type_at(lx, e.span))));
        auto r2 = ({
            __label__ _done;
            prism_rtl::Slot<EvRef> _v;
            if (prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t)) {
                auto&& m29712_0_0 = prism_rtl::as<crate::lower::model::OutTy::OutEvent>(t).a0;
                if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(m29712_0_0)) {
                    _v.set(fed == crate::lower::model::OutTy(crate::lower::model::OutTy::OutError{})
                        ? err_pipe(r)
                        : r);
                    goto _done;
                }
            }
            if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t)) {
                _v.set(fed == crate::lower::model::OutTy(crate::lower::model::OutTy::OutError{})
                    ? err_pipe(r)
                    : r);
                goto _done;
            }
            {
                _v.set(r);
                goto _done;
            }
        _done:
            _v.take();
        });
        return std::tuple{connect(wx2, r2, Sk(Sk::SkNode{er.node_})), benv};
    }
    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::Bn::BnDyn>(prism_rtl::some_of(_m))) {
        auto&& t = prism_rtl::as<crate::lower::Bn::BnDyn>(prism_rtl::some_of(_m)).a2;
        auto rs = crate::lower::snake(pat_text(p_));
        auto [ex, reads] = dynamic_expr(wx, menv, e);
        auto getter = crate::lower::model::MethDef{.name = rs, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = t, .body = Array<crate::lower::model::Do>{}, .tail = ex, .doc = prism_rtl::cat("`", pat_text(p_), "`")};
        auto wx2 = ({
            Wx this_ = wx;
            this_.getters = crate::prelude::push(this_.getters, getter);
            this_.dyn_reads = insert(this_.dyn_reads, rs, reads);
            this_;
        });
        return all_inited(wx2, reads)
            ? ({
            auto wx3 = ({
                Wx this_ = wx2;
                this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat(rs, "_init")})), t}), crate::lower::own(crate::lower::value_of(lx, init_env(benv), e))}));
                this_.inited = crate::prelude::push(this_.inited, rs);
                this_;
            });
            std::tuple{wx3, crate::lower::bind(benv, prism_rtl::cat(pat_text(p_), "#init"), crate::lower::Bn(crate::lower::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat(rs, "_init")}), crate::lower::Holding(crate::lower::Holding::Owned{}), t}))};
        })
            : std::tuple{wx2, benv};
    }
    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::Bn::BnLocal>(prism_rtl::some_of(_m))) {
        auto&& rs = prism_rtl::as<crate::lower::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
        auto&& t = prism_rtl::as<crate::lower::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
        auto insts_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>> _v;
            auto&& _m = p_.kind;
            if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                _v.set(many_instances(lx, n.span));
                goto _done;
            }
            {
                _v.set(std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        if (prism_rtl::is_some(insts_opt)) {
            auto&& insts = prism_rtl::some_of(insts_opt);
            auto&& _m = p_.kind;
            if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                auto nkey = crate::check::env::sname_key(n);
                auto wxn = run_to_end(fold_job(crate::check::errors::range0(len(insts)), wx, ({
                    auto lx_1 = lx;
                    auto insts_2 = insts;
                    auto nkey_3 = nkey;
                    auto menv_4 = menv;
                    auto benv_5 = benv;
                    auto e_6 = e;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Wx>(std::tuple<Wx, Nat>)>>(prism_rtl::rc([=](std::tuple<Wx, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto lx_1_7 = lx_1;
                        auto insts_2_7 = insts_2;
                        auto nkey_3_7 = nkey_3;
                        auto menv_4_7 = menv_4;
                        auto benv_5_7 = benv_5;
                        auto e_6_7 = e_6;
                        entered(once_job([=]() {
                        return ({
                            auto w = p0;
                            auto k = p1;
                            ({
                            auto lxk = crate::lower::at_instance(lx_1_7, or_(index(insts_2_7, k), std::tuple{Array<std::tuple<Text, crate::check::types::Ty>>{}, Array<std::tuple<Text, crate::check::types::Col>>{}}));
                            auto bkey = k == Nat(0u) ? nkey_3_7 : prism_rtl::cat(nkey_3_7, "#inst", k);
                            ({
                            auto&& _m = crate::prelude::get(menv_4_7->names, bkey);
                            prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::Bn::BnLocal>(prism_rtl::some_of(_m)) ? ({
                            auto&& rk = prism_rtl::as<crate::lower::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                            auto&& tk = prism_rtl::as<crate::lower::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                            call_then(crate::lower::start_value_of(lxk, benv_5_7, e_6_7), [=](crate::lower::Vl value_of_31515) { return prism_rtl::finished(widget_let_field(w, crate::lower::place_stem(rk), tk, crate::lower::own(value_of_31515), prism_rtl::cat("`", nkey_3_7, "` at its instantiation ", k))); });
                        })
                            : prism_rtl::finished(({
                            Wx this_ = w;
                            this_.build = crate::prelude::push(this_.build, crate::lower::refusal_do(prism_rtl::cat("`", nkey_3_7, "` at its instantiation ", k, ", which has no binding")));
                            this_;
                        }));
                        });
                        });
                        });
                    }));
                    });
                })));
                })));
                return std::tuple{wxn, benv};
            }
            {
                return std::tuple{wx, benv};
            }
        }
        if (prism_rtl::is_none(insts_opt)) {
            auto lxw = ({
                __label__ _done;
                prism_rtl::Slot<crate::lower::Lx> _v;
                auto&& _m = p_.kind;
                if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                    auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                    _v.set(crate::lower::widget_let_lx(lx, n.span));
                    goto _done;
                }
                {
                    _v.set(lx);
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto v_ = crate::lower::own(crate::lower::value_of(lxw, benv, e));
            return std::tuple{widget_let_field(wx, crate::lower::place_stem(rs), t, v_, prism_rtl::cat("`", pat_text(p_), "`")), benv};
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        return std::tuple{wx, benv};
    }
}


prism_rtl::Turn<std::tuple<Wx, crate::lower::Env>> LetLine::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& p_ = this->p_;
    const auto& e = this->e;
    auto lx = wx.lx;
    return ({
        auto&& _m = binding_of(menv, p_);
        prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::Bn::BnEv>(prism_rtl::some_of(_m)) ? ({
        auto&& er = prism_rtl::as<crate::lower::Bn::BnEv>(prism_rtl::some_of(_m)).a0;
        auto&& t = prism_rtl::as<crate::lower::Bn::BnEv>(prism_rtl::some_of(_m)).a1;
        ({
        auto benv_1 = benv;
        auto e_2 = e;
        auto menv_3 = menv;
        auto wx_4 = wx;
        call_then(start_event_ref(wx_4, menv_3, e_2), [=](std::tuple<EvRef, Wx> event_ref_29602) {
        return ({
            auto [r, wx2] = event_ref_29602;
            call_then(crate::lower::start_out_ty_of(lx, crate::lower::peel(crate::lower::peel(crate::lower::type_at(lx, e_2.span)))), [=](crate::lower::model::OutTy out_ty_of_29645) {
            return ({
                auto fed = out_ty_of_29645;
                auto r2 = ({
                    __label__ _done;
                    prism_rtl::Slot<EvRef> _v;
                    if (prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t)) {
                        auto&& m29712_0_0 = prism_rtl::as<crate::lower::model::OutTy::OutEvent>(t).a0;
                        if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(m29712_0_0)) {
                            _v.set(fed == crate::lower::model::OutTy(crate::lower::model::OutTy::OutError{})
                                ? err_pipe(r)
                                : r);
                            goto _done;
                        }
                    }
                    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t)) {
                        _v.set(fed == crate::lower::model::OutTy(crate::lower::model::OutTy::OutError{})
                            ? err_pipe(r)
                            : r);
                        goto _done;
                    }
                    {
                        _v.set(r);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                (prism_rtl::finished(std::tuple{connect(wx2, r2, Sk(Sk::SkNode{er.node_})), benv_1}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::Bn::BnDyn>(prism_rtl::some_of(_m)) ? ({
        auto&& t = prism_rtl::as<crate::lower::Bn::BnDyn>(prism_rtl::some_of(_m)).a2;
        ({
        auto rs = crate::lower::snake(pat_text(p_));
        auto benv_1 = benv;
        auto e_2 = e;
        auto menv_3 = menv;
        auto p__4 = p_;
        auto wx_5 = wx;
        call_then(start_dynamic_expr(wx_5, menv_3, e_2), [=](std::tuple<crate::lower::model::Ex, Array<Read>> dynamic_expr_30065) {
        return ({
            auto [ex, reads] = dynamic_expr_30065;
            auto getter = crate::lower::model::MethDef{.name = rs, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = t, .body = Array<crate::lower::model::Do>{}, .tail = ex, .doc = prism_rtl::cat("`", pat_text(p__4), "`")};
            auto wx2 = ({
                Wx this_ = wx_5;
                this_.getters = crate::prelude::push(this_.getters, getter);
                this_.dyn_reads = insert(this_.dyn_reads, rs, reads);
                this_;
            });
            all_inited(wx2, reads)
            ? ({
            auto wx3 = ({
                Wx this_ = wx2;
                this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat(rs, "_init")})), t}), crate::lower::own(crate::lower::value_of(lx, init_env(benv_1), e_2))}));
                this_.inited = crate::prelude::push(this_.inited, rs);
                this_;
            });
            (prism_rtl::finished(std::tuple{wx3, crate::lower::bind(benv_1, prism_rtl::cat(pat_text(p__4), "#init"), crate::lower::Bn(crate::lower::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat(rs, "_init")}), crate::lower::Holding(crate::lower::Holding::Owned{}), t}))}));
        })
            : prism_rtl::finished(std::tuple{wx2, benv_1});
        });
    });
    });
    })
        : prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::Bn::BnLocal>(prism_rtl::some_of(_m)) ? ({
        auto&& rs = prism_rtl::as<crate::lower::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
        auto&& t = prism_rtl::as<crate::lower::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
        ({
        auto insts_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>> _v;
            auto&& _m = p_.kind;
            if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                _v.set(many_instances(lx, n.span));
                goto _done;
            }
            {
                _v.set(std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        ({
        prism_rtl::is_some(insts_opt) ? ({
        auto&& insts = prism_rtl::some_of(insts_opt);
        ({
        auto&& _m = p_.kind;
        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        ({
        auto nkey = crate::check::env::sname_key(n);
        auto benv_1 = benv;
        auto e_2 = e;
        auto insts_3 = insts;
        auto menv_4 = menv;
        auto wx_5 = wx;
        call_value(fold_job(crate::check::errors::range0(len(insts_3)), wx_5, ({
        auto lx_6 = lx;
        auto insts_3_7 = insts_3;
        auto nkey_7 = nkey;
        auto menv_4_8 = menv_4;
        auto benv_1_8 = benv_1;
        auto e_2_8 = e_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Wx>(std::tuple<Wx, Nat>)>>(prism_rtl::rc([=](std::tuple<Wx, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_6_8 = lx_6;
            auto insts_3_7_8 = insts_3_7;
            auto nkey_7_8 = nkey_7;
            auto menv_4_8_8 = menv_4_8;
            auto benv_1_8_8 = benv_1_8;
            auto e_2_8_8 = e_2_8;
            entered(once_job([=]() {
            return ({
                auto w = p0;
                auto k = p1;
                ({
                auto lxk = crate::lower::at_instance(lx_6_8, or_(index(insts_3_7_8, k), std::tuple{Array<std::tuple<Text, crate::check::types::Ty>>{}, Array<std::tuple<Text, crate::check::types::Col>>{}}));
                auto bkey = k == Nat(0u) ? nkey_7_8 : prism_rtl::cat(nkey_7_8, "#inst", k);
                ({
                auto&& _m = crate::prelude::get(menv_4_8_8->names, bkey);
                prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::Bn::BnLocal>(prism_rtl::some_of(_m)) ? ({
                auto&& rk = prism_rtl::as<crate::lower::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& tk = prism_rtl::as<crate::lower::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                call_then(crate::lower::start_value_of(lxk, benv_1_8_8, e_2_8_8), [=](crate::lower::Vl value_of_31515) { return prism_rtl::finished(widget_let_field(w, crate::lower::place_stem(rk), tk, crate::lower::own(value_of_31515), prism_rtl::cat("`", nkey_7_8, "` at its instantiation ", k))); });
            })
                : prism_rtl::finished(({
                Wx this_ = w;
                this_.build = crate::prelude::push(this_.build, crate::lower::refusal_do(prism_rtl::cat("`", nkey_7_8, "` at its instantiation ", k, ", which has no binding")));
                this_;
            }));
            });
            });
            });
        }));
        });
    })));
    })), [=](Wx fold_31159) {
        return ({
            auto wxn = fold_31159;
            (prism_rtl::finished(std::tuple{wxn, benv_1}));
        });
    });
    });
    })
        : prism_rtl::finished(std::tuple{wx, benv});
    });
    })
        : prism_rtl::is_none(insts_opt) ? ({
        auto lxw = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::Lx> _v;
            auto&& _m = p_.kind;
            if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                _v.set(crate::lower::widget_let_lx(lx, n.span));
                goto _done;
            }
            {
                _v.set(lx);
                goto _done;
            }
        _done:
            _v.take();
        });
        auto benv_1 = benv;
        auto e_2 = e;
        auto p__3 = p_;
        auto wx_4 = wx;
        call_then(crate::lower::start_value_of(lxw, benv_1, e_2), [=](crate::lower::Vl value_of_32035) {
        return ({
            auto v_ = crate::lower::own(value_of_32035);
            (prism_rtl::finished(std::tuple{widget_let_field(wx_4, crate::lower::place_stem(rs), t, v_, prism_rtl::cat("`", pat_text(p__3), "`")), benv_1}));
        });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : prism_rtl::finished(std::tuple{wx, benv});
    });
}


/// `Start LetLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Wx, crate::lower::Env>> start_let_line(Wx wx, crate::lower::Env benv, crate::lower::Env menv, crate::syntax::Pattern_ p_, crate::syntax::Expr e) {
    return prism_rtl::make_rc<LetLine>(wx, benv, menv, p_, e);
}


/// WidgetLetField: fn Wx, Text, OutTy, Ex, Text -> Wx
Wx widget_let_field(const Wx& wx, const Text& f, const crate::lower::model::OutTy& t, const crate::lower::model::Ex& v_, const Text& doc) {
    Wx this_ = wx;
    this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{f}), v_}));
    this_.fields = crate::prelude::push(this_.fields, std::tuple{f, t, doc});
    this_.inits = crate::prelude::push(this_.inits, std::tuple{f, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{f}))})});
    return this_;
}


/// ErrPipe: fn EvRef -> EvRef
EvRef err_pipe(const EvRef& r) {
    return EvRef{.node_ = r.node_, .owner = r.owner, .pipe = ({
        auto r_1 = r;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>)>>(prism_rtl::rc([=](std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto r_1_2 = r_1;
            entered(once_job([=]() {
            return ({
                auto x = p0;
                auto k_fn = p1;
                r_1_2.pipe(std::tuple{x, ({
                auto k_fn_2 = k_fn;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>(prism_rtl::rc([=](crate::lower::model::Ex p0) {
                return ({
                    auto k_fn_2_3 = k_fn_2;
                    entered(once_job([=]() {
                    return ({
                        auto y = p0;
                        k_fn_2_3(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{y})}))->cycle();
                    });
                }));
                });
            })));
            })})->cycle();
            });
        }));
        });
    })));
    })};
}


/// OwnAs: fn OutTy, Vl -> Ex
crate::lower::model::Ex own_as(const crate::lower::model::OutTy& t, const crate::lower::Vl& v_) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t)) {
        return crate::lower::value_ty(v_) == crate::lower::model::OutTy(crate::lower::model::OutTy::OutError{})
            ? crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{crate::lower::own(v_)})})
            : crate::lower::own(v_);
    }
    {
        return crate::lower::own(v_);
    }
}


/// BindRes: fn Wx, Env, Pattern, Wres -> Wx
Wx bind_res(const Wx& wx2, const crate::lower::Env& menv, const crate::syntax::Pattern_& p_, const Wres& res) {
    auto&& _m = binding_of(menv, p_);
    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::Bn::BnEv>(prism_rtl::some_of(_m))) {
        auto&& er = prism_rtl::as<crate::lower::Bn::BnEv>(prism_rtl::some_of(_m)).a0;
        if (prism_rtl::is<Wres::WrEv>(res)) {
            auto&& r = prism_rtl::as<Wres::WrEv>(res).a0;
            return er.owner != wx2.node_
                ? crossed(wx2, prism_rtl::cat("the bound event of node `", er.owner, "` (its graph node ", er.node_, ")"))
                : r.node_ == er.node_ ? wx2 : connect(wx2, r, Sk(Sk::SkNode{er.node_}));
        }
        {
            return wx2;
        }
    }
    {
        return wx2;
    }
}


/// BuildLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
std::tuple<Wx, Wres> build_line(const Wx& wx, const crate::lower::Env& benv, const crate::lower::Env& menv, const crate::syntax::Expr& e, const std::optional<crate::lower::Bn>& bound_opt) {
    auto lx = wx.lx;
    auto full = crate::lower::type_at(lx, e.span);
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return build_line(wx, benv, menv, x, bound_opt);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m)) {
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EWidgetBlock>(_m).a0;
        return inline_block(wx, benv, menv, b, lx);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFor>(_m)) {
        auto&& binders_opt = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
        auto&& source = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
        return for_line(wx, benv, menv, binders_opt, source, body, e, bound_opt);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ERebuild>(_m)) {
        auto&& scrut = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a0;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a1;
        return rebuild_line(wx, benv, menv, scrut, body, e, bound_opt);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2)) {
        auto&& m33812_4_0 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
        if (prism_rtl::is<crate::syntax::Cond::CondExpr>(m33812_4_0)) {
            auto&& c = prism_rtl::as<crate::syntax::Cond::CondExpr>(m33812_4_0).a0;
            return crate::lower::if_gen_line(wx, menv, c, then_b, else_b, e);
        }
    }
    {
        auto&& _m = crate::lower::peel(full);
        if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
            return element_line(wx, benv, menv, e, bound_opt);
        }
        if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
            return widget_line(wx, benv, menv, e, bound_opt);
        }
        {
            auto wx2 = ({
                Wx this_ = wx;
                this_.build = crate::prelude::push(this_.build, crate::lower::refusal_do(Text::lit("a building line this back end does not lower yet")));
                this_;
            });
            return std::tuple{wx2, Wres(Wres::WrUnit{})};
        }
    }
}


prism_rtl::Turn<std::tuple<Wx, Wres>> BuildLine::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& e = this->e;
    const auto& bound_opt = this->bound_opt;
    auto lx = wx.lx;
    auto full = crate::lower::type_at(lx, e.span);
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(BuildLine(wx, benv, menv, x, bound_opt)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m) ? ({
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EWidgetBlock>(_m).a0;
        prism_rtl::more(prism_rtl::rc(InlineBlock(wx, benv, menv, b, lx)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EFor>(_m) ? ({
        auto&& binders_opt = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
        auto&& source = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
        prism_rtl::more(prism_rtl::rc(ForLine(wx, benv, menv, binders_opt, source, body, e, bound_opt)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ERebuild>(_m) ? ({
        auto&& scrut = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a0;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a1;
        prism_rtl::more(prism_rtl::rc(RebuildLine(wx, benv, menv, scrut, body, e, bound_opt)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2) && ({
        auto&& m33812_4_0 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
        prism_rtl::is<crate::syntax::Cond::CondExpr>(m33812_4_0);
    }) ? ({
        auto&& m33812_4_0 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
        auto&& c = prism_rtl::as<crate::syntax::Cond::CondExpr>(m33812_4_0).a0;
        prism_rtl::more(prism_rtl::rc(crate::lower::IfGenLine(wx, menv, c, then_b, else_b, e)));
    })
        : ({
        auto&& _m = crate::lower::peel(full);
        prism_rtl::is<crate::check::types::Ty::TyElem>(_m) ? prism_rtl::more(prism_rtl::rc(ElementLine(wx, benv, menv, e, bound_opt)))
        : prism_rtl::is<crate::check::types::Ty::TyAt>(_m) ? prism_rtl::more(prism_rtl::rc(WidgetLine(wx, benv, menv, e, bound_opt)))
        : ({
        auto wx2 = ({
            Wx this_ = wx;
            this_.build = crate::prelude::push(this_.build, crate::lower::refusal_do(Text::lit("a building line this back end does not lower yet")));
            this_;
        });
        (prism_rtl::finished(std::tuple{wx2, Wres(Wres::WrUnit{})}));
    });
    });
    });
}


/// `Start BuildLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Wx, Wres>> start_build_line(Wx wx, crate::lower::Env benv, crate::lower::Env menv, crate::syntax::Expr e, std::optional<crate::lower::Bn> bound_opt) {
    return prism_rtl::make_rc<BuildLine>(wx, benv, menv, e, bound_opt);
}


/// ElementLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
std::tuple<Wx, Wres> element_line(const Wx& wx, const crate::lower::Env& benv, const crate::lower::Env& menv, const crate::syntax::Expr& e, const std::optional<crate::lower::Bn>& bound_opt) {
    auto lx = wx.lx;
    auto [tag_name, args] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Text, Array<crate::syntax::Arg>>> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
            auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
            auto&& xs = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
            _v.set(std::tuple{tag_name_of(lx, c), xs});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            _v.set(std::tuple{tag_name_of(lx, e), Array<crate::syntax::Arg>{}});
            goto _done;
        }
        {
            _v.set(std::tuple{Text::lit(""), Array<crate::syntax::Arg>{}});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto full = crate::lower::type_at(lx, e.span);
    auto&& _m = crate::prelude::get(lx.g.tags, tag_name);
    if (prism_rtl::is_none(_m)) {
        auto wx2 = ({
            Wx this_ = wx;
            this_.build = crate::prelude::push(this_.build, crate::lower::refusal_do(Text::lit("an element of an unknown tag")));
            this_;
        });
        return std::tuple{wx2, Wres(Wres::WrUnit{})};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& tg = prism_rtl::some_of(_m);
        auto pos = wx.pos;
        auto wx1 = ({
            Wx this_ = wx;
            this_.pos = crate::lower::model::next_pos(this_.pos);
            this_;
        });
        auto struct_path = crate::lower::path_in(lx, tg.home, crate::lower::tag_struct(tg.name));
        auto [live_fields, const_fields, reads, wx2] = run_to_end(fold_job(tg.fields, std::tuple{Array<std::tuple<Text, crate::lower::model::Ex>>{}, Array<std::tuple<Text, crate::lower::model::Ex>>{}, Array<Read>{}, wx1}, ({
            auto args_1 = args;
            auto menv_2 = menv;
            auto pos_3 = pos;
            auto tg_4 = tg;
            auto lx_5 = lx;
            auto benv_6 = benv;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::lower::model::Ex>>, Array<std::tuple<Text, crate::lower::model::Ex>>, Array<Read>, Wx>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::lower::model::Ex>>, Array<std::tuple<Text, crate::lower::model::Ex>>, Array<Read>, Wx>, std::tuple<Text, crate::check::types::Ty>>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<Text, crate::lower::model::Ex>>, Array<std::tuple<Text, crate::lower::model::Ex>>, Array<Read>, Wx>, std::tuple<Text, crate::check::types::Ty>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto args_1_7 = args_1;
                auto menv_2_7 = menv_2;
                auto pos_3_7 = pos_3;
                auto tg_4_7 = tg_4;
                auto lx_5_7 = lx_5;
                auto benv_6_7 = benv_6;
                entered(once_job([=]() {
                return ({
                    auto [lf, cf, rd, w] = p0;
                    auto [fname, fty] = p1;
                    ({
                    auto&& _m = tag_arg(args_1_7, fname);
                    prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{lf, cf, rd, w})
                    : prism_rtl::is_some(_m) ? ({
                    auto&& arg = prism_rtl::some_of(_m);
                    ({
                    auto&& _m = crate::lower::layer_of(fty);
                    prism_rtl::is<crate::lower::Layer::LyEv>(_m) ? call_then(start_event_ref(w, menv_2_7, arg), [=](std::tuple<EvRef, Wx> event_ref_36127) {
                    return ({
                        auto [r, w2] = event_ref_36127;
                        (prism_rtl::finished(std::tuple{lf, cf, rd, connect(w2, r, Sk(Sk::SkRequest{pos_3_7, request_field(tg_4_7, fname)}))}));
                    });
                })
                    : call_then(start_dynamic_expr(w, menv_2_7, arg), [=](std::tuple<crate::lower::model::Ex, Array<Read>> dynamic_expr_36345) {
                    return ({
                        auto [ex, rds] = dynamic_expr_36345;
                        call_then(crate::lower::start_value_of(lx_5_7, benv_6_7, arg), [=](crate::lower::Vl value_of_36416) {
                        return ({
                            auto cv = crate::lower::own(value_of_36416);
                            (prism_rtl::finished(std::tuple{crate::prelude::push(lf, std::tuple{crate::lower::snake(fname), ex}), crate::prelude::push(cf, std::tuple{crate::lower::snake(fname), cv}), union_reads(rd, rds), w}));
                        });
                    });
                    });
                });
                });
                })
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        }));
        })));
        auto live = len(reads) > Nat(0u);
        auto [getter, wx3] = live
            ? fresh_name(wx2, crate::lower::snake(crate::check::types::bare_name(tg.name)))
            : std::tuple{Text::lit(""), wx2};
        auto variant = crate::lower::variant_of(lx, tg);
        auto level = crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRecord{struct_path, live ? live_fields : const_fields})})});
        auto at_build = crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRecord{struct_path, const_fields})})});
        auto added = live
            ? crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), getter, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})
            : level;
        auto wx4 = ({
            Wx this_ = wx3;
            this_.places = crate::prelude::push(this_.places, Place{.pos = pos, .level = level, .getter = getter, .reads = reads});
            this_.build = emits(wx3, pos)
                ? crate::prelude::push(this_.build, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("added"), Array(std::vector{place_at(wx3, Text::lit("node"), pos), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(added), Text::lit("to_pod"), Array<crate::lower::model::Ex>{}})})})}))
                : this_.build;
            this_;
        });
        return element_output(wx4, menv, tg, element_out(lx, tg, full), pos, bound_opt, at_build);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<Wx, Wres>> ElementLine::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& e = this->e;
    const auto& bound_opt = this->bound_opt;
    auto lx = wx.lx;
    auto [tag_name, args] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Text, Array<crate::syntax::Arg>>> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
            auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
            auto&& xs = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
            _v.set(std::tuple{tag_name_of(lx, c), xs});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            _v.set(std::tuple{tag_name_of(lx, e), Array<crate::syntax::Arg>{}});
            goto _done;
        }
        {
            _v.set(std::tuple{Text::lit(""), Array<crate::syntax::Arg>{}});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto full = crate::lower::type_at(lx, e.span);
    return ({
        auto&& _m = crate::prelude::get(lx.g.tags, tag_name);
        prism_rtl::is_none(_m) ? ({
        auto wx2 = ({
            Wx this_ = wx;
            this_.build = crate::prelude::push(this_.build, crate::lower::refusal_do(Text::lit("an element of an unknown tag")));
            this_;
        });
        (prism_rtl::finished(std::tuple{wx2, Wres(Wres::WrUnit{})}));
    })
        : prism_rtl::is_some(_m) ? ({
        auto&& tg = prism_rtl::some_of(_m);
        ({
        auto pos = wx.pos;
        auto wx1 = ({
            Wx this_ = wx;
            this_.pos = crate::lower::model::next_pos(this_.pos);
            this_;
        });
        auto struct_path = crate::lower::path_in(lx, tg.home, crate::lower::tag_struct(tg.name));
        auto bound_opt_1 = bound_opt;
        auto benv_2 = benv;
        auto menv_3 = menv;
        call_value(fold_job(tg.fields, std::tuple{Array<std::tuple<Text, crate::lower::model::Ex>>{}, Array<std::tuple<Text, crate::lower::model::Ex>>{}, Array<Read>{}, wx1}, ({
        auto args_4 = args;
        auto menv_3_5 = menv_3;
        auto pos_5 = pos;
        auto tg_6 = tg;
        auto lx_7 = lx;
        auto benv_2_8 = benv_2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::lower::model::Ex>>, Array<std::tuple<Text, crate::lower::model::Ex>>, Array<Read>, Wx>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::lower::model::Ex>>, Array<std::tuple<Text, crate::lower::model::Ex>>, Array<Read>, Wx>, std::tuple<Text, crate::check::types::Ty>>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<Text, crate::lower::model::Ex>>, Array<std::tuple<Text, crate::lower::model::Ex>>, Array<Read>, Wx>, std::tuple<Text, crate::check::types::Ty>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto args_4_8 = args_4;
            auto menv_3_5_8 = menv_3_5;
            auto pos_5_8 = pos_5;
            auto tg_6_8 = tg_6;
            auto lx_7_8 = lx_7;
            auto benv_2_8_8 = benv_2_8;
            entered(once_job([=]() {
            return ({
                auto [lf, cf, rd, w] = p0;
                auto [fname, fty] = p1;
                ({
                auto&& _m = tag_arg(args_4_8, fname);
                prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{lf, cf, rd, w})
                : prism_rtl::is_some(_m) ? ({
                auto&& arg = prism_rtl::some_of(_m);
                ({
                auto&& _m = crate::lower::layer_of(fty);
                prism_rtl::is<crate::lower::Layer::LyEv>(_m) ? call_then(start_event_ref(w, menv_3_5_8, arg), [=](std::tuple<EvRef, Wx> event_ref_36127) {
                return ({
                    auto [r, w2] = event_ref_36127;
                    (prism_rtl::finished(std::tuple{lf, cf, rd, connect(w2, r, Sk(Sk::SkRequest{pos_5_8, request_field(tg_6_8, fname)}))}));
                });
            })
                : call_then(start_dynamic_expr(w, menv_3_5_8, arg), [=](std::tuple<crate::lower::model::Ex, Array<Read>> dynamic_expr_36345) {
                return ({
                    auto [ex, rds] = dynamic_expr_36345;
                    call_then(crate::lower::start_value_of(lx_7_8, benv_2_8_8, arg), [=](crate::lower::Vl value_of_36416) {
                    return ({
                        auto cv = crate::lower::own(value_of_36416);
                        (prism_rtl::finished(std::tuple{crate::prelude::push(lf, std::tuple{crate::lower::snake(fname), ex}), crate::prelude::push(cf, std::tuple{crate::lower::snake(fname), cv}), union_reads(rd, rds), w}));
                    });
                });
                });
            });
            });
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<std::tuple<Text, crate::lower::model::Ex>>, Array<std::tuple<Text, crate::lower::model::Ex>>, Array<Read>, Wx> fold_35809) {
        return ({
            auto [live_fields, const_fields, reads, wx2] = fold_35809;
            auto live = len(reads) > Nat(0u);
            auto [getter, wx3] = live
                ? fresh_name(wx2, crate::lower::snake(crate::check::types::bare_name(tg.name)))
                : std::tuple{Text::lit(""), wx2};
            auto variant = crate::lower::variant_of(lx, tg);
            auto level = crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRecord{struct_path, live ? live_fields : const_fields})})});
            auto at_build = crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRecord{struct_path, const_fields})})});
            auto added = live
                ? crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), getter, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})
                : level;
            auto wx4 = ({
                Wx this_ = wx3;
                this_.places = crate::prelude::push(this_.places, Place{.pos = pos, .level = level, .getter = getter, .reads = reads});
                this_.build = emits(wx3, pos)
                    ? crate::prelude::push(this_.build, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("added"), Array(std::vector{place_at(wx3, Text::lit("node"), pos), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(added), Text::lit("to_pod"), Array<crate::lower::model::Ex>{}})})})}))
                    : this_.build;
                this_;
            });
            (prism_rtl::finished(element_output(wx4, menv_3, tg, element_out(lx, tg, full), pos, bound_opt_1, at_build)));
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ElementLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Wx, Wres>> start_element_line(Wx wx, crate::lower::Env benv, crate::lower::Env menv, crate::syntax::Expr e, std::optional<crate::lower::Bn> bound_opt) {
    return prism_rtl::make_rc<ElementLine>(wx, benv, menv, e, bound_opt);
}


/// ElementOut: unbounded fn Lx, TagInfo, Ty -> OutTy
crate::lower::model::OutTy element_out(const crate::lower::Lx& lx, const crate::check::env::TagInfo& tg, const crate::check::types::Ty& full) {
    auto t = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::OutTy> _v;
        auto&& _m = crate::lower::peel(full);
        if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
            auto&& o = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a1;
            _v.set(crate::lower::out_ty_of(lx, crate::lower::peel(o)));
            goto _done;
        }
        {
            _v.set(crate::lower::out_ty_of(lx, crate::lower::peel(tg->out)));
            goto _done;
        }
    _done:
        _v.take();
    });
    if (prism_rtl::is<crate::lower::model::OutTy::OutGen>(t)) {
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutPod{});
    }
    {
        return t;
    }
}


/// TagNameOf: fn Lx, Expr -> Text
Text tag_name_of(const crate::lower::Lx& lx, const crate::syntax::Expr& c) {
    auto&& _m = c.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        auto&& _qk_opt = crate::check::env::resolve_value(lx.g, lx.home, n);
        auto&& qk_opt = std::get<0>(_qk_opt);
        return or_(qk_opt, crate::check::env::dotted(n->path_));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return tag_name_of(lx, x);
    }
    {
        return Text::lit("");
    }
}


/// ?TagArg: fn [Arg], Text -> ?Expr
std::optional<crate::syntax::Expr> tag_arg(const Array<crate::syntax::Arg>& args, const Text& fname) {
    return fold(args, std::optional<crate::syntax::Expr>{}, [&](const std::optional<crate::syntax::Expr>& found_opt, const crate::syntax::Arg& a) {
        return ({
            __label__ _done;
            prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
            auto&& _m = a.name;
            if (prism_rtl::is_some(_m)) {
                auto&& n = prism_rtl::some_of(_m);
                _v.set(n.name == fname ? std::optional(a->value) : found_opt);
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(found_opt);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// RequestField: fn TagInfo, Text -> Text
Text request_field(const crate::check::env::TagInfo& tg, const Text& fname) {
    auto evs = filter(tg.fields, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
        auto&& t = std::get<1>(_p0);
        return crate::lower::layer_of(t) == crate::lower::Layer(crate::lower::Layer::LyEv{});
    });
    return len(evs) > Nat(1u) ? fname : Text::lit("");
}


/// ElementOutput: unbounded fn Wx, Env, TagInfo, OutTy, Pos, ?Bn, Ex -> ((Wx, Wres))
std::tuple<Wx, Wres> element_output(const Wx& wx, const crate::lower::Env& menv, const crate::check::env::TagInfo& tg, const crate::lower::model::OutTy& out, const crate::lower::model::Pos_& pos, const std::optional<crate::lower::Bn>& bound_opt, const crate::lower::model::Ex& level) {
    auto lx = wx.lx;
    if (prism_rtl::is_some(bound_opt) && prism_rtl::is<crate::lower::Bn::BnParts>(prism_rtl::some_of(bound_opt))) {
        auto&& parts = prism_rtl::as<crate::lower::Bn::BnParts>(prism_rtl::some_of(bound_opt)).a0;
        return bundle_output(wx, tg, out, pos, parts, level);
    }
    {
        return element_output_of(wx, menv, tg, out, pos, bound_opt, level);
    }
}


/// BundleOutput: unbounded fn Wx, TagInfo, OutTy, Pos, [?Bn], Ex -> ((Wx, Wres))
std::tuple<Wx, Wres> bundle_output(const Wx& wx, const crate::check::env::TagInfo& tg, const crate::lower::model::OutTy& out, const crate::lower::model::Pos_& pos, const Array<std::optional<crate::lower::Bn>>& parts, const crate::lower::model::Ex& level) {
    return !emits(wx, pos)
        ? ({
        auto wx2 = ({
            Wx this_ = wx;
            this_.build = crate::prelude::push(this_.build, crate::lower::refusal_do(prism_rtl::cat("a bundle (", tg.name, ") in a hosted scope")));
            this_;
        });
        std::tuple{wx2, Wres(Wres::WrUnit{})};
    })
        : bundle_output_of(wx, tg, out, pos, parts, level);
}


/// BundleOutputOf: unbounded fn Wx, TagInfo, OutTy, Pos, [?Bn], Ex -> ((Wx, Wres))
std::tuple<Wx, Wres> bundle_output_of(const Wx& wx, const crate::check::env::TagInfo& tg, const crate::lower::model::OutTy& out, const crate::lower::model::Pos_& pos, const Array<std::optional<crate::lower::Bn>>& parts, const crate::lower::model::Ex& level) {
    auto layers = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::Layer>> _v;
        auto&& _m = tg->out;
        if (prism_rtl::is<crate::check::types::Ty::TyTuple>(_m)) {
            auto&& cs = prism_rtl::as<crate::check::types::Ty::TyTuple>(_m).a0;
            _v.set(each(cs, [&](const crate::check::types::Ty& c) { return crate::lower::layer_of(c); }));
            goto _done;
        }
        {
            _v.set(Array<crate::lower::Layer>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto tys = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
        if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(out)) {
            auto&& ts = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(out).a0;
            _v.set(ts);
            goto _done;
        }
        {
            _v.set(Array<crate::lower::model::OutTy>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto idx = crate::check::errors::range0(len(layers));
    auto plain_ix = filter(idx, [&](const Nat& i) { return or_(index(layers, i), crate::lower::Layer(crate::lower::Layer::LyPlain{})) == crate::lower::Layer(crate::lower::Layer::LyPlain{}); });
    auto ev_ix = filter(idx, [&](const Nat& i) { return or_(index(layers, i), crate::lower::Layer(crate::lower::Layer::LyPlain{})) == crate::lower::Layer(crate::lower::Layer::LyEv{}); });
    auto dyn_ix = filter(idx, [&](const Nat& i) { return or_(index(layers, i), crate::lower::Layer(crate::lower::Layer::LyPlain{})) == crate::lower::Layer(crate::lower::Layer::LyDyn{}); });
    auto wx1 = bundle_first(wx, tg, pos, plain_ix, tys, parts, level);
    auto wx2 = fold(ev_ix, wx1, [&](const Wx& w, const Nat& i) { return bundle_answer(w, pos, or_(index(tys, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})), or_(index(parts, i), std::optional<crate::lower::Bn>{})); });
    return (len(ev_ix) > Nat(1u)) || (len(dyn_ix) > Nat(0u))
        ? ({
        auto wx3 = ({
            Wx this_ = wx2;
            this_.build = crate::prelude::push(this_.build, crate::lower::refusal_do(prism_rtl::cat("a bundle with a `$` part or two event parts (", tg.name, ")")));
            this_;
        });
        std::tuple{wx3, Wres(Wres::WrUnit{})};
    })
        : std::tuple{wx2, Wres(Wres::WrUnit{})};
}


/// BundleFirst: unbounded fn Wx, TagInfo, Pos, [Nat], [OutTy], [?Bn], Ex -> Wx
Wx bundle_first(const Wx& wx, const crate::check::env::TagInfo& tg, const crate::lower::model::Pos_& pos, const Array<Nat>& plain_ix, const Array<crate::lower::model::OutTy>& tys, const Array<std::optional<crate::lower::Bn>>& parts, const crate::lower::model::Ex& level) {
    {
        auto&& m41142_0 = plain_ix;
        if (m41142_0.size() == 0u) {
            return wx;
        }
    }
    {
        auto one = len(plain_ix) == Nat(1u);
        auto plain_ty = one
            ? or_(index(tys, or_(index(plain_ix, Nat(0u)), Nat(0u))), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))
            : crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{each(plain_ix, [&](const Nat& i) { return or_(index(tys, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})); })});
        auto wx1 = ({
            Wx this_ = wx;
            this_.lets = append(this_.lets, Array(std::vector{first_value_let(wx, pos, tg, level), crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat("bundle_", crate::lower::model::place_text(pos))}), crate::lower::model::Ex(crate::lower::model::Ex::XDecode{plain_ty, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("first_", crate::lower::model::place_text(pos))}))}))})})}));
            this_.fallible = true;
            this_;
        });
        return fold(crate::check::errors::range0(len(plain_ix)), wx1, [&](const Wx& w, const Nat& k) {
            return ({
                auto i = or_(index(plain_ix, k), Nat(0u));
                ({
                __label__ _done;
                prism_rtl::Slot<Wx> _v;
                auto&& _m = index(parts, i);
                if (prism_rtl::is_some(_m) && prism_rtl::is_some(prism_rtl::some_of(_m)) && prism_rtl::is<crate::lower::Bn::BnLocal>(prism_rtl::some_of(prism_rtl::some_of(_m)))) {
                    auto&& rs = prism_rtl::as<crate::lower::Bn::BnLocal>(prism_rtl::some_of(prism_rtl::some_of(_m))).a0;
                    _v.set(({
                        auto f = crate::lower::place_stem(rs);
                        auto part = one
                            ? crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("bundle_", crate::lower::model::place_text(pos))})
                            : crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XPart{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("bundle_", crate::lower::model::place_text(pos))})), k}))});
                        ({
                        Wx this_ = w;
                        this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{f}), part}));
                        this_.fields = crate::prelude::push(this_.fields, std::tuple{f, or_(index(tys, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})), prism_rtl::cat("place ", crate::lower::model::place_text(pos), "'s answer, part ", i, " of its first value")});
                        this_.inits = crate::prelude::push(this_.inits, std::tuple{f, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{f}))})});
                        this_;
                    });
                    }));
                    goto _done;
                }
                {
                    _v.set(w);
                    goto _done;
                }
            _done:
                _v.take();
            });
            });
        });
    }
}


/// BundleAnswer: fn Wx, Pos, OutTy, ?Bn -> Wx
Wx bundle_answer(const Wx& wx, const crate::lower::model::Pos_& pos, const crate::lower::model::OutTy& et, const std::optional<crate::lower::Bn>& b_opt) {
    auto t = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::OutTy> _v;
        if (prism_rtl::is<crate::lower::model::OutTy::OutEvent>(et)) {
            auto&& inner = prism_rtl::as<crate::lower::model::OutTy::OutEvent>(et).a0;
            _v.set(inner);
            goto _done;
        }
        {
            _v.set(et);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [id, wx2] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Nat, Wx>> _v;
        if (prism_rtl::is_some(b_opt) && prism_rtl::is<crate::lower::Bn::BnEv>(prism_rtl::some_of(b_opt))) {
            auto&& er = prism_rtl::as<crate::lower::Bn::BnEv>(prism_rtl::some_of(b_opt)).a0;
            _v.set(std::tuple{er.node_, wx});
            goto _done;
        }
        {
            _v.set(({
                auto [nm, w] = fresh_name(wx, prism_rtl::cat("place_", crate::lower::model::place_text(pos)));
                add_gn(w, nm, t, GnKind(GnKind::GnAnswer{}), Nat(0u));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
    Wx this_ = wx2;
    this_.answers = crate::prelude::push(this_.answers, std::tuple{pos, id, t, Text::lit("")});
    return this_;
}


/// FirstValueLet: fn Wx, Pos, TagInfo, Ex -> Do
crate::lower::model::Do first_value_let(const Wx& wx, const crate::lower::model::Pos_& pos, const crate::check::env::TagInfo& tg, const crate::lower::model::Ex& level) {
    auto missing = crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Fault::answer"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{prism_rtl::cat("no first value for ", tg.name)})})});
    return emits(wx, pos)
        ? ({
        auto asked = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("first_value"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(level), Text::lit("to_pod"), Array<crate::lower::model::Ex>{}}))})})});
        (crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat("first_", crate::lower::model::place_text(pos))}), crate::lower::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(asked), Text::lit("ok_or"), Array(std::vector{missing})}))}));
    })
        : ({
        auto host = host_local(wx, pos);
        auto asked = crate::lower::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{host})), Text::lit("first_value"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(place_at(wx, Text::lit(""), pos))}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(level)}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}));
        (crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat("first_", crate::lower::model::place_text(pos))}), crate::lower::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(asked), Text::lit("ok_or"), Array(std::vector{missing})}))), answer_accessor(tg), Array<crate::lower::model::Ex>{}}))}));
    });
}


/// HostLocal: fn Wx, Pos -> Text
Text host_local(const Wx& wx, const crate::lower::model::Pos_& pos) {
    return pos.scope == Nat(0u)
        ? Text::lit("enclosing")
        : or_(index(wx.scopes, crate::syntax::lexer::dec(pos.scope)), Text::lit(""));
}


/// AnswerVariant: fn TagInfo -> Text
Text answer_variant(const crate::check::env::TagInfo& tg) {
    return prism_rtl::cat("crate::Answer::", crate::lower::tag_struct(tg.name));
}


/// AnswerAccessor: fn TagInfo -> Text
Text answer_accessor(const crate::check::env::TagInfo& tg) {
    return crate::lower::snake(crate::lower::tag_struct(tg.name));
}


/// ElementOutputOf: unbounded fn Wx, Env, TagInfo, OutTy, Pos, ?Bn, Ex -> ((Wx, Wres))
std::tuple<Wx, Wres> element_output_of(const Wx& wx, const crate::lower::Env& menv, const crate::check::env::TagInfo& tg, const crate::lower::model::OutTy& out, const crate::lower::model::Pos_& pos, const std::optional<crate::lower::Bn>& bound_opt, const crate::lower::model::Ex& level) {
    auto lx = wx.lx;
    auto&& _m = crate::lower::layer_of(tg->out);
    if (prism_rtl::is<crate::lower::Layer::LyEv>(_m)) {
        auto [id, wx2] = ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Nat, Wx>> _v;
            if (prism_rtl::is_some(bound_opt) && prism_rtl::is<crate::lower::Bn::BnEv>(prism_rtl::some_of(bound_opt))) {
                auto&& er = prism_rtl::as<crate::lower::Bn::BnEv>(prism_rtl::some_of(bound_opt)).a0;
                _v.set(std::tuple{er.node_, wx});
                goto _done;
            }
            {
                _v.set(({
                    auto [nm, w] = fresh_name(wx, prism_rtl::cat("place_", crate::lower::model::place_text(pos)));
                    add_gn(w, nm, out, GnKind(GnKind::GnAnswer{}), Nat(0u));
                }));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto wx3 = ({
            Wx this_ = wx2;
            this_.answers = crate::prelude::push(this_.answers, std::tuple{pos, id, out, answer_accessor(tg)});
            this_;
        });
        return std::tuple{wx3, Wres(Wres::WrEv{ev_ref_of(wx3, id)})};
    }
    if (prism_rtl::is<crate::lower::Layer::LyDyn>(_m)) {
        auto [f, wx1] = ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Text, Wx>> _v;
            if (prism_rtl::is_some(bound_opt) && prism_rtl::is<crate::lower::Bn::BnHold>(prism_rtl::some_of(bound_opt))) {
                auto&& hf = prism_rtl::as<crate::lower::Bn::BnHold>(prism_rtl::some_of(bound_opt)).a0;
                _v.set(std::tuple{hf, wx});
                goto _done;
            }
            {
                _v.set(fresh_name(wx, prism_rtl::cat("place_", crate::lower::model::place_text(pos))));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto emits_ = emits(wx, pos);
        auto first__1 = emits_
            ? crate::lower::model::Ex(crate::lower::model::Ex::XDecode{out, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("first_", crate::lower::model::place_text(pos))}))}))})
            : crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("first_", crate::lower::model::place_text(pos))});
        auto wx2 = ({
            Wx this_ = wx1;
            this_.lets = crate::prelude::push(this_.lets, first_value_let(wx, pos, tg, level));
            this_.fields = crate::prelude::push(this_.fields, std::tuple{f, crate::lower::model::OutTy(crate::lower::model::OutTy::OutHold{prism_rtl::rc(out)}), prism_rtl::cat("pushed to place ", crate::lower::model::place_text(pos))});
            this_.inits = crate::prelude::push(this_.inits, std::tuple{f, crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Hold::new"), Array(std::vector{first__1, crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
            this_.dyn_places = crate::prelude::push(this_.dyn_places, std::tuple{pos, f, out, answer_accessor(tg)});
            this_.fallible = true;
            this_;
        });
        auto wx3 = emits_
            ? ({
            Wx this_ = wx2;
            this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat(f, "_element")}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(level), Text::lit("to_pod"), Array<crate::lower::model::Ex>{}})}));
            this_.fields = crate::prelude::push(this_.fields, std::tuple{prism_rtl::cat(f, "_element"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutPod{}), prism_rtl::cat("place ", crate::lower::model::place_text(pos), "'s element, which pushes are keyed by")});
            this_.moves = crate::prelude::push(this_.moves, std::tuple{prism_rtl::cat(f, "_element"), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat(f, "_element")}))})});
            this_.build = crate::prelude::push(this_.build, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("listen"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), prism_rtl::cat(f, "_element")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")}))})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutObj{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Node"), Array<crate::lower::model::OutTy>{}}))})}))})})})}));
            this_;
        })
            : wx2;
        return std::tuple{wx3, Wres(Wres::WrDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f)})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{Read(Read::OwnRead{f})}), out})};
    }
    {
        if (prism_rtl::is_some(bound_opt) && prism_rtl::is<crate::lower::Bn::BnLocal>(prism_rtl::some_of(bound_opt))) {
            auto&& rs = prism_rtl::as<crate::lower::Bn::BnLocal>(prism_rtl::some_of(bound_opt)).a0;
            auto f = crate::lower::place_stem(rs);
            auto first__1 = emits(wx, pos)
                ? crate::lower::model::Ex(crate::lower::model::Ex::XDecode{out, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("first_", crate::lower::model::place_text(pos))}))}))})
                : crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("first_", crate::lower::model::place_text(pos))});
            auto wx2 = ({
                Wx this_ = wx;
                this_.lets = append(this_.lets, Array(std::vector{first_value_let(wx, pos, tg, level), crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{f}), first__1})}));
                this_.fields = crate::prelude::push(this_.fields, std::tuple{f, out, prism_rtl::cat("place ", crate::lower::model::place_text(pos), "'s answer, its first value")});
                this_.inits = crate::prelude::push(this_.inits, std::tuple{f, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{f}))})});
                this_.fallible = true;
                this_;
            });
            return std::tuple{wx2, Wres(Wres::WrUnit{})};
        }
        {
            return std::tuple{wx, Wres(Wres::WrUnit{})};
        }
    }
}


/// WidgetLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
std::tuple<Wx, Wres> widget_line(const Wx& wx, const crate::lower::Env& benv, const crate::lower::Env& menv, const crate::syntax::Expr& e, const std::optional<crate::lower::Bn>& bound_opt) {
    auto lx = wx.lx;
    auto [callee, args] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::syntax::Expr, Array<crate::syntax::Arg>>> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
            auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
            auto&& xs = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
            _v.set(std::tuple{c, xs});
            goto _done;
        }
        {
            _v.set(std::tuple{e, Array<crate::syntax::Arg>{}});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto qk = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = callee.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            _v.set(({
                auto&& _q_opt = crate::check::env::resolve_value(lx.g, lx.home, n);
                auto&& q_opt = std::get<0>(_q_opt);
                or_(q_opt, Text::lit(""));
            }));
            goto _done;
        }
        {
            _v.set(Text::lit(""));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto target_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Nat>> _v;
        if (prism_rtl::is_some(bound_opt) && prism_rtl::is<crate::lower::Bn::BnEv>(prism_rtl::some_of(bound_opt))) {
            auto&& er = prism_rtl::as<crate::lower::Bn::BnEv>(prism_rtl::some_of(bound_opt)).a0;
            _v.set(std::optional(er.node_));
            goto _done;
        }
        {
            _v.set(std::optional<Nat>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto param_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<crate::lower::Bn>> _v;
        auto&& _m = callee.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            _v.set(len(n->path_) == Nat(1u)
                ? crate::prelude::get(menv->names, crate::check::env::sname_key(n))
                : std::optional<crate::lower::Bn>{});
            goto _done;
        }
        {
            _v.set(std::optional<crate::lower::Bn>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    if (prism_rtl::is_some(param_opt) && prism_rtl::is<crate::lower::Bn::BnWidget>(prism_rtl::some_of(param_opt))) {
        auto&& x = prism_rtl::as<crate::lower::Bn::BnWidget>(prism_rtl::some_of(param_opt)).a0;
        auto&& cbenv = prism_rtl::as<crate::lower::Bn::BnWidget>(prism_rtl::some_of(param_opt)).a1;
        auto&& cmenv = prism_rtl::as<crate::lower::Bn::BnWidget>(prism_rtl::some_of(param_opt)).a2;
        auto&& clx = prism_rtl::as<crate::lower::Bn::BnWidget>(prism_rtl::some_of(param_opt)).a3;
        return apply_widget_param(wx, x, cbenv, cmenv, clx, len(args));
    }
    {
        return widget_call(wx, benv, menv, e, bound_opt, qk, args, target_opt);
    }
}


prism_rtl::Turn<std::tuple<Wx, Wres>> WidgetLine::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& e = this->e;
    const auto& bound_opt = this->bound_opt;
    auto lx = wx.lx;
    auto [callee, args] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::syntax::Expr, Array<crate::syntax::Arg>>> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
            auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
            auto&& xs = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
            _v.set(std::tuple{c, xs});
            goto _done;
        }
        {
            _v.set(std::tuple{e, Array<crate::syntax::Arg>{}});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto qk = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = callee.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            _v.set(({
                auto&& _q_opt = crate::check::env::resolve_value(lx.g, lx.home, n);
                auto&& q_opt = std::get<0>(_q_opt);
                or_(q_opt, Text::lit(""));
            }));
            goto _done;
        }
        {
            _v.set(Text::lit(""));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto target_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Nat>> _v;
        if (prism_rtl::is_some(bound_opt) && prism_rtl::is<crate::lower::Bn::BnEv>(prism_rtl::some_of(bound_opt))) {
            auto&& er = prism_rtl::as<crate::lower::Bn::BnEv>(prism_rtl::some_of(bound_opt)).a0;
            _v.set(std::optional(er.node_));
            goto _done;
        }
        {
            _v.set(std::optional<Nat>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto param_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<crate::lower::Bn>> _v;
        auto&& _m = callee.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            _v.set(len(n->path_) == Nat(1u)
                ? crate::prelude::get(menv->names, crate::check::env::sname_key(n))
                : std::optional<crate::lower::Bn>{});
            goto _done;
        }
        {
            _v.set(std::optional<crate::lower::Bn>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return ({
        prism_rtl::is_some(param_opt) && prism_rtl::is<crate::lower::Bn::BnWidget>(prism_rtl::some_of(param_opt)) ? ({
        auto&& x = prism_rtl::as<crate::lower::Bn::BnWidget>(prism_rtl::some_of(param_opt)).a0;
        auto&& cbenv = prism_rtl::as<crate::lower::Bn::BnWidget>(prism_rtl::some_of(param_opt)).a1;
        auto&& cmenv = prism_rtl::as<crate::lower::Bn::BnWidget>(prism_rtl::some_of(param_opt)).a2;
        auto&& clx = prism_rtl::as<crate::lower::Bn::BnWidget>(prism_rtl::some_of(param_opt)).a3;
        prism_rtl::finished(apply_widget_param(wx, x, cbenv, cmenv, clx, len(args)));
    })
        : prism_rtl::finished(widget_call(wx, benv, menv, e, bound_opt, qk, args, target_opt));
    });
}


/// `Start WidgetLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Wx, Wres>> start_widget_line(Wx wx, crate::lower::Env benv, crate::lower::Env menv, crate::syntax::Expr e, std::optional<crate::lower::Bn> bound_opt) {
    return prism_rtl::make_rc<WidgetLine>(wx, benv, menv, e, bound_opt);
}


/// ApplyWidgetParam: unbounded fn Wx, Expr, Env, Env, Lx, Nat -> ((Wx, Wres))
std::tuple<Wx, Wres> apply_widget_param(const Wx& wx, const crate::syntax::Expr& x, const crate::lower::Env& cbenv, const crate::lower::Env& cmenv, const crate::lower::Lx& clx, const Nat& nargs) {
    return nargs > Nat(0u)
        ? ({
        auto wx2 = ({
            Wx this_ = wx;
            this_.build = crate::prelude::push(this_.build, crate::lower::refusal_do(Text::lit("a widget parameter applied to arguments")));
            this_;
        });
        std::tuple{wx2, Wres(Wres::WrUnit{})};
    })
        : wx.depth > Nat(32u)
        ? std::tuple{wx, Wres(Wres::WrUnit{})}
        : ({
        auto lx = wx.lx;
        auto inner = ({
            Wx this_ = wx;
            this_.lx = clx;
            this_.depth = this_.depth + Nat(1u);
            this_;
        });
        auto [done, res] = build_line(inner, cbenv, cmenv, x, std::optional<crate::lower::Bn>{});
        auto back_ = ({
            Wx this_ = done;
            this_.lx = lx;
            this_.depth = wx.depth;
            this_;
        });
        std::tuple{back_, res};
    });
}


/// InlineBlock: unbounded fn Wx, Env, Env, Block, Lx -> ((Wx, Wres))
std::tuple<Wx, Wres> inline_block(const Wx& wx, const crate::lower::Env& benv, const crate::lower::Env& menv, const crate::syntax::Block& b, const crate::lower::Lx& lx) {
    auto inner = ({
        Wx this_ = wx;
        this_.result = Wres(Wres::WrUnit{});
        this_;
    });
    auto done = block_into(inner, benv, menv, b);
    auto back_ = ({
        Wx this_ = done;
        this_.result = wx->result;
        this_;
    });
    return std::tuple{back_, done->result};
}


prism_rtl::Turn<std::tuple<Wx, Wres>> InlineBlock::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& b = this->b;
    const auto& lx = this->lx;
    auto inner = ({
        Wx this_ = wx;
        this_.result = Wres(Wres::WrUnit{});
        this_;
    });
    auto b_1 = b;
    auto benv_2 = benv;
    auto menv_3 = menv;
    auto wx_4 = wx;
    return call_then(start_block_into(inner, benv_2, menv_3, b_1), [=](Wx block_into_50040) {
        return ({
            auto done = block_into_50040;
            auto back_ = ({
                Wx this_ = done;
                this_.result = wx_4->result;
                this_;
            });
            (prism_rtl::finished(std::tuple{back_, done->result}));
        });
    });
}


/// `Start InlineBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Wx, Wres>> start_inline_block(Wx wx, crate::lower::Env benv, crate::lower::Env menv, crate::syntax::Block b, crate::lower::Lx lx) {
    return prism_rtl::make_rc<InlineBlock>(wx, benv, menv, b, lx);
}


/// WidgetCall: unbounded fn Wx, Env, Env, Expr, ?Bn, Text, [Arg], ?Nat -> ((Wx, Wres))
std::tuple<Wx, Wres> widget_call(const Wx& wx, const crate::lower::Env& benv, const crate::lower::Env& menv, const crate::syntax::Expr& e, const std::optional<crate::lower::Bn>& bound_opt, const Text& qk, const Array<crate::syntax::Arg>& args, const std::optional<Nat>& target_opt) {
    auto lx = wx.lx;
    {
        auto&& m50324_0 = qk;
        if (m50324_0 == Text::lit("Prelude.@started")) {
            return started_line(wx, bound_opt);
        }
    }
    {
        auto&& m50324_1 = qk;
        if (m50324_1 == Text::lit("Prelude.@Switch")) {
            return switch_line(wx, menv, args);
        }
    }
    {
        auto&& m50324_2 = qk;
        if (m50324_2 == Text::lit("Prelude.@Flatten")) {
            return flatten_line(wx, menv, args, bound_opt);
        }
    }
    {
        auto&& m50324_3 = qk;
        if (m50324_3 == Text::lit("Prelude.@Defer")) {
            return defer_line(wx, menv, args, e, target_opt);
        }
    }
    {
        auto&& m50324_4 = qk;
        if (m50324_4 == Text::lit("Prelude.@Run")) {
            return run_line(wx, benv, args, e, target_opt);
        }
    }
    {
        auto&& m50324_5 = qk;
        if (m50324_5 == Text::lit("Prelude.@Machine")) {
            return machine_line(wx, benv, menv, args, e, target_opt);
        }
    }
    {
        auto&& m50324_6 = qk;
        if (m50324_6 == Text::lit("Prelude.@HostDocument")) {
            return host_line(wx, benv, menv, HostForm(HostForm::HostEach{}), args, bound_opt);
        }
    }
    {
        auto&& m50324_7 = qk;
        if (m50324_7 == Text::lit("Prelude.@HostSome")) {
            return host_line(wx, benv, menv, HostForm(HostForm::HostSome{}), args, bound_opt);
        }
    }
    {
        auto&& _m = crate::prelude::get(lx.g.vals, qk);
        if (prism_rtl::is_some(_m)) {
            auto&& v_ = prism_rtl::some_of(_m);
            return inline_widget(wx, benv, menv, qk, v_, args, e);
        }
        if (prism_rtl::is_none(_m)) {
            auto wx2 = ({
                Wx this_ = wx;
                this_.build = crate::prelude::push(this_.build, crate::lower::refusal_do(Text::lit("a widget this back end does not lower yet")));
                this_;
            });
            return std::tuple{wx2, Wres(Wres::WrUnit{})};
        }
        prism_rtl::unreachable("no arm matched");
    }
}


/// HostLine: unbounded fn Wx, Env, Env, HostForm, [Arg], ?Bn -> ((Wx, Wres))
std::tuple<Wx, Wres> host_line(const Wx& wx, const crate::lower::Env& benv, const crate::lower::Env& menv, const HostForm& form, const Array<crate::syntax::Arg>& args, const std::optional<crate::lower::Bn>& bound_opt) {
    auto lx = wx.lx;
    auto pos = wx.pos;
    auto k = len(wx.scopes) + Nat(1u);
    auto hf = prism_rtl::cat("host_", k);
    auto rows_name = prism_rtl::cat(hf, "_rows");
    auto doc_getter = prism_rtl::cat(hf, "_doc");
    auto wx1 = ({
        Wx this_ = wx;
        this_.taken = append(this_.taken, Array(std::vector{hf, rows_name, doc_getter, prism_rtl::cat(doc_getter, "_now"), prism_rtl::cat(doc_getter, "_snap"), prism_rtl::cat(doc_getter, "_direct"), prism_rtl::cat(doc_getter, "_publish"), prism_rtl::cat(hf, "_answer"), prism_rtl::cat(hf, "_moved")}));
        this_;
    });
    auto named = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = index(args, Nat(1u));
        if (prism_rtl::is_some(_m)) {
            auto&& sup = prism_rtl::some_of(_m);
            _v.set(is_widget_name(sup->value));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& _m = std::tuple{index(args, Nat(0u)), index(args, Nat(1u))};
    if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
        if (named) {
            auto wx2 = ({
                Wx this_ = wx1;
                this_.pos = crate::lower::model::next_pos(this_.pos);
                this_.build = crate::prelude::push(this_.build, crate::lower::refusal_do(Text::lit("a named widget function as a host's supplier (gap NS): a lambda supplier is lowered, a widget function is not a value")));
                this_;
            });
            return std::tuple{wx2, Wres(Wres::WrHosted{prism_rtl::rc(Wres(Wres::WrUnit{})), crate::lower::Bn(crate::lower::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::Holding(crate::lower::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})})})};
        }
    }
    if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
        auto&& child = prism_rtl::some_of(std::get<0>(_m));
        auto&& sup = prism_rtl::some_of(std::get<1>(_m));
        auto [wxd, dyn_env, dyn_lets] = dynamic_answers(wx1, benv, menv, hf, sup->value);
        auto offered = crate::lower::own(crate::lower::value_of(lx, dyn_env, sup->value));
        auto supplier0 = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::Ex> _v;
            if (prism_rtl::is<HostForm::HostEach>(form)) {
                _v.set(offered);
                goto _done;
            }
            if (prism_rtl::is<HostForm::HostSome>(form)) {
                _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::forward_on_none"), Array(std::vector{offered})}));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto supplier = len(dyn_lets) == Nat(0u)
            ? supplier0
            : crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dyn_lets, prism_rtl::rc(supplier0)});
        auto enclosing = emits(wx, pos)
            ? crate::lower::model::Ex(crate::lower::model::Ex::XNone{})
            : crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{host_local(wx, pos)}))})), crate::lower::host_of_ty()})})});
        auto made = crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::Host::new"), Array(std::vector{place_at(wx, Text::lit(""), pos), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{rows_name}))}), supplier, enclosing, crate::lower::model::Ex(crate::lower::model::Ex::XPath{prism_rtl::cat(wx.node_, "::", doc_getter, "_direct")}), crate::lower::model::Ex(crate::lower::model::Ex::XPath{prism_rtl::cat(wx.node_, "::", hf, "_answer")})})});
        auto host_ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutRc{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("prism_rtl::Host"), Array(std::vector{crate::lower::elem_ty(), crate::lower::answer_ty_value(), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{wx.node_, Array<crate::lower::model::OutTy>{}})})}))});
        auto rows_ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("prism_rtl::Rows"), Array(std::vector{crate::lower::elem_ty(), crate::lower::answer_ty_value()})});
        auto doc_ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutPath{})), prism_rtl::rc(crate::lower::elem_ty())});
        auto what = prism_rtl::cat("the document of the child hosted at place ", crate::lower::model::place_text(pos));
        auto wx2 = ({
            Wx this_ = wxd;
            this_.pos = crate::lower::model::next_pos(this_.pos);
            this_.lets = append(this_.lets, Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{rows_name})), rows_ty}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("RefCell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Map::new"), Array<crate::lower::model::Ex>{}})})})})})}), crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{hf}), made})}));
            this_.fields = append(this_.fields, Array(std::vector{std::tuple{hf, host_ty, prism_rtl::cat("the host at place ", crate::lower::model::place_text(pos), ": its supplier, its rows, and the way back into its child (pick HO)")}, std::tuple{rows_name, rows_ty, prism_rtl::cat("the rows of the host at place ", crate::lower::model::place_text(pos), ": `for p, e <- $doc`, one supplier blueprint per child place")}, std::tuple{prism_rtl::cat(doc_getter, "_snap"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutSnapshot{prism_rtl::rc(doc_ty)}), prism_rtl::cat("`$doc` of the host at place ", crate::lower::model::place_text(pos), ", a structural dynamic: its snapshots, the structure and the lagged dynamic (pick ST)")}}));
            this_.moves = append(this_.moves, Array(std::vector{std::tuple{hf, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{hf}))})}, std::tuple{rows_name, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{rows_name}))})}}));
            this_.inits = crate::prelude::push(this_.inits, std::tuple{prism_rtl::cat(doc_getter, "_snap"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Snapshot::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{what})})})});
            this_.hosts = crate::prelude::push(this_.hosts, HostDef{.pos = pos, .name = hf, .scope = k});
            this_.snaps = crate::prelude::push(this_.snaps, SnapDef{.name = doc_getter, .live = prism_rtl::cat(doc_getter, "_now"), .ty = doc_ty, .eq = true, .builder = rows_name, .before = true, .what = what});
            this_.getters = append(this_.getters, Array(std::vector{snap_getter(doc_getter, doc_ty, prism_rtl::cat("The document of the child hosted at place ", crate::lower::model::place_text(pos), ", `$doc`, a structural dynamic (pick ST): one tick behind the child's structure, the snapshot of the tick before the tick the read point is after.")), crate::lower::model::MethDef{.name = prism_rtl::cat(doc_getter, "_direct"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = doc_ty, .body = Array<crate::lower::model::Do>{}, .tail = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(doc_getter, "_snap")})), Text::lit("current"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), .doc = prism_rtl::cat("The structure of the child hosted at place ", crate::lower::model::place_text(pos), ", not the lagged `$doc`: the snapshot taken in this tick's construction step, the document as the tick opened during propagation. The host's own `for` and its rows' entries read it, so a newborn child place gets its row in the tick it is born (pick ST).")}}));
            this_.scopes = crate::prelude::push(this_.scopes, hf);
            this_.builders = crate::prelude::push(this_.builders, crate::lower::model::ForDef{.name = rows_name, .pos = pos, .at = place_at(wx, Text::lit("self"), pos), .key_ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutPath{}), .value_ty = crate::lower::elem_ty(), .row_node = Text::lit("prism_rtl::HostRow::<crate::Elem, crate::Answer>"), .keyed = true, .source = prism_rtl::cat(doc_getter, "_direct"), .parent = crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), hf}))}), .passed = Array<crate::lower::model::Ex>{}});
            this_.build_holds = add_read(this_.build_holds, Read(Read::OwnRead{prism_rtl::cat(doc_getter, "_now")}));
            this_.row_marks = crate::prelude::push(this_.row_marks, RowMarks{.builder = rows_name, .reads = Array(std::vector{Read(Read::OwnRead{prism_rtl::cat(doc_getter, "_now")})}), .wrote = Array<Text>{}, .kind = crate::lower::model::RowKind(crate::lower::model::RowKind::ForRow{})});
            this_.fallible = true;
            this_;
        });
        auto inner = ({
            Wx this_ = wx2;
            this_.pos = crate::lower::model::scope_pos(k);
            this_.result = Wres(Wres::WrUnit{});
            this_;
        });
        auto [done, res] = build_line(inner, benv, menv, child->value, std::optional<crate::lower::Bn>{});
        auto child_places = drop(done.places, len(wx2.places));
        auto child_builds = filter(done.build_holds, [&](const Read& h) { return !has_read(wx2.build_holds, h); });
        auto child_gens = fold(drop(done.gen_holds, len(wx2.gen_holds)), Array<Read>{}, [&](const Array<Read>& acc, const std::tuple<Text, Array<Read>>& _p1) {
            auto&& hs = std::get<1>(_p1);
            return union_reads(acc, hs);
        });
        auto child_rows = fold(drop(done.row_marks, len(wx2.row_marks)), Array<Read>{}, [&](const Array<Read>& acc, const RowMarks& rm) { return union_reads(acc, rm.reads); });
        auto doc_reads = fold(child_places, union_reads(union_reads(child_builds, child_gens), child_rows), [&](const Array<Read>& acc, const Place& pl) { return union_reads(acc, pl.reads); });
        auto in_scope_fn = ({
            auto k_1 = k;
            (prism_rtl::rc([=](const crate::lower::model::Pos_& p_) { return p_.scope == k_1; }));
        });
        auto getter = host_doc_getter(prism_rtl::cat(doc_getter, "_now"), pos, filter(child_places, [&](const Place& pl) { return in_scope_fn(pl.pos); }), filter(drop(done.builders, len(wx2.builders)), [&](const crate::lower::model::ForDef& b) { return in_scope_fn(b.pos); }), filter(drop(done.gens, len(wx2.gens)), [&](const crate::lower::model::GenDef& gd) { return in_scope_fn(gd.pos); }));
        auto back_ = ({
            Wx this_ = done;
            this_.pos = wx2.pos;
            this_.result = wx->result;
            this_.getters = crate::prelude::push(this_.getters, getter);
            this_.dyn_reads = insert(this_.dyn_reads, prism_rtl::cat(doc_getter, "_now"), doc_reads);
            this_;
        });
        auto doc_bn = crate::lower::Bn(crate::lower::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), doc_getter, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{Read(Read::OwnRead{doc_getter})}), doc_ty});
        return std::tuple{back_, Wres(Wres::WrHosted{prism_rtl::rc(res), doc_bn})};
    }
    {
        auto wx2 = ({
            Wx this_ = wx1;
            this_.pos = crate::lower::model::next_pos(this_.pos);
            this_.build = crate::prelude::push(this_.build, crate::lower::refusal_do(Text::lit("a host without its child or its supplier")));
            this_;
        });
        return std::tuple{wx2, Wres(Wres::WrHosted{prism_rtl::rc(Wres(Wres::WrUnit{})), crate::lower::Bn(crate::lower::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::Holding(crate::lower::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})})})};
    }
}


/// IsWidgetName: fn Expr -> Bool
bool is_widget_name(const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return crate::syntax::lexer::has_prefix(crate::check::env::sname_key(n), Text::lit("@"));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return is_widget_name(x);
    }
    {
        return false;
    }
}


/// DynamicAnswers: unbounded fn Wx, Env, Env, Text, Expr -> ((Wx, Env, [Do]))
std::tuple<Wx, crate::lower::Env, Array<crate::lower::model::Do>> dynamic_answers(const Wx& wx, const crate::lower::Env& benv, const crate::lower::Env& menv, const Text& hf, const crate::syntax::Expr& sup) {
    auto lx = wx.lx;
    auto dyns = fold(crate::check::typed::exprs_in(sup), Array<std::tuple<crate::syntax::Expr, crate::syntax::Expr>>{}, [&](const Array<std::tuple<crate::syntax::Expr, crate::syntax::Expr>>& acc, const crate::syntax::Expr& x) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<crate::syntax::Expr, crate::syntax::Expr>>> _v;
            auto&& _m = x.kind;
            if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
                auto&& m60487_0_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
                auto&& y = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
                if (m60487_0_0 == Text::lit("@")) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Array<std::tuple<crate::syntax::Expr, crate::syntax::Expr>>> _v;
                        auto&& _m = dynamic_answer(lx, y);
                        if (prism_rtl::is_some(_m)) {
                            auto&& d = prism_rtl::some_of(_m);
                            _v.set(crate::prelude::push(acc, std::tuple{y, d}));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(acc);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return len(dyns) == Nat(0u)
        ? std::tuple{wx, benv, Array<crate::lower::model::Do>{}}
        : ({
        auto owner = prism_rtl::cat(hf, "_owner");
        auto wx1 = ({
            Wx this_ = wx;
            this_.taken = crate::prelude::push(this_.taken, owner);
            this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{owner}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{prism_rtl::cat("prism_rtl::Link::<", wx.node_, ">::new"), Array<crate::lower::model::Ex>{}})}));
            this_.build = crate::prelude::push(this_.build, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{owner})), Text::lit("link"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")}))})})})}));
            this_;
        });
        auto env0 = crate::lower::bind(benv, Text::lit("#owner"), crate::lower::Bn(crate::lower::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{owner}), crate::lower::Holding(crate::lower::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}));
        auto lets0 = Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{owner}), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{owner}))})})});
        run_to_end(fold_job(crate::check::errors::range0(len(dyns)), std::tuple{wx1, env0, lets0}, ({
        auto dyns_1 = dyns;
        auto hf_2 = hf;
        auto menv_3 = menv;
        auto lx_4 = lx;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Wx, crate::lower::Env, Array<crate::lower::model::Do>>>(std::tuple<std::tuple<Wx, crate::lower::Env, Array<crate::lower::model::Do>>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Wx, crate::lower::Env, Array<crate::lower::model::Do>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto dyns_1_5 = dyns_1;
            auto hf_2_5 = hf_2;
            auto menv_3_5 = menv_3;
            auto lx_4_5 = lx_4;
            entered(once_job([=]() {
            return ({
                auto [w, en, ls] = p0;
                auto j = p1;
                ({
                auto&& _m = index(dyns_1_5, j);
                prism_rtl::is_some(_m) ? ({
                auto&& y = std::get<0>(prism_rtl::some_of(_m));
                auto&& d = std::get<1>(prism_rtl::some_of(_m));
                ({
                auto name = prism_rtl::cat(hf_2_5, "_dyn_", j + Nat(1u));
                auto port = prism_rtl::cat(name, "_port");
                call_then(start_dynamic_expr(w, menv_3_5, d), [=](std::tuple<crate::lower::model::Ex, Array<Read>> dynamic_expr_61399) {
                return ({
                    auto [ex, reads] = dynamic_expr_61399;
                    call_then(crate::lower::start_out_ty_of(lx_4_5, crate::lower::peel(crate::lower::type_at(lx_4_5, d.span))), [=](crate::lower::model::OutTy out_ty_of_61446) {
                    return ({
                        auto t = out_ty_of_61446;
                        !all_inited(w, reads)
                        ? prism_rtl::finished(std::tuple{w, en, ls})
                        : ({
                        auto w2 = ({
                            Wx this_ = w;
                            this_.taken = append(this_.taken, Array(std::vector{name, port}));
                            this_.getters = crate::prelude::push(this_.getters, crate::lower::model::MethDef{.name = name, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = t, .body = Array<crate::lower::model::Do>{}, .tail = ex, .doc = prism_rtl::cat("The host at `", hf_2_5, "`'s dynamic answer `", crate::lower::src_text(lx_4_5, lx_4_5->file, y.span), "`, read at the read point (round 3 DY).")});
                            this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{port})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRc{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutPort{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))}))})}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Port::new"), Array<crate::lower::model::Ex>{}})})})}));
                            this_.fields = crate::prelude::push(this_.fields, std::tuple{port, crate::lower::model::OutTy(crate::lower::model::OutTy::OutRc{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutPort{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))}))}), prism_rtl::cat("the dynamic answer `", name, "` moved: its blueprints push the child's place next tick")});
                            this_.moves = crate::prelude::push(this_.moves, std::tuple{port, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{port}))})});
                            this_.dyn_answers = crate::prelude::push(this_.dyn_answers, std::tuple{name, reads});
                            this_;
                        });
                        (prism_rtl::finished(std::tuple{w2, crate::lower::bind(en, prism_rtl::cat("#dyn", dyn_key(y)), crate::lower::Bn(crate::lower::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{name}), crate::lower::Holding(crate::lower::Holding::Owned{}), t})), crate::prelude::push(ls, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{port}), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{port}))})}))}));
                    });
                    });
                });
                });
            });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{w, en, ls})
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })));
    });
}


/// ?DynamicAnswer: fn Lx, Expr -> ?Expr
std::optional<crate::syntax::Expr> dynamic_answer(const crate::lower::Lx& lx, const crate::syntax::Expr& x) {
    return crate::lower::layer_of(crate::lower::type_at(lx, x.span)) != crate::lower::Layer(crate::lower::Layer::LyDyn{})
        ? std::optional<crate::syntax::Expr>{}
        : ({
        __label__ _done;
        prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
        auto&& _m = x.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
            auto&& m62876_0_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
            auto&& inner = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
            if (m62876_0_0 == Text::lit("$")) {
                _v.set(crate::lower::layer_of(crate::lower::type_at(lx, inner.span)) == crate::lower::Layer(crate::lower::Layer::LyDyn{})
                    ? std::optional(inner)
                    : std::optional<crate::syntax::Expr>{});
                goto _done;
            }
        }
        {
            _v.set(std::optional(x));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// DynKey: fn Expr -> Text
Text dyn_key(const crate::syntax::Expr& x) {
    return prism_rtl::cat(x.span.start, ":", x.span.end);
}


/// HostDocGetter: fn Text, Pos, [Place], [ForDef], [GenDef] -> MethDef
crate::lower::model::MethDef host_doc_getter(const Text& name, const crate::lower::model::Pos_& pos, const Array<Place>& places, const Array<crate::lower::model::ForDef>& builders, const Array<crate::lower::model::GenDef>& gens) {
    auto start = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("doc")})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutPath{})), prism_rtl::rc(crate::lower::elem_ty())})}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Map::new"), Array<crate::lower::model::Ex>{}})});
    auto body = document_body(({
        auto f = prism_rtl::rc(map_insert);
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Do>(std::tuple<crate::lower::model::Ex, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<crate::lower::model::Ex, crate::lower::model::Ex> _p0) {
        auto&& a0 = std::get<0>(_p0);
        auto&& a1 = std::get<1>(_p0);
        return ({
            auto f_1 = f;
            once_job([=]() { return prism_rtl::finished(f_1(a0, a1)); });
        });
    })));
    }), places, builders, gens);
    return crate::lower::model::MethDef{.name = name, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutPath{})), prism_rtl::rc(crate::lower::elem_ty())}), .body = append(Array(std::vector{start}), body), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("doc")}), .doc = prism_rtl::cat("The document of the child hosted at place ", crate::lower::model::place_text(pos), " computed live: each of its places by its path relative to the child, its level at the read point (pick HO). Read only by the snapshot `$doc` answers from (pick ST).")};
}


/// SnapGetter: fn Text, OutTy, Text -> MethDef
crate::lower::model::MethDef snap_getter(const Text& name, const crate::lower::model::OutTy& t, const Text& doc) {
    return crate::lower::model::MethDef{.name = name, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = t, .body = Array<crate::lower::model::Do>{}, .tail = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(name, "_snap")})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), .doc = doc};
}


/// StartedLine: fn Wx, ?Bn -> ((Wx, Wres))
std::tuple<Wx, Wres> started_line(const Wx& wx, const std::optional<crate::lower::Bn>& bound_opt) {
    auto wx1 = ({
        Wx this_ = wx;
        this_.pos = crate::lower::model::next_pos(this_.pos);
        this_;
    });
    auto [id, wx2] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Nat, Wx>> _v;
        if (prism_rtl::is_some(bound_opt) && prism_rtl::is<crate::lower::Bn::BnEv>(prism_rtl::some_of(bound_opt))) {
            auto&& er = prism_rtl::as<crate::lower::Bn::BnEv>(prism_rtl::some_of(bound_opt)).a0;
            _v.set(std::tuple{er.node_, wx1});
            goto _done;
        }
        {
            _v.set(({
                auto [nm, w] = fresh_name(wx1, Text::lit("started"));
                add_gn(w, nm, crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), GnKind(GnKind::GnStarted{}), Nat(0u));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto wx3 = ({
        Wx this_ = wx2;
        this_.started = crate::prelude::push(this_.started, id);
        this_;
    });
    return std::tuple{wx3, Wres(Wres::WrEv{ev_ref_of(wx3, id)})};
}


/// DeferLine: unbounded fn Wx, Env, [Arg], Expr, ?Nat -> ((Wx, Wres))
std::tuple<Wx, Wres> defer_line(const Wx& wx, const crate::lower::Env& menv, const Array<crate::syntax::Arg>& args, const crate::syntax::Expr& e, const std::optional<Nat>& target_opt) {
    auto lx = wx.lx;
    auto t = crate::lower::out_ty_of(lx, crate::lower::out_of(crate::lower::type_at(lx, e.span)));
    auto [field, wx1] = fresh_name(wx, Text::lit("deferred"));
    auto [id, wx2] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Nat, Wx>> _v;
        if (prism_rtl::is_some(target_opt)) {
            auto&& n = prism_rtl::some_of(target_opt);
            _v.set(std::tuple{n, wx1});
            goto _done;
        }
        if (prism_rtl::is_none(target_opt)) {
            _v.set(add_gn(wx1, prism_rtl::cat(field, "_fired"), t, GnKind(GnKind::GnDeferred{}), Nat(0u)));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto wx3 = add_field_last(wx2, field, crate::lower::model::OutTy(crate::lower::model::OutTy::OutDefer{prism_rtl::rc(t)}), Text::lit("`@Defer`"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Defer::new"), Array<crate::lower::model::Ex>{}}));
    auto wx4 = ({
        Wx this_ = wx3;
        this_.defers = crate::prelude::push(this_.defers, std::tuple{field, id});
        this_;
    });
    auto&& _m = index(args, Nat(0u));
    if (prism_rtl::is_some(_m)) {
        auto&& a = prism_rtl::some_of(_m);
        auto [r, wx5] = event_ref(wx4, menv, a->value);
        return std::tuple{connect(wx5, r, Sk(Sk::SkArm{field})), Wres(Wres::WrEv{ev_ref_of(wx5, id)})};
    }
    if (prism_rtl::is_none(_m)) {
        return std::tuple{wx4, Wres(Wres::WrEv{ev_ref_of(wx4, id)})};
    }
    prism_rtl::unreachable("no arm matched");
}


/// RunLine: unbounded fn Wx, Env, [Arg], Expr, ?Nat -> ((Wx, Wres))
std::tuple<Wx, Wres> run_line(const Wx& wx, const crate::lower::Env& benv, const Array<crate::syntax::Arg>& args, const crate::syntax::Expr& e, const std::optional<Nat>& target_opt) {
    auto lx = wx.lx;
    auto t = crate::lower::out_ty_of(lx, crate::lower::out_of(crate::lower::type_at(lx, e.span)));
    auto [p_, wx1] = fresh_name(wx, Text::lit("run"));
    auto wx2 = ({
        Wx this_ = wx1;
        this_.pos = crate::lower::model::next_pos(this_.pos);
        this_.taken = append(this_.taken, Array(std::vector{prism_rtl::cat(p_, "_job"), prism_rtl::cat(p_, "_again"), prism_rtl::cat(p_, "_started"), prism_rtl::cat(p_, "_turn")}));
        this_;
    });
    auto start = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Ex> _v;
        auto&& _m = index(args, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& a = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<crate::lower::model::Ex> _v;
                auto&& _m = a->value.kind;
                if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                    auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                    _v.set(({
                        auto&& _q_opt = crate::check::env::resolve_value(lx.g, lx.home, n);
                        auto&& q_opt = std::get<0>(_q_opt);
                        (crate::lower::model::Ex(crate::lower::model::Ex::XPath{crate::lower::start_path(lx, or_(q_opt, Text::lit("")))}));
                    }));
                    goto _done;
                }
                {
                    _v.set(crate::lower::refusal(Text::lit("an `@Run` of a function value that is not a name")));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::lower::refusal(Text::lit("an `@Run` without its function")));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto x = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Ex> _v;
        auto&& _m = index(args, Nat(1u));
        if (prism_rtl::is_some(_m)) {
            auto&& a = prism_rtl::some_of(_m);
            _v.set(crate::lower::own(crate::lower::value_of(lx, benv, a->value)));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto wx3 = add_field(wx2, prism_rtl::cat(p_, "_job"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutHold{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutJob{prism_rtl::rc(t)}))}), Text::lit("`@Run`'s job (`@Machine`'s state)"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Hold::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XApply{prism_rtl::rc(start), Array(std::vector{x})}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}));
    auto wx4 = add_field_last(wx3, prism_rtl::cat(p_, "_again"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutDefer{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))}), Text::lit("`@Run`'s `!again`"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Defer::new"), Array<crate::lower::model::Ex>{}}));
    auto [s, wx5] = add_gn(wx4, prism_rtl::cat(p_, "_started"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), GnKind(GnKind::GnStarted{}), Nat(0u));
    auto [a, wx6] = add_gn(wx5, prism_rtl::cat(p_, "_again"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), GnKind(GnKind::GnDeferred{}), Nat(0u));
    auto [m, wx7] = crate::lower::node_::merge(wx6, prism_rtl::cat(p_, "_turn"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), ev_ref_of(wx6, s), ev_ref_of(wx6, a));
    auto [res, wx8] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Nat, Wx>> _v;
        if (prism_rtl::is_some(target_opt)) {
            auto&& n = prism_rtl::some_of(target_opt);
            _v.set(std::tuple{n, wx7});
            goto _done;
        }
        if (prism_rtl::is_none(target_opt)) {
            _v.set(add_gn(wx7, prism_rtl::cat(p_, "_done"), t, GnKind(GnKind::GnNamed{}), Nat(0u)));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto wx9 = ({
        Wx this_ = connect(wx8, ev_ref_of(wx8, m), Sk(Sk::SkCycle{prism_rtl::cat(p_, "_job"), prism_rtl::cat(p_, "_again"), res}));
        this_.started = crate::prelude::push(this_.started, s);
        this_.defers = crate::prelude::push(this_.defers, std::tuple{prism_rtl::cat(p_, "_again"), a});
        this_;
    });
    return std::tuple{wx9, Wres(Wres::WrEv{ev_ref_of(wx9, res)})};
}


/// MachineLine: unbounded fn Wx, Env, Env, [Arg], Expr, ?Nat -> ((Wx, Wres))
std::tuple<Wx, Wres> machine_line(const Wx& wx, const crate::lower::Env& benv, const crate::lower::Env& menv, const Array<crate::syntax::Arg>& args, const crate::syntax::Expr& e, const std::optional<Nat>& target_opt) {
    auto lx = wx.lx;
    auto t = crate::lower::out_ty_of(lx, crate::lower::out_of(crate::lower::type_at(lx, e.span)));
    auto [f, wx1] = fresh_name(wx, Text::lit("machine"));
    auto step_ = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(args, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& a = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = a->value.kind;
                if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                    auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                    _v.set(({
                        auto&& _q_opt = crate::check::env::resolve_value(lx.g, lx.home, n);
                        auto&& q_opt = std::get<0>(_q_opt);
                        ({
                        __label__ _done;
                        prism_rtl::Slot<Text> _v;
                        if (prism_rtl::is_some(q_opt)) {
                            auto&& q = prism_rtl::some_of(q_opt);
                            _v.set(crate::lower::value_path(lx, q));
                            goto _done;
                        }
                        if (prism_rtl::is_none(q_opt)) {
                            _v.set(Text::lit(""));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    }));
                    goto _done;
                }
                {
                    _v.set(Text::lit(""));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& _m = std::tuple{step_, index(args, Nat(1u)), index(args, Nat(2u))};
    if (prism_rtl::is_some(std::get<1>(_m)) && prism_rtl::is_some(std::get<2>(_m))) {
        auto&& sp = std::get<0>(_m);
        auto&& init = prism_rtl::some_of(std::get<1>(_m));
        auto&& ev = prism_rtl::some_of(std::get<2>(_m));
        if (sp != Text::lit("")) {
            auto st = crate::lower::out_ty_of(lx, crate::lower::peel(crate::lower::type_at(lx, init->value.span)));
            auto x = crate::lower::own(crate::lower::value_of(lx, benv, init->value));
            auto wx2 = add_field(wx1, prism_rtl::cat(f, "_state"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutHold{prism_rtl::rc(st)}), Text::lit("`@Machine`'s state"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Hold::new"), Array(std::vector{x, crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}));
            auto [out, wx3] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Nat, Wx>> _v;
                if (prism_rtl::is_some(target_opt)) {
                    auto&& n = prism_rtl::some_of(target_opt);
                    _v.set(std::tuple{n, wx2});
                    goto _done;
                }
                if (prism_rtl::is_none(target_opt)) {
                    _v.set(add_gn(wx2, prism_rtl::cat(f, "_fired"), t, GnKind(GnKind::GnNamed{}), Nat(0u)));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto [r, wx4] = event_ref(wx3, menv, ev->value);
            return std::tuple{connect(wx4, r, Sk(Sk::SkMachine{prism_rtl::cat(f, "_state"), sp, out})), Wres(Wres::WrEv{ev_ref_of(wx4, out)})};
        }
    }
    {
        auto wx2 = ({
            Wx this_ = wx1;
            this_.build = crate::prelude::push(this_.build, crate::lower::refusal_do(Text::lit("an `@Machine` whose step is not a named function")));
            this_;
        });
        return std::tuple{wx2, Wres(Wres::WrUnit{})};
    }
}


/// InlineWidget: unbounded fn Wx, Env, Env, Text, ValInfo, [Arg], Expr -> ((Wx, Wres))
std::tuple<Wx, Wres> inline_widget(const Wx& wx, const crate::lower::Env& benv, const crate::lower::Env& menv, const Text& qk, const crate::check::env::ValInfo& v_, const Array<crate::syntax::Arg>& args, const crate::syntax::Expr& e) {
    auto lx = wx.lx;
    auto clauses = crate::lower::clauses_of(lx.g, qk);
    auto w_opt = widget_decl_of(lx.g, qk);
    auto [params, body_opt] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::syntax::Pattern_>, std::optional<crate::syntax::Block>>> _v;
        if (prism_rtl::is_some(w_opt)) {
            auto&& wd = prism_rtl::some_of(w_opt);
            _v.set(std::tuple{Array<crate::syntax::Pattern_>{}, std::optional(wd.body)});
            goto _done;
        }
        if (prism_rtl::is_none(w_opt)) {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<crate::syntax::Pattern_>, std::optional<crate::syntax::Block>>> _v;
                {
                    auto&& m69812_0 = clauses;
                    if (m69812_0.size() == 1u) {
                        {
                            auto&& _c1 = index(m69812_0, Nat(0u));
                            if (prism_rtl::is_some(_c1)) {
                                auto&& c = prism_rtl::some_of(_c1);
                                _v.set(({
                                    __label__ _done;
                                    prism_rtl::Slot<std::tuple<Array<crate::syntax::Pattern_>, std::optional<crate::syntax::Block>>> _v;
                                    auto&& _m = c.body;
                                    if (prism_rtl::is<crate::syntax::FnBody::BodyBlock>(_m)) {
                                        auto&& b = prism_rtl::as<crate::syntax::FnBody::BodyBlock>(_m).a0;
                                        _v.set(std::tuple{c.params, std::optional(b)});
                                        goto _done;
                                    }
                                    if (prism_rtl::is<crate::syntax::FnBody::BodyExpr>(_m)) {
                                        auto&& x = prism_rtl::as<crate::syntax::FnBody::BodyExpr>(_m).a0;
                                        _v.set(std::tuple{c.params, std::optional(crate::syntax::Block{.stmts = Array(std::vector{crate::syntax::Stmt{.kind = crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{x}), .span = x.span}}), .inline_ = true, .span = x.span})});
                                        goto _done;
                                    }
                                    prism_rtl::unreachable("no arm matched");
                                _done:
                                    _v.take();
                                }));
                                goto _done;
                            }
                        }
                    }
                }
                {
                    _v.set(std::tuple{Array<crate::syntax::Pattern_>{}, std::optional<crate::syntax::Block>{}});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    if (prism_rtl::is_none(body_opt)) {
        return len(clauses) == Nat(0u)
            ? ({
            auto wx2 = ({
                Wx this_ = wx;
                this_.build = crate::prelude::push(this_.build, crate::lower::refusal_do(prism_rtl::cat("the builtin widget ", crate::check::types::bare_name(qk))));
                this_;
            });
            std::tuple{wx2, Wres(Wres::WrUnit{})};
        })
            : ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Wx, Wres>> _v;
            auto&& _m = index(args, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& a = prism_rtl::some_of(_m);
                _v.set(({
                    auto call = crate::syntax::Block{.stmts = Array(std::vector{crate::syntax::Stmt{.kind = crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{e}), .span = e.span}}), .inline_ = true, .span = e.span};
                    clause_widget_line(wx, menv, a->value, call, qk, v_, e);
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(({
                    auto wx2 = ({
                        Wx this_ = wx;
                        this_.build = crate::prelude::push(this_.build, crate::lower::refusal_do(Text::lit("a widget of several clauses that takes no arguments")));
                        this_;
                    });
                    std::tuple{wx2, Wres(Wres::WrUnit{})};
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_some(body_opt)) {
        auto&& body = prism_rtl::some_of(body_opt);
        return wx.depth > Nat(16u)
            ? std::tuple{wx, Wres(Wres::WrUnit{})}
            : ({
            auto lxc = crate::lower::in_module_at(lx, v_->file, v_.home, lx.site);
            auto ptys = ({
                __label__ _done;
                prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
                auto&& _m = v_.scheme.ty;
                if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
                    auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
                    _v.set(ps);
                    goto _done;
                }
                {
                    _v.set(Array<crate::check::types::Ty>{});
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto [wx1, be1, me1] = run_to_end(fold_job(crate::check::errors::range0(len(params)), std::tuple{wx, crate::lower::empty_env(), crate::lower::empty_env()}, ({
                auto params_1 = params;
                auto lxc_2 = lxc;
                auto ptys_3 = ptys;
                auto args_4 = args;
                auto benv_5 = benv;
                auto menv_6 = menv;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Wx, crate::lower::Env, crate::lower::Env>>(std::tuple<std::tuple<Wx, crate::lower::Env, crate::lower::Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Wx, crate::lower::Env, crate::lower::Env>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto params_1_7 = params_1;
                    auto lxc_2_7 = lxc_2;
                    auto ptys_3_7 = ptys_3;
                    auto args_4_7 = args_4;
                    auto benv_5_7 = benv_5;
                    auto menv_6_7 = menv_6;
                    entered(once_job([=]() {
                    return ({
                        auto [w, be, me] = p0;
                        auto i = p1;
                        ({
                        auto p_ = or_(index(params_1_7, i), crate::lower::dummy_pat());
                        auto nkey = crate::lower::plain_binder(lxc_2_7, p_);
                        auto pty = or_(index(ptys_3_7, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
                        ({
                        auto&& _m = index(args_4_7, i);
                        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{w, be, me})
                        : prism_rtl::is_some(_m) ? ({
                        auto&& a = prism_rtl::some_of(_m);
                        prism_rtl::finished(bind_param(w, benv_5_7, menv_6_7, be, me, nkey, pty, a->value));
                    })
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                    });
                }));
                });
            }));
            })));
            auto inner = ({
                Wx this_ = wx1;
                this_.lx = lxc;
                this_.depth = this_.depth + Nat(1u);
                this_.result = Wres(Wres::WrUnit{});
                this_;
            });
            auto done = block_into(inner, be1, me1, body);
            auto back_ = ({
                Wx this_ = done;
                this_.lx = lx;
                this_.depth = wx.depth;
                this_.result = wx->result;
                this_;
            });
            std::tuple{back_, done->result};
        });
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?WidgetDeclOf: fn G, Text -> ?WidgetDecl
std::optional<crate::syntax::WidgetDecl> widget_decl_of(const crate::check::env::G& g, const Text& qk) {
    return fold(g.defs, std::optional<crate::syntax::WidgetDecl>{}, [&](const std::optional<crate::syntax::WidgetDecl>& found_opt, const crate::check::env::Def& d) { return d.qk == qk ? def_widget(d, found_opt) : found_opt; });
}


/// ?DefWidget: fn Def, ?WidgetDecl -> ?WidgetDecl
std::optional<crate::syntax::WidgetDecl> def_widget(const crate::check::env::Def& d, const std::optional<crate::syntax::WidgetDecl>& other_opt) {
    auto&& _m = d.body;
    if (prism_rtl::is<crate::check::env::DefBody::DbWidget>(_m)) {
        auto&& w = prism_rtl::as<crate::check::env::DefBody::DbWidget>(_m).a0;
        return std::optional(w);
    }
    {
        return other_opt;
    }
}


/// BindParam: unbounded fn Wx, Env, Env, Env, Env, Text, Ty, Expr -> ((Wx, Env, Env))
std::tuple<Wx, crate::lower::Env, crate::lower::Env> bind_param(const Wx& wx, const crate::lower::Env& cbenv, const crate::lower::Env& cmenv, const crate::lower::Env& be, const crate::lower::Env& me, const Text& nkey, const crate::check::types::Ty& pty, const crate::syntax::Expr& arg) {
    auto lx = wx.lx;
    auto t = crate::lower::out_ty_of(lx, crate::lower::peel(pty));
    auto&& _m = crate::lower::layer_of(pty);
    if (prism_rtl::is<crate::lower::Layer::LyBlueprint>(_m)) {
        auto b = crate::lower::Bn(crate::lower::Bn::BnWidget{arg, cbenv, cmenv, lx});
        return std::tuple{wx, crate::lower::bind(be, nkey, b), crate::lower::bind(me, nkey, b)};
    }
    if (prism_rtl::is<crate::lower::Layer::LyEv>(_m)) {
        auto [r, wx2] = event_ref(wx, cmenv, arg);
        auto b = crate::lower::Bn(crate::lower::Bn::BnEv{r, t});
        return std::tuple{wx2, crate::lower::bind(be, nkey, b), crate::lower::bind(me, nkey, b)};
    }
    if (prism_rtl::is<crate::lower::Layer::LyDyn>(_m)) {
        auto [ex, reads] = dynamic_expr(wx, cmenv, arg);
        auto b = crate::lower::Bn(crate::lower::Bn::BnDyn{ex, reads, t});
        return std::tuple{wx, crate::lower::bind(be, nkey, b), crate::lower::bind(me, nkey, b)};
    }
    {
        auto [rs, wx2] = fresh_name(wx, crate::lower::snake(nkey));
        auto v_ = crate::lower::own(crate::lower::value_of(lx, cbenv, arg));
        auto wx3 = ({
            Wx this_ = wx2;
            this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{rs}), v_}));
            this_.fields = crate::prelude::push(this_.fields, std::tuple{rs, t, prism_rtl::cat("`", nkey, "`")});
            this_.inits = crate::prelude::push(this_.inits, std::tuple{rs, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs}))})});
            this_;
        });
        auto [be2, me2] = bind_plain(be, me, nkey, rs, t);
        return std::tuple{wx3, be2, me2};
    }
}


/// DynamicExpr: unbounded fn Wx, Env, Expr -> ((Ex, [Read]))
std::tuple<crate::lower::model::Ex, Array<Read>> dynamic_expr(const Wx& wx, const crate::lower::Env& menv, const crate::syntax::Expr& e) {
    auto v_ = crate::lower::value_of(wx.lx, menv, e);
    auto reads = fold(crate::check::typed::exprs_in(e), Array<Read>{}, [&](const Array<Read>& acc, const crate::syntax::Expr& x) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Read>> _v;
            auto&& _m = x.kind;
            if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<Read>> _v;
                    auto&& _m = crate::prelude::get(menv->names, crate::check::env::sname_key(n));
                    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::Bn::BnHold>(prism_rtl::some_of(_m))) {
                        auto&& f = prism_rtl::as<crate::lower::Bn::BnHold>(prism_rtl::some_of(_m)).a0;
                        _v.set(add_read(acc, Read(Read::OwnRead{f})));
                        goto _done;
                    }
                    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::Bn::BnDyn>(prism_rtl::some_of(_m))) {
                        auto&& rs = prism_rtl::as<crate::lower::Bn::BnDyn>(prism_rtl::some_of(_m)).a1;
                        _v.set(union_reads(acc, rs));
                        goto _done;
                    }
                    {
                        _v.set(acc);
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return std::tuple{crate::lower::own(v_), reads};
}


prism_rtl::Turn<std::tuple<crate::lower::model::Ex, Array<Read>>> DynamicExpr::cycle() const {
    const auto& wx = this->wx;
    const auto& menv = this->menv;
    const auto& e = this->e;
    auto e_1 = e;
    auto menv_2 = menv;
    auto wx_3 = wx;
    return call_then(crate::lower::start_value_of(wx_3.lx, menv_2, e_1), [=](crate::lower::Vl value_of_74755) {
        return ({
            auto v_ = value_of_74755;
            call_then(crate::check::typed::start_exprs_in(e_1), [=](Array<crate::syntax::Expr> exprs_in_74800) {
            return ({
                auto reads = fold(exprs_in_74800, Array<Read>{}, [&](const Array<Read>& acc, const crate::syntax::Expr& x) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Read>> _v;
                        auto&& _m = x.kind;
                        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                            _v.set(({
                                __label__ _done;
                                prism_rtl::Slot<Array<Read>> _v;
                                auto&& _m = crate::prelude::get(menv_2->names, crate::check::env::sname_key(n));
                                if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::Bn::BnHold>(prism_rtl::some_of(_m))) {
                                    auto&& f = prism_rtl::as<crate::lower::Bn::BnHold>(prism_rtl::some_of(_m)).a0;
                                    _v.set(add_read(acc, Read(Read::OwnRead{f})));
                                    goto _done;
                                }
                                if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::Bn::BnDyn>(prism_rtl::some_of(_m))) {
                                    auto&& rs = prism_rtl::as<crate::lower::Bn::BnDyn>(prism_rtl::some_of(_m)).a1;
                                    _v.set(union_reads(acc, rs));
                                    goto _done;
                                }
                                {
                                    _v.set(acc);
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        {
                            _v.set(acc);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                });
                (prism_rtl::finished(std::tuple{crate::lower::own(v_), reads}));
            });
        });
        });
    });
}


/// `Start DynamicExpr, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::model::Ex, Array<Read>>> start_dynamic_expr(Wx wx, crate::lower::Env menv, crate::syntax::Expr e) {
    return prism_rtl::make_rc<DynamicExpr>(wx, menv, e);
}


/// NeverEvent: fn Wx, OutTy -> ((EvRef, Wx))
std::tuple<EvRef, Wx> never_event(const Wx& wx, const crate::lower::model::OutTy& t) {
    auto [id, wx2] = add_gn(wx, Text::lit("never"), t, GnKind(GnKind::GnNever{}), Nat(0u));
    return std::tuple{ev_ref_of(wx2, id), wx2};
}


/// EventRef: unbounded fn Wx, Env, Expr -> ((EvRef, Wx))
std::tuple<EvRef, Wx> event_ref(const Wx& wx, const crate::lower::Env& menv, const crate::syntax::Expr& e) {
    auto lx = wx.lx;
    auto t = crate::lower::out_ty_of(lx, crate::lower::peel(crate::lower::type_at(lx, e.span)));
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return event_ref(wx, menv, x);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        auto&& _m = crate::prelude::get(menv->names, crate::check::env::sname_key(n));
        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::Bn::BnEv>(prism_rtl::some_of(_m))) {
            auto&& r = prism_rtl::as<crate::lower::Bn::BnEv>(prism_rtl::some_of(_m)).a0;
            return r.owner == wx.node_
                ? std::tuple{r, wx}
                : never_event(crossed(wx, prism_rtl::cat("the event `", crate::check::env::sname_key(n), "`, of node `", r.owner, "`,")), t);
        }
        {
            return never_event(wx, t);
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
        auto&& m75664_2_0 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        if (m75664_2_0 == Text::lit("<|")) {
            auto [lr, w1] = event_ref(wx, menv, l);
            auto [rr, w2] = event_ref(w1, menv, r);
            auto [nm, w3] = fresh_name(w2, Text::lit("anon"));
            auto [id, w4] = crate::lower::node_::merge(w3, nm, t, lr, rr);
            return std::tuple{ev_ref_of(w4, id), w4};
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
        auto&& m75664_3_0 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        if (m75664_3_0 == Text::lit("on")) {
            auto [rr, w1] = event_ref(wx, menv, r);
            auto value = crate::lower::own(crate::lower::value_of(lx, menv, l));
            return std::tuple{EvRef{.node_ = rr.node_, .owner = rr.owner, .pipe = ({
                auto rr_1 = rr;
                auto value_2 = value;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>)>>(prism_rtl::rc([=](std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto rr_1_3 = rr_1;
                    auto value_2_3 = value_2;
                    entered(once_job([=]() {
                    return ({
                        auto x = p0;
                        auto k_fn = p1;
                        rr_1_3.pipe(std::tuple{x, ({
                        auto k_fn_3 = k_fn;
                        auto value_2_3_4 = value_2_3;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>(prism_rtl::rc([=](crate::lower::model::Ex p0) {
                        return ({
                            auto k_fn_3_4 = k_fn_3;
                            auto value_2_3_4_4 = value_2_3_4;
                            entered(once_job([=]() {
                            return ({
                                static_cast<void>(p0);
                                k_fn_3_4(value_2_3_4_4)->cycle();
                            });
                        }));
                        });
                    })));
                    })})->cycle();
                    });
                }));
                });
            })));
            })}, w1};
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        auto&& _m = callee_key(lx, c);
        {
            auto&& m76520_0 = _m;
            if (m76520_0 == Text::lit("Prelude.!Filter")) {
                return filter_event(wx, menv, args, false);
            }
        }
        {
            auto&& m76520_1 = _m;
            if (m76520_1 == Text::lit("Prelude.!Present")) {
                return filter_event(wx, menv, args, true);
            }
        }
        {
            auto&& m76520_2 = _m;
            if (m76520_2 == Text::lit("Prelude.!Gate")) {
                return gate_event(wx, menv, args);
            }
        }
        {
            auto&& m76520_3 = _m;
            if (m76520_3 == Text::lit("Prelude.!Union")) {
                return pair_event(wx, menv, args, GnKind(GnKind::GnUnion{}), t);
            }
        }
        {
            auto&& m76520_4 = _m;
            if (m76520_4 == Text::lit("Prelude.!Both")) {
                return pair_event(wx, menv, args, GnKind(GnKind::GnBoth{}), t);
            }
        }
        {
            auto&& m76520_5 = _m;
            if (m76520_5 == Text::lit("Prelude.!Except")) {
                return pair_event(wx, menv, args, GnKind(GnKind::GnExcept{}), t);
            }
        }
        {
            auto&& m76520_6 = _m;
            if (m76520_6 == Text::lit("Prelude.!MergeAll")) {
                return merge_all_event(wx, menv, args, t);
            }
        }
        {
            auto&& m76520_7 = _m;
            if (m76520_7 == Text::lit("Prelude.!Updated")) {
                return updated_event(wx, menv, args, t);
            }
        }
        {
            return event_map(wx, menv, e);
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2)) {
        auto&& m75664_5_0 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
        if (prism_rtl::is<crate::syntax::Cond::CondExpr>(m75664_5_0)) {
            auto&& c = prism_rtl::as<crate::syntax::Cond::CondExpr>(m75664_5_0).a0;
            auto&& _m = std::tuple{block_expr(then_b), block_expr(else_b)};
            if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                auto&& a = prism_rtl::some_of(std::get<0>(_m));
                auto&& b = prism_rtl::some_of(std::get<1>(_m));
                return event_if(wx, menv, c, a, b, t);
            }
            {
                return event_map(wx, menv, e);
            }
        }
    }
    {
        return event_map(wx, menv, e);
    }
}


prism_rtl::Turn<std::tuple<EvRef, Wx>> EventRef::cycle() const {
    const auto& wx = this->wx;
    const auto& menv = this->menv;
    const auto& e = this->e;
    auto lx = wx.lx;
    auto e_1 = e;
    auto menv_2 = menv;
    auto wx_3 = wx;
    return call_then(crate::lower::start_out_ty_of(lx, crate::lower::peel(crate::lower::type_at(lx, e_1.span))), [=](crate::lower::model::OutTy out_ty_of_75621) {
        return ({
            auto t = out_ty_of_75621;
            ({
            auto&& _m = e_1.kind;
            prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
            prism_rtl::more(prism_rtl::rc(EventRef(wx_3, menv_2, x)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            ({
            auto&& _m = crate::prelude::get(menv_2->names, crate::check::env::sname_key(n));
            prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::Bn::BnEv>(prism_rtl::some_of(_m)) ? ({
            auto&& r = prism_rtl::as<crate::lower::Bn::BnEv>(prism_rtl::some_of(_m)).a0;
            r.owner == wx_3.node_
            ? prism_rtl::finished(std::tuple{r, wx_3})
            : prism_rtl::finished(never_event(crossed(wx_3, prism_rtl::cat("the event `", crate::check::env::sname_key(n), "`, of node `", r.owner, "`,")), t));
        })
            : prism_rtl::finished(never_event(wx_3, t));
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m) && ({
            auto&& m75664_2_0 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
            auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
            auto&& r = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
            (m75664_2_0 == Text::lit("<|"));
        }) ? ({
            auto&& m75664_2_0 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
            auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
            auto&& r = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
            ({
            auto l_4 = l;
            auto r_5 = r;
            call_then(start_event_ref(wx_3, menv_2, l_4), [=](std::tuple<EvRef, Wx> event_ref_76041) {
            return ({
                auto [lr, w1] = event_ref_76041;
                call_then(start_event_ref(w1, menv_2, r_5), [=](std::tuple<EvRef, Wx> event_ref_76091) {
                return ({
                    auto [rr, w2] = event_ref_76091;
                    auto [nm, w3] = fresh_name(w2, Text::lit("anon"));
                    auto [id, w4] = crate::lower::node_::merge(w3, nm, t, lr, rr);
                    (prism_rtl::finished(std::tuple{ev_ref_of(w4, id), w4}));
                });
            });
            });
        });
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m) && ({
            auto&& m75664_3_0 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
            auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
            auto&& r = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
            (m75664_3_0 == Text::lit("on"));
        }) ? ({
            auto&& m75664_3_0 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
            auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
            auto&& r = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
            ({
            auto l_4 = l;
            auto r_5 = r;
            call_then(start_event_ref(wx_3, menv_2, r_5), [=](std::tuple<EvRef, Wx> event_ref_76309) {
            return ({
                auto [rr, w1] = event_ref_76309;
                call_then(crate::lower::start_value_of(lx, menv_2, l_4), [=](crate::lower::Vl value_of_76359) {
                return ({
                    auto value = crate::lower::own(value_of_76359);
                    (prism_rtl::finished(std::tuple{EvRef{.node_ = rr.node_, .owner = rr.owner, .pipe = ({
                    auto rr_6 = rr;
                    auto value_7 = value;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>)>>(prism_rtl::rc([=](std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto rr_6_8 = rr_6;
                        auto value_7_8 = value_7;
                        entered(once_job([=]() {
                        return ({
                            auto x = p0;
                            auto k_fn = p1;
                            rr_6_8.pipe(std::tuple{x, ({
                            auto k_fn_8 = k_fn;
                            auto value_7_8_9 = value_7_8;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>(prism_rtl::rc([=](crate::lower::model::Ex p0) {
                            return ({
                                auto k_fn_8_9 = k_fn_8;
                                auto value_7_8_9_9 = value_7_8_9;
                                entered(once_job([=]() {
                                return ({
                                    static_cast<void>(p0);
                                    k_fn_8_9(value_7_8_9_9)->cycle();
                                });
                            }));
                            });
                        })));
                        })})->cycle();
                        });
                    }));
                    });
                })));
                })}, w1}));
                });
            });
            });
        });
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::ECall>(_m) ? ({
            auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
            auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
            ({
            auto&& _m = callee_key(lx, c);
            ({
            auto&& m76520_0 = _m;
            (m76520_0 == Text::lit("Prelude.!Filter"));
        }) ? ({
            auto&& m76520_0 = _m;
            prism_rtl::finished(filter_event(wx_3, menv_2, args, false));
        })
            : ({
            auto&& m76520_1 = _m;
            (m76520_1 == Text::lit("Prelude.!Present"));
        }) ? ({
            auto&& m76520_1 = _m;
            prism_rtl::finished(filter_event(wx_3, menv_2, args, true));
        })
            : ({
            auto&& m76520_2 = _m;
            (m76520_2 == Text::lit("Prelude.!Gate"));
        }) ? ({
            auto&& m76520_2 = _m;
            prism_rtl::finished(gate_event(wx_3, menv_2, args));
        })
            : ({
            auto&& m76520_3 = _m;
            (m76520_3 == Text::lit("Prelude.!Union"));
        }) ? ({
            auto&& m76520_3 = _m;
            prism_rtl::finished(pair_event(wx_3, menv_2, args, GnKind(GnKind::GnUnion{}), t));
        })
            : ({
            auto&& m76520_4 = _m;
            (m76520_4 == Text::lit("Prelude.!Both"));
        }) ? ({
            auto&& m76520_4 = _m;
            prism_rtl::finished(pair_event(wx_3, menv_2, args, GnKind(GnKind::GnBoth{}), t));
        })
            : ({
            auto&& m76520_5 = _m;
            (m76520_5 == Text::lit("Prelude.!Except"));
        }) ? ({
            auto&& m76520_5 = _m;
            prism_rtl::finished(pair_event(wx_3, menv_2, args, GnKind(GnKind::GnExcept{}), t));
        })
            : ({
            auto&& m76520_6 = _m;
            (m76520_6 == Text::lit("Prelude.!MergeAll"));
        }) ? ({
            auto&& m76520_6 = _m;
            prism_rtl::finished(merge_all_event(wx_3, menv_2, args, t));
        })
            : ({
            auto&& m76520_7 = _m;
            (m76520_7 == Text::lit("Prelude.!Updated"));
        }) ? ({
            auto&& m76520_7 = _m;
            prism_rtl::finished(updated_event(wx_3, menv_2, args, t));
        })
            : prism_rtl::finished(event_map(wx_3, menv_2, e_1));
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2) && ({
            auto&& m75664_5_0 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
            auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
            auto&& else_b = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
            prism_rtl::is<crate::syntax::Cond::CondExpr>(m75664_5_0);
        }) ? ({
            auto&& m75664_5_0 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
            auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
            auto&& else_b = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
            auto&& c = prism_rtl::as<crate::syntax::Cond::CondExpr>(m75664_5_0).a0;
            ({
            auto&& _m = std::tuple{block_expr(then_b), block_expr(else_b)};
            prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m)) ? ({
            auto&& a = prism_rtl::some_of(std::get<0>(_m));
            auto&& b = prism_rtl::some_of(std::get<1>(_m));
            prism_rtl::finished(event_if(wx_3, menv_2, c, a, b, t));
        })
            : prism_rtl::finished(event_map(wx_3, menv_2, e_1));
        });
        })
            : prism_rtl::finished(event_map(wx_3, menv_2, e_1));
        });
        });
    });
}

}  // namespace crate::lower::node_
