// The module `Lower.Node`, from `target/bootstrap/cpp-src/prismc/lower/node/mod.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <lower/node_/module.hpp>
#include <lower/model/module.hpp>
#include <lower/module.hpp>
#include <lower/types/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate::lower::node_ {



Pod FlatDef::to_pod() const {
    return Pod::record("FlatDef", {{"name", prism_rtl::to_pod(name)}, {"outer", prism_rtl::to_pod(outer)}, {"generation", prism_rtl::to_pod(generation)}, {"ty", prism_rtl::to_pod(ty)}});
}

Result<FlatDef> FlatDef::from_pod(const Pod& whole) {
    return FlatDef{.name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .outer = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "outer")))), .generation = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "generation")))), .ty = TRY(prism_rtl::from_pod<crate::lower::model::OutTy>(TRY(crate::prelude::field(whole, "ty"))))};
}




void GnKind::show(Printer& p) const {
    if (auto c = std::get_if<GnNamed>(&cases())) p.choice("GnNamed", {});
    else if (auto c = std::get_if<GnAnswer>(&cases())) p.choice("GnAnswer", {});
    else if (auto c = std::get_if<GnStarted>(&cases())) p.choice("GnStarted", {});
    else if (auto c = std::get_if<GnDeferred>(&cases())) p.choice("GnDeferred", {});
    else if (auto c = std::get_if<GnPort>(&cases())) p.choice("GnPort", {});
    else if (auto c = std::get_if<GnMerge>(&cases())) p.choice("GnMerge", {});
    else if (auto c = std::get_if<GnUnion>(&cases())) p.choice("GnUnion", {});
    else if (auto c = std::get_if<GnBoth>(&cases())) p.choice("GnBoth", {});
    else if (auto c = std::get_if<GnExcept>(&cases())) p.choice("GnExcept", {});
    else if (auto c = std::get_if<GnMergeAll>(&cases())) p.choice("GnMergeAll", {});
    else if (auto c = std::get_if<GnGather>(&cases())) p.choice("GnGather", {});
    else if (auto c = std::get_if<GnUpdated>(&cases())) p.choice("GnUpdated", {});
    else if (auto c = std::get_if<GnNever>(&cases())) p.choice("GnNever", {});
}

Pod GnKind::to_pod() const {
    return std::holds_alternative<GnNamed>(cases()) ? Pod::choice("GnNamed", {})
        : std::holds_alternative<GnAnswer>(cases()) ? Pod::choice("GnAnswer", {})
        : std::holds_alternative<GnStarted>(cases()) ? Pod::choice("GnStarted", {})
        : std::holds_alternative<GnDeferred>(cases()) ? Pod::choice("GnDeferred", {})
        : std::holds_alternative<GnPort>(cases()) ? Pod::choice("GnPort", {})
        : std::holds_alternative<GnMerge>(cases()) ? Pod::choice("GnMerge", {})
        : std::holds_alternative<GnUnion>(cases()) ? Pod::choice("GnUnion", {})
        : std::holds_alternative<GnBoth>(cases()) ? Pod::choice("GnBoth", {})
        : std::holds_alternative<GnExcept>(cases()) ? Pod::choice("GnExcept", {})
        : std::holds_alternative<GnMergeAll>(cases()) ? Pod::choice("GnMergeAll", {})
        : std::holds_alternative<GnGather>(cases()) ? Pod::choice("GnGather", {})
        : std::holds_alternative<GnUpdated>(cases()) ? Pod::choice("GnUpdated", {})
        : std::holds_alternative<GnNever>(cases()) ? Pod::choice("GnNever", {})
        : Pod();
}

Result<GnKind> GnKind::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "GnNamed" && c->args.size() == 0) return GnKind(GnNamed{});
        if (c->ctor == "GnAnswer" && c->args.size() == 0) return GnKind(GnAnswer{});
        if (c->ctor == "GnStarted" && c->args.size() == 0) return GnKind(GnStarted{});
        if (c->ctor == "GnDeferred" && c->args.size() == 0) return GnKind(GnDeferred{});
        if (c->ctor == "GnPort" && c->args.size() == 0) return GnKind(GnPort{});
        if (c->ctor == "GnMerge" && c->args.size() == 0) return GnKind(GnMerge{});
        if (c->ctor == "GnUnion" && c->args.size() == 0) return GnKind(GnUnion{});
        if (c->ctor == "GnBoth" && c->args.size() == 0) return GnKind(GnBoth{});
        if (c->ctor == "GnExcept" && c->args.size() == 0) return GnKind(GnExcept{});
        if (c->ctor == "GnMergeAll" && c->args.size() == 0) return GnKind(GnMergeAll{});
        if (c->ctor == "GnGather" && c->args.size() == 0) return GnKind(GnGather{});
        if (c->ctor == "GnUpdated" && c->args.size() == 0) return GnKind(GnUpdated{});
        if (c->ctor == "GnNever" && c->args.size() == 0) return GnKind(GnNever{});
    }
    return mismatch<GnKind>("a GnKind", p);
}


Pod HostDef::to_pod() const {
    return Pod::record("HostDef", {{"pos", prism_rtl::to_pod(pos)}, {"name", prism_rtl::to_pod(name)}, {"scope", prism_rtl::to_pod(scope)}});
}

Result<HostDef> HostDef::from_pod(const Pod& whole) {
    return HostDef{.pos = TRY(prism_rtl::from_pod<crate::lower::model::Pos_>(TRY(crate::prelude::field(whole, "pos")))), .name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .scope = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "scope"))))};
}






Pod Place::to_pod() const {
    return Pod::record("Place", {{"pos", prism_rtl::to_pod(pos)}, {"level", prism_rtl::to_pod(level)}, {"getter", prism_rtl::to_pod(getter)}, {"reads", prism_rtl::to_pod(reads)}});
}

Result<Place> Place::from_pod(const Pod& whole) {
    return Place{.pos = TRY(prism_rtl::from_pod<crate::lower::model::Pos_>(TRY(crate::prelude::field(whole, "pos")))), .level = TRY(prism_rtl::from_pod<crate::lower::model::Ex>(TRY(crate::prelude::field(whole, "level")))), .getter = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "getter")))), .reads = TRY(prism_rtl::from_pod<Array<Read>>(TRY(crate::prelude::field(whole, "reads"))))};
}


void Read::show(Printer& p) const {
    if (auto c = std::get_if<OwnRead>(&cases())) p.choice("OwnRead", {c->a0});
    else if (auto c = std::get_if<ParentRead>(&cases())) p.choice("ParentRead", {c->a0});
}

Pod Read::to_pod() const {
    return std::holds_alternative<OwnRead>(cases()) ? Pod::choice("OwnRead", {prism_rtl::to_pod(std::get<OwnRead>(cases()).a0)})
        : std::holds_alternative<ParentRead>(cases()) ? Pod::choice("ParentRead", {prism_rtl::to_pod(std::get<ParentRead>(cases()).a0)})
        : Pod();
}

Result<Read> Read::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "OwnRead" && c->args.size() == 1) return Read(OwnRead{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "ParentRead" && c->args.size() == 1) return Read(ParentRead{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
    }
    return mismatch<Read>("a Read", p);
}


Pod RowMarks::to_pod() const {
    return Pod::record("RowMarks", {{"builder", prism_rtl::to_pod(builder)}, {"reads", prism_rtl::to_pod(reads)}, {"wrote", prism_rtl::to_pod(wrote)}, {"kind", prism_rtl::to_pod(kind)}});
}

Result<RowMarks> RowMarks::from_pod(const Pod& whole) {
    return RowMarks{.builder = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "builder")))), .reads = TRY(prism_rtl::from_pod<Array<Read>>(TRY(crate::prelude::field(whole, "reads")))), .wrote = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "wrote")))), .kind = TRY(prism_rtl::from_pod<crate::lower::model::RowKind>(TRY(crate::prelude::field(whole, "kind"))))};
}


Pod Sk::to_pod() const {
    return std::holds_alternative<SkNode>(cases()) ? Pod::choice("SkNode", {prism_rtl::to_pod(std::get<SkNode>(cases()).a0)})
        : std::holds_alternative<SkIn>(cases()) ? Pod::choice("SkIn", {prism_rtl::to_pod(std::get<SkIn>(cases()).a0), prism_rtl::to_pod(std::get<SkIn>(cases()).a1)})
        : std::holds_alternative<SkHold>(cases()) ? Pod::choice("SkHold", {prism_rtl::to_pod(std::get<SkHold>(cases()).a0)})
        : std::holds_alternative<SkRequest>(cases()) ? Pod::choice("SkRequest", {prism_rtl::to_pod(std::get<SkRequest>(cases()).a0), prism_rtl::to_pod(std::get<SkRequest>(cases()).a1)})
        : std::holds_alternative<SkResult>(cases()) ? Pod::choice("SkResult", {})
        : std::holds_alternative<SkArm>(cases()) ? Pod::choice("SkArm", {prism_rtl::to_pod(std::get<SkArm>(cases()).a0)})
        : std::holds_alternative<SkCycle>(cases()) ? Pod::choice("SkCycle", {prism_rtl::to_pod(std::get<SkCycle>(cases()).a0), prism_rtl::to_pod(std::get<SkCycle>(cases()).a1), prism_rtl::to_pod(std::get<SkCycle>(cases()).a2)})
        : std::holds_alternative<SkUp>(cases()) ? Pod::choice("SkUp", {prism_rtl::to_pod(std::get<SkUp>(cases()).a0)})
        : std::holds_alternative<SkPort>(cases()) ? Pod::choice("SkPort", {prism_rtl::to_pod(std::get<SkPort>(cases()).a0)})
        : std::holds_alternative<SkMachine>(cases()) ? Pod::choice("SkMachine", {prism_rtl::to_pod(std::get<SkMachine>(cases()).a0), prism_rtl::to_pod(std::get<SkMachine>(cases()).a1), prism_rtl::to_pod(std::get<SkMachine>(cases()).a2)})
        : Pod();
}

Result<Sk> Sk::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "SkNode" && c->args.size() == 1) return Sk(SkNode{TRY(prism_rtl::from_pod<Nat>(c->args[0]))});
        if (c->ctor == "SkIn" && c->args.size() == 2) return Sk(SkIn{TRY(prism_rtl::from_pod<Nat>(c->args[0])), TRY(prism_rtl::from_pod<Nat>(c->args[1]))});
        if (c->ctor == "SkHold" && c->args.size() == 1) return Sk(SkHold{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "SkRequest" && c->args.size() == 2) return Sk(SkRequest{TRY(prism_rtl::from_pod<crate::lower::model::Pos_>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1]))});
        if (c->ctor == "SkResult" && c->args.size() == 0) return Sk(SkResult{});
        if (c->ctor == "SkArm" && c->args.size() == 1) return Sk(SkArm{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "SkCycle" && c->args.size() == 3) return Sk(SkCycle{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1])), TRY(prism_rtl::from_pod<Nat>(c->args[2]))});
        if (c->ctor == "SkUp" && c->args.size() == 1) return Sk(SkUp{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "SkPort" && c->args.size() == 1) return Sk(SkPort{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "SkMachine" && c->args.size() == 3) return Sk(SkMachine{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1])), TRY(prism_rtl::from_pod<Nat>(c->args[2]))});
    }
    return mismatch<Sk>("a Sk", p);
}


Pod SnapDef::to_pod() const {
    return Pod::record("SnapDef", {{"name", prism_rtl::to_pod(name)}, {"live", prism_rtl::to_pod(live)}, {"ty", prism_rtl::to_pod(ty)}, {"eq", prism_rtl::to_pod(eq)}, {"builder", prism_rtl::to_pod(builder)}, {"before", prism_rtl::to_pod(before)}, {"what", prism_rtl::to_pod(what)}});
}

Result<SnapDef> SnapDef::from_pod(const Pod& whole) {
    return SnapDef{.name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .live = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "live")))), .ty = TRY(prism_rtl::from_pod<crate::lower::model::OutTy>(TRY(crate::prelude::field(whole, "ty")))), .eq = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "eq")))), .builder = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "builder")))), .before = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "before")))), .what = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "what"))))};
}






/// IdPipe: unbounded fn Ex, (unbounded fn Ex -> [Do]) -> [Do]
Array<crate::lower::model::Do> id_pipe(const crate::lower::model::Ex& x, const prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>& k_fn) {
    return run_to_end(k_fn(x));
}


prism_rtl::Turn<Array<crate::lower::model::Do>> IdPipe::cycle() const {
    const auto& x = this->x;
    const auto& k_fn = this->k_fn;
    return k_fn(x)->cycle();
}


/// `Start IdPipe, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::Do>> start_id_pipe(crate::lower::model::Ex x, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)> k_fn) {
    return prism_rtl::make_rc<IdPipe>(x, k_fn);
}


/// EvRefOf: fn Wx, Nat -> EvRef
EvRef ev_ref_of(const Wx& wx, const Nat& n) {
    return EvRef{.node_ = n, .owner = wx.node_, .pipe = static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>)>>(prism_rtl::rc([&](std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>> _p0) {
        auto&& a0 = std::get<0>(_p0);
        auto&& a1 = std::get<1>(_p0);
        return entered(start_id_pipe(a0, a1));
    }))};
}


/// KindWord: fn GnKind -> Text
Text kind_word(const GnKind& k) {
    if (prism_rtl::is<GnKind::GnNamed>(k)) {
        return Text::lit("named");
    }
    if (prism_rtl::is<GnKind::GnAnswer>(k)) {
        return Text::lit("answer");
    }
    if (prism_rtl::is<GnKind::GnStarted>(k)) {
        return Text::lit("started");
    }
    if (prism_rtl::is<GnKind::GnDeferred>(k)) {
        return Text::lit("deferred");
    }
    if (prism_rtl::is<GnKind::GnPort>(k)) {
        return Text::lit("port");
    }
    if (prism_rtl::is<GnKind::GnMerge>(k)) {
        return Text::lit("merge");
    }
    if (prism_rtl::is<GnKind::GnUnion>(k)) {
        return Text::lit("union");
    }
    if (prism_rtl::is<GnKind::GnBoth>(k)) {
        return Text::lit("both");
    }
    if (prism_rtl::is<GnKind::GnExcept>(k)) {
        return Text::lit("except");
    }
    if (prism_rtl::is<GnKind::GnMergeAll>(k)) {
        return Text::lit("mergeall");
    }
    if (prism_rtl::is<GnKind::GnGather>(k)) {
        return Text::lit("gather");
    }
    if (prism_rtl::is<GnKind::GnUpdated>(k)) {
        return Text::lit("updated");
    }
    if (prism_rtl::is<GnKind::GnNever>(k)) {
        return Text::lit("never");
    }
    prism_rtl::unreachable("no arm matched");
}


/// HasRead: fn [Read], Read -> Bool
bool has_read(const Array<Read>& rs, const Read& r) {
    return fold(rs, false, [&](const bool& seen, const Read& x) { return seen || (x == r); });
}


/// AddRead: fn [Read], Read -> [Read]
Array<Read> add_read(const Array<Read>& rs, const Read& r) {
    return has_read(rs, r) ? rs : crate::prelude::push(rs, r);
}


/// UnionReads: fn [Read], [Read] -> [Read]
Array<Read> union_reads(const Array<Read>& xs, const Array<Read>& ys) {
    return fold(ys, xs, [&](const Array<Read>& acc, const Read& y) { return add_read(acc, y); });
}


/// let nodeHooks
Array<Text> node_hooks() {
    return Array(std::vector{Text::lit("path"), Text::lit("build"), Text::lit("wake"), Text::lit("started"), Text::lit("deferred"), Text::lit("answer"), Text::lit("push"), Text::lit("swap"), Text::lit("leave"), Text::lit("patch"), Text::lit("clean_up"), Text::lit("edges"), Text::lit("release"), Text::lit("leave_row"), Text::lit("remove_places")});
}


/// NewWx: fn Lx, Text, [((Text, OutTy, Text))], [((Text, Ex))], [((Text, Ex))], [MethDef], (Text ==> [Read]), [Text], Nat, ?Text -> Wx
Wx new_wx(const crate::lower::Lx& lx, const Text& name, const Array<std::tuple<Text, crate::lower::model::OutTy, Text>>& fields, const Array<std::tuple<Text, crate::lower::model::Ex>>& inits, const Array<std::tuple<Text, crate::lower::model::Ex>>& moves, const Array<crate::lower::model::MethDef>& getters, const Map<Text, Array<Read>>& dyn_reads, const Array<Text>& taken, const Nat& depth, const std::optional<Text>& hosted_by_opt) {
    auto hosted_fields = ({
        __label__ _done;
        prism_rtl::Slot<Array<std::tuple<Text, crate::lower::model::OutTy, Text>>> _v;
        if (prism_rtl::is_some(hosted_by_opt)) {
            _v.set(Array(std::vector{std::tuple{Text::lit("enclosing"), crate::lower::types::host_of_ty(), Text::lit("the host whose document this row's places are entries of (pick HO)")}}));
            goto _done;
        }
        if (prism_rtl::is_none(hosted_by_opt)) {
            _v.set(Array<std::tuple<Text, crate::lower::model::OutTy, Text>>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto hosted_inits = ({
        __label__ _done;
        prism_rtl::Slot<Array<std::tuple<Text, crate::lower::model::Ex>>> _v;
        if (prism_rtl::is_some(hosted_by_opt)) {
            _v.set(Array(std::vector{std::tuple{Text::lit("enclosing"), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("enclosing")})}}));
            goto _done;
        }
        if (prism_rtl::is_none(hosted_by_opt)) {
            _v.set(Array<std::tuple<Text, crate::lower::model::Ex>>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return Wx{.lx = lx, .node_ = name, .pos = crate::lower::model::pos0(), .gns = Array<Gn>{}, .fields = append(fields, hosted_fields), .inits = inits, .moves = append(moves, hosted_inits), .lets = Array<crate::lower::model::Do>{}, .build = Array<crate::lower::model::Do>{}, .places = Array<Place>{}, .answers = Array<std::tuple<crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text>>{}, .started = Array<Nat>{}, .defers = Array<std::tuple<Text, Nat>>{}, .getters = getters, .dyn_reads = dyn_reads, .taken = crate::prelude::push(taken, Text::lit("enclosing")), .fallible = false, .depth = depth, .result = Wres(Wres::WrUnit{}), .rows = Array<crate::lower::model::NodeDef>{}, .builders = Array<crate::lower::model::ForDef>{}, .build_holds = Array<Read>{}, .up_sink = Text::lit(""), .gens = Array<crate::lower::model::GenDef>{}, .gen_holds = Array<std::tuple<Text, Array<Read>>>{}, .ports = Array<Text>{}, .subs = Array<std::tuple<Text, Text, crate::lower::model::OutTy>>{}, .parent_env = crate::lower::types::empty_env(), .hosts = Array<HostDef>{}, .dyn_places = Array<std::tuple<crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text>>{}, .scopes = Array<Text>{}, .hosted_by = hosted_by_opt, .root_dyn = std::optional<std::tuple<crate::lower::model::Ex, Array<Read>, crate::lower::model::OutTy>>{}, .row_marks = Array<RowMarks>{}, .pending = Array<PendingRow>{}, .floors = Map<Text, Nat>{}, .snaps = Array<SnapDef>{}, .result_moved = std::optional<std::tuple<Text, Array<Read>>>{}, .dyn_answers = Array<std::tuple<Text, Array<Read>>>{}, .inited = Array<Text>{}, .flattens = Array<FlatDef>{}};
}


/// FreshName: fn Wx, Text -> ((Text, Wx))
std::tuple<Text, Wx> fresh_name(const Wx& wx, const Text& base) {
    auto pick = !crate::check::types::has_text(wx.taken, base)
        ? base
        : prism_rtl::cat(base, "_", first_free(wx.taken, base, Nat(2u)));
    auto wx2 = ({
        Wx this_ = wx;
        this_.taken = crate::prelude::push(this_.taken, pick);
        this_;
    });
    return std::tuple{pick, wx2};
}


/// FirstFree: fn [Text], Text, Nat -> Nat
Nat first_free(const Array<Text>& taken, const Text& base, const Nat& from) {
    return fold(crate::check::errors::range0(len(taken)), from, [&](const Nat& n, const Nat& _p1) {
        return crate::check::types::has_text(taken, prism_rtl::cat(base, "_", n))
            ? n + Nat(1u)
            : n;
    });
}


/// AddGn: fn Wx, Text, OutTy, GnKind, Nat -> ((Nat, Wx))
std::tuple<Nat, Wx> add_gn(const Wx& wx, const Text& name, const crate::lower::model::OutTy& ty, const GnKind& kind, const Nat& height) {
    auto id = len(wx.gns);
    auto wx2 = ({
        Wx this_ = wx;
        this_.gns = crate::prelude::push(this_.gns, Gn{.id = id, .name = name, .ty = ty, .kind = kind, .height = height, .inputs = Array<Text>{}, .reads = Array<Read>{}, .floor = Nat(0u), .outs = Array<Out>{}});
        this_;
    });
    return std::tuple{id, wx2};
}


/// Connect: fn Wx, EvRef, Sk -> Wx
Wx connect(const Wx& wx, const EvRef& r, const Sk& sink) {
    return r.owner != wx.node_
        ? crossed(wx, prism_rtl::cat("an event of node `", r.owner, "` (its graph node ", r.node_, ")"))
        : ({
        Wx this_ = wx;
        this_.gns = each(this_.gns, [&](const Gn& n) { return n.id == r.node_ ? add_out(n, Out{.pipe = r.pipe, .sink = sink}) : n; });
        this_;
    });
}


/// Crossed: fn Wx, Text -> Wx
Wx crossed(const Wx& wx, const Text& what) {
    Wx this_ = wx;
    this_.build = crate::prelude::push(this_.build, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::expr::refusal(prism_rtl::cat(what, " read in node `", wx.node_, "` without a port (a lowering bug)"))}));
    return this_;
}


/// AddOut: fn Gn, Out -> Gn
Gn add_out(const Gn& n, const Out& o) {
    Gn this_ = n;
    this_.outs = crate::prelude::push(this_.outs, o);
    return this_;
}


/// AddField: fn Wx, Text, OutTy, Text, Ex -> Wx
Wx add_field(const Wx& wx, const Text& name, const crate::lower::model::OutTy& t, const Text& doc, const crate::lower::model::Ex& init) {
    Wx this_ = wx;
    this_.fields = crate::prelude::push(this_.fields, std::tuple{name, t, doc});
    this_.inits = crate::prelude::push(this_.inits, std::tuple{name, init});
    return this_;
}


/// AddFieldLast: fn Wx, Text, OutTy, Text, Ex -> Wx
Wx add_field_last(const Wx& wx, const Text& name, const crate::lower::model::OutTy& t, const Text& doc, const crate::lower::model::Ex& init) {
    Wx this_ = wx;
    this_.fields = crate::prelude::push(this_.fields, std::tuple{name, t, doc});
    this_.moves = crate::prelude::push(this_.moves, std::tuple{name, init});
    return this_;
}


/// GnOf: fn Wx, Nat -> Gn
Gn gn_of(const Wx& wx, const Nat& n) {
    return or_(index(wx.gns, n), Gn{.id = n, .name = Text::lit("never"), .ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .kind = GnKind(GnKind::GnNever{}), .height = Nat(0u), .inputs = Array<Text>{}, .reads = Array<Read>{}, .floor = Nat(0u), .outs = Array<Out>{}});
}


/// BindPlain: fn Env, Env, Text, Text, OutTy -> ((Env, Env))
std::tuple<crate::lower::types::Env, crate::lower::types::Env> bind_plain(const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const Text& nkey, const Text& rs, const crate::lower::model::OutTy& t) {
    return std::tuple{crate::lower::types::bind(benv, nkey, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t})), crate::lower::types::bind(menv, nkey, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), rs}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t}))};
}

}  // namespace crate::lower::node_
