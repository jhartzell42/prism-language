// The module `Lower.Node`: its generic functions' and types' definitions, emitted by prismc
// (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include <lower/node_/module.hpp>
#include <lower/model/module.hpp>
#include <lower/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/env/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/passes/module.hpp>
#include <check/shrink/module.hpp>
#include <check/typed/module.hpp>
#include <check/types/module.hpp>
#include <syntax/module.hpp>
#include <syntax/lexer/module.hpp>

namespace crate {

using namespace prelude;

namespace lower::node_ {

/// IsSome: fn ?a -> Bool
template <class A>
bool is_some(const std::optional<A>& opt0) {
    if (prism_rtl::is_some(opt0)) {
        return true;
    }
    if (prism_rtl::is_none(opt0)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


}  // namespace lower::node_

}  // namespace crate
