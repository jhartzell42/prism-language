// The module `Lower.Node.Keyed`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace lower::node_::keyed {

struct RowLocal;

struct ForLine;

}  // namespace lower::node_::keyed

}  // namespace crate
