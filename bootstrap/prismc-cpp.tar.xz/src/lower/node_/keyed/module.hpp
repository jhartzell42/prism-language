// The module `Lower.Node.Keyed`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <lower/node_/keyed/types.hpp>
#include "elem.types.hpp"
#include <lower/model/types.hpp>
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace lower::node_::keyed {

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> for_line(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const std::optional<crate::syntax::ForBinders>& binders_opt, const crate::syntax::Expr& source, const crate::syntax::Block& body, const crate::syntax::Expr& e, const std::optional<crate::lower::types::Bn>& bound_opt);

prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> start_for_line(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, std::optional<crate::syntax::ForBinders> binders_opt, crate::syntax::Expr source, crate::syntax::Block body, crate::syntax::Expr e, std::optional<crate::lower::types::Bn> bound_opt);

crate::lower::model::MethDef entry_getter(const Text& src_getter, const crate::lower::model::OutTy& vt);

crate::lower::node_::Wx add_builder(const crate::lower::node_::Wx& wx, const Text& name, const crate::lower::model::Pos_& pos, const crate::lower::model::OutTy& kt, const crate::lower::model::OutTy& vt, const Text& row_name, const bool& keyed, const Array<crate::lower::node_::Read>& reads, const crate::lower::node_::PendingRow& waiting, const Array<crate::lower::model::Ex>& passed);

Text for_value_name(const std::optional<crate::syntax::ForBinders>& binders_opt);

Text pattern_name_or(const crate::syntax::Pattern_& p_, const Text& other);

Array<crate::lower::node_::Read> row_place_reads(const crate::lower::node_::Wx& row_wx);

Array<std::tuple<Text, crate::lower::model::OutTy>> hosted_params(const crate::lower::node_::Wx& wx);

Array<crate::lower::model::Ex> hosted_passed(const crate::lower::node_::Wx& wx);

crate::lower::types::Env row_reads(const crate::lower::types::Env& env, const crate::lower::model::Ex& pref);

crate::lower::types::Env events_of(const crate::lower::types::Env& ports, const crate::lower::types::Env& env);

Array<crate::lower::node_::Read> block_reads(const Array<crate::lower::node_::Read>& reads);

Array<RowLocal> row_locals(const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const crate::syntax::Block& body);

std::tuple<crate::lower::types::Env, crate::lower::types::Env> for_envs(const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const std::optional<crate::syntax::ForBinders>& binders_opt, const crate::lower::types::Bn& key_b, const crate::lower::types::Bn& key_m, const crate::lower::types::Bn& val_b, const crate::lower::types::Bn& val_m, const crate::lower::model::OutTy& vt);

crate::lower::model::OutTy kt0();

crate::lower::types::Env bind_pat(const crate::lower::types::Env& env, const crate::syntax::Pattern_& p_, const crate::lower::types::Bn& b, const crate::lower::model::Ex& whole, const crate::lower::model::OutTy& t);

crate::lower::types::Bn part_bn(const crate::lower::types::Bn& bn0, const crate::lower::model::Ex& whole, const Nat& i, const crate::lower::model::OutTy& t);

Text row_suffix(const crate::lower::node_::Wx& wx);

crate::lower::model::OutTy gn_ty_named(const crate::lower::node_::Wx& wx, const Text& n);

}  // namespace lower::node_::keyed


namespace lower::node_::keyed {

/// The step machine of `ForLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ForLine: unbounded fn Wx, Env, Env, ?ForBinders, Expr, Block, Expr, ?Bn -> ((Wx, Wres))
struct ForLine : prism_rtl::Job<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> {
    crate::lower::node_::Wx wx;
    crate::lower::types::Env benv;
    crate::lower::types::Env menv;
    std::optional<crate::syntax::ForBinders> binders_opt;
    crate::syntax::Expr source;
    crate::syntax::Block body;
    crate::syntax::Expr e;
    std::optional<crate::lower::types::Bn> bound_opt;
    ForLine(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, std::optional<crate::syntax::ForBinders> binders_opt, crate::syntax::Expr source, crate::syntax::Block body, crate::syntax::Expr e, std::optional<crate::lower::types::Bn> bound_opt) : wx(std::move(wx)), benv(std::move(benv)), menv(std::move(menv)), binders_opt(std::move(binders_opt)), source(std::move(source)), body(std::move(body)), e(std::move(e)), bound_opt(std::move(bound_opt)) {}
    prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> cycle() const override;
};


}  // namespace lower::node_::keyed

}  // namespace crate
