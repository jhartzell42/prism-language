// The module `Lower.Node.Keyed`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <lower/node_/keyed/types.hpp>
#include "elem.types.hpp"
#include <lower/model/types.hpp>
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace lower::node_::keyed {

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> for_line(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const std::optional<crate::syntax::ForBinders>& binders_o3, const crate::syntax::Expr& source_p4, const crate::syntax::Block& body_p5, const crate::syntax::Expr& e_p6, const std::optional<crate::lower::types::Bn>& bound_o7);

prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> start_for_line(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, std::optional<crate::syntax::ForBinders> binders_o3, crate::syntax::Expr source_p4, crate::syntax::Block body_p5, crate::syntax::Expr e_p6, std::optional<crate::lower::types::Bn> bound_o7);

crate::lower::model::MethDef entry_getter(const Text& src_getter_p0, const crate::lower::model::OutTy& vt_p1);

crate::lower::node_::Wx add_builder(const crate::lower::node_::Wx& wx_p0, const Text& name_p1, const crate::lower::model::Pos_& pos_p2, const crate::lower::model::OutTy& kt_p3, const crate::lower::model::OutTy& vt_p4, const Text& row_name_p5, const bool& keyed_p6, const Array<crate::lower::node_::Read>& reads_p7, const crate::lower::node_::PendingRow& waiting_p8, const Array<crate::lower::model::Ex>& passed_p9);

Text for_value_name(const std::optional<crate::syntax::ForBinders>& binders_o0);

Text pattern_name_or(const crate::syntax::Pattern_& p_p0, const Text& other_p1);

Array<crate::lower::node_::Read> row_place_reads(const crate::lower::node_::Wx& row_wx_p0);

Array<std::tuple<Text, crate::lower::model::OutTy>> hosted_params(const crate::lower::node_::Wx& wx_p0);

Array<crate::lower::model::Ex> hosted_passed(const crate::lower::node_::Wx& wx_p0);

crate::lower::types::Env row_reads(const crate::lower::types::Env& env_p0, const crate::lower::model::Ex& pref_p1);

crate::lower::types::Env events_of(const crate::lower::types::Env& ports_p0, const crate::lower::types::Env& env_p1);

Array<crate::lower::node_::Read> block_reads(const Array<crate::lower::node_::Read>& reads_p0);

Array<RowLocal> row_locals(const crate::lower::types::Env& benv_p0, const crate::lower::types::Env& menv_p1, const crate::syntax::Block& body_p2);

std::tuple<crate::lower::types::Env, crate::lower::types::Env> for_envs(const crate::lower::types::Env& benv_p0, const crate::lower::types::Env& menv_p1, const std::optional<crate::syntax::ForBinders>& binders_o2, const crate::lower::types::Bn& key_b_p3, const crate::lower::types::Bn& key_m_p4, const crate::lower::types::Bn& val_b_p5, const crate::lower::types::Bn& val_m_p6, const crate::lower::model::OutTy& vt_p7);

crate::lower::model::OutTy kt0();

crate::lower::types::Env bind_pat(const crate::lower::types::Env& env_p0, const crate::syntax::Pattern_& p_p1, const crate::lower::types::Bn& b_p2, const crate::lower::model::Ex& whole_p3, const crate::lower::model::OutTy& t_p4);

crate::lower::types::Bn part_bn(const crate::lower::types::Bn& bn0, const crate::lower::model::Ex& whole_p2, const Nat& i_p3, const crate::lower::model::OutTy& t_p4);

Text row_suffix(const crate::lower::node_::Wx& wx_p0);

crate::lower::model::OutTy gn_ty_named(const crate::lower::node_::Wx& wx_p0, const Text& n_p1);

}  // namespace lower::node_::keyed


namespace lower::node_::keyed {

/// The step machine of `ForLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ForLine: unbounded fn Wx, Env, Env, ?ForBinders, Expr, Block, Expr, ?Bn -> ((Wx, Wres))
struct ForLine : prism_rtl::Job<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> {
    crate::lower::node_::Wx wx_p0;
    crate::lower::types::Env benv_p1;
    crate::lower::types::Env menv_p2;
    std::optional<crate::syntax::ForBinders> binders_o3;
    crate::syntax::Expr source_p4;
    crate::syntax::Block body_p5;
    crate::syntax::Expr e_p6;
    std::optional<crate::lower::types::Bn> bound_o7;
    ForLine(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, std::optional<crate::syntax::ForBinders> binders_o3, crate::syntax::Expr source_p4, crate::syntax::Block body_p5, crate::syntax::Expr e_p6, std::optional<crate::lower::types::Bn> bound_o7) : wx_p0(std::move(wx_p0)), benv_p1(std::move(benv_p1)), menv_p2(std::move(menv_p2)), binders_o3(std::move(binders_o3)), source_p4(std::move(source_p4)), body_p5(std::move(body_p5)), e_p6(std::move(e_p6)), bound_o7(std::move(bound_o7)) {}
    prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> cycle() const override;
};


}  // namespace lower::node_::keyed

}  // namespace crate
