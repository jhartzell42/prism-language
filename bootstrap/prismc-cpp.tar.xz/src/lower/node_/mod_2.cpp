// The module `Lower.Node`, from `target/bootstrap/cpp-src/prismc/lower/node/mod.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <lower/node_/module.hpp>
#include <lower/model/module.hpp>
#include <lower/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/env/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/passes/module.hpp>
#include <check/shrink/module.hpp>
#include <check/typed/module.hpp>
#include <check/types/module.hpp>
#include <syntax/module.hpp>
#include <syntax/lexer/module.hpp>
#include <lower/node_/generic.hpp>
#include <check/env/generic.hpp>
#include <syntax/lexer/generic.hpp>

namespace crate::lower::node_ {

/// `Start EventRef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<EvRef, Wx>> start_event_ref(Wx wx, crate::lower::Env menv, crate::syntax::Expr e) {
    return prism_rtl::make_rc<EventRef>(wx, menv, e);
}


/// EventIf: unbounded fn Wx, Env, Expr, Expr, Expr, OutTy -> ((EvRef, Wx))
std::tuple<EvRef, Wx> event_if(const Wx& wx, const crate::lower::Env& menv, const crate::syntax::Expr& c, const crate::syntax::Expr& a, const crate::syntax::Expr& b, const crate::lower::model::OutTy& t) {
    auto cond = crate::lower::as_bool(crate::lower::value_of(wx.lx, menv, c));
    auto [ra, w1] = event_ref(wx, menv, a);
    auto [rb, w2] = event_ref(w1, menv, b);
    auto ga = EvRef{.node_ = ra.node_, .owner = ra.owner, .pipe = ({
        auto ra_1 = ra;
        auto cond_2 = cond;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>)>>(prism_rtl::rc([=](std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto ra_1_3 = ra_1;
            auto cond_2_3 = cond_2;
            entered(once_job([=]() {
            return ({
                auto x = p0;
                auto k_fn = p1;
                ra_1_3.pipe(std::tuple{x, ({
                auto cond_2_3_3 = cond_2_3;
                auto k_fn_3 = k_fn;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>(prism_rtl::rc([=](crate::lower::model::Ex p0) {
                return ({
                    auto cond_2_3_3_4 = cond_2_3_3;
                    auto k_fn_3_4 = k_fn_3;
                    entered(once_job([=]() {
                    return ({
                        auto y = p0;
                        call_value(k_fn_3_4(y), [=](Array<crate::lower::model::Do> k_77798) { return prism_rtl::finished(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIf{cond_2_3_3_4, k_77798, Array<crate::lower::model::Do>{}})})); });
                    });
                }));
                });
            })));
            })})->cycle();
            });
        }));
        });
    })));
    })};
    auto gb = EvRef{.node_ = rb.node_, .owner = rb.owner, .pipe = ({
        auto rb_1 = rb;
        auto cond_2 = cond;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>)>>(prism_rtl::rc([=](std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto rb_1_3 = rb_1;
            auto cond_2_3 = cond_2;
            entered(once_job([=]() {
            return ({
                auto x = p0;
                auto k_fn = p1;
                rb_1_3.pipe(std::tuple{x, ({
                auto cond_2_3_3 = cond_2_3;
                auto k_fn_3 = k_fn;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>(prism_rtl::rc([=](crate::lower::model::Ex p0) {
                return ({
                    auto cond_2_3_3_4 = cond_2_3_3;
                    auto k_fn_3_4 = k_fn_3;
                    entered(once_job([=]() {
                    return ({
                        auto y = p0;
                        call_value(k_fn_3_4(y), [=](Array<crate::lower::model::Do> k_77936) { return prism_rtl::finished(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("=="), prism_rtl::rc(cond_2_3_3_4), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XBool{false}))}), k_77936, Array<crate::lower::model::Do>{}})})); });
                    });
                }));
                });
            })));
            })})->cycle();
            });
        }));
        });
    })));
    })};
    auto [nm, w3] = fresh_name(w2, Text::lit("chosen"));
    auto [id, w4] = crate::lower::node_::merge(w3, nm, t, ga, gb);
    return std::tuple{ev_ref_of(w4, id), w4};
}


/// ?BlockExpr: fn Block -> ?Expr
std::optional<crate::syntax::Expr> block_expr(const crate::syntax::Block& b) {
    auto&& _m = b.stmts;
    {
        auto&& m78170_0 = _m;
        if (m78170_0.size() == 1u) {
            {
                auto&& _c1 = index(m78170_0, Nat(0u));
                if (prism_rtl::is_some(_c1)) {
                    auto&& st = prism_rtl::some_of(_c1);
                    auto&& _m = st.kind;
                    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
                        auto&& x = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                        return std::optional(x);
                    }
                    {
                        return std::optional<crate::syntax::Expr>{};
                    }
                }
            }
        }
    }
    {
        return std::optional<crate::syntax::Expr>{};
    }
}


/// CalleeKey: fn Lx, Expr -> Text
Text callee_key(const crate::lower::Lx& lx, const crate::syntax::Expr& c) {
    auto&& _m = c.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        auto&& _q_opt = crate::check::env::resolve_value(lx.g, lx.home, n);
        auto&& q_opt = std::get<0>(_q_opt);
        return or_(q_opt, Text::lit(""));
    }
    {
        return Text::lit("");
    }
}


/// PairEvent: unbounded fn Wx, Env, [Arg], GnKind, OutTy -> ((EvRef, Wx))
std::tuple<EvRef, Wx> pair_event(const Wx& wx, const crate::lower::Env& menv, const Array<crate::syntax::Arg>& args, const GnKind& kind, const crate::lower::model::OutTy& t) {
    auto&& _m = std::tuple{index(args, Nat(0u)), index(args, Nat(1u))};
    if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
        auto&& a = prism_rtl::some_of(std::get<0>(_m));
        auto&& b = prism_rtl::some_of(std::get<1>(_m));
        auto [ra, w1] = event_ref(wx, menv, a->value);
        auto [rb, w2] = event_ref(w1, menv, b->value);
        auto lt = crate::lower::out_ty_of(wx.lx, crate::lower::peel(crate::lower::type_at(wx.lx, a->value.span)));
        auto rt = crate::lower::out_ty_of(wx.lx, crate::lower::peel(crate::lower::type_at(wx.lx, b->value.span)));
        auto [nm, w3] = fresh_name(w2, kind_word(kind));
        auto [id, w4] = combinator(w3, nm, t, kind, ra, rb, lt, rt);
        return std::tuple{ev_ref_of(w4, id), w4};
    }
    {
        return never_event(wx, t);
    }
}


/// MergeAllEvent: unbounded fn Wx, Env, [Arg], OutTy -> ((EvRef, Wx))
std::tuple<EvRef, Wx> merge_all_event(const Wx& wx, const crate::lower::Env& menv, const Array<crate::syntax::Arg>& args, const crate::lower::model::OutTy& t) {
    auto&& _m = index(args, Nat(0u));
    if (prism_rtl::is_some(_m)) {
        auto&& a = prism_rtl::some_of(_m);
        auto&& _m = a->value.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EArray>(_m)) {
            auto&& es = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
            auto et = ({
                __label__ _done;
                prism_rtl::Slot<crate::lower::model::OutTy> _v;
                if (prism_rtl::is<crate::lower::model::OutTy::OutArray>(t)) {
                    auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t).a0;
                    _v.set(x);
                    goto _done;
                }
                {
                    _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto [nm, w1] = fresh_name(wx, Text::lit("merged"));
            auto [id, w2] = add_gn(w1, nm, t, GnKind(GnKind::GnMergeAll{}), Nat(1u));
            auto ins = each(crate::check::errors::range0(len(es)), [&](const Nat& i) { return prism_rtl::cat(nm, "_", i); });
            auto w3 = fold(ins, w2, [&](const Wx& w, const Text& f) { return add_field_last(w, f, crate::lower::model::OutTy(crate::lower::model::OutTy::OutStamped{prism_rtl::rc(et)}), Text::lit("an input of `!MergeAll`"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Stamped::new"), Array<crate::lower::model::Ex>{}})); });
            auto w4 = ({
                Wx this_ = w3;
                this_.gns = each(this_.gns, [&](const Gn& n) { return n.id == id ? with_inputs(n, ins) : n; });
                this_;
            });
            auto w5 = run_to_end(fold_job(crate::check::errors::range0(len(es)), w4, ({
                auto menv_1 = menv;
                auto es_2 = es;
                auto a_3 = a;
                auto id_4 = id;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Wx>(std::tuple<Wx, Nat>)>>(prism_rtl::rc([=](std::tuple<Wx, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto menv_1_5 = menv_1;
                    auto es_2_5 = es_2;
                    auto a_3_5 = a_3;
                    auto id_4_5 = id_4;
                    entered(once_job([=]() {
                    return ({
                        auto w = p0;
                        auto i = p1;
                        call_then(start_event_ref(w, menv_1_5, or_(index(es_2_5, i), a_3_5->value)), [=](std::tuple<EvRef, Wx> event_ref_80104) {
                        return ({
                            auto [r, w6] = event_ref_80104;
                            (prism_rtl::finished(connect(w6, r, Sk(Sk::SkIn{id_4_5, i}))));
                        });
                    });
                    });
                }));
                });
            })));
            })));
            return std::tuple{ev_ref_of(w5, id), w5};
        }
        {
            auto [r, w1] = never_event(wx, t);
            auto w2 = ({
                Wx this_ = w1;
                this_.build = crate::prelude::push(this_.build, crate::lower::refusal_do(Text::lit("`!MergeAll` of a list that is not a literal")));
                this_;
            });
            return std::tuple{r, w2};
        }
    }
    if (prism_rtl::is_none(_m)) {
        return never_event(wx, t);
    }
    prism_rtl::unreachable("no arm matched");
}


/// UpdatedEvent: unbounded fn Wx, Env, [Arg], OutTy -> ((EvRef, Wx))
std::tuple<EvRef, Wx> updated_event(const Wx& wx, const crate::lower::Env& menv, const Array<crate::syntax::Arg>& args, const crate::lower::model::OutTy& t) {
    auto&& _m = index(args, Nat(0u));
    if (prism_rtl::is_some(_m)) {
        auto&& a = prism_rtl::some_of(_m);
        auto [ex, reads] = dynamic_expr(wx, menv, a->value);
        auto [nm, w1] = fresh_name(wx, Text::lit("updated"));
        auto [id, w2] = add_gn(w1, nm, t, GnKind(GnKind::GnUpdated{}), Nat(1u));
        auto w3 = add_field_last(w2, prism_rtl::cat(nm, "_moved"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Cell"), Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})})}), prism_rtl::cat("a hold `!", nm, "`'s dynamic reads was written this tick"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Cell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XBool{false})})}));
        auto w4 = ({
            Wx this_ = w3;
            this_.gns = each(this_.gns, [&](const Gn& n) { return n.id == id ? with_reads(n, reads) : n; });
            this_.getters = crate::prelude::push(this_.getters, crate::lower::model::MethDef{.name = prism_rtl::cat(nm, "_value"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = t, .body = Array<crate::lower::model::Do>{}, .tail = ex, .doc = prism_rtl::cat("The dynamic `!", nm, "` is the event half of, which the wake reads after the tick.")});
            this_;
        });
        return std::tuple{ev_ref_of(w4, id), w4};
    }
    if (prism_rtl::is_none(_m)) {
        return never_event(wx, t);
    }
    prism_rtl::unreachable("no arm matched");
}


/// FilterEvent: unbounded fn Wx, Env, [Arg], Bool -> ((EvRef, Wx))
std::tuple<EvRef, Wx> filter_event(const Wx& wx, const crate::lower::Env& menv, const Array<crate::syntax::Arg>& args, const bool& is_unit) {
    auto&& _m = index(args, Nat(0u));
    if (prism_rtl::is_none(_m)) {
        return never_event(wx, crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
    }
    if (prism_rtl::is_some(_m)) {
        auto&& a = prism_rtl::some_of(_m);
        auto [r, w1] = event_ref(wx, menv, a->value);
        auto bound = is_unit
            ? crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})
            : crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("w")});
        auto pipe = ({
            auto r_1 = r;
            auto bound_2 = bound;
            auto is_unit_3 = is_unit;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>)>>(prism_rtl::rc([=](std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto r_1_4 = r_1;
                auto bound_2_4 = bound_2;
                auto is_unit_3_4 = is_unit_3;
                entered(once_job([=]() {
                return ({
                    auto x = p0;
                    auto k_fn = p1;
                    r_1_4.pipe(std::tuple{x, ({
                    auto bound_2_4_4 = bound_2_4;
                    auto k_fn_4 = k_fn;
                    auto is_unit_3_4_5 = is_unit_3_4;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>(prism_rtl::rc([=](crate::lower::model::Ex p0) {
                    return ({
                        auto bound_2_4_4_5 = bound_2_4_4;
                        auto k_fn_4_5 = k_fn_4;
                        auto is_unit_3_4_5_5 = is_unit_3_4_5;
                        entered(once_job([=]() {
                        return ({
                            auto y = p0;
                            call_value(k_fn_4_5(is_unit_3_4_5_5
                            ? crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})
                            : crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("w")})), [=](Array<crate::lower::model::Do> k_82466) { return prism_rtl::finished(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{bound_2_4_4_5})}), y, k_82466, Array<crate::lower::model::Do>{}})})); });
                        });
                    }));
                    });
                })));
                })})->cycle();
                });
            }));
            });
        })));
        });
        return std::tuple{EvRef{.node_ = r.node_, .owner = r.owner, .pipe = pipe}, w1};
    }
    prism_rtl::unreachable("no arm matched");
}


/// GateEvent: unbounded fn Wx, Env, [Arg] -> ((EvRef, Wx))
std::tuple<EvRef, Wx> gate_event(const Wx& wx, const crate::lower::Env& menv, const Array<crate::syntax::Arg>& args) {
    auto&& _m = index(args, Nat(1u));
    if (prism_rtl::is_none(_m)) {
        return never_event(wx, crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
    }
    if (prism_rtl::is_some(_m)) {
        auto&& a = prism_rtl::some_of(_m);
        auto [r, w1] = event_ref(wx, menv, a->value);
        auto cond = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::Ex> _v;
            auto&& _m = index(args, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& b = prism_rtl::some_of(_m);
                _v.set(crate::lower::as_bool(crate::lower::value_of(wx.lx, menv, b->value)));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XBool{false}));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto pipe = ({
            auto r_1 = r;
            auto cond_2 = cond;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>)>>(prism_rtl::rc([=](std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto r_1_3 = r_1;
                auto cond_2_3 = cond_2;
                entered(once_job([=]() {
                return ({
                    auto x = p0;
                    auto k_fn = p1;
                    r_1_3.pipe(std::tuple{x, ({
                    auto cond_2_3_3 = cond_2_3;
                    auto k_fn_3 = k_fn;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>(prism_rtl::rc([=](crate::lower::model::Ex p0) {
                    return ({
                        auto cond_2_3_3_4 = cond_2_3_3;
                        auto k_fn_3_4 = k_fn_3;
                        entered(once_job([=]() {
                        return ({
                            auto y = p0;
                            call_value(k_fn_3_4(y), [=](Array<crate::lower::model::Do> k_82999) { return prism_rtl::finished(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIf{cond_2_3_3_4, k_82999, Array<crate::lower::model::Do>{}})})); });
                        });
                    }));
                    });
                })));
                })})->cycle();
                });
            }));
            });
        })));
        });
        return std::tuple{EvRef{.node_ = r.node_, .owner = r.owner, .pipe = pipe}, w1};
    }
    prism_rtl::unreachable("no arm matched");
}


/// EventMap: unbounded fn Wx, Env, Expr -> ((EvRef, Wx))
std::tuple<EvRef, Wx> event_map(const Wx& wx, const crate::lower::Env& menv, const crate::syntax::Expr& e) {
    auto lx = wx.lx;
    auto t = crate::lower::out_ty_of(lx, crate::lower::peel(crate::lower::type_at(lx, e.span)));
    auto evs = filter(operands(e), [&](const crate::syntax::Expr& x) { return crate::lower::layer_of(crate::lower::type_at(lx, x.span)) == crate::lower::Layer(crate::lower::Layer::LyEv{}); });
    {
        auto&& m83481_0 = evs;
        if (m83481_0.size() == 1u) {
            {
                auto&& _c1 = index(m83481_0, Nat(0u));
                if (prism_rtl::is_some(_c1)) {
                    auto&& one = prism_rtl::some_of(_c1);
                    auto [r, w1] = event_ref(wx, menv, one);
                    auto et = crate::lower::out_ty_of(lx, crate::lower::peel(crate::lower::type_at(lx, one.span)));
                    auto k = crate::lower::place_key(lx, one.span);
                    auto pipe = ({
                        auto r_1 = r;
                        auto lx_2 = lx;
                        auto menv_3 = menv;
                        auto k_4 = k;
                        auto et_5 = et;
                        auto e_6 = e;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>)>>(prism_rtl::rc([=](std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto r_1_7 = r_1;
                            auto lx_2_7 = lx_2;
                            auto menv_3_7 = menv_3;
                            auto k_4_7 = k_4;
                            auto et_5_7 = et_5;
                            auto e_6_7 = e_6;
                            entered(once_job([=]() {
                            return ({
                                auto x = p0;
                                auto k_fn = p1;
                                r_1_7.pipe(std::tuple{x, ({
                                auto k_fn_7 = k_fn;
                                auto lx_2_7_8 = lx_2_7;
                                auto menv_3_7_8 = menv_3_7;
                                auto k_4_7_8 = k_4_7;
                                auto et_5_7_8 = et_5_7;
                                auto e_6_7_8 = e_6_7;
                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>(prism_rtl::rc([=](crate::lower::model::Ex p0) {
                                return ({
                                    auto k_fn_7_8 = k_fn_7;
                                    auto lx_2_7_8_8 = lx_2_7_8;
                                    auto menv_3_7_8_8 = menv_3_7_8;
                                    auto k_4_7_8_8 = k_4_7_8;
                                    auto et_5_7_8_8 = et_5_7_8;
                                    auto e_6_7_8_8 = e_6_7_8;
                                    entered(once_job([=]() {
                                    return ({
                                        auto y = p0;
                                        call_then(crate::lower::start_value_of(lx_2_7_8_8, crate::lower::bind_span(menv_3_7_8_8, k_4_7_8_8, firing_value(y, et_5_7_8_8)), e_6_7_8_8), [=](crate::lower::Vl value_of_83718) { return k_fn_7_8(crate::lower::own(value_of_83718))->cycle(); });
                                    });
                                }));
                                });
                            })));
                            })})->cycle();
                            });
                        }));
                        });
                    })));
                    });
                    return std::tuple{EvRef{.node_ = r.node_, .owner = r.owner, .pipe = pipe}, w1};
                }
            }
        }
    }
    {
        return never_event(wx, t);
    }
}


/// FiringValue: fn Ex, OutTy -> Vl
crate::lower::Vl firing_value(const crate::lower::model::Ex& ex0, const crate::lower::model::OutTy& t) {
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(ex0)) {
        auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(ex0).a0;
        return crate::lower::Vl(crate::lower::Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XVar{n}), crate::lower::Holding(crate::lower::Holding::Owned{}), t});
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUnit>(ex0)) {
        return crate::lower::Vl(crate::lower::Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::Holding(crate::lower::Holding::Owned{}), t});
    }
    {
        auto&& x = ex0;
        return crate::lower::Vl(crate::lower::Vl::VlOwned{x, t});
    }
}


/// Operands: fn Expr -> [Expr]
Array<crate::syntax::Expr> operands(const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        return append(Array(std::vector{c}), each(args, [&](const crate::syntax::Arg& a) { return a->value; }));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
        return append(Array(std::vector{r}), each(args, [&](const crate::syntax::Arg& a) { return a->value; }));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        return Array(std::vector{l, r});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
        return Array(std::vector{x});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        return Array(std::vector{x});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return Array(std::vector{x});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        return Array(std::vector{r});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& i = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        return Array(std::vector{r, i});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m)) {
        auto&& es = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
        return es;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EArray>(_m)) {
        auto&& es = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
        return es;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMap>(_m)) {
        auto&& kvs = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
        return fold(kvs, Array<crate::syntax::Expr>{}, [&](const Array<crate::syntax::Expr>& acc, const std::tuple<crate::syntax::Expr, crate::syntax::Expr>& _p1) {
            auto&& k = std::get<0>(_p1);
            auto&& v_ = std::get<1>(_p1);
            return append(acc, Array(std::vector{k, v_}));
        });
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELit>(_m)) {
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
        auto&& _m = l.kind;
        if (prism_rtl::is<crate::syntax::LitKind::LText>(_m)) {
            auto&& segs = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
            return fold(segs, Array<crate::syntax::Expr>{}, [&](const Array<crate::syntax::Expr>& acc, const crate::syntax::TextSeg& sg) {
                return ({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
                    if (prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(sg)) {
                        auto&& x = prism_rtl::as<crate::syntax::TextSeg::SegPlaceholder>(sg).a0;
                        _v.set(crate::prelude::push(acc, x));
                        goto _done;
                    }
                    {
                        _v.set(acc);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            });
        }
        {
            return Array<crate::syntax::Expr>{};
        }
    }
    {
        return Array<crate::syntax::Expr>{};
    }
}


/// Merge: fn Wx, Text, OutTy, EvRef, EvRef -> ((Nat, Wx))
std::tuple<Nat, Wx> merge(const Wx& wx, const Text& name, const crate::lower::model::OutTy& t, const EvRef& l, const EvRef& r) {
    return combinator(wx, name, t, GnKind(GnKind::GnMerge{}), l, r, t, t);
}


/// Combinator: fn Wx, Text, OutTy, GnKind, EvRef, EvRef, OutTy, OutTy -> ((Nat, Wx))
std::tuple<Nat, Wx> combinator(const Wx& wx, const Text& name, const crate::lower::model::OutTy& t, const GnKind& kind, const EvRef& l, const EvRef& r, const crate::lower::model::OutTy& lt, const crate::lower::model::OutTy& rt) {
    auto [id, wx1] = add_gn(wx, name, t, kind, Nat(1u));
    auto wx2 = add_field_last(wx1, prism_rtl::cat(name, "_left"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutStamped{prism_rtl::rc(lt)}), prism_rtl::cat("`", name, "`'s left input"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Stamped::new"), Array<crate::lower::model::Ex>{}}));
    auto wx3 = add_field_last(wx2, prism_rtl::cat(name, "_right"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutStamped{prism_rtl::rc(rt)}), Text::lit("its right input"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Stamped::new"), Array<crate::lower::model::Ex>{}}));
    auto wx4 = ({
        Wx this_ = wx3;
        this_.gns = each(this_.gns, [&](const Gn& n) {
            return n.id == id
                ? with_inputs(n, Array(std::vector{prism_rtl::cat(name, "_left"), prism_rtl::cat(name, "_right")}))
                : n;
        });
        this_;
    });
    return std::tuple{id, connect(connect(wx4, l, Sk(Sk::SkIn{id, Nat(0u)})), r, Sk(Sk::SkIn{id, Nat(1u)}))};
}


/// WithInputs: fn Gn, [Text] -> Gn
Gn with_inputs(const Gn& n, const Array<Text>& ins) {
    Gn this_ = n;
    this_.inputs = ins;
    return this_;
}


/// WithReads: fn Gn, [Read] -> Gn
Gn with_reads(const Gn& n, const Array<Read>& reads) {
    Gn this_ = n;
    this_.reads = reads;
    return this_;
}


/// Heights: fn [Gn] -> [Gn]
Array<Gn> heights(const Array<Gn>& gns) {
    return fold(gns, gns, [&](const Array<Gn>& cur, const Gn& _p1) { return each(cur, [&](const Gn& n) { return height_step(cur, n); }); });
}


/// HeightStep: fn [Gn], Gn -> Gn
Gn height_step(const Array<Gn>& gns, const Gn& n) {
    auto feeders = filter(gns, [&](const Gn& m) { return fold(m.outs, false, [&](const bool& f, const Out& o) { return f || feeds(o.sink, n); }); });
    auto top = fold(feeders, Nat(0u), [&](const Nat& hi, const Gn& m) { return crate::prelude::max(hi, m.height); });
    auto h = ({
        __label__ _done;
        prism_rtl::Slot<Nat> _v;
        auto&& _m = n.kind;
        if (prism_rtl::is<GnKind::GnNamed>(_m)) {
            _v.set(top);
            goto _done;
        }
        {
            auto&& kind = _m;
            _v.set(is_comb(kind) ? crate::prelude::max(top + Nat(1u), n.floor) : n.height);
            goto _done;
        }
    _done:
        _v.take();
    });
    Gn this_ = n;
    this_.height = h;
    return this_;
}


/// IsComb: fn GnKind -> Bool
bool is_comb(const GnKind& k) {
    if (prism_rtl::is<GnKind::GnMerge>(k)) {
        return true;
    }
    if (prism_rtl::is<GnKind::GnUnion>(k)) {
        return true;
    }
    if (prism_rtl::is<GnKind::GnBoth>(k)) {
        return true;
    }
    if (prism_rtl::is<GnKind::GnExcept>(k)) {
        return true;
    }
    if (prism_rtl::is<GnKind::GnMergeAll>(k)) {
        return true;
    }
    if (prism_rtl::is<GnKind::GnUpdated>(k)) {
        return true;
    }
    {
        return false;
    }
}


/// Feeds: fn Sk, Gn -> Bool
bool feeds(const Sk& sk0, const Gn& n) {
    if (prism_rtl::is<Sk::SkNode>(sk0)) {
        auto&& m = prism_rtl::as<Sk::SkNode>(sk0).a0;
        return m == n.id;
    }
    if (prism_rtl::is<Sk::SkIn>(sk0)) {
        auto&& m = prism_rtl::as<Sk::SkIn>(sk0).a0;
        return m == n.id;
    }
    if (prism_rtl::is<Sk::SkCycle>(sk0)) {
        auto&& m = prism_rtl::as<Sk::SkCycle>(sk0).a2;
        return m == n.id;
    }
    if (prism_rtl::is<Sk::SkMachine>(sk0)) {
        auto&& f = prism_rtl::as<Sk::SkMachine>(sk0).a0;
        auto&& m = prism_rtl::as<Sk::SkMachine>(sk0).a2;
        return (m == n.id) || writes(f, n);
    }
    if (prism_rtl::is<Sk::SkHold>(sk0)) {
        auto&& f = prism_rtl::as<Sk::SkHold>(sk0).a0;
        return writes(f, n);
    }
    {
        auto&& other = sk0;
        return false;
    }
}


/// Writes: fn Text, Gn -> Bool
bool writes(const Text& f, const Gn& n) {
    return moves(Read(Read::OwnRead{f}), n);
}


/// Moves: fn Read, Gn -> Bool
bool moves(const Read& r, const Gn& n) {
    return (n.kind == GnKind(GnKind::GnUpdated{})) && has_read(n.reads, r);
}


/// ReadsClosed: fn (Text ==> [Read]), [Read] -> [Read]
Array<Read> reads_closed(const Map<Text, Array<Read>>& dyn_, const Array<Read>& reads) {
    return fold(crate::check::errors::range0(Nat(4u)), reads, [&](const Array<Read>& acc, const Nat& _p1) { return fold(acc, acc, [&](const Array<Read>& a, const Read& r) { return union_reads(a, getter_reads(dyn_, r)); }); });
}


/// GetterReads: fn (Text ==> [Read]), Read -> [Read]
Array<Read> getter_reads(const Map<Text, Array<Read>>& dyn_, const Read& read1) {
    if (prism_rtl::is<Read::OwnRead>(read1)) {
        auto&& n = prism_rtl::as<Read::OwnRead>(read1).a0;
        return or_(crate::prelude::get(dyn_, n), Array<Read>{});
    }
    if (prism_rtl::is<Read::ParentRead>(read1)) {
        return Array<Read>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// ReachesSnap: fn [Text], [Read] -> Bool
bool reaches_snap(const Array<Text>& roots, const Array<Read>& reads) {
    return fold(reads, false, [&](const bool& f, const Read& r) {
        return f || ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            if (prism_rtl::is<Read::OwnRead>(r)) {
                auto&& n = prism_rtl::as<Read::OwnRead>(r).a0;
                _v.set(crate::check::types::has_text(roots, n));
                goto _done;
            }
            if (prism_rtl::is<Read::ParentRead>(r)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// SnapNames: fn Wx -> [Text]
Array<Text> snap_names(const Wx& wx) {
    return each(wx.snaps, [&](const SnapDef& sn) { return sn.name; });
}


/// WakeConst: fn [Nat], Nat -> Text
Text wake_const(const Array<Nat>& heights_, const Nat& h) {
    return len(heights_) <= Nat(1u) ? Text::lit("WAKE") : prism_rtl::cat("WAKE_", h);
}


/// SelfCall: fn Text, [Ex] -> Do
crate::lower::model::Do self_call(const Text& m, const Array<crate::lower::model::Ex>& args) {
    return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), m, crate::prelude::push(args, crate::lower::model::Ex(crate::lower::model::Ex::XCx{}))})});
}


/// SinkCode: fn Sinks, Sk, Ex -> [Do]
Array<crate::lower::model::Do> sink_code(const Sinks& sk, const Sk& target, const crate::lower::model::Ex& y) {
    if (prism_rtl::is<Sk::SkNode>(target)) {
        auto&& m = prism_rtl::as<Sk::SkNode>(target).a0;
        return Array(std::vector{self_call(gn_of(sk.wx, m).name, Array(std::vector{y}))});
    }
    if (prism_rtl::is<Sk::SkIn>(target)) {
        auto&& m = prism_rtl::as<Sk::SkIn>(target).a0;
        auto&& i = prism_rtl::as<Sk::SkIn>(target).a1;
        auto g = gn_of(sk.wx, m);
        return append(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(or_(index(g.inputs, i), Text::lit("")))})), Text::lit("set"), Array(std::vector{y, crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})}), ask_wake(sk, g.height));
    }
    if (prism_rtl::is<Sk::SkHold>(target)) {
        auto&& f = prism_rtl::as<Sk::SkHold>(target).a0;
        return append(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f)})), Text::lit("set"), Array(std::vector{y, crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})}), hold_written(sk, f));
    }
    if (prism_rtl::is<Sk::SkRequest>(target)) {
        auto&& pos = prism_rtl::as<Sk::SkRequest>(target).a0;
        auto&& field = prism_rtl::as<Sk::SkRequest>(target).a1;
        auto field_ex = field == Text::lit("")
            ? crate::lower::model::Ex(crate::lower::model::Ex::XNone{})
            : crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{field})})});
        return emits(sk.wx, pos)
            ? Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("request"), Array(std::vector{place_at(sk.wx, Text::lit("self"), pos), field_ex, crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(y), Text::lit("to_pod"), Array<crate::lower::model::Ex>{}})})})})})
            : Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("requested")}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(host_field_ex(sk.wx, pos)), Text::lit("request"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(place_at(sk.wx, Text::lit("self"), pos))}), field_ex, crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(y), Text::lit("to_pod"), Array<crate::lower::model::Ex>{}}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})}), crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("keep"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("requested")})})})})});
    }
    if (prism_rtl::is<Sk::SkResult>(target)) {
        return Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("result"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Outcome::Fired"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(y), Text::lit("to_pod"), Array<crate::lower::model::Ex>{}})})})})})})});
    }
    if (prism_rtl::is<Sk::SkArm>(target)) {
        auto&& f = prism_rtl::as<Sk::SkArm>(target).a0;
        return Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f)})), Text::lit("arm"), Array(std::vector{y, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})});
    }
    if (prism_rtl::is<Sk::SkMachine>(target)) {
        auto&& f = prism_rtl::as<Sk::SkMachine>(target).a0;
        auto&& step_ = prism_rtl::as<Sk::SkMachine>(target).a1;
        auto&& out = prism_rtl::as<Sk::SkMachine>(target).a2;
        auto stepped = crate::lower::model::Ex(crate::lower::model::Ex::XCall{step_, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), f})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(y)})})});
        return append(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("machine_s")}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("machine_b")})})}), stepped}), crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f)})), Text::lit("set"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("machine_s")}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})}), crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("machine_b")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("machine_b")}), Array(std::vector{self_call(gn_of(sk.wx, out).name, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("machine_b")})}))}), Array<crate::lower::model::Do>{}})}), moved_marks(sk, f));
    }
    if (prism_rtl::is<Sk::SkPort>(target)) {
        auto&& f = prism_rtl::as<Sk::SkPort>(target).a0;
        return Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f, "_port")})), Text::lit("fire"), Array(std::vector{y, crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})), Text::lit("ok"), Array<crate::lower::model::Ex>{}})})});
    }
    if (prism_rtl::is<Sk::SkUp>(target)) {
        auto&& m = prism_rtl::as<Sk::SkUp>(target).a0;
        auto keyed = len(filter(sk.wx.fields, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
            auto&& f = std::get<0>(_p0);
            return f == Text::lit("key");
        })) > Nat(0u);
        auto args = keyed
            ? Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("key")}))}), y, crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})
            : Array(std::vector{y, crate::lower::model::Ex(crate::lower::model::Ex::XCx{})});
        return Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("parent")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XUpgrade{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("parent")}))}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("parent")})), m, args})})}), Array<crate::lower::model::Do>{}})});
    }
    if (prism_rtl::is<Sk::SkCycle>(target)) {
        auto&& job = prism_rtl::as<Sk::SkCycle>(target).a0;
        auto&& again = prism_rtl::as<Sk::SkCycle>(target).a1;
        auto&& res = prism_rtl::as<Sk::SkCycle>(target).a2;
        auto more = Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(job)})), Text::lit("set"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("next")}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})}), crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(again)})), Text::lit("arm"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})});
        auto fin = Array(std::vector{self_call(gn_of(sk.wx, res).name, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("b")})}))});
        return Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoMatch{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(job)})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})), Text::lit("cycle"), Array<crate::lower::model::Ex>{}}), Array(std::vector{std::tuple{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("prism_rtl::Turn::More"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("next")})})}), more}, std::tuple{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("b")})})}), fin}})})});
    }
    prism_rtl::unreachable("no arm matched");
}


/// HoldWritten: fn Sinks, Text -> [Do]
Array<crate::lower::model::Do> hold_written(const Sinks& sk, const Text& f) {
    auto r = Read(Read::OwnRead{f});
    auto read_by_place = has_read(sk.dirty, r);
    auto [dirty, told] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, Array<crate::lower::model::Do>>> _v;
        auto&& _m = sk.wx.hosted_by;
        if (prism_rtl::is_some(_m)) {
            _v.set(std::tuple{Array<crate::lower::model::Do>{}, read_by_place
                ? Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("document_moved"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})})
                : Array<crate::lower::model::Do>{}});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::tuple{read_by_place
                ? Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("dirty"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})})})})})
                : Array<crate::lower::model::Do>{}, Array<crate::lower::model::Do>{}});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto stales = fold(sk.wx.gen_holds, Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc, const std::tuple<Text, Array<Read>>& _p1) {
        auto&& gname = std::get<0>(_p1);
        auto&& hs = std::get<1>(_p1);
        return has_read(reads_closed(sk.wx.dyn_reads, hs), r)
            ? crate::prelude::push(acc, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(gname, "_stale")})), Text::lit("set"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XBool{true})})})}))
            : acc;
    });
    auto row_marks = fold(sk.wx.row_marks, Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc, const RowMarks& rm) { return append(acc, row_written(sk.wx, rm, r)); });
    auto builds = has_read(sk.builds, r) || (len(stales) > Nat(0u));
    auto rebuild_it = builds && (!lists_build(sk, r))
        ? append(stales, Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("build_later"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})})})})}))
        : stales;
    auto gathered = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::Do>> _v;
        auto&& _m = sk.wx.result_moved;
        if (prism_rtl::is_some(_m)) {
            auto&& m = std::get<0>(prism_rtl::some_of(_m));
            auto&& rds = std::get<1>(prism_rtl::some_of(_m));
            _v.set(has_read(rds, r)
                ? Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("parent")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XUpgrade{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("parent")}))}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("parent")})), m, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})}), Array<crate::lower::model::Do>{}})})
                : Array<crate::lower::model::Do>{});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<crate::lower::model::Do>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return append(append(append(append(append(dirty, told), rebuild_it), row_marks), gathered), moved_marks(sk, f));
}


/// HostFieldEx: fn Wx, Pos -> Ex
crate::lower::model::Ex host_field_ex(const Wx& wx, const crate::lower::model::Pos_& pos) {
    return crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), host_local(wx, pos)});
}


/// MovedMarks: fn Sinks, Text -> [Do]
Array<crate::lower::model::Do> moved_marks(const Sinks& sk, const Text& f) {
    return moved_by(sk, Read(Read::OwnRead{f}));
}


/// MovedBy: fn Sinks, Read -> [Do]
Array<crate::lower::model::Do> moved_by(const Sinks& sk, const Read& r) {
    auto moved = filter(sk.wx.gns, [&](const Gn& g) { return moves(r, g); });
    auto flags = each(moved, [&](const Gn& g) { return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(g.name, "_moved")})), Text::lit("set"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XBool{true})})})}); });
    auto heights_ = sort_nats(fold(moved, Array<Nat>{}, [&](const Array<Nat>& acc, const Gn& g) { return crate::check::types::add_nat(acc, g.height); }));
    auto marks = each(snaps_behind(sk.wx, r), [&](const SnapDef& sn) { return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(sn.name, "_snap")})), Text::lit("mark"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})}); });
    auto listed = lists_build(sk, r)
        ? Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("build_later"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})})})})})
        : Array<crate::lower::model::Do>{};
    auto answers = each(filter(sk.wx.dyn_answers, [&](const std::tuple<Text, Array<Read>>& _p0) {
        auto&& rds = std::get<1>(_p0);
        return has_read(reads_closed(sk.wx.dyn_reads, rds), r);
    }), [&](const std::tuple<Text, Array<Read>>& _p0) {
        auto&& name = std::get<0>(_p0);
        return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(name, "_port")})), Text::lit("fire"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})), Text::lit("ok"), Array<crate::lower::model::Ex>{}})});
    });
    auto adoptions = each(filter(sk.wx.flattens, [&](const FlatDef& fl) { return r == Read(Read::OwnRead{fl.outer}); }), [&](const FlatDef& fl) { return crate::lower::model::Do(crate::lower::model::Do::DoScope{adoption(fl)}); });
    return append(append(append(append(append(fold(heights_, flags, [&](const Array<crate::lower::model::Do>& acc, const Nat& h) { return append(acc, ask_wake(sk, h)); }), marks), listed), answers), adoptions), source_marks(sk.wx, r));
}


/// SourceMarks: fn Wx, Read -> [Do]
Array<crate::lower::model::Do> source_marks(const Wx& wx, const Read& r) {
    return fold(wx.builders, Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc, const crate::lower::model::ForDef& b) {
        return has_read(reads_closed(wx.dyn_reads, or_(crate::prelude::get(wx.dyn_reads, b->source), Array<Read>{})), r)
            ? crate::prelude::push(acc, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(b->source, "_cache")})), Text::lit("mark"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})}))
            : acc;
    });
}


/// SnapsBehind: fn Wx, Read -> [SnapDef]
Array<SnapDef> snaps_behind(const Wx& wx, const Read& r) {
    return filter(wx.snaps, [&](const SnapDef& sn) { return (r == Read(Read::OwnRead{sn.live})) || has_read(reads_closed(wx.dyn_reads, Array(std::vector{Read(Read::OwnRead{sn.live})})), r); });
}


/// ListsBuild: fn Sinks, Read -> Bool
bool lists_build(const Sinks& sk, const Read& r) {
    return len(snaps_behind(sk.wx, r)) > Nat(0u);
}


/// FiringCode: unbounded fn Sinks, Gn, Ex -> [Do]
Array<crate::lower::model::Do> firing_code(const Sinks& sk, const Gn& g, const crate::lower::model::Ex& x) {
    auto many = (len(g.outs) > Nat(1u)) && (!crate::lower::is_copy(g.ty));
    auto xv = many
        ? crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(x)})
        : x;
    return run_to_end(fold_job(g.outs, Array<crate::lower::model::Do>{}, ({
        auto xv_1 = xv;
        auto sk_2 = sk;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<Array<crate::lower::model::Do>, Out>)>>(prism_rtl::rc([=](std::tuple<Array<crate::lower::model::Do>, Out> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto xv_1_3 = xv_1;
            auto sk_2_3 = sk_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto o = p1;
                call_value(o.pipe(std::tuple{xv_1_3, ({
                auto sk_2_3_3 = sk_2_3;
                auto o_3 = o;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>(prism_rtl::rc([=](crate::lower::model::Ex p0) {
                return ({
                    auto sk_2_3_3_4 = sk_2_3_3;
                    auto o_3_4 = o_3;
                    once_job([=]() {
                    return ({
                        auto y = p0;
                        (prism_rtl::finished(sink_code(sk_2_3_3_4, o_3_4.sink, y)));
                    });
                });
                });
            })));
            })}), [=](Array<crate::lower::model::Do> call_97202) { return prism_rtl::finished(append(acc, call_97202)); });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<crate::lower::model::Do>> FiringCode::cycle() const {
    const auto& sk = this->sk;
    const auto& g = this->g;
    const auto& x = this->x;
    auto many = (len(g.outs) > Nat(1u)) && (!crate::lower::is_copy(g.ty));
    auto xv = many
        ? crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(x)})
        : x;
    return fold_job(g.outs, Array<crate::lower::model::Do>{}, ({
        auto xv_1 = xv;
        auto sk_2 = sk;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<Array<crate::lower::model::Do>, Out>)>>(prism_rtl::rc([=](std::tuple<Array<crate::lower::model::Do>, Out> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto xv_1_3 = xv_1;
            auto sk_2_3 = sk_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto o = p1;
                call_value(o.pipe(std::tuple{xv_1_3, ({
                auto sk_2_3_3 = sk_2_3;
                auto o_3 = o;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>(prism_rtl::rc([=](crate::lower::model::Ex p0) {
                return ({
                    auto sk_2_3_3_4 = sk_2_3_3;
                    auto o_3_4 = o_3;
                    once_job([=]() {
                    return ({
                        auto y = p0;
                        (prism_rtl::finished(sink_code(sk_2_3_3_4, o_3_4.sink, y)));
                    });
                });
                });
            })));
            })}), [=](Array<crate::lower::model::Do> call_97202) { return prism_rtl::finished(append(acc, call_97202)); });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start FiringCode, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::Do>> start_firing_code(Sinks sk, Gn g, crate::lower::model::Ex x) {
    return prism_rtl::make_rc<FiringCode>(sk, g, x);
}


/// FinishNode: unbounded fn Wx, Text, [((Text, OutTy))], Bool -> NodeDef
crate::lower::model::NodeDef finish_node(const Wx& wx0, const Text& qk, const Array<std::tuple<Text, crate::lower::model::OutTy>>& params, const bool& is_row) {
    auto closed_gns = each(wx0.gns, [&](const Gn& g) {
        return g.kind == GnKind(GnKind::GnUpdated{})
            ? with_reads(g, reads_closed(wx0.dyn_reads, g.reads))
            : g;
    });
    auto [row_defs, gns2] = finish_pending(wx0, heights(closed_gns));
    auto is_gen = is_row && (len(filter(wx0.fields, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& f = std::get<0>(_p0);
        return f == Text::lit("key");
    })) == Nat(0u));
    auto wx = ({
        Wx this_ = wx0;
        this_.gns = heights(gns2);
        this_.build = append(this_.build, updated_gaps(wx0, closed_gns, is_gen));
        this_.rows = fold(row_defs, this_.rows, [&](const Array<crate::lower::model::NodeDef>& acc, const crate::lower::model::NodeDef& rd) { return append(crate::prelude::push(acc, rd), rd.children); });
        this_;
    });
    auto combs = filter(wx.gns, [&](const Gn& g) { return is_comb(g.kind) || (g.kind == GnKind(GnKind::GnGather{})); });
    auto heights_ = sort_nats(fold(combs, Array<Nat>{}, [&](const Array<Nat>& acc, const Gn& g) { return crate::check::types::add_nat(acc, g.height); }));
    auto many = len(heights_) > Nat(1u);
    auto consts = each(heights_, [&](const Nat& h) { return std::tuple{wake_const(heights_, h), h, Text::lit("merges' height above the node's inputs")}; });
    auto live = filter(wx.places, [&](const Place& p_) { return p_.getter != Text::lit(""); });
    auto root_reads = ({
        __label__ _done;
        prism_rtl::Slot<Array<Read>> _v;
        auto&& _m = wx.root_dyn;
        if (prism_rtl::is_some(_m)) {
            auto&& rds = std::get<1>(prism_rtl::some_of(_m));
            _v.set(reads_closed(wx.dyn_reads, rds));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<Read>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto dirty_holds = fold(live, root_reads, [&](const Array<Read>& acc, const Place& p_) { return union_reads(acc, reads_closed(wx.dyn_reads, p_.reads)); });
    auto build_holds = reads_closed(wx.dyn_reads, wx.build_holds);
    auto sinks = Sinks{.wx = wx, .dirty = dirty_holds, .builds = build_holds, .heights = heights_, .many = many};
    auto ev_methods = run_to_end(each_job(filter(wx.gns, [&](const Gn& g) { return g.kind != GnKind(GnKind::GnNever{}); }), ({
        auto sinks_1 = sinks;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::MethDef>(Gn)>>(prism_rtl::rc([=](Gn p0) {
        return ({
            auto sinks_1_2 = sinks_1;
            entered(once_job([=]() {
            return ({
                auto g = p0;
                call_then(start_firing_code(sinks_1_2, g, crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")})), [=](Array<crate::lower::model::Do> firing_code_98994) { return prism_rtl::finished(crate::lower::model::MethDef{.name = g.name, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array(std::vector{std::tuple{Text::lit("v"), g.ty}}), .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = firing_code_98994, .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = gn_doc(g)}); });
            });
        }));
        });
    })));
    })));
    auto gather_ins = each(filter(wx.gns, [&](const Gn& g) { return g.kind == GnKind(GnKind::GnGather{}); }), [&](const Gn& g) { return gather_in(sinks, g); });
    auto place_getters = each(live, [&](const Place& p_) { return crate::lower::model::MethDef{.name = p_.getter, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = crate::lower::elem_ty(), .body = Array<crate::lower::model::Do>{}, .tail = p_.level, .doc = prism_rtl::cat("Place ", crate::lower::model::place_text(p_.pos), "'s level, read at the read point.")}; });
    auto wake_body = many
        ? Array(std::vector{wake_by_height(combs, heights_)})
        : each(combs, [&](const Gn& g) { return decide(g); });
    auto started_body = each(wx->started, [&](const Nat& st) { return self_call(gn_of(wx, st).name, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})})); });
    auto deferred_body = each(wx.defers, [&](const std::tuple<Text, Nat>& _p0) {
        auto&& f = std::get<0>(_p0);
        auto&& id = std::get<1>(_p0);
        return crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("v")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f)})), Text::lit("fired"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{self_call(gn_of(wx, id).name, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")})}))}), Array<crate::lower::model::Do>{}});
    });
    auto patch_body0 = fold(filter(live, [&](const Place& p_) { return emits(wx, p_.pos); }), Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc, const Place& p_) { return append(acc, patch_place(wx, p_)); });
    auto patch_body = append(patch_body0, root_dyn_patch(wx));
    auto build_body = build_steps(sinks, false);
    auto push_body = each(filter(wx.dyn_places, [&](const std::tuple<crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        return emits(wx, pos);
    }), [&](const std::tuple<crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        auto&& f = std::get<1>(_p0);
        auto&& t = std::get<2>(_p0);
        return crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("=="), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("element")})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f, "_element")}))}))}), dyn_place_write(sinks, f, crate::lower::model::Ex(crate::lower::model::Ex::XDecode{t, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}))})), Array<crate::lower::model::Do>{}});
    });
    auto hooks = filter(Array(std::vector{std::tuple{Text::lit("wake"), wake_body}, std::tuple{Text::lit("started"), started_body}, std::tuple{Text::lit("deferred"), deferred_body}, std::tuple{Text::lit("build"), build_body}, std::tuple{Text::lit("push"), push_body}, std::tuple{Text::lit("patch"), patch_body}}), [&](const std::tuple<Text, Array<crate::lower::model::Do>>& _p0) {
        auto&& b = std::get<1>(_p0);
        return len(b) > Nat(0u);
    });
    auto started_reg = len(wx->started) > Nat(0u)
        ? Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("on_started"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")}))})})})})})
        : Array<crate::lower::model::Do>{};
    auto links = each(wx.hosts, [&](const HostDef& h) { return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), prism_rtl::cat(h.name)})), Text::lit("link"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")}))})})})}); });
    auto rows_built = append(links, build_steps(sinks, true));
    auto subscribed = each(wx.subs, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& ev = std::get<0>(_p0);
        auto&& m = std::get<1>(_p0);
        auto&& t = std::get<2>(_p0);
        return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("subscribe_row"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XUpgrade{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), Text::lit("parent")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("p")})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("p")})), prism_rtl::cat(ev, "_port")}))}))}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("n")}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("v")}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("cx")})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("n")})), m, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), prism_rtl::cat(m, "_sub")}))})})})});
    });
    auto answers = append(each(filter(wx.answers, [&](const std::tuple<crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        return emits(wx, pos);
    }), [&](const std::tuple<crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        auto&& id = std::get<1>(_p0);
        auto&& t = std::get<2>(_p0);
        return answer_arm(wx, pos, id, t);
    }), each(filter(wx.dyn_places, [&](const std::tuple<crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        return emits(wx, pos);
    }), [&](const std::tuple<crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        auto&& f = std::get<1>(_p0);
        auto&& t = std::get<2>(_p0);
        return dyn_answer_arm(sinks, pos, f, t);
    }));
    auto forwards = append(each(filter(wx.builders, [&](const crate::lower::model::ForDef& b) { return emits(wx, b.pos); }), [&](const crate::lower::model::ForDef& b) { return std::tuple{pos_pat(b.pos, key_tail()), forward_answer(b)}; }), fold(filter(wx.gens, [&](const crate::lower::model::GenDef& gd) { return emits(wx, gd.pos); }), Array<std::tuple<crate::lower::model::Pa, crate::lower::model::Ex>>{}, [&](const Array<std::tuple<crate::lower::model::Pa, crate::lower::model::Ex>>& acc, const crate::lower::model::GenDef& gd) { return append(acc, gen_forwards(gd)); }));
    auto host_methods = fold(wx.hosts, Array<crate::lower::model::MethDef>{}, [&](const Array<crate::lower::model::MethDef>& acc, const HostDef& h) { return append(acc, Array(std::vector{typed_dispatch(sinks, prism_rtl::cat(h.name, "_answer"), h.scope), host_moved(sinks, h)})); });
    auto gathered = filter(wx.snaps, [&](const SnapDef& sn) { return !(sn.before || is_generation(wx, sn.builder)); });
    auto gathered_moved_ = append(append(each(gathered, [&](const SnapDef& sn) { return gathered_moved(sn); }), each(wx.snaps, [&](const SnapDef& sn) { return snap_publish(sinks, sn); })), flatten_methods(sinks));
    auto hosted_methods = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::MethDef>> _v;
        auto&& _m = wx.hosted_by;
        if (prism_rtl::is_some(_m)) {
            _v.set(Array(std::vector{typed_dispatch(sinks, Text::lit("deliver"), Nat(0u)), document_getter(wx)}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<crate::lower::model::MethDef>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto moved_method = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::MethDef>> _v;
        auto&& _m = wx.hosted_by;
        if (prism_rtl::is_some(_m)) {
            auto&& m = prism_rtl::some_of(_m);
            _v.set(Array(std::vector{crate::lower::node_::document_moved(m)}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<crate::lower::model::MethDef>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto row_methods_ = is_row ? row_methods(wx) : Array<crate::lower::model::MethDef>{};
    auto heard = each(row_hears(wx), [&](const Text& m) { return crate::lower::model::MethDef{.name = prism_rtl::cat("parent_wrote_", m), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = append(moved_by(sinks, Read(Read::ParentRead{m})), fold(wx.row_marks, Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc, const RowMarks& rm) { return append(acc, row_written(wx, rm, Read(Read::ParentRead{m}))); })), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = prism_rtl::cat("The block wrote behind its `", m, "`, which this row reads through the parent: the `!Updated` nodes over it are told and the wake asked at their heights; the rows of this row's own `for`s that read it are marked.")}; });
    auto top = fold(wx.gns, Nat(0u), [&](const Nat& hi, const Gn& g) { return crate::prelude::max(hi, g.height); });
    auto wakes_field = many
        ? Array(std::vector{std::tuple{Text::lit("wakes"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutWakes{}), Text::lit("the heights asked for this tick, lowest first")}})
        : Array<std::tuple<Text, crate::lower::model::OutTy, Text>>{};
    auto wakes_init = many
        ? Array(std::vector{std::tuple{Text::lit("wakes"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Wakes::default"), Array<crate::lower::model::Ex>{}})}})
        : Array<std::tuple<Text, crate::lower::model::Ex>>{};
    auto gen_fields = fold(wx.gens, Array<std::tuple<Text, crate::lower::model::OutTy, Text>>{}, [&](const Array<std::tuple<Text, crate::lower::model::OutTy, Text>>& acc, const crate::lower::model::GenDef& gd) { return append(acc, Array(std::vector{std::tuple{gd.name, crate::lower::model::OutTy(crate::lower::model::OutTy::OutCell{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutObj{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Row"), Array<crate::lower::model::OutTy>{}}))}))}))}), prism_rtl::cat("the current generation of the `rebuild` at place ", crate::lower::model::place_text(gd.pos))}, std::tuple{prism_rtl::cat(gd.name, "_count"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Cell"), Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutCount{})})}), Text::lit("how many generations it has built")}, std::tuple{prism_rtl::cat(gd.name, "_stale"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Cell"), Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})})}), Text::lit("its source changed since it was built")}})); });
    auto gen_inits = fold(wx.gens, Array<std::tuple<Text, crate::lower::model::Ex>>{}, [&](const Array<std::tuple<Text, crate::lower::model::Ex>>& acc, const crate::lower::model::GenDef& gd) { return append(acc, Array(std::vector{std::tuple{gd.name, crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("RefCell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XNone{})})})}, std::tuple{prism_rtl::cat(gd.name, "_count"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Cell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XIndex{Nat(0u)})})})}, std::tuple{prism_rtl::cat(gd.name, "_stale"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Cell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XBool{false})})})}})); });
    auto port_fields = each(wx.ports, [&](const Text& pn) { return std::tuple{prism_rtl::cat(pn, "_port"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutPort{prism_rtl::rc(gn_ty_named(wx, pn))}), prism_rtl::cat("`!", pn, "`, which rows subscribe to")}; });
    auto port_inits = each(wx.ports, [&](const Text& pn) { return std::tuple{prism_rtl::cat(pn, "_port"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Port::new"), Array<crate::lower::model::Ex>{}})}; });
    auto sub_fields = each(wx.subs, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& ev = std::get<0>(_p0);
        auto&& m = std::get<1>(_p0);
        auto&& t = std::get<2>(_p0);
        return std::tuple{prism_rtl::cat(m, "_sub"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Cell"), Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Handle"), Array<crate::lower::model::OutTy>{}}))})})}), prism_rtl::cat("the subscription to the parent's `!", ev, "`")};
    });
    auto sub_inits = each(wx.subs, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& ev = std::get<0>(_p0);
        auto&& m = std::get<1>(_p0);
        auto&& t = std::get<2>(_p0);
        return std::tuple{prism_rtl::cat(m, "_sub"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Cell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XNone{})})})};
    });
    auto fallible = ((wx.fallible || is_row) || (len(wx.builders) > Nat(0u))) || (len(wx.gens) > Nat(0u));
    return crate::lower::model::NodeDef{.name = wx.node_, .prism = crate::check::types::bare_name(qk), .doc = crate::lower::definition_text(wx.lx, qk), .params = params, .fields = append(append(append(append(wx.fields, wakes_field), gen_fields), port_fields), sub_fields), .consts = consts, .lets = wx.lets, .inits = append(wx.inits, append(append(append(append(wx.moves, wakes_init), gen_inits), port_inits), sub_inits)), .build = append(append(append(rows_built, wx->build), subscribed), started_reg), .fallible = fallible, .methods = append(append(append(append(append(append(append(append(ev_methods, gather_ins), place_getters), wx.getters), row_methods_), heard), host_methods), gathered_moved_), moved_method), .answers = append(answers, forwards), .hooks = hooks, .builders = wx.builders, .wakes = many, .children = wx->rows, .gens = wx.gens, .subs = wx.subs, .top = top, .row_kind = is_row
        ? is_gen
        ? crate::lower::model::RowKind(crate::lower::model::RowKind::GenerationRow{})
        : crate::lower::model::RowKind(crate::lower::model::RowKind::ForRow{})
        : crate::lower::model::RowKind(crate::lower::model::RowKind::NotARow{}), .hosted = hosted_methods};
}


prism_rtl::Turn<crate::lower::model::NodeDef> FinishNode::cycle() const {
    const auto& wx0 = this->wx0;
    const auto& qk = this->qk;
    const auto& params = this->params;
    const auto& is_row = this->is_row;
    auto closed_gns = each(wx0.gns, [&](const Gn& g) {
        return g.kind == GnKind(GnKind::GnUpdated{})
            ? with_reads(g, reads_closed(wx0.dyn_reads, g.reads))
            : g;
    });
    auto is_row_1 = is_row;
    auto params_2 = params;
    auto qk_3 = qk;
    auto wx0_4 = wx0;
    return call_then(start_finish_pending(wx0_4, heights(closed_gns)), [=](std::tuple<Array<crate::lower::model::NodeDef>, Array<Gn>> finish_pending_97759) {
        return ({
            auto [row_defs, gns2] = finish_pending_97759;
            auto is_gen = is_row_1 && (len(filter(wx0_4.fields, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
                auto&& f = std::get<0>(_p0);
                return f == Text::lit("key");
            })) == Nat(0u));
            auto wx = ({
                Wx this_ = wx0_4;
                this_.gns = heights(gns2);
                this_.build = append(this_.build, updated_gaps(wx0_4, closed_gns, is_gen));
                this_.rows = fold(row_defs, this_.rows, [&](const Array<crate::lower::model::NodeDef>& acc, const crate::lower::model::NodeDef& rd) { return append(crate::prelude::push(acc, rd), rd.children); });
                this_;
            });
            auto combs = filter(wx.gns, [&](const Gn& g) { return is_comb(g.kind) || (g.kind == GnKind(GnKind::GnGather{})); });
            auto heights_ = sort_nats(fold(combs, Array<Nat>{}, [&](const Array<Nat>& acc, const Gn& g) { return crate::check::types::add_nat(acc, g.height); }));
            auto many = len(heights_) > Nat(1u);
            auto consts = each(heights_, [&](const Nat& h) { return std::tuple{wake_const(heights_, h), h, Text::lit("merges' height above the node's inputs")}; });
            auto live = filter(wx.places, [&](const Place& p_) { return p_.getter != Text::lit(""); });
            auto root_reads = ({
                __label__ _done;
                prism_rtl::Slot<Array<Read>> _v;
                auto&& _m = wx.root_dyn;
                if (prism_rtl::is_some(_m)) {
                    auto&& rds = std::get<1>(prism_rtl::some_of(_m));
                    _v.set(reads_closed(wx.dyn_reads, rds));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Array<Read>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto dirty_holds = fold(live, root_reads, [&](const Array<Read>& acc, const Place& p_) { return union_reads(acc, reads_closed(wx.dyn_reads, p_.reads)); });
            auto build_holds = reads_closed(wx.dyn_reads, wx.build_holds);
            auto sinks = Sinks{.wx = wx, .dirty = dirty_holds, .builds = build_holds, .heights = heights_, .many = many};
            call_value(each_job(filter(wx.gns, [&](const Gn& g) { return g.kind != GnKind(GnKind::GnNever{}); }), ({
            auto sinks_5 = sinks;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::MethDef>(Gn)>>(prism_rtl::rc([=](Gn p0) {
            return ({
                auto sinks_5_6 = sinks_5;
                entered(once_job([=]() {
                return ({
                    auto g = p0;
                    call_then(start_firing_code(sinks_5_6, g, crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")})), [=](Array<crate::lower::model::Do> firing_code_98994) { return prism_rtl::finished(crate::lower::model::MethDef{.name = g.name, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array(std::vector{std::tuple{Text::lit("v"), g.ty}}), .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = firing_code_98994, .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = gn_doc(g)}); });
                });
            }));
            });
        })));
        })), [=](Array<crate::lower::model::MethDef> each_98854) {
            return ({
                auto ev_methods = each_98854;
                auto gather_ins = each(filter(wx.gns, [&](const Gn& g) { return g.kind == GnKind(GnKind::GnGather{}); }), [&](const Gn& g) { return gather_in(sinks, g); });
                auto place_getters = each(live, [&](const Place& p_) { return crate::lower::model::MethDef{.name = p_.getter, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = crate::lower::elem_ty(), .body = Array<crate::lower::model::Do>{}, .tail = p_.level, .doc = prism_rtl::cat("Place ", crate::lower::model::place_text(p_.pos), "'s level, read at the read point.")}; });
                auto wake_body = many
                    ? Array(std::vector{wake_by_height(combs, heights_)})
                    : each(combs, [&](const Gn& g) { return decide(g); });
                auto started_body = each(wx->started, [&](const Nat& st) { return self_call(gn_of(wx, st).name, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})})); });
                auto deferred_body = each(wx.defers, [&](const std::tuple<Text, Nat>& _p0) {
                    auto&& f = std::get<0>(_p0);
                    auto&& id = std::get<1>(_p0);
                    return crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("v")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f)})), Text::lit("fired"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{self_call(gn_of(wx, id).name, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")})}))}), Array<crate::lower::model::Do>{}});
                });
                auto patch_body0 = fold(filter(live, [&](const Place& p_) { return emits(wx, p_.pos); }), Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc, const Place& p_) { return append(acc, patch_place(wx, p_)); });
                auto patch_body = append(patch_body0, root_dyn_patch(wx));
                auto build_body = build_steps(sinks, false);
                auto push_body = each(filter(wx.dyn_places, [&](const std::tuple<crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text>& _p0) {
                    auto&& pos = std::get<0>(_p0);
                    return emits(wx, pos);
                }), [&](const std::tuple<crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text>& _p0) {
                    auto&& pos = std::get<0>(_p0);
                    auto&& f = std::get<1>(_p0);
                    auto&& t = std::get<2>(_p0);
                    return crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("=="), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("element")})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f, "_element")}))}))}), dyn_place_write(sinks, f, crate::lower::model::Ex(crate::lower::model::Ex::XDecode{t, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}))})), Array<crate::lower::model::Do>{}});
                });
                auto hooks = filter(Array(std::vector{std::tuple{Text::lit("wake"), wake_body}, std::tuple{Text::lit("started"), started_body}, std::tuple{Text::lit("deferred"), deferred_body}, std::tuple{Text::lit("build"), build_body}, std::tuple{Text::lit("push"), push_body}, std::tuple{Text::lit("patch"), patch_body}}), [&](const std::tuple<Text, Array<crate::lower::model::Do>>& _p0) {
                    auto&& b = std::get<1>(_p0);
                    return len(b) > Nat(0u);
                });
                auto started_reg = len(wx->started) > Nat(0u)
                    ? Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("on_started"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")}))})})})})})
                    : Array<crate::lower::model::Do>{};
                auto links = each(wx.hosts, [&](const HostDef& h) { return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), prism_rtl::cat(h.name)})), Text::lit("link"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")}))})})})}); });
                auto rows_built = append(links, build_steps(sinks, true));
                auto subscribed = each(wx.subs, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
                    auto&& ev = std::get<0>(_p0);
                    auto&& m = std::get<1>(_p0);
                    auto&& t = std::get<2>(_p0);
                    return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("subscribe_row"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XUpgrade{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), Text::lit("parent")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("p")})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("p")})), prism_rtl::cat(ev, "_port")}))}))}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("n")}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("v")}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("cx")})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("n")})), m, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), prism_rtl::cat(m, "_sub")}))})})})});
                });
                auto answers = append(each(filter(wx.answers, [&](const std::tuple<crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text>& _p0) {
                    auto&& pos = std::get<0>(_p0);
                    return emits(wx, pos);
                }), [&](const std::tuple<crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text>& _p0) {
                    auto&& pos = std::get<0>(_p0);
                    auto&& id = std::get<1>(_p0);
                    auto&& t = std::get<2>(_p0);
                    return answer_arm(wx, pos, id, t);
                }), each(filter(wx.dyn_places, [&](const std::tuple<crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text>& _p0) {
                    auto&& pos = std::get<0>(_p0);
                    return emits(wx, pos);
                }), [&](const std::tuple<crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text>& _p0) {
                    auto&& pos = std::get<0>(_p0);
                    auto&& f = std::get<1>(_p0);
                    auto&& t = std::get<2>(_p0);
                    return dyn_answer_arm(sinks, pos, f, t);
                }));
                auto forwards = append(each(filter(wx.builders, [&](const crate::lower::model::ForDef& b) { return emits(wx, b.pos); }), [&](const crate::lower::model::ForDef& b) { return std::tuple{pos_pat(b.pos, key_tail()), forward_answer(b)}; }), fold(filter(wx.gens, [&](const crate::lower::model::GenDef& gd) { return emits(wx, gd.pos); }), Array<std::tuple<crate::lower::model::Pa, crate::lower::model::Ex>>{}, [&](const Array<std::tuple<crate::lower::model::Pa, crate::lower::model::Ex>>& acc, const crate::lower::model::GenDef& gd) { return append(acc, gen_forwards(gd)); }));
                auto host_methods = fold(wx.hosts, Array<crate::lower::model::MethDef>{}, [&](const Array<crate::lower::model::MethDef>& acc, const HostDef& h) { return append(acc, Array(std::vector{typed_dispatch(sinks, prism_rtl::cat(h.name, "_answer"), h.scope), host_moved(sinks, h)})); });
                auto gathered = filter(wx.snaps, [&](const SnapDef& sn) { return !(sn.before || is_generation(wx, sn.builder)); });
                auto gathered_moved_ = append(append(each(gathered, [&](const SnapDef& sn) { return gathered_moved(sn); }), each(wx.snaps, [&](const SnapDef& sn) { return snap_publish(sinks, sn); })), flatten_methods(sinks));
                auto hosted_methods = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::lower::model::MethDef>> _v;
                    auto&& _m = wx.hosted_by;
                    if (prism_rtl::is_some(_m)) {
                        _v.set(Array(std::vector{typed_dispatch(sinks, Text::lit("deliver"), Nat(0u)), document_getter(wx)}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Array<crate::lower::model::MethDef>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto moved_method = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::lower::model::MethDef>> _v;
                    auto&& _m = wx.hosted_by;
                    if (prism_rtl::is_some(_m)) {
                        auto&& m = prism_rtl::some_of(_m);
                        _v.set(Array(std::vector{crate::lower::node_::document_moved(m)}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Array<crate::lower::model::MethDef>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto row_methods_ = is_row_1 ? row_methods(wx) : Array<crate::lower::model::MethDef>{};
                auto heard = each(row_hears(wx), [&](const Text& m) { return crate::lower::model::MethDef{.name = prism_rtl::cat("parent_wrote_", m), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = append(moved_by(sinks, Read(Read::ParentRead{m})), fold(wx.row_marks, Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc, const RowMarks& rm) { return append(acc, row_written(wx, rm, Read(Read::ParentRead{m}))); })), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = prism_rtl::cat("The block wrote behind its `", m, "`, which this row reads through the parent: the `!Updated` nodes over it are told and the wake asked at their heights; the rows of this row's own `for`s that read it are marked.")}; });
                auto top = fold(wx.gns, Nat(0u), [&](const Nat& hi, const Gn& g) { return crate::prelude::max(hi, g.height); });
                auto wakes_field = many
                    ? Array(std::vector{std::tuple{Text::lit("wakes"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutWakes{}), Text::lit("the heights asked for this tick, lowest first")}})
                    : Array<std::tuple<Text, crate::lower::model::OutTy, Text>>{};
                auto wakes_init = many
                    ? Array(std::vector{std::tuple{Text::lit("wakes"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Wakes::default"), Array<crate::lower::model::Ex>{}})}})
                    : Array<std::tuple<Text, crate::lower::model::Ex>>{};
                auto gen_fields = fold(wx.gens, Array<std::tuple<Text, crate::lower::model::OutTy, Text>>{}, [&](const Array<std::tuple<Text, crate::lower::model::OutTy, Text>>& acc, const crate::lower::model::GenDef& gd) { return append(acc, Array(std::vector{std::tuple{gd.name, crate::lower::model::OutTy(crate::lower::model::OutTy::OutCell{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutObj{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Row"), Array<crate::lower::model::OutTy>{}}))}))}))}), prism_rtl::cat("the current generation of the `rebuild` at place ", crate::lower::model::place_text(gd.pos))}, std::tuple{prism_rtl::cat(gd.name, "_count"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Cell"), Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutCount{})})}), Text::lit("how many generations it has built")}, std::tuple{prism_rtl::cat(gd.name, "_stale"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Cell"), Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})})}), Text::lit("its source changed since it was built")}})); });
                auto gen_inits = fold(wx.gens, Array<std::tuple<Text, crate::lower::model::Ex>>{}, [&](const Array<std::tuple<Text, crate::lower::model::Ex>>& acc, const crate::lower::model::GenDef& gd) { return append(acc, Array(std::vector{std::tuple{gd.name, crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("RefCell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XNone{})})})}, std::tuple{prism_rtl::cat(gd.name, "_count"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Cell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XIndex{Nat(0u)})})})}, std::tuple{prism_rtl::cat(gd.name, "_stale"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Cell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XBool{false})})})}})); });
                auto port_fields = each(wx.ports, [&](const Text& pn) { return std::tuple{prism_rtl::cat(pn, "_port"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutPort{prism_rtl::rc(gn_ty_named(wx, pn))}), prism_rtl::cat("`!", pn, "`, which rows subscribe to")}; });
                auto port_inits = each(wx.ports, [&](const Text& pn) { return std::tuple{prism_rtl::cat(pn, "_port"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Port::new"), Array<crate::lower::model::Ex>{}})}; });
                auto sub_fields = each(wx.subs, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
                    auto&& ev = std::get<0>(_p0);
                    auto&& m = std::get<1>(_p0);
                    auto&& t = std::get<2>(_p0);
                    return std::tuple{prism_rtl::cat(m, "_sub"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Cell"), Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Handle"), Array<crate::lower::model::OutTy>{}}))})})}), prism_rtl::cat("the subscription to the parent's `!", ev, "`")};
                });
                auto sub_inits = each(wx.subs, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
                    auto&& ev = std::get<0>(_p0);
                    auto&& m = std::get<1>(_p0);
                    auto&& t = std::get<2>(_p0);
                    return std::tuple{prism_rtl::cat(m, "_sub"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Cell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XNone{})})})};
                });
                auto fallible = ((wx.fallible || is_row_1) || (len(wx.builders) > Nat(0u))) || (len(wx.gens) > Nat(0u));
                (prism_rtl::finished(crate::lower::model::NodeDef{.name = wx.node_, .prism = crate::check::types::bare_name(qk_3), .doc = crate::lower::definition_text(wx.lx, qk_3), .params = params_2, .fields = append(append(append(append(wx.fields, wakes_field), gen_fields), port_fields), sub_fields), .consts = consts, .lets = wx.lets, .inits = append(wx.inits, append(append(append(append(wx.moves, wakes_init), gen_inits), port_inits), sub_inits)), .build = append(append(append(rows_built, wx->build), subscribed), started_reg), .fallible = fallible, .methods = append(append(append(append(append(append(append(append(ev_methods, gather_ins), place_getters), wx.getters), row_methods_), heard), host_methods), gathered_moved_), moved_method), .answers = append(answers, forwards), .hooks = hooks, .builders = wx.builders, .wakes = many, .children = wx->rows, .gens = wx.gens, .subs = wx.subs, .top = top, .row_kind = is_row_1
                ? is_gen
                ? crate::lower::model::RowKind(crate::lower::model::RowKind::GenerationRow{})
                : crate::lower::model::RowKind(crate::lower::model::RowKind::ForRow{})
                : crate::lower::model::RowKind(crate::lower::model::RowKind::NotARow{}), .hosted = hosted_methods}));
            });
        });
        });
    });
}


/// `Start FinishNode, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::NodeDef> start_finish_node(Wx wx0, Text qk, Array<std::tuple<Text, crate::lower::model::OutTy>> params, bool is_row) {
    return prism_rtl::make_rc<FinishNode>(wx0, qk, params, is_row);
}


/// IsGeneration: fn Wx, Text -> Bool
bool is_generation(const Wx& wx, const Text& name) {
    return len(filter(wx.gens, [&](const crate::lower::model::GenDef& gd) { return gd.name == name; })) > Nat(0u);
}


/// FlattenMethods: fn Sinks -> [MethDef]
Array<crate::lower::model::MethDef> flatten_methods(const Sinks& sk) {
    auto wx = sk.wx;
    auto adopts_1 = each(wx.flattens, [&](const FlatDef& fl) {
        return ({
            auto set_1 = crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(fl.name, "_inner")})), Text::lit("set"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), fl.outer, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
            crate::lower::model::MethDef{.name = prism_rtl::cat(fl.name, "_adopt"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = append(Array(std::vector{set_1}), hold_written(sk, prism_rtl::cat(fl.name, "_inner"))), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = Text::lit("`@Flatten` adopts the inner its `rebuild`'s dynamic held after the tick before, among this tick's first firings: from here on it reads that inner (Semantics ch. 7).")};
        });
    });
    auto dyn_gens = filter(wx.gens, [&](const crate::lower::model::GenDef& gd) { return len(filter(wx.snaps, [&](const SnapDef& sn) { return sn.builder == gd.name; })) > Nat(0u); });
    auto moved_2 = each(dyn_gens, [&](const crate::lower::model::GenDef& gd) {
        return ({
            auto marks = fold(filter(wx.flattens, [&](const FlatDef& fl) { return fl->generation == gd.name; }), Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc, const FlatDef& fl) { return append(acc, hold_written(sk, prism_rtl::cat(fl.name, "_inner"))); });
            crate::lower::model::MethDef{.name = prism_rtl::cat(gd.name, "_result_moved"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = marks, .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = Text::lit("The current generation's result moved: what reads a `@Flatten` over it reads it again.")};
        });
    });
    return append(adopts_1, moved_2);
}


/// HostMoved: fn Sinks, HostDef -> MethDef
crate::lower::model::MethDef host_moved(const Sinks& sk, const HostDef& h) {
    return crate::lower::model::MethDef{.name = prism_rtl::cat(h.name, "_moved"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = hold_written(sk, prism_rtl::cat(h.name, "_doc_now")), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = prism_rtl::cat("A node of the child hosted at place ", crate::lower::model::place_text(h.pos), " wrote behind its document: the structure is marked as for a write of a hold it reads (pick HO), the snapshot listed to be taken; the program's `$doc` moves when it is published, the tick after (pick ST).")};
}


/// BuildSteps: fn Sinks, Bool -> [Do]
Array<crate::lower::model::Do> build_steps(const Sinks& sk, const bool& at_build) {
    auto wx = sk.wx;
    auto recv = at_build
        ? crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})
        : crate::lower::model::Ex(crate::lower::model::Ex::XSelf{});
    auto take_fn = ({
        auto at_build_1 = at_build;
        auto sk_2 = sk;
        (prism_rtl::rc([=](const SnapDef& sn) { return at_build_1 ? snap_take_at_build(sn) : snap_take(sk_2, sn); }));
    });
    auto builder_fn = ({
        auto wx_1 = wx;
        auto take_fn_2 = take_fn;
        auto recv_3 = recv;
        (prism_rtl::rc([=](const crate::lower::model::ForDef& b) {
        return ({
            auto before_ = each(filter(wx_1.snaps, [&](const SnapDef& sn) { return sn.before && (sn.builder == b.name); }), take_fn_2);
            auto after_ = each(filter(wx_1.snaps, [&](const SnapDef& sn) { return (!sn.before) && (sn.builder == b.name); }), take_fn_2);
            append(crate::prelude::push(before_, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(recv_3), prism_rtl::cat(b.name, "_build"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))})), after_);
        });
    }));
    });
    auto gen__fn = ({
        auto at_build_1 = at_build;
        auto recv_2 = recv;
        auto wx_3 = wx;
        auto take_fn_4 = take_fn;
        (prism_rtl::rc([=](const crate::lower::model::GenDef& gd) {
        return ({
            auto built = at_build_1
                ? crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(recv_2), prism_rtl::cat(gd.name, "_build"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))})
                : crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(gd.name, "_stale")})), Text::lit("replace"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XBool{false})})}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(gd.name, "_build"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))})}), Array<crate::lower::model::Do>{}});
            append(Array(std::vector{built}), each(filter(wx_3.snaps, [&](const SnapDef& sn) { return (!sn.before) && (sn.builder == gd.name); }), take_fn_4));
        });
    }));
    });
    return fold(crate::check::errors::range0(len(wx.scopes) + Nat(1u)), Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc, const Nat& i) {
        return ({
            auto k = or_(len(wx.scopes).checked_sub(i), Nat(0u));
            auto builders = fold(filter(wx.builders, [&](const crate::lower::model::ForDef& b) { return b.pos.scope == k; }), Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& a, const crate::lower::model::ForDef& b) { return append(a, builder_fn(b)); });
            append(append(acc, builders), fold(filter(wx.gens, [&](const crate::lower::model::GenDef& gd) { return gd.pos.scope == k; }), Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& a, const crate::lower::model::GenDef& gd) { return append(a, gen__fn(gd)); }));
        });
    });
}


/// SnapTakeAtBuild: fn SnapDef -> Do
crate::lower::model::Do snap_take_at_build(const SnapDef& sn) {
    return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), prism_rtl::cat(sn.name, "_snap")})), Text::lit("take"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), prism_rtl::cat(sn.name, "_now"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
}


/// SnapTake: fn Sinks, SnapDef -> Do
crate::lower::model::Do snap_take(const Sinks& sk, const SnapDef& sn) {
    auto now = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(sn.name, "_now"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})});
    auto take_ = crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(sn.name, "_snap")})), sn.eq ? Text::lit("take_compared") : Text::lit("take"), Array(std::vector{now, crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
    auto queue = crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("answer_later"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XLater{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), prism_rtl::cat(sn.name, "_publish"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))})})})});
    auto queued = crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(sn.name, "_snap")})), Text::lit("queue"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("node")}), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})}), queue}), Array<crate::lower::model::Do>{}});
    return crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(sn.name, "_snap")})), Text::lit("marked"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{take_, queued}), Array<crate::lower::model::Do>{}});
}


/// SnapPublish: fn Sinks, SnapDef -> MethDef
crate::lower::model::MethDef snap_publish(const Sinks& sk, const SnapDef& sn) {
    return crate::lower::model::MethDef{.name = prism_rtl::cat(sn.name, "_publish"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(sn.name, "_snap")})), Text::lit("published"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), hold_written(sk, sn.name), Array<crate::lower::model::Do>{}})}), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = prism_rtl::cat(sn.what, ", published: its snapshot of the tick before moved it, written as a hold is (pick ST).")};
}


/// GatheredMoved: fn SnapDef -> MethDef
crate::lower::model::MethDef gathered_moved(const SnapDef& sn) {
    return crate::lower::model::MethDef{.name = prism_rtl::cat(sn.name, "_moved"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(sn.name, "_snap")})), Text::lit("mark"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})}), crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("build_later"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})})})})}), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = Text::lit("A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).")};
}


/// DocumentGetter: fn Wx -> MethDef
crate::lower::model::MethDef document_getter(const Wx& wx) {
    auto is_own_fn = prism_rtl::rc([=](const crate::lower::model::Pos_& p_) { return p_.scope == Nat(0u); });
    auto body = document_body(({
        auto f = prism_rtl::rc(vec_push);
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Do>(std::tuple<crate::lower::model::Ex, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<crate::lower::model::Ex, crate::lower::model::Ex> _p0) {
        auto&& a0 = std::get<0>(_p0);
        auto&& a1 = std::get<1>(_p0);
        return ({
            auto f_1 = f;
            once_job([=]() { return prism_rtl::finished(f_1(a0, a1)); });
        });
    })));
    }), filter(wx.places, [&](const Place& pl) { return is_own_fn(pl.pos); }), filter(wx.builders, [&](const crate::lower::model::ForDef& b) { return is_own_fn(b.pos); }), filter(wx.gens, [&](const crate::lower::model::GenDef& gd) { return is_own_fn(gd.pos); }));
    return crate::lower::model::MethDef{.name = Text::lit("document"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Vec"), Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutPath{}), crate::lower::elem_ty()})})})}), .body = append(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("doc")})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Vec"), Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutPath{}), crate::lower::elem_ty()})})})})}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Vec::new"), Array<crate::lower::model::Ex>{}})})}), body), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("doc")}), .doc = Text::lit("The row's own places, entries of its host's document, by their paths relative to the row (pick HO).")};
}


/// DocumentMoved: fn Text -> MethDef
crate::lower::model::MethDef document_moved(const Text& m) {
    return crate::lower::model::MethDef{.name = Text::lit("document_moved"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("parent")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XUpgrade{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("parent")}))}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("parent")})), m, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})}), Array<crate::lower::model::Do>{}})}), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = Text::lit("A place of this row may have moved: its host's document moved, and the host's readers and rows are marked (pick HO).")};
}


/// DocumentBody: fn (fn Ex, Ex -> Do), [Place], [ForDef], [GenDef] -> [Do]
Array<crate::lower::model::Do> document_body(const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Do>(std::tuple<crate::lower::model::Ex, crate::lower::model::Ex>)>& add_fn, const Array<Place>& places, const Array<crate::lower::model::ForDef>& builders, const Array<crate::lower::model::GenDef>& gens) {
    auto statics = run_to_end(each_job(places, ({
        auto add_fn_1 = add_fn;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Do>(Place)>>(prism_rtl::rc([=](Place p0) {
        return ({
            auto add_fn_1_2 = add_fn_1;
            entered(once_job([=]() {
            return ({
                auto pl = p0;
                ({
                auto level = pl.getter == Text::lit("")
                    ? pl.level
                    : crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), pl.getter, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})});
                add_fn_1_2(std::tuple{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Path::root"), Array<crate::lower::model::Ex>{}})), Text::lit("at"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XIndex{pl.pos.at})})}), level})->cycle();
            });
            });
        }));
        });
    })));
    })));
    auto rows = run_to_end(each_job(builders, ({
        auto add_fn_1 = add_fn;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Do>(crate::lower::model::ForDef)>>(prism_rtl::rc([=](crate::lower::model::ForDef p0) {
        return ({
            auto add_fn_1_2 = add_fn_1;
            entered(once_job([=]() {
            return ({
                auto b = p0;
                call_value(add_fn_1_2(std::tuple{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Path::root"), Array<crate::lower::model::Ex>{}})), Text::lit("at"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XIndex{b.pos.at})})})), Text::lit("child"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Segment::Key"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("k")})), Text::lit("to_pod"), Array<crate::lower::model::Ex>{}})})})})})), Text::lit("join"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("p")}))})})}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("e")})}), [=](crate::lower::model::Do add_114367) { return prism_rtl::finished(crate::lower::model::Do(crate::lower::model::Do::DoFor{crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("k")}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), b.name})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}})), Text::lit("iter"), Array<crate::lower::model::Ex>{}}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoFor{crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("p")}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("e")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")})), Text::lit("document"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{add_114367})})})})); });
            });
        }));
        });
    })));
    })));
    auto generations = run_to_end(each_job(gens, ({
        auto add_fn_1 = add_fn;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Do>(crate::lower::model::GenDef)>>(prism_rtl::rc([=](crate::lower::model::GenDef p0) {
        return ({
            auto add_fn_1_2 = add_fn_1;
            entered(once_job([=]() {
            return ({
                auto gd = p0;
                call_value(add_fn_1_2(std::tuple{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Path::root"), Array<crate::lower::model::Ex>{}})), Text::lit("at"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XIndex{gd.pos.at})})})), Text::lit("child"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Segment::Gen"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("g")})})})})})), Text::lit("join"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("p")}))})})}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("e")})}), [=](crate::lower::model::Do add_114939) { return prism_rtl::finished(crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), gd.name})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}})), Text::lit("as_ref"), Array<crate::lower::model::Ex>{}}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("g")}), crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("-"), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(gd.name, "_count")})), Text::lit("get"), Array<crate::lower::model::Ex>{}})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XIndex{Nat(1u)}))})}), crate::lower::model::Do(crate::lower::model::Do::DoFor{crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("p")}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("e")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")})), Text::lit("document"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{add_114939})})}), Array<crate::lower::model::Do>{}})); });
            });
        }));
        });
    })));
    })));
    return append(append(statics, rows), generations);
}


/// MapInsert: fn Ex, Ex -> Do
crate::lower::model::Do map_insert(const crate::lower::model::Ex& path_, const crate::lower::model::Ex& e) {
    return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("doc")})), Text::lit("insert"), Array(std::vector{path_, e})})});
}


/// VecPush: fn Ex, Ex -> Do
crate::lower::model::Do vec_push(const crate::lower::model::Ex& path_, const crate::lower::model::Ex& e) {
    return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("doc")})), Text::lit("push"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XTuple{Array(std::vector{path_, e})})})})});
}


/// DynAnswerArm: fn Sinks, Pos, Text, OutTy -> ((Pa, Ex))
std::tuple<crate::lower::model::Pa, crate::lower::model::Ex> dyn_answer_arm(const Sinks& sk, const crate::lower::model::Pos_& pos, const Text& f, const crate::lower::model::OutTy& t) {
    return std::tuple{pos_pat(pos, Array<crate::lower::model::Pa>{}), crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dyn_place_write(sk, f, crate::lower::model::Ex(crate::lower::model::Ex::XDecode{t, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}))})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}))})};
}


/// DynPlaceWrite: fn Sinks, Text, Ex -> [Do]
Array<crate::lower::model::Do> dyn_place_write(const Sinks& sk, const Text& f, const crate::lower::model::Ex& value) {
    return append(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f)})), Text::lit("set"), Array(std::vector{value, crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})}), hold_written(sk, f));
}


/// UpdatedGaps: fn Wx, [Gn], Bool -> [Do]
Array<crate::lower::model::Do> updated_gaps(const Wx& wx, const Array<Gn>& gns, const bool& is_gen) {
    auto holds = fold(wx.fields, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, crate::lower::model::OutTy, Text>& _p1) {
        auto&& f = std::get<0>(_p1);
        auto&& t = std::get<1>(_p1);
        return is_hold(t) ? crate::prelude::push(acc, f) : acc;
    });
    auto derived = keys(wx.dyn_reads);
    auto roots = snap_names(wx);
    auto own = fold(filter(gns, [&](const Gn& g) { return g.kind == GnKind(GnKind::GnUpdated{}); }), Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc, const Gn& g) {
        return fold(g.reads, acc, [&](const Array<crate::lower::model::Do>& a, const Read& r) {
            return ({
                __label__ _done;
                prism_rtl::Slot<Array<crate::lower::model::Do>> _v;
                if (prism_rtl::is<Read::ParentRead>(r)) {
                    auto&& f = prism_rtl::as<Read::ParentRead>(r).a0;
                    _v.set(is_gen
                        ? crate::prelude::push(a, crate::lower::refusal_do(prism_rtl::cat("`!Updated` of a dynamic in a generation that reads its block's `", f, "`, which the block does not tell a generation of (gap DY)")))
                        : a);
                    goto _done;
                }
                if (prism_rtl::is<Read::OwnRead>(r)) {
                    auto&& f = prism_rtl::as<Read::OwnRead>(r).a0;
                    _v.set((crate::check::types::has_text(holds, f) || crate::check::types::has_text(derived, f)) || crate::check::types::has_text(roots, f)
                        ? a
                        : crate::prelude::push(a, crate::lower::refusal_do(prism_rtl::cat("`!Updated` of a dynamic that reads `", f, "`, which no sink of this node writes (no height for its event)"))));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        });
    });
    return fold(wx.pending, own, [&](const Array<crate::lower::model::Do>& acc, const PendingRow& p_) {
        return fold(row_hears(p_.wx), acc, [&](const Array<crate::lower::model::Do>& a, const Text& m) {
            return ({
                auto behind = reads_closed(wx.dyn_reads, Array(std::vector{Read(Read::OwnRead{m})}));
                auto written = fold(behind, false, [&](const bool& w, const Read& r) {
                    return w || ({
                        __label__ _done;
                        prism_rtl::Slot<bool> _v;
                        if (prism_rtl::is<Read::OwnRead>(r)) {
                            auto&& h = prism_rtl::as<Read::OwnRead>(r).a0;
                            _v.set(crate::check::types::has_text(holds, h));
                            goto _done;
                        }
                        if (prism_rtl::is<Read::ParentRead>(r)) {
                            _v.set(true);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                });
                (crate::check::types::has_text(roots, m) || reaches_snap(roots, behind)
                ? crate::prelude::push(a, crate::lower::refusal_do(prism_rtl::cat("`!Updated` of a dynamic in a row that reads its block's `", m, "`, a structural dynamic the block publishes at the start of a tick, not lowered for a row's `!Updated` (gap SU)")))
                : written || crate::check::types::has_text(derived, m)
                ? a
                : crate::prelude::push(a, crate::lower::refusal_do(prism_rtl::cat("`!Updated` of a dynamic in a row that reads its block's `", m, "`, which no sink of the block writes (no height for its event)"))));
            });
        });
    });
}


/// FinishPending: unbounded fn Wx, [Gn] -> (([NodeDef], [Gn]))
std::tuple<Array<crate::lower::model::NodeDef>, Array<Gn>> finish_pending(const Wx& wx, const Array<Gn>& gns) {
    return run_to_end(fold_job(wx.pending, std::tuple{Array<crate::lower::model::NodeDef>{}, gns}, ({
        auto wx_1 = wx;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::NodeDef>, Array<Gn>>>(std::tuple<std::tuple<Array<crate::lower::model::NodeDef>, Array<Gn>>, PendingRow>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::lower::model::NodeDef>, Array<Gn>>, PendingRow> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto wx_1_2 = wx_1;
            entered(once_job([=]() {
            return ({
                auto [defs, cur] = p0;
                auto p_ = p1;
                ({
                auto floors = fold(row_hears(p_.wx), Map<Text, Nat>{}, [&](const Map<Text, Nat>& acc, const Text& m) { return insert(acc, m, parent_floor(wx_1_2, cur, Array(std::vector{Read(Read::ParentRead{m})}))); });
                auto floored = ({
                    Wx this_ = p_.wx;
                    this_.floors = floors;
                    this_.gns = each(this_.gns, [&](const Gn& g) {
                        return g.kind == GnKind(GnKind::GnUpdated{})
                            ? with_floor(g, parent_floor(wx_1_2, cur, reads_closed(p_.wx.dyn_reads, g.reads)))
                            : g;
                    });
                    this_;
                });
                call_then(start_finish_node(floored, p_.qk, p_.params, true), [=](crate::lower::model::NodeDef finish_node_119205) {
                return ({
                    auto def = finish_node_119205;
                    auto next = ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Gn>> _v;
                        auto&& _m = p_.gather;
                        if (prism_rtl::is_some(_m)) {
                            auto&& gid = prism_rtl::some_of(_m);
                            _v.set(each(cur, [&](const Gn& g) { return g.id == gid ? with_height(g, def.top + Nat(1u)) : g; }));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(cur);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    (prism_rtl::finished(std::tuple{crate::prelude::push(defs, def), next}));
                });
            });
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Array<crate::lower::model::NodeDef>, Array<Gn>>> FinishPending::cycle() const {
    const auto& wx = this->wx;
    const auto& gns = this->gns;
    return fold_job(wx.pending, std::tuple{Array<crate::lower::model::NodeDef>{}, gns}, ({
        auto wx_1 = wx;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::NodeDef>, Array<Gn>>>(std::tuple<std::tuple<Array<crate::lower::model::NodeDef>, Array<Gn>>, PendingRow>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::lower::model::NodeDef>, Array<Gn>>, PendingRow> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto wx_1_2 = wx_1;
            entered(once_job([=]() {
            return ({
                auto [defs, cur] = p0;
                auto p_ = p1;
                ({
                auto floors = fold(row_hears(p_.wx), Map<Text, Nat>{}, [&](const Map<Text, Nat>& acc, const Text& m) { return insert(acc, m, parent_floor(wx_1_2, cur, Array(std::vector{Read(Read::ParentRead{m})}))); });
                auto floored = ({
                    Wx this_ = p_.wx;
                    this_.floors = floors;
                    this_.gns = each(this_.gns, [&](const Gn& g) {
                        return g.kind == GnKind(GnKind::GnUpdated{})
                            ? with_floor(g, parent_floor(wx_1_2, cur, reads_closed(p_.wx.dyn_reads, g.reads)))
                            : g;
                    });
                    this_;
                });
                call_then(start_finish_node(floored, p_.qk, p_.params, true), [=](crate::lower::model::NodeDef finish_node_119205) {
                return ({
                    auto def = finish_node_119205;
                    auto next = ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Gn>> _v;
                        auto&& _m = p_.gather;
                        if (prism_rtl::is_some(_m)) {
                            auto&& gid = prism_rtl::some_of(_m);
                            _v.set(each(cur, [&](const Gn& g) { return g.id == gid ? with_height(g, def.top + Nat(1u)) : g; }));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(cur);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    (prism_rtl::finished(std::tuple{crate::prelude::push(defs, def), next}));
                });
            });
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start FinishPending, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::lower::model::NodeDef>, Array<Gn>>> start_finish_pending(Wx wx, Array<Gn> gns) {
    return prism_rtl::make_rc<FinishPending>(wx, gns);
}


/// ParentFloor: fn Wx, [Gn], [Read] -> Nat
Nat parent_floor(const Wx& wx, const Array<Gn>& gns, const Array<Read>& reads) {
    return fold(reads, Nat(0u), [&](const Nat& hi, const Read& r) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Nat> _v;
            if (prism_rtl::is<Read::ParentRead>(r)) {
                auto&& m = prism_rtl::as<Read::ParentRead>(r).a0;
                _v.set(fold(reads_closed(wx.dyn_reads, Array(std::vector{Read(Read::OwnRead{m})})), hi, [&](const Nat& h2, const Read& hr) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Nat> _v;
                        if (prism_rtl::is<Read::OwnRead>(hr)) {
                            auto&& f = prism_rtl::as<Read::OwnRead>(hr).a0;
                            _v.set(fold(gns, h2, [&](const Nat& h3, const Gn& g) { return writes_hold(g, f) ? crate::prelude::max(h3, g.height + Nat(1u)) : h3; }));
                            goto _done;
                        }
                        if (prism_rtl::is<Read::ParentRead>(hr)) {
                            auto&& up = prism_rtl::as<Read::ParentRead>(hr).a0;
                            _v.set(crate::prelude::max(h2, or_(crate::prelude::get(wx.floors, up), Nat(0u))));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                }));
                goto _done;
            }
            if (prism_rtl::is<Read::OwnRead>(r)) {
                _v.set(hi);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// WritesHold: fn Gn, Text -> Bool
bool writes_hold(const Gn& g, const Text& f) {
    return fold(g.outs, false, [&](const bool& acc, const Out& o) { return acc || sink_writes_hold(o.sink, f); });
}


/// SinkWritesHold: fn Sk, Text -> Bool
bool sink_writes_hold(const Sk& sk0, const Text& f) {
    if (prism_rtl::is<Sk::SkHold>(sk0)) {
        auto&& h = prism_rtl::as<Sk::SkHold>(sk0).a0;
        return h == f;
    }
    if (prism_rtl::is<Sk::SkMachine>(sk0)) {
        auto&& h = prism_rtl::as<Sk::SkMachine>(sk0).a0;
        return h == f;
    }
    {
        auto&& other = sk0;
        return false;
    }
}


/// WithFloor: fn Gn, Nat -> Gn
Gn with_floor(const Gn& g, const Nat& h) {
    Gn this_ = g;
    this_.floor = h;
    return this_;
}


/// WithHeight: fn Gn, Nat -> Gn
Gn with_height(const Gn& g, const Nat& h) {
    Gn this_ = g;
    this_.height = h;
    return this_;
}


/// RowHears: fn Wx -> [Text]
Array<Text> row_hears(const Wx& wx) {
    auto from_updated = fold(filter(wx.gns, [&](const Gn& g) { return g.kind == GnKind(GnKind::GnUpdated{}); }), Array<Read>{}, [&](const Array<Read>& acc, const Gn& g) { return union_reads(acc, reads_closed(wx.dyn_reads, g.reads)); });
    auto from_rows = fold(wx.row_marks, Array<Read>{}, [&](const Array<Read>& acc, const RowMarks& rm) { return union_reads(acc, reads_closed(wx.dyn_reads, append(rm.reads, each(rm.wrote, [&](const Text& m) { return Read(Read::OwnRead{m}); })))); });
    return fold(union_reads(from_updated, from_rows), Array<Text>{}, [&](const Array<Text>& acc, const Read& r) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            if (prism_rtl::is<Read::ParentRead>(r)) {
                auto&& m = prism_rtl::as<Read::ParentRead>(r).a0;
                _v.set(crate::check::types::add_text(acc, m));
                goto _done;
            }
            if (prism_rtl::is<Read::OwnRead>(r)) {
                _v.set(acc);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// RowWritten: fn Wx, RowMarks, Read -> [Do]
Array<crate::lower::model::Do> row_written(const Wx& wx, const RowMarks& rm, const Read& r) {
    auto dirty_1 = has_read(reads_closed(wx.dyn_reads, rm.reads), r)
        ? Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("dirty"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")}))})})})})})
        : Array<crate::lower::model::Do>{};
    auto told = fold(rm.wrote, Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc, const Text& m) {
        return has_read(reads_closed(wx.dyn_reads, Array(std::vector{Read(Read::OwnRead{m})})), r)
            ? crate::prelude::push(acc, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")})), prism_rtl::cat("parent_wrote_", m), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})}))
            : acc;
    });
    auto body = append(dirty_1, told);
    return len(body) == Nat(0u)
        ? Array<crate::lower::model::Do>{}
        : ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::Do>> _v;
        auto&& _m = rm.kind;
        if (prism_rtl::is<crate::lower::model::RowKind::GenerationRow>(_m)) {
            _v.set(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), rm.builder})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}})), Text::lit("as_ref"), Array<crate::lower::model::Ex>{}}), body, Array<crate::lower::model::Do>{}})}));
            goto _done;
        }
        {
            _v.set(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoFor{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), rm.builder})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}})), Text::lit("values"), Array<crate::lower::model::Ex>{}}), body})}));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// PatchPlace: fn Wx, Place -> [Do]
Array<crate::lower::model::Do> patch_place(const Wx& wx, const Place& p_) {
    auto pull = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{p_.getter}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), p_.getter, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
    auto at_ = place_at(wx, Text::lit("self"), p_.pos);
    return Array(std::vector{pull, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("changed"), Array(std::vector{at_, crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{p_.getter})), Text::lit("to_pod"), Array<crate::lower::model::Ex>{}})})})})});
}


/// Emits: fn Wx, Pos -> Bool
bool emits(const Wx& wx, const crate::lower::model::Pos_& pos) {
    return (pos.scope == Nat(0u)) && (wx.hosted_by == std::optional<Text>{});
}


/// ResultTold: fn Ex -> [Do]
Array<crate::lower::model::Do> result_told(const crate::lower::model::Ex& node_) {
    auto r_1 = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("r")}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(node_), Text::lit("result_value"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
    return Array(std::vector{r_1, result_kept(node_), result_tell()});
}


/// ResultMoved: fn Ex -> [Do]
Array<crate::lower::model::Do> result_moved(const crate::lower::model::Ex& node_) {
    auto r_1 = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("r")}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(node_), Text::lit("result_value"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
    auto last = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(node_), Text::lit("result_last")})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}})), Text::lit("as_ref"), Array<crate::lower::model::Ex>{}});
    auto differs = crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("!="), prism_rtl::rc(last), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("r")}))})})}))});
    return Array(std::vector{r_1, crate::lower::model::Do(crate::lower::model::Do::DoIf{differs, Array(std::vector{result_kept(node_), result_tell()}), Array<crate::lower::model::Do>{}})});
}


/// ResultKept: fn Ex -> Do
crate::lower::model::Do result_kept(const crate::lower::model::Ex& node_) {
    return crate::lower::model::Do(crate::lower::model::Do::DoAssign{crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(node_), Text::lit("result_last")})), Text::lit("borrow_mut"), Array<crate::lower::model::Ex>{}}))}), crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("r")}))})})})});
}


/// let resultTell
crate::lower::model::Do result_tell() {
    return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("result"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Outcome::Value"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("r")})})})})})});
}


/// Adoption: fn FlatDef -> [Do]
Array<crate::lower::model::Do> adoption(const FlatDef& fl) {
    auto adopt = crate::lower::model::Ex(crate::lower::model::Ex::XLater{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), prism_rtl::cat(fl.name, "_adopt"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))});
    return Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("node")}), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})}), crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("answer_later"), Array(std::vector{adopt})})})});
}


/// PlaceAt: fn Wx, Text, Pos -> Ex
crate::lower::model::Ex place_at(const Wx& wx, const Text& recv, const crate::lower::model::Pos_& pos) {
    auto at_ = Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XIndex{pos.at})});
    return emits(wx, pos)
        ? crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(recv == Text::lit("")
        ? crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("path")})
        : recv == Text::lit("self")
        ? crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("path")})
        : crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{recv})), Text::lit("path")})), Text::lit("at"), at_})
        : crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Path::root"), Array<crate::lower::model::Ex>{}})), Text::lit("at"), at_});
}


/// PosPat: fn Pos, [Pa] -> Pa
crate::lower::model::Pa pos_pat(const crate::lower::model::Pos_& pos, const Array<crate::lower::model::Pa>& tail) {
    return crate::lower::model::Pa(crate::lower::model::Pa::PaSlice{append(Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Segment::Pos"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaIndex{pos.at})})})}), tail)});
}


/// let keyTail
Array<crate::lower::model::Pa> key_tail() {
    return Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Segment::Key"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("k")})})}), crate::lower::model::Pa(crate::lower::model::Pa::PaRest{Text::lit("rest")})});
}


/// let genTail
Array<crate::lower::model::Pa> gen_tail() {
    return Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Segment::Gen"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("g")})})}), crate::lower::model::Pa(crate::lower::model::Pa::PaRest{Text::lit("rest")})});
}


/// ?HostedRows: fn Wx -> ?Text
std::optional<Text> hosted_rows(const Wx& wx) {
    return wx.pos.scope > Nat(0u)
        ? std::optional(prism_rtl::cat(or_(index(wx.scopes, crate::syntax::lexer::dec(wx.pos.scope)), Text::lit("")), "_moved"))
        : ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Text>> _v;
        auto&& _m = wx.hosted_by;
        if (prism_rtl::is_some(_m)) {
            _v.set(std::optional(Text::lit("document_moved")));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::optional<Text>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// RootDynPatch: fn Wx -> [Do]
Array<crate::lower::model::Do> root_dyn_patch(const Wx& wx) {
    auto&& _m = wx.root_dyn;
    if (prism_rtl::is_some(_m)) {
        return Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLine{result_moved(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})});
    }
    if (prism_rtl::is_none(_m)) {
        return Array<crate::lower::model::Do>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// AnswerArm: fn Wx, Pos, Nat, OutTy -> ((Pa, Ex))
std::tuple<crate::lower::model::Pa, crate::lower::model::Ex> answer_arm(const Wx& wx, const crate::lower::model::Pos_& pos, const Nat& id, const crate::lower::model::OutTy& t) {
    auto call = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), gn_of(wx, id).name, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XDecode{t, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})});
    return std::tuple{pos_pat(pos, Array<crate::lower::model::Pa>{}), call};
}


/// TypedAnswerArm: fn Wx, Pos, Nat, Text -> ((Pa, [Do]))
std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>> typed_answer_arm(const Wx& wx, const crate::lower::model::Pos_& pos, const Nat& id, const Text& acc) {
    return std::tuple{pos_pat(pos, Array<crate::lower::model::Pa>{}), Array(std::vector{self_call(gn_of(wx, id).name, Array(std::vector{crate::lower::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")})), acc, Array<crate::lower::model::Ex>{}}))}))})};
}


/// TypedDynArm: fn Sinks, Pos, Text, Text -> ((Pa, [Do]))
std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>> typed_dyn_arm(const Sinks& sk, const crate::lower::model::Pos_& pos, const Text& f, const Text& acc) {
    return std::tuple{pos_pat(pos, Array<crate::lower::model::Pa>{}), dyn_place_write(sk, f, crate::lower::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")})), acc, Array<crate::lower::model::Ex>{}})))};
}


/// TypedForwardArm: fn ForDef, Ex -> ((Pa, [Do]))
std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>> typed_forward_arm(const crate::lower::model::ForDef& b, const crate::lower::model::Ex& segs) {
    auto row_of = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(b.name)})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDecode{b.key_ty, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("k")}))}))})})})), Text::lit("cloned"), Array<crate::lower::model::Ex>{}});
    return std::tuple{pos_pat(b.pos, key_tail()), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")}), row_of}), crate::lower::model::Do(crate::lower::model::Do::DoMatch{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")}), Array(std::vector{std::tuple{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")})})}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")})), Text::lit("deliver"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("rest")}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))})})}, std::tuple{crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{Text::lit("None")}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoReturn{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Fault::answer"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XFormatStr{Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XText{Text::lit("no row ")}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("k")}), crate::lower::model::Ex(crate::lower::model::Ex::XText{Text::lit(" under the hosted place ")}), crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Path"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(segs), Text::lit("to_vec"), Array<crate::lower::model::Ex>{}})})})})})})})})})})})}})})})};
}


/// TypedGenArm: fn GenDef -> ((Pa, [Do]))
std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>> typed_gen_arm(const crate::lower::model::GenDef& gd) {
    auto current = crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(gd.name)})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}}))});
    auto is_current = crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("=="), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("+"), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("g")}))})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XIndex{Nat(1u)}))})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(gd.name, "_count")})), Text::lit("get"), Array<crate::lower::model::Ex>{}}))});
    return std::tuple{pos_pat(gd.pos, gen_tail()), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")}), current}), crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIf{is_current, Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")})), Text::lit("deliver"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("rest")}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))})}), Array<crate::lower::model::Do>{}})}), Array<crate::lower::model::Do>{}})})};
}


/// TypedDispatch: fn Sinks, Text, Nat -> MethDef
crate::lower::model::MethDef typed_dispatch(const Sinks& sk, const Text& name, const Nat& scope) {
    auto wx = sk.wx;
    auto in_scope_fn = ({
        auto scope_1 = scope;
        (prism_rtl::rc([=](const crate::lower::model::Pos_& p_) { return p_.scope == scope_1; }));
    });
    auto [recv, param, segs, doc] = scope > Nat(0u)
        ? std::tuple{crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), std::tuple{Text::lit("place"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutPath{}))})}, crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("place")})), Text::lit("segments"), Array<crate::lower::model::Ex>{}}), prism_rtl::cat("The host at place ", crate::lower::model::place_text(or_(index(wx.hosts, crate::syntax::lexer::dec(scope)), dummy_host()).pos), " answers its child's place `place` (pick HO): into the child's input method, a hold the place's element answers, or the row of a `for` or `rebuild` under it.")}
        : std::tuple{crate::lower::model::Recv(crate::lower::model::Recv::RecvOwned{}), std::tuple{Text::lit("at"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutSlice{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Segment"), Array<crate::lower::model::OutTy>{}}))}))})}, crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("at")}), Text::lit("A host's answer to a place of this row's own, `at` under the row (pick HO): into the input method, a hold, or a row under it.")};
    auto answers = each(filter(wx.answers, [&](const std::tuple<crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        return in_scope_fn(pos);
    }), [&](const std::tuple<crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        auto&& id = std::get<1>(_p0);
        auto&& acc = std::get<3>(_p0);
        return typed_answer_arm(wx, pos, id, acc);
    });
    auto dyns = each(filter(wx.dyn_places, [&](const std::tuple<crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        return in_scope_fn(pos);
    }), [&](const std::tuple<crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        auto&& f = std::get<1>(_p0);
        auto&& acc = std::get<3>(_p0);
        return typed_dyn_arm(sk, pos, f, acc);
    });
    auto rows = each(filter(wx.builders, [&](const crate::lower::model::ForDef& b) { return in_scope_fn(b.pos); }), [&](const crate::lower::model::ForDef& b) { return typed_forward_arm(b, segs); });
    auto gens = each(filter(wx.gens, [&](const crate::lower::model::GenDef& gd) { return in_scope_fn(gd.pos); }), [&](const crate::lower::model::GenDef& gd) { return typed_gen_arm(gd); });
    auto none = std::tuple{crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoReturn{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Fault::answer"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XFormatStr{Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XText{Text::lit("no hosted place at ")}), crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Path"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(segs), Text::lit("to_vec"), Array<crate::lower::model::Ex>{}})})}), crate::lower::model::Ex(crate::lower::model::Ex::XText{Text::lit(" to answer")})})})})})})})})})};
    auto arms = crate::prelude::push(append(append(append(answers, dyns), rows), gens), none);
    return crate::lower::model::MethDef{.name = name, .recv = recv, .params = Array(std::vector{param, std::tuple{Text::lit("v"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(crate::lower::answer_ty_value())})}}), .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Done"), Array<crate::lower::model::OutTy>{}}), .body = Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoMatch{segs, arms})}), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Ok"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})})}), .doc = doc};
}


/// let dummyHost
HostDef dummy_host() {
    return HostDef{.pos = crate::lower::model::pos0(), .name = Text::lit(""), .scope = Nat(0u)};
}


/// SortNats: fn [Nat] -> [Nat]
Array<Nat> sort_nats(const Array<Nat>& xs) {
    return fold(xs, Array<Nat>{}, [&](const Array<Nat>& acc, const Nat& x) { return append(crate::prelude::push(filter(acc, [&](const Nat& y) { return y < x; }), x), filter(acc, [&](const Nat& y) { return !(y < x); })); });
}


/// AskWake: fn Sinks, Nat -> [Do]
Array<crate::lower::model::Do> ask_wake(const Sinks& sk, const Nat& h) {
    auto c = crate::lower::model::Ex(crate::lower::model::Ex::XConst{wake_const(sk.heights, h)});
    auto ask_1 = crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("wakes")})), Text::lit("ask"), Array(std::vector{c})})});
    auto wake_2 = crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("wake"), Array(std::vector{c, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})})})});
    return sk.many ? Array(std::vector{ask_1, wake_2}) : Array(std::vector{wake_2});
}


/// GatherIn: fn Sinks, Gn -> MethDef
crate::lower::model::MethDef gather_in(const Sinks& sk, const Gn& g) {
    auto field = or_(index(g.inputs, Nat(0u)), Text::lit(""));
    auto kt = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::OutTy> _v;
        auto&& _m = g.ty;
        if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(_m)) {
            auto&& k = prism_rtl::as<crate::lower::model::OutTy::OutMap>(_m).a0;
            _v.set(k);
            goto _done;
        }
        {
            _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto vt = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::OutTy> _v;
        auto&& _m = g.ty;
        if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(_m)) {
            auto&& v_ = prism_rtl::as<crate::lower::model::OutTy::OutMap>(_m).a1;
            _v.set(v_);
            goto _done;
        }
        {
            _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto current = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(field)})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})), Text::lit("unwrap_or_default"), Array<crate::lower::model::Ex>{}});
    auto collect = Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("all")}), current}), crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("all")})), Text::lit("insert"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("k")}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")})})})}), crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(field)})), Text::lit("set"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("all")}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})});
    auto body = append(collect, ask_wake(sk, g.height));
    return crate::lower::model::MethDef{.name = prism_rtl::cat(g.name, "_in"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array(std::vector{std::tuple{Text::lit("k"), kt}, std::tuple{Text::lit("v"), vt}}), .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = body, .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = Text::lit("A row's firing, gathered by its key.")};
}


/// Decide: fn Gn -> Do
crate::lower::model::Do decide(const Gn& g) {
    auto&& _m = g.kind;
    if (prism_rtl::is<GnKind::GnGather>(_m)) {
        return crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("v")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(or_(index(g.inputs, Nat(0u)), Text::lit("")))})), Text::lit("take"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{self_call(g.name, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")})}))}), Array<crate::lower::model::Do>{}});
    }
    if (prism_rtl::is<GnKind::GnMerge>(_m)) {
        return merge_decide(g);
    }
    if (prism_rtl::is<GnKind::GnUpdated>(_m)) {
        return updated_decide(g);
    }
    if (prism_rtl::is<GnKind::GnMergeAll>(_m)) {
        auto pushes = each(g.inputs, [&](const Text& f) { return crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("x")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f)})), Text::lit("take"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("all")})), Text::lit("push_back"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("x")})})})})}), Array<crate::lower::model::Do>{}}); });
        auto start = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("all")})), g.ty}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Array::new"), Array<crate::lower::model::Ex>{}})});
        auto fire = crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{Text::lit("!"), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("all")})), Text::lit("is_empty"), Array<crate::lower::model::Ex>{}}))}), Array(std::vector{self_call(g.name, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("all")})}))}), Array<crate::lower::model::Do>{}});
        return crate::lower::model::Do(crate::lower::model::Do::DoBlock{crate::prelude::push(append(Array(std::vector{start}), pushes), fire)});
    }
    {
        auto&& kind = _m;
        return pair_decide(g, kind);
    }
}


/// UpdatedDecide: fn Gn -> Do
crate::lower::model::Do updated_decide(const Gn& g) {
    return crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(g.name, "_moved")})), Text::lit("replace"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XBool{false})})}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("after")}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("after"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("cx")})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(g.name, "_value"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))})})})}), self_call(g.name, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("after")})}))}), Array<crate::lower::model::Do>{}});
}


/// PairDecide: fn Gn, GnKind -> Do
crate::lower::model::Do pair_decide(const Gn& g, const GnKind& kind) {
    auto get_l = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(or_(index(g.inputs, Nat(0u)), Text::lit("")))})), Text::lit("take"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})});
    auto get_r = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(or_(index(g.inputs, Nat(1u)), Text::lit("")))})), Text::lit("take"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})});
    auto both_ = crate::lower::model::Ex(crate::lower::model::Ex::XTuple{Array(std::vector{get_l, get_r})});
    auto fire_fn = ({
        auto g_1 = g;
        (prism_rtl::rc([=](const crate::lower::model::Ex& x) { return Array(std::vector{self_call(g_1.name, Array(std::vector{x}))}); }));
    });
    auto sa = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("a")})})});
    auto sb = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("b")})})});
    auto some2 = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{sa, sb})});
    auto left = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{sa, crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{Text::lit("None")})})});
    auto right = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{Text::lit("None")}), sb})});
    auto cases = ({
        __label__ _done;
        prism_rtl::Slot<Array<std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>>>> _v;
        if (prism_rtl::is<GnKind::GnUnion>(kind)) {
            _v.set(Array(std::vector{std::tuple{some2, fire_fn(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("union"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("a")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("b")}))})})}))}, std::tuple{left, fire_fn(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("a")}))}, std::tuple{right, fire_fn(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("b")}))}, std::tuple{crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), Array<crate::lower::model::Do>{}}}));
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnBoth>(kind)) {
            _v.set(Array(std::vector{std::tuple{some2, fire_fn(crate::lower::model::Ex(crate::lower::model::Ex::XTuple{Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("a")}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("b")})})}))}, std::tuple{crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), Array<crate::lower::model::Do>{}}}));
            goto _done;
        }
        {
            _v.set(Array(std::vector{std::tuple{left, fire_fn(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("a")}))}, std::tuple{crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), Array<crate::lower::model::Do>{}}}));
            goto _done;
        }
    _done:
        _v.take();
    });
    return crate::lower::model::Do(crate::lower::model::Do::DoMatch{both_, cases});
}


/// WakeByHeight: fn [Gn], [Nat] -> Do
crate::lower::model::Do wake_by_height(const Array<Gn>& combs, const Array<Nat>& heights_) {
    return crate::lower::model::Do(crate::lower::model::Do::DoMatch{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("wakes")})), Text::lit("next"), Array<crate::lower::model::Ex>{}}), crate::prelude::push(each(heights_, [&](const Nat& h) { return std::tuple{crate::lower::model::Pa(crate::lower::model::Pa::PaConst{wake_const(heights_, h)}), each(filter(combs, [&](const Gn& g) { return g.height == h; }), [&](const Gn& g) { return decide(g); })}; }), std::tuple{crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), Array<crate::lower::model::Do>{}})});
}


/// ForwardAnswer: fn ForDef -> Ex
crate::lower::model::Ex forward_answer(const crate::lower::model::ForDef& b) {
    auto row_of = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(b.name)})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDecode{b.key_ty, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("k")}))}))})})})), Text::lit("cloned"), Array<crate::lower::model::Ex>{}});
    return crate::lower::model::Ex(crate::lower::model::Ex::XBlock{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")}), row_of}), crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")})), Text::lit("answer"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("rest")}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))})}), Array<crate::lower::model::Do>{}})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}))});
}


/// IsHold: fn OutTy -> Bool
bool is_hold(const crate::lower::model::OutTy& out_ty0) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutHold>(out_ty0)) {
        return true;
    }
    {
        auto&& other = out_ty0;
        return false;
    }
}


/// RowMethods: fn Wx -> [MethDef]
Array<crate::lower::model::MethDef> row_methods(const Wx& wx) {
    auto removes = each(filter(wx.places, [&](const Place& p_) { return emits(wx, p_.pos); }), [&](const Place& p_) { return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("removed"), Array(std::vector{place_at(wx, Text::lit("self"), p_.pos)})})}); });
    auto nested = append(each(wx.builders, [&](const crate::lower::model::ForDef& b) { return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), b.name})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}})), Text::lit("values"), Array<crate::lower::model::Ex>{}})), Text::lit("for_each"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")})), Text::lit("leave_row"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))})})})}); }), each(wx.gens, [&](const crate::lower::model::GenDef& gd) { return crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), gd.name})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}})), Text::lit("as_ref"), Array<crate::lower::model::Ex>{}}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")})), Text::lit("leave_row"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})}), Array<crate::lower::model::Do>{}}); }));
    return Array(std::vector{crate::lower::model::MethDef{.name = Text::lit("remove_places"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = append(removes, nested), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = Text::lit("The row left: its places are torn down.")}});
}


/// GnDoc: fn Gn -> Text
Text gn_doc(const Gn& g) {
    auto&& _m = g.kind;
    if (prism_rtl::is<GnKind::GnAnswer>(_m)) {
        return prism_rtl::cat("`", g.name, "`: an answer at its place.");
    }
    if (prism_rtl::is<GnKind::GnStarted>(_m)) {
        return Text::lit("`@started`, the tick after the build.");
    }
    if (prism_rtl::is<GnKind::GnDeferred>(_m)) {
        return Text::lit("An `@Defer` firing, the tick after it was armed.");
    }
    if (prism_rtl::is<GnKind::GnMerge>(_m)) {
        return prism_rtl::cat("The merge `", g.name, "`, decided in the wake.");
    }
    if (prism_rtl::is<GnKind::GnUpdated>(_m)) {
        return Text::lit("`!Updated`: the dynamic's value after the tick, fired in the wake when a hold it reads was written (or a structural dynamic it reads was published, pick ST).");
    }
    {
        return prism_rtl::cat("`!", g.name, "`.");
    }
}


/// MergeDecide: fn Gn -> Do
crate::lower::model::Do merge_decide(const Gn& g) {
    auto call = Array(std::vector{self_call(g.name, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")})}))});
    auto take_l = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("left")}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(or_(index(g.inputs, Nat(0u)), Text::lit("")))})), Text::lit("take"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
    auto take_r = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("right")}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(or_(index(g.inputs, Nat(1u)), Text::lit("")))})), Text::lit("take"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
    auto right_1 = crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("v")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("right")}), call, Array<crate::lower::model::Do>{}});
    return crate::lower::model::Do(crate::lower::model::Do::DoBlock{Array(std::vector{take_l, take_r, crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("v")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("left")}), call, Array(std::vector{right_1})})})});
}


/// ForLine: unbounded fn Wx, Env, Env, ?ForBinders, Expr, Block, Expr, ?Bn -> ((Wx, Wres))
std::tuple<Wx, Wres> for_line(const Wx& wx, const crate::lower::Env& benv, const crate::lower::Env& menv, const std::optional<crate::syntax::ForBinders>& binders_opt, const crate::syntax::Expr& source, const crate::syntax::Block& body, const crate::syntax::Expr& e, const std::optional<crate::lower::Bn>& bound_opt) {
    auto lx = wx.lx;
    auto pos = wx.pos;
    auto wx1 = ({
        Wx this_ = wx;
        this_.pos = crate::lower::model::next_pos(this_.pos);
        this_;
    });
    auto [src_ex, reads] = dynamic_expr(wx1, menv, source);
    auto src_ty = crate::lower::peel(crate::lower::type_at(lx, source.span));
    auto [kt, vt, keyed] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::lower::model::OutTy, crate::lower::model::OutTy, bool>> _v;
        if (prism_rtl::is<crate::check::types::Ty::TyMap>(src_ty)) {
            auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(src_ty).a0;
            auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(src_ty).a1;
            _v.set(std::tuple{crate::lower::out_ty_of(lx, k), crate::lower::out_ty_of(lx, v_), true});
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyArray>(src_ty)) {
            auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyArray>(src_ty).a0;
            _v.set(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{}), crate::lower::out_ty_of(lx, v_), false});
            goto _done;
        }
        {
            _v.set(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), true});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto src = keyed
        ? src_ex
        : crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("indexed"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(src_ex)})})});
    auto base = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is_some(bound_opt) && prism_rtl::is<crate::lower::Bn::BnEv>(prism_rtl::some_of(bound_opt))) {
            auto&& er = prism_rtl::as<crate::lower::Bn::BnEv>(prism_rtl::some_of(bound_opt)).a0;
            _v.set(gn_of(wx1, er.node_).name);
            goto _done;
        }
        {
            _v.set(Text::lit("rows"));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [name, wx2a] = fresh_name(wx1, base);
    auto src_getter = prism_rtl::cat(name, "_source");
    auto src_cached = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(src_getter, "_cache")})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array<crate::lower::model::Pa>{}, prism_rtl::rc(src)})})});
    auto src_def = crate::lower::model::MethDef{.name = src_getter, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(kt), prism_rtl::rc(vt)}), .body = Array<crate::lower::model::Do>{}, .tail = src_cached, .doc = prism_rtl::cat("The source of the `for` at place ", crate::lower::model::place_text(pos), " by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.")};
    auto row_name = prism_rtl::cat(wx.node_, row_suffix(wx), "Row");
    auto locals = row_locals(benv, menv, body);
    auto row_fields = append(Array(std::vector{std::tuple{Text::lit("key"), kt, Text::lit("the row's key")}, std::tuple{Text::lit("left_entry"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutCell{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(vt)}))}), Text::lit("the entry as the tick its key left opened, kept from the row's leaving on (R8)")}, std::tuple{Text::lit("parent"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutWeak{wx.node_}), Text::lit("the node of the `for`")}}), each(locals, [&](const RowLocal& l) { return std::tuple{l.field, l.ty, prism_rtl::cat("`", l.name, "`, the block's")}; }));
    auto row_moves = append(Array(std::vector{std::tuple{Text::lit("key"), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("key")}))})}, std::tuple{Text::lit("left_entry"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("RefCell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XNone{})})})}, std::tuple{Text::lit("parent"), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("parent")})}}), each(locals, [&](const RowLocal& l) { return std::tuple{l.field, crate::lower::model::Ex(crate::lower::model::Ex::XVar{l.field})}; }));
    auto row_taken = append(append(node_hooks(), Array(std::vector{Text::lit("key"), Text::lit("value"), Text::lit("parent"), Text::lit("entry"), Text::lit("left_entry")})), each(locals, [&](const RowLocal& l) { return l.field; }));
    auto row_wx0 = new_wx(lx, row_name, row_fields, Array<std::tuple<Text, crate::lower::model::Ex>>{}, row_moves, Array(std::vector{entry_getter(src_getter, vt)}), map_of(std::vector{std::tuple{Text::lit("entry"), Array(std::vector{Read(Read::ParentRead{src_getter})})}}), row_taken, wx.depth, hosted_rows(wx));
    auto [wx2p, row_wx0p, ports] = row_env(wx2a, row_wx0, menv, body);
    auto wx2 = ({
        Wx this_ = add_field(wx2p, prism_rtl::cat(src_getter, "_cache"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Cache"), Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(kt), prism_rtl::rc(vt)})})}), prism_rtl::cat("the source of the `for` at place ", crate::lower::model::place_text(pos), ", cached (gap SR)"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Cache::new"), Array<crate::lower::model::Ex>{}}));
        this_.taken = append(this_.taken, Array(std::vector{src_getter, prism_rtl::cat(src_getter, "_cache")}));
        this_.getters = crate::prelude::push(this_.getters, src_def);
        this_.dyn_reads = insert(this_.dyn_reads, src_getter, reads);
        this_;
    });
    auto key_b = crate::lower::Bn(crate::lower::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("key")}), crate::lower::Holding(crate::lower::Holding::Owned{}), kt});
    auto key_m = crate::lower::Bn(crate::lower::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("key")}), crate::lower::Holding(crate::lower::Holding::Owned{}), kt});
    auto benv_l = events_of(ports, fold(locals, row_reads(benv, parent_arg()), [&](const crate::lower::Env& en, const RowLocal& l) { return crate::lower::bind(en, l.name, crate::lower::Bn(crate::lower::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{l.field}), crate::lower::Holding(crate::lower::Holding::Owned{}), l.ty})); }));
    auto menv_l = events_of(ports, fold(locals, row_reads(menv, parent_ref()), [&](const crate::lower::Env& en, const RowLocal& l) { return crate::lower::bind(en, l.name, crate::lower::Bn(crate::lower::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), l.field}), crate::lower::Holding(crate::lower::Holding::Owned{}), l.ty})); }));
    auto passed = append(hosted_passed(wx), each(locals, [&](const RowLocal& l) { return l.passed; }));
    auto row_params = append(append(Array(std::vector{std::tuple{Text::lit("key"), kt}, std::tuple{Text::lit("value"), vt}, std::tuple{Text::lit("parent"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutWeak{wx.node_})}}), hosted_params(wx)), each(locals, [&](const RowLocal& l) { return std::tuple{l.field, l.ty}; }));
    auto entry_m = crate::lower::Bn(crate::lower::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("entry"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{Read(Read::ParentRead{src_getter})}), vt});
    auto [rbe, rme] = for_envs(benv_l, menv_l, binders_opt, key_b, key_m, crate::lower::Bn(crate::lower::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("value")}), crate::lower::Holding(crate::lower::Holding::Owned{}), vt}), entry_m, vt);
    auto row_wx = block_into(row_wx0p, rbe, rme, body);
    auto wx3 = ({
        Wx this_ = wx2;
        this_.row_marks = crate::prelude::push(this_.row_marks, RowMarks{.builder = name, .reads = row_place_reads(row_wx), .wrote = row_hears(row_wx), .kind = crate::lower::model::RowKind(crate::lower::model::RowKind::ForRow{})});
        this_;
    });
    auto full = crate::lower::type_at(lx, e.span);
    auto out_ty = crate::lower::out_ty_of(lx, crate::lower::peel(full));
    auto&& _m = row_wx->result;
    if (prism_rtl::is<Wres::WrEv>(_m)) {
        auto&& r = prism_rtl::as<Wres::WrEv>(_m).a0;
        auto [gid, wx4] = add_gn(wx3, prism_rtl::cat(name, "_all"), out_ty, GnKind(GnKind::GnGather{}), Nat(1u));
        auto wx5 = add_field_last(wx4, prism_rtl::cat(name, "_gathered"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutStamped{prism_rtl::rc(out_ty)}), Text::lit("the rows' firings this tick, by key"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Stamped::new"), Array<crate::lower::model::Ex>{}}));
        auto wx6 = ({
            Wx this_ = wx5;
            this_.gns = each(this_.gns, [&](const Gn& n) {
                return n.id == gid
                    ? with_inputs(n, Array(std::vector{prism_rtl::cat(name, "_gathered")}))
                    : n;
            });
            this_;
        });
        auto row_done = connect(row_wx, r, Sk(Sk::SkUp{prism_rtl::cat(name, "_all_in")}));
        auto wx7 = add_builder(wx6, name, pos, kt, vt, row_name, keyed, reads, PendingRow{.wx = row_done, .qk = row_name, .params = row_params, .gather = std::optional(gid)}, passed);
        return std::tuple{wx7, Wres(Wres::WrEv{ev_ref_of(wx7, gid)})};
    }
    if (prism_rtl::is<Wres::WrDyn>(_m)) {
        auto&& ex = prism_rtl::as<Wres::WrDyn>(_m).a0;
        auto&& result_reads = prism_rtl::as<Wres::WrDyn>(_m).a1;
        auto&& rt = prism_rtl::as<Wres::WrDyn>(_m).a2;
        auto gathered = prism_rtl::cat(name, "_all");
        auto gathered_ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(kt), prism_rtl::rc(rt)});
        auto own_behind = filter(reads_closed(row_wx.dyn_reads, result_reads), [&](const Read& r) {
            return ({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                if (prism_rtl::is<Read::OwnRead>(r)) {
                    _v.set(true);
                    goto _done;
                }
                if (prism_rtl::is<Read::ParentRead>(r)) {
                    _v.set(false);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        });
        auto row_done = ({
            Wx this_ = row_wx;
            this_.getters = crate::prelude::push(this_.getters, crate::lower::model::MethDef{.name = Text::lit("result"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = rt, .body = Array<crate::lower::model::Do>{}, .tail = ex, .doc = Text::lit("The row's result, which the block gathers by key.")});
            this_.result_moved = len(own_behind) > Nat(0u)
                ? std::optional(std::tuple{prism_rtl::cat(gathered, "_moved"), own_behind})
                : std::optional<std::tuple<Text, Array<Read>>>{};
            this_;
        });
        auto wx4 = add_builder(wx3, name, pos, kt, vt, row_name, keyed, reads, PendingRow{.wx = row_done, .qk = row_name, .params = row_params, .gather = std::optional<Nat>{}}, passed);
        auto all = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), name})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}})), Text::lit("iter"), Array<crate::lower::model::Ex>{}})), Text::lit("map"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("k")}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")})})})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XTuple{Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("k")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")})), Text::lit("result"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})}))})})})), Text::lit("collect"), Array<crate::lower::model::Ex>{}});
        auto what = prism_rtl::cat("the dynamic gathered by the `for` at place ", crate::lower::model::place_text(pos));
        auto wx5 = ({
            Wx this_ = wx4;
            this_.taken = append(this_.taken, Array(std::vector{gathered, prism_rtl::cat(gathered, "_now"), prism_rtl::cat(gathered, "_snap"), prism_rtl::cat(gathered, "_moved"), prism_rtl::cat(gathered, "_publish")}));
            this_.getters = append(this_.getters, Array(std::vector{crate::lower::model::MethDef{.name = prism_rtl::cat(gathered, "_now"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = gathered_ty, .body = Array<crate::lower::model::Do>{}, .tail = all, .doc = Text::lit("The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).")}, snap_getter(gathered, gathered_ty, Text::lit("The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after."))}));
            this_.fields = crate::prelude::push(this_.fields, std::tuple{prism_rtl::cat(gathered, "_snap"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutSnapshot{prism_rtl::rc(gathered_ty)}), prism_rtl::cat("the `for` at place ", crate::lower::model::place_text(pos), "'s gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)")});
            this_.inits = crate::prelude::push(this_.inits, std::tuple{prism_rtl::cat(gathered, "_snap"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Snapshot::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{what})})})});
            this_.snaps = crate::prelude::push(this_.snaps, SnapDef{.name = gathered, .live = prism_rtl::cat(gathered, "_now"), .ty = gathered_ty, .eq = crate::lower::ty_has_eq(lx, crate::lower::peel(full), Array<Text>{}), .builder = name, .before = false, .what = what});
            this_.dyn_reads = insert(this_.dyn_reads, prism_rtl::cat(gathered, "_now"), union_reads(reads, block_reads(reads_closed(row_wx.dyn_reads, result_reads))));
            this_;
        });
        return std::tuple{wx5, Wres(Wres::WrDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), gathered, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{Read(Read::OwnRead{gathered})}), gathered_ty})};
    }
    {
        auto wx4 = add_builder(wx3, name, pos, kt, vt, row_name, keyed, reads, PendingRow{.wx = row_wx, .qk = row_name, .params = row_params, .gather = std::optional<Nat>{}}, passed);
        return std::tuple{wx4, Wres(Wres::WrUnit{})};
    }
}


prism_rtl::Turn<std::tuple<Wx, Wres>> ForLine::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& binders_opt = this->binders_opt;
    const auto& source = this->source;
    const auto& body = this->body;
    const auto& e = this->e;
    const auto& bound_opt = this->bound_opt;
    auto lx = wx.lx;
    auto pos = wx.pos;
    auto wx1 = ({
        Wx this_ = wx;
        this_.pos = crate::lower::model::next_pos(this_.pos);
        this_;
    });
    auto binders_opt_1 = binders_opt;
    auto bound_opt_2 = bound_opt;
    auto benv_3 = benv;
    auto body_4 = body;
    auto e_5 = e;
    auto menv_6 = menv;
    auto source_7 = source;
    auto wx_8 = wx;
    return call_then(start_dynamic_expr(wx1, menv_6, source_7), [=](std::tuple<crate::lower::model::Ex, Array<Read>> dynamic_expr_138334) {
        return ({
            auto [src_ex, reads] = dynamic_expr_138334;
            auto src_ty = crate::lower::peel(crate::lower::type_at(lx, source_7.span));
            auto [kt, vt, keyed] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::lower::model::OutTy, crate::lower::model::OutTy, bool>> _v;
                if (prism_rtl::is<crate::check::types::Ty::TyMap>(src_ty)) {
                    auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(src_ty).a0;
                    auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(src_ty).a1;
                    _v.set(std::tuple{crate::lower::out_ty_of(lx, k), crate::lower::out_ty_of(lx, v_), true});
                    goto _done;
                }
                if (prism_rtl::is<crate::check::types::Ty::TyArray>(src_ty)) {
                    auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyArray>(src_ty).a0;
                    _v.set(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{}), crate::lower::out_ty_of(lx, v_), false});
                    goto _done;
                }
                {
                    _v.set(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), true});
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto src = keyed
                ? src_ex
                : crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("indexed"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(src_ex)})})});
            auto base = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                if (prism_rtl::is_some(bound_opt) && prism_rtl::is<crate::lower::Bn::BnEv>(prism_rtl::some_of(bound_opt))) {
                    auto&& er = prism_rtl::as<crate::lower::Bn::BnEv>(prism_rtl::some_of(bound_opt)).a0;
                    _v.set(gn_of(wx1, er.node_).name);
                    goto _done;
                }
                {
                    _v.set(Text::lit("rows"));
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto [name, wx2a] = fresh_name(wx1, base);
            auto src_getter = prism_rtl::cat(name, "_source");
            auto src_cached = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(src_getter, "_cache")})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array<crate::lower::model::Pa>{}, prism_rtl::rc(src)})})});
            auto src_def = crate::lower::model::MethDef{.name = src_getter, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(kt), prism_rtl::rc(vt)}), .body = Array<crate::lower::model::Do>{}, .tail = src_cached, .doc = prism_rtl::cat("The source of the `for` at place ", crate::lower::model::place_text(pos), " by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.")};
            auto row_name = prism_rtl::cat(wx_8.node_, row_suffix(wx_8), "Row");
            auto locals = row_locals(benv_3, menv_6, body_4);
            auto row_fields = append(Array(std::vector{std::tuple{Text::lit("key"), kt, Text::lit("the row's key")}, std::tuple{Text::lit("left_entry"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutCell{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(vt)}))}), Text::lit("the entry as the tick its key left opened, kept from the row's leaving on (R8)")}, std::tuple{Text::lit("parent"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutWeak{wx_8.node_}), Text::lit("the node of the `for`")}}), each(locals, [&](const RowLocal& l) { return std::tuple{l.field, l.ty, prism_rtl::cat("`", l.name, "`, the block's")}; }));
            auto row_moves = append(Array(std::vector{std::tuple{Text::lit("key"), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("key")}))})}, std::tuple{Text::lit("left_entry"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("RefCell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XNone{})})})}, std::tuple{Text::lit("parent"), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("parent")})}}), each(locals, [&](const RowLocal& l) { return std::tuple{l.field, crate::lower::model::Ex(crate::lower::model::Ex::XVar{l.field})}; }));
            auto row_taken = append(append(node_hooks(), Array(std::vector{Text::lit("key"), Text::lit("value"), Text::lit("parent"), Text::lit("entry"), Text::lit("left_entry")})), each(locals, [&](const RowLocal& l) { return l.field; }));
            auto row_wx0 = new_wx(lx, row_name, row_fields, Array<std::tuple<Text, crate::lower::model::Ex>>{}, row_moves, Array(std::vector{entry_getter(src_getter, vt)}), map_of(std::vector{std::tuple{Text::lit("entry"), Array(std::vector{Read(Read::ParentRead{src_getter})})}}), row_taken, wx_8.depth, hosted_rows(wx_8));
            auto [wx2p, row_wx0p, ports] = row_env(wx2a, row_wx0, menv_6, body_4);
            auto wx2 = ({
                Wx this_ = add_field(wx2p, prism_rtl::cat(src_getter, "_cache"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Cache"), Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(kt), prism_rtl::rc(vt)})})}), prism_rtl::cat("the source of the `for` at place ", crate::lower::model::place_text(pos), ", cached (gap SR)"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Cache::new"), Array<crate::lower::model::Ex>{}}));
                this_.taken = append(this_.taken, Array(std::vector{src_getter, prism_rtl::cat(src_getter, "_cache")}));
                this_.getters = crate::prelude::push(this_.getters, src_def);
                this_.dyn_reads = insert(this_.dyn_reads, src_getter, reads);
                this_;
            });
            auto key_b = crate::lower::Bn(crate::lower::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("key")}), crate::lower::Holding(crate::lower::Holding::Owned{}), kt});
            auto key_m = crate::lower::Bn(crate::lower::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("key")}), crate::lower::Holding(crate::lower::Holding::Owned{}), kt});
            auto benv_l = events_of(ports, fold(locals, row_reads(benv_3, parent_arg()), [&](const crate::lower::Env& en, const RowLocal& l) { return crate::lower::bind(en, l.name, crate::lower::Bn(crate::lower::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{l.field}), crate::lower::Holding(crate::lower::Holding::Owned{}), l.ty})); }));
            auto menv_l = events_of(ports, fold(locals, row_reads(menv_6, parent_ref()), [&](const crate::lower::Env& en, const RowLocal& l) { return crate::lower::bind(en, l.name, crate::lower::Bn(crate::lower::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), l.field}), crate::lower::Holding(crate::lower::Holding::Owned{}), l.ty})); }));
            auto passed = append(hosted_passed(wx_8), each(locals, [&](const RowLocal& l) { return l.passed; }));
            auto row_params = append(append(Array(std::vector{std::tuple{Text::lit("key"), kt}, std::tuple{Text::lit("value"), vt}, std::tuple{Text::lit("parent"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutWeak{wx_8.node_})}}), hosted_params(wx_8)), each(locals, [&](const RowLocal& l) { return std::tuple{l.field, l.ty}; }));
            auto entry_m = crate::lower::Bn(crate::lower::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("entry"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{Read(Read::ParentRead{src_getter})}), vt});
            auto [rbe, rme] = for_envs(benv_l, menv_l, binders_opt_1, key_b, key_m, crate::lower::Bn(crate::lower::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("value")}), crate::lower::Holding(crate::lower::Holding::Owned{}), vt}), entry_m, vt);
            call_then(start_block_into(row_wx0p, rbe, rme, body_4), [=](Wx block_into_142143) {
            return ({
                auto row_wx = block_into_142143;
                auto wx3 = ({
                    Wx this_ = wx2;
                    this_.row_marks = crate::prelude::push(this_.row_marks, RowMarks{.builder = name, .reads = row_place_reads(row_wx), .wrote = row_hears(row_wx), .kind = crate::lower::model::RowKind(crate::lower::model::RowKind::ForRow{})});
                    this_;
                });
                auto full = crate::lower::type_at(lx, e_5.span);
                call_then(crate::lower::start_out_ty_of(lx, crate::lower::peel(full)), [=](crate::lower::model::OutTy out_ty_of_142382) {
                return ({
                    auto out_ty = out_ty_of_142382;
                    ({
                    auto&& _m = row_wx->result;
                    prism_rtl::is<Wres::WrEv>(_m) ? ({
                    auto&& r = prism_rtl::as<Wres::WrEv>(_m).a0;
                    ({
                    auto [gid, wx4] = add_gn(wx3, prism_rtl::cat(name, "_all"), out_ty, GnKind(GnKind::GnGather{}), Nat(1u));
                    auto wx5 = add_field_last(wx4, prism_rtl::cat(name, "_gathered"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutStamped{prism_rtl::rc(out_ty)}), Text::lit("the rows' firings this tick, by key"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Stamped::new"), Array<crate::lower::model::Ex>{}}));
                    auto wx6 = ({
                        Wx this_ = wx5;
                        this_.gns = each(this_.gns, [&](const Gn& n) {
                            return n.id == gid
                                ? with_inputs(n, Array(std::vector{prism_rtl::cat(name, "_gathered")}))
                                : n;
                        });
                        this_;
                    });
                    auto row_done = connect(row_wx, r, Sk(Sk::SkUp{prism_rtl::cat(name, "_all_in")}));
                    auto wx7 = add_builder(wx6, name, pos, kt, vt, row_name, keyed, reads, PendingRow{.wx = row_done, .qk = row_name, .params = row_params, .gather = std::optional(gid)}, passed);
                    (prism_rtl::finished(std::tuple{wx7, Wres(Wres::WrEv{ev_ref_of(wx7, gid)})}));
                });
                })
                    : prism_rtl::is<Wres::WrDyn>(_m) ? ({
                    auto&& ex = prism_rtl::as<Wres::WrDyn>(_m).a0;
                    auto&& result_reads = prism_rtl::as<Wres::WrDyn>(_m).a1;
                    auto&& rt = prism_rtl::as<Wres::WrDyn>(_m).a2;
                    ({
                    auto gathered = prism_rtl::cat(name, "_all");
                    auto gathered_ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(kt), prism_rtl::rc(rt)});
                    auto own_behind = filter(reads_closed(row_wx.dyn_reads, result_reads), [&](const Read& r) {
                        return ({
                            __label__ _done;
                            prism_rtl::Slot<bool> _v;
                            if (prism_rtl::is<Read::OwnRead>(r)) {
                                _v.set(true);
                                goto _done;
                            }
                            if (prism_rtl::is<Read::ParentRead>(r)) {
                                _v.set(false);
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        });
                    });
                    auto row_done = ({
                        Wx this_ = row_wx;
                        this_.getters = crate::prelude::push(this_.getters, crate::lower::model::MethDef{.name = Text::lit("result"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = rt, .body = Array<crate::lower::model::Do>{}, .tail = ex, .doc = Text::lit("The row's result, which the block gathers by key.")});
                        this_.result_moved = len(own_behind) > Nat(0u)
                            ? std::optional(std::tuple{prism_rtl::cat(gathered, "_moved"), own_behind})
                            : std::optional<std::tuple<Text, Array<Read>>>{};
                        this_;
                    });
                    auto wx4 = add_builder(wx3, name, pos, kt, vt, row_name, keyed, reads, PendingRow{.wx = row_done, .qk = row_name, .params = row_params, .gather = std::optional<Nat>{}}, passed);
                    auto all = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), name})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}})), Text::lit("iter"), Array<crate::lower::model::Ex>{}})), Text::lit("map"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("k")}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")})})})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XTuple{Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("k")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")})), Text::lit("result"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})}))})})})), Text::lit("collect"), Array<crate::lower::model::Ex>{}});
                    auto what = prism_rtl::cat("the dynamic gathered by the `for` at place ", crate::lower::model::place_text(pos));
                    auto wx5 = ({
                        Wx this_ = wx4;
                        this_.taken = append(this_.taken, Array(std::vector{gathered, prism_rtl::cat(gathered, "_now"), prism_rtl::cat(gathered, "_snap"), prism_rtl::cat(gathered, "_moved"), prism_rtl::cat(gathered, "_publish")}));
                        this_.getters = append(this_.getters, Array(std::vector{crate::lower::model::MethDef{.name = prism_rtl::cat(gathered, "_now"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = gathered_ty, .body = Array<crate::lower::model::Do>{}, .tail = all, .doc = Text::lit("The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).")}, snap_getter(gathered, gathered_ty, Text::lit("The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after."))}));
                        this_.fields = crate::prelude::push(this_.fields, std::tuple{prism_rtl::cat(gathered, "_snap"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutSnapshot{prism_rtl::rc(gathered_ty)}), prism_rtl::cat("the `for` at place ", crate::lower::model::place_text(pos), "'s gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)")});
                        this_.inits = crate::prelude::push(this_.inits, std::tuple{prism_rtl::cat(gathered, "_snap"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Snapshot::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{what})})})});
                        this_.snaps = crate::prelude::push(this_.snaps, SnapDef{.name = gathered, .live = prism_rtl::cat(gathered, "_now"), .ty = gathered_ty, .eq = crate::lower::ty_has_eq(lx, crate::lower::peel(full), Array<Text>{}), .builder = name, .before = false, .what = what});
                        this_.dyn_reads = insert(this_.dyn_reads, prism_rtl::cat(gathered, "_now"), union_reads(reads, block_reads(reads_closed(row_wx.dyn_reads, result_reads))));
                        this_;
                    });
                    (prism_rtl::finished(std::tuple{wx5, Wres(Wres::WrDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), gathered, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{Read(Read::OwnRead{gathered})}), gathered_ty})}));
                });
                })
                    : ({
                    auto wx4 = add_builder(wx3, name, pos, kt, vt, row_name, keyed, reads, PendingRow{.wx = row_wx, .qk = row_name, .params = row_params, .gather = std::optional<Nat>{}}, passed);
                    (prism_rtl::finished(std::tuple{wx4, Wres(Wres::WrUnit{})}));
                });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start ForLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Wx, Wres>> start_for_line(Wx wx, crate::lower::Env benv, crate::lower::Env menv, std::optional<crate::syntax::ForBinders> binders_opt, crate::syntax::Expr source, crate::syntax::Block body, crate::syntax::Expr e, std::optional<crate::lower::Bn> bound_opt) {
    return prism_rtl::make_rc<ForLine>(wx, benv, menv, binders_opt, source, body, e, bound_opt);
}


/// EntryGetter: fn Text, OutTy -> MethDef
crate::lower::model::MethDef entry_getter(const Text& src_getter, const crate::lower::model::OutTy& vt) {
    auto found = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("parent")})), src_getter, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("key")}))})})})), Text::lit("cloned"), Array<crate::lower::model::Ex>{}});
    auto opened_1 = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("before"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("cx")})}), prism_rtl::rc(found)})})})), Text::lit("expect"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{Text::lit("a row's key is in its source as its tick opened")})})});
    auto body = Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("v")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("left_entry")})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}})), Text::lit("as_ref"), Array<crate::lower::model::Ex>{}}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoReturn{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}))})})}), Array<crate::lower::model::Do>{}}), crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("parent")}), parent_ref()})});
    auto tail = crate::lower::model::Ex(crate::lower::model::Ex::XMatch{prism_rtl::rc(found), Array(std::vector{crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("v")})})}), .conds = Array<crate::lower::model::Cc>{}, .body = crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")})}, crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{Text::lit("None")}), .conds = Array<crate::lower::model::Cc>{}, .body = opened_1}}), false, vt});
    return crate::lower::model::MethDef{.name = Text::lit("entry"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = vt, .body = body, .tail = tail, .doc = Text::lit("The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.")};
}


/// AddBuilder: fn Wx, Text, Pos, OutTy, OutTy, Text, Bool, [Read], PendingRow, [Ex] -> Wx
Wx add_builder(const Wx& wx, const Text& name, const crate::lower::model::Pos_& pos, const crate::lower::model::OutTy& kt, const crate::lower::model::OutTy& vt, const Text& row_name, const bool& keyed, const Array<Read>& reads, const PendingRow& waiting, const Array<crate::lower::model::Ex>& passed) {
    auto wx0 = add_field_last(wx, name, crate::lower::model::OutTy(crate::lower::model::OutTy::OutCell{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(kt), prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutRc{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{row_name, Array<crate::lower::model::OutTy>{}}))}))}))}), prism_rtl::cat("the rows of the `for` at place ", crate::lower::model::place_text(pos)), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("RefCell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Map::new"), Array<crate::lower::model::Ex>{}})})}));
    Wx this_ = wx0;
    this_.builders = crate::prelude::push(this_.builders, crate::lower::model::ForDef{.name = name, .pos = pos, .at = place_at(wx, Text::lit("self"), pos), .key_ty = kt, .value_ty = vt, .row_node = row_name, .keyed = keyed, .source = prism_rtl::cat(name, "_source"), .parent = crate::lower::model::Ex(crate::lower::model::Ex::XWeak{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))}), .passed = passed});
    this_.build_holds = union_reads(this_.build_holds, reads);
    this_.pending = crate::prelude::push(this_.pending, waiting);
    return this_;
}


/// RowPlaceReads: fn Wx -> [Read]
Array<Read> row_place_reads(const Wx& row_wx) {
    return fold(row_wx.places, Array<Read>{}, [&](const Array<Read>& acc, const Place& pl) { return union_reads(acc, block_reads(reads_closed(row_wx.dyn_reads, pl.reads))); });
}


/// HostedParams: fn Wx -> [((Text, OutTy))]
Array<std::tuple<Text, crate::lower::model::OutTy>> hosted_params(const Wx& wx) {
    auto&& _m = hosted_rows(wx);
    if (prism_rtl::is_some(_m)) {
        return Array(std::vector{std::tuple{Text::lit("enclosing"), crate::lower::host_of_ty()}});
    }
    if (prism_rtl::is_none(_m)) {
        return Array<std::tuple<Text, crate::lower::model::OutTy>>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// HostedPassed: fn Wx -> [Ex]
Array<crate::lower::model::Ex> hosted_passed(const Wx& wx) {
    auto&& _m = hosted_rows(wx);
    if (prism_rtl::is_some(_m)) {
        return Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(host_field_ex(wx, wx.pos))})});
    }
    if (prism_rtl::is_none(_m)) {
        return Array<crate::lower::model::Ex>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// RowReads: fn Env, Ex -> Env
crate::lower::Env row_reads(const crate::lower::Env& env, const crate::lower::model::Ex& pref) {
    return fold(keys(env->names), env, [&](const crate::lower::Env& en, const Text& k) {
        return ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::Env> _v;
            auto&& _m = crate::prelude::get(env->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::Bn::BnHold>(prism_rtl::some_of(_m))) {
                auto&& f = prism_rtl::as<crate::lower::Bn::BnHold>(prism_rtl::some_of(_m)).a0;
                auto&& t = prism_rtl::as<crate::lower::Bn::BnHold>(prism_rtl::some_of(_m)).a1;
                _v.set(crate::lower::bind(en, k, crate::lower::Bn(crate::lower::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(pref), f})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{Read(Read::ParentRead{f})}), t})));
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::Bn::BnDyn>(prism_rtl::some_of(_m)) && prism_rtl::is<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::Bn::BnDyn>(prism_rtl::some_of(_m)).a0)) {
                auto&& m149659_1_0_0 = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a0;
                auto&& m = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a1;
                auto&& xs = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a2;
                auto&& t = prism_rtl::as<crate::lower::Bn::BnDyn>(prism_rtl::some_of(_m)).a2;
                if (prism_rtl::is<crate::lower::model::Ex::XSelf>(m149659_1_0_0)) {
                    _v.set(crate::lower::bind(en, k, crate::lower::Bn(crate::lower::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(pref), m, xs}), Array(std::vector{Read(Read::ParentRead{m})}), t})));
                    goto _done;
                }
            }
            {
                _v.set(en);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// EventsOf: fn Env, Env -> Env
crate::lower::Env events_of(const crate::lower::Env& ports, const crate::lower::Env& env) {
    return fold(keys(ports->names), env, [&](const crate::lower::Env& en, const Text& k) {
        return ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::Env> _v;
            auto&& _m = crate::prelude::get(ports->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::Bn::BnEv>(prism_rtl::some_of(_m))) {
                auto&& er = prism_rtl::as<crate::lower::Bn::BnEv>(prism_rtl::some_of(_m)).a0;
                auto&& t = prism_rtl::as<crate::lower::Bn::BnEv>(prism_rtl::some_of(_m)).a1;
                _v.set(crate::lower::bind(en, k, crate::lower::Bn(crate::lower::Bn::BnEv{er, t})));
                goto _done;
            }
            {
                _v.set(en);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// BlockReads: fn [Read] -> [Read]
Array<Read> block_reads(const Array<Read>& reads) {
    return fold(reads, Array<Read>{}, [&](const Array<Read>& acc, const Read& r) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Read>> _v;
            if (prism_rtl::is<Read::ParentRead>(r)) {
                auto&& f = prism_rtl::as<Read::ParentRead>(r).a0;
                _v.set(add_read(acc, Read(Read::OwnRead{f})));
                goto _done;
            }
            if (prism_rtl::is<Read::OwnRead>(r)) {
                _v.set(acc);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// RowLocals: unbounded fn Env, Env, Block -> [RowLocal]
Array<RowLocal> row_locals(const crate::lower::Env& benv, const crate::lower::Env& menv, const crate::syntax::Block& body) {
    return fold(crate::lower::read_names(crate::check::typed::block_exprs(body)), Array<RowLocal>{}, [&](const Array<RowLocal>& acc, const Text& n) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<RowLocal>> _v;
            auto&& _m = crate::prelude::get(menv->names, n);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<crate::lower::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& mode = prism_rtl::as<crate::lower::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                auto&& t = prism_rtl::as<crate::lower::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(({
                    auto field = crate::lower::snake(n);
                    (((field == Text::lit("key")) || (field == Text::lit("value"))) || (field == Text::lit("parent"))) || (field == Text::lit("path"))
                    ? acc
                    : crate::prelude::push(acc, RowLocal{.name = n, .field = field, .ty = t, .passed = crate::lower::own(crate::lower::Vl(crate::lower::Vl::VlPlace{rs, mode, t}))});
                }));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// ForEnvs: unbounded fn Env, Env, ?ForBinders, Bn, Bn, Bn, Bn, OutTy -> ((Env, Env))
std::tuple<crate::lower::Env, crate::lower::Env> for_envs(const crate::lower::Env& benv, const crate::lower::Env& menv, const std::optional<crate::syntax::ForBinders>& binders_opt, const crate::lower::Bn& key_b, const crate::lower::Bn& key_m, const crate::lower::Bn& val_b, const crate::lower::Bn& val_m, const crate::lower::model::OutTy& vt) {
    auto be0 = crate::lower::bind(crate::lower::bind(benv, Text::lit("key"), key_b), Text::lit("$_"), val_b);
    auto me0 = crate::lower::bind(crate::lower::bind(menv, Text::lit("key"), key_m), Text::lit("$_"), val_m);
    if (prism_rtl::is_none(binders_opt)) {
        return std::tuple{be0, me0};
    }
    if (prism_rtl::is_some(binders_opt)) {
        auto&& fb = prism_rtl::some_of(binders_opt);
        auto&& _m = fb.second;
        if (prism_rtl::is_some(_m)) {
            auto&& second = prism_rtl::some_of(_m);
            auto be1 = bind_pat(be0, fb.first, key_b, crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("key")}), kt0());
            auto me1 = bind_pat(me0, fb.first, key_m, crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("key")}), kt0());
            return std::tuple{bind_pat(be1, second, val_b, crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("value")}), vt), bind_pat(me1, second, val_m, crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), vt)};
        }
        if (prism_rtl::is_none(_m)) {
            return std::tuple{bind_pat(be0, fb.first, val_b, crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("value")}), vt), bind_pat(me0, fb.first, val_m, crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), vt)};
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


/// let kt0
crate::lower::model::OutTy kt0() {
    return crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{});
}


/// BindPat: fn Env, Pattern, Bn, Ex, OutTy -> Env
crate::lower::Env bind_pat(const crate::lower::Env& env, const crate::syntax::Pattern_& p_, const crate::lower::Bn& b, const crate::lower::model::Ex& whole, const crate::lower::model::OutTy& t) {
    auto&& _m = p_.kind;
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        return crate::lower::bind(env, crate::check::env::sname_key(n), b);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return bind_pat(env, q, b, whole, t);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m)) {
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        auto ts = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
            if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t)) {
                auto&& xs = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t).a0;
                _v.set(xs);
                goto _done;
            }
            {
                _v.set(Array<crate::lower::model::OutTy>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        return fold(crate::check::errors::range0(len(ps)), env, [&](const crate::lower::Env& en, const Nat& i) {
            return ({
                __label__ _done;
                prism_rtl::Slot<crate::lower::Env> _v;
                auto&& _m = index(ps, i);
                if (prism_rtl::is_some(_m)) {
                    auto&& q = prism_rtl::some_of(_m);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<crate::lower::Env> _v;
                        auto&& _m = q.kind;
                        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                            auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                            _v.set(crate::lower::bind(en, crate::check::env::sname_key(n), part_bn(b, whole, i, or_(index(ts, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})))));
                            goto _done;
                        }
                        {
                            _v.set(en);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(en);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        });
    }
    {
        return env;
    }
}


/// PartBn: fn Bn, Ex, Nat, OutTy -> Bn
crate::lower::Bn part_bn(const crate::lower::Bn& bn0, const crate::lower::model::Ex& whole, const Nat& i, const crate::lower::model::OutTy& t) {
    if (prism_rtl::is<crate::lower::Bn::BnDyn>(bn0)) {
        auto&& x = prism_rtl::as<crate::lower::Bn::BnDyn>(bn0).a0;
        auto&& rds = prism_rtl::as<crate::lower::Bn::BnDyn>(bn0).a1;
        return crate::lower::Bn(crate::lower::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XPart{prism_rtl::rc(x), i}), rds, t});
    }
    {
        auto&& other = bn0;
        return crate::lower::Bn(crate::lower::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XPart{prism_rtl::rc(whole), i}), crate::lower::Holding(crate::lower::Holding::Owned{}), t});
    }
}


/// RowSuffix: fn Wx -> Text
Text row_suffix(const Wx& wx) {
    auto n = len(wx->rows) + len(wx.pending);
    return n == Nat(0u) ? Text::lit("") : prism_rtl::cat(n);
}


/// GnTyNamed: fn Wx, Text -> OutTy
crate::lower::model::OutTy gn_ty_named(const Wx& wx, const Text& n) {
    return fold(wx.gns, crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), [&](const crate::lower::model::OutTy& acc, const Gn& g) { return g.name == n ? g.ty : acc; });
}


/// RowEnv: unbounded fn Wx, Wx, Env, Block -> ((Wx, Wx, Env))
std::tuple<Wx, Wx, crate::lower::Env> row_env(const Wx& parent, const Wx& row_wx, const crate::lower::Env& menv, const crate::syntax::Block& body) {
    auto names = crate::lower::read_names(crate::check::typed::block_exprs(body));
    return fold(names, std::tuple{parent, row_wx, crate::lower::empty_env()}, [&](const std::tuple<Wx, Wx, crate::lower::Env>& _p0, const Text& n) {
        auto&& p_ = std::get<0>(_p0);
        auto&& r = std::get<1>(_p0);
        auto&& env = std::get<2>(_p0);
        return ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Wx, Wx, crate::lower::Env>> _v;
            auto&& _m = crate::prelude::get(menv->names, n);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<crate::lower::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& mode = prism_rtl::as<crate::lower::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                auto&& t = prism_rtl::as<crate::lower::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(std::tuple{p_, r, crate::lower::bind(env, n, crate::lower::Bn(crate::lower::Bn::BnLocal{over_parent(rs), crate::lower::Holding(crate::lower::Holding::Owned{}), t}))});
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::Bn::BnEv>(prism_rtl::some_of(_m))) {
                auto&& er = prism_rtl::as<crate::lower::Bn::BnEv>(prism_rtl::some_of(_m)).a0;
                auto&& t = prism_rtl::as<crate::lower::Bn::BnEv>(prism_rtl::some_of(_m)).a1;
                _v.set(({
                    auto pname = gn_of(p_, er.node_).name;
                    auto [rs, r1] = fresh_name(r, crate::lower::snake(n));
                    auto [id, r2] = add_gn(r1, rs, t, GnKind(GnKind::GnPort{}), Nat(0u));
                    auto r3 = ({
                        Wx this_ = r2;
                        this_.subs = crate::prelude::push(this_.subs, std::tuple{pname, rs, t});
                        this_;
                    });
                    auto p2 = crate::check::types::has_text(p_.ports, pname)
                        ? p_
                        : connect(with_port(p_, pname), ev_ref_of(p_, er.node_), Sk(Sk::SkPort{pname}));
                    std::tuple{p2, r3, crate::lower::bind(env, n, crate::lower::Bn(crate::lower::Bn::BnEv{ev_ref_of(r3, id), t}))};
                }));
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::Bn::BnDyn>(prism_rtl::some_of(_m)) && prism_rtl::is<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::Bn::BnDyn>(prism_rtl::some_of(_m)).a0)) {
                auto&& recv = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a0;
                auto&& m = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a1;
                auto&& xs = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a2;
                auto&& t = prism_rtl::as<crate::lower::Bn::BnDyn>(prism_rtl::some_of(_m)).a2;
                _v.set(recv == crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})
                    ? std::tuple{p_, r, crate::lower::bind(env, n, crate::lower::Bn(crate::lower::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(parent_ref()), m, xs}), Array(std::vector{Read(Read::ParentRead{m})}), t}))}
                    : std::tuple{p_, r, env});
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::Bn::BnHold>(prism_rtl::some_of(_m))) {
                auto&& f = prism_rtl::as<crate::lower::Bn::BnHold>(prism_rtl::some_of(_m)).a0;
                auto&& t = prism_rtl::as<crate::lower::Bn::BnHold>(prism_rtl::some_of(_m)).a1;
                _v.set(std::tuple{p_, r, crate::lower::bind(env, n, crate::lower::Bn(crate::lower::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(parent_ref()), f})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{Read(Read::ParentRead{f})}), t}))});
                goto _done;
            }
            {
                _v.set(std::tuple{p_, r, env});
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}

}  // namespace crate::lower::node_
