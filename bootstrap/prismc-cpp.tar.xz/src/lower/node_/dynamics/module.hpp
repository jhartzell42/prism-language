// The module `Lower.Node.Dynamics`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <lower/node_/dynamics/types.hpp>
#include "elem.types.hpp"
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace lower::node_::dynamics {

std::tuple<crate::lower::model::Ex, Array<crate::lower::node_::Read>> dynamic_expr_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const crate::syntax::Expr& e_p2);

prism_rtl::JobRef<std::tuple<crate::lower::model::Ex, Array<crate::lower::node_::Read>>> start_dynamic_expr_f(crate::lower::node_::Wx wx_p0, crate::lower::types::Env menv_p1, crate::syntax::Expr e_p2);

std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> never_event_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::model::OutTy& t_p1);

std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> event_ref_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const crate::syntax::Expr& e_p2);

prism_rtl::JobRef<std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx>> start_event_ref_f(crate::lower::node_::Wx wx_p0, crate::lower::types::Env menv_p1, crate::syntax::Expr e_p2);

std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> event_if_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const crate::syntax::Expr& c_p2, const crate::syntax::Expr& a_p3, const crate::syntax::Expr& b_p4, const crate::lower::model::OutTy& t_p5);

std::optional<crate::syntax::Expr> block_expr_o(const crate::syntax::Block& b_p0);

Text callee_key_f(const crate::lower::Lx& lx_p0, const crate::syntax::Expr& c_p1);

std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> pair_event_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const Array<crate::syntax::Arg>& args_p2, const crate::lower::node_::GnKind& kind_p3, const crate::lower::model::OutTy& t_p4);

std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> merge_all_event_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const Array<crate::syntax::Arg>& args_p2, const crate::lower::model::OutTy& t_p3);

std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> updated_event_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const Array<crate::syntax::Arg>& args_p2, const crate::lower::model::OutTy& t_p3);

std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> filter_event_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const Array<crate::syntax::Arg>& args_p2, const bool& is_unit_p3);

std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> gate_event_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const Array<crate::syntax::Arg>& args_p2);

std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> event_map_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const crate::syntax::Expr& e_p2);

crate::lower::types::Vl firing_value_f(const crate::lower::model::Ex& ex0, const crate::lower::model::OutTy& t_p1);

Array<crate::syntax::Expr> operands_f(const crate::syntax::Expr& e_p0);

std::tuple<Nat, crate::lower::node_::Wx> merge_f(const crate::lower::node_::Wx& wx_p0, const Text& name_p1, const crate::lower::model::OutTy& t_p2, const crate::lower::node_::EvRef& l_p3, const crate::lower::node_::EvRef& r_p4);

std::tuple<Nat, crate::lower::node_::Wx> combinator_f(const crate::lower::node_::Wx& wx_p0, const Text& name_p1, const crate::lower::model::OutTy& t_p2, const crate::lower::node_::GnKind& kind_p3, const crate::lower::node_::EvRef& l_p4, const crate::lower::node_::EvRef& r_p5, const crate::lower::model::OutTy& lt_p6, const crate::lower::model::OutTy& rt_p7);

crate::lower::node_::Gn with_inputs_f(const crate::lower::node_::Gn& n_p0, const Array<Text>& ins_p1);

crate::lower::node_::Gn with_reads_f(const crate::lower::node_::Gn& n_p0, const Array<crate::lower::node_::Read>& reads_p1);

}  // namespace lower::node_::dynamics


namespace lower::node_::dynamics {

/// The step machine of `DynamicExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DynamicExpr: unbounded fn Wx, Env, Expr -> ((Ex, [Read]))
struct DynamicExpr : prism_rtl::Job<std::tuple<crate::lower::model::Ex, Array<crate::lower::node_::Read>>> {
    crate::lower::node_::Wx wx_p0;
    crate::lower::types::Env menv_p1;
    crate::syntax::Expr e_p2;
    DynamicExpr(crate::lower::node_::Wx wx_p0, crate::lower::types::Env menv_p1, crate::syntax::Expr e_p2) : wx_p0(std::move(wx_p0)), menv_p1(std::move(menv_p1)), e_p2(std::move(e_p2)) {}
    prism_rtl::Turn<std::tuple<crate::lower::model::Ex, Array<crate::lower::node_::Read>>> cycle() const override;
};


/// The step machine of `EventRef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// EventRef: unbounded fn Wx, Env, Expr -> ((EvRef, Wx))
struct EventRef : prism_rtl::Job<std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx>> {
    crate::lower::node_::Wx wx_p0;
    crate::lower::types::Env menv_p1;
    crate::syntax::Expr e_p2;
    EventRef(crate::lower::node_::Wx wx_p0, crate::lower::types::Env menv_p1, crate::syntax::Expr e_p2) : wx_p0(std::move(wx_p0)), menv_p1(std::move(menv_p1)), e_p2(std::move(e_p2)) {}
    prism_rtl::Turn<std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx>> cycle() const override;
};


}  // namespace lower::node_::dynamics

}  // namespace crate
