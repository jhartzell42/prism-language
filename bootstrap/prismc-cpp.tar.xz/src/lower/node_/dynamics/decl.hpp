// The module `Lower.Node.Dynamics`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace lower::node_::dynamics {

struct DynamicExpr;

struct EventRef;

}  // namespace lower::node_::dynamics


}  // namespace crate
