// The module `Lower.Node`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace lower::node_ {

struct EvRef;

struct FlatDef;

struct Gn;

class GnKind;

struct HostDef;

struct Out;

struct PendingRow;

struct Place;

class Read;

struct RowMarks;

class Sk;

struct SnapDef;

class Wres;

struct Wx;

struct IdPipe;

}  // namespace lower::node_

}  // namespace crate
