// The module `Lower.Node`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace lower::node_ {

struct EvRef;

struct FlatDef;

struct Gn;

class GnKind;

struct HostDef;

struct Out;

struct PendingRow;

struct Place;

class Read;

struct RowMarks;

class Sk;

struct SnapDef;

class Wres;

struct Wx;

struct IdPipe;

}  // namespace lower::node_

namespace lower::node_ {

/// `GnKind`:
///
/// ```prism
/// type GnKind = choice:
/// ```
class GnKind {
public:
    using prism_value = void;
    struct GnNamed;
    struct GnAnswer;
    struct GnStarted;
    struct GnDeferred;
    struct GnPort;
    struct GnMerge;
    struct GnUnion;
    struct GnBoth;
    struct GnExcept;
    struct GnMergeAll;
    struct GnGather;
    struct GnUpdated;
    struct GnNever;
    using Cases = std::variant<GnNamed, GnAnswer, GnStarted, GnDeferred, GnPort, GnMerge, GnUnion, GnBoth, GnExcept, GnMergeAll, GnGather, GnUpdated, GnNever>;
    template <class C>
        requires prism_rtl::one_of<C, GnNamed, GnAnswer, GnStarted, GnDeferred, GnPort, GnMerge, GnUnion, GnBoth, GnExcept, GnMergeAll, GnGather, GnUpdated, GnNever>
    GnKind(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<GnKind> from_pod(const Pod& whole);
    friend inline bool operator==(const GnKind& a, const GnKind& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `Read`:
///
/// ```prism
/// type Read = choice:
/// ```
class Read {
public:
    using prism_value = void;
    struct OwnRead;
    struct ParentRead;
    using Cases = std::variant<OwnRead, ParentRead>;
    template <class C>
        requires prism_rtl::one_of<C, OwnRead, ParentRead>
    Read(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Read> from_pod(const Pod& whole);
    friend inline bool operator==(const Read& a, const Read& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `Sk`:
///
/// ```prism
/// type Sk = choice:
/// ```
class Sk {
public:
    using prism_value = void;
    struct SkNode;
    struct SkIn;
    struct SkHold;
    struct SkRequest;
    struct SkResult;
    struct SkArm;
    struct SkCycle;
    struct SkUp;
    struct SkPort;
    struct SkMachine;
    using Cases = std::variant<SkNode, SkIn, SkHold, SkRequest, SkResult, SkArm, SkCycle, SkUp, SkPort, SkMachine>;
    template <class C>
        requires prism_rtl::one_of<C, SkNode, SkIn, SkHold, SkRequest, SkResult, SkArm, SkCycle, SkUp, SkPort, SkMachine>
    Sk(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    Pod to_pod() const;
    static Result<Sk> from_pod(const Pod& whole);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `Wres`:
///
/// ```prism
/// type Wres = choice:
/// ```
class Wres {
public:
    using prism_value = void;
    struct WrEv;
    struct WrDyn;
    struct WrPlain;
    struct WrUnit;
    struct WrHosted;
    using Cases = std::variant<WrEv, WrDyn, WrPlain, WrUnit, WrHosted>;
    template <class C>
        requires prism_rtl::one_of<C, WrEv, WrDyn, WrPlain, WrUnit, WrHosted>
    Wres(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;

private:
    prism_rtl::Rc<const Cases> cases_;
};


}  // namespace lower::node_

}  // namespace crate
