// The module `Lower.Node.Def`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace lower::node_::def {

class HowBound;

struct NodeDefOf;

struct BlockInto;

struct PreBind;

struct GivesResult;

struct PreBindName;

struct ManyInstances;

struct WidgetStmt;

struct BindParts;

struct ResultOf;

struct ResultOfTyped;

struct HoldLine;

struct NamesInited;

struct LetLine;

struct BuildLine;

}  // namespace lower::node_::def

namespace lower::node_::def {

/// `HowBound`:
///
/// ```prism
/// type HowBound = choice:
/// ```
class HowBound {
public:
    using prism_value = void;
    struct AsHold;
    struct AsBind;
    struct AsLet;
    struct AsResult;
    using Cases = std::variant<AsHold, AsBind, AsLet, AsResult>;
    template <class C>
        requires prism_rtl::one_of<C, AsHold, AsBind, AsLet, AsResult>
    HowBound(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<HowBound> from_pod(const Pod& whole);
    friend inline bool operator==(const HowBound& a, const HowBound& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


}  // namespace lower::node_::def

}  // namespace crate
