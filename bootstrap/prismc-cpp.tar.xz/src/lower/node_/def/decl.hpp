// The module `Lower.Node.Def`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace lower::node_::def {

class HowBound;

struct NodeDefOf;

struct BlockInto;

struct PreBind;

struct GivesResult;

struct PreBindName;

struct ManyInstances;

struct WidgetStmt;

struct BindParts;

struct ResultOf;

struct ResultOfTyped;

struct HoldLine;

struct NamesInited;

struct LetLine;

struct BuildLine;

}  // namespace lower::node_::def

}  // namespace crate
