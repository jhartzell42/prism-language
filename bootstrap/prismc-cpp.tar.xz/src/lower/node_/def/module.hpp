// The module `Lower.Node.Def`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <lower/node_/def/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace lower::node_::def {

crate::lower::model::NodeDef node_def_of(const crate::lower::Lx& lx, const Text& qk, const Array<crate::syntax::Pattern_>& params, const crate::syntax::Block& body, const crate::check::types::Scheme& sc, const bool& is_root);

prism_rtl::JobRef<crate::lower::model::NodeDef> start_node_def_of(crate::lower::Lx lx, Text qk, Array<crate::syntax::Pattern_> params, crate::syntax::Block body, crate::check::types::Scheme sc, bool is_root);

crate::lower::node_::Wx root_result(const crate::lower::node_::Wx& wx);

crate::lower::node_::Wx block_into(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const crate::syntax::Block& b);

prism_rtl::JobRef<crate::lower::node_::Wx> start_block_into(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, crate::syntax::Block b);

std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env> pre_bind(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const crate::syntax::Stmt& s);

prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> start_pre_bind(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, crate::syntax::Stmt s);

bool gives_result(const crate::lower::Lx& lx, const crate::lower::types::Env& menv, const crate::syntax::Expr& e);

prism_rtl::JobRef<bool> start_gives_result(crate::lower::Lx lx, crate::lower::types::Env menv, crate::syntax::Expr e);

bool is_prelude_name(const Text& q);

bool is_getter_builtin(const Text& q);

bool is_widget_ty(const crate::check::types::Ty& t);

HowBound how_bound(const std::optional<crate::syntax::Expr>& opt0);

std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env> pre_bind_name(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const crate::syntax::SName& n, const HowBound& how);

prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> start_pre_bind_name(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, crate::syntax::SName n, HowBound how);

crate::lower::types::Env with_use(const crate::lower::types::Env& env, const Text& ukey, const Text& bkey);

std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> many_instances(const crate::lower::Lx& lx, const crate::syntax::Range& span);

prism_rtl::JobRef<std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>> start_many_instances(crate::lower::Lx lx, crate::syntax::Range span);

bool is_switched(const crate::check::types::Ty& t);

std::optional<crate::lower::types::Bn> binding_of(const crate::lower::types::Env& env, const crate::syntax::Pattern_& p_);

std::optional<crate::lower::types::Bn> binding_of_name(const crate::lower::types::Env& env, const crate::syntax::Pattern_& p_);

std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env> widget_stmt(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const crate::syntax::Stmt& s, const bool& last);

prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> start_widget_stmt(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, crate::syntax::Stmt s, bool last);

std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env> bind_hosted(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const crate::lower::node_::Wres& res, const crate::lower::types::Bn& doc, const Array<crate::syntax::Pattern_>& ps);

std::tuple<crate::lower::types::Env, crate::lower::types::Env> bind_part(const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const std::optional<crate::syntax::Pattern_>& p__opt, const std::optional<crate::lower::types::Bn>& b_opt);

std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env> bind_part2(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const std::optional<crate::syntax::Pattern_>& p__opt, const std::optional<crate::lower::types::Bn>& b_opt);

std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env> bind_parts(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const Array<crate::lower::node_::Wres>& parts, const Array<crate::syntax::Pattern_>& ps);

prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> start_bind_parts(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, Array<crate::lower::node_::Wres> parts, Array<crate::syntax::Pattern_> ps);

std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env> result_getter(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& menv, const crate::syntax::SName& n, const crate::lower::model::Ex& ex, const Array<crate::lower::node_::Read>& rds, const crate::lower::model::OutTy& t, const crate::lower::types::Env& benv2, const crate::lower::types::Env& menv2);

crate::lower::node_::Wx bind_plain_result(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& menv, const crate::syntax::Pattern_& p_, const crate::lower::model::Ex& ex, const crate::lower::model::OutTy& t);

prism_rtl::JobRef<crate::lower::node_::Wx> start_bind_plain_result(crate::lower::node_::Wx wx, crate::lower::types::Env menv, crate::syntax::Pattern_ p_, crate::lower::model::Ex ex, crate::lower::model::OutTy t);

crate::lower::node_::Wx refuse_plain_result(const crate::lower::node_::Wx& wx, const crate::syntax::Pattern_& p_);

crate::lower::types::Bn bundle_bn(const crate::lower::node_::Wres& res);

crate::lower::node_::Wres bn_res(const crate::lower::types::Bn& b);

crate::lower::node_::Wres part_res(const std::optional<crate::lower::types::Bn>& b_opt);

crate::lower::node_::Wx set_result(const crate::lower::node_::Wx& wx, const crate::lower::node_::Wres& res);

std::tuple<crate::lower::node_::Wres, crate::lower::node_::Wx> result_of(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const crate::syntax::Expr& x);

prism_rtl::JobRef<std::tuple<crate::lower::node_::Wres, crate::lower::node_::Wx>> start_result_of(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, crate::syntax::Expr x);

std::tuple<crate::lower::node_::Wres, crate::lower::node_::Wx> result_of_typed(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const crate::syntax::Expr& x, const crate::check::types::Ty& full, const crate::lower::model::OutTy& t);

prism_rtl::JobRef<std::tuple<crate::lower::node_::Wres, crate::lower::node_::Wx>> start_result_of_typed(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, crate::syntax::Expr x, crate::check::types::Ty full, crate::lower::model::OutTy t);

std::tuple<crate::lower::node_::Wx, crate::lower::types::Env> hold_line(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const crate::syntax::Pattern_& p_, const crate::syntax::Expr& init, const crate::syntax::Expr& step_);

prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env>> start_hold_line(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, crate::syntax::Pattern_ p_, crate::syntax::Expr init, crate::syntax::Expr step_);

crate::lower::types::Env init_env(const crate::lower::types::Env& env);

bool all_inited(const crate::lower::node_::Wx& wx, const Array<crate::lower::node_::Read>& reads);

bool names_inited(const crate::lower::types::Env& env, const crate::syntax::Expr& e);

prism_rtl::JobRef<bool> start_names_inited(crate::lower::types::Env env, crate::syntax::Expr e);

Text pat_text(const crate::syntax::Pattern_& p_);

std::tuple<crate::lower::node_::Wx, crate::lower::types::Env> let_line(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const crate::syntax::Pattern_& p_, const crate::syntax::Expr& e);

prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env>> start_let_line(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, crate::syntax::Pattern_ p_, crate::syntax::Expr e);

crate::lower::node_::Wx widget_let_field(const crate::lower::node_::Wx& wx, const Text& f, const crate::lower::model::OutTy& t, const crate::lower::model::Ex& v_, const Text& doc);

crate::lower::node_::EvRef err_pipe(const crate::lower::node_::EvRef& r);

crate::lower::model::Ex own_as(const crate::lower::model::OutTy& t, const crate::lower::types::Vl& v_);

crate::lower::node_::Wx bind_res(const crate::lower::node_::Wx& wx2, const crate::lower::types::Env& menv, const crate::syntax::Pattern_& p_, const crate::lower::node_::Wres& res);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> build_line(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const crate::syntax::Expr& e, const std::optional<crate::lower::types::Bn>& bound_opt);

prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> start_build_line(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, crate::syntax::Expr e, std::optional<crate::lower::types::Bn> bound_opt);

}  // namespace lower::node_::def


namespace lower::node_::def {

/// The step machine of `NodeDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NodeDefOf: unbounded fn Lx, Text, [Pattern], Block, Scheme, Bool -> NodeDef
struct NodeDefOf : prism_rtl::Job<crate::lower::model::NodeDef> {
    crate::lower::Lx lx;
    Text qk;
    Array<crate::syntax::Pattern_> params;
    crate::syntax::Block body;
    crate::check::types::Scheme sc;
    bool is_root;
    NodeDefOf(crate::lower::Lx lx, Text qk, Array<crate::syntax::Pattern_> params, crate::syntax::Block body, crate::check::types::Scheme sc, bool is_root) : lx(std::move(lx)), qk(std::move(qk)), params(std::move(params)), body(std::move(body)), sc(std::move(sc)), is_root(std::move(is_root)) {}
    prism_rtl::Turn<crate::lower::model::NodeDef> cycle() const override;
};


/// The step machine of `BlockInto`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BlockInto: unbounded fn Wx, Env, Env, Block -> Wx
struct BlockInto : prism_rtl::Job<crate::lower::node_::Wx> {
    crate::lower::node_::Wx wx;
    crate::lower::types::Env benv;
    crate::lower::types::Env menv;
    crate::syntax::Block b;
    BlockInto(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, crate::syntax::Block b) : wx(std::move(wx)), benv(std::move(benv)), menv(std::move(menv)), b(std::move(b)) {}
    prism_rtl::Turn<crate::lower::node_::Wx> cycle() const override;
};


/// The step machine of `PreBind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PreBind: unbounded fn Wx, Env, Env, Stmt -> ((Wx, Env, Env))
struct PreBind : prism_rtl::Job<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> {
    crate::lower::node_::Wx wx;
    crate::lower::types::Env benv;
    crate::lower::types::Env menv;
    crate::syntax::Stmt s;
    PreBind(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, crate::syntax::Stmt s) : wx(std::move(wx)), benv(std::move(benv)), menv(std::move(menv)), s(std::move(s)) {}
    prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> cycle() const override;
};


/// The step machine of `GivesResult`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GivesResult: unbounded fn Lx, Env, Expr -> Bool
struct GivesResult : prism_rtl::Job<bool> {
    crate::lower::Lx lx;
    crate::lower::types::Env menv;
    crate::syntax::Expr e;
    GivesResult(crate::lower::Lx lx, crate::lower::types::Env menv, crate::syntax::Expr e) : lx(std::move(lx)), menv(std::move(menv)), e(std::move(e)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `PreBindName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PreBindName: unbounded fn Wx, Env, Env, SName, HowBound -> ((Wx, Env, Env))
struct PreBindName : prism_rtl::Job<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> {
    crate::lower::node_::Wx wx;
    crate::lower::types::Env benv;
    crate::lower::types::Env menv;
    crate::syntax::SName n;
    HowBound how;
    PreBindName(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, crate::syntax::SName n, HowBound how) : wx(std::move(wx)), benv(std::move(benv)), menv(std::move(menv)), n(std::move(n)), how(std::move(how)) {}
    prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> cycle() const override;
};


/// The step machine of `ManyInstances`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?ManyInstances: unbounded fn Lx, Range -> ?[(([((Text, Ty))], [((Text, Col))]))]
struct ManyInstances : prism_rtl::Job<std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>> {
    crate::lower::Lx lx;
    crate::syntax::Range span;
    ManyInstances(crate::lower::Lx lx, crate::syntax::Range span) : lx(std::move(lx)), span(std::move(span)) {}
    prism_rtl::Turn<std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>> cycle() const override;
};


/// The step machine of `WidgetStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WidgetStmt: unbounded fn Wx, Env, Env, Stmt, Bool -> ((Wx, Env, Env))
struct WidgetStmt : prism_rtl::Job<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> {
    crate::lower::node_::Wx wx;
    crate::lower::types::Env benv;
    crate::lower::types::Env menv;
    crate::syntax::Stmt s;
    bool last;
    WidgetStmt(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, crate::syntax::Stmt s, bool last) : wx(std::move(wx)), benv(std::move(benv)), menv(std::move(menv)), s(std::move(s)), last(std::move(last)) {}
    prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> cycle() const override;
};


/// The step machine of `BindParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindParts: unbounded fn Wx, Env, Env, [Wres], [Pattern] -> ((Wx, Env, Env))
struct BindParts : prism_rtl::Job<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> {
    crate::lower::node_::Wx wx;
    crate::lower::types::Env benv;
    crate::lower::types::Env menv;
    Array<crate::lower::node_::Wres> parts;
    Array<crate::syntax::Pattern_> ps;
    BindParts(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, Array<crate::lower::node_::Wres> parts, Array<crate::syntax::Pattern_> ps) : wx(std::move(wx)), benv(std::move(benv)), menv(std::move(menv)), parts(std::move(parts)), ps(std::move(ps)) {}
    prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> cycle() const override;
};


/// The step machine of `BindPlainResult`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindPlainResult: unbounded fn Wx, Env, Pattern, Ex, OutTy -> Wx
struct BindPlainResult : prism_rtl::Job<crate::lower::node_::Wx> {
    crate::lower::node_::Wx wx;
    crate::lower::types::Env menv;
    crate::syntax::Pattern_ p_;
    crate::lower::model::Ex ex;
    crate::lower::model::OutTy t;
    BindPlainResult(crate::lower::node_::Wx wx, crate::lower::types::Env menv, crate::syntax::Pattern_ p_, crate::lower::model::Ex ex, crate::lower::model::OutTy t) : wx(std::move(wx)), menv(std::move(menv)), p_(std::move(p_)), ex(std::move(ex)), t(std::move(t)) {}
    prism_rtl::Turn<crate::lower::node_::Wx> cycle() const override;
};


/// The step machine of `ResultOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ResultOf: unbounded fn Wx, Env, Env, Expr -> ((Wres, Wx))
struct ResultOf : prism_rtl::Job<std::tuple<crate::lower::node_::Wres, crate::lower::node_::Wx>> {
    crate::lower::node_::Wx wx;
    crate::lower::types::Env benv;
    crate::lower::types::Env menv;
    crate::syntax::Expr x;
    ResultOf(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, crate::syntax::Expr x) : wx(std::move(wx)), benv(std::move(benv)), menv(std::move(menv)), x(std::move(x)) {}
    prism_rtl::Turn<std::tuple<crate::lower::node_::Wres, crate::lower::node_::Wx>> cycle() const override;
};


/// The step machine of `ResultOfTyped`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ResultOfTyped: unbounded fn Wx, Env, Env, Expr, Ty, OutTy -> ((Wres, Wx))
struct ResultOfTyped : prism_rtl::Job<std::tuple<crate::lower::node_::Wres, crate::lower::node_::Wx>> {
    crate::lower::node_::Wx wx;
    crate::lower::types::Env benv;
    crate::lower::types::Env menv;
    crate::syntax::Expr x;
    crate::check::types::Ty full;
    crate::lower::model::OutTy t;
    ResultOfTyped(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, crate::syntax::Expr x, crate::check::types::Ty full, crate::lower::model::OutTy t) : wx(std::move(wx)), benv(std::move(benv)), menv(std::move(menv)), x(std::move(x)), full(std::move(full)), t(std::move(t)) {}
    prism_rtl::Turn<std::tuple<crate::lower::node_::Wres, crate::lower::node_::Wx>> cycle() const override;
};


/// The step machine of `HoldLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// HoldLine: unbounded fn Wx, Env, Env, Pattern, Expr, Expr -> ((Wx, Env))
struct HoldLine : prism_rtl::Job<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env>> {
    crate::lower::node_::Wx wx;
    crate::lower::types::Env benv;
    crate::lower::types::Env menv;
    crate::syntax::Pattern_ p_;
    crate::syntax::Expr init;
    crate::syntax::Expr step_;
    HoldLine(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, crate::syntax::Pattern_ p_, crate::syntax::Expr init, crate::syntax::Expr step_) : wx(std::move(wx)), benv(std::move(benv)), menv(std::move(menv)), p_(std::move(p_)), init(std::move(init)), step_(std::move(step_)) {}
    prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env>> cycle() const override;
};


/// The step machine of `NamesInited`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NamesInited: unbounded fn Env, Expr -> Bool
struct NamesInited : prism_rtl::Job<bool> {
    crate::lower::types::Env env;
    crate::syntax::Expr e;
    NamesInited(crate::lower::types::Env env, crate::syntax::Expr e) : env(std::move(env)), e(std::move(e)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `LetLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LetLine: unbounded fn Wx, Env, Env, Pattern, Expr -> ((Wx, Env))
struct LetLine : prism_rtl::Job<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env>> {
    crate::lower::node_::Wx wx;
    crate::lower::types::Env benv;
    crate::lower::types::Env menv;
    crate::syntax::Pattern_ p_;
    crate::syntax::Expr e;
    LetLine(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, crate::syntax::Pattern_ p_, crate::syntax::Expr e) : wx(std::move(wx)), benv(std::move(benv)), menv(std::move(menv)), p_(std::move(p_)), e(std::move(e)) {}
    prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env>> cycle() const override;
};


/// The step machine of `BuildLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BuildLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
struct BuildLine : prism_rtl::Job<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> {
    crate::lower::node_::Wx wx;
    crate::lower::types::Env benv;
    crate::lower::types::Env menv;
    crate::syntax::Expr e;
    std::optional<crate::lower::types::Bn> bound_opt;
    BuildLine(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, crate::syntax::Expr e, std::optional<crate::lower::types::Bn> bound_opt) : wx(std::move(wx)), benv(std::move(benv)), menv(std::move(menv)), e(std::move(e)), bound_opt(std::move(bound_opt)) {}
    prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> cycle() const override;
};


}  // namespace lower::node_::def

}  // namespace crate
