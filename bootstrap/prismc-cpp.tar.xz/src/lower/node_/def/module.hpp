// The module `Lower.Node.Def`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <lower/node_/def/types.hpp>
#include "elem.types.hpp"
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace lower::node_::def {

crate::lower::model::NodeDef node_def_of_f(const crate::lower::Lx& lx_p0, const Text& qk_p1, const Array<crate::syntax::Pattern_>& params_p2, const crate::syntax::Block& body_p3, const crate::check::types::Scheme& sc_p4, const bool& is_root_p5);

prism_rtl::JobRef<crate::lower::model::NodeDef> start_node_def_of_f(crate::lower::Lx lx_p0, Text qk_p1, Array<crate::syntax::Pattern_> params_p2, crate::syntax::Block body_p3, crate::check::types::Scheme sc_p4, bool is_root_p5);

crate::lower::node_::Wx root_result_f(const crate::lower::node_::Wx& wx_p0);

crate::lower::node_::Wx block_into_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const crate::syntax::Block& b_p3);

prism_rtl::JobRef<crate::lower::node_::Wx> start_block_into_f(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::Block b_p3);

std::tuple<crate::lower::node_::Wx, crate::lower::types::Env> pre_init_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const crate::syntax::Stmt& s_p3);

prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env>> start_pre_init_f(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::Stmt s_p3);

crate::lower::node_::Wx build_in_order_f(const crate::lower::node_::Wx& wx_p0, const Array<crate::syntax::Stmt>& stmts_p1, const Array<Array<Nat>>& order_p2, const Nat& start_p3, const Array<Nat>& ends_p4);

prism_rtl::JobRef<crate::lower::node_::Wx> start_build_in_order_f(crate::lower::node_::Wx wx_p0, Array<crate::syntax::Stmt> stmts_p1, Array<Array<Nat>> order_p2, Nat start_p3, Array<Nat> ends_p4);

Array<Array<Nat>> build_order_f(const Array<crate::syntax::Stmt>& stmts_p0);

prism_rtl::JobRef<Array<Array<Nat>>> start_build_order_f(Array<crate::syntax::Stmt> stmts_p0);

Array<Text> reads_at_build_f(const crate::syntax::Stmt& s_p0);

prism_rtl::JobRef<Array<Text>> start_reads_at_build_f(crate::syntax::Stmt s_p0);

std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env> pre_bind_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const crate::syntax::Stmt& s_p3);

prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> start_pre_bind_f(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::Stmt s_p3);

bool gives_result_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& menv_p1, const crate::syntax::Expr& e_p2);

prism_rtl::JobRef<bool> start_gives_result_f(crate::lower::Lx lx_p0, crate::lower::types::Env menv_p1, crate::syntax::Expr e_p2);

bool is_prelude_name_f(const Text& q_p0);

bool is_getter_builtin_f(const Text& q_p0);

bool is_widget_ty_f(const crate::check::types::Ty& t_p0);

HowBound how_bound_f(const std::optional<crate::syntax::Expr>& opt0);

std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env> pre_bind_name_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const crate::syntax::SName& n_p3, const HowBound& how_p4);

prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> start_pre_bind_name_f(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::SName n_p3, HowBound how_p4);

crate::lower::types::Env with_use_f(const crate::lower::types::Env& env_p0, const Text& ukey_p1, const Text& bkey_p2);

std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> many_instances_o(const crate::lower::Lx& lx_p0, const crate::syntax::Range& span_p1);

prism_rtl::JobRef<std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>> start_many_instances_o(crate::lower::Lx lx_p0, crate::syntax::Range span_p1);

bool is_switched_f(const crate::check::types::Ty& t_p0);

std::optional<crate::lower::types::Bn> binding_of_o(const crate::lower::types::Env& env_p0, const crate::syntax::Pattern_& p_p1);

std::optional<crate::lower::types::Bn> binding_of_name_o(const crate::lower::types::Env& env_p0, const crate::syntax::Pattern_& p_p1);

std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env> widget_stmt_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const crate::syntax::Stmt& s_p3, const bool& last_p4);

prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> start_widget_stmt_f(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::Stmt s_p3, bool last_p4);

std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env> bind_hosted_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const crate::lower::node_::Wres& res_p3, const crate::lower::types::Bn& doc_p4, const Array<crate::syntax::Pattern_>& ps_p5);

std::tuple<crate::lower::types::Env, crate::lower::types::Env> bind_part_f(const crate::lower::types::Env& benv_p0, const crate::lower::types::Env& menv_p1, const std::optional<crate::syntax::Pattern_>& p_o2, const std::optional<crate::lower::types::Bn>& b_o3);

std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env> bind_part2_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const std::optional<crate::syntax::Pattern_>& p_o3, const std::optional<crate::lower::types::Bn>& b_o4);

std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env> bind_parts_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const Array<crate::lower::node_::Wres>& parts_p3, const Array<crate::syntax::Pattern_>& ps_p4);

prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> start_bind_parts_f(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, Array<crate::lower::node_::Wres> parts_p3, Array<crate::syntax::Pattern_> ps_p4);

std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env> result_getter_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const crate::syntax::SName& n_p2, const crate::lower::model::Ex& ex_p3, const Array<crate::lower::node_::Read>& rds_p4, const crate::lower::model::OutTy& t_p5, const crate::lower::types::Env& benv2_p6, const crate::lower::types::Env& menv2_p7);

crate::lower::node_::Wx bind_plain_result_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const crate::syntax::Pattern_& p_p2, const crate::lower::model::Ex& ex_p3, const crate::lower::model::OutTy& t_p4);

prism_rtl::JobRef<crate::lower::node_::Wx> start_bind_plain_result_f(crate::lower::node_::Wx wx_p0, crate::lower::types::Env menv_p1, crate::syntax::Pattern_ p_p2, crate::lower::model::Ex ex_p3, crate::lower::model::OutTy t_p4);

crate::lower::node_::Wx refuse_plain_result_f(const crate::lower::node_::Wx& wx_p0, const crate::syntax::Pattern_& p_p1);

crate::lower::types::Bn bundle_bn_f(const crate::lower::node_::Wres& res_p0);

crate::lower::node_::Wres bn_res_f(const crate::lower::types::Bn& b_p0);

crate::lower::node_::Wres part_res_f(const std::optional<crate::lower::types::Bn>& b_o0);

crate::lower::node_::Wx set_result_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::node_::Wres& res_p1);

std::tuple<crate::lower::node_::Wres, crate::lower::node_::Wx> result_of_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const crate::syntax::Expr& x_p3);

prism_rtl::JobRef<std::tuple<crate::lower::node_::Wres, crate::lower::node_::Wx>> start_result_of_f(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::Expr x_p3);

std::tuple<crate::lower::node_::Wres, crate::lower::node_::Wx> result_of_typed_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const crate::syntax::Expr& x_p3, const crate::check::types::Ty& full_p4, const crate::lower::model::OutTy& t_p5);

prism_rtl::JobRef<std::tuple<crate::lower::node_::Wres, crate::lower::node_::Wx>> start_result_of_typed_f(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::Expr x_p3, crate::check::types::Ty full_p4, crate::lower::model::OutTy t_p5);

std::tuple<crate::lower::node_::Wx, crate::lower::types::Env> hold_line_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const crate::syntax::Pattern_& p_p3, const crate::syntax::Expr& init_p4, const crate::syntax::Expr& step_p5);

prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env>> start_hold_line_f(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::Pattern_ p_p3, crate::syntax::Expr init_p4, crate::syntax::Expr step_p5);

crate::lower::types::Env init_env_f(const crate::lower::types::Env& env_p0);

bool all_inited_f(const crate::lower::node_::Wx& wx_p0, const Array<crate::lower::node_::Read>& reads_p1);

bool names_inited_f(const crate::lower::types::Env& env_p0, const crate::syntax::Expr& e_p1);

prism_rtl::JobRef<bool> start_names_inited_f(crate::lower::types::Env env_p0, crate::syntax::Expr e_p1);

Text pat_text_f(const crate::syntax::Pattern_& p_p0);

std::tuple<crate::lower::node_::Wx, crate::lower::types::Env> let_line_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const crate::syntax::Pattern_& p_p3, const crate::syntax::Expr& e_p4);

prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env>> start_let_line_f(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::Pattern_ p_p3, crate::syntax::Expr e_p4);

crate::lower::node_::Wx widget_let_field_f(const crate::lower::node_::Wx& wx_p0, const Text& f_p1, const crate::lower::model::OutTy& t_p2, const crate::lower::model::Ex& v_p3, const Text& doc_p4);

crate::lower::node_::EvRef err_pipe_f(const crate::lower::node_::EvRef& r_p0);

crate::lower::model::Ex own_as_f(const crate::lower::model::OutTy& t_p0, const crate::lower::types::Vl& v_p1);

crate::lower::node_::Wx bind_res_f(const crate::lower::node_::Wx& wx2_p0, const crate::lower::types::Env& menv_p1, const crate::syntax::Pattern_& p_p2, const crate::lower::node_::Wres& res_p3);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> build_line_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const crate::syntax::Expr& e_p3, const std::optional<crate::lower::types::Bn>& bound_o4);

prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> start_build_line_f(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::Expr e_p3, std::optional<crate::lower::types::Bn> bound_o4);

}  // namespace lower::node_::def


namespace lower::node_::def {

/// The step machine of `NodeDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NodeDefOf: unbounded fn Lx, Text, [Pattern], Block, Scheme, Bool -> NodeDef
struct NodeDefOf : prism_rtl::Job<crate::lower::model::NodeDef> {
    crate::lower::Lx lx_p0;
    Text qk_p1;
    Array<crate::syntax::Pattern_> params_p2;
    crate::syntax::Block body_p3;
    crate::check::types::Scheme sc_p4;
    bool is_root_p5;
    NodeDefOf(crate::lower::Lx lx_p0, Text qk_p1, Array<crate::syntax::Pattern_> params_p2, crate::syntax::Block body_p3, crate::check::types::Scheme sc_p4, bool is_root_p5) : lx_p0(std::move(lx_p0)), qk_p1(std::move(qk_p1)), params_p2(std::move(params_p2)), body_p3(std::move(body_p3)), sc_p4(std::move(sc_p4)), is_root_p5(std::move(is_root_p5)) {}
    prism_rtl::Turn<crate::lower::model::NodeDef> cycle() const override;
};


/// The step machine of `BlockInto`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BlockInto: unbounded fn Wx, Env, Env, Block -> Wx
struct BlockInto : prism_rtl::Job<crate::lower::node_::Wx> {
    crate::lower::node_::Wx wx_p0;
    crate::lower::types::Env benv_p1;
    crate::lower::types::Env menv_p2;
    crate::syntax::Block b_p3;
    BlockInto(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::Block b_p3) : wx_p0(std::move(wx_p0)), benv_p1(std::move(benv_p1)), menv_p2(std::move(menv_p2)), b_p3(std::move(b_p3)) {}
    prism_rtl::Turn<crate::lower::node_::Wx> cycle() const override;
};


/// The step machine of `PreInit`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PreInit: unbounded fn Wx, Env, Env, Stmt -> ((Wx, Env))
struct PreInit : prism_rtl::Job<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env>> {
    crate::lower::node_::Wx wx_p0;
    crate::lower::types::Env benv_p1;
    crate::lower::types::Env menv_p2;
    crate::syntax::Stmt s_p3;
    PreInit(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::Stmt s_p3) : wx_p0(std::move(wx_p0)), benv_p1(std::move(benv_p1)), menv_p2(std::move(menv_p2)), s_p3(std::move(s_p3)) {}
    prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env>> cycle() const override;
};


/// The step machine of `BuildInOrder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BuildInOrder: unbounded fn Wx, [Stmt], [ [Nat] ], Nat, [Nat] -> Wx
struct BuildInOrder : prism_rtl::Job<crate::lower::node_::Wx> {
    crate::lower::node_::Wx wx_p0;
    Array<crate::syntax::Stmt> stmts_p1;
    Array<Array<Nat>> order_p2;
    Nat start_p3;
    Array<Nat> ends_p4;
    BuildInOrder(crate::lower::node_::Wx wx_p0, Array<crate::syntax::Stmt> stmts_p1, Array<Array<Nat>> order_p2, Nat start_p3, Array<Nat> ends_p4) : wx_p0(std::move(wx_p0)), stmts_p1(std::move(stmts_p1)), order_p2(std::move(order_p2)), start_p3(std::move(start_p3)), ends_p4(std::move(ends_p4)) {}
    prism_rtl::Turn<crate::lower::node_::Wx> cycle() const override;
};


/// The step machine of `BuildOrder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BuildOrder: unbounded fn [Stmt] -> [ [Nat] ]
struct BuildOrder : prism_rtl::Job<Array<Array<Nat>>> {
    Array<crate::syntax::Stmt> stmts_p0;
    BuildOrder(Array<crate::syntax::Stmt> stmts_p0) : stmts_p0(std::move(stmts_p0)) {}
    prism_rtl::Turn<Array<Array<Nat>>> cycle() const override;
};


/// The step machine of `ReadsAtBuild`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ReadsAtBuild: unbounded fn Stmt -> [Text]
struct ReadsAtBuild : prism_rtl::Job<Array<Text>> {
    crate::syntax::Stmt s_p0;
    ReadsAtBuild(crate::syntax::Stmt s_p0) : s_p0(std::move(s_p0)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `PreBind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PreBind: unbounded fn Wx, Env, Env, Stmt -> ((Wx, Env, Env))
struct PreBind : prism_rtl::Job<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> {
    crate::lower::node_::Wx wx_p0;
    crate::lower::types::Env benv_p1;
    crate::lower::types::Env menv_p2;
    crate::syntax::Stmt s_p3;
    PreBind(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::Stmt s_p3) : wx_p0(std::move(wx_p0)), benv_p1(std::move(benv_p1)), menv_p2(std::move(menv_p2)), s_p3(std::move(s_p3)) {}
    prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> cycle() const override;
};


/// The step machine of `GivesResult`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GivesResult: unbounded fn Lx, Env, Expr -> Bool
struct GivesResult : prism_rtl::Job<bool> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env menv_p1;
    crate::syntax::Expr e_p2;
    GivesResult(crate::lower::Lx lx_p0, crate::lower::types::Env menv_p1, crate::syntax::Expr e_p2) : lx_p0(std::move(lx_p0)), menv_p1(std::move(menv_p1)), e_p2(std::move(e_p2)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `PreBindName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PreBindName: unbounded fn Wx, Env, Env, SName, HowBound -> ((Wx, Env, Env))
struct PreBindName : prism_rtl::Job<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> {
    crate::lower::node_::Wx wx_p0;
    crate::lower::types::Env benv_p1;
    crate::lower::types::Env menv_p2;
    crate::syntax::SName n_p3;
    HowBound how_p4;
    PreBindName(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::SName n_p3, HowBound how_p4) : wx_p0(std::move(wx_p0)), benv_p1(std::move(benv_p1)), menv_p2(std::move(menv_p2)), n_p3(std::move(n_p3)), how_p4(std::move(how_p4)) {}
    prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> cycle() const override;
};


/// The step machine of `ManyInstances`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?ManyInstances: unbounded fn Lx, Range -> ?[(([((Text, Ty))], [((Text, Col))]))]
struct ManyInstances : prism_rtl::Job<std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>> {
    crate::lower::Lx lx_p0;
    crate::syntax::Range span_p1;
    ManyInstances(crate::lower::Lx lx_p0, crate::syntax::Range span_p1) : lx_p0(std::move(lx_p0)), span_p1(std::move(span_p1)) {}
    prism_rtl::Turn<std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>> cycle() const override;
};


/// The step machine of `WidgetStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WidgetStmt: unbounded fn Wx, Env, Env, Stmt, Bool -> ((Wx, Env, Env))
struct WidgetStmt : prism_rtl::Job<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> {
    crate::lower::node_::Wx wx_p0;
    crate::lower::types::Env benv_p1;
    crate::lower::types::Env menv_p2;
    crate::syntax::Stmt s_p3;
    bool last_p4;
    WidgetStmt(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::Stmt s_p3, bool last_p4) : wx_p0(std::move(wx_p0)), benv_p1(std::move(benv_p1)), menv_p2(std::move(menv_p2)), s_p3(std::move(s_p3)), last_p4(std::move(last_p4)) {}
    prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> cycle() const override;
};


/// The step machine of `BindParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindParts: unbounded fn Wx, Env, Env, [Wres], [Pattern] -> ((Wx, Env, Env))
struct BindParts : prism_rtl::Job<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> {
    crate::lower::node_::Wx wx_p0;
    crate::lower::types::Env benv_p1;
    crate::lower::types::Env menv_p2;
    Array<crate::lower::node_::Wres> parts_p3;
    Array<crate::syntax::Pattern_> ps_p4;
    BindParts(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, Array<crate::lower::node_::Wres> parts_p3, Array<crate::syntax::Pattern_> ps_p4) : wx_p0(std::move(wx_p0)), benv_p1(std::move(benv_p1)), menv_p2(std::move(menv_p2)), parts_p3(std::move(parts_p3)), ps_p4(std::move(ps_p4)) {}
    prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> cycle() const override;
};


/// The step machine of `BindPlainResult`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindPlainResult: unbounded fn Wx, Env, Pattern, Ex, OutTy -> Wx
struct BindPlainResult : prism_rtl::Job<crate::lower::node_::Wx> {
    crate::lower::node_::Wx wx_p0;
    crate::lower::types::Env menv_p1;
    crate::syntax::Pattern_ p_p2;
    crate::lower::model::Ex ex_p3;
    crate::lower::model::OutTy t_p4;
    BindPlainResult(crate::lower::node_::Wx wx_p0, crate::lower::types::Env menv_p1, crate::syntax::Pattern_ p_p2, crate::lower::model::Ex ex_p3, crate::lower::model::OutTy t_p4) : wx_p0(std::move(wx_p0)), menv_p1(std::move(menv_p1)), p_p2(std::move(p_p2)), ex_p3(std::move(ex_p3)), t_p4(std::move(t_p4)) {}
    prism_rtl::Turn<crate::lower::node_::Wx> cycle() const override;
};


/// The step machine of `ResultOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ResultOf: unbounded fn Wx, Env, Env, Expr -> ((Wres, Wx))
struct ResultOf : prism_rtl::Job<std::tuple<crate::lower::node_::Wres, crate::lower::node_::Wx>> {
    crate::lower::node_::Wx wx_p0;
    crate::lower::types::Env benv_p1;
    crate::lower::types::Env menv_p2;
    crate::syntax::Expr x_p3;
    ResultOf(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::Expr x_p3) : wx_p0(std::move(wx_p0)), benv_p1(std::move(benv_p1)), menv_p2(std::move(menv_p2)), x_p3(std::move(x_p3)) {}
    prism_rtl::Turn<std::tuple<crate::lower::node_::Wres, crate::lower::node_::Wx>> cycle() const override;
};


/// The step machine of `ResultOfTyped`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ResultOfTyped: unbounded fn Wx, Env, Env, Expr, Ty, OutTy -> ((Wres, Wx))
struct ResultOfTyped : prism_rtl::Job<std::tuple<crate::lower::node_::Wres, crate::lower::node_::Wx>> {
    crate::lower::node_::Wx wx_p0;
    crate::lower::types::Env benv_p1;
    crate::lower::types::Env menv_p2;
    crate::syntax::Expr x_p3;
    crate::check::types::Ty full_p4;
    crate::lower::model::OutTy t_p5;
    ResultOfTyped(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::Expr x_p3, crate::check::types::Ty full_p4, crate::lower::model::OutTy t_p5) : wx_p0(std::move(wx_p0)), benv_p1(std::move(benv_p1)), menv_p2(std::move(menv_p2)), x_p3(std::move(x_p3)), full_p4(std::move(full_p4)), t_p5(std::move(t_p5)) {}
    prism_rtl::Turn<std::tuple<crate::lower::node_::Wres, crate::lower::node_::Wx>> cycle() const override;
};


/// The step machine of `HoldLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// HoldLine: unbounded fn Wx, Env, Env, Pattern, Expr, Expr -> ((Wx, Env))
struct HoldLine : prism_rtl::Job<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env>> {
    crate::lower::node_::Wx wx_p0;
    crate::lower::types::Env benv_p1;
    crate::lower::types::Env menv_p2;
    crate::syntax::Pattern_ p_p3;
    crate::syntax::Expr init_p4;
    crate::syntax::Expr step_p5;
    HoldLine(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::Pattern_ p_p3, crate::syntax::Expr init_p4, crate::syntax::Expr step_p5) : wx_p0(std::move(wx_p0)), benv_p1(std::move(benv_p1)), menv_p2(std::move(menv_p2)), p_p3(std::move(p_p3)), init_p4(std::move(init_p4)), step_p5(std::move(step_p5)) {}
    prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env>> cycle() const override;
};


/// The step machine of `NamesInited`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NamesInited: unbounded fn Env, Expr -> Bool
struct NamesInited : prism_rtl::Job<bool> {
    crate::lower::types::Env env_p0;
    crate::syntax::Expr e_p1;
    NamesInited(crate::lower::types::Env env_p0, crate::syntax::Expr e_p1) : env_p0(std::move(env_p0)), e_p1(std::move(e_p1)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `LetLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LetLine: unbounded fn Wx, Env, Env, Pattern, Expr -> ((Wx, Env))
struct LetLine : prism_rtl::Job<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env>> {
    crate::lower::node_::Wx wx_p0;
    crate::lower::types::Env benv_p1;
    crate::lower::types::Env menv_p2;
    crate::syntax::Pattern_ p_p3;
    crate::syntax::Expr e_p4;
    LetLine(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::Pattern_ p_p3, crate::syntax::Expr e_p4) : wx_p0(std::move(wx_p0)), benv_p1(std::move(benv_p1)), menv_p2(std::move(menv_p2)), p_p3(std::move(p_p3)), e_p4(std::move(e_p4)) {}
    prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env>> cycle() const override;
};


/// The step machine of `BuildLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BuildLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
struct BuildLine : prism_rtl::Job<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> {
    crate::lower::node_::Wx wx_p0;
    crate::lower::types::Env benv_p1;
    crate::lower::types::Env menv_p2;
    crate::syntax::Expr e_p3;
    std::optional<crate::lower::types::Bn> bound_o4;
    BuildLine(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::Expr e_p3, std::optional<crate::lower::types::Bn> bound_o4) : wx_p0(std::move(wx_p0)), benv_p1(std::move(benv_p1)), menv_p2(std::move(menv_p2)), e_p3(std::move(e_p3)), bound_o4(std::move(bound_o4)) {}
    prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> cycle() const override;
};


}  // namespace lower::node_::def

}  // namespace crate
