// The module `Lower.Node.Static`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace lower::node_::static_ {

class HostForm;

struct WidgetLine;

struct InlineBlock;

}  // namespace lower::node_::static_

}  // namespace crate
