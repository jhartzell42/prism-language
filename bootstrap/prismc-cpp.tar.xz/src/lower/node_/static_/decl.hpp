// The module `Lower.Node.Static`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace lower::node_::static_ {

class HostForm;

struct WidgetLine;

struct InlineBlock;

}  // namespace lower::node_::static_

namespace lower::node_::static_ {

/// `HostForm`:
///
/// ```prism
/// type HostForm = choice:
/// ```
class HostForm {
public:
    using prism_value = void;
    struct HostEach;
    struct HostSome;
    using Cases = std::variant<HostEach, HostSome>;
    template <class C>
        requires prism_rtl::one_of<C, HostEach, HostSome>
    HostForm(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<HostForm> from_pod(const Pod& whole);
    friend inline bool operator==(const HostForm& a, const HostForm& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


}  // namespace lower::node_::static_

}  // namespace crate
