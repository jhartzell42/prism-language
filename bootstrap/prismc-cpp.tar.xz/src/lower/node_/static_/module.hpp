// The module `Lower.Node.Static`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <lower/node_/static_/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace lower::node_::static_ {

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> widget_line(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const crate::syntax::Expr& e_p3, const std::optional<crate::lower::types::Bn>& bound_o4);

prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> start_widget_line(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::Expr e_p3, std::optional<crate::lower::types::Bn> bound_o4);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> apply_widget_param(const crate::lower::node_::Wx& wx_p0, const crate::syntax::Expr& x_p1, const crate::lower::types::Env& cbenv_p2, const crate::lower::types::Env& cmenv_p3, const crate::lower::Lx& clx_p4, const Nat& nargs_p5);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> inline_block(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const crate::syntax::Block& b_p3, const crate::lower::Lx& lx_p4);

prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> start_inline_block(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::Block b_p3, crate::lower::Lx lx_p4);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> widget_call(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const crate::syntax::Expr& e_p3, const std::optional<crate::lower::types::Bn>& bound_o4, const Text& qk_p5, const Array<crate::syntax::Arg>& args_p6, const std::optional<Nat>& target_o7);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> host_line(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const HostForm& form_p3, const Array<crate::syntax::Arg>& args_p4, const std::optional<crate::lower::types::Bn>& bound_o5);

bool is_widget_name(const crate::syntax::Expr& e_p0);

std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, Array<crate::lower::model::Do>> dynamic_answers(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const Text& hf_p3, const crate::syntax::Expr& sup_p4);

std::optional<crate::syntax::Expr> dynamic_answer(const crate::lower::Lx& lx_p0, const crate::syntax::Expr& x_p1);

Text dyn_key(const crate::syntax::Expr& x_p0);

crate::lower::model::MethDef host_doc_getter(const Text& name_p0, const crate::lower::model::Pos_& pos_p1, const Array<crate::lower::node_::Place>& places_p2, const Array<crate::lower::model::ForDef>& builders_p3, const Array<crate::lower::model::GenDef>& gens_p4);

crate::lower::model::MethDef snap_getter(const Text& name_p0, const crate::lower::model::OutTy& t_p1, const Text& doc_p2);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> started_line(const crate::lower::node_::Wx& wx_p0, const std::optional<crate::lower::types::Bn>& bound_o1);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> defer_line(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const Array<crate::syntax::Arg>& args_p2, const crate::syntax::Expr& e_p3, const std::optional<Nat>& target_o4);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> distinct_line(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const Array<crate::syntax::Arg>& args_p2, const crate::syntax::Expr& e_p3, const std::optional<crate::lower::types::Bn>& bound_o4);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> per_key_line(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const Array<crate::syntax::Arg>& args_p2, const std::optional<crate::lower::types::Bn>& bound_o3);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> run_line(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const Array<crate::syntax::Arg>& args_p2, const crate::syntax::Expr& e_p3, const std::optional<Nat>& target_o4);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> machine_line(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const Array<crate::syntax::Arg>& args_p3, const crate::syntax::Expr& e_p4, const std::optional<Nat>& target_o5);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> inline_widget(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const Text& qk_p3, const crate::check::env::ValInfo& v_p4, const Array<crate::syntax::Arg>& args_p5, const crate::syntax::Expr& e_p6);

Nat recursion(const Array<Text>& inlining_p0, const Text& qk_p1);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> too_deep(const crate::lower::node_::Wx& wx_p0, const Text& qk_p1, const crate::syntax::Expr& e_p2);

std::optional<crate::syntax::decls::WidgetDecl> widget_decl_of(const crate::check::env::G& g_p0, const Text& qk_p1);

std::optional<crate::syntax::decls::WidgetDecl> def_widget(const crate::check::env::Def& d_p0, const std::optional<crate::syntax::decls::WidgetDecl>& other_o1);

std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env> bind_param(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& cbenv_p1, const crate::lower::types::Env& cmenv_p2, const crate::lower::types::Env& be_p3, const crate::lower::types::Env& me_p4, const Text& nkey_p5, const crate::check::types::Ty& pty_p6, const crate::syntax::Expr& arg_p7);

}  // namespace lower::node_::static_


namespace lower::node_::static_ {

/// The step machine of `WidgetLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WidgetLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
struct WidgetLine : prism_rtl::Job<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> {
    crate::lower::node_::Wx wx_p0;
    crate::lower::types::Env benv_p1;
    crate::lower::types::Env menv_p2;
    crate::syntax::Expr e_p3;
    std::optional<crate::lower::types::Bn> bound_o4;
    WidgetLine(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::Expr e_p3, std::optional<crate::lower::types::Bn> bound_o4) : wx_p0(std::move(wx_p0)), benv_p1(std::move(benv_p1)), menv_p2(std::move(menv_p2)), e_p3(std::move(e_p3)), bound_o4(std::move(bound_o4)) {}
    prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> cycle() const override;
};


/// The step machine of `InlineBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InlineBlock: unbounded fn Wx, Env, Env, Block, Lx -> ((Wx, Wres))
struct InlineBlock : prism_rtl::Job<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> {
    crate::lower::node_::Wx wx_p0;
    crate::lower::types::Env benv_p1;
    crate::lower::types::Env menv_p2;
    crate::syntax::Block b_p3;
    crate::lower::Lx lx_p4;
    InlineBlock(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::Block b_p3, crate::lower::Lx lx_p4) : wx_p0(std::move(wx_p0)), benv_p1(std::move(benv_p1)), menv_p2(std::move(menv_p2)), b_p3(std::move(b_p3)), lx_p4(std::move(lx_p4)) {}
    prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> cycle() const override;
};


}  // namespace lower::node_::static_

}  // namespace crate
