// The module `Lower.Node.Static`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <lower/node_/static_/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace lower::node_::static_ {

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> widget_line(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const crate::syntax::Expr& e, const std::optional<crate::lower::types::Bn>& bound_opt);

prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> start_widget_line(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, crate::syntax::Expr e, std::optional<crate::lower::types::Bn> bound_opt);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> apply_widget_param(const crate::lower::node_::Wx& wx, const crate::syntax::Expr& x, const crate::lower::types::Env& cbenv, const crate::lower::types::Env& cmenv, const crate::lower::Lx& clx, const Nat& nargs);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> inline_block(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const crate::syntax::Block& b, const crate::lower::Lx& lx);

prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> start_inline_block(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, crate::syntax::Block b, crate::lower::Lx lx);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> widget_call(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const crate::syntax::Expr& e, const std::optional<crate::lower::types::Bn>& bound_opt, const Text& qk, const Array<crate::syntax::Arg>& args, const std::optional<Nat>& target_opt);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> host_line(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const HostForm& form, const Array<crate::syntax::Arg>& args, const std::optional<crate::lower::types::Bn>& bound_opt);

bool is_widget_name(const crate::syntax::Expr& e);

std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, Array<crate::lower::model::Do>> dynamic_answers(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const Text& hf, const crate::syntax::Expr& sup);

std::optional<crate::syntax::Expr> dynamic_answer(const crate::lower::Lx& lx, const crate::syntax::Expr& x);

Text dyn_key(const crate::syntax::Expr& x);

crate::lower::model::MethDef host_doc_getter(const Text& name, const crate::lower::model::Pos_& pos, const Array<crate::lower::node_::Place>& places, const Array<crate::lower::model::ForDef>& builders, const Array<crate::lower::model::GenDef>& gens);

crate::lower::model::MethDef snap_getter(const Text& name, const crate::lower::model::OutTy& t, const Text& doc);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> started_line(const crate::lower::node_::Wx& wx, const std::optional<crate::lower::types::Bn>& bound_opt);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> defer_line(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& menv, const Array<crate::syntax::Arg>& args, const crate::syntax::Expr& e, const std::optional<Nat>& target_opt);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> run_line(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const Array<crate::syntax::Arg>& args, const crate::syntax::Expr& e, const std::optional<Nat>& target_opt);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> machine_line(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const Array<crate::syntax::Arg>& args, const crate::syntax::Expr& e, const std::optional<Nat>& target_opt);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> inline_widget(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const Text& qk, const crate::check::env::ValInfo& v_, const Array<crate::syntax::Arg>& args, const crate::syntax::Expr& e);

std::optional<crate::syntax::decls::WidgetDecl> widget_decl_of(const crate::check::env::G& g, const Text& qk);

std::optional<crate::syntax::decls::WidgetDecl> def_widget(const crate::check::env::Def& d, const std::optional<crate::syntax::decls::WidgetDecl>& other_opt);

std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env> bind_param(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& cbenv, const crate::lower::types::Env& cmenv, const crate::lower::types::Env& be, const crate::lower::types::Env& me, const Text& nkey, const crate::check::types::Ty& pty, const crate::syntax::Expr& arg);

}  // namespace lower::node_::static_


namespace lower::node_::static_ {

/// The step machine of `WidgetLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WidgetLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
struct WidgetLine : prism_rtl::Job<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> {
    crate::lower::node_::Wx wx;
    crate::lower::types::Env benv;
    crate::lower::types::Env menv;
    crate::syntax::Expr e;
    std::optional<crate::lower::types::Bn> bound_opt;
    WidgetLine(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, crate::syntax::Expr e, std::optional<crate::lower::types::Bn> bound_opt) : wx(std::move(wx)), benv(std::move(benv)), menv(std::move(menv)), e(std::move(e)), bound_opt(std::move(bound_opt)) {}
    prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> cycle() const override;
};


/// The step machine of `InlineBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InlineBlock: unbounded fn Wx, Env, Env, Block, Lx -> ((Wx, Wres))
struct InlineBlock : prism_rtl::Job<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> {
    crate::lower::node_::Wx wx;
    crate::lower::types::Env benv;
    crate::lower::types::Env menv;
    crate::syntax::Block b;
    crate::lower::Lx lx;
    InlineBlock(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, crate::syntax::Block b, crate::lower::Lx lx) : wx(std::move(wx)), benv(std::move(benv)), menv(std::move(menv)), b(std::move(b)), lx(std::move(lx)) {}
    prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> cycle() const override;
};


}  // namespace lower::node_::static_

}  // namespace crate
