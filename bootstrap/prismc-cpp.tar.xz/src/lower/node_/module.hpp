// The module `Lower.Node`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <lower/node_/types.hpp>
#include "elem.types.hpp"
#include <lower/model/types.hpp>
#include <lower/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/env/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/passes/types.hpp>
#include <check/shrink/types.hpp>
#include <check/typed/types.hpp>
#include <check/types/types.hpp>
#include <syntax/types.hpp>
#include <syntax/lexer/types.hpp>

namespace crate {

using namespace prelude;

namespace lower::node_ {

Array<crate::lower::model::Do> id_pipe(const crate::lower::model::Ex& x, const prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>& k_fn);

prism_rtl::JobRef<Array<crate::lower::model::Do>> start_id_pipe(crate::lower::model::Ex x, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)> k_fn);

EvRef ev_ref_of(const Wx& wx, const Nat& n);

Text kind_word(const GnKind& k);

bool has_read(const Array<Read>& rs, const Read& r);

Array<Read> add_read(const Array<Read>& rs, const Read& r);

Array<Read> union_reads(const Array<Read>& xs, const Array<Read>& ys);

Array<Text> node_hooks();

Wx new_wx(const crate::lower::Lx& lx, const Text& name, const Array<std::tuple<Text, crate::lower::model::OutTy, Text>>& fields, const Array<std::tuple<Text, crate::lower::model::Ex>>& inits, const Array<std::tuple<Text, crate::lower::model::Ex>>& moves_, const Array<crate::lower::model::MethDef>& getters, const Map<Text, Array<Read>>& dyn_reads, const Array<Text>& taken, const Nat& depth, const std::optional<Text>& hosted_by_opt);

std::tuple<Text, Wx> fresh_name(const Wx& wx, const Text& base);

Nat first_free(const Array<Text>& taken, const Text& base, const Nat& from);

std::tuple<Nat, Wx> add_gn(const Wx& wx, const Text& name, const crate::lower::model::OutTy& ty, const GnKind& kind, const Nat& height);

Wx connect(const Wx& wx, const EvRef& r, const Sk& sink);

Wx crossed(const Wx& wx, const Text& what);

Gn add_out(const Gn& n, const Out& o);

Wx add_field(const Wx& wx, const Text& name, const crate::lower::model::OutTy& t, const Text& doc, const crate::lower::model::Ex& init);

Wx add_field_last(const Wx& wx, const Text& name, const crate::lower::model::OutTy& t, const Text& doc, const crate::lower::model::Ex& init);

Gn gn_of(const Wx& wx, const Nat& n);

std::tuple<crate::lower::Env, crate::lower::Env> bind_plain(const crate::lower::Env& benv, const crate::lower::Env& menv, const Text& nkey, const Text& rs, const crate::lower::model::OutTy& t);

crate::lower::model::NodeDef node_def_of(const crate::lower::Lx& lx, const Text& qk, const Array<crate::syntax::Pattern_>& params, const crate::syntax::Block& body, const crate::check::types::Scheme& sc, const bool& is_root);

prism_rtl::JobRef<crate::lower::model::NodeDef> start_node_def_of(crate::lower::Lx lx, Text qk, Array<crate::syntax::Pattern_> params, crate::syntax::Block body, crate::check::types::Scheme sc, bool is_root);

Wx root_result(const Wx& wx);

Wx block_into(const Wx& wx, const crate::lower::Env& benv, const crate::lower::Env& menv, const crate::syntax::Block& b);

prism_rtl::JobRef<Wx> start_block_into(Wx wx, crate::lower::Env benv, crate::lower::Env menv, crate::syntax::Block b);

std::tuple<Wx, crate::lower::Env, crate::lower::Env> pre_bind(const Wx& wx, const crate::lower::Env& benv, const crate::lower::Env& menv, const crate::syntax::Stmt& s);

prism_rtl::JobRef<std::tuple<Wx, crate::lower::Env, crate::lower::Env>> start_pre_bind(Wx wx, crate::lower::Env benv, crate::lower::Env menv, crate::syntax::Stmt s);

HowBound how_bound(const std::optional<crate::syntax::Expr>& opt0);

std::tuple<Wx, crate::lower::Env, crate::lower::Env> pre_bind_name(const Wx& wx, const crate::lower::Env& benv, const crate::lower::Env& menv, const crate::syntax::SName& n, const HowBound& how);

prism_rtl::JobRef<std::tuple<Wx, crate::lower::Env, crate::lower::Env>> start_pre_bind_name(Wx wx, crate::lower::Env benv, crate::lower::Env menv, crate::syntax::SName n, HowBound how);

crate::lower::Env with_use(const crate::lower::Env& env, const Text& ukey, const Text& bkey);

std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> many_instances(const crate::lower::Lx& lx, const crate::syntax::Range& span);

prism_rtl::JobRef<std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>> start_many_instances(crate::lower::Lx lx, crate::syntax::Range span);

bool is_switched(const crate::check::types::Ty& t);

std::optional<crate::lower::Bn> binding_of(const crate::lower::Env& env, const crate::syntax::Pattern_& p_);

std::optional<crate::lower::Bn> binding_of_name(const crate::lower::Env& env, const crate::syntax::Pattern_& p_);

std::tuple<Wx, crate::lower::Env, crate::lower::Env> widget_stmt(const Wx& wx, const crate::lower::Env& benv, const crate::lower::Env& menv, const crate::syntax::Stmt& s, const bool& last);

prism_rtl::JobRef<std::tuple<Wx, crate::lower::Env, crate::lower::Env>> start_widget_stmt(Wx wx, crate::lower::Env benv, crate::lower::Env menv, crate::syntax::Stmt s, bool last);

std::tuple<Wx, crate::lower::Env, crate::lower::Env> bind_hosted(const Wx& wx, const crate::lower::Env& benv, const crate::lower::Env& menv, const Wres& res, const crate::lower::Bn& doc, const Array<crate::syntax::Pattern_>& ps);

std::tuple<crate::lower::Env, crate::lower::Env> bind_part(const crate::lower::Env& benv, const crate::lower::Env& menv, const std::optional<crate::syntax::Pattern_>& p__opt, const std::optional<crate::lower::Bn>& b_opt);

std::tuple<Wx, crate::lower::Env, crate::lower::Env> bind_part2(const Wx& wx, const crate::lower::Env& benv, const crate::lower::Env& menv, const std::optional<crate::syntax::Pattern_>& p__opt, const std::optional<crate::lower::Bn>& b_opt);

Wx set_result(const Wx& wx, const Wres& res);

std::tuple<Wres, Wx> result_of(const Wx& wx, const crate::lower::Env& benv, const crate::lower::Env& menv, const crate::syntax::Expr& x);

prism_rtl::JobRef<std::tuple<Wres, Wx>> start_result_of(Wx wx, crate::lower::Env benv, crate::lower::Env menv, crate::syntax::Expr x);

std::tuple<Wres, Wx> result_of_typed(const Wx& wx, const crate::lower::Env& benv, const crate::lower::Env& menv, const crate::syntax::Expr& x, const crate::check::types::Ty& full, const crate::lower::model::OutTy& t);

prism_rtl::JobRef<std::tuple<Wres, Wx>> start_result_of_typed(Wx wx, crate::lower::Env benv, crate::lower::Env menv, crate::syntax::Expr x, crate::check::types::Ty full, crate::lower::model::OutTy t);

std::tuple<Wx, crate::lower::Env> hold_line(const Wx& wx, const crate::lower::Env& benv, const crate::lower::Env& menv, const crate::syntax::Pattern_& p_, const crate::syntax::Expr& init, const crate::syntax::Expr& step_);

prism_rtl::JobRef<std::tuple<Wx, crate::lower::Env>> start_hold_line(Wx wx, crate::lower::Env benv, crate::lower::Env menv, crate::syntax::Pattern_ p_, crate::syntax::Expr init, crate::syntax::Expr step_);

crate::lower::Env init_env(const crate::lower::Env& env);

bool all_inited(const Wx& wx, const Array<Read>& reads);

Text pat_text(const crate::syntax::Pattern_& p_);

std::tuple<Wx, crate::lower::Env> let_line(const Wx& wx, const crate::lower::Env& benv, const crate::lower::Env& menv, const crate::syntax::Pattern_& p_, const crate::syntax::Expr& e);

prism_rtl::JobRef<std::tuple<Wx, crate::lower::Env>> start_let_line(Wx wx, crate::lower::Env benv, crate::lower::Env menv, crate::syntax::Pattern_ p_, crate::syntax::Expr e);

Wx widget_let_field(const Wx& wx, const Text& f, const crate::lower::model::OutTy& t, const crate::lower::model::Ex& v_, const Text& doc);

EvRef err_pipe(const EvRef& r);

crate::lower::model::Ex own_as(const crate::lower::model::OutTy& t, const crate::lower::Vl& v_);

Wx bind_res(const Wx& wx2, const crate::lower::Env& menv, const crate::syntax::Pattern_& p_, const Wres& res);

std::tuple<Wx, Wres> build_line(const Wx& wx, const crate::lower::Env& benv, const crate::lower::Env& menv, const crate::syntax::Expr& e, const std::optional<crate::lower::Bn>& bound_opt);

prism_rtl::JobRef<std::tuple<Wx, Wres>> start_build_line(Wx wx, crate::lower::Env benv, crate::lower::Env menv, crate::syntax::Expr e, std::optional<crate::lower::Bn> bound_opt);

std::tuple<Wx, Wres> element_line(const Wx& wx, const crate::lower::Env& benv, const crate::lower::Env& menv, const crate::syntax::Expr& e, const std::optional<crate::lower::Bn>& bound_opt);

prism_rtl::JobRef<std::tuple<Wx, Wres>> start_element_line(Wx wx, crate::lower::Env benv, crate::lower::Env menv, crate::syntax::Expr e, std::optional<crate::lower::Bn> bound_opt);

crate::lower::model::OutTy element_out(const crate::lower::Lx& lx, const crate::check::env::TagInfo& tg, const crate::check::types::Ty& full);

Text tag_name_of(const crate::lower::Lx& lx, const crate::syntax::Expr& c);

std::optional<crate::syntax::Expr> tag_arg(const Array<crate::syntax::Arg>& args, const Text& fname);

Text request_field(const crate::check::env::TagInfo& tg, const Text& fname);

std::tuple<Wx, Wres> element_output(const Wx& wx, const crate::lower::Env& menv, const crate::check::env::TagInfo& tg, const crate::lower::model::OutTy& out, const crate::lower::model::Pos_& pos, const std::optional<crate::lower::Bn>& bound_opt, const crate::lower::model::Ex& level);

std::tuple<Wx, Wres> bundle_output(const Wx& wx, const crate::check::env::TagInfo& tg, const crate::lower::model::OutTy& out, const crate::lower::model::Pos_& pos, const Array<std::optional<crate::lower::Bn>>& parts, const crate::lower::model::Ex& level);

std::tuple<Wx, Wres> bundle_output_of(const Wx& wx, const crate::check::env::TagInfo& tg, const crate::lower::model::OutTy& out, const crate::lower::model::Pos_& pos, const Array<std::optional<crate::lower::Bn>>& parts, const crate::lower::model::Ex& level);

Wx bundle_first(const Wx& wx, const crate::check::env::TagInfo& tg, const crate::lower::model::Pos_& pos, const Array<Nat>& plain_ix, const Array<crate::lower::model::OutTy>& tys, const Array<std::optional<crate::lower::Bn>>& parts, const crate::lower::model::Ex& level);

Wx bundle_answer(const Wx& wx, const crate::lower::model::Pos_& pos, const crate::lower::model::OutTy& et, const std::optional<crate::lower::Bn>& b_opt);

crate::lower::model::Do first_value_let(const Wx& wx, const crate::lower::model::Pos_& pos, const crate::check::env::TagInfo& tg, const crate::lower::model::Ex& level);

Text host_local(const Wx& wx, const crate::lower::model::Pos_& pos);

Text answer_variant(const crate::check::env::TagInfo& tg);

Text answer_accessor(const crate::check::env::TagInfo& tg);

std::tuple<Wx, Wres> element_output_of(const Wx& wx, const crate::lower::Env& menv, const crate::check::env::TagInfo& tg, const crate::lower::model::OutTy& out, const crate::lower::model::Pos_& pos, const std::optional<crate::lower::Bn>& bound_opt, const crate::lower::model::Ex& level);

std::tuple<Wx, Wres> widget_line(const Wx& wx, const crate::lower::Env& benv, const crate::lower::Env& menv, const crate::syntax::Expr& e, const std::optional<crate::lower::Bn>& bound_opt);

prism_rtl::JobRef<std::tuple<Wx, Wres>> start_widget_line(Wx wx, crate::lower::Env benv, crate::lower::Env menv, crate::syntax::Expr e, std::optional<crate::lower::Bn> bound_opt);

std::tuple<Wx, Wres> apply_widget_param(const Wx& wx, const crate::syntax::Expr& x, const crate::lower::Env& cbenv, const crate::lower::Env& cmenv, const crate::lower::Lx& clx, const Nat& nargs);

std::tuple<Wx, Wres> inline_block(const Wx& wx, const crate::lower::Env& benv, const crate::lower::Env& menv, const crate::syntax::Block& b, const crate::lower::Lx& lx);

prism_rtl::JobRef<std::tuple<Wx, Wres>> start_inline_block(Wx wx, crate::lower::Env benv, crate::lower::Env menv, crate::syntax::Block b, crate::lower::Lx lx);

std::tuple<Wx, Wres> widget_call(const Wx& wx, const crate::lower::Env& benv, const crate::lower::Env& menv, const crate::syntax::Expr& e, const std::optional<crate::lower::Bn>& bound_opt, const Text& qk, const Array<crate::syntax::Arg>& args, const std::optional<Nat>& target_opt);

std::tuple<Wx, Wres> host_line(const Wx& wx, const crate::lower::Env& benv, const crate::lower::Env& menv, const HostForm& form, const Array<crate::syntax::Arg>& args, const std::optional<crate::lower::Bn>& bound_opt);

bool is_widget_name(const crate::syntax::Expr& e);

std::tuple<Wx, crate::lower::Env, Array<crate::lower::model::Do>> dynamic_answers(const Wx& wx, const crate::lower::Env& benv, const crate::lower::Env& menv, const Text& hf, const crate::syntax::Expr& sup);

std::optional<crate::syntax::Expr> dynamic_answer(const crate::lower::Lx& lx, const crate::syntax::Expr& x);

Text dyn_key(const crate::syntax::Expr& x);

crate::lower::model::MethDef host_doc_getter(const Text& name, const crate::lower::model::Pos_& pos, const Array<Place>& places, const Array<crate::lower::model::ForDef>& builders, const Array<crate::lower::model::GenDef>& gens);

crate::lower::model::MethDef snap_getter(const Text& name, const crate::lower::model::OutTy& t, const Text& doc);

std::tuple<Wx, Wres> started_line(const Wx& wx, const std::optional<crate::lower::Bn>& bound_opt);

std::tuple<Wx, Wres> defer_line(const Wx& wx, const crate::lower::Env& menv, const Array<crate::syntax::Arg>& args, const crate::syntax::Expr& e, const std::optional<Nat>& target_opt);

std::tuple<Wx, Wres> run_line(const Wx& wx, const crate::lower::Env& benv, const Array<crate::syntax::Arg>& args, const crate::syntax::Expr& e, const std::optional<Nat>& target_opt);

std::tuple<Wx, Wres> machine_line(const Wx& wx, const crate::lower::Env& benv, const crate::lower::Env& menv, const Array<crate::syntax::Arg>& args, const crate::syntax::Expr& e, const std::optional<Nat>& target_opt);

std::tuple<Wx, Wres> inline_widget(const Wx& wx, const crate::lower::Env& benv, const crate::lower::Env& menv, const Text& qk, const crate::check::env::ValInfo& v_, const Array<crate::syntax::Arg>& args, const crate::syntax::Expr& e);

std::optional<crate::syntax::WidgetDecl> widget_decl_of(const crate::check::env::G& g, const Text& qk);

std::optional<crate::syntax::WidgetDecl> def_widget(const crate::check::env::Def& d, const std::optional<crate::syntax::WidgetDecl>& other_opt);

std::tuple<Wx, crate::lower::Env, crate::lower::Env> bind_param(const Wx& wx, const crate::lower::Env& cbenv, const crate::lower::Env& cmenv, const crate::lower::Env& be, const crate::lower::Env& me, const Text& nkey, const crate::check::types::Ty& pty, const crate::syntax::Expr& arg);

std::tuple<crate::lower::model::Ex, Array<Read>> dynamic_expr(const Wx& wx, const crate::lower::Env& menv, const crate::syntax::Expr& e);

prism_rtl::JobRef<std::tuple<crate::lower::model::Ex, Array<Read>>> start_dynamic_expr(Wx wx, crate::lower::Env menv, crate::syntax::Expr e);

std::tuple<EvRef, Wx> never_event(const Wx& wx, const crate::lower::model::OutTy& t);

std::tuple<EvRef, Wx> event_ref(const Wx& wx, const crate::lower::Env& menv, const crate::syntax::Expr& e);

prism_rtl::JobRef<std::tuple<EvRef, Wx>> start_event_ref(Wx wx, crate::lower::Env menv, crate::syntax::Expr e);

std::tuple<EvRef, Wx> event_if(const Wx& wx, const crate::lower::Env& menv, const crate::syntax::Expr& c, const crate::syntax::Expr& a, const crate::syntax::Expr& b, const crate::lower::model::OutTy& t);

std::optional<crate::syntax::Expr> block_expr(const crate::syntax::Block& b);

Text callee_key(const crate::lower::Lx& lx, const crate::syntax::Expr& c);

std::tuple<EvRef, Wx> pair_event(const Wx& wx, const crate::lower::Env& menv, const Array<crate::syntax::Arg>& args, const GnKind& kind, const crate::lower::model::OutTy& t);

std::tuple<EvRef, Wx> merge_all_event(const Wx& wx, const crate::lower::Env& menv, const Array<crate::syntax::Arg>& args, const crate::lower::model::OutTy& t);

std::tuple<EvRef, Wx> updated_event(const Wx& wx, const crate::lower::Env& menv, const Array<crate::syntax::Arg>& args, const crate::lower::model::OutTy& t);

std::tuple<EvRef, Wx> filter_event(const Wx& wx, const crate::lower::Env& menv, const Array<crate::syntax::Arg>& args, const bool& is_unit);

std::tuple<EvRef, Wx> gate_event(const Wx& wx, const crate::lower::Env& menv, const Array<crate::syntax::Arg>& args);

std::tuple<EvRef, Wx> event_map(const Wx& wx, const crate::lower::Env& menv, const crate::syntax::Expr& e);

crate::lower::Vl firing_value(const crate::lower::model::Ex& ex0, const crate::lower::model::OutTy& t);

Array<crate::syntax::Expr> operands(const crate::syntax::Expr& e);

std::tuple<Nat, Wx> merge(const Wx& wx, const Text& name, const crate::lower::model::OutTy& t, const EvRef& l, const EvRef& r);

std::tuple<Nat, Wx> combinator(const Wx& wx, const Text& name, const crate::lower::model::OutTy& t, const GnKind& kind, const EvRef& l, const EvRef& r, const crate::lower::model::OutTy& lt, const crate::lower::model::OutTy& rt);

Gn with_inputs(const Gn& n, const Array<Text>& ins);

Gn with_reads(const Gn& n, const Array<Read>& reads);

Array<Gn> heights(const Array<Gn>& gns);

Gn height_step(const Array<Gn>& gns, const Gn& n);

bool is_comb(const GnKind& k);

bool feeds(const Sk& sk0, const Gn& n);

bool writes(const Text& f, const Gn& n);

bool moves(const Read& r, const Gn& n);

Array<Read> reads_closed(const Map<Text, Array<Read>>& dyn_, const Array<Read>& reads);

Array<Read> getter_reads(const Map<Text, Array<Read>>& dyn_, const Read& read1);

bool reaches_snap(const Array<Text>& roots, const Array<Read>& reads);

Array<Text> snap_names(const Wx& wx);

Text wake_const(const Array<Nat>& heights_, const Nat& h);

crate::lower::model::Do self_call(const Text& m, const Array<crate::lower::model::Ex>& args);

Array<crate::lower::model::Do> sink_code(const Sinks& sk, const Sk& target, const crate::lower::model::Ex& y);

Array<crate::lower::model::Do> hold_written(const Sinks& sk, const Text& f);

crate::lower::model::Ex host_field_ex(const Wx& wx, const crate::lower::model::Pos_& pos);

Array<crate::lower::model::Do> moved_marks(const Sinks& sk, const Text& f);

Array<crate::lower::model::Do> moved_by(const Sinks& sk, const Read& r);

Array<crate::lower::model::Do> source_marks(const Wx& wx, const Read& r);

Array<SnapDef> snaps_behind(const Wx& wx, const Read& r);

bool lists_build(const Sinks& sk, const Read& r);

Array<crate::lower::model::Do> firing_code(const Sinks& sk, const Gn& g, const crate::lower::model::Ex& x);

prism_rtl::JobRef<Array<crate::lower::model::Do>> start_firing_code(Sinks sk, Gn g, crate::lower::model::Ex x);

crate::lower::model::NodeDef finish_node(const Wx& wx0, const Text& qk, const Array<std::tuple<Text, crate::lower::model::OutTy>>& params, const bool& is_row);

prism_rtl::JobRef<crate::lower::model::NodeDef> start_finish_node(Wx wx0, Text qk, Array<std::tuple<Text, crate::lower::model::OutTy>> params, bool is_row);

bool is_generation(const Wx& wx, const Text& name);

Array<crate::lower::model::MethDef> flatten_methods(const Sinks& sk);

crate::lower::model::MethDef host_moved(const Sinks& sk, const HostDef& h);

Array<crate::lower::model::Do> build_steps(const Sinks& sk, const bool& at_build);

crate::lower::model::Do snap_take_at_build(const SnapDef& sn);

crate::lower::model::Do snap_take(const Sinks& sk, const SnapDef& sn);

crate::lower::model::MethDef snap_publish(const Sinks& sk, const SnapDef& sn);

crate::lower::model::MethDef gathered_moved(const SnapDef& sn);

crate::lower::model::MethDef document_getter(const Wx& wx);

crate::lower::model::MethDef document_moved(const Text& m);

Array<crate::lower::model::Do> document_body(const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Do>(std::tuple<crate::lower::model::Ex, crate::lower::model::Ex>)>& add_fn, const Array<Place>& places, const Array<crate::lower::model::ForDef>& builders, const Array<crate::lower::model::GenDef>& gens);

crate::lower::model::Do map_insert(const crate::lower::model::Ex& path_, const crate::lower::model::Ex& e);

crate::lower::model::Do vec_push(const crate::lower::model::Ex& path_, const crate::lower::model::Ex& e);

std::tuple<crate::lower::model::Pa, crate::lower::model::Ex> dyn_answer_arm(const Sinks& sk, const crate::lower::model::Pos_& pos, const Text& f, const crate::lower::model::OutTy& t);

Array<crate::lower::model::Do> dyn_place_write(const Sinks& sk, const Text& f, const crate::lower::model::Ex& value);

Array<crate::lower::model::Do> updated_gaps(const Wx& wx, const Array<Gn>& gns, const bool& is_gen);

std::tuple<Array<crate::lower::model::NodeDef>, Array<Gn>> finish_pending(const Wx& wx, const Array<Gn>& gns);

prism_rtl::JobRef<std::tuple<Array<crate::lower::model::NodeDef>, Array<Gn>>> start_finish_pending(Wx wx, Array<Gn> gns);

Nat parent_floor(const Wx& wx, const Array<Gn>& gns, const Array<Read>& reads);

bool writes_hold(const Gn& g, const Text& f);

bool sink_writes_hold(const Sk& sk0, const Text& f);

Gn with_floor(const Gn& g, const Nat& h);

Gn with_height(const Gn& g, const Nat& h);

Array<Text> row_hears(const Wx& wx);

Array<crate::lower::model::Do> row_written(const Wx& wx, const RowMarks& rm, const Read& r);

Array<crate::lower::model::Do> patch_place(const Wx& wx, const Place& p_);

bool emits(const Wx& wx, const crate::lower::model::Pos_& pos);

Array<crate::lower::model::Do> result_told(const crate::lower::model::Ex& node_);

Array<crate::lower::model::Do> result_moved(const crate::lower::model::Ex& node_);

crate::lower::model::Do result_kept(const crate::lower::model::Ex& node_);

crate::lower::model::Do result_tell();

Array<crate::lower::model::Do> adoption(const FlatDef& fl);

crate::lower::model::Ex place_at(const Wx& wx, const Text& recv, const crate::lower::model::Pos_& pos);

crate::lower::model::Pa pos_pat(const crate::lower::model::Pos_& pos, const Array<crate::lower::model::Pa>& tail);

Array<crate::lower::model::Pa> key_tail();

Array<crate::lower::model::Pa> gen_tail();

std::optional<Text> hosted_rows(const Wx& wx);

Array<crate::lower::model::Do> root_dyn_patch(const Wx& wx);

std::tuple<crate::lower::model::Pa, crate::lower::model::Ex> answer_arm(const Wx& wx, const crate::lower::model::Pos_& pos, const Nat& id, const crate::lower::model::OutTy& t);

std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>> typed_answer_arm(const Wx& wx, const crate::lower::model::Pos_& pos, const Nat& id, const Text& acc);

std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>> typed_dyn_arm(const Sinks& sk, const crate::lower::model::Pos_& pos, const Text& f, const Text& acc);

std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>> typed_forward_arm(const crate::lower::model::ForDef& b, const crate::lower::model::Ex& segs);

std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>> typed_gen_arm(const crate::lower::model::GenDef& gd);

crate::lower::model::MethDef typed_dispatch(const Sinks& sk, const Text& name, const Nat& scope);

HostDef dummy_host();

Array<Nat> sort_nats(const Array<Nat>& xs);

Array<crate::lower::model::Do> ask_wake(const Sinks& sk, const Nat& h);

crate::lower::model::MethDef gather_in(const Sinks& sk, const Gn& g);

crate::lower::model::Do decide(const Gn& g);

crate::lower::model::Do updated_decide(const Gn& g);

crate::lower::model::Do pair_decide(const Gn& g, const GnKind& kind);

crate::lower::model::Do wake_by_height(const Array<Gn>& combs, const Array<Nat>& heights_);

crate::lower::model::Ex forward_answer(const crate::lower::model::ForDef& b);

bool is_hold(const crate::lower::model::OutTy& out_ty0);

Array<crate::lower::model::MethDef> row_methods(const Wx& wx);

Text gn_doc(const Gn& g);

crate::lower::model::Do merge_decide(const Gn& g);

std::tuple<Wx, Wres> for_line(const Wx& wx, const crate::lower::Env& benv, const crate::lower::Env& menv, const std::optional<crate::syntax::ForBinders>& binders_opt, const crate::syntax::Expr& source, const crate::syntax::Block& body, const crate::syntax::Expr& e, const std::optional<crate::lower::Bn>& bound_opt);

prism_rtl::JobRef<std::tuple<Wx, Wres>> start_for_line(Wx wx, crate::lower::Env benv, crate::lower::Env menv, std::optional<crate::syntax::ForBinders> binders_opt, crate::syntax::Expr source, crate::syntax::Block body, crate::syntax::Expr e, std::optional<crate::lower::Bn> bound_opt);

crate::lower::model::MethDef entry_getter(const Text& src_getter, const crate::lower::model::OutTy& vt);

Wx add_builder(const Wx& wx, const Text& name, const crate::lower::model::Pos_& pos, const crate::lower::model::OutTy& kt, const crate::lower::model::OutTy& vt, const Text& row_name, const bool& keyed, const Array<Read>& reads, const PendingRow& waiting, const Array<crate::lower::model::Ex>& passed);

Array<Read> row_place_reads(const Wx& row_wx);

Array<std::tuple<Text, crate::lower::model::OutTy>> hosted_params(const Wx& wx);

Array<crate::lower::model::Ex> hosted_passed(const Wx& wx);

crate::lower::Env row_reads(const crate::lower::Env& env, const crate::lower::model::Ex& pref);

crate::lower::Env events_of(const crate::lower::Env& ports, const crate::lower::Env& env);

Array<Read> block_reads(const Array<Read>& reads);

Array<RowLocal> row_locals(const crate::lower::Env& benv, const crate::lower::Env& menv, const crate::syntax::Block& body);

std::tuple<crate::lower::Env, crate::lower::Env> for_envs(const crate::lower::Env& benv, const crate::lower::Env& menv, const std::optional<crate::syntax::ForBinders>& binders_opt, const crate::lower::Bn& key_b, const crate::lower::Bn& key_m, const crate::lower::Bn& val_b, const crate::lower::Bn& val_m, const crate::lower::model::OutTy& vt);

crate::lower::model::OutTy kt0();

crate::lower::Env bind_pat(const crate::lower::Env& env, const crate::syntax::Pattern_& p_, const crate::lower::Bn& b, const crate::lower::model::Ex& whole, const crate::lower::model::OutTy& t);

crate::lower::Bn part_bn(const crate::lower::Bn& bn0, const crate::lower::model::Ex& whole, const Nat& i, const crate::lower::model::OutTy& t);

Text row_suffix(const Wx& wx);

crate::lower::model::OutTy gn_ty_named(const Wx& wx, const Text& n);

std::tuple<Wx, Wx, crate::lower::Env> row_env(const Wx& parent, const Wx& row_wx, const crate::lower::Env& menv, const crate::syntax::Block& body);

crate::lower::model::Ex over_parent(const crate::lower::model::Ex& x);

crate::lower::model::Ex parent_ref();

crate::lower::model::Ex parent_arg();

Wx with_port(const Wx& wx, const Text& pname);

std::tuple<Wx, Wres> rebuild_line(const Wx& wx, const crate::lower::Env& benv, const crate::lower::Env& menv, const crate::syntax::Expr& scrut, const crate::syntax::Block& body, const crate::syntax::Expr& e, const std::optional<crate::lower::Bn>& bound_opt);

prism_rtl::JobRef<std::tuple<Wx, Wres>> start_rebuild_line(Wx wx, crate::lower::Env benv, crate::lower::Env menv, crate::syntax::Expr scrut, crate::syntax::Block body, crate::syntax::Expr e, std::optional<crate::lower::Bn> bound_opt);

bool gives_dynamic(const crate::check::types::Ty& t);

std::tuple<Wx, Wres> rebuild_dynamic(const Wx& wx, const crate::lower::Env& menv, const crate::syntax::Block& body, const crate::lower::model::Ex& src_ex, const Array<Read>& reads, const crate::lower::model::OutTy& vt, const Text& name, const crate::lower::model::Pos_& pos);

std::tuple<Wx, Wres> clause_widget_line(const Wx& wx, const crate::lower::Env& menv, const crate::syntax::Expr& scrut, const crate::syntax::Block& call, const Text& qk, const crate::check::env::ValInfo& v_, const crate::syntax::Expr& e);

bool is_hosted_scope(const Wx& wx);

template <class A>
bool is_some(const std::optional<A>& opt0);

std::tuple<Array<GenCase>, Wx> gen_cases(const Wx& wx, const crate::lower::Env& menv, const crate::syntax::Block& body, const crate::lower::model::OutTy& vt, const Text& name);

std::optional<std::tuple<Text, Array<crate::syntax::Arg>>> clause_call(const crate::lower::Lx& lx, const crate::syntax::Block& body);

std::optional<std::tuple<Text, Array<crate::syntax::Arg>>> clause_call_x(const crate::lower::Lx& lx, const crate::syntax::Expr& x);

ClauseRow clause_row_of(const Wx& wx, const crate::lower::Env& menv, const crate::syntax::FnClause& c, const crate::check::env::ValInfo& v_, const Text& row_name, const Text& gen_name, const bool& transparent);

GenRow gen_row_of(const Wx& wx, const crate::lower::Env& menv, const crate::syntax::Block& body, const crate::lower::model::OutTy& vt, const Text& row_name, const Text& gen_name);

Wx gen_result(const Wx& r, const Text& gen_name, const crate::lower::model::Ex& ex, const Array<Read>& result_reads, const crate::lower::model::OutTy& rt);

Wx gen_marked(const Wx& parent, const Text& gen_name, const Wx& row_wx);

crate::lower::Env build_spelling(const crate::lower::Env& env);

crate::lower::model::Ex gen_select(const Wx& wx, const crate::lower::Env& menv, const crate::syntax::Block& body, const Array<GenCase>& cases, const crate::lower::model::Pos_& pos);

crate::lower::model::MethDef gen_up(const Text& name, const Text& up_name, const crate::lower::model::OutTy& t);

Array<std::tuple<crate::lower::model::Pa, crate::lower::model::Ex>> gen_forwards(const crate::lower::model::GenDef& gd);

crate::lower::model::Ex forward_gen(const crate::lower::model::GenDef& gd);

std::tuple<Wx, Wres> flatten_line(const Wx& wx, const crate::lower::Env& menv, const Array<crate::syntax::Arg>& args, const std::optional<crate::lower::Bn>& bound_opt);

std::tuple<Wx, Wres> switch_line(const Wx& wx, const crate::lower::Env& menv, const Array<crate::syntax::Arg>& args);

}  // namespace lower::node_


namespace lower::node_ {

/// The step machine of `IdPipe`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IdPipe: unbounded fn Ex, (unbounded fn Ex -> [Do]) -> [Do]
struct IdPipe : prism_rtl::Job<Array<crate::lower::model::Do>> {
    crate::lower::model::Ex x;
    prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)> k_fn;
    IdPipe(crate::lower::model::Ex x, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)> k_fn) : x(std::move(x)), k_fn(std::move(k_fn)) {}
    prism_rtl::Turn<Array<crate::lower::model::Do>> cycle() const override;
};


/// The step machine of `NodeDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NodeDefOf: unbounded fn Lx, Text, [Pattern], Block, Scheme, Bool -> NodeDef
struct NodeDefOf : prism_rtl::Job<crate::lower::model::NodeDef> {
    crate::lower::Lx lx;
    Text qk;
    Array<crate::syntax::Pattern_> params;
    crate::syntax::Block body;
    crate::check::types::Scheme sc;
    bool is_root;
    NodeDefOf(crate::lower::Lx lx, Text qk, Array<crate::syntax::Pattern_> params, crate::syntax::Block body, crate::check::types::Scheme sc, bool is_root) : lx(std::move(lx)), qk(std::move(qk)), params(std::move(params)), body(std::move(body)), sc(std::move(sc)), is_root(std::move(is_root)) {}
    prism_rtl::Turn<crate::lower::model::NodeDef> cycle() const override;
};


/// The step machine of `BlockInto`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BlockInto: unbounded fn Wx, Env, Env, Block -> Wx
struct BlockInto : prism_rtl::Job<Wx> {
    Wx wx;
    crate::lower::Env benv;
    crate::lower::Env menv;
    crate::syntax::Block b;
    BlockInto(Wx wx, crate::lower::Env benv, crate::lower::Env menv, crate::syntax::Block b) : wx(std::move(wx)), benv(std::move(benv)), menv(std::move(menv)), b(std::move(b)) {}
    prism_rtl::Turn<Wx> cycle() const override;
};


/// The step machine of `PreBind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PreBind: unbounded fn Wx, Env, Env, Stmt -> ((Wx, Env, Env))
struct PreBind : prism_rtl::Job<std::tuple<Wx, crate::lower::Env, crate::lower::Env>> {
    Wx wx;
    crate::lower::Env benv;
    crate::lower::Env menv;
    crate::syntax::Stmt s;
    PreBind(Wx wx, crate::lower::Env benv, crate::lower::Env menv, crate::syntax::Stmt s) : wx(std::move(wx)), benv(std::move(benv)), menv(std::move(menv)), s(std::move(s)) {}
    prism_rtl::Turn<std::tuple<Wx, crate::lower::Env, crate::lower::Env>> cycle() const override;
};


/// The step machine of `PreBindName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PreBindName: unbounded fn Wx, Env, Env, SName, HowBound -> ((Wx, Env, Env))
struct PreBindName : prism_rtl::Job<std::tuple<Wx, crate::lower::Env, crate::lower::Env>> {
    Wx wx;
    crate::lower::Env benv;
    crate::lower::Env menv;
    crate::syntax::SName n;
    HowBound how;
    PreBindName(Wx wx, crate::lower::Env benv, crate::lower::Env menv, crate::syntax::SName n, HowBound how) : wx(std::move(wx)), benv(std::move(benv)), menv(std::move(menv)), n(std::move(n)), how(std::move(how)) {}
    prism_rtl::Turn<std::tuple<Wx, crate::lower::Env, crate::lower::Env>> cycle() const override;
};


/// The step machine of `ManyInstances`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?ManyInstances: unbounded fn Lx, Range -> ?[(([((Text, Ty))], [((Text, Col))]))]
struct ManyInstances : prism_rtl::Job<std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>> {
    crate::lower::Lx lx;
    crate::syntax::Range span;
    ManyInstances(crate::lower::Lx lx, crate::syntax::Range span) : lx(std::move(lx)), span(std::move(span)) {}
    prism_rtl::Turn<std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>> cycle() const override;
};


/// The step machine of `WidgetStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WidgetStmt: unbounded fn Wx, Env, Env, Stmt, Bool -> ((Wx, Env, Env))
struct WidgetStmt : prism_rtl::Job<std::tuple<Wx, crate::lower::Env, crate::lower::Env>> {
    Wx wx;
    crate::lower::Env benv;
    crate::lower::Env menv;
    crate::syntax::Stmt s;
    bool last;
    WidgetStmt(Wx wx, crate::lower::Env benv, crate::lower::Env menv, crate::syntax::Stmt s, bool last) : wx(std::move(wx)), benv(std::move(benv)), menv(std::move(menv)), s(std::move(s)), last(std::move(last)) {}
    prism_rtl::Turn<std::tuple<Wx, crate::lower::Env, crate::lower::Env>> cycle() const override;
};


/// The step machine of `ResultOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ResultOf: unbounded fn Wx, Env, Env, Expr -> ((Wres, Wx))
struct ResultOf : prism_rtl::Job<std::tuple<Wres, Wx>> {
    Wx wx;
    crate::lower::Env benv;
    crate::lower::Env menv;
    crate::syntax::Expr x;
    ResultOf(Wx wx, crate::lower::Env benv, crate::lower::Env menv, crate::syntax::Expr x) : wx(std::move(wx)), benv(std::move(benv)), menv(std::move(menv)), x(std::move(x)) {}
    prism_rtl::Turn<std::tuple<Wres, Wx>> cycle() const override;
};


/// The step machine of `ResultOfTyped`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ResultOfTyped: unbounded fn Wx, Env, Env, Expr, Ty, OutTy -> ((Wres, Wx))
struct ResultOfTyped : prism_rtl::Job<std::tuple<Wres, Wx>> {
    Wx wx;
    crate::lower::Env benv;
    crate::lower::Env menv;
    crate::syntax::Expr x;
    crate::check::types::Ty full;
    crate::lower::model::OutTy t;
    ResultOfTyped(Wx wx, crate::lower::Env benv, crate::lower::Env menv, crate::syntax::Expr x, crate::check::types::Ty full, crate::lower::model::OutTy t) : wx(std::move(wx)), benv(std::move(benv)), menv(std::move(menv)), x(std::move(x)), full(std::move(full)), t(std::move(t)) {}
    prism_rtl::Turn<std::tuple<Wres, Wx>> cycle() const override;
};


/// The step machine of `HoldLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// HoldLine: unbounded fn Wx, Env, Env, Pattern, Expr, Expr -> ((Wx, Env))
struct HoldLine : prism_rtl::Job<std::tuple<Wx, crate::lower::Env>> {
    Wx wx;
    crate::lower::Env benv;
    crate::lower::Env menv;
    crate::syntax::Pattern_ p_;
    crate::syntax::Expr init;
    crate::syntax::Expr step_;
    HoldLine(Wx wx, crate::lower::Env benv, crate::lower::Env menv, crate::syntax::Pattern_ p_, crate::syntax::Expr init, crate::syntax::Expr step_) : wx(std::move(wx)), benv(std::move(benv)), menv(std::move(menv)), p_(std::move(p_)), init(std::move(init)), step_(std::move(step_)) {}
    prism_rtl::Turn<std::tuple<Wx, crate::lower::Env>> cycle() const override;
};


/// The step machine of `LetLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LetLine: unbounded fn Wx, Env, Env, Pattern, Expr -> ((Wx, Env))
struct LetLine : prism_rtl::Job<std::tuple<Wx, crate::lower::Env>> {
    Wx wx;
    crate::lower::Env benv;
    crate::lower::Env menv;
    crate::syntax::Pattern_ p_;
    crate::syntax::Expr e;
    LetLine(Wx wx, crate::lower::Env benv, crate::lower::Env menv, crate::syntax::Pattern_ p_, crate::syntax::Expr e) : wx(std::move(wx)), benv(std::move(benv)), menv(std::move(menv)), p_(std::move(p_)), e(std::move(e)) {}
    prism_rtl::Turn<std::tuple<Wx, crate::lower::Env>> cycle() const override;
};


/// The step machine of `BuildLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BuildLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
struct BuildLine : prism_rtl::Job<std::tuple<Wx, Wres>> {
    Wx wx;
    crate::lower::Env benv;
    crate::lower::Env menv;
    crate::syntax::Expr e;
    std::optional<crate::lower::Bn> bound_opt;
    BuildLine(Wx wx, crate::lower::Env benv, crate::lower::Env menv, crate::syntax::Expr e, std::optional<crate::lower::Bn> bound_opt) : wx(std::move(wx)), benv(std::move(benv)), menv(std::move(menv)), e(std::move(e)), bound_opt(std::move(bound_opt)) {}
    prism_rtl::Turn<std::tuple<Wx, Wres>> cycle() const override;
};


/// The step machine of `ElementLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ElementLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
struct ElementLine : prism_rtl::Job<std::tuple<Wx, Wres>> {
    Wx wx;
    crate::lower::Env benv;
    crate::lower::Env menv;
    crate::syntax::Expr e;
    std::optional<crate::lower::Bn> bound_opt;
    ElementLine(Wx wx, crate::lower::Env benv, crate::lower::Env menv, crate::syntax::Expr e, std::optional<crate::lower::Bn> bound_opt) : wx(std::move(wx)), benv(std::move(benv)), menv(std::move(menv)), e(std::move(e)), bound_opt(std::move(bound_opt)) {}
    prism_rtl::Turn<std::tuple<Wx, Wres>> cycle() const override;
};


/// The step machine of `WidgetLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WidgetLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
struct WidgetLine : prism_rtl::Job<std::tuple<Wx, Wres>> {
    Wx wx;
    crate::lower::Env benv;
    crate::lower::Env menv;
    crate::syntax::Expr e;
    std::optional<crate::lower::Bn> bound_opt;
    WidgetLine(Wx wx, crate::lower::Env benv, crate::lower::Env menv, crate::syntax::Expr e, std::optional<crate::lower::Bn> bound_opt) : wx(std::move(wx)), benv(std::move(benv)), menv(std::move(menv)), e(std::move(e)), bound_opt(std::move(bound_opt)) {}
    prism_rtl::Turn<std::tuple<Wx, Wres>> cycle() const override;
};


/// The step machine of `InlineBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InlineBlock: unbounded fn Wx, Env, Env, Block, Lx -> ((Wx, Wres))
struct InlineBlock : prism_rtl::Job<std::tuple<Wx, Wres>> {
    Wx wx;
    crate::lower::Env benv;
    crate::lower::Env menv;
    crate::syntax::Block b;
    crate::lower::Lx lx;
    InlineBlock(Wx wx, crate::lower::Env benv, crate::lower::Env menv, crate::syntax::Block b, crate::lower::Lx lx) : wx(std::move(wx)), benv(std::move(benv)), menv(std::move(menv)), b(std::move(b)), lx(std::move(lx)) {}
    prism_rtl::Turn<std::tuple<Wx, Wres>> cycle() const override;
};


/// The step machine of `DynamicExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DynamicExpr: unbounded fn Wx, Env, Expr -> ((Ex, [Read]))
struct DynamicExpr : prism_rtl::Job<std::tuple<crate::lower::model::Ex, Array<Read>>> {
    Wx wx;
    crate::lower::Env menv;
    crate::syntax::Expr e;
    DynamicExpr(Wx wx, crate::lower::Env menv, crate::syntax::Expr e) : wx(std::move(wx)), menv(std::move(menv)), e(std::move(e)) {}
    prism_rtl::Turn<std::tuple<crate::lower::model::Ex, Array<Read>>> cycle() const override;
};


/// The step machine of `EventRef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// EventRef: unbounded fn Wx, Env, Expr -> ((EvRef, Wx))
struct EventRef : prism_rtl::Job<std::tuple<EvRef, Wx>> {
    Wx wx;
    crate::lower::Env menv;
    crate::syntax::Expr e;
    EventRef(Wx wx, crate::lower::Env menv, crate::syntax::Expr e) : wx(std::move(wx)), menv(std::move(menv)), e(std::move(e)) {}
    prism_rtl::Turn<std::tuple<EvRef, Wx>> cycle() const override;
};


/// The step machine of `FiringCode`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FiringCode: unbounded fn Sinks, Gn, Ex -> [Do]
struct FiringCode : prism_rtl::Job<Array<crate::lower::model::Do>> {
    Sinks sk;
    Gn g;
    crate::lower::model::Ex x;
    FiringCode(Sinks sk, Gn g, crate::lower::model::Ex x) : sk(std::move(sk)), g(std::move(g)), x(std::move(x)) {}
    prism_rtl::Turn<Array<crate::lower::model::Do>> cycle() const override;
};


/// The step machine of `FinishNode`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FinishNode: unbounded fn Wx, Text, [((Text, OutTy))], Bool -> NodeDef
struct FinishNode : prism_rtl::Job<crate::lower::model::NodeDef> {
    Wx wx0;
    Text qk;
    Array<std::tuple<Text, crate::lower::model::OutTy>> params;
    bool is_row;
    FinishNode(Wx wx0, Text qk, Array<std::tuple<Text, crate::lower::model::OutTy>> params, bool is_row) : wx0(std::move(wx0)), qk(std::move(qk)), params(std::move(params)), is_row(std::move(is_row)) {}
    prism_rtl::Turn<crate::lower::model::NodeDef> cycle() const override;
};


/// The step machine of `FinishPending`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FinishPending: unbounded fn Wx, [Gn] -> (([NodeDef], [Gn]))
struct FinishPending : prism_rtl::Job<std::tuple<Array<crate::lower::model::NodeDef>, Array<Gn>>> {
    Wx wx;
    Array<Gn> gns;
    FinishPending(Wx wx, Array<Gn> gns) : wx(std::move(wx)), gns(std::move(gns)) {}
    prism_rtl::Turn<std::tuple<Array<crate::lower::model::NodeDef>, Array<Gn>>> cycle() const override;
};


/// The step machine of `ForLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ForLine: unbounded fn Wx, Env, Env, ?ForBinders, Expr, Block, Expr, ?Bn -> ((Wx, Wres))
struct ForLine : prism_rtl::Job<std::tuple<Wx, Wres>> {
    Wx wx;
    crate::lower::Env benv;
    crate::lower::Env menv;
    std::optional<crate::syntax::ForBinders> binders_opt;
    crate::syntax::Expr source;
    crate::syntax::Block body;
    crate::syntax::Expr e;
    std::optional<crate::lower::Bn> bound_opt;
    ForLine(Wx wx, crate::lower::Env benv, crate::lower::Env menv, std::optional<crate::syntax::ForBinders> binders_opt, crate::syntax::Expr source, crate::syntax::Block body, crate::syntax::Expr e, std::optional<crate::lower::Bn> bound_opt) : wx(std::move(wx)), benv(std::move(benv)), menv(std::move(menv)), binders_opt(std::move(binders_opt)), source(std::move(source)), body(std::move(body)), e(std::move(e)), bound_opt(std::move(bound_opt)) {}
    prism_rtl::Turn<std::tuple<Wx, Wres>> cycle() const override;
};


/// The step machine of `RebuildLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RebuildLine: unbounded fn Wx, Env, Env, Expr, Block, Expr, ?Bn -> ((Wx, Wres))
struct RebuildLine : prism_rtl::Job<std::tuple<Wx, Wres>> {
    Wx wx;
    crate::lower::Env benv;
    crate::lower::Env menv;
    crate::syntax::Expr scrut;
    crate::syntax::Block body;
    crate::syntax::Expr e;
    std::optional<crate::lower::Bn> bound_opt;
    RebuildLine(Wx wx, crate::lower::Env benv, crate::lower::Env menv, crate::syntax::Expr scrut, crate::syntax::Block body, crate::syntax::Expr e, std::optional<crate::lower::Bn> bound_opt) : wx(std::move(wx)), benv(std::move(benv)), menv(std::move(menv)), scrut(std::move(scrut)), body(std::move(body)), e(std::move(e)), bound_opt(std::move(bound_opt)) {}
    prism_rtl::Turn<std::tuple<Wx, Wres>> cycle() const override;
};


}  // namespace lower::node_

}  // namespace crate
