// The module `Lower.Node`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <lower/node_/types.hpp>
#include "elem.types.hpp"
#include <lower/model/types.hpp>
#include <lower/types/types.hpp>
#include <lower/types.hpp>
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace lower::node_ {

Array<crate::lower::model::Do> id_pipe(const crate::lower::model::Ex& x_p0, const prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>& k_f1);

prism_rtl::JobRef<Array<crate::lower::model::Do>> start_id_pipe(crate::lower::model::Ex x_p0, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)> k_f1);

EvRef ev_ref_of(const Wx& wx_p0, const Nat& n_p1);

Text kind_word(const GnKind& k_p0);

bool has_read(const Array<Read>& rs_p0, const Read& r_p1);

Array<Read> add_read(const Array<Read>& rs_p0, const Read& r_p1);

Array<Read> union_reads(const Array<Read>& xs_p0, const Array<Read>& ys_p1);

Array<Text> node_hooks();

Wx new_wx(const crate::lower::Lx& lx_p0, const Text& name_p1, const Array<std::tuple<Text, crate::lower::model::OutTy, Text>>& fields_p2, const Array<std::tuple<Text, crate::lower::model::Ex>>& inits_p3, const Array<std::tuple<Text, crate::lower::model::Ex>>& moves_p4, const Array<crate::lower::model::MethDef>& getters_p5, const Map<Text, Array<Read>>& dyn_reads_p6, const Array<Text>& taken_p7, const Array<Text>& inlining_p8, const std::optional<Text>& hosted_by_o9);

std::tuple<Text, Wx> fresh_name(const Wx& wx_p0, const Text& base_p1);

Nat first_free(const Array<Text>& taken_p0, const Text& base_p1, const Nat& from_p2);

std::tuple<Nat, Wx> add_gn(const Wx& wx_p0, const Text& name_p1, const crate::lower::model::OutTy& ty_p2, const GnKind& kind_p3, const Nat& height_p4);

Wx connect(const Wx& wx_p0, const EvRef& r_p1, const Sk& sink_p2);

Wx crossed(const Wx& wx_p0, const Text& what_p1);

Gn add_out(const Gn& n_p0, const Out& o_p1);

Wx add_field(const Wx& wx_p0, const Text& name_p1, const crate::lower::model::OutTy& t_p2, const Text& doc_p3, const crate::lower::model::Ex& init_p4);

Wx add_field_last(const Wx& wx_p0, const Text& name_p1, const crate::lower::model::OutTy& t_p2, const Text& doc_p3, const crate::lower::model::Ex& init_p4);

Gn gn_of(const Wx& wx_p0, const Nat& n_p1);

std::tuple<crate::lower::types::Env, crate::lower::types::Env> bind_plain(const crate::lower::types::Env& benv_p0, const crate::lower::types::Env& menv_p1, const Text& nkey_p2, const Text& rs_p3, const crate::lower::model::OutTy& t_p4);

}  // namespace lower::node_


namespace lower::node_ {

/// The step machine of `IdPipe`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IdPipe: unbounded fn Ex, (unbounded fn Ex -> [Do]) -> [Do]
struct IdPipe : prism_rtl::Job<Array<crate::lower::model::Do>> {
    crate::lower::model::Ex x_p0;
    prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)> k_f1;
    IdPipe(crate::lower::model::Ex x_p0, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)> k_f1) : x_p0(std::move(x_p0)), k_f1(std::move(k_f1)) {}
    prism_rtl::Turn<Array<crate::lower::model::Do>> cycle() const override;
};


}  // namespace lower::node_

}  // namespace crate
