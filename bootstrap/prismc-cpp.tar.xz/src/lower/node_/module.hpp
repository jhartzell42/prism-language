// The module `Lower.Node`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <lower/node_/types.hpp>
#include "elem.types.hpp"
#include <lower/model/types.hpp>
#include <lower/types/types.hpp>
#include <lower/types.hpp>
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace lower::node_ {

Array<crate::lower::model::Do> id_pipe(const crate::lower::model::Ex& x, const prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>& k_fn);

prism_rtl::JobRef<Array<crate::lower::model::Do>> start_id_pipe(crate::lower::model::Ex x, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)> k_fn);

EvRef ev_ref_of(const Wx& wx, const Nat& n);

Text kind_word(const GnKind& k);

bool has_read(const Array<Read>& rs, const Read& r);

Array<Read> add_read(const Array<Read>& rs, const Read& r);

Array<Read> union_reads(const Array<Read>& xs, const Array<Read>& ys);

Array<Text> node_hooks();

Wx new_wx(const crate::lower::Lx& lx, const Text& name, const Array<std::tuple<Text, crate::lower::model::OutTy, Text>>& fields, const Array<std::tuple<Text, crate::lower::model::Ex>>& inits, const Array<std::tuple<Text, crate::lower::model::Ex>>& moves, const Array<crate::lower::model::MethDef>& getters, const Map<Text, Array<Read>>& dyn_reads, const Array<Text>& taken, const Array<Text>& inlining, const std::optional<Text>& hosted_by_opt);

std::tuple<Text, Wx> fresh_name(const Wx& wx, const Text& base);

Nat first_free(const Array<Text>& taken, const Text& base, const Nat& from);

std::tuple<Nat, Wx> add_gn(const Wx& wx, const Text& name, const crate::lower::model::OutTy& ty, const GnKind& kind, const Nat& height);

Wx connect(const Wx& wx, const EvRef& r, const Sk& sink);

Wx crossed(const Wx& wx, const Text& what);

Gn add_out(const Gn& n, const Out& o);

Wx add_field(const Wx& wx, const Text& name, const crate::lower::model::OutTy& t, const Text& doc, const crate::lower::model::Ex& init);

Wx add_field_last(const Wx& wx, const Text& name, const crate::lower::model::OutTy& t, const Text& doc, const crate::lower::model::Ex& init);

Gn gn_of(const Wx& wx, const Nat& n);

std::tuple<crate::lower::types::Env, crate::lower::types::Env> bind_plain(const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const Text& nkey, const Text& rs, const crate::lower::model::OutTy& t);

}  // namespace lower::node_


namespace lower::node_ {

/// The step machine of `IdPipe`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IdPipe: unbounded fn Ex, (unbounded fn Ex -> [Do]) -> [Do]
struct IdPipe : prism_rtl::Job<Array<crate::lower::model::Do>> {
    crate::lower::model::Ex x;
    prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)> k_fn;
    IdPipe(crate::lower::model::Ex x, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)> k_fn) : x(std::move(x)), k_fn(std::move(k_fn)) {}
    prism_rtl::Turn<Array<crate::lower::model::Do>> cycle() const override;
};


}  // namespace lower::node_

}  // namespace crate
