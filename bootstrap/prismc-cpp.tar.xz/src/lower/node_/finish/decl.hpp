// The module `Lower.Node.Finish`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace lower::node_::finish {

struct Sinks;

struct FiringCode;

struct FinishNode;

struct FinishPending;

}  // namespace lower::node_::finish

}  // namespace crate
