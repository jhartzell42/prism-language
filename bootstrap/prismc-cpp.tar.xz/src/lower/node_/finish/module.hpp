// The module `Lower.Node.Finish`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <lower/node_/finish/types.hpp>
#include "elem.types.hpp"
#include <lower/node_/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace lower::node_::finish {

Array<crate::lower::node_::Gn> heights_f(const Array<crate::lower::node_::Gn>& gns_p0);

crate::lower::node_::Gn height_step_f(const Array<crate::lower::node_::Gn>& gns_p0, const crate::lower::node_::Gn& n_p1);

bool is_comb_f(const crate::lower::node_::GnKind& k_p0);

bool feeds_f(const crate::lower::node_::Sk& sk0, const crate::lower::node_::Gn& n_p1);

bool writes_f(const Text& f_p0, const crate::lower::node_::Gn& n_p1);

bool moves_f(const crate::lower::node_::Read& r_p0, const crate::lower::node_::Gn& n_p1);

Array<crate::lower::node_::Read> reads_closed_f(const Map<Text, Array<crate::lower::node_::Read>>& dyn_p0, const Array<crate::lower::node_::Read>& reads_p1);

Array<crate::lower::node_::Read> getter_reads_f(const Map<Text, Array<crate::lower::node_::Read>>& dyn_p0, const crate::lower::node_::Read& read1);

bool reaches_snap_f(const Array<Text>& roots_p0, const Array<crate::lower::node_::Read>& reads_p1);

Array<Text> snap_names_f(const crate::lower::node_::Wx& wx_p0);

Text wake_const_f(const Array<Nat>& heights_p0, const Nat& h_p1);

crate::lower::model::Do self_call_f(const Text& m_p0, const Array<crate::lower::model::Ex>& args_p1);

Array<crate::lower::model::Do> sink_code_f(const Sinks& sk_p0, const crate::lower::node_::Sk& target_p1, const crate::lower::model::Ex& y_p2);

Array<crate::lower::model::Do> hold_written_f(const Sinks& sk_p0, const Text& f_p1);

crate::lower::model::Ex host_field_ex_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::model::Pos_& pos_p1);

Array<crate::lower::model::Do> moved_marks_f(const Sinks& sk_p0, const Text& f_p1);

Array<crate::lower::model::Do> moved_by_f(const Sinks& sk_p0, const crate::lower::node_::Read& r_p1);

Array<crate::lower::model::Do> source_marks_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::node_::Read& r_p1);

Array<crate::lower::node_::Read> reads_all_f(const Map<Text, Array<crate::lower::node_::Read>>& dyn_p0, const Array<crate::lower::node_::Read>& reads_p1);

bool is_own_read_f(const crate::lower::node_::Read& r_p0);

Array<crate::lower::node_::SnapDef> snaps_behind_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::node_::Read& r_p1);

bool lists_build_f(const Sinks& sk_p0, const crate::lower::node_::Read& r_p1);

Array<crate::lower::model::Do> firing_code_f(const Sinks& sk_p0, const crate::lower::node_::Gn& g_p1, const crate::lower::model::Ex& x_p2);

prism_rtl::JobRef<Array<crate::lower::model::Do>> start_firing_code_f(Sinks sk_p0, crate::lower::node_::Gn g_p1, crate::lower::model::Ex x_p2);

crate::lower::model::NodeDef finish_node_f(const crate::lower::node_::Wx& wx0_p0, const Text& qk_p1, const Array<std::tuple<Text, crate::lower::model::OutTy>>& params_p2, const bool& is_row_p3);

prism_rtl::JobRef<crate::lower::model::NodeDef> start_finish_node_f(crate::lower::node_::Wx wx0_p0, Text qk_p1, Array<std::tuple<Text, crate::lower::model::OutTy>> params_p2, bool is_row_p3);

bool is_generation_f(const crate::lower::node_::Wx& wx_p0, const Text& name_p1);

Array<crate::lower::model::MethDef> flatten_methods_f(const Sinks& sk_p0);

crate::lower::model::MethDef host_moved_f(const Sinks& sk_p0, const crate::lower::node_::HostDef& h_p1);

Array<crate::lower::model::Do> build_steps_f(const Sinks& sk_p0, const bool& at_build_p1);

crate::lower::model::Do entry_take_f(const crate::lower::model::Ex& recv_p0, const crate::lower::node_::Place& pl_p1);

crate::lower::model::Do snap_take_at_build_f(const crate::lower::node_::SnapDef& sn_p0);

crate::lower::model::Do snap_take_f(const Sinks& sk_p0, const crate::lower::node_::SnapDef& sn_p1);

crate::lower::model::MethDef snap_publish_f(const Sinks& sk_p0, const crate::lower::node_::SnapDef& sn_p1);

crate::lower::model::MethDef gathered_moved_f(const crate::lower::node_::SnapDef& sn_p0);

crate::lower::model::MethDef document_getter_f(const crate::lower::node_::Wx& wx_p0);

crate::lower::model::MethDef document_moved_f(const Text& m_p0);

Array<crate::lower::model::Do> document_body_f(const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Do>(std::tuple<crate::lower::model::Ex, crate::lower::model::Ex>)>& add_f0, const Array<crate::lower::node_::Place>& places_p1, const Array<crate::lower::model::ForDef>& builders_p2, const Array<crate::lower::model::GenDef>& gens_p3);

crate::lower::model::Do map_insert_f(const crate::lower::model::Ex& path_p0, const crate::lower::model::Ex& e_p1);

crate::lower::model::Do vec_push_f(const crate::lower::model::Ex& path_p0, const crate::lower::model::Ex& e_p1);

std::tuple<crate::lower::model::Pa, crate::lower::model::Ex> dyn_answer_arm_f(const Sinks& sk_p0, const crate::lower::model::Pos_& pos_p1, const Text& f_p2, const crate::lower::model::OutTy& t_p3);

Array<crate::lower::model::Do> dyn_place_write_f(const Sinks& sk_p0, const Text& f_p1, const crate::lower::model::Ex& value_p2);

Array<crate::lower::model::Do> updated_gaps_f(const crate::lower::node_::Wx& wx_p0, const Array<crate::lower::node_::Gn>& gns_p1, const bool& is_gen_p2);

std::tuple<Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>> finish_pending_f(const crate::lower::node_::Wx& wx_p0, const Array<crate::lower::node_::Gn>& gns_p1);

prism_rtl::JobRef<std::tuple<Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>>> start_finish_pending_f(crate::lower::node_::Wx wx_p0, Array<crate::lower::node_::Gn> gns_p1);

Nat parent_floor_f(const crate::lower::node_::Wx& wx_p0, const Array<crate::lower::node_::Gn>& gns_p1, const Array<crate::lower::node_::Read>& reads_p2);

bool writes_hold_f(const crate::lower::node_::Gn& g_p0, const Text& f_p1);

bool sink_writes_hold_f(const crate::lower::node_::Sk& sk0, const Text& f_p1);

crate::lower::node_::Gn with_floor_f(const crate::lower::node_::Gn& g_p0, const Nat& h_p1);

crate::lower::node_::Gn with_height_f(const crate::lower::node_::Gn& g_p0, const Nat& h_p1);

Array<Text> row_hears_f(const crate::lower::node_::Wx& wx_p0);

Array<Text> updated_hears_f(const crate::lower::node_::Wx& wx_p0);

Array<crate::lower::model::Do> row_written_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::node_::RowMarks& rm_p1, const crate::lower::node_::Read& r_p2);

Array<crate::lower::model::Do> patch_place_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::node_::Place& p_p1);

bool emits_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::model::Pos_& pos_p1);

Array<crate::lower::model::Do> result_told_f(const crate::lower::model::Ex& node_p0);

Array<crate::lower::model::Do> result_moved_f(const crate::lower::model::Ex& node_p0);

crate::lower::model::Do result_kept_f(const crate::lower::model::Ex& node_p0);

crate::lower::model::Do result_tell_p();

Array<crate::lower::model::Do> adoption_f(const crate::lower::node_::FlatDef& fl_p0);

crate::lower::model::Ex place_at_f(const crate::lower::node_::Wx& wx_p0, const Text& recv_p1, const crate::lower::model::Pos_& pos_p2);

crate::lower::model::Pa pos_pat_f(const crate::lower::model::Pos_& pos_p0, const Array<crate::lower::model::Pa>& tail_p1);

Array<crate::lower::model::Pa> key_tail_p();

Array<crate::lower::model::Pa> gen_tail_p();

std::optional<Text> hosted_rows_o(const crate::lower::node_::Wx& wx_p0);

Array<crate::lower::model::Do> root_dyn_patch_f(const crate::lower::node_::Wx& wx_p0);

std::tuple<crate::lower::model::Pa, crate::lower::model::Ex> answer_arm_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::model::Pos_& pos_p1, const Nat& id_p2, const crate::lower::model::OutTy& t_p3);

std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>> typed_answer_arm_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::model::Pos_& pos_p1, const Nat& id_p2, const Text& acc_p3);

std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>> typed_dyn_arm_f(const Sinks& sk_p0, const crate::lower::model::Pos_& pos_p1, const Text& f_p2, const Text& acc_p3);

std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>> typed_forward_arm_f(const crate::lower::model::ForDef& b_p0, const crate::lower::model::Ex& segs_p1);

std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>> typed_gen_arm_f(const crate::lower::model::GenDef& gd_p0);

crate::lower::model::MethDef typed_dispatch_f(const Sinks& sk_p0, const Text& name_p1, const Nat& scope_p2);

crate::lower::node_::HostDef dummy_host_p();

Array<Nat> sort_nats_f(const Array<Nat>& xs_p0);

Array<crate::lower::model::Do> ask_wake_f(const Sinks& sk_p0, const Nat& h_p1);

crate::lower::model::MethDef gather_in_f(const Sinks& sk_p0, const crate::lower::node_::Gn& g_p1);

crate::lower::model::Do decide_f(const crate::lower::node_::Gn& g_p0);

crate::lower::model::Do updated_decide_f(const crate::lower::node_::Gn& g_p0);

crate::lower::model::Do pair_decide_f(const crate::lower::node_::Gn& g_p0, const crate::lower::node_::GnKind& kind_p1);

crate::lower::model::Do wake_by_height_f(const Array<crate::lower::node_::Gn>& combs_p0, const Array<Nat>& heights_p1);

crate::lower::model::Ex forward_answer_f(const crate::lower::model::ForDef& b_p0);

bool is_hold_f(const crate::lower::model::OutTy& out_ty0);

Array<crate::lower::model::MethDef> row_methods_f(const crate::lower::node_::Wx& wx_p0);

Text gn_doc_f(const crate::lower::node_::Gn& g_p0);

crate::lower::model::Do merge_decide_f(const crate::lower::node_::Gn& g_p0);

}  // namespace lower::node_::finish


namespace lower::node_::finish {

/// The step machine of `FiringCode`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FiringCode: unbounded fn Sinks, Gn, Ex -> [Do]
struct FiringCode : prism_rtl::Job<Array<crate::lower::model::Do>> {
    Sinks sk_p0;
    crate::lower::node_::Gn g_p1;
    crate::lower::model::Ex x_p2;
    FiringCode(Sinks sk_p0, crate::lower::node_::Gn g_p1, crate::lower::model::Ex x_p2) : sk_p0(std::move(sk_p0)), g_p1(std::move(g_p1)), x_p2(std::move(x_p2)) {}
    prism_rtl::Turn<Array<crate::lower::model::Do>> cycle() const override;
};


/// The step machine of `FinishNode`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FinishNode: unbounded fn Wx, Text, [((Text, OutTy))], Bool -> NodeDef
struct FinishNode : prism_rtl::Job<crate::lower::model::NodeDef> {
    crate::lower::node_::Wx wx0_p0;
    Text qk_p1;
    Array<std::tuple<Text, crate::lower::model::OutTy>> params_p2;
    bool is_row_p3;
    FinishNode(crate::lower::node_::Wx wx0_p0, Text qk_p1, Array<std::tuple<Text, crate::lower::model::OutTy>> params_p2, bool is_row_p3) : wx0_p0(std::move(wx0_p0)), qk_p1(std::move(qk_p1)), params_p2(std::move(params_p2)), is_row_p3(std::move(is_row_p3)) {}
    prism_rtl::Turn<crate::lower::model::NodeDef> cycle() const override;
};


/// The step machine of `FinishPending`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FinishPending: unbounded fn Wx, [Gn] -> (([NodeDef], [Gn]))
struct FinishPending : prism_rtl::Job<std::tuple<Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>>> {
    crate::lower::node_::Wx wx_p0;
    Array<crate::lower::node_::Gn> gns_p1;
    FinishPending(crate::lower::node_::Wx wx_p0, Array<crate::lower::node_::Gn> gns_p1) : wx_p0(std::move(wx_p0)), gns_p1(std::move(gns_p1)) {}
    prism_rtl::Turn<std::tuple<Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>>> cycle() const override;
};


}  // namespace lower::node_::finish

}  // namespace crate
