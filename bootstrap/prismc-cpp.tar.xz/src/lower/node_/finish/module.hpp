// The module `Lower.Node.Finish`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <lower/node_/finish/types.hpp>
#include "elem.types.hpp"
#include <lower/node_/types.hpp>
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace lower::node_::finish {

Array<crate::lower::node_::Gn> heights(const Array<crate::lower::node_::Gn>& gns_p0);

crate::lower::node_::Gn height_step(const Array<crate::lower::node_::Gn>& gns_p0, const crate::lower::node_::Gn& n_p1);

bool is_comb(const crate::lower::node_::GnKind& k_p0);

bool feeds(const crate::lower::node_::Sk& sk0, const crate::lower::node_::Gn& n_p1);

bool writes(const Text& f_p0, const crate::lower::node_::Gn& n_p1);

bool moves(const crate::lower::node_::Read& r_p0, const crate::lower::node_::Gn& n_p1);

Array<crate::lower::node_::Read> reads_closed(const Map<Text, Array<crate::lower::node_::Read>>& dyn_p0, const Array<crate::lower::node_::Read>& reads_p1);

Array<crate::lower::node_::Read> getter_reads(const Map<Text, Array<crate::lower::node_::Read>>& dyn_p0, const crate::lower::node_::Read& read1);

bool reaches_snap(const Array<Text>& roots_p0, const Array<crate::lower::node_::Read>& reads_p1);

Array<Text> snap_names(const crate::lower::node_::Wx& wx_p0);

Text wake_const(const Array<Nat>& heights_p0, const Nat& h_p1);

crate::lower::model::Do self_call(const Text& m_p0, const Array<crate::lower::model::Ex>& args_p1);

Array<crate::lower::model::Do> sink_code(const Sinks& sk_p0, const crate::lower::node_::Sk& target_p1, const crate::lower::model::Ex& y_p2);

Array<crate::lower::model::Do> hold_written(const Sinks& sk_p0, const Text& f_p1);

crate::lower::model::Ex host_field_ex(const crate::lower::node_::Wx& wx_p0, const crate::lower::model::Pos_& pos_p1);

Array<crate::lower::model::Do> moved_marks(const Sinks& sk_p0, const Text& f_p1);

Array<crate::lower::model::Do> moved_by(const Sinks& sk_p0, const crate::lower::node_::Read& r_p1);

Array<crate::lower::model::Do> source_marks(const crate::lower::node_::Wx& wx_p0, const crate::lower::node_::Read& r_p1);

Array<crate::lower::node_::Read> reads_all(const Map<Text, Array<crate::lower::node_::Read>>& dyn_p0, const Array<crate::lower::node_::Read>& reads_p1);

bool is_own_read(const crate::lower::node_::Read& r_p0);

Array<crate::lower::node_::SnapDef> snaps_behind(const crate::lower::node_::Wx& wx_p0, const crate::lower::node_::Read& r_p1);

bool lists_build(const Sinks& sk_p0, const crate::lower::node_::Read& r_p1);

Array<crate::lower::model::Do> firing_code(const Sinks& sk_p0, const crate::lower::node_::Gn& g_p1, const crate::lower::model::Ex& x_p2);

prism_rtl::JobRef<Array<crate::lower::model::Do>> start_firing_code(Sinks sk_p0, crate::lower::node_::Gn g_p1, crate::lower::model::Ex x_p2);

crate::lower::model::NodeDef finish_node(const crate::lower::node_::Wx& wx0_p0, const Text& qk_p1, const Array<std::tuple<Text, crate::lower::model::OutTy>>& params_p2, const bool& is_row_p3);

prism_rtl::JobRef<crate::lower::model::NodeDef> start_finish_node(crate::lower::node_::Wx wx0_p0, Text qk_p1, Array<std::tuple<Text, crate::lower::model::OutTy>> params_p2, bool is_row_p3);

bool is_generation(const crate::lower::node_::Wx& wx_p0, const Text& name_p1);

Array<crate::lower::model::MethDef> flatten_methods(const Sinks& sk_p0);

crate::lower::model::MethDef host_moved(const Sinks& sk_p0, const crate::lower::node_::HostDef& h_p1);

Array<crate::lower::model::Do> build_steps(const Sinks& sk_p0, const bool& at_build_p1);

crate::lower::model::Do entry_take(const crate::lower::model::Ex& recv_p0, const crate::lower::node_::Place& pl_p1);

crate::lower::model::Do snap_take_at_build(const crate::lower::node_::SnapDef& sn_p0);

crate::lower::model::Do snap_take(const Sinks& sk_p0, const crate::lower::node_::SnapDef& sn_p1);

crate::lower::model::MethDef snap_publish(const Sinks& sk_p0, const crate::lower::node_::SnapDef& sn_p1);

crate::lower::model::MethDef gathered_moved(const crate::lower::node_::SnapDef& sn_p0);

crate::lower::model::MethDef document_getter(const crate::lower::node_::Wx& wx_p0);

crate::lower::model::MethDef document_moved(const Text& m_p0);

Array<crate::lower::model::Do> document_body(const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Do>(std::tuple<crate::lower::model::Ex, crate::lower::model::Ex>)>& add_f0, const Array<crate::lower::node_::Place>& places_p1, const Array<crate::lower::model::ForDef>& builders_p2, const Array<crate::lower::model::GenDef>& gens_p3);

crate::lower::model::Do map_insert(const crate::lower::model::Ex& path_p0, const crate::lower::model::Ex& e_p1);

crate::lower::model::Do vec_push(const crate::lower::model::Ex& path_p0, const crate::lower::model::Ex& e_p1);

std::tuple<crate::lower::model::Pa, crate::lower::model::Ex> dyn_answer_arm(const Sinks& sk_p0, const crate::lower::model::Pos_& pos_p1, const Text& f_p2, const crate::lower::model::OutTy& t_p3);

Array<crate::lower::model::Do> dyn_place_write(const Sinks& sk_p0, const Text& f_p1, const crate::lower::model::Ex& value_p2);

Array<crate::lower::model::Do> updated_gaps(const crate::lower::node_::Wx& wx_p0, const Array<crate::lower::node_::Gn>& gns_p1, const bool& is_gen_p2);

std::tuple<Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>> finish_pending(const crate::lower::node_::Wx& wx_p0, const Array<crate::lower::node_::Gn>& gns_p1);

prism_rtl::JobRef<std::tuple<Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>>> start_finish_pending(crate::lower::node_::Wx wx_p0, Array<crate::lower::node_::Gn> gns_p1);

Nat parent_floor(const crate::lower::node_::Wx& wx_p0, const Array<crate::lower::node_::Gn>& gns_p1, const Array<crate::lower::node_::Read>& reads_p2);

bool writes_hold(const crate::lower::node_::Gn& g_p0, const Text& f_p1);

bool sink_writes_hold(const crate::lower::node_::Sk& sk0, const Text& f_p1);

crate::lower::node_::Gn with_floor(const crate::lower::node_::Gn& g_p0, const Nat& h_p1);

crate::lower::node_::Gn with_height(const crate::lower::node_::Gn& g_p0, const Nat& h_p1);

Array<Text> row_hears(const crate::lower::node_::Wx& wx_p0);

Array<Text> updated_hears(const crate::lower::node_::Wx& wx_p0);

Array<crate::lower::model::Do> row_written(const crate::lower::node_::Wx& wx_p0, const crate::lower::node_::RowMarks& rm_p1, const crate::lower::node_::Read& r_p2);

Array<crate::lower::model::Do> patch_place(const crate::lower::node_::Wx& wx_p0, const crate::lower::node_::Place& p_p1);

bool emits(const crate::lower::node_::Wx& wx_p0, const crate::lower::model::Pos_& pos_p1);

Array<crate::lower::model::Do> result_told(const crate::lower::model::Ex& node_p0);

Array<crate::lower::model::Do> result_moved(const crate::lower::model::Ex& node_p0);

crate::lower::model::Do result_kept(const crate::lower::model::Ex& node_p0);

crate::lower::model::Do result_tell();

Array<crate::lower::model::Do> adoption(const crate::lower::node_::FlatDef& fl_p0);

crate::lower::model::Ex place_at(const crate::lower::node_::Wx& wx_p0, const Text& recv_p1, const crate::lower::model::Pos_& pos_p2);

crate::lower::model::Pa pos_pat(const crate::lower::model::Pos_& pos_p0, const Array<crate::lower::model::Pa>& tail_p1);

Array<crate::lower::model::Pa> key_tail();

Array<crate::lower::model::Pa> gen_tail();

std::optional<Text> hosted_rows(const crate::lower::node_::Wx& wx_p0);

Array<crate::lower::model::Do> root_dyn_patch(const crate::lower::node_::Wx& wx_p0);

std::tuple<crate::lower::model::Pa, crate::lower::model::Ex> answer_arm(const crate::lower::node_::Wx& wx_p0, const crate::lower::model::Pos_& pos_p1, const Nat& id_p2, const crate::lower::model::OutTy& t_p3);

std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>> typed_answer_arm(const crate::lower::node_::Wx& wx_p0, const crate::lower::model::Pos_& pos_p1, const Nat& id_p2, const Text& acc_p3);

std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>> typed_dyn_arm(const Sinks& sk_p0, const crate::lower::model::Pos_& pos_p1, const Text& f_p2, const Text& acc_p3);

std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>> typed_forward_arm(const crate::lower::model::ForDef& b_p0, const crate::lower::model::Ex& segs_p1);

std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>> typed_gen_arm(const crate::lower::model::GenDef& gd_p0);

crate::lower::model::MethDef typed_dispatch(const Sinks& sk_p0, const Text& name_p1, const Nat& scope_p2);

crate::lower::node_::HostDef dummy_host();

Array<Nat> sort_nats(const Array<Nat>& xs_p0);

Array<crate::lower::model::Do> ask_wake(const Sinks& sk_p0, const Nat& h_p1);

crate::lower::model::MethDef gather_in(const Sinks& sk_p0, const crate::lower::node_::Gn& g_p1);

crate::lower::model::Do decide(const crate::lower::node_::Gn& g_p0);

crate::lower::model::Do updated_decide(const crate::lower::node_::Gn& g_p0);

crate::lower::model::Do pair_decide(const crate::lower::node_::Gn& g_p0, const crate::lower::node_::GnKind& kind_p1);

crate::lower::model::Do wake_by_height(const Array<crate::lower::node_::Gn>& combs_p0, const Array<Nat>& heights_p1);

crate::lower::model::Ex forward_answer(const crate::lower::model::ForDef& b_p0);

bool is_hold(const crate::lower::model::OutTy& out_ty0);

Array<crate::lower::model::MethDef> row_methods(const crate::lower::node_::Wx& wx_p0);

Text gn_doc(const crate::lower::node_::Gn& g_p0);

crate::lower::model::Do merge_decide(const crate::lower::node_::Gn& g_p0);

}  // namespace lower::node_::finish


namespace lower::node_::finish {

/// The step machine of `FiringCode`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FiringCode: unbounded fn Sinks, Gn, Ex -> [Do]
struct FiringCode : prism_rtl::Job<Array<crate::lower::model::Do>> {
    Sinks sk_p0;
    crate::lower::node_::Gn g_p1;
    crate::lower::model::Ex x_p2;
    FiringCode(Sinks sk_p0, crate::lower::node_::Gn g_p1, crate::lower::model::Ex x_p2) : sk_p0(std::move(sk_p0)), g_p1(std::move(g_p1)), x_p2(std::move(x_p2)) {}
    prism_rtl::Turn<Array<crate::lower::model::Do>> cycle() const override;
};


/// The step machine of `FinishNode`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FinishNode: unbounded fn Wx, Text, [((Text, OutTy))], Bool -> NodeDef
struct FinishNode : prism_rtl::Job<crate::lower::model::NodeDef> {
    crate::lower::node_::Wx wx0_p0;
    Text qk_p1;
    Array<std::tuple<Text, crate::lower::model::OutTy>> params_p2;
    bool is_row_p3;
    FinishNode(crate::lower::node_::Wx wx0_p0, Text qk_p1, Array<std::tuple<Text, crate::lower::model::OutTy>> params_p2, bool is_row_p3) : wx0_p0(std::move(wx0_p0)), qk_p1(std::move(qk_p1)), params_p2(std::move(params_p2)), is_row_p3(std::move(is_row_p3)) {}
    prism_rtl::Turn<crate::lower::model::NodeDef> cycle() const override;
};


/// The step machine of `FinishPending`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FinishPending: unbounded fn Wx, [Gn] -> (([NodeDef], [Gn]))
struct FinishPending : prism_rtl::Job<std::tuple<Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>>> {
    crate::lower::node_::Wx wx_p0;
    Array<crate::lower::node_::Gn> gns_p1;
    FinishPending(crate::lower::node_::Wx wx_p0, Array<crate::lower::node_::Gn> gns_p1) : wx_p0(std::move(wx_p0)), gns_p1(std::move(gns_p1)) {}
    prism_rtl::Turn<std::tuple<Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>>> cycle() const override;
};


}  // namespace lower::node_::finish

}  // namespace crate
