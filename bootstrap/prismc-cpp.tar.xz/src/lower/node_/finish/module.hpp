// The module `Lower.Node.Finish`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <lower/node_/finish/types.hpp>
#include "elem.types.hpp"
#include <lower/node_/types.hpp>
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace lower::node_::finish {

Array<crate::lower::node_::Gn> heights(const Array<crate::lower::node_::Gn>& gns);

crate::lower::node_::Gn height_step(const Array<crate::lower::node_::Gn>& gns, const crate::lower::node_::Gn& n);

bool is_comb(const crate::lower::node_::GnKind& k);

bool feeds(const crate::lower::node_::Sk& sk0, const crate::lower::node_::Gn& n);

bool writes(const Text& f, const crate::lower::node_::Gn& n);

bool moves(const crate::lower::node_::Read& r, const crate::lower::node_::Gn& n);

Array<crate::lower::node_::Read> reads_closed(const Map<Text, Array<crate::lower::node_::Read>>& dyn_, const Array<crate::lower::node_::Read>& reads);

Array<crate::lower::node_::Read> getter_reads(const Map<Text, Array<crate::lower::node_::Read>>& dyn_, const crate::lower::node_::Read& read1);

bool reaches_snap(const Array<Text>& roots, const Array<crate::lower::node_::Read>& reads);

Array<Text> snap_names(const crate::lower::node_::Wx& wx);

Text wake_const(const Array<Nat>& heights_, const Nat& h);

crate::lower::model::Do self_call(const Text& m, const Array<crate::lower::model::Ex>& args);

Array<crate::lower::model::Do> sink_code(const Sinks& sk, const crate::lower::node_::Sk& target, const crate::lower::model::Ex& y);

Array<crate::lower::model::Do> hold_written(const Sinks& sk, const Text& f);

crate::lower::model::Ex host_field_ex(const crate::lower::node_::Wx& wx, const crate::lower::model::Pos_& pos);

Array<crate::lower::model::Do> moved_marks(const Sinks& sk, const Text& f);

Array<crate::lower::model::Do> moved_by(const Sinks& sk, const crate::lower::node_::Read& r);

Array<crate::lower::model::Do> source_marks(const crate::lower::node_::Wx& wx, const crate::lower::node_::Read& r);

Array<crate::lower::node_::SnapDef> snaps_behind(const crate::lower::node_::Wx& wx, const crate::lower::node_::Read& r);

bool lists_build(const Sinks& sk, const crate::lower::node_::Read& r);

Array<crate::lower::model::Do> firing_code(const Sinks& sk, const crate::lower::node_::Gn& g, const crate::lower::model::Ex& x);

prism_rtl::JobRef<Array<crate::lower::model::Do>> start_firing_code(Sinks sk, crate::lower::node_::Gn g, crate::lower::model::Ex x);

crate::lower::model::NodeDef finish_node(const crate::lower::node_::Wx& wx0, const Text& qk, const Array<std::tuple<Text, crate::lower::model::OutTy>>& params, const bool& is_row);

prism_rtl::JobRef<crate::lower::model::NodeDef> start_finish_node(crate::lower::node_::Wx wx0, Text qk, Array<std::tuple<Text, crate::lower::model::OutTy>> params, bool is_row);

bool is_generation(const crate::lower::node_::Wx& wx, const Text& name);

Array<crate::lower::model::MethDef> flatten_methods(const Sinks& sk);

crate::lower::model::MethDef host_moved(const Sinks& sk, const crate::lower::node_::HostDef& h);

Array<crate::lower::model::Do> build_steps(const Sinks& sk, const bool& at_build);

crate::lower::model::Do snap_take_at_build(const crate::lower::node_::SnapDef& sn);

crate::lower::model::Do snap_take(const Sinks& sk, const crate::lower::node_::SnapDef& sn);

crate::lower::model::MethDef snap_publish(const Sinks& sk, const crate::lower::node_::SnapDef& sn);

crate::lower::model::MethDef gathered_moved(const crate::lower::node_::SnapDef& sn);

crate::lower::model::MethDef document_getter(const crate::lower::node_::Wx& wx);

crate::lower::model::MethDef document_moved(const Text& m);

Array<crate::lower::model::Do> document_body(const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Do>(std::tuple<crate::lower::model::Ex, crate::lower::model::Ex>)>& add_fn, const Array<crate::lower::node_::Place>& places, const Array<crate::lower::model::ForDef>& builders, const Array<crate::lower::model::GenDef>& gens);

crate::lower::model::Do map_insert(const crate::lower::model::Ex& path_, const crate::lower::model::Ex& e);

crate::lower::model::Do vec_push(const crate::lower::model::Ex& path_, const crate::lower::model::Ex& e);

std::tuple<crate::lower::model::Pa, crate::lower::model::Ex> dyn_answer_arm(const Sinks& sk, const crate::lower::model::Pos_& pos, const Text& f, const crate::lower::model::OutTy& t);

Array<crate::lower::model::Do> dyn_place_write(const Sinks& sk, const Text& f, const crate::lower::model::Ex& value);

Array<crate::lower::model::Do> updated_gaps(const crate::lower::node_::Wx& wx, const Array<crate::lower::node_::Gn>& gns, const bool& is_gen);

std::tuple<Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>> finish_pending(const crate::lower::node_::Wx& wx, const Array<crate::lower::node_::Gn>& gns);

prism_rtl::JobRef<std::tuple<Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>>> start_finish_pending(crate::lower::node_::Wx wx, Array<crate::lower::node_::Gn> gns);

Nat parent_floor(const crate::lower::node_::Wx& wx, const Array<crate::lower::node_::Gn>& gns, const Array<crate::lower::node_::Read>& reads);

bool writes_hold(const crate::lower::node_::Gn& g, const Text& f);

bool sink_writes_hold(const crate::lower::node_::Sk& sk0, const Text& f);

crate::lower::node_::Gn with_floor(const crate::lower::node_::Gn& g, const Nat& h);

crate::lower::node_::Gn with_height(const crate::lower::node_::Gn& g, const Nat& h);

Array<Text> row_hears(const crate::lower::node_::Wx& wx);

Array<crate::lower::model::Do> row_written(const crate::lower::node_::Wx& wx, const crate::lower::node_::RowMarks& rm, const crate::lower::node_::Read& r);

Array<crate::lower::model::Do> patch_place(const crate::lower::node_::Wx& wx, const crate::lower::node_::Place& p_);

bool emits(const crate::lower::node_::Wx& wx, const crate::lower::model::Pos_& pos);

Array<crate::lower::model::Do> result_told(const crate::lower::model::Ex& node_);

Array<crate::lower::model::Do> result_moved(const crate::lower::model::Ex& node_);

crate::lower::model::Do result_kept(const crate::lower::model::Ex& node_);

crate::lower::model::Do result_tell();

Array<crate::lower::model::Do> adoption(const crate::lower::node_::FlatDef& fl);

crate::lower::model::Ex place_at(const crate::lower::node_::Wx& wx, const Text& recv, const crate::lower::model::Pos_& pos);

crate::lower::model::Pa pos_pat(const crate::lower::model::Pos_& pos, const Array<crate::lower::model::Pa>& tail);

Array<crate::lower::model::Pa> key_tail();

Array<crate::lower::model::Pa> gen_tail();

std::optional<Text> hosted_rows(const crate::lower::node_::Wx& wx);

Array<crate::lower::model::Do> root_dyn_patch(const crate::lower::node_::Wx& wx);

std::tuple<crate::lower::model::Pa, crate::lower::model::Ex> answer_arm(const crate::lower::node_::Wx& wx, const crate::lower::model::Pos_& pos, const Nat& id, const crate::lower::model::OutTy& t);

std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>> typed_answer_arm(const crate::lower::node_::Wx& wx, const crate::lower::model::Pos_& pos, const Nat& id, const Text& acc);

std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>> typed_dyn_arm(const Sinks& sk, const crate::lower::model::Pos_& pos, const Text& f, const Text& acc);

std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>> typed_forward_arm(const crate::lower::model::ForDef& b, const crate::lower::model::Ex& segs);

std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>> typed_gen_arm(const crate::lower::model::GenDef& gd);

crate::lower::model::MethDef typed_dispatch(const Sinks& sk, const Text& name, const Nat& scope);

crate::lower::node_::HostDef dummy_host();

Array<Nat> sort_nats(const Array<Nat>& xs);

Array<crate::lower::model::Do> ask_wake(const Sinks& sk, const Nat& h);

crate::lower::model::MethDef gather_in(const Sinks& sk, const crate::lower::node_::Gn& g);

crate::lower::model::Do decide(const crate::lower::node_::Gn& g);

crate::lower::model::Do updated_decide(const crate::lower::node_::Gn& g);

crate::lower::model::Do pair_decide(const crate::lower::node_::Gn& g, const crate::lower::node_::GnKind& kind);

crate::lower::model::Do wake_by_height(const Array<crate::lower::node_::Gn>& combs, const Array<Nat>& heights_);

crate::lower::model::Ex forward_answer(const crate::lower::model::ForDef& b);

bool is_hold(const crate::lower::model::OutTy& out_ty0);

Array<crate::lower::model::MethDef> row_methods(const crate::lower::node_::Wx& wx);

Text gn_doc(const crate::lower::node_::Gn& g);

crate::lower::model::Do merge_decide(const crate::lower::node_::Gn& g);

}  // namespace lower::node_::finish


namespace lower::node_::finish {

/// The step machine of `FiringCode`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FiringCode: unbounded fn Sinks, Gn, Ex -> [Do]
struct FiringCode : prism_rtl::Job<Array<crate::lower::model::Do>> {
    Sinks sk;
    crate::lower::node_::Gn g;
    crate::lower::model::Ex x;
    FiringCode(Sinks sk, crate::lower::node_::Gn g, crate::lower::model::Ex x) : sk(std::move(sk)), g(std::move(g)), x(std::move(x)) {}
    prism_rtl::Turn<Array<crate::lower::model::Do>> cycle() const override;
};


/// The step machine of `FinishNode`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FinishNode: unbounded fn Wx, Text, [((Text, OutTy))], Bool -> NodeDef
struct FinishNode : prism_rtl::Job<crate::lower::model::NodeDef> {
    crate::lower::node_::Wx wx0;
    Text qk;
    Array<std::tuple<Text, crate::lower::model::OutTy>> params;
    bool is_row;
    FinishNode(crate::lower::node_::Wx wx0, Text qk, Array<std::tuple<Text, crate::lower::model::OutTy>> params, bool is_row) : wx0(std::move(wx0)), qk(std::move(qk)), params(std::move(params)), is_row(std::move(is_row)) {}
    prism_rtl::Turn<crate::lower::model::NodeDef> cycle() const override;
};


/// The step machine of `FinishPending`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FinishPending: unbounded fn Wx, [Gn] -> (([NodeDef], [Gn]))
struct FinishPending : prism_rtl::Job<std::tuple<Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>>> {
    crate::lower::node_::Wx wx;
    Array<crate::lower::node_::Gn> gns;
    FinishPending(crate::lower::node_::Wx wx, Array<crate::lower::node_::Gn> gns) : wx(std::move(wx)), gns(std::move(gns)) {}
    prism_rtl::Turn<std::tuple<Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>>> cycle() const override;
};


}  // namespace lower::node_::finish

}  // namespace crate
