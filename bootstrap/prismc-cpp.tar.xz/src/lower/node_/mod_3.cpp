// The module `Lower.Node`, from `target/bootstrap/cpp-src/prismc/lower/node/mod.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <lower/node_/module.hpp>
#include <lower/model/module.hpp>
#include <lower/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/env/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/passes/module.hpp>
#include <check/shrink/module.hpp>
#include <check/typed/module.hpp>
#include <check/types/module.hpp>
#include <syntax/module.hpp>
#include <syntax/lexer/module.hpp>
#include <lower/node_/generic.hpp>
#include <check/env/generic.hpp>
#include <syntax/lexer/generic.hpp>

namespace crate::lower::node_ {

/// OverParent: fn Ex -> Ex
crate::lower::model::Ex over_parent(const crate::lower::model::Ex& x) {
    if (prism_rtl::is<crate::lower::model::Ex::XSelf>(x)) {
        return parent_ref();
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XField>(x).a0;
        auto&& f = prism_rtl::as<crate::lower::model::Ex::XField>(x).a1;
        return crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(over_parent(y)), f});
    }
    if (prism_rtl::is<crate::lower::model::Ex::XPart>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XPart>(x).a0;
        auto&& k = prism_rtl::as<crate::lower::model::Ex::XPart>(x).a1;
        return crate::lower::model::Ex(crate::lower::model::Ex::XPart{prism_rtl::rc(over_parent(y)), k});
    }
    if (prism_rtl::is<crate::lower::model::Ex::XMethod>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XMethod>(x).a0;
        auto&& m = prism_rtl::as<crate::lower::model::Ex::XMethod>(x).a1;
        auto&& xs = prism_rtl::as<crate::lower::model::Ex::XMethod>(x).a2;
        return crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(over_parent(y)), m, xs});
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUpgrade>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XUpgrade>(x).a0;
        return crate::lower::model::Ex(crate::lower::model::Ex::XUpgrade{prism_rtl::rc(over_parent(y))});
    }
    {
        return crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(parent_ref()), crate::lower::place_stem(x)});
    }
}


/// let parentRef
crate::lower::model::Ex parent_ref() {
    return crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XUpgrade{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("parent")}))})), Text::lit("expect"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{Text::lit("the block outlives its rows")})})});
}


/// let parentArg
crate::lower::model::Ex parent_arg() {
    return crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XUpgrade{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("parent")}))})), Text::lit("expect"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{Text::lit("the block outlives its rows")})})});
}


/// WithPort: fn Wx, Text -> Wx
Wx with_port(const Wx& wx, const Text& pname) {
    Wx this_ = wx;
    this_.ports = crate::prelude::push(this_.ports, pname);
    return this_;
}


/// RebuildLine: unbounded fn Wx, Env, Env, Expr, Block, Expr, ?Bn -> ((Wx, Wres))
std::tuple<Wx, Wres> rebuild_line(const Wx& wx, const crate::lower::Env& benv, const crate::lower::Env& menv, const crate::syntax::Expr& scrut, const crate::syntax::Block& body, const crate::syntax::Expr& e, const std::optional<crate::lower::Bn>& bound_opt) {
    auto lx = wx.lx;
    auto pos = wx.pos;
    auto wx1 = ({
        Wx this_ = wx;
        this_.pos = crate::lower::model::next_pos(this_.pos);
        this_;
    });
    auto [src_ex, reads] = dynamic_expr(wx1, menv, scrut);
    auto vt = crate::lower::out_ty_of(lx, crate::lower::peel(crate::lower::type_at(lx, scrut.span)));
    auto [name, wx2] = fresh_name(wx1, Text::lit("generation"));
    return gives_dynamic(crate::lower::type_at(lx, e.span))
        ? rebuild_dynamic(wx2, menv, body, src_ex, reads, vt, name, pos)
        : ({
        auto [up_id, wx3] = ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Nat, Wx>> _v;
            if (prism_rtl::is_some(bound_opt) && prism_rtl::is<crate::lower::Bn::BnEv>(prism_rtl::some_of(bound_opt))) {
                auto&& er = prism_rtl::as<crate::lower::Bn::BnEv>(prism_rtl::some_of(bound_opt)).a0;
                _v.set(std::tuple{er.node_, wx2});
                goto _done;
            }
            {
                _v.set(add_gn(wx2, prism_rtl::cat(name, "_fired"), crate::lower::out_ty_of(lx, crate::lower::peel(crate::lower::type_at(lx, e.span))), GnKind(GnKind::GnNamed{}), Nat(0u)));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto [cases, wx4] = gen_cases(wx3, menv, body, vt, name);
        auto row_defs = each(cases, [&](const GenCase& c) { return c.node_; });
        auto select = gen_select(wx4, menv, body, cases, pos);
        auto wx5 = ({
            Wx this_ = wx4;
            this_.gens = crate::prelude::push(this_.gens, crate::lower::model::GenDef{.name = name, .pos = pos, .at = place_at(wx, Text::lit("self"), pos), .source = src_ex, .value_ty = vt, .select = select, .transparent = false, .width = Nat(0u)});
            this_.gen_holds = crate::prelude::push(this_.gen_holds, std::tuple{name, reads});
            this_.rows = fold(row_defs, this_.rows, [&](const Array<crate::lower::model::NodeDef>& acc, const crate::lower::model::NodeDef& rd) { return append(crate::prelude::push(acc, rd), rd.children); });
            this_.getters = crate::prelude::push(this_.getters, gen_up(name, gn_of(wx4, up_id).name, gn_of(wx4, up_id).ty));
            this_;
        });
        std::tuple{wx5, Wres(Wres::WrEv{ev_ref_of(wx5, up_id)})};
    });
}


prism_rtl::Turn<std::tuple<Wx, Wres>> RebuildLine::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& scrut = this->scrut;
    const auto& body = this->body;
    const auto& e = this->e;
    const auto& bound_opt = this->bound_opt;
    auto lx = wx.lx;
    auto pos = wx.pos;
    auto wx1 = ({
        Wx this_ = wx;
        this_.pos = crate::lower::model::next_pos(this_.pos);
        this_;
    });
    auto bound_opt_1 = bound_opt;
    auto body_2 = body;
    auto e_3 = e;
    auto menv_4 = menv;
    auto scrut_5 = scrut;
    auto wx_6 = wx;
    return call_then(start_dynamic_expr(wx1, menv_4, scrut_5), [=](std::tuple<crate::lower::model::Ex, Array<Read>> dynamic_expr_156454) {
        return ({
            auto [src_ex, reads] = dynamic_expr_156454;
            call_then(crate::lower::start_out_ty_of(lx, crate::lower::peel(crate::lower::type_at(lx, scrut_5.span))), [=](crate::lower::model::OutTy out_ty_of_156496) {
            return ({
                auto vt = out_ty_of_156496;
                auto [name, wx2] = fresh_name(wx1, Text::lit("generation"));
                gives_dynamic(crate::lower::type_at(lx, e_3.span))
                ? prism_rtl::finished(rebuild_dynamic(wx2, menv_4, body_2, src_ex, reads, vt, name, pos))
                : ({
                auto [up_id, wx3] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<Nat, Wx>> _v;
                    if (prism_rtl::is_some(bound_opt) && prism_rtl::is<crate::lower::Bn::BnEv>(prism_rtl::some_of(bound_opt))) {
                        auto&& er = prism_rtl::as<crate::lower::Bn::BnEv>(prism_rtl::some_of(bound_opt)).a0;
                        _v.set(std::tuple{er.node_, wx2});
                        goto _done;
                    }
                    {
                        _v.set(add_gn(wx2, prism_rtl::cat(name, "_fired"), crate::lower::out_ty_of(lx, crate::lower::peel(crate::lower::type_at(lx, e_3.span))), GnKind(GnKind::GnNamed{}), Nat(0u)));
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto [cases, wx4] = gen_cases(wx3, menv_4, body_2, vt, name);
                auto row_defs = each(cases, [&](const GenCase& c) { return c.node_; });
                auto select = gen_select(wx4, menv_4, body_2, cases, pos);
                auto wx5 = ({
                    Wx this_ = wx4;
                    this_.gens = crate::prelude::push(this_.gens, crate::lower::model::GenDef{.name = name, .pos = pos, .at = place_at(wx_6, Text::lit("self"), pos), .source = src_ex, .value_ty = vt, .select = select, .transparent = false, .width = Nat(0u)});
                    this_.gen_holds = crate::prelude::push(this_.gen_holds, std::tuple{name, reads});
                    this_.rows = fold(row_defs, this_.rows, [&](const Array<crate::lower::model::NodeDef>& acc, const crate::lower::model::NodeDef& rd) { return append(crate::prelude::push(acc, rd), rd.children); });
                    this_.getters = crate::prelude::push(this_.getters, gen_up(name, gn_of(wx4, up_id).name, gn_of(wx4, up_id).ty));
                    this_;
                });
                (prism_rtl::finished(std::tuple{wx5, Wres(Wres::WrEv{ev_ref_of(wx5, up_id)})}));
            });
            });
        });
        });
    });
}


/// `Start RebuildLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Wx, Wres>> start_rebuild_line(Wx wx, crate::lower::Env benv, crate::lower::Env menv, crate::syntax::Expr scrut, crate::syntax::Block body, crate::syntax::Expr e, std::optional<crate::lower::Bn> bound_opt) {
    return prism_rtl::make_rc<RebuildLine>(wx, benv, menv, scrut, body, e, bound_opt);
}


/// GivesDynamic: fn Ty -> Bool
bool gives_dynamic(const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& m157715_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& m157715_0_1 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        if (m157715_0_0 == Text::lit("$")) {
            if (prism_rtl::is<crate::check::types::Ty::TySig>(m157715_0_1)) {
                auto&& m157715_0_1_r_0 = prism_rtl::as<crate::check::types::Ty::TySig>(m157715_0_1).a0;
                if (m157715_0_1_r_0 == Text::lit("$")) {
                    return true;
                }
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a0;
        return gives_dynamic(i);
    }
    {
        return false;
    }
}


/// RebuildDynamic: unbounded fn Wx, Env, Block, Ex, [Read], OutTy, Text, Pos -> ((Wx, Wres))
std::tuple<Wx, Wres> rebuild_dynamic(const Wx& wx, const crate::lower::Env& menv, const crate::syntax::Block& body, const crate::lower::model::Ex& src_ex, const Array<Read>& reads, const crate::lower::model::OutTy& vt, const Text& name, const crate::lower::model::Pos_& pos) {
    auto row_name = prism_rtl::cat(wx.node_, "Gen", row_suffix(wx));
    auto whole = gen_row_of(wx, menv, body, vt, row_name, name);
    auto&& _m = whole.dyn_result;
    if (prism_rtl::is_none(_m)) {
        auto wx2 = ({
            Wx this_ = whole->parent;
            this_.build = crate::prelude::push(this_.build, crate::lower::refusal_do(Text::lit("a `rebuild` whose generation gives a dynamic it does not lower")));
            this_;
        });
        return std::tuple{wx2, Wres(Wres::WrUnit{})};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& rt = prism_rtl::some_of(_m);
        auto dyn_ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutDyn{prism_rtl::rc(rt)});
        auto result = prism_rtl::cat(name, "_result");
        auto live = prism_rtl::cat(result, "_live");
        auto what = prism_rtl::cat("the dynamic of the `rebuild` at place ", crate::lower::model::place_text(pos));
        auto tail = append(append(Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XWeak{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})}), hosted_passed(wx)), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})}));
        auto built = crate::lower::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XCall{prism_rtl::cat(whole.node_.name, "::build"), append(Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("path")}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("value")})}), tail)}));
        auto kept = crate::lower::model::Do(crate::lower::model::Do::DoAssign{crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), live})), Text::lit("borrow_mut"), Array<crate::lower::model::Ex>{}}))}), crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")})), Text::lit("result_dynamic"), Array<crate::lower::model::Ex>{}})})})});
        auto marked = crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(result, "_snap")})), Text::lit("mark"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
        auto select = crate::lower::model::Ex(crate::lower::model::Ex::XBlock{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")}), built}), kept, marked}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")}))});
        auto current = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(live)})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}}))})), Text::lit("expect"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{Text::lit("a `rebuild` has a generation from its build on")})})});
        auto wx2 = ({
            Wx this_ = whole->parent;
            this_.gens = crate::prelude::push(this_.gens, crate::lower::model::GenDef{.name = name, .pos = pos, .at = place_at(wx, Text::lit("self"), pos), .source = src_ex, .value_ty = vt, .select = select, .transparent = false, .width = Nat(0u)});
            this_.gen_holds = crate::prelude::push(this_.gen_holds, std::tuple{name, reads});
            this_.rows = append(crate::prelude::push(this_.rows, whole.node_), whole.node_.children);
            this_.taken = append(this_.taken, Array(std::vector{result, live, prism_rtl::cat(result, "_now"), prism_rtl::cat(result, "_snap"), prism_rtl::cat(result, "_publish"), prism_rtl::cat(result, "_moved")}));
            this_.fields = append(this_.fields, Array(std::vector{std::tuple{live, crate::lower::model::OutTy(crate::lower::model::OutTy::OutCell{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(dyn_ty)}))}), Text::lit("the current generation's result, which the snapshot of the `rebuild`'s dynamic is taken from")}, std::tuple{prism_rtl::cat(result, "_snap"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutSnapshot{prism_rtl::rc(dyn_ty)}), prism_rtl::cat("the `rebuild` at place ", crate::lower::model::place_text(pos), "'s dynamic, structural: its snapshots, the generations' results and the lagged dynamic (pick ST)")}}));
            this_.moves = crate::prelude::push(this_.moves, std::tuple{live, crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("RefCell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XNone{})})})});
            this_.inits = crate::prelude::push(this_.inits, std::tuple{prism_rtl::cat(result, "_snap"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Snapshot::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{what})})})});
            this_.getters = append(this_.getters, Array(std::vector{crate::lower::model::MethDef{.name = prism_rtl::cat(result, "_now"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = dyn_ty, .body = Array<crate::lower::model::Do>{}, .tail = current, .doc = Text::lit("The current generation's result: what the snapshot of the `rebuild`'s dynamic is taken from (pick ST).")}, snap_getter(result, dyn_ty, Text::lit("The `rebuild`'s dynamic, its generation's result, a structural dynamic (pick ST): one tick behind the generations, the snapshot of the tick before the tick the read point is after."))}));
            this_.snaps = crate::prelude::push(this_.snaps, SnapDef{.name = result, .live = prism_rtl::cat(result, "_now"), .ty = dyn_ty, .eq = false, .builder = name, .before = false, .what = what});
            this_;
        });
        return std::tuple{wx2, Wres(Wres::WrDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), result, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{Read(Read::OwnRead{result})}), dyn_ty})};
    }
    prism_rtl::unreachable("no arm matched");
}


/// ClauseWidgetLine: unbounded fn Wx, Env, Expr, Block, Text, ValInfo, Expr -> ((Wx, Wres))
std::tuple<Wx, Wres> clause_widget_line(const Wx& wx, const crate::lower::Env& menv, const crate::syntax::Expr& scrut, const crate::syntax::Block& call, const Text& qk, const crate::check::env::ValInfo& v_, const crate::syntax::Expr& e) {
    auto lx = wx.lx;
    auto pos = wx.pos;
    auto [src_ex, reads] = dynamic_expr(wx, menv, scrut);
    auto vt = crate::lower::out_ty_of(lx, crate::lower::peel(crate::lower::type_at(lx, scrut.span)));
    auto [name, wx1] = fresh_name(wx, Text::lit("generation"));
    auto [up_id, wx2] = add_gn(wx1, prism_rtl::cat(name, "_fired"), crate::lower::out_ty_of(lx, crate::lower::out_of(crate::lower::type_at(lx, e.span))), GnKind(GnKind::GnNamed{}), Nat(0u));
    auto clauses = crate::lower::clauses_of(lx.g, qk);
    auto row_name = prism_rtl::cat(wx.node_, "Gen", row_suffix(wx));
    auto [rows, wx3] = run_to_end(fold_job(crate::check::errors::range0(len(clauses)), std::tuple{Array<ClauseRow>{}, wx2}, ({
        auto clauses_1 = clauses;
        auto menv_2 = menv;
        auto v__3 = v_;
        auto row_name_4 = row_name;
        auto name_5 = name;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<ClauseRow>, Wx>>(std::tuple<std::tuple<Array<ClauseRow>, Wx>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<ClauseRow>, Wx>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto clauses_1_6 = clauses_1;
            auto menv_2_6 = menv_2;
            auto v__3_6 = v__3;
            auto row_name_4_6 = row_name_4;
            auto name_5_6 = name_5;
            entered(once_job([=]() {
            return ({
                auto [acc, w] = p0;
                auto i = p1;
                ({
                auto c = or_(index(clauses_1_6, i), crate::lower::dummy_clause());
                auto cr = clause_row_of(w, menv_2_6, c, v__3_6, prism_rtl::cat(row_name_4_6, i), name_5_6, true);
                (prism_rtl::finished(std::tuple{crate::prelude::push(acc, cr), cr->parent}));
            });
            });
        }));
        });
    }));
    })));
    auto width = fold(rows, Nat(0u), [&](const Nat& acc, const ClauseRow& cr) { return crate::prelude::max(acc, cr.width); });
    auto cases = each(rows, [&](const ClauseRow& cr) { return cr.case_; });
    return is_hosted_scope(wx)
        ? ({
        auto wx4 = ({
            Wx this_ = wx3;
            this_.build = crate::prelude::push(this_.build, crate::lower::refusal_do(Text::lit("a widget of several clauses in a static position of a hosted scope")));
            this_;
        });
        std::tuple{wx4, Wres(Wres::WrUnit{})};
    })
        : ({
        auto select = gen_select(wx3, menv, call, cases, pos);
        auto wx4 = ({
            Wx this_ = wx3;
            this_.pos = crate::lower::model::Pos_{.scope = pos.scope, .at = pos.at + width};
            this_.gens = crate::prelude::push(this_.gens, crate::lower::model::GenDef{.name = name, .pos = pos, .at = place_at(wx, Text::lit("self"), pos), .source = src_ex, .value_ty = vt, .select = select, .transparent = true, .width = width});
            this_.gen_holds = crate::prelude::push(this_.gen_holds, std::tuple{name, reads});
            this_.rows = fold(cases, this_.rows, [&](const Array<crate::lower::model::NodeDef>& acc, const GenCase& gc) { return append(crate::prelude::push(acc, gc.node_), gc.node_.children); });
            this_.getters = crate::prelude::push(this_.getters, gen_up(name, gn_of(wx3, up_id).name, gn_of(wx3, up_id).ty));
            this_;
        });
        std::tuple{wx4, Wres(Wres::WrEv{ev_ref_of(wx4, up_id)})};
    });
}


/// IsHostedScope: fn Wx -> Bool
bool is_hosted_scope(const Wx& wx) {
    return (wx.pos.scope > Nat(0u)) || prism_rtl::is_some(wx.hosted_by);
}


/// GenCases: unbounded fn Wx, Env, Block, OutTy, Text -> (([GenCase], Wx))
std::tuple<Array<GenCase>, Wx> gen_cases(const Wx& wx, const crate::lower::Env& menv, const crate::syntax::Block& body, const crate::lower::model::OutTy& vt, const Text& name) {
    auto lx = wx.lx;
    auto row_name = prism_rtl::cat(wx.node_, "Gen", row_suffix(wx));
    auto&& _m = clause_call(lx, body);
    if (prism_rtl::is_some(_m)) {
        auto&& qk = std::get<0>(prism_rtl::some_of(_m));
        auto&& args = std::get<1>(prism_rtl::some_of(_m));
        auto clauses = crate::lower::clauses_of(lx.g, qk);
        auto v_ = crate::lower::val_of(lx, qk);
        return run_to_end(fold_job(crate::check::errors::range0(len(clauses)), std::tuple{Array<GenCase>{}, wx}, ({
            auto clauses_1 = clauses;
            auto menv_2 = menv;
            auto v__3 = v_;
            auto row_name_4 = row_name;
            auto name_5 = name;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<GenCase>, Wx>>(std::tuple<std::tuple<Array<GenCase>, Wx>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<GenCase>, Wx>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto clauses_1_6 = clauses_1;
                auto menv_2_6 = menv_2;
                auto v__3_6 = v__3;
                auto row_name_4_6 = row_name_4;
                auto name_5_6 = name_5;
                entered(once_job([=]() {
                return ({
                    auto [acc, w] = p0;
                    auto i = p1;
                    ({
                    auto c = or_(index(clauses_1_6, i), crate::lower::dummy_clause());
                    auto cr = clause_row_of(w, menv_2_6, c, v__3_6, prism_rtl::cat(row_name_4_6, i), name_5_6, false);
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc, cr.case_), cr->parent}));
                });
                });
            }));
            });
        }));
        })));
    }
    if (prism_rtl::is_none(_m)) {
        auto whole = gen_row_of(wx, menv, body, vt, row_name, name);
        return std::tuple{Array(std::vector{GenCase{.node_ = whole.node_, .params = Array(std::vector{std::tuple{Text::lit("value"), vt}}), .pat = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .passed = Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("value")})})}}), whole->parent};
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?ClauseCall: fn Lx, Block -> ?((Text, [Arg]))
std::optional<std::tuple<Text, Array<crate::syntax::Arg>>> clause_call(const crate::lower::Lx& lx, const crate::syntax::Block& body) {
    auto&& _m = body.stmts;
    {
        auto&& m165664_0 = _m;
        if (m165664_0.size() == 1u) {
            {
                auto&& _c1 = index(m165664_0, Nat(0u));
                if (prism_rtl::is_some(_c1)) {
                    auto&& st = prism_rtl::some_of(_c1);
                    auto&& _m = st.kind;
                    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
                        auto&& x = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                        return clause_call_x(lx, x);
                    }
                    if (prism_rtl::is<crate::syntax::StmtKind::SIgnore>(_m)) {
                        auto&& x = prism_rtl::as<crate::syntax::StmtKind::SIgnore>(_m).a0;
                        return clause_call_x(lx, x);
                    }
                    {
                        return std::optional<std::tuple<Text, Array<crate::syntax::Arg>>>{};
                    }
                }
            }
        }
    }
    {
        return std::optional<std::tuple<Text, Array<crate::syntax::Arg>>>{};
    }
}


/// ?ClauseCallX: fn Lx, Expr -> ?((Text, [Arg]))
std::optional<std::tuple<Text, Array<crate::syntax::Arg>>> clause_call_x(const crate::lower::Lx& lx, const crate::syntax::Expr& x) {
    auto&& _m = x.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        auto qk = crate::lower::blueprint_qk(lx, c);
        return len(crate::lower::clauses_of(lx.g, qk)) > Nat(1u)
            ? std::optional(std::tuple{qk, args})
            : std::optional<std::tuple<Text, Array<crate::syntax::Arg>>>{};
    }
    {
        return std::optional<std::tuple<Text, Array<crate::syntax::Arg>>>{};
    }
}


/// ClauseRowOf: unbounded fn Wx, Env, FnClause, ValInfo, Text, Text, Bool -> ClauseRow
ClauseRow clause_row_of(const Wx& wx, const crate::lower::Env& menv, const crate::syntax::FnClause& c, const crate::check::env::ValInfo& v_, const Text& row_name, const Text& gen_name, const bool& transparent) {
    auto up_name = prism_rtl::cat(gen_name, "_up");
    auto lx = wx.lx;
    auto lxc = crate::lower::in_module_at(lx, v_->file, v_.home, lx.site);
    auto ptys = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
        auto&& _m = v_.scheme.ty;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            _v.set(ps);
            goto _done;
        }
        {
            _v.set(Array<crate::check::types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto pos = run_to_end(each_job(crate::check::errors::range0(len(c.params)), ({
        auto lxc_1 = lxc;
        auto c_2 = c;
        auto ptys_3 = ptys;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto lxc_1_4 = lxc_1;
            auto c_2_4 = c_2;
            auto ptys_3_4 = ptys_3;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(crate::lower::RustPat(lxc_1_4, or_(index(c_2_4.params, i), crate::lower::dummy_pat()), or_(index(ptys_3_4, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), crate::lower::Holding(crate::lower::Holding::ByRef{}), prism_rtl::cat("c", i)))));
            });
        }));
        });
    })));
    })));
    auto pa = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(pos, [&](const crate::lower::PatOut& o) { return o.pa; })});
    auto binds = fold(pos, Map<Text, crate::lower::Bn>{}, [&](const Map<Text, crate::lower::Bn>& m, const crate::lower::PatOut& o) {
        return fold(o.binds, m, [&](const Map<Text, crate::lower::Bn>& m2, const std::tuple<Text, crate::lower::Bn>& _p1) {
            auto&& n = std::get<0>(_p1);
            auto&& b = std::get<1>(_p1);
            return insert(m2, n, b);
        });
    });
    auto binders = filter(run_to_end(fold_job(c.params, Array<std::tuple<Text, crate::syntax::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto p_ = p1;
                call_then(crate::check::env::start_pattern_binders(p_), [=](Array<std::tuple<Text, crate::syntax::Range>> pattern_binders_167177) { return prism_rtl::finished(append(acc, pattern_binders_167177)); });
            });
        }));
    })))), [&](const std::tuple<Text, crate::syntax::Range>& _p0) {
        auto&& bn = std::get<0>(_p0);
        return crate::check::env::has_key(binds, bn);
    });
    auto fields = run_to_end(each_job(binders, ({
        auto lxc_1 = lxc;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::lower::model::OutTy, Text>>(std::tuple<Text, crate::syntax::Range>)>>(prism_rtl::rc([=](std::tuple<Text, crate::syntax::Range> p0) {
        return ({
            auto lxc_1_2 = lxc_1;
            entered(once_job([=]() {
            return ({
                auto [bn, r] = p0;
                call_then(crate::lower::start_out_ty_of(lxc_1_2, crate::lower::peel(crate::lower::binder_ty(lxc_1_2, r))), [=](crate::lower::model::OutTy out_ty_of_167291) { return prism_rtl::finished(std::tuple{crate::lower::snake(bn), out_ty_of_167291, bn}); });
            });
        }));
        });
    }));
    })));
    auto row_fields = crate::prelude::push(each(fields, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& f = std::get<0>(_p0);
        auto&& t = std::get<1>(_p0);
        auto&& bn = std::get<2>(_p0);
        return std::tuple{f, t, prism_rtl::cat("`", bn, "`")};
    }), std::tuple{Text::lit("parent"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutWeak{wx.node_}), Text::lit("the node of the `rebuild`")});
    auto row_inits = each(fields, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& f = std::get<0>(_p0);
        return std::tuple{f, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{f}))})};
    });
    auto row_taken = append(node_hooks(), crate::prelude::push(each(fields, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& f = std::get<0>(_p0);
        return f;
    }), Text::lit("parent")));
    auto r00 = new_wx(lxc, row_name, row_fields, row_inits, Array(std::vector{std::tuple{Text::lit("parent"), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("parent")})}}), Array<crate::lower::model::MethDef>{}, Map<Text, Array<Read>>{}, row_taken, wx.depth, hosted_rows(wx));
    auto r0 = transparent
        ? ({
        Wx this_ = r00;
        this_.pos = wx.pos;
        this_;
    })
        : r00;
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<crate::syntax::Block> _v;
        auto&& _m = c.body;
        if (prism_rtl::is<crate::syntax::FnBody::BodyBlock>(_m)) {
            auto&& b = prism_rtl::as<crate::syntax::FnBody::BodyBlock>(_m).a0;
            _v.set(b);
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::FnBody::BodyExpr>(_m)) {
            auto&& x = prism_rtl::as<crate::syntax::FnBody::BodyExpr>(_m).a0;
            _v.set(crate::syntax::Block{.stmts = Array(std::vector{crate::syntax::Stmt{.kind = crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{x}), .span = x.span}}), .inline_ = true, .span = x.span});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto [p1, r1, ports] = row_env(wx, r0, menv, body);
    auto [be, me] = fold(fields, std::tuple{crate::lower::empty_env(), crate::lower::empty_env()}, [&](const std::tuple<crate::lower::Env, crate::lower::Env>& _p0, const std::tuple<Text, crate::lower::model::OutTy, Text>& _p1) {
        auto&& b = std::get<0>(_p0);
        auto&& m = std::get<1>(_p0);
        auto&& f = std::get<0>(_p1);
        auto&& t = std::get<1>(_p1);
        auto&& bn = std::get<2>(_p1);
        return bind_plain(b, m, bn, f, t);
    });
    auto r2 = block_into(r1, be, me, body);
    auto r3 = ({
        __label__ _done;
        prism_rtl::Slot<Wx> _v;
        auto&& _m = r2->result;
        if (prism_rtl::is<Wres::WrEv>(_m)) {
            auto&& r = prism_rtl::as<Wres::WrEv>(_m).a0;
            _v.set(connect(r2, r, Sk(Sk::SkUp{up_name})));
            goto _done;
        }
        {
            _v.set(r2);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto node_ = finish_node(r3, row_name, append(crate::prelude::push(each(fields, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& f = std::get<0>(_p0);
        auto&& t = std::get<1>(_p0);
        return std::tuple{f, t};
    }), std::tuple{Text::lit("parent"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutWeak{wx.node_})}), hosted_params(wx)), true);
    auto p2 = gen_marked(p1, gen_name, r3);
    auto passed = each(fields, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& f = std::get<0>(_p0);
        auto&& t = std::get<1>(_p0);
        auto&& bn = std::get<2>(_p0);
        return ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::Ex> _v;
            auto&& _m = crate::prelude::get(binds, bn);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<crate::lower::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& mode = prism_rtl::as<crate::lower::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                auto&& bt = prism_rtl::as<crate::lower::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(crate::lower::own(crate::lower::Vl(crate::lower::Vl::VlPlace{rs, mode, bt})));
                goto _done;
            }
            {
                _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{f}))}));
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return ClauseRow{.case_ = GenCase{.node_ = node_, .params = each(fields, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& f = std::get<0>(_p0);
        auto&& t = std::get<1>(_p0);
        return std::tuple{f, t};
    }), .pat = pa, .conds = fold(pos, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc, const crate::lower::PatOut& o) { return append(acc, o.conds); }), .passed = passed}, .parent = p2, .width = or_(r2.pos.at.checked_sub(r0.pos.at), Nat(0u))};
}


/// GenRowOf: unbounded fn Wx, Env, Block, OutTy, Text, Text -> GenRow
GenRow gen_row_of(const Wx& wx, const crate::lower::Env& menv, const crate::syntax::Block& body, const crate::lower::model::OutTy& vt, const Text& row_name, const Text& gen_name) {
    auto lx = wx.lx;
    auto up_name = prism_rtl::cat(gen_name, "_up");
    auto r0 = new_wx(lx, row_name, Array(std::vector{std::tuple{Text::lit("value"), vt, Text::lit("the generation's value, `_`")}, std::tuple{Text::lit("parent"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutWeak{wx.node_}), Text::lit("the node of the `rebuild`")}}), Array(std::vector{std::tuple{Text::lit("value"), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("value")}))})}}), Array(std::vector{std::tuple{Text::lit("parent"), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("parent")})}}), Array<crate::lower::model::MethDef>{}, Map<Text, Array<Read>>{}, append(node_hooks(), Array(std::vector{Text::lit("value"), Text::lit("parent"), Text::lit("result"), Text::lit("result_dynamic")})), wx.depth, hosted_rows(wx));
    auto [p1, r1, ports] = row_env(wx, r0, menv, body);
    auto be = crate::lower::bind(build_spelling(ports), Text::lit("_"), crate::lower::Bn(crate::lower::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("value")}), crate::lower::Holding(crate::lower::Holding::Owned{}), vt}));
    auto me = crate::lower::bind(ports, Text::lit("_"), crate::lower::Bn(crate::lower::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("value")}), crate::lower::Holding(crate::lower::Holding::Owned{}), vt}));
    auto r2 = block_into(r1, be, me, body);
    auto [r3, dyn_result_opt] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Wx, std::optional<crate::lower::model::OutTy>>> _v;
        auto&& _m = r2->result;
        if (prism_rtl::is<Wres::WrEv>(_m)) {
            auto&& r = prism_rtl::as<Wres::WrEv>(_m).a0;
            _v.set(std::tuple{connect(r2, r, Sk(Sk::SkUp{up_name})), std::optional<crate::lower::model::OutTy>{}});
            goto _done;
        }
        if (prism_rtl::is<Wres::WrDyn>(_m)) {
            auto&& ex = prism_rtl::as<Wres::WrDyn>(_m).a0;
            auto&& result_reads = prism_rtl::as<Wres::WrDyn>(_m).a1;
            auto&& rt = prism_rtl::as<Wres::WrDyn>(_m).a2;
            _v.set(std::tuple{gen_result(r2, gen_name, ex, result_reads, rt), std::optional(rt)});
            goto _done;
        }
        {
            _v.set(std::tuple{r2, std::optional<crate::lower::model::OutTy>{}});
            goto _done;
        }
    _done:
        _v.take();
    });
    return GenRow{.node_ = finish_node(r3, row_name, append(Array(std::vector{std::tuple{Text::lit("value"), vt}, std::tuple{Text::lit("parent"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutWeak{wx.node_})}}), hosted_params(wx)), true), .parent = gen_marked(p1, gen_name, r3), .dyn_result = dyn_result_opt};
}


/// GenResult: fn Wx, Text, Ex, [Read], OutTy -> Wx
Wx gen_result(const Wx& r, const Text& gen_name, const crate::lower::model::Ex& ex, const Array<Read>& result_reads, const crate::lower::model::OutTy& rt) {
    auto own_behind = filter(reads_closed(r.dyn_reads, result_reads), [&](const Read& rd) {
        return ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            if (prism_rtl::is<Read::OwnRead>(rd)) {
                _v.set(true);
                goto _done;
            }
            if (prism_rtl::is<Read::ParentRead>(rd)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    auto made = crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Dynamic::of"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("cx")})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("me")})), Text::lit("result"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Port::new"), Array<crate::lower::model::Ex>{}})})}))})})});
    auto doc = prism_rtl::cat("The generation's result as a dynamic, which the block keeps while the generation is current; the block hears it move through `", gen_name, "_result_moved`, not through the dynamic's port.");
    Wx this_ = r;
    this_.getters = append(this_.getters, Array(std::vector{crate::lower::model::MethDef{.name = Text::lit("result"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = rt, .body = Array<crate::lower::model::Do>{}, .tail = ex, .doc = Text::lit("The generation's result, which the `rebuild` hands back.")}, crate::lower::model::MethDef{.name = Text::lit("result_dynamic"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxNone{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutDyn{prism_rtl::rc(rt)}), .body = Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("me")}), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})})}), .tail = made, .doc = doc}}));
    this_.result_moved = len(own_behind) > Nat(0u)
        ? std::optional(std::tuple{prism_rtl::cat(gen_name, "_result_moved"), own_behind})
        : std::optional<std::tuple<Text, Array<Read>>>{};
    return this_;
}


/// GenMarked: fn Wx, Text, Wx -> Wx
Wx gen_marked(const Wx& parent, const Text& gen_name, const Wx& row_wx) {
    auto reads = row_place_reads(row_wx);
    return len(reads) == Nat(0u)
        ? parent
        : ({
        Wx this_ = parent;
        this_.row_marks = crate::prelude::push(this_.row_marks, RowMarks{.builder = gen_name, .reads = reads, .wrote = Array<Text>{}, .kind = crate::lower::model::RowKind(crate::lower::model::RowKind::GenerationRow{})});
        this_;
    });
}


/// BuildSpelling: fn Env -> Env
crate::lower::Env build_spelling(const crate::lower::Env& env) {
    return fold(keys(env->names), env, [&](const crate::lower::Env& en, const Text& k) {
        return ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::Env> _v;
            auto&& _m = crate::prelude::get(env->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<crate::lower::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& mode = prism_rtl::as<crate::lower::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                auto&& t = prism_rtl::as<crate::lower::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<crate::lower::Env> _v;
                    auto&& _m = crate::lower::through_parent(rs);
                    if (prism_rtl::is_some(_m)) {
                        auto&& x = prism_rtl::some_of(_m);
                        _v.set(crate::lower::bind(en, k, crate::lower::Bn(crate::lower::Bn::BnLocal{x, mode, t})));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(en);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::Bn::BnDyn>(prism_rtl::some_of(_m)) && prism_rtl::is<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::Bn::BnDyn>(prism_rtl::some_of(_m)).a0)) {
                auto&& rs = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a0;
                auto&& m = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a1;
                auto&& xs = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a2;
                auto&& ds = prism_rtl::as<crate::lower::Bn::BnDyn>(prism_rtl::some_of(_m)).a1;
                auto&& t = prism_rtl::as<crate::lower::Bn::BnDyn>(prism_rtl::some_of(_m)).a2;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<crate::lower::Env> _v;
                    auto&& _m = crate::lower::through_parent(rs);
                    if (prism_rtl::is_some(_m)) {
                        auto&& x = prism_rtl::some_of(_m);
                        _v.set(crate::lower::bind(en, k, crate::lower::Bn(crate::lower::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(x), m, xs}), ds, t})));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(en);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(en);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// GenSelect: unbounded fn Wx, Env, Block, [GenCase], Pos -> Ex
crate::lower::model::Ex gen_select(const Wx& wx, const crate::lower::Env& menv, const crate::syntax::Block& body, const Array<GenCase>& cases, const crate::lower::model::Pos_& pos) {
    auto tail = append(append(Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XWeak{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})}), hosted_passed(wx)), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})}));
    auto&& _m = clause_call(wx.lx, body);
    if (prism_rtl::is_none(_m)) {
        auto&& _m = index(cases, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& c = prism_rtl::some_of(_m);
            return crate::lower::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XCall{prism_rtl::cat(c.node_.name, "::build"), append(Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("path")}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("value")})}), tail)}));
        }
        if (prism_rtl::is_none(_m)) {
            return crate::lower::refusal(Text::lit("a `rebuild` with no generation"));
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_some(_m)) {
        auto&& qk = std::get<0>(prism_rtl::some_of(_m));
        auto&& args = std::get<1>(prism_rtl::some_of(_m));
        auto env = crate::lower::bind(menv, Text::lit("_"), crate::lower::Bn(crate::lower::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("value")}), crate::lower::Holding(crate::lower::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}));
        auto scrut = crate::lower::model::Ex(crate::lower::model::Ex::XTuple{run_to_end(each_job(args, ({
            auto wx_1 = wx;
            auto env_2 = env;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=](crate::syntax::Arg p0) {
            return ({
                auto wx_1_3 = wx_1;
                auto env_2_3 = env_2;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(crate::lower::Argument(wx_1_3.lx, env_2_3, a->value))));
                });
            }));
            });
        })));
        })))});
        auto arms = each(cases, [&](const GenCase& c) {
            return ({
                auto made = crate::lower::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XCall{prism_rtl::cat(c.node_.name, "::build"), append(append(Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("path")}))})}), c.passed), tail)}));
                crate::lower::model::XArm{.pat = c.pat, .conds = c.conds, .body = crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(made), crate::lower::model::OutTy(crate::lower::model::OutTy::OutObj{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Row"), Array<crate::lower::model::OutTy>{}}))})})};
            });
        });
        return crate::lower::own(crate::lower::arms_value(scrut, arms, Text::lit("'select"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutObj{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Row"), Array<crate::lower::model::OutTy>{}}))})));
    }
    prism_rtl::unreachable("no arm matched");
}


/// GenUp: fn Text, Text, OutTy -> MethDef
crate::lower::model::MethDef gen_up(const Text& name, const Text& up_name, const crate::lower::model::OutTy& t) {
    return crate::lower::model::MethDef{.name = prism_rtl::cat(name, "_up"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array(std::vector{std::tuple{Text::lit("v"), t}}), .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = Array(std::vector{self_call(up_name, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")})}))}), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = Text::lit("The current generation's result fires the `rebuild`'s.")};
}


/// GenForwards: fn GenDef -> [((Pa, Ex))]
Array<std::tuple<crate::lower::model::Pa, crate::lower::model::Ex>> gen_forwards(const crate::lower::model::GenDef& gd) {
    return gd.transparent
        ? each(crate::check::errors::range0(gd.width), [&](const Nat& i) {
        return ({
            auto current = crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(gd.name)})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}}))});
            auto body = crate::lower::model::Ex(crate::lower::model::Ex::XBlock{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")}), current}), crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")})), Text::lit("answer"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("at")}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))})}), Array<crate::lower::model::Do>{}})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}))});
            std::tuple{pos_pat(crate::lower::model::Pos_{.scope = gd.pos.scope, .at = gd.pos.at + i}, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaRest{Text::lit("")})})), body};
        });
    })
        : Array(std::vector{std::tuple{pos_pat(gd.pos, gen_tail()), forward_gen(gd)}});
}


/// ForwardGen: fn GenDef -> Ex
crate::lower::model::Ex forward_gen(const crate::lower::model::GenDef& gd) {
    auto current = crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(gd.name)})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}}))});
    auto is_current = crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("=="), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("+"), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("g")}))})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XIndex{Nat(1u)}))})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(gd.name, "_count")})), Text::lit("get"), Array<crate::lower::model::Ex>{}}))});
    return crate::lower::model::Ex(crate::lower::model::Ex::XBlock{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")}), current}), crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIf{is_current, Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")})), Text::lit("answer"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("rest")}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))})}), Array<crate::lower::model::Do>{}})}), Array<crate::lower::model::Do>{}})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}))});
}


/// FlattenLine: unbounded fn Wx, Env, [Arg], ?Bn -> ((Wx, Wres))
std::tuple<Wx, Wres> flatten_line(const Wx& wx, const crate::lower::Env& menv, const Array<crate::syntax::Arg>& args, const std::optional<crate::lower::Bn>& bound_opt) {
    auto outer_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<std::tuple<Text, Text, crate::lower::model::OutTy>>> _v;
        auto&& _m = index(args, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& a = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::optional<std::tuple<Text, Text, crate::lower::model::OutTy>>> _v;
                auto&& _m = a->value.kind;
                if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                    auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::optional<std::tuple<Text, Text, crate::lower::model::OutTy>>> _v;
                        auto&& _m = crate::prelude::get(menv->names, crate::check::env::sname_key(n));
                        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::Bn::BnDyn>(prism_rtl::some_of(_m)) && prism_rtl::is<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::Bn::BnDyn>(prism_rtl::some_of(_m)).a0) && prism_rtl::is<crate::lower::model::OutTy::OutDyn>(prism_rtl::as<crate::lower::Bn::BnDyn>(prism_rtl::some_of(_m)).a2)) {
                            auto&& m175976_0_0_0 = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a0;
                            auto&& m = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a1;
                            auto&& t = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(prism_rtl::as<crate::lower::Bn::BnDyn>(prism_rtl::some_of(_m)).a2).a0;
                            if (prism_rtl::is<crate::lower::model::Ex::XSelf>(m175976_0_0_0)) {
                                _v.set(fold(wx.gens, std::optional<std::tuple<Text, Text, crate::lower::model::OutTy>>{}, [&](const std::optional<std::tuple<Text, Text, crate::lower::model::OutTy>>& acc_opt, const crate::lower::model::GenDef& gd) {
                                    return prism_rtl::cat(gd.name, "_result") == m
                                        ? std::optional(std::tuple{m, gd.name, t})
                                        : acc_opt;
                                }));
                                goto _done;
                            }
                        }
                        {
                            _v.set(std::optional<std::tuple<Text, Text, crate::lower::model::OutTy>>{});
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                {
                    _v.set(std::optional<std::tuple<Text, Text, crate::lower::model::OutTy>>{});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::optional<std::tuple<Text, Text, crate::lower::model::OutTy>>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    if (prism_rtl::is_none(outer_opt)) {
        auto wx2 = ({
            Wx this_ = wx;
            this_.build = crate::prelude::push(this_.build, crate::lower::refusal_do(Text::lit("`@Flatten` of a dynamic that is not a `rebuild`'s")));
            this_;
        });
        return std::tuple{wx2, Wres(Wres::WrUnit{})};
    }
    if (prism_rtl::is_some(outer_opt)) {
        auto&& m = std::get<0>(prism_rtl::some_of(outer_opt));
        auto&& gen_ = std::get<1>(prism_rtl::some_of(outer_opt));
        auto&& t = std::get<2>(prism_rtl::some_of(outer_opt));
        auto [name, wx1] = ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Text, Wx>> _v;
            if (prism_rtl::is_some(bound_opt) && prism_rtl::is<crate::lower::Bn::BnHold>(prism_rtl::some_of(bound_opt))) {
                auto&& f = prism_rtl::as<crate::lower::Bn::BnHold>(prism_rtl::some_of(bound_opt)).a0;
                _v.set(std::tuple{f, wx});
                goto _done;
            }
            {
                _v.set(fresh_name(wx, Text::lit("flatten")));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto inner = prism_rtl::cat(name, "_inner");
        auto first_ = crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), prism_rtl::cat(inner)})), Text::lit("set"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), m, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
        auto sample_1 = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(inner)})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})), Text::lit("expect"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{Text::lit("`@Flatten` adopts its first inner at the build")})})})), Text::lit("sample"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})});
        auto wx2 = ({
            Wx this_ = wx1;
            this_.taken = append(this_.taken, Array(std::vector{inner, prism_rtl::cat(name, "_adopt")}));
            this_.fields = crate::prelude::push(this_.fields, std::tuple{inner, crate::lower::model::OutTy(crate::lower::model::OutTy::OutHold{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutDyn{prism_rtl::rc(t)}))}))}), Text::lit("`@Flatten`'s current inner: the dynamic of the generation it adopted")});
            this_.moves = crate::prelude::push(this_.moves, std::tuple{inner, crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Hold::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XNone{}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
            this_.build = crate::prelude::push(this_.build, first_);
            this_.getters = crate::prelude::push(this_.getters, crate::lower::model::MethDef{.name = name, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = t, .body = Array<crate::lower::model::Do>{}, .tail = sample_1, .doc = Text::lit("`@Flatten`'s dynamic: its current inner at the read point.")});
            this_.dyn_reads = insert(this_.dyn_reads, name, Array(std::vector{Read(Read::OwnRead{inner})}));
            this_.flattens = crate::prelude::push(this_.flattens, FlatDef{.name = name, .outer = m, .generation = gen_, .ty = t});
            this_;
        });
        return std::tuple{wx2, Wres(Wres::WrDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), name, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{Read(Read::OwnRead{inner})}), t})};
    }
    prism_rtl::unreachable("no arm matched");
}


/// SwitchLine: unbounded fn Wx, Env, [Arg] -> ((Wx, Wres))
std::tuple<Wx, Wres> switch_line(const Wx& wx, const crate::lower::Env& menv, const Array<crate::syntax::Arg>& args) {
    auto&& _m = index(args, Nat(0u));
    if (prism_rtl::is_some(_m)) {
        auto&& a = prism_rtl::some_of(_m);
        auto [r, wx2] = event_ref(wx, menv, a->value);
        return std::tuple{wx2, Wres(Wres::WrEv{r})};
    }
    if (prism_rtl::is_none(_m)) {
        return std::tuple{wx, Wres(Wres::WrUnit{})};
    }
    prism_rtl::unreachable("no arm matched");
}

}  // namespace crate::lower::node_
