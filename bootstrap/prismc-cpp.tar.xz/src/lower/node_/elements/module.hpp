// The module `Lower.Node.Elements`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <lower/node_/elements/types.hpp>
#include "elem.types.hpp"
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace lower::node_::elements {

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> element_line_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const crate::syntax::Expr& e_p3, const std::optional<crate::lower::types::Bn>& bound_o4);

prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> start_element_line_f(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::Expr e_p3, std::optional<crate::lower::types::Bn> bound_o4);

crate::lower::model::OutTy element_out_f(const crate::lower::Lx& lx_p0, const crate::check::env::TagInfo& tg_p1, const crate::check::types::Ty& full_p2);

Text tag_name_of_f(const crate::lower::Lx& lx_p0, const crate::syntax::Expr& c_p1);

std::optional<crate::syntax::Expr> tag_arg_o(const Array<crate::syntax::Arg>& args_p0, const Text& fname_p1);

Text request_field_f(const crate::check::env::TagInfo& tg_p0, const Text& fname_p1);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> element_output_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const crate::check::env::TagInfo& tg_p2, const crate::lower::model::OutTy& out_p3, const crate::lower::model::Pos_& pos_p4, const std::optional<crate::lower::types::Bn>& bound_o5, const crate::lower::model::Ex& level_p6);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> bundle_output_f(const crate::lower::node_::Wx& wx_p0, const crate::check::env::TagInfo& tg_p1, const crate::lower::model::OutTy& out_p2, const crate::lower::model::Pos_& pos_p3, const Array<std::optional<crate::lower::types::Bn>>& parts_p4, const crate::lower::model::Ex& level_p5);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> bundle_output_of_f(const crate::lower::node_::Wx& wx_p0, const crate::check::env::TagInfo& tg_p1, const crate::lower::model::OutTy& out_p2, const crate::lower::model::Pos_& pos_p3, const Array<std::optional<crate::lower::types::Bn>>& parts_p4, const crate::lower::model::Ex& level_p5);

crate::lower::node_::Wx bundle_first_f(const crate::lower::node_::Wx& wx_p0, const crate::check::env::TagInfo& tg_p1, const crate::lower::model::Pos_& pos_p2, const Array<Nat>& plain_ix_p3, const Array<crate::lower::model::OutTy>& tys_p4, const Array<std::optional<crate::lower::types::Bn>>& parts_p5, const crate::lower::model::Ex& level_p6);

crate::lower::node_::Wx bundle_answer_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::model::Pos_& pos_p1, const crate::lower::model::OutTy& et_p2, const std::optional<crate::lower::types::Bn>& b_o3);

crate::lower::model::Do first_value_let_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::model::Pos_& pos_p1, const crate::check::env::TagInfo& tg_p2, const crate::lower::model::Ex& level_p3);

Text host_local_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::model::Pos_& pos_p1);

Text answer_variant_f(const crate::check::env::TagInfo& tg_p0);

Text answer_accessor_f(const crate::check::env::TagInfo& tg_p0);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> element_output_of_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const crate::check::env::TagInfo& tg_p2, const crate::lower::model::OutTy& out_p3, const crate::lower::model::Pos_& pos_p4, const std::optional<crate::lower::types::Bn>& bound_o5, const crate::lower::model::Ex& level_p6);

}  // namespace lower::node_::elements


namespace lower::node_::elements {

/// The step machine of `ElementLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ElementLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
struct ElementLine : prism_rtl::Job<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> {
    crate::lower::node_::Wx wx_p0;
    crate::lower::types::Env benv_p1;
    crate::lower::types::Env menv_p2;
    crate::syntax::Expr e_p3;
    std::optional<crate::lower::types::Bn> bound_o4;
    ElementLine(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::Expr e_p3, std::optional<crate::lower::types::Bn> bound_o4) : wx_p0(std::move(wx_p0)), benv_p1(std::move(benv_p1)), menv_p2(std::move(menv_p2)), e_p3(std::move(e_p3)), bound_o4(std::move(bound_o4)) {}
    prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> cycle() const override;
};


}  // namespace lower::node_::elements

}  // namespace crate
