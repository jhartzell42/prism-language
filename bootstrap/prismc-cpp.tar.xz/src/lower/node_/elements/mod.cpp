// The module `Lower.Node.Elements`, from `target/bootstrap/cpp-src/prismc/lower/node/elements.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <lower/node_/elements/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate::lower::node_::elements {

/// ElementLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> element_line(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const crate::syntax::Expr& e, const std::optional<crate::lower::types::Bn>& bound_opt) {
    auto lx = wx.lx;
    auto [tag_name, args] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Text, Array<crate::syntax::Arg>>> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
            auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
            auto&& xs = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
            _v.set(std::tuple{tag_name_of(lx, c), xs});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            _v.set(std::tuple{tag_name_of(lx, e), Array<crate::syntax::Arg>{}});
            goto _done;
        }
        {
            _v.set(std::tuple{Text::lit(""), Array<crate::syntax::Arg>{}});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto full = crate::lower::type_at(lx, e.span);
    auto&& _m = crate::prelude::get(lx.g.tags, tag_name);
    if (prism_rtl::is_none(_m)) {
        auto wx2 = ({
            crate::lower::node_::Wx this_ = wx;
            this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("an element of an unknown tag")));
            this_;
        });
        return std::tuple{wx2, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& tg = prism_rtl::some_of(_m);
        auto pos = wx.pos;
        auto wx1 = ({
            crate::lower::node_::Wx this_ = wx;
            this_.pos = crate::lower::model::next_pos(this_.pos);
            this_;
        });
        auto struct_path = crate::lower::path_in(lx, tg.home, crate::lower::tag_struct(tg.name));
        auto [live_fields, const_fields, reads, wx2] = run_to_end(fold_job(tg.fields, std::tuple{Array<std::tuple<Text, crate::lower::model::Ex>>{}, Array<std::tuple<Text, crate::lower::model::Ex>>{}, Array<crate::lower::node_::Read>{}, wx1}, ({
            auto args_1 = args;
            auto menv_2 = menv;
            auto pos_3 = pos;
            auto tg_4 = tg;
            auto lx_5 = lx;
            auto benv_6 = benv;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::lower::model::Ex>>, Array<std::tuple<Text, crate::lower::model::Ex>>, Array<crate::lower::node_::Read>, crate::lower::node_::Wx>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::lower::model::Ex>>, Array<std::tuple<Text, crate::lower::model::Ex>>, Array<crate::lower::node_::Read>, crate::lower::node_::Wx>, std::tuple<Text, crate::check::types::Ty>>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<Text, crate::lower::model::Ex>>, Array<std::tuple<Text, crate::lower::model::Ex>>, Array<crate::lower::node_::Read>, crate::lower::node_::Wx>, std::tuple<Text, crate::check::types::Ty>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto args_1_7 = args_1;
                auto menv_2_7 = menv_2;
                auto pos_3_7 = pos_3;
                auto tg_4_7 = tg_4;
                auto lx_5_7 = lx_5;
                auto benv_6_7 = benv_6;
                entered(once_job([=]() {
                return ({
                    auto [lf, cf, rd, w] = p0;
                    auto [fname, fty] = p1;
                    ({
                    auto&& _m = tag_arg(args_1_7, fname);
                    prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{lf, cf, rd, w})
                    : prism_rtl::is_some(_m) ? ({
                    auto&& arg = prism_rtl::some_of(_m);
                    ({
                    auto&& _m = crate::lower::types::layer_of(fty);
                    prism_rtl::is<crate::lower::types::Layer::LyEv>(_m) ? call_then(crate::lower::node_::dynamics::start_event_ref(w, menv_2_7, arg), [=](std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> event_ref_2400) {
                    return ({
                        auto [r, w2] = event_ref_2400;
                        (prism_rtl::finished(std::tuple{lf, cf, rd, crate::lower::node_::connect(w2, r, crate::lower::node_::Sk(crate::lower::node_::Sk::SkRequest{pos_3_7, request_field(tg_4_7, fname)}))}));
                    });
                })
                    : call_then(crate::lower::node_::dynamics::start_dynamic_expr(w, menv_2_7, arg), [=](std::tuple<crate::lower::model::Ex, Array<crate::lower::node_::Read>> dynamic_expr_2618) {
                    return ({
                        auto [ex, rds] = dynamic_expr_2618;
                        call_then(crate::lower::expr::start_value_of(lx_5_7, benv_6_7, arg), [=](crate::lower::types::Vl value_of_2689) {
                        return ({
                            auto cv = crate::lower::types::own(value_of_2689);
                            (prism_rtl::finished(std::tuple{crate::prelude::push(lf, std::tuple{crate::lower::snake(fname), ex}), crate::prelude::push(cf, std::tuple{crate::lower::snake(fname), cv}), crate::lower::node_::union_reads(rd, rds), w}));
                        });
                    });
                    });
                });
                });
                })
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        }));
        })));
        auto live = len(reads) > Nat(0u);
        auto [getter, wx3] = live
            ? crate::lower::node_::fresh_name(wx2, crate::lower::snake(crate::check::types::bare_name(tg.name)))
            : std::tuple{Text::lit(""), wx2};
        auto variant = crate::lower::program::variant_of(lx, tg);
        auto level = crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRecord{struct_path, live ? live_fields : const_fields})})});
        auto at_build = crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRecord{struct_path, const_fields})})});
        auto added = live
            ? crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), getter, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})
            : level;
        auto wx4 = ({
            crate::lower::node_::Wx this_ = wx3;
            this_.places = crate::prelude::push(this_.places, crate::lower::node_::Place{.pos = pos, .level = level, .getter = getter, .reads = reads});
            this_.build = crate::lower::node_::finish::emits(wx3, pos)
                ? crate::prelude::push(this_.build, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("added"), Array(std::vector{crate::lower::node_::finish::place_at(wx3, Text::lit("node"), pos), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(added), Text::lit("to_pod"), Array<crate::lower::model::Ex>{}})})})}))
                : this_.build;
            this_;
        });
        return element_output(wx4, menv, tg, element_out(lx, tg, full), pos, bound_opt, at_build);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> ElementLine::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& e = this->e;
    const auto& bound_opt = this->bound_opt;
    auto lx = wx.lx;
    auto [tag_name, args] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Text, Array<crate::syntax::Arg>>> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
            auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
            auto&& xs = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
            _v.set(std::tuple{tag_name_of(lx, c), xs});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            _v.set(std::tuple{tag_name_of(lx, e), Array<crate::syntax::Arg>{}});
            goto _done;
        }
        {
            _v.set(std::tuple{Text::lit(""), Array<crate::syntax::Arg>{}});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto full = crate::lower::type_at(lx, e.span);
    return ({
        auto&& _m = crate::prelude::get(lx.g.tags, tag_name);
        prism_rtl::is_none(_m) ? ({
        auto wx2 = ({
            crate::lower::node_::Wx this_ = wx;
            this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("an element of an unknown tag")));
            this_;
        });
        (prism_rtl::finished(std::tuple{wx2, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})}));
    })
        : prism_rtl::is_some(_m) ? ({
        auto&& tg = prism_rtl::some_of(_m);
        ({
        auto pos = wx.pos;
        auto wx1 = ({
            crate::lower::node_::Wx this_ = wx;
            this_.pos = crate::lower::model::next_pos(this_.pos);
            this_;
        });
        auto struct_path = crate::lower::path_in(lx, tg.home, crate::lower::tag_struct(tg.name));
        auto bound_opt_1 = bound_opt;
        auto benv_2 = benv;
        auto menv_3 = menv;
        call_value(fold_job(tg.fields, std::tuple{Array<std::tuple<Text, crate::lower::model::Ex>>{}, Array<std::tuple<Text, crate::lower::model::Ex>>{}, Array<crate::lower::node_::Read>{}, wx1}, ({
        auto args_4 = args;
        auto menv_3_5 = menv_3;
        auto pos_5 = pos;
        auto tg_6 = tg;
        auto lx_7 = lx;
        auto benv_2_8 = benv_2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::lower::model::Ex>>, Array<std::tuple<Text, crate::lower::model::Ex>>, Array<crate::lower::node_::Read>, crate::lower::node_::Wx>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::lower::model::Ex>>, Array<std::tuple<Text, crate::lower::model::Ex>>, Array<crate::lower::node_::Read>, crate::lower::node_::Wx>, std::tuple<Text, crate::check::types::Ty>>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<Text, crate::lower::model::Ex>>, Array<std::tuple<Text, crate::lower::model::Ex>>, Array<crate::lower::node_::Read>, crate::lower::node_::Wx>, std::tuple<Text, crate::check::types::Ty>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto args_4_8 = args_4;
            auto menv_3_5_8 = menv_3_5;
            auto pos_5_8 = pos_5;
            auto tg_6_8 = tg_6;
            auto lx_7_8 = lx_7;
            auto benv_2_8_8 = benv_2_8;
            entered(once_job([=]() {
            return ({
                auto [lf, cf, rd, w] = p0;
                auto [fname, fty] = p1;
                ({
                auto&& _m = tag_arg(args_4_8, fname);
                prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{lf, cf, rd, w})
                : prism_rtl::is_some(_m) ? ({
                auto&& arg = prism_rtl::some_of(_m);
                ({
                auto&& _m = crate::lower::types::layer_of(fty);
                prism_rtl::is<crate::lower::types::Layer::LyEv>(_m) ? call_then(crate::lower::node_::dynamics::start_event_ref(w, menv_3_5_8, arg), [=](std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> event_ref_2400) {
                return ({
                    auto [r, w2] = event_ref_2400;
                    (prism_rtl::finished(std::tuple{lf, cf, rd, crate::lower::node_::connect(w2, r, crate::lower::node_::Sk(crate::lower::node_::Sk::SkRequest{pos_5_8, request_field(tg_6_8, fname)}))}));
                });
            })
                : call_then(crate::lower::node_::dynamics::start_dynamic_expr(w, menv_3_5_8, arg), [=](std::tuple<crate::lower::model::Ex, Array<crate::lower::node_::Read>> dynamic_expr_2618) {
                return ({
                    auto [ex, rds] = dynamic_expr_2618;
                    call_then(crate::lower::expr::start_value_of(lx_7_8, benv_2_8_8, arg), [=](crate::lower::types::Vl value_of_2689) {
                    return ({
                        auto cv = crate::lower::types::own(value_of_2689);
                        (prism_rtl::finished(std::tuple{crate::prelude::push(lf, std::tuple{crate::lower::snake(fname), ex}), crate::prelude::push(cf, std::tuple{crate::lower::snake(fname), cv}), crate::lower::node_::union_reads(rd, rds), w}));
                    });
                });
                });
            });
            });
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<std::tuple<Text, crate::lower::model::Ex>>, Array<std::tuple<Text, crate::lower::model::Ex>>, Array<crate::lower::node_::Read>, crate::lower::node_::Wx> fold_2082) {
        return ({
            auto [live_fields, const_fields, reads, wx2] = fold_2082;
            auto live = len(reads) > Nat(0u);
            auto [getter, wx3] = live
                ? crate::lower::node_::fresh_name(wx2, crate::lower::snake(crate::check::types::bare_name(tg.name)))
                : std::tuple{Text::lit(""), wx2};
            auto variant = crate::lower::program::variant_of(lx, tg);
            auto level = crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRecord{struct_path, live ? live_fields : const_fields})})});
            auto at_build = crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRecord{struct_path, const_fields})})});
            auto added = live
                ? crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), getter, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})
                : level;
            auto wx4 = ({
                crate::lower::node_::Wx this_ = wx3;
                this_.places = crate::prelude::push(this_.places, crate::lower::node_::Place{.pos = pos, .level = level, .getter = getter, .reads = reads});
                this_.build = crate::lower::node_::finish::emits(wx3, pos)
                    ? crate::prelude::push(this_.build, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("added"), Array(std::vector{crate::lower::node_::finish::place_at(wx3, Text::lit("node"), pos), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(added), Text::lit("to_pod"), Array<crate::lower::model::Ex>{}})})})}))
                    : this_.build;
                this_;
            });
            (prism_rtl::finished(element_output(wx4, menv_3, tg, element_out(lx, tg, full), pos, bound_opt_1, at_build)));
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ElementLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> start_element_line(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, crate::syntax::Expr e, std::optional<crate::lower::types::Bn> bound_opt) {
    return prism_rtl::make_rc<ElementLine>(wx, benv, menv, e, bound_opt);
}


/// ElementOut: unbounded fn Lx, TagInfo, Ty -> OutTy
crate::lower::model::OutTy element_out(const crate::lower::Lx& lx, const crate::check::env::TagInfo& tg, const crate::check::types::Ty& full) {
    auto t = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::OutTy> _v;
        auto&& _m = crate::lower::types::peel(full);
        if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
            auto&& o = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a1;
            _v.set(crate::lower::types::out_ty_of(lx, crate::lower::types::peel(o)));
            goto _done;
        }
        {
            _v.set(crate::lower::types::out_ty_of(lx, crate::lower::types::peel(tg->out)));
            goto _done;
        }
    _done:
        _v.take();
    });
    if (prism_rtl::is<crate::lower::model::OutTy::OutGen>(t)) {
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutPod{});
    }
    {
        return t;
    }
}


/// TagNameOf: fn Lx, Expr -> Text
Text tag_name_of(const crate::lower::Lx& lx, const crate::syntax::Expr& c) {
    auto&& _m = c.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        auto&& _qk_opt = crate::check::env::names::resolve_value(lx.g, lx.home, n);
        auto&& qk_opt = std::get<0>(_qk_opt);
        return or_(qk_opt, crate::check::env::dotted(n->path_));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return tag_name_of(lx, x);
    }
    {
        return Text::lit("");
    }
}


/// ?TagArg: fn [Arg], Text -> ?Expr
std::optional<crate::syntax::Expr> tag_arg(const Array<crate::syntax::Arg>& args, const Text& fname) {
    return fold(args, std::optional<crate::syntax::Expr>{}, [&](const std::optional<crate::syntax::Expr>& found_opt, const crate::syntax::Arg& a) {
        return ({
            __label__ _done;
            prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
            auto&& _m = a.name;
            if (prism_rtl::is_some(_m)) {
                auto&& n = prism_rtl::some_of(_m);
                _v.set(n.name == fname ? std::optional(a->value) : found_opt);
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(found_opt);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// RequestField: fn TagInfo, Text -> Text
Text request_field(const crate::check::env::TagInfo& tg, const Text& fname) {
    auto evs = filter(tg.fields, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
        auto&& t = std::get<1>(_p0);
        return crate::lower::types::layer_of(t) == crate::lower::types::Layer(crate::lower::types::Layer::LyEv{});
    });
    return len(evs) > Nat(1u) ? fname : Text::lit("");
}


/// ElementOutput: unbounded fn Wx, Env, TagInfo, OutTy, Pos, ?Bn, Ex -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> element_output(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& menv, const crate::check::env::TagInfo& tg, const crate::lower::model::OutTy& out, const crate::lower::model::Pos_& pos, const std::optional<crate::lower::types::Bn>& bound_opt, const crate::lower::model::Ex& level) {
    auto lx = wx.lx;
    if (prism_rtl::is_some(bound_opt) && prism_rtl::is<crate::lower::types::Bn::BnParts>(prism_rtl::some_of(bound_opt))) {
        auto&& parts = prism_rtl::as<crate::lower::types::Bn::BnParts>(prism_rtl::some_of(bound_opt)).a0;
        return bundle_output(wx, tg, out, pos, parts, level);
    }
    {
        return element_output_of(wx, menv, tg, out, pos, bound_opt, level);
    }
}


/// BundleOutput: unbounded fn Wx, TagInfo, OutTy, Pos, [?Bn], Ex -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> bundle_output(const crate::lower::node_::Wx& wx, const crate::check::env::TagInfo& tg, const crate::lower::model::OutTy& out, const crate::lower::model::Pos_& pos, const Array<std::optional<crate::lower::types::Bn>>& parts, const crate::lower::model::Ex& level) {
    return !crate::lower::node_::finish::emits(wx, pos)
        ? ({
        auto wx2 = ({
            crate::lower::node_::Wx this_ = wx;
            this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(prism_rtl::cat("a bundle (", tg.name, ") in a hosted scope")));
            this_;
        });
        std::tuple{wx2, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
    })
        : bundle_output_of(wx, tg, out, pos, parts, level);
}


/// BundleOutputOf: unbounded fn Wx, TagInfo, OutTy, Pos, [?Bn], Ex -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> bundle_output_of(const crate::lower::node_::Wx& wx, const crate::check::env::TagInfo& tg, const crate::lower::model::OutTy& out, const crate::lower::model::Pos_& pos, const Array<std::optional<crate::lower::types::Bn>>& parts, const crate::lower::model::Ex& level) {
    auto layers = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::types::Layer>> _v;
        auto&& _m = tg->out;
        if (prism_rtl::is<crate::check::types::Ty::TyTuple>(_m)) {
            auto&& cs = prism_rtl::as<crate::check::types::Ty::TyTuple>(_m).a0;
            _v.set(each(cs, [&](const crate::check::types::Ty& c) { return crate::lower::types::layer_of(c); }));
            goto _done;
        }
        {
            _v.set(Array<crate::lower::types::Layer>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto tys = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
        if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(out)) {
            auto&& ts = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(out).a0;
            _v.set(ts);
            goto _done;
        }
        {
            _v.set(Array<crate::lower::model::OutTy>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto idx = crate::check::errors::range0(len(layers));
    auto plain_ix = filter(idx, [&](const Nat& i) { return or_(index(layers, i), crate::lower::types::Layer(crate::lower::types::Layer::LyPlain{})) == crate::lower::types::Layer(crate::lower::types::Layer::LyPlain{}); });
    auto ev_ix = filter(idx, [&](const Nat& i) { return or_(index(layers, i), crate::lower::types::Layer(crate::lower::types::Layer::LyPlain{})) == crate::lower::types::Layer(crate::lower::types::Layer::LyEv{}); });
    auto dyn_ix = filter(idx, [&](const Nat& i) { return or_(index(layers, i), crate::lower::types::Layer(crate::lower::types::Layer::LyPlain{})) == crate::lower::types::Layer(crate::lower::types::Layer::LyDyn{}); });
    auto wx1 = bundle_first(wx, tg, pos, plain_ix, tys, parts, level);
    auto wx2 = fold(ev_ix, wx1, [&](const crate::lower::node_::Wx& w, const Nat& i) { return bundle_answer(w, pos, or_(index(tys, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})), or_(index(parts, i), std::optional<crate::lower::types::Bn>{})); });
    return (len(ev_ix) > Nat(1u)) || (len(dyn_ix) > Nat(0u))
        ? ({
        auto wx3 = ({
            crate::lower::node_::Wx this_ = wx2;
            this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(prism_rtl::cat("a bundle with a `$` part or two event parts (", tg.name, ")")));
            this_;
        });
        std::tuple{wx3, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
    })
        : std::tuple{wx2, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
}


/// BundleFirst: unbounded fn Wx, TagInfo, Pos, [Nat], [OutTy], [?Bn], Ex -> Wx
crate::lower::node_::Wx bundle_first(const crate::lower::node_::Wx& wx, const crate::check::env::TagInfo& tg, const crate::lower::model::Pos_& pos, const Array<Nat>& plain_ix, const Array<crate::lower::model::OutTy>& tys, const Array<std::optional<crate::lower::types::Bn>>& parts, const crate::lower::model::Ex& level) {
    {
        auto&& m7415_0 = plain_ix;
        if (m7415_0.size() == 0u) {
            return wx;
        }
    }
    {
        auto one = len(plain_ix) == Nat(1u);
        auto plain_ty = one
            ? or_(index(tys, or_(index(plain_ix, Nat(0u)), Nat(0u))), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))
            : crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{each(plain_ix, [&](const Nat& i) { return or_(index(tys, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})); })});
        auto wx1 = ({
            crate::lower::node_::Wx this_ = wx;
            this_.lets = append(this_.lets, Array(std::vector{first_value_let(wx, pos, tg, level), crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat("bundle_", crate::lower::model::place_text(pos))}), crate::lower::model::Ex(crate::lower::model::Ex::XDecode{plain_ty, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("first_", crate::lower::model::place_text(pos))}))}))})})}));
            this_.fallible = true;
            this_;
        });
        return fold(crate::check::errors::range0(len(plain_ix)), wx1, [&](const crate::lower::node_::Wx& w, const Nat& k) {
            return ({
                auto i = or_(index(plain_ix, k), Nat(0u));
                ({
                __label__ _done;
                prism_rtl::Slot<crate::lower::node_::Wx> _v;
                auto&& _m = index(parts, i);
                if (prism_rtl::is_some(_m) && prism_rtl::is_some(prism_rtl::some_of(_m)) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(prism_rtl::some_of(_m)))) {
                    auto&& rs = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(prism_rtl::some_of(_m))).a0;
                    _v.set(({
                        auto f = crate::lower::types::place_stem(rs);
                        auto part = one
                            ? crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("bundle_", crate::lower::model::place_text(pos))})
                            : crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XPart{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("bundle_", crate::lower::model::place_text(pos))})), k}))});
                        ({
                        crate::lower::node_::Wx this_ = w;
                        this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{f}), part}));
                        this_.fields = crate::prelude::push(this_.fields, std::tuple{f, or_(index(tys, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})), prism_rtl::cat("place ", crate::lower::model::place_text(pos), "'s answer, part ", i, " of its first value")});
                        this_.inits = crate::prelude::push(this_.inits, std::tuple{f, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{f}))})});
                        this_;
                    });
                    }));
                    goto _done;
                }
                {
                    _v.set(w);
                    goto _done;
                }
            _done:
                _v.take();
            });
            });
        });
    }
}


/// BundleAnswer: fn Wx, Pos, OutTy, ?Bn -> Wx
crate::lower::node_::Wx bundle_answer(const crate::lower::node_::Wx& wx, const crate::lower::model::Pos_& pos, const crate::lower::model::OutTy& et, const std::optional<crate::lower::types::Bn>& b_opt) {
    auto t = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::OutTy> _v;
        if (prism_rtl::is<crate::lower::model::OutTy::OutEvent>(et)) {
            auto&& inner = prism_rtl::as<crate::lower::model::OutTy::OutEvent>(et).a0;
            _v.set(inner);
            goto _done;
        }
        {
            _v.set(et);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [id, wx2] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Nat, crate::lower::node_::Wx>> _v;
        if (prism_rtl::is_some(b_opt) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(b_opt))) {
            auto&& er = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(b_opt)).a0;
            _v.set(std::tuple{er.node_, wx});
            goto _done;
        }
        {
            _v.set(({
                auto [nm, w] = crate::lower::node_::fresh_name(wx, prism_rtl::cat("place_", crate::lower::model::place_text(pos)));
                (crate::lower::node_::add_gn(w, nm, t, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnAnswer{}), Nat(0u)));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
    crate::lower::node_::Wx this_ = wx2;
    this_.answers = crate::prelude::push(this_.answers, std::tuple{pos, id, t, Text::lit("")});
    return this_;
}


/// FirstValueLet: fn Wx, Pos, TagInfo, Ex -> Do
crate::lower::model::Do first_value_let(const crate::lower::node_::Wx& wx, const crate::lower::model::Pos_& pos, const crate::check::env::TagInfo& tg, const crate::lower::model::Ex& level) {
    auto missing = crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Fault::answer"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{prism_rtl::cat("no first value for ", tg.name)})})});
    return crate::lower::node_::finish::emits(wx, pos)
        ? ({
        auto asked = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("first_value"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(level), Text::lit("to_pod"), Array<crate::lower::model::Ex>{}}))})})});
        (crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat("first_", crate::lower::model::place_text(pos))}), crate::lower::expr::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(asked), Text::lit("ok_or"), Array(std::vector{missing})}))}));
    })
        : ({
        auto host = host_local(wx, pos);
        auto asked = crate::lower::expr::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{host})), Text::lit("first_value"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::node_::finish::place_at(wx, Text::lit(""), pos))}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(level)}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}));
        (crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat("first_", crate::lower::model::place_text(pos))}), crate::lower::expr::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::expr::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(asked), Text::lit("ok_or"), Array(std::vector{missing})}))), answer_accessor(tg), Array<crate::lower::model::Ex>{}}))}));
    });
}


/// HostLocal: fn Wx, Pos -> Text
Text host_local(const crate::lower::node_::Wx& wx, const crate::lower::model::Pos_& pos) {
    return pos.scope == Nat(0u)
        ? Text::lit("enclosing")
        : or_(index(wx.scopes, crate::syntax::lexer::chars::dec(pos.scope)), Text::lit(""));
}


/// AnswerVariant: fn TagInfo -> Text
Text answer_variant(const crate::check::env::TagInfo& tg) {
    return prism_rtl::cat("crate::Answer::", crate::lower::tag_struct(tg.name));
}


/// AnswerAccessor: fn TagInfo -> Text
Text answer_accessor(const crate::check::env::TagInfo& tg) {
    return crate::lower::snake(crate::lower::tag_struct(tg.name));
}


/// ElementOutputOf: unbounded fn Wx, Env, TagInfo, OutTy, Pos, ?Bn, Ex -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> element_output_of(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& menv, const crate::check::env::TagInfo& tg, const crate::lower::model::OutTy& out, const crate::lower::model::Pos_& pos, const std::optional<crate::lower::types::Bn>& bound_opt, const crate::lower::model::Ex& level) {
    auto lx = wx.lx;
    auto&& _m = crate::lower::types::layer_of(tg->out);
    if (prism_rtl::is<crate::lower::types::Layer::LyEv>(_m)) {
        auto [id, wx2] = ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Nat, crate::lower::node_::Wx>> _v;
            if (prism_rtl::is_some(bound_opt) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_opt))) {
                auto&& er = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_opt)).a0;
                _v.set(std::tuple{er.node_, wx});
                goto _done;
            }
            {
                _v.set(({
                    auto [nm, w] = crate::lower::node_::fresh_name(wx, prism_rtl::cat("place_", crate::lower::model::place_text(pos)));
                    (crate::lower::node_::add_gn(w, nm, out, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnAnswer{}), Nat(0u)));
                }));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto wx3 = ({
            crate::lower::node_::Wx this_ = wx2;
            this_.answers = crate::prelude::push(this_.answers, std::tuple{pos, id, out, answer_accessor(tg)});
            this_;
        });
        return std::tuple{wx3, crate::lower::node_::Wres(crate::lower::node_::Wres::WrEv{crate::lower::node_::ev_ref_of(wx3, id)})};
    }
    if (prism_rtl::is<crate::lower::types::Layer::LyDyn>(_m)) {
        auto [f, wx1] = ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Text, crate::lower::node_::Wx>> _v;
            if (prism_rtl::is_some(bound_opt) && prism_rtl::is<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(bound_opt))) {
                auto&& hf = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(bound_opt)).a0;
                _v.set(std::tuple{hf, wx});
                goto _done;
            }
            {
                _v.set(crate::lower::node_::fresh_name(wx, prism_rtl::cat("place_", crate::lower::model::place_text(pos))));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto emits_1 = crate::lower::node_::finish::emits(wx, pos);
        auto first__2 = emits_1
            ? crate::lower::model::Ex(crate::lower::model::Ex::XDecode{out, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("first_", crate::lower::model::place_text(pos))}))}))})
            : crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("first_", crate::lower::model::place_text(pos))});
        auto wx2 = ({
            crate::lower::node_::Wx this_ = wx1;
            this_.lets = crate::prelude::push(this_.lets, first_value_let(wx, pos, tg, level));
            this_.fields = crate::prelude::push(this_.fields, std::tuple{f, crate::lower::model::OutTy(crate::lower::model::OutTy::OutHold{prism_rtl::rc(out)}), prism_rtl::cat("pushed to place ", crate::lower::model::place_text(pos))});
            this_.inits = crate::prelude::push(this_.inits, std::tuple{f, crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Hold::new"), Array(std::vector{first__2, crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
            this_.dyn_places = crate::prelude::push(this_.dyn_places, std::tuple{pos, f, out, answer_accessor(tg)});
            this_.fallible = true;
            this_;
        });
        auto wx3 = emits_1
            ? ({
            crate::lower::node_::Wx this_ = wx2;
            this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat(f, "_element")}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(level), Text::lit("to_pod"), Array<crate::lower::model::Ex>{}})}));
            this_.fields = crate::prelude::push(this_.fields, std::tuple{prism_rtl::cat(f, "_element"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutPod{}), prism_rtl::cat("place ", crate::lower::model::place_text(pos), "'s element, which pushes are keyed by")});
            this_.moves = crate::prelude::push(this_.moves, std::tuple{prism_rtl::cat(f, "_element"), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat(f, "_element")}))})});
            this_.build = crate::prelude::push(this_.build, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("listen"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), prism_rtl::cat(f, "_element")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")}))})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutObj{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Node"), Array<crate::lower::model::OutTy>{}}))})}))})})})}));
            this_;
        })
            : wx2;
        return std::tuple{wx3, crate::lower::node_::Wres(crate::lower::node_::Wres::WrDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f)})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{f})}), out})};
    }
    {
        if (prism_rtl::is_some(bound_opt) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(bound_opt))) {
            auto&& rs = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(bound_opt)).a0;
            auto f = crate::lower::types::place_stem(rs);
            auto first__1 = crate::lower::node_::finish::emits(wx, pos)
                ? crate::lower::model::Ex(crate::lower::model::Ex::XDecode{out, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("first_", crate::lower::model::place_text(pos))}))}))})
                : crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("first_", crate::lower::model::place_text(pos))});
            auto wx2 = ({
                crate::lower::node_::Wx this_ = wx;
                this_.lets = append(this_.lets, Array(std::vector{first_value_let(wx, pos, tg, level), crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{f}), first__1})}));
                this_.fields = crate::prelude::push(this_.fields, std::tuple{f, out, prism_rtl::cat("place ", crate::lower::model::place_text(pos), "'s answer, its first value")});
                this_.inits = crate::prelude::push(this_.inits, std::tuple{f, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{f}))})});
                this_.fallible = true;
                this_;
            });
            return std::tuple{wx2, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
        }
        {
            return std::tuple{wx, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
        }
    }
}

}  // namespace crate::lower::node_::elements
