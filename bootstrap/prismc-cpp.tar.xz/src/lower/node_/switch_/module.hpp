// The module `Lower.Node.Switch`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <lower/node_/switch_/types.hpp>
#include "elem.types.hpp"
#include <lower/node_/types.hpp>
#include <lower/model/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace lower::node_::switch_ {

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env> row_env_f(const crate::lower::node_::Wx& parent_p0, const crate::lower::node_::Wx& row_wx_p1, const crate::lower::types::Env& menv_p2, const crate::syntax::Block& body_p3);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env> row_param_env_f(const crate::lower::node_::Wx& p_p0, const crate::lower::node_::Wx& r_p1, const crate::lower::types::Env& env_p2, const crate::lower::types::Env& menv_p3, const Text& n_p4);

crate::lower::model::Ex over_parent_f(const crate::lower::model::Ex& x_p0);

crate::lower::model::Ex parent_ref_p();

crate::lower::model::Ex parent_arg_p();

crate::lower::node_::Wx with_port_f(const crate::lower::node_::Wx& wx_p0, const Text& pname_p1);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> rebuild_line_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const crate::syntax::Expr& scrut_p3, const crate::syntax::Block& body_p4, const crate::syntax::Expr& e_p5, const std::optional<crate::lower::types::Bn>& bound_o6);

prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> start_rebuild_line_f(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::Expr scrut_p3, crate::syntax::Block body_p4, crate::syntax::Expr e_p5, std::optional<crate::lower::types::Bn> bound_o6);

bool gives_dynamic_f(const crate::check::types::Ty& t_p0);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> rebuild_dynamic_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const crate::syntax::Block& body_p2, const crate::lower::model::Ex& src_ex_p3, const Array<crate::lower::node_::Read>& reads_p4, const crate::lower::model::OutTy& vt_p5, const Text& name_p6, const crate::lower::model::Pos_& pos_p7);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> clause_widget_line_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const crate::syntax::Expr& scrut_p2, const crate::syntax::Block& call_p3, const Text& qk_p4, const crate::check::env::ValInfo& v_p5, const crate::syntax::Expr& e_p6);

bool is_hosted_scope_f(const crate::lower::node_::Wx& wx_p0);

template <class A>
bool is_some_f(const std::optional<A>& opt0);

std::tuple<Array<GenCase>, crate::lower::node_::Wx> gen_cases_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const crate::syntax::Block& body_p2, const crate::lower::model::OutTy& vt_p3, const Text& name_p4);

std::optional<std::tuple<Text, Array<crate::syntax::Arg>>> clause_call_o(const crate::lower::Lx& lx_p0, const crate::syntax::Block& body_p1);

std::optional<std::tuple<Text, Array<crate::syntax::Arg>>> clause_call_x_o(const crate::lower::Lx& lx_p0, const crate::syntax::Expr& x_p1);

ClauseRow clause_row_of_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const crate::syntax::decls::FnClause& c_p2, const crate::check::env::ValInfo& v_p3, const Text& row_name_p4, const Text& gen_name_p5, const bool& transparent_p6);

GenRow gen_row_of_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const crate::syntax::Block& body_p2, const crate::lower::model::OutTy& vt_p3, const Text& row_name_p4, const Text& gen_name_p5);

crate::lower::node_::Wx gen_result_f(const crate::lower::node_::Wx& r_p0, const Text& gen_name_p1, const crate::lower::model::Ex& ex_p2, const Array<crate::lower::node_::Read>& result_reads_p3, const crate::lower::model::OutTy& rt_p4);

crate::lower::node_::Wx gen_marked_f(const crate::lower::node_::Wx& parent_p0, const Text& gen_name_p1, const crate::lower::node_::Wx& row_wx_p2);

crate::lower::types::Env build_spelling_f(const crate::lower::types::Env& env_p0);

crate::lower::model::Ex gen_select_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const crate::syntax::Block& body_p2, const Array<GenCase>& cases_p3, const crate::lower::model::Pos_& pos_p4);

crate::lower::model::MethDef gen_up_f(const Text& name_p0, const Text& up_name_p1, const crate::lower::model::OutTy& t_p2);

Array<std::tuple<crate::lower::model::Pa, crate::lower::model::Ex>> gen_forwards_f(const crate::lower::model::GenDef& gd_p0);

crate::lower::model::Ex forward_gen_f(const crate::lower::model::GenDef& gd_p0);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> flatten_line_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const Array<crate::syntax::Arg>& args_p2, const std::optional<crate::lower::types::Bn>& bound_o3);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> entry_flatten_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::model::OutTy& t_p1, const std::optional<crate::lower::types::Bn>& bound_o2);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> switch_line_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const Array<crate::syntax::Arg>& args_p2);

}  // namespace lower::node_::switch_


namespace lower::node_::switch_ {

/// The step machine of `RebuildLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RebuildLine: unbounded fn Wx, Env, Env, Expr, Block, Expr, ?Bn -> ((Wx, Wres))
struct RebuildLine : prism_rtl::Job<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> {
    crate::lower::node_::Wx wx_p0;
    crate::lower::types::Env benv_p1;
    crate::lower::types::Env menv_p2;
    crate::syntax::Expr scrut_p3;
    crate::syntax::Block body_p4;
    crate::syntax::Expr e_p5;
    std::optional<crate::lower::types::Bn> bound_o6;
    RebuildLine(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::Expr scrut_p3, crate::syntax::Block body_p4, crate::syntax::Expr e_p5, std::optional<crate::lower::types::Bn> bound_o6) : wx_p0(std::move(wx_p0)), benv_p1(std::move(benv_p1)), menv_p2(std::move(menv_p2)), scrut_p3(std::move(scrut_p3)), body_p4(std::move(body_p4)), e_p5(std::move(e_p5)), bound_o6(std::move(bound_o6)) {}
    prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> cycle() const override;
};


}  // namespace lower::node_::switch_

}  // namespace crate
