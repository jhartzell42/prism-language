// The module `Lower.Node.Switch`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <lower/node_/switch_/types.hpp>
#include "elem.types.hpp"
#include <lower/node_/types.hpp>
#include <lower/model/types.hpp>
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace lower::node_::switch_ {

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env> row_env(const crate::lower::node_::Wx& parent, const crate::lower::node_::Wx& row_wx, const crate::lower::types::Env& menv, const crate::syntax::Block& body);

crate::lower::model::Ex over_parent(const crate::lower::model::Ex& x);

crate::lower::model::Ex parent_ref();

crate::lower::model::Ex parent_arg();

crate::lower::node_::Wx with_port(const crate::lower::node_::Wx& wx, const Text& pname);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> rebuild_line(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const crate::syntax::Expr& scrut, const crate::syntax::Block& body, const crate::syntax::Expr& e, const std::optional<crate::lower::types::Bn>& bound_opt);

prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> start_rebuild_line(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, crate::syntax::Expr scrut, crate::syntax::Block body, crate::syntax::Expr e, std::optional<crate::lower::types::Bn> bound_opt);

bool gives_dynamic(const crate::check::types::Ty& t);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> rebuild_dynamic(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& menv, const crate::syntax::Block& body, const crate::lower::model::Ex& src_ex, const Array<crate::lower::node_::Read>& reads, const crate::lower::model::OutTy& vt, const Text& name, const crate::lower::model::Pos_& pos);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> clause_widget_line(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& menv, const crate::syntax::Expr& scrut, const crate::syntax::Block& call, const Text& qk, const crate::check::env::ValInfo& v_, const crate::syntax::Expr& e);

bool is_hosted_scope(const crate::lower::node_::Wx& wx);

template <class A>
bool is_some_(const std::optional<A>& opt0);

std::tuple<Array<GenCase>, crate::lower::node_::Wx> gen_cases(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& menv, const crate::syntax::Block& body, const crate::lower::model::OutTy& vt, const Text& name);

std::optional<std::tuple<Text, Array<crate::syntax::Arg>>> clause_call(const crate::lower::Lx& lx, const crate::syntax::Block& body);

std::optional<std::tuple<Text, Array<crate::syntax::Arg>>> clause_call_x(const crate::lower::Lx& lx, const crate::syntax::Expr& x);

ClauseRow clause_row_of(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& menv, const crate::syntax::decls::FnClause& c, const crate::check::env::ValInfo& v_, const Text& row_name, const Text& gen_name, const bool& transparent);

GenRow gen_row_of(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& menv, const crate::syntax::Block& body, const crate::lower::model::OutTy& vt, const Text& row_name, const Text& gen_name);

crate::lower::node_::Wx gen_result(const crate::lower::node_::Wx& r, const Text& gen_name, const crate::lower::model::Ex& ex, const Array<crate::lower::node_::Read>& result_reads, const crate::lower::model::OutTy& rt);

crate::lower::node_::Wx gen_marked(const crate::lower::node_::Wx& parent, const Text& gen_name, const crate::lower::node_::Wx& row_wx);

crate::lower::types::Env build_spelling(const crate::lower::types::Env& env);

crate::lower::model::Ex gen_select(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& menv, const crate::syntax::Block& body, const Array<GenCase>& cases, const crate::lower::model::Pos_& pos);

crate::lower::model::MethDef gen_up(const Text& name, const Text& up_name, const crate::lower::model::OutTy& t);

Array<std::tuple<crate::lower::model::Pa, crate::lower::model::Ex>> gen_forwards(const crate::lower::model::GenDef& gd);

crate::lower::model::Ex forward_gen(const crate::lower::model::GenDef& gd);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> flatten_line(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& menv, const Array<crate::syntax::Arg>& args, const std::optional<crate::lower::types::Bn>& bound_opt);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> entry_flatten(const crate::lower::node_::Wx& wx, const crate::lower::model::OutTy& t, const std::optional<crate::lower::types::Bn>& bound_opt);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> switch_line(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& menv, const Array<crate::syntax::Arg>& args);

}  // namespace lower::node_::switch_


namespace lower::node_::switch_ {

/// The step machine of `RebuildLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RebuildLine: unbounded fn Wx, Env, Env, Expr, Block, Expr, ?Bn -> ((Wx, Wres))
struct RebuildLine : prism_rtl::Job<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> {
    crate::lower::node_::Wx wx;
    crate::lower::types::Env benv;
    crate::lower::types::Env menv;
    crate::syntax::Expr scrut;
    crate::syntax::Block body;
    crate::syntax::Expr e;
    std::optional<crate::lower::types::Bn> bound_opt;
    RebuildLine(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, crate::syntax::Expr scrut, crate::syntax::Block body, crate::syntax::Expr e, std::optional<crate::lower::types::Bn> bound_opt) : wx(std::move(wx)), benv(std::move(benv)), menv(std::move(menv)), scrut(std::move(scrut)), body(std::move(body)), e(std::move(e)), bound_opt(std::move(bound_opt)) {}
    prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> cycle() const override;
};


}  // namespace lower::node_::switch_

}  // namespace crate
