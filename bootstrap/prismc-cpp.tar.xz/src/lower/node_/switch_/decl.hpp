// The module `Lower.Node.Switch`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace lower::node_::switch_ {

struct ClauseRow;

struct GenCase;

struct GenRow;

struct RebuildLine;

}  // namespace lower::node_::switch_

}  // namespace crate
