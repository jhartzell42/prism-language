// The module `Lower.Node.Switch`: its value types (records, tags, newtypes and choices with their cases), each
// after the types it holds by value, emitted by prismc (claude/backend.md). Edit the Prism
// source, not this file.
#pragma once

#include <lower/node_/switch_/decl.hpp>
#include "elem.decl.hpp"
#include <check/decl.hpp>
#include <check/blocks/decl.hpp>
#include <check/blocks/borrows/decl.hpp>
#include <check/blocks/structure/decl.hpp>
#include <check/env/decl.hpp>
#include <check/env/decls/decl.hpp>
#include <check/env/names/decl.hpp>
#include <check/env/reading/decl.hpp>
#include <check/env/traits/decl.hpp>
#include <check/errors/decl.hpp>
#include <check/expr/decl.hpp>
#include <check/expr/calls/decl.hpp>
#include <check/expr/lets/decl.hpp>
#include <check/expr/lifting/decl.hpp>
#include <check/expr/operators/decl.hpp>
#include <check/expr/patterns/decl.hpp>
#include <check/passes/decl.hpp>
#include <check/passes/borrows/decl.hpp>
#include <check/passes/cycles/decl.hpp>
#include <check/regex/decl.hpp>
#include <check/shrink/decl.hpp>
#include <check/shrink/calls/decl.hpp>
#include <check/shrink/locals/decl.hpp>
#include <check/shrink/relations/decl.hpp>
#include <check/shrink/summaries/decl.hpp>
#include <check/shrink/types/decl.hpp>
#include <check/shrink/walk/decl.hpp>
#include <check/typed/decl.hpp>
#include <check/typed/print/decl.hpp>
#include <check/types/decl.hpp>
#include <check/types/colors/decl.hpp>
#include <check/types/recording/decl.hpp>
#include <check/types/schemes/decl.hpp>
#include <check/types/unify/decl.hpp>
#include <lower/decl.hpp>
#include <lower/expr/decl.hpp>
#include <lower/functions/decl.hpp>
#include <lower/jobs/decl.hpp>
#include <lower/node_/def/decl.hpp>
#include <lower/node_/dynamics/decl.hpp>
#include <lower/node_/elements/decl.hpp>
#include <lower/node_/finish/decl.hpp>
#include <lower/node_/keyed/decl.hpp>
#include <lower/node_/static_/decl.hpp>
#include <lower/patterns/decl.hpp>
#include <lower/program/decl.hpp>
#include <lower/templates/decl.hpp>
#include <lower/types/decl.hpp>
#include <syntax/decl.hpp>
#include <syntax/decls/decl.hpp>
#include <syntax/lexer/decl.hpp>
#include <syntax/lexer/chars/decl.hpp>
#include <syntax/lexer/corpus/decl.hpp>
#include <syntax/lexer/layout/decl.hpp>
#include <syntax/lexer/literals/decl.hpp>
#include <syntax/lexer/regexes/decl.hpp>
#include <syntax/lexer/templates/decl.hpp>
#include <syntax/lexer/words/decl.hpp>
#include <lower/node_/types.hpp>
#include <lower/model/types.hpp>

namespace crate {

using namespace prelude;

namespace lower::node_::switch_ {

/// `GenCase`:
///
/// ```prism
/// type GenCase = record:
/// ```
struct GenCase {
    using prism_value = void;
    crate::lower::model::NodeDef node_p;
    Array<std::tuple<Text, crate::lower::model::OutTy>> params_p;
    crate::lower::model::Pa pat_p;
    Array<crate::lower::model::Cc> conds_p;
    Array<crate::lower::model::Ex> passed_p;
    const GenCase* operator->() const { return this; }
    GenCase* operator->() { return this; }
    Pod to_pod() const;
    static Result<GenCase> from_pod(const Pod& whole);
};


}  // namespace lower::node_::switch_

namespace lower::node_::switch_ {

/// `GenRow`:
///
/// ```prism
/// type GenRow = record:
/// ```
struct GenRow {
    using prism_value = void;
    crate::lower::model::NodeDef node_p;
    crate::lower::node_::Wx parent_p;
    std::optional<crate::lower::model::OutTy> dyn_result_o;
    const GenRow* operator->() const { return this; }
    GenRow* operator->() { return this; }
};


}  // namespace lower::node_::switch_

namespace lower::node_::switch_ {

/// `ClauseRow`:
///
/// ```prism
/// type ClauseRow = record:
/// ```
struct ClauseRow {
    using prism_value = void;
    GenCase case_p;
    crate::lower::node_::Wx parent_p;
    Nat width_p;
    const ClauseRow* operator->() const { return this; }
    ClauseRow* operator->() { return this; }
};


}  // namespace lower::node_::switch_

}  // namespace crate
