// The module `Lower.Templates`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace lower::templates {

struct TemplateValue;

struct TemplatePartDos;

struct TemplateArgs;

struct GivenValue;

struct UpdateValue;

struct UpdStmts;

struct UpdStmt;

struct UpdFor;

struct UpdForRefs;

struct UpdForValues;

struct UpdIf;

struct UpdMatch;

struct GuardConds;

struct PlaceOf;

struct PlaceTy;

struct FieldTy;

struct Assign;

}  // namespace lower::templates

}  // namespace crate
