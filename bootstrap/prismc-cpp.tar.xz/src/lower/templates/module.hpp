// The module `Lower.Templates`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <lower/templates/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace lower::templates {

crate::lower::types::Vl template_value(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Template& tp_p2);

prism_rtl::JobRef<crate::lower::types::Vl> start_template_value(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Template tp_p2);

Array<crate::lower::model::Do> template_part_dos(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::TemplatePart& part_p2);

prism_rtl::JobRef<Array<crate::lower::model::Do>> start_template_part_dos(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::TemplatePart part_p2);

Array<crate::lower::model::Ex> template_args(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Text& qk_p2, const Array<crate::syntax::Arg>& args_p3, const Array<crate::lower::model::Ex>& body_p4);

prism_rtl::JobRef<Array<crate::lower::model::Ex>> start_template_args(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Text qk_p2, Array<crate::syntax::Arg> args_p3, Array<crate::lower::model::Ex> body_p4);

std::optional<crate::syntax::Arg> attr_at(const Array<crate::syntax::decls::FnClause>& clauses_p0, const Nat& j_p1, const Array<crate::syntax::Arg>& args_p2);

std::optional<Text> place_name(const crate::syntax::Pattern_& p_p0);

crate::lower::model::Ex shown_text(const crate::lower::types::Vl& v_p0);

crate::lower::types::Vl given_value(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Block& b_p2, const crate::lower::model::OutTy& t_p3, const crate::syntax::Range& span_p4);

prism_rtl::JobRef<crate::lower::types::Vl> start_given_value(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Block b_p2, crate::lower::model::OutTy t_p3, crate::syntax::Range span_p4);

crate::lower::model::Do given_bind(const bool& is_try_p0, const crate::lower::model::Pa& pa_p1, const crate::lower::model::Ex& x_p2, const Text& label_p3, const crate::lower::model::OutTy& t_p4);

Text source_text(const crate::lower::Lx& lx_p0, const crate::syntax::Range& r_p1);

crate::lower::types::Vl update_value(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& target_p2, const crate::syntax::Block& b_p3, const crate::lower::model::OutTy& t_p4, const crate::syntax::Range& span_p5);

prism_rtl::JobRef<crate::lower::types::Vl> start_update_value(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr target_p2, crate::syntax::Block b_p3, crate::lower::model::OutTy t_p4, crate::syntax::Range span_p5);

std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmts(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Array<crate::syntax::Stmt>& stmts_p2);

prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> start_upd_stmts(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Array<crate::syntax::Stmt> stmts_p2);

std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmt(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Stmt& s_p2);

prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> start_upd_stmt(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Stmt s_p2);

crate::lower::model::Do upd_for(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const std::optional<crate::syntax::ForBinders>& binders_o2, const crate::syntax::Expr& source_p3, const crate::syntax::Block& body_p4, const crate::syntax::Range& span_p5);

prism_rtl::JobRef<crate::lower::model::Do> start_upd_for(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, std::optional<crate::syntax::ForBinders> binders_o2, crate::syntax::Expr source_p3, crate::syntax::Block body_p4, crate::syntax::Range span_p5);

crate::lower::model::Do upd_for_refs(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::SName& n_p2, const crate::syntax::Expr& source_p3, const crate::syntax::Block& body_p4, const crate::syntax::Range& span_p5, const crate::check::types::Ty& sty_p6);

prism_rtl::JobRef<crate::lower::model::Do> start_upd_for_refs(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::SName n_p2, crate::syntax::Expr source_p3, crate::syntax::Block body_p4, crate::syntax::Range span_p5, crate::check::types::Ty sty_p6);

std::optional<crate::syntax::SName> ref_binder(const std::optional<crate::syntax::ForBinders>& opt0);

bool is_ref_path(const crate::syntax::Expr& e_p0);

crate::lower::model::Do upd_for_values(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const std::optional<crate::syntax::ForBinders>& binders_o2, const crate::syntax::Expr& source_p3, const crate::syntax::Block& body_p4, const crate::syntax::Range& span_p5, const crate::check::types::Ty& sty_p6);

prism_rtl::JobRef<crate::lower::model::Do> start_upd_for_values(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, std::optional<crate::syntax::ForBinders> binders_o2, crate::syntax::Expr source_p3, crate::syntax::Block body_p4, crate::syntax::Range span_p5, crate::check::types::Ty sty_p6);

crate::lower::model::Do upd_if(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Cond& c_p2, const crate::syntax::Block& then_b_p3, const std::optional<crate::syntax::Block>& else_b_o4);

prism_rtl::JobRef<crate::lower::model::Do> start_upd_if(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Cond c_p2, crate::syntax::Block then_b_p3, std::optional<crate::syntax::Block> else_b_o4);

crate::lower::model::Do upd_match(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& scrut_p2, const Array<crate::syntax::Arm>& arms_p3);

prism_rtl::JobRef<crate::lower::model::Do> start_upd_match(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr scrut_p2, Array<crate::syntax::Arm> arms_p3);

crate::lower::model::Ex all_of(const Array<crate::lower::model::Ex>& xs0);

Array<crate::lower::model::Do> arm_dos(const crate::lower::model::Ex& ex0);

Array<crate::lower::model::Cc> guard_conds(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const std::optional<crate::syntax::Expr>& opt2);

prism_rtl::JobRef<Array<crate::lower::model::Cc>> start_guard_conds(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, std::optional<crate::syntax::Expr> opt2);

crate::lower::model::Ex place_of(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2);

prism_rtl::JobRef<crate::lower::model::Ex> start_place_of(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2);

crate::lower::model::Do assign(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& target_p2, const crate::lower::model::Ex& v_p3);

prism_rtl::JobRef<crate::lower::model::Do> start_assign(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr target_p2, crate::lower::model::Ex v_p3);

}  // namespace lower::templates


namespace lower::templates {

/// The step machine of `TemplateValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplateValue: unbounded fn Lx, Env, Template -> Vl
struct TemplateValue : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Template tp_p2;
    TemplateValue(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Template tp_p2) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), tp_p2(std::move(tp_p2)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `TemplatePartDos`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplatePartDos: unbounded fn Lx, Env, TemplatePart -> [Do]
struct TemplatePartDos : prism_rtl::Job<Array<crate::lower::model::Do>> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::TemplatePart part_p2;
    TemplatePartDos(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::TemplatePart part_p2) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), part_p2(std::move(part_p2)) {}
    prism_rtl::Turn<Array<crate::lower::model::Do>> cycle() const override;
};


/// The step machine of `TemplateArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplateArgs: unbounded fn Lx, Env, Text, [Arg], [Ex] -> [Ex]
struct TemplateArgs : prism_rtl::Job<Array<crate::lower::model::Ex>> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    Text qk_p2;
    Array<crate::syntax::Arg> args_p3;
    Array<crate::lower::model::Ex> body_p4;
    TemplateArgs(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Text qk_p2, Array<crate::syntax::Arg> args_p3, Array<crate::lower::model::Ex> body_p4) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), qk_p2(std::move(qk_p2)), args_p3(std::move(args_p3)), body_p4(std::move(body_p4)) {}
    prism_rtl::Turn<Array<crate::lower::model::Ex>> cycle() const override;
};


/// The step machine of `GivenValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GivenValue: unbounded fn Lx, Env, Block, OutTy, Range -> Vl
struct GivenValue : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Block b_p2;
    crate::lower::model::OutTy t_p3;
    crate::syntax::Range span_p4;
    GivenValue(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Block b_p2, crate::lower::model::OutTy t_p3, crate::syntax::Range span_p4) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), b_p2(std::move(b_p2)), t_p3(std::move(t_p3)), span_p4(std::move(span_p4)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `UpdateValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdateValue: unbounded fn Lx, Env, Expr, Block, OutTy, Range -> Vl
struct UpdateValue : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Expr target_p2;
    crate::syntax::Block b_p3;
    crate::lower::model::OutTy t_p4;
    crate::syntax::Range span_p5;
    UpdateValue(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr target_p2, crate::syntax::Block b_p3, crate::lower::model::OutTy t_p4, crate::syntax::Range span_p5) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), target_p2(std::move(target_p2)), b_p3(std::move(b_p3)), t_p4(std::move(t_p4)), span_p5(std::move(span_p5)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `UpdStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdStmts: unbounded fn Lx, Env, [Stmt] -> (([Do], Env))
struct UpdStmts : prism_rtl::Job<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    Array<crate::syntax::Stmt> stmts_p2;
    UpdStmts(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Array<crate::syntax::Stmt> stmts_p2) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), stmts_p2(std::move(stmts_p2)) {}
    prism_rtl::Turn<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> cycle() const override;
};


/// The step machine of `UpdStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdStmt: unbounded fn Lx, Env, Stmt -> (([Do], Env))
struct UpdStmt : prism_rtl::Job<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Stmt s_p2;
    UpdStmt(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Stmt s_p2) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), s_p2(std::move(s_p2)) {}
    prism_rtl::Turn<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> cycle() const override;
};


/// The step machine of `UpdFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdFor: unbounded fn Lx, Env, ?ForBinders, Expr, Block, Range -> Do
struct UpdFor : prism_rtl::Job<crate::lower::model::Do> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    std::optional<crate::syntax::ForBinders> binders_o2;
    crate::syntax::Expr source_p3;
    crate::syntax::Block body_p4;
    crate::syntax::Range span_p5;
    UpdFor(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, std::optional<crate::syntax::ForBinders> binders_o2, crate::syntax::Expr source_p3, crate::syntax::Block body_p4, crate::syntax::Range span_p5) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), binders_o2(std::move(binders_o2)), source_p3(std::move(source_p3)), body_p4(std::move(body_p4)), span_p5(std::move(span_p5)) {}
    prism_rtl::Turn<crate::lower::model::Do> cycle() const override;
};


/// The step machine of `UpdForRefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdForRefs: unbounded fn Lx, Env, SName, Expr, Block, Range, Ty -> Do
struct UpdForRefs : prism_rtl::Job<crate::lower::model::Do> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::SName n_p2;
    crate::syntax::Expr source_p3;
    crate::syntax::Block body_p4;
    crate::syntax::Range span_p5;
    crate::check::types::Ty sty_p6;
    UpdForRefs(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::SName n_p2, crate::syntax::Expr source_p3, crate::syntax::Block body_p4, crate::syntax::Range span_p5, crate::check::types::Ty sty_p6) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), n_p2(std::move(n_p2)), source_p3(std::move(source_p3)), body_p4(std::move(body_p4)), span_p5(std::move(span_p5)), sty_p6(std::move(sty_p6)) {}
    prism_rtl::Turn<crate::lower::model::Do> cycle() const override;
};


/// The step machine of `UpdForValues`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdForValues: unbounded fn Lx, Env, ?ForBinders, Expr, Block, Range, Ty -> Do
struct UpdForValues : prism_rtl::Job<crate::lower::model::Do> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    std::optional<crate::syntax::ForBinders> binders_o2;
    crate::syntax::Expr source_p3;
    crate::syntax::Block body_p4;
    crate::syntax::Range span_p5;
    crate::check::types::Ty sty_p6;
    UpdForValues(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, std::optional<crate::syntax::ForBinders> binders_o2, crate::syntax::Expr source_p3, crate::syntax::Block body_p4, crate::syntax::Range span_p5, crate::check::types::Ty sty_p6) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), binders_o2(std::move(binders_o2)), source_p3(std::move(source_p3)), body_p4(std::move(body_p4)), span_p5(std::move(span_p5)), sty_p6(std::move(sty_p6)) {}
    prism_rtl::Turn<crate::lower::model::Do> cycle() const override;
};


/// The step machine of `UpdIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdIf: unbounded fn Lx, Env, Cond, Block, ?Block -> Do
struct UpdIf : prism_rtl::Job<crate::lower::model::Do> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Cond c_p2;
    crate::syntax::Block then_b_p3;
    std::optional<crate::syntax::Block> else_b_o4;
    UpdIf(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Cond c_p2, crate::syntax::Block then_b_p3, std::optional<crate::syntax::Block> else_b_o4) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), c_p2(std::move(c_p2)), then_b_p3(std::move(then_b_p3)), else_b_o4(std::move(else_b_o4)) {}
    prism_rtl::Turn<crate::lower::model::Do> cycle() const override;
};


/// The step machine of `UpdMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdMatch: unbounded fn Lx, Env, Expr, [Arm] -> Do
struct UpdMatch : prism_rtl::Job<crate::lower::model::Do> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Expr scrut_p2;
    Array<crate::syntax::Arm> arms_p3;
    UpdMatch(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr scrut_p2, Array<crate::syntax::Arm> arms_p3) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), scrut_p2(std::move(scrut_p2)), arms_p3(std::move(arms_p3)) {}
    prism_rtl::Turn<crate::lower::model::Do> cycle() const override;
};


/// The step machine of `GuardConds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GuardConds: unbounded fn Lx, Env, ?Expr -> [Cc]
struct GuardConds : prism_rtl::Job<Array<crate::lower::model::Cc>> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    std::optional<crate::syntax::Expr> opt2;
    GuardConds(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, std::optional<crate::syntax::Expr> opt2) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), opt2(std::move(opt2)) {}
    prism_rtl::Turn<Array<crate::lower::model::Cc>> cycle() const override;
};


/// The step machine of `PlaceOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PlaceOf: unbounded fn Lx, Env, Expr -> Ex
struct PlaceOf : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Expr e_p2;
    PlaceOf(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), e_p2(std::move(e_p2)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `Assign`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Assign: unbounded fn Lx, Env, Expr, Ex -> Do
struct Assign : prism_rtl::Job<crate::lower::model::Do> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Expr target_p2;
    crate::lower::model::Ex v_p3;
    Assign(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr target_p2, crate::lower::model::Ex v_p3) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), target_p2(std::move(target_p2)), v_p3(std::move(v_p3)) {}
    prism_rtl::Turn<crate::lower::model::Do> cycle() const override;
};


}  // namespace lower::templates

}  // namespace crate
