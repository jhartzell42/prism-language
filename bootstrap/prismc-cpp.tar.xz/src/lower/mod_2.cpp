// The module `Lower`, from `target/bootstrap/cpp-src/prismc/lower/mod.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include <lower/module.hpp>
#include <lower/node_/module.hpp>
#include <syntax/module.hpp>
#include <check/env/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/passes/module.hpp>
#include <check/shrink/module.hpp>
#include <check/typed/module.hpp>
#include <check/types/module.hpp>
#include <lower/model/module.hpp>
#include <syntax/lexer/module.hpp>
#include <lower/node_/generic.hpp>
#include <check/env/generic.hpp>
#include <syntax/lexer/generic.hpp>

namespace crate::lower {

prism_rtl::Turn<Vl> Application::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& callee = this->callee;
    const auto& args = this->args;
    const auto& span = this->span;
    auto args_1 = args;
    auto callee_2 = callee;
    auto env_3 = env;
    auto lx_4 = lx;
    auto span_5 = span;
    return call_then(start_out_ty_of(lx_4, peel(type_at(lx_4, span_5))), [=](crate::lower::model::OutTy out_ty_of_46794) {
        return ({
            auto t = out_ty_of_46794;
            ({
            auto&& _m = callee_2.kind;
            prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            ({
            auto nkey = name_key_at(lx_4, env_3, n, callee_2.span);
            auto local_opt = len(n->path_) == Nat(1u)
                ? crate::prelude::get(env_3->names, nkey)
                : std::optional<Bn>{};
            ({
            prism_rtl::is_some(local_opt) && prism_rtl::is<Bn::BnLocalFn>(prism_rtl::some_of(local_opt)) ? ({
            auto&& c = prism_rtl::as<Bn::BnLocalFn>(prism_rtl::some_of(local_opt)).a0;
            prism_rtl::more(prism_rtl::rc(InlineLocalFn(lx_4, env_3, c, args_1, t)));
        })
            : prism_rtl::is_some(local_opt) ? ({
            auto&& b = prism_rtl::some_of(local_opt);
            ({
            auto n_6 = n;
            call_then(start_name_value(lx_4, env_3, n_6, callee_2.span), [=](Vl name_value_47143) {
            return ({
                auto f = name_value_47143;
                ({
                auto&& _m = value_ty(f);
                prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m) ? call_then(start_start_args(lx_4, env_3, f, args_1), [=](Array<crate::lower::model::Ex> start_args_47337) { return prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("run_to_end"), Array(std::vector{start_call(f, start_args_47337)})}), t})); })
                : call_value(each_job(args_1, ({
                auto lx_4_7 = lx_4;
                auto env_3_7 = env_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=](crate::syntax::Arg p0) {
                return ({
                    auto lx_4_7_7 = lx_4_7;
                    auto env_3_7_7 = env_3_7;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        (prism_rtl::more(prism_rtl::rc(Argument(lx_4_7_7, env_3_7_7, a->value))));
                    });
                }));
                });
            })));
            })), [=](Array<crate::lower::model::Ex> each_47433) { return prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XApply{prism_rtl::rc(ref_(f)), each_47433}), t})); });
            });
            });
        });
        });
        })
            : prism_rtl::is_none(local_opt) ? ({
            auto [qk_opt, why] = crate::check::env::resolve_value(lx_4.g, lx_4.home, n);
            ({
            prism_rtl::is_some(qk_opt) ? ({
            auto&& qk = prism_rtl::some_of(qk_opt);
            ({
            auto&& _m = crate::prelude::get(lx_4.g.tags, qk);
            prism_rtl::is_some(_m) && ({
            auto&& tg = prism_rtl::some_of(_m);
            (why == Text::lit("tag"));
        }) ? ({
            auto&& tg = prism_rtl::some_of(_m);
            prism_rtl::more(prism_rtl::rc(TagValue(lx_4, env_3, tg, args_1)));
        })
            : qk == Text::lit("Prelude.@Element")
            ? prism_rtl::more(prism_rtl::rc(ElementBlueprint(lx_4, env_3, args_1, t)))
            : prism_rtl::more(prism_rtl::rc(GlobalCall(lx_4, env_3, qk, args_1, span_5, t)));
        });
        })
            : prism_rtl::is_none(qk_opt) ? prism_rtl::finished(Vl(Vl::VlOwned{refusal(prism_rtl::cat("a call of ", nkey, ", which nothing declares")), t}))
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
            prism_rtl::more(prism_rtl::rc(Application(lx_4, env_3, x, args_1, span_5)));
        })
            : call_then(start_value_of(lx_4, env_3, callee_2), [=](Vl value_of_48256) {
            return ({
                auto f = value_of_48256;
                ({
                auto&& _m = value_ty(f);
                prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m) ? call_then(start_start_args(lx_4, env_3, f, args_1), [=](Array<crate::lower::model::Ex> start_args_48396) { return prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("run_to_end"), Array(std::vector{start_call(f, start_args_48396)})}), t})); })
                : call_value(each_job(args_1, ({
                auto lx_4_6 = lx_4;
                auto env_3_6 = env_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=](crate::syntax::Arg p0) {
                return ({
                    auto lx_4_6_6 = lx_4_6;
                    auto env_3_6_6 = env_3_6;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        (prism_rtl::more(prism_rtl::rc(Argument(lx_4_6_6, env_3_6_6, a->value))));
                    });
                }));
                });
            })));
            })), [=](Array<crate::lower::model::Ex> each_48484) { return prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XApply{prism_rtl::rc(ref_(f)), each_48484}), t})); });
            });
            });
        });
        });
        });
    });
}


/// `Start Application, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_application(Lx lx, Env env, crate::syntax::Expr callee, Array<crate::syntax::Arg> args, crate::syntax::Range span) {
    return prism_rtl::make_rc<Application>(lx, env, callee, args, span);
}


/// InlineLocalFn: unbounded fn Lx, Env, FnClause, [Arg], OutTy -> Vl
Vl inline_local_fn(const Lx& lx, const Env& env, const crate::syntax::FnClause& c, const Array<crate::syntax::Arg>& args, const crate::lower::model::OutTy& t) {
    auto names = each(c.params, [&](const crate::syntax::Pattern_& p_) { return plain_binder(lx, p_); });
    return fold(names, false, [&](const bool& bad, const Text& nm) { return bad || (nm == Text::lit("")); })
        ? Vl(Vl::VlOwned{refusal(Text::lit("a local function whose parameters are not names")), t})
        : ({
        auto [dos, env2] = run_to_end(fold_job(crate::check::errors::range0(len(names)), std::tuple{Array<crate::lower::model::Do>{}, env}, ({
            auto names_1 = names;
            auto lx_2 = lx;
            auto c_3 = c;
            auto args_4 = args;
            auto env_5 = env;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, Env>>(std::tuple<std::tuple<Array<crate::lower::model::Do>, Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::lower::model::Do>, Env>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto names_1_6 = names_1;
                auto lx_2_6 = lx_2;
                auto c_3_6 = c_3;
                auto args_4_6 = args_4;
                auto env_5_6 = env_5;
                entered(once_job([=]() {
                return ({
                    auto [acc, en] = p0;
                    auto i = p1;
                    ({
                    auto nm = or_(index(names_1_6, i), Text::lit(""));
                    auto rs = prism_rtl::cat(local_name(lx_2_6, nm), "_", c_3_6.span.start);
                    auto v_ = ({
                        __label__ _done;
                        prism_rtl::Slot<Vl> _v;
                        auto&& _m = index(args_4_6, i);
                        if (prism_rtl::is_some(_m)) {
                            auto&& a = prism_rtl::some_of(_m);
                            _v.set(value_of(lx_2_6, env_5_6, a->value));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    auto bt = value_ty(v_);
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{rs}), own(v_)})), bind(en, nm, Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs}), Holding(Holding::Owned{}), bt}))}));
                });
                });
            }));
            });
        }));
        })));
        (Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos, prism_rtl::rc(fn_body_value(lx, env2, c.body))}), t}));
    });
}


prism_rtl::Turn<Vl> InlineLocalFn::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& c = this->c;
    const auto& args = this->args;
    const auto& t = this->t;
    auto names = each(c.params, [&](const crate::syntax::Pattern_& p_) { return plain_binder(lx, p_); });
    return fold(names, false, [&](const bool& bad, const Text& nm) { return bad || (nm == Text::lit("")); })
        ? prism_rtl::finished(Vl(Vl::VlOwned{refusal(Text::lit("a local function whose parameters are not names")), t}))
        : ({
        auto args_1 = args;
        auto c_2 = c;
        auto env_3 = env;
        auto lx_4 = lx;
        auto t_5 = t;
        call_value(fold_job(crate::check::errors::range0(len(names)), std::tuple{Array<crate::lower::model::Do>{}, env_3}, ({
        auto names_6 = names;
        auto lx_4_7 = lx_4;
        auto c_2_7 = c_2;
        auto args_1_7 = args_1;
        auto env_3_7 = env_3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, Env>>(std::tuple<std::tuple<Array<crate::lower::model::Do>, Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::lower::model::Do>, Env>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto names_6_7 = names_6;
            auto lx_4_7_7 = lx_4_7;
            auto c_2_7_7 = c_2_7;
            auto args_1_7_7 = args_1_7;
            auto env_3_7_7 = env_3_7;
            entered(once_job([=]() {
            return ({
                auto [acc, en] = p0;
                auto i = p1;
                ({
                auto nm = or_(index(names_6_7, i), Text::lit(""));
                auto rs = prism_rtl::cat(local_name(lx_4_7_7, nm), "_", c_2_7_7.span.start);
                auto v_ = ({
                    __label__ _done;
                    prism_rtl::Slot<Vl> _v;
                    auto&& _m = index(args_1_7_7, i);
                    if (prism_rtl::is_some(_m)) {
                        auto&& a = prism_rtl::some_of(_m);
                        _v.set(value_of(lx_4_7_7, env_3_7_7, a->value));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto bt = value_ty(v_);
                (prism_rtl::finished(std::tuple{crate::prelude::push(acc, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{rs}), own(v_)})), bind(en, nm, Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs}), Holding(Holding::Owned{}), bt}))}));
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<crate::lower::model::Do>, Env> fold_49070) {
        return ({
            auto [dos, env2] = fold_49070;
            call_then(start_fn_body_value(lx_4, env2, c_2.body), [=](crate::lower::model::Ex fn_body_value_49516) { return prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos, prism_rtl::rc(fn_body_value_49516)}), t_5})); });
        });
    });
    });
}


/// `Start InlineLocalFn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_inline_local_fn(Lx lx, Env env, crate::syntax::FnClause c, Array<crate::syntax::Arg> args, crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<InlineLocalFn>(lx, env, c, args, t);
}


/// Argument: unbounded fn Lx, Env, Expr -> Ex
crate::lower::model::Ex argument(const Lx& lx, const Env& env, const crate::syntax::Expr& e) {
    auto&& _m = crate::prelude::get(env.spans, place_key(lx, e.span));
    if (prism_rtl::is_some(_m)) {
        auto&& v_ = prism_rtl::some_of(_m);
        return ref_(v_);
    }
    if (prism_rtl::is_none(_m)) {
        return argument_by_kind(lx, env, e);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::model::Ex> Argument::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    return ({
        auto&& _m = crate::prelude::get(env.spans, place_key(lx, e.span));
        prism_rtl::is_some(_m) ? ({
        auto&& v_ = prism_rtl::some_of(_m);
        prism_rtl::finished(ref_(v_));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(ArgumentByKind(lx, env, e)))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start Argument, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_argument(Lx lx, Env env, crate::syntax::Expr e) {
    return prism_rtl::make_rc<Argument>(lx, env, e);
}


/// ArgumentByKind: unbounded fn Lx, Env, Expr -> Ex
crate::lower::model::Ex argument_by_kind(const Lx& lx, const Env& env, const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
        auto&& ps_opt = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
        return crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(lambda_arg(lx, env, or_(ps_opt, Array<crate::syntax::Pattern_>{}), body, lambda_param_tys(lx, e, len(or_(ps_opt, Array<crate::syntax::Pattern_>{})))))});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return argument(lx, env, x);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        auto t = type_at(lx, e.span);
        auto&& _m = peel(t);
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CBound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0)) {
            auto local_opt = len(n->path_) == Nat(1u)
                ? crate::prelude::get(env->names, name_key_at(lx, env, n, e.span))
                : std::optional<Bn>{};
            if (prism_rtl::is_some(local_opt)) {
                return closure_ref(value_of(lx, env, e));
            }
            if (prism_rtl::is_none(local_opt)) {
                auto&& _qk_opt = crate::check::env::resolve_value(lx.g, lx.home, n);
                auto&& qk_opt = std::get<0>(_qk_opt);
                if (prism_rtl::is_some(qk_opt)) {
                    auto&& qk = prism_rtl::some_of(qk_opt);
                    return crate::check::env::has_key(lx.g.ctors, qk)
                        ? closure_ref(value_of(lx, env, e))
                        : crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XPath{value_path(lx, qk)}))});
                }
                if (prism_rtl::is_none(qk_opt)) {
                    return ref_(value_of(lx, env, e));
                }
                prism_rtl::unreachable("no arm matched");
            }
            prism_rtl::unreachable("no arm matched");
        }
        {
            return ref_(value_of(lx, env, e));
        }
    }
    {
        return ref_(value_of(lx, env, e));
    }
}


prism_rtl::Turn<crate::lower::model::Ex> ArgumentByKind::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) ? ({
        auto&& ps_opt = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
        ({
        auto ps_opt_1 = ps_opt;
        auto body_2 = body;
        auto e_3 = e;
        auto env_4 = env;
        auto lx_5 = lx;
        call_then(start_lambda_param_tys(lx_5, e_3, len(or_(ps_opt_1, Array<crate::syntax::Pattern_>{}))), [=](Array<crate::lower::model::OutTy> lambda_param_tys_49954) { return call_then(start_lambda_arg(lx_5, env_4, or_(ps_opt_1, Array<crate::syntax::Pattern_>{}), body_2, lambda_param_tys_49954), [=](crate::lower::model::Ex lambda_arg_49912) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(lambda_arg_49912)})); }); });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(Argument(lx, env, x)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        ({
        auto t = type_at(lx, e.span);
        ({
        auto&& _m = peel(t);
        prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CBound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0) ? ({
        auto local_opt = len(n->path_) == Nat(1u)
            ? crate::prelude::get(env->names, name_key_at(lx, env, n, e.span))
            : std::optional<Bn>{};
        ({
        prism_rtl::is_some(local_opt) ? ({
        auto e_1 = e;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(start_value_of(lx_3, env_2, e_1), [=](Vl value_of_50316) { return prism_rtl::finished(closure_ref(value_of_50316)); });
    })
        : prism_rtl::is_none(local_opt) ? ({
        auto&& _qk_opt = crate::check::env::resolve_value(lx.g, lx.home, n);
        auto&& qk_opt = std::get<0>(_qk_opt);
        ({
        prism_rtl::is_some(qk_opt) ? ({
        auto&& qk = prism_rtl::some_of(qk_opt);
        crate::check::env::has_key(lx.g.ctors, qk)
        ? ({
        auto e_1 = e;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(start_value_of(lx_3, env_2, e_1), [=](Vl value_of_50544) { return prism_rtl::finished(closure_ref(value_of_50544)); });
    })
        : prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XPath{value_path(lx, qk)}))}));
    })
        : prism_rtl::is_none(qk_opt) ? ({
        auto e_1 = e;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(start_value_of(lx_3, env_2, e_1), [=](Vl value_of_50640) { return prism_rtl::finished(ref_(value_of_50640)); });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : ({
        auto e_1 = e;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(start_value_of(lx_3, env_2, e_1), [=](Vl value_of_50688) { return prism_rtl::finished(ref_(value_of_50688)); });
    });
    });
    });
    })
        : ({
        auto e_1 = e;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(start_value_of(lx_3, env_2, e_1), [=](Vl value_of_50728) { return prism_rtl::finished(ref_(value_of_50728)); });
    });
    });
}


/// `Start ArgumentByKind, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_argument_by_kind(Lx lx, Env env, crate::syntax::Expr e) {
    return prism_rtl::make_rc<ArgumentByKind>(lx, env, e);
}


/// ClosureRef: fn Vl -> Ex
crate::lower::model::Ex closure_ref(const Vl& vl0) {
    if (prism_rtl::is<Vl::VlPlace>(vl0) && prism_rtl::is<Holding::ByRef>(prism_rtl::as<Vl::VlPlace>(vl0).a1)) {
        auto&& x = prism_rtl::as<Vl::VlPlace>(vl0).a0;
        auto&& t = prism_rtl::as<Vl::VlPlace>(vl0).a2;
        return x;
    }
    if (prism_rtl::is<Vl::VlPlace>(vl0)) {
        auto&& x = prism_rtl::as<Vl::VlPlace>(vl0).a0;
        auto&& t = prism_rtl::as<Vl::VlPlace>(vl0).a2;
        return crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(x)}))});
    }
    if (prism_rtl::is<Vl::VlOwned>(vl0)) {
        auto&& x = prism_rtl::as<Vl::VlOwned>(vl0).a0;
        auto&& t = prism_rtl::as<Vl::VlOwned>(vl0).a1;
        return crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(x)}))});
    }
    prism_rtl::unreachable("no arm matched");
}


/// TagValue: unbounded fn Lx, Env, TagInfo, [Arg] -> Vl
Vl tag_value(const Lx& lx, const Env& env, const crate::check::env::TagInfo& tg, const Array<crate::syntax::Arg>& args) {
    auto [variant, struct_path] = tag_paths(lx, tg);
    auto t = crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{kind_path(lx, tg.kind), Array<crate::lower::model::OutTy>{}});
    auto&& _m = tg.kind;
    {
        auto&& m51479_0 = _m;
        if (m51479_0 == Text::lit("Element")) {
            return Vl(Vl::VlOwned{refusal(prism_rtl::cat("an element as a plain value (", tg.name, "): a live element comes from its host")), t});
        }
    }
    {
        auto&& m51479_1 = _m;
        if (m51479_1 == Text::lit("Prelude.Fault")) {
            return Vl(Vl::VlOwned{refusal(prism_rtl::cat("a fault kind applied (", tg.name, ")")), t});
        }
    }
    {
        auto named = fold(args, false, [&](const bool& f, const crate::syntax::Arg& a) { return f || is_named_arg(a); });
        auto fields = run_to_end(each_job(crate::check::errors::range0(len(tg.fields)), ({
            auto tg_1 = tg;
            auto named_2 = named;
            auto args_3 = args;
            auto lx_4 = lx;
            auto env_5 = env;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::lower::model::Ex>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto tg_1_6 = tg_1;
                auto named_2_6 = named_2;
                auto args_3_6 = args_3;
                auto lx_4_6 = lx_4;
                auto env_5_6 = env_5;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    ({
                    auto&& _fname = or_(index(tg_1_6.fields, i), std::tuple{Text::lit(""), crate::check::types::Ty(crate::check::types::Ty::TyErr{})});
                    auto&& fname = std::get<0>(_fname);
                    auto arg_opt = named_2_6
                        ? crate::lower::node_::tag_arg(args_3_6, fname)
                        : ({
                        __label__ _done;
                        prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                        auto&& _m = index(args_3_6, i);
                        if (prism_rtl::is_some(_m)) {
                            auto&& a = prism_rtl::some_of(_m);
                            _v.set(std::optional(a->value));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(std::optional<crate::syntax::Expr>{});
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    auto v_ = ({
                        __label__ _done;
                        prism_rtl::Slot<crate::lower::model::Ex> _v;
                        if (prism_rtl::is_some(arg_opt)) {
                            auto&& x = prism_rtl::some_of(arg_opt);
                            _v.set(own(value_of(lx_4_6, env_5_6, x)));
                            goto _done;
                        }
                        if (prism_rtl::is_none(arg_opt)) {
                            _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Default::default"), Array<crate::lower::model::Ex>{}}));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    (prism_rtl::finished(std::tuple{snake(fname), v_}));
                });
                });
            }));
            });
        }));
        })));
        return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRecord{struct_path, fields})})}), t});
    }
}


prism_rtl::Turn<Vl> TagValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& tg = this->tg;
    const auto& args = this->args;
    auto [variant, struct_path] = tag_paths(lx, tg);
    auto t = crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{kind_path(lx, tg.kind), Array<crate::lower::model::OutTy>{}});
    return ({
        auto&& _m = tg.kind;
        ({
        auto&& m51479_0 = _m;
        (m51479_0 == Text::lit("Element"));
    }) ? ({
        auto&& m51479_0 = _m;
        prism_rtl::finished(Vl(Vl::VlOwned{refusal(prism_rtl::cat("an element as a plain value (", tg.name, "): a live element comes from its host")), t}));
    })
        : ({
        auto&& m51479_1 = _m;
        (m51479_1 == Text::lit("Prelude.Fault"));
    }) ? ({
        auto&& m51479_1 = _m;
        prism_rtl::finished(Vl(Vl::VlOwned{refusal(prism_rtl::cat("a fault kind applied (", tg.name, ")")), t}));
    })
        : ({
        auto named = fold(args, false, [&](const bool& f, const crate::syntax::Arg& a) { return f || is_named_arg(a); });
        auto args_1 = args;
        auto env_2 = env;
        auto lx_3 = lx;
        auto tg_4 = tg;
        call_value(each_job(crate::check::errors::range0(len(tg_4.fields)), ({
        auto tg_4_5 = tg_4;
        auto named_5 = named;
        auto args_1_6 = args_1;
        auto lx_3_6 = lx_3;
        auto env_2_6 = env_2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::lower::model::Ex>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto tg_4_5_6 = tg_4_5;
            auto named_5_6 = named_5;
            auto args_1_6_6 = args_1_6;
            auto lx_3_6_6 = lx_3_6;
            auto env_2_6_6 = env_2_6;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto&& _fname = or_(index(tg_4_5_6.fields, i), std::tuple{Text::lit(""), crate::check::types::Ty(crate::check::types::Ty::TyErr{})});
                auto&& fname = std::get<0>(_fname);
                auto arg_opt = named_5_6
                    ? crate::lower::node_::tag_arg(args_1_6_6, fname)
                    : ({
                    __label__ _done;
                    prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                    auto&& _m = index(args_1_6_6, i);
                    if (prism_rtl::is_some(_m)) {
                        auto&& a = prism_rtl::some_of(_m);
                        _v.set(std::optional(a->value));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(std::optional<crate::syntax::Expr>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto v_ = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::lower::model::Ex> _v;
                    if (prism_rtl::is_some(arg_opt)) {
                        auto&& x = prism_rtl::some_of(arg_opt);
                        _v.set(own(value_of(lx_3_6_6, env_2_6_6, x)));
                        goto _done;
                    }
                    if (prism_rtl::is_none(arg_opt)) {
                        _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Default::default"), Array<crate::lower::model::Ex>{}}));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                (prism_rtl::finished(std::tuple{snake(fname), v_}));
            });
            });
        }));
        });
    }));
    })), [=](Array<std::tuple<Text, crate::lower::model::Ex>> each_51805) {
        return ({
            auto fields = each_51805;
            (prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRecord{struct_path, fields})})}), t})));
        });
    });
    });
    });
}


/// `Start TagValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_tag_value(Lx lx, Env env, crate::check::env::TagInfo tg, Array<crate::syntax::Arg> args) {
    return prism_rtl::make_rc<TagValue>(lx, env, tg, args);
}


/// GlobalCall: unbounded fn Lx, Env, Text, [Arg], Range, OutTy -> Vl
Vl global_call(const Lx& lx, const Env& env, const Text& qk, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span, const crate::lower::model::OutTy& t) {
    auto&& _m = crate::prelude::get(lx.g.ctors, qk);
    if (prism_rtl::is_some(_m)) {
        auto&& c = prism_rtl::some_of(_m);
        return ctor_app(lx, env, c, args, span);
    }
    if (prism_rtl::is_none(_m)) {
        auto&& _m = crate::prelude::get(lx.g.vals, qk);
        if (prism_rtl::is_some(_m)) {
            auto&& v_ = prism_rtl::some_of(_m);
            return v_.sort == Text::lit("method")
                ? method_call(lx, env, v_, args, span, t)
                : v_.home == Text::lit("Prelude")
                ? prelude_call(lx, env, qk, args, span, t)
                : Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{value_path(lx, qk), args_for(lx, env, v_, args)}), t});
        }
        if (prism_rtl::is_none(_m)) {
            return Vl(Vl::VlOwned{refusal(prism_rtl::cat("a call of ", qk)), t});
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Vl> GlobalCall::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& qk = this->qk;
    const auto& args = this->args;
    const auto& span = this->span;
    const auto& t = this->t;
    return ({
        auto&& _m = crate::prelude::get(lx.g.ctors, qk);
        prism_rtl::is_some(_m) ? ({
        auto&& c = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(CtorApp(lx, env, c, args, span)));
    })
        : prism_rtl::is_none(_m) ? ({
        auto&& _m = crate::prelude::get(lx.g.vals, qk);
        prism_rtl::is_some(_m) ? ({
        auto&& v_ = prism_rtl::some_of(_m);
        v_.sort == Text::lit("method")
        ? prism_rtl::more(prism_rtl::rc(MethodCall(lx, env, v_, args, span, t)))
        : v_.home == Text::lit("Prelude")
        ? prism_rtl::more(prism_rtl::rc(PreludeCall(lx, env, qk, args, span, t)))
        : ({
        auto args_1 = args;
        auto env_2 = env;
        auto lx_3 = lx;
        auto qk_4 = qk;
        auto t_5 = t;
        call_then(start_args_for(lx_3, env_2, v_, args_1), [=](Array<crate::lower::model::Ex> args_for_52845) { return prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{value_path(lx_3, qk_4), args_for_52845}), t_5})); });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(Vl(Vl::VlOwned{refusal(prism_rtl::cat("a call of ", qk)), t}))
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start GlobalCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_global_call(Lx lx, Env env, Text qk, Array<crate::syntax::Arg> args, crate::syntax::Range span, crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<GlobalCall>(lx, env, qk, args, span, t);
}


/// ArgsFor: unbounded fn Lx, Env, ValInfo, [Arg] -> [Ex]
Array<crate::lower::model::Ex> args_for(const Lx& lx, const Env& env, const crate::check::env::ValInfo& v_, const Array<crate::syntax::Arg>& args) {
    auto ps = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
        auto&& _m = v_.scheme.ty;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& xs = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            _v.set(xs);
            goto _done;
        }
        {
            _v.set(Array<crate::check::types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return run_to_end(each_job(crate::check::errors::range0(len(args)), ({
        auto args_1 = args;
        auto ps_2 = ps;
        auto lx_3 = lx;
        auto env_4 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto args_1_5 = args_1;
            auto ps_2_5 = ps_2;
            auto lx_3_5 = lx_3;
            auto env_4_5 = env_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto a = or_(index(args_1_5, i), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = dummy_expr(), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}});
                auto is_try = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = peel(or_(index(ps_2_5, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})));
                    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
                        auto&& m53411_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
                        if (m53411_0_0 == Text::lit("~")) {
                            _v.set(true);
                            goto _done;
                        }
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto is_error = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = peel(type_at(lx_3_5, a->value.span));
                    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
                        auto&& m53528_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
                        if (m53528_0_0 == Text::lit("Prelude.Error")) {
                            _v.set(true);
                            goto _done;
                        }
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto to_unbounded = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = peel(or_(index(ps_2_5, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})));
                    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CBound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0)) {
                        _v.set(false);
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
                        _v.set(true);
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                is_try && is_error
                ? call_then(start_value_of(lx_3_5, env_4_5, a->value), [=](Vl value_of_53877) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{own(value_of_53877)})}))})); })
                : to_unbounded
                ? call_then(start_as_job_value(lx_3_5, env_4_5, a->value), [=](crate::lower::model::Ex as_job_value_53942) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(as_job_value_53942)})); })
                : prism_rtl::more(prism_rtl::rc(Argument(lx_3_5, env_4_5, a->value)));
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<crate::lower::model::Ex>> ArgsFor::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& v_ = this->v_;
    const auto& args = this->args;
    auto ps = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
        auto&& _m = v_.scheme.ty;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& xs = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            _v.set(xs);
            goto _done;
        }
        {
            _v.set(Array<crate::check::types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return each_job(crate::check::errors::range0(len(args)), ({
        auto args_1 = args;
        auto ps_2 = ps;
        auto lx_3 = lx;
        auto env_4 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto args_1_5 = args_1;
            auto ps_2_5 = ps_2;
            auto lx_3_5 = lx_3;
            auto env_4_5 = env_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto a = or_(index(args_1_5, i), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = dummy_expr(), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}});
                auto is_try = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = peel(or_(index(ps_2_5, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})));
                    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
                        auto&& m53411_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
                        if (m53411_0_0 == Text::lit("~")) {
                            _v.set(true);
                            goto _done;
                        }
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto is_error = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = peel(type_at(lx_3_5, a->value.span));
                    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
                        auto&& m53528_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
                        if (m53528_0_0 == Text::lit("Prelude.Error")) {
                            _v.set(true);
                            goto _done;
                        }
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto to_unbounded = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = peel(or_(index(ps_2_5, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})));
                    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CBound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0)) {
                        _v.set(false);
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
                        _v.set(true);
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                is_try && is_error
                ? call_then(start_value_of(lx_3_5, env_4_5, a->value), [=](Vl value_of_53877) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{own(value_of_53877)})}))})); })
                : to_unbounded
                ? call_then(start_as_job_value(lx_3_5, env_4_5, a->value), [=](crate::lower::model::Ex as_job_value_53942) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(as_job_value_53942)})); })
                : prism_rtl::more(prism_rtl::rc(Argument(lx_3_5, env_4_5, a->value)));
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start ArgsFor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::Ex>> start_args_for(Lx lx, Env env, crate::check::env::ValInfo v_, Array<crate::syntax::Arg> args) {
    return prism_rtl::make_rc<ArgsFor>(lx, env, v_, args);
}


/// let dummyExpr
crate::syntax::Expr dummy_expr() {
    return crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// CtorApp: unbounded fn Lx, Env, CtorInfo, [Arg], Range -> Vl
Vl ctor_app(const Lx& lx, const Env& env, const crate::check::env::CtorInfo& c, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span) {
    auto t = out_ty_of(lx, peel(type_at(lx, span)));
    auto owner = or_(crate::prelude::get(lx.g.types, c.owner), crate::check::env::dummy_ty_info());
    auto ty_path = path_in(lx, owner.home, camel(crate::check::types::bare_name(c.owner)));
    auto vals = ctor_args(lx, env, c, args);
    auto&& _m = c.owner;
    {
        auto&& m54557_0 = _m;
        if (m54557_0 == Text::lit("Bool")) {
            return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBool{c.name == Text::lit("True")}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})});
        }
    }
    {
        auto&& m54557_1 = _m;
        if (m54557_1 == Text::lit("Prelude.Error")) {
            auto kind = or_(index(vals, Nat(0u)), crate::lower::model::Ex(crate::lower::model::Ex::XStr{Text::lit("")}));
            auto msg = or_(index(vals, Nat(1u)), crate::lower::model::Ex(crate::lower::model::Ex::XText{Text::lit("")}));
            auto made = crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Error::new"), Array(std::vector{kind, msg})});
            if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t)) {
                return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{made})}), t});
            }
            {
                return Vl(Vl::VlOwned{made, crate::lower::model::OutTy(crate::lower::model::OutTy::OutError{})});
            }
        }
    }
    {
        auto&& _m = owner.body;
        if (prism_rtl::is<crate::check::env::TyBody::BRecord>(_m)) {
            auto&& fs = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
            return len(c.fields) == Nat(0u)
                ? Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XPath{ty_path}), t})
                : Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XRecord{ty_path, each(crate::check::errors::range0(len(c.fields)), [&](const Nat& i) { return std::tuple{snake(or_(index(c.fields, i), Text::lit(""))), or_(index(vals, i), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Default::default"), Array<crate::lower::model::Ex>{}}))}; })}), t});
        }
        if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
            auto&& cases = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
            auto is_unit_type = ((len(cases) == Nat(1u)) && (len(c->args) == Nat(0u))) && crate::check::env::is_lower_text(crate::check::types::bare_name(c.name));
            auto is_newtype = (len(cases) == Nat(1u)) && (crate::check::types::bare_name(c.name) == crate::check::types::bare_name(c.owner));
            auto path_ = is_unit_type || is_newtype
                ? ty_path
                : prism_rtl::cat(ty_path, "::", camel(crate::check::types::bare_name(c.name)));
            return len(c->args) == Nat(0u)
                ? Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XPath{path_}), t})
                : Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{path_, vals}), t});
        }
        {
            return Vl(Vl::VlOwned{refusal(prism_rtl::cat("a constructor of ", c.owner)), t});
        }
    }
}


prism_rtl::Turn<Vl> CtorApp::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& c = this->c;
    const auto& args = this->args;
    const auto& span = this->span;
    auto args_1 = args;
    auto c_2 = c;
    auto env_3 = env;
    auto lx_4 = lx;
    auto span_5 = span;
    return call_then(start_out_ty_of(lx_4, peel(type_at(lx_4, span_5))), [=](crate::lower::model::OutTy out_ty_of_54356) {
        return ({
            auto t = out_ty_of_54356;
            auto owner = or_(crate::prelude::get(lx_4.g.types, c_2.owner), crate::check::env::dummy_ty_info());
            auto ty_path = path_in(lx_4, owner.home, camel(crate::check::types::bare_name(c_2.owner)));
            call_then(start_ctor_args(lx_4, env_3, c_2, args_1), [=](Array<crate::lower::model::Ex> ctor_args_54527) {
            return ({
                auto vals = ctor_args_54527;
                ({
                auto&& _m = c_2.owner;
                ({
                auto&& m54557_0 = _m;
                (m54557_0 == Text::lit("Bool"));
            }) ? ({
                auto&& m54557_0 = _m;
                prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBool{c_2.name == Text::lit("True")}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})}));
            })
                : ({
                auto&& m54557_1 = _m;
                (m54557_1 == Text::lit("Prelude.Error"));
            }) ? ({
                auto&& m54557_1 = _m;
                ({
                auto kind = or_(index(vals, Nat(0u)), crate::lower::model::Ex(crate::lower::model::Ex::XStr{Text::lit("")}));
                auto msg = or_(index(vals, Nat(1u)), crate::lower::model::Ex(crate::lower::model::Ex::XText{Text::lit("")}));
                auto made = crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Error::new"), Array(std::vector{kind, msg})});
                ({
                prism_rtl::is<crate::lower::model::OutTy::OutRes>(t) ? prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{made})}), t}))
                : prism_rtl::finished(Vl(Vl::VlOwned{made, crate::lower::model::OutTy(crate::lower::model::OutTy::OutError{})}));
            });
            });
            })
                : ({
                auto&& _m = owner.body;
                prism_rtl::is<crate::check::env::TyBody::BRecord>(_m) ? ({
                auto&& fs = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
                len(c_2.fields) == Nat(0u)
                ? prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XPath{ty_path}), t}))
                : prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XRecord{ty_path, each(crate::check::errors::range0(len(c_2.fields)), [&](const Nat& i) { return std::tuple{snake(or_(index(c_2.fields, i), Text::lit(""))), or_(index(vals, i), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Default::default"), Array<crate::lower::model::Ex>{}}))}; })}), t}));
            })
                : prism_rtl::is<crate::check::env::TyBody::BChoice>(_m) ? ({
                auto&& cases = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
                ({
                auto is_unit_type = ((len(cases) == Nat(1u)) && (len(c_2->args) == Nat(0u))) && crate::check::env::is_lower_text(crate::check::types::bare_name(c_2.name));
                auto is_newtype = (len(cases) == Nat(1u)) && (crate::check::types::bare_name(c_2.name) == crate::check::types::bare_name(c_2.owner));
                auto path_ = is_unit_type || is_newtype
                    ? ty_path
                    : prism_rtl::cat(ty_path, "::", camel(crate::check::types::bare_name(c_2.name)));
                len(c_2->args) == Nat(0u)
                ? prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XPath{path_}), t}))
                : prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{path_, vals}), t}));
            });
            })
                : prism_rtl::finished(Vl(Vl::VlOwned{refusal(prism_rtl::cat("a constructor of ", c_2.owner)), t}));
            });
            });
            });
        });
        });
    });
}


/// `Start CtorApp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_ctor_app(Lx lx, Env env, crate::check::env::CtorInfo c, Array<crate::syntax::Arg> args, crate::syntax::Range span) {
    return prism_rtl::make_rc<CtorApp>(lx, env, c, args, span);
}


/// CtorFn: unbounded fn Lx, CtorInfo, [OutTy], Range, OutTy, Bool -> Vl
Vl ctor_fn(const Lx& lx, const crate::check::env::CtorInfo& c, const Array<crate::lower::model::OutTy>& pts, const crate::syntax::Range& span, const crate::lower::model::OutTy& t, const bool& job) {
    auto names = each(crate::check::errors::range0(len(pts)), [&](const Nat& i) { return prism_rtl::cat("a", i); });
    auto fakes = each(crate::check::errors::range0(len(pts)), [&](const Nat& i) { return crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EAbsent{})), .span = crate::syntax::Range{.start = *Nat::from_int(Int(4000000000ll)) + i, .end = *Nat::from_int(Int(4000000000ll)) + i}}, .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}}; });
    auto env = fold(crate::check::errors::range0(len(pts)), empty_env(), [&](const Env& en, const Nat& i) { return bind_span(en, place_key(lx, crate::syntax::Range{.start = *Nat::from_int(Int(4000000000ll)) + i, .end = *Nat::from_int(Int(4000000000ll)) + i}), Vl(Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XVar{or_(index(names, i), Text::lit("a"))}), job ? Holding(Holding::Owned{}) : Holding(Holding::ByRef{}), or_(index(pts, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))})); });
    auto made = own(ctor_app(lx, env, c, fakes, span));
    return job
        ? ({
        auto a = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::OutTy> _v;
            if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t)) {
                auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t).a0;
                _v.set(x);
                goto _done;
            }
            {
                _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto pa = len(pts) == Nat(1u)
            ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("a0")})), a})
            : crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(names, [&](const Text& nm) { return crate::lower::model::Pa(crate::lower::model::Pa::PaBind{nm}); })})), a});
        (Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{pa}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("once_job"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array<crate::lower::model::Pa>{}, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{made})}))})})}))})})})), t}), t}));
    })
        : ({
        auto pas = each(crate::check::errors::range0(len(pts)), [&](const Nat& i) { return crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{or_(index(names, i), Text::lit("a"))})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(or_(index(pts, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})))})}); });
        (Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, pas, prism_rtl::rc(made)})})}), t}));
    });
}


prism_rtl::Turn<Vl> CtorFn::cycle() const {
    const auto& lx = this->lx;
    const auto& c = this->c;
    const auto& pts = this->pts;
    const auto& span = this->span;
    const auto& t = this->t;
    const auto& job = this->job;
    auto names = each(crate::check::errors::range0(len(pts)), [&](const Nat& i) { return prism_rtl::cat("a", i); });
    auto fakes = each(crate::check::errors::range0(len(pts)), [&](const Nat& i) { return crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EAbsent{})), .span = crate::syntax::Range{.start = *Nat::from_int(Int(4000000000ll)) + i, .end = *Nat::from_int(Int(4000000000ll)) + i}}, .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}}; });
    auto env = fold(crate::check::errors::range0(len(pts)), empty_env(), [&](const Env& en, const Nat& i) { return bind_span(en, place_key(lx, crate::syntax::Range{.start = *Nat::from_int(Int(4000000000ll)) + i, .end = *Nat::from_int(Int(4000000000ll)) + i}), Vl(Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XVar{or_(index(names, i), Text::lit("a"))}), job ? Holding(Holding::Owned{}) : Holding(Holding::ByRef{}), or_(index(pts, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))})); });
    auto c_1 = c;
    auto job_2 = job;
    auto lx_3 = lx;
    auto pts_4 = pts;
    auto span_5 = span;
    auto t_6 = t;
    return call_then(start_ctor_app(lx_3, env, c_1, fakes, span_5), [=](Vl ctor_app_56675) {
        return ({
            auto made = own(ctor_app_56675);
            job_2
            ? ({
            auto a = ({
                __label__ _done;
                prism_rtl::Slot<crate::lower::model::OutTy> _v;
                if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t)) {
                    auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t).a0;
                    _v.set(x);
                    goto _done;
                }
                {
                    _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto pa = len(pts_4) == Nat(1u)
                ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("a0")})), a})
                : crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(names, [&](const Text& nm) { return crate::lower::model::Pa(crate::lower::model::Pa::PaBind{nm}); })})), a});
            (prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{pa}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("once_job"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array<crate::lower::model::Pa>{}, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{made})}))})})}))})})})), t_6}), t_6})));
        })
            : ({
            auto pas = each(crate::check::errors::range0(len(pts_4)), [&](const Nat& i) { return crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{or_(index(names, i), Text::lit("a"))})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(or_(index(pts_4, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})))})}); });
            (prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, pas, prism_rtl::rc(made)})})}), t_6})));
        });
        });
    });
}


/// `Start CtorFn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_ctor_fn(Lx lx, crate::check::env::CtorInfo c, Array<crate::lower::model::OutTy> pts, crate::syntax::Range span, crate::lower::model::OutTy t, bool job) {
    return prism_rtl::make_rc<CtorFn>(lx, c, pts, span, t, job);
}


/// IsNamedArg: fn Arg -> Bool
bool is_named_arg(const crate::syntax::Arg& a) {
    auto&& _m = a.name;
    if (prism_rtl::is_some(_m)) {
        return true;
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// CtorArgs: unbounded fn Lx, Env, CtorInfo, [Arg] -> [Ex]
Array<crate::lower::model::Ex> ctor_args(const Lx& lx, const Env& env, const crate::check::env::CtorInfo& c, const Array<crate::syntax::Arg>& args) {
    auto named = fold(args, false, [&](const bool& f, const crate::syntax::Arg& a) { return f || is_named_arg(a); });
    auto ordered = named
        ? each(c.fields, [&](const Text& f) {
        return fold(args, std::optional<crate::syntax::Expr>{}, [&](const std::optional<crate::syntax::Expr>& found_opt, const crate::syntax::Arg& a) {
            return ({
                __label__ _done;
                prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                auto&& _m = a.name;
                if (prism_rtl::is_some(_m)) {
                    auto&& n = prism_rtl::some_of(_m);
                    _v.set(n.name == f ? std::optional(a->value) : found_opt);
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(found_opt);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        });
    })
        : each(args, [&](const crate::syntax::Arg& a) { return std::optional(a->value); });
    return run_to_end(each_job(crate::check::errors::range0(len(ordered)), ({
        auto ordered_1 = ordered;
        auto lx_2 = lx;
        auto env_3 = env;
        auto c_4 = c;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto ordered_1_5 = ordered_1;
            auto lx_2_5 = lx_2;
            auto env_3_5 = env_3;
            auto c_4_5 = c_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto&& _m = index(ordered_1_5, i);
                prism_rtl::is_some(_m) && prism_rtl::is_some(prism_rtl::some_of(_m)) ? ({
                auto&& x = prism_rtl::some_of(prism_rtl::some_of(_m));
                call_then(start_value_of(lx_2_5, env_3_5, x), [=](Vl value_of_57940) {
                return ({
                    auto v_ = own(value_of_57940);
                    (c_4_5.owner == Text::lit("Prelude.Error")) && (i == Nat(0u))
                    ? prism_rtl::finished(v_)
                    : rc_field(lx_2_5, c_4_5.name, i)
                    ? prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{v_})}))
                    : prism_rtl::finished(v_);
                });
            });
            })
                : prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Default::default"), Array<crate::lower::model::Ex>{}}));
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<crate::lower::model::Ex>> CtorArgs::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& c = this->c;
    const auto& args = this->args;
    auto named = fold(args, false, [&](const bool& f, const crate::syntax::Arg& a) { return f || is_named_arg(a); });
    auto ordered = named
        ? each(c.fields, [&](const Text& f) {
        return fold(args, std::optional<crate::syntax::Expr>{}, [&](const std::optional<crate::syntax::Expr>& found_opt, const crate::syntax::Arg& a) {
            return ({
                __label__ _done;
                prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                auto&& _m = a.name;
                if (prism_rtl::is_some(_m)) {
                    auto&& n = prism_rtl::some_of(_m);
                    _v.set(n.name == f ? std::optional(a->value) : found_opt);
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(found_opt);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        });
    })
        : each(args, [&](const crate::syntax::Arg& a) { return std::optional(a->value); });
    return each_job(crate::check::errors::range0(len(ordered)), ({
        auto ordered_1 = ordered;
        auto lx_2 = lx;
        auto env_3 = env;
        auto c_4 = c;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto ordered_1_5 = ordered_1;
            auto lx_2_5 = lx_2;
            auto env_3_5 = env_3;
            auto c_4_5 = c_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto&& _m = index(ordered_1_5, i);
                prism_rtl::is_some(_m) && prism_rtl::is_some(prism_rtl::some_of(_m)) ? ({
                auto&& x = prism_rtl::some_of(prism_rtl::some_of(_m));
                call_then(start_value_of(lx_2_5, env_3_5, x), [=](Vl value_of_57940) {
                return ({
                    auto v_ = own(value_of_57940);
                    (c_4_5.owner == Text::lit("Prelude.Error")) && (i == Nat(0u))
                    ? prism_rtl::finished(v_)
                    : rc_field(lx_2_5, c_4_5.name, i)
                    ? prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{v_})}))
                    : prism_rtl::finished(v_);
                });
            });
            })
                : prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Default::default"), Array<crate::lower::model::Ex>{}}));
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start CtorArgs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::Ex>> start_ctor_args(Lx lx, Env env, crate::check::env::CtorInfo c, Array<crate::syntax::Arg> args) {
    return prism_rtl::make_rc<CtorArgs>(lx, env, c, args);
}


/// MethodCall: unbounded fn Lx, Env, ValInfo, [Arg], Range, OutTy -> Vl
Vl method_call(const Lx& lx, const Env& env, const crate::check::env::ValInfo& v_, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span, const crate::lower::model::OutTy& t) {
    auto cls = or_(index(each(v_.scheme.bounds, [&](const std::tuple<Text, Text>& _p0) {
        auto&& c = std::get<1>(_p0);
        return c;
    }), Nat(0u)), Text::lit(""));
    auto m = crate::check::types::bare_name(v_.qk);
    auto vals = run_to_end(each_job(args, ({
        auto lx_1 = lx;
        auto env_2 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Vl>(crate::syntax::Arg)>>(prism_rtl::rc([=](crate::syntax::Arg p0) {
        return ({
            auto lx_1_3 = lx_1;
            auto env_2_3 = env_2;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(ValueOf(lx_1_3, env_2_3, a->value))));
            });
        }));
        });
    })));
    })));
    return crate::syntax::lexer::has_prefix(cls, Text::lit("Prelude."))
        ? prelude_method(lx, cls, m, vals, span, t)
        : ({
        auto tr = or_(crate::prelude::get(lx.g.traits, cls), dummy_trait_info());
        auto path_ = path_in(lx, tr.home, prism_rtl::cat(camel(crate::check::types::bare_name(cls)), "::", snake(m)));
        (Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{path_, run_to_end(each_job(args, ({
        auto lx_1 = lx;
        auto env_2 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=](crate::syntax::Arg p0) {
        return ({
            auto lx_1_3 = lx_1;
            auto env_2_3 = env_2;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(Argument(lx_1_3, env_2_3, a->value))));
            });
        }));
        });
    })));
    })))}), t}));
    });
}


prism_rtl::Turn<Vl> MethodCall::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& v_ = this->v_;
    const auto& args = this->args;
    const auto& span = this->span;
    const auto& t = this->t;
    auto cls = or_(index(each(v_.scheme.bounds, [&](const std::tuple<Text, Text>& _p0) {
        auto&& c = std::get<1>(_p0);
        return c;
    }), Nat(0u)), Text::lit(""));
    auto m = crate::check::types::bare_name(v_.qk);
    auto args_1 = args;
    auto env_2 = env;
    auto lx_3 = lx;
    auto span_4 = span;
    auto t_5 = t;
    return call_value(each_job(args_1, ({
        auto lx_3_6 = lx_3;
        auto env_2_6 = env_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Vl>(crate::syntax::Arg)>>(prism_rtl::rc([=](crate::syntax::Arg p0) {
        return ({
            auto lx_3_6_6 = lx_3_6;
            auto env_2_6_6 = env_2_6;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(ValueOf(lx_3_6_6, env_2_6_6, a->value))));
            });
        }));
        });
    })));
    })), [=](Array<Vl> each_58558) {
        return ({
            auto vals = each_58558;
            (crate::syntax::lexer::has_prefix(cls, Text::lit("Prelude."))
            ? prism_rtl::more(prism_rtl::rc(PreludeMethod(lx_3, cls, m, vals, span_4, t_5)))
            : ({
            auto tr = or_(crate::prelude::get(lx_3.g.traits, cls), dummy_trait_info());
            auto path_ = path_in(lx_3, tr.home, prism_rtl::cat(camel(crate::check::types::bare_name(cls)), "::", snake(m)));
            call_value(each_job(args_1, ({
            auto lx_3_6 = lx_3;
            auto env_2_6 = env_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=](crate::syntax::Arg p0) {
            return ({
                auto lx_3_6_6 = lx_3_6;
                auto env_2_6_6 = env_2_6;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(Argument(lx_3_6_6, env_2_6_6, a->value))));
                });
            }));
            });
        })));
        })), [=](Array<crate::lower::model::Ex> each_58843) { return prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{path_, each_58843}), t_5})); });
        }));
        });
    });
}


/// `Start MethodCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_method_call(Lx lx, Env env, crate::check::env::ValInfo v_, Array<crate::syntax::Arg> args, crate::syntax::Range span, crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<MethodCall>(lx, env, v_, args, span, t);
}


/// let dummyTraitInfo
crate::check::env::TraitInfo dummy_trait_info() {
    return crate::check::env::TraitInfo{.name = Text::lit(""), .home = Text::lit(""), .param = Text::lit("a"), .supers = Array<Text>{}, .methods = Array<Text>{}, .defaults = Array<Text>{}, .assocs = Array<Text>{}, .file = Nat(0u), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// PreludeMethod: unbounded fn Lx, Text, Text, [Vl], Range, OutTy -> Vl
Vl prelude_method(const Lx& lx, const Text& cls, const Text& m, const Array<Vl>& vals, const crate::syntax::Range& span, const crate::lower::model::OutTy& t) {
    auto a = or_(index(vals, Nat(0u)), Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}));
    auto b = or_(index(vals, Nat(1u)), Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}));
    {
        auto&& m59262_0 = m;
        if (m59262_0 == Text::lit("Show")) {
            return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("show_text"), Array(std::vector{ref_(a)})}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})});
        }
    }
    {
        auto&& m59262_1 = m;
        if (m59262_1 == Text::lit("Compare")) {
            return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("compare"), Array(std::vector{ref_(a), ref_(b)})}), t});
        }
    }
    {
        auto&& m59262_2 = m;
        if (m59262_2 == Text::lit("Children")) {
            return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("children"), Array(std::vector{ref_(a)})}), t});
        }
    }
    {
        return op_value(lx, m, a, b, span, t);
    }
}


prism_rtl::Turn<Vl> PreludeMethod::cycle() const {
    const auto& lx = this->lx;
    const auto& cls = this->cls;
    const auto& m = this->m;
    const auto& vals = this->vals;
    const auto& span = this->span;
    const auto& t = this->t;
    auto a = or_(index(vals, Nat(0u)), Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}));
    auto b = or_(index(vals, Nat(1u)), Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}));
    return ({
        ({
        auto&& m59262_0 = m;
        (m59262_0 == Text::lit("Show"));
    }) ? ({
        auto&& m59262_0 = m;
        prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("show_text"), Array(std::vector{ref_(a)})}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})}));
    })
        : ({
        auto&& m59262_1 = m;
        (m59262_1 == Text::lit("Compare"));
    }) ? ({
        auto&& m59262_1 = m;
        prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("compare"), Array(std::vector{ref_(a), ref_(b)})}), t}));
    })
        : ({
        auto&& m59262_2 = m;
        (m59262_2 == Text::lit("Children"));
    }) ? ({
        auto&& m59262_2 = m;
        prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("children"), Array(std::vector{ref_(a)})}), t}));
    })
        : prism_rtl::finished(op_value(lx, m, a, b, span, t));
    });
}


/// `Start PreludeMethod, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_prelude_method(Lx lx, Text cls, Text m, Array<Vl> vals, crate::syntax::Range span, crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<PreludeMethod>(lx, cls, m, vals, span, t);
}


/// BinaryValue: unbounded fn Lx, Env, Text, Expr, Expr, Range -> Vl
Vl binary_value(const Lx& lx, const Env& env, const Text& op, const crate::syntax::Expr& l, const crate::syntax::Expr& r, const crate::syntax::Range& span) {
    auto t = out_ty_of(lx, peel(type_at(lx, span)));
    {
        auto&& m59690_0 = op;
        if (m59690_0 == Text::lit("and")) {
            return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("&&"), prism_rtl::rc(as_bool(value_of(lx, env, l))), prism_rtl::rc(as_bool(value_of(lx, env, r)))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})});
        }
    }
    {
        auto&& m59690_1 = op;
        if (m59690_1 == Text::lit("or")) {
            return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("||"), prism_rtl::rc(as_bool(value_of(lx, env, l))), prism_rtl::rc(as_bool(value_of(lx, env, r)))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})});
        }
    }
    {
        auto&& m59690_2 = op;
        if (m59690_2 == Text::lit("on")) {
            return value_of(lx, env, l);
        }
    }
    {
        return op_value(lx, op, value_of(lx, env, l), value_of(lx, env, r), span, t);
    }
}


prism_rtl::Turn<Vl> BinaryValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& op = this->op;
    const auto& l = this->l;
    const auto& r = this->r;
    const auto& span = this->span;
    auto env_1 = env;
    auto l_2 = l;
    auto lx_3 = lx;
    auto op_4 = op;
    auto r_5 = r;
    auto span_6 = span;
    return call_then(start_out_ty_of(lx_3, peel(type_at(lx_3, span_6))), [=](crate::lower::model::OutTy out_ty_of_59649) {
        return ({
            auto t = out_ty_of_59649;
            ({
            ({
            auto&& m59690_0 = op_4;
            (m59690_0 == Text::lit("and"));
        }) ? ({
            auto&& m59690_0 = op_4;
            call_then(start_value_of(lx_3, env_1, l_2), [=](Vl value_of_59744) { return call_then(start_value_of(lx_3, env_1, r_5), [=](Vl value_of_59775) { return prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("&&"), prism_rtl::rc(as_bool(value_of_59744)), prism_rtl::rc(as_bool(value_of_59775))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})})); }); });
        })
            : ({
            auto&& m59690_1 = op_4;
            (m59690_1 == Text::lit("or"));
        }) ? ({
            auto&& m59690_1 = op_4;
            call_then(start_value_of(lx_3, env_1, l_2), [=](Vl value_of_59849) { return call_then(start_value_of(lx_3, env_1, r_5), [=](Vl value_of_59880) { return prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("||"), prism_rtl::rc(as_bool(value_of_59849)), prism_rtl::rc(as_bool(value_of_59880))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})})); }); });
        })
            : ({
            auto&& m59690_2 = op_4;
            (m59690_2 == Text::lit("on"));
        }) ? ({
            auto&& m59690_2 = op_4;
            prism_rtl::more(prism_rtl::rc(ValueOf(lx_3, env_1, l_2)));
        })
            : call_then(start_value_of(lx_3, env_1, l_2), [=](Vl value_of_60146) { return call_then(start_value_of(lx_3, env_1, r_5), [=](Vl value_of_60168) { return prism_rtl::finished(op_value(lx_3, op_4, value_of_60146, value_of_60168, span_6, t)); }); });
        });
        });
    });
}


/// `Start BinaryValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_binary_value(Lx lx, Env env, Text op, crate::syntax::Expr l, crate::syntax::Expr r, crate::syntax::Range span) {
    return prism_rtl::make_rc<BinaryValue>(lx, env, op, l, r, span);
}


/// OpValue: fn Lx, Text, Vl, Vl, Range, OutTy -> Vl
Vl op_value(const Lx& lx, const Text& op, const Vl& a, const Vl& b, const crate::syntax::Range& span, const crate::lower::model::OutTy& t) {
    auto at_ = value_ty(a);
    auto generic = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<crate::lower::model::OutTy::OutGen>(at_)) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    return crate::check::types::has_text(Array(std::vector{Text::lit("=="), Text::lit("!="), Text::lit("<"), Text::lit("<="), Text::lit(">"), Text::lit(">=")}), op)
        ? Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBin{op, prism_rtl::rc(ref_(a)), prism_rtl::rc(ref_(b))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})})
        : op == Text::lit("mod")
        ? Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(ref_(a)), Text::lit("modulo"), Array(std::vector{ref_(b)})}), t})
        : generic
        ? Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{prism_rtl::cat("Num::", num_method(op)), Array(std::vector{ref_(a), ref_(b)})}), t})
        : op == Text::lit("/")
        ? at_ == crate::lower::model::OutTy(crate::lower::model::OutTy::OutFloat{})
        ? Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("/"), prism_rtl::rc(crate::lower::copy(a)), prism_rtl::rc(crate::lower::copy(b))}), t})
        : Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(ref_(a)), Text::lit("div"), Array(std::vector{ref_(b)})}), t})
        : op == Text::lit("-?")
        ? at_ == crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{})
        ? Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(ref_(a)), Text::lit("checked_sub"), Array(std::vector{ref_(b)})}), t})
        : Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("-"), prism_rtl::rc(ref_(a)), prism_rtl::rc(ref_(b))})})}), t})
        : op == Text::lit("+?")
        ? Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("+"), prism_rtl::rc(ref_(a)), prism_rtl::rc(ref_(b))})})}), t})
        : op == Text::lit("*?")
        ? Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("*"), prism_rtl::rc(ref_(a)), prism_rtl::rc(ref_(b))})})}), t})
        : is_copy(at_)
        ? Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBin{op, prism_rtl::rc(crate::lower::copy(a)), prism_rtl::rc(crate::lower::copy(b))}), t})
        : Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBin{op, prism_rtl::rc(ref_(a)), prism_rtl::rc(ref_(b))}), t});
}


/// NumMethod: fn Text -> Text
Text num_method(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("+")) {
            return Text::lit("add");
        }
    }
    {
        auto&& c1_0 = text0;
        if (c1_0 == Text::lit("-")) {
            return Text::lit("sub");
        }
    }
    {
        auto&& c2_0 = text0;
        if (c2_0 == Text::lit("*")) {
            return Text::lit("mul");
        }
    }
    {
        auto&& c3_0 = text0;
        if (c3_0 == Text::lit("/")) {
            return Text::lit("div_opt");
        }
    }
    {
        auto&& c4_0 = text0;
        if (c4_0 == Text::lit("+?")) {
            return Text::lit("add_opt");
        }
    }
    {
        auto&& c5_0 = text0;
        if (c5_0 == Text::lit("-?")) {
            return Text::lit("sub_opt");
        }
    }
    {
        auto&& c6_0 = text0;
        if (c6_0 == Text::lit("*?")) {
            return Text::lit("mul_opt");
        }
    }
    {
        auto&& other = text0;
        return Text::lit("add");
    }
}


/// PreludeCall: unbounded fn Lx, Env, Text, [Arg], Range, OutTy -> Vl
Vl prelude_call(const Lx& lx, const Env& env, const Text& qk, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span, const crate::lower::model::OutTy& t) {
    auto name = or_(crate::prelude::get(lx.rs_names, qk), snake(crate::check::types::bare_name(qk)));
    auto first_ = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::OutTy> _v;
        auto&& _m = index(args, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& a = prism_rtl::some_of(_m);
            _v.set(out_ty_of(lx, peel(type_at(lx, a->value.span))));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto variant = prelude_variant(name, first_);
    auto&& _m = prelude_job(lx, env, variant, args);
    if (prism_rtl::is_some(_m)) {
        auto&& job = prism_rtl::some_of(_m);
        return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("run_to_end"), Array(std::vector{job})}), t});
    }
    if (prism_rtl::is_none(_m)) {
        return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{prelude_path(lx, variant), run_to_end(each_job(args, ({
            auto lx_1 = lx;
            auto env_2 = env;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=](crate::syntax::Arg p0) {
            return ({
                auto lx_1_3 = lx_1;
                auto env_2_3 = env_2;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(Argument(lx_1_3, env_2_3, a->value))));
                });
            }));
            });
        })));
        })))}), t});
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Vl> PreludeCall::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& qk = this->qk;
    const auto& args = this->args;
    const auto& span = this->span;
    const auto& t = this->t;
    auto name = or_(crate::prelude::get(lx.rs_names, qk), snake(crate::check::types::bare_name(qk)));
    auto first_ = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::OutTy> _v;
        auto&& _m = index(args, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& a = prism_rtl::some_of(_m);
            _v.set(out_ty_of(lx, peel(type_at(lx, a->value.span))));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto variant = prelude_variant(name, first_);
    auto args_1 = args;
    auto env_2 = env;
    auto lx_3 = lx;
    auto t_4 = t;
    return call_then(start_prelude_job(lx_3, env_2, variant, args_1), [=](std::optional<crate::lower::model::Ex> prelude_job_62178) {
        return ({
            prism_rtl::is_some(prelude_job_62178) ? ({
            auto&& job = prism_rtl::some_of(prelude_job_62178);
            prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("run_to_end"), Array(std::vector{job})}), t_4}));
        })
            : prism_rtl::is_none(prelude_job_62178) ? call_value(each_job(args_1, ({
            auto lx_3_5 = lx_3;
            auto env_2_5 = env_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=](crate::syntax::Arg p0) {
            return ({
                auto lx_3_5_5 = lx_3_5;
                auto env_2_5_5 = env_2_5;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(Argument(lx_3_5_5, env_2_5_5, a->value))));
                });
            }));
            });
        })));
        })), [=](Array<crate::lower::model::Ex> each_62326) { return prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{prelude_path(lx_3, variant), each_62326}), t_4})); })
            : throw prism_rtl::Panic("no arm matched");
        });
    });
}


/// `Start PreludeCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_prelude_call(Lx lx, Env env, Text qk, Array<crate::syntax::Arg> args, crate::syntax::Range span, crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<PreludeCall>(lx, env, qk, args, span, t);
}


/// ?PreludeJob: unbounded fn Lx, Env, Text, [Arg] -> ?Ex
std::optional<crate::lower::model::Ex> prelude_job(const Lx& lx, const Env& env, const Text& variant, const Array<crate::syntax::Arg>& args) {
    return crate::check::types::has_text(Array(std::vector{Text::lit("fold"), Text::lit("fold_map"), Text::lit("each"), Text::lit("each_map"), Text::lit("filter"), Text::lit("filter_map")}), variant)
        ? ({
        auto last = or_(index(args, crate::syntax::lexer::dec(len(args))), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = dummy_expr(), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}});
        ({
        __label__ _done;
        prism_rtl::Slot<std::optional<crate::lower::model::Ex>> _v;
        auto&& _m = out_ty_of(lx, peel(type_at(lx, last->value.span)));
        if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m)) {
            _v.set(({
                auto front_ = run_to_end(each_job(take(args, crate::syntax::lexer::dec(len(args))), ({
                    auto lx_1 = lx;
                    auto env_2 = env;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=](crate::syntax::Arg p0) {
                    return ({
                        auto lx_1_3 = lx_1;
                        auto env_2_3 = env_2;
                        entered(once_job([=]() {
                        return ({
                            auto a = p0;
                            call_then(start_value_of(lx_1_3, env_2_3, a->value), [=](Vl value_of_63192) { return prism_rtl::finished(own(value_of_63192)); });
                        });
                    }));
                    });
                })));
                })));
                (std::optional(crate::lower::model::Ex(crate::lower::model::Ex::XCall{prism_rtl::cat(variant, "_job"), crate::prelude::push(front_, as_job_value(lx, env, last->value))})));
            }));
            goto _done;
        }
        {
            _v.set(std::optional<crate::lower::model::Ex>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    })
        : std::optional<crate::lower::model::Ex>{};
}


prism_rtl::Turn<std::optional<crate::lower::model::Ex>> PreludeJob::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& variant = this->variant;
    const auto& args = this->args;
    return crate::check::types::has_text(Array(std::vector{Text::lit("fold"), Text::lit("fold_map"), Text::lit("each"), Text::lit("each_map"), Text::lit("filter"), Text::lit("filter_map")}), variant)
        ? ({
        auto last = or_(index(args, crate::syntax::lexer::dec(len(args))), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = dummy_expr(), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}});
        auto args_1 = args;
        auto env_2 = env;
        auto lx_3 = lx;
        auto variant_4 = variant;
        call_then(start_out_ty_of(lx_3, peel(type_at(lx_3, last->value.span))), [=](crate::lower::model::OutTy out_ty_of_63032) {
        return ({
            prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(out_ty_of_63032) ? call_value(each_job(take(args_1, crate::syntax::lexer::dec(len(args_1))), ({
            auto lx_3_5 = lx_3;
            auto env_2_5 = env_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=](crate::syntax::Arg p0) {
            return ({
                auto lx_3_5_5 = lx_3_5;
                auto env_2_5_5 = env_2_5;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    call_then(start_value_of(lx_3_5_5, env_2_5_5, a->value), [=](Vl value_of_63192) { return prism_rtl::finished(own(value_of_63192)); });
                });
            }));
            });
        })));
        })), [=](Array<crate::lower::model::Ex> each_63146) {
            return ({
                auto front_ = each_63146;
                (prism_rtl::finished(std::optional(crate::lower::model::Ex(crate::lower::model::Ex::XCall{prism_rtl::cat(variant_4, "_job"), crate::prelude::push(front_, as_job_value(lx_3, env_2, last->value))}))));
            });
        })
            : prism_rtl::finished(std::optional<crate::lower::model::Ex>{});
        });
    });
    })
        : prism_rtl::finished(std::optional<crate::lower::model::Ex>{});
}


/// `Start PreludeJob, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<crate::lower::model::Ex>> start_prelude_job(Lx lx, Env env, Text variant, Array<crate::syntax::Arg> args) {
    return prism_rtl::make_rc<PreludeJob>(lx, env, variant, args);
}


/// ?PreludeJobCall: unbounded fn Lx, Env, Expr -> ?Ex
std::optional<crate::lower::model::Ex> prelude_job_call(const Lx& lx, const Env& env, const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        auto&& _m = c.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            return (len(n->path_) == Nat(1u)) && crate::check::env::has_key(env->names, crate::check::env::sname_key(n))
                ? std::optional<crate::lower::model::Ex>{}
                : ({
                auto&& _qk_opt = crate::check::env::resolve_value(lx.g, lx.home, n);
                auto&& qk_opt = std::get<0>(_qk_opt);
                ({
                __label__ _done;
                prism_rtl::Slot<std::optional<crate::lower::model::Ex>> _v;
                if (prism_rtl::is_some(qk_opt)) {
                    auto&& qk = prism_rtl::some_of(qk_opt);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::optional<crate::lower::model::Ex>> _v;
                        auto&& _m = crate::prelude::get(lx.g.vals, qk);
                        if (prism_rtl::is_some(_m)) {
                            auto&& v_ = prism_rtl::some_of(_m);
                            _v.set(v_.home == Text::lit("Prelude")
                                ? ({
                                auto name = or_(crate::prelude::get(lx.rs_names, qk), snake(crate::check::types::bare_name(qk)));
                                auto first_ = ({
                                    __label__ _done;
                                    prism_rtl::Slot<crate::lower::model::OutTy> _v;
                                    auto&& _m = index(args, Nat(0u));
                                    if (prism_rtl::is_some(_m)) {
                                        auto&& a = prism_rtl::some_of(_m);
                                        _v.set(out_ty_of(lx, peel(type_at(lx, a->value.span))));
                                        goto _done;
                                    }
                                    if (prism_rtl::is_none(_m)) {
                                        _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
                                        goto _done;
                                    }
                                    prism_rtl::unreachable("no arm matched");
                                _done:
                                    _v.take();
                                });
                                prelude_job(lx, env, prelude_variant(name, first_), args);
                            })
                                : std::optional<crate::lower::model::Ex>{});
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(std::optional<crate::lower::model::Ex>{});
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(qk_opt)) {
                    _v.set(std::optional<crate::lower::model::Ex>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            });
        }
        {
            return std::optional<crate::lower::model::Ex>{};
        }
    }
    {
        return std::optional<crate::lower::model::Ex>{};
    }
}


prism_rtl::Turn<std::optional<crate::lower::model::Ex>> PreludeJobCall::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::ECall>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        ({
        auto&& _m = c.kind;
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        (len(n->path_) == Nat(1u)) && crate::check::env::has_key(env->names, crate::check::env::sname_key(n))
        ? prism_rtl::finished(std::optional<crate::lower::model::Ex>{})
        : ({
        auto&& _qk_opt = crate::check::env::resolve_value(lx.g, lx.home, n);
        auto&& qk_opt = std::get<0>(_qk_opt);
        ({
        prism_rtl::is_some(qk_opt) ? ({
        auto&& qk = prism_rtl::some_of(qk_opt);
        ({
        auto&& _m = crate::prelude::get(lx.g.vals, qk);
        prism_rtl::is_some(_m) ? ({
        auto&& v_ = prism_rtl::some_of(_m);
        v_.home == Text::lit("Prelude")
        ? ({
        auto name = or_(crate::prelude::get(lx.rs_names, qk), snake(crate::check::types::bare_name(qk)));
        auto first_ = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::OutTy> _v;
            auto&& _m = index(args, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& a = prism_rtl::some_of(_m);
                _v.set(out_ty_of(lx, peel(type_at(lx, a->value.span))));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        (prism_rtl::more(prism_rtl::rc(PreludeJob(lx, env, prelude_variant(name, first_), args))));
    })
        : prism_rtl::finished(std::optional<crate::lower::model::Ex>{});
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<crate::lower::model::Ex>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is_none(qk_opt) ? prism_rtl::finished(std::optional<crate::lower::model::Ex>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : prism_rtl::finished(std::optional<crate::lower::model::Ex>{});
    });
    })
        : prism_rtl::finished(std::optional<crate::lower::model::Ex>{});
    });
}


/// `Start PreludeJobCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<crate::lower::model::Ex>> start_prelude_job_call(Lx lx, Env env, crate::syntax::Expr e) {
    return prism_rtl::make_rc<PreludeJobCall>(lx, env, e);
}


/// AsJobValue: unbounded fn Lx, Env, Expr -> Ex
crate::lower::model::Ex as_job_value(const Lx& lx, const Env& env, const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return as_job_value(lx, env, x);
    }
    {
        auto target = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::OutTy> _v;
            auto&& _m = peel(type_at(lx, e.span));
            if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
                auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
                auto&& r = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
                _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutJobFn{prism_rtl::rc(rust_ty_of_params(lx, ps)), prism_rtl::rc(out_ty_of(lx, r))}));
                goto _done;
            }
            {
                auto&& other = _m;
                _v.set(out_ty_of(lx, other));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto a = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::OutTy> _v;
            if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(target)) {
                auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(target).a0;
                _v.set(x);
                goto _done;
            }
            {
                _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto&& _m = e.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
            auto&& ps_opt = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
            auto&& body = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
            return own(job_lambda(lx, env, or_(ps_opt, Array<crate::syntax::Pattern_>{}), body, target, a, enters_lambda(lx, e)));
        }
        {
            auto v_ = value_of(lx, env, e);
            auto&& _m = value_ty(v_);
            if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(_m)) {
                auto&& pts = prism_rtl::as<crate::lower::model::OutTy::OutFn>(_m).a0;
                return wrap_as_job(own(v_), pts, target, a);
            }
            {
                return own(v_);
            }
        }
    }
}


prism_rtl::Turn<crate::lower::model::Ex> AsJobValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(AsJobValue(lx, env, x)));
    })
        : ({
        auto target = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::OutTy> _v;
            auto&& _m = peel(type_at(lx, e.span));
            if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
                auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
                auto&& r = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
                _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutJobFn{prism_rtl::rc(rust_ty_of_params(lx, ps)), prism_rtl::rc(out_ty_of(lx, r))}));
                goto _done;
            }
            {
                auto&& other = _m;
                _v.set(out_ty_of(lx, other));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto a = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::OutTy> _v;
            if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(target)) {
                auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(target).a0;
                _v.set(x);
                goto _done;
            }
            {
                _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
                goto _done;
            }
        _done:
            _v.take();
        });
        ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) ? ({
        auto&& ps_opt = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
        ({
        auto ps_opt_1 = ps_opt;
        auto body_2 = body;
        auto e_3 = e;
        auto env_4 = env;
        auto lx_5 = lx;
        call_then(start_job_lambda(lx_5, env_4, or_(ps_opt_1, Array<crate::syntax::Pattern_>{}), body_2, target, a, enters_lambda(lx_5, e_3)), [=](Vl job_lambda_65081) { return prism_rtl::finished(own(job_lambda_65081)); });
    });
    })
        : ({
        auto e_1 = e;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(start_value_of(lx_3, env_2, e_1), [=](Vl value_of_65202) {
        return ({
            auto v_ = value_of_65202;
            ({
            auto&& _m = value_ty(v_);
            prism_rtl::is<crate::lower::model::OutTy::OutFn>(_m) ? ({
            auto&& pts = prism_rtl::as<crate::lower::model::OutTy::OutFn>(_m).a0;
            prism_rtl::finished(wrap_as_job(own(v_), pts, target, a));
        })
            : prism_rtl::finished(own(v_));
        });
        });
    });
    });
    });
    });
    });
}


/// `Start AsJobValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_as_job_value(Lx lx, Env env, crate::syntax::Expr e) {
    return prism_rtl::make_rc<AsJobValue>(lx, env, e);
}


/// WrapAsJob: fn Ex, [OutTy], OutTy, OutTy -> Ex
crate::lower::model::Ex wrap_as_job(const crate::lower::model::Ex& f, const Array<crate::lower::model::OutTy>& pts, const crate::lower::model::OutTy& target, const crate::lower::model::OutTy& a) {
    auto names = each(crate::check::errors::range0(len(pts)), [&](const Nat& i) { return prism_rtl::cat("a", i); });
    auto pa = len(pts) == Nat(1u)
        ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("a0")})), a})
        : crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(names, [&](const Text& nm) { return crate::lower::model::Pa(crate::lower::model::Pa::PaBind{nm}); })})), a});
    auto call = crate::lower::model::Ex(crate::lower::model::Ex::XApply{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("f")})), each(names, [&](const Text& nm) { return crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{nm}))}); })});
    auto body = crate::lower::model::Ex(crate::lower::model::Ex::XBlock{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("f")}), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("f")}))})})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("once_job"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array<crate::lower::model::Pa>{}, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{call})}))})})}))});
    return crate::lower::model::Ex(crate::lower::model::Ex::XBlock{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("f")}), f})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{pa}), prism_rtl::rc(body)})})})), target}))});
}


/// NamedArgsOwned: unbounded fn Lx, Env, Text, [Arg] -> [Ex]
Array<crate::lower::model::Ex> named_args_owned(const Lx& lx, const Env& env, const Text& qk, const Array<crate::syntax::Arg>& args) {
    auto&& _ps = scheme_parts(lx, qk);
    auto&& ps = std::get<0>(_ps);
    return run_to_end(each_job(crate::check::errors::range0(len(args)), ({
        auto args_1 = args;
        auto ps_2 = ps;
        auto lx_3 = lx;
        auto env_4 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto args_1_5 = args_1;
            auto ps_2_5 = ps_2;
            auto lx_3_5 = lx_3;
            auto env_4_5 = env_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto a = or_(index(args_1_5, i), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = dummy_expr(), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}});
                ({
                auto&& _m = peel(or_(index(ps_2_5, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})));
                prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CBound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0) ? call_then(start_value_of(lx_3_5, env_4_5, a->value), [=](Vl value_of_66505) { return prism_rtl::finished(own(value_of_66505)); })
                : prism_rtl::is<crate::check::types::Ty::TyFn>(_m) ? prism_rtl::more(prism_rtl::rc(AsJobValue(lx_3_5, env_4_5, a->value)))
                : call_then(start_value_of(lx_3_5, env_4_5, a->value), [=](Vl value_of_66628) { return prism_rtl::finished(own(value_of_66628)); });
            });
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<crate::lower::model::Ex>> NamedArgsOwned::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& qk = this->qk;
    const auto& args = this->args;
    auto&& _ps = scheme_parts(lx, qk);
    auto&& ps = std::get<0>(_ps);
    return each_job(crate::check::errors::range0(len(args)), ({
        auto args_1 = args;
        auto ps_2 = ps;
        auto lx_3 = lx;
        auto env_4 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto args_1_5 = args_1;
            auto ps_2_5 = ps_2;
            auto lx_3_5 = lx_3;
            auto env_4_5 = env_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto a = or_(index(args_1_5, i), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = dummy_expr(), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}});
                ({
                auto&& _m = peel(or_(index(ps_2_5, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})));
                prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CBound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0) ? call_then(start_value_of(lx_3_5, env_4_5, a->value), [=](Vl value_of_66505) { return prism_rtl::finished(own(value_of_66505)); })
                : prism_rtl::is<crate::check::types::Ty::TyFn>(_m) ? prism_rtl::more(prism_rtl::rc(AsJobValue(lx_3_5, env_4_5, a->value)))
                : call_then(start_value_of(lx_3_5, env_4_5, a->value), [=](Vl value_of_66628) { return prism_rtl::finished(own(value_of_66628)); });
            });
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start NamedArgsOwned, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::Ex>> start_named_args_owned(Lx lx, Env env, Text qk, Array<crate::syntax::Arg> args) {
    return prism_rtl::make_rc<NamedArgsOwned>(lx, env, qk, args);
}


/// StartArgs: unbounded fn Lx, Env, Vl, [Arg] -> [Ex]
Array<crate::lower::model::Ex> start_args(const Lx& lx, const Env& env, const Vl& f, const Array<crate::syntax::Arg>& args) {
    auto pts = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
        auto&& _m = value_ty(f);
        if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m)) {
            auto&& m66840_0_0 = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(_m).a0;
            if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(m66840_0_0)) {
                auto&& ts = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(m66840_0_0).a0;
                _v.set(len(args) == Nat(1u)
                    ? Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{ts})})
                    : ts);
                goto _done;
            }
        }
        if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m)) {
            auto&& a = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(_m).a0;
            _v.set(Array(std::vector{a}));
            goto _done;
        }
        {
            _v.set(Array<crate::lower::model::OutTy>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return run_to_end(each_job(crate::check::errors::range0(len(args)), ({
        auto args_1 = args;
        auto pts_2 = pts;
        auto lx_3 = lx;
        auto env_4 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto args_1_5 = args_1;
            auto pts_2_5 = pts_2;
            auto lx_3_5 = lx_3;
            auto env_4_5 = env_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto a = or_(index(args_1_5, i), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = dummy_expr(), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}});
                ({
                auto&& _m = or_(index(pts_2_5, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
                prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m) ? prism_rtl::more(prism_rtl::rc(AsJobValue(lx_3_5, env_4_5, a->value)))
                : call_then(start_value_of(lx_3_5, env_4_5, a->value), [=](Vl value_of_67251) { return prism_rtl::finished(own(value_of_67251)); });
            });
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<crate::lower::model::Ex>> StartArgs::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& f = this->f;
    const auto& args = this->args;
    auto pts = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
        auto&& _m = value_ty(f);
        if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m)) {
            auto&& m66840_0_0 = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(_m).a0;
            if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(m66840_0_0)) {
                auto&& ts = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(m66840_0_0).a0;
                _v.set(len(args) == Nat(1u)
                    ? Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{ts})})
                    : ts);
                goto _done;
            }
        }
        if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m)) {
            auto&& a = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(_m).a0;
            _v.set(Array(std::vector{a}));
            goto _done;
        }
        {
            _v.set(Array<crate::lower::model::OutTy>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return each_job(crate::check::errors::range0(len(args)), ({
        auto args_1 = args;
        auto pts_2 = pts;
        auto lx_3 = lx;
        auto env_4 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto args_1_5 = args_1;
            auto pts_2_5 = pts_2;
            auto lx_3_5 = lx_3;
            auto env_4_5 = env_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto a = or_(index(args_1_5, i), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = dummy_expr(), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}});
                ({
                auto&& _m = or_(index(pts_2_5, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
                prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m) ? prism_rtl::more(prism_rtl::rc(AsJobValue(lx_3_5, env_4_5, a->value)))
                : call_then(start_value_of(lx_3_5, env_4_5, a->value), [=](Vl value_of_67251) { return prism_rtl::finished(own(value_of_67251)); });
            });
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start StartArgs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::Ex>> start_start_args(Lx lx, Env env, Vl f, Array<crate::syntax::Arg> args) {
    return prism_rtl::make_rc<StartArgs>(lx, env, f, args);
}


/// PreludeVariant: fn Text, OutTy -> Text
Text prelude_variant(const Text& name, const crate::lower::model::OutTy& first_) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutText>(first_)) {
        return name == Text::lit("len") ? Text::lit("len_text") : name;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(first_)) {
        return crate::check::types::has_text(Array(std::vector{Text::lit("len"), Text::lit("fold"), Text::lit("each"), Text::lit("filter")}), name)
            ? prism_rtl::cat(name, "_map")
            : name;
    }
    {
        return name;
    }
}


/// FieldValue: unbounded fn Lx, Env, Expr, Text -> Vl
Vl field_value(const Lx& lx, const Env& env, const crate::syntax::Expr& r, const Text& name) {
    auto rv = value_of(lx, env, r);
    auto rty = peel(type_at(lx, r.span));
    auto [ft, rc] = field_info(lx, rty, name);
    auto f = snake(name);
    auto mode = rc ? Holding(Holding::RcOwned{}) : Holding(Holding::Owned{});
    if (prism_rtl::is<Vl::VlPlace>(rv)) {
        auto&& x = prism_rtl::as<Vl::VlPlace>(rv).a0;
        return Vl(Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(x), f}), mode, ft});
    }
    if (prism_rtl::is<Vl::VlOwned>(rv)) {
        auto&& x = prism_rtl::as<Vl::VlOwned>(rv).a0;
        return Vl(Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(x), f}), mode, ft});
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Vl> FieldValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& r = this->r;
    const auto& name = this->name;
    auto env_1 = env;
    auto lx_2 = lx;
    auto name_3 = name;
    auto r_4 = r;
    return call_then(start_value_of(lx_2, env_1, r_4), [=](Vl value_of_67746) {
        return ({
            auto rv = value_of_67746;
            auto rty = peel(type_at(lx_2, r_4.span));
            call_then(start_field_info(lx_2, rty, name_3), [=](std::tuple<crate::lower::model::OutTy, bool> field_info_67825) {
            return ({
                auto [ft, rc] = field_info_67825;
                auto f = snake(name_3);
                auto mode = rc ? Holding(Holding::RcOwned{}) : Holding(Holding::Owned{});
                ({
                prism_rtl::is<Vl::VlPlace>(rv) ? ({
                auto&& x = prism_rtl::as<Vl::VlPlace>(rv).a0;
                prism_rtl::finished(Vl(Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(x), f}), mode, ft}));
            })
                : prism_rtl::is<Vl::VlOwned>(rv) ? ({
                auto&& x = prism_rtl::as<Vl::VlOwned>(rv).a0;
                prism_rtl::finished(Vl(Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(x), f}), mode, ft}));
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        });
        });
    });
}


/// `Start FieldValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_field_value(Lx lx, Env env, crate::syntax::Expr r, Text name) {
    return prism_rtl::make_rc<FieldValue>(lx, env, r, name);
}


/// FieldInfo: unbounded fn Lx, Ty, Text -> ((OutTy, Bool))
std::tuple<crate::lower::model::OutTy, bool> field_info(const Lx& lx, const crate::check::types::Ty& rty, const Text& name) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(rty)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(rty).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(rty).a1;
        auto&& _m = crate::prelude::get(lx.g.ctors, n);
        if (prism_rtl::is_some(_m)) {
            auto&& c = prism_rtl::some_of(_m);
            auto fix_opt = fold(crate::check::errors::range0(len(c.fields)), std::optional<Nat>{}, [&](const std::optional<Nat>& found_opt, const Nat& i) {
                return or_(index(c.fields, i), Text::lit("")) == name
                    ? std::optional(i)
                    : found_opt;
            });
            if (prism_rtl::is_some(fix_opt)) {
                auto&& i = prism_rtl::some_of(fix_opt);
                auto ft = or_(index(c->args, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
                auto inst = instantiated(ft, c.params, args);
                return std::tuple{out_ty_of(lx, inst), rc_field(lx, c.name, i)};
            }
            if (prism_rtl::is_none(fix_opt)) {
                return std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{prism_rtl::cat("a field ", name)}), false};
            }
            prism_rtl::unreachable("no arm matched");
        }
        if (prism_rtl::is_none(_m)) {
            return std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{prism_rtl::cat("a field ", name)}), false};
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        return std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{prism_rtl::cat("a field ", name, " of a non-record")}), false};
    }
}


prism_rtl::Turn<std::tuple<crate::lower::model::OutTy, bool>> FieldInfo::cycle() const {
    const auto& lx = this->lx;
    const auto& rty = this->rty;
    const auto& name = this->name;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyCon>(rty) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(rty).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(rty).a1;
        ({
        auto&& _m = crate::prelude::get(lx.g.ctors, n);
        prism_rtl::is_some(_m) ? ({
        auto&& c = prism_rtl::some_of(_m);
        ({
        auto fix_opt = fold(crate::check::errors::range0(len(c.fields)), std::optional<Nat>{}, [&](const std::optional<Nat>& found_opt, const Nat& i) {
            return or_(index(c.fields, i), Text::lit("")) == name
                ? std::optional(i)
                : found_opt;
        });
        ({
        prism_rtl::is_some(fix_opt) ? ({
        auto&& i = prism_rtl::some_of(fix_opt);
        ({
        auto ft = or_(index(c->args, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
        auto args_1 = args;
        auto i_2 = i;
        auto lx_3 = lx;
        auto name_4 = name;
        call_then(start_instantiated(ft, c.params, args_1), [=](crate::check::types::Ty instantiated_68513) {
        return ({
            auto inst = instantiated_68513;
            call_then(start_out_ty_of(lx_3, inst), [=](crate::lower::model::OutTy out_ty_of_68568) { return prism_rtl::finished(std::tuple{out_ty_of_68568, rc_field(lx_3, c.name, i_2)}); });
        });
    });
    });
    })
        : prism_rtl::is_none(fix_opt) ? prism_rtl::finished(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{prism_rtl::cat("a field ", name)}), false})
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{prism_rtl::cat("a field ", name)}), false})
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::finished(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{prism_rtl::cat("a field ", name, " of a non-record")}), false});
    });
}


/// `Start FieldInfo, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::model::OutTy, bool>> start_field_info(Lx lx, crate::check::types::Ty rty, Text name) {
    return prism_rtl::make_rc<FieldInfo>(lx, rty, name);
}


/// Instantiated: unbounded fn Ty, [Text], [Ty] -> Ty
crate::check::types::Ty instantiated(const crate::check::types::Ty& t, const Array<Text>& params, const Array<crate::check::types::Ty>& args) {
    if (prism_rtl::is<crate::check::types::Ty::TyQ>(t)) {
        auto&& q = prism_rtl::as<crate::check::types::Ty::TyQ>(t).a0;
        auto hit_opt = fold(crate::check::errors::range0(len(params)), std::optional<crate::check::types::Ty>{}, [&](const std::optional<crate::check::types::Ty>& found_opt, const Nat& i) { return or_(index(params, i), Text::lit("")) == q ? index(args, i) : found_opt; });
        return or_(hit_opt, t);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& xs = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyCon{n, run_to_end(each_job(xs, ({
            auto params_1 = params;
            auto args_2 = args;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
            return ({
                auto params_1_3 = params_1;
                auto args_2_3 = args_2;
                entered(once_job([=]() {
                return ({
                    auto x = p0;
                    (prism_rtl::more(prism_rtl::rc(Instantiated(x, params_1_3, args_2_3))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t)) {
        auto&& c = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        return crate::check::types::Ty(crate::check::types::Ty::TyFn{c, run_to_end(each_job(ps, ({
            auto params_1 = params;
            auto args_2 = args;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
            return ({
                auto params_1_3 = params_1;
                auto args_2_3 = args_2;
                entered(once_job([=]() {
                return ({
                    auto x = p0;
                    (prism_rtl::more(prism_rtl::rc(Instantiated(x, params_1_3, args_2_3))));
                });
            }));
            });
        })));
        }))), prism_rtl::rc(instantiated(res, params, args))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyTuple{run_to_end(each_job(ts, ({
            auto params_1 = params;
            auto args_2 = args;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
            return ({
                auto params_1_3 = params_1;
                auto args_2_3 = args_2;
                entered(once_job([=]() {
                return ({
                    auto x = p0;
                    (prism_rtl::more(prism_rtl::rc(Instantiated(x, params_1_3, args_2_3))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(instantiated(e, params, args))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(instantiated(k, params, args)), prism_rtl::rc(instantiated(v_, params, args))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& s = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TySig{s, prism_rtl::rc(instantiated(i, params, args))});
    }
    {
        return t;
    }
}


prism_rtl::Turn<crate::check::types::Ty> Instantiated::cycle() const {
    const auto& t = this->t;
    const auto& params = this->params;
    const auto& args = this->args;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyQ>(t) ? ({
        auto&& q = prism_rtl::as<crate::check::types::Ty::TyQ>(t).a0;
        ({
        auto hit_opt = fold(crate::check::errors::range0(len(params)), std::optional<crate::check::types::Ty>{}, [&](const std::optional<crate::check::types::Ty>& found_opt, const Nat& i) { return or_(index(params, i), Text::lit("")) == q ? index(args, i) : found_opt; });
        (prism_rtl::finished(or_(hit_opt, t)));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& xs = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        ({
        auto args_1 = args;
        auto n_2 = n;
        auto params_3 = params;
        auto xs_4 = xs;
        call_value(each_job(xs_4, ({
        auto params_3_5 = params_3;
        auto args_1_5 = args_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return ({
            auto params_3_5_5 = params_3_5;
            auto args_1_5_5 = args_1_5;
            entered(once_job([=]() {
            return ({
                auto x = p0;
                (prism_rtl::more(prism_rtl::rc(Instantiated(x, params_3_5_5, args_1_5_5))));
            });
        }));
        });
    })));
    })), [=](Array<crate::check::types::Ty> each_69148) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyCon{n_2, each_69148})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(t) ? ({
        auto&& c = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        ({
        auto args_1 = args;
        auto c_2 = c;
        auto params_3 = params;
        auto ps_4 = ps;
        auto res_5 = res;
        call_value(each_job(ps_4, ({
        auto params_3_6 = params_3;
        auto args_1_6 = args_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return ({
            auto params_3_6_6 = params_3_6;
            auto args_1_6_6 = args_1_6;
            entered(once_job([=]() {
            return ({
                auto x = p0;
                (prism_rtl::more(prism_rtl::rc(Instantiated(x, params_3_6_6, args_1_6_6))));
            });
        }));
        });
    })));
    })), [=](Array<crate::check::types::Ty> each_69222) { return call_then(start_instantiated(res_5, params_3, args_1), [=](crate::check::types::Ty instantiated_69268) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyFn{c_2, each_69222, prism_rtl::rc(instantiated_69268)})); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        ({
        auto args_1 = args;
        auto params_2 = params;
        auto ts_3 = ts;
        call_value(each_job(ts_3, ({
        auto params_2_4 = params_2;
        auto args_1_4 = args_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return ({
            auto params_2_4_4 = params_2_4;
            auto args_1_4_4 = args_1_4;
            entered(once_job([=]() {
            return ({
                auto x = p0;
                (prism_rtl::more(prism_rtl::rc(Instantiated(x, params_2_4_4, args_1_4_4))));
            });
        }));
        });
    })));
    })), [=](Array<crate::check::types::Ty> each_69325) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyTuple{each_69325})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        ({
        auto args_1 = args;
        auto e_2 = e;
        auto params_3 = params;
        call_then(start_instantiated(e_2, params_3, args_1), [=](crate::check::types::Ty instantiated_69393) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(instantiated_69393)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        ({
        auto args_1 = args;
        auto k_2 = k;
        auto params_3 = params;
        auto v__4 = v_;
        call_then(start_instantiated(k_2, params_3, args_1), [=](crate::check::types::Ty instantiated_69446) { return call_then(start_instantiated(v__4, params_3, args_1), [=](crate::check::types::Ty instantiated_69478) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(instantiated_69446), prism_rtl::rc(instantiated_69478)})); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t) ? ({
        auto&& s = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        ({
        auto args_1 = args;
        auto i_2 = i;
        auto params_3 = params;
        auto s_4 = s;
        call_then(start_instantiated(i_2, params_3, args_1), [=](crate::check::types::Ty instantiated_69534) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TySig{s_4, prism_rtl::rc(instantiated_69534)})); });
    });
    })
        : prism_rtl::finished(t);
    });
}


/// `Start Instantiated, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_instantiated(crate::check::types::Ty t, Array<Text> params, Array<crate::check::types::Ty> args) {
    return prism_rtl::make_rc<Instantiated>(t, params, args);
}


/// IndexValue: unbounded fn Lx, Env, Expr, Expr, OutTy -> Vl
Vl index_value(const Lx& lx, const Env& env, const crate::syntax::Expr& r, const crate::syntax::Expr& i, const crate::lower::model::OutTy& t) {
    auto rt = out_ty_of(lx, peel(type_at(lx, r.span)));
    auto f = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(rt)) {
            _v.set(Text::lit("get"));
            goto _done;
        }
        {
            _v.set(Text::lit("index"));
            goto _done;
        }
    _done:
        _v.take();
    });
    return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{f, Array(std::vector{argument(lx, env, r), argument(lx, env, i)})}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(t)})});
}


prism_rtl::Turn<Vl> IndexValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& r = this->r;
    const auto& i = this->i;
    const auto& t = this->t;
    auto env_1 = env;
    auto i_2 = i;
    auto lx_3 = lx;
    auto r_4 = r;
    auto t_5 = t;
    return call_then(start_out_ty_of(lx_3, peel(type_at(lx_3, r_4.span))), [=](crate::lower::model::OutTy out_ty_of_69777) {
        return ({
            auto rt = out_ty_of_69777;
            auto f = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(rt)) {
                    _v.set(Text::lit("get"));
                    goto _done;
                }
                {
                    _v.set(Text::lit("index"));
                    goto _done;
                }
            _done:
                _v.take();
            });
            call_then(start_argument(lx_3, env_1, r_4), [=](crate::lower::model::Ex argument_69927) { return call_then(start_argument(lx_3, env_1, i_2), [=](crate::lower::model::Ex argument_69950) { return prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{f, Array(std::vector{argument_69927, argument_69950})}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(t_5)})})); }); });
        });
    });
}


/// `Start IndexValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_index_value(Lx lx, Env env, crate::syntax::Expr r, crate::syntax::Expr i, crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<IndexValue>(lx, env, r, i, t);
}


/// ReadNames: unbounded fn [Expr] -> [Text]
Array<Text> read_names(const Array<crate::syntax::Expr>& es) {
    return fold(es, Array<Text>{}, [&](const Array<Text>& acc, const crate::syntax::Expr& x) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = x.kind;
            if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                _v.set(len(n->path_) == Nat(1u)
                    ? crate::check::types::add_text(acc, crate::check::env::sname_key(n))
                    : acc);
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Array<Text>> ReadNames::cycle() const {
    const auto& es = this->es;
    return prism_rtl::finished(fold(es, Array<Text>{}, [&](const Array<Text>& acc, const crate::syntax::Expr& x) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = x.kind;
            if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                _v.set(len(n->path_) == Nat(1u)
                    ? crate::check::types::add_text(acc, crate::check::env::sname_key(n))
                    : acc);
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    }));
}


/// `Start ReadNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_read_names(Array<crate::syntax::Expr> es) {
    return prism_rtl::make_rc<ReadNames>(es);
}


/// LambdaExprs: unbounded fn LambdaBody -> [Expr]
Array<crate::syntax::Expr> lambda_exprs(const crate::syntax::LambdaBody& lambda_body0) {
    if (prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(lambda_body0)) {
        auto&& x = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(lambda_body0).a0;
        return crate::check::typed::exprs_in(x);
    }
    if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(lambda_body0)) {
        auto&& b = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(lambda_body0).a0;
        return crate::check::typed::block_exprs(b);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<crate::syntax::Expr>> LambdaExprs::cycle() const {
    const auto& lambda_body0 = this->lambda_body0;
    return ({
        prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(lambda_body0) ? ({
        auto&& x = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(lambda_body0).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::typed::ExprsIn(x)));
    })
        : prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(lambda_body0) ? ({
        auto&& b = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(lambda_body0).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::typed::BlockExprs(b)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start LambdaExprs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::syntax::Expr>> start_lambda_exprs(crate::syntax::LambdaBody lambda_body0) {
    return prism_rtl::make_rc<LambdaExprs>(lambda_body0);
}


/// LambdaValue: unbounded fn Lx, Env, Expr, [Pattern], LambdaBody -> Vl
Vl lambda_value(const Lx& lx, const Env& env, const crate::syntax::Expr& e, const Array<crate::syntax::Pattern_>& ps, const crate::syntax::LambdaBody& body) {
    auto ft = out_ty_of(lx, peel(type_at(lx, e.span)));
    if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(ft)) {
        auto&& a = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(ft).a0;
        return job_lambda(lx, env, ps, body, ft, a, enters_lambda(lx, e));
    }
    {
        return plain_lambda(lx, env, ps, body, ft);
    }
}


prism_rtl::Turn<Vl> LambdaValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    const auto& ps = this->ps;
    const auto& body = this->body;
    auto body_1 = body;
    auto e_2 = e;
    auto env_3 = env;
    auto lx_4 = lx;
    auto ps_5 = ps;
    return call_then(start_out_ty_of(lx_4, peel(type_at(lx_4, e_2.span))), [=](crate::lower::model::OutTy out_ty_of_70615) {
        return ({
            auto ft = out_ty_of_70615;
            ({
            prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(ft) ? ({
            auto&& a = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(ft).a0;
            prism_rtl::more(prism_rtl::rc(JobLambda(lx_4, env_3, ps_5, body_1, ft, a, enters_lambda(lx_4, e_2))));
        })
            : prism_rtl::more(prism_rtl::rc(PlainLambda(lx_4, env_3, ps_5, body_1, ft)));
        });
        });
    });
}


/// `Start LambdaValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_lambda_value(Lx lx, Env env, crate::syntax::Expr e, Array<crate::syntax::Pattern_> ps, crate::syntax::LambdaBody body) {
    return prism_rtl::make_rc<LambdaValue>(lx, env, e, ps, body);
}


/// PlainLambda: unbounded fn Lx, Env, [Pattern], LambdaBody, OutTy -> Vl
Vl plain_lambda(const Lx& lx, const Env& env, const Array<crate::syntax::Pattern_>& ps, const crate::syntax::LambdaBody& body, const crate::lower::model::OutTy& ft) {
    auto pts = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
        if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(ft)) {
            auto&& xs = prism_rtl::as<crate::lower::model::OutTy::OutFn>(ft).a0;
            _v.set(xs);
            goto _done;
        }
        {
            _v.set(Array<crate::lower::model::OutTy>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto read = with_instances(env, read_names(lambda_exprs(body)));
    auto caps0 = filter(read, [&](const Text& n) {
        return ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = crate::prelude::get(env->names, n);
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                _v.set(true);
                goto _done;
            }
            {
                _v.set(false);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto caps = append(append(caps0, filter(each(read, [&](const Text& n) { return prism_rtl::cat(n, "#port"); }), [&](const Text& n) { return crate::check::env::has_key(env->names, n); })), filter(each(read, [&](const Text& n) { return prism_rtl::cat(n, "#init"); }), [&](const Text& n) { return crate::check::env::has_key(env->names, n); }));
    auto [dos, env1] = fold(caps, std::tuple{Array<crate::lower::model::Do>{}, env}, [&](const std::tuple<Array<crate::lower::model::Do>, Env>& _p0, const Text& n) {
        auto&& acc = std::get<0>(_p0);
        auto&& en = std::get<1>(_p0);
        return ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, Env>> _v;
            auto&& _m = crate::prelude::get(env->names, n);
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& mode = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                auto&& ct = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(({
                    auto local = place_stem(rs);
                    auto d = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{local}), own(local_place(rs, mode, ct))});
                    std::tuple{crate::prelude::push(acc, d), bind(en, n, Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{local}), Holding(Holding::Owned{}), ct}))};
                }));
                goto _done;
            }
            {
                _v.set(std::tuple{acc, en});
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto [pas, env2] = closure_params(lx, env1, ps, pts, true);
    auto v_ = lambda_body_value(lx, env2, body);
    return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, pas, prism_rtl::rc(own(v_))})})}))}), ft});
}


prism_rtl::Turn<Vl> PlainLambda::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& ps = this->ps;
    const auto& body = this->body;
    const auto& ft = this->ft;
    auto pts = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
        if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(ft)) {
            auto&& xs = prism_rtl::as<crate::lower::model::OutTy::OutFn>(ft).a0;
            _v.set(xs);
            goto _done;
        }
        {
            _v.set(Array<crate::lower::model::OutTy>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto body_1 = body;
    auto env_2 = env;
    auto ft_3 = ft;
    auto lx_4 = lx;
    auto ps_5 = ps;
    return call_then(start_lambda_exprs(body_1), [=](Array<crate::syntax::Expr> lambda_exprs_71038) {
        return call_then(start_read_names(lambda_exprs_71038), [=](Array<Text> read_names_71027) {
            return ({
                auto read = with_instances(env_2, read_names_71027);
                auto caps0 = filter(read, [&](const Text& n) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<bool> _v;
                        auto&& _m = crate::prelude::get(env_2->names, n);
                        if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                            _v.set(true);
                            goto _done;
                        }
                        {
                            _v.set(false);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                });
                auto caps = append(append(caps0, filter(each(read, [&](const Text& n) { return prism_rtl::cat(n, "#port"); }), [&](const Text& n) { return crate::check::env::has_key(env_2->names, n); })), filter(each(read, [&](const Text& n) { return prism_rtl::cat(n, "#init"); }), [&](const Text& n) { return crate::check::env::has_key(env_2->names, n); }));
                auto [dos, env1] = fold(caps, std::tuple{Array<crate::lower::model::Do>{}, env_2}, [&](const std::tuple<Array<crate::lower::model::Do>, Env>& _p0, const Text& n) {
                    auto&& acc = std::get<0>(_p0);
                    auto&& en = std::get<1>(_p0);
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, Env>> _v;
                        auto&& _m = crate::prelude::get(env_2->names, n);
                        if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                            auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                            auto&& mode = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                            auto&& ct = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                            _v.set(({
                                auto local = place_stem(rs);
                                auto d = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{local}), own(local_place(rs, mode, ct))});
                                std::tuple{crate::prelude::push(acc, d), bind(en, n, Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{local}), Holding(Holding::Owned{}), ct}))};
                            }));
                            goto _done;
                        }
                        {
                            _v.set(std::tuple{acc, en});
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                });
                call_then(start_closure_params(lx_4, env1, ps_5, pts, true), [=](std::tuple<Array<crate::lower::model::Pa>, Env> closure_params_71921) {
                return ({
                    auto [pas, env2] = closure_params_71921;
                    call_then(start_lambda_body_value(lx_4, env2, body_1), [=](Vl lambda_body_value_71971) {
                    return ({
                        auto v_ = lambda_body_value_71971;
                        (prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, pas, prism_rtl::rc(own(v_))})})}))}), ft_3})));
                    });
                });
                });
            });
            });
        });
    });
}


/// `Start PlainLambda, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_plain_lambda(Lx lx, Env env, Array<crate::syntax::Pattern_> ps, crate::syntax::LambdaBody body, crate::lower::model::OutTy ft) {
    return prism_rtl::make_rc<PlainLambda>(lx, env, ps, body, ft);
}


/// LambdaParamTys: unbounded fn Lx, Expr, Nat -> [OutTy]
Array<crate::lower::model::OutTy> lambda_param_tys(const Lx& lx, const crate::syntax::Expr& e, const Nat& n) {
    auto ts = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
        auto&& _m = out_ty_of(lx, peel(type_at(lx, e.span)));
        if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(_m)) {
            auto&& xs = prism_rtl::as<crate::lower::model::OutTy::OutFn>(_m).a0;
            _v.set(xs);
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m)) {
            auto&& a = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
                auto&& _m = a;
                if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(_m)) {
                    auto&& xs = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(_m).a0;
                    _v.set(n == Nat(1u) ? Array(std::vector{a}) : xs);
                    goto _done;
                }
                {
                    _v.set(Array(std::vector{a}));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(Array<crate::lower::model::OutTy>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return (len(ts) == n) && run_to_end(fold_job(ts, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto t = p1;
                (prism_rtl::finished(ok && is_known_ty(t)));
            });
        }));
    }))))
        ? ts
        : Array<crate::lower::model::OutTy>{};
}


prism_rtl::Turn<Array<crate::lower::model::OutTy>> LambdaParamTys::cycle() const {
    const auto& lx = this->lx;
    const auto& e = this->e;
    const auto& n = this->n;
    auto e_1 = e;
    auto lx_2 = lx;
    auto n_3 = n;
    return call_then(start_out_ty_of(lx_2, peel(type_at(lx_2, e_1.span))), [=](crate::lower::model::OutTy out_ty_of_72375) {
        return ({
            auto ts = ({
                __label__ _done;
                prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
                if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(out_ty_of_72375)) {
                    auto&& xs = prism_rtl::as<crate::lower::model::OutTy::OutFn>(out_ty_of_72375).a0;
                    _v.set(xs);
                    goto _done;
                }
                if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(out_ty_of_72375)) {
                    auto&& a = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(out_ty_of_72375).a0;
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
                        auto&& _m = a;
                        if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(_m)) {
                            auto&& xs = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(_m).a0;
                            _v.set(n_3 == Nat(1u) ? Array(std::vector{a}) : xs);
                            goto _done;
                        }
                        {
                            _v.set(Array(std::vector{a}));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                {
                    _v.set(Array<crate::lower::model::OutTy>{});
                    goto _done;
                }
            _done:
                _v.take();
            });
            (len(ts) == n_3) && run_to_end(fold_job(ts, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto t = p1;
                    (prism_rtl::finished(ok && is_known_ty(t)));
                });
            }));
        }))))
            ? prism_rtl::finished(ts)
            : prism_rtl::finished(Array<crate::lower::model::OutTy>{});
        });
    });
}


/// `Start LambdaParamTys, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::OutTy>> start_lambda_param_tys(Lx lx, crate::syntax::Expr e, Nat n) {
    return prism_rtl::make_rc<LambdaParamTys>(lx, e, n);
}


/// IsKnownTy: unbounded fn OutTy -> Bool
bool is_known_ty(const crate::lower::model::OutTy& t) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutUnknown>(t)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t)) {
        auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t).a0;
        return is_known_ty(x);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t)) {
        auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t).a0;
        return is_known_ty(x);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutArray>(t)) {
        auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t).a0;
        return is_known_ty(x);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRc>(t)) {
        auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t).a0;
        return is_known_ty(x);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(t)) {
        auto&& k = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t).a1;
        return is_known_ty(k) && is_known_ty(v_);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t)) {
        auto&& xs = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t).a0;
        return run_to_end(fold_job(xs, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto x = p1;
                    (prism_rtl::finished(ok && is_known_ty(x)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t)) {
        auto&& xs = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        return run_to_end(fold_job(xs, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto x = p1;
                    (prism_rtl::finished(ok && is_known_ty(x)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(t)) {
        auto&& xs = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t).a0;
        auto&& r = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t).a1;
        return run_to_end(fold_job(xs, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto x = p1;
                    (prism_rtl::finished(ok && is_known_ty(x)));
                });
            }));
        })))) && is_known_ty(r);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t)) {
        auto&& a = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t).a0;
        auto&& b = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t).a1;
        return is_known_ty(a) && is_known_ty(b);
    }
    {
        return true;
    }
}


prism_rtl::Turn<bool> IsKnownTy::cycle() const {
    const auto& t = this->t;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutUnknown>(t) ? prism_rtl::finished(false)
        : prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t) ? ({
        auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t).a0;
        prism_rtl::more(prism_rtl::rc(IsKnownTy(x)));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRes>(t) ? ({
        auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t).a0;
        prism_rtl::more(prism_rtl::rc(IsKnownTy(x)));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutArray>(t) ? ({
        auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t).a0;
        prism_rtl::more(prism_rtl::rc(IsKnownTy(x)));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRc>(t) ? ({
        auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t).a0;
        prism_rtl::more(prism_rtl::rc(IsKnownTy(x)));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutMap>(t) ? ({
        auto&& k = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t).a1;
        ({
        auto k_1 = k;
        auto v__2 = v_;
        call_then(start_is_known_ty(k_1), [=](bool is_known_ty_72885) { return prism_rtl::finished(is_known_ty_72885 && is_known_ty(v__2)); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t) ? ({
        auto&& xs = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t).a0;
        fold_job(xs, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto x = p1;
                (prism_rtl::finished(ok && is_known_ty(x)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t) ? ({
        auto&& xs = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        fold_job(xs, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto x = p1;
                (prism_rtl::finished(ok && is_known_ty(x)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutFn>(t) ? ({
        auto&& xs = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t).a0;
        auto&& r = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t).a1;
        ({
        auto r_1 = r;
        auto xs_2 = xs;
        call_value(fold_job(xs_2, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto x = p1;
                (prism_rtl::finished(ok && is_known_ty(x)));
            });
        }));
    }))), [=](bool fold_73060) { return prism_rtl::finished(fold_73060 && is_known_ty(r_1)); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t) ? ({
        auto&& a = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t).a0;
        auto&& b = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t).a1;
        ({
        auto a_1 = a;
        auto b_2 = b;
        call_then(start_is_known_ty(a_1), [=](bool is_known_ty_73140) { return prism_rtl::finished(is_known_ty_73140 && is_known_ty(b_2)); });
    });
    })
        : prism_rtl::finished(true);
    });
}


/// `Start IsKnownTy, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_known_ty(crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<IsKnownTy>(t);
}


/// JobLambda: unbounded fn Lx, Env, [Pattern], LambdaBody, OutTy, OutTy, Bool -> Vl
Vl job_lambda(const Lx& lx, const Env& env, const Array<crate::syntax::Pattern_>& ps, const crate::syntax::LambdaBody& body, const crate::lower::model::OutTy& ft, const crate::lower::model::OutTy& a, const bool& enter) {
    auto caps = filter(with_instances(env, read_names(lambda_exprs(body))), [&](const Text& n) {
        return ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = crate::prelude::get(env->names, n);
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                _v.set(true);
                goto _done;
            }
            {
                _v.set(false);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto [dos, env1] = fold(caps, std::tuple{Array<crate::lower::model::Do>{}, env}, [&](const std::tuple<Array<crate::lower::model::Do>, Env>& _p0, const Text& n) {
        auto&& acc = std::get<0>(_p0);
        auto&& en = std::get<1>(_p0);
        return ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, Env>> _v;
            auto&& _m = crate::prelude::get(env->names, n);
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& mode = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                auto&& ct = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(({
                    auto d = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{place_stem(rs)}), own(local_place(rs, mode, ct))});
                    std::tuple{crate::prelude::push(acc, d), bind(en, n, Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), ct}))};
                }));
                goto _done;
            }
            {
                _v.set(std::tuple{acc, en});
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto again = fold(caps, Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc, const Text& n) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::model::Do>> _v;
            auto&& _m = crate::prelude::get(env1->names, n);
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& ct = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(crate::prelude::push(acc, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{place_stem(rs)}), own(local_place(rs, Holding(Holding::Owned{}), ct))})));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto pts = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
        if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(a)) {
            auto&& ts = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(a).a0;
            _v.set(len(ps) == Nat(1u) ? Array(std::vector{a}) : ts);
            goto _done;
        }
        {
            _v.set(Array(std::vector{a}));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto env1b = only_captured(env1, caps);
    auto pos = run_to_end(each_job(crate::check::errors::range0(len(ps)), ({
        auto ps_1 = ps;
        auto lx_2 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto ps_1_3 = ps_1;
            auto lx_2_3 = lx_2;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto p_ = or_(index(ps_1_3, i), dummy_pat());
                (prism_rtl::more(prism_rtl::rc(RustPat(lx_2_3, p_, binder_ty_of_pattern(lx_2_3, p_), Holding(Holding::Owned{}), prism_rtl::cat("p", i, "_")))));
            });
            });
        }));
        });
    })));
    })));
    auto unpack = fold(crate::check::errors::range0(len(pos)), Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc, const Nat& i) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::model::Do>> _v;
            auto&& _m = index(pos, i);
            if (prism_rtl::is_some(_m)) {
                auto&& po = prism_rtl::some_of(_m);
                _v.set(append(crate::prelude::push(acc, crate::lower::model::Do(crate::lower::model::Do::DoLet{po.pa, crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("p", i)})})), each(po.conds, [&](const crate::lower::model::Cc& c) { return cond_as_let(c); })));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(acc);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    auto pos2 = each(crate::check::errors::range0(len(pos)), [&](const Nat& i) {
        return ({
            __label__ _done;
            prism_rtl::Slot<PatOut> _v;
            auto&& _m = index(pos, i);
            if (prism_rtl::is_some(_m)) {
                auto&& po = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<PatOut> _v;
                    auto&& _m = or_(index(ps, i), dummy_pat()).kind;
                    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                        _v.set(({
                            PatOut this_ = po;
                            this_.binds = each(this_.binds, [&](const std::tuple<Text, Bn>& _p0) {
                                auto&& n = std::get<0>(_p0);
                                auto&& b = std::get<1>(_p0);
                                return ({
                                    __label__ _done;
                                    prism_rtl::Slot<std::tuple<Text, Bn>> _v;
                                    if (prism_rtl::is<Bn::BnLocal>(b)) {
                                        auto&& rs = prism_rtl::as<Bn::BnLocal>(b).a0;
                                        auto&& mode = prism_rtl::as<Bn::BnLocal>(b).a1;
                                        auto&& bt = prism_rtl::as<Bn::BnLocal>(b).a2;
                                        _v.set(std::tuple{n, Bn(Bn::BnLocal{rs, mode, or_(index(pts, i), bt)})});
                                        goto _done;
                                    }
                                    {
                                        _v.set(std::tuple{n, b});
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                });
                            });
                            this_;
                        }));
                        goto _done;
                    }
                    {
                        _v.set(po);
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array<std::tuple<Text, Bn>>{}});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    auto env2 = fold(pos2, env1b, [&](const Env& en, const PatOut& po) { return bind_all(en, po.binds); });
    auto names = each(crate::check::errors::range0(len(ps)), [&](const Nat& i) { return prism_rtl::cat("p", i); });
    auto pa = len(ps) == Nat(1u)
        ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("p0")})), a})
        : crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(names, [&](const Text& nm) { return crate::lower::model::Pa(crate::lower::model::Pa::PaBind{nm}); })})), a});
    auto tail0 = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Ex> _v;
        if (prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(body)) {
            auto&& x = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(body).a0;
            _v.set(tail(lx, env2, x));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(body)) {
            auto&& bl = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(body).a0;
            _v.set(tail_block(lx, env2, bl));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto tail_ = len(unpack) == Nat(0u)
        ? tail0
        : crate::lower::model::Ex(crate::lower::model::Ex::XBlock{unpack, prism_rtl::rc(tail0)});
    auto job0 = crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("once_job"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array<crate::lower::model::Pa>{}, prism_rtl::rc(tail_)})})});
    auto job = enter
        ? crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("entered"), Array(std::vector{job0})})
        : job0;
    auto call = len(again) == Nat(0u)
        ? job
        : crate::lower::model::Ex(crate::lower::model::Ex::XBlock{again, prism_rtl::rc(job)});
    return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{pa}), prism_rtl::rc(call)})})})), ft}))}), ft});
}


prism_rtl::Turn<Vl> JobLambda::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& ps = this->ps;
    const auto& body = this->body;
    const auto& ft = this->ft;
    const auto& a = this->a;
    const auto& enter = this->enter;
    auto a_1 = a;
    auto body_2 = body;
    auto enter_3 = enter;
    auto env_4 = env;
    auto ft_5 = ft;
    auto lx_6 = lx;
    auto ps_7 = ps;
    return call_then(start_lambda_exprs(body_2), [=](Array<crate::syntax::Expr> lambda_exprs_74016) {
        return call_then(start_read_names(lambda_exprs_74016), [=](Array<Text> read_names_74005) {
            return ({
                auto caps = filter(with_instances(env_4, read_names_74005), [&](const Text& n) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<bool> _v;
                        auto&& _m = crate::prelude::get(env_4->names, n);
                        if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                            _v.set(true);
                            goto _done;
                        }
                        {
                            _v.set(false);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                });
                auto [dos, env1] = fold(caps, std::tuple{Array<crate::lower::model::Do>{}, env_4}, [&](const std::tuple<Array<crate::lower::model::Do>, Env>& _p0, const Text& n) {
                    auto&& acc = std::get<0>(_p0);
                    auto&& en = std::get<1>(_p0);
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, Env>> _v;
                        auto&& _m = crate::prelude::get(env_4->names, n);
                        if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                            auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                            auto&& mode = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                            auto&& ct = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                            _v.set(({
                                auto d = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{place_stem(rs)}), own(local_place(rs, mode, ct))});
                                std::tuple{crate::prelude::push(acc, d), bind(en, n, Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), ct}))};
                            }));
                            goto _done;
                        }
                        {
                            _v.set(std::tuple{acc, en});
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                });
                auto again = fold(caps, Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc, const Text& n) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<crate::lower::model::Do>> _v;
                        auto&& _m = crate::prelude::get(env1->names, n);
                        if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                            auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                            auto&& ct = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                            _v.set(crate::prelude::push(acc, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{place_stem(rs)}), own(local_place(rs, Holding(Holding::Owned{}), ct))})));
                            goto _done;
                        }
                        {
                            _v.set(acc);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                });
                auto pts = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
                    if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(a)) {
                        auto&& ts = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(a).a0;
                        _v.set(len(ps_7) == Nat(1u) ? Array(std::vector{a_1}) : ts);
                        goto _done;
                    }
                    {
                        _v.set(Array(std::vector{a_1}));
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto env1b = only_captured(env1, caps);
                call_value(each_job(crate::check::errors::range0(len(ps_7)), ({
                auto ps_7_8 = ps_7;
                auto lx_6_8 = lx_6;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                return ({
                    auto ps_7_8_8 = ps_7_8;
                    auto lx_6_8_8 = lx_6_8;
                    entered(once_job([=]() {
                    return ({
                        auto i = p0;
                        ({
                        auto p_ = or_(index(ps_7_8_8, i), dummy_pat());
                        (prism_rtl::more(prism_rtl::rc(RustPat(lx_6_8_8, p_, binder_ty_of_pattern(lx_6_8_8, p_), Holding(Holding::Owned{}), prism_rtl::cat("p", i, "_")))));
                    });
                    });
                }));
                });
            })));
            })), [=](Array<PatOut> each_75044) {
                return ({
                    auto pos = each_75044;
                    auto unpack = fold(crate::check::errors::range0(len(pos)), Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc, const Nat& i) {
                        return ({
                            __label__ _done;
                            prism_rtl::Slot<Array<crate::lower::model::Do>> _v;
                            auto&& _m = index(pos, i);
                            if (prism_rtl::is_some(_m)) {
                                auto&& po = prism_rtl::some_of(_m);
                                _v.set(append(crate::prelude::push(acc, crate::lower::model::Do(crate::lower::model::Do::DoLet{po.pa, crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("p", i)})})), each(po.conds, [&](const crate::lower::model::Cc& c) { return cond_as_let(c); })));
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(acc);
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        });
                    });
                    auto pos2 = each(crate::check::errors::range0(len(pos)), [&](const Nat& i) {
                        return ({
                            __label__ _done;
                            prism_rtl::Slot<PatOut> _v;
                            auto&& _m = index(pos, i);
                            if (prism_rtl::is_some(_m)) {
                                auto&& po = prism_rtl::some_of(_m);
                                _v.set(({
                                    __label__ _done;
                                    prism_rtl::Slot<PatOut> _v;
                                    auto&& _m = or_(index(ps_7, i), dummy_pat()).kind;
                                    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                                        _v.set(({
                                            PatOut this_ = po;
                                            this_.binds = each(this_.binds, [&](const std::tuple<Text, Bn>& _p0) {
                                                auto&& n = std::get<0>(_p0);
                                                auto&& b = std::get<1>(_p0);
                                                return ({
                                                    __label__ _done;
                                                    prism_rtl::Slot<std::tuple<Text, Bn>> _v;
                                                    if (prism_rtl::is<Bn::BnLocal>(b)) {
                                                        auto&& rs = prism_rtl::as<Bn::BnLocal>(b).a0;
                                                        auto&& mode = prism_rtl::as<Bn::BnLocal>(b).a1;
                                                        auto&& bt = prism_rtl::as<Bn::BnLocal>(b).a2;
                                                        _v.set(std::tuple{n, Bn(Bn::BnLocal{rs, mode, or_(index(pts, i), bt)})});
                                                        goto _done;
                                                    }
                                                    {
                                                        _v.set(std::tuple{n, b});
                                                        goto _done;
                                                    }
                                                _done:
                                                    _v.take();
                                                });
                                            });
                                            this_;
                                        }));
                                        goto _done;
                                    }
                                    {
                                        _v.set(po);
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                }));
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array<std::tuple<Text, Bn>>{}});
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        });
                    });
                    auto env2 = fold(pos2, env1b, [&](const Env& en, const PatOut& po) { return bind_all(en, po.binds); });
                    auto names = each(crate::check::errors::range0(len(ps_7)), [&](const Nat& i) { return prism_rtl::cat("p", i); });
                    auto pa = len(ps_7) == Nat(1u)
                        ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("p0")})), a_1})
                        : crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(names, [&](const Text& nm) { return crate::lower::model::Pa(crate::lower::model::Pa::PaBind{nm}); })})), a_1});
                    auto tail0 = ({
                        __label__ _done;
                        prism_rtl::Slot<crate::lower::model::Ex> _v;
                        if (prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(body)) {
                            auto&& x = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(body).a0;
                            _v.set(tail(lx_6, env2, x));
                            goto _done;
                        }
                        if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(body)) {
                            auto&& bl = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(body).a0;
                            _v.set(tail_block(lx_6, env2, bl));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    auto tail_ = len(unpack) == Nat(0u)
                        ? tail0
                        : crate::lower::model::Ex(crate::lower::model::Ex::XBlock{unpack, prism_rtl::rc(tail0)});
                    auto job0 = crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("once_job"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array<crate::lower::model::Pa>{}, prism_rtl::rc(tail_)})})});
                    auto job = enter_3
                        ? crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("entered"), Array(std::vector{job0})})
                        : job0;
                    auto call = len(again) == Nat(0u)
                        ? job
                        : crate::lower::model::Ex(crate::lower::model::Ex::XBlock{again, prism_rtl::rc(job)});
                    (prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{pa}), prism_rtl::rc(call)})})})), ft_5}))}), ft_5})));
                });
            });
            });
        });
    });
}


/// `Start JobLambda, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_job_lambda(Lx lx, Env env, Array<crate::syntax::Pattern_> ps, crate::syntax::LambdaBody body, crate::lower::model::OutTy ft, crate::lower::model::OutTy a, bool enter) {
    return prism_rtl::make_rc<JobLambda>(lx, env, ps, body, ft, a, enter);
}


/// EntersLambda: fn Lx, Expr -> Bool
bool enters_lambda(const Lx& lx, const crate::syntax::Expr& e) {
    auto&& _m = peel(type_at(lx, e.span));
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CBound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0)) {
        return false;
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// OnlyCaptured: fn Env, [Text] -> Env
Env only_captured(const Env& env, const Array<Text>& caps) {
    Env this_ = env;
    this_.names = fold(keys(env->names), Map<Text, Bn>{}, [&](const Map<Text, Bn>& m, const Text& k) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, Bn>> _v;
            auto&& _m = crate::prelude::get(env->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& mode = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                auto&& t = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(crate::check::types::has_text(caps, k) || (mode == Holding(Holding::Owned{}))
                    ? insert(m, k, Bn(Bn::BnLocal{rs, mode, t}))
                    : m);
                goto _done;
            }
            if (prism_rtl::is_some(_m)) {
                auto&& b = prism_rtl::some_of(_m);
                _v.set(insert(m, k, b));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(m);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    return this_;
}


/// CondAsLet: fn Cc -> Do
crate::lower::model::Do cond_as_let(const crate::lower::model::Cc& cc0) {
    if (prism_rtl::is<crate::lower::model::Cc::CcLet>(cc0)) {
        auto&& pa = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc0).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc0).a1;
        return crate::lower::model::Do(crate::lower::model::Do::DoLet{pa, x});
    }
    if (prism_rtl::is<crate::lower::model::Cc::CcIf>(cc0)) {
        auto&& x = prism_rtl::as<crate::lower::model::Cc::CcIf>(cc0).a0;
        return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})});
    }
    prism_rtl::unreachable("no arm matched");
}


/// LambdaArg: unbounded fn Lx, Env, [Pattern], LambdaBody, [OutTy] -> Ex
crate::lower::model::Ex lambda_arg(const Lx& lx, const Env& env, const Array<crate::syntax::Pattern_>& ps, const crate::syntax::LambdaBody& body, const Array<crate::lower::model::OutTy>& pts) {
    auto [pas, env2] = closure_params(lx, env, ps, pts, len(pts) > Nat(0u));
    auto v_ = lambda_body_value(lx, env2, body);
    return crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, pas, prism_rtl::rc(own(v_))});
}


prism_rtl::Turn<crate::lower::model::Ex> LambdaArg::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& ps = this->ps;
    const auto& body = this->body;
    const auto& pts = this->pts;
    auto body_1 = body;
    auto env_2 = env;
    auto lx_3 = lx;
    auto ps_4 = ps;
    auto pts_5 = pts;
    return call_then(start_closure_params(lx_3, env_2, ps_4, pts_5, len(pts_5) > Nat(0u)), [=](std::tuple<Array<crate::lower::model::Pa>, Env> closure_params_77784) {
        return ({
            auto [pas, env2] = closure_params_77784;
            call_then(start_lambda_body_value(lx_3, env2, body_1), [=](Vl lambda_body_value_77842) {
            return ({
                auto v_ = lambda_body_value_77842;
                (prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, pas, prism_rtl::rc(own(v_))})));
            });
        });
        });
    });
}


/// `Start LambdaArg, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_lambda_arg(Lx lx, Env env, Array<crate::syntax::Pattern_> ps, crate::syntax::LambdaBody body, Array<crate::lower::model::OutTy> pts) {
    return prism_rtl::make_rc<LambdaArg>(lx, env, ps, body, pts);
}


/// LambdaBodyValue: unbounded fn Lx, Env, LambdaBody -> Vl
Vl lambda_body_value(const Lx& lx, const Env& env, const crate::syntax::LambdaBody& lambda_body2) {
    if (prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(lambda_body2)) {
        auto&& x = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(lambda_body2).a0;
        return value_of(lx, env, x);
    }
    if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(lambda_body2)) {
        auto&& b = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(lambda_body2).a0;
        return block_value(lx, env, b);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Vl> LambdaBodyValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& lambda_body2 = this->lambda_body2;
    return ({
        prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(lambda_body2) ? ({
        auto&& x = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(lambda_body2).a0;
        prism_rtl::more(prism_rtl::rc(ValueOf(lx, env, x)));
    })
        : prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(lambda_body2) ? ({
        auto&& b = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(lambda_body2).a0;
        prism_rtl::more(prism_rtl::rc(BlockValue(lx, env, b)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start LambdaBodyValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_lambda_body_value(Lx lx, Env env, crate::syntax::LambdaBody lambda_body2) {
    return prism_rtl::make_rc<LambdaBodyValue>(lx, env, lambda_body2);
}


/// ClosureParams: unbounded fn Lx, Env, [Pattern], [OutTy], Bool -> (([Pa], Env))
std::tuple<Array<crate::lower::model::Pa>, Env> closure_params(const Lx& lx, const Env& env, const Array<crate::syntax::Pattern_>& ps, const Array<crate::lower::model::OutTy>& pts, const bool& typed) {
    return run_to_end(fold_job(crate::check::errors::range0(len(ps)), std::tuple{Array<crate::lower::model::Pa>{}, env}, ({
        auto ps_1 = ps;
        auto lx_2 = lx;
        auto typed_3 = typed;
        auto pts_4 = pts;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Pa>, Env>>(std::tuple<std::tuple<Array<crate::lower::model::Pa>, Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::lower::model::Pa>, Env>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto ps_1_5 = ps_1;
            auto lx_2_5 = lx_2;
            auto typed_3_5 = typed_3;
            auto pts_4_5 = pts_4;
            entered(once_job([=]() {
            return ({
                auto [acc, en] = p0;
                auto i = p1;
                ({
                auto&& _m = index(ps_1_5, i);
                prism_rtl::is_some(_m) ? ({
                auto&& p_ = prism_rtl::some_of(_m);
                call_then(start_rust_pat(lx_2_5, p_, binder_ty_of_pattern(lx_2_5, p_), Holding(Holding::ByRef{}), prism_rtl::cat("a", p_.span.start)), [=](PatOut rust_pat_78405) {
                return ({
                    auto po = rust_pat_78405;
                    auto en2 = bind_all(en, po.binds);
                    auto pa = typed_3_5
                        ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(po.pa), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(or_(index(pts_4_5, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{Text::lit("a parameter")})))})})
                        : po.pa;
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc, pa), en2}));
                });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{acc, en})
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Array<crate::lower::model::Pa>, Env>> ClosureParams::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& ps = this->ps;
    const auto& pts = this->pts;
    const auto& typed = this->typed;
    return fold_job(crate::check::errors::range0(len(ps)), std::tuple{Array<crate::lower::model::Pa>{}, env}, ({
        auto ps_1 = ps;
        auto lx_2 = lx;
        auto typed_3 = typed;
        auto pts_4 = pts;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Pa>, Env>>(std::tuple<std::tuple<Array<crate::lower::model::Pa>, Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::lower::model::Pa>, Env>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto ps_1_5 = ps_1;
            auto lx_2_5 = lx_2;
            auto typed_3_5 = typed_3;
            auto pts_4_5 = pts_4;
            entered(once_job([=]() {
            return ({
                auto [acc, en] = p0;
                auto i = p1;
                ({
                auto&& _m = index(ps_1_5, i);
                prism_rtl::is_some(_m) ? ({
                auto&& p_ = prism_rtl::some_of(_m);
                call_then(start_rust_pat(lx_2_5, p_, binder_ty_of_pattern(lx_2_5, p_), Holding(Holding::ByRef{}), prism_rtl::cat("a", p_.span.start)), [=](PatOut rust_pat_78405) {
                return ({
                    auto po = rust_pat_78405;
                    auto en2 = bind_all(en, po.binds);
                    auto pa = typed_3_5
                        ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(po.pa), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(or_(index(pts_4_5, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{Text::lit("a parameter")})))})})
                        : po.pa;
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc, pa), en2}));
                });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{acc, en})
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start ClosureParams, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Pa>, Env>> start_closure_params(Lx lx, Env env, Array<crate::syntax::Pattern_> ps, Array<crate::lower::model::OutTy> pts, bool typed) {
    return prism_rtl::make_rc<ClosureParams>(lx, env, ps, pts, typed);
}


/// BindAll: fn Env, [((Text, Bn))] -> Env
Env bind_all(const Env& env, const Array<std::tuple<Text, Bn>>& bs) {
    return fold(bs, env, [&](const Env& en, const std::tuple<Text, Bn>& _p1) {
        auto&& n = std::get<0>(_p1);
        auto&& b = std::get<1>(_p1);
        return bind(en, n, b);
    });
}


/// BinderTyOfPattern: fn Lx, Pattern -> Ty
crate::check::types::Ty binder_ty_of_pattern(const Lx& lx, const crate::syntax::Pattern_& p_) {
    auto&& _m = p_.kind;
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        return binder_ty(lx, n.span);
    }
    {
        return type_at(lx, p_.span);
    }
}


/// IfValue: unbounded fn Lx, Env, Cond, Block, ?Block, OutTy -> Vl
Vl if_value(const Lx& lx, const Env& env, const crate::syntax::Cond& c, const crate::syntax::Block& then_b, const std::optional<crate::syntax::Block>& else_b_opt, const crate::lower::model::OutTy& t) {
    auto else_v = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Ex> _v;
        if (prism_rtl::is_some(else_b_opt)) {
            auto&& b = prism_rtl::some_of(else_b_opt);
            _v.set(crate::lower::node_::own_as(t, block_value(lx, env, b)));
            goto _done;
        }
        if (prism_rtl::is_none(else_b_opt)) {
            _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c)) {
        auto&& x = prism_rtl::as<crate::syntax::Cond::CondExpr>(c).a0;
        return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XIf{prism_rtl::rc(as_bool(value_of(lx, env, x))), prism_rtl::rc(crate::lower::node_::own_as(t, block_value(lx, env, then_b))), prism_rtl::rc(else_v)}), t});
    }
    if (prism_rtl::is<crate::syntax::Cond::CondBind>(c)) {
        auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a0;
        auto&& x = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a1;
        auto&& g_opt = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a2;
        auto sv = value_of(lx, env, x);
        auto po = rust_pat(lx, p_, type_at(lx, x.span), Holding(Holding::ByRef{}), prism_rtl::cat("c", x.span.start));
        auto env2 = bind_all(env, po.binds);
        auto guard = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::model::Cc>> _v;
            auto&& _m = g_opt;
            if (prism_rtl::is_some(_m)) {
                auto&& ge = prism_rtl::some_of(_m);
                _v.set(Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{as_bool(value_of(lx, env2, ge))})}));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<crate::lower::model::Cc>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto arm = crate::lower::model::XArm{.pat = po.pa, .conds = append(po.conds, guard), .body = crate::lower::node_::own_as(t, block_value(lx, env2, then_b))};
        auto other = crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .body = else_v};
        return arms_value(ref_(sv), Array(std::vector{arm, other}), prism_rtl::cat("c", x.span.start), t);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Vl> IfValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& c = this->c;
    const auto& then_b = this->then_b;
    const auto& else_b_opt = this->else_b_opt;
    const auto& t = this->t;
    auto else_v = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Ex> _v;
        if (prism_rtl::is_some(else_b_opt)) {
            auto&& b = prism_rtl::some_of(else_b_opt);
            _v.set(crate::lower::node_::own_as(t, block_value(lx, env, b)));
            goto _done;
        }
        if (prism_rtl::is_none(else_b_opt)) {
            _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ({
        prism_rtl::is<crate::syntax::Cond::CondExpr>(c) ? ({
        auto&& x = prism_rtl::as<crate::syntax::Cond::CondExpr>(c).a0;
        ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto t_3 = t;
        auto then_b_4 = then_b;
        auto x_5 = x;
        call_then(start_value_of(lx_2, env_1, x_5), [=](Vl value_of_79311) { return call_then(start_block_value(lx_2, env_1, then_b_4), [=](Vl block_value_79344) { return prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XIf{prism_rtl::rc(as_bool(value_of_79311)), prism_rtl::rc(crate::lower::node_::own_as(t_3, block_value_79344)), prism_rtl::rc(else_v)}), t_3})); }); });
    });
    })
        : prism_rtl::is<crate::syntax::Cond::CondBind>(c) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a0;
        auto&& x = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a1;
        auto&& g_opt = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a2;
        ({
        auto g_opt_1 = g_opt;
        auto c_2 = c;
        auto env_3 = env;
        auto lx_4 = lx;
        auto p__5 = p_;
        auto t_6 = t;
        auto then_b_7 = then_b;
        auto x_8 = x;
        call_then(start_value_of(lx_4, env_3, x_8), [=](Vl value_of_79431) {
        return ({
            auto sv = value_of_79431;
            call_then(start_rust_pat(lx_4, p__5, type_at(lx_4, x_8.span), Holding(Holding::ByRef{}), prism_rtl::cat("c", x_8.span.start)), [=](PatOut rust_pat_79471) {
            return ({
                auto po = rust_pat_79471;
                auto env2 = bind_all(env_3, po.binds);
                auto guard = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::lower::model::Cc>> _v;
                    if (prism_rtl::is_some(g_opt)) {
                        auto&& ge = prism_rtl::some_of(g_opt);
                        _v.set(Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{as_bool(value_of(lx_4, env2, ge))})}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(g_opt)) {
                        _v.set(Array<crate::lower::model::Cc>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                call_then(start_block_value(lx_4, env2, then_b_7), [=](Vl block_value_79786) {
                return ({
                    auto arm = crate::lower::model::XArm{.pat = po.pa, .conds = append(po.conds, guard), .body = crate::lower::node_::own_as(t_6, block_value_79786)};
                    auto other = crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .body = else_v};
                    (prism_rtl::finished(arms_value(ref_(sv), Array(std::vector{arm, other}), prism_rtl::cat("c", x_8.span.start), t_6)));
                });
            });
            });
        });
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start IfValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_if_value(Lx lx, Env env, crate::syntax::Cond c, crate::syntax::Block then_b, std::optional<crate::syntax::Block> else_b_opt, crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<IfValue>(lx, env, c, then_b, else_b_opt, t);
}


/// ArmsValue: fn Ex, [XArm], Text, OutTy -> Vl
Vl arms_value(const crate::lower::model::Ex& scrut, const Array<crate::lower::model::XArm>& arms, const Text& label, const crate::lower::model::OutTy& t) {
    auto chain = fold(arms, false, [&](const bool& f, const crate::lower::model::XArm& a) { return f || fold(a.conds, false, [&](const bool& f2, const crate::lower::model::Cc& c) { return f2 || is_let_cond(c); }); });
    auto guarded = fold(arms, false, [&](const bool& f, const crate::lower::model::XArm& a) { return f || (len(a.conds) > Nat(0u)); });
    return chain
        ? Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XChain{label, prism_rtl::rc(scrut), arms, t}), t})
        : Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XMatch{prism_rtl::rc(scrut), arms, guarded, t}), t});
}


/// IsLetCond: fn Cc -> Bool
bool is_let_cond(const crate::lower::model::Cc& cc0) {
    if (prism_rtl::is<crate::lower::model::Cc::CcLet>(cc0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Cc::CcIf>(cc0)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// MatchValue: unbounded fn Lx, Env, Expr, [Arm], OutTy, Range -> Vl
Vl match_value(const Lx& lx, const Env& env, const crate::syntax::Expr& s, const Array<crate::syntax::Arm>& arms, const crate::lower::model::OutTy& t, const crate::syntax::Range& span) {
    auto sv = value_of(lx, env, s);
    auto sty = type_at(lx, s.span);
    auto label = prism_rtl::cat("m", span.start);
    auto by_ref = run_to_end(each_job(crate::check::errors::range0(len(arms)), ({
        auto lx_1 = lx;
        auto arms_2 = arms;
        auto sty_3 = sty;
        auto label_4 = label;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto lx_1_5 = lx_1;
            auto arms_2_5 = arms_2;
            auto sty_3_5 = sty_3;
            auto label_4_5 = label_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(ArmPat(lx_1_5, or_(index(arms_2_5, i), dummy_arm()).pattern, sty_3_5, Holding(Holding::ByRef{}), prism_rtl::cat(label_4_5, "_", i)))));
            });
        }));
        });
    })));
    })));
    auto chain = fold(by_ref, false, [&](const bool& f, const PatOut& po) { return f || fold(po.conds, false, [&](const bool& f2, const crate::lower::model::Cc& c) { return f2 || is_let_cond(c); }); });
    auto owned = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<Vl::VlOwned>(sv)) {
            _v.set(!chain);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto pats = owned
        ? run_to_end(each_job(crate::check::errors::range0(len(arms)), ({
        auto lx_1 = lx;
        auto arms_2 = arms;
        auto sty_3 = sty;
        auto label_4 = label;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto lx_1_5 = lx_1;
            auto arms_2_5 = arms_2;
            auto sty_3_5 = sty_3;
            auto label_4_5 = label_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(ArmPat(lx_1_5, or_(index(arms_2_5, i), dummy_arm()).pattern, sty_3_5, Holding(Holding::Owned{}), prism_rtl::cat(label_4_5, "_", i)))));
            });
        }));
        });
    })));
    })))
        : by_ref;
    auto xarms = run_to_end(each_job(crate::check::errors::range0(len(arms)), ({
        auto arms_1 = arms;
        auto pats_2 = pats;
        auto env_3 = env;
        auto lx_4 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::XArm>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto arms_1_5 = arms_1;
            auto pats_2_5 = pats_2;
            auto env_3_5 = env_3;
            auto lx_4_5 = lx_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto arm = or_(index(arms_1_5, i), dummy_arm());
                auto po = or_(index(pats_2_5, i), PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array<std::tuple<Text, Bn>>{}});
                auto env2 = bind_all(env_3_5, po.binds);
                auto guard = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::lower::model::Cc>> _v;
                    auto&& _m = arm.guard;
                    if (prism_rtl::is_some(_m)) {
                        auto&& ge = prism_rtl::some_of(_m);
                        _v.set(Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{as_bool(value_of(lx_4_5, env2, ge))})}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Array<crate::lower::model::Cc>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                call_then(start_block_value(lx_4_5, env2, arm.body), [=](Vl block_value_81678) { return prism_rtl::finished(crate::lower::model::XArm{.pat = po.pa, .conds = append(po.conds, guard), .body = own(block_value_81678)}); });
            });
            });
        }));
        });
    })));
    })));
    auto scrut = owned ? own(sv) : ref_(sv);
    return arms_value(scrut, xarms, label, t);
}


prism_rtl::Turn<Vl> MatchValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& s = this->s;
    const auto& arms = this->arms;
    const auto& t = this->t;
    const auto& span = this->span;
    auto arms_1 = arms;
    auto env_2 = env;
    auto lx_3 = lx;
    auto s_4 = s;
    auto span_5 = span;
    auto t_6 = t;
    return call_then(start_value_of(lx_3, env_2, s_4), [=](Vl value_of_80763) {
        return ({
            auto sv = value_of_80763;
            auto sty = type_at(lx_3, s_4.span);
            auto label = prism_rtl::cat("m", span_5.start);
            call_value(each_job(crate::check::errors::range0(len(arms_1)), ({
            auto lx_3_7 = lx_3;
            auto arms_1_7 = arms_1;
            auto sty_7 = sty;
            auto label_8 = label;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto lx_3_7_9 = lx_3_7;
                auto arms_1_7_9 = arms_1_7;
                auto sty_7_9 = sty_7;
                auto label_8_9 = label_8;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    (prism_rtl::more(prism_rtl::rc(ArmPat(lx_3_7_9, or_(index(arms_1_7_9, i), dummy_arm()).pattern, sty_7_9, Holding(Holding::ByRef{}), prism_rtl::cat(label_8_9, "_", i)))));
                });
            }));
            });
        })));
        })), [=](Array<PatOut> each_80862) {
            return ({
                auto by_ref = each_80862;
                auto chain = fold(by_ref, false, [&](const bool& f, const PatOut& po) { return f || fold(po.conds, false, [&](const bool& f2, const crate::lower::model::Cc& c) { return f2 || is_let_cond(c); }); });
                auto owned = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    if (prism_rtl::is<Vl::VlOwned>(sv)) {
                        _v.set(!chain);
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto pats = owned
                    ? run_to_end(each_job(crate::check::errors::range0(len(arms_1)), ({
                    auto lx_3_7 = lx_3;
                    auto arms_1_7 = arms_1;
                    auto sty_7 = sty;
                    auto label_8 = label;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                    return ({
                        auto lx_3_7_9 = lx_3_7;
                        auto arms_1_7_9 = arms_1_7;
                        auto sty_7_9 = sty_7;
                        auto label_8_9 = label_8;
                        entered(once_job([=]() {
                        return ({
                            auto i = p0;
                            (prism_rtl::more(prism_rtl::rc(ArmPat(lx_3_7_9, or_(index(arms_1_7_9, i), dummy_arm()).pattern, sty_7_9, Holding(Holding::Owned{}), prism_rtl::cat(label_8_9, "_", i)))));
                        });
                    }));
                    });
                })));
                })))
                    : by_ref;
                call_value(each_job(crate::check::errors::range0(len(arms_1)), ({
                auto arms_1_7 = arms_1;
                auto pats_7 = pats;
                auto env_2_8 = env_2;
                auto lx_3_8 = lx_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::XArm>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                return ({
                    auto arms_1_7_8 = arms_1_7;
                    auto pats_7_8 = pats_7;
                    auto env_2_8_8 = env_2_8;
                    auto lx_3_8_8 = lx_3_8;
                    entered(once_job([=]() {
                    return ({
                        auto i = p0;
                        ({
                        auto arm = or_(index(arms_1_7_8, i), dummy_arm());
                        auto po = or_(index(pats_7_8, i), PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array<std::tuple<Text, Bn>>{}});
                        auto env2 = bind_all(env_2_8_8, po.binds);
                        auto guard = ({
                            __label__ _done;
                            prism_rtl::Slot<Array<crate::lower::model::Cc>> _v;
                            auto&& _m = arm.guard;
                            if (prism_rtl::is_some(_m)) {
                                auto&& ge = prism_rtl::some_of(_m);
                                _v.set(Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{as_bool(value_of(lx_3_8_8, env2, ge))})}));
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(Array<crate::lower::model::Cc>{});
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        });
                        call_then(start_block_value(lx_3_8_8, env2, arm.body), [=](Vl block_value_81678) { return prism_rtl::finished(crate::lower::model::XArm{.pat = po.pa, .conds = append(po.conds, guard), .body = own(block_value_81678)}); });
                    });
                    });
                }));
                });
            })));
            })), [=](Array<crate::lower::model::XArm> each_81308) {
                return ({
                    auto xarms = each_81308;
                    auto scrut = owned ? own(sv) : ref_(sv);
                    (prism_rtl::finished(arms_value(scrut, xarms, label, t_6)));
                });
            });
            });
        });
        });
    });
}


/// `Start MatchValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_match_value(Lx lx, Env env, crate::syntax::Expr s, Array<crate::syntax::Arm> arms, crate::lower::model::OutTy t, crate::syntax::Range span) {
    return prism_rtl::make_rc<MatchValue>(lx, env, s, arms, t, span);
}


/// let dummyArm
crate::syntax::Arm dummy_arm() {
    return crate::syntax::Arm{.pattern = std::optional<crate::syntax::Pattern_>{}, .guard = std::optional<crate::syntax::Expr>{}, .body = crate::syntax::Block{.stmts = Array<crate::syntax::Stmt>{}, .inline_ = true, .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}}, .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// ArmPat: unbounded fn Lx, ?Pattern, Ty, Holding, Text -> PatOut
PatOut arm_pat(const Lx& lx, const std::optional<crate::syntax::Pattern_>& opt1, const crate::check::types::Ty& ty, const Holding& mode, const Text& fresh) {
    if (prism_rtl::is_some(opt1)) {
        auto&& p_ = prism_rtl::some_of(opt1);
        return rust_pat(lx, p_, ty, mode, fresh);
    }
    if (prism_rtl::is_none(opt1)) {
        return PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array<std::tuple<Text, Bn>>{}};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<PatOut> ArmPat::cycle() const {
    const auto& lx = this->lx;
    const auto& opt1 = this->opt1;
    const auto& ty = this->ty;
    const auto& mode = this->mode;
    const auto& fresh = this->fresh;
    return ({
        prism_rtl::is_some(opt1) ? ({
        auto&& p_ = prism_rtl::some_of(opt1);
        prism_rtl::more(prism_rtl::rc(RustPat(lx, p_, ty, mode, fresh)));
    })
        : prism_rtl::is_none(opt1) ? prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array<std::tuple<Text, Bn>>{}})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ArmPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_arm_pat(Lx lx, std::optional<crate::syntax::Pattern_> opt1, crate::check::types::Ty ty, Holding mode, Text fresh) {
    return prism_rtl::make_rc<ArmPat>(lx, opt1, ty, mode, fresh);
}


/// BlockValue: unbounded fn Lx, Env, Block -> Vl
Vl block_value(const Lx& lx, const Env& env, const crate::syntax::Block& b) {
    return is_given_block(b.stmts)
        ? given_value(lx, env, b, block_ty(lx, b), b.span)
        : plain_block_value(lx, env, b);
}


prism_rtl::Turn<Vl> BlockValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& b = this->b;
    return is_given_block(b.stmts)
        ? ({
        auto b_1 = b;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(start_block_ty(lx_3, b_1), [=](crate::lower::model::OutTy block_ty_82405) { return prism_rtl::more(prism_rtl::rc(GivenValue(lx_3, env_2, b_1, block_ty_82405, b_1.span))); });
    })
        : prism_rtl::more(prism_rtl::rc(PlainBlockValue(lx, env, b)));
}


/// `Start BlockValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_block_value(Lx lx, Env env, crate::syntax::Block b) {
    return prism_rtl::make_rc<BlockValue>(lx, env, b);
}


/// IsGivenBlock: fn [Stmt] -> Bool
bool is_given_block(const Array<crate::syntax::Stmt>& stmts) {
    return fold(stmts, false, [&](const bool& f, const crate::syntax::Stmt& s) { return f || is_guardish(s); });
}


/// IsGuardish: fn Stmt -> Bool
bool is_guardish(const crate::syntax::Stmt& s) {
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SRequire>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SForbid>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// BlockTy: unbounded fn Lx, Block -> OutTy
crate::lower::model::OutTy block_ty(const Lx& lx, const crate::syntax::Block& b) {
    auto&& _m = or_(index(b.stmts, crate::syntax::lexer::dec(len(b.stmts))), dummy_stmt_l()).kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        return out_ty_of(lx, peel(type_at(lx, x.span)));
    }
    {
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{});
    }
}


prism_rtl::Turn<crate::lower::model::OutTy> BlockTy::cycle() const {
    const auto& lx = this->lx;
    const auto& b = this->b;
    return ({
        auto&& _m = or_(index(b.stmts, crate::syntax::lexer::dec(len(b.stmts))), dummy_stmt_l()).kind;
        prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        prism_rtl::more(prism_rtl::rc(OutTyOf(lx, peel(type_at(lx, x.span)))));
    })
        : prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
    });
}


/// `Start BlockTy, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::OutTy> start_block_ty(Lx lx, crate::syntax::Block b) {
    return prism_rtl::make_rc<BlockTy>(lx, b);
}


/// PlainBlockValue: unbounded fn Lx, Env, Block -> Vl
Vl plain_block_value(const Lx& lx, const Env& env, const crate::syntax::Block& b) {
    auto n = len(b.stmts);
    auto [dos, env2, last_opt] = run_to_end(fold_job(crate::check::errors::range0(n), std::tuple{Array<crate::lower::model::Do>{}, env, std::optional<Vl>{}}, ({
        auto b_1 = b;
        auto n_2 = n;
        auto lx_3 = lx;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, Env, std::optional<Vl>>>(std::tuple<std::tuple<Array<crate::lower::model::Do>, Env, std::optional<Vl>>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::lower::model::Do>, Env, std::optional<Vl>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto b_1_4 = b_1;
            auto n_2_4 = n_2;
            auto lx_3_4 = lx_3;
            entered(once_job([=]() {
            return ({
                auto [acc, en, lv_opt] = p0;
                auto i = p1;
                ({
                auto s = or_(index(b_1_4.stmts, i), dummy_stmt_l());
                (i + Nat(1u)) == n_2_4
                ? ({
                auto&& _m = s.kind;
                prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
                auto&& x = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                prism_rtl::finished(std::tuple{acc, en, std::optional(value_of(lx_3_4, en, x))});
            })
                : call_then(start_block_stmt(lx_3_4, en, s), [=](std::tuple<Array<crate::lower::model::Do>, Env> block_stmt_83447) {
                return ({
                    auto [more, en2] = block_stmt_83447;
                    (prism_rtl::finished(std::tuple{append(acc, more), en2, std::optional<Vl>{}}));
                });
            });
            })
                : call_then(start_block_stmt(lx_3_4, en, s), [=](std::tuple<Array<crate::lower::model::Do>, Env> block_stmt_83562) {
                return ({
                    auto [more, en2] = block_stmt_83562;
                    (prism_rtl::finished(std::tuple{append(acc, more), en2, lv_opt}));
                });
            });
            });
            });
        }));
        });
    }));
    })));
    auto last = or_(last_opt, Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}));
    return len(dos) == Nat(0u)
        ? last
        : Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos, prism_rtl::rc(own(last))}), value_ty(last)});
}


prism_rtl::Turn<Vl> PlainBlockValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& b = this->b;
    auto n = len(b.stmts);
    auto b_1 = b;
    auto env_2 = env;
    auto lx_3 = lx;
    return call_value(fold_job(crate::check::errors::range0(n), std::tuple{Array<crate::lower::model::Do>{}, env_2, std::optional<Vl>{}}, ({
        auto b_1_4 = b_1;
        auto n_4 = n;
        auto lx_3_5 = lx_3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, Env, std::optional<Vl>>>(std::tuple<std::tuple<Array<crate::lower::model::Do>, Env, std::optional<Vl>>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::lower::model::Do>, Env, std::optional<Vl>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto b_1_4_5 = b_1_4;
            auto n_4_5 = n_4;
            auto lx_3_5_5 = lx_3_5;
            entered(once_job([=]() {
            return ({
                auto [acc, en, lv_opt] = p0;
                auto i = p1;
                ({
                auto s = or_(index(b_1_4_5.stmts, i), dummy_stmt_l());
                (i + Nat(1u)) == n_4_5
                ? ({
                auto&& _m = s.kind;
                prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
                auto&& x = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                prism_rtl::finished(std::tuple{acc, en, std::optional(value_of(lx_3_5_5, en, x))});
            })
                : call_then(start_block_stmt(lx_3_5_5, en, s), [=](std::tuple<Array<crate::lower::model::Do>, Env> block_stmt_83447) {
                return ({
                    auto [more, en2] = block_stmt_83447;
                    (prism_rtl::finished(std::tuple{append(acc, more), en2, std::optional<Vl>{}}));
                });
            });
            })
                : call_then(start_block_stmt(lx_3_5_5, en, s), [=](std::tuple<Array<crate::lower::model::Do>, Env> block_stmt_83562) {
                return ({
                    auto [more, en2] = block_stmt_83562;
                    (prism_rtl::finished(std::tuple{append(acc, more), en2, lv_opt}));
                });
            });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<crate::lower::model::Do>, Env, std::optional<Vl>> fold_83193) {
        return ({
            auto [dos, env2, last_opt] = fold_83193;
            auto last = or_(last_opt, Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}));
            len(dos) == Nat(0u)
            ? prism_rtl::finished(last)
            : prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos, prism_rtl::rc(own(last))}), value_ty(last)}));
        });
    });
}


/// `Start PlainBlockValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_plain_block_value(Lx lx, Env env, crate::syntax::Block b) {
    return prism_rtl::make_rc<PlainBlockValue>(lx, env, b);
}


/// let dummyStmtL
crate::syntax::Stmt dummy_stmt_l() {
    return crate::syntax::Stmt{.kind = crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}}}), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// BlockStmt: unbounded fn Lx, Env, Stmt -> (([Do], Env))
std::tuple<Array<crate::lower::model::Do>, Env> block_stmt(const Lx& lx, const Env& env, const crate::syntax::Stmt& s) {
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& x = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        auto&& _m = p_.kind;
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            auto&& _m = crate::prelude::get(lx.gens, place_key(lx, n.span));
            if (prism_rtl::is_some(_m)) {
                auto&& gn = prism_rtl::some_of(_m);
                return generic_let(lx, env, n, gn, x);
            }
            if (prism_rtl::is_none(_m)) {
                return plain_let(lx, env, s, p_, x);
            }
            prism_rtl::unreachable("no arm matched");
        }
        {
            return plain_let(lx, env, s, p_, x);
        }
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        return std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{own(value_of(lx, env, x))})}), env};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m)) {
        return std::tuple{Array<crate::lower::model::Do>{}, env};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        auto&& f = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        return std::tuple{Array(std::vector{refusal_do(prism_rtl::cat("a local function ", crate::check::env::def_name_text(f.name), ": not lowered yet"))}), env};
    }
    {
        return std::tuple{Array(std::vector{refusal_do(Text::lit("a statement this back end does not lower yet"))}), env};
    }
}


prism_rtl::Turn<std::tuple<Array<crate::lower::model::Do>, Env>> BlockStmt::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& s = this->s;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& x = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        ({
        auto&& _m = p_.kind;
        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        ({
        auto&& _m = crate::prelude::get(lx.gens, place_key(lx, n.span));
        prism_rtl::is_some(_m) ? ({
        auto&& gn = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(GenericLet(lx, env, n, gn, x)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(PlainLet(lx, env, s, p_, x)))
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::more(prism_rtl::rc(PlainLet(lx, env, s, p_, x)));
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto x_3 = x;
        call_then(start_value_of(lx_2, env_1, x_3), [=](Vl value_of_84270) { return prism_rtl::finished(std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{own(value_of_84270)})}), env_1}); });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m) ? prism_rtl::finished(std::tuple{Array<crate::lower::model::Do>{}, env})
        : prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? ({
        auto&& f = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        prism_rtl::finished(std::tuple{Array(std::vector{refusal_do(prism_rtl::cat("a local function ", crate::check::env::def_name_text(f.name), ": not lowered yet"))}), env});
    })
        : prism_rtl::finished(std::tuple{Array(std::vector{refusal_do(Text::lit("a statement this back end does not lower yet"))}), env});
    });
}


/// `Start BlockStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, Env>> start_block_stmt(Lx lx, Env env, crate::syntax::Stmt s) {
    return prism_rtl::make_rc<BlockStmt>(lx, env, s);
}


/// GenericLet: unbounded fn Lx, Env, SName, GenNote, Expr -> (([Do], Env))
std::tuple<Array<crate::lower::model::Do>, Env> generic_let(const Lx& lx, const Env& env, const crate::syntax::SName& n, const crate::check::typed::GenNote& gn, const crate::syntax::Expr& x) {
    auto nkey = crate::check::env::sname_key(n);
    auto distinct = instantiations(lx, gn);
    auto one = len(distinct) == Nat(1u);
    auto rs = local_name(lx, nkey);
    return run_to_end(fold_job(crate::check::errors::range0(len(distinct)), std::tuple{Array<crate::lower::model::Do>{}, env}, ({
        auto distinct_1 = distinct;
        auto lx_2 = lx;
        auto one_3 = one;
        auto rs_4 = rs;
        auto nkey_5 = nkey;
        auto n_6 = n;
        auto env_7 = env;
        auto x_8 = x;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, Env>>(std::tuple<std::tuple<Array<crate::lower::model::Do>, Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::lower::model::Do>, Env>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto distinct_1_9 = distinct_1;
            auto lx_2_9 = lx_2;
            auto one_3_9 = one_3;
            auto rs_4_9 = rs_4;
            auto nkey_5_9 = nkey_5;
            auto n_6_9 = n_6;
            auto env_7_9 = env_7;
            auto x_8_9 = x_8;
            entered(once_job([=]() {
            return ({
                auto [dos, en] = p0;
                auto k = p1;
                ({
                auto [tys, cols] = or_(index(distinct_1_9, k), std::tuple{Array<std::tuple<Text, crate::check::types::Ty>>{}, Array<std::tuple<Text, crate::check::types::Col>>{}});
                auto lxk = at_instance(lx_2_9, std::tuple{tys, cols});
                auto rk = one_3_9 ? rs_4_9 : prism_rtl::cat(rs_4_9, "_", k);
                auto bkey = k == Nat(0u) ? nkey_5_9 : prism_rtl::cat(nkey_5_9, "#inst", k);
                call_then(start_out_ty_of(lxk, peel(binder_ty(lxk, n_6_9.span))), [=](crate::lower::model::OutTy out_ty_of_85432) {
                return ({
                    auto bt = out_ty_of_85432;
                    call_then(start_value_of(lxk, env_7_9, x_8_9), [=](Vl value_of_85491) {
                    return ({
                        auto v_ = value_of_85491;
                        auto en1 = bind(en, bkey, Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rk}), Holding(Holding::Owned{}), bt}));
                        auto en2 = ({
                            Env this_ = en1;
                            this_.uses = insert(this_.uses, prism_rtl::cat(nkey_5_9, "#", show_text(std::tuple{tys, cols})), bkey);
                            this_;
                        });
                        auto d = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{rk}), own(v_)});
                        (prism_rtl::finished(std::tuple{crate::prelude::push(dos, d), en2}));
                    });
                });
                });
            });
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Array<crate::lower::model::Do>, Env>> GenericLet::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& n = this->n;
    const auto& gn = this->gn;
    const auto& x = this->x;
    auto nkey = crate::check::env::sname_key(n);
    auto env_1 = env;
    auto gn_2 = gn;
    auto lx_3 = lx;
    auto n_4 = n;
    auto x_5 = x;
    return call_then(start_instantiations(lx_3, gn_2), [=](Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> instantiations_85051) {
        return ({
            auto distinct = instantiations_85051;
            auto one = len(distinct) == Nat(1u);
            auto rs = local_name(lx_3, nkey);
            fold_job(crate::check::errors::range0(len(distinct)), std::tuple{Array<crate::lower::model::Do>{}, env_1}, ({
            auto distinct_6 = distinct;
            auto lx_3_7 = lx_3;
            auto one_7 = one;
            auto rs_8 = rs;
            auto nkey_9 = nkey;
            auto n_4_10 = n_4;
            auto env_1_10 = env_1;
            auto x_5_10 = x_5;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, Env>>(std::tuple<std::tuple<Array<crate::lower::model::Do>, Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::lower::model::Do>, Env>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto distinct_6_10 = distinct_6;
                auto lx_3_7_10 = lx_3_7;
                auto one_7_10 = one_7;
                auto rs_8_10 = rs_8;
                auto nkey_9_10 = nkey_9;
                auto n_4_10_10 = n_4_10;
                auto env_1_10_10 = env_1_10;
                auto x_5_10_10 = x_5_10;
                entered(once_job([=]() {
                return ({
                    auto [dos, en] = p0;
                    auto k = p1;
                    ({
                    auto [tys, cols] = or_(index(distinct_6_10, k), std::tuple{Array<std::tuple<Text, crate::check::types::Ty>>{}, Array<std::tuple<Text, crate::check::types::Col>>{}});
                    auto lxk = at_instance(lx_3_7_10, std::tuple{tys, cols});
                    auto rk = one_7_10 ? rs_8_10 : prism_rtl::cat(rs_8_10, "_", k);
                    auto bkey = k == Nat(0u) ? nkey_9_10 : prism_rtl::cat(nkey_9_10, "#inst", k);
                    call_then(start_out_ty_of(lxk, peel(binder_ty(lxk, n_4_10_10.span))), [=](crate::lower::model::OutTy out_ty_of_85432) {
                    return ({
                        auto bt = out_ty_of_85432;
                        call_then(start_value_of(lxk, env_1_10_10, x_5_10_10), [=](Vl value_of_85491) {
                        return ({
                            auto v_ = value_of_85491;
                            auto en1 = bind(en, bkey, Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rk}), Holding(Holding::Owned{}), bt}));
                            auto en2 = ({
                                Env this_ = en1;
                                this_.uses = insert(this_.uses, prism_rtl::cat(nkey_9_10, "#", show_text(std::tuple{tys, cols})), bkey);
                                this_;
                            });
                            auto d = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{rk}), own(v_)});
                            (prism_rtl::finished(std::tuple{crate::prelude::push(dos, d), en2}));
                        });
                    });
                    });
                });
                });
                });
            }));
            });
        }));
        }))->cycle();
        });
    });
}


/// `Start GenericLet, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, Env>> start_generic_let(Lx lx, Env env, crate::syntax::SName n, crate::check::typed::GenNote gn, crate::syntax::Expr x) {
    return prism_rtl::make_rc<GenericLet>(lx, env, n, gn, x);
}


/// Instantiations: unbounded fn Lx, GenNote -> [(([((Text, Ty))], [((Text, Col))]))]
Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> instantiations(const Lx& lx, const crate::check::typed::GenNote& gn) {
    return run_to_end(fold_job(or_(crate::prelude::get(lx.insts, gen_key(gn)), Array<crate::check::typed::InstNote>{}), Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>{}, ({
        auto lx_1 = lx;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>(std::tuple<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>, crate::check::typed::InstNote>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>, crate::check::typed::InstNote> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto u = p1;
                call_then(start_expanded(lx_1_2, inst_at(lx_1_2, u)), [=](Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> expanded_86156) {
                return prism_rtl::finished(fold(expanded_86156, acc, [&](const Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>& a, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& i) {
                    return fold(a, false, [&](const bool& seen, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& j) { return seen || (show_text(j) == show_text(i)); })
                        ? a
                        : crate::prelude::push(a, i);
                }));
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> Instantiations::cycle() const {
    const auto& lx = this->lx;
    const auto& gn = this->gn;
    return fold_job(or_(crate::prelude::get(lx.insts, gen_key(gn)), Array<crate::check::typed::InstNote>{}), Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>{}, ({
        auto lx_1 = lx;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>(std::tuple<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>, crate::check::typed::InstNote>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>, crate::check::typed::InstNote> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto u = p1;
                call_then(start_expanded(lx_1_2, inst_at(lx_1_2, u)), [=](Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> expanded_86156) {
                return prism_rtl::finished(fold(expanded_86156, acc, [&](const Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>& a, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& i) {
                    return fold(a, false, [&](const bool& seen, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& j) { return seen || (show_text(j) == show_text(i)); })
                        ? a
                        : crate::prelude::push(a, i);
                }));
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start Instantiations, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> start_instantiations(Lx lx, crate::check::typed::GenNote gn) {
    return prism_rtl::make_rc<Instantiations>(lx, gn);
}


/// Expanded: unbounded fn Lx, (([((Text, Ty))], [((Text, Col))])) -> [(([((Text, Ty))], [((Text, Col))]))]
Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> expanded(const Lx& lx, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& i) {
    auto&& _m = open_q(lx, i);
    if (prism_rtl::is_none(_m)) {
        return Array(std::vector{i});
    }
    if (prism_rtl::is_some(_m)) {
        auto&& q = prism_rtl::some_of(_m);
        auto&& _m = crate::prelude::get(lx.gen_of_q, q);
        if (prism_rtl::is_some(_m)) {
            auto&& g = prism_rtl::some_of(_m);
            return run_to_end(fold_job(instantiations(lx, g), Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>{}, ({
                auto lx_1 = lx;
                auto i_2 = i;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>(std::tuple<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>, std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>, std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto lx_1_3 = lx_1;
                    auto i_2_3 = i_2;
                    entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto gi = p1;
                        ({
                        auto lx2 = at_instance(lx_1_3, gi);
                        call_then(start_expanded(lx2, subst_inst(lx2, i_2_3)), [=](Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> expanded_86589) { return prism_rtl::finished(append(acc, expanded_86589)); });
                    });
                    });
                }));
                });
            }));
            })));
        }
        if (prism_rtl::is_none(_m)) {
            return Array(std::vector{i});
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}

}  // namespace crate::lower
