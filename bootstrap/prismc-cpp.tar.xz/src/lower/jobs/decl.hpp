// The module `Lower.Jobs`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace lower::jobs {

struct Tail;

struct TailHere;

struct TailBlock;

struct TailFrom;

struct UpdTail;

struct UpdTailFrom;

struct StmtJob;

struct WhileJob;

struct StmtsThen;

struct IfJob;

struct MatchJob;

struct ForJob;

struct FrameCall;

struct FirstFrame;

struct Frame;

struct LocalJobFn;

struct TailBody;

struct TailMatch;

struct JobFieldNames;

struct JobDefOf;

struct JobClauses;

}  // namespace lower::jobs

}  // namespace crate
