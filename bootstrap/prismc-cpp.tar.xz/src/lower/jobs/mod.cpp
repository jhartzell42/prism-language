// The module `Lower.Jobs`, from `target/bootstrap/cpp-src/prismc/lower/jobs.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <lower/jobs/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate::lower::jobs {

/// Tail: unbounded fn Lx, Env, Expr -> Ex
crate::lower::model::Ex tail(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& e) {
    auto&& _m = frame_call(lx, env, e, true);
    if (prism_rtl::is_some(_m)) {
        auto&& c = prism_rtl::some_of(_m);
        return frame(lx, env, c, rest_text(lx, e.span, c.span, e.span), ({
            auto lx_1 = lx;
            auto e_2 = e;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::lower::types::Env)>>(prism_rtl::rc([=](crate::lower::types::Env p0) {
            return ({
                auto lx_1_3 = lx_1;
                auto e_2_3 = e_2;
                entered(once_job([=]() {
                return ({
                    auto env2 = p0;
                    (prism_rtl::more(prism_rtl::rc(Tail(lx_1_3, env2, e_2_3))));
                });
            }));
            });
        })));
        }));
    }
    if (prism_rtl::is_none(_m)) {
        return tail_here(lx, env, e);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::model::Ex> Tail::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    auto e_1 = e;
    auto env_2 = env;
    auto lx_3 = lx;
    return call_then(start_frame_call(lx_3, env_2, e_1, true), [=](std::optional<crate::syntax::Expr> frame_call_1854) {
        return ({
            prism_rtl::is_some(frame_call_1854) ? ({
            auto&& c = prism_rtl::some_of(frame_call_1854);
            prism_rtl::more(prism_rtl::rc(Frame(lx_3, env_2, c, rest_text(lx_3, e_1.span, c.span, e_1.span), ({
            auto lx_3_4 = lx_3;
            auto e_1_4 = e_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::lower::types::Env)>>(prism_rtl::rc([=](crate::lower::types::Env p0) {
            return ({
                auto lx_3_4_4 = lx_3_4;
                auto e_1_4_4 = e_1_4;
                entered(once_job([=]() {
                return ({
                    auto env2 = p0;
                    (prism_rtl::more(prism_rtl::rc(Tail(lx_3_4_4, env2, e_1_4_4))));
                });
            }));
            });
        })));
        }))));
        })
            : prism_rtl::is_none(frame_call_1854) ? prism_rtl::more(prism_rtl::rc(TailHere(lx_3, env_2, e_1)))
            : throw prism_rtl::Panic("no arm matched");
        });
    });
}


/// `Start Tail, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_tail(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e) {
    return prism_rtl::make_rc<Tail>(lx, env, e);
}


/// TailHere: unbounded fn Lx, Env, Expr -> Ex
crate::lower::model::Ex tail_here(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return tail(lx, env, x);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m)) {
        auto&& target = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
        return has_top_while(lx, b)
            ? upd_tail(lx, env, target, b, e.span, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<crate::lower::types::Env, crate::lower::model::Ex> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return once_job([=]() {
                return ({
                    auto en = p0;
                    auto v_ = p1;
                    (prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{v_})})));
                });
            });
        })))
            : crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{crate::lower::types::own(crate::lower::expr::value_of(lx, env, e))})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        return tail_match(lx, env, s, arms, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2)) {
        auto&& m2072_3_0 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
        if (prism_rtl::is<crate::syntax::Cond::CondExpr>(m2072_3_0)) {
            auto&& c = prism_rtl::as<crate::syntax::Cond::CondExpr>(m2072_3_0).a0;
            return crate::lower::model::Ex(crate::lower::model::Ex::XIf{prism_rtl::rc(crate::lower::types::as_bool(crate::lower::expr::value_of(lx, env, c))), prism_rtl::rc(tail_block(lx, env, then_b)), prism_rtl::rc(tail_block(lx, env, else_b))});
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& callee = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        auto&& _m = tail_callee(lx, env, callee);
        if (prism_rtl::is_some(_m)) {
            auto&& qk = prism_rtl::some_of(_m);
            auto job = or_(crate::prelude::get(lx.rs_names, qk), crate::lower::snake(crate::check::types::bare_name(qk)));
            auto job_name = crate::lower::path_in(lx, crate::lower::owner_of(qk), crate::lower::camel(crate::check::types::bare_name(qk)));
            auto&& _ptys = scheme_parts(lx, qk);
            auto&& ptys = std::get<0>(_ptys);
            auto fields = job_field_names(lx, qk);
            auto vals = crate::lower::expr::named_args_owned(lx, env, qk, args);
            return crate::lower::program::enters_at_once(lx, qk, args)
                ? crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::path_in(lx, crate::lower::owner_of(qk), prism_rtl::cat("start_", job)), vals})), Text::lit("cycle"), Array<crate::lower::model::Ex>{}})
                : crate::lower::program::is_color_poly(lx, qk)
                ? crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::More"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::path_in(lx, crate::lower::owner_of(qk), prism_rtl::cat("start_", job)), vals})})})
                : crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::More"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRecord{job_name, each(crate::check::errors::range0(len(vals)), [&](const Nat& i) { return std::tuple{or_(index(fields, i), Text::lit("arg")), or_(index(vals, i), crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}))}; })})})})})});
        }
        if (prism_rtl::is_none(_m)) {
            auto&& _m = local_job_fn(lx, env, callee);
            if (prism_rtl::is_some(_m)) {
                auto&& f = prism_rtl::some_of(_m);
                return crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(start_call(f, crate::lower::expr::start_args(lx, env, f, args))), Text::lit("cycle"), Array<crate::lower::model::Ex>{}});
            }
            if (prism_rtl::is_none(_m)) {
                auto&& _m = crate::lower::expr::prelude_job_call(lx, env, e);
                if (prism_rtl::is_some(_m)) {
                    auto&& job = prism_rtl::some_of(_m);
                    return crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(job), Text::lit("cycle"), Array<crate::lower::model::Ex>{}});
                }
                if (prism_rtl::is_none(_m)) {
                    return crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{crate::lower::types::own(crate::lower::expr::value_of(lx, env, e))})});
                }
                prism_rtl::unreachable("no arm matched");
            }
            prism_rtl::unreachable("no arm matched");
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        return crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{crate::lower::types::own(crate::lower::expr::value_of(lx, env, e))})});
    }
}


prism_rtl::Turn<crate::lower::model::Ex> TailHere::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(Tail(lx, env, x)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m) ? ({
        auto&& target = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
        has_top_while(lx, b)
        ? prism_rtl::more(prism_rtl::rc(UpdTail(lx, env, target, b, e.span, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<crate::lower::types::Env, crate::lower::model::Ex> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return once_job([=]() {
            return ({
                auto en = p0;
                auto v_ = p1;
                (prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{v_})})));
            });
        });
    })))))
        : ({
        auto e_1 = e;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(crate::lower::expr::start_value_of(lx_3, env_2, e_1), [=](crate::lower::types::Vl value_of_2311) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{crate::lower::types::own(value_of_2311)})})); });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
        auto&& s = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        prism_rtl::more(prism_rtl::rc(TailMatch(lx, env, s, arms, e.span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2) && ({
        auto&& m2072_3_0 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
        prism_rtl::is<crate::syntax::Cond::CondExpr>(m2072_3_0);
    }) ? ({
        auto&& m2072_3_0 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
        auto&& c = prism_rtl::as<crate::syntax::Cond::CondExpr>(m2072_3_0).a0;
        ({
        auto c_1 = c;
        auto else_b_2 = else_b;
        auto env_3 = env;
        auto lx_4 = lx;
        auto then_b_5 = then_b;
        call_then(crate::lower::expr::start_value_of(lx_4, env_3, c_1), [=](crate::lower::types::Vl value_of_2441) { return call_then(start_tail_block(lx_4, env_3, then_b_5), [=](crate::lower::model::Ex tail_block_2464) { return call_then(start_tail_block(lx_4, env_3, else_b_2), [=](crate::lower::model::Ex tail_block_2492) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XIf{prism_rtl::rc(crate::lower::types::as_bool(value_of_2441)), prism_rtl::rc(tail_block_2464), prism_rtl::rc(tail_block_2492)})); }); }); });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::ECall>(_m) ? ({
        auto&& callee = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        ({
        auto&& _m = tail_callee(lx, env, callee);
        prism_rtl::is_some(_m) ? ({
        auto&& qk = prism_rtl::some_of(_m);
        ({
        auto job = or_(crate::prelude::get(lx.rs_names, qk), crate::lower::snake(crate::check::types::bare_name(qk)));
        auto job_name = crate::lower::path_in(lx, crate::lower::owner_of(qk), crate::lower::camel(crate::check::types::bare_name(qk)));
        auto&& _ptys = scheme_parts(lx, qk);
        auto&& ptys = std::get<0>(_ptys);
        auto args_1 = args;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(start_job_field_names(lx_3, qk), [=](Array<Text> job_field_names_2822) {
        return ({
            auto fields = job_field_names_2822;
            call_then(crate::lower::expr::start_named_args_owned(lx_3, env_2, qk, args_1), [=](Array<crate::lower::model::Ex> named_args_owned_2866) {
            return ({
                auto vals = named_args_owned_2866;
                (crate::lower::program::enters_at_once(lx_3, qk, args_1)
                ? prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::path_in(lx_3, crate::lower::owner_of(qk), prism_rtl::cat("start_", job)), vals})), Text::lit("cycle"), Array<crate::lower::model::Ex>{}}))
                : crate::lower::program::is_color_poly(lx_3, qk)
                ? prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::More"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::path_in(lx_3, crate::lower::owner_of(qk), prism_rtl::cat("start_", job)), vals})})}))
                : prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::More"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRecord{job_name, each(crate::check::errors::range0(len(vals)), [&](const Nat& i) { return std::tuple{or_(index(fields, i), Text::lit("arg")), or_(index(vals, i), crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}))}; })})})})})})));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto args_1 = args;
        auto callee_2 = callee;
        auto e_3 = e;
        auto env_4 = env;
        auto lx_5 = lx;
        call_then(start_local_job_fn(lx_5, env_4, callee_2), [=](std::optional<crate::lower::types::Vl> local_job_fn_3346) {
        return ({
            prism_rtl::is_some(local_job_fn_3346) ? ({
            auto&& f = prism_rtl::some_of(local_job_fn_3346);
            call_then(crate::lower::expr::start_start_args(lx_5, env_4, f, args_1), [=](Array<crate::lower::model::Ex> start_args_3415) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(start_call(f, start_args_3415)), Text::lit("cycle"), Array<crate::lower::model::Ex>{}})); });
        })
            : prism_rtl::is_none(local_job_fn_3346) ? call_then(crate::lower::expr::start_prelude_job_call(lx_5, env_4, e_3), [=](std::optional<crate::lower::model::Ex> prelude_job_call_3482) {
            return ({
                prism_rtl::is_some(prelude_job_call_3482) ? ({
                auto&& job = prism_rtl::some_of(prelude_job_call_3482);
                prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(job), Text::lit("cycle"), Array<crate::lower::model::Ex>{}}));
            })
                : prism_rtl::is_none(prelude_job_call_3482) ? call_then(crate::lower::expr::start_value_of(lx_5, env_4, e_3), [=](crate::lower::types::Vl value_of_3623) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{crate::lower::types::own(value_of_3623)})})); })
                : throw prism_rtl::Panic("no arm matched");
            });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : ({
        auto e_1 = e;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(crate::lower::expr::start_value_of(lx_3, env_2, e_1), [=](crate::lower::types::Vl value_of_3702) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{crate::lower::types::own(value_of_3702)})})); });
    });
    });
}


/// `Start TailHere, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_tail_here(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e) {
    return prism_rtl::make_rc<TailHere>(lx, env, e);
}


/// TailBlock: unbounded fn Lx, Env, Block -> Ex
crate::lower::model::Ex tail_block(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Block& b) {
    return tail_from(lx, env, b, Nat(0u));
}


prism_rtl::Turn<crate::lower::model::Ex> TailBlock::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& b = this->b;
    return prism_rtl::more(prism_rtl::rc(TailFrom(lx, env, b, Nat(0u))));
}


/// `Start TailBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_tail_block(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Block b) {
    return prism_rtl::make_rc<TailBlock>(lx, env, b);
}


/// TailFrom: unbounded fn Lx, Env, Block, Nat -> Ex
crate::lower::model::Ex tail_from(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Block& b, const Nat& i) {
    auto s = or_(index(b.stmts, i), crate::lower::expr::dummy_stmt_l());
    return (i + Nat(1u)) >= len(b.stmts)
        ? ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Ex> _v;
        auto&& _m = s.kind;
        if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
            auto&& x = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
            _v.set(tail(lx, env, x));
            goto _done;
        }
        {
            _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})})}));
            goto _done;
        }
    _done:
        _v.take();
    })
        : ({
        auto found_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
            auto&& _m = s.kind;
            if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
                auto&& x = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
                _v.set(frame_call(lx, env, x, false));
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
                auto&& x = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                _v.set(frame_call(lx, env, x, false));
                goto _done;
            }
            {
                _v.set(std::optional<crate::syntax::Expr>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto looping_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<std::tuple<crate::syntax::Pattern_, crate::syntax::Expr, crate::syntax::Block, crate::syntax::Expr>>> _v;
            auto&& _m = s.kind;
            if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
                auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
                auto&& x = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<std::optional<std::tuple<crate::syntax::Pattern_, crate::syntax::Expr, crate::syntax::Block, crate::syntax::Expr>>> _v;
                    auto&& _m = x.kind;
                    if (prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m)) {
                        auto&& target = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
                        auto&& ub = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
                        _v.set(has_top_while(lx, ub)
                            ? std::optional(std::tuple{p_, target, ub, x})
                            : std::optional<std::tuple<crate::syntax::Pattern_, crate::syntax::Expr, crate::syntax::Block, crate::syntax::Expr>>{});
                        goto _done;
                    }
                    {
                        _v.set(std::optional<std::tuple<crate::syntax::Pattern_, crate::syntax::Expr, crate::syntax::Block, crate::syntax::Expr>>{});
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(std::optional<std::tuple<crate::syntax::Pattern_, crate::syntax::Expr, crate::syntax::Block, crate::syntax::Expr>>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Ex> _v;
        if (prism_rtl::is_some(looping_opt)) {
            auto&& p_ = std::get<0>(prism_rtl::some_of(looping_opt));
            auto&& target = std::get<1>(prism_rtl::some_of(looping_opt));
            auto&& ub = std::get<2>(prism_rtl::some_of(looping_opt));
            auto&& x = std::get<3>(prism_rtl::some_of(looping_opt));
            _v.set(upd_tail(lx, env, target, ub, b.span, ({
                auto lx_1 = lx;
                auto p__2 = p_;
                auto x_3 = x;
                auto s_4 = s;
                auto b_5 = b;
                auto i_6 = i;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<crate::lower::types::Env, crate::lower::model::Ex> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto lx_1_7 = lx_1;
                    auto p__2_7 = p__2;
                    auto x_3_7 = x_3;
                    auto s_4_7 = s_4;
                    auto b_5_7 = b_5;
                    auto i_6_7 = i_6;
                    entered(once_job([=]() {
                    return ({
                        auto en = p0;
                        auto v_ = p1;
                        call_then(crate::lower::patterns::start_rust_pat(lx_1_7, p__2_7, crate::lower::type_at(lx_1_7, x_3_7.span), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("l", s_4_7.span.start)), [=](crate::lower::patterns::PatOut rust_pat_4825) {
                        return ({
                            auto po = rust_pat_4825;
                            call_then(start_tail_from(lx_1_7, crate::lower::expr::bind_all(en, po.binds), b_5_7, i_6_7 + Nat(1u)), [=](crate::lower::model::Ex tail_from_4917) {
                            return ({
                                auto rest = tail_from_4917;
                                (prism_rtl::finished(prepend(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{po.pa, v_})}), rest)));
                            });
                        });
                        });
                    });
                    });
                }));
                });
            })));
            })));
            goto _done;
        }
        if (prism_rtl::is_none(looping_opt)) {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<crate::lower::model::Ex> _v;
                if (prism_rtl::is_some(found_opt)) {
                    auto&& c = prism_rtl::some_of(found_opt);
                    _v.set(frame(lx, env, c, rest_text(lx, s.span, c.span, b.span), ({
                        auto lx_1 = lx;
                        auto b_2 = b;
                        auto i_3 = i;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::lower::types::Env)>>(prism_rtl::rc([=](crate::lower::types::Env p0) {
                        return ({
                            auto lx_1_4 = lx_1;
                            auto b_2_4 = b_2;
                            auto i_3_4 = i_3;
                            entered(once_job([=]() {
                            return ({
                                auto env2 = p0;
                                (prism_rtl::more(prism_rtl::rc(TailFrom(lx_1_4, env2, b_2_4, i_3_4))));
                            });
                        }));
                        });
                    })));
                    })));
                    goto _done;
                }
                if (prism_rtl::is_none(found_opt)) {
                    _v.set(({
                        auto [dos, env2] = crate::lower::expr::block_stmt(lx, env, s);
                        ({
                        __label__ _done;
                        prism_rtl::Slot<crate::lower::model::Ex> _v;
                        auto&& _m = tail_from(lx, env2, b, i + Nat(1u));
                        if (prism_rtl::is<crate::lower::model::Ex::XBlock>(_m)) {
                            auto&& more = prism_rtl::as<crate::lower::model::Ex::XBlock>(_m).a0;
                            auto&& last = prism_rtl::as<crate::lower::model::Ex::XBlock>(_m).a1;
                            _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XBlock{append(dos, more), prism_rtl::rc(last)}));
                            goto _done;
                        }
                        {
                            auto&& last = _m;
                            _v.set(len(dos) == Nat(0u)
                                ? last
                                : crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos, prism_rtl::rc(last)}));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    });
}


prism_rtl::Turn<crate::lower::model::Ex> TailFrom::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& b = this->b;
    const auto& i = this->i;
    auto s = or_(index(b.stmts, i), crate::lower::expr::dummy_stmt_l());
    return (i + Nat(1u)) >= len(b.stmts)
        ? ({
        auto&& _m = s.kind;
        prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        prism_rtl::more(prism_rtl::rc(Tail(lx, env, x)));
    })
        : prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})})}));
    })
        : ({
        auto found_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
            auto&& _m = s.kind;
            if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
                auto&& x = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
                _v.set(frame_call(lx, env, x, false));
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
                auto&& x = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                _v.set(frame_call(lx, env, x, false));
                goto _done;
            }
            {
                _v.set(std::optional<crate::syntax::Expr>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto looping_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<std::tuple<crate::syntax::Pattern_, crate::syntax::Expr, crate::syntax::Block, crate::syntax::Expr>>> _v;
            auto&& _m = s.kind;
            if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
                auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
                auto&& x = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<std::optional<std::tuple<crate::syntax::Pattern_, crate::syntax::Expr, crate::syntax::Block, crate::syntax::Expr>>> _v;
                    auto&& _m = x.kind;
                    if (prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m)) {
                        auto&& target = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
                        auto&& ub = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
                        _v.set(has_top_while(lx, ub)
                            ? std::optional(std::tuple{p_, target, ub, x})
                            : std::optional<std::tuple<crate::syntax::Pattern_, crate::syntax::Expr, crate::syntax::Block, crate::syntax::Expr>>{});
                        goto _done;
                    }
                    {
                        _v.set(std::optional<std::tuple<crate::syntax::Pattern_, crate::syntax::Expr, crate::syntax::Block, crate::syntax::Expr>>{});
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(std::optional<std::tuple<crate::syntax::Pattern_, crate::syntax::Expr, crate::syntax::Block, crate::syntax::Expr>>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        ({
        prism_rtl::is_some(looping_opt) ? ({
        auto&& p_ = std::get<0>(prism_rtl::some_of(looping_opt));
        auto&& target = std::get<1>(prism_rtl::some_of(looping_opt));
        auto&& ub = std::get<2>(prism_rtl::some_of(looping_opt));
        auto&& x = std::get<3>(prism_rtl::some_of(looping_opt));
        prism_rtl::more(prism_rtl::rc(UpdTail(lx, env, target, ub, b.span, ({
        auto lx_1 = lx;
        auto p__2 = p_;
        auto x_3 = x;
        auto s_4 = s;
        auto b_5 = b;
        auto i_6 = i;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<crate::lower::types::Env, crate::lower::model::Ex> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_7 = lx_1;
            auto p__2_7 = p__2;
            auto x_3_7 = x_3;
            auto s_4_7 = s_4;
            auto b_5_7 = b_5;
            auto i_6_7 = i_6;
            entered(once_job([=]() {
            return ({
                auto en = p0;
                auto v_ = p1;
                call_then(crate::lower::patterns::start_rust_pat(lx_1_7, p__2_7, crate::lower::type_at(lx_1_7, x_3_7.span), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("l", s_4_7.span.start)), [=](crate::lower::patterns::PatOut rust_pat_4825) {
                return ({
                    auto po = rust_pat_4825;
                    call_then(start_tail_from(lx_1_7, crate::lower::expr::bind_all(en, po.binds), b_5_7, i_6_7 + Nat(1u)), [=](crate::lower::model::Ex tail_from_4917) {
                    return ({
                        auto rest = tail_from_4917;
                        (prism_rtl::finished(prepend(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{po.pa, v_})}), rest)));
                    });
                });
                });
            });
            });
        }));
        });
    })));
    }))));
    })
        : prism_rtl::is_none(looping_opt) ? ({
        prism_rtl::is_some(found_opt) ? ({
        auto&& c = prism_rtl::some_of(found_opt);
        prism_rtl::more(prism_rtl::rc(Frame(lx, env, c, rest_text(lx, s.span, c.span, b.span), ({
        auto lx_1 = lx;
        auto b_2 = b;
        auto i_3 = i;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::lower::types::Env)>>(prism_rtl::rc([=](crate::lower::types::Env p0) {
        return ({
            auto lx_1_4 = lx_1;
            auto b_2_4 = b_2;
            auto i_3_4 = i_3;
            entered(once_job([=]() {
            return ({
                auto env2 = p0;
                (prism_rtl::more(prism_rtl::rc(TailFrom(lx_1_4, env2, b_2_4, i_3_4))));
            });
        }));
        });
    })));
    }))));
    })
        : prism_rtl::is_none(found_opt) ? ({
        auto b_1 = b;
        auto env_2 = env;
        auto i_3 = i;
        auto lx_4 = lx;
        call_then(crate::lower::expr::start_block_stmt(lx_4, env_2, s), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> block_stmt_5220) {
        return ({
            auto [dos, env2] = block_stmt_5220;
            call_then(start_tail_from(lx_4, env2, b_1, i_3 + Nat(1u)), [=](crate::lower::model::Ex tail_from_5267) {
            return ({
                prism_rtl::is<crate::lower::model::Ex::XBlock>(tail_from_5267) ? ({
                auto&& more = prism_rtl::as<crate::lower::model::Ex::XBlock>(tail_from_5267).a0;
                auto&& last = prism_rtl::as<crate::lower::model::Ex::XBlock>(tail_from_5267).a1;
                prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XBlock{append(dos, more), prism_rtl::rc(last)}));
            })
                : ({
                auto&& last = tail_from_5267;
                len(dos) == Nat(0u)
                ? prism_rtl::finished(last)
                : prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos, prism_rtl::rc(last)}));
            });
            });
        });
        });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    });
}


/// `Start TailFrom, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_tail_from(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Block b, Nat i) {
    return prism_rtl::make_rc<TailFrom>(lx, env, b, i);
}


/// HasTopWhile: fn Lx, Block -> Bool
bool has_top_while(const crate::lower::Lx& lx, const crate::syntax::Block& b) {
    return fold(b.stmts, false, [&](const bool& f, const crate::syntax::Stmt& st) { return (f || is_cycle_while(lx, st)) || holds_cycle_while(lx, st); });
}


/// IsCycleWhile: fn Lx, Stmt -> Bool
bool is_cycle_while(const crate::lower::Lx& lx, const crate::syntax::Stmt& st) {
    auto&& _m = st.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m)) {
        return crate::check::env::has_key(lx.unshrunk, crate::lower::place_key(lx, st.span));
    }
    {
        return false;
    }
}


/// ElseHasTopWhile: fn Lx, ?Block -> Bool
bool else_has_top_while(const crate::lower::Lx& lx, const std::optional<crate::syntax::Block>& opt1) {
    if (prism_rtl::is_some(opt1)) {
        auto&& b = prism_rtl::some_of(opt1);
        return has_top_while(lx, b);
    }
    if (prism_rtl::is_none(opt1)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// HoldsCycleWhile: fn Lx, Stmt -> Bool
bool holds_cycle_while(const crate::lower::Lx& lx, const crate::syntax::Stmt& st) {
    auto&& _m = st.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m)) {
        auto&& wb = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
        return has_top_while(lx, wb);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        auto&& _m = x.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
            auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
            auto&& else_b_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
            return has_top_while(lx, then_b) || else_has_top_while(lx, else_b_opt);
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
            auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
            return fold(arms, false, [&](const bool& f, const crate::syntax::Arm& a) { return f || has_top_while(lx, a.body); });
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EFor>(_m)) {
            auto&& fb = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
            return has_top_while(lx, fb);
        }
        {
            return false;
        }
    }
    {
        return false;
    }
}


/// UpdTail: unbounded fn Lx, Env, Expr, Block, Range, (unbounded fn Env, Ex -> Ex) -> Ex
crate::lower::model::Ex upd_tail(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& target, const crate::syntax::Block& b, const crate::syntax::Range& to, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)>& cont_fn) {
    auto t = crate::lower::types::out_ty_of(lx, crate::lower::types::peel(crate::lower::type_at(lx, target.span)));
    auto tv = crate::lower::expr::value_of(lx, env, target);
    auto env1 = crate::lower::types::bind(env, Text::lit("&_"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("this")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t}));
    return prepend(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("this")})), t}), crate::lower::types::own(tv)})}), upd_tail_from(lx, env, env1, b, Nat(0u), to, cont_fn));
}


prism_rtl::Turn<crate::lower::model::Ex> UpdTail::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& target = this->target;
    const auto& b = this->b;
    const auto& to = this->to;
    const auto& cont_fn = this->cont_fn;
    auto cont_fn_1 = cont_fn;
    auto b_2 = b;
    auto env_3 = env;
    auto lx_4 = lx;
    auto target_5 = target;
    auto to_6 = to;
    return call_then(crate::lower::types::start_out_ty_of(lx_4, crate::lower::types::peel(crate::lower::type_at(lx_4, target_5.span))), [=](crate::lower::model::OutTy out_ty_of_7825) {
        return ({
            auto t = out_ty_of_7825;
            call_then(crate::lower::expr::start_value_of(lx_4, env_3, target_5), [=](crate::lower::types::Vl value_of_7882) {
            return ({
                auto tv = value_of_7882;
                auto env1 = crate::lower::types::bind(env_3, Text::lit("&_"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("this")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t}));
                call_then(start_upd_tail_from(lx_4, env_3, env1, b_2, Nat(0u), to_6, cont_fn_1), [=](crate::lower::model::Ex upd_tail_from_8035) { return prism_rtl::finished(prepend(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("this")})), t}), crate::lower::types::own(tv)})}), upd_tail_from_8035)); });
            });
        });
        });
    });
}


/// `Start UpdTail, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_upd_tail(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr target, crate::syntax::Block b, crate::syntax::Range to, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)> cont_fn) {
    return prism_rtl::make_rc<UpdTail>(lx, env, target, b, to, cont_fn);
}


/// UpdTailFrom: unbounded fn Lx, Env, Env, Block, Nat, Range, (unbounded fn Env, Ex -> Ex) -> Ex
crate::lower::model::Ex upd_tail_from(const crate::lower::Lx& lx, const crate::lower::types::Env& outer, const crate::lower::types::Env& env, const crate::syntax::Block& b, const Nat& i, const crate::syntax::Range& to, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)>& cont_fn) {
    return i >= len(b.stmts)
        ? run_to_end(cont_fn(std::tuple{outer, crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("this")})}))
        : ({
        auto s = or_(index(b.stmts, i), crate::lower::expr::dummy_stmt_l());
        auto rest = rest_text(lx, crate::syntax::Range{.start = s.span.end, .end = s.span.end}, crate::syntax::Range{.start = s.span.end, .end = s.span.end}, to);
        auto next_fn = ({
            auto lx_1 = lx;
            auto b_2 = b;
            auto i_3 = i;
            auto to_4 = to;
            auto cont_fn_5 = cont_fn;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)>>(prism_rtl::rc([=](std::tuple<crate::lower::types::Env, crate::lower::types::Env> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_1_6 = lx_1;
                auto b_2_6 = b_2;
                auto i_3_6 = i_3;
                auto to_4_6 = to_4;
                auto cont_fn_5_6 = cont_fn_5;
                entered(once_job([=]() {
                return ({
                    auto o2 = p0;
                    auto e2 = p1;
                    (prism_rtl::more(prism_rtl::rc(UpdTailFrom(lx_1_6, o2, e2, b_2_6, i_3_6 + Nat(1u), to_4_6, cont_fn_5_6))));
                });
            }));
            });
        })));
        });
        is_cycle_while(lx, s) || holds_cycle_while(lx, s)
        ? stmt_job(lx, outer, env, s, rest, next_fn)
        : ({
        auto [dos, env2] = crate::lower::templates::upd_stmt(lx, env, s);
        prepend(dos, upd_tail_from(lx, outer, env2, b, i + Nat(1u), to, cont_fn));
    });
    });
}


prism_rtl::Turn<crate::lower::model::Ex> UpdTailFrom::cycle() const {
    const auto& lx = this->lx;
    const auto& outer = this->outer;
    const auto& env = this->env;
    const auto& b = this->b;
    const auto& i = this->i;
    const auto& to = this->to;
    const auto& cont_fn = this->cont_fn;
    return i >= len(b.stmts)
        ? cont_fn(std::tuple{outer, crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("this")})})->cycle()
        : ({
        auto s = or_(index(b.stmts, i), crate::lower::expr::dummy_stmt_l());
        auto rest = rest_text(lx, crate::syntax::Range{.start = s.span.end, .end = s.span.end}, crate::syntax::Range{.start = s.span.end, .end = s.span.end}, to);
        auto next_fn = ({
            auto lx_1 = lx;
            auto b_2 = b;
            auto i_3 = i;
            auto to_4 = to;
            auto cont_fn_5 = cont_fn;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)>>(prism_rtl::rc([=](std::tuple<crate::lower::types::Env, crate::lower::types::Env> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_1_6 = lx_1;
                auto b_2_6 = b_2;
                auto i_3_6 = i_3;
                auto to_4_6 = to_4;
                auto cont_fn_5_6 = cont_fn_5;
                entered(once_job([=]() {
                return ({
                    auto o2 = p0;
                    auto e2 = p1;
                    (prism_rtl::more(prism_rtl::rc(UpdTailFrom(lx_1_6, o2, e2, b_2_6, i_3_6 + Nat(1u), to_4_6, cont_fn_5_6))));
                });
            }));
            });
        })));
        });
        is_cycle_while(lx, s) || holds_cycle_while(lx, s)
        ? prism_rtl::more(prism_rtl::rc(StmtJob(lx, outer, env, s, rest, next_fn)))
        : ({
        auto cont_fn_1 = cont_fn;
        auto b_2 = b;
        auto env_3 = env;
        auto i_4 = i;
        auto lx_5 = lx;
        auto outer_6 = outer;
        auto to_7 = to;
        call_then(crate::lower::templates::start_upd_stmt(lx_5, env_3, s), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmt_8662) {
        return ({
            auto [dos, env2] = upd_stmt_8662;
            call_then(start_upd_tail_from(lx_5, outer_6, env2, b_2, i_4 + Nat(1u), to_7, cont_fn_1), [=](crate::lower::model::Ex upd_tail_from_8707) { return prism_rtl::finished(prepend(dos, upd_tail_from_8707)); });
        });
    });
    });
    });
}


/// `Start UpdTailFrom, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_upd_tail_from(crate::lower::Lx lx, crate::lower::types::Env outer, crate::lower::types::Env env, crate::syntax::Block b, Nat i, crate::syntax::Range to, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)> cont_fn) {
    return prism_rtl::make_rc<UpdTailFrom>(lx, outer, env, b, i, to, cont_fn);
}


/// StmtJob: unbounded fn Lx, Env, Env, Stmt, Text, (unbounded fn Env, Env -> Ex) -> Ex
crate::lower::model::Ex stmt_job(const crate::lower::Lx& lx, const crate::lower::types::Env& outer, const crate::lower::types::Env& env, const crate::syntax::Stmt& s, const Text& rest, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)>& cont_fn) {
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
        auto&& wb = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
        return while_job(lx, outer, env, c, wb, s.span, rest, cont_fn);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        auto&& _m = x.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
            auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
            auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
            auto&& else_b_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
            return if_job(lx, outer, env, c, then_b, else_b_opt, s.span, rest, cont_fn);
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
            auto&& scrut = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
            auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
            return match_job(lx, outer, env, scrut, arms, s.span, rest, cont_fn);
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EFor>(_m)) {
            auto&& binders_opt = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
            auto&& source = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
            auto&& body = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
            auto&& _m = crate::lower::templates::ref_binder(binders_opt);
            if (prism_rtl::is_some(_m)) {
                return crate::lower::expr::refusal(Text::lit("a cycle-point `while` in a `for &` of an `update` block, whose references a job cannot keep (gap LP)"));
            }
            if (prism_rtl::is_none(_m)) {
                return for_job(lx, outer, env, binders_opt, source, body, s.span, rest, cont_fn);
            }
            prism_rtl::unreachable("no arm matched");
        }
        {
            return crate::lower::expr::refusal(prism_rtl::cat("a cycle-point `while` in ", crate::lower::expr::kind_words(x.kind), " (gap LP)"));
        }
    }
    {
        return crate::lower::expr::refusal(Text::lit("a cycle-point `while` in this statement (gap LP)"));
    }
}


prism_rtl::Turn<crate::lower::model::Ex> StmtJob::cycle() const {
    const auto& lx = this->lx;
    const auto& outer = this->outer;
    const auto& env = this->env;
    const auto& s = this->s;
    const auto& rest = this->rest;
    const auto& cont_fn = this->cont_fn;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
        auto&& wb = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
        prism_rtl::more(prism_rtl::rc(WhileJob(lx, outer, env, c, wb, s.span, rest, cont_fn)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        ({
        auto&& _m = x.kind;
        prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        prism_rtl::more(prism_rtl::rc(IfJob(lx, outer, env, c, then_b, else_b_opt, s.span, rest, cont_fn)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
        auto&& scrut = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        prism_rtl::more(prism_rtl::rc(MatchJob(lx, outer, env, scrut, arms, s.span, rest, cont_fn)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EFor>(_m) ? ({
        auto&& binders_opt = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
        auto&& source = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
        ({
        auto&& _m = crate::lower::templates::ref_binder(binders_opt);
        prism_rtl::is_some(_m) ? prism_rtl::finished(crate::lower::expr::refusal(Text::lit("a cycle-point `while` in a `for &` of an `update` block, whose references a job cannot keep (gap LP)")))
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(ForJob(lx, outer, env, binders_opt, source, body, s.span, rest, cont_fn)))
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::finished(crate::lower::expr::refusal(prism_rtl::cat("a cycle-point `while` in ", crate::lower::expr::kind_words(x.kind), " (gap LP)")));
    });
    })
        : prism_rtl::finished(crate::lower::expr::refusal(Text::lit("a cycle-point `while` in this statement (gap LP)")));
    });
}


/// `Start StmtJob, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_stmt_job(crate::lower::Lx lx, crate::lower::types::Env outer, crate::lower::types::Env env, crate::syntax::Stmt s, Text rest, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)> cont_fn) {
    return prism_rtl::make_rc<StmtJob>(lx, outer, env, s, rest, cont_fn);
}


/// Prepend: fn [Do], Ex -> Ex
crate::lower::model::Ex prepend(const Array<crate::lower::model::Do>& dos, const crate::lower::model::Ex& ex1) {
    if (prism_rtl::is<crate::lower::model::Ex::XBlock>(ex1)) {
        auto&& more = prism_rtl::as<crate::lower::model::Ex::XBlock>(ex1).a0;
        auto&& last = prism_rtl::as<crate::lower::model::Ex::XBlock>(ex1).a1;
        return crate::lower::model::Ex(crate::lower::model::Ex::XBlock{append(dos, more), prism_rtl::rc(last)});
    }
    {
        auto&& x = ex1;
        return len(dos) == Nat(0u)
            ? x
            : crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos, prism_rtl::rc(x)});
    }
}


/// WhileJob: unbounded fn Lx, Env, Env, Cond, Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
crate::lower::model::Ex while_job(const crate::lower::Lx& lx, const crate::lower::types::Env& outer, const crate::lower::types::Env& env, const crate::syntax::Cond& c, const crate::syntax::Block& wb, const crate::syntax::Range& span, const Text& rest_text_, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)>& cont_fn) {
    auto state = fold(keys(env->names), Array<std::tuple<Text, Text, crate::lower::model::OutTy>>{}, [&](const Array<std::tuple<Text, Text, crate::lower::model::OutTy>>& acc, const Text& k) {
        return !crate::syntax::lexer::chars::has_prefix(k, Text::lit("&"))
            ? acc
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, Text, crate::lower::model::OutTy>>> _v;
            auto&& _m = crate::prelude::get(env->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& bt = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(crate::prelude::push(acc, std::tuple{k, crate::lower::types::place_stem(rs), bt}));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto names = each(state, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        return rs;
    });
    auto st_ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{each(state, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& bt = std::get<2>(_p0);
        return bt;
    })});
    auto pat = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(names, [&](const Text& n) { return crate::lower::model::Pa(crate::lower::model::Pa::PaMut{prism_rtl::cat(n)}); })});
    auto pack = crate::lower::model::Ex(crate::lower::model::Ex::XTuple{each(names, [&](const Text& n) { return crate::lower::model::Ex(crate::lower::model::Ex::XVar{n}); })});
    auto env_s = fold(state, env, [&](const crate::lower::types::Env& en, const std::tuple<Text, Text, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<2>(_p1);
        return crate::lower::types::bind(en, k, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt}));
    });
    auto loop_text = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(lx.g.srcs, lx->file);
        if (prism_rtl::is_some(_m)) {
            auto&& src = prism_rtl::some_of(_m);
            _v.set(crate::check::errors::span_text(src, span));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto caps = caps_in(env_s, loop_text, names);
    auto cap_dos = each(caps, [&](const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        auto&& mode = std::get<2>(_p0);
        auto&& bt = std::get<3>(_p0);
        return crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{crate::lower::types::place_stem(rs)}), crate::lower::types::own(crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{rs, mode, bt}))});
    });
    auto env_c = fold(caps, env_s, [&](const crate::lower::types::Env& en, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return crate::lower::types::bind(en, k, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::types::place_stem(rs)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt}));
    });
    auto jobs = has_top_while(lx, wb);
    auto finish_fn = ({
        auto jobs_1 = jobs;
        (prism_rtl::rc([=](const crate::lower::model::Ex& x) {
        return jobs_1
            ? crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{x})})
            : x;
    }));
    });
    auto step_ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Result"), Array(std::vector{st_ty, st_ty})});
    auto again = finish_fn(crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Ok"), Array(std::vector{pack})})), step_ty}));
    auto stop = finish_fn(crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{pack})})), step_ty}));
    auto body_fn = ({
        auto jobs_1 = jobs;
        auto lx_2 = lx;
        auto wb_3 = wb;
        auto again_4 = again;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::lower::types::Env)>>(prism_rtl::rc([=](crate::lower::types::Env p0) {
        return ({
            auto jobs_1_5 = jobs_1;
            auto lx_2_5 = lx_2;
            auto wb_3_5 = wb_3;
            auto again_4_5 = again_4;
            entered(once_job([=]() {
            return ({
                auto en = p0;
                jobs_1_5
                ? prism_rtl::more(prism_rtl::rc(UpdTailFrom(lx_2_5, en, en, wb_3_5, Nat(0u), wb_3_5.span, ({
                auto again_4_5_5 = again_4_5;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<crate::lower::types::Env, crate::lower::model::Ex> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto again_4_5_5_5 = again_4_5_5;
                    once_job([=]() {
                    return ({
                        auto o2 = p0;
                        auto e2 = p1;
                        (prism_rtl::finished(again_4_5_5_5));
                    });
                });
                });
            })));
            }))))
                : prism_rtl::more(prism_rtl::rc(StmtsThen(lx_2_5, en, wb_3_5, again_4_5)));
            });
        }));
        });
    })));
    });
    auto res_ty = jobs
        ? crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("prism_rtl::Turn"), Array(std::vector{step_ty})})
        : st_ty;
    auto turn = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Ex> _v;
        if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c)) {
            auto&& x = prism_rtl::as<crate::syntax::Cond::CondExpr>(c).a0;
            _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XIf{prism_rtl::rc(crate::lower::types::as_bool(crate::lower::expr::value_of(lx, env_c, x))), prism_rtl::rc(run_to_end(body_fn(env_c))), prism_rtl::rc(stop)}));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::Cond::CondBind>(c)) {
            auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a0;
            auto&& x = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a1;
            auto&& g_opt = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a2;
            _v.set(({
                auto po = crate::lower::patterns::rust_pat(lx, p_, crate::lower::type_at(lx, x.span), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("w", span.start));
                auto env_b = crate::lower::expr::bind_all(env_c, po.binds);
                auto conds = append(po.conds, crate::lower::templates::guard_conds(lx, env_b, g_opt));
                (crate::lower::types::own(crate::lower::expr::arms_value(crate::lower::types::own(crate::lower::expr::value_of(lx, env_c, x)), Array(std::vector{crate::lower::model::XArm{.pat = po.pa, .conds = conds, .body = run_to_end(body_fn(env_b))}, crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .body = stop}}), prism_rtl::cat("\'w", span.start), res_ty)));
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto out_caps = caps_in(outer, rest_text_, names);
    auto out_dos = each(out_caps, [&](const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        auto&& mode = std::get<2>(_p0);
        auto&& bt = std::get<3>(_p0);
        return crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{crate::lower::types::place_stem(rs)}), crate::lower::types::own(crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{rs, mode, bt}))});
    });
    auto outer2 = fold(out_caps, outer, [&](const crate::lower::types::Env& en, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return crate::lower::types::bind(en, k, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::types::place_stem(rs)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt}));
    });
    auto env2 = fold(out_caps, env_s, [&](const crate::lower::types::Env& en, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return crate::lower::types::bind(en, k, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::types::place_stem(rs)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt}));
    });
    auto step_fn = prepend(cap_dos, crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(pat), st_ty})}), prism_rtl::rc(turn)}));
    auto looping = jobs ? Text::lit("loop_turns") : Text::lit("loop_job");
    auto enter = crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("call_then"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{looping, Array(std::vector{pack, step_fn})}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(pat), st_ty})}), prism_rtl::rc(run_to_end(cont_fn(std::tuple{outer2, env2})))})})});
    return prepend(out_dos, enter);
}


prism_rtl::Turn<crate::lower::model::Ex> WhileJob::cycle() const {
    const auto& lx = this->lx;
    const auto& outer = this->outer;
    const auto& env = this->env;
    const auto& c = this->c;
    const auto& wb = this->wb;
    const auto& span = this->span;
    const auto& rest_text_ = this->rest_text_;
    const auto& cont_fn = this->cont_fn;
    auto state = fold(keys(env->names), Array<std::tuple<Text, Text, crate::lower::model::OutTy>>{}, [&](const Array<std::tuple<Text, Text, crate::lower::model::OutTy>>& acc, const Text& k) {
        return !crate::syntax::lexer::chars::has_prefix(k, Text::lit("&"))
            ? acc
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, Text, crate::lower::model::OutTy>>> _v;
            auto&& _m = crate::prelude::get(env->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& bt = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(crate::prelude::push(acc, std::tuple{k, crate::lower::types::place_stem(rs), bt}));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto names = each(state, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        return rs;
    });
    auto st_ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{each(state, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& bt = std::get<2>(_p0);
        return bt;
    })});
    auto pat = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(names, [&](const Text& n) { return crate::lower::model::Pa(crate::lower::model::Pa::PaMut{prism_rtl::cat(n)}); })});
    auto pack = crate::lower::model::Ex(crate::lower::model::Ex::XTuple{each(names, [&](const Text& n) { return crate::lower::model::Ex(crate::lower::model::Ex::XVar{n}); })});
    auto env_s = fold(state, env, [&](const crate::lower::types::Env& en, const std::tuple<Text, Text, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<2>(_p1);
        return crate::lower::types::bind(en, k, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt}));
    });
    auto loop_text = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(lx.g.srcs, lx->file);
        if (prism_rtl::is_some(_m)) {
            auto&& src = prism_rtl::some_of(_m);
            _v.set(crate::check::errors::span_text(src, span));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto caps = caps_in(env_s, loop_text, names);
    auto cap_dos = each(caps, [&](const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        auto&& mode = std::get<2>(_p0);
        auto&& bt = std::get<3>(_p0);
        return crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{crate::lower::types::place_stem(rs)}), crate::lower::types::own(crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{rs, mode, bt}))});
    });
    auto env_c = fold(caps, env_s, [&](const crate::lower::types::Env& en, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return crate::lower::types::bind(en, k, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::types::place_stem(rs)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt}));
    });
    auto jobs = has_top_while(lx, wb);
    auto finish_fn = ({
        auto jobs_1 = jobs;
        (prism_rtl::rc([=](const crate::lower::model::Ex& x) {
        return jobs_1
            ? crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{x})})
            : x;
    }));
    });
    auto step_ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Result"), Array(std::vector{st_ty, st_ty})});
    auto again = finish_fn(crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Ok"), Array(std::vector{pack})})), step_ty}));
    auto stop = finish_fn(crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{pack})})), step_ty}));
    auto body_fn = ({
        auto jobs_1 = jobs;
        auto lx_2 = lx;
        auto wb_3 = wb;
        auto again_4 = again;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::lower::types::Env)>>(prism_rtl::rc([=](crate::lower::types::Env p0) {
        return ({
            auto jobs_1_5 = jobs_1;
            auto lx_2_5 = lx_2;
            auto wb_3_5 = wb_3;
            auto again_4_5 = again_4;
            entered(once_job([=]() {
            return ({
                auto en = p0;
                jobs_1_5
                ? prism_rtl::more(prism_rtl::rc(UpdTailFrom(lx_2_5, en, en, wb_3_5, Nat(0u), wb_3_5.span, ({
                auto again_4_5_5 = again_4_5;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<crate::lower::types::Env, crate::lower::model::Ex> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto again_4_5_5_5 = again_4_5_5;
                    once_job([=]() {
                    return ({
                        auto o2 = p0;
                        auto e2 = p1;
                        (prism_rtl::finished(again_4_5_5_5));
                    });
                });
                });
            })));
            }))))
                : prism_rtl::more(prism_rtl::rc(StmtsThen(lx_2_5, en, wb_3_5, again_4_5)));
            });
        }));
        });
    })));
    });
    auto res_ty = jobs
        ? crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("prism_rtl::Turn"), Array(std::vector{step_ty})})
        : st_ty;
    auto turn = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Ex> _v;
        if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c)) {
            auto&& x = prism_rtl::as<crate::syntax::Cond::CondExpr>(c).a0;
            _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XIf{prism_rtl::rc(crate::lower::types::as_bool(crate::lower::expr::value_of(lx, env_c, x))), prism_rtl::rc(run_to_end(body_fn(env_c))), prism_rtl::rc(stop)}));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::Cond::CondBind>(c)) {
            auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a0;
            auto&& x = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a1;
            auto&& g_opt = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a2;
            _v.set(({
                auto po = crate::lower::patterns::rust_pat(lx, p_, crate::lower::type_at(lx, x.span), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("w", span.start));
                auto env_b = crate::lower::expr::bind_all(env_c, po.binds);
                auto conds = append(po.conds, crate::lower::templates::guard_conds(lx, env_b, g_opt));
                (crate::lower::types::own(crate::lower::expr::arms_value(crate::lower::types::own(crate::lower::expr::value_of(lx, env_c, x)), Array(std::vector{crate::lower::model::XArm{.pat = po.pa, .conds = conds, .body = run_to_end(body_fn(env_b))}, crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .body = stop}}), prism_rtl::cat("\'w", span.start), res_ty)));
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto out_caps = caps_in(outer, rest_text_, names);
    auto out_dos = each(out_caps, [&](const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        auto&& mode = std::get<2>(_p0);
        auto&& bt = std::get<3>(_p0);
        return crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{crate::lower::types::place_stem(rs)}), crate::lower::types::own(crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{rs, mode, bt}))});
    });
    auto outer2 = fold(out_caps, outer, [&](const crate::lower::types::Env& en, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return crate::lower::types::bind(en, k, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::types::place_stem(rs)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt}));
    });
    auto env2 = fold(out_caps, env_s, [&](const crate::lower::types::Env& en, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return crate::lower::types::bind(en, k, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::types::place_stem(rs)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt}));
    });
    auto step_fn = prepend(cap_dos, crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(pat), st_ty})}), prism_rtl::rc(turn)}));
    auto looping = jobs ? Text::lit("loop_turns") : Text::lit("loop_job");
    auto cont_fn_1 = cont_fn;
    return call_value(cont_fn_1(std::tuple{outer2, env2}), [=](crate::lower::model::Ex cont_13212) {
        return ({
            auto enter = crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("call_then"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{looping, Array(std::vector{pack, step_fn})}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(pat), st_ty})}), prism_rtl::rc(cont_13212)})})});
            (prism_rtl::finished(prepend(out_dos, enter)));
        });
    });
}


/// `Start WhileJob, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_while_job(crate::lower::Lx lx, crate::lower::types::Env outer, crate::lower::types::Env env, crate::syntax::Cond c, crate::syntax::Block wb, crate::syntax::Range span, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)> cont_fn) {
    return prism_rtl::make_rc<WhileJob>(lx, outer, env, c, wb, span, rest_text_, cont_fn);
}


/// StmtsThen: unbounded fn Lx, Env, Block, Ex -> Ex
crate::lower::model::Ex stmts_then(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Block& b, const crate::lower::model::Ex& last) {
    auto&& _dos = crate::lower::templates::upd_stmts(lx, env, b.stmts);
    auto&& dos = std::get<0>(_dos);
    return crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos, prism_rtl::rc(last)});
}


prism_rtl::Turn<crate::lower::model::Ex> StmtsThen::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& b = this->b;
    const auto& last = this->last;
    auto b_1 = b;
    auto env_2 = env;
    auto last_3 = last;
    auto lx_4 = lx;
    return call_then(crate::lower::templates::start_upd_stmts(lx_4, env_2, b_1.stmts), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmts_13425) {
        return ({
            auto&& _dos = upd_stmts_13425;
            auto&& dos = std::get<0>(_dos);
            (prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos, prism_rtl::rc(last_3)})));
        });
    });
}


/// `Start StmtsThen, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_stmts_then(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Block b, crate::lower::model::Ex last) {
    return prism_rtl::make_rc<StmtsThen>(lx, env, b, last);
}


/// IfJob: unbounded fn Lx, Env, Env, Cond, Block, ?Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
crate::lower::model::Ex if_job(const crate::lower::Lx& lx, const crate::lower::types::Env& outer, const crate::lower::types::Env& env, const crate::syntax::Cond& c, const crate::syntax::Block& then_b, const std::optional<crate::syntax::Block>& else_b_opt, const crate::syntax::Range& span, const Text& rest_text_, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)>& cont_fn) {
    auto state = fold(keys(env->names), Array<std::tuple<Text, Text, crate::lower::model::OutTy>>{}, [&](const Array<std::tuple<Text, Text, crate::lower::model::OutTy>>& acc, const Text& k) {
        return !crate::syntax::lexer::chars::has_prefix(k, Text::lit("&"))
            ? acc
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, Text, crate::lower::model::OutTy>>> _v;
            auto&& _m = crate::prelude::get(env->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& bt = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(crate::prelude::push(acc, std::tuple{k, crate::lower::types::place_stem(rs), bt}));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto names = each(state, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        return rs;
    });
    auto st_ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{each(state, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& bt = std::get<2>(_p0);
        return bt;
    })});
    auto pat = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(names, [&](const Text& n) { return crate::lower::model::Pa(crate::lower::model::Pa::PaMut{prism_rtl::cat(n)}); })});
    auto pack = crate::lower::model::Ex(crate::lower::model::Ex::XTuple{each(names, [&](const Text& n) { return crate::lower::model::Ex(crate::lower::model::Ex::XVar{n}); })});
    auto env_s = fold(state, env, [&](const crate::lower::types::Env& en, const std::tuple<Text, Text, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<2>(_p1);
        return crate::lower::types::bind(en, k, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt}));
    });
    auto out_caps = caps_in(outer, rest_text_, names);
    auto out_dos = each(out_caps, [&](const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        auto&& mode = std::get<2>(_p0);
        auto&& bt = std::get<3>(_p0);
        return crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{crate::lower::types::place_stem(rs)}), crate::lower::types::own(crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{rs, mode, bt}))});
    });
    auto outer2 = fold(out_caps, outer, [&](const crate::lower::types::Env& en, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return crate::lower::types::bind(en, k, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::types::place_stem(rs)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt}));
    });
    auto env2 = fold(out_caps, env_s, [&](const crate::lower::types::Env& en, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return crate::lower::types::bind(en, k, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::types::place_stem(rs)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt}));
    });
    auto k_name = prism_rtl::cat("k_if", span.start);
    auto k_do = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{k_name}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(pat), st_ty})}), prism_rtl::rc(run_to_end(cont_fn(std::tuple{outer2, env2})))})});
    auto to_k_fn = ({
        auto k_name_1 = k_name;
        auto pack_2 = pack;
        (prism_rtl::rc([=](const crate::lower::types::Env& o2, const crate::lower::model::Ex& e2) { return crate::lower::model::Ex(crate::lower::model::Ex::XCall{k_name_1, Array(std::vector{pack_2})}); }));
    });
    auto branch_fn = ({
        auto lx_1 = lx;
        auto env_2 = env;
        auto to_k_fn_3 = to_k_fn;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Block)>>(prism_rtl::rc([=](crate::syntax::Block p0) {
        return ({
            auto lx_1_4 = lx_1;
            auto env_2_4 = env_2;
            auto to_k_fn_3_4 = to_k_fn_3;
            entered(once_job([=]() {
            return ({
                auto b = p0;
                (prism_rtl::more(prism_rtl::rc(UpdTailFrom(lx_1_4, env_2_4, env_2_4, b, Nat(0u), b.span, ({
                auto f = to_k_fn_3_4;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<crate::lower::types::Env, crate::lower::model::Ex> _p0) {
                auto&& a0 = std::get<0>(_p0);
                auto&& a1 = std::get<1>(_p0);
                return ({
                    auto f_4 = f;
                    once_job([=]() { return prism_rtl::finished(f_4(a0, a1)); });
                });
            })));
            })))));
            });
        }));
        });
    })));
    });
    auto else_x = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Ex> _v;
        if (prism_rtl::is_some(else_b_opt)) {
            auto&& eb = prism_rtl::some_of(else_b_opt);
            _v.set(run_to_end(branch_fn(eb)));
            goto _done;
        }
        if (prism_rtl::is_none(else_b_opt)) {
            _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XCall{k_name, Array(std::vector{pack})}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto choose = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Ex> _v;
        if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c)) {
            auto&& x = prism_rtl::as<crate::syntax::Cond::CondExpr>(c).a0;
            _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XIf{prism_rtl::rc(crate::lower::types::as_bool(crate::lower::expr::value_of(lx, env, x))), prism_rtl::rc(run_to_end(branch_fn(then_b))), prism_rtl::rc(else_x)}));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::Cond::CondBind>(c)) {
            auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a0;
            auto&& x = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a1;
            _v.set(({
                auto po = crate::lower::patterns::rust_pat(lx, p_, crate::lower::type_at(lx, x.span), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("u", x.span.start));
                auto then_x = upd_tail_from(lx, crate::lower::expr::bind_all(env, po.binds), crate::lower::expr::bind_all(env, po.binds), then_b, Nat(0u), then_b.span, ({
                    auto f = to_k_fn;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<crate::lower::types::Env, crate::lower::model::Ex> _p0) {
                    auto&& a0 = std::get<0>(_p0);
                    auto&& a1 = std::get<1>(_p0);
                    return ({
                        auto f_1 = f;
                        once_job([=]() { return prism_rtl::finished(f_1(a0, a1)); });
                    });
                })));
                }));
                (crate::lower::types::own(crate::lower::expr::arms_value(crate::lower::types::own(crate::lower::expr::value_of(lx, env, x)), Array(std::vector{crate::lower::model::XArm{.pat = po.pa, .conds = po.conds, .body = then_x}, crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .body = else_x}}), prism_rtl::cat("\'u", x.span.start), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{Text::lit("the job\'s turn")}))));
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return prepend(crate::prelude::push(out_dos, k_do), choose);
}


prism_rtl::Turn<crate::lower::model::Ex> IfJob::cycle() const {
    const auto& lx = this->lx;
    const auto& outer = this->outer;
    const auto& env = this->env;
    const auto& c = this->c;
    const auto& then_b = this->then_b;
    const auto& else_b_opt = this->else_b_opt;
    const auto& span = this->span;
    const auto& rest_text_ = this->rest_text_;
    const auto& cont_fn = this->cont_fn;
    auto state = fold(keys(env->names), Array<std::tuple<Text, Text, crate::lower::model::OutTy>>{}, [&](const Array<std::tuple<Text, Text, crate::lower::model::OutTy>>& acc, const Text& k) {
        return !crate::syntax::lexer::chars::has_prefix(k, Text::lit("&"))
            ? acc
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, Text, crate::lower::model::OutTy>>> _v;
            auto&& _m = crate::prelude::get(env->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& bt = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(crate::prelude::push(acc, std::tuple{k, crate::lower::types::place_stem(rs), bt}));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto names = each(state, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        return rs;
    });
    auto st_ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{each(state, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& bt = std::get<2>(_p0);
        return bt;
    })});
    auto pat = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(names, [&](const Text& n) { return crate::lower::model::Pa(crate::lower::model::Pa::PaMut{prism_rtl::cat(n)}); })});
    auto pack = crate::lower::model::Ex(crate::lower::model::Ex::XTuple{each(names, [&](const Text& n) { return crate::lower::model::Ex(crate::lower::model::Ex::XVar{n}); })});
    auto env_s = fold(state, env, [&](const crate::lower::types::Env& en, const std::tuple<Text, Text, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<2>(_p1);
        return crate::lower::types::bind(en, k, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt}));
    });
    auto out_caps = caps_in(outer, rest_text_, names);
    auto out_dos = each(out_caps, [&](const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        auto&& mode = std::get<2>(_p0);
        auto&& bt = std::get<3>(_p0);
        return crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{crate::lower::types::place_stem(rs)}), crate::lower::types::own(crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{rs, mode, bt}))});
    });
    auto outer2 = fold(out_caps, outer, [&](const crate::lower::types::Env& en, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return crate::lower::types::bind(en, k, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::types::place_stem(rs)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt}));
    });
    auto env2 = fold(out_caps, env_s, [&](const crate::lower::types::Env& en, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return crate::lower::types::bind(en, k, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::types::place_stem(rs)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt}));
    });
    auto k_name = prism_rtl::cat("k_if", span.start);
    auto else_b_opt_1 = else_b_opt;
    auto cont_fn_2 = cont_fn;
    auto c_3 = c;
    auto env_4 = env;
    auto lx_5 = lx;
    auto span_6 = span;
    auto then_b_7 = then_b;
    return call_value(cont_fn_2(std::tuple{outer2, env2}), [=](crate::lower::model::Ex cont_15137) {
        return ({
            auto k_do = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{k_name}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(pat), st_ty})}), prism_rtl::rc(cont_15137)})});
            auto to_k_fn = ({
                auto k_name_8 = k_name;
                auto pack_9 = pack;
                (prism_rtl::rc([=](const crate::lower::types::Env& o2, const crate::lower::model::Ex& e2) { return crate::lower::model::Ex(crate::lower::model::Ex::XCall{k_name_8, Array(std::vector{pack_9})}); }));
            });
            auto branch_fn = ({
                auto lx_5_8 = lx_5;
                auto env_4_8 = env_4;
                auto to_k_fn_8 = to_k_fn;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Block)>>(prism_rtl::rc([=](crate::syntax::Block p0) {
                return ({
                    auto lx_5_8_9 = lx_5_8;
                    auto env_4_8_9 = env_4_8;
                    auto to_k_fn_8_9 = to_k_fn_8;
                    entered(once_job([=]() {
                    return ({
                        auto b = p0;
                        (prism_rtl::more(prism_rtl::rc(UpdTailFrom(lx_5_8_9, env_4_8_9, env_4_8_9, b, Nat(0u), b.span, ({
                        auto f = to_k_fn_8_9;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<crate::lower::types::Env, crate::lower::model::Ex> _p0) {
                        auto&& a0 = std::get<0>(_p0);
                        auto&& a1 = std::get<1>(_p0);
                        return ({
                            auto f_9 = f;
                            once_job([=]() { return prism_rtl::finished(f_9(a0, a1)); });
                        });
                    })));
                    })))));
                    });
                }));
                });
            })));
            });
            auto else_x = ({
                __label__ _done;
                prism_rtl::Slot<crate::lower::model::Ex> _v;
                if (prism_rtl::is_some(else_b_opt)) {
                    auto&& eb = prism_rtl::some_of(else_b_opt);
                    _v.set(run_to_end(branch_fn(eb)));
                    goto _done;
                }
                if (prism_rtl::is_none(else_b_opt)) {
                    _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XCall{k_name, Array(std::vector{pack})}));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto choose = ({
                __label__ _done;
                prism_rtl::Slot<crate::lower::model::Ex> _v;
                if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c)) {
                    auto&& x = prism_rtl::as<crate::syntax::Cond::CondExpr>(c).a0;
                    _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XIf{prism_rtl::rc(crate::lower::types::as_bool(crate::lower::expr::value_of(lx_5, env_4, x))), prism_rtl::rc(run_to_end(branch_fn(then_b_7))), prism_rtl::rc(else_x)}));
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::Cond::CondBind>(c)) {
                    auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a0;
                    auto&& x = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a1;
                    _v.set(({
                        auto po = crate::lower::patterns::rust_pat(lx_5, p_, crate::lower::type_at(lx_5, x.span), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("u", x.span.start));
                        auto then_x = upd_tail_from(lx_5, crate::lower::expr::bind_all(env_4, po.binds), crate::lower::expr::bind_all(env_4, po.binds), then_b_7, Nat(0u), then_b_7.span, ({
                            auto f = to_k_fn;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<crate::lower::types::Env, crate::lower::model::Ex> _p0) {
                            auto&& a0 = std::get<0>(_p0);
                            auto&& a1 = std::get<1>(_p0);
                            return ({
                                auto f_8 = f;
                                once_job([=]() { return prism_rtl::finished(f_8(a0, a1)); });
                            });
                        })));
                        }));
                        (crate::lower::types::own(crate::lower::expr::arms_value(crate::lower::types::own(crate::lower::expr::value_of(lx_5, env_4, x)), Array(std::vector{crate::lower::model::XArm{.pat = po.pa, .conds = po.conds, .body = then_x}, crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .body = else_x}}), prism_rtl::cat("\'u", x.span.start), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{Text::lit("the job\'s turn")}))));
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (prism_rtl::finished(prepend(crate::prelude::push(out_dos, k_do), choose)));
        });
    });
}


/// `Start IfJob, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_if_job(crate::lower::Lx lx, crate::lower::types::Env outer, crate::lower::types::Env env, crate::syntax::Cond c, crate::syntax::Block then_b, std::optional<crate::syntax::Block> else_b_opt, crate::syntax::Range span, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)> cont_fn) {
    return prism_rtl::make_rc<IfJob>(lx, outer, env, c, then_b, else_b_opt, span, rest_text_, cont_fn);
}


/// MatchJob: unbounded fn Lx, Env, Env, Expr, [Arm], Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
crate::lower::model::Ex match_job(const crate::lower::Lx& lx, const crate::lower::types::Env& outer, const crate::lower::types::Env& env, const crate::syntax::Expr& scrut, const Array<crate::syntax::Arm>& arms, const crate::syntax::Range& span, const Text& rest_text_, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)>& cont_fn) {
    auto state = fold(keys(env->names), Array<std::tuple<Text, Text, crate::lower::model::OutTy>>{}, [&](const Array<std::tuple<Text, Text, crate::lower::model::OutTy>>& acc, const Text& k) {
        return !crate::syntax::lexer::chars::has_prefix(k, Text::lit("&"))
            ? acc
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, Text, crate::lower::model::OutTy>>> _v;
            auto&& _m = crate::prelude::get(env->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& bt = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(crate::prelude::push(acc, std::tuple{k, crate::lower::types::place_stem(rs), bt}));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto names = each(state, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        return rs;
    });
    auto st_ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{each(state, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& bt = std::get<2>(_p0);
        return bt;
    })});
    auto pat = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(names, [&](const Text& n) { return crate::lower::model::Pa(crate::lower::model::Pa::PaMut{prism_rtl::cat(n)}); })});
    auto pack = crate::lower::model::Ex(crate::lower::model::Ex::XTuple{each(names, [&](const Text& n) { return crate::lower::model::Ex(crate::lower::model::Ex::XVar{n}); })});
    auto env_s = fold(state, env, [&](const crate::lower::types::Env& en, const std::tuple<Text, Text, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<2>(_p1);
        return crate::lower::types::bind(en, k, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt}));
    });
    auto out_caps = caps_in(outer, rest_text_, names);
    auto out_dos = each(out_caps, [&](const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        auto&& mode = std::get<2>(_p0);
        auto&& bt = std::get<3>(_p0);
        return crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{crate::lower::types::place_stem(rs)}), crate::lower::types::own(crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{rs, mode, bt}))});
    });
    auto outer2 = fold(out_caps, outer, [&](const crate::lower::types::Env& en, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return crate::lower::types::bind(en, k, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::types::place_stem(rs)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt}));
    });
    auto env2 = fold(out_caps, env_s, [&](const crate::lower::types::Env& en, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return crate::lower::types::bind(en, k, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::types::place_stem(rs)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt}));
    });
    auto k_name = prism_rtl::cat("k_match", span.start);
    auto k_do = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{k_name}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(pat), st_ty})}), prism_rtl::rc(run_to_end(cont_fn(std::tuple{outer2, env2})))})});
    auto to_k_fn = ({
        auto k_name_1 = k_name;
        auto pack_2 = pack;
        (prism_rtl::rc([=](const crate::lower::types::Env& o2, const crate::lower::model::Ex& e2) { return crate::lower::model::Ex(crate::lower::model::Ex::XCall{k_name_1, Array(std::vector{pack_2})}); }));
    });
    auto sty = crate::lower::type_at(lx, scrut.span);
    auto xarms = run_to_end(each_job(crate::check::errors::range0(len(arms)), ({
        auto arms_1 = arms;
        auto lx_2 = lx;
        auto sty_3 = sty;
        auto scrut_4 = scrut;
        auto env_5 = env;
        auto to_k_fn_6 = to_k_fn;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::XArm>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto arms_1_7 = arms_1;
            auto lx_2_7 = lx_2;
            auto sty_3_7 = sty_3;
            auto scrut_4_7 = scrut_4;
            auto env_5_7 = env_5;
            auto to_k_fn_6_7 = to_k_fn_6;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto arm = or_(index(arms_1_7, i), crate::lower::expr::dummy_arm());
                call_then(crate::lower::expr::start_arm_pat(lx_2_7, arm.pattern, sty_3_7, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("u", scrut_4_7.span.start, "_", i)), [=](crate::lower::patterns::PatOut arm_pat_17704) {
                return ({
                    auto po = arm_pat_17704;
                    auto env_a = crate::lower::expr::bind_all(env_5_7, po.binds);
                    call_then(crate::lower::templates::start_guard_conds(lx_2_7, env_a, arm.guard), [=](Array<crate::lower::model::Cc> guard_conds_17848) {
                    return ({
                        auto guarded = append(po.conds, guard_conds_17848);
                        call_then(start_upd_tail_from(lx_2_7, env_a, env_a, arm.body, Nat(0u), arm.body.span, ({
                        auto f = to_k_fn_6_7;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<crate::lower::types::Env, crate::lower::model::Ex> _p0) {
                        auto&& a0 = std::get<0>(_p0);
                        auto&& a1 = std::get<1>(_p0);
                        return ({
                            auto f_7 = f;
                            once_job([=]() { return prism_rtl::finished(f_7(a0, a1)); });
                        });
                    })));
                    })), [=](crate::lower::model::Ex upd_tail_from_17926) { return prism_rtl::finished(crate::lower::model::XArm{.pat = po.pa, .conds = guarded, .body = upd_tail_from_17926}); });
                    });
                });
                });
            });
            });
            });
        }));
        });
    })));
    })));
    return prepend(crate::prelude::push(out_dos, k_do), crate::lower::types::own(crate::lower::expr::arms_value(crate::lower::types::own(crate::lower::expr::value_of(lx, env, scrut)), xarms, prism_rtl::cat("\'u", scrut.span.start), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{Text::lit("the job\'s turn")}))));
}


prism_rtl::Turn<crate::lower::model::Ex> MatchJob::cycle() const {
    const auto& lx = this->lx;
    const auto& outer = this->outer;
    const auto& env = this->env;
    const auto& scrut = this->scrut;
    const auto& arms = this->arms;
    const auto& span = this->span;
    const auto& rest_text_ = this->rest_text_;
    const auto& cont_fn = this->cont_fn;
    auto state = fold(keys(env->names), Array<std::tuple<Text, Text, crate::lower::model::OutTy>>{}, [&](const Array<std::tuple<Text, Text, crate::lower::model::OutTy>>& acc, const Text& k) {
        return !crate::syntax::lexer::chars::has_prefix(k, Text::lit("&"))
            ? acc
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, Text, crate::lower::model::OutTy>>> _v;
            auto&& _m = crate::prelude::get(env->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& bt = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(crate::prelude::push(acc, std::tuple{k, crate::lower::types::place_stem(rs), bt}));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto names = each(state, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        return rs;
    });
    auto st_ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{each(state, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& bt = std::get<2>(_p0);
        return bt;
    })});
    auto pat = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(names, [&](const Text& n) { return crate::lower::model::Pa(crate::lower::model::Pa::PaMut{prism_rtl::cat(n)}); })});
    auto pack = crate::lower::model::Ex(crate::lower::model::Ex::XTuple{each(names, [&](const Text& n) { return crate::lower::model::Ex(crate::lower::model::Ex::XVar{n}); })});
    auto env_s = fold(state, env, [&](const crate::lower::types::Env& en, const std::tuple<Text, Text, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<2>(_p1);
        return crate::lower::types::bind(en, k, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt}));
    });
    auto out_caps = caps_in(outer, rest_text_, names);
    auto out_dos = each(out_caps, [&](const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        auto&& mode = std::get<2>(_p0);
        auto&& bt = std::get<3>(_p0);
        return crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{crate::lower::types::place_stem(rs)}), crate::lower::types::own(crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{rs, mode, bt}))});
    });
    auto outer2 = fold(out_caps, outer, [&](const crate::lower::types::Env& en, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return crate::lower::types::bind(en, k, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::types::place_stem(rs)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt}));
    });
    auto env2 = fold(out_caps, env_s, [&](const crate::lower::types::Env& en, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return crate::lower::types::bind(en, k, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::types::place_stem(rs)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt}));
    });
    auto k_name = prism_rtl::cat("k_match", span.start);
    auto cont_fn_1 = cont_fn;
    auto arms_2 = arms;
    auto env_3 = env;
    auto lx_4 = lx;
    auto scrut_5 = scrut;
    auto span_6 = span;
    return call_value(cont_fn_1(std::tuple{outer2, env2}), [=](crate::lower::model::Ex cont_17499) {
        return ({
            auto k_do = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{k_name}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(pat), st_ty})}), prism_rtl::rc(cont_17499)})});
            auto to_k_fn = ({
                auto k_name_7 = k_name;
                auto pack_8 = pack;
                (prism_rtl::rc([=](const crate::lower::types::Env& o2, const crate::lower::model::Ex& e2) { return crate::lower::model::Ex(crate::lower::model::Ex::XCall{k_name_7, Array(std::vector{pack_8})}); }));
            });
            auto sty = crate::lower::type_at(lx_4, scrut_5.span);
            call_value(each_job(crate::check::errors::range0(len(arms_2)), ({
            auto arms_2_7 = arms_2;
            auto lx_4_7 = lx_4;
            auto sty_7 = sty;
            auto scrut_5_8 = scrut_5;
            auto env_3_8 = env_3;
            auto to_k_fn_8 = to_k_fn;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::XArm>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto arms_2_7_9 = arms_2_7;
                auto lx_4_7_9 = lx_4_7;
                auto sty_7_9 = sty_7;
                auto scrut_5_8_9 = scrut_5_8;
                auto env_3_8_9 = env_3_8;
                auto to_k_fn_8_9 = to_k_fn_8;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    ({
                    auto arm = or_(index(arms_2_7_9, i), crate::lower::expr::dummy_arm());
                    call_then(crate::lower::expr::start_arm_pat(lx_4_7_9, arm.pattern, sty_7_9, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("u", scrut_5_8_9.span.start, "_", i)), [=](crate::lower::patterns::PatOut arm_pat_17704) {
                    return ({
                        auto po = arm_pat_17704;
                        auto env_a = crate::lower::expr::bind_all(env_3_8_9, po.binds);
                        call_then(crate::lower::templates::start_guard_conds(lx_4_7_9, env_a, arm.guard), [=](Array<crate::lower::model::Cc> guard_conds_17848) {
                        return ({
                            auto guarded = append(po.conds, guard_conds_17848);
                            call_then(start_upd_tail_from(lx_4_7_9, env_a, env_a, arm.body, Nat(0u), arm.body.span, ({
                            auto f = to_k_fn_8_9;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<crate::lower::types::Env, crate::lower::model::Ex> _p0) {
                            auto&& a0 = std::get<0>(_p0);
                            auto&& a1 = std::get<1>(_p0);
                            return ({
                                auto f_9 = f;
                                once_job([=]() { return prism_rtl::finished(f_9(a0, a1)); });
                            });
                        })));
                        })), [=](crate::lower::model::Ex upd_tail_from_17926) { return prism_rtl::finished(crate::lower::model::XArm{.pat = po.pa, .conds = guarded, .body = upd_tail_from_17926}); });
                        });
                    });
                    });
                });
                });
                });
            }));
            });
        })));
        })), [=](Array<crate::lower::model::XArm> each_17617) {
            return ({
                auto xarms = each_17617;
                call_then(crate::lower::expr::start_value_of(lx_4, env_3, scrut_5), [=](crate::lower::types::Vl value_of_18042) { return prism_rtl::finished(prepend(crate::prelude::push(out_dos, k_do), crate::lower::types::own(crate::lower::expr::arms_value(crate::lower::types::own(value_of_18042), xarms, prism_rtl::cat("\'u", scrut_5.span.start), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{Text::lit("the job\'s turn")}))))); });
            });
        });
        });
    });
}


/// `Start MatchJob, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_match_job(crate::lower::Lx lx, crate::lower::types::Env outer, crate::lower::types::Env env, crate::syntax::Expr scrut, Array<crate::syntax::Arm> arms, crate::syntax::Range span, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)> cont_fn) {
    return prism_rtl::make_rc<MatchJob>(lx, outer, env, scrut, arms, span, rest_text_, cont_fn);
}


/// ForJob: unbounded fn Lx, Env, Env, ?ForBinders, Expr, Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
crate::lower::model::Ex for_job(const crate::lower::Lx& lx, const crate::lower::types::Env& outer, const crate::lower::types::Env& env, const std::optional<crate::syntax::ForBinders>& binders_opt, const crate::syntax::Expr& source, const crate::syntax::Block& body, const crate::syntax::Range& span, const Text& rest_text_, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)>& cont_fn) {
    auto state = fold(keys(env->names), Array<std::tuple<Text, Text, crate::lower::model::OutTy>>{}, [&](const Array<std::tuple<Text, Text, crate::lower::model::OutTy>>& acc, const Text& k) {
        return !crate::syntax::lexer::chars::has_prefix(k, Text::lit("&"))
            ? acc
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, Text, crate::lower::model::OutTy>>> _v;
            auto&& _m = crate::prelude::get(env->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& bt = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(crate::prelude::push(acc, std::tuple{k, crate::lower::types::place_stem(rs), bt}));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto names = each(state, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        return rs;
    });
    auto st_ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{each(state, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& bt = std::get<2>(_p0);
        return bt;
    })});
    auto pat = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(names, [&](const Text& n) { return crate::lower::model::Pa(crate::lower::model::Pa::PaMut{prism_rtl::cat(n)}); })});
    auto pack = crate::lower::model::Ex(crate::lower::model::Ex::XTuple{each(names, [&](const Text& n) { return crate::lower::model::Ex(crate::lower::model::Ex::XVar{n}); })});
    auto env_s = fold(state, env, [&](const crate::lower::types::Env& en, const std::tuple<Text, Text, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<2>(_p1);
        return crate::lower::types::bind(en, k, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt}));
    });
    auto src = crate::lower::types::own(crate::lower::expr::value_of(lx, env, source));
    auto sty = crate::lower::types::peel(crate::lower::type_at(lx, source.span));
    auto [kt, vt, is_array] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::lower::model::OutTy, crate::lower::model::OutTy, bool>> _v;
        if (prism_rtl::is<crate::check::types::Ty::TyArray>(sty)) {
            auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyArray>(sty).a0;
            _v.set(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{}), crate::lower::types::out_ty_of(lx, v_), true});
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyMap>(sty)) {
            auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(sty).a0;
            auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(sty).a1;
            _v.set(std::tuple{crate::lower::types::out_ty_of(lx, k), crate::lower::types::out_ty_of(lx, v_), false});
            goto _done;
        }
        {
            _v.set(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), true});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [vty, kty] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::Ty>> _v;
        if (prism_rtl::is<crate::check::types::Ty::TyArray>(sty)) {
            auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyArray>(sty).a0;
            _v.set(std::tuple{v_, crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Nat"), Array<crate::check::types::Ty>{}})});
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyMap>(sty)) {
            auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(sty).a0;
            auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(sty).a1;
            _v.set(std::tuple{v_, k});
            goto _done;
        }
        {
            _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::Ty(crate::check::types::Ty::TyErr{})});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto key_name = prism_rtl::cat("k", span.start);
    auto val_name = prism_rtl::cat("v", span.start);
    auto loop_text = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(lx.g.srcs, lx->file);
        if (prism_rtl::is_some(_m)) {
            auto&& src2 = prism_rtl::some_of(_m);
            _v.set(crate::check::errors::span_text(src2, span));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto caps = caps_in(env_s, loop_text, names);
    auto cap_dos = each(caps, [&](const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        auto&& mode = std::get<2>(_p0);
        auto&& bt = std::get<3>(_p0);
        return crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{crate::lower::types::place_stem(rs)}), crate::lower::types::own(crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{rs, mode, bt}))});
    });
    auto env_c = fold(caps, env_s, [&](const crate::lower::types::Env& en, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return crate::lower::types::bind(en, k, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::types::place_stem(rs)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt}));
    });
    auto env1 = crate::lower::types::bind(crate::lower::types::bind(env_c, Text::lit("key"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), kt})), Text::lit("_"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{val_name}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), vt}));
    auto env_k = is_array
        ? crate::lower::types::bind(env1, Text::lit("ix"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), kt}))
        : env1;
    auto [binds, env_b] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
        if (prism_rtl::is_none(binders_opt)) {
            _v.set(std::tuple{Array<crate::lower::model::Do>{}, env_k});
            goto _done;
        }
        if (prism_rtl::is_some(binders_opt)) {
            auto&& fb = prism_rtl::some_of(binders_opt);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
                auto&& _m = fb.second;
                if (prism_rtl::is_none(_m)) {
                    _v.set(({
                        auto po = crate::lower::patterns::rust_pat(lx, fb.first, vty, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("e", span.start));
                        std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{po.pa, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{val_name}))})})}), crate::lower::expr::bind_all(env_k, po.binds)};
                    }));
                    goto _done;
                }
                if (prism_rtl::is_some(_m)) {
                    auto&& second = prism_rtl::some_of(_m);
                    _v.set(({
                        auto pk = crate::lower::patterns::rust_pat(lx, fb.first, kty, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("k", span.start, "_"));
                        auto pv = crate::lower::patterns::rust_pat(lx, second, vty, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("e", span.start));
                        std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{pk.pa, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name}))})}), crate::lower::model::Do(crate::lower::model::Do::DoLet{pv.pa, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{val_name}))})})}), crate::lower::expr::bind_all(crate::lower::expr::bind_all(env_k, pk.binds), pv.binds)};
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto turn = prepend(binds, upd_tail_from(lx, env_b, env_b, body, Nat(0u), body.span, ({
        auto pack_1 = pack;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<crate::lower::types::Env, crate::lower::model::Ex> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto pack_1_2 = pack_1;
            once_job([=]() {
            return ({
                auto o2 = p0;
                auto e2 = p1;
                (prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{pack_1_2})})));
            });
        });
        });
    })));
    })));
    auto step_fn = prepend(cap_dos, crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(pat), st_ty}), crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{key_name})), kt}), crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{val_name})), vt})}), prism_rtl::rc(turn)}));
    auto out_caps = caps_in(outer, rest_text_, names);
    auto out_dos = each(out_caps, [&](const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        auto&& mode = std::get<2>(_p0);
        auto&& bt = std::get<3>(_p0);
        return crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{crate::lower::types::place_stem(rs)}), crate::lower::types::own(crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{rs, mode, bt}))});
    });
    auto outer2 = fold(out_caps, outer, [&](const crate::lower::types::Env& en, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return crate::lower::types::bind(en, k, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::types::place_stem(rs)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt}));
    });
    auto env2 = fold(out_caps, env_s, [&](const crate::lower::types::Env& en, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return crate::lower::types::bind(en, k, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::types::place_stem(rs)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt}));
    });
    auto looping = is_array ? Text::lit("for_turns_indexed") : Text::lit("for_turns_keyed");
    auto enter = crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("call_then"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{looping, Array(std::vector{src, pack, step_fn})}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(pat), st_ty})}), prism_rtl::rc(run_to_end(cont_fn(std::tuple{outer2, env2})))})})});
    return prepend(out_dos, enter);
}


prism_rtl::Turn<crate::lower::model::Ex> ForJob::cycle() const {
    const auto& lx = this->lx;
    const auto& outer = this->outer;
    const auto& env = this->env;
    const auto& binders_opt = this->binders_opt;
    const auto& source = this->source;
    const auto& body = this->body;
    const auto& span = this->span;
    const auto& rest_text_ = this->rest_text_;
    const auto& cont_fn = this->cont_fn;
    auto state = fold(keys(env->names), Array<std::tuple<Text, Text, crate::lower::model::OutTy>>{}, [&](const Array<std::tuple<Text, Text, crate::lower::model::OutTy>>& acc, const Text& k) {
        return !crate::syntax::lexer::chars::has_prefix(k, Text::lit("&"))
            ? acc
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, Text, crate::lower::model::OutTy>>> _v;
            auto&& _m = crate::prelude::get(env->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& bt = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(crate::prelude::push(acc, std::tuple{k, crate::lower::types::place_stem(rs), bt}));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto names = each(state, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        return rs;
    });
    auto st_ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{each(state, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& bt = std::get<2>(_p0);
        return bt;
    })});
    auto pat = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(names, [&](const Text& n) { return crate::lower::model::Pa(crate::lower::model::Pa::PaMut{prism_rtl::cat(n)}); })});
    auto pack = crate::lower::model::Ex(crate::lower::model::Ex::XTuple{each(names, [&](const Text& n) { return crate::lower::model::Ex(crate::lower::model::Ex::XVar{n}); })});
    auto env_s = fold(state, env, [&](const crate::lower::types::Env& en, const std::tuple<Text, Text, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<2>(_p1);
        return crate::lower::types::bind(en, k, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt}));
    });
    auto binders_opt_1 = binders_opt;
    auto cont_fn_2 = cont_fn;
    auto body_3 = body;
    auto env_4 = env;
    auto lx_5 = lx;
    auto outer_6 = outer;
    auto rest_text__7 = rest_text_;
    auto source_8 = source;
    auto span_9 = span;
    return call_then(crate::lower::expr::start_value_of(lx_5, env_4, source_8), [=](crate::lower::types::Vl value_of_19279) {
        return ({
            auto src = crate::lower::types::own(value_of_19279);
            auto sty = crate::lower::types::peel(crate::lower::type_at(lx_5, source_8.span));
            auto [kt, vt, is_array] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::lower::model::OutTy, crate::lower::model::OutTy, bool>> _v;
                if (prism_rtl::is<crate::check::types::Ty::TyArray>(sty)) {
                    auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyArray>(sty).a0;
                    _v.set(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{}), crate::lower::types::out_ty_of(lx_5, v_), true});
                    goto _done;
                }
                if (prism_rtl::is<crate::check::types::Ty::TyMap>(sty)) {
                    auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(sty).a0;
                    auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(sty).a1;
                    _v.set(std::tuple{crate::lower::types::out_ty_of(lx_5, k), crate::lower::types::out_ty_of(lx_5, v_), false});
                    goto _done;
                }
                {
                    _v.set(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), true});
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto [vty, kty] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::Ty>> _v;
                if (prism_rtl::is<crate::check::types::Ty::TyArray>(sty)) {
                    auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyArray>(sty).a0;
                    _v.set(std::tuple{v_, crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Nat"), Array<crate::check::types::Ty>{}})});
                    goto _done;
                }
                if (prism_rtl::is<crate::check::types::Ty::TyMap>(sty)) {
                    auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(sty).a0;
                    auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(sty).a1;
                    _v.set(std::tuple{v_, k});
                    goto _done;
                }
                {
                    _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::Ty(crate::check::types::Ty::TyErr{})});
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto key_name = prism_rtl::cat("k", span_9.start);
            auto val_name = prism_rtl::cat("v", span_9.start);
            auto loop_text = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = index(lx_5.g.srcs, lx_5->file);
                if (prism_rtl::is_some(_m)) {
                    auto&& src2 = prism_rtl::some_of(_m);
                    _v.set(crate::check::errors::span_text(src2, span_9));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Text::lit(""));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto caps = caps_in(env_s, loop_text, names);
            auto cap_dos = each(caps, [&](const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p0) {
                auto&& rs = std::get<1>(_p0);
                auto&& mode = std::get<2>(_p0);
                auto&& bt = std::get<3>(_p0);
                return crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{crate::lower::types::place_stem(rs)}), crate::lower::types::own(crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{rs, mode, bt}))});
            });
            auto env_c = fold(caps, env_s, [&](const crate::lower::types::Env& en, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
                auto&& k = std::get<0>(_p1);
                auto&& rs = std::get<1>(_p1);
                auto&& bt = std::get<3>(_p1);
                return crate::lower::types::bind(en, k, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::types::place_stem(rs)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt}));
            });
            auto env1 = crate::lower::types::bind(crate::lower::types::bind(env_c, Text::lit("key"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), kt})), Text::lit("_"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{val_name}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), vt}));
            auto env_k = is_array
                ? crate::lower::types::bind(env1, Text::lit("ix"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), kt}))
                : env1;
            auto [binds, env_b] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
                if (prism_rtl::is_none(binders_opt)) {
                    _v.set(std::tuple{Array<crate::lower::model::Do>{}, env_k});
                    goto _done;
                }
                if (prism_rtl::is_some(binders_opt)) {
                    auto&& fb = prism_rtl::some_of(binders_opt);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
                        auto&& _m = fb.second;
                        if (prism_rtl::is_none(_m)) {
                            _v.set(({
                                auto po = crate::lower::patterns::rust_pat(lx_5, fb.first, vty, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("e", span_9.start));
                                std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{po.pa, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{val_name}))})})}), crate::lower::expr::bind_all(env_k, po.binds)};
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_some(_m)) {
                            auto&& second = prism_rtl::some_of(_m);
                            _v.set(({
                                auto pk = crate::lower::patterns::rust_pat(lx_5, fb.first, kty, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("k", span_9.start, "_"));
                                auto pv = crate::lower::patterns::rust_pat(lx_5, second, vty, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("e", span_9.start));
                                std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{pk.pa, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name}))})}), crate::lower::model::Do(crate::lower::model::Do::DoLet{pv.pa, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{val_name}))})})}), crate::lower::expr::bind_all(crate::lower::expr::bind_all(env_k, pk.binds), pv.binds)};
                            }));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            call_then(start_upd_tail_from(lx_5, env_b, env_b, body_3, Nat(0u), body_3.span, ({
            auto pack_10 = pack;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<crate::lower::types::Env, crate::lower::model::Ex> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto pack_10_11 = pack_10;
                once_job([=]() {
                return ({
                    auto o2 = p0;
                    auto e2 = p1;
                    (prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{pack_10_11})})));
                });
            });
            });
        })));
        })), [=](crate::lower::model::Ex upd_tail_from_21044) {
            return ({
                auto turn = prepend(binds, upd_tail_from_21044);
                auto step_fn = prepend(cap_dos, crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(pat), st_ty}), crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{key_name})), kt}), crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{val_name})), vt})}), prism_rtl::rc(turn)}));
                auto out_caps = caps_in(outer_6, rest_text__7, names);
                auto out_dos = each(out_caps, [&](const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p0) {
                    auto&& rs = std::get<1>(_p0);
                    auto&& mode = std::get<2>(_p0);
                    auto&& bt = std::get<3>(_p0);
                    return crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{crate::lower::types::place_stem(rs)}), crate::lower::types::own(crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{rs, mode, bt}))});
                });
                auto outer2 = fold(out_caps, outer_6, [&](const crate::lower::types::Env& en, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
                    auto&& k = std::get<0>(_p1);
                    auto&& rs = std::get<1>(_p1);
                    auto&& bt = std::get<3>(_p1);
                    return crate::lower::types::bind(en, k, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::types::place_stem(rs)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt}));
                });
                auto env2 = fold(out_caps, env_s, [&](const crate::lower::types::Env& en, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
                    auto&& k = std::get<0>(_p1);
                    auto&& rs = std::get<1>(_p1);
                    auto&& bt = std::get<3>(_p1);
                    return crate::lower::types::bind(en, k, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::types::place_stem(rs)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt}));
                });
                auto looping = is_array ? Text::lit("for_turns_indexed") : Text::lit("for_turns_keyed");
                call_value(cont_fn_2(std::tuple{outer2, env2}), [=](crate::lower::model::Ex cont_21892) {
                return ({
                    auto enter = crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("call_then"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{looping, Array(std::vector{src, pack, step_fn})}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(pat), st_ty})}), prism_rtl::rc(cont_21892)})})});
                    (prism_rtl::finished(prepend(out_dos, enter)));
                });
            });
            });
        });
        });
    });
}


/// `Start ForJob, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_for_job(crate::lower::Lx lx, crate::lower::types::Env outer, crate::lower::types::Env env, std::optional<crate::syntax::ForBinders> binders_opt, crate::syntax::Expr source, crate::syntax::Block body, crate::syntax::Range span, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)> cont_fn) {
    return prism_rtl::make_rc<ForJob>(lx, outer, env, binders_opt, source, body, span, rest_text_, cont_fn);
}


/// InstanceOf: fn Text -> Text
Text instance_of(const Text& k) {
    return or_(index(split(k, Text::lit("#inst")), Nat(0u)), k);
}


/// CapsIn: fn Env, Text, [Text] -> [((Text, Ex, Holding, OutTy))]
Array<std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>> caps_in(const crate::lower::types::Env& env, const Text& text_, const Array<Text>& skip) {
    return fold(keys(env->names), Array<std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>>{}, [&](const Array<std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>>& acc, const Text& k) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>>> _v;
            auto&& _m = crate::prelude::get(env->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& mode = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                auto&& bt = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set((crate::check::types::has_text(skip, crate::lower::types::place_stem(rs)) || crate::lower::types::on_self(rs)) || (!mentions(text_, crate::syntax::lexer::chars::drop_prefix(instance_of(k), crate::check::types::unify::marks_of(k))))
                    ? acc
                    : crate::prelude::push(acc, std::tuple{k, rs, mode, bt}));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// ?FrameCall: unbounded fn Lx, Env, Expr, Bool -> ?Expr
std::optional<crate::syntax::Expr> frame_call(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& e, const bool& top) {
    return crate::check::env::has_key(env.spans, crate::lower::place_key(lx, e.span))
        ? std::optional<crate::syntax::Expr>{}
        : ({
        __label__ _done;
        prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
            _v.set(frame_call(lx, env, x, top));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
            auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
            auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                auto&& _m = first_frame(lx, env, each(args, [&](const crate::syntax::Arg& a) { return a->value; }));
                if (prism_rtl::is_some(_m)) {
                    auto&& x = prism_rtl::some_of(_m);
                    _v.set(std::optional(x));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(top
                        ? std::optional<crate::syntax::Expr>{}
                        : ({
                        __label__ _done;
                        prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                        auto&& _m = tail_callee(lx, env, c);
                        if (prism_rtl::is_some(_m)) {
                            _v.set(std::optional(e));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(({
                                __label__ _done;
                                prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                                auto&& _m = local_job_fn(lx, env, c);
                                if (prism_rtl::is_some(_m)) {
                                    _v.set(std::optional(e));
                                    goto _done;
                                }
                                if (prism_rtl::is_none(_m)) {
                                    _v.set(({
                                        __label__ _done;
                                        prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                                        auto&& _m = crate::lower::expr::prelude_job_call(lx, env, e);
                                        if (prism_rtl::is_some(_m)) {
                                            _v.set(std::optional(e));
                                            goto _done;
                                        }
                                        if (prism_rtl::is_none(_m)) {
                                            _v.set(std::optional<crate::syntax::Expr>{});
                                            goto _done;
                                        }
                                        prism_rtl::unreachable("no arm matched");
                                    _done:
                                        _v.take();
                                    }));
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
            _v.set(frame_call(lx, env, x, false));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
            auto&& m23058_3_0 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
            if (prism_rtl::is<crate::syntax::Cond::CondExpr>(m23058_3_0)) {
                auto&& x = prism_rtl::as<crate::syntax::Cond::CondExpr>(m23058_3_0).a0;
                _v.set(frame_call(lx, env, x, false));
                goto _done;
            }
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
            auto&& op = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
            auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
            auto&& r = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
            _v.set((op == Text::lit("and")) || (op == Text::lit("or"))
                ? frame_call(lx, env, l, false)
                : first_frame(lx, env, Array(std::vector{l, r})));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m)) {
            auto&& es = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
            _v.set(first_frame(lx, env, es));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EArray>(_m)) {
            auto&& es = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
            _v.set(first_frame(lx, env, es));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m)) {
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
            _v.set(frame_call(lx, env, x, false));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
            _v.set(frame_call(lx, env, x, false));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
            auto&& i = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
            _v.set(first_frame(lx, env, Array(std::vector{x, i})));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m)) {
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
            auto&& args = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
            _v.set(first_frame(lx, env, append(Array(std::vector{x}), each(args, [&](const crate::syntax::Arg& a) { return a->value; }))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ECast>(_m)) {
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a0;
            _v.set(frame_call(lx, env, x, false));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ELit>(_m)) {
            auto&& l = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                auto&& _m = l.kind;
                if (prism_rtl::is<crate::syntax::LitKind::LText>(_m)) {
                    auto&& segs = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
                    _v.set(first_frame(lx, env, placeholders(segs)));
                    goto _done;
                }
                {
                    _v.set(std::optional<crate::syntax::Expr>{});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(std::optional<crate::syntax::Expr>{});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::optional<crate::syntax::Expr>> FrameCall::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    const auto& top = this->top;
    return crate::check::env::has_key(env.spans, crate::lower::place_key(lx, e.span))
        ? prism_rtl::finished(std::optional<crate::syntax::Expr>{})
        : ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(FrameCall(lx, env, x, top)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ECall>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        ({
        auto args_1 = args;
        auto c_2 = c;
        auto e_3 = e;
        auto env_4 = env;
        auto lx_5 = lx;
        auto top_6 = top;
        call_then(start_first_frame(lx_5, env_4, each(args_1, [&](const crate::syntax::Arg& a) { return a->value; })), [=](std::optional<crate::syntax::Expr> first_frame_23162) {
        return ({
            prism_rtl::is_some(first_frame_23162) ? ({
            auto&& x = prism_rtl::some_of(first_frame_23162);
            prism_rtl::finished(std::optional(x));
        })
            : prism_rtl::is_none(first_frame_23162) ? top_6
            ? prism_rtl::finished(std::optional<crate::syntax::Expr>{})
            : ({
            auto&& _m = tail_callee(lx_5, env_4, c_2);
            prism_rtl::is_some(_m) ? prism_rtl::finished(std::optional(e_3))
            : prism_rtl::is_none(_m) ? call_then(start_local_job_fn(lx_5, env_4, c_2), [=](std::optional<crate::lower::types::Vl> local_job_fn_23393) {
            return ({
                prism_rtl::is_some(local_job_fn_23393) ? prism_rtl::finished(std::optional(e_3))
                : prism_rtl::is_none(local_job_fn_23393) ? call_then(crate::lower::expr::start_prelude_job_call(lx_5, env_4, e_3), [=](std::optional<crate::lower::model::Ex> prelude_job_call_23490) {
                return ({
                    prism_rtl::is_some(prelude_job_call_23490) ? prism_rtl::finished(std::optional(e_3))
                    : prism_rtl::is_none(prelude_job_call_23490) ? prism_rtl::finished(std::optional<crate::syntax::Expr>{})
                    : throw prism_rtl::Panic("no arm matched");
                });
            })
                : throw prism_rtl::Panic("no arm matched");
            });
        })
            : throw prism_rtl::Panic("no arm matched");
        })
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        prism_rtl::more(prism_rtl::rc(FrameCall(lx, env, x, false)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) && ({
        auto&& m23058_3_0 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        prism_rtl::is<crate::syntax::Cond::CondExpr>(m23058_3_0);
    }) ? ({
        auto&& m23058_3_0 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& x = prism_rtl::as<crate::syntax::Cond::CondExpr>(m23058_3_0).a0;
        prism_rtl::more(prism_rtl::rc(FrameCall(lx, env, x, false)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m) ? ({
        auto&& op = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        (op == Text::lit("and")) || (op == Text::lit("or"))
        ? prism_rtl::more(prism_rtl::rc(FrameCall(lx, env, l, false)))
        : prism_rtl::more(prism_rtl::rc(FirstFrame(lx, env, Array(std::vector{l, r}))));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m) ? ({
        auto&& es = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
        prism_rtl::more(prism_rtl::rc(FirstFrame(lx, env, es)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EArray>(_m) ? ({
        auto&& es = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
        prism_rtl::more(prism_rtl::rc(FirstFrame(lx, env, es)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
        prism_rtl::more(prism_rtl::rc(FrameCall(lx, env, x, false)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EField>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        prism_rtl::more(prism_rtl::rc(FrameCall(lx, env, x, false)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& i = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        prism_rtl::more(prism_rtl::rc(FirstFrame(lx, env, Array(std::vector{x, i}))));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
        prism_rtl::more(prism_rtl::rc(FirstFrame(lx, env, append(Array(std::vector{x}), each(args, [&](const crate::syntax::Arg& a) { return a->value; })))));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ECast>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a0;
        prism_rtl::more(prism_rtl::rc(FrameCall(lx, env, x, false)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ELit>(_m) ? ({
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
        ({
        auto&& _m = l.kind;
        prism_rtl::is<crate::syntax::LitKind::LText>(_m) ? ({
        auto&& segs = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
        prism_rtl::more(prism_rtl::rc(FirstFrame(lx, env, placeholders(segs))));
    })
        : prism_rtl::finished(std::optional<crate::syntax::Expr>{});
    });
    })
        : prism_rtl::finished(std::optional<crate::syntax::Expr>{});
    });
}


/// `Start FrameCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<crate::syntax::Expr>> start_frame_call(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e, bool top) {
    return prism_rtl::make_rc<FrameCall>(lx, env, e, top);
}


/// Placeholders: fn [TextSeg] -> [Expr]
Array<crate::syntax::Expr> placeholders(const Array<crate::syntax::TextSeg>& segs) {
    return fold(segs, Array<crate::syntax::Expr>{}, [&](const Array<crate::syntax::Expr>& acc, const crate::syntax::TextSeg& sg) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
            if (prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(sg)) {
                auto&& x = prism_rtl::as<crate::syntax::TextSeg::SegPlaceholder>(sg).a0;
                _v.set(crate::prelude::push(acc, x));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// ?FirstFrame: unbounded fn Lx, Env, [Expr] -> ?Expr
std::optional<crate::syntax::Expr> first_frame(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const Array<crate::syntax::Expr>& es) {
    return run_to_end(fold_job(es, std::optional<crate::syntax::Expr>{}, ({
        auto lx_1 = lx;
        auto env_2 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<crate::syntax::Expr>>(std::tuple<std::optional<crate::syntax::Expr>, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<std::optional<crate::syntax::Expr>, crate::syntax::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_3 = lx_1;
            auto env_2_3 = env_2;
            entered(once_job([=]() {
            return ({
                auto found_opt = p0;
                auto x = p1;
                ({
                prism_rtl::is_some(found_opt) ? ({
                auto&& f = prism_rtl::some_of(found_opt);
                prism_rtl::finished(std::optional(f));
            })
                : prism_rtl::is_none(found_opt) ? prism_rtl::more(prism_rtl::rc(FrameCall(lx_1_3, env_2_3, x, false)))
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<std::optional<crate::syntax::Expr>> FirstFrame::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& es = this->es;
    return fold_job(es, std::optional<crate::syntax::Expr>{}, ({
        auto lx_1 = lx;
        auto env_2 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<crate::syntax::Expr>>(std::tuple<std::optional<crate::syntax::Expr>, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<std::optional<crate::syntax::Expr>, crate::syntax::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_3 = lx_1;
            auto env_2_3 = env_2;
            entered(once_job([=]() {
            return ({
                auto found_opt = p0;
                auto x = p1;
                ({
                prism_rtl::is_some(found_opt) ? ({
                auto&& f = prism_rtl::some_of(found_opt);
                prism_rtl::finished(std::optional(f));
            })
                : prism_rtl::is_none(found_opt) ? prism_rtl::more(prism_rtl::rc(FrameCall(lx_1_3, env_2_3, x, false)))
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start FirstFrame, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<crate::syntax::Expr>> start_first_frame(crate::lower::Lx lx, crate::lower::types::Env env, Array<crate::syntax::Expr> es) {
    return prism_rtl::make_rc<FirstFrame>(lx, env, es);
}


/// Frame: unbounded fn Lx, Env, Expr, Text, (unbounded fn Env -> Ex) -> Ex
crate::lower::model::Ex frame(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& call, const Text& rest_text_, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::lower::types::Env)>& cont_fn) {
    auto&& _m = call.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        auto qk_opt = tail_callee(lx, env, c);
        auto qk = or_(qk_opt, Text::lit(""));
        auto base = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& q = prism_rtl::some_of(qk_opt);
                _v.set(or_(crate::prelude::get(lx.rs_names, q), crate::lower::snake(crate::check::types::bare_name(q))));
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(crate::lower::snake(callee_text(c)));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto v_ = prism_rtl::cat(base, "_", call.span.start);
        auto t = crate::lower::types::out_ty_of(lx, crate::lower::types::peel(crate::lower::type_at(lx, call.span)));
        auto caps = fold(keys(env->names), Array<std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>>{}, [&](const Array<std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>>& acc, const Text& k) {
            return ({
                __label__ _done;
                prism_rtl::Slot<Array<std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>>> _v;
                auto&& _m = crate::prelude::get(env->names, k);
                if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                    auto&& rs = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                    auto&& mode = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                    auto&& bt = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                    _v.set(((mode == crate::lower::types::Holding(crate::lower::types::Holding::ByRef{})) || (mode == crate::lower::types::Holding(crate::lower::types::Holding::RcRef{}))) && mentions(rest_text_, instance_of(k))
                        ? crate::prelude::push(acc, std::tuple{k, rs, mode, bt})
                        : acc);
                    goto _done;
                }
                {
                    _v.set(acc);
                    goto _done;
                }
            _done:
                _v.take();
            });
        });
        auto dos = each(caps, [&](const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p0) {
            auto&& rs = std::get<1>(_p0);
            auto&& mode = std::get<2>(_p0);
            auto&& bt = std::get<3>(_p0);
            return crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{crate::lower::types::place_stem(rs)}), crate::lower::types::own(crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{rs, mode, bt}))});
        });
        auto env2 = fold(caps, env, [&](const crate::lower::types::Env& en, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
            auto&& k = std::get<0>(_p1);
            auto&& rs = std::get<1>(_p1);
            auto&& bt = std::get<3>(_p1);
            return crate::lower::types::bind(en, k, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::types::place_stem(rs)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt}));
        });
        auto vals = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& q = prism_rtl::some_of(qk_opt);
                _v.set(crate::lower::expr::named_args_owned(lx, env2, q, args));
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
                    auto&& _m = local_job_fn(lx, env2, c);
                    if (prism_rtl::is_some(_m)) {
                        auto&& f = prism_rtl::some_of(_m);
                        _v.set(crate::lower::expr::start_args(lx, env2, f, args));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(run_to_end(each_job(args, ({
                            auto lx_1 = lx;
                            auto env2_2 = env2;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=](crate::syntax::Arg p0) {
                            return ({
                                auto lx_1_3 = lx_1;
                                auto env2_2_3 = env2_2;
                                entered(once_job([=]() {
                                return ({
                                    auto a = p0;
                                    call_then(crate::lower::expr::start_value_of(lx_1_3, env2_2_3, a->value), [=](crate::lower::types::Vl value_of_26213) { return prism_rtl::finished(crate::lower::types::own(value_of_26213)); });
                                });
                            }));
                            });
                        })));
                        }))));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto env3 = crate::lower::types::bind_span(env2, crate::lower::place_key(lx, call.span), crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XVar{v_}), t}));
        auto body = run_to_end(cont_fn(env3));
        auto [job, how] = ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<crate::lower::model::Ex, Text>> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& q = prism_rtl::some_of(qk_opt);
                _v.set(std::tuple{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::path_in(lx, crate::lower::owner_of(q), prism_rtl::cat("start_", base)), vals}), crate::lower::program::enters_at_once(lx, q, args)
                    ? Text::lit("call_value")
                    : Text::lit("call_then")});
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<crate::lower::model::Ex, Text>> _v;
                    auto&& _m = local_job_fn(lx, env2, c);
                    if (prism_rtl::is_some(_m)) {
                        auto&& f = prism_rtl::some_of(_m);
                        _v.set(std::tuple{start_call(f, vals), Text::lit("call_value")});
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<std::tuple<crate::lower::model::Ex, Text>> _v;
                            auto&& _m = crate::lower::expr::prelude_job_call(lx, env2, call);
                            if (prism_rtl::is_some(_m)) {
                                auto&& pj = prism_rtl::some_of(_m);
                                _v.set(std::tuple{pj, Text::lit("call_value")});
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(std::tuple{crate::lower::expr::refusal(Text::lit("a call this frame cannot enter")), Text::lit("call_then")});
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto enter = crate::lower::model::Ex(crate::lower::model::Ex::XCall{how, Array(std::vector{job, crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{v_})), t})}), prism_rtl::rc(body)})})});
        return len(dos) == Nat(0u)
            ? enter
            : crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos, prism_rtl::rc(enter)});
    }
    {
        return run_to_end(cont_fn(env));
    }
}


prism_rtl::Turn<crate::lower::model::Ex> Frame::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& call = this->call;
    const auto& rest_text_ = this->rest_text_;
    const auto& cont_fn = this->cont_fn;
    return ({
        auto&& _m = call.kind;
        prism_rtl::is<crate::syntax::ExprKind::ECall>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        ({
        auto qk_opt = tail_callee(lx, env, c);
        auto qk = or_(qk_opt, Text::lit(""));
        auto base = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& q = prism_rtl::some_of(qk_opt);
                _v.set(or_(crate::prelude::get(lx.rs_names, q), crate::lower::snake(crate::check::types::bare_name(q))));
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(crate::lower::snake(callee_text(c)));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto v_ = prism_rtl::cat(base, "_", call.span.start);
        auto cont_fn_1 = cont_fn;
        auto args_2 = args;
        auto c_3 = c;
        auto call_4 = call;
        auto env_5 = env;
        auto lx_6 = lx;
        auto rest_text__7 = rest_text_;
        call_then(crate::lower::types::start_out_ty_of(lx_6, crate::lower::types::peel(crate::lower::type_at(lx_6, call_4.span))), [=](crate::lower::model::OutTy out_ty_of_25458) {
        return ({
            auto t = out_ty_of_25458;
            auto caps = fold(keys(env_5->names), Array<std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>>{}, [&](const Array<std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>>& acc, const Text& k) {
                return ({
                    __label__ _done;
                    prism_rtl::Slot<Array<std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>>> _v;
                    auto&& _m = crate::prelude::get(env_5->names, k);
                    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                        auto&& rs = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                        auto&& mode = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                        auto&& bt = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                        _v.set(((mode == crate::lower::types::Holding(crate::lower::types::Holding::ByRef{})) || (mode == crate::lower::types::Holding(crate::lower::types::Holding::RcRef{}))) && mentions(rest_text__7, instance_of(k))
                            ? crate::prelude::push(acc, std::tuple{k, rs, mode, bt})
                            : acc);
                        goto _done;
                    }
                    {
                        _v.set(acc);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            });
            auto dos = each(caps, [&](const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p0) {
                auto&& rs = std::get<1>(_p0);
                auto&& mode = std::get<2>(_p0);
                auto&& bt = std::get<3>(_p0);
                return crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{crate::lower::types::place_stem(rs)}), crate::lower::types::own(crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{rs, mode, bt}))});
            });
            auto env2 = fold(caps, env_5, [&](const crate::lower::types::Env& en, const std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>& _p1) {
                auto&& k = std::get<0>(_p1);
                auto&& rs = std::get<1>(_p1);
                auto&& bt = std::get<3>(_p1);
                return crate::lower::types::bind(en, k, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::types::place_stem(rs)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt}));
            });
            auto vals = ({
                __label__ _done;
                prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
                if (prism_rtl::is_some(qk_opt)) {
                    auto&& q = prism_rtl::some_of(qk_opt);
                    _v.set(crate::lower::expr::named_args_owned(lx_6, env2, q, args_2));
                    goto _done;
                }
                if (prism_rtl::is_none(qk_opt)) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
                        auto&& _m = local_job_fn(lx_6, env2, c_3);
                        if (prism_rtl::is_some(_m)) {
                            auto&& f = prism_rtl::some_of(_m);
                            _v.set(crate::lower::expr::start_args(lx_6, env2, f, args_2));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(run_to_end(each_job(args_2, ({
                                auto lx_6_8 = lx_6;
                                auto env2_8 = env2;
                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=](crate::syntax::Arg p0) {
                                return ({
                                    auto lx_6_8_9 = lx_6_8;
                                    auto env2_8_9 = env2_8;
                                    entered(once_job([=]() {
                                    return ({
                                        auto a = p0;
                                        call_then(crate::lower::expr::start_value_of(lx_6_8_9, env2_8_9, a->value), [=](crate::lower::types::Vl value_of_26213) { return prism_rtl::finished(crate::lower::types::own(value_of_26213)); });
                                    });
                                }));
                                });
                            })));
                            }))));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto env3 = crate::lower::types::bind_span(env2, crate::lower::place_key(lx_6, call_4.span), crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XVar{v_}), t}));
            call_value(cont_fn_1(env3), [=](crate::lower::model::Ex cont_26341) {
            return ({
                auto body = cont_26341;
                auto [job, how] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<crate::lower::model::Ex, Text>> _v;
                    if (prism_rtl::is_some(qk_opt)) {
                        auto&& q = prism_rtl::some_of(qk_opt);
                        _v.set(std::tuple{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::path_in(lx_6, crate::lower::owner_of(q), prism_rtl::cat("start_", base)), vals}), crate::lower::program::enters_at_once(lx_6, q, args_2)
                            ? Text::lit("call_value")
                            : Text::lit("call_then")});
                        goto _done;
                    }
                    if (prism_rtl::is_none(qk_opt)) {
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<std::tuple<crate::lower::model::Ex, Text>> _v;
                            auto&& _m = local_job_fn(lx_6, env2, c_3);
                            if (prism_rtl::is_some(_m)) {
                                auto&& f = prism_rtl::some_of(_m);
                                _v.set(std::tuple{start_call(f, vals), Text::lit("call_value")});
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(({
                                    __label__ _done;
                                    prism_rtl::Slot<std::tuple<crate::lower::model::Ex, Text>> _v;
                                    auto&& _m = crate::lower::expr::prelude_job_call(lx_6, env2, call_4);
                                    if (prism_rtl::is_some(_m)) {
                                        auto&& pj = prism_rtl::some_of(_m);
                                        _v.set(std::tuple{pj, Text::lit("call_value")});
                                        goto _done;
                                    }
                                    if (prism_rtl::is_none(_m)) {
                                        _v.set(std::tuple{crate::lower::expr::refusal(Text::lit("a call this frame cannot enter")), Text::lit("call_then")});
                                        goto _done;
                                    }
                                    prism_rtl::unreachable("no arm matched");
                                _done:
                                    _v.take();
                                }));
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto enter = crate::lower::model::Ex(crate::lower::model::Ex::XCall{how, Array(std::vector{job, crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{v_})), t})}), prism_rtl::rc(body)})})});
                len(dos) == Nat(0u)
                ? prism_rtl::finished(enter)
                : prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos, prism_rtl::rc(enter)}));
            });
        });
        });
    });
    });
    })
        : cont_fn(env)->cycle();
    });
}


/// `Start Frame, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_frame(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr call, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::lower::types::Env)> cont_fn) {
    return prism_rtl::make_rc<Frame>(lx, env, call, rest_text_, cont_fn);
}


/// ?LocalJobFn: unbounded fn Lx, Env, Expr -> ?Vl
std::optional<crate::lower::types::Vl> local_job_fn(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& c) {
    auto&& _m = c.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return (len(n->path_) == Nat(1u)) && crate::check::env::has_key(env->names, crate::check::env::sname_key(n))
            ? job_value(crate::lower::expr::name_value(lx, env, n, c.span))
            : std::optional<crate::lower::types::Vl>{};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return local_job_fn(lx, env, x);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        return job_value(crate::lower::expr::value_of(lx, env, c));
    }
    {
        return std::optional<crate::lower::types::Vl>{};
    }
}


prism_rtl::Turn<std::optional<crate::lower::types::Vl>> LocalJobFn::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& c = this->c;
    return ({
        auto&& _m = c.kind;
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        (len(n->path_) == Nat(1u)) && crate::check::env::has_key(env->names, crate::check::env::sname_key(n))
        ? ({
        auto c_1 = c;
        auto env_2 = env;
        auto lx_3 = lx;
        auto n_4 = n;
        call_then(crate::lower::expr::start_name_value(lx_3, env_2, n_4, c_1.span), [=](crate::lower::types::Vl name_value_27258) { return prism_rtl::finished(job_value(name_value_27258)); });
    })
        : prism_rtl::finished(std::optional<crate::lower::types::Vl>{});
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(LocalJobFn(lx, env, x)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EField>(_m) ? ({
        auto c_1 = c;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(crate::lower::expr::start_value_of(lx_3, env_2, c_1), [=](crate::lower::types::Vl value_of_27389) { return prism_rtl::finished(job_value(value_of_27389)); });
    })
        : prism_rtl::finished(std::optional<crate::lower::types::Vl>{});
    });
}


/// `Start LocalJobFn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<crate::lower::types::Vl>> start_local_job_fn(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr c) {
    return prism_rtl::make_rc<LocalJobFn>(lx, env, c);
}


/// ?JobValue: fn Vl -> ?Vl
std::optional<crate::lower::types::Vl> job_value(const crate::lower::types::Vl& f) {
    auto&& _m = crate::lower::types::value_ty(f);
    if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m)) {
        return std::optional(f);
    }
    {
        return std::optional<crate::lower::types::Vl>{};
    }
}


/// StartCall: fn Vl, [Ex] -> Ex
crate::lower::model::Ex start_call(const crate::lower::types::Vl& f, const Array<crate::lower::model::Ex>& vals) {
    return crate::lower::model::Ex(crate::lower::model::Ex::XApply{prism_rtl::rc(crate::lower::types::ref_(f)), Array(std::vector{one_or_tuple(vals)})});
}


/// OneOrTuple: fn [Ex] -> Ex
crate::lower::model::Ex one_or_tuple(const Array<crate::lower::model::Ex>& xs0) {
    {
        auto&& c0_0 = xs0;
        if (c0_0.size() == 1u) {
            {
                auto&& _c1 = index(c0_0, Nat(0u));
                if (prism_rtl::is_some(_c1)) {
                    auto&& one = prism_rtl::some_of(_c1);
                    return one;
                }
            }
        }
    }
    {
        auto&& vals = xs0;
        return crate::lower::model::Ex(crate::lower::model::Ex::XTuple{vals});
    }
}


/// CalleeText: fn Expr -> Text
Text callee_text(const crate::syntax::Expr& c) {
    auto&& _m = c.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return crate::check::env::dotted(n->path_);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return callee_text(x);
    }
    {
        return Text::lit("call");
    }
}


/// RestText: fn Lx, Range, Range, Range -> Text
Text rest_text(const crate::lower::Lx& lx, const crate::syntax::Range& from, const crate::syntax::Range& call, const crate::syntax::Range& to) {
    auto&& _m = index(lx.g.srcs, lx->file);
    if (prism_rtl::is_some(_m)) {
        auto&& src = prism_rtl::some_of(_m);
        return crate::check::errors::span_text(src, crate::syntax::Range{.start = from.start, .end = to.end});
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// Mentions: fn Text, Text -> Bool
bool mentions(const Text& text_, const Text& name) {
    auto parts = split(text_, name);
    auto last = crate::syntax::lexer::chars::dec(len(parts));
    return fold(crate::check::errors::range0(last), false, [&](const bool& found, const Nat& i) {
        return ({
            auto before_ = or_(index(parts, i), Text::lit(""));
            auto after_ = or_(index(parts, i + Nat(1u)), Text::lit(""));
            auto left_word = before_ != Text::lit("")
                ? ends_ident(before_)
                : (i > Nat(0u)) && ends_ident(name);
            auto right_word = after_ != Text::lit("")
                ? starts_ident(after_)
                : ((i + Nat(1u)) < last) && starts_ident(name);
            found || ((!left_word) && (!right_word));
        });
    });
}


/// EndsIdent: fn Text -> Bool
bool ends_ident(const Text& t) {
    return (len_text(t) > Nat(0u)) && crate::syntax::lexer::chars::is_ident_char(crate::syntax::lexer::chars::last_char(t));
}


/// StartsIdent: fn Text -> Bool
bool starts_ident(const Text& t) {
    return (len_text(t) > Nat(0u)) && crate::syntax::lexer::chars::is_ident_char(crate::syntax::lexer::chars::head(t));
}


/// TailBody: unbounded fn Lx, Env, FnBody -> Ex
crate::lower::model::Ex tail_body(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::decls::FnBody& fn_body2) {
    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(fn_body2)) {
        auto&& x = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(fn_body2).a0;
        return tail(lx, env, x);
    }
    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(fn_body2)) {
        auto&& b = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(fn_body2).a0;
        return tail_block(lx, env, b);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::model::Ex> TailBody::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& fn_body2 = this->fn_body2;
    return ({
        prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(fn_body2) ? ({
        auto&& x = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(fn_body2).a0;
        prism_rtl::more(prism_rtl::rc(Tail(lx, env, x)));
    })
        : prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(fn_body2) ? ({
        auto&& b = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(fn_body2).a0;
        prism_rtl::more(prism_rtl::rc(TailBlock(lx, env, b)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TailBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_tail_body(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::decls::FnBody fn_body2) {
    return prism_rtl::make_rc<TailBody>(lx, env, fn_body2);
}


/// TailMatch: unbounded fn Lx, Env, Expr, [Arm], Range -> Ex
crate::lower::model::Ex tail_match(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& s, const Array<crate::syntax::Arm>& arms, const crate::syntax::Range& span) {
    auto sv = crate::lower::expr::value_of(lx, env, s);
    auto sty = crate::lower::type_at(lx, s.span);
    auto label = prism_rtl::cat("m", span.start);
    auto by_ref = run_to_end(each_job(crate::check::errors::range0(len(arms)), ({
        auto lx_1 = lx;
        auto arms_2 = arms;
        auto sty_3 = sty;
        auto label_4 = label;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::patterns::PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto lx_1_5 = lx_1;
            auto arms_2_5 = arms_2;
            auto sty_3_5 = sty_3;
            auto label_4_5 = label_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(crate::lower::expr::ArmPat(lx_1_5, or_(index(arms_2_5, i), crate::lower::expr::dummy_arm()).pattern, sty_3_5, crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), prism_rtl::cat(label_4_5, "_", i)))));
            });
        }));
        });
    })));
    })));
    auto chain = fold(by_ref, false, [&](const bool& f, const crate::lower::patterns::PatOut& po) { return f || fold(po.conds, false, [&](const bool& f2, const crate::lower::model::Cc& c) { return f2 || crate::lower::expr::is_let_cond(c); }); });
    auto owned = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<crate::lower::types::Vl::VlOwned>(sv)) {
            _v.set(!chain);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto pats = owned
        ? run_to_end(each_job(crate::check::errors::range0(len(arms)), ({
        auto lx_1 = lx;
        auto arms_2 = arms;
        auto sty_3 = sty;
        auto label_4 = label;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::patterns::PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto lx_1_5 = lx_1;
            auto arms_2_5 = arms_2;
            auto sty_3_5 = sty_3;
            auto label_4_5 = label_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(crate::lower::expr::ArmPat(lx_1_5, or_(index(arms_2_5, i), crate::lower::expr::dummy_arm()).pattern, sty_3_5, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat(label_4_5, "_", i)))));
            });
        }));
        });
    })));
    })))
        : by_ref;
    auto xarms = run_to_end(each_job(crate::check::errors::range0(len(arms)), ({
        auto arms_1 = arms;
        auto pats_2 = pats;
        auto env_3 = env;
        auto lx_4 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::XArm>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto arms_1_5 = arms_1;
            auto pats_2_5 = pats_2;
            auto env_3_5 = env_3;
            auto lx_4_5 = lx_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto arm = or_(index(arms_1_5, i), crate::lower::expr::dummy_arm());
                auto po = or_(index(pats_2_5, i), crate::lower::patterns::PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}});
                auto env2 = crate::lower::expr::bind_all(env_3_5, po.binds);
                call_then(crate::lower::templates::start_guard_conds(lx_4_5, env2, arm.guard), [=](Array<crate::lower::model::Cc> guard_conds_30299) { return call_then(start_tail_block(lx_4_5, env2, arm.body), [=](crate::lower::model::Ex tail_block_30340) { return prism_rtl::finished(crate::lower::model::XArm{.pat = po.pa, .conds = append(po.conds, guard_conds_30299), .body = tail_block_30340}); }); });
            });
            });
        }));
        });
    })));
    })));
    auto scrut = owned ? crate::lower::types::own(sv) : crate::lower::types::ref_(sv);
    return crate::lower::types::own(crate::lower::expr::arms_value(scrut, xarms, prism_rtl::cat("\'", label), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{Text::lit("the job\'s turn")})));
}


prism_rtl::Turn<crate::lower::model::Ex> TailMatch::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& s = this->s;
    const auto& arms = this->arms;
    const auto& span = this->span;
    auto arms_1 = arms;
    auto env_2 = env;
    auto lx_3 = lx;
    auto s_4 = s;
    auto span_5 = span;
    return call_then(crate::lower::expr::start_value_of(lx_3, env_2, s_4), [=](crate::lower::types::Vl value_of_29521) {
        return ({
            auto sv = value_of_29521;
            auto sty = crate::lower::type_at(lx_3, s_4.span);
            auto label = prism_rtl::cat("m", span_5.start);
            call_value(each_job(crate::check::errors::range0(len(arms_1)), ({
            auto lx_3_6 = lx_3;
            auto arms_1_6 = arms_1;
            auto sty_6 = sty;
            auto label_7 = label;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::patterns::PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto lx_3_6_8 = lx_3_6;
                auto arms_1_6_8 = arms_1_6;
                auto sty_6_8 = sty_6;
                auto label_7_8 = label_7;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    (prism_rtl::more(prism_rtl::rc(crate::lower::expr::ArmPat(lx_3_6_8, or_(index(arms_1_6_8, i), crate::lower::expr::dummy_arm()).pattern, sty_6_8, crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), prism_rtl::cat(label_7_8, "_", i)))));
                });
            }));
            });
        })));
        })), [=](Array<crate::lower::patterns::PatOut> each_29620) {
            return ({
                auto by_ref = each_29620;
                auto chain = fold(by_ref, false, [&](const bool& f, const crate::lower::patterns::PatOut& po) { return f || fold(po.conds, false, [&](const bool& f2, const crate::lower::model::Cc& c) { return f2 || crate::lower::expr::is_let_cond(c); }); });
                auto owned = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    if (prism_rtl::is<crate::lower::types::Vl::VlOwned>(sv)) {
                        _v.set(!chain);
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto pats = owned
                    ? run_to_end(each_job(crate::check::errors::range0(len(arms_1)), ({
                    auto lx_3_6 = lx_3;
                    auto arms_1_6 = arms_1;
                    auto sty_6 = sty;
                    auto label_7 = label;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::patterns::PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                    return ({
                        auto lx_3_6_8 = lx_3_6;
                        auto arms_1_6_8 = arms_1_6;
                        auto sty_6_8 = sty_6;
                        auto label_7_8 = label_7;
                        entered(once_job([=]() {
                        return ({
                            auto i = p0;
                            (prism_rtl::more(prism_rtl::rc(crate::lower::expr::ArmPat(lx_3_6_8, or_(index(arms_1_6_8, i), crate::lower::expr::dummy_arm()).pattern, sty_6_8, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat(label_7_8, "_", i)))));
                        });
                    }));
                    });
                })));
                })))
                    : by_ref;
                call_value(each_job(crate::check::errors::range0(len(arms_1)), ({
                auto arms_1_6 = arms_1;
                auto pats_6 = pats;
                auto env_2_7 = env_2;
                auto lx_3_7 = lx_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::XArm>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                return ({
                    auto arms_1_6_7 = arms_1_6;
                    auto pats_6_7 = pats_6;
                    auto env_2_7_7 = env_2_7;
                    auto lx_3_7_7 = lx_3_7;
                    entered(once_job([=]() {
                    return ({
                        auto i = p0;
                        ({
                        auto arm = or_(index(arms_1_6_7, i), crate::lower::expr::dummy_arm());
                        auto po = or_(index(pats_6_7, i), crate::lower::patterns::PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}});
                        auto env2 = crate::lower::expr::bind_all(env_2_7_7, po.binds);
                        call_then(crate::lower::templates::start_guard_conds(lx_3_7_7, env2, arm.guard), [=](Array<crate::lower::model::Cc> guard_conds_30299) { return call_then(start_tail_block(lx_3_7_7, env2, arm.body), [=](crate::lower::model::Ex tail_block_30340) { return prism_rtl::finished(crate::lower::model::XArm{.pat = po.pa, .conds = append(po.conds, guard_conds_30299), .body = tail_block_30340}); }); });
                    });
                    });
                }));
                });
            })));
            })), [=](Array<crate::lower::model::XArm> each_30066) {
                return ({
                    auto xarms = each_30066;
                    auto scrut = owned ? crate::lower::types::own(sv) : crate::lower::types::ref_(sv);
                    (prism_rtl::finished(crate::lower::types::own(crate::lower::expr::arms_value(scrut, xarms, prism_rtl::cat("\'", label), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{Text::lit("the job\'s turn")})))));
                });
            });
            });
        });
        });
    });
}


/// `Start TailMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_tail_match(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr s, Array<crate::syntax::Arm> arms, crate::syntax::Range span) {
    return prism_rtl::make_rc<TailMatch>(lx, env, s, arms, span);
}


/// ?TailCallee: fn Lx, Env, Expr -> ?Text
std::optional<Text> tail_callee(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& callee) {
    auto&& _m = callee.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return (len(n->path_) == Nat(1u)) && crate::check::env::has_key(env->names, crate::check::env::sname_key(n))
            ? std::optional<Text>{}
            : ({
            auto&& _qk_opt = crate::check::env::names::resolve_value(lx.g, lx.home, n);
            auto&& qk_opt = std::get<0>(_qk_opt);
            ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Text>> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& qk = prism_rtl::some_of(qk_opt);
                _v.set(crate::check::types::has_text(lx.unbs, qk) && (!crate::lower::program::in_prelude(lx, qk))
                    ? std::optional(qk)
                    : std::optional<Text>{});
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(std::optional<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        });
    }
    {
        return std::optional<Text>{};
    }
}


/// SchemeParts: fn Lx, Text -> (([Ty], Ty))
std::tuple<Array<crate::check::types::Ty>, crate::check::types::Ty> scheme_parts(const crate::lower::Lx& lx, const Text& qk) {
    auto&& _m = crate::prelude::get(lx.g.vals, qk);
    if (prism_rtl::is_some(_m)) {
        auto&& v_ = prism_rtl::some_of(_m);
        auto&& _m = v_.scheme.ty;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            auto&& r = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
            return std::tuple{ps, r};
        }
        {
            auto&& other = _m;
            return std::tuple{Array<crate::check::types::Ty>{}, other};
        }
    }
    if (prism_rtl::is_none(_m)) {
        return std::tuple{Array<crate::check::types::Ty>{}, crate::check::types::Ty(crate::check::types::Ty::TyErr{})};
    }
    prism_rtl::unreachable("no arm matched");
}


/// JobFieldNames: unbounded fn Lx, Text -> [Text]
Array<Text> job_field_names(const crate::lower::Lx& lx, const Text& qk) {
    auto clauses = clauses_of(lx.g, qk);
    auto&& _ptys = scheme_parts(lx, qk);
    auto&& ptys = std::get<0>(_ptys);
    auto pts = run_to_end(each_job(ptys, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(crate::lower::types::OutTyOf(lx_1_2, crate::lower::types::peel(p_)))));
            });
        }));
        });
    })));
    })));
    return each(crate::lower::functions::param_names(lx, clauses, pts), [&](const std::tuple<Text, bool>& _p0) {
        auto&& n = std::get<0>(_p0);
        return n;
    });
}


prism_rtl::Turn<Array<Text>> JobFieldNames::cycle() const {
    const auto& lx = this->lx;
    const auto& qk = this->qk;
    auto clauses = clauses_of(lx.g, qk);
    auto&& _ptys = scheme_parts(lx, qk);
    auto&& ptys = std::get<0>(_ptys);
    auto lx_1 = lx;
    return call_value(each_job(ptys, ({
        auto lx_1_2 = lx_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return ({
            auto lx_1_2_2 = lx_1_2;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(crate::lower::types::OutTyOf(lx_1_2_2, crate::lower::types::peel(p_)))));
            });
        }));
        });
    })));
    })), [=](Array<crate::lower::model::OutTy> each_31407) {
        return ({
            auto pts = each_31407;
            (prism_rtl::finished(each(crate::lower::functions::param_names(lx_1, clauses, pts), [&](const std::tuple<Text, bool>& _p0) {
            auto&& n = std::get<0>(_p0);
            return n;
        })));
        });
    });
}


/// `Start JobFieldNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_job_field_names(crate::lower::Lx lx, Text qk) {
    return prism_rtl::make_rc<JobFieldNames>(lx, qk);
}


/// ClausesOf: fn G, Text -> [FnClause]
Array<crate::syntax::decls::FnClause> clauses_of(const crate::check::env::G& g, const Text& qk) {
    return fold(g.defs, Array<crate::syntax::decls::FnClause>{}, [&](const Array<crate::syntax::decls::FnClause>& acc, const crate::check::env::Def& d) { return d.qk == qk ? def_clauses(d, acc) : acc; });
}


/// DefClauses: fn Def, [FnClause] -> [FnClause]
Array<crate::syntax::decls::FnClause> def_clauses(const crate::check::env::Def& d, const Array<crate::syntax::decls::FnClause>& other) {
    auto&& _m = d.body;
    if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
        auto&& cs = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
        return cs;
    }
    {
        return other;
    }
}


/// JobDefOf: unbounded fn Lx, Text, [FnClause], Scheme -> JobDef
crate::lower::model::JobDef job_def_of(const crate::lower::Lx& lx, const Text& qk, const Array<crate::syntax::decls::FnClause>& clauses, const crate::check::types::Scheme& sc) {
    auto [ptys, res] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::check::types::Ty>, crate::check::types::Ty>> _v;
        auto&& _m = sc.ty;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            auto&& r = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
            _v.set(std::tuple{ps, r});
            goto _done;
        }
        {
            auto&& other = _m;
            _v.set(std::tuple{Array<crate::check::types::Ty>{}, other});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto pts = run_to_end(each_job(ptys, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(crate::lower::types::OutTyOf(lx_1_2, crate::lower::types::peel(p_)))));
            });
        }));
        });
    })));
    })));
    auto names = crate::lower::functions::param_names(lx, clauses, pts);
    auto body = job_clauses(lx, clauses, names, ptys, pts);
    auto base = or_(crate::prelude::get(lx.rs_names, qk), crate::lower::snake(crate::check::types::bare_name(qk)));
    return crate::lower::model::JobDef{.name = crate::lower::camel(crate::check::types::bare_name(qk)), .start = prism_rtl::cat("start_", base), .generics = crate::lower::functions::scheme_generics(lx, sc), .fields = each(crate::check::errors::range0(len(pts)), [&](const Nat& i) {
        return std::tuple{or_(index(each(names, [&](const std::tuple<Text, bool>& _p0) {
            auto&& n = std::get<0>(_p0);
            return n;
        }), i), Text::lit("arg")), or_(index(pts, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))};
    }), .ret = crate::lower::types::out_ty_of(lx, crate::lower::types::peel(res)), .body = body, .doc = crate::lower::functions::signature_text(lx, qk)};
}


prism_rtl::Turn<crate::lower::model::JobDef> JobDefOf::cycle() const {
    const auto& lx = this->lx;
    const auto& qk = this->qk;
    const auto& clauses = this->clauses;
    const auto& sc = this->sc;
    auto [ptys, res] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::check::types::Ty>, crate::check::types::Ty>> _v;
        auto&& _m = sc.ty;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            auto&& r = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
            _v.set(std::tuple{ps, r});
            goto _done;
        }
        {
            auto&& other = _m;
            _v.set(std::tuple{Array<crate::check::types::Ty>{}, other});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto clauses_1 = clauses;
    auto lx_2 = lx;
    auto qk_3 = qk;
    auto sc_4 = sc;
    return call_value(each_job(ptys, ({
        auto lx_2_5 = lx_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return ({
            auto lx_2_5_5 = lx_2_5;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(crate::lower::types::OutTyOf(lx_2_5_5, crate::lower::types::peel(p_)))));
            });
        }));
        });
    })));
    })), [=](Array<crate::lower::model::OutTy> each_32061) {
        return ({
            auto pts = each_32061;
            auto names = crate::lower::functions::param_names(lx_2, clauses_1, pts);
            call_then(start_job_clauses(lx_2, clauses_1, names, ptys, pts), [=](crate::lower::model::Ex job_clauses_32157) {
            return ({
                auto body = job_clauses_32157;
                auto base = or_(crate::prelude::get(lx_2.rs_names, qk_3), crate::lower::snake(crate::check::types::bare_name(qk_3)));
                call_then(crate::lower::types::start_out_ty_of(lx_2, crate::lower::types::peel(res)), [=](crate::lower::model::OutTy out_ty_of_32468) {
                return prism_rtl::finished(crate::lower::model::JobDef{.name = crate::lower::camel(crate::check::types::bare_name(qk_3)), .start = prism_rtl::cat("start_", base), .generics = crate::lower::functions::scheme_generics(lx_2, sc_4), .fields = each(crate::check::errors::range0(len(pts)), [&](const Nat& i) {
                    return std::tuple{or_(index(each(names, [&](const std::tuple<Text, bool>& _p0) {
                        auto&& n = std::get<0>(_p0);
                        return n;
                    }), i), Text::lit("arg")), or_(index(pts, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))};
                }), .ret = out_ty_of_32468, .body = body, .doc = crate::lower::functions::signature_text(lx_2, qk_3)});
            });
            });
        });
        });
    });
}


/// `Start JobDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::JobDef> start_job_def_of(crate::lower::Lx lx, Text qk, Array<crate::syntax::decls::FnClause> clauses, crate::check::types::Scheme sc) {
    return prism_rtl::make_rc<JobDefOf>(lx, qk, clauses, sc);
}


/// JobClauses: unbounded fn Lx, [FnClause], [((Text, Bool))], [Ty], [OutTy] -> Ex
crate::lower::model::Ex job_clauses(const crate::lower::Lx& lx, const Array<crate::syntax::decls::FnClause>& clauses, const Array<std::tuple<Text, bool>>& names, const Array<crate::check::types::Ty>& ptys, const Array<crate::lower::model::OutTy>& pts) {
    auto lets = each(crate::check::errors::range0(len(names)), [&](const Nat& i) {
        return ({
            auto&& _rs = or_(index(names, i), std::tuple{Text::lit("arg"), true});
            auto&& rs = std::get<0>(_rs);
            (crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{rs}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), rs}))})}));
        });
    });
    auto inner = crate::lower::functions::clauses_body(lx, crate::lower::types::empty_env(), clauses, names, ptys, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody>)>>(prism_rtl::rc([&](std::tuple<crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody> _p0) {
        auto&& a0 = std::get<0>(_p0);
        auto&& a1 = std::get<1>(_p0);
        auto&& a2 = std::get<2>(_p0);
        return entered(start_tail_body(a0, a1, a2));
    })), Text::lit("j"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{Text::lit("the job\'s turn")}));
    return crate::lower::model::Ex(crate::lower::model::Ex::XBlock{lets, prism_rtl::rc(inner)});
}


prism_rtl::Turn<crate::lower::model::Ex> JobClauses::cycle() const {
    const auto& lx = this->lx;
    const auto& clauses = this->clauses;
    const auto& names = this->names;
    const auto& ptys = this->ptys;
    const auto& pts = this->pts;
    auto lets = each(crate::check::errors::range0(len(names)), [&](const Nat& i) {
        return ({
            auto&& _rs = or_(index(names, i), std::tuple{Text::lit("arg"), true});
            auto&& rs = std::get<0>(_rs);
            (crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{rs}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), rs}))})}));
        });
    });
    auto clauses_1 = clauses;
    auto lx_2 = lx;
    auto names_3 = names;
    auto ptys_4 = ptys;
    return call_then(crate::lower::functions::start_clauses_body(lx_2, crate::lower::types::empty_env(), clauses_1, names_3, ptys_4, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody>)>>(prism_rtl::rc([&](std::tuple<crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody> _p0) {
        auto&& a0 = std::get<0>(_p0);
        auto&& a1 = std::get<1>(_p0);
        auto&& a2 = std::get<2>(_p0);
        return entered(start_tail_body(a0, a1, a2));
    })), Text::lit("j"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{Text::lit("the job\'s turn")})), [=](crate::lower::model::Ex clauses_body_32897) {
        return ({
            auto inner = clauses_body_32897;
            (prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XBlock{lets, prism_rtl::rc(inner)})));
        });
    });
}


/// `Start JobClauses, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_job_clauses(crate::lower::Lx lx, Array<crate::syntax::decls::FnClause> clauses, Array<std::tuple<Text, bool>> names, Array<crate::check::types::Ty> ptys, Array<crate::lower::model::OutTy> pts) {
    return prism_rtl::make_rc<JobClauses>(lx, clauses, names, ptys, pts);
}

}  // namespace crate::lower::jobs
