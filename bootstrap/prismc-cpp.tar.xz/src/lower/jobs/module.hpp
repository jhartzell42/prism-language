// The module `Lower.Jobs`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <lower/jobs/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace lower::jobs {

crate::lower::model::Ex tail(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2);

prism_rtl::JobRef<crate::lower::model::Ex> start_tail(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2);

crate::lower::model::Ex tail_here(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2);

prism_rtl::JobRef<crate::lower::model::Ex> start_tail_here(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2);

crate::lower::model::Ex tail_block(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Block& b_p2);

prism_rtl::JobRef<crate::lower::model::Ex> start_tail_block(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Block b_p2);

crate::lower::model::Ex tail_from(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Block& b_p2, const Nat& i_p3);

prism_rtl::JobRef<crate::lower::model::Ex> start_tail_from(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Block b_p2, Nat i_p3);

bool has_top_while(const crate::lower::Lx& lx_p0, const crate::syntax::Block& b_p1);

bool is_cycle_while(const crate::lower::Lx& lx_p0, const crate::syntax::Stmt& st_p1);

bool else_has_top_while(const crate::lower::Lx& lx_p0, const std::optional<crate::syntax::Block>& opt1);

bool holds_cycle_while(const crate::lower::Lx& lx_p0, const crate::syntax::Stmt& st_p1);

crate::lower::model::Ex upd_tail(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& target_p2, const crate::syntax::Block& b_p3, const crate::syntax::Range& to_p4, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)>& cont_f5);

prism_rtl::JobRef<crate::lower::model::Ex> start_upd_tail(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr target_p2, crate::syntax::Block b_p3, crate::syntax::Range to_p4, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)> cont_f5);

crate::lower::model::Ex upd_tail_from(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& outer_p1, const crate::lower::types::Env& env_p2, const crate::syntax::Block& b_p3, const Nat& i_p4, const crate::syntax::Range& to_p5, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)>& cont_f6);

prism_rtl::JobRef<crate::lower::model::Ex> start_upd_tail_from(crate::lower::Lx lx_p0, crate::lower::types::Env outer_p1, crate::lower::types::Env env_p2, crate::syntax::Block b_p3, Nat i_p4, crate::syntax::Range to_p5, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)> cont_f6);

crate::lower::model::Ex stmt_job(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& outer_p1, const crate::lower::types::Env& env_p2, const crate::syntax::Stmt& s_p3, const Text& rest_p4, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)>& cont_f5);

prism_rtl::JobRef<crate::lower::model::Ex> start_stmt_job(crate::lower::Lx lx_p0, crate::lower::types::Env outer_p1, crate::lower::types::Env env_p2, crate::syntax::Stmt s_p3, Text rest_p4, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)> cont_f5);

crate::lower::model::Ex prepend(const Array<crate::lower::model::Do>& dos_p0, const crate::lower::model::Ex& ex1);

crate::lower::model::Ex while_job(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& outer_p1, const crate::lower::types::Env& env_p2, const crate::syntax::Cond& c_p3, const crate::syntax::Block& wb_p4, const crate::syntax::Range& span_p5, const Text& rest_text_p6, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)>& cont_f7);

prism_rtl::JobRef<crate::lower::model::Ex> start_while_job(crate::lower::Lx lx_p0, crate::lower::types::Env outer_p1, crate::lower::types::Env env_p2, crate::syntax::Cond c_p3, crate::syntax::Block wb_p4, crate::syntax::Range span_p5, Text rest_text_p6, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)> cont_f7);

crate::lower::model::Ex stmts_then(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Block& b_p2, const crate::lower::model::Ex& last_p3);

prism_rtl::JobRef<crate::lower::model::Ex> start_stmts_then(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Block b_p2, crate::lower::model::Ex last_p3);

crate::lower::model::Ex if_job(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& outer_p1, const crate::lower::types::Env& env_p2, const crate::syntax::Cond& c_p3, const crate::syntax::Block& then_b_p4, const std::optional<crate::syntax::Block>& else_b_o5, const crate::syntax::Range& span_p6, const Text& rest_text_p7, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)>& cont_f8);

prism_rtl::JobRef<crate::lower::model::Ex> start_if_job(crate::lower::Lx lx_p0, crate::lower::types::Env outer_p1, crate::lower::types::Env env_p2, crate::syntax::Cond c_p3, crate::syntax::Block then_b_p4, std::optional<crate::syntax::Block> else_b_o5, crate::syntax::Range span_p6, Text rest_text_p7, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)> cont_f8);

crate::lower::model::Ex match_job(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& outer_p1, const crate::lower::types::Env& env_p2, const crate::syntax::Expr& scrut_p3, const Array<crate::syntax::Arm>& arms_p4, const crate::syntax::Range& span_p5, const Text& rest_text_p6, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)>& cont_f7);

prism_rtl::JobRef<crate::lower::model::Ex> start_match_job(crate::lower::Lx lx_p0, crate::lower::types::Env outer_p1, crate::lower::types::Env env_p2, crate::syntax::Expr scrut_p3, Array<crate::syntax::Arm> arms_p4, crate::syntax::Range span_p5, Text rest_text_p6, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)> cont_f7);

crate::lower::model::Ex for_job(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& outer_p1, const crate::lower::types::Env& env_p2, const std::optional<crate::syntax::ForBinders>& binders_o3, const crate::syntax::Expr& source_p4, const crate::syntax::Block& body_p5, const crate::syntax::Range& span_p6, const Text& rest_text_p7, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)>& cont_f8);

prism_rtl::JobRef<crate::lower::model::Ex> start_for_job(crate::lower::Lx lx_p0, crate::lower::types::Env outer_p1, crate::lower::types::Env env_p2, std::optional<crate::syntax::ForBinders> binders_o3, crate::syntax::Expr source_p4, crate::syntax::Block body_p5, crate::syntax::Range span_p6, Text rest_text_p7, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)> cont_f8);

Text instance_of(const Text& k_p0);

Array<std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>> caps_in(const crate::lower::types::Env& env_p0, const Text& text_p1, const Array<Text>& skip_p2);

std::optional<crate::syntax::Expr> frame_call(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2, const bool& top_p3);

prism_rtl::JobRef<std::optional<crate::syntax::Expr>> start_frame_call(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2, bool top_p3);

Array<crate::syntax::Expr> placeholders(const Array<crate::syntax::TextSeg>& segs_p0);

std::optional<crate::syntax::Expr> first_frame(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Array<crate::syntax::Expr>& es_p2);

prism_rtl::JobRef<std::optional<crate::syntax::Expr>> start_first_frame(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Array<crate::syntax::Expr> es_p2);

crate::lower::model::Ex frame(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& call_p2, const Text& rest_text_p3, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::lower::types::Env)>& cont_f4);

prism_rtl::JobRef<crate::lower::model::Ex> start_frame(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr call_p2, Text rest_text_p3, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::lower::types::Env)> cont_f4);

std::optional<crate::lower::types::Vl> local_job_fn(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& c_p2);

prism_rtl::JobRef<std::optional<crate::lower::types::Vl>> start_local_job_fn(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr c_p2);

std::optional<crate::lower::types::Vl> job_value(const crate::lower::types::Vl& f_p0);

crate::lower::model::Ex start_call(const crate::lower::types::Vl& f_p0, const Array<crate::lower::model::Ex>& vals_p1);

crate::lower::model::Ex one_or_tuple(const Array<crate::lower::model::Ex>& xs0);

Text callee_text(const crate::syntax::Expr& c_p0);

Text rest_text(const crate::lower::Lx& lx_p0, const crate::syntax::Range& from_p1, const crate::syntax::Range& call_p2, const crate::syntax::Range& to_p3);

bool mentions(const Text& text_p0, const Text& name_p1);

bool ends_ident(const Text& t_p0);

bool starts_ident(const Text& t_p0);

crate::lower::model::Ex tail_body(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::decls::FnBody& fn_body2);

prism_rtl::JobRef<crate::lower::model::Ex> start_tail_body(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::decls::FnBody fn_body2);

crate::lower::model::Ex tail_match(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& s_p2, const Array<crate::syntax::Arm>& arms_p3, const crate::syntax::Range& span_p4);

prism_rtl::JobRef<crate::lower::model::Ex> start_tail_match(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr s_p2, Array<crate::syntax::Arm> arms_p3, crate::syntax::Range span_p4);

std::optional<Text> tail_callee(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& callee_p2);

std::tuple<Array<crate::check::types::Ty>, crate::check::types::Ty> scheme_parts(const crate::lower::Lx& lx_p0, const Text& qk_p1);

Array<Text> job_field_names(const crate::lower::Lx& lx_p0, const Text& qk_p1);

prism_rtl::JobRef<Array<Text>> start_job_field_names(crate::lower::Lx lx_p0, Text qk_p1);

Array<crate::syntax::decls::FnClause> clauses_of(const crate::check::env::G& g_p0, const Text& qk_p1);

Array<crate::syntax::decls::FnClause> def_clauses(const crate::check::env::Def& d_p0, const Array<crate::syntax::decls::FnClause>& other_p1);

crate::lower::model::JobDef job_def_of(const crate::lower::Lx& lx_p0, const Text& qk_p1, const Array<crate::syntax::decls::FnClause>& clauses_p2, const crate::check::types::Scheme& sc_p3);

prism_rtl::JobRef<crate::lower::model::JobDef> start_job_def_of(crate::lower::Lx lx_p0, Text qk_p1, Array<crate::syntax::decls::FnClause> clauses_p2, crate::check::types::Scheme sc_p3);

crate::lower::model::Ex job_clauses(const crate::lower::Lx& lx_p0, const Array<crate::syntax::decls::FnClause>& clauses_p1, const Array<std::tuple<Text, bool>>& names_p2, const Array<crate::check::types::Ty>& ptys_p3, const Array<crate::lower::model::OutTy>& pts_p4);

prism_rtl::JobRef<crate::lower::model::Ex> start_job_clauses(crate::lower::Lx lx_p0, Array<crate::syntax::decls::FnClause> clauses_p1, Array<std::tuple<Text, bool>> names_p2, Array<crate::check::types::Ty> ptys_p3, Array<crate::lower::model::OutTy> pts_p4);

}  // namespace lower::jobs


namespace lower::jobs {

/// The step machine of `Tail`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Tail: unbounded fn Lx, Env, Expr -> Ex
struct Tail : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Expr e_p2;
    Tail(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), e_p2(std::move(e_p2)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `TailHere`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TailHere: unbounded fn Lx, Env, Expr -> Ex
struct TailHere : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Expr e_p2;
    TailHere(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), e_p2(std::move(e_p2)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `TailBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TailBlock: unbounded fn Lx, Env, Block -> Ex
struct TailBlock : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Block b_p2;
    TailBlock(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Block b_p2) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), b_p2(std::move(b_p2)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `TailFrom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TailFrom: unbounded fn Lx, Env, Block, Nat -> Ex
struct TailFrom : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Block b_p2;
    Nat i_p3;
    TailFrom(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Block b_p2, Nat i_p3) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), b_p2(std::move(b_p2)), i_p3(std::move(i_p3)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `UpdTail`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdTail: unbounded fn Lx, Env, Expr, Block, Range, (unbounded fn Env, Ex -> Ex) -> Ex
struct UpdTail : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Expr target_p2;
    crate::syntax::Block b_p3;
    crate::syntax::Range to_p4;
    prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)> cont_f5;
    UpdTail(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr target_p2, crate::syntax::Block b_p3, crate::syntax::Range to_p4, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)> cont_f5) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), target_p2(std::move(target_p2)), b_p3(std::move(b_p3)), to_p4(std::move(to_p4)), cont_f5(std::move(cont_f5)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `UpdTailFrom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdTailFrom: unbounded fn Lx, Env, Env, Block, Nat, Range, (unbounded fn Env, Ex -> Ex) -> Ex
struct UpdTailFrom : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env outer_p1;
    crate::lower::types::Env env_p2;
    crate::syntax::Block b_p3;
    Nat i_p4;
    crate::syntax::Range to_p5;
    prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)> cont_f6;
    UpdTailFrom(crate::lower::Lx lx_p0, crate::lower::types::Env outer_p1, crate::lower::types::Env env_p2, crate::syntax::Block b_p3, Nat i_p4, crate::syntax::Range to_p5, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)> cont_f6) : lx_p0(std::move(lx_p0)), outer_p1(std::move(outer_p1)), env_p2(std::move(env_p2)), b_p3(std::move(b_p3)), i_p4(std::move(i_p4)), to_p5(std::move(to_p5)), cont_f6(std::move(cont_f6)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `StmtJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StmtJob: unbounded fn Lx, Env, Env, Stmt, Text, (unbounded fn Env, Env -> Ex) -> Ex
struct StmtJob : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env outer_p1;
    crate::lower::types::Env env_p2;
    crate::syntax::Stmt s_p3;
    Text rest_p4;
    prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)> cont_f5;
    StmtJob(crate::lower::Lx lx_p0, crate::lower::types::Env outer_p1, crate::lower::types::Env env_p2, crate::syntax::Stmt s_p3, Text rest_p4, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)> cont_f5) : lx_p0(std::move(lx_p0)), outer_p1(std::move(outer_p1)), env_p2(std::move(env_p2)), s_p3(std::move(s_p3)), rest_p4(std::move(rest_p4)), cont_f5(std::move(cont_f5)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `WhileJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WhileJob: unbounded fn Lx, Env, Env, Cond, Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
struct WhileJob : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env outer_p1;
    crate::lower::types::Env env_p2;
    crate::syntax::Cond c_p3;
    crate::syntax::Block wb_p4;
    crate::syntax::Range span_p5;
    Text rest_text_p6;
    prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)> cont_f7;
    WhileJob(crate::lower::Lx lx_p0, crate::lower::types::Env outer_p1, crate::lower::types::Env env_p2, crate::syntax::Cond c_p3, crate::syntax::Block wb_p4, crate::syntax::Range span_p5, Text rest_text_p6, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)> cont_f7) : lx_p0(std::move(lx_p0)), outer_p1(std::move(outer_p1)), env_p2(std::move(env_p2)), c_p3(std::move(c_p3)), wb_p4(std::move(wb_p4)), span_p5(std::move(span_p5)), rest_text_p6(std::move(rest_text_p6)), cont_f7(std::move(cont_f7)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `StmtsThen`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StmtsThen: unbounded fn Lx, Env, Block, Ex -> Ex
struct StmtsThen : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Block b_p2;
    crate::lower::model::Ex last_p3;
    StmtsThen(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Block b_p2, crate::lower::model::Ex last_p3) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), b_p2(std::move(b_p2)), last_p3(std::move(last_p3)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `IfJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IfJob: unbounded fn Lx, Env, Env, Cond, Block, ?Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
struct IfJob : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env outer_p1;
    crate::lower::types::Env env_p2;
    crate::syntax::Cond c_p3;
    crate::syntax::Block then_b_p4;
    std::optional<crate::syntax::Block> else_b_o5;
    crate::syntax::Range span_p6;
    Text rest_text_p7;
    prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)> cont_f8;
    IfJob(crate::lower::Lx lx_p0, crate::lower::types::Env outer_p1, crate::lower::types::Env env_p2, crate::syntax::Cond c_p3, crate::syntax::Block then_b_p4, std::optional<crate::syntax::Block> else_b_o5, crate::syntax::Range span_p6, Text rest_text_p7, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)> cont_f8) : lx_p0(std::move(lx_p0)), outer_p1(std::move(outer_p1)), env_p2(std::move(env_p2)), c_p3(std::move(c_p3)), then_b_p4(std::move(then_b_p4)), else_b_o5(std::move(else_b_o5)), span_p6(std::move(span_p6)), rest_text_p7(std::move(rest_text_p7)), cont_f8(std::move(cont_f8)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `MatchJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MatchJob: unbounded fn Lx, Env, Env, Expr, [Arm], Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
struct MatchJob : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env outer_p1;
    crate::lower::types::Env env_p2;
    crate::syntax::Expr scrut_p3;
    Array<crate::syntax::Arm> arms_p4;
    crate::syntax::Range span_p5;
    Text rest_text_p6;
    prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)> cont_f7;
    MatchJob(crate::lower::Lx lx_p0, crate::lower::types::Env outer_p1, crate::lower::types::Env env_p2, crate::syntax::Expr scrut_p3, Array<crate::syntax::Arm> arms_p4, crate::syntax::Range span_p5, Text rest_text_p6, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)> cont_f7) : lx_p0(std::move(lx_p0)), outer_p1(std::move(outer_p1)), env_p2(std::move(env_p2)), scrut_p3(std::move(scrut_p3)), arms_p4(std::move(arms_p4)), span_p5(std::move(span_p5)), rest_text_p6(std::move(rest_text_p6)), cont_f7(std::move(cont_f7)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `ForJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ForJob: unbounded fn Lx, Env, Env, ?ForBinders, Expr, Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
struct ForJob : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env outer_p1;
    crate::lower::types::Env env_p2;
    std::optional<crate::syntax::ForBinders> binders_o3;
    crate::syntax::Expr source_p4;
    crate::syntax::Block body_p5;
    crate::syntax::Range span_p6;
    Text rest_text_p7;
    prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)> cont_f8;
    ForJob(crate::lower::Lx lx_p0, crate::lower::types::Env outer_p1, crate::lower::types::Env env_p2, std::optional<crate::syntax::ForBinders> binders_o3, crate::syntax::Expr source_p4, crate::syntax::Block body_p5, crate::syntax::Range span_p6, Text rest_text_p7, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)> cont_f8) : lx_p0(std::move(lx_p0)), outer_p1(std::move(outer_p1)), env_p2(std::move(env_p2)), binders_o3(std::move(binders_o3)), source_p4(std::move(source_p4)), body_p5(std::move(body_p5)), span_p6(std::move(span_p6)), rest_text_p7(std::move(rest_text_p7)), cont_f8(std::move(cont_f8)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `FrameCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?FrameCall: unbounded fn Lx, Env, Expr, Bool -> ?Expr
struct FrameCall : prism_rtl::Job<std::optional<crate::syntax::Expr>> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Expr e_p2;
    bool top_p3;
    FrameCall(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2, bool top_p3) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), e_p2(std::move(e_p2)), top_p3(std::move(top_p3)) {}
    prism_rtl::Turn<std::optional<crate::syntax::Expr>> cycle() const override;
};


/// The step machine of `FirstFrame`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?FirstFrame: unbounded fn Lx, Env, [Expr] -> ?Expr
struct FirstFrame : prism_rtl::Job<std::optional<crate::syntax::Expr>> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    Array<crate::syntax::Expr> es_p2;
    FirstFrame(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Array<crate::syntax::Expr> es_p2) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), es_p2(std::move(es_p2)) {}
    prism_rtl::Turn<std::optional<crate::syntax::Expr>> cycle() const override;
};


/// The step machine of `Frame`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Frame: unbounded fn Lx, Env, Expr, Text, (unbounded fn Env -> Ex) -> Ex
struct Frame : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Expr call_p2;
    Text rest_text_p3;
    prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::lower::types::Env)> cont_f4;
    Frame(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr call_p2, Text rest_text_p3, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::lower::types::Env)> cont_f4) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), call_p2(std::move(call_p2)), rest_text_p3(std::move(rest_text_p3)), cont_f4(std::move(cont_f4)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `LocalJobFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?LocalJobFn: unbounded fn Lx, Env, Expr -> ?Vl
struct LocalJobFn : prism_rtl::Job<std::optional<crate::lower::types::Vl>> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Expr c_p2;
    LocalJobFn(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr c_p2) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), c_p2(std::move(c_p2)) {}
    prism_rtl::Turn<std::optional<crate::lower::types::Vl>> cycle() const override;
};


/// The step machine of `TailBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TailBody: unbounded fn Lx, Env, FnBody -> Ex
struct TailBody : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::decls::FnBody fn_body2;
    TailBody(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::decls::FnBody fn_body2) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), fn_body2(std::move(fn_body2)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `TailMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TailMatch: unbounded fn Lx, Env, Expr, [Arm], Range -> Ex
struct TailMatch : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Expr s_p2;
    Array<crate::syntax::Arm> arms_p3;
    crate::syntax::Range span_p4;
    TailMatch(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr s_p2, Array<crate::syntax::Arm> arms_p3, crate::syntax::Range span_p4) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), s_p2(std::move(s_p2)), arms_p3(std::move(arms_p3)), span_p4(std::move(span_p4)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `JobFieldNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// JobFieldNames: unbounded fn Lx, Text -> [Text]
struct JobFieldNames : prism_rtl::Job<Array<Text>> {
    crate::lower::Lx lx_p0;
    Text qk_p1;
    JobFieldNames(crate::lower::Lx lx_p0, Text qk_p1) : lx_p0(std::move(lx_p0)), qk_p1(std::move(qk_p1)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `JobDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// JobDefOf: unbounded fn Lx, Text, [FnClause], Scheme -> JobDef
struct JobDefOf : prism_rtl::Job<crate::lower::model::JobDef> {
    crate::lower::Lx lx_p0;
    Text qk_p1;
    Array<crate::syntax::decls::FnClause> clauses_p2;
    crate::check::types::Scheme sc_p3;
    JobDefOf(crate::lower::Lx lx_p0, Text qk_p1, Array<crate::syntax::decls::FnClause> clauses_p2, crate::check::types::Scheme sc_p3) : lx_p0(std::move(lx_p0)), qk_p1(std::move(qk_p1)), clauses_p2(std::move(clauses_p2)), sc_p3(std::move(sc_p3)) {}
    prism_rtl::Turn<crate::lower::model::JobDef> cycle() const override;
};


/// The step machine of `JobClauses`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// JobClauses: unbounded fn Lx, [FnClause], [((Text, Bool))], [Ty], [OutTy] -> Ex
struct JobClauses : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx_p0;
    Array<crate::syntax::decls::FnClause> clauses_p1;
    Array<std::tuple<Text, bool>> names_p2;
    Array<crate::check::types::Ty> ptys_p3;
    Array<crate::lower::model::OutTy> pts_p4;
    JobClauses(crate::lower::Lx lx_p0, Array<crate::syntax::decls::FnClause> clauses_p1, Array<std::tuple<Text, bool>> names_p2, Array<crate::check::types::Ty> ptys_p3, Array<crate::lower::model::OutTy> pts_p4) : lx_p0(std::move(lx_p0)), clauses_p1(std::move(clauses_p1)), names_p2(std::move(names_p2)), ptys_p3(std::move(ptys_p3)), pts_p4(std::move(pts_p4)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


}  // namespace lower::jobs

}  // namespace crate
