// The module `Lower.Jobs`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <lower/jobs/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace lower::jobs {

crate::lower::model::Ex tail(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& e);

prism_rtl::JobRef<crate::lower::model::Ex> start_tail(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e);

crate::lower::model::Ex tail_here(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& e);

prism_rtl::JobRef<crate::lower::model::Ex> start_tail_here(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e);

crate::lower::model::Ex tail_block(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Block& b);

prism_rtl::JobRef<crate::lower::model::Ex> start_tail_block(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Block b);

crate::lower::model::Ex tail_from(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Block& b, const Nat& i);

prism_rtl::JobRef<crate::lower::model::Ex> start_tail_from(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Block b, Nat i);

bool has_top_while(const crate::lower::Lx& lx, const crate::syntax::Block& b);

bool is_cycle_while(const crate::lower::Lx& lx, const crate::syntax::Stmt& st);

bool else_has_top_while(const crate::lower::Lx& lx, const std::optional<crate::syntax::Block>& opt1);

bool holds_cycle_while(const crate::lower::Lx& lx, const crate::syntax::Stmt& st);

crate::lower::model::Ex upd_tail(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& target, const crate::syntax::Block& b, const crate::syntax::Range& to, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)>& cont_fn);

prism_rtl::JobRef<crate::lower::model::Ex> start_upd_tail(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr target, crate::syntax::Block b, crate::syntax::Range to, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)> cont_fn);

crate::lower::model::Ex upd_tail_from(const crate::lower::Lx& lx, const crate::lower::types::Env& outer, const crate::lower::types::Env& env, const crate::syntax::Block& b, const Nat& i, const crate::syntax::Range& to, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)>& cont_fn);

prism_rtl::JobRef<crate::lower::model::Ex> start_upd_tail_from(crate::lower::Lx lx, crate::lower::types::Env outer, crate::lower::types::Env env, crate::syntax::Block b, Nat i, crate::syntax::Range to, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)> cont_fn);

crate::lower::model::Ex stmt_job(const crate::lower::Lx& lx, const crate::lower::types::Env& outer, const crate::lower::types::Env& env, const crate::syntax::Stmt& s, const Text& rest, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)>& cont_fn);

prism_rtl::JobRef<crate::lower::model::Ex> start_stmt_job(crate::lower::Lx lx, crate::lower::types::Env outer, crate::lower::types::Env env, crate::syntax::Stmt s, Text rest, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)> cont_fn);

crate::lower::model::Ex prepend(const Array<crate::lower::model::Do>& dos, const crate::lower::model::Ex& ex1);

crate::lower::model::Ex while_job(const crate::lower::Lx& lx, const crate::lower::types::Env& outer, const crate::lower::types::Env& env, const crate::syntax::Cond& c, const crate::syntax::Block& wb, const crate::syntax::Range& span, const Text& rest_text_, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)>& cont_fn);

prism_rtl::JobRef<crate::lower::model::Ex> start_while_job(crate::lower::Lx lx, crate::lower::types::Env outer, crate::lower::types::Env env, crate::syntax::Cond c, crate::syntax::Block wb, crate::syntax::Range span, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)> cont_fn);

crate::lower::model::Ex stmts_then(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Block& b, const crate::lower::model::Ex& last);

prism_rtl::JobRef<crate::lower::model::Ex> start_stmts_then(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Block b, crate::lower::model::Ex last);

crate::lower::model::Ex if_job(const crate::lower::Lx& lx, const crate::lower::types::Env& outer, const crate::lower::types::Env& env, const crate::syntax::Cond& c, const crate::syntax::Block& then_b, const std::optional<crate::syntax::Block>& else_b_opt, const crate::syntax::Range& span, const Text& rest_text_, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)>& cont_fn);

prism_rtl::JobRef<crate::lower::model::Ex> start_if_job(crate::lower::Lx lx, crate::lower::types::Env outer, crate::lower::types::Env env, crate::syntax::Cond c, crate::syntax::Block then_b, std::optional<crate::syntax::Block> else_b_opt, crate::syntax::Range span, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)> cont_fn);

crate::lower::model::Ex match_job(const crate::lower::Lx& lx, const crate::lower::types::Env& outer, const crate::lower::types::Env& env, const crate::syntax::Expr& scrut, const Array<crate::syntax::Arm>& arms, const crate::syntax::Range& span, const Text& rest_text_, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)>& cont_fn);

prism_rtl::JobRef<crate::lower::model::Ex> start_match_job(crate::lower::Lx lx, crate::lower::types::Env outer, crate::lower::types::Env env, crate::syntax::Expr scrut, Array<crate::syntax::Arm> arms, crate::syntax::Range span, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)> cont_fn);

crate::lower::model::Ex for_job(const crate::lower::Lx& lx, const crate::lower::types::Env& outer, const crate::lower::types::Env& env, const std::optional<crate::syntax::ForBinders>& binders_opt, const crate::syntax::Expr& source, const crate::syntax::Block& body, const crate::syntax::Range& span, const Text& rest_text_, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)>& cont_fn);

prism_rtl::JobRef<crate::lower::model::Ex> start_for_job(crate::lower::Lx lx, crate::lower::types::Env outer, crate::lower::types::Env env, std::optional<crate::syntax::ForBinders> binders_opt, crate::syntax::Expr source, crate::syntax::Block body, crate::syntax::Range span, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)> cont_fn);

Text instance_of(const Text& k);

Array<std::tuple<Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy>> caps_in(const crate::lower::types::Env& env, const Text& text, const Array<Text>& skip);

std::optional<crate::syntax::Expr> frame_call(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& e, const bool& top);

prism_rtl::JobRef<std::optional<crate::syntax::Expr>> start_frame_call(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e, bool top);

Array<crate::syntax::Expr> placeholders(const Array<crate::syntax::TextSeg>& segs);

std::optional<crate::syntax::Expr> first_frame(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const Array<crate::syntax::Expr>& es);

prism_rtl::JobRef<std::optional<crate::syntax::Expr>> start_first_frame(crate::lower::Lx lx, crate::lower::types::Env env, Array<crate::syntax::Expr> es);

crate::lower::model::Ex frame(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& call, const Text& rest_text_, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::lower::types::Env)>& cont_fn);

prism_rtl::JobRef<crate::lower::model::Ex> start_frame(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr call, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::lower::types::Env)> cont_fn);

std::optional<crate::lower::types::Vl> local_job_fn(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& c);

prism_rtl::JobRef<std::optional<crate::lower::types::Vl>> start_local_job_fn(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr c);

std::optional<crate::lower::types::Vl> job_value(const crate::lower::types::Vl& f);

crate::lower::model::Ex start_call(const crate::lower::types::Vl& f, const Array<crate::lower::model::Ex>& vals);

crate::lower::model::Ex one_or_tuple(const Array<crate::lower::model::Ex>& xs0);

Text callee_text(const crate::syntax::Expr& c);

Text rest_text(const crate::lower::Lx& lx, const crate::syntax::Range& from, const crate::syntax::Range& call, const crate::syntax::Range& to);

bool mentions(const Text& text, const Text& name);

bool ends_ident(const Text& t);

bool starts_ident(const Text& t);

crate::lower::model::Ex tail_body(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::decls::FnBody& fn_body2);

prism_rtl::JobRef<crate::lower::model::Ex> start_tail_body(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::decls::FnBody fn_body2);

crate::lower::model::Ex tail_match(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& s, const Array<crate::syntax::Arm>& arms, const crate::syntax::Range& span);

prism_rtl::JobRef<crate::lower::model::Ex> start_tail_match(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr s, Array<crate::syntax::Arm> arms, crate::syntax::Range span);

std::optional<Text> tail_callee(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& callee);

std::tuple<Array<crate::check::types::Ty>, crate::check::types::Ty> scheme_parts(const crate::lower::Lx& lx, const Text& qk);

Array<Text> job_field_names(const crate::lower::Lx& lx, const Text& qk);

prism_rtl::JobRef<Array<Text>> start_job_field_names(crate::lower::Lx lx, Text qk);

Array<crate::syntax::decls::FnClause> clauses_of(const crate::check::env::G& g, const Text& qk);

Array<crate::syntax::decls::FnClause> def_clauses(const crate::check::env::Def& d, const Array<crate::syntax::decls::FnClause>& other);

crate::lower::model::JobDef job_def_of(const crate::lower::Lx& lx, const Text& qk, const Array<crate::syntax::decls::FnClause>& clauses, const crate::check::types::Scheme& sc);

prism_rtl::JobRef<crate::lower::model::JobDef> start_job_def_of(crate::lower::Lx lx, Text qk, Array<crate::syntax::decls::FnClause> clauses, crate::check::types::Scheme sc);

crate::lower::model::Ex job_clauses(const crate::lower::Lx& lx, const Array<crate::syntax::decls::FnClause>& clauses, const Array<std::tuple<Text, bool>>& names, const Array<crate::check::types::Ty>& ptys, const Array<crate::lower::model::OutTy>& pts);

prism_rtl::JobRef<crate::lower::model::Ex> start_job_clauses(crate::lower::Lx lx, Array<crate::syntax::decls::FnClause> clauses, Array<std::tuple<Text, bool>> names, Array<crate::check::types::Ty> ptys, Array<crate::lower::model::OutTy> pts);

}  // namespace lower::jobs


namespace lower::jobs {

/// The step machine of `Tail`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Tail: unbounded fn Lx, Env, Expr -> Ex
struct Tail : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::Expr e;
    Tail(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `TailHere`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TailHere: unbounded fn Lx, Env, Expr -> Ex
struct TailHere : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::Expr e;
    TailHere(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `TailBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TailBlock: unbounded fn Lx, Env, Block -> Ex
struct TailBlock : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::Block b;
    TailBlock(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Block b) : lx(std::move(lx)), env(std::move(env)), b(std::move(b)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `TailFrom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TailFrom: unbounded fn Lx, Env, Block, Nat -> Ex
struct TailFrom : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::Block b;
    Nat i;
    TailFrom(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Block b, Nat i) : lx(std::move(lx)), env(std::move(env)), b(std::move(b)), i(std::move(i)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `UpdTail`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdTail: unbounded fn Lx, Env, Expr, Block, Range, (unbounded fn Env, Ex -> Ex) -> Ex
struct UpdTail : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::Expr target;
    crate::syntax::Block b;
    crate::syntax::Range to;
    prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)> cont_fn;
    UpdTail(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr target, crate::syntax::Block b, crate::syntax::Range to, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)> cont_fn) : lx(std::move(lx)), env(std::move(env)), target(std::move(target)), b(std::move(b)), to(std::move(to)), cont_fn(std::move(cont_fn)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `UpdTailFrom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdTailFrom: unbounded fn Lx, Env, Env, Block, Nat, Range, (unbounded fn Env, Ex -> Ex) -> Ex
struct UpdTailFrom : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx;
    crate::lower::types::Env outer;
    crate::lower::types::Env env;
    crate::syntax::Block b;
    Nat i;
    crate::syntax::Range to;
    prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)> cont_fn;
    UpdTailFrom(crate::lower::Lx lx, crate::lower::types::Env outer, crate::lower::types::Env env, crate::syntax::Block b, Nat i, crate::syntax::Range to, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::model::Ex>)> cont_fn) : lx(std::move(lx)), outer(std::move(outer)), env(std::move(env)), b(std::move(b)), i(std::move(i)), to(std::move(to)), cont_fn(std::move(cont_fn)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `StmtJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StmtJob: unbounded fn Lx, Env, Env, Stmt, Text, (unbounded fn Env, Env -> Ex) -> Ex
struct StmtJob : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx;
    crate::lower::types::Env outer;
    crate::lower::types::Env env;
    crate::syntax::Stmt s;
    Text rest;
    prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)> cont_fn;
    StmtJob(crate::lower::Lx lx, crate::lower::types::Env outer, crate::lower::types::Env env, crate::syntax::Stmt s, Text rest, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)> cont_fn) : lx(std::move(lx)), outer(std::move(outer)), env(std::move(env)), s(std::move(s)), rest(std::move(rest)), cont_fn(std::move(cont_fn)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `WhileJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WhileJob: unbounded fn Lx, Env, Env, Cond, Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
struct WhileJob : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx;
    crate::lower::types::Env outer;
    crate::lower::types::Env env;
    crate::syntax::Cond c;
    crate::syntax::Block wb;
    crate::syntax::Range span;
    Text rest_text_;
    prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)> cont_fn;
    WhileJob(crate::lower::Lx lx, crate::lower::types::Env outer, crate::lower::types::Env env, crate::syntax::Cond c, crate::syntax::Block wb, crate::syntax::Range span, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)> cont_fn) : lx(std::move(lx)), outer(std::move(outer)), env(std::move(env)), c(std::move(c)), wb(std::move(wb)), span(std::move(span)), rest_text_(std::move(rest_text_)), cont_fn(std::move(cont_fn)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `StmtsThen`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StmtsThen: unbounded fn Lx, Env, Block, Ex -> Ex
struct StmtsThen : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::Block b;
    crate::lower::model::Ex last;
    StmtsThen(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Block b, crate::lower::model::Ex last) : lx(std::move(lx)), env(std::move(env)), b(std::move(b)), last(std::move(last)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `IfJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IfJob: unbounded fn Lx, Env, Env, Cond, Block, ?Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
struct IfJob : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx;
    crate::lower::types::Env outer;
    crate::lower::types::Env env;
    crate::syntax::Cond c;
    crate::syntax::Block then_b;
    std::optional<crate::syntax::Block> else_b_opt;
    crate::syntax::Range span;
    Text rest_text_;
    prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)> cont_fn;
    IfJob(crate::lower::Lx lx, crate::lower::types::Env outer, crate::lower::types::Env env, crate::syntax::Cond c, crate::syntax::Block then_b, std::optional<crate::syntax::Block> else_b_opt, crate::syntax::Range span, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)> cont_fn) : lx(std::move(lx)), outer(std::move(outer)), env(std::move(env)), c(std::move(c)), then_b(std::move(then_b)), else_b_opt(std::move(else_b_opt)), span(std::move(span)), rest_text_(std::move(rest_text_)), cont_fn(std::move(cont_fn)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `MatchJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MatchJob: unbounded fn Lx, Env, Env, Expr, [Arm], Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
struct MatchJob : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx;
    crate::lower::types::Env outer;
    crate::lower::types::Env env;
    crate::syntax::Expr scrut;
    Array<crate::syntax::Arm> arms;
    crate::syntax::Range span;
    Text rest_text_;
    prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)> cont_fn;
    MatchJob(crate::lower::Lx lx, crate::lower::types::Env outer, crate::lower::types::Env env, crate::syntax::Expr scrut, Array<crate::syntax::Arm> arms, crate::syntax::Range span, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)> cont_fn) : lx(std::move(lx)), outer(std::move(outer)), env(std::move(env)), scrut(std::move(scrut)), arms(std::move(arms)), span(std::move(span)), rest_text_(std::move(rest_text_)), cont_fn(std::move(cont_fn)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `ForJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ForJob: unbounded fn Lx, Env, Env, ?ForBinders, Expr, Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
struct ForJob : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx;
    crate::lower::types::Env outer;
    crate::lower::types::Env env;
    std::optional<crate::syntax::ForBinders> binders_opt;
    crate::syntax::Expr source;
    crate::syntax::Block body;
    crate::syntax::Range span;
    Text rest_text_;
    prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)> cont_fn;
    ForJob(crate::lower::Lx lx, crate::lower::types::Env outer, crate::lower::types::Env env, std::optional<crate::syntax::ForBinders> binders_opt, crate::syntax::Expr source, crate::syntax::Block body, crate::syntax::Range span, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::types::Env, crate::lower::types::Env>)> cont_fn) : lx(std::move(lx)), outer(std::move(outer)), env(std::move(env)), binders_opt(std::move(binders_opt)), source(std::move(source)), body(std::move(body)), span(std::move(span)), rest_text_(std::move(rest_text_)), cont_fn(std::move(cont_fn)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `FrameCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?FrameCall: unbounded fn Lx, Env, Expr, Bool -> ?Expr
struct FrameCall : prism_rtl::Job<std::optional<crate::syntax::Expr>> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::Expr e;
    bool top;
    FrameCall(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e, bool top) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)), top(std::move(top)) {}
    prism_rtl::Turn<std::optional<crate::syntax::Expr>> cycle() const override;
};


/// The step machine of `FirstFrame`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?FirstFrame: unbounded fn Lx, Env, [Expr] -> ?Expr
struct FirstFrame : prism_rtl::Job<std::optional<crate::syntax::Expr>> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    Array<crate::syntax::Expr> es;
    FirstFrame(crate::lower::Lx lx, crate::lower::types::Env env, Array<crate::syntax::Expr> es) : lx(std::move(lx)), env(std::move(env)), es(std::move(es)) {}
    prism_rtl::Turn<std::optional<crate::syntax::Expr>> cycle() const override;
};


/// The step machine of `Frame`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Frame: unbounded fn Lx, Env, Expr, Text, (unbounded fn Env -> Ex) -> Ex
struct Frame : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::Expr call;
    Text rest_text_;
    prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::lower::types::Env)> cont_fn;
    Frame(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr call, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::lower::types::Env)> cont_fn) : lx(std::move(lx)), env(std::move(env)), call(std::move(call)), rest_text_(std::move(rest_text_)), cont_fn(std::move(cont_fn)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `LocalJobFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?LocalJobFn: unbounded fn Lx, Env, Expr -> ?Vl
struct LocalJobFn : prism_rtl::Job<std::optional<crate::lower::types::Vl>> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::Expr c;
    LocalJobFn(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr c) : lx(std::move(lx)), env(std::move(env)), c(std::move(c)) {}
    prism_rtl::Turn<std::optional<crate::lower::types::Vl>> cycle() const override;
};


/// The step machine of `TailBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TailBody: unbounded fn Lx, Env, FnBody -> Ex
struct TailBody : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::decls::FnBody fn_body2;
    TailBody(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::decls::FnBody fn_body2) : lx(std::move(lx)), env(std::move(env)), fn_body2(std::move(fn_body2)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `TailMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TailMatch: unbounded fn Lx, Env, Expr, [Arm], Range -> Ex
struct TailMatch : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::Expr s;
    Array<crate::syntax::Arm> arms;
    crate::syntax::Range span;
    TailMatch(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr s, Array<crate::syntax::Arm> arms, crate::syntax::Range span) : lx(std::move(lx)), env(std::move(env)), s(std::move(s)), arms(std::move(arms)), span(std::move(span)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `JobFieldNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// JobFieldNames: unbounded fn Lx, Text -> [Text]
struct JobFieldNames : prism_rtl::Job<Array<Text>> {
    crate::lower::Lx lx;
    Text qk;
    JobFieldNames(crate::lower::Lx lx, Text qk) : lx(std::move(lx)), qk(std::move(qk)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `JobDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// JobDefOf: unbounded fn Lx, Text, [FnClause], Scheme -> JobDef
struct JobDefOf : prism_rtl::Job<crate::lower::model::JobDef> {
    crate::lower::Lx lx;
    Text qk;
    Array<crate::syntax::decls::FnClause> clauses;
    crate::check::types::Scheme sc;
    JobDefOf(crate::lower::Lx lx, Text qk, Array<crate::syntax::decls::FnClause> clauses, crate::check::types::Scheme sc) : lx(std::move(lx)), qk(std::move(qk)), clauses(std::move(clauses)), sc(std::move(sc)) {}
    prism_rtl::Turn<crate::lower::model::JobDef> cycle() const override;
};


/// The step machine of `JobClauses`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// JobClauses: unbounded fn Lx, [FnClause], [((Text, Bool))], [Ty], [OutTy] -> Ex
struct JobClauses : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx;
    Array<crate::syntax::decls::FnClause> clauses;
    Array<std::tuple<Text, bool>> names;
    Array<crate::check::types::Ty> ptys;
    Array<crate::lower::model::OutTy> pts;
    JobClauses(crate::lower::Lx lx, Array<crate::syntax::decls::FnClause> clauses, Array<std::tuple<Text, bool>> names, Array<crate::check::types::Ty> ptys, Array<crate::lower::model::OutTy> pts) : lx(std::move(lx)), clauses(std::move(clauses)), names(std::move(names)), ptys(std::move(ptys)), pts(std::move(pts)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


}  // namespace lower::jobs

}  // namespace crate
