// The module `Lower.Program`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace lower::program {

struct LowerProgram;

struct WithNeeds;

struct NamedMods;

struct WithGroups;

struct ReachedBy;

struct NeededMods;

struct ModRefs;

struct ProgDefOf;

struct JobRoots;

struct UnboundedValues;

struct RunTargets;

struct TailTargets;

struct TailsOfBody;

struct ModDefOf;

struct DefItems;

struct TyDefs;

struct TyPodable;

struct CaseField;

struct TagDefOf;

struct RowDefOf;

struct ElemRow;

struct AnswerEnum;

struct AnswerTy;

struct CheckDefOf;

}  // namespace lower::program


}  // namespace crate
