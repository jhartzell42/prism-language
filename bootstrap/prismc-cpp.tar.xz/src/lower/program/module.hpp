// The module `Lower.Program`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <lower/program/types.hpp>
#include "elem.types.hpp"
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace lower::program {

crate::lower::Lx in_module_f(const crate::lower::Lx& lx_p0, const Nat& file_p1, const Text& home_p2);

crate::lower::Lx in_module_at_f(const crate::lower::Lx& lx_p0, const Nat& file_p1, const Text& home_p2, const Text& site_p3);

crate::lower::model::Model lower_program_f(const Array<crate::check::errors::Src>& srcs_p0, const Array<crate::syntax::Module>& trees_p1, const Nat& shown_p2, const crate::check::typed::TProgram& tp_p3, const Text& name_p4);

prism_rtl::JobRef<crate::lower::model::Model> start_lower_program_f(Array<crate::check::errors::Src> srcs_p0, Array<crate::syntax::Module> trees_p1, Nat shown_p2, crate::check::typed::TProgram tp_p3, Text name_p4);

Array<crate::lower::model::ModDef> with_needs_f(const crate::check::env::G& g_p0, const Array<crate::check::errors::Src>& srcs_p1, const crate::check::typed::TProgram& tp_p2, const Array<crate::lower::model::ModDef>& defs_p3);

prism_rtl::JobRef<Array<crate::lower::model::ModDef>> start_with_needs_f(crate::check::env::G g_p0, Array<crate::check::errors::Src> srcs_p1, crate::check::typed::TProgram tp_p2, Array<crate::lower::model::ModDef> defs_p3);

Map<Text, Array<Text>> named_mods_f(const crate::check::env::G& g_p0, const Array<crate::check::errors::Src>& srcs_p1, const crate::check::typed::TProgram& tp_p2, const Array<Text>& ms_p3);

prism_rtl::JobRef<Map<Text, Array<Text>>> start_named_mods_f(crate::check::env::G g_p0, Array<crate::check::errors::Src> srcs_p1, crate::check::typed::TProgram tp_p2, Array<Text> ms_p3);

Array<Text> types_named_in_f(const crate::check::typed::TProgram& tp_p0, const Nat& file_p1);

prism_rtl::JobRef<Array<Text>> start_types_named_in_f(crate::check::typed::TProgram tp_p0, Nat file_p1);

Array<Text> ty_con_names_f(const crate::check::types::Ty& t_p0);

prism_rtl::JobRef<Array<Text>> start_ty_con_names_f(crate::check::types::Ty t_p0);

Text impl_path_f(const Text& how_p0);

Map<Text, bool> value_types_f(const Array<crate::lower::model::ModDef>& defs_p0);

Array<Text> item_held_f(const Array<Text>& names_p0, const Map<Text, bool>& value_tys_p1, const Text& home_p2, const crate::lower::model::Item& it_p3);

Array<Text> held_in_f(const Array<Text>& names_p0, const Map<Text, bool>& value_tys_p1, const Text& home_p2, const crate::lower::model::OutTy& t_p3);

Array<Text> named_in_f(const Array<Text>& names_p0, const Text& home_p1, const crate::lower::model::OutTy& t_p2);

Text path_from_f(const Array<Text>& names_p0, const Text& home_p1, const Text& n_p2);

bool starts_with_module_f(const Array<Text>& names_p0, const Text& q_p1);

Text parent_of_f(const Text& p_p0);

Array<crate::lower::model::ModDef> with_groups_f(const Array<crate::lower::model::ModDef>& defs_p0);

prism_rtl::JobRef<Array<crate::lower::model::ModDef>> start_with_groups_f(Array<crate::lower::model::ModDef> defs_p0);

Array<Text> reached_by_f(const Map<Text, Array<Text>>& edges_p0, const Array<Text>& todo_p1, const Array<Text>& seen_p2);

prism_rtl::JobRef<Array<Text>> start_reached_by_f(Map<Text, Array<Text>> edges_p0, Array<Text> todo_p1, Array<Text> seen_p2);

Array<Text> needed_mods_f(const crate::check::env::G& g_p0, const Nat& shown_p1);

prism_rtl::JobRef<Array<Text>> start_needed_mods_f(crate::check::env::G g_p0, Nat shown_p1);

Array<Text> mod_refs_f(const crate::check::env::G& g_p0, const Text& m_p1);

prism_rtl::JobRef<Array<Text>> start_mod_refs_f(crate::check::env::G g_p0, Text m_p1);

Array<std::tuple<Text, bool>> root_widgets_f(const crate::lower::Lx& lx_p0);

bool is_main_f(const Text& qk_p0);

Text blueprint_qk_f(const crate::lower::Lx& lx_p0, const crate::syntax::Expr& e_p1);

crate::check::env::ValInfo val_of_f(const crate::lower::Lx& lx_p0, const Text& qk_p1);

crate::lower::model::ProgDef prog_def_of_f(const crate::lower::Lx& lx_p0, const Text& qk_p1);

prism_rtl::JobRef<crate::lower::model::ProgDef> start_prog_def_of_f(crate::lower::Lx lx_p0, Text qk_p1);

Array<Text> job_roots_f(const crate::lower::Lx& lx_p0);

prism_rtl::JobRef<Array<Text>> start_job_roots_f(crate::lower::Lx lx_p0);

Array<Text> unbounded_values_f(const crate::lower::Lx& lx_p0, const crate::check::env::Def& d_p1);

prism_rtl::JobRef<Array<Text>> start_unbounded_values_f(crate::lower::Lx lx_p0, crate::check::env::Def d_p1);

bool in_prelude_f(const crate::lower::Lx& lx_p0, const Text& q_p1);

bool is_color_poly_f(const crate::lower::Lx& lx_p0, const Text& q_p1);

bool enters_at_once_f(const crate::lower::Lx& lx_p0, const Text& q_p1, const Array<crate::syntax::Arg>& args_p2);

bool is_unbounded_arg_f(const crate::lower::Lx& lx_p0, const crate::syntax::Arg& a_p1);

bool is_unbounded_f(const crate::lower::Lx& lx_p0, const Text& q_p1);

Array<Text> run_targets_f(const crate::lower::Lx& lx_p0, const crate::check::env::Def& d_p1);

prism_rtl::JobRef<Array<Text>> start_run_targets_f(crate::lower::Lx lx_p0, crate::check::env::Def d_p1);

Array<Text> tail_targets_f(const crate::lower::Lx& lx_p0, const Text& qk_p1);

prism_rtl::JobRef<Array<Text>> start_tail_targets_f(crate::lower::Lx lx_p0, Text qk_p1);

Array<Text> tails_of_body_f(const crate::lower::Lx& lx_p0, const crate::syntax::decls::FnBody& body_p1);

prism_rtl::JobRef<Array<Text>> start_tails_of_body_f(crate::lower::Lx lx_p0, crate::syntax::decls::FnBody body_p1);

crate::lower::model::ModDef mod_def_of_f(const crate::lower::Lx& lx0_p0, const Text& m_p1, const Array<std::tuple<Text, bool>>& roots_p2, const crate::check::env::ModInfo& info_p3, const Array<Text>& mods_p4);

prism_rtl::JobRef<crate::lower::model::ModDef> start_mod_def_of_f(crate::lower::Lx lx0_p0, Text m_p1, Array<std::tuple<Text, bool>> roots_p2, crate::check::env::ModInfo info_p3, Array<Text> mods_p4);

Array<crate::lower::model::Item> def_items_f(const crate::lower::Lx& lx_p0, const crate::check::env::Def& d_p1, const Array<std::tuple<Text, bool>>& roots_p2);

prism_rtl::JobRef<Array<crate::lower::model::Item>> start_def_items_f(crate::lower::Lx lx_p0, crate::check::env::Def d_p1, Array<std::tuple<Text, bool>> roots_p2);

Array<crate::lower::model::Item> node_items_f(const crate::lower::model::NodeDef& n_p0);

Array<crate::lower::model::Item> ty_defs_f(const crate::lower::Lx& lx_p0, const crate::check::env::TyInfo& ti_p1);

prism_rtl::JobRef<Array<crate::lower::model::Item>> start_ty_defs_f(crate::lower::Lx lx_p0, crate::check::env::TyInfo ti_p1);

bool ty_podable_f(const crate::lower::Lx& lx_p0, const crate::check::types::Ty& t_p1, const Array<Text>& seen_p2);

prism_rtl::JobRef<bool> start_ty_podable_f(crate::lower::Lx lx_p0, crate::check::types::Ty t_p1, Array<Text> seen_p2);

bool ty_has_eq_f(const crate::lower::Lx& lx_p0, const crate::check::types::Ty& t_p1, const Array<Text>& seen_p2);

bool has_own_eq_f(const crate::lower::Lx& lx_p0, const Text& tn_p1);

crate::lower::model::OutTy case_field_f(const crate::lower::Lx& lx_p0, const Text& ck_p1, const Nat& i_p2, const crate::check::types::Ty& t_p3);

prism_rtl::JobRef<crate::lower::model::OutTy> start_case_field_f(crate::lower::Lx lx_p0, Text ck_p1, Nat i_p2, crate::check::types::Ty t_p3);

Text type_doc_f(const crate::lower::Lx& lx_p0, const crate::check::env::TyInfo& ti_p1);

crate::lower::model::TagDef tag_def_of_f(const crate::lower::Lx& lx_p0, const crate::check::env::TagInfo& tg_p1);

prism_rtl::JobRef<crate::lower::model::TagDef> start_tag_def_of_f(crate::lower::Lx lx_p0, crate::check::env::TagInfo tg_p1);

Array<std::tuple<Text, crate::check::types::Ty>> level_fields_f(const crate::check::env::TagInfo& tg_p0);

Array<crate::check::env::TagInfo> kind_tags_f(const crate::lower::Lx& lx_p0, const Text& kind_p1, const Array<Text>& mods_p2);

crate::lower::model::RowDef row_def_of_f(const crate::lower::Lx& lx_p0, const crate::check::env::TyInfo& ti_p1);

prism_rtl::JobRef<crate::lower::model::RowDef> start_row_def_of_f(crate::lower::Lx lx_p0, crate::check::env::TyInfo ti_p1);

crate::lower::model::RowDef elem_row_f(const crate::lower::Lx& lx_p0, const Array<Text>& mods_p1);

prism_rtl::JobRef<crate::lower::model::RowDef> start_elem_row_f(crate::lower::Lx lx_p0, Array<Text> mods_p1);

bool tag_holds_dyn_f(const crate::lower::Lx& lx_p0, const crate::check::env::TagInfo& tg_p1);

prism_rtl::JobRef<bool> start_tag_holds_dyn_f(crate::lower::Lx lx_p0, crate::check::env::TagInfo tg_p1);

crate::lower::model::AnswerDef answer_enum_f(const crate::lower::Lx& lx_p0, const Array<Text>& mods_p1);

prism_rtl::JobRef<crate::lower::model::AnswerDef> start_answer_enum_f(crate::lower::Lx lx_p0, Array<Text> mods_p1);

crate::lower::model::OutTy answer_ty_f(const crate::lower::Lx& lx_p0, const crate::check::env::TagInfo& tg_p1);

prism_rtl::JobRef<crate::lower::model::OutTy> start_answer_ty_f(crate::lower::Lx lx_p0, crate::check::env::TagInfo tg_p1);

std::tuple<Text, Text> tag_paths_f(const crate::lower::Lx& lx_p0, const crate::check::env::TagInfo& tg_p1);

Text variant_of_f(const crate::lower::Lx& lx_p0, const crate::check::env::TagInfo& tg_p1);

Text kind_path_f(const crate::lower::Lx& lx_p0, const Text& kind_p1);

crate::lower::model::CheckDef check_def_of_f(const crate::lower::Lx& lx_p0, const crate::syntax::decls::CheckDecl& c_p1);

prism_rtl::JobRef<crate::lower::model::CheckDef> start_check_def_of_f(crate::lower::Lx lx_p0, crate::syntax::decls::CheckDecl c_p1);

}  // namespace lower::program


namespace lower::program {

/// The step machine of `LowerProgram`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LowerProgram: unbounded fn [Src], [Module], Nat, TProgram, Text -> Model
struct LowerProgram : prism_rtl::Job<crate::lower::model::Model> {
    Array<crate::check::errors::Src> srcs_p0;
    Array<crate::syntax::Module> trees_p1;
    Nat shown_p2;
    crate::check::typed::TProgram tp_p3;
    Text name_p4;
    LowerProgram(Array<crate::check::errors::Src> srcs_p0, Array<crate::syntax::Module> trees_p1, Nat shown_p2, crate::check::typed::TProgram tp_p3, Text name_p4) : srcs_p0(std::move(srcs_p0)), trees_p1(std::move(trees_p1)), shown_p2(std::move(shown_p2)), tp_p3(std::move(tp_p3)), name_p4(std::move(name_p4)) {}
    prism_rtl::Turn<crate::lower::model::Model> cycle() const override;
};


/// The step machine of `WithNeeds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WithNeeds: unbounded fn G, [Src], TProgram, [ModDef] -> [ModDef]
struct WithNeeds : prism_rtl::Job<Array<crate::lower::model::ModDef>> {
    crate::check::env::G g_p0;
    Array<crate::check::errors::Src> srcs_p1;
    crate::check::typed::TProgram tp_p2;
    Array<crate::lower::model::ModDef> defs_p3;
    WithNeeds(crate::check::env::G g_p0, Array<crate::check::errors::Src> srcs_p1, crate::check::typed::TProgram tp_p2, Array<crate::lower::model::ModDef> defs_p3) : g_p0(std::move(g_p0)), srcs_p1(std::move(srcs_p1)), tp_p2(std::move(tp_p2)), defs_p3(std::move(defs_p3)) {}
    prism_rtl::Turn<Array<crate::lower::model::ModDef>> cycle() const override;
};


/// The step machine of `NamedMods`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NamedMods: unbounded fn G, [Src], TProgram, [Text] -> (Text ==> [Text])
struct NamedMods : prism_rtl::Job<Map<Text, Array<Text>>> {
    crate::check::env::G g_p0;
    Array<crate::check::errors::Src> srcs_p1;
    crate::check::typed::TProgram tp_p2;
    Array<Text> ms_p3;
    NamedMods(crate::check::env::G g_p0, Array<crate::check::errors::Src> srcs_p1, crate::check::typed::TProgram tp_p2, Array<Text> ms_p3) : g_p0(std::move(g_p0)), srcs_p1(std::move(srcs_p1)), tp_p2(std::move(tp_p2)), ms_p3(std::move(ms_p3)) {}
    prism_rtl::Turn<Map<Text, Array<Text>>> cycle() const override;
};


/// The step machine of `TypesNamedIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TypesNamedIn: unbounded fn TProgram, Nat -> [Text]
struct TypesNamedIn : prism_rtl::Job<Array<Text>> {
    crate::check::typed::TProgram tp_p0;
    Nat file_p1;
    TypesNamedIn(crate::check::typed::TProgram tp_p0, Nat file_p1) : tp_p0(std::move(tp_p0)), file_p1(std::move(file_p1)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `TyConNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TyConNames: unbounded fn Ty -> [Text]
struct TyConNames : prism_rtl::Job<Array<Text>> {
    crate::check::types::Ty t_p0;
    TyConNames(crate::check::types::Ty t_p0) : t_p0(std::move(t_p0)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `WithGroups`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WithGroups: unbounded fn [ModDef] -> [ModDef]
struct WithGroups : prism_rtl::Job<Array<crate::lower::model::ModDef>> {
    Array<crate::lower::model::ModDef> defs_p0;
    WithGroups(Array<crate::lower::model::ModDef> defs_p0) : defs_p0(std::move(defs_p0)) {}
    prism_rtl::Turn<Array<crate::lower::model::ModDef>> cycle() const override;
};


/// The step machine of `ReachedBy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ReachedBy: unbounded fn (Text ==> [Text]), [Text], [Text] -> [Text]
struct ReachedBy : prism_rtl::Job<Array<Text>> {
    Map<Text, Array<Text>> edges_p0;
    Array<Text> todo_p1;
    Array<Text> seen_p2;
    ReachedBy(Map<Text, Array<Text>> edges_p0, Array<Text> todo_p1, Array<Text> seen_p2) : edges_p0(std::move(edges_p0)), todo_p1(std::move(todo_p1)), seen_p2(std::move(seen_p2)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `NeededMods`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NeededMods: unbounded fn G, Nat -> [Text]
struct NeededMods : prism_rtl::Job<Array<Text>> {
    crate::check::env::G g_p0;
    Nat shown_p1;
    NeededMods(crate::check::env::G g_p0, Nat shown_p1) : g_p0(std::move(g_p0)), shown_p1(std::move(shown_p1)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `ModRefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ModRefs: unbounded fn G, Text -> [Text]
struct ModRefs : prism_rtl::Job<Array<Text>> {
    crate::check::env::G g_p0;
    Text m_p1;
    ModRefs(crate::check::env::G g_p0, Text m_p1) : g_p0(std::move(g_p0)), m_p1(std::move(m_p1)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `ProgDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ProgDefOf: unbounded fn Lx, Text -> ProgDef
struct ProgDefOf : prism_rtl::Job<crate::lower::model::ProgDef> {
    crate::lower::Lx lx_p0;
    Text qk_p1;
    ProgDefOf(crate::lower::Lx lx_p0, Text qk_p1) : lx_p0(std::move(lx_p0)), qk_p1(std::move(qk_p1)) {}
    prism_rtl::Turn<crate::lower::model::ProgDef> cycle() const override;
};


/// The step machine of `JobRoots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// JobRoots: unbounded fn Lx -> [Text]
struct JobRoots : prism_rtl::Job<Array<Text>> {
    crate::lower::Lx lx_p0;
    JobRoots(crate::lower::Lx lx_p0) : lx_p0(std::move(lx_p0)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `UnboundedValues`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UnboundedValues: unbounded fn Lx, Def -> [Text]
struct UnboundedValues : prism_rtl::Job<Array<Text>> {
    crate::lower::Lx lx_p0;
    crate::check::env::Def d_p1;
    UnboundedValues(crate::lower::Lx lx_p0, crate::check::env::Def d_p1) : lx_p0(std::move(lx_p0)), d_p1(std::move(d_p1)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `RunTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RunTargets: unbounded fn Lx, Def -> [Text]
struct RunTargets : prism_rtl::Job<Array<Text>> {
    crate::lower::Lx lx_p0;
    crate::check::env::Def d_p1;
    RunTargets(crate::lower::Lx lx_p0, crate::check::env::Def d_p1) : lx_p0(std::move(lx_p0)), d_p1(std::move(d_p1)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `TailTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TailTargets: unbounded fn Lx, Text -> [Text]
struct TailTargets : prism_rtl::Job<Array<Text>> {
    crate::lower::Lx lx_p0;
    Text qk_p1;
    TailTargets(crate::lower::Lx lx_p0, Text qk_p1) : lx_p0(std::move(lx_p0)), qk_p1(std::move(qk_p1)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `TailsOfBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TailsOfBody: unbounded fn Lx, FnBody -> [Text]
struct TailsOfBody : prism_rtl::Job<Array<Text>> {
    crate::lower::Lx lx_p0;
    crate::syntax::decls::FnBody body_p1;
    TailsOfBody(crate::lower::Lx lx_p0, crate::syntax::decls::FnBody body_p1) : lx_p0(std::move(lx_p0)), body_p1(std::move(body_p1)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `ModDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ModDefOf: unbounded fn Lx, Text, [((Text, Bool))], ModInfo, [Text] -> ModDef
struct ModDefOf : prism_rtl::Job<crate::lower::model::ModDef> {
    crate::lower::Lx lx0_p0;
    Text m_p1;
    Array<std::tuple<Text, bool>> roots_p2;
    crate::check::env::ModInfo info_p3;
    Array<Text> mods_p4;
    ModDefOf(crate::lower::Lx lx0_p0, Text m_p1, Array<std::tuple<Text, bool>> roots_p2, crate::check::env::ModInfo info_p3, Array<Text> mods_p4) : lx0_p0(std::move(lx0_p0)), m_p1(std::move(m_p1)), roots_p2(std::move(roots_p2)), info_p3(std::move(info_p3)), mods_p4(std::move(mods_p4)) {}
    prism_rtl::Turn<crate::lower::model::ModDef> cycle() const override;
};


/// The step machine of `DefItems`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DefItems: unbounded fn Lx, Def, [((Text, Bool))] -> [Item]
struct DefItems : prism_rtl::Job<Array<crate::lower::model::Item>> {
    crate::lower::Lx lx_p0;
    crate::check::env::Def d_p1;
    Array<std::tuple<Text, bool>> roots_p2;
    DefItems(crate::lower::Lx lx_p0, crate::check::env::Def d_p1, Array<std::tuple<Text, bool>> roots_p2) : lx_p0(std::move(lx_p0)), d_p1(std::move(d_p1)), roots_p2(std::move(roots_p2)) {}
    prism_rtl::Turn<Array<crate::lower::model::Item>> cycle() const override;
};


/// The step machine of `TyDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TyDefs: unbounded fn Lx, TyInfo -> [Item]
struct TyDefs : prism_rtl::Job<Array<crate::lower::model::Item>> {
    crate::lower::Lx lx_p0;
    crate::check::env::TyInfo ti_p1;
    TyDefs(crate::lower::Lx lx_p0, crate::check::env::TyInfo ti_p1) : lx_p0(std::move(lx_p0)), ti_p1(std::move(ti_p1)) {}
    prism_rtl::Turn<Array<crate::lower::model::Item>> cycle() const override;
};


/// The step machine of `TyPodable`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TyPodable: unbounded fn Lx, Ty, [Text] -> Bool
struct TyPodable : prism_rtl::Job<bool> {
    crate::lower::Lx lx_p0;
    crate::check::types::Ty t_p1;
    Array<Text> seen_p2;
    TyPodable(crate::lower::Lx lx_p0, crate::check::types::Ty t_p1, Array<Text> seen_p2) : lx_p0(std::move(lx_p0)), t_p1(std::move(t_p1)), seen_p2(std::move(seen_p2)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `CaseField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CaseField: unbounded fn Lx, Text, Nat, Ty -> OutTy
struct CaseField : prism_rtl::Job<crate::lower::model::OutTy> {
    crate::lower::Lx lx_p0;
    Text ck_p1;
    Nat i_p2;
    crate::check::types::Ty t_p3;
    CaseField(crate::lower::Lx lx_p0, Text ck_p1, Nat i_p2, crate::check::types::Ty t_p3) : lx_p0(std::move(lx_p0)), ck_p1(std::move(ck_p1)), i_p2(std::move(i_p2)), t_p3(std::move(t_p3)) {}
    prism_rtl::Turn<crate::lower::model::OutTy> cycle() const override;
};


/// The step machine of `TagDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TagDefOf: unbounded fn Lx, TagInfo -> TagDef
struct TagDefOf : prism_rtl::Job<crate::lower::model::TagDef> {
    crate::lower::Lx lx_p0;
    crate::check::env::TagInfo tg_p1;
    TagDefOf(crate::lower::Lx lx_p0, crate::check::env::TagInfo tg_p1) : lx_p0(std::move(lx_p0)), tg_p1(std::move(tg_p1)) {}
    prism_rtl::Turn<crate::lower::model::TagDef> cycle() const override;
};


/// The step machine of `RowDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RowDefOf: unbounded fn Lx, TyInfo -> RowDef
struct RowDefOf : prism_rtl::Job<crate::lower::model::RowDef> {
    crate::lower::Lx lx_p0;
    crate::check::env::TyInfo ti_p1;
    RowDefOf(crate::lower::Lx lx_p0, crate::check::env::TyInfo ti_p1) : lx_p0(std::move(lx_p0)), ti_p1(std::move(ti_p1)) {}
    prism_rtl::Turn<crate::lower::model::RowDef> cycle() const override;
};


/// The step machine of `ElemRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ElemRow: unbounded fn Lx, [Text] -> RowDef
struct ElemRow : prism_rtl::Job<crate::lower::model::RowDef> {
    crate::lower::Lx lx_p0;
    Array<Text> mods_p1;
    ElemRow(crate::lower::Lx lx_p0, Array<Text> mods_p1) : lx_p0(std::move(lx_p0)), mods_p1(std::move(mods_p1)) {}
    prism_rtl::Turn<crate::lower::model::RowDef> cycle() const override;
};


/// The step machine of `TagHoldsDyn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TagHoldsDyn: unbounded fn Lx, TagInfo -> Bool
struct TagHoldsDyn : prism_rtl::Job<bool> {
    crate::lower::Lx lx_p0;
    crate::check::env::TagInfo tg_p1;
    TagHoldsDyn(crate::lower::Lx lx_p0, crate::check::env::TagInfo tg_p1) : lx_p0(std::move(lx_p0)), tg_p1(std::move(tg_p1)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `AnswerEnum`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AnswerEnum: unbounded fn Lx, [Text] -> AnswerDef
struct AnswerEnum : prism_rtl::Job<crate::lower::model::AnswerDef> {
    crate::lower::Lx lx_p0;
    Array<Text> mods_p1;
    AnswerEnum(crate::lower::Lx lx_p0, Array<Text> mods_p1) : lx_p0(std::move(lx_p0)), mods_p1(std::move(mods_p1)) {}
    prism_rtl::Turn<crate::lower::model::AnswerDef> cycle() const override;
};


/// The step machine of `AnswerTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AnswerTy: unbounded fn Lx, TagInfo -> OutTy
struct AnswerTy : prism_rtl::Job<crate::lower::model::OutTy> {
    crate::lower::Lx lx_p0;
    crate::check::env::TagInfo tg_p1;
    AnswerTy(crate::lower::Lx lx_p0, crate::check::env::TagInfo tg_p1) : lx_p0(std::move(lx_p0)), tg_p1(std::move(tg_p1)) {}
    prism_rtl::Turn<crate::lower::model::OutTy> cycle() const override;
};


/// The step machine of `CheckDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckDefOf: unbounded fn Lx, CheckDecl -> CheckDef
struct CheckDefOf : prism_rtl::Job<crate::lower::model::CheckDef> {
    crate::lower::Lx lx_p0;
    crate::syntax::decls::CheckDecl c_p1;
    CheckDefOf(crate::lower::Lx lx_p0, crate::syntax::decls::CheckDecl c_p1) : lx_p0(std::move(lx_p0)), c_p1(std::move(c_p1)) {}
    prism_rtl::Turn<crate::lower::model::CheckDef> cycle() const override;
};


}  // namespace lower::program

}  // namespace crate
