// The module `Lower.Program`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <lower/program/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace lower::program {

crate::lower::Lx in_module(const crate::lower::Lx& lx, const Nat& file, const Text& home);

crate::lower::Lx in_module_at(const crate::lower::Lx& lx, const Nat& file, const Text& home, const Text& site);

crate::lower::model::Model lower_program(const Array<crate::check::errors::Src>& srcs, const Array<crate::syntax::Module>& trees, const Nat& shown, const crate::check::typed::TProgram& tp, const Text& name);

prism_rtl::JobRef<crate::lower::model::Model> start_lower_program(Array<crate::check::errors::Src> srcs, Array<crate::syntax::Module> trees, Nat shown, crate::check::typed::TProgram tp, Text name);

Array<crate::lower::model::ModDef> with_needs(const crate::check::env::G& g, const Array<crate::check::errors::Src>& srcs, const crate::check::typed::TProgram& tp, const Array<crate::lower::model::ModDef>& defs);

prism_rtl::JobRef<Array<crate::lower::model::ModDef>> start_with_needs(crate::check::env::G g, Array<crate::check::errors::Src> srcs, crate::check::typed::TProgram tp, Array<crate::lower::model::ModDef> defs);

Map<Text, Array<Text>> named_mods(const crate::check::env::G& g, const Array<crate::check::errors::Src>& srcs, const crate::check::typed::TProgram& tp, const Array<Text>& ms);

prism_rtl::JobRef<Map<Text, Array<Text>>> start_named_mods(crate::check::env::G g, Array<crate::check::errors::Src> srcs, crate::check::typed::TProgram tp, Array<Text> ms);

Text impl_path(const Text& how);

Map<Text, bool> value_types(const Array<crate::lower::model::ModDef>& defs);

Array<Text> item_held(const Array<Text>& names, const Map<Text, bool>& value_tys, const Text& home, const crate::lower::model::Item& it);

Array<Text> held_in(const Array<Text>& names, const Map<Text, bool>& value_tys, const Text& home, const crate::lower::model::OutTy& t);

Array<Text> named_in(const Array<Text>& names, const Text& home, const crate::lower::model::OutTy& t);

Text path_from(const Array<Text>& names, const Text& home, const Text& n);

bool starts_with_module(const Array<Text>& names, const Text& q);

Text parent_of(const Text& p_);

Array<crate::lower::model::ModDef> with_groups(const Array<crate::lower::model::ModDef>& defs);

prism_rtl::JobRef<Array<crate::lower::model::ModDef>> start_with_groups(Array<crate::lower::model::ModDef> defs);

Array<Text> reached_by(const Map<Text, Array<Text>>& edges, const Array<Text>& todo, const Array<Text>& seen);

prism_rtl::JobRef<Array<Text>> start_reached_by(Map<Text, Array<Text>> edges, Array<Text> todo, Array<Text> seen);

Array<Text> needed_mods(const crate::check::env::G& g, const Nat& shown);

prism_rtl::JobRef<Array<Text>> start_needed_mods(crate::check::env::G g, Nat shown);

Array<Text> mod_refs(const crate::check::env::G& g, const Text& m);

prism_rtl::JobRef<Array<Text>> start_mod_refs(crate::check::env::G g, Text m);

Array<std::tuple<Text, bool>> root_widgets(const crate::lower::Lx& lx);

bool is_main(const Text& qk);

Text blueprint_qk(const crate::lower::Lx& lx, const crate::syntax::Expr& e);

crate::check::env::ValInfo val_of(const crate::lower::Lx& lx, const Text& qk);

crate::lower::model::ProgDef prog_def_of(const crate::lower::Lx& lx, const Text& qk);

prism_rtl::JobRef<crate::lower::model::ProgDef> start_prog_def_of(crate::lower::Lx lx, Text qk);

Array<Text> job_roots(const crate::lower::Lx& lx);

prism_rtl::JobRef<Array<Text>> start_job_roots(crate::lower::Lx lx);

Array<Text> unbounded_values(const crate::lower::Lx& lx, const crate::check::env::Def& d);

prism_rtl::JobRef<Array<Text>> start_unbounded_values(crate::lower::Lx lx, crate::check::env::Def d);

bool in_prelude(const crate::lower::Lx& lx, const Text& q);

bool is_color_poly(const crate::lower::Lx& lx, const Text& q);

bool enters_at_once(const crate::lower::Lx& lx, const Text& q, const Array<crate::syntax::Arg>& args);

bool is_unbounded_arg(const crate::lower::Lx& lx, const crate::syntax::Arg& a);

bool is_unbounded(const crate::lower::Lx& lx, const Text& q);

Array<Text> run_targets(const crate::lower::Lx& lx, const crate::check::env::Def& d);

prism_rtl::JobRef<Array<Text>> start_run_targets(crate::lower::Lx lx, crate::check::env::Def d);

Array<Text> tail_targets(const crate::lower::Lx& lx, const Text& qk);

prism_rtl::JobRef<Array<Text>> start_tail_targets(crate::lower::Lx lx, Text qk);

Array<Text> tails_of_body(const crate::lower::Lx& lx, const crate::syntax::decls::FnBody& body);

prism_rtl::JobRef<Array<Text>> start_tails_of_body(crate::lower::Lx lx, crate::syntax::decls::FnBody body);

crate::lower::model::ModDef mod_def_of(const crate::lower::Lx& lx0, const Text& m, const Array<std::tuple<Text, bool>>& roots, const crate::check::env::ModInfo& info, const Array<Text>& mods);

prism_rtl::JobRef<crate::lower::model::ModDef> start_mod_def_of(crate::lower::Lx lx0, Text m, Array<std::tuple<Text, bool>> roots, crate::check::env::ModInfo info, Array<Text> mods);

Array<crate::lower::model::Item> def_items(const crate::lower::Lx& lx, const crate::check::env::Def& d, const Array<std::tuple<Text, bool>>& roots);

prism_rtl::JobRef<Array<crate::lower::model::Item>> start_def_items(crate::lower::Lx lx, crate::check::env::Def d, Array<std::tuple<Text, bool>> roots);

Array<crate::lower::model::Item> node_items(const crate::lower::model::NodeDef& n);

Array<crate::lower::model::Item> ty_defs(const crate::lower::Lx& lx, const crate::check::env::TyInfo& ti);

prism_rtl::JobRef<Array<crate::lower::model::Item>> start_ty_defs(crate::lower::Lx lx, crate::check::env::TyInfo ti);

bool ty_podable(const crate::lower::Lx& lx, const crate::check::types::Ty& t, const Array<Text>& seen);

prism_rtl::JobRef<bool> start_ty_podable(crate::lower::Lx lx, crate::check::types::Ty t, Array<Text> seen);

bool ty_has_eq(const crate::lower::Lx& lx, const crate::check::types::Ty& t, const Array<Text>& seen);

bool has_own_eq(const crate::lower::Lx& lx, const Text& tn);

crate::lower::model::OutTy case_field(const crate::lower::Lx& lx, const Text& ck, const Nat& i, const crate::check::types::Ty& t);

prism_rtl::JobRef<crate::lower::model::OutTy> start_case_field(crate::lower::Lx lx, Text ck, Nat i, crate::check::types::Ty t);

Text type_doc(const crate::lower::Lx& lx, const crate::check::env::TyInfo& ti);

crate::lower::model::TagDef tag_def_of(const crate::lower::Lx& lx, const crate::check::env::TagInfo& tg);

prism_rtl::JobRef<crate::lower::model::TagDef> start_tag_def_of(crate::lower::Lx lx, crate::check::env::TagInfo tg);

Array<std::tuple<Text, crate::check::types::Ty>> level_fields(const crate::check::env::TagInfo& tg);

Array<crate::check::env::TagInfo> kind_tags(const crate::lower::Lx& lx, const Text& kind, const Array<Text>& mods);

crate::lower::model::RowDef row_def_of(const crate::lower::Lx& lx, const crate::check::env::TyInfo& ti);

prism_rtl::JobRef<crate::lower::model::RowDef> start_row_def_of(crate::lower::Lx lx, crate::check::env::TyInfo ti);

crate::lower::model::RowDef elem_row(const crate::lower::Lx& lx, const Array<Text>& mods);

prism_rtl::JobRef<crate::lower::model::RowDef> start_elem_row(crate::lower::Lx lx, Array<Text> mods);

bool tag_holds_dyn(const crate::lower::Lx& lx, const crate::check::env::TagInfo& tg);

prism_rtl::JobRef<bool> start_tag_holds_dyn(crate::lower::Lx lx, crate::check::env::TagInfo tg);

crate::lower::model::AnswerDef answer_enum(const crate::lower::Lx& lx, const Array<Text>& mods);

prism_rtl::JobRef<crate::lower::model::AnswerDef> start_answer_enum(crate::lower::Lx lx, Array<Text> mods);

crate::lower::model::OutTy answer_ty(const crate::lower::Lx& lx, const crate::check::env::TagInfo& tg);

prism_rtl::JobRef<crate::lower::model::OutTy> start_answer_ty(crate::lower::Lx lx, crate::check::env::TagInfo tg);

std::tuple<Text, Text> tag_paths(const crate::lower::Lx& lx, const crate::check::env::TagInfo& tg);

Text variant_of(const crate::lower::Lx& lx, const crate::check::env::TagInfo& tg);

Text kind_path(const crate::lower::Lx& lx, const Text& kind);

crate::lower::model::CheckDef check_def_of(const crate::lower::Lx& lx, const crate::syntax::decls::CheckDecl& c);

prism_rtl::JobRef<crate::lower::model::CheckDef> start_check_def_of(crate::lower::Lx lx, crate::syntax::decls::CheckDecl c);

}  // namespace lower::program


namespace lower::program {

/// The step machine of `LowerProgram`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LowerProgram: unbounded fn [Src], [Module], Nat, TProgram, Text -> Model
struct LowerProgram : prism_rtl::Job<crate::lower::model::Model> {
    Array<crate::check::errors::Src> srcs;
    Array<crate::syntax::Module> trees;
    Nat shown;
    crate::check::typed::TProgram tp;
    Text name;
    LowerProgram(Array<crate::check::errors::Src> srcs, Array<crate::syntax::Module> trees, Nat shown, crate::check::typed::TProgram tp, Text name) : srcs(std::move(srcs)), trees(std::move(trees)), shown(std::move(shown)), tp(std::move(tp)), name(std::move(name)) {}
    prism_rtl::Turn<crate::lower::model::Model> cycle() const override;
};


/// The step machine of `WithNeeds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WithNeeds: unbounded fn G, [Src], TProgram, [ModDef] -> [ModDef]
struct WithNeeds : prism_rtl::Job<Array<crate::lower::model::ModDef>> {
    crate::check::env::G g;
    Array<crate::check::errors::Src> srcs;
    crate::check::typed::TProgram tp;
    Array<crate::lower::model::ModDef> defs;
    WithNeeds(crate::check::env::G g, Array<crate::check::errors::Src> srcs, crate::check::typed::TProgram tp, Array<crate::lower::model::ModDef> defs) : g(std::move(g)), srcs(std::move(srcs)), tp(std::move(tp)), defs(std::move(defs)) {}
    prism_rtl::Turn<Array<crate::lower::model::ModDef>> cycle() const override;
};


/// The step machine of `NamedMods`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NamedMods: unbounded fn G, [Src], TProgram, [Text] -> (Text ==> [Text])
struct NamedMods : prism_rtl::Job<Map<Text, Array<Text>>> {
    crate::check::env::G g;
    Array<crate::check::errors::Src> srcs;
    crate::check::typed::TProgram tp;
    Array<Text> ms;
    NamedMods(crate::check::env::G g, Array<crate::check::errors::Src> srcs, crate::check::typed::TProgram tp, Array<Text> ms) : g(std::move(g)), srcs(std::move(srcs)), tp(std::move(tp)), ms(std::move(ms)) {}
    prism_rtl::Turn<Map<Text, Array<Text>>> cycle() const override;
};


/// The step machine of `WithGroups`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WithGroups: unbounded fn [ModDef] -> [ModDef]
struct WithGroups : prism_rtl::Job<Array<crate::lower::model::ModDef>> {
    Array<crate::lower::model::ModDef> defs;
    WithGroups(Array<crate::lower::model::ModDef> defs) : defs(std::move(defs)) {}
    prism_rtl::Turn<Array<crate::lower::model::ModDef>> cycle() const override;
};


/// The step machine of `ReachedBy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ReachedBy: unbounded fn (Text ==> [Text]), [Text], [Text] -> [Text]
struct ReachedBy : prism_rtl::Job<Array<Text>> {
    Map<Text, Array<Text>> edges;
    Array<Text> todo;
    Array<Text> seen;
    ReachedBy(Map<Text, Array<Text>> edges, Array<Text> todo, Array<Text> seen) : edges(std::move(edges)), todo(std::move(todo)), seen(std::move(seen)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `NeededMods`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NeededMods: unbounded fn G, Nat -> [Text]
struct NeededMods : prism_rtl::Job<Array<Text>> {
    crate::check::env::G g;
    Nat shown;
    NeededMods(crate::check::env::G g, Nat shown) : g(std::move(g)), shown(std::move(shown)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `ModRefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ModRefs: unbounded fn G, Text -> [Text]
struct ModRefs : prism_rtl::Job<Array<Text>> {
    crate::check::env::G g;
    Text m;
    ModRefs(crate::check::env::G g, Text m) : g(std::move(g)), m(std::move(m)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `ProgDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ProgDefOf: unbounded fn Lx, Text -> ProgDef
struct ProgDefOf : prism_rtl::Job<crate::lower::model::ProgDef> {
    crate::lower::Lx lx;
    Text qk;
    ProgDefOf(crate::lower::Lx lx, Text qk) : lx(std::move(lx)), qk(std::move(qk)) {}
    prism_rtl::Turn<crate::lower::model::ProgDef> cycle() const override;
};


/// The step machine of `JobRoots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// JobRoots: unbounded fn Lx -> [Text]
struct JobRoots : prism_rtl::Job<Array<Text>> {
    crate::lower::Lx lx;
    JobRoots(crate::lower::Lx lx) : lx(std::move(lx)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `UnboundedValues`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UnboundedValues: unbounded fn Lx, Def -> [Text]
struct UnboundedValues : prism_rtl::Job<Array<Text>> {
    crate::lower::Lx lx;
    crate::check::env::Def d;
    UnboundedValues(crate::lower::Lx lx, crate::check::env::Def d) : lx(std::move(lx)), d(std::move(d)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `RunTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RunTargets: unbounded fn Lx, Def -> [Text]
struct RunTargets : prism_rtl::Job<Array<Text>> {
    crate::lower::Lx lx;
    crate::check::env::Def d;
    RunTargets(crate::lower::Lx lx, crate::check::env::Def d) : lx(std::move(lx)), d(std::move(d)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `TailTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TailTargets: unbounded fn Lx, Text -> [Text]
struct TailTargets : prism_rtl::Job<Array<Text>> {
    crate::lower::Lx lx;
    Text qk;
    TailTargets(crate::lower::Lx lx, Text qk) : lx(std::move(lx)), qk(std::move(qk)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `TailsOfBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TailsOfBody: unbounded fn Lx, FnBody -> [Text]
struct TailsOfBody : prism_rtl::Job<Array<Text>> {
    crate::lower::Lx lx;
    crate::syntax::decls::FnBody body;
    TailsOfBody(crate::lower::Lx lx, crate::syntax::decls::FnBody body) : lx(std::move(lx)), body(std::move(body)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `ModDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ModDefOf: unbounded fn Lx, Text, [((Text, Bool))], ModInfo, [Text] -> ModDef
struct ModDefOf : prism_rtl::Job<crate::lower::model::ModDef> {
    crate::lower::Lx lx0;
    Text m;
    Array<std::tuple<Text, bool>> roots;
    crate::check::env::ModInfo info;
    Array<Text> mods;
    ModDefOf(crate::lower::Lx lx0, Text m, Array<std::tuple<Text, bool>> roots, crate::check::env::ModInfo info, Array<Text> mods) : lx0(std::move(lx0)), m(std::move(m)), roots(std::move(roots)), info(std::move(info)), mods(std::move(mods)) {}
    prism_rtl::Turn<crate::lower::model::ModDef> cycle() const override;
};


/// The step machine of `DefItems`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DefItems: unbounded fn Lx, Def, [((Text, Bool))] -> [Item]
struct DefItems : prism_rtl::Job<Array<crate::lower::model::Item>> {
    crate::lower::Lx lx;
    crate::check::env::Def d;
    Array<std::tuple<Text, bool>> roots;
    DefItems(crate::lower::Lx lx, crate::check::env::Def d, Array<std::tuple<Text, bool>> roots) : lx(std::move(lx)), d(std::move(d)), roots(std::move(roots)) {}
    prism_rtl::Turn<Array<crate::lower::model::Item>> cycle() const override;
};


/// The step machine of `TyDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TyDefs: unbounded fn Lx, TyInfo -> [Item]
struct TyDefs : prism_rtl::Job<Array<crate::lower::model::Item>> {
    crate::lower::Lx lx;
    crate::check::env::TyInfo ti;
    TyDefs(crate::lower::Lx lx, crate::check::env::TyInfo ti) : lx(std::move(lx)), ti(std::move(ti)) {}
    prism_rtl::Turn<Array<crate::lower::model::Item>> cycle() const override;
};


/// The step machine of `TyPodable`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TyPodable: unbounded fn Lx, Ty, [Text] -> Bool
struct TyPodable : prism_rtl::Job<bool> {
    crate::lower::Lx lx;
    crate::check::types::Ty t;
    Array<Text> seen;
    TyPodable(crate::lower::Lx lx, crate::check::types::Ty t, Array<Text> seen) : lx(std::move(lx)), t(std::move(t)), seen(std::move(seen)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `CaseField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CaseField: unbounded fn Lx, Text, Nat, Ty -> OutTy
struct CaseField : prism_rtl::Job<crate::lower::model::OutTy> {
    crate::lower::Lx lx;
    Text ck;
    Nat i;
    crate::check::types::Ty t;
    CaseField(crate::lower::Lx lx, Text ck, Nat i, crate::check::types::Ty t) : lx(std::move(lx)), ck(std::move(ck)), i(std::move(i)), t(std::move(t)) {}
    prism_rtl::Turn<crate::lower::model::OutTy> cycle() const override;
};


/// The step machine of `TagDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TagDefOf: unbounded fn Lx, TagInfo -> TagDef
struct TagDefOf : prism_rtl::Job<crate::lower::model::TagDef> {
    crate::lower::Lx lx;
    crate::check::env::TagInfo tg;
    TagDefOf(crate::lower::Lx lx, crate::check::env::TagInfo tg) : lx(std::move(lx)), tg(std::move(tg)) {}
    prism_rtl::Turn<crate::lower::model::TagDef> cycle() const override;
};


/// The step machine of `RowDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RowDefOf: unbounded fn Lx, TyInfo -> RowDef
struct RowDefOf : prism_rtl::Job<crate::lower::model::RowDef> {
    crate::lower::Lx lx;
    crate::check::env::TyInfo ti;
    RowDefOf(crate::lower::Lx lx, crate::check::env::TyInfo ti) : lx(std::move(lx)), ti(std::move(ti)) {}
    prism_rtl::Turn<crate::lower::model::RowDef> cycle() const override;
};


/// The step machine of `ElemRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ElemRow: unbounded fn Lx, [Text] -> RowDef
struct ElemRow : prism_rtl::Job<crate::lower::model::RowDef> {
    crate::lower::Lx lx;
    Array<Text> mods;
    ElemRow(crate::lower::Lx lx, Array<Text> mods) : lx(std::move(lx)), mods(std::move(mods)) {}
    prism_rtl::Turn<crate::lower::model::RowDef> cycle() const override;
};


/// The step machine of `TagHoldsDyn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TagHoldsDyn: unbounded fn Lx, TagInfo -> Bool
struct TagHoldsDyn : prism_rtl::Job<bool> {
    crate::lower::Lx lx;
    crate::check::env::TagInfo tg;
    TagHoldsDyn(crate::lower::Lx lx, crate::check::env::TagInfo tg) : lx(std::move(lx)), tg(std::move(tg)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `AnswerEnum`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AnswerEnum: unbounded fn Lx, [Text] -> AnswerDef
struct AnswerEnum : prism_rtl::Job<crate::lower::model::AnswerDef> {
    crate::lower::Lx lx;
    Array<Text> mods;
    AnswerEnum(crate::lower::Lx lx, Array<Text> mods) : lx(std::move(lx)), mods(std::move(mods)) {}
    prism_rtl::Turn<crate::lower::model::AnswerDef> cycle() const override;
};


/// The step machine of `AnswerTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AnswerTy: unbounded fn Lx, TagInfo -> OutTy
struct AnswerTy : prism_rtl::Job<crate::lower::model::OutTy> {
    crate::lower::Lx lx;
    crate::check::env::TagInfo tg;
    AnswerTy(crate::lower::Lx lx, crate::check::env::TagInfo tg) : lx(std::move(lx)), tg(std::move(tg)) {}
    prism_rtl::Turn<crate::lower::model::OutTy> cycle() const override;
};


/// The step machine of `CheckDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckDefOf: unbounded fn Lx, CheckDecl -> CheckDef
struct CheckDefOf : prism_rtl::Job<crate::lower::model::CheckDef> {
    crate::lower::Lx lx;
    crate::syntax::decls::CheckDecl c;
    CheckDefOf(crate::lower::Lx lx, crate::syntax::decls::CheckDecl c) : lx(std::move(lx)), c(std::move(c)) {}
    prism_rtl::Turn<crate::lower::model::CheckDef> cycle() const override;
};


}  // namespace lower::program

}  // namespace crate
