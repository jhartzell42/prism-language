// The module `Lower`: its generic functions' and types' definitions, emitted by prismc
// (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include <lower/module.hpp>
#include <ast/module.hpp>
#include <check_env/module.hpp>
#include <check_errors/module.hpp>
#include <check_types/module.hpp>
#include <lexer/module.hpp>
#include <typed/module.hpp>

namespace crate {

using namespace prelude;

namespace lower {

/// IsSome: fn ?a -> Bool
template <class A>
bool is_some(const std::optional<A>& opt0) {
    if (prism_rtl::is_some(opt0)) {
        return true;
    }
    if (prism_rtl::is_none(opt0)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


}  // namespace lower

}  // namespace crate
