// The module `Lower.Functions`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace lower::functions {

struct ClausesBody;

struct FnBodyValue;

struct FnDefOf;

struct LetGetter;

struct SelfIn;

struct TraitDefOf;

struct ImplDefOf;

struct IfGenLine;

}  // namespace lower::functions


}  // namespace crate
