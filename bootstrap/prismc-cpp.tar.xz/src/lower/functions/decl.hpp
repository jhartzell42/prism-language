// The module `Lower.Functions`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace lower::functions {

struct ParamNames;

struct ClausesBody;

struct FnBodyValue;

struct FnDefOf;

struct LetGetter;

struct SelfIn;

struct TraitDefOf;

struct ImplDefOf;

struct ImplBounds;

struct IfGenLine;

}  // namespace lower::functions

}  // namespace crate
