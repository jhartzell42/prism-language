// The module `Lower.Functions`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <lower/functions/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace lower::functions {

Array<Text> bound_of(const crate::lower::Lx& lx, const Text& text1);

Array<std::tuple<Text, Array<Text>>> scheme_generics(const crate::lower::Lx& lx, const crate::check::types::Scheme& sc);

Array<std::tuple<Text, bool>> param_names(const crate::lower::Lx& lx, const Array<crate::syntax::decls::FnClause>& clauses, const Array<crate::lower::model::OutTy>& pts);

Text plain_binder(const crate::lower::Lx& lx, const crate::syntax::Pattern_& p_);

Text param_word(const crate::lower::model::OutTy& t, const Nat& i);

crate::lower::model::Ex clauses_body(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const Array<crate::syntax::decls::FnClause>& clauses, const Array<std::tuple<Text, bool>>& names, const Array<crate::check::types::Ty>& ptys, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody>)>& body_fn, const Text& label, const crate::lower::model::OutTy& t);

prism_rtl::JobRef<crate::lower::model::Ex> start_clauses_body(crate::lower::Lx lx, crate::lower::types::Env env, Array<crate::syntax::decls::FnClause> clauses, Array<std::tuple<Text, bool>> names, Array<crate::check::types::Ty> ptys, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody>)> body_fn, Text label, crate::lower::model::OutTy t);

crate::syntax::decls::FnClause dummy_clause();

crate::lower::model::Ex fn_body_value(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::decls::FnBody& fn_body2);

prism_rtl::JobRef<crate::lower::model::Ex> start_fn_body_value(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::decls::FnBody fn_body2);

crate::lower::model::FnDef fn_def_of(const crate::lower::Lx& lx, const Text& qk, const Array<crate::syntax::decls::FnClause>& clauses, const crate::check::types::Scheme& sc);

prism_rtl::JobRef<crate::lower::model::FnDef> start_fn_def_of(crate::lower::Lx lx, Text qk, Array<crate::syntax::decls::FnClause> clauses, crate::check::types::Scheme sc);

Array<Text> ty_params_in(const crate::lower::model::OutTy& t);

Text signature_text(const crate::lower::Lx& lx, const Text& qk);

Text definition_text(const crate::lower::Lx& lx, const Text& qk);

Text src_text(const crate::lower::Lx& lx, const Nat& f, const crate::syntax::Range& r);

Text drop_trailing_comments(const Text& t);

bool is_code_line(const Text& l);

crate::lower::model::FnDef let_getter(const crate::lower::Lx& lx, const Text& qk, const crate::syntax::decls::LetDecl& l);

prism_rtl::JobRef<crate::lower::model::FnDef> start_let_getter(crate::lower::Lx lx, Text qk, crate::syntax::decls::LetDecl l);

bool has_own_show(const crate::lower::Lx& lx, const Text& tn);

Text head_name(const crate::check::types::Ty& ty0);

crate::check::types::Ty self_in(const crate::check::types::Ty& t, const Text& param);

prism_rtl::JobRef<crate::check::types::Ty> start_self_in(crate::check::types::Ty t, Text param);

crate::lower::model::TraitDef trait_def_of(const crate::lower::Lx& lx0, const crate::check::env::TraitInfo& tr);

prism_rtl::JobRef<crate::lower::model::TraitDef> start_trait_def_of(crate::lower::Lx lx0, crate::check::env::TraitInfo tr);

Array<crate::syntax::decls::FnClause> default_clauses(const crate::check::env::G& g, const Text& qk);

Array<crate::syntax::decls::FnClause> default_of(const crate::check::env::Def& d, const Array<crate::syntax::decls::FnClause>& other);

crate::lower::model::ImplDef impl_def_of(const crate::lower::Lx& lx, const crate::check::env::ImplInfo& im);

prism_rtl::JobRef<crate::lower::model::ImplDef> start_impl_def_of(crate::lower::Lx lx, crate::check::env::ImplInfo im);

crate::lower::model::FnDef renamed(const crate::lower::model::FnDef& fd, const Text& n);

bool is_method_of(const crate::check::env::Def& d, const crate::check::env::ImplInfo& im);

Array<crate::syntax::decls::FnClause> method_clauses(const crate::check::env::Def& d);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> if_gen_line(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& menv, const crate::syntax::Expr& c, const crate::syntax::Block& then_b, const crate::syntax::Block& else_b, const crate::syntax::Expr& e);

prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> start_if_gen_line(crate::lower::node_::Wx wx, crate::lower::types::Env menv, crate::syntax::Expr c, crate::syntax::Block then_b, crate::syntax::Block else_b, crate::syntax::Expr e);

}  // namespace lower::functions


namespace lower::functions {

/// The step machine of `ClausesBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClausesBody: unbounded fn Lx, Env, [FnClause], [((Text, Bool))], [Ty], (fn Lx, Env, FnBody -> Ex), Text, OutTy -> Ex
struct ClausesBody : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    Array<crate::syntax::decls::FnClause> clauses;
    Array<std::tuple<Text, bool>> names;
    Array<crate::check::types::Ty> ptys;
    prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody>)> body_fn;
    Text label;
    crate::lower::model::OutTy t;
    ClausesBody(crate::lower::Lx lx, crate::lower::types::Env env, Array<crate::syntax::decls::FnClause> clauses, Array<std::tuple<Text, bool>> names, Array<crate::check::types::Ty> ptys, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody>)> body_fn, Text label, crate::lower::model::OutTy t) : lx(std::move(lx)), env(std::move(env)), clauses(std::move(clauses)), names(std::move(names)), ptys(std::move(ptys)), body_fn(std::move(body_fn)), label(std::move(label)), t(std::move(t)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `FnBodyValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FnBodyValue: unbounded fn Lx, Env, FnBody -> Ex
struct FnBodyValue : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::decls::FnBody fn_body2;
    FnBodyValue(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::decls::FnBody fn_body2) : lx(std::move(lx)), env(std::move(env)), fn_body2(std::move(fn_body2)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `FnDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FnDefOf: unbounded fn Lx, Text, [FnClause], Scheme -> FnDef
struct FnDefOf : prism_rtl::Job<crate::lower::model::FnDef> {
    crate::lower::Lx lx;
    Text qk;
    Array<crate::syntax::decls::FnClause> clauses;
    crate::check::types::Scheme sc;
    FnDefOf(crate::lower::Lx lx, Text qk, Array<crate::syntax::decls::FnClause> clauses, crate::check::types::Scheme sc) : lx(std::move(lx)), qk(std::move(qk)), clauses(std::move(clauses)), sc(std::move(sc)) {}
    prism_rtl::Turn<crate::lower::model::FnDef> cycle() const override;
};


/// The step machine of `LetGetter`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LetGetter: unbounded fn Lx, Text, LetDecl -> FnDef
struct LetGetter : prism_rtl::Job<crate::lower::model::FnDef> {
    crate::lower::Lx lx;
    Text qk;
    crate::syntax::decls::LetDecl l;
    LetGetter(crate::lower::Lx lx, Text qk, crate::syntax::decls::LetDecl l) : lx(std::move(lx)), qk(std::move(qk)), l(std::move(l)) {}
    prism_rtl::Turn<crate::lower::model::FnDef> cycle() const override;
};


/// The step machine of `SelfIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SelfIn: unbounded fn Ty, Text -> Ty
struct SelfIn : prism_rtl::Job<crate::check::types::Ty> {
    crate::check::types::Ty t;
    Text param;
    SelfIn(crate::check::types::Ty t, Text param) : t(std::move(t)), param(std::move(param)) {}
    prism_rtl::Turn<crate::check::types::Ty> cycle() const override;
};


/// The step machine of `TraitDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TraitDefOf: unbounded fn Lx, TraitInfo -> TraitDef
struct TraitDefOf : prism_rtl::Job<crate::lower::model::TraitDef> {
    crate::lower::Lx lx0;
    crate::check::env::TraitInfo tr;
    TraitDefOf(crate::lower::Lx lx0, crate::check::env::TraitInfo tr) : lx0(std::move(lx0)), tr(std::move(tr)) {}
    prism_rtl::Turn<crate::lower::model::TraitDef> cycle() const override;
};


/// The step machine of `ImplDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ImplDefOf: unbounded fn Lx, ImplInfo -> ImplDef
struct ImplDefOf : prism_rtl::Job<crate::lower::model::ImplDef> {
    crate::lower::Lx lx;
    crate::check::env::ImplInfo im;
    ImplDefOf(crate::lower::Lx lx, crate::check::env::ImplInfo im) : lx(std::move(lx)), im(std::move(im)) {}
    prism_rtl::Turn<crate::lower::model::ImplDef> cycle() const override;
};


/// The step machine of `IfGenLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IfGenLine: unbounded fn Wx, Env, Expr, Block, Block, Expr -> ((Wx, Wres))
struct IfGenLine : prism_rtl::Job<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> {
    crate::lower::node_::Wx wx;
    crate::lower::types::Env menv;
    crate::syntax::Expr c;
    crate::syntax::Block then_b;
    crate::syntax::Block else_b;
    crate::syntax::Expr e;
    IfGenLine(crate::lower::node_::Wx wx, crate::lower::types::Env menv, crate::syntax::Expr c, crate::syntax::Block then_b, crate::syntax::Block else_b, crate::syntax::Expr e) : wx(std::move(wx)), menv(std::move(menv)), c(std::move(c)), then_b(std::move(then_b)), else_b(std::move(else_b)), e(std::move(e)) {}
    prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> cycle() const override;
};


}  // namespace lower::functions

}  // namespace crate
