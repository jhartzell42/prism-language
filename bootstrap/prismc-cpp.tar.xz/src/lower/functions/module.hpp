// The module `Lower.Functions`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <lower/functions/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace lower::functions {

Array<Text> bound_of(const crate::lower::Lx& lx_p0, const Text& text1);

Array<std::tuple<Text, Array<Text>>> scheme_generics(const crate::lower::Lx& lx_p0, const crate::check::types::Scheme& sc_p1);

bool keys_by(const crate::check::types::Ty& t_p0, const Text& q_p1);

Array<std::tuple<Text, bool>> param_names(const crate::lower::Lx& lx_p0, const Array<crate::syntax::decls::FnClause>& clauses_p1, const Array<crate::lower::model::OutTy>& pts_p2);

prism_rtl::JobRef<Array<std::tuple<Text, bool>>> start_param_names(crate::lower::Lx lx_p0, Array<crate::syntax::decls::FnClause> clauses_p1, Array<crate::lower::model::OutTy> pts_p2);

Text plain_binder(const crate::lower::Lx& lx_p0, const crate::syntax::Pattern_& p_p1);

Text param_word(const crate::lower::model::OutTy& t_p0, const Nat& i_p1);

crate::lower::model::Ex clauses_body(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Array<crate::syntax::decls::FnClause>& clauses_p2, const Array<std::tuple<Text, bool>>& names_p3, const Array<crate::check::types::Ty>& ptys_p4, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody>)>& body_f5, const Text& label_p6, const crate::lower::model::OutTy& t_p7);

prism_rtl::JobRef<crate::lower::model::Ex> start_clauses_body(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Array<crate::syntax::decls::FnClause> clauses_p2, Array<std::tuple<Text, bool>> names_p3, Array<crate::check::types::Ty> ptys_p4, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody>)> body_f5, Text label_p6, crate::lower::model::OutTy t_p7);

crate::syntax::decls::FnClause dummy_clause();

crate::lower::model::Ex fn_body_value(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::decls::FnBody& fn_body2);

prism_rtl::JobRef<crate::lower::model::Ex> start_fn_body_value(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::decls::FnBody fn_body2);

crate::lower::model::FnDef fn_def_of(const crate::lower::Lx& lx_p0, const Text& qk_p1, const Array<crate::syntax::decls::FnClause>& clauses_p2, const crate::check::types::Scheme& sc_p3);

prism_rtl::JobRef<crate::lower::model::FnDef> start_fn_def_of(crate::lower::Lx lx_p0, Text qk_p1, Array<crate::syntax::decls::FnClause> clauses_p2, crate::check::types::Scheme sc_p3);

Array<Text> ty_params_in(const crate::lower::model::OutTy& t_p0);

Text signature_text(const crate::lower::Lx& lx_p0, const Text& qk_p1);

Text definition_text(const crate::lower::Lx& lx_p0, const Text& qk_p1);

Text src_text(const crate::lower::Lx& lx_p0, const Nat& f_p1, const crate::syntax::Range& r_p2);

Text drop_trailing_comments(const Text& t_p0);

bool is_code_line(const Text& l_p0);

crate::lower::model::FnDef let_getter(const crate::lower::Lx& lx_p0, const Text& qk_p1, const crate::syntax::decls::LetDecl& l_p2);

prism_rtl::JobRef<crate::lower::model::FnDef> start_let_getter(crate::lower::Lx lx_p0, Text qk_p1, crate::syntax::decls::LetDecl l_p2);

bool has_own_show(const crate::lower::Lx& lx_p0, const Text& tn_p1);

Text head_name(const crate::check::types::Ty& ty0);

crate::check::types::Ty self_in(const crate::check::types::Ty& t_p0, const Text& param_p1);

prism_rtl::JobRef<crate::check::types::Ty> start_self_in(crate::check::types::Ty t_p0, Text param_p1);

crate::lower::model::TraitDef trait_def_of(const crate::lower::Lx& lx0_p0, const crate::check::env::TraitInfo& tr_p1);

prism_rtl::JobRef<crate::lower::model::TraitDef> start_trait_def_of(crate::lower::Lx lx0_p0, crate::check::env::TraitInfo tr_p1);

Array<crate::syntax::decls::FnClause> default_clauses(const crate::check::env::G& g_p0, const Text& qk_p1);

Array<crate::syntax::decls::FnClause> default_of(const crate::check::env::Def& d_p0, const Array<crate::syntax::decls::FnClause>& other_p1);

crate::lower::model::ImplDef impl_def_of(const crate::lower::Lx& lx_p0, const crate::check::env::ImplInfo& im_p1);

prism_rtl::JobRef<crate::lower::model::ImplDef> start_impl_def_of(crate::lower::Lx lx_p0, crate::check::env::ImplInfo im_p1);

crate::lower::model::FnDef renamed(const crate::lower::model::FnDef& fd_p0, const Text& n_p1);

bool is_method_of(const crate::check::env::Def& d_p0, const crate::check::env::ImplInfo& im_p1);

Array<crate::syntax::decls::FnClause> method_clauses(const crate::check::env::Def& d_p0);

std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> if_gen_line(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const crate::syntax::Expr& c_p2, const crate::syntax::Block& then_b_p3, const crate::syntax::Block& else_b_p4, const crate::syntax::Expr& e_p5);

prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> start_if_gen_line(crate::lower::node_::Wx wx_p0, crate::lower::types::Env menv_p1, crate::syntax::Expr c_p2, crate::syntax::Block then_b_p3, crate::syntax::Block else_b_p4, crate::syntax::Expr e_p5);

}  // namespace lower::functions


namespace lower::functions {

/// The step machine of `ParamNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParamNames: unbounded fn Lx, [FnClause], [OutTy] -> [((Text, Bool))]
struct ParamNames : prism_rtl::Job<Array<std::tuple<Text, bool>>> {
    crate::lower::Lx lx_p0;
    Array<crate::syntax::decls::FnClause> clauses_p1;
    Array<crate::lower::model::OutTy> pts_p2;
    ParamNames(crate::lower::Lx lx_p0, Array<crate::syntax::decls::FnClause> clauses_p1, Array<crate::lower::model::OutTy> pts_p2) : lx_p0(std::move(lx_p0)), clauses_p1(std::move(clauses_p1)), pts_p2(std::move(pts_p2)) {}
    prism_rtl::Turn<Array<std::tuple<Text, bool>>> cycle() const override;
};


/// The step machine of `ClausesBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClausesBody: unbounded fn Lx, Env, [FnClause], [((Text, Bool))], [Ty], (fn Lx, Env, FnBody -> Ex), Text, OutTy -> Ex
struct ClausesBody : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    Array<crate::syntax::decls::FnClause> clauses_p2;
    Array<std::tuple<Text, bool>> names_p3;
    Array<crate::check::types::Ty> ptys_p4;
    prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody>)> body_f5;
    Text label_p6;
    crate::lower::model::OutTy t_p7;
    ClausesBody(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Array<crate::syntax::decls::FnClause> clauses_p2, Array<std::tuple<Text, bool>> names_p3, Array<crate::check::types::Ty> ptys_p4, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody>)> body_f5, Text label_p6, crate::lower::model::OutTy t_p7) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), clauses_p2(std::move(clauses_p2)), names_p3(std::move(names_p3)), ptys_p4(std::move(ptys_p4)), body_f5(std::move(body_f5)), label_p6(std::move(label_p6)), t_p7(std::move(t_p7)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `FnBodyValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FnBodyValue: unbounded fn Lx, Env, FnBody -> Ex
struct FnBodyValue : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::decls::FnBody fn_body2;
    FnBodyValue(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::decls::FnBody fn_body2) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), fn_body2(std::move(fn_body2)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `FnDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FnDefOf: unbounded fn Lx, Text, [FnClause], Scheme -> FnDef
struct FnDefOf : prism_rtl::Job<crate::lower::model::FnDef> {
    crate::lower::Lx lx_p0;
    Text qk_p1;
    Array<crate::syntax::decls::FnClause> clauses_p2;
    crate::check::types::Scheme sc_p3;
    FnDefOf(crate::lower::Lx lx_p0, Text qk_p1, Array<crate::syntax::decls::FnClause> clauses_p2, crate::check::types::Scheme sc_p3) : lx_p0(std::move(lx_p0)), qk_p1(std::move(qk_p1)), clauses_p2(std::move(clauses_p2)), sc_p3(std::move(sc_p3)) {}
    prism_rtl::Turn<crate::lower::model::FnDef> cycle() const override;
};


/// The step machine of `LetGetter`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LetGetter: unbounded fn Lx, Text, LetDecl -> FnDef
struct LetGetter : prism_rtl::Job<crate::lower::model::FnDef> {
    crate::lower::Lx lx_p0;
    Text qk_p1;
    crate::syntax::decls::LetDecl l_p2;
    LetGetter(crate::lower::Lx lx_p0, Text qk_p1, crate::syntax::decls::LetDecl l_p2) : lx_p0(std::move(lx_p0)), qk_p1(std::move(qk_p1)), l_p2(std::move(l_p2)) {}
    prism_rtl::Turn<crate::lower::model::FnDef> cycle() const override;
};


/// The step machine of `SelfIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SelfIn: unbounded fn Ty, Text -> Ty
struct SelfIn : prism_rtl::Job<crate::check::types::Ty> {
    crate::check::types::Ty t_p0;
    Text param_p1;
    SelfIn(crate::check::types::Ty t_p0, Text param_p1) : t_p0(std::move(t_p0)), param_p1(std::move(param_p1)) {}
    prism_rtl::Turn<crate::check::types::Ty> cycle() const override;
};


/// The step machine of `TraitDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TraitDefOf: unbounded fn Lx, TraitInfo -> TraitDef
struct TraitDefOf : prism_rtl::Job<crate::lower::model::TraitDef> {
    crate::lower::Lx lx0_p0;
    crate::check::env::TraitInfo tr_p1;
    TraitDefOf(crate::lower::Lx lx0_p0, crate::check::env::TraitInfo tr_p1) : lx0_p0(std::move(lx0_p0)), tr_p1(std::move(tr_p1)) {}
    prism_rtl::Turn<crate::lower::model::TraitDef> cycle() const override;
};


/// The step machine of `ImplDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ImplDefOf: unbounded fn Lx, ImplInfo -> ImplDef
struct ImplDefOf : prism_rtl::Job<crate::lower::model::ImplDef> {
    crate::lower::Lx lx_p0;
    crate::check::env::ImplInfo im_p1;
    ImplDefOf(crate::lower::Lx lx_p0, crate::check::env::ImplInfo im_p1) : lx_p0(std::move(lx_p0)), im_p1(std::move(im_p1)) {}
    prism_rtl::Turn<crate::lower::model::ImplDef> cycle() const override;
};


/// The step machine of `IfGenLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IfGenLine: unbounded fn Wx, Env, Expr, Block, Block, Expr -> ((Wx, Wres))
struct IfGenLine : prism_rtl::Job<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> {
    crate::lower::node_::Wx wx_p0;
    crate::lower::types::Env menv_p1;
    crate::syntax::Expr c_p2;
    crate::syntax::Block then_b_p3;
    crate::syntax::Block else_b_p4;
    crate::syntax::Expr e_p5;
    IfGenLine(crate::lower::node_::Wx wx_p0, crate::lower::types::Env menv_p1, crate::syntax::Expr c_p2, crate::syntax::Block then_b_p3, crate::syntax::Block else_b_p4, crate::syntax::Expr e_p5) : wx_p0(std::move(wx_p0)), menv_p1(std::move(menv_p1)), c_p2(std::move(c_p2)), then_b_p3(std::move(then_b_p3)), else_b_p4(std::move(else_b_p4)), e_p5(std::move(e_p5)) {}
    prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> cycle() const override;
};


}  // namespace lower::functions

}  // namespace crate
