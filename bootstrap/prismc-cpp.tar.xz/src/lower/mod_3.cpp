// The module `Lower`, from `target/bootstrap/cpp-src/prismc/lower/mod.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <lower/module.hpp>
#include <lower/node_/module.hpp>
#include <syntax/module.hpp>
#include <check/env/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/passes/module.hpp>
#include <check/shrink/module.hpp>
#include <check/typed/module.hpp>
#include <check/types/module.hpp>
#include <lower/model/module.hpp>
#include <syntax/lexer/module.hpp>
#include <lower/node_/generic.hpp>
#include <check/env/generic.hpp>
#include <syntax/lexer/generic.hpp>

namespace crate::lower {

prism_rtl::Turn<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> Instantiations::cycle() const {
    const auto& lx = this->lx;
    const auto& gn = this->gn;
    return fold_job(or_(crate::prelude::get(lx.insts, gen_key(gn)), Array<crate::check::typed::InstNote>{}), Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>{}, ({
        auto lx_1 = lx;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>(std::tuple<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>, crate::check::typed::InstNote>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>, crate::check::typed::InstNote> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto u = p1;
                call_then(start_expanded(lx_1_2, inst_at(lx_1_2, u)), [=](Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> expanded_87467) {
                return prism_rtl::finished(fold(expanded_87467, acc, [&](const Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>& a, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& i) {
                    return fold(a, false, [&](const bool& seen, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& j) { return seen || (show_text(j) == show_text(i)); })
                        ? a
                        : crate::prelude::push(a, i);
                }));
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start Instantiations, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> start_instantiations(Lx lx, crate::check::typed::GenNote gn) {
    return prism_rtl::make_rc<Instantiations>(lx, gn);
}


/// Expanded: unbounded fn Lx, (([((Text, Ty))], [((Text, Col))])) -> [(([((Text, Ty))], [((Text, Col))]))]
Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> expanded(const Lx& lx, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& i) {
    auto&& _m = open_q(lx, i);
    if (prism_rtl::is_none(_m)) {
        return Array(std::vector{i});
    }
    if (prism_rtl::is_some(_m)) {
        auto&& q = prism_rtl::some_of(_m);
        auto&& _m = crate::prelude::get(lx.gen_of_q, q);
        if (prism_rtl::is_some(_m)) {
            auto&& g = prism_rtl::some_of(_m);
            return run_to_end(fold_job(instantiations(lx, g), Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>{}, ({
                auto lx_1 = lx;
                auto i_2 = i;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>(std::tuple<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>, std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>, std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto lx_1_3 = lx_1;
                    auto i_2_3 = i_2;
                    entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto gi = p1;
                        ({
                        auto lx2 = at_instance(lx_1_3, gi);
                        call_then(start_expanded(lx2, subst_inst(lx2, i_2_3)), [=](Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> expanded_87900) { return prism_rtl::finished(append(acc, expanded_87900)); });
                    });
                    });
                }));
                });
            }));
            })));
        }
        if (prism_rtl::is_none(_m)) {
            return Array(std::vector{i});
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> Expanded::cycle() const {
    const auto& lx = this->lx;
    const auto& i = this->i;
    auto i_1 = i;
    auto lx_2 = lx;
    return call_then(start_open_q(lx_2, i_1), [=](std::optional<Text> open_q_87718) {
        return ({
            prism_rtl::is_none(open_q_87718) ? prism_rtl::finished(Array(std::vector{i_1}))
            : prism_rtl::is_some(open_q_87718) ? ({
            auto&& q = prism_rtl::some_of(open_q_87718);
            ({
            auto&& _m = crate::prelude::get(lx_2.gen_of_q, q);
            prism_rtl::is_some(_m) ? ({
            auto&& g = prism_rtl::some_of(_m);
            call_then(start_instantiations(lx_2, g), [=](Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> instantiations_87795) {
            return fold_job(instantiations_87795, Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>{}, ({
                auto lx_2_3 = lx_2;
                auto i_1_3 = i_1;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>(std::tuple<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>, std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>, std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto lx_2_3_3 = lx_2_3;
                    auto i_1_3_3 = i_1_3;
                    entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto gi = p1;
                        ({
                        auto lx2 = at_instance(lx_2_3_3, gi);
                        call_then(start_expanded(lx2, subst_inst(lx2, i_1_3_3)), [=](Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> expanded_87900) { return prism_rtl::finished(append(acc, expanded_87900)); });
                    });
                    });
                }));
                });
            }));
            }))->cycle();
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(Array(std::vector{i_1}))
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
    });
}


/// `Start Expanded, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> start_expanded(Lx lx, std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>> i) {
    return prism_rtl::make_rc<Expanded>(lx, i);
}


/// SubstInst: fn Lx, (([((Text, Ty))], [((Text, Col))])) -> (([((Text, Ty))], [((Text, Col))]))
std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>> subst_inst(const Lx& lx, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& arg1) {
    {
        auto&& tys = std::get<0>(arg1);
        auto&& cols = std::get<1>(arg1);
        auto tys2 = each(tys, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
            auto&& q = std::get<0>(_p0);
            auto&& t = std::get<1>(_p0);
            return std::tuple{q, subst_ty(lx, t)};
        });
        auto cols2 = each(cols, [&](const std::tuple<Text, crate::check::types::Col>& _p0) {
            auto&& q = std::get<0>(_p0);
            auto&& c = std::get<1>(_p0);
            return std::tuple{q, inst_col(lx, c)};
        });
        return std::tuple{tys2, cols2};
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?OpenQ: unbounded fn Lx, (([((Text, Ty))], [((Text, Col))])) -> ?Text
std::optional<Text> open_q(const Lx& lx, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& arg1) {
    {
        auto&& tys = std::get<0>(arg1);
        auto&& cols = std::get<1>(arg1);
        auto from_cols = fold(cols, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, crate::check::types::Col>& _p1) {
            auto&& c = std::get<1>(_p1);
            return append(acc, open_cols(lx, c));
        });
        auto all = run_to_end(fold_job(tys, from_cols, ({
            auto lx_1 = lx;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, std::tuple<Text, crate::check::types::Ty>>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, std::tuple<Text, crate::check::types::Ty>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_1_2 = lx_1;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto&& _t = p1;
                    auto&& t = std::get<1>(_t);
                    call_then(start_open_ty_qs(lx_1_2, t), [=](Array<Text> open_ty_qs_88581) { return prism_rtl::finished(append(acc, open_ty_qs_88581)); });
                });
            }));
            });
        })));
        })));
        return index(all, Nat(0u));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::optional<Text>> OpenQ::cycle() const {
    const auto& lx = this->lx;
    const auto& arg1 = this->arg1;
    return ({
        ({
        auto&& tys = std::get<0>(arg1);
        auto&& cols = std::get<1>(arg1);
        ({
        auto from_cols = fold(cols, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, crate::check::types::Col>& _p1) {
            auto&& c = std::get<1>(_p1);
            return append(acc, open_cols(lx, c));
        });
        auto lx_1 = lx;
        auto tys_2 = tys;
        call_value(fold_job(tys_2, from_cols, ({
        auto lx_1_3 = lx_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, std::tuple<Text, crate::check::types::Ty>>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, std::tuple<Text, crate::check::types::Ty>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_3_3 = lx_1_3;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto&& _t = p1;
                auto&& t = std::get<1>(_t);
                call_then(start_open_ty_qs(lx_1_3_3, t), [=](Array<Text> open_ty_qs_88581) { return prism_rtl::finished(append(acc, open_ty_qs_88581)); });
            });
        }));
        });
    })));
    })), [=](Array<Text> fold_88526) {
        return ({
            auto all = fold_88526;
            (prism_rtl::finished(index(all, Nat(0u))));
        });
    });
    });
    });
    });
}


/// `Start OpenQ, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Text>> start_open_q(Lx lx, std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>> arg1) {
    return prism_rtl::make_rc<OpenQ>(lx, arg1);
}


/// OpenCols: fn Lx, Col -> [Text]
Array<Text> open_cols(const Lx& lx, const crate::check::types::Col& col1) {
    if (prism_rtl::is<crate::check::types::Col::CQ>(col1)) {
        auto&& q = prism_rtl::as<crate::check::types::Col::CQ>(col1).a0;
        return crate::check::env::has_key(lx.gen_of_q, q) && (!crate::check::env::has_key(lx.csubst, q))
            ? Array(std::vector{q})
            : Array<Text>{};
    }
    {
        auto&& c = col1;
        return Array<Text>{};
    }
}


/// OpenTyQs: unbounded fn Lx, Ty -> [Text]
Array<Text> open_ty_qs(const Lx& lx, const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyFlex>(t).a0;
        return crate::check::env::has_key(lx.gen_of_q, prism_rtl::cat("'", n)) && (!crate::check::env::has_key(lx.subst, prism_rtl::cat("'", n)))
            ? Array(std::vector{prism_rtl::cat("'", n)})
            : Array<Text>{};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t)) {
        auto&& c = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        return run_to_end(fold_job(crate::prelude::push(ps, res), open_cols(lx, c), ({
            auto lx_1 = lx;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_1_2 = lx_1;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto x = p1;
                    call_then(start_open_ty_qs(lx_1_2, x), [=](Array<Text> open_ty_qs_89017) { return prism_rtl::finished(append(acc, open_ty_qs_89017)); });
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        return run_to_end(fold_job(args, Array<Text>{}, ({
            auto lx_1 = lx;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_1_2 = lx_1;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto x = p1;
                    call_then(start_open_ty_qs(lx_1_2, x), [=](Array<Text> open_ty_qs_89097) { return prism_rtl::finished(append(acc, open_ty_qs_89097)); });
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        return run_to_end(fold_job(ts, Array<Text>{}, ({
            auto lx_1 = lx;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_1_2 = lx_1;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto x = p1;
                    call_then(start_open_ty_qs(lx_1_2, x), [=](Array<Text> open_ty_qs_89167) { return prism_rtl::finished(append(acc, open_ty_qs_89167)); });
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        return open_ty_qs(lx, e);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        return append(open_ty_qs(lx, k), open_ty_qs(lx, v_));
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        return open_ty_qs(lx, i);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a0;
        return open_ty_qs(lx, i);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t)) {
        auto&& o = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a1;
        return open_ty_qs(lx, o);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t)) {
        auto&& a = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t).a1;
        return open_ty_qs(lx, a);
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> OpenTyQs::cycle() const {
    const auto& lx = this->lx;
    const auto& t = this->t;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyFlex>(t) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyFlex>(t).a0;
        crate::check::env::has_key(lx.gen_of_q, prism_rtl::cat("'", n)) && (!crate::check::env::has_key(lx.subst, prism_rtl::cat("'", n)))
        ? prism_rtl::finished(Array(std::vector{prism_rtl::cat("'", n)}))
        : prism_rtl::finished(Array<Text>{});
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(t) ? ({
        auto&& c = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        fold_job(crate::prelude::push(ps, res), open_cols(lx, c), ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto x = p1;
                call_then(start_open_ty_qs(lx_1_2, x), [=](Array<Text> open_ty_qs_89017) { return prism_rtl::finished(append(acc, open_ty_qs_89017)); });
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) ? ({
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        fold_job(args, Array<Text>{}, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto x = p1;
                call_then(start_open_ty_qs(lx_1_2, x), [=](Array<Text> open_ty_qs_89097) { return prism_rtl::finished(append(acc, open_ty_qs_89097)); });
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        fold_job(ts, Array<Text>{}, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto x = p1;
                call_then(start_open_ty_qs(lx_1_2, x), [=](Array<Text> open_ty_qs_89167) { return prism_rtl::finished(append(acc, open_ty_qs_89167)); });
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        prism_rtl::more(prism_rtl::rc(OpenTyQs(lx, e)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        ({
        auto k_1 = k;
        auto lx_2 = lx;
        auto v__3 = v_;
        call_then(start_open_ty_qs(lx_2, k_1), [=](Array<Text> open_ty_qs_89237) { return call_then(start_open_ty_qs(lx_2, v__3), [=](Array<Text> open_ty_qs_89255) { return prism_rtl::finished(append(open_ty_qs_89237, open_ty_qs_89255)); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t) ? ({
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        prism_rtl::more(prism_rtl::rc(OpenTyQs(lx, i)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyAt>(t) ? ({
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a0;
        prism_rtl::more(prism_rtl::rc(OpenTyQs(lx, i)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyElem>(t) ? ({
        auto&& o = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a1;
        prism_rtl::more(prism_rtl::rc(OpenTyQs(lx, o)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyAssoc>(t) ? ({
        auto&& a = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t).a1;
        prism_rtl::more(prism_rtl::rc(OpenTyQs(lx, a)));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start OpenTyQs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_open_ty_qs(Lx lx, crate::check::types::Ty t) {
    return prism_rtl::make_rc<OpenTyQs>(lx, t);
}


/// AtInstance: fn Lx, (([((Text, Ty))], [((Text, Col))])) -> Lx
Lx at_instance(const Lx& lx, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& arg1) {
    {
        auto&& tys = std::get<0>(arg1);
        auto&& cols = std::get<1>(arg1);
        Lx this_ = lx;
        this_.subst = fold(tys, this_.subst, [&](const Map<Text, crate::check::types::Ty>& m, const std::tuple<Text, crate::check::types::Ty>& _p1) {
            auto&& q = std::get<0>(_p1);
            auto&& t = std::get<1>(_p1);
            return insert(m, q, t);
        });
        this_.csubst = fold(cols, this_.csubst, [&](const Map<Text, crate::check::types::Col>& m, const std::tuple<Text, crate::check::types::Col>& _p1) {
            auto&& q = std::get<0>(_p1);
            auto&& c = std::get<1>(_p1);
            return insert(m, q, c);
        });
        return this_;
    }
    prism_rtl::unreachable("no arm matched");
}


/// WidgetLetLx: unbounded fn Lx, Range -> Lx
Lx widget_let_lx(const Lx& lx, const crate::syntax::Range& span) {
    auto&& _m = crate::prelude::get(lx.gens, place_key(lx, span));
    if (prism_rtl::is_some(_m)) {
        auto&& gn = prism_rtl::some_of(_m);
        auto&& _m = instantiations(lx, gn);
        {
            auto&& m90076_0 = _m;
            if (m90076_0.size() == 1u) {
                {
                    auto&& _c1 = index(m90076_0, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& i = prism_rtl::some_of(_c1);
                        return at_instance(lx, i);
                    }
                }
            }
        }
        {
            return lx;
        }
    }
    if (prism_rtl::is_none(_m)) {
        return lx;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Lx> WidgetLetLx::cycle() const {
    const auto& lx = this->lx;
    const auto& span = this->span;
    return ({
        auto&& _m = crate::prelude::get(lx.gens, place_key(lx, span));
        prism_rtl::is_some(_m) ? ({
        auto&& gn = prism_rtl::some_of(_m);
        ({
        auto lx_1 = lx;
        call_then(start_instantiations(lx_1, gn), [=](Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> instantiations_90082) {
        return ({
            ({
            auto&& m90076_0 = instantiations_90082;
            (m90076_0.size() == 1u) && ({
            auto&& _c1 = index(m90076_0, Nat(0u));
            prism_rtl::is_some(_c1);
        });
        }) ? ({
            auto&& m90076_0 = instantiations_90082;
            auto&& _c1 = index(m90076_0, Nat(0u));
            auto&& i = prism_rtl::some_of(_c1);
            prism_rtl::finished(at_instance(lx_1, i));
        })
            : prism_rtl::finished(lx_1);
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(lx)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start WidgetLetLx, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Lx> start_widget_let_lx(Lx lx, crate::syntax::Range span) {
    return prism_rtl::make_rc<WidgetLetLx>(lx, span);
}


/// InstAt: fn Lx, InstNote -> (([((Text, Ty))], [((Text, Col))]))
std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>> inst_at(const Lx& lx, const crate::check::typed::InstNote& u) {
    auto tys = each(u.tys, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
        auto&& q = std::get<0>(_p0);
        auto&& t = std::get<1>(_p0);
        return std::tuple{q, subst_ty(lx, t)};
    });
    auto cols = each(u.cols, [&](const std::tuple<Text, crate::check::types::Col>& _p0) {
        auto&& q = std::get<0>(_p0);
        auto&& c = std::get<1>(_p0);
        return std::tuple{q, inst_col(lx, c)};
    });
    return std::tuple{tys, cols};
}


/// GenKey: fn GenNote -> Text
Text gen_key(const crate::check::typed::GenNote& gn) {
    return or_(index(append(gn.tys, gn.cols), Nat(0u)), Text::lit(""));
}


/// InstKey: fn InstNote -> Text
Text inst_key(const crate::check::typed::InstNote& u) {
    return or_(index(append(each(u.tys, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
        auto&& q = std::get<0>(_p0);
        return q;
    }), each(u.cols, [&](const std::tuple<Text, crate::check::types::Col>& _p0) {
        auto&& q = std::get<0>(_p0);
        return q;
    })), Nat(0u)), Text::lit(""));
}


/// ColName: fn Col -> Text
Text col_name(const crate::check::types::Col& col0) {
    if (prism_rtl::is<crate::check::types::Col::CQ>(col0)) {
        auto&& q = prism_rtl::as<crate::check::types::Col::CQ>(col0).a0;
        return q;
    }
    {
        auto&& c = col0;
        return Text::lit("");
    }
}


/// PlainLet: unbounded fn Lx, Env, Stmt, Pattern, Expr -> (([Do], Env))
std::tuple<Array<crate::lower::model::Do>, Env> plain_let(const Lx& lx, const Env& env, const crate::syntax::Stmt& s, const crate::syntax::Pattern_& p_, const crate::syntax::Expr& x) {
    auto v_ = value_of(lx, env, x);
    auto po = rust_pat(lx, p_, type_at(lx, x.span), Holding(Holding::Owned{}), prism_rtl::cat("l", s.span.start));
    return std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{po.pa, own(v_)})}), bind_all(env, po.binds)};
}


prism_rtl::Turn<std::tuple<Array<crate::lower::model::Do>, Env>> PlainLet::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& s = this->s;
    const auto& p_ = this->p_;
    const auto& x = this->x;
    auto env_1 = env;
    auto lx_2 = lx;
    auto p__3 = p_;
    auto s_4 = s;
    auto x_5 = x;
    return call_then(start_value_of(lx_2, env_1, x_5), [=](Vl value_of_90867) {
        return ({
            auto v_ = value_of_90867;
            call_then(start_rust_pat(lx_2, p__3, type_at(lx_2, x_5.span), Holding(Holding::Owned{}), prism_rtl::cat("l", s_4.span.start)), [=](PatOut rust_pat_90903) {
            return ({
                auto po = rust_pat_90903;
                (prism_rtl::finished(std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{po.pa, own(v_)})}), bind_all(env_1, po.binds)}));
            });
        });
        });
    });
}


/// `Start PlainLet, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, Env>> start_plain_let(Lx lx, Env env, crate::syntax::Stmt s, crate::syntax::Pattern_ p_, crate::syntax::Expr x) {
    return prism_rtl::make_rc<PlainLet>(lx, env, s, p_, x);
}


/// PatOnly: fn Pa -> PatOut
PatOut pat_only(const crate::lower::model::Pa& pa) {
    return PatOut{.pa = pa, .conds = Array<crate::lower::model::Cc>{}, .binds = Array<std::tuple<Text, Bn>>{}};
}


/// RustPat: unbounded fn Lx, Pattern, Ty, Holding, Text -> PatOut
PatOut rust_pat(const Lx& lx, const crate::syntax::Pattern_& p_, const crate::check::types::Ty& ty, const Holding& mode, const Text& fresh) {
    auto&& _m = p_.kind;
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        auto nkey = crate::check::env::sname_key(n);
        auto [qk_opt, why] = crate::check::env::resolve_value(lx.g, lx.home, n);
        auto is_ctor = ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& qk = prism_rtl::some_of(qk_opt);
                _v.set(crate::check::env::has_key(lx.g.ctors, qk) && ((crate::check::env::is_upper_text(base(nkey)) || (len(n->path_) > Nat(1u))) || is_unit_ctor(lx, qk)));
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto tagged_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<crate::check::env::TagInfo>> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& qk = prism_rtl::some_of(qk_opt);
                _v.set(crate::prelude::get(lx.g.tags, qk));
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(std::optional<crate::check::env::TagInfo>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return is_ctor
            ? ctor_pat(lx, n, Array<crate::syntax::Pattern_>{}, ty, mode, fresh)
            : (why == Text::lit("tag")) && (tagged_opt != std::optional<crate::check::env::TagInfo>{})
            ? tag_pat(lx, or_(tagged_opt, dummy_tag_info()), Array<crate::syntax::FieldPat>{}, true, ty, mode, fresh)
            : ({
            auto rs = local_name(lx, nkey);
            auto bt = out_ty_of(lx, peel(binder_ty(lx, n.span)));
            PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{rs}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array(std::vector{std::tuple{nkey, Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs}), mode, bt})}})};
        });
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m)) {
        return pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PUnit>(_m)) {
        return pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PNil>(_m)) {
        return pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{Text::lit("None")}));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PLit>(_m)) {
        auto&& l = prism_rtl::as<crate::syntax::PatternKind::PLit>(_m).a0;
        return lit_pat(lx, l, ty, mode, fresh, false);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PNeg>(_m)) {
        auto&& l = prism_rtl::as<crate::syntax::PatternKind::PNeg>(_m).a0;
        return lit_pat(lx, l, ty, mode, fresh, true);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m)) {
        auto&& m91829_6_0 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        if (m91829_6_0 == Text::lit("?")) {
            return wrap_pat(lx, Text::lit("Some"), q, inner_ty(ty), mode, fresh);
        }
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m)) {
        auto&& m91829_7_0 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        if (m91829_7_0 == Text::lit("~")) {
            return wrap_pat(lx, Text::lit("Ok"), q, inner_ty(ty), mode, fresh);
        }
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m)) {
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        return rust_pat(lx, q, ty, mode, fresh);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return rust_pat(lx, q, ty, mode, fresh);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PCtor>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a0;
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a1;
        return ctor_pat(lx, n, ps, ty, mode, fresh);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PRecord>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a0;
        auto&& fps = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a1;
        auto&& rest = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a2;
        return record_pat(lx, n, fps, rest, ty, mode, fresh);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m)) {
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        auto ts = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
            auto&& _m = peel(ty);
            if (prism_rtl::is<crate::check::types::Ty::TyTuple>(_m)) {
                auto&& xs = prism_rtl::as<crate::check::types::Ty::TyTuple>(_m).a0;
                _v.set(xs);
                goto _done;
            }
            {
                _v.set(Array<crate::check::types::Ty>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto subs = run_to_end(each_job(crate::check::errors::range0(len(ps)), ({
            auto lx_1 = lx;
            auto ps_2 = ps;
            auto ts_3 = ts;
            auto mode_4 = mode;
            auto fresh_5 = fresh;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto lx_1_6 = lx_1;
                auto ps_2_6 = ps_2;
                auto ts_3_6 = ts_3;
                auto mode_4_6 = mode_4;
                auto fresh_5_6 = fresh_5;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    (prism_rtl::more(prism_rtl::rc(RustPat(lx_1_6, or_(index(ps_2_6, i), dummy_pat()), or_(index(ts_3_6, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), mode_4_6, prism_rtl::cat(fresh_5_6, "_", i)))));
                });
            }));
            });
        })));
        })));
        return PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(subs, [&](const PatOut& o) { return o.pa; })}), .conds = fold(subs, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc, const PatOut& o) { return append(acc, o.conds); }), .binds = fold(subs, Array<std::tuple<Text, Bn>>{}, [&](const Array<std::tuple<Text, Bn>>& acc, const PatOut& o) { return append(acc, o.binds); })};
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PArray>(_m)) {
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PArray>(_m).a0;
        return array_pat(lx, ps, ty, mode, fresh);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PFamily>(_m)) {
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PFamily>(_m).a0;
        return family_pat(lx, q, ty, fresh);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<PatOut> RustPat::cycle() const {
    const auto& lx = this->lx;
    const auto& p_ = this->p_;
    const auto& ty = this->ty;
    const auto& mode = this->mode;
    const auto& fresh = this->fresh;
    return ({
        auto&& _m = p_.kind;
        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        ({
        auto nkey = crate::check::env::sname_key(n);
        auto [qk_opt, why] = crate::check::env::resolve_value(lx.g, lx.home, n);
        auto is_ctor = ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& qk = prism_rtl::some_of(qk_opt);
                _v.set(crate::check::env::has_key(lx.g.ctors, qk) && ((crate::check::env::is_upper_text(base(nkey)) || (len(n->path_) > Nat(1u))) || is_unit_ctor(lx, qk)));
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto tagged_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<crate::check::env::TagInfo>> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& qk = prism_rtl::some_of(qk_opt);
                _v.set(crate::prelude::get(lx.g.tags, qk));
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(std::optional<crate::check::env::TagInfo>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        is_ctor
        ? prism_rtl::more(prism_rtl::rc(CtorPat(lx, n, Array<crate::syntax::Pattern_>{}, ty, mode, fresh)))
        : (why == Text::lit("tag")) && (tagged_opt != std::optional<crate::check::env::TagInfo>{})
        ? prism_rtl::more(prism_rtl::rc(TagPat(lx, or_(tagged_opt, dummy_tag_info()), Array<crate::syntax::FieldPat>{}, true, ty, mode, fresh)))
        : ({
        auto rs = local_name(lx, nkey);
        auto lx_1 = lx;
        auto mode_2 = mode;
        auto n_3 = n;
        call_then(start_out_ty_of(lx_1, peel(binder_ty(lx_1, n_3.span))), [=](crate::lower::model::OutTy out_ty_of_92447) {
        return ({
            auto bt = out_ty_of_92447;
            (prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{rs}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array(std::vector{std::tuple{nkey, Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs}), mode_2, bt})}})}));
        });
    });
    });
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m) ? prism_rtl::finished(pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})))
        : prism_rtl::is<crate::syntax::PatternKind::PUnit>(_m) ? prism_rtl::finished(pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})))
        : prism_rtl::is<crate::syntax::PatternKind::PNil>(_m) ? prism_rtl::finished(pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{Text::lit("None")})))
        : prism_rtl::is<crate::syntax::PatternKind::PLit>(_m) ? ({
        auto&& l = prism_rtl::as<crate::syntax::PatternKind::PLit>(_m).a0;
        prism_rtl::more(prism_rtl::rc(LitPat(lx, l, ty, mode, fresh, false)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PNeg>(_m) ? ({
        auto&& l = prism_rtl::as<crate::syntax::PatternKind::PNeg>(_m).a0;
        prism_rtl::more(prism_rtl::rc(LitPat(lx, l, ty, mode, fresh, true)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m) && ({
        auto&& m91829_6_0 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        (m91829_6_0 == Text::lit("?"));
    }) ? ({
        auto&& m91829_6_0 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        prism_rtl::more(prism_rtl::rc(WrapPat(lx, Text::lit("Some"), q, inner_ty(ty), mode, fresh)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m) && ({
        auto&& m91829_7_0 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        (m91829_7_0 == Text::lit("~"));
    }) ? ({
        auto&& m91829_7_0 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        prism_rtl::more(prism_rtl::rc(WrapPat(lx, Text::lit("Ok"), q, inner_ty(ty), mode, fresh)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m) ? ({
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        prism_rtl::more(prism_rtl::rc(RustPat(lx, q, ty, mode, fresh)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m) ? ({
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(RustPat(lx, q, ty, mode, fresh)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PCtor>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a0;
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a1;
        prism_rtl::more(prism_rtl::rc(CtorPat(lx, n, ps, ty, mode, fresh)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PRecord>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a0;
        auto&& fps = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a1;
        auto&& rest = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a2;
        prism_rtl::more(prism_rtl::rc(RecordPat(lx, n, fps, rest, ty, mode, fresh)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m) ? ({
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        ({
        auto ts = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
            auto&& _m = peel(ty);
            if (prism_rtl::is<crate::check::types::Ty::TyTuple>(_m)) {
                auto&& xs = prism_rtl::as<crate::check::types::Ty::TyTuple>(_m).a0;
                _v.set(xs);
                goto _done;
            }
            {
                _v.set(Array<crate::check::types::Ty>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto fresh_1 = fresh;
        auto lx_2 = lx;
        auto mode_3 = mode;
        auto ps_4 = ps;
        call_value(each_job(crate::check::errors::range0(len(ps_4)), ({
        auto lx_2_5 = lx_2;
        auto ps_4_5 = ps_4;
        auto ts_5 = ts;
        auto mode_3_6 = mode_3;
        auto fresh_1_6 = fresh_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto lx_2_5_6 = lx_2_5;
            auto ps_4_5_6 = ps_4_5;
            auto ts_5_6 = ts_5;
            auto mode_3_6_6 = mode_3_6;
            auto fresh_1_6_6 = fresh_1_6;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(RustPat(lx_2_5_6, or_(index(ps_4_5_6, i), dummy_pat()), or_(index(ts_5_6, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), mode_3_6_6, prism_rtl::cat(fresh_1_6_6, "_", i)))));
            });
        }));
        });
    })));
    })), [=](Array<PatOut> each_93246) {
        return ({
            auto subs = each_93246;
            (prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(subs, [&](const PatOut& o) { return o.pa; })}), .conds = fold(subs, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc, const PatOut& o) { return append(acc, o.conds); }), .binds = fold(subs, Array<std::tuple<Text, Bn>>{}, [&](const Array<std::tuple<Text, Bn>>& acc, const PatOut& o) { return append(acc, o.binds); })}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PArray>(_m) ? ({
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PArray>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ArrayPat(lx, ps, ty, mode, fresh)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PFamily>(_m) ? ({
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PFamily>(_m).a0;
        prism_rtl::more(prism_rtl::rc(FamilyPat(lx, q, ty, fresh)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start RustPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_rust_pat(Lx lx, crate::syntax::Pattern_ p_, crate::check::types::Ty ty, Holding mode, Text fresh) {
    return prism_rtl::make_rc<RustPat>(lx, p_, ty, mode, fresh);
}


/// let dummyPat
crate::syntax::Pattern_ dummy_pat() {
    return crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// InnerTy: fn Ty -> Ty
crate::check::types::Ty inner_ty(const crate::check::types::Ty& t) {
    auto&& _m = peel(t);
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& m93705_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        if (m93705_0_0 == Text::lit("?")) {
            return i;
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& m93705_1_0 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        if (m93705_1_0 == Text::lit("~")) {
            return i;
        }
    }
    {
        return crate::check::types::Ty(crate::check::types::Ty::TyErr{});
    }
}


/// IsUnitCtor: fn Lx, Text -> Bool
bool is_unit_ctor(const Lx& lx, const Text& qk) {
    auto&& _m = crate::prelude::get(lx.g.ctors, qk);
    if (prism_rtl::is_some(_m)) {
        auto&& c = prism_rtl::some_of(_m);
        auto&& _m = or_(crate::prelude::get(lx.g.types, c.owner), crate::check::env::dummy_ty_info()).body;
        if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
            auto&& m93958_0_0 = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
            if (m93958_0_0.size() == 1u) {
                {
                    auto&& _c2 = index(m93958_0_0, Nat(0u));
                    if (prism_rtl::is_some(_c2)) {
                        auto&& m93958_0_0_0_1 = std::get<1>(prism_rtl::some_of(_c2));
                        if (m93958_0_0_0_1.size() == 0u) {
                            return crate::check::env::is_lower_text(crate::check::types::bare_name(qk));
                        }
                    }
                }
            }
        }
        {
            return false;
        }
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// WrapPat: unbounded fn Lx, Text, Pattern, Ty, Holding, Text -> PatOut
PatOut wrap_pat(const Lx& lx, const Text& ctor, const crate::syntax::Pattern_& q, const crate::check::types::Ty& inner, const Holding& mode, const Text& fresh) {
    auto o = rust_pat(lx, q, inner, mode, fresh);
    PatOut this_ = o;
    this_.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{ctor, Array(std::vector{this_.pa})});
    return this_;
}


prism_rtl::Turn<PatOut> WrapPat::cycle() const {
    const auto& lx = this->lx;
    const auto& ctor = this->ctor;
    const auto& q = this->q;
    const auto& inner = this->inner;
    const auto& mode = this->mode;
    const auto& fresh = this->fresh;
    auto ctor_1 = ctor;
    auto fresh_2 = fresh;
    auto inner_3 = inner;
    auto lx_4 = lx;
    auto mode_5 = mode;
    auto q_6 = q;
    return call_then(start_rust_pat(lx_4, q_6, inner_3, mode_5, fresh_2), [=](PatOut rust_pat_94238) {
        return ({
            auto o = rust_pat_94238;
            (prism_rtl::finished(({
            PatOut this_ = o;
            this_.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{ctor_1, Array(std::vector{this_.pa})});
            this_;
        })));
        });
    });
}


/// `Start WrapPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_wrap_pat(Lx lx, Text ctor, crate::syntax::Pattern_ q, crate::check::types::Ty inner, Holding mode, Text fresh) {
    return prism_rtl::make_rc<WrapPat>(lx, ctor, q, inner, mode, fresh);
}


/// LitPat: unbounded fn Lx, Literal, Ty, Holding, Text, Bool -> PatOut
PatOut lit_pat(const Lx& lx, const crate::syntax::Literal& l, const crate::check::types::Ty& ty, const Holding& mode, const Text& fresh, const bool& neg) {
    auto t = out_ty_of(lx, peel(ty));
    auto&& _m = l.kind;
    if (prism_rtl::is<crate::syntax::LitKind::LChar>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::LitKind::LChar>(_m).a0;
        return pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaChar{c}));
    }
    {
        auto lit = ({
            __label__ _done;
            prism_rtl::Slot<Vl> _v;
            auto&& _m = l.kind;
            if (prism_rtl::is<crate::syntax::LitKind::LInt>(_m)) {
                auto&& d = prism_rtl::as<crate::syntax::LitKind::LInt>(_m).a0;
                _v.set((((t == crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{})) || (t == crate::lower::model::OutTy(crate::lower::model::OutTy::OutInt{}))) || (t == crate::lower::model::OutTy(crate::lower::model::OutTy::OutU8{}))) || (t == crate::lower::model::OutTy(crate::lower::model::OutTy::OutFloat{}))
                    ? Vl(Vl::VlOwned{number(t, d, neg), t})
                    : literal_value(lx, empty_env(), l, l.span, neg));
                goto _done;
            }
            {
                _v.set(literal_value(lx, empty_env(), l, l.span, neg));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto lv = Vl(Vl::VlOwned{own(lit), t});
        auto b = local_place(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh}), mode, t);
        return PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh}), .conds = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("=="), prism_rtl::rc(ref_(b)), prism_rtl::rc(ref_(lv))})})}), .binds = Array<std::tuple<Text, Bn>>{}};
    }
}


prism_rtl::Turn<PatOut> LitPat::cycle() const {
    const auto& lx = this->lx;
    const auto& l = this->l;
    const auto& ty = this->ty;
    const auto& mode = this->mode;
    const auto& fresh = this->fresh;
    const auto& neg = this->neg;
    auto fresh_1 = fresh;
    auto l_2 = l;
    auto lx_3 = lx;
    auto mode_4 = mode;
    auto neg_5 = neg;
    auto ty_6 = ty;
    return call_then(start_out_ty_of(lx_3, peel(ty_6)), [=](crate::lower::model::OutTy out_ty_of_94550) {
        return ({
            auto t = out_ty_of_94550;
            ({
            auto&& _m = l_2.kind;
            prism_rtl::is<crate::syntax::LitKind::LChar>(_m) ? ({
            auto&& c = prism_rtl::as<crate::syntax::LitKind::LChar>(_m).a0;
            prism_rtl::finished(pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaChar{c})));
        })
            : ({
            auto lit = ({
                __label__ _done;
                prism_rtl::Slot<Vl> _v;
                auto&& _m = l_2.kind;
                if (prism_rtl::is<crate::syntax::LitKind::LInt>(_m)) {
                    auto&& d = prism_rtl::as<crate::syntax::LitKind::LInt>(_m).a0;
                    _v.set((((t == crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{})) || (t == crate::lower::model::OutTy(crate::lower::model::OutTy::OutInt{}))) || (t == crate::lower::model::OutTy(crate::lower::model::OutTy::OutU8{}))) || (t == crate::lower::model::OutTy(crate::lower::model::OutTy::OutFloat{}))
                        ? Vl(Vl::VlOwned{number(t, d, neg_5), t})
                        : literal_value(lx_3, empty_env(), l_2, l_2.span, neg_5));
                    goto _done;
                }
                {
                    _v.set(literal_value(lx_3, empty_env(), l_2, l_2.span, neg_5));
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto lv = Vl(Vl::VlOwned{own(lit), t});
            auto b = local_place(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_1}), mode_4, t);
            (prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh_1}), .conds = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("=="), prism_rtl::rc(ref_(b)), prism_rtl::rc(ref_(lv))})})}), .binds = Array<std::tuple<Text, Bn>>{}}));
        });
        });
        });
    });
}


/// `Start LitPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_lit_pat(Lx lx, crate::syntax::Literal l, crate::check::types::Ty ty, Holding mode, Text fresh, bool neg) {
    return prism_rtl::make_rc<LitPat>(lx, l, ty, mode, fresh, neg);
}


/// CtorPat: unbounded fn Lx, SName, [Pattern], Ty, Holding, Text -> PatOut
PatOut ctor_pat(const Lx& lx, const crate::syntax::SName& n, const Array<crate::syntax::Pattern_>& ps, const crate::check::types::Ty& ty, const Holding& mode, const Text& fresh) {
    auto&& _qk_opt = crate::check::env::resolve_value(lx.g, lx.home, n);
    auto&& qk_opt = std::get<0>(_qk_opt);
    if (prism_rtl::is_some(qk_opt)) {
        auto&& m95593_0 = prism_rtl::some_of(qk_opt);
        if (m95593_0 == Text::lit("True")) {
            return pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaBool{true}));
        }
    }
    if (prism_rtl::is_some(qk_opt)) {
        auto&& m95593_1 = prism_rtl::some_of(qk_opt);
        if (m95593_1 == Text::lit("False")) {
            return pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaBool{false}));
        }
    }
    if (prism_rtl::is_some(qk_opt)) {
        auto&& qk = prism_rtl::some_of(qk_opt);
        auto&& _m = crate::prelude::get(lx.g.ctors, qk);
        if (prism_rtl::is_some(_m)) {
            auto&& c = prism_rtl::some_of(_m);
            auto owner = or_(crate::prelude::get(lx.g.types, c.owner), crate::check::env::dummy_ty_info());
            auto ty_path = path_in(lx, owner.home, camel(crate::check::types::bare_name(c.owner)));
            auto args = ({
                __label__ _done;
                prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
                auto&& _m = peel(ty);
                if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
                    auto&& xs = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
                    _v.set(xs);
                    goto _done;
                }
                {
                    _v.set(Array<crate::check::types::Ty>{});
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto subs = run_to_end(each_job(crate::check::errors::range0(len(ps)), ({
                auto lx_1 = lx;
                auto c_2 = c;
                auto ps_3 = ps;
                auto args_4 = args;
                auto mode_5 = mode;
                auto fresh_6 = fresh;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                return ({
                    auto lx_1_7 = lx_1;
                    auto c_2_7 = c_2;
                    auto ps_3_7 = ps_3;
                    auto args_4_7 = args_4;
                    auto mode_5_7 = mode_5;
                    auto fresh_6_7 = fresh_6;
                    entered(once_job([=]() {
                    return ({
                        auto i = p0;
                        call_then(start_instantiated(or_(index(c_2_7->args, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), c_2_7.params, args_4_7), [=](crate::check::types::Ty instantiated_96097) { return prism_rtl::more(prism_rtl::rc(SubPat(lx_1_7, c_2_7, i, or_(index(ps_3_7, i), dummy_pat()), instantiated_96097, mode_5_7, prism_rtl::cat(fresh_6_7, "_", i)))); });
                    });
                }));
                });
            })));
            })));
            auto conds = fold(subs, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc, const PatOut& o) { return append(acc, o.conds); });
            auto binds = fold(subs, Array<std::tuple<Text, Bn>>{}, [&](const Array<std::tuple<Text, Bn>>& acc, const PatOut& o) { return append(acc, o.binds); });
            auto pas = each(subs, [&](const PatOut& o) { return o.pa; });
            auto&& _m = owner.body;
            if (prism_rtl::is<crate::check::env::TyBody::BRecord>(_m)) {
                auto&& fs = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
                return PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaRecord{ty_path, each(crate::check::errors::range0(len(pas)), [&](const Nat& i) { return std::tuple{snake(or_(index(c.fields, i), Text::lit(""))), or_(index(pas, i), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}))}; }), len(pas) < len(c.fields)}), .conds = conds, .binds = binds};
            }
            {
                auto is_unit_type = (len(c->args) == Nat(0u)) && is_unit_ctor(lx, qk);
                auto is_newtype = (crate::check::types::bare_name(c.name) == crate::check::types::bare_name(c.owner)) && ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = owner.body;
                    if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
                        auto&& cases = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
                        _v.set(len(cases) == Nat(1u));
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto path_ = is_unit_type || is_newtype
                    ? ty_path
                    : prism_rtl::cat(ty_path, "::", camel(crate::check::types::bare_name(c.name)));
                return len(c->args) == Nat(0u)
                    ? PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{path_}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array<std::tuple<Text, Bn>>{}}
                    : PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{path_, pas}), .conds = conds, .binds = binds};
            }
        }
        if (prism_rtl::is_none(_m)) {
            return PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{refusal(prism_rtl::cat("a pattern of ", qk))})}), .binds = Array<std::tuple<Text, Bn>>{}};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_none(qk_opt)) {
        return PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{refusal(Text::lit("a pattern of an unknown constructor"))})}), .binds = Array<std::tuple<Text, Bn>>{}};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<PatOut> CtorPat::cycle() const {
    const auto& lx = this->lx;
    const auto& n = this->n;
    const auto& ps = this->ps;
    const auto& ty = this->ty;
    const auto& mode = this->mode;
    const auto& fresh = this->fresh;
    auto&& _qk_opt = crate::check::env::resolve_value(lx.g, lx.home, n);
    auto&& qk_opt = std::get<0>(_qk_opt);
    return ({
        prism_rtl::is_some(qk_opt) && ({
        auto&& m95593_0 = prism_rtl::some_of(qk_opt);
        (m95593_0 == Text::lit("True"));
    }) ? ({
        auto&& m95593_0 = prism_rtl::some_of(qk_opt);
        prism_rtl::finished(pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaBool{true})));
    })
        : prism_rtl::is_some(qk_opt) && ({
        auto&& m95593_1 = prism_rtl::some_of(qk_opt);
        (m95593_1 == Text::lit("False"));
    }) ? ({
        auto&& m95593_1 = prism_rtl::some_of(qk_opt);
        prism_rtl::finished(pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaBool{false})));
    })
        : prism_rtl::is_some(qk_opt) ? ({
        auto&& qk = prism_rtl::some_of(qk_opt);
        ({
        auto&& _m = crate::prelude::get(lx.g.ctors, qk);
        prism_rtl::is_some(_m) ? ({
        auto&& c = prism_rtl::some_of(_m);
        ({
        auto owner = or_(crate::prelude::get(lx.g.types, c.owner), crate::check::env::dummy_ty_info());
        auto ty_path = path_in(lx, owner.home, camel(crate::check::types::bare_name(c.owner)));
        auto args = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
            auto&& _m = peel(ty);
            if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
                auto&& xs = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
                _v.set(xs);
                goto _done;
            }
            {
                _v.set(Array<crate::check::types::Ty>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto fresh_1 = fresh;
        auto lx_2 = lx;
        auto mode_3 = mode;
        auto ps_4 = ps;
        auto qk_5 = qk;
        call_value(each_job(crate::check::errors::range0(len(ps_4)), ({
        auto lx_2_6 = lx_2;
        auto c_6 = c;
        auto ps_4_7 = ps_4;
        auto args_7 = args;
        auto mode_3_8 = mode_3;
        auto fresh_1_8 = fresh_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto lx_2_6_8 = lx_2_6;
            auto c_6_8 = c_6;
            auto ps_4_7_8 = ps_4_7;
            auto args_7_8 = args_7;
            auto mode_3_8_8 = mode_3_8;
            auto fresh_1_8_8 = fresh_1_8;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                call_then(start_instantiated(or_(index(c_6_8->args, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), c_6_8.params, args_7_8), [=](crate::check::types::Ty instantiated_96097) { return prism_rtl::more(prism_rtl::rc(SubPat(lx_2_6_8, c_6_8, i, or_(index(ps_4_7_8, i), dummy_pat()), instantiated_96097, mode_3_8_8, prism_rtl::cat(fresh_1_8_8, "_", i)))); });
            });
        }));
        });
    })));
    })), [=](Array<PatOut> each_96028) {
        return ({
            auto subs = each_96028;
            auto conds = fold(subs, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc, const PatOut& o) { return append(acc, o.conds); });
            auto binds = fold(subs, Array<std::tuple<Text, Bn>>{}, [&](const Array<std::tuple<Text, Bn>>& acc, const PatOut& o) { return append(acc, o.binds); });
            auto pas = each(subs, [&](const PatOut& o) { return o.pa; });
            ({
            auto&& _m = owner.body;
            prism_rtl::is<crate::check::env::TyBody::BRecord>(_m) ? ({
            auto&& fs = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
            prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaRecord{ty_path, each(crate::check::errors::range0(len(pas)), [&](const Nat& i) { return std::tuple{snake(or_(index(c.fields, i), Text::lit(""))), or_(index(pas, i), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}))}; }), len(pas) < len(c.fields)}), .conds = conds, .binds = binds});
        })
            : ({
            auto is_unit_type = (len(c->args) == Nat(0u)) && is_unit_ctor(lx_2, qk_5);
            auto is_newtype = (crate::check::types::bare_name(c.name) == crate::check::types::bare_name(c.owner)) && ({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = owner.body;
                if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
                    auto&& cases = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
                    _v.set(len(cases) == Nat(1u));
                    goto _done;
                }
                {
                    _v.set(false);
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto path_ = is_unit_type || is_newtype
                ? ty_path
                : prism_rtl::cat(ty_path, "::", camel(crate::check::types::bare_name(c.name)));
            len(c->args) == Nat(0u)
            ? prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{path_}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array<std::tuple<Text, Bn>>{}})
            : prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{path_, pas}), .conds = conds, .binds = binds});
        });
        });
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{refusal(prism_rtl::cat("a pattern of ", qk))})}), .binds = Array<std::tuple<Text, Bn>>{}})
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is_none(qk_opt) ? prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{refusal(Text::lit("a pattern of an unknown constructor"))})}), .binds = Array<std::tuple<Text, Bn>>{}})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CtorPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_ctor_pat(Lx lx, crate::syntax::SName n, Array<crate::syntax::Pattern_> ps, crate::check::types::Ty ty, Holding mode, Text fresh) {
    return prism_rtl::make_rc<CtorPat>(lx, n, ps, ty, mode, fresh);
}


/// SubPat: unbounded fn Lx, CtorInfo, Nat, Pattern, Ty, Holding, Text -> PatOut
PatOut sub_pat(const Lx& lx, const crate::check::env::CtorInfo& c, const Nat& i, const crate::syntax::Pattern_& p_, const crate::check::types::Ty& ty, const Holding& mode, const Text& fresh) {
    return !rc_field(lx, c.name, i)
        ? rust_pat(lx, p_, ty, mode, fresh)
        : ({
        auto rc_mode = mode == Holding(Holding::Owned{})
            ? Holding(Holding::RcOwned{})
            : Holding(Holding::RcRef{});
        ({
        __label__ _done;
        prism_rtl::Slot<PatOut> _v;
        auto&& _m = p_.kind;
        if (prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m)) {
            _v.set(pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            _v.set(({
                auto o = rust_pat(lx, p_, ty, rc_mode, fresh);
                ({
                __label__ _done;
                prism_rtl::Slot<PatOut> _v;
                auto&& _m = o.pa;
                if (prism_rtl::is<crate::lower::model::Pa::PaBind>(_m)) {
                    _v.set(o);
                    goto _done;
                }
                {
                    _v.set(behind_rc(lx, p_, ty, rc_mode, fresh));
                    goto _done;
                }
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        {
            _v.set(behind_rc(lx, p_, ty, rc_mode, fresh));
            goto _done;
        }
    _done:
        _v.take();
    });
    });
}


prism_rtl::Turn<PatOut> SubPat::cycle() const {
    const auto& lx = this->lx;
    const auto& c = this->c;
    const auto& i = this->i;
    const auto& p_ = this->p_;
    const auto& ty = this->ty;
    const auto& mode = this->mode;
    const auto& fresh = this->fresh;
    return !rc_field(lx, c.name, i)
        ? prism_rtl::more(prism_rtl::rc(RustPat(lx, p_, ty, mode, fresh)))
        : ({
        auto rc_mode = mode == Holding(Holding::Owned{})
            ? Holding(Holding::RcOwned{})
            : Holding(Holding::RcRef{});
        ({
        auto&& _m = p_.kind;
        prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m) ? prism_rtl::finished(pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})))
        : prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        ({
        auto fresh_1 = fresh;
        auto lx_2 = lx;
        auto p__3 = p_;
        auto ty_4 = ty;
        call_then(start_rust_pat(lx_2, p__3, ty_4, rc_mode, fresh_1), [=](PatOut rust_pat_97991) {
        return ({
            auto o = rust_pat_97991;
            ({
            auto&& _m = o.pa;
            prism_rtl::is<crate::lower::model::Pa::PaBind>(_m) ? prism_rtl::finished(o)
            : prism_rtl::more(prism_rtl::rc(BehindRc(lx_2, p__3, ty_4, rc_mode, fresh_1)));
        });
        });
    });
    });
    })
        : prism_rtl::more(prism_rtl::rc(BehindRc(lx, p_, ty, rc_mode, fresh)));
    });
    });
}


/// `Start SubPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_sub_pat(Lx lx, crate::check::env::CtorInfo c, Nat i, crate::syntax::Pattern_ p_, crate::check::types::Ty ty, Holding mode, Text fresh) {
    return prism_rtl::make_rc<SubPat>(lx, c, i, p_, ty, mode, fresh);
}


/// BehindRc: unbounded fn Lx, Pattern, Ty, Holding, Text -> PatOut
PatOut behind_rc(const Lx& lx, const crate::syntax::Pattern_& p_, const crate::check::types::Ty& ty, const Holding& rc_mode, const Text& fresh) {
    auto inner = rust_pat(lx, p_, ty, Holding(Holding::ByRef{}), prism_rtl::cat(fresh, "_r"));
    auto place = ref_(local_place(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh}), rc_mode, crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{Text::lit("a payload")})));
    return PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh}), .conds = append(Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcLet{inner.pa, place})}), inner.conds), .binds = inner.binds};
}


prism_rtl::Turn<PatOut> BehindRc::cycle() const {
    const auto& lx = this->lx;
    const auto& p_ = this->p_;
    const auto& ty = this->ty;
    const auto& rc_mode = this->rc_mode;
    const auto& fresh = this->fresh;
    auto fresh_1 = fresh;
    auto lx_2 = lx;
    auto p__3 = p_;
    auto rc_mode_4 = rc_mode;
    auto ty_5 = ty;
    return call_then(start_rust_pat(lx_2, p__3, ty_5, Holding(Holding::ByRef{}), prism_rtl::cat(fresh_1, "_r")), [=](PatOut rust_pat_98330) {
        return ({
            auto inner = rust_pat_98330;
            auto place = ref_(local_place(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_1}), rc_mode_4, crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{Text::lit("a payload")})));
            (prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh_1}), .conds = append(Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcLet{inner.pa, place})}), inner.conds), .binds = inner.binds}));
        });
    });
}


/// `Start BehindRc, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_behind_rc(Lx lx, crate::syntax::Pattern_ p_, crate::check::types::Ty ty, Holding rc_mode, Text fresh) {
    return prism_rtl::make_rc<BehindRc>(lx, p_, ty, rc_mode, fresh);
}


/// RecordPat: unbounded fn Lx, SName, [FieldPat], Bool, Ty, Holding, Text -> PatOut
PatOut record_pat(const Lx& lx, const crate::syntax::SName& n, const Array<crate::syntax::FieldPat>& fps, const bool& rest, const crate::check::types::Ty& ty, const Holding& mode, const Text& fresh) {
    auto [qk_opt, why] = crate::check::env::resolve_value(lx.g, lx.home, n);
    auto qk = or_(qk_opt, Text::lit(""));
    return qk == Text::lit("Prelude.Error")
        ? error_pat(lx, fps, ty, mode, fresh)
        : (why == Text::lit("tag")) && crate::check::env::has_key(lx.g.tags, qk)
        ? tag_pat(lx, or_(crate::prelude::get(lx.g.tags, qk), dummy_tag_info()), fps, rest, ty, mode, fresh)
        : ({
        __label__ _done;
        prism_rtl::Slot<PatOut> _v;
        auto&& _m = crate::prelude::get(lx.g.ctors, qk);
        if (prism_rtl::is_some(_m)) {
            auto&& c = prism_rtl::some_of(_m);
            _v.set(({
                auto owner = or_(crate::prelude::get(lx.g.types, c.owner), crate::check::env::dummy_ty_info());
                auto ty_path = path_in(lx, owner.home, camel(crate::check::types::bare_name(c.owner)));
                ({
                __label__ _done;
                prism_rtl::Slot<PatOut> _v;
                auto&& _m = owner.body;
                if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
                    auto&& cases = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
                    if (len(fps) == Nat(0u)) {
                        _v.set(rest_case_pat(c, cases, ty_path));
                        goto _done;
                    }
                }
                {
                    _v.set(fields_pat(lx, c, fps, rest, ty, mode, fresh, ty_path));
                    goto _done;
                }
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<PatOut> _v;
                auto&& _m = crate::prelude::get(lx.g.tags, qk);
                if (prism_rtl::is_some(_m)) {
                    auto&& tg = prism_rtl::some_of(_m);
                    _v.set(tag_pat(lx, tg, fps, rest, ty, mode, fresh));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{refusal(prism_rtl::cat("a pattern of ", qk))})}), .binds = Array<std::tuple<Text, Bn>>{}});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<PatOut> RecordPat::cycle() const {
    const auto& lx = this->lx;
    const auto& n = this->n;
    const auto& fps = this->fps;
    const auto& rest = this->rest;
    const auto& ty = this->ty;
    const auto& mode = this->mode;
    const auto& fresh = this->fresh;
    auto [qk_opt, why] = crate::check::env::resolve_value(lx.g, lx.home, n);
    auto qk = or_(qk_opt, Text::lit(""));
    return qk == Text::lit("Prelude.Error")
        ? prism_rtl::more(prism_rtl::rc(ErrorPat(lx, fps, ty, mode, fresh)))
        : (why == Text::lit("tag")) && crate::check::env::has_key(lx.g.tags, qk)
        ? prism_rtl::more(prism_rtl::rc(TagPat(lx, or_(crate::prelude::get(lx.g.tags, qk), dummy_tag_info()), fps, rest, ty, mode, fresh)))
        : ({
        auto&& _m = crate::prelude::get(lx.g.ctors, qk);
        prism_rtl::is_some(_m) ? ({
        auto&& c = prism_rtl::some_of(_m);
        ({
        auto owner = or_(crate::prelude::get(lx.g.types, c.owner), crate::check::env::dummy_ty_info());
        auto ty_path = path_in(lx, owner.home, camel(crate::check::types::bare_name(c.owner)));
        ({
        auto&& _m = owner.body;
        prism_rtl::is<crate::check::env::TyBody::BChoice>(_m) && ({
        auto&& cases = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
        (len(fps) == Nat(0u));
    }) ? ({
        auto&& cases = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
        prism_rtl::finished(rest_case_pat(c, cases, ty_path));
    })
        : prism_rtl::more(prism_rtl::rc(FieldsPat(lx, c, fps, rest, ty, mode, fresh, ty_path)));
    });
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto&& _m = crate::prelude::get(lx.g.tags, qk);
        prism_rtl::is_some(_m) ? ({
        auto&& tg = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(TagPat(lx, tg, fps, rest, ty, mode, fresh)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{refusal(prism_rtl::cat("a pattern of ", qk))})}), .binds = Array<std::tuple<Text, Bn>>{}})
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start RecordPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_record_pat(Lx lx, crate::syntax::SName n, Array<crate::syntax::FieldPat> fps, bool rest, crate::check::types::Ty ty, Holding mode, Text fresh) {
    return prism_rtl::make_rc<RecordPat>(lx, n, fps, rest, ty, mode, fresh);
}


/// RestCasePat: fn CtorInfo, [((Text, [Ty]))], Text -> PatOut
PatOut rest_case_pat(const crate::check::env::CtorInfo& c, const Array<std::tuple<Text, Array<crate::check::types::Ty>>>& cases, const Text& ty_path) {
    auto is_newtype = (len(cases) == Nat(1u)) && (crate::check::types::bare_name(c.name) == crate::check::types::bare_name(c.owner));
    auto path_ = is_newtype
        ? ty_path
        : prism_rtl::cat(ty_path, "::", camel(crate::check::types::bare_name(c.name)));
    return len(c->args) == Nat(0u)
        ? PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{path_}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array<std::tuple<Text, Bn>>{}}
        : PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{path_, each(c->args, [&](const crate::check::types::Ty& _p0) { return crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}); })}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array<std::tuple<Text, Bn>>{}};
}


/// FieldsPat: unbounded fn Lx, CtorInfo, [FieldPat], Bool, Ty, Holding, Text, Text -> PatOut
PatOut fields_pat(const Lx& lx, const crate::check::env::CtorInfo& c, const Array<crate::syntax::FieldPat>& fps, const bool& rest, const crate::check::types::Ty& ty, const Holding& mode, const Text& fresh, const Text& ty_path) {
    auto args = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
        auto&& _m = peel(ty);
        if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
            auto&& xs = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
            _v.set(xs);
            goto _done;
        }
        {
            _v.set(Array<crate::check::types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto subs = run_to_end(each_job(crate::check::errors::range0(len(fps)), ({
        auto fps_1 = fps;
        auto c_2 = c;
        auto lx_3 = lx;
        auto args_4 = args;
        auto mode_5 = mode;
        auto fresh_6 = fresh;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, PatOut>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto fps_1_7 = fps_1;
            auto c_2_7 = c_2;
            auto lx_3_7 = lx_3;
            auto args_4_7 = args_4;
            auto mode_5_7 = mode_5;
            auto fresh_6_7 = fresh_6;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto fp = or_(index(fps_1_7, i), dummy_field_pat());
                auto fname = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = fp.name;
                    if (prism_rtl::is_some(_m)) {
                        auto&& id = prism_rtl::some_of(_m);
                        _v.set(id.name);
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(or_(index(c_2_7.fields, i), Text::lit("")));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto fix = fold(crate::check::errors::range0(len(c_2_7.fields)), i, [&](const Nat& found, const Nat& j) { return or_(index(c_2_7.fields, j), Text::lit("")) == fname ? j : found; });
                call_then(start_instantiated(or_(index(c_2_7->args, fix), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), c_2_7.params, args_4_7), [=](crate::check::types::Ty instantiated_100837) { return call_then(start_sub_pat(lx_3_7, c_2_7, fix, fp.pattern, instantiated_100837, mode_5_7, prism_rtl::cat(fresh_6_7, "_", i)), [=](PatOut sub_pat_100805) { return prism_rtl::finished(std::tuple{snake(fname), sub_pat_100805}); }); });
            });
            });
        }));
        });
    }));
    })));
    auto conds = fold(subs, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc, const std::tuple<Text, PatOut>& _p1) {
        auto&& o = std::get<1>(_p1);
        return append(acc, o.conds);
    });
    auto binds = fold(subs, Array<std::tuple<Text, Bn>>{}, [&](const Array<std::tuple<Text, Bn>>& acc, const std::tuple<Text, PatOut>& _p1) {
        auto&& o = std::get<1>(_p1);
        return append(acc, o.binds);
    });
    return PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaRecord{ty_path, each(subs, [&](const std::tuple<Text, PatOut>& _p0) {
        auto&& f = std::get<0>(_p0);
        auto&& o = std::get<1>(_p0);
        return std::tuple{f, o.pa};
    }), rest || (len(subs) < len(c.fields))}), .conds = conds, .binds = binds};
}


prism_rtl::Turn<PatOut> FieldsPat::cycle() const {
    const auto& lx = this->lx;
    const auto& c = this->c;
    const auto& fps = this->fps;
    const auto& rest = this->rest;
    const auto& ty = this->ty;
    const auto& mode = this->mode;
    const auto& fresh = this->fresh;
    const auto& ty_path = this->ty_path;
    auto args = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
        auto&& _m = peel(ty);
        if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
            auto&& xs = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
            _v.set(xs);
            goto _done;
        }
        {
            _v.set(Array<crate::check::types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto c_1 = c;
    auto fps_2 = fps;
    auto fresh_3 = fresh;
    auto lx_4 = lx;
    auto mode_5 = mode;
    auto rest_6 = rest;
    auto ty_path_7 = ty_path;
    return call_value(each_job(crate::check::errors::range0(len(fps_2)), ({
        auto fps_2_8 = fps_2;
        auto c_1_8 = c_1;
        auto lx_4_8 = lx_4;
        auto args_8 = args;
        auto mode_5_9 = mode_5;
        auto fresh_3_9 = fresh_3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, PatOut>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto fps_2_8_9 = fps_2_8;
            auto c_1_8_9 = c_1_8;
            auto lx_4_8_9 = lx_4_8;
            auto args_8_9 = args_8;
            auto mode_5_9_9 = mode_5_9;
            auto fresh_3_9_9 = fresh_3_9;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto fp = or_(index(fps_2_8_9, i), dummy_field_pat());
                auto fname = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = fp.name;
                    if (prism_rtl::is_some(_m)) {
                        auto&& id = prism_rtl::some_of(_m);
                        _v.set(id.name);
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(or_(index(c_1_8_9.fields, i), Text::lit("")));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto fix = fold(crate::check::errors::range0(len(c_1_8_9.fields)), i, [&](const Nat& found, const Nat& j) { return or_(index(c_1_8_9.fields, j), Text::lit("")) == fname ? j : found; });
                call_then(start_instantiated(or_(index(c_1_8_9->args, fix), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), c_1_8_9.params, args_8_9), [=](crate::check::types::Ty instantiated_100837) { return call_then(start_sub_pat(lx_4_8_9, c_1_8_9, fix, fp.pattern, instantiated_100837, mode_5_9_9, prism_rtl::cat(fresh_3_9_9, "_", i)), [=](PatOut sub_pat_100805) { return prism_rtl::finished(std::tuple{snake(fname), sub_pat_100805}); }); });
            });
            });
        }));
        });
    }));
    })), [=](Array<std::tuple<Text, PatOut>> each_100452) {
        return ({
            auto subs = each_100452;
            auto conds = fold(subs, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc, const std::tuple<Text, PatOut>& _p1) {
                auto&& o = std::get<1>(_p1);
                return append(acc, o.conds);
            });
            auto binds = fold(subs, Array<std::tuple<Text, Bn>>{}, [&](const Array<std::tuple<Text, Bn>>& acc, const std::tuple<Text, PatOut>& _p1) {
                auto&& o = std::get<1>(_p1);
                return append(acc, o.binds);
            });
            (prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaRecord{ty_path_7, each(subs, [&](const std::tuple<Text, PatOut>& _p0) {
            auto&& f = std::get<0>(_p0);
            auto&& o = std::get<1>(_p0);
            return std::tuple{f, o.pa};
        }), rest_6 || (len(subs) < len(c_1.fields))}), .conds = conds, .binds = binds}));
        });
    });
}


/// `Start FieldsPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_fields_pat(Lx lx, crate::check::env::CtorInfo c, Array<crate::syntax::FieldPat> fps, bool rest, crate::check::types::Ty ty, Holding mode, Text fresh, Text ty_path) {
    return prism_rtl::make_rc<FieldsPat>(lx, c, fps, rest, ty, mode, fresh, ty_path);
}


/// let dummyFieldPat
crate::syntax::FieldPat dummy_field_pat() {
    return crate::syntax::FieldPat{.name = std::optional<crate::syntax::Ident>{}, .pattern = dummy_pat(), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// let dummyTagInfo
crate::check::env::TagInfo dummy_tag_info() {
    return crate::check::env::TagInfo{.name = Text::lit(""), .family = Text::lit(""), .kind = Text::lit(""), .out = crate::check::types::Ty(crate::check::types::Ty::TyErr{}), .qs = Array<Text>{}, .rqs = Array<Text>{}, .bounds = Array<std::tuple<Text, Text>>{}, .fields = Array<std::tuple<Text, crate::check::types::Ty>>{}, .home = Text::lit(""), .file = Nat(0u), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// IsLive: fn Ty -> Bool
bool is_live(const crate::check::types::Ty& t) {
    auto&& _m = peel(t);
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// TagFieldName: fn FieldPat, [Text], Nat -> Text
Text tag_field_name(const crate::syntax::FieldPat& fp, const Array<Text>& names, const Nat& i) {
    auto&& _m = fp.name;
    if (prism_rtl::is_some(_m)) {
        auto&& id = prism_rtl::some_of(_m);
        return id.name;
    }
    if (prism_rtl::is_none(_m)) {
        auto&& _m = fp.pattern.kind;
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            return crate::check::types::has_text(names, crate::check::env::sname_key(n))
                ? crate::check::env::sname_key(n)
                : or_(index(names, i), Text::lit(""));
        }
        {
            return or_(index(names, i), Text::lit(""));
        }
    }
    prism_rtl::unreachable("no arm matched");
}


/// TagPat: unbounded fn Lx, TagInfo, [FieldPat], Bool, Ty, Holding, Text -> PatOut
PatOut tag_pat(const Lx& lx, const crate::check::env::TagInfo& tg, const Array<crate::syntax::FieldPat>& fps, const bool& rest, const crate::check::types::Ty& ty, const Holding& mode, const Text& fresh) {
    auto [variant, struct_path] = tag_paths(lx, tg);
    auto live = is_live(ty);
    auto names = each(tg.fields, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
        auto&& f = std::get<0>(_p0);
        return f;
    });
    auto sub_mode = live ? Holding(Holding::ByRef{}) : mode;
    auto parts = run_to_end(each_job(crate::check::errors::range0(len(fps)), ({
        auto fps_1 = fps;
        auto names_2 = names;
        auto tg_3 = tg;
        auto live_4 = live;
        auto lx_5 = lx;
        auto variant_6 = variant;
        auto fresh_7 = fresh;
        auto sub_mode_8 = sub_mode;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<std::optional<Text>, PatOut>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto fps_1_9 = fps_1;
            auto names_2_9 = names_2;
            auto tg_3_9 = tg_3;
            auto live_4_9 = live_4;
            auto lx_5_9 = lx_5;
            auto variant_6_9 = variant_6;
            auto fresh_7_9 = fresh_7;
            auto sub_mode_8_9 = sub_mode_8;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto fp = or_(index(fps_1_9, i), dummy_field_pat());
                auto fname = tag_field_name(fp, names_2_9, i);
                auto ft = fold(tg_3_9.fields, crate::check::types::Ty(crate::check::types::Ty::TyErr{}), [&](const crate::check::types::Ty& found, const std::tuple<Text, crate::check::types::Ty>& _p1) {
                    auto&& f = std::get<0>(_p1);
                    auto&& t = std::get<1>(_p1);
                    return f == fname ? t : found;
                });
                ({
                auto&& _m = layer_of(ft);
                prism_rtl::is<Layer::LyEv>(_m) ? prism_rtl::finished(std::tuple{std::optional<Text>{}, PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{refusal(prism_rtl::cat("an event field in an element pattern (", tg_3_9.name, ".", fname, ")"))})}), .binds = Array<std::tuple<Text, Bn>>{}}})
                : prism_rtl::is<Layer::LyDyn>(_m) && ({
                live_4_9;
            }) ? call_then(start_live_field_pat(lx_5_9, fp.pattern, variant_6_9, fname, ft, fresh_7_9), [=](PatOut live_field_pat_103212) { return prism_rtl::finished(std::tuple{std::optional<Text>{}, live_field_pat_103212}); })
                : call_then(start_rust_pat(lx_5_9, fp.pattern, peel(ft), sub_mode_8_9, prism_rtl::cat(fresh_7_9, "_", i)), [=](PatOut rust_pat_103317) {
                return ({
                    auto o = rust_pat_103317;
                    (prism_rtl::finished(std::tuple{std::optional(snake(fname)), o}));
                });
            });
            });
            });
            });
        }));
        });
    }));
    })));
    auto field_pas = fold(parts, Array<std::tuple<Text, crate::lower::model::Pa>>{}, [&](const Array<std::tuple<Text, crate::lower::model::Pa>>& acc, const std::tuple<std::optional<Text>, PatOut>& _p1) {
        auto&& f_opt = std::get<0>(_p1);
        auto&& o = std::get<1>(_p1);
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, crate::lower::model::Pa>>> _v;
            if (prism_rtl::is_some(f_opt)) {
                auto&& f = prism_rtl::some_of(f_opt);
                _v.set(crate::prelude::push(acc, std::tuple{f, o.pa}));
                goto _done;
            }
            if (prism_rtl::is_none(f_opt)) {
                _v.set(acc);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    auto conds = fold(parts, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc, const std::tuple<std::optional<Text>, PatOut>& _p1) {
        auto&& o = std::get<1>(_p1);
        return append(acc, o.conds);
    });
    auto binds = fold(parts, Array<std::tuple<Text, Bn>>{}, [&](const Array<std::tuple<Text, Bn>>& acc, const std::tuple<std::optional<Text>, PatOut>& _p1) {
        auto&& o = std::get<1>(_p1);
        return append(acc, o.binds);
    });
    auto level = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{variant, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaRecord{struct_path, field_pas, true})})});
    auto tagged = crate::prelude::push(binds, std::tuple{Text::lit("#tag"), Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XPath{crate::lower::node_::answer_variant(tg)}), Holding(Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})})});
    return live
        ? PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh}), .conds = append(Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcLet{level, crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh})), Text::lit("identity")}))})})}), conds), .binds = tagged}
        : PatOut{.pa = level, .conds = conds, .binds = binds};
}


prism_rtl::Turn<PatOut> TagPat::cycle() const {
    const auto& lx = this->lx;
    const auto& tg = this->tg;
    const auto& fps = this->fps;
    const auto& rest = this->rest;
    const auto& ty = this->ty;
    const auto& mode = this->mode;
    const auto& fresh = this->fresh;
    auto [variant, struct_path] = tag_paths(lx, tg);
    auto live = is_live(ty);
    auto names = each(tg.fields, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
        auto&& f = std::get<0>(_p0);
        return f;
    });
    auto sub_mode = live ? Holding(Holding::ByRef{}) : mode;
    auto fps_1 = fps;
    auto fresh_2 = fresh;
    auto lx_3 = lx;
    auto tg_4 = tg;
    return call_value(each_job(crate::check::errors::range0(len(fps_1)), ({
        auto fps_1_5 = fps_1;
        auto names_5 = names;
        auto tg_4_6 = tg_4;
        auto live_6 = live;
        auto lx_3_7 = lx_3;
        auto variant_7 = variant;
        auto fresh_2_8 = fresh_2;
        auto sub_mode_8 = sub_mode;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<std::optional<Text>, PatOut>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto fps_1_5_9 = fps_1_5;
            auto names_5_9 = names_5;
            auto tg_4_6_9 = tg_4_6;
            auto live_6_9 = live_6;
            auto lx_3_7_9 = lx_3_7;
            auto variant_7_9 = variant_7;
            auto fresh_2_8_9 = fresh_2_8;
            auto sub_mode_8_9 = sub_mode_8;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto fp = or_(index(fps_1_5_9, i), dummy_field_pat());
                auto fname = tag_field_name(fp, names_5_9, i);
                auto ft = fold(tg_4_6_9.fields, crate::check::types::Ty(crate::check::types::Ty::TyErr{}), [&](const crate::check::types::Ty& found, const std::tuple<Text, crate::check::types::Ty>& _p1) {
                    auto&& f = std::get<0>(_p1);
                    auto&& t = std::get<1>(_p1);
                    return f == fname ? t : found;
                });
                ({
                auto&& _m = layer_of(ft);
                prism_rtl::is<Layer::LyEv>(_m) ? prism_rtl::finished(std::tuple{std::optional<Text>{}, PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{refusal(prism_rtl::cat("an event field in an element pattern (", tg_4_6_9.name, ".", fname, ")"))})}), .binds = Array<std::tuple<Text, Bn>>{}}})
                : prism_rtl::is<Layer::LyDyn>(_m) && ({
                live_6_9;
            }) ? call_then(start_live_field_pat(lx_3_7_9, fp.pattern, variant_7_9, fname, ft, fresh_2_8_9), [=](PatOut live_field_pat_103212) { return prism_rtl::finished(std::tuple{std::optional<Text>{}, live_field_pat_103212}); })
                : call_then(start_rust_pat(lx_3_7_9, fp.pattern, peel(ft), sub_mode_8_9, prism_rtl::cat(fresh_2_8_9, "_", i)), [=](PatOut rust_pat_103317) {
                return ({
                    auto o = rust_pat_103317;
                    (prism_rtl::finished(std::tuple{std::optional(snake(fname)), o}));
                });
            });
            });
            });
            });
        }));
        });
    }));
    })), [=](Array<std::tuple<std::optional<Text>, PatOut>> each_102801) {
        return ({
            auto parts = each_102801;
            auto field_pas = fold(parts, Array<std::tuple<Text, crate::lower::model::Pa>>{}, [&](const Array<std::tuple<Text, crate::lower::model::Pa>>& acc, const std::tuple<std::optional<Text>, PatOut>& _p1) {
                auto&& f_opt = std::get<0>(_p1);
                auto&& o = std::get<1>(_p1);
                return ({
                    __label__ _done;
                    prism_rtl::Slot<Array<std::tuple<Text, crate::lower::model::Pa>>> _v;
                    if (prism_rtl::is_some(f_opt)) {
                        auto&& f = prism_rtl::some_of(f_opt);
                        _v.set(crate::prelude::push(acc, std::tuple{f, o.pa}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(f_opt)) {
                        _v.set(acc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
            });
            auto conds = fold(parts, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc, const std::tuple<std::optional<Text>, PatOut>& _p1) {
                auto&& o = std::get<1>(_p1);
                return append(acc, o.conds);
            });
            auto binds = fold(parts, Array<std::tuple<Text, Bn>>{}, [&](const Array<std::tuple<Text, Bn>>& acc, const std::tuple<std::optional<Text>, PatOut>& _p1) {
                auto&& o = std::get<1>(_p1);
                return append(acc, o.binds);
            });
            auto level = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{variant, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaRecord{struct_path, field_pas, true})})});
            auto tagged = crate::prelude::push(binds, std::tuple{Text::lit("#tag"), Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XPath{crate::lower::node_::answer_variant(tg_4)}), Holding(Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})})});
            live
            ? prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh_2}), .conds = append(Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcLet{level, crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_2})), Text::lit("identity")}))})})}), conds), .binds = tagged})
            : prism_rtl::finished(PatOut{.pa = level, .conds = conds, .binds = binds});
        });
    });
}


/// `Start TagPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_tag_pat(Lx lx, crate::check::env::TagInfo tg, Array<crate::syntax::FieldPat> fps, bool rest, crate::check::types::Ty ty, Holding mode, Text fresh) {
    return prism_rtl::make_rc<TagPat>(lx, tg, fps, rest, ty, mode, fresh);
}


/// LiveFieldPat: unbounded fn Lx, Pattern, Text, Text, Ty, Text -> PatOut
PatOut live_field_pat(const Lx& lx, const crate::syntax::Pattern_& p_, const Text& variant, const Text& fname, const crate::check::types::Ty& ft, const Text& fresh) {
    auto&& _m = p_.kind;
    if (prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m)) {
        return pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        auto rs = lx.in_node
            ? live_projection(fresh, variant, fname, out_ty_of(lx, peel(ft)))
            : refusal(prism_rtl::cat("a live element's `$` field (", fname, ") in a plain function, which has no read point (gap LE)"));
        return PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array(std::vector{std::tuple{crate::check::env::sname_key(n), Bn(Bn::BnLocal{rs, Holding(Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutDyn{prism_rtl::rc(out_ty_of(lx, peel(ft)))})})}})};
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return live_field_pat(lx, q, variant, fname, ft, fresh);
    }
    {
        return PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{refusal(prism_rtl::cat("a pattern inside a live element's `$` field (", fname, ")"))})}), .binds = Array<std::tuple<Text, Bn>>{}};
    }
}


prism_rtl::Turn<PatOut> LiveFieldPat::cycle() const {
    const auto& lx = this->lx;
    const auto& p_ = this->p_;
    const auto& variant = this->variant;
    const auto& fname = this->fname;
    const auto& ft = this->ft;
    const auto& fresh = this->fresh;
    return ({
        auto&& _m = p_.kind;
        prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m) ? prism_rtl::finished(pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})))
        : prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        ({
        auto rs = lx.in_node
            ? live_projection(fresh, variant, fname, out_ty_of(lx, peel(ft)))
            : refusal(prism_rtl::cat("a live element's `$` field (", fname, ") in a plain function, which has no read point (gap LE)"));
        auto ft_1 = ft;
        auto lx_2 = lx;
        auto n_3 = n;
        call_then(start_out_ty_of(lx_2, peel(ft_1)), [=](crate::lower::model::OutTy out_ty_of_104929) { return prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array(std::vector{std::tuple{crate::check::env::sname_key(n_3), Bn(Bn::BnLocal{rs, Holding(Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutDyn{prism_rtl::rc(out_ty_of_104929)})})}})}); });
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m) ? ({
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(LiveFieldPat(lx, q, variant, fname, ft, fresh)));
    })
        : prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{refusal(prism_rtl::cat("a pattern inside a live element's `$` field (", fname, ")"))})}), .binds = Array<std::tuple<Text, Bn>>{}});
    });
}


/// `Start LiveFieldPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_live_field_pat(Lx lx, crate::syntax::Pattern_ p_, Text variant, Text fname, crate::check::types::Ty ft, Text fresh) {
    return prism_rtl::make_rc<LiveFieldPat>(lx, p_, variant, fname, ft, fresh);
}


/// LiveProjection: fn Text, Text, Text, OutTy -> Ex
crate::lower::model::Ex live_projection(const Text& fresh, const Text& variant, const Text& fname, const crate::lower::model::OutTy& ft) {
    auto arm = crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{variant, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("x")})})}), .conds = Array<crate::lower::model::Cc>{}, .body = crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("x")})), snake(fname)}))})};
    auto other = crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .body = crate::lower::model::Ex(crate::lower::model::Ex::XUnreachable{})};
    return crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh})), Text::lit("level")})), Text::lit("map"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("l")})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMatch{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("l")})), Array(std::vector{arm, other}), false, ft}))})})});
}


/// FamilyPat: unbounded fn Lx, QualName, Ty, Text -> PatOut
PatOut family_pat(const Lx& lx, const crate::syntax::QualName& q, const crate::check::types::Ty& ty, const Text& fresh) {
    auto fam = crate::check::env::dotted(filter(q->path_, [&](const Text& x) { return x != Text::lit("*"); }));
    auto kind = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = peel(ty);
        if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
            _v.set(Text::lit("Element"));
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(_m)) {
            _v.set(Text::lit("Element"));
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
            auto&& k = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
            _v.set(k);
            goto _done;
        }
        {
            _v.set(Text::lit(""));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto tags = filter(kind_tags(lx, kind, keys(lx.rs_mods)), [&](const crate::check::env::TagInfo& tg) { return tg.family == fam; });
    auto place = is_live(ty)
        ? crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh})), Text::lit("identity")})
        : crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh});
    return PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh}), .conds = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XIsCase{prism_rtl::rc(place), each(tags, [&](const crate::check::env::TagInfo& tg) { return variant_of(lx, tg); })})})}), .binds = Array<std::tuple<Text, Bn>>{}};
}


prism_rtl::Turn<PatOut> FamilyPat::cycle() const {
    const auto& lx = this->lx;
    const auto& q = this->q;
    const auto& ty = this->ty;
    const auto& fresh = this->fresh;
    auto fam = crate::check::env::dotted(filter(q->path_, [&](const Text& x) { return x != Text::lit("*"); }));
    auto kind = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = peel(ty);
        if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
            _v.set(Text::lit("Element"));
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(_m)) {
            _v.set(Text::lit("Element"));
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
            auto&& k = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
            _v.set(k);
            goto _done;
        }
        {
            _v.set(Text::lit(""));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto tags = filter(kind_tags(lx, kind, keys(lx.rs_mods)), [&](const crate::check::env::TagInfo& tg) { return tg.family == fam; });
    auto place = is_live(ty)
        ? crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh})), Text::lit("identity")})
        : crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh});
    return prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh}), .conds = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XIsCase{prism_rtl::rc(place), each(tags, [&](const crate::check::env::TagInfo& tg) { return variant_of(lx, tg); })})})}), .binds = Array<std::tuple<Text, Bn>>{}});
}


/// `Start FamilyPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_family_pat(Lx lx, crate::syntax::QualName q, crate::check::types::Ty ty, Text fresh) {
    return prism_rtl::make_rc<FamilyPat>(lx, q, ty, fresh);
}


/// ErrorPat: unbounded fn Lx, [FieldPat], Ty, Holding, Text -> PatOut
PatOut error_pat(const Lx& lx, const Array<crate::syntax::FieldPat>& fps, const crate::check::types::Ty& ty, const Holding& mode, const Text& fresh) {
    auto e = local_place(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh}), mode, crate::lower::model::OutTy(crate::lower::model::OutTy::OutError{}));
    auto parts = each(fps, [&](const crate::syntax::FieldPat& fp) {
        return ({
            auto fname = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = fp.name;
                if (prism_rtl::is_some(_m)) {
                    auto&& id = prism_rtl::some_of(_m);
                    _v.set(id.name);
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Text::lit(""));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, Bn>>>> _v;
            {
                auto&& m106544_0 = fname;
                if (m106544_0 == Text::lit("kind")) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, Bn>>>> _v;
                        auto&& _m = fp.pattern.kind;
                        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                            auto&& k = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                            _v.set(({
                                auto&& _kq_opt = crate::check::env::resolve_value(lx.g, lx.home, k);
                                auto&& kq_opt = std::get<0>(_kq_opt);
                                ({
                                __label__ _done;
                                prism_rtl::Slot<std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, Bn>>>> _v;
                                if (prism_rtl::is_some(kq_opt)) {
                                    auto&& kq = prism_rtl::some_of(kq_opt);
                                    _v.set(crate::check::env::has_key(lx.g.tags, kq)
                                        ? std::tuple{Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("=="), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh})), Text::lit("kind")}))}))})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XStr{kq}))})})}), Array<std::tuple<Text, Bn>>{}}
                                        : std::tuple{Array<crate::lower::model::Cc>{}, Array(std::vector{std::tuple{crate::check::env::sname_key(k), Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh})), Text::lit("kind")}), Holding(Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})})}})});
                                    goto _done;
                                }
                                if (prism_rtl::is_none(kq_opt)) {
                                    _v.set(std::tuple{Array<crate::lower::model::Cc>{}, Array(std::vector{std::tuple{crate::check::env::sname_key(k), Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh})), Text::lit("kind")}), Holding(Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})})}})});
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            });
                            }));
                            goto _done;
                        }
                        {
                            _v.set(std::tuple{Array<crate::lower::model::Cc>{}, Array<std::tuple<Text, Bn>>{}});
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
            }
            {
                auto&& m106544_1 = fname;
                if (m106544_1 == Text::lit("message")) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, Bn>>>> _v;
                        auto&& _m = fp.pattern.kind;
                        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                            auto&& m = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                            _v.set(std::tuple{Array<crate::lower::model::Cc>{}, Array(std::vector{std::tuple{crate::check::env::sname_key(m), Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh})), Text::lit("message")}), Holding(Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})})}})});
                            goto _done;
                        }
                        {
                            _v.set(std::tuple{Array<crate::lower::model::Cc>{}, Array<std::tuple<Text, Bn>>{}});
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
            }
            {
                _v.set(std::tuple{Array<crate::lower::model::Cc>{}, Array<std::tuple<Text, Bn>>{}});
                goto _done;
            }
        _done:
            _v.take();
        });
        });
    });
    auto wrapped = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Pa> _v;
        auto&& _m = peel(ty);
        if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
            auto&& m107381_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
            if (m107381_0_0 == Text::lit("~")) {
                _v.set(crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Err"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh})})}));
                goto _done;
            }
        }
        {
            _v.set(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh}));
            goto _done;
        }
    _done:
        _v.take();
    });
    return PatOut{.pa = wrapped, .conds = fold(parts, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc, const std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, Bn>>>& _p1) {
        auto&& cs = std::get<0>(_p1);
        return append(acc, cs);
    }), .binds = fold(parts, Array<std::tuple<Text, Bn>>{}, [&](const Array<std::tuple<Text, Bn>>& acc, const std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, Bn>>>& _p1) {
        auto&& bs = std::get<1>(_p1);
        return append(acc, bs);
    })};
}


prism_rtl::Turn<PatOut> ErrorPat::cycle() const {
    const auto& lx = this->lx;
    const auto& fps = this->fps;
    const auto& ty = this->ty;
    const auto& mode = this->mode;
    const auto& fresh = this->fresh;
    auto e = local_place(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh}), mode, crate::lower::model::OutTy(crate::lower::model::OutTy::OutError{}));
    auto parts = each(fps, [&](const crate::syntax::FieldPat& fp) {
        return ({
            auto fname = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = fp.name;
                if (prism_rtl::is_some(_m)) {
                    auto&& id = prism_rtl::some_of(_m);
                    _v.set(id.name);
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Text::lit(""));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, Bn>>>> _v;
            {
                auto&& m106544_0 = fname;
                if (m106544_0 == Text::lit("kind")) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, Bn>>>> _v;
                        auto&& _m = fp.pattern.kind;
                        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                            auto&& k = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                            _v.set(({
                                auto&& _kq_opt = crate::check::env::resolve_value(lx.g, lx.home, k);
                                auto&& kq_opt = std::get<0>(_kq_opt);
                                ({
                                __label__ _done;
                                prism_rtl::Slot<std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, Bn>>>> _v;
                                if (prism_rtl::is_some(kq_opt)) {
                                    auto&& kq = prism_rtl::some_of(kq_opt);
                                    _v.set(crate::check::env::has_key(lx.g.tags, kq)
                                        ? std::tuple{Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("=="), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh})), Text::lit("kind")}))}))})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XStr{kq}))})})}), Array<std::tuple<Text, Bn>>{}}
                                        : std::tuple{Array<crate::lower::model::Cc>{}, Array(std::vector{std::tuple{crate::check::env::sname_key(k), Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh})), Text::lit("kind")}), Holding(Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})})}})});
                                    goto _done;
                                }
                                if (prism_rtl::is_none(kq_opt)) {
                                    _v.set(std::tuple{Array<crate::lower::model::Cc>{}, Array(std::vector{std::tuple{crate::check::env::sname_key(k), Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh})), Text::lit("kind")}), Holding(Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})})}})});
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            });
                            }));
                            goto _done;
                        }
                        {
                            _v.set(std::tuple{Array<crate::lower::model::Cc>{}, Array<std::tuple<Text, Bn>>{}});
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
            }
            {
                auto&& m106544_1 = fname;
                if (m106544_1 == Text::lit("message")) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, Bn>>>> _v;
                        auto&& _m = fp.pattern.kind;
                        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                            auto&& m = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                            _v.set(std::tuple{Array<crate::lower::model::Cc>{}, Array(std::vector{std::tuple{crate::check::env::sname_key(m), Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh})), Text::lit("message")}), Holding(Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})})}})});
                            goto _done;
                        }
                        {
                            _v.set(std::tuple{Array<crate::lower::model::Cc>{}, Array<std::tuple<Text, Bn>>{}});
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
            }
            {
                _v.set(std::tuple{Array<crate::lower::model::Cc>{}, Array<std::tuple<Text, Bn>>{}});
                goto _done;
            }
        _done:
            _v.take();
        });
        });
    });
    auto wrapped = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Pa> _v;
        auto&& _m = peel(ty);
        if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
            auto&& m107381_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
            if (m107381_0_0 == Text::lit("~")) {
                _v.set(crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Err"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh})})}));
                goto _done;
            }
        }
        {
            _v.set(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh}));
            goto _done;
        }
    _done:
        _v.take();
    });
    return prism_rtl::finished(PatOut{.pa = wrapped, .conds = fold(parts, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc, const std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, Bn>>>& _p1) {
        auto&& cs = std::get<0>(_p1);
        return append(acc, cs);
    }), .binds = fold(parts, Array<std::tuple<Text, Bn>>{}, [&](const Array<std::tuple<Text, Bn>>& acc, const std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, Bn>>>& _p1) {
        auto&& bs = std::get<1>(_p1);
        return append(acc, bs);
    })});
}


/// `Start ErrorPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_error_pat(Lx lx, Array<crate::syntax::FieldPat> fps, crate::check::types::Ty ty, Holding mode, Text fresh) {
    return prism_rtl::make_rc<ErrorPat>(lx, fps, ty, mode, fresh);
}


/// ArrayPat: unbounded fn Lx, [Pattern], Ty, Holding, Text -> PatOut
PatOut array_pat(const Lx& lx, const Array<crate::syntax::Pattern_>& ps, const crate::check::types::Ty& ty, const Holding& mode, const Text& fresh) {
    auto et = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::Ty> _v;
        auto&& _m = peel(ty);
        if (prism_rtl::is<crate::check::types::Ty::TyArray>(_m)) {
            auto&& x = prism_rtl::as<crate::check::types::Ty::TyArray>(_m).a0;
            _v.set(x);
            goto _done;
        }
        {
            _v.set(crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto arr = local_place(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh}), mode, out_ty_of(lx, peel(ty)));
    auto len_cond = crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("=="), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(ref_(arr)), Text::lit("len"), Array<crate::lower::model::Ex>{}})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XIndex{len(ps)}))})});
    auto subs = run_to_end(each_job(crate::check::errors::range0(len(ps)), ({
        auto lx_1 = lx;
        auto ps_2 = ps;
        auto et_3 = et;
        auto fresh_4 = fresh;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Nat, PatOut>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto lx_1_5 = lx_1;
            auto ps_2_5 = ps_2;
            auto et_3_5 = et_3;
            auto fresh_4_5 = fresh_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                call_then(start_rust_pat(lx_1_5, or_(index(ps_2_5, i), dummy_pat()), et_3_5, Holding(Holding::Owned{}), prism_rtl::cat(fresh_4_5, "_", i)), [=](PatOut rust_pat_108078) { return prism_rtl::finished(std::tuple{i, rust_pat_108078}); });
            });
        }));
        });
    }));
    })));
    auto conds = fold(subs, Array(std::vector{len_cond}), [&](const Array<crate::lower::model::Cc>& acc, const std::tuple<Nat, PatOut>& _p1) {
        auto&& i = std::get<0>(_p1);
        auto&& o = std::get<1>(_p1);
        return append(crate::prelude::push(acc, crate::lower::model::Cc(crate::lower::model::Cc::CcLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{o.pa})}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("index"), Array(std::vector{ref_(arr), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XNat{prism_rtl::cat(i)}))})})})})), o.conds);
    });
    auto binds = fold(subs, Array<std::tuple<Text, Bn>>{}, [&](const Array<std::tuple<Text, Bn>>& acc, const std::tuple<Nat, PatOut>& _p1) {
        auto&& o = std::get<1>(_p1);
        return append(acc, o.binds);
    });
    return PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh}), .conds = conds, .binds = binds};
}


prism_rtl::Turn<PatOut> ArrayPat::cycle() const {
    const auto& lx = this->lx;
    const auto& ps = this->ps;
    const auto& ty = this->ty;
    const auto& mode = this->mode;
    const auto& fresh = this->fresh;
    auto et = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::Ty> _v;
        auto&& _m = peel(ty);
        if (prism_rtl::is<crate::check::types::Ty::TyArray>(_m)) {
            auto&& x = prism_rtl::as<crate::check::types::Ty::TyArray>(_m).a0;
            _v.set(x);
            goto _done;
        }
        {
            _v.set(crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto fresh_1 = fresh;
    auto lx_2 = lx;
    auto mode_3 = mode;
    auto ps_4 = ps;
    auto ty_5 = ty;
    return call_then(start_out_ty_of(lx_2, peel(ty_5)), [=](crate::lower::model::OutTy out_ty_of_107917) {
        return ({
            auto arr = local_place(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_1}), mode_3, out_ty_of_107917);
            auto len_cond = crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("=="), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(ref_(arr)), Text::lit("len"), Array<crate::lower::model::Ex>{}})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XIndex{len(ps_4)}))})});
            call_value(each_job(crate::check::errors::range0(len(ps_4)), ({
            auto lx_2_6 = lx_2;
            auto ps_4_6 = ps_4;
            auto et_6 = et;
            auto fresh_1_7 = fresh_1;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Nat, PatOut>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto lx_2_6_7 = lx_2_6;
                auto ps_4_6_7 = ps_4_6;
                auto et_6_7 = et_6;
                auto fresh_1_7_7 = fresh_1_7;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    call_then(start_rust_pat(lx_2_6_7, or_(index(ps_4_6_7, i), dummy_pat()), et_6_7, Holding(Holding::Owned{}), prism_rtl::cat(fresh_1_7_7, "_", i)), [=](PatOut rust_pat_108078) { return prism_rtl::finished(std::tuple{i, rust_pat_108078}); });
                });
            }));
            });
        }));
        })), [=](Array<std::tuple<Nat, PatOut>> each_108043) {
            return ({
                auto subs = each_108043;
                auto conds = fold(subs, Array(std::vector{len_cond}), [&](const Array<crate::lower::model::Cc>& acc, const std::tuple<Nat, PatOut>& _p1) {
                    auto&& i = std::get<0>(_p1);
                    auto&& o = std::get<1>(_p1);
                    return append(crate::prelude::push(acc, crate::lower::model::Cc(crate::lower::model::Cc::CcLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{o.pa})}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("index"), Array(std::vector{ref_(arr), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XNat{prism_rtl::cat(i)}))})})})})), o.conds);
                });
                auto binds = fold(subs, Array<std::tuple<Text, Bn>>{}, [&](const Array<std::tuple<Text, Bn>>& acc, const std::tuple<Nat, PatOut>& _p1) {
                    auto&& o = std::get<1>(_p1);
                    return append(acc, o.binds);
                });
                (prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh_1}), .conds = conds, .binds = binds}));
            });
        });
        });
    });
}


/// `Start ArrayPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_array_pat(Lx lx, Array<crate::syntax::Pattern_> ps, crate::check::types::Ty ty, Holding mode, Text fresh) {
    return prism_rtl::make_rc<ArrayPat>(lx, ps, ty, mode, fresh);
}


/// TemplateValue: unbounded fn Lx, Env, Template -> Vl
Vl template_value(const Lx& lx, const Env& env, const crate::syntax::Template& tp) {
    auto start = Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("out")}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("String::new"), Array<crate::lower::model::Ex>{}})})});
    auto dos = run_to_end(fold_job(tp.parts, start, ({
        auto lx_1 = lx;
        auto env_2 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<Array<crate::lower::model::Do>, crate::syntax::TemplatePart>)>>(prism_rtl::rc([=](std::tuple<Array<crate::lower::model::Do>, crate::syntax::TemplatePart> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_3 = lx_1;
            auto env_2_3 = env_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto part = p1;
                call_then(start_template_part_dos(lx_1_3, env_2_3, part), [=](Array<crate::lower::model::Do> template_part_dos_109192) { return prism_rtl::finished(append(acc, template_part_dos_109192)); });
            });
        }));
        });
    })));
    })));
    return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Text::from"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")})})}))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})});
}


prism_rtl::Turn<Vl> TemplateValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& tp = this->tp;
    auto start = Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("out")}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("String::new"), Array<crate::lower::model::Ex>{}})})});
    auto env_1 = env;
    auto lx_2 = lx;
    auto tp_3 = tp;
    return call_value(fold_job(tp_3.parts, start, ({
        auto lx_2_4 = lx_2;
        auto env_1_4 = env_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<Array<crate::lower::model::Do>, crate::syntax::TemplatePart>)>>(prism_rtl::rc([=](std::tuple<Array<crate::lower::model::Do>, crate::syntax::TemplatePart> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_2_4_4 = lx_2_4;
            auto env_1_4_4 = env_1_4;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto part = p1;
                call_then(start_template_part_dos(lx_2_4_4, env_1_4_4, part), [=](Array<crate::lower::model::Do> template_part_dos_109192) { return prism_rtl::finished(append(acc, template_part_dos_109192)); });
            });
        }));
        });
    })));
    })), [=](Array<crate::lower::model::Do> fold_109144) {
        return ({
            auto dos = fold_109144;
            (prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Text::from"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")})})}))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})})));
        });
    });
}


/// `Start TemplateValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_template_value(Lx lx, Env env, crate::syntax::Template tp) {
    return prism_rtl::make_rc<TemplateValue>(lx, env, tp);
}


/// TemplatePartDos: unbounded fn Lx, Env, TemplatePart -> [Do]
Array<crate::lower::model::Do> template_part_dos(const Lx& lx, const Env& env, const crate::syntax::TemplatePart& part) {
    if (prism_rtl::is<crate::syntax::TemplatePart::TpText>(part)) {
        auto&& t = prism_rtl::as<crate::syntax::TemplatePart::TpText>(part).a0;
        return Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")})), Text::lit("push_str"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{t})})})})});
    }
    if (prism_rtl::is<crate::syntax::TemplatePart::TpPlaceholder>(part)) {
        auto&& x = prism_rtl::as<crate::syntax::TemplatePart::TpPlaceholder>(part).a0;
        auto&& col_opt = prism_rtl::as<crate::syntax::TemplatePart::TpPlaceholder>(part).a1;
        auto v_ = value_of(lx, env, x);
        auto column = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::Ex> _v;
            if (prism_rtl::is_some(col_opt)) {
                auto&& c = prism_rtl::some_of(col_opt);
                _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XIndex{c})})}));
                goto _done;
            }
            if (prism_rtl::is_none(col_opt)) {
                _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XNone{}));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("place"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRefMut{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")}))}), shown_text(v_), column})})})});
    }
    if (prism_rtl::is<crate::syntax::TemplatePart::TpBlock>(part)) {
        auto&& b = prism_rtl::as<crate::syntax::TemplatePart::TpBlock>(part).a0;
        auto v_ = block_value(lx, env, b);
        return value_ty(v_) == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})
            ? Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{own(v_)})})
            : Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("place"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRefMut{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")}))}), shown_text(v_), crate::lower::model::Ex(crate::lower::model::Ex::XNone{})})})})});
    }
    if (prism_rtl::is<crate::syntax::TemplatePart::TpCall>(part)) {
        auto&& n = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part).a0;
        auto&& args = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part).a1;
        auto&& parts_opt = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part).a2;
        auto plain = crate::syntax::SName{.sigils = crate::syntax::lexer::after_first(n.sigils), .path_ = n->path_, .span = n.span};
        auto&& _qk_opt = crate::check::env::resolve_value(lx.g, lx.home, n);
        auto&& qk_opt = std::get<0>(_qk_opt);
        auto&& _qk2_opt = crate::check::env::resolve_value(lx.g, lx.home, plain);
        auto&& qk2_opt = std::get<0>(_qk2_opt);
        auto callee = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& q = prism_rtl::some_of(qk_opt);
                _v.set(value_path(lx, q));
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    if (prism_rtl::is_some(qk2_opt)) {
                        auto&& q = prism_rtl::some_of(qk2_opt);
                        _v.set(value_path(lx, q));
                        goto _done;
                    }
                    if (prism_rtl::is_none(qk2_opt)) {
                        _v.set(snake(crate::check::env::sname_key(n)));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto body = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
            if (prism_rtl::is_some(parts_opt)) {
                auto&& ps = prism_rtl::some_of(parts_opt);
                _v.set(({
                    auto inner = run_to_end(fold_job(ps, Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("out")}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("String::new"), Array<crate::lower::model::Ex>{}})})}), ({
                        auto lx_1 = lx;
                        auto env_2 = env;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<Array<crate::lower::model::Do>, crate::syntax::TemplatePart>)>>(prism_rtl::rc([=](std::tuple<Array<crate::lower::model::Do>, crate::syntax::TemplatePart> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto lx_1_3 = lx_1;
                            auto env_2_3 = env_2;
                            entered(once_job([=]() {
                            return ({
                                auto acc = p0;
                                auto p_ = p1;
                                call_then(start_template_part_dos(lx_1_3, env_2_3, p_), [=](Array<crate::lower::model::Do> template_part_dos_110502) { return prism_rtl::finished(append(acc, template_part_dos_110502)); });
                            });
                        }));
                        });
                    })));
                    })));
                    (Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XBlock{inner, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Text::from"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")})})}))}))})}));
                }));
                goto _done;
            }
            if (prism_rtl::is_none(parts_opt)) {
                _v.set(Array<crate::lower::model::Ex>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto passed = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& q = prism_rtl::some_of(qk_opt);
                _v.set(template_args(lx, env, q, args, body));
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
                    if (prism_rtl::is_some(qk2_opt)) {
                        auto&& q = prism_rtl::some_of(qk2_opt);
                        _v.set(template_args(lx, env, q, args, body));
                        goto _done;
                    }
                    if (prism_rtl::is_none(qk2_opt)) {
                        _v.set(append(run_to_end(each_job(args, ({
                            auto lx_1 = lx;
                            auto env_2 = env;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=](crate::syntax::Arg p0) {
                            return ({
                                auto lx_1_3 = lx_1;
                                auto env_2_3 = env_2;
                                entered(once_job([=]() {
                                return ({
                                    auto a = p0;
                                    (prism_rtl::more(prism_rtl::rc(Argument(lx_1_3, env_2_3, a->value))));
                                });
                            }));
                            });
                        })));
                        }))), body));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto call = crate::lower::model::Ex(crate::lower::model::Ex::XCall{callee, passed});
        return Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("place"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRefMut{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(call)}), crate::lower::model::Ex(crate::lower::model::Ex::XNone{})})})})});
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<crate::lower::model::Do>> TemplatePartDos::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& part = this->part;
    return ({
        prism_rtl::is<crate::syntax::TemplatePart::TpText>(part) ? ({
        auto&& t = prism_rtl::as<crate::syntax::TemplatePart::TpText>(part).a0;
        prism_rtl::finished(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")})), Text::lit("push_str"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{t})})})})}));
    })
        : prism_rtl::is<crate::syntax::TemplatePart::TpPlaceholder>(part) ? ({
        auto&& x = prism_rtl::as<crate::syntax::TemplatePart::TpPlaceholder>(part).a0;
        auto&& col_opt = prism_rtl::as<crate::syntax::TemplatePart::TpPlaceholder>(part).a1;
        ({
        auto col_opt_1 = col_opt;
        auto env_2 = env;
        auto lx_3 = lx;
        auto x_4 = x;
        call_then(start_value_of(lx_3, env_2, x_4), [=](Vl value_of_109522) {
        return ({
            auto v_ = value_of_109522;
            auto column = ({
                __label__ _done;
                prism_rtl::Slot<crate::lower::model::Ex> _v;
                if (prism_rtl::is_some(col_opt)) {
                    auto&& c = prism_rtl::some_of(col_opt);
                    _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XIndex{c})})}));
                    goto _done;
                }
                if (prism_rtl::is_none(col_opt)) {
                    _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XNone{}));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (prism_rtl::finished(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("place"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRefMut{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")}))}), shown_text(v_), column})})})})));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::TemplatePart::TpBlock>(part) ? ({
        auto&& b = prism_rtl::as<crate::syntax::TemplatePart::TpBlock>(part).a0;
        ({
        auto b_1 = b;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(start_block_value(lx_3, env_2, b_1), [=](Vl block_value_109756) {
        return ({
            auto v_ = block_value_109756;
            value_ty(v_) == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})
            ? prism_rtl::finished(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{own(v_)})}))
            : prism_rtl::finished(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("place"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRefMut{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")}))}), shown_text(v_), crate::lower::model::Ex(crate::lower::model::Ex::XNone{})})})})}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::TemplatePart::TpCall>(part) ? ({
        auto&& n = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part).a0;
        auto&& args = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part).a1;
        auto&& parts_opt = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part).a2;
        ({
        auto plain = crate::syntax::SName{.sigils = crate::syntax::lexer::after_first(n.sigils), .path_ = n->path_, .span = n.span};
        auto&& _qk_opt = crate::check::env::resolve_value(lx.g, lx.home, n);
        auto&& qk_opt = std::get<0>(_qk_opt);
        auto&& _qk2_opt = crate::check::env::resolve_value(lx.g, lx.home, plain);
        auto&& qk2_opt = std::get<0>(_qk2_opt);
        auto callee = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& q = prism_rtl::some_of(qk_opt);
                _v.set(value_path(lx, q));
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    if (prism_rtl::is_some(qk2_opt)) {
                        auto&& q = prism_rtl::some_of(qk2_opt);
                        _v.set(value_path(lx, q));
                        goto _done;
                    }
                    if (prism_rtl::is_none(qk2_opt)) {
                        _v.set(snake(crate::check::env::sname_key(n)));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto body = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
            if (prism_rtl::is_some(parts_opt)) {
                auto&& ps = prism_rtl::some_of(parts_opt);
                _v.set(({
                    auto inner = run_to_end(fold_job(ps, Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("out")}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("String::new"), Array<crate::lower::model::Ex>{}})})}), ({
                        auto lx_1 = lx;
                        auto env_2 = env;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<Array<crate::lower::model::Do>, crate::syntax::TemplatePart>)>>(prism_rtl::rc([=](std::tuple<Array<crate::lower::model::Do>, crate::syntax::TemplatePart> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto lx_1_3 = lx_1;
                            auto env_2_3 = env_2;
                            entered(once_job([=]() {
                            return ({
                                auto acc = p0;
                                auto p_ = p1;
                                call_then(start_template_part_dos(lx_1_3, env_2_3, p_), [=](Array<crate::lower::model::Do> template_part_dos_110502) { return prism_rtl::finished(append(acc, template_part_dos_110502)); });
                            });
                        }));
                        });
                    })));
                    })));
                    (Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XBlock{inner, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Text::from"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")})})}))}))})}));
                }));
                goto _done;
            }
            if (prism_rtl::is_none(parts_opt)) {
                _v.set(Array<crate::lower::model::Ex>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto passed = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& q = prism_rtl::some_of(qk_opt);
                _v.set(template_args(lx, env, q, args, body));
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
                    if (prism_rtl::is_some(qk2_opt)) {
                        auto&& q = prism_rtl::some_of(qk2_opt);
                        _v.set(template_args(lx, env, q, args, body));
                        goto _done;
                    }
                    if (prism_rtl::is_none(qk2_opt)) {
                        _v.set(append(run_to_end(each_job(args, ({
                            auto lx_1 = lx;
                            auto env_2 = env;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=](crate::syntax::Arg p0) {
                            return ({
                                auto lx_1_3 = lx_1;
                                auto env_2_3 = env_2;
                                entered(once_job([=]() {
                                return ({
                                    auto a = p0;
                                    (prism_rtl::more(prism_rtl::rc(Argument(lx_1_3, env_2_3, a->value))));
                                });
                            }));
                            });
                        })));
                        }))), body));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto call = crate::lower::model::Ex(crate::lower::model::Ex::XCall{callee, passed});
        (prism_rtl::finished(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("place"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRefMut{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(call)}), crate::lower::model::Ex(crate::lower::model::Ex::XNone{})})})})})));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TemplatePartDos, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::Do>> start_template_part_dos(Lx lx, Env env, crate::syntax::TemplatePart part) {
    return prism_rtl::make_rc<TemplatePartDos>(lx, env, part);
}


/// TemplateArgs: unbounded fn Lx, Env, Text, [Arg], [Ex] -> [Ex]
Array<crate::lower::model::Ex> template_args(const Lx& lx, const Env& env, const Text& qk, const Array<crate::syntax::Arg>& args, const Array<crate::lower::model::Ex>& body) {
    auto clauses = clauses_of(lx.g, qk);
    auto arity = len(or_(index(clauses, Nat(0u)), dummy_clause()).params);
    return run_to_end(each_job(crate::check::errors::range0(arity), ({
        auto body_1 = body;
        auto arity_2 = arity;
        auto clauses_3 = clauses;
        auto args_4 = args;
        auto lx_5 = lx;
        auto env_6 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto body_1_7 = body_1;
            auto arity_2_7 = arity_2;
            auto clauses_3_7 = clauses_3;
            auto args_4_7 = args_4;
            auto lx_5_7 = lx_5;
            auto env_6_7 = env_6;
            entered(once_job([=]() {
            return ({
                auto j = p0;
                (len(body_1_7) > Nat(0u)) && ((j + Nat(1u)) == arity_2_7)
                ? prism_rtl::finished(or_(index(body_1_7, Nat(0u)), crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})))
                : ({
                auto&& _m = attr_at(clauses_3_7, j, args_4_7);
                prism_rtl::is_some(_m) ? ({
                auto&& a = prism_rtl::some_of(_m);
                prism_rtl::more(prism_rtl::rc(Argument(lx_5_7, env_6_7, a->value)));
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(refusal(prism_rtl::cat("a template call that fills no argument at place ", j)))
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<crate::lower::model::Ex>> TemplateArgs::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& qk = this->qk;
    const auto& args = this->args;
    const auto& body = this->body;
    auto clauses = clauses_of(lx.g, qk);
    auto arity = len(or_(index(clauses, Nat(0u)), dummy_clause()).params);
    return each_job(crate::check::errors::range0(arity), ({
        auto body_1 = body;
        auto arity_2 = arity;
        auto clauses_3 = clauses;
        auto args_4 = args;
        auto lx_5 = lx;
        auto env_6 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto body_1_7 = body_1;
            auto arity_2_7 = arity_2;
            auto clauses_3_7 = clauses_3;
            auto args_4_7 = args_4;
            auto lx_5_7 = lx_5;
            auto env_6_7 = env_6;
            entered(once_job([=]() {
            return ({
                auto j = p0;
                (len(body_1_7) > Nat(0u)) && ((j + Nat(1u)) == arity_2_7)
                ? prism_rtl::finished(or_(index(body_1_7, Nat(0u)), crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})))
                : ({
                auto&& _m = attr_at(clauses_3_7, j, args_4_7);
                prism_rtl::is_some(_m) ? ({
                auto&& a = prism_rtl::some_of(_m);
                prism_rtl::more(prism_rtl::rc(Argument(lx_5_7, env_6_7, a->value)));
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(refusal(prism_rtl::cat("a template call that fills no argument at place ", j)))
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start TemplateArgs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::Ex>> start_template_args(Lx lx, Env env, Text qk, Array<crate::syntax::Arg> args, Array<crate::lower::model::Ex> body) {
    return prism_rtl::make_rc<TemplateArgs>(lx, env, qk, args, body);
}


/// ?AttrAt: fn [FnClause], Nat, [Arg] -> ?Arg
std::optional<crate::syntax::Arg> attr_at(const Array<crate::syntax::FnClause>& clauses, const Nat& j, const Array<crate::syntax::Arg>& args) {
    auto names = fold(clauses, Array<Text>{}, [&](const Array<Text>& acc, const crate::syntax::FnClause& c) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = index(c.params, j);
            if (prism_rtl::is_some(_m)) {
                auto&& p_ = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    auto&& _m = place_name(p_);
                    if (prism_rtl::is_some(_m)) {
                        auto&& n = prism_rtl::some_of(_m);
                        _v.set(crate::check::types::add_text(acc, n));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(acc);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    return fold(args, std::optional<crate::syntax::Arg>{}, [&](const std::optional<crate::syntax::Arg>& found_opt, const crate::syntax::Arg& a) {
        return ({
            __label__ _done;
            prism_rtl::Slot<std::optional<crate::syntax::Arg>> _v;
            auto&& _m = a.name;
            if (prism_rtl::is_some(_m)) {
                auto&& n = prism_rtl::some_of(_m);
                _v.set(crate::check::types::has_text(names, n.name) ? std::optional(a) : found_opt);
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(found_opt);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// ?PlaceName: fn Pattern -> ?Text
std::optional<Text> place_name(const crate::syntax::Pattern_& p_) {
    auto&& _m = p_.kind;
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        return std::optional(crate::check::env::dotted(n->path_));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return place_name(q);
    }
    {
        return std::optional<Text>{};
    }
}


/// ShownText: fn Vl -> Ex
crate::lower::model::Ex shown_text(const Vl& v_) {
    auto&& _m = value_ty(v_);
    if (prism_rtl::is<crate::lower::model::OutTy::OutText>(_m)) {
        return ref_(v_);
    }
    {
        return crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("show_text"), Array(std::vector{ref_(v_)})}))});
    }
}


/// GivenValue: unbounded fn Lx, Env, Block, OutTy, Range -> Vl
Vl given_value(const Lx& lx, const Env& env, const crate::syntax::Block& b, const crate::lower::model::OutTy& t, const crate::syntax::Range& span) {
    auto label = prism_rtl::cat("'g", span.start);
    auto is_try = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t)) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto n = len(b.stmts);
    auto [dos, env2, last_opt] = run_to_end(fold_job(crate::check::errors::range0(n), std::tuple{Array<crate::lower::model::Do>{}, env, std::optional<Vl>{}}, ({
        auto b_1 = b;
        auto is_try_2 = is_try;
        auto lx_3 = lx;
        auto label_4 = label;
        auto n_5 = n;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, Env, std::optional<Vl>>>(std::tuple<std::tuple<Array<crate::lower::model::Do>, Env, std::optional<Vl>>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::lower::model::Do>, Env, std::optional<Vl>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto b_1_6 = b_1;
            auto is_try_2_6 = is_try_2;
            auto lx_3_6 = lx_3;
            auto label_4_6 = label_4;
            auto n_5_6 = n_5;
            entered(once_job([=]() {
            return ({
                auto [acc, en, lv_opt] = p0;
                auto i = p1;
                ({
                auto s = or_(index(b_1_6.stmts, i), dummy_stmt_l());
                auto fail = is_try_2_6
                    ? crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Error::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{Text::lit("Prelude.Unmet")}), crate::lower::model::Ex(crate::lower::model::Ex::XStr{source_text(lx_3_6, s.span)})})})})})
                    : crate::lower::model::Ex(crate::lower::model::Ex::XNone{});
                ({
                auto&& _m = s.kind;
                prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2) ? ({
                auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
                auto&& x = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
                ({
                auto p__6 = p_;
                auto x_7 = x;
                call_then(start_value_of(lx_3_6, en, x_7), [=](Vl value_of_113436) {
                return ({
                    auto v_ = value_of_113436;
                    call_then(start_rust_pat(lx_3_6, p__6, inner_ty(type_at(lx_3_6, x_7.span)), Holding(Holding::Owned{}), prism_rtl::cat("g", s.span.start)), [=](PatOut rust_pat_113479) {
                    return ({
                        auto po = rust_pat_113479;
                        call_then(start_out_ty_of(lx_3_6, inner_ty(type_at(lx_3_6, x_7.span))), [=](crate::lower::model::OutTy out_ty_of_113621) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc, given_bind(is_try_2_6, po.pa, own(v_), label_4_6, out_ty_of_113621)), bind_all(en, po.binds), lv_opt}); });
                    });
                });
                });
            });
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SRequire>(_m) ? ({
                auto&& c = prism_rtl::as<crate::syntax::StmtKind::SRequire>(_m).a0;
                ({
                auto c_6 = c;
                call_then(start_value_of(lx_3_6, en, c_6), [=](Vl value_of_113762) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc, crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{Text::lit("!"), prism_rtl::rc(as_bool(value_of_113762))}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XBreak{label_4_6, prism_rtl::rc(fail)})})}), Array<crate::lower::model::Do>{}})), en, lv_opt}); });
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SForbid>(_m) ? ({
                auto&& c = prism_rtl::as<crate::syntax::StmtKind::SForbid>(_m).a0;
                ({
                auto c_6 = c;
                call_then(start_value_of(lx_3_6, en, c_6), [=](Vl value_of_113886) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc, crate::lower::model::Do(crate::lower::model::Do::DoIf{as_bool(value_of_113886), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XBreak{label_4_6, prism_rtl::rc(fail)})})}), Array<crate::lower::model::Do>{}})), en, lv_opt}); });
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
                auto&& x = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                (i + Nat(1u)) == n_5_6
                ? prism_rtl::finished(std::tuple{acc, en, std::optional(value_of(lx_3_6, en, x))})
                : ({
                auto x_6 = x;
                call_then(start_value_of(lx_3_6, en, x_6), [=](Vl value_of_114094) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc, crate::lower::model::Do(crate::lower::model::Do::DoExpr{own(value_of_114094)})), en, lv_opt}); });
            });
            })
                : call_then(start_block_stmt(lx_3_6, en, s), [=](std::tuple<Array<crate::lower::model::Do>, Env> block_stmt_114186) {
                return ({
                    auto [more, en2] = block_stmt_114186;
                    (prism_rtl::finished(std::tuple{append(acc, more), en2, lv_opt}));
                });
            });
            });
            });
            });
        }));
        });
    }));
    })));
    auto last = or_(last_opt, Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XNone{}), t}));
    return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XLabeled{label, dos, prism_rtl::rc(own(last)), t}), t});
}


prism_rtl::Turn<Vl> GivenValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& b = this->b;
    const auto& t = this->t;
    const auto& span = this->span;
    auto label = prism_rtl::cat("'g", span.start);
    auto is_try = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t)) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto n = len(b.stmts);
    auto b_1 = b;
    auto env_2 = env;
    auto lx_3 = lx;
    auto span_4 = span;
    auto t_5 = t;
    return call_value(fold_job(crate::check::errors::range0(n), std::tuple{Array<crate::lower::model::Do>{}, env_2, std::optional<Vl>{}}, ({
        auto b_1_6 = b_1;
        auto is_try_6 = is_try;
        auto lx_3_7 = lx_3;
        auto label_7 = label;
        auto n_8 = n;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, Env, std::optional<Vl>>>(std::tuple<std::tuple<Array<crate::lower::model::Do>, Env, std::optional<Vl>>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::lower::model::Do>, Env, std::optional<Vl>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto b_1_6_9 = b_1_6;
            auto is_try_6_9 = is_try_6;
            auto lx_3_7_9 = lx_3_7;
            auto label_7_9 = label_7;
            auto n_8_9 = n_8;
            entered(once_job([=]() {
            return ({
                auto [acc, en, lv_opt] = p0;
                auto i = p1;
                ({
                auto s = or_(index(b_1_6_9.stmts, i), dummy_stmt_l());
                auto fail = is_try_6_9
                    ? crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Error::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{Text::lit("Prelude.Unmet")}), crate::lower::model::Ex(crate::lower::model::Ex::XStr{source_text(lx_3_7_9, s.span)})})})})})
                    : crate::lower::model::Ex(crate::lower::model::Ex::XNone{});
                ({
                auto&& _m = s.kind;
                prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2) ? ({
                auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
                auto&& x = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
                ({
                auto p__9 = p_;
                auto x_10 = x;
                call_then(start_value_of(lx_3_7_9, en, x_10), [=](Vl value_of_113436) {
                return ({
                    auto v_ = value_of_113436;
                    call_then(start_rust_pat(lx_3_7_9, p__9, inner_ty(type_at(lx_3_7_9, x_10.span)), Holding(Holding::Owned{}), prism_rtl::cat("g", s.span.start)), [=](PatOut rust_pat_113479) {
                    return ({
                        auto po = rust_pat_113479;
                        call_then(start_out_ty_of(lx_3_7_9, inner_ty(type_at(lx_3_7_9, x_10.span))), [=](crate::lower::model::OutTy out_ty_of_113621) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc, given_bind(is_try_6_9, po.pa, own(v_), label_7_9, out_ty_of_113621)), bind_all(en, po.binds), lv_opt}); });
                    });
                });
                });
            });
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SRequire>(_m) ? ({
                auto&& c = prism_rtl::as<crate::syntax::StmtKind::SRequire>(_m).a0;
                ({
                auto c_9 = c;
                call_then(start_value_of(lx_3_7_9, en, c_9), [=](Vl value_of_113762) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc, crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{Text::lit("!"), prism_rtl::rc(as_bool(value_of_113762))}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XBreak{label_7_9, prism_rtl::rc(fail)})})}), Array<crate::lower::model::Do>{}})), en, lv_opt}); });
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SForbid>(_m) ? ({
                auto&& c = prism_rtl::as<crate::syntax::StmtKind::SForbid>(_m).a0;
                ({
                auto c_9 = c;
                call_then(start_value_of(lx_3_7_9, en, c_9), [=](Vl value_of_113886) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc, crate::lower::model::Do(crate::lower::model::Do::DoIf{as_bool(value_of_113886), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XBreak{label_7_9, prism_rtl::rc(fail)})})}), Array<crate::lower::model::Do>{}})), en, lv_opt}); });
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
                auto&& x = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                (i + Nat(1u)) == n_8_9
                ? prism_rtl::finished(std::tuple{acc, en, std::optional(value_of(lx_3_7_9, en, x))})
                : ({
                auto x_9 = x;
                call_then(start_value_of(lx_3_7_9, en, x_9), [=](Vl value_of_114094) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc, crate::lower::model::Do(crate::lower::model::Do::DoExpr{own(value_of_114094)})), en, lv_opt}); });
            });
            })
                : call_then(start_block_stmt(lx_3_7_9, en, s), [=](std::tuple<Array<crate::lower::model::Do>, Env> block_stmt_114186) {
                return ({
                    auto [more, en2] = block_stmt_114186;
                    (prism_rtl::finished(std::tuple{append(acc, more), en2, lv_opt}));
                });
            });
            });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<crate::lower::model::Do>, Env, std::optional<Vl>> fold_113120) {
        return ({
            auto [dos, env2, last_opt] = fold_113120;
            auto last = or_(last_opt, Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XNone{}), t_5}));
            (prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XLabeled{label, dos, prism_rtl::rc(own(last)), t_5}), t_5})));
        });
    });
}


/// `Start GivenValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_given_value(Lx lx, Env env, crate::syntax::Block b, crate::lower::model::OutTy t, crate::syntax::Range span) {
    return prism_rtl::make_rc<GivenValue>(lx, env, b, t, span);
}


/// GivenBind: fn Bool, Pa, Ex, Text, OutTy -> Do
crate::lower::model::Do given_bind(const bool& is_try, const crate::lower::model::Pa& pa, const crate::lower::model::Ex& x, const Text& label, const crate::lower::model::OutTy& t) {
    return is_try
        ? crate::lower::model::Do(crate::lower::model::Do::DoLet{pa, crate::lower::model::Ex(crate::lower::model::Ex::XMatch{prism_rtl::rc(x), Array(std::vector{crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Ok"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("v")})})}), .conds = Array<crate::lower::model::Cc>{}, .body = crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")})}, crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Err"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("e")})})}), .conds = Array<crate::lower::model::Cc>{}, .body = crate::lower::model::Ex(crate::lower::model::Ex::XBreak{label, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("e")})})}))})}}), false, t})})
        : crate::lower::model::Do(crate::lower::model::Do::DoLetElse{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{pa})}), x, crate::lower::model::Ex(crate::lower::model::Ex::XBreak{label, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XNone{}))})});
}


/// SourceText: fn Lx, Range -> Text
Text source_text(const Lx& lx, const crate::syntax::Range& r) {
    auto&& _m = index(lx.g.srcs, lx->file);
    if (prism_rtl::is_some(_m)) {
        auto&& src = prism_rtl::some_of(_m);
        return crate::check::errors::span_text(src, r);
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// UpdateValue: unbounded fn Lx, Env, Expr, Block, OutTy, Range -> Vl
Vl update_value(const Lx& lx, const Env& env, const crate::syntax::Expr& target, const crate::syntax::Block& b, const crate::lower::model::OutTy& t, const crate::syntax::Range& span) {
    auto tv = value_of(lx, env, target);
    auto env1 = bind(env, Text::lit("&_"), Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("this")}), Holding(Holding::Owned{}), t}));
    auto&& _dos = upd_stmts(lx, env1, b.stmts);
    auto&& dos = std::get<0>(_dos);
    return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{append(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("this")})), t}), own(tv)})}), dos), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("this")}))}), t});
}


prism_rtl::Turn<Vl> UpdateValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& target = this->target;
    const auto& b = this->b;
    const auto& t = this->t;
    const auto& span = this->span;
    auto b_1 = b;
    auto env_2 = env;
    auto lx_3 = lx;
    auto t_4 = t;
    auto target_5 = target;
    return call_then(start_value_of(lx_3, env_2, target_5), [=](Vl value_of_115385) {
        return ({
            auto tv = value_of_115385;
            auto env1 = bind(env_2, Text::lit("&_"), Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("this")}), Holding(Holding::Owned{}), t_4}));
            call_then(start_upd_stmts(lx_3, env1, b_1.stmts), [=](std::tuple<Array<crate::lower::model::Do>, Env> upd_stmts_115500) {
            return ({
                auto&& _dos = upd_stmts_115500;
                auto&& dos = std::get<0>(_dos);
                (prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{append(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("this")})), t_4}), own(tv)})}), dos), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("this")}))}), t_4})));
            });
        });
        });
    });
}


/// `Start UpdateValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_update_value(Lx lx, Env env, crate::syntax::Expr target, crate::syntax::Block b, crate::lower::model::OutTy t, crate::syntax::Range span) {
    return prism_rtl::make_rc<UpdateValue>(lx, env, target, b, t, span);
}


/// UpdStmts: unbounded fn Lx, Env, [Stmt] -> (([Do], Env))
std::tuple<Array<crate::lower::model::Do>, Env> upd_stmts(const Lx& lx, const Env& env, const Array<crate::syntax::Stmt>& stmts) {
    return run_to_end(fold_job(stmts, std::tuple{Array<crate::lower::model::Do>{}, env}, ({
        auto lx_1 = lx;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, Env>>(std::tuple<std::tuple<Array<crate::lower::model::Do>, Env>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::lower::model::Do>, Env>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto [acc, en] = p0;
                auto s = p1;
                call_then(start_upd_stmt(lx_1_2, en, s), [=](std::tuple<Array<crate::lower::model::Do>, Env> upd_stmt_115785) {
                return ({
                    auto [more, en2] = upd_stmt_115785;
                    (prism_rtl::finished(std::tuple{append(acc, more), en2}));
                });
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Array<crate::lower::model::Do>, Env>> UpdStmts::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& stmts = this->stmts;
    return fold_job(stmts, std::tuple{Array<crate::lower::model::Do>{}, env}, ({
        auto lx_1 = lx;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, Env>>(std::tuple<std::tuple<Array<crate::lower::model::Do>, Env>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::lower::model::Do>, Env>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto [acc, en] = p0;
                auto s = p1;
                call_then(start_upd_stmt(lx_1_2, en, s), [=](std::tuple<Array<crate::lower::model::Do>, Env> upd_stmt_115785) {
                return ({
                    auto [more, en2] = upd_stmt_115785;
                    (prism_rtl::finished(std::tuple{append(acc, more), en2}));
                });
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start UpdStmts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, Env>> start_upd_stmts(Lx lx, Env env, Array<crate::syntax::Stmt> stmts) {
    return prism_rtl::make_rc<UpdStmts>(lx, env, stmts);
}


/// UpdStmt: unbounded fn Lx, Env, Stmt -> (([Do], Env))
std::tuple<Array<crate::lower::model::Do>, Env> upd_stmt(const Lx& lx, const Env& env, const crate::syntax::Stmt& s) {
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SSet>(_m)) {
        auto&& target = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
        auto&& value = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
        auto v_ = own(value_of(lx, env, value));
        return std::tuple{Array(std::vector{assign(lx, env, target, v_)}), env};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m)) {
        auto&& target = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
        auto&& op = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a1;
        auto&& value = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a2;
        auto cur = place_of(lx, env, target);
        auto tt = out_ty_of(lx, peel(type_at(lx, target.span)));
        auto rv = value_of(lx, env, value);
        auto bin = crate::syntax::lexer::head(op);
        auto next = op_value(lx, bin, Vl(Vl::VlPlace{cur, Holding(Holding::Owned{}), tt}), rv, s.span, tt);
        return std::tuple{Array(std::vector{assign(lx, env, target, own(next))}), env};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& x = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        auto v_ = own(value_of(lx, env, x));
        auto&& _m = p_.kind;
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            return crate::syntax::lexer::has_prefix(n.sigils, Text::lit("&"))
                ? ({
                auto rs = local_name(lx, crate::check::env::sname_key(n));
                auto bt = out_ty_of(lx, peel(binder_ty(lx, n.span)));
                auto pa = is_known_ty(bt)
                    ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaMut{prism_rtl::cat(rs)})), bt})
                    : crate::lower::model::Pa(crate::lower::model::Pa::PaMut{prism_rtl::cat(rs)});
                std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{pa, v_})}), bind(env, crate::check::env::sname_key(n), Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs}), Holding(Holding::Owned{}), bt}))};
            })
                : block_stmt(lx, env, s);
        }
        {
            return block_stmt(lx, env, s);
        }
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
        auto&& body = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
        auto&& _inner = upd_stmts(lx, env, body.stmts);
        auto&& inner = std::get<0>(_inner);
        if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c)) {
            auto&& x = prism_rtl::as<crate::syntax::Cond::CondExpr>(c).a0;
            return std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoWhile{as_bool(value_of(lx, env, x)), inner})}), env};
        }
        if (prism_rtl::is<crate::syntax::Cond::CondBind>(c)) {
            auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a0;
            auto&& x = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a1;
            auto&& g_opt = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a2;
            auto po = rust_pat(lx, p_, type_at(lx, x.span), Holding(Holding::Owned{}), prism_rtl::cat("w", s.span.start));
            auto env_b = bind_all(env, po.binds);
            auto&& _inner2 = upd_stmts(lx, env_b, body.stmts);
            auto&& inner2 = std::get<0>(_inner2);
            auto conds = append(po.conds, guard_conds(lx, env_b, g_opt));
            auto tests = fold(conds, Array<crate::lower::model::Ex>{}, [&](const Array<crate::lower::model::Ex>& acc, const crate::lower::model::Cc& c) {
                return ({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
                    if (prism_rtl::is<crate::lower::model::Cc::CcIf>(c)) {
                        auto&& t = prism_rtl::as<crate::lower::model::Cc::CcIf>(c).a0;
                        _v.set(crate::prelude::push(acc, t));
                        goto _done;
                    }
                    {
                        _v.set(acc);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            });
            auto lets = fold(conds, false, [&](const bool& f, const crate::lower::model::Cc& c) { return f || is_let_cond(c); });
            auto stop = len(tests) == Nat(0u)
                ? Array<crate::lower::model::Do>{}
                : Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{Text::lit("!"), prism_rtl::rc(all_of(tests))}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("break")})})}), Array<crate::lower::model::Do>{}})});
            auto body2 = lets
                ? Array(std::vector{refusal_do(Text::lit("a `while` whose pattern matches through an `Rc`"))})
                : append(stop, inner2);
            return std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoWhileLet{po.pa, own(value_of(lx, env, x)), body2})}), env};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        auto&& _m = x.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
            auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
            auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
            auto&& else_b_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
            return std::tuple{Array(std::vector{upd_if(lx, env, c, then_b, else_b_opt)}), env};
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
            auto&& scrut = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
            auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
            return std::tuple{Array(std::vector{upd_match(lx, env, scrut, arms)}), env};
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EFor>(_m)) {
            auto&& binders_opt = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
            auto&& source = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
            auto&& body = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
            return std::tuple{Array(std::vector{upd_for(lx, env, binders_opt, source, body, x.span)}), env};
        }
        {
            return std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{own(value_of(lx, env, x))})}), env};
        }
    }
    {
        return block_stmt(lx, env, s);
    }
}


prism_rtl::Turn<std::tuple<Array<crate::lower::model::Do>, Env>> UpdStmt::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& s = this->s;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<crate::syntax::StmtKind::SSet>(_m) ? ({
        auto&& target = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
        auto&& value = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
        ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto target_3 = target;
        auto value_4 = value;
        call_then(start_value_of(lx_2, env_1, value_4), [=](Vl value_of_115972) {
        return ({
            auto v_ = own(value_of_115972);
            call_then(start_assign(lx_2, env_1, target_3, v_), [=](crate::lower::model::Do assign_116009) { return prism_rtl::finished(std::tuple{Array(std::vector{assign_116009}), env_1}); });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m) ? ({
        auto&& target = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
        auto&& op = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a1;
        auto&& value = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a2;
        ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto op_3 = op;
        auto s_4 = s;
        auto target_5 = target;
        auto value_6 = value;
        call_then(start_place_of(lx_2, env_1, target_5), [=](crate::lower::model::Ex place_of_116093) {
        return ({
            auto cur = place_of_116093;
            call_then(start_out_ty_of(lx_2, peel(type_at(lx_2, target_5.span))), [=](crate::lower::model::OutTy out_ty_of_116134) {
            return ({
                auto tt = out_ty_of_116134;
                call_then(start_value_of(lx_2, env_1, value_6), [=](Vl value_of_116195) {
                return ({
                    auto rv = value_of_116195;
                    auto bin = crate::syntax::lexer::head(op_3);
                    auto next = op_value(lx_2, bin, Vl(Vl::VlPlace{cur, Holding(Holding::Owned{}), tt}), rv, s_4.span, tt);
                    call_then(start_assign(lx_2, env_1, target_5, own(next)), [=](crate::lower::model::Do assign_116334) { return prism_rtl::finished(std::tuple{Array(std::vector{assign_116334}), env_1}); });
                });
            });
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& x = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto p__3 = p_;
        auto s_4 = s;
        auto x_5 = x;
        call_then(start_value_of(lx_2, env_1, x_5), [=](Vl value_of_116423) {
        return ({
            auto v_ = own(value_of_116423);
            ({
            auto&& _m = p__3.kind;
            prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
            auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            crate::syntax::lexer::has_prefix(n.sigils, Text::lit("&"))
            ? ({
            auto rs = local_name(lx_2, crate::check::env::sname_key(n));
            auto n_6 = n;
            call_then(start_out_ty_of(lx_2, peel(binder_ty(lx_2, n_6.span))), [=](crate::lower::model::OutTy out_ty_of_116617) {
            return ({
                auto bt = out_ty_of_116617;
                call_then(start_is_known_ty(bt), [=](bool is_known_ty_116690) {
                return ({
                    auto pa = is_known_ty_116690
                        ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaMut{prism_rtl::cat(rs)})), bt})
                        : crate::lower::model::Pa(crate::lower::model::Pa::PaMut{prism_rtl::cat(rs)});
                    (prism_rtl::finished(std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{pa, v_})}), bind(env_1, crate::check::env::sname_key(n_6), Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs}), Holding(Holding::Owned{}), bt}))}));
                });
            });
            });
        });
        })
            : prism_rtl::more(prism_rtl::rc(BlockStmt(lx_2, env_1, s_4)));
        })
            : prism_rtl::more(prism_rtl::rc(BlockStmt(lx_2, env_1, s_4)));
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
        auto&& body = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
        ({
        auto body_1 = body;
        auto c_2 = c;
        auto env_3 = env;
        auto lx_4 = lx;
        auto s_5 = s;
        call_then(start_upd_stmts(lx_4, env_3, body_1.stmts), [=](std::tuple<Array<crate::lower::model::Do>, Env> upd_stmts_116989) {
        return ({
            auto&& _inner = upd_stmts_116989;
            auto&& inner = std::get<0>(_inner);
            ({
            prism_rtl::is<crate::syntax::Cond::CondExpr>(c_2) ? ({
            auto&& x = prism_rtl::as<crate::syntax::Cond::CondExpr>(c_2).a0;
            ({
            auto x_6 = x;
            call_then(start_value_of(lx_4, env_3, x_6), [=](Vl value_of_117081) { return prism_rtl::finished(std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoWhile{as_bool(value_of_117081), inner})}), env_3}); });
        });
        })
            : prism_rtl::is<crate::syntax::Cond::CondBind>(c_2) ? ({
            auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(c_2).a0;
            auto&& x = prism_rtl::as<crate::syntax::Cond::CondBind>(c_2).a1;
            auto&& g_opt = prism_rtl::as<crate::syntax::Cond::CondBind>(c_2).a2;
            ({
            auto g_opt_6 = g_opt;
            auto p__7 = p_;
            auto x_8 = x;
            call_then(start_rust_pat(lx_4, p__7, type_at(lx_4, x_8.span), Holding(Holding::Owned{}), prism_rtl::cat("w", s_5.span.start)), [=](PatOut rust_pat_117175) {
            return ({
                auto po = rust_pat_117175;
                auto env_b = bind_all(env_3, po.binds);
                call_then(start_upd_stmts(lx_4, env_b, body_1.stmts), [=](std::tuple<Array<crate::lower::model::Do>, Env> upd_stmts_117326) {
                return ({
                    auto&& _inner2 = upd_stmts_117326;
                    auto&& inner2 = std::get<0>(_inner2);
                    call_then(start_guard_conds(lx_4, env_b, g_opt_6), [=](Array<crate::lower::model::Cc> guard_conds_117584) {
                    return ({
                        auto conds = append(po.conds, guard_conds_117584);
                        auto tests = fold(conds, Array<crate::lower::model::Ex>{}, [&](const Array<crate::lower::model::Ex>& acc, const crate::lower::model::Cc& c) {
                            return ({
                                __label__ _done;
                                prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
                                if (prism_rtl::is<crate::lower::model::Cc::CcIf>(c)) {
                                    auto&& t = prism_rtl::as<crate::lower::model::Cc::CcIf>(c).a0;
                                    _v.set(crate::prelude::push(acc, t));
                                    goto _done;
                                }
                                {
                                    _v.set(acc);
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            });
                        });
                        auto lets = fold(conds, false, [&](const bool& f, const crate::lower::model::Cc& c) { return f || is_let_cond(c); });
                        auto stop = len(tests) == Nat(0u)
                            ? Array<crate::lower::model::Do>{}
                            : Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{Text::lit("!"), prism_rtl::rc(all_of(tests))}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("break")})})}), Array<crate::lower::model::Do>{}})});
                        auto body2 = lets
                            ? Array(std::vector{refusal_do(Text::lit("a `while` whose pattern matches through an `Rc`"))})
                            : append(stop, inner2);
                        call_then(start_value_of(lx_4, env_3, x_8), [=](Vl value_of_118123) { return prism_rtl::finished(std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoWhileLet{po.pa, own(value_of_118123), body2})}), env_3}); });
                    });
                });
                });
            });
            });
        });
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        ({
        auto&& _m = x.kind;
        prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        ({
        auto else_b_opt_1 = else_b_opt;
        auto c_2 = c;
        auto env_3 = env;
        auto lx_4 = lx;
        auto then_b_5 = then_b;
        call_then(start_upd_if(lx_4, env_3, c_2, then_b_5, else_b_opt_1), [=](crate::lower::model::Do upd_if_118223) { return prism_rtl::finished(std::tuple{Array(std::vector{upd_if_118223}), env_3}); });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
        auto&& scrut = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        ({
        auto arms_1 = arms;
        auto env_2 = env;
        auto lx_3 = lx;
        auto scrut_4 = scrut;
        call_then(start_upd_match(lx_3, env_2, scrut_4, arms_1), [=](crate::lower::model::Do upd_match_118298) { return prism_rtl::finished(std::tuple{Array(std::vector{upd_match_118298}), env_2}); });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EFor>(_m) ? ({
        auto&& binders_opt = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
        auto&& source = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
        ({
        auto binders_opt_1 = binders_opt;
        auto body_2 = body;
        auto env_3 = env;
        auto lx_4 = lx;
        auto source_5 = source;
        auto x_6 = x;
        call_then(start_upd_for(lx_4, env_3, binders_opt_1, source_5, body_2, x_6.span), [=](crate::lower::model::Do upd_for_118380) { return prism_rtl::finished(std::tuple{Array(std::vector{upd_for_118380}), env_3}); });
    });
    })
        : ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto x_3 = x;
        call_then(start_value_of(lx_2, env_1, x_3), [=](Vl value_of_118473) { return prism_rtl::finished(std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{own(value_of_118473)})}), env_1}); });
    });
    });
    })
        : prism_rtl::more(prism_rtl::rc(BlockStmt(lx, env, s)));
    });
}


/// `Start UpdStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, Env>> start_upd_stmt(Lx lx, Env env, crate::syntax::Stmt s) {
    return prism_rtl::make_rc<UpdStmt>(lx, env, s);
}


/// UpdFor: unbounded fn Lx, Env, ?ForBinders, Expr, Block, Range -> Do
crate::lower::model::Do upd_for(const Lx& lx, const Env& env, const std::optional<crate::syntax::ForBinders>& binders_opt, const crate::syntax::Expr& source, const crate::syntax::Block& body, const crate::syntax::Range& span) {
    auto sty = peel(type_at(lx, source.span));
    auto&& _m = ref_binder(binders_opt);
    if (prism_rtl::is_some(_m)) {
        auto&& n = prism_rtl::some_of(_m);
        return is_ref_path(source)
            ? upd_for_refs(lx, env, n, source, body, span, sty)
            : upd_for_values(lx, env, binders_opt, source, body, span, sty);
    }
    if (prism_rtl::is_none(_m)) {
        return upd_for_values(lx, env, binders_opt, source, body, span, sty);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::model::Do> UpdFor::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& binders_opt = this->binders_opt;
    const auto& source = this->source;
    const auto& body = this->body;
    const auto& span = this->span;
    auto sty = peel(type_at(lx, source.span));
    return ({
        auto&& _m = ref_binder(binders_opt);
        prism_rtl::is_some(_m) ? ({
        auto&& n = prism_rtl::some_of(_m);
        is_ref_path(source)
        ? prism_rtl::more(prism_rtl::rc(UpdForRefs(lx, env, n, source, body, span, sty)))
        : prism_rtl::more(prism_rtl::rc(UpdForValues(lx, env, binders_opt, source, body, span, sty)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(UpdForValues(lx, env, binders_opt, source, body, span, sty)))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start UpdFor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Do> start_upd_for(Lx lx, Env env, std::optional<crate::syntax::ForBinders> binders_opt, crate::syntax::Expr source, crate::syntax::Block body, crate::syntax::Range span) {
    return prism_rtl::make_rc<UpdFor>(lx, env, binders_opt, source, body, span);
}


/// UpdForRefs: unbounded fn Lx, Env, SName, Expr, Block, Range, Ty -> Do
crate::lower::model::Do upd_for_refs(const Lx& lx, const Env& env, const crate::syntax::SName& n, const crate::syntax::Expr& source, const crate::syntax::Block& body, const crate::syntax::Range& span, const crate::check::types::Ty& sty) {
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(sty)) {
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyArray>(sty).a0;
        auto key_name = prism_rtl::cat("k", span.start);
        auto ref_name = prism_rtl::cat("r", span.start);
        auto env1 = bind(bind(bind(env, Text::lit("key"), Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name}), Holding(Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{})})), Text::lit("ix"), Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name}), Holding(Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{})})), crate::check::env::sname_key(n), Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XTarget{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{ref_name}))}), Holding(Holding::Owned{}), out_ty_of(lx, v_)}));
        auto&& _dos = upd_stmts(lx, env1, body.stmts);
        auto&& dos = std::get<0>(_dos);
        auto head = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{key_name}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("nat_of"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("i", span.start)})})})});
        return crate::lower::model::Do(crate::lower::model::Do::DoFor{crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat("i", span.start)}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{ref_name})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(place_of(lx, env, source)), Text::lit("iter_mut"), Array<crate::lower::model::Ex>{}})), Text::lit("enumerate"), Array<crate::lower::model::Ex>{}}), append(Array(std::vector{head}), dos)});
    }
    {
        return refusal_do(Text::lit("a `for` by reference over what is not an array"));
    }
}


prism_rtl::Turn<crate::lower::model::Do> UpdForRefs::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& n = this->n;
    const auto& source = this->source;
    const auto& body = this->body;
    const auto& span = this->span;
    const auto& sty = this->sty;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyArray>(sty) ? ({
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyArray>(sty).a0;
        ({
        auto key_name = prism_rtl::cat("k", span.start);
        auto ref_name = prism_rtl::cat("r", span.start);
        auto body_1 = body;
        auto env_2 = env;
        auto lx_3 = lx;
        auto n_4 = n;
        auto source_5 = source;
        auto span_6 = span;
        auto v__7 = v_;
        call_then(start_out_ty_of(lx_3, v__7), [=](crate::lower::model::OutTy out_ty_of_119833) {
        return ({
            auto env1 = bind(bind(bind(env_2, Text::lit("key"), Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name}), Holding(Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{})})), Text::lit("ix"), Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name}), Holding(Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{})})), crate::check::env::sname_key(n_4), Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XTarget{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{ref_name}))}), Holding(Holding::Owned{}), out_ty_of_119833}));
            call_then(start_upd_stmts(lx_3, env1, body_1.stmts), [=](std::tuple<Array<crate::lower::model::Do>, Env> upd_stmts_119879) {
            return ({
                auto&& _dos = upd_stmts_119879;
                auto&& dos = std::get<0>(_dos);
                auto head = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{key_name}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("nat_of"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("i", span_6.start)})})})});
                call_then(start_place_of(lx_3, env_2, source_5), [=](crate::lower::model::Ex place_of_120088) { return prism_rtl::finished(crate::lower::model::Do(crate::lower::model::Do::DoFor{crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat("i", span_6.start)}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{ref_name})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(place_of_120088), Text::lit("iter_mut"), Array<crate::lower::model::Ex>{}})), Text::lit("enumerate"), Array<crate::lower::model::Ex>{}}), append(Array(std::vector{head}), dos)})); });
            });
        });
        });
    });
    });
    })
        : prism_rtl::finished(refusal_do(Text::lit("a `for` by reference over what is not an array")));
    });
}


/// `Start UpdForRefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Do> start_upd_for_refs(Lx lx, Env env, crate::syntax::SName n, crate::syntax::Expr source, crate::syntax::Block body, crate::syntax::Range span, crate::check::types::Ty sty) {
    return prism_rtl::make_rc<UpdForRefs>(lx, env, n, source, body, span, sty);
}


/// ?RefBinder: fn ?ForBinders -> ?SName
std::optional<crate::syntax::SName> ref_binder(const std::optional<crate::syntax::ForBinders>& opt0) {
    if (prism_rtl::is_some(opt0)) {
        auto&& fb = prism_rtl::some_of(opt0);
        auto&& _m = fb.second;
        if (prism_rtl::is_none(_m)) {
            auto&& _m = fb.first.kind;
            if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                return crate::syntax::lexer::has_prefix(n.sigils, Text::lit("&"))
                    ? std::optional(n)
                    : std::optional<crate::syntax::SName>{};
            }
            {
                return std::optional<crate::syntax::SName>{};
            }
        }
        {
            return std::optional<crate::syntax::SName>{};
        }
    }
    if (prism_rtl::is_none(opt0)) {
        return std::optional<crate::syntax::SName>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// IsRefPath: fn Expr -> Bool
bool is_ref_path(const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return crate::syntax::lexer::has_prefix(n.sigils, Text::lit("&"));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        return is_ref_path(r);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        return is_ref_path(r);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return is_ref_path(x);
    }
    {
        return false;
    }
}


/// UpdForValues: unbounded fn Lx, Env, ?ForBinders, Expr, Block, Range, Ty -> Do
crate::lower::model::Do upd_for_values(const Lx& lx, const Env& env, const std::optional<crate::syntax::ForBinders>& binders_opt, const crate::syntax::Expr& source, const crate::syntax::Block& body, const crate::syntax::Range& span, const crate::check::types::Ty& sty) {
    auto src = own(value_of(lx, env, source));
    auto [kt, vt, is_array] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::lower::model::OutTy, crate::lower::model::OutTy, bool>> _v;
        if (prism_rtl::is<crate::check::types::Ty::TyArray>(sty)) {
            auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyArray>(sty).a0;
            _v.set(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{}), out_ty_of(lx, v_), true});
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyMap>(sty)) {
            auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(sty).a0;
            auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(sty).a1;
            _v.set(std::tuple{out_ty_of(lx, k), out_ty_of(lx, v_), false});
            goto _done;
        }
        {
            _v.set(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), true});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [vty, kty] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::Ty>> _v;
        if (prism_rtl::is<crate::check::types::Ty::TyArray>(sty)) {
            auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyArray>(sty).a0;
            _v.set(std::tuple{v_, crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Nat"), Array<crate::check::types::Ty>{}})});
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyMap>(sty)) {
            auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(sty).a0;
            auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(sty).a1;
            _v.set(std::tuple{v_, k});
            goto _done;
        }
        {
            _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::Ty(crate::check::types::Ty::TyErr{})});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto key_name = prism_rtl::cat("k", span.start);
    auto val_name = prism_rtl::cat("v", span.start);
    auto env1 = bind(bind(env, Text::lit("key"), Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name}), Holding(Holding::Owned{}), kt})), Text::lit("_"), Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{val_name}), Holding(Holding::Owned{}), vt}));
    auto env2 = is_array
        ? bind(env1, Text::lit("ix"), Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name}), Holding(Holding::Owned{}), kt}))
        : env1;
    auto [binds, env3] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, Env>> _v;
        if (prism_rtl::is_none(binders_opt)) {
            _v.set(std::tuple{Array<crate::lower::model::Do>{}, env2});
            goto _done;
        }
        if (prism_rtl::is_some(binders_opt)) {
            auto&& fb = prism_rtl::some_of(binders_opt);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, Env>> _v;
                auto&& _m = fb.second;
                if (prism_rtl::is_none(_m)) {
                    _v.set(({
                        auto po = rust_pat(lx, fb.first, vty, Holding(Holding::Owned{}), prism_rtl::cat("e", span.start));
                        std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{po.pa, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{val_name}))})})}), bind_all(env2, po.binds)};
                    }));
                    goto _done;
                }
                if (prism_rtl::is_some(_m)) {
                    auto&& second = prism_rtl::some_of(_m);
                    _v.set(({
                        auto pk = rust_pat(lx, fb.first, kty, Holding(Holding::Owned{}), prism_rtl::cat("k", span.start, "_"));
                        auto pv = rust_pat(lx, second, vty, Holding(Holding::Owned{}), prism_rtl::cat("e", span.start));
                        std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{pk.pa, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name}))})}), crate::lower::model::Do(crate::lower::model::Do::DoLet{pv.pa, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{val_name}))})})}), bind_all(bind_all(env2, pk.binds), pv.binds)};
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& _dos = upd_stmts(lx, env3, body.stmts);
    auto&& dos = std::get<0>(_dos);
    return is_array
        ? ({
        auto head = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{key_name}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("nat_of"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("i", span.start)})})})});
        (crate::lower::model::Do(crate::lower::model::Do::DoFor{crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat("i", span.start)}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{val_name})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(src), Text::lit("into_iter"), Array<crate::lower::model::Ex>{}})), Text::lit("enumerate"), Array<crate::lower::model::Ex>{}}), append(crate::prelude::push(Array<crate::lower::model::Do>{}, head), append(binds, dos))}));
    })
        : crate::lower::model::Do(crate::lower::model::Do::DoFor{crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{key_name}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{val_name})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(src), Text::lit("into_iter"), Array<crate::lower::model::Ex>{}}), append(binds, dos)});
}


prism_rtl::Turn<crate::lower::model::Do> UpdForValues::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& binders_opt = this->binders_opt;
    const auto& source = this->source;
    const auto& body = this->body;
    const auto& span = this->span;
    const auto& sty = this->sty;
    auto binders_opt_1 = binders_opt;
    auto body_2 = body;
    auto env_3 = env;
    auto lx_4 = lx;
    auto source_5 = source;
    auto span_6 = span;
    auto sty_7 = sty;
    return call_then(start_value_of(lx_4, env_3, source_5), [=](Vl value_of_120983) {
        return ({
            auto src = own(value_of_120983);
            auto [kt, vt, is_array] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::lower::model::OutTy, crate::lower::model::OutTy, bool>> _v;
                if (prism_rtl::is<crate::check::types::Ty::TyArray>(sty)) {
                    auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyArray>(sty).a0;
                    _v.set(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{}), out_ty_of(lx_4, v_), true});
                    goto _done;
                }
                if (prism_rtl::is<crate::check::types::Ty::TyMap>(sty)) {
                    auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(sty).a0;
                    auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(sty).a1;
                    _v.set(std::tuple{out_ty_of(lx_4, k), out_ty_of(lx_4, v_), false});
                    goto _done;
                }
                {
                    _v.set(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), true});
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto [vty, kty] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::Ty>> _v;
                if (prism_rtl::is<crate::check::types::Ty::TyArray>(sty)) {
                    auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyArray>(sty).a0;
                    _v.set(std::tuple{v_, crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Nat"), Array<crate::check::types::Ty>{}})});
                    goto _done;
                }
                if (prism_rtl::is<crate::check::types::Ty::TyMap>(sty)) {
                    auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(sty).a0;
                    auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(sty).a1;
                    _v.set(std::tuple{v_, k});
                    goto _done;
                }
                {
                    _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::Ty(crate::check::types::Ty::TyErr{})});
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto key_name = prism_rtl::cat("k", span_6.start);
            auto val_name = prism_rtl::cat("v", span_6.start);
            auto env1 = bind(bind(env_3, Text::lit("key"), Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name}), Holding(Holding::Owned{}), kt})), Text::lit("_"), Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{val_name}), Holding(Holding::Owned{}), vt}));
            auto env2 = is_array
                ? bind(env1, Text::lit("ix"), Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name}), Holding(Holding::Owned{}), kt}))
                : env1;
            auto [binds, env3] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, Env>> _v;
                if (prism_rtl::is_none(binders_opt)) {
                    _v.set(std::tuple{Array<crate::lower::model::Do>{}, env2});
                    goto _done;
                }
                if (prism_rtl::is_some(binders_opt)) {
                    auto&& fb = prism_rtl::some_of(binders_opt);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, Env>> _v;
                        auto&& _m = fb.second;
                        if (prism_rtl::is_none(_m)) {
                            _v.set(({
                                auto po = rust_pat(lx_4, fb.first, vty, Holding(Holding::Owned{}), prism_rtl::cat("e", span_6.start));
                                std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{po.pa, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{val_name}))})})}), bind_all(env2, po.binds)};
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_some(_m)) {
                            auto&& second = prism_rtl::some_of(_m);
                            _v.set(({
                                auto pk = rust_pat(lx_4, fb.first, kty, Holding(Holding::Owned{}), prism_rtl::cat("k", span_6.start, "_"));
                                auto pv = rust_pat(lx_4, second, vty, Holding(Holding::Owned{}), prism_rtl::cat("e", span_6.start));
                                std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{pk.pa, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name}))})}), crate::lower::model::Do(crate::lower::model::Do::DoLet{pv.pa, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{val_name}))})})}), bind_all(bind_all(env2, pk.binds), pv.binds)};
                            }));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            call_then(start_upd_stmts(lx_4, env3, body_2.stmts), [=](std::tuple<Array<crate::lower::model::Do>, Env> upd_stmts_122264) {
            return ({
                auto&& _dos = upd_stmts_122264;
                auto&& dos = std::get<0>(_dos);
                is_array
                ? ({
                auto head = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{key_name}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("nat_of"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("i", span_6.start)})})})});
                (prism_rtl::finished(crate::lower::model::Do(crate::lower::model::Do::DoFor{crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat("i", span_6.start)}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{val_name})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(src), Text::lit("into_iter"), Array<crate::lower::model::Ex>{}})), Text::lit("enumerate"), Array<crate::lower::model::Ex>{}}), append(crate::prelude::push(Array<crate::lower::model::Do>{}, head), append(binds, dos))})));
            })
                : prism_rtl::finished(crate::lower::model::Do(crate::lower::model::Do::DoFor{crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{key_name}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{val_name})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(src), Text::lit("into_iter"), Array<crate::lower::model::Ex>{}}), append(binds, dos)}));
            });
        });
        });
    });
}


/// `Start UpdForValues, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Do> start_upd_for_values(Lx lx, Env env, std::optional<crate::syntax::ForBinders> binders_opt, crate::syntax::Expr source, crate::syntax::Block body, crate::syntax::Range span, crate::check::types::Ty sty) {
    return prism_rtl::make_rc<UpdForValues>(lx, env, binders_opt, source, body, span, sty);
}


/// UpdIf: unbounded fn Lx, Env, Cond, Block, ?Block -> Do
crate::lower::model::Do upd_if(const Lx& lx, const Env& env, const crate::syntax::Cond& c, const crate::syntax::Block& then_b, const std::optional<crate::syntax::Block>& else_b_opt) {
    auto&& _else_dos = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, Env>> _v;
        if (prism_rtl::is_some(else_b_opt)) {
            auto&& b = prism_rtl::some_of(else_b_opt);
            _v.set(upd_stmts(lx, env, b.stmts));
            goto _done;
        }
        if (prism_rtl::is_none(else_b_opt)) {
            _v.set(std::tuple{Array<crate::lower::model::Do>{}, env});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& else_dos = std::get<0>(_else_dos);
    if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c)) {
        auto&& x = prism_rtl::as<crate::syntax::Cond::CondExpr>(c).a0;
        auto&& _then_dos = upd_stmts(lx, env, then_b.stmts);
        auto&& then_dos = std::get<0>(_then_dos);
        return crate::lower::model::Do(crate::lower::model::Do::DoIf{as_bool(value_of(lx, env, x)), then_dos, else_dos});
    }
    if (prism_rtl::is<crate::syntax::Cond::CondBind>(c)) {
        auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a0;
        auto&& x = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a1;
        auto po = rust_pat(lx, p_, type_at(lx, x.span), Holding(Holding::Owned{}), prism_rtl::cat("u", x.span.start));
        auto&& _then_dos = upd_stmts(lx, bind_all(env, po.binds), then_b.stmts);
        auto&& then_dos = std::get<0>(_then_dos);
        return crate::lower::model::Do(crate::lower::model::Do::DoIfLet{po.pa, own(value_of(lx, env, x)), then_dos, else_dos});
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::model::Do> UpdIf::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& c = this->c;
    const auto& then_b = this->then_b;
    const auto& else_b_opt = this->else_b_opt;
    auto&& _else_dos = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, Env>> _v;
        if (prism_rtl::is_some(else_b_opt)) {
            auto&& b = prism_rtl::some_of(else_b_opt);
            _v.set(upd_stmts(lx, env, b.stmts));
            goto _done;
        }
        if (prism_rtl::is_none(else_b_opt)) {
            _v.set(std::tuple{Array<crate::lower::model::Do>{}, env});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& else_dos = std::get<0>(_else_dos);
    return ({
        prism_rtl::is<crate::syntax::Cond::CondExpr>(c) ? ({
        auto&& x = prism_rtl::as<crate::syntax::Cond::CondExpr>(c).a0;
        ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto then_b_3 = then_b;
        auto x_4 = x;
        call_then(start_upd_stmts(lx_2, env_1, then_b_3.stmts), [=](std::tuple<Array<crate::lower::model::Do>, Env> upd_stmts_122974) {
        return ({
            auto&& _then_dos = upd_stmts_122974;
            auto&& then_dos = std::get<0>(_then_dos);
            call_then(start_value_of(lx_2, env_1, x_4), [=](Vl value_of_123030) { return prism_rtl::finished(crate::lower::model::Do(crate::lower::model::Do::DoIf{as_bool(value_of_123030), then_dos, else_dos})); });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::Cond::CondBind>(c) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a0;
        auto&& x = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a1;
        ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto p__3 = p_;
        auto then_b_4 = then_b;
        auto x_5 = x;
        call_then(start_rust_pat(lx_2, p__3, type_at(lx_2, x_5.span), Holding(Holding::Owned{}), prism_rtl::cat("u", x_5.span.start)), [=](PatOut rust_pat_123121) {
        return ({
            auto po = rust_pat_123121;
            call_then(start_upd_stmts(lx_2, bind_all(env_1, po.binds), then_b_4.stmts), [=](std::tuple<Array<crate::lower::model::Do>, Env> upd_stmts_123220) {
            return ({
                auto&& _then_dos = upd_stmts_123220;
                auto&& then_dos = std::get<0>(_then_dos);
                call_then(start_value_of(lx_2, env_1, x_5), [=](Vl value_of_123303) { return prism_rtl::finished(crate::lower::model::Do(crate::lower::model::Do::DoIfLet{po.pa, own(value_of_123303), then_dos, else_dos})); });
            });
        });
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start UpdIf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Do> start_upd_if(Lx lx, Env env, crate::syntax::Cond c, crate::syntax::Block then_b, std::optional<crate::syntax::Block> else_b_opt) {
    return prism_rtl::make_rc<UpdIf>(lx, env, c, then_b, else_b_opt);
}


/// UpdMatch: unbounded fn Lx, Env, Expr, [Arm] -> Do
crate::lower::model::Do upd_match(const Lx& lx, const Env& env, const crate::syntax::Expr& scrut, const Array<crate::syntax::Arm>& arms) {
    auto sv = value_of(lx, env, scrut);
    auto sty = type_at(lx, scrut.span);
    auto arms3 = run_to_end(each_job(crate::check::errors::range0(len(arms)), ({
        auto arms_1 = arms;
        auto lx_2 = lx;
        auto sty_3 = sty;
        auto scrut_4 = scrut;
        auto env_5 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::XArm>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto arms_1_6 = arms_1;
            auto lx_2_6 = lx_2;
            auto sty_3_6 = sty_3;
            auto scrut_4_6 = scrut_4;
            auto env_5_6 = env_5;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto arm = or_(index(arms_1_6, i), dummy_arm());
                call_then(start_arm_pat(lx_2_6, arm.pattern, sty_3_6, Holding(Holding::ByRef{}), prism_rtl::cat("u", scrut_4_6.span.start, "_", i)), [=](PatOut arm_pat_123602) {
                return ({
                    auto po = arm_pat_123602;
                    call_then(start_upd_stmts(lx_2_6, bind_all(env_5_6, po.binds), arm.body.stmts), [=](std::tuple<Array<crate::lower::model::Do>, Env> upd_stmts_123695) {
                    return ({
                        auto&& _dos = upd_stmts_123695;
                        auto&& dos = std::get<0>(_dos);
                        call_then(start_guard_conds(lx_2_6, bind_all(env_5_6, po.binds), arm.guard), [=](Array<crate::lower::model::Cc> guard_conds_123788) {
                        return ({
                            auto guarded = append(po.conds, guard_conds_123788);
                            (prism_rtl::finished(crate::lower::model::XArm{.pat = po.pa, .conds = guarded, .body = crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}))})}));
                        });
                    });
                    });
                });
                });
            });
            });
            });
        }));
        });
    })));
    })));
    return fold(arms3, false, [&](const bool& f, const crate::lower::model::XArm& a) { return f || (len(a.conds) > Nat(0u)); })
        ? crate::lower::model::Do(crate::lower::model::Do::DoExpr{own(arms_value(ref_(sv), arms3, prism_rtl::cat("'u", scrut.span.start), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})))})
        : crate::lower::model::Do(crate::lower::model::Do::DoMatch{ref_(sv), each(arms3, [&](const crate::lower::model::XArm& a) { return std::tuple{a.pat, arm_dos(a.body)}; })});
}


prism_rtl::Turn<crate::lower::model::Do> UpdMatch::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& scrut = this->scrut;
    const auto& arms = this->arms;
    auto arms_1 = arms;
    auto env_2 = env;
    auto lx_3 = lx;
    auto scrut_4 = scrut;
    return call_then(start_value_of(lx_3, env_2, scrut_4), [=](Vl value_of_123440) {
        return ({
            auto sv = value_of_123440;
            auto sty = type_at(lx_3, scrut_4.span);
            call_value(each_job(crate::check::errors::range0(len(arms_1)), ({
            auto arms_1_5 = arms_1;
            auto lx_3_5 = lx_3;
            auto sty_5 = sty;
            auto scrut_4_6 = scrut_4;
            auto env_2_6 = env_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::XArm>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto arms_1_5_6 = arms_1_5;
                auto lx_3_5_6 = lx_3_5;
                auto sty_5_6 = sty_5;
                auto scrut_4_6_6 = scrut_4_6;
                auto env_2_6_6 = env_2_6;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    ({
                    auto arm = or_(index(arms_1_5_6, i), dummy_arm());
                    call_then(start_arm_pat(lx_3_5_6, arm.pattern, sty_5_6, Holding(Holding::ByRef{}), prism_rtl::cat("u", scrut_4_6_6.span.start, "_", i)), [=](PatOut arm_pat_123602) {
                    return ({
                        auto po = arm_pat_123602;
                        call_then(start_upd_stmts(lx_3_5_6, bind_all(env_2_6_6, po.binds), arm.body.stmts), [=](std::tuple<Array<crate::lower::model::Do>, Env> upd_stmts_123695) {
                        return ({
                            auto&& _dos = upd_stmts_123695;
                            auto&& dos = std::get<0>(_dos);
                            call_then(start_guard_conds(lx_3_5_6, bind_all(env_2_6_6, po.binds), arm.guard), [=](Array<crate::lower::model::Cc> guard_conds_123788) {
                            return ({
                                auto guarded = append(po.conds, guard_conds_123788);
                                (prism_rtl::finished(crate::lower::model::XArm{.pat = po.pa, .conds = guarded, .body = crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}))})}));
                            });
                        });
                        });
                    });
                    });
                });
                });
                });
            }));
            });
        })));
        })), [=](Array<crate::lower::model::XArm> each_123515) {
            return ({
                auto arms3 = each_123515;
                fold(arms3, false, [&](const bool& f, const crate::lower::model::XArm& a) { return f || (len(a.conds) > Nat(0u)); })
                ? prism_rtl::finished(crate::lower::model::Do(crate::lower::model::Do::DoExpr{own(arms_value(ref_(sv), arms3, prism_rtl::cat("'u", scrut_4.span.start), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})))}))
                : prism_rtl::finished(crate::lower::model::Do(crate::lower::model::Do::DoMatch{ref_(sv), each(arms3, [&](const crate::lower::model::XArm& a) { return std::tuple{a.pat, arm_dos(a.body)}; })}));
            });
        });
        });
    });
}


/// `Start UpdMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Do> start_upd_match(Lx lx, Env env, crate::syntax::Expr scrut, Array<crate::syntax::Arm> arms) {
    return prism_rtl::make_rc<UpdMatch>(lx, env, scrut, arms);
}


/// AllOf: fn [Ex] -> Ex
crate::lower::model::Ex all_of(const Array<crate::lower::model::Ex>& xs0) {
    {
        auto&& c0_0 = xs0;
        if (c0_0.size() == 1u) {
            {
                auto&& _c1 = index(c0_0, Nat(0u));
                if (prism_rtl::is_some(_c1)) {
                    auto&& one = prism_rtl::some_of(_c1);
                    return one;
                }
            }
        }
    }
    {
        auto&& xs = xs0;
        return fold(drop(xs, Nat(1u)), or_(index(xs, Nat(0u)), crate::lower::model::Ex(crate::lower::model::Ex::XBool{true})), [&](const crate::lower::model::Ex& acc, const crate::lower::model::Ex& x) { return crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("&&"), prism_rtl::rc(acc), prism_rtl::rc(x)}); });
    }
}


/// ArmDos: fn Ex -> [Do]
Array<crate::lower::model::Do> arm_dos(const crate::lower::model::Ex& ex0) {
    if (prism_rtl::is<crate::lower::model::Ex::XBlock>(ex0)) {
        auto&& dos = prism_rtl::as<crate::lower::model::Ex::XBlock>(ex0).a0;
        return dos;
    }
    {
        auto&& x = ex0;
        return Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{x})});
    }
}


/// GuardConds: unbounded fn Lx, Env, ?Expr -> [Cc]
Array<crate::lower::model::Cc> guard_conds(const Lx& lx, const Env& env, const std::optional<crate::syntax::Expr>& opt2) {
    if (prism_rtl::is_some(opt2)) {
        auto&& ge = prism_rtl::some_of(opt2);
        return Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{as_bool(value_of(lx, env, ge))})});
    }
    if (prism_rtl::is_none(opt2)) {
        return Array<crate::lower::model::Cc>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<crate::lower::model::Cc>> GuardConds::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& opt2 = this->opt2;
    return ({
        prism_rtl::is_some(opt2) ? ({
        auto&& ge = prism_rtl::some_of(opt2);
        ({
        auto env_1 = env;
        auto ge_2 = ge;
        auto lx_3 = lx;
        call_then(start_value_of(lx_3, env_1, ge_2), [=](Vl value_of_124630) { return prism_rtl::finished(Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{as_bool(value_of_124630)})})); });
    });
    })
        : prism_rtl::is_none(opt2) ? prism_rtl::finished(Array<crate::lower::model::Cc>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start GuardConds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::Cc>> start_guard_conds(Lx lx, Env env, std::optional<crate::syntax::Expr> opt2) {
    return prism_rtl::make_rc<GuardConds>(lx, env, opt2);
}


/// PlaceOf: unbounded fn Lx, Env, Expr -> Ex
crate::lower::model::Ex place_of(const Lx& lx, const Env& env, const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        auto&& _m = crate::prelude::get(env->names, crate::check::env::sname_key(n));
        if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
            auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
            return rs;
        }
        {
            return crate::lower::model::Ex(crate::lower::model::Ex::XVar{snake(crate::check::env::sname_key(n))});
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        auto&& name = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a2;
        return crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(place_of(lx, env, r)), snake(name.name)});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& k = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        auto rt = out_ty_of(lx, peel(type_at(lx, r.span)));
        auto f = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(rt)) {
                _v.set(Text::lit("at_mut_map"));
                goto _done;
            }
            {
                _v.set(Text::lit("at_mut"));
                goto _done;
            }
        _done:
            _v.take();
        });
        return crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{f, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRefMut{prism_rtl::rc(place_of(lx, env, r))}), argument(lx, env, k)})}))});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return place_of(lx, env, x);
    }
    {
        return refusal(Text::lit("a reference path this back end does not lower"));
    }
}


prism_rtl::Turn<crate::lower::model::Ex> PlaceOf::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        ({
        auto&& _m = crate::prelude::get(env->names, crate::check::env::sname_key(n));
        prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m)) ? ({
        auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
        prism_rtl::finished(rs);
    })
        : prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XVar{snake(crate::check::env::sname_key(n))}));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EField>(_m) ? ({
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        auto&& name = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a2;
        ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto name_3 = name;
        auto r_4 = r;
        call_then(start_place_of(lx_2, env_1, r_4), [=](crate::lower::model::Ex place_of_124998) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(place_of_124998), snake(name_3.name)})); });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m) ? ({
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& k = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        ({
        auto env_1 = env;
        auto k_2 = k;
        auto lx_3 = lx;
        auto r_4 = r;
        call_then(start_out_ty_of(lx_3, peel(type_at(lx_3, r_4.span))), [=](crate::lower::model::OutTy out_ty_of_125071) {
        return ({
            auto rt = out_ty_of_125071;
            auto f = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(rt)) {
                    _v.set(Text::lit("at_mut_map"));
                    goto _done;
                }
                {
                    _v.set(Text::lit("at_mut"));
                    goto _done;
                }
            _done:
                _v.take();
            });
            call_then(start_place_of(lx_3, env_1, r_4), [=](crate::lower::model::Ex place_of_125253) { return call_then(start_argument(lx_3, env_1, k_2), [=](crate::lower::model::Ex argument_125276) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{f, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRefMut{prism_rtl::rc(place_of_125253)}), argument_125276})}))})); }); });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(PlaceOf(lx, env, x)));
    })
        : prism_rtl::finished(refusal(Text::lit("a reference path this back end does not lower")));
    });
}

}  // namespace crate::lower
