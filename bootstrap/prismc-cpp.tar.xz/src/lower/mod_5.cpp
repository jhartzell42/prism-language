// The module `Lower`, from `target/bootstrap/cpp-src/prismc/lower/mod.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include <lower/module.hpp>
#include <lower/node_/module.hpp>
#include <syntax/module.hpp>
#include <check/env/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/passes/module.hpp>
#include <check/shrink/module.hpp>
#include <check/typed/module.hpp>
#include <check/types/module.hpp>
#include <lower/model/module.hpp>
#include <syntax/lexer/module.hpp>
#include <lower/node_/generic.hpp>
#include <check/env/generic.hpp>
#include <syntax/lexer/generic.hpp>

namespace crate::lower {

/// `Start TailMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_tail_match(Lx lx, Env env, crate::syntax::Expr s, Array<crate::syntax::Arm> arms, crate::syntax::Range span) {
    return prism_rtl::make_rc<TailMatch>(lx, env, s, arms, span);
}


/// ?TailCallee: fn Lx, Env, Expr -> ?Text
std::optional<Text> tail_callee(const Lx& lx, const Env& env, const crate::syntax::Expr& callee) {
    auto&& _m = callee.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return (len(n->path_) == Nat(1u)) && crate::check::env::has_key(env->names, crate::check::env::sname_key(n))
            ? std::optional<Text>{}
            : ({
            auto&& _qk_opt = crate::check::env::resolve_value(lx.g, lx.home, n);
            auto&& qk_opt = std::get<0>(_qk_opt);
            ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Text>> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& qk = prism_rtl::some_of(qk_opt);
                _v.set(crate::check::types::has_text(lx.unbs, qk) && (!in_prelude(lx, qk))
                    ? std::optional(qk)
                    : std::optional<Text>{});
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(std::optional<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        });
    }
    {
        return std::optional<Text>{};
    }
}


/// SchemeParts: fn Lx, Text -> (([Ty], Ty))
std::tuple<Array<crate::check::types::Ty>, crate::check::types::Ty> scheme_parts(const Lx& lx, const Text& qk) {
    auto&& _m = crate::prelude::get(lx.g.vals, qk);
    if (prism_rtl::is_some(_m)) {
        auto&& v_ = prism_rtl::some_of(_m);
        auto&& _m = v_.scheme.ty;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            auto&& r = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
            return std::tuple{ps, r};
        }
        {
            auto&& other = _m;
            return std::tuple{Array<crate::check::types::Ty>{}, other};
        }
    }
    if (prism_rtl::is_none(_m)) {
        return std::tuple{Array<crate::check::types::Ty>{}, crate::check::types::Ty(crate::check::types::Ty::TyErr{})};
    }
    prism_rtl::unreachable("no arm matched");
}


/// JobFieldNames: unbounded fn Lx, Text -> [Text]
Array<Text> job_field_names(const Lx& lx, const Text& qk) {
    auto clauses = clauses_of(lx.g, qk);
    auto&& _ptys = scheme_parts(lx, qk);
    auto&& ptys = std::get<0>(_ptys);
    auto pts = run_to_end(each_job(ptys, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_1_2, peel(p_)))));
            });
        }));
        });
    })));
    })));
    return each(param_names(lx, clauses, pts), [&](const std::tuple<Text, bool>& _p0) {
        auto&& n = std::get<0>(_p0);
        return n;
    });
}


prism_rtl::Turn<Array<Text>> JobFieldNames::cycle() const {
    const auto& lx = this->lx;
    const auto& qk = this->qk;
    auto clauses = clauses_of(lx.g, qk);
    auto&& _ptys = scheme_parts(lx, qk);
    auto&& ptys = std::get<0>(_ptys);
    auto lx_1 = lx;
    return call_value(each_job(ptys, ({
        auto lx_1_2 = lx_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return ({
            auto lx_1_2_2 = lx_1_2;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_1_2_2, peel(p_)))));
            });
        }));
        });
    })));
    })), [=](Array<crate::lower::model::OutTy> each_168982) {
        return ({
            auto pts = each_168982;
            (prism_rtl::finished(each(param_names(lx_1, clauses, pts), [&](const std::tuple<Text, bool>& _p0) {
            auto&& n = std::get<0>(_p0);
            return n;
        })));
        });
    });
}


/// `Start JobFieldNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_job_field_names(Lx lx, Text qk) {
    return prism_rtl::make_rc<JobFieldNames>(lx, qk);
}


/// ClausesOf: fn G, Text -> [FnClause]
Array<crate::syntax::FnClause> clauses_of(const crate::check::env::G& g, const Text& qk) {
    return fold(g.defs, Array<crate::syntax::FnClause>{}, [&](const Array<crate::syntax::FnClause>& acc, const crate::check::env::Def& d) { return d.qk == qk ? def_clauses(d, acc) : acc; });
}


/// DefClauses: fn Def, [FnClause] -> [FnClause]
Array<crate::syntax::FnClause> def_clauses(const crate::check::env::Def& d, const Array<crate::syntax::FnClause>& other) {
    auto&& _m = d.body;
    if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
        auto&& cs = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
        return cs;
    }
    {
        return other;
    }
}


/// JobDefOf: unbounded fn Lx, Text, [FnClause], Scheme -> JobDef
crate::lower::model::JobDef job_def_of(const Lx& lx, const Text& qk, const Array<crate::syntax::FnClause>& clauses, const crate::check::types::Scheme& sc) {
    auto [ptys, res] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::check::types::Ty>, crate::check::types::Ty>> _v;
        auto&& _m = sc.ty;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            auto&& r = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
            _v.set(std::tuple{ps, r});
            goto _done;
        }
        {
            auto&& other = _m;
            _v.set(std::tuple{Array<crate::check::types::Ty>{}, other});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto pts = run_to_end(each_job(ptys, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_1_2, peel(p_)))));
            });
        }));
        });
    })));
    })));
    auto names = param_names(lx, clauses, pts);
    auto body = job_clauses(lx, clauses, names, ptys, pts);
    auto base_ = or_(crate::prelude::get(lx.rs_names, qk), snake(crate::check::types::bare_name(qk)));
    return crate::lower::model::JobDef{.name = camel(crate::check::types::bare_name(qk)), .start = prism_rtl::cat("start_", base_), .generics = scheme_generics(lx, sc), .fields = each(crate::check::errors::range0(len(pts)), [&](const Nat& i) {
        return std::tuple{or_(index(each(names, [&](const std::tuple<Text, bool>& _p0) {
            auto&& n = std::get<0>(_p0);
            return n;
        }), i), Text::lit("arg")), or_(index(pts, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))};
    }), .ret = out_ty_of(lx, peel(res)), .body = body, .doc = signature_text(lx, qk)};
}


prism_rtl::Turn<crate::lower::model::JobDef> JobDefOf::cycle() const {
    const auto& lx = this->lx;
    const auto& qk = this->qk;
    const auto& clauses = this->clauses;
    const auto& sc = this->sc;
    auto [ptys, res] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::check::types::Ty>, crate::check::types::Ty>> _v;
        auto&& _m = sc.ty;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            auto&& r = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
            _v.set(std::tuple{ps, r});
            goto _done;
        }
        {
            auto&& other = _m;
            _v.set(std::tuple{Array<crate::check::types::Ty>{}, other});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto clauses_1 = clauses;
    auto lx_2 = lx;
    auto qk_3 = qk;
    auto sc_4 = sc;
    return call_value(each_job(ptys, ({
        auto lx_2_5 = lx_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return ({
            auto lx_2_5_5 = lx_2_5;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_2_5_5, peel(p_)))));
            });
        }));
        });
    })));
    })), [=](Array<crate::lower::model::OutTy> each_169636) {
        return ({
            auto pts = each_169636;
            auto names = param_names(lx_2, clauses_1, pts);
            call_then(start_job_clauses(lx_2, clauses_1, names, ptys, pts), [=](crate::lower::model::Ex job_clauses_169732) {
            return ({
                auto body = job_clauses_169732;
                auto base_ = or_(crate::prelude::get(lx_2.rs_names, qk_3), snake(crate::check::types::bare_name(qk_3)));
                call_then(start_out_ty_of(lx_2, peel(res)), [=](crate::lower::model::OutTy out_ty_of_170043) {
                return prism_rtl::finished(crate::lower::model::JobDef{.name = camel(crate::check::types::bare_name(qk_3)), .start = prism_rtl::cat("start_", base_), .generics = scheme_generics(lx_2, sc_4), .fields = each(crate::check::errors::range0(len(pts)), [&](const Nat& i) {
                    return std::tuple{or_(index(each(names, [&](const std::tuple<Text, bool>& _p0) {
                        auto&& n = std::get<0>(_p0);
                        return n;
                    }), i), Text::lit("arg")), or_(index(pts, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))};
                }), .ret = out_ty_of_170043, .body = body, .doc = signature_text(lx_2, qk_3)});
            });
            });
        });
        });
    });
}


/// `Start JobDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::JobDef> start_job_def_of(Lx lx, Text qk, Array<crate::syntax::FnClause> clauses, crate::check::types::Scheme sc) {
    return prism_rtl::make_rc<JobDefOf>(lx, qk, clauses, sc);
}


/// JobClauses: unbounded fn Lx, [FnClause], [((Text, Bool))], [Ty], [OutTy] -> Ex
crate::lower::model::Ex job_clauses(const Lx& lx, const Array<crate::syntax::FnClause>& clauses, const Array<std::tuple<Text, bool>>& names, const Array<crate::check::types::Ty>& ptys, const Array<crate::lower::model::OutTy>& pts) {
    auto lets = each(crate::check::errors::range0(len(names)), [&](const Nat& i) {
        return ({
            auto&& _rs = or_(index(names, i), std::tuple{Text::lit("arg"), true});
            auto&& rs = std::get<0>(_rs);
            (crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{rs}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), rs}))})}));
        });
    });
    auto inner = clauses_body(lx, empty_env(), clauses, names, ptys, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Lx, Env, crate::syntax::FnBody>)>>(prism_rtl::rc([&](std::tuple<Lx, Env, crate::syntax::FnBody> _p0) {
        auto&& a0 = std::get<0>(_p0);
        auto&& a1 = std::get<1>(_p0);
        auto&& a2 = std::get<2>(_p0);
        return entered(start_tail_body(a0, a1, a2));
    })), Text::lit("j"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{Text::lit("the job's turn")}));
    return crate::lower::model::Ex(crate::lower::model::Ex::XBlock{lets, prism_rtl::rc(inner)});
}


prism_rtl::Turn<crate::lower::model::Ex> JobClauses::cycle() const {
    const auto& lx = this->lx;
    const auto& clauses = this->clauses;
    const auto& names = this->names;
    const auto& ptys = this->ptys;
    const auto& pts = this->pts;
    auto lets = each(crate::check::errors::range0(len(names)), [&](const Nat& i) {
        return ({
            auto&& _rs = or_(index(names, i), std::tuple{Text::lit("arg"), true});
            auto&& rs = std::get<0>(_rs);
            (crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{rs}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), rs}))})}));
        });
    });
    auto clauses_1 = clauses;
    auto lx_2 = lx;
    auto names_3 = names;
    auto ptys_4 = ptys;
    return call_then(start_clauses_body(lx_2, empty_env(), clauses_1, names_3, ptys_4, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Lx, Env, crate::syntax::FnBody>)>>(prism_rtl::rc([&](std::tuple<Lx, Env, crate::syntax::FnBody> _p0) {
        auto&& a0 = std::get<0>(_p0);
        auto&& a1 = std::get<1>(_p0);
        auto&& a2 = std::get<2>(_p0);
        return entered(start_tail_body(a0, a1, a2));
    })), Text::lit("j"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{Text::lit("the job's turn")})), [=](crate::lower::model::Ex clauses_body_170472) {
        return ({
            auto inner = clauses_body_170472;
            (prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XBlock{lets, prism_rtl::rc(inner)})));
        });
    });
}


/// `Start JobClauses, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_job_clauses(Lx lx, Array<crate::syntax::FnClause> clauses, Array<std::tuple<Text, bool>> names, Array<crate::check::types::Ty> ptys, Array<crate::lower::model::OutTy> pts) {
    return prism_rtl::make_rc<JobClauses>(lx, clauses, names, ptys, pts);
}


/// InModule: fn Lx, Nat, Text -> Lx
Lx in_module(const Lx& lx, const Nat& file, const Text& home) {
    Lx this_ = lx;
    this_.file = file;
    this_.home = home;
    this_.site = home;
    return this_;
}


/// InModuleAt: fn Lx, Nat, Text, Text -> Lx
Lx in_module_at(const Lx& lx, const Nat& file, const Text& home, const Text& site) {
    Lx this_ = lx;
    this_.file = file;
    this_.home = home;
    this_.site = site;
    return this_;
}


/// LowerProgram: unbounded fn [Src], [Module], Nat, TProgram, Text -> Model
crate::lower::model::Model lower_program(const Array<crate::check::errors::Src>& srcs, const Array<crate::syntax::Module>& trees, const Nat& shown, const crate::check::typed::TProgram& tp, const Text& name) {
    auto&& _g = crate::check::env::build_g(srcs, trees);
    auto&& g = std::get<0>(_g);
    auto [tys, apps, bs, ims] = typed_tables(tp);
    auto gens = fold(tp.gens, Map<Text, crate::check::typed::GenNote>{}, [&](const Map<Text, crate::check::typed::GenNote>& m, const crate::check::typed::GenNote& n) { return insert(m, crate::check::typed::at_key(n.at), n); });
    auto insts = fold(tp.insts, Map<Text, Array<crate::check::typed::InstNote>>{}, [&](const Map<Text, Array<crate::check::typed::InstNote>>& m, const crate::check::typed::InstNote& n) { return insert(m, inst_key(n), crate::prelude::push(or_(crate::prelude::get(m, inst_key(n)), Array<crate::check::typed::InstNote>{}), n)); });
    auto quants = fold(tp.gens, Map<Text, Text>{}, [&](const Map<Text, Text>& m, const crate::check::typed::GenNote& n) { return fold(append(n.tys, n.cols), m, [&](const Map<Text, Text>& m2, const Text& q) { return insert(m2, q, n.name); }); });
    auto gen_of_q = fold(tp.gens, Map<Text, crate::check::typed::GenNote>{}, [&](const Map<Text, crate::check::typed::GenNote>& m, const crate::check::typed::GenNote& n) { return fold(append(n.tys, n.cols), m, [&](const Map<Text, crate::check::typed::GenNote>& m2, const Text& q) { return insert(m2, q, n); }); });
    auto use_insts = fold(tp.insts, Map<Text, crate::check::typed::InstNote>{}, [&](const Map<Text, crate::check::typed::InstNote>& m, const crate::check::typed::InstNote& n) { return insert(m, crate::check::typed::at_key(n.at), n); });
    auto mods = needed_mods(g, shown);
    auto rs_mods = fold(mods, Map<Text, Text>{}, [&](const Map<Text, Text>& acc, const Text& m) { return insert(acc, m, rust_mod_name(m)); });
    auto lx0 = Lx{.g = g, .tys = tys, .apps = apps, .binders = bs, .impls = ims, .file = Nat(0u), .home = Text::lit(""), .site = Text::lit(""), .rs_mods = rs_mods, .rs_names = value_names(g), .layouts = layouts(g), .unbs = Array<Text>{}, .notes = Array<Text>{}, .globals = global_names(g), .in_node = false, .unshrunk = fold(tp.unshrunk, Map<Text, bool>{}, [&](const Map<Text, bool>& m, const crate::check::typed::SrcAt& a) { return insert(m, crate::check::typed::at_key(a), true); }), .gens = gens, .insts = insts, .quants = quants, .gen_of_q = gen_of_q, .use_insts = use_insts, .subst = Map<Text, crate::check::types::Ty>{}, .csubst = Map<Text, crate::check::types::Col>{}};
    auto lx = ({
        Lx this_ = lx0;
        this_.unbs = job_roots(lx0);
        this_;
    });
    auto roots = root_widgets(lx);
    auto mod_defs = run_to_end(each_job(mods, ({
        auto lx_1 = lx;
        auto roots_2 = roots;
        auto g_3 = g;
        auto mods_4 = mods;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::ModDef>(Text)>>(prism_rtl::rc([=](Text p0) {
        return ({
            auto lx_1_5 = lx_1;
            auto roots_2_5 = roots_2;
            auto g_3_5 = g_3;
            auto mods_4_5 = mods_4;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                (prism_rtl::more(prism_rtl::rc(ModDefOf(lx_1_5, m, roots_2_5, or_(crate::prelude::get(g_3_5.mods, m), crate::check::env::dummy_mod()), mods_4_5))));
            });
        }));
        });
    })));
    })));
    auto programs = run_to_end(each_job(roots, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::ProgDef>(std::tuple<Text, bool>)>>(prism_rtl::rc([=](std::tuple<Text, bool> p0) {
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto&& _qk = p0;
                auto&& qk = std::get<0>(_qk);
                (prism_rtl::more(prism_rtl::rc(ProgDefOf(lx_1_2, qk))));
            });
        }));
        });
    })));
    })));
    auto main_qk = fold(g.defs, Text::lit(""), [&](const Text& found, const crate::check::env::Def& d) { return (found == Text::lit("")) && is_main(d.qk) ? d.qk : found; });
    auto root_opt = main_qk == Text::lit("")
        ? std::optional<crate::lower::model::ProgDef>{}
        : std::optional(prog_def_of(lx, main_qk));
    auto checks = run_to_end(fold_job(g.defs, Array<crate::lower::model::CheckDef>{}, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::CheckDef>>(std::tuple<Array<crate::lower::model::CheckDef>, crate::check::env::Def>)>>(prism_rtl::rc([=](std::tuple<Array<crate::lower::model::CheckDef>, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto d = p1;
                ({
                auto&& _m = d.body;
                prism_rtl::is<crate::check::env::DefBody::DbCheck>(_m) ? ({
                auto&& c = prism_rtl::as<crate::check::env::DefBody::DbCheck>(_m).a0;
                ({
                auto c_2 = c;
                call_then(start_check_def_of(in_module_at(lx_1_2, d->file, d.home, Text::lit("\000main"sv)), c_2), [=](crate::lower::model::CheckDef check_def_of_173147) { return prism_rtl::finished(crate::prelude::push(acc, check_def_of_173147)); });
            });
            })
                : prism_rtl::finished(acc);
            });
            });
        }));
        });
    })));
    })));
    auto with_needs_ = with_groups(with_needs(g, srcs, tp, mod_defs));
    auto elem = elem_row(lx, mods);
    auto answer = answer_enum(in_module_at(lx, Nat(0u), Text::lit(""), Text::lit("\000main"sv)), mods);
    auto names = each(with_needs_, [&](const crate::lower::model::ModDef& d) { return d.name; });
    auto value_tys = value_types(with_needs_);
    auto elem_held = fold(elem.cases_, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, Text>& _p1) {
        auto&& sp = std::get<1>(_p1);
        return crate::check::types::union_texts(acc, held_in(names, value_tys, Text::lit(""), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{sp, Array<crate::lower::model::OutTy>{}})));
    });
    auto answer_held = fold(answer.cases_, elem_held, [&](const Array<Text>& acc, const crate::lower::model::AnswerCase& k) { return crate::check::types::union_texts(acc, held_in(names, value_tys, Text::lit(""), k.ty)); });
    auto answer_named = fold(answer.cases_, Array<Text>{}, [&](const Array<Text>& acc, const crate::lower::model::AnswerCase& k) { return crate::check::types::union_texts(acc, named_in(names, Text::lit(""), k.ty)); });
    return crate::lower::model::Model{.name = name, .mods = with_needs_, .programs = programs, .root = root_opt, .checks = checks, .elem = elem, .answer = answer, .elem_complete = answer_held, .elem_declared = crate::check::types::minus_texts(answer_named, answer_held), .scripts = Array<Text>{}, .notes = Array<Text>{}};
}


prism_rtl::Turn<crate::lower::model::Model> LowerProgram::cycle() const {
    const auto& srcs = this->srcs;
    const auto& trees = this->trees;
    const auto& shown = this->shown;
    const auto& tp = this->tp;
    const auto& name = this->name;
    auto name_1 = name;
    auto shown_2 = shown;
    auto srcs_3 = srcs;
    auto tp_4 = tp;
    auto trees_5 = trees;
    return call_then(crate::check::env::start_build_g(srcs_3, trees_5), [=](std::tuple<crate::check::env::G, crate::check::types::St> build_g_171656) {
        return ({
            auto&& _g = build_g_171656;
            auto&& g = std::get<0>(_g);
            auto [tys, apps, bs, ims] = typed_tables(tp_4);
            auto gens = fold(tp_4.gens, Map<Text, crate::check::typed::GenNote>{}, [&](const Map<Text, crate::check::typed::GenNote>& m, const crate::check::typed::GenNote& n) { return insert(m, crate::check::typed::at_key(n.at), n); });
            auto insts = fold(tp_4.insts, Map<Text, Array<crate::check::typed::InstNote>>{}, [&](const Map<Text, Array<crate::check::typed::InstNote>>& m, const crate::check::typed::InstNote& n) { return insert(m, inst_key(n), crate::prelude::push(or_(crate::prelude::get(m, inst_key(n)), Array<crate::check::typed::InstNote>{}), n)); });
            auto quants = fold(tp_4.gens, Map<Text, Text>{}, [&](const Map<Text, Text>& m, const crate::check::typed::GenNote& n) { return fold(append(n.tys, n.cols), m, [&](const Map<Text, Text>& m2, const Text& q) { return insert(m2, q, n.name); }); });
            auto gen_of_q = fold(tp_4.gens, Map<Text, crate::check::typed::GenNote>{}, [&](const Map<Text, crate::check::typed::GenNote>& m, const crate::check::typed::GenNote& n) { return fold(append(n.tys, n.cols), m, [&](const Map<Text, crate::check::typed::GenNote>& m2, const Text& q) { return insert(m2, q, n); }); });
            auto use_insts = fold(tp_4.insts, Map<Text, crate::check::typed::InstNote>{}, [&](const Map<Text, crate::check::typed::InstNote>& m, const crate::check::typed::InstNote& n) { return insert(m, crate::check::typed::at_key(n.at), n); });
            call_then(start_needed_mods(g, shown_2), [=](Array<Text> needed_mods_172182) {
            return ({
                auto mods = needed_mods_172182;
                auto rs_mods = fold(mods, Map<Text, Text>{}, [&](const Map<Text, Text>& acc, const Text& m) { return insert(acc, m, rust_mod_name(m)); });
                call_then(start_layouts(g), [=](Map<Text, Array<bool>> layouts_172414) {
                return ({
                    auto lx0 = Lx{.g = g, .tys = tys, .apps = apps, .binders = bs, .impls = ims, .file = Nat(0u), .home = Text::lit(""), .site = Text::lit(""), .rs_mods = rs_mods, .rs_names = value_names(g), .layouts = layouts_172414, .unbs = Array<Text>{}, .notes = Array<Text>{}, .globals = global_names(g), .in_node = false, .unshrunk = fold(tp_4.unshrunk, Map<Text, bool>{}, [&](const Map<Text, bool>& m, const crate::check::typed::SrcAt& a) { return insert(m, crate::check::typed::at_key(a), true); }), .gens = gens, .insts = insts, .quants = quants, .gen_of_q = gen_of_q, .use_insts = use_insts, .subst = Map<Text, crate::check::types::Ty>{}, .csubst = Map<Text, crate::check::types::Col>{}};
                    auto lx = ({
                        Lx this_ = lx0;
                        this_.unbs = job_roots(lx0);
                        this_;
                    });
                    auto roots = root_widgets(lx);
                    call_value(each_job(mods, ({
                    auto lx_6 = lx;
                    auto roots_7 = roots;
                    auto g_8 = g;
                    auto mods_9 = mods;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::ModDef>(Text)>>(prism_rtl::rc([=](Text p0) {
                    return ({
                        auto lx_6_10 = lx_6;
                        auto roots_7_10 = roots_7;
                        auto g_8_10 = g_8;
                        auto mods_9_10 = mods_9;
                        entered(once_job([=]() {
                        return ({
                            auto m = p0;
                            (prism_rtl::more(prism_rtl::rc(ModDefOf(lx_6_10, m, roots_7_10, or_(crate::prelude::get(g_8_10.mods, m), crate::check::env::dummy_mod()), mods_9_10))));
                        });
                    }));
                    });
                })));
                })), [=](Array<crate::lower::model::ModDef> each_172756) {
                    return ({
                        auto mod_defs = each_172756;
                        call_value(each_job(roots, ({
                        auto lx_6 = lx;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::ProgDef>(std::tuple<Text, bool>)>>(prism_rtl::rc([=](std::tuple<Text, bool> p0) {
                        return ({
                            auto lx_6_7 = lx_6;
                            entered(once_job([=]() {
                            return ({
                                auto&& _qk = p0;
                                auto&& qk = std::get<0>(_qk);
                                (prism_rtl::more(prism_rtl::rc(ProgDefOf(lx_6_7, qk))));
                            });
                        }));
                        });
                    })));
                    })), [=](Array<crate::lower::model::ProgDef> each_172845) {
                        return ({
                            auto programs = each_172845;
                            auto main_qk = fold(g.defs, Text::lit(""), [&](const Text& found, const crate::check::env::Def& d) { return (found == Text::lit("")) && is_main(d.qk) ? d.qk : found; });
                            auto root_opt = main_qk == Text::lit("")
                                ? std::optional<crate::lower::model::ProgDef>{}
                                : std::optional(prog_def_of(lx, main_qk));
                            call_value(fold_job(g.defs, Array<crate::lower::model::CheckDef>{}, ({
                            auto lx_6 = lx;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::CheckDef>>(std::tuple<Array<crate::lower::model::CheckDef>, crate::check::env::Def>)>>(prism_rtl::rc([=](std::tuple<Array<crate::lower::model::CheckDef>, crate::check::env::Def> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto lx_6_7 = lx_6;
                                entered(once_job([=]() {
                                return ({
                                    auto acc = p0;
                                    auto d = p1;
                                    ({
                                    auto&& _m = d.body;
                                    prism_rtl::is<crate::check::env::DefBody::DbCheck>(_m) ? ({
                                    auto&& c = prism_rtl::as<crate::check::env::DefBody::DbCheck>(_m).a0;
                                    ({
                                    auto c_7 = c;
                                    call_then(start_check_def_of(in_module_at(lx_6_7, d->file, d.home, Text::lit("\000main"sv)), c_7), [=](crate::lower::model::CheckDef check_def_of_173147) { return prism_rtl::finished(crate::prelude::push(acc, check_def_of_173147)); });
                                });
                                })
                                    : prism_rtl::finished(acc);
                                });
                                });
                            }));
                            });
                        })));
                        })), [=](Array<crate::lower::model::CheckDef> fold_173074) {
                            return ({
                                auto checks = fold_173074;
                                call_then(start_with_needs(g, srcs_3, tp_4, mod_defs), [=](Array<crate::lower::model::ModDef> with_needs_173262) {
                                return call_then(start_with_groups(with_needs_173262), [=](Array<crate::lower::model::ModDef> with_groups_173250) {
                                    return ({
                                        auto with_needs_ = with_groups_173250;
                                        call_then(start_elem_row(lx, mods), [=](crate::lower::model::RowDef elem_row_173309) {
                                        return ({
                                            auto elem = elem_row_173309;
                                            call_then(start_answer_enum(in_module_at(lx, Nat(0u), Text::lit(""), Text::lit("\000main"sv)), mods), [=](crate::lower::model::AnswerDef answer_enum_173343) {
                                            return ({
                                                auto answer = answer_enum_173343;
                                                auto names = each(with_needs_, [&](const crate::lower::model::ModDef& d) { return d.name; });
                                                auto value_tys = value_types(with_needs_);
                                                auto elem_held = fold(elem.cases_, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, Text>& _p1) {
                                                    auto&& sp = std::get<1>(_p1);
                                                    return crate::check::types::union_texts(acc, held_in(names, value_tys, Text::lit(""), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{sp, Array<crate::lower::model::OutTy>{}})));
                                                });
                                                auto answer_held = fold(answer.cases_, elem_held, [&](const Array<Text>& acc, const crate::lower::model::AnswerCase& k) { return crate::check::types::union_texts(acc, held_in(names, value_tys, Text::lit(""), k.ty)); });
                                                auto answer_named = fold(answer.cases_, Array<Text>{}, [&](const Array<Text>& acc, const crate::lower::model::AnswerCase& k) { return crate::check::types::union_texts(acc, named_in(names, Text::lit(""), k.ty)); });
                                                (prism_rtl::finished(crate::lower::model::Model{.name = name_1, .mods = with_needs_, .programs = programs, .root = root_opt, .checks = checks, .elem = elem, .answer = answer, .elem_complete = answer_held, .elem_declared = crate::check::types::minus_texts(answer_named, answer_held), .scripts = Array<Text>{}, .notes = Array<Text>{}}));
                                            });
                                        });
                                        });
                                    });
                                    });
                                });
                            });
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start LowerProgram, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Model> start_lower_program(Array<crate::check::errors::Src> srcs, Array<crate::syntax::Module> trees, Nat shown, crate::check::typed::TProgram tp, Text name) {
    return prism_rtl::make_rc<LowerProgram>(srcs, trees, shown, tp, name);
}


/// WithNeeds: unbounded fn G, [Src], TProgram, [ModDef] -> [ModDef]
Array<crate::lower::model::ModDef> with_needs(const crate::check::env::G& g, const Array<crate::check::errors::Src>& srcs, const crate::check::typed::TProgram& tp, const Array<crate::lower::model::ModDef>& defs) {
    auto names = each(defs, [&](const crate::lower::model::ModDef& d) { return d.name; });
    auto value_tys = value_types(defs);
    auto refs = named_mods(g, srcs, tp, each(defs, [&](const crate::lower::model::ModDef& d) { return d.prism; }));
    return run_to_end(each_job(defs, ({
        auto names_1 = names;
        auto value_tys_2 = value_tys;
        auto refs_3 = refs;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::ModDef>(crate::lower::model::ModDef)>>(prism_rtl::rc([=](crate::lower::model::ModDef p0) {
        return ({
            auto names_1_4 = names_1;
            auto value_tys_2_4 = value_tys_2;
            auto refs_3_4 = refs_3;
            entered(once_job([=]() {
            return ({
                auto d = p0;
                ({
                auto held = fold(d.items, Array<Text>{}, [&](const Array<Text>& acc, const crate::lower::model::Item& it) { return crate::check::types::union_texts(acc, item_held(names_1_4, value_tys_2_4, d.name, it)); });
                auto complete = filter(held, [&](const Text& n) { return n != d.name; });
                call_then(start_reached_by(refs_3_4, Array(std::vector{d.prism}), Array<Text>{}), [=](Array<Text> reached_by_174557) {
                return ({
                    auto reached = each(reached_by_174557, [&](const Text& m) { return rust_mod_name(m); });
                    auto declared = filter(names_1_4, [&](const Text& n) { return ((n != d.name) && crate::check::types::has_text(reached, n)) && (!crate::check::types::has_text(complete, n)); });
                    (prism_rtl::finished(({
                    crate::lower::model::ModDef this_ = d;
                    this_.complete = complete;
                    this_.declared = declared;
                    this_;
                })));
                });
            });
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<crate::lower::model::ModDef>> WithNeeds::cycle() const {
    const auto& g = this->g;
    const auto& srcs = this->srcs;
    const auto& tp = this->tp;
    const auto& defs = this->defs;
    auto names = each(defs, [&](const crate::lower::model::ModDef& d) { return d.name; });
    auto value_tys = value_types(defs);
    auto defs_1 = defs;
    auto g_2 = g;
    auto srcs_3 = srcs;
    auto tp_4 = tp;
    return call_then(start_named_mods(g_2, srcs_3, tp_4, each(defs_1, [&](const crate::lower::model::ModDef& d) { return d.prism; })), [=](Map<Text, Array<Text>> named_mods_174302) {
        return ({
            auto refs = named_mods_174302;
            each_job(defs_1, ({
            auto names_5 = names;
            auto value_tys_6 = value_tys;
            auto refs_7 = refs;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::ModDef>(crate::lower::model::ModDef)>>(prism_rtl::rc([=](crate::lower::model::ModDef p0) {
            return ({
                auto names_5_8 = names_5;
                auto value_tys_6_8 = value_tys_6;
                auto refs_7_8 = refs_7;
                entered(once_job([=]() {
                return ({
                    auto d = p0;
                    ({
                    auto held = fold(d.items, Array<Text>{}, [&](const Array<Text>& acc, const crate::lower::model::Item& it) { return crate::check::types::union_texts(acc, item_held(names_5_8, value_tys_6_8, d.name, it)); });
                    auto complete = filter(held, [&](const Text& n) { return n != d.name; });
                    call_then(start_reached_by(refs_7_8, Array(std::vector{d.prism}), Array<Text>{}), [=](Array<Text> reached_by_174557) {
                    return ({
                        auto reached = each(reached_by_174557, [&](const Text& m) { return rust_mod_name(m); });
                        auto declared = filter(names_5_8, [&](const Text& n) { return ((n != d.name) && crate::check::types::has_text(reached, n)) && (!crate::check::types::has_text(complete, n)); });
                        (prism_rtl::finished(({
                        crate::lower::model::ModDef this_ = d;
                        this_.complete = complete;
                        this_.declared = declared;
                        this_;
                    })));
                    });
                });
                });
                });
            }));
            });
        })));
        }))->cycle();
        });
    });
}


/// `Start WithNeeds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::ModDef>> start_with_needs(crate::check::env::G g, Array<crate::check::errors::Src> srcs, crate::check::typed::TProgram tp, Array<crate::lower::model::ModDef> defs) {
    return prism_rtl::make_rc<WithNeeds>(g, srcs, tp, defs);
}


/// NamedMods: unbounded fn G, [Src], TProgram, [Text] -> (Text ==> [Text])
Map<Text, Array<Text>> named_mods(const crate::check::env::G& g, const Array<crate::check::errors::Src>& srcs, const crate::check::typed::TProgram& tp, const Array<Text>& ms) {
    auto by_path = fold(values(g.mods), Map<Text, Text>{}, [&](const Map<Text, Text>& acc, const crate::check::env::ModInfo& info) { return insert(acc, or_(index(srcs, info->file), crate::check::errors::mk_src(Text::lit(""), Text::lit("")))->path_, info.name); });
    auto by_file = fold(values(g.mods), Map<Nat, Text>{}, [&](const Map<Nat, Text>& acc, const crate::check::env::ModInfo& info) { return insert(acc, info->file, info.name); });
    auto solved = fold(tp.impls, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& acc, const crate::check::typed::ImplNote& n) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, Array<Text>>> _v;
            auto&& _m = crate::prelude::get(by_file, n.at->file);
            if (prism_rtl::is_some(_m)) {
                auto&& site = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Map<Text, Array<Text>>> _v;
                    auto&& _m = crate::prelude::get(by_path, impl_path(n.how));
                    if (prism_rtl::is_some(_m)) {
                        auto&& home = prism_rtl::some_of(_m);
                        _v.set((home == site) || crate::check::types::has_text(or_(crate::prelude::get(acc, site), Array<Text>{}), home)
                            ? acc
                            : insert(acc, site, crate::prelude::push(or_(crate::prelude::get(acc, site), Array<Text>{}), home)));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(acc);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    return run_to_end(fold_job(ms, Map<Text, Array<Text>>{}, ({
        auto g_1 = g;
        auto srcs_2 = srcs;
        auto ms_3 = ms;
        auto solved_4 = solved;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, Text>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Array<Text>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_5 = g_1;
            auto srcs_2_5 = srcs_2;
            auto ms_3_5 = ms_3;
            auto solved_4_5 = solved_4;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto m = p1;
                ({
                auto&& _m = crate::prelude::get(g_1_5.mods, m);
                prism_rtl::is_some(_m) ? ({
                auto&& info = prism_rtl::some_of(_m);
                ({
                auto code = crate::syntax::lexer::join(filter(split(or_(index(srcs_2_5, info->file), crate::check::errors::mk_src(Text::lit(""), Text::lit("")))->text, Text::lit("\n")), [&](const Text& l) { return !crate::syntax::lexer::has_prefix(crate::syntax::lexer::trim_start(l), Text::lit("#")); }), Text::lit("\n"));
                auto qualified = filter(ms_3_5, [&](const Text& o) { return ((o != m) && (o != Text::lit(""))) && crate::syntax::lexer::contains(code, prism_rtl::cat(o, ".")); });
                call_then(start_mod_refs(g_1_5, m), [=](Array<Text> mod_refs_176204) { return prism_rtl::finished(insert(acc, m, crate::check::types::union_texts(crate::check::types::union_texts(mod_refs_176204, qualified), or_(crate::prelude::get(solved_4_5, m), Array<Text>{})))); });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(acc)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<Map<Text, Array<Text>>> NamedMods::cycle() const {
    const auto& g = this->g;
    const auto& srcs = this->srcs;
    const auto& tp = this->tp;
    const auto& ms = this->ms;
    auto by_path = fold(values(g.mods), Map<Text, Text>{}, [&](const Map<Text, Text>& acc, const crate::check::env::ModInfo& info) { return insert(acc, or_(index(srcs, info->file), crate::check::errors::mk_src(Text::lit(""), Text::lit("")))->path_, info.name); });
    auto by_file = fold(values(g.mods), Map<Nat, Text>{}, [&](const Map<Nat, Text>& acc, const crate::check::env::ModInfo& info) { return insert(acc, info->file, info.name); });
    auto solved = fold(tp.impls, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& acc, const crate::check::typed::ImplNote& n) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, Array<Text>>> _v;
            auto&& _m = crate::prelude::get(by_file, n.at->file);
            if (prism_rtl::is_some(_m)) {
                auto&& site = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Map<Text, Array<Text>>> _v;
                    auto&& _m = crate::prelude::get(by_path, impl_path(n.how));
                    if (prism_rtl::is_some(_m)) {
                        auto&& home = prism_rtl::some_of(_m);
                        _v.set((home == site) || crate::check::types::has_text(or_(crate::prelude::get(acc, site), Array<Text>{}), home)
                            ? acc
                            : insert(acc, site, crate::prelude::push(or_(crate::prelude::get(acc, site), Array<Text>{}), home)));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(acc);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    return fold_job(ms, Map<Text, Array<Text>>{}, ({
        auto g_1 = g;
        auto srcs_2 = srcs;
        auto ms_3 = ms;
        auto solved_4 = solved;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, Text>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Array<Text>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_5 = g_1;
            auto srcs_2_5 = srcs_2;
            auto ms_3_5 = ms_3;
            auto solved_4_5 = solved_4;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto m = p1;
                ({
                auto&& _m = crate::prelude::get(g_1_5.mods, m);
                prism_rtl::is_some(_m) ? ({
                auto&& info = prism_rtl::some_of(_m);
                ({
                auto code = crate::syntax::lexer::join(filter(split(or_(index(srcs_2_5, info->file), crate::check::errors::mk_src(Text::lit(""), Text::lit("")))->text, Text::lit("\n")), [&](const Text& l) { return !crate::syntax::lexer::has_prefix(crate::syntax::lexer::trim_start(l), Text::lit("#")); }), Text::lit("\n"));
                auto qualified = filter(ms_3_5, [&](const Text& o) { return ((o != m) && (o != Text::lit(""))) && crate::syntax::lexer::contains(code, prism_rtl::cat(o, ".")); });
                call_then(start_mod_refs(g_1_5, m), [=](Array<Text> mod_refs_176204) { return prism_rtl::finished(insert(acc, m, crate::check::types::union_texts(crate::check::types::union_texts(mod_refs_176204, qualified), or_(crate::prelude::get(solved_4_5, m), Array<Text>{})))); });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(acc)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start NamedMods, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Array<Text>>> start_named_mods(crate::check::env::G g, Array<crate::check::errors::Src> srcs, crate::check::typed::TProgram tp, Array<Text> ms) {
    return prism_rtl::make_rc<NamedMods>(g, srcs, tp, ms);
}


/// ImplPath: fn Text -> Text
Text impl_path(const Text& how) {
    auto rest = or_(crate::syntax::lexer::after_prefix(how, Text::lit("impl ")), or_(crate::syntax::lexer::after_prefix(how, Text::lit("derived ")), Text::lit("")));
    auto parts = split(rest, Text::lit(":"));
    return crate::syntax::lexer::join(take(parts, crate::syntax::lexer::dec(len(parts))), Text::lit(":"));
}


/// ValueTypes: fn [ModDef] -> (Text ==> Bool)
Map<Text, bool> value_types(const Array<crate::lower::model::ModDef>& defs) {
    return fold(defs, Map<Text, bool>{}, [&](const Map<Text, bool>& acc, const crate::lower::model::ModDef& d) {
        return fold(d.items, acc, [&](const Map<Text, bool>& a, const crate::lower::model::Item& it) {
            return ({
                __label__ _done;
                prism_rtl::Slot<Map<Text, bool>> _v;
                if (prism_rtl::is<crate::lower::model::Item::ItType>(it)) {
                    auto&& t = prism_rtl::as<crate::lower::model::Item::ItType>(it).a0;
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Map<Text, bool>> _v;
                        auto&& _m = t.shape;
                        if (prism_rtl::is<crate::lower::model::TyShape::ShapeChoice>(_m)) {
                            _v.set(a);
                            goto _done;
                        }
                        {
                            _v.set(insert(a, prism_rtl::cat(d.name, "::", t.name), true));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is<crate::lower::model::Item::ItTag>(it)) {
                    auto&& t = prism_rtl::as<crate::lower::model::Item::ItTag>(it).a0;
                    _v.set(insert(a, prism_rtl::cat(d.name, "::", t.name), true));
                    goto _done;
                }
                {
                    _v.set(a);
                    goto _done;
                }
            _done:
                _v.take();
            });
        });
    });
}


/// ItemHeld: fn [Text], (Text ==> Bool), Text, Item -> [Text]
Array<Text> item_held(const Array<Text>& names, const Map<Text, bool>& value_tys, const Text& home, const crate::lower::model::Item& it) {
    if (prism_rtl::is<crate::lower::model::Item::ItType>(it)) {
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItType>(it).a0;
        return fold(t.cases_, Array<Text>{}, [&](const Array<Text>& acc, const crate::lower::model::CaseDef& c) {
            return fold(c.fields, acc, [&](const Array<Text>& a, const std::tuple<Text, crate::lower::model::OutTy>& _p1) {
                auto&& ft = std::get<1>(_p1);
                return crate::check::types::union_texts(a, held_in(names, value_tys, home, ft));
            });
        });
    }
    if (prism_rtl::is<crate::lower::model::Item::ItTag>(it)) {
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItTag>(it).a0;
        return fold(t.fields, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, Text, crate::lower::model::OutTy>& _p1) {
            auto&& ft = std::get<2>(_p1);
            return crate::check::types::union_texts(acc, held_in(names, value_tys, home, ft));
        });
    }
    if (prism_rtl::is<crate::lower::model::Item::ItRow>(it)) {
        auto&& r = prism_rtl::as<crate::lower::model::Item::ItRow>(it).a0;
        return fold(r.cases_, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, Text>& _p1) {
            auto&& sp = std::get<1>(_p1);
            return crate::check::types::union_texts(acc, held_in(names, value_tys, home, crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{sp, Array<crate::lower::model::OutTy>{}})));
        });
    }
    {
        return Array<Text>{};
    }
}


/// HeldIn: fn [Text], (Text ==> Bool), Text, OutTy -> [Text]
Array<Text> held_in(const Array<Text>& names, const Map<Text, bool>& value_tys, const Text& home, const crate::lower::model::OutTy& t) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t)) {
        auto&& n = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a0;
        auto&& args = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        auto p_ = path_from(names, home, n);
        auto own_ = crate::check::env::has_key(value_tys, p_)
            ? Array(std::vector{parent_of(p_)})
            : Array<Text>{};
        return fold(args, own_, [&](const Array<Text>& acc, const crate::lower::model::OutTy& a) { return crate::check::types::union_texts(acc, held_in(names, value_tys, home, a)); });
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t).a0;
        return held_in(names, value_tys, home, i);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t).a0;
        return held_in(names, value_tys, home, i);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutCell>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutCell>(t).a0;
        return held_in(names, value_tys, home, i);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRc>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t).a0;
        return held_in(names, value_tys, home, i);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t).a0;
        return fold(ts, Array<Text>{}, [&](const Array<Text>& acc, const crate::lower::model::OutTy& a) { return crate::check::types::union_texts(acc, held_in(names, value_tys, home, a)); });
    }
    {
        return Array<Text>{};
    }
}


/// NamedIn: fn [Text], Text, OutTy -> [Text]
Array<Text> named_in(const Array<Text>& names, const Text& home, const crate::lower::model::OutTy& t) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t)) {
        auto&& n = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a0;
        auto&& args = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        auto p_ = path_from(names, home, n);
        auto own_ = crate::check::types::has_text(names, parent_of(p_))
            ? Array(std::vector{parent_of(p_)})
            : Array<Text>{};
        return fold(args, own_, [&](const Array<Text>& acc, const crate::lower::model::OutTy& a) { return crate::check::types::union_texts(acc, named_in(names, home, a)); });
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t).a0;
        return named_in(names, home, i);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t).a0;
        return named_in(names, home, i);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutCell>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutCell>(t).a0;
        return named_in(names, home, i);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutArray>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t).a0;
        return named_in(names, home, i);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRc>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t).a0;
        return named_in(names, home, i);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutEvent>(t).a0;
        return named_in(names, home, i);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(t).a0;
        return named_in(names, home, i);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(t)) {
        auto&& k = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t).a1;
        return crate::check::types::union_texts(named_in(names, home, k), named_in(names, home, v_));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t).a0;
        return fold(ts, Array<Text>{}, [&](const Array<Text>& acc, const crate::lower::model::OutTy& a) { return crate::check::types::union_texts(acc, named_in(names, home, a)); });
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(t)) {
        auto&& ps = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t).a0;
        auto&& r = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t).a1;
        return fold(ps, named_in(names, home, r), [&](const Array<Text>& acc, const crate::lower::model::OutTy& a) { return crate::check::types::union_texts(acc, named_in(names, home, a)); });
    }
    {
        return Array<Text>{};
    }
}


/// PathFrom: fn [Text], Text, Text -> Text
Text path_from(const Array<Text>& names, const Text& home, const Text& n) {
    auto q = crate::syntax::lexer::drop_prefix(n, Text::lit("crate::"));
    return starts_with_module(names, q)
        ? q
        : home == Text::lit("") ? q : prism_rtl::cat(home, "::", q);
}


/// StartsWithModule: fn [Text], Text -> Bool
bool starts_with_module(const Array<Text>& names, const Text& q) {
    return fold(names, false, [&](const bool& f, const Text& n) { return f || ((n != Text::lit("")) && crate::syntax::lexer::has_prefix(q, prism_rtl::cat(n, "::"))); });
}


/// ParentOf: fn Text -> Text
Text parent_of(const Text& p_) {
    auto segs = split(p_, Text::lit("::"));
    return crate::syntax::lexer::join(take(segs, crate::syntax::lexer::dec(len(segs))), Text::lit("::"));
}


/// WithGroups: unbounded fn [ModDef] -> [ModDef]
Array<crate::lower::model::ModDef> with_groups(const Array<crate::lower::model::ModDef>& defs) {
    auto edges = fold(defs, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& m, const crate::lower::model::ModDef& d) { return insert(m, d.name, d.complete); });
    auto reach = run_to_end(fold_job(defs, Map<Text, Array<Text>>{}, ({
        auto edges_1 = edges;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, crate::lower::model::ModDef>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Array<Text>>, crate::lower::model::ModDef> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto edges_1_2 = edges_1;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                auto d = p1;
                call_then(start_reached_by(edges_1_2, Array(std::vector{d.name}), Array<Text>{}), [=](Array<Text> reached_by_180490) { return prism_rtl::finished(insert(m, d.name, reached_by_180490)); });
            });
        }));
        });
    }));
    })));
    return each(defs, [&](const crate::lower::model::ModDef& d) {
        return ({
            auto mine = or_(crate::prelude::get(reach, d.name), Array<Text>{});
            ({
            crate::lower::model::ModDef this_ = d;
            this_.types_with = filter(each(defs, [&](const crate::lower::model::ModDef& o) { return o.name; }), [&](const Text& n) { return (n == d.name) || (crate::check::types::has_text(mine, n) && crate::check::types::has_text(or_(crate::prelude::get(reach, n), Array<Text>{}), d.name)); });
            this_;
        });
        });
    });
}


prism_rtl::Turn<Array<crate::lower::model::ModDef>> WithGroups::cycle() const {
    const auto& defs = this->defs;
    auto edges = fold(defs, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& m, const crate::lower::model::ModDef& d) { return insert(m, d.name, d.complete); });
    auto defs_1 = defs;
    return call_value(fold_job(defs_1, Map<Text, Array<Text>>{}, ({
        auto edges_2 = edges;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, crate::lower::model::ModDef>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Array<Text>>, crate::lower::model::ModDef> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto edges_2_3 = edges_2;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                auto d = p1;
                call_then(start_reached_by(edges_2_3, Array(std::vector{d.name}), Array<Text>{}), [=](Array<Text> reached_by_180490) { return prism_rtl::finished(insert(m, d.name, reached_by_180490)); });
            });
        }));
        });
    }));
    })), [=](Map<Text, Array<Text>> fold_180448) {
        return ({
            auto reach = fold_180448;
            (prism_rtl::finished(each(defs_1, [&](const crate::lower::model::ModDef& d) {
            return ({
                auto mine = or_(crate::prelude::get(reach, d.name), Array<Text>{});
                ({
                crate::lower::model::ModDef this_ = d;
                this_.types_with = filter(each(defs_1, [&](const crate::lower::model::ModDef& o) { return o.name; }), [&](const Text& n) { return (n == d.name) || (crate::check::types::has_text(mine, n) && crate::check::types::has_text(or_(crate::prelude::get(reach, n), Array<Text>{}), d.name)); });
                this_;
            });
            });
        })));
        });
    });
}


/// `Start WithGroups, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::ModDef>> start_with_groups(Array<crate::lower::model::ModDef> defs) {
    return prism_rtl::make_rc<WithGroups>(defs);
}


/// ReachedBy: unbounded fn (Text ==> [Text]), [Text], [Text] -> [Text]
Array<Text> reached_by(const Map<Text, Array<Text>>& edges, const Array<Text>& todo, const Array<Text>& seen) {
    auto&& _m = index(todo, Nat(0u));
    if (prism_rtl::is_none(_m)) {
        return seen;
    }
    if (prism_rtl::is_some(_m)) {
        auto&& m = prism_rtl::some_of(_m);
        return crate::check::types::has_text(seen, m)
            ? reached_by(edges, drop(todo, Nat(1u)), seen)
            : reached_by(edges, append(drop(todo, Nat(1u)), or_(crate::prelude::get(edges, m), Array<Text>{})), crate::prelude::push(seen, m));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> ReachedBy::cycle() const {
    const auto& edges = this->edges;
    const auto& todo = this->todo;
    const auto& seen = this->seen;
    return ({
        auto&& _m = index(todo, Nat(0u));
        prism_rtl::is_none(_m) ? prism_rtl::finished(seen)
        : prism_rtl::is_some(_m) ? ({
        auto&& m = prism_rtl::some_of(_m);
        crate::check::types::has_text(seen, m)
        ? prism_rtl::more(prism_rtl::rc(ReachedBy(edges, drop(todo, Nat(1u)), seen)))
        : prism_rtl::more(prism_rtl::rc(ReachedBy(edges, append(drop(todo, Nat(1u)), or_(crate::prelude::get(edges, m), Array<Text>{})), crate::prelude::push(seen, m))));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ReachedBy, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_reached_by(Map<Text, Array<Text>> edges, Array<Text> todo, Array<Text> seen) {
    return prism_rtl::make_rc<ReachedBy>(edges, todo, seen);
}


/// NeededMods: unbounded fn G, Nat -> [Text]
Array<Text> needed_mods(const crate::check::env::G& g, const Nat& shown) {
    auto own_ = filter(keys(g.mods), [&](const Text& m) { return (or_(crate::prelude::get(g.mods, m), crate::check::env::dummy_mod())->file < shown) && (m != Text::lit("Prelude")); });
    auto grown = run_to_end(fold_job(crate::check::errors::range0(Nat(6u)), own_, ({
        auto g_1 = g;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Nat>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_2 = g_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                static_cast<void>(p1);
                fold_job(acc, acc, ({
                auto g_1_2_2 = g_1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto g_1_2_2_2 = g_1_2_2;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        auto m = p1;
                        call_then(start_mod_refs(g_1_2_2_2, m), [=](Array<Text> mod_refs_181513) { return prism_rtl::finished(crate::check::types::union_texts(a, mod_refs_181513)); });
                    });
                }));
                });
            })));
            }))->cycle();
            });
        }));
        });
    })));
    })));
    return filter(keys(g.mods), [&](const Text& m) { return (m != Text::lit("Prelude")) && crate::check::types::has_text(grown, m); });
}


prism_rtl::Turn<Array<Text>> NeededMods::cycle() const {
    const auto& g = this->g;
    const auto& shown = this->shown;
    auto own_ = filter(keys(g.mods), [&](const Text& m) { return (or_(crate::prelude::get(g.mods, m), crate::check::env::dummy_mod())->file < shown) && (m != Text::lit("Prelude")); });
    auto g_1 = g;
    return call_value(fold_job(crate::check::errors::range0(Nat(6u)), own_, ({
        auto g_1_2 = g_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Nat>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_2_2 = g_1_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                static_cast<void>(p1);
                fold_job(acc, acc, ({
                auto g_1_2_2_2 = g_1_2_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto g_1_2_2_2_2 = g_1_2_2_2;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        auto m = p1;
                        call_then(start_mod_refs(g_1_2_2_2_2, m), [=](Array<Text> mod_refs_181513) { return prism_rtl::finished(crate::check::types::union_texts(a, mod_refs_181513)); });
                    });
                }));
                });
            })));
            }))->cycle();
            });
        }));
        });
    })));
    })), [=](Array<Text> fold_181438) {
        return ({
            auto grown = fold_181438;
            (prism_rtl::finished(filter(keys(g_1.mods), [&](const Text& m) { return (m != Text::lit("Prelude")) && crate::check::types::has_text(grown, m); })));
        });
    });
}


/// `Start NeededMods, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_needed_mods(crate::check::env::G g, Nat shown) {
    return prism_rtl::make_rc<NeededMods>(g, shown);
}


/// ModRefs: unbounded fn G, Text -> [Text]
Array<Text> mod_refs(const crate::check::env::G& g, const Text& m) {
    auto&& _m = crate::prelude::get(g.mods, m);
    if (prism_rtl::is_some(_m)) {
        auto&& info = prism_rtl::some_of(_m);
        auto used = each(info.uses, [&](const std::tuple<Text, bool>& _p0) {
            auto&& u = std::get<0>(_p0);
            return u;
        });
        auto fams = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = info.tree.emit_row;
            if (prism_rtl::is_some(_m)) {
                auto&& rw = prism_rtl::some_of(_m);
                _v.set(fold(rw.terms, Array<Text>{}, [&](const Array<Text>& acc, const crate::syntax::RowTerm& t) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Text>> _v;
                        if (prism_rtl::is<crate::syntax::RowTerm::RFamily>(t)) {
                            auto&& q = prism_rtl::as<crate::syntax::RowTerm::RFamily>(t).a0;
                            _v.set(crate::prelude::push(acc, or_(crate::prelude::get(g.fam_owner, crate::check::env::dotted(q->path_)), crate::check::env::dotted(q->path_))));
                            goto _done;
                        }
                        {
                            _v.set(acc);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return filter(append(used, fams), [&](const Text& x) { return crate::check::env::has_key(g.mods, x); });
    }
    if (prism_rtl::is_none(_m)) {
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> ModRefs::cycle() const {
    const auto& g = this->g;
    const auto& m = this->m;
    return ({
        auto&& _m = crate::prelude::get(g.mods, m);
        prism_rtl::is_some(_m) ? ({
        auto&& info = prism_rtl::some_of(_m);
        ({
        auto used = each(info.uses, [&](const std::tuple<Text, bool>& _p0) {
            auto&& u = std::get<0>(_p0);
            return u;
        });
        auto fams = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = info.tree.emit_row;
            if (prism_rtl::is_some(_m)) {
                auto&& rw = prism_rtl::some_of(_m);
                _v.set(fold(rw.terms, Array<Text>{}, [&](const Array<Text>& acc, const crate::syntax::RowTerm& t) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Text>> _v;
                        if (prism_rtl::is<crate::syntax::RowTerm::RFamily>(t)) {
                            auto&& q = prism_rtl::as<crate::syntax::RowTerm::RFamily>(t).a0;
                            _v.set(crate::prelude::push(acc, or_(crate::prelude::get(g.fam_owner, crate::check::env::dotted(q->path_)), crate::check::env::dotted(q->path_))));
                            goto _done;
                        }
                        {
                            _v.set(acc);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        (prism_rtl::finished(filter(append(used, fams), [&](const Text& x) { return crate::check::env::has_key(g.mods, x); })));
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ModRefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_mod_refs(crate::check::env::G g, Text m) {
    return prism_rtl::make_rc<ModRefs>(g, m);
}


/// RootWidgets: fn Lx -> [((Text, Bool))]
Array<std::tuple<Text, bool>> root_widgets(const Lx& lx) {
    auto tested = fold(lx.g.defs, Array<std::tuple<Text, bool>>{}, [&](const Array<std::tuple<Text, bool>>& acc, const crate::check::env::Def& d) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, bool>>> _v;
            auto&& _m = d.body;
            if (prism_rtl::is<crate::check::env::DefBody::DbTest>(_m)) {
                auto&& t = prism_rtl::as<crate::check::env::DefBody::DbTest>(_m).a0;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<std::tuple<Text, bool>>> _v;
                    auto&& _m = blueprint_qk(in_module(lx, d->file, d.home), t.blueprint);
                    {
                        auto&& m182267_0 = _m;
                        if (m182267_0 == Text::lit("")) {
                            _v.set(acc);
                            goto _done;
                        }
                    }
                    {
                        auto&& qk = _m;
                        _v.set(crate::check::types::has_text(each(acc, [&](const std::tuple<Text, bool>& _p0) {
                            auto&& q = std::get<0>(_p0);
                            return q;
                        }), qk)
                            ? acc
                            : crate::prelude::push(acc, std::tuple{qk, true}));
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto main = fold(lx.g.defs, Array<std::tuple<Text, bool>>{}, [&](const Array<std::tuple<Text, bool>>& acc, const crate::check::env::Def& d) { return is_main(d.qk) ? crate::prelude::push(acc, std::tuple{d.qk, false}) : acc; });
    return fold(main, tested, [&](const Array<std::tuple<Text, bool>>& acc, const std::tuple<Text, bool>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& b = std::get<1>(_p1);
        return crate::check::types::has_text(each(acc, [&](const std::tuple<Text, bool>& _p0) {
            auto&& q = std::get<0>(_p0);
            return q;
        }), k)
            ? acc
            : crate::prelude::push(acc, std::tuple{k, b});
    });
}


/// IsMain: fn Text -> Bool
bool is_main(const Text& qk) {
    return ((owner_of(qk) == Text::lit("")) && (base(crate::check::types::bare_name(qk)) == Text::lit("main"))) && crate::syntax::lexer::has_prefix(crate::check::types::bare_name(qk), Text::lit("@"));
}


/// BlueprintQk: fn Lx, Expr -> Text
Text blueprint_qk(const Lx& lx, const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        return blueprint_qk(lx, c);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return blueprint_qk(lx, x);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        auto&& _q_opt = crate::check::env::resolve_value(lx.g, lx.home, n);
        auto&& q_opt = std::get<0>(_q_opt);
        return or_(q_opt, Text::lit(""));
    }
    {
        return Text::lit("");
    }
}


/// ValOf: fn Lx, Text -> ValInfo
crate::check::env::ValInfo val_of(const Lx& lx, const Text& qk) {
    auto&& _m = crate::prelude::get(lx.g.vals, qk);
    if (prism_rtl::is_some(_m)) {
        auto&& v_ = prism_rtl::some_of(_m);
        return v_;
    }
    if (prism_rtl::is_none(_m)) {
        auto d = fold(lx.g.defs, crate::check::env::dummy_def(), [&](const crate::check::env::Def& found, const crate::check::env::Def& df) { return df.qk == qk ? df : found; });
        return crate::check::env::ValInfo{.qk = qk, .scheme = crate::check::types::mono(crate::check::types::Ty(crate::check::types::Ty::TyErr{})), .sort = Text::lit("fn"), .has_sig = false, .home = d.home, .file = d->file, .span = d.span};
    }
    prism_rtl::unreachable("no arm matched");
}


/// ProgDefOf: unbounded fn Lx, Text -> ProgDef
crate::lower::model::ProgDef prog_def_of(const Lx& lx, const Text& qk) {
    auto v_ = val_of(lx, qk);
    auto ptys = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
        auto&& _m = v_.scheme.ty;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            _v.set(ps);
            goto _done;
        }
        {
            _v.set(Array<crate::check::types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto lxm = in_module_at(lx, v_->file, v_.home, Text::lit("\000main"sv));
    auto params = run_to_end(each_job(crate::check::errors::range0(len(ptys)), ({
        auto lxm_1 = lxm;
        auto ptys_2 = ptys;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::lower::model::OutTy>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto lxm_1_3 = lxm_1;
            auto ptys_2_3 = ptys_2;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                call_then(start_out_ty_of(lxm_1_3, peel(or_(index(ptys_2_3, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})))), [=](crate::lower::model::OutTy out_ty_of_183842) { return prism_rtl::finished(std::tuple{prism_rtl::cat("arg", i), out_ty_of_183842}); });
            });
        }));
        });
    }));
    })));
    auto node_ = prism_rtl::cat(rust_mod_name(v_.home), "::", camel(crate::check::types::bare_name(qk)));
    auto fams = or_(crate::prelude::get(lx.g.mods, v_.home), crate::check::env::dummy_mod()).emit_rw.fams;
    auto world = crate::check::types::has_text(fams, Text::lit("Gui"))
        ? Text::lit("canvas")
        : crate::check::types::has_text(fams, Text::lit("Ui"))
        ? Text::lit("none")
        : Text::lit("cli");
    return crate::lower::model::ProgDef{.name = prism_rtl::cat(camel(crate::check::types::bare_name(qk)), "Program"), .prism = crate::syntax::lexer::after_first(crate::check::types::bare_name(qk)), .node_ = node_, .params = params, .fallible = true, .world = world};
}


prism_rtl::Turn<crate::lower::model::ProgDef> ProgDefOf::cycle() const {
    const auto& lx = this->lx;
    const auto& qk = this->qk;
    auto v_ = val_of(lx, qk);
    auto ptys = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
        auto&& _m = v_.scheme.ty;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            _v.set(ps);
            goto _done;
        }
        {
            _v.set(Array<crate::check::types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto lxm = in_module_at(lx, v_->file, v_.home, Text::lit("\000main"sv));
    auto lx_1 = lx;
    auto qk_2 = qk;
    return call_value(each_job(crate::check::errors::range0(len(ptys)), ({
        auto lxm_3 = lxm;
        auto ptys_4 = ptys;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::lower::model::OutTy>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto lxm_3_5 = lxm_3;
            auto ptys_4_5 = ptys_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                call_then(start_out_ty_of(lxm_3_5, peel(or_(index(ptys_4_5, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})))), [=](crate::lower::model::OutTy out_ty_of_183842) { return prism_rtl::finished(std::tuple{prism_rtl::cat("arg", i), out_ty_of_183842}); });
            });
        }));
        });
    }));
    })), [=](Array<std::tuple<Text, crate::lower::model::OutTy>> each_183798) {
        return ({
            auto params = each_183798;
            auto node_ = prism_rtl::cat(rust_mod_name(v_.home), "::", camel(crate::check::types::bare_name(qk_2)));
            auto fams = or_(crate::prelude::get(lx_1.g.mods, v_.home), crate::check::env::dummy_mod()).emit_rw.fams;
            auto world = crate::check::types::has_text(fams, Text::lit("Gui"))
                ? Text::lit("canvas")
                : crate::check::types::has_text(fams, Text::lit("Ui"))
                ? Text::lit("none")
                : Text::lit("cli");
            (prism_rtl::finished(crate::lower::model::ProgDef{.name = prism_rtl::cat(camel(crate::check::types::bare_name(qk_2)), "Program"), .prism = crate::syntax::lexer::after_first(crate::check::types::bare_name(qk_2)), .node_ = node_, .params = params, .fallible = true, .world = world}));
        });
    });
}


/// `Start ProgDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::ProgDef> start_prog_def_of(Lx lx, Text qk) {
    return prism_rtl::make_rc<ProgDefOf>(lx, qk);
}


/// JobRoots: unbounded fn Lx -> [Text]
Array<Text> job_roots(const Lx& lx) {
    auto direct = run_to_end(fold_job(lx.g.defs, Array<Text>{}, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::env::Def>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto d = p1;
                ({
                auto lxd = in_module(lx_1_2, d->file, d.home);
                call_then(start_run_targets(lxd, d), [=](Array<Text> run_targets_184677) { return call_then(start_unbounded_values(lxd, d), [=](Array<Text> unbounded_values_184699) { return prism_rtl::finished(crate::check::types::union_texts(crate::check::types::union_texts(acc, run_targets_184677), unbounded_values_184699)); }); });
            });
            });
        }));
        });
    })));
    })));
    return run_to_end(fold_job(crate::check::errors::range0(Nat(8u)), direct, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Nat>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                static_cast<void>(p1);
                fold_job(acc, acc, ({
                auto lx_1_2_2 = lx_1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto lx_1_2_2_2 = lx_1_2_2;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        auto qk = p1;
                        call_then(start_tail_targets(lx_1_2_2_2, qk), [=](Array<Text> tail_targets_184806) { return prism_rtl::finished(crate::check::types::union_texts(a, tail_targets_184806)); });
                    });
                }));
                });
            })));
            }))->cycle();
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Text>> JobRoots::cycle() const {
    const auto& lx = this->lx;
    auto lx_1 = lx;
    return call_value(fold_job(lx_1.g.defs, Array<Text>{}, ({
        auto lx_1_2 = lx_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::env::Def>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2_2 = lx_1_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto d = p1;
                ({
                auto lxd = in_module(lx_1_2_2, d->file, d.home);
                call_then(start_run_targets(lxd, d), [=](Array<Text> run_targets_184677) { return call_then(start_unbounded_values(lxd, d), [=](Array<Text> unbounded_values_184699) { return prism_rtl::finished(crate::check::types::union_texts(crate::check::types::union_texts(acc, run_targets_184677), unbounded_values_184699)); }); });
            });
            });
        }));
        });
    })));
    })), [=](Array<Text> fold_184562) {
        return ({
            auto direct = fold_184562;
            fold_job(crate::check::errors::range0(Nat(8u)), direct, ({
            auto lx_1_2 = lx_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Nat>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_1_2_2 = lx_1_2;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    static_cast<void>(p1);
                    fold_job(acc, acc, ({
                    auto lx_1_2_2_2 = lx_1_2_2;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto lx_1_2_2_2_2 = lx_1_2_2_2;
                        entered(once_job([=]() {
                        return ({
                            auto a = p0;
                            auto qk = p1;
                            call_then(start_tail_targets(lx_1_2_2_2_2, qk), [=](Array<Text> tail_targets_184806) { return prism_rtl::finished(crate::check::types::union_texts(a, tail_targets_184806)); });
                        });
                    }));
                    });
                })));
                }))->cycle();
                });
            }));
            });
        })));
        }))->cycle();
        });
    });
}


/// `Start JobRoots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_job_roots(Lx lx) {
    return prism_rtl::make_rc<JobRoots>(lx);
}


/// UnboundedValues: unbounded fn Lx, Def -> [Text]
Array<Text> unbounded_values(const Lx& lx, const crate::check::env::Def& d) {
    auto es = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
        auto&& _m = d.body;
        if (prism_rtl::is<crate::check::env::DefBody::DbWidget>(_m)) {
            auto&& w = prism_rtl::as<crate::check::env::DefBody::DbWidget>(_m).a0;
            _v.set(crate::check::typed::block_exprs(w.body));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
            auto&& cs = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
            _v.set(run_to_end(fold_job(cs, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::FnClause> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto c = p1;
                        call_then(crate::check::typed::start_body_exprs(c.body), [=](Array<crate::syntax::Expr> body_exprs_185155) { return prism_rtl::finished(append(acc, body_exprs_185155)); });
                    });
                }));
            })))));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbLet>(_m)) {
            auto&& l = prism_rtl::as<crate::check::env::DefBody::DbLet>(_m).a0;
            _v.set(crate::check::typed::exprs_in(l->value));
            goto _done;
        }
        {
            _v.set(Array<crate::syntax::Expr>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto callees = fold(es, Array<Text>{}, [&](const Array<Text>& acc, const crate::syntax::Expr& e) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = e.kind;
            if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
                auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
                _v.set(crate::prelude::push(acc, place_key(lx, c.span)));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return fold(es, Array<Text>{}, [&](const Array<Text>& acc, const crate::syntax::Expr& e) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = e.kind;
            if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                _v.set(crate::check::types::has_text(callees, place_key(lx, e.span))
                    ? acc
                    : ({
                    auto&& _q_opt = crate::check::env::resolve_value(lx.g, lx.home, n);
                    auto&& q_opt = std::get<0>(_q_opt);
                    ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    if (prism_rtl::is_some(q_opt)) {
                        auto&& q = prism_rtl::some_of(q_opt);
                        _v.set(is_unbounded(lx, q) ? crate::check::types::add_text(acc, q) : acc);
                        goto _done;
                    }
                    if (prism_rtl::is_none(q_opt)) {
                        _v.set(acc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                }));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Array<Text>> UnboundedValues::cycle() const {
    const auto& lx = this->lx;
    const auto& d = this->d;
    auto es = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
        auto&& _m = d.body;
        if (prism_rtl::is<crate::check::env::DefBody::DbWidget>(_m)) {
            auto&& w = prism_rtl::as<crate::check::env::DefBody::DbWidget>(_m).a0;
            _v.set(crate::check::typed::block_exprs(w.body));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
            auto&& cs = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
            _v.set(run_to_end(fold_job(cs, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::FnClause> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto c = p1;
                        call_then(crate::check::typed::start_body_exprs(c.body), [=](Array<crate::syntax::Expr> body_exprs_185155) { return prism_rtl::finished(append(acc, body_exprs_185155)); });
                    });
                }));
            })))));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbLet>(_m)) {
            auto&& l = prism_rtl::as<crate::check::env::DefBody::DbLet>(_m).a0;
            _v.set(crate::check::typed::exprs_in(l->value));
            goto _done;
        }
        {
            _v.set(Array<crate::syntax::Expr>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto callees = fold(es, Array<Text>{}, [&](const Array<Text>& acc, const crate::syntax::Expr& e) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = e.kind;
            if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
                auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
                _v.set(crate::prelude::push(acc, place_key(lx, c.span)));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return prism_rtl::finished(fold(es, Array<Text>{}, [&](const Array<Text>& acc, const crate::syntax::Expr& e) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = e.kind;
            if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                _v.set(crate::check::types::has_text(callees, place_key(lx, e.span))
                    ? acc
                    : ({
                    auto&& _q_opt = crate::check::env::resolve_value(lx.g, lx.home, n);
                    auto&& q_opt = std::get<0>(_q_opt);
                    ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    if (prism_rtl::is_some(q_opt)) {
                        auto&& q = prism_rtl::some_of(q_opt);
                        _v.set(is_unbounded(lx, q) ? crate::check::types::add_text(acc, q) : acc);
                        goto _done;
                    }
                    if (prism_rtl::is_none(q_opt)) {
                        _v.set(acc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                }));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    }));
}


/// `Start UnboundedValues, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_unbounded_values(Lx lx, crate::check::env::Def d) {
    return prism_rtl::make_rc<UnboundedValues>(lx, d);
}


/// InPrelude: fn Lx, Text -> Bool
bool in_prelude(const Lx& lx, const Text& q) {
    auto&& _m = crate::prelude::get(lx.g.vals, q);
    if (prism_rtl::is_some(_m)) {
        auto&& v_ = prism_rtl::some_of(_m);
        return v_.home == Text::lit("Prelude");
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// IsColorPoly: fn Lx, Text -> Bool
bool is_color_poly(const Lx& lx, const Text& q) {
    auto&& _m = crate::prelude::get(lx.g.vals, q);
    if (prism_rtl::is_some(_m)) {
        auto&& v_ = prism_rtl::some_of(_m);
        auto&& _m = v_.scheme.ty;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CQ>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0)) {
            return true;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CRigid>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0)) {
            return true;
        }
        {
            return false;
        }
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// EntersAtOnce: fn Lx, Text, [Arg] -> Bool
bool enters_at_once(const Lx& lx, const Text& q, const Array<crate::syntax::Arg>& args) {
    return is_color_poly(lx, q) && (!fold(args, false, [&](const bool& seen, const crate::syntax::Arg& a) { return seen || is_unbounded_arg(lx, a); }));
}


/// IsUnboundedArg: fn Lx, Arg -> Bool
bool is_unbounded_arg(const Lx& lx, const crate::syntax::Arg& a) {
    auto&& _m = peel(type_at(lx, a->value.span));
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CUnbound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0)) {
        return true;
    }
    {
        return false;
    }
}


/// IsUnbounded: fn Lx, Text -> Bool
bool is_unbounded(const Lx& lx, const Text& q) {
    auto&& _m = crate::prelude::get(lx.g.vals, q);
    if (prism_rtl::is_some(_m)) {
        auto&& v_ = prism_rtl::some_of(_m);
        auto&& _m = v_.scheme.ty;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CBound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0)) {
            return false;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            return true;
        }
        {
            return false;
        }
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// RunTargets: unbounded fn Lx, Def -> [Text]
Array<Text> run_targets(const Lx& lx, const crate::check::env::Def& d) {
    auto es = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
        auto&& _m = d.body;
        if (prism_rtl::is<crate::check::env::DefBody::DbWidget>(_m)) {
            auto&& w = prism_rtl::as<crate::check::env::DefBody::DbWidget>(_m).a0;
            _v.set(crate::check::typed::block_exprs(w.body));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
            auto&& cs = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
            _v.set(run_to_end(fold_job(cs, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::FnClause> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto c = p1;
                        call_then(crate::check::typed::start_body_exprs(c.body), [=](Array<crate::syntax::Expr> body_exprs_187384) { return prism_rtl::finished(append(acc, body_exprs_187384)); });
                    });
                }));
            })))));
            goto _done;
        }
        {
            _v.set(Array<crate::syntax::Expr>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return fold(es, Array<Text>{}, [&](const Array<Text>& acc, const crate::syntax::Expr& e) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = e.kind;
            if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
                auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
                auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
                _v.set(blueprint_qk(lx, c) == Text::lit("Prelude.@Run")
                    ? ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    auto&& _m = index(args, Nat(0u));
                    if (prism_rtl::is_some(_m)) {
                        auto&& a = prism_rtl::some_of(_m);
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Array<Text>> _v;
                            auto&& _m = a->value.kind;
                            if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                                auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                                _v.set(({
                                    auto&& _q_opt = crate::check::env::resolve_value(lx.g, lx.home, n);
                                    auto&& q_opt = std::get<0>(_q_opt);
                                    ({
                                    __label__ _done;
                                    prism_rtl::Slot<Array<Text>> _v;
                                    if (prism_rtl::is_some(q_opt)) {
                                        auto&& q = prism_rtl::some_of(q_opt);
                                        _v.set(crate::check::types::add_text(acc, q));
                                        goto _done;
                                    }
                                    if (prism_rtl::is_none(q_opt)) {
                                        _v.set(acc);
                                        goto _done;
                                    }
                                    prism_rtl::unreachable("no arm matched");
                                _done:
                                    _v.take();
                                });
                                }));
                                goto _done;
                            }
                            {
                                _v.set(acc);
                                goto _done;
                            }
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                })
                    : acc);
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Array<Text>> RunTargets::cycle() const {
    const auto& lx = this->lx;
    const auto& d = this->d;
    auto es = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
        auto&& _m = d.body;
        if (prism_rtl::is<crate::check::env::DefBody::DbWidget>(_m)) {
            auto&& w = prism_rtl::as<crate::check::env::DefBody::DbWidget>(_m).a0;
            _v.set(crate::check::typed::block_exprs(w.body));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
            auto&& cs = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
            _v.set(run_to_end(fold_job(cs, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::FnClause> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto c = p1;
                        call_then(crate::check::typed::start_body_exprs(c.body), [=](Array<crate::syntax::Expr> body_exprs_187384) { return prism_rtl::finished(append(acc, body_exprs_187384)); });
                    });
                }));
            })))));
            goto _done;
        }
        {
            _v.set(Array<crate::syntax::Expr>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return prism_rtl::finished(fold(es, Array<Text>{}, [&](const Array<Text>& acc, const crate::syntax::Expr& e) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = e.kind;
            if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
                auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
                auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
                _v.set(blueprint_qk(lx, c) == Text::lit("Prelude.@Run")
                    ? ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    auto&& _m = index(args, Nat(0u));
                    if (prism_rtl::is_some(_m)) {
                        auto&& a = prism_rtl::some_of(_m);
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Array<Text>> _v;
                            auto&& _m = a->value.kind;
                            if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                                auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                                _v.set(({
                                    auto&& _q_opt = crate::check::env::resolve_value(lx.g, lx.home, n);
                                    auto&& q_opt = std::get<0>(_q_opt);
                                    ({
                                    __label__ _done;
                                    prism_rtl::Slot<Array<Text>> _v;
                                    if (prism_rtl::is_some(q_opt)) {
                                        auto&& q = prism_rtl::some_of(q_opt);
                                        _v.set(crate::check::types::add_text(acc, q));
                                        goto _done;
                                    }
                                    if (prism_rtl::is_none(q_opt)) {
                                        _v.set(acc);
                                        goto _done;
                                    }
                                    prism_rtl::unreachable("no arm matched");
                                _done:
                                    _v.take();
                                });
                                }));
                                goto _done;
                            }
                            {
                                _v.set(acc);
                                goto _done;
                            }
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                })
                    : acc);
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    }));
}


/// `Start RunTargets, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_run_targets(Lx lx, crate::check::env::Def d) {
    return prism_rtl::make_rc<RunTargets>(lx, d);
}


/// TailTargets: unbounded fn Lx, Text -> [Text]
Array<Text> tail_targets(const Lx& lx, const Text& qk) {
    auto v_ = or_(crate::prelude::get(lx.g.vals, qk), crate::check::env::builtin(qk, crate::check::types::mono(crate::check::types::Ty(crate::check::types::Ty::TyErr{}))));
    auto lxm = in_module(lx, v_->file, v_.home);
    return run_to_end(fold_job(clauses_of(lx.g, qk), Array<Text>{}, ({
        auto lxm_1 = lxm;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lxm_1_2 = lxm_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                call_then(start_tails_of_body(lxm_1_2, c.body), [=](Array<Text> tails_of_body_188263) { return prism_rtl::finished(crate::check::types::union_texts(acc, tails_of_body_188263)); });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Text>> TailTargets::cycle() const {
    const auto& lx = this->lx;
    const auto& qk = this->qk;
    auto v_ = or_(crate::prelude::get(lx.g.vals, qk), crate::check::env::builtin(qk, crate::check::types::mono(crate::check::types::Ty(crate::check::types::Ty::TyErr{}))));
    auto lxm = in_module(lx, v_->file, v_.home);
    return fold_job(clauses_of(lx.g, qk), Array<Text>{}, ({
        auto lxm_1 = lxm;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lxm_1_2 = lxm_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                call_then(start_tails_of_body(lxm_1_2, c.body), [=](Array<Text> tails_of_body_188263) { return prism_rtl::finished(crate::check::types::union_texts(acc, tails_of_body_188263)); });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start TailTargets, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_tail_targets(Lx lx, Text qk) {
    return prism_rtl::make_rc<TailTargets>(lx, qk);
}


/// TailsOfBody: unbounded fn Lx, FnBody -> [Text]
Array<Text> tails_of_body(const Lx& lx, const crate::syntax::FnBody& body) {
    return fold(crate::check::typed::body_exprs(body), Array<Text>{}, [&](const Array<Text>& acc, const crate::syntax::Expr& e) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = e.kind;
            if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
                auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
                _v.set(({
                    auto q = blueprint_qk(lx, c);
                    ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    auto&& _m = crate::prelude::get(lx.g.vals, q);
                    if (prism_rtl::is_some(_m)) {
                        auto&& v_ = prism_rtl::some_of(_m);
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Array<Text>> _v;
                            auto&& _m = v_.scheme.ty;
                            if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CBound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0)) {
                                _v.set(acc);
                                goto _done;
                            }
                            if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
                                _v.set(crate::check::types::add_text(acc, q));
                                goto _done;
                            }
                            {
                                _v.set(acc);
                                goto _done;
                            }
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                }));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Array<Text>> TailsOfBody::cycle() const {
    const auto& lx = this->lx;
    const auto& body = this->body;
    auto body_1 = body;
    auto lx_2 = lx;
    return call_then(crate::check::typed::start_body_exprs(body_1), [=](Array<crate::syntax::Expr> body_exprs_188368) {
        return prism_rtl::finished(fold(body_exprs_188368, Array<Text>{}, [&](const Array<Text>& acc, const crate::syntax::Expr& e) {
            return ({
                __label__ _done;
                prism_rtl::Slot<Array<Text>> _v;
                auto&& _m = e.kind;
                if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
                    auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
                    _v.set(({
                        auto q = blueprint_qk(lx_2, c);
                        ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Text>> _v;
                        auto&& _m = crate::prelude::get(lx_2.g.vals, q);
                        if (prism_rtl::is_some(_m)) {
                            auto&& v_ = prism_rtl::some_of(_m);
                            _v.set(({
                                __label__ _done;
                                prism_rtl::Slot<Array<Text>> _v;
                                auto&& _m = v_.scheme.ty;
                                if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CBound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0)) {
                                    _v.set(acc);
                                    goto _done;
                                }
                                if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
                                    _v.set(crate::check::types::add_text(acc, q));
                                    goto _done;
                                }
                                {
                                    _v.set(acc);
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(acc);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    }));
                    goto _done;
                }
                {
                    _v.set(acc);
                    goto _done;
                }
            _done:
                _v.take();
            });
        }));
    });
}


/// `Start TailsOfBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_tails_of_body(Lx lx, crate::syntax::FnBody body) {
    return prism_rtl::make_rc<TailsOfBody>(lx, body);
}


/// ModDefOf: unbounded fn Lx, Text, [((Text, Bool))], ModInfo, [Text] -> ModDef
crate::lower::model::ModDef mod_def_of(const Lx& lx0, const Text& m, const Array<std::tuple<Text, bool>>& roots, const crate::check::env::ModInfo& info, const Array<Text>& mods) {
    auto lx = in_module(lx0, info->file, m);
    auto path_ = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(lx.g.srcs, info->file);
        if (prism_rtl::is_some(_m)) {
            auto&& src = prism_rtl::some_of(_m);
            _v.set(src->path_);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto types = run_to_end(fold_job(values(lx.g.types), Array<crate::lower::model::Item>{}, ({
        auto m_1 = m;
        auto lx_2 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Item>>(std::tuple<Array<crate::lower::model::Item>, crate::check::env::TyInfo>)>>(prism_rtl::rc([=](std::tuple<Array<crate::lower::model::Item>, crate::check::env::TyInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_1_3 = m_1;
            auto lx_2_3 = lx_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto ti = p1;
                ti.home == m_1_3
                ? call_then(start_ty_defs(lx_2_3, ti), [=](Array<crate::lower::model::Item> ty_defs_189093) { return prism_rtl::finished(append(acc, ty_defs_189093)); })
                : prism_rtl::finished(acc);
            });
        }));
        });
    })));
    })));
    auto tags = run_to_end(fold_job(values(lx.g.tags), Array<crate::lower::model::Item>{}, ({
        auto m_1 = m;
        auto lx_2 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Item>>(std::tuple<Array<crate::lower::model::Item>, crate::check::env::TagInfo>)>>(prism_rtl::rc([=](std::tuple<Array<crate::lower::model::Item>, crate::check::env::TagInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_1_3 = m_1;
            auto lx_2_3 = lx_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto tg = p1;
                (tg.home == m_1_3) && (tg.kind != Text::lit("Prelude.Fault"))
                ? call_then(start_tag_def_of(lx_2_3, tg), [=](crate::lower::model::TagDef tag_def_of_189241) { return prism_rtl::finished(crate::prelude::push(acc, crate::lower::model::Item(crate::lower::model::Item::ItTag{tag_def_of_189241}))); })
                : prism_rtl::finished(acc);
            });
        }));
        });
    })));
    })));
    auto defs = run_to_end(fold_job(lx.g.defs, Array<crate::lower::model::Item>{}, ({
        auto m_1 = m;
        auto lx_2 = lx;
        auto roots_3 = roots;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Item>>(std::tuple<Array<crate::lower::model::Item>, crate::check::env::Def>)>>(prism_rtl::rc([=](std::tuple<Array<crate::lower::model::Item>, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_1_4 = m_1;
            auto lx_2_4 = lx_2;
            auto roots_3_4 = roots_3;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto d = p1;
                d.home == m_1_4
                ? call_then(start_def_items(in_module(lx_2_4, d->file, m_1_4), d, roots_3_4), [=](Array<crate::lower::model::Item> def_items_189345) { return prism_rtl::finished(append(acc, def_items_189345)); })
                : prism_rtl::finished(acc);
            });
        }));
        });
    })));
    })));
    auto traits = run_to_end(fold_job(values(lx.g.traits), Array<crate::lower::model::Item>{}, ({
        auto m_1 = m;
        auto lx_2 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Item>>(std::tuple<Array<crate::lower::model::Item>, crate::check::env::TraitInfo>)>>(prism_rtl::rc([=](std::tuple<Array<crate::lower::model::Item>, crate::check::env::TraitInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_1_3 = m_1;
            auto lx_2_3 = lx_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto tr = p1;
                tr.home == m_1_3
                ? call_then(start_trait_def_of(lx_2_3, tr), [=](crate::lower::model::TraitDef trait_def_of_189498) { return prism_rtl::finished(crate::prelude::push(acc, crate::lower::model::Item(crate::lower::model::Item::ItTrait{trait_def_of_189498}))); })
                : prism_rtl::finished(acc);
            });
        }));
        });
    })));
    })));
    auto impls = run_to_end(fold_job(values(lx.g.impls), Array<crate::lower::model::Item>{}, ({
        auto m_1 = m;
        auto lx_2 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Item>>(std::tuple<Array<crate::lower::model::Item>, Array<crate::check::env::ImplInfo>>)>>(prism_rtl::rc([=](std::tuple<Array<crate::lower::model::Item>, Array<crate::check::env::ImplInfo>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_1_3 = m_1;
            auto lx_2_3 = lx_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto ims = p1;
                fold_job(ims, acc, ({
                auto m_1_3_3 = m_1_3;
                auto lx_2_3_3 = lx_2_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Item>>(std::tuple<Array<crate::lower::model::Item>, crate::check::env::ImplInfo>)>>(prism_rtl::rc([=](std::tuple<Array<crate::lower::model::Item>, crate::check::env::ImplInfo> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto m_1_3_3_3 = m_1_3_3;
                    auto lx_2_3_3_3 = lx_2_3_3;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        auto im = p1;
                        (im.home == m_1_3_3_3) && (!im.derived)
                        ? call_then(start_impl_def_of(in_module(lx_2_3_3_3, im->file, m_1_3_3_3), im), [=](crate::lower::model::ImplDef impl_def_of_189665) { return prism_rtl::finished(crate::prelude::push(a, crate::lower::model::Item(crate::lower::model::Item::ItImpl{impl_def_of_189665}))); })
                        : prism_rtl::finished(a);
                    });
                }));
                });
            })));
            }))->cycle();
            });
        }));
        });
    })));
    })));
    auto uses = filter(each(mods, [&](const Text& o) { return rust_mod_name(o); }), [&](const Text& o) { return o != rust_mod_name(m); });
    return crate::lower::model::ModDef{.name = rust_mod_name(m), .prism = m, .path_ = path_, .uses = uses, .complete = Array<Text>{}, .declared = Array<Text>{}, .types_with = Array<Text>{}, .items = append(append(append(append(types, tags), traits), impls), defs)};
}


prism_rtl::Turn<crate::lower::model::ModDef> ModDefOf::cycle() const {
    const auto& lx0 = this->lx0;
    const auto& m = this->m;
    const auto& roots = this->roots;
    const auto& info = this->info;
    const auto& mods = this->mods;
    auto lx = in_module(lx0, info->file, m);
    auto path_ = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(lx.g.srcs, info->file);
        if (prism_rtl::is_some(_m)) {
            auto&& src = prism_rtl::some_of(_m);
            _v.set(src->path_);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto m_1 = m;
    auto mods_2 = mods;
    auto roots_3 = roots;
    return call_value(fold_job(values(lx.g.types), Array<crate::lower::model::Item>{}, ({
        auto m_1_4 = m_1;
        auto lx_4 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Item>>(std::tuple<Array<crate::lower::model::Item>, crate::check::env::TyInfo>)>>(prism_rtl::rc([=](std::tuple<Array<crate::lower::model::Item>, crate::check::env::TyInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_1_4_5 = m_1_4;
            auto lx_4_5 = lx_4;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto ti = p1;
                ti.home == m_1_4_5
                ? call_then(start_ty_defs(lx_4_5, ti), [=](Array<crate::lower::model::Item> ty_defs_189093) { return prism_rtl::finished(append(acc, ty_defs_189093)); })
                : prism_rtl::finished(acc);
            });
        }));
        });
    })));
    })), [=](Array<crate::lower::model::Item> fold_189020) {
        return ({
            auto types = fold_189020;
            call_value(fold_job(values(lx.g.tags), Array<crate::lower::model::Item>{}, ({
            auto m_1_4 = m_1;
            auto lx_4 = lx;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Item>>(std::tuple<Array<crate::lower::model::Item>, crate::check::env::TagInfo>)>>(prism_rtl::rc([=](std::tuple<Array<crate::lower::model::Item>, crate::check::env::TagInfo> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto m_1_4_5 = m_1_4;
                auto lx_4_5 = lx_4;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto tg = p1;
                    (tg.home == m_1_4_5) && (tg.kind != Text::lit("Prelude.Fault"))
                    ? call_then(start_tag_def_of(lx_4_5, tg), [=](crate::lower::model::TagDef tag_def_of_189241) { return prism_rtl::finished(crate::prelude::push(acc, crate::lower::model::Item(crate::lower::model::Item::ItTag{tag_def_of_189241}))); })
                    : prism_rtl::finished(acc);
                });
            }));
            });
        })));
        })), [=](Array<crate::lower::model::Item> fold_189133) {
            return ({
                auto tags = fold_189133;
                call_value(fold_job(lx.g.defs, Array<crate::lower::model::Item>{}, ({
                auto m_1_4 = m_1;
                auto lx_4 = lx;
                auto roots_3_5 = roots_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Item>>(std::tuple<Array<crate::lower::model::Item>, crate::check::env::Def>)>>(prism_rtl::rc([=](std::tuple<Array<crate::lower::model::Item>, crate::check::env::Def> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto m_1_4_5 = m_1_4;
                    auto lx_4_5 = lx_4;
                    auto roots_3_5_5 = roots_3_5;
                    entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto d = p1;
                        d.home == m_1_4_5
                        ? call_then(start_def_items(in_module(lx_4_5, d->file, m_1_4_5), d, roots_3_5_5), [=](Array<crate::lower::model::Item> def_items_189345) { return prism_rtl::finished(append(acc, def_items_189345)); })
                        : prism_rtl::finished(acc);
                    });
                }));
                });
            })));
            })), [=](Array<crate::lower::model::Item> fold_189284) {
                return ({
                    auto defs = fold_189284;
                    call_value(fold_job(values(lx.g.traits), Array<crate::lower::model::Item>{}, ({
                    auto m_1_4 = m_1;
                    auto lx_4 = lx;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Item>>(std::tuple<Array<crate::lower::model::Item>, crate::check::env::TraitInfo>)>>(prism_rtl::rc([=](std::tuple<Array<crate::lower::model::Item>, crate::check::env::TraitInfo> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto m_1_4_5 = m_1_4;
                        auto lx_4_5 = lx_4;
                        entered(once_job([=]() {
                        return ({
                            auto acc = p0;
                            auto tr = p1;
                            tr.home == m_1_4_5
                            ? call_then(start_trait_def_of(lx_4_5, tr), [=](crate::lower::model::TraitDef trait_def_of_189498) { return prism_rtl::finished(crate::prelude::push(acc, crate::lower::model::Item(crate::lower::model::Item::ItTrait{trait_def_of_189498}))); })
                            : prism_rtl::finished(acc);
                        });
                    }));
                    });
                })));
                })), [=](Array<crate::lower::model::Item> fold_189417) {
                    return ({
                        auto traits = fold_189417;
                        call_value(fold_job(values(lx.g.impls), Array<crate::lower::model::Item>{}, ({
                        auto m_1_4 = m_1;
                        auto lx_4 = lx;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Item>>(std::tuple<Array<crate::lower::model::Item>, Array<crate::check::env::ImplInfo>>)>>(prism_rtl::rc([=](std::tuple<Array<crate::lower::model::Item>, Array<crate::check::env::ImplInfo>> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto m_1_4_5 = m_1_4;
                            auto lx_4_5 = lx_4;
                            entered(once_job([=]() {
                            return ({
                                auto acc = p0;
                                auto ims = p1;
                                fold_job(ims, acc, ({
                                auto m_1_4_5_5 = m_1_4_5;
                                auto lx_4_5_5 = lx_4_5;
                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Item>>(std::tuple<Array<crate::lower::model::Item>, crate::check::env::ImplInfo>)>>(prism_rtl::rc([=](std::tuple<Array<crate::lower::model::Item>, crate::check::env::ImplInfo> _p0) {
                                auto&& p0 = std::get<0>(_p0);
                                auto&& p1 = std::get<1>(_p0);
                                return ({
                                    auto m_1_4_5_5_5 = m_1_4_5_5;
                                    auto lx_4_5_5_5 = lx_4_5_5;
                                    entered(once_job([=]() {
                                    return ({
                                        auto a = p0;
                                        auto im = p1;
                                        (im.home == m_1_4_5_5_5) && (!im.derived)
                                        ? call_then(start_impl_def_of(in_module(lx_4_5_5_5, im->file, m_1_4_5_5_5), im), [=](crate::lower::model::ImplDef impl_def_of_189665) { return prism_rtl::finished(crate::prelude::push(a, crate::lower::model::Item(crate::lower::model::Item::ItImpl{impl_def_of_189665}))); })
                                        : prism_rtl::finished(a);
                                    });
                                }));
                                });
                            })));
                            }))->cycle();
                            });
                        }));
                        });
                    })));
                    })), [=](Array<crate::lower::model::Item> fold_189544) {
                        return ({
                            auto impls = fold_189544;
                            auto uses = filter(each(mods_2, [&](const Text& o) { return rust_mod_name(o); }), [&](const Text& o) { return o != rust_mod_name(m_1); });
                            (prism_rtl::finished(crate::lower::model::ModDef{.name = rust_mod_name(m_1), .prism = m_1, .path_ = path_, .uses = uses, .complete = Array<Text>{}, .declared = Array<Text>{}, .types_with = Array<Text>{}, .items = append(append(append(append(types, tags), traits), impls), defs)}));
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start ModDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::ModDef> start_mod_def_of(Lx lx0, Text m, Array<std::tuple<Text, bool>> roots, crate::check::env::ModInfo info, Array<Text> mods) {
    return prism_rtl::make_rc<ModDefOf>(lx0, m, roots, info, mods);
}


/// DefItems: unbounded fn Lx, Def, [((Text, Bool))] -> [Item]
Array<crate::lower::model::Item> def_items(const Lx& lx, const crate::check::env::Def& d, const Array<std::tuple<Text, bool>>& roots) {
    auto is_root = crate::check::types::has_text(each(roots, [&](const std::tuple<Text, bool>& _p0) {
        auto&& q = std::get<0>(_p0);
        return q;
    }), d.qk);
    auto&& _m = d.body;
    if (prism_rtl::is<crate::check::env::DefBody::DbWidget>(_m)) {
        auto&& w = prism_rtl::as<crate::check::env::DefBody::DbWidget>(_m).a0;
        return is_root
            ? node_items(crate::lower::node_::node_def_of(lx, d.qk, Array<crate::syntax::Pattern_>{}, w.body, or_(crate::prelude::get(lx.g.vals, d.qk), crate::check::env::builtin(d.qk, crate::check::types::mono(crate::check::types::Ty(crate::check::types::Ty::TyErr{})))).scheme, true))
            : Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItNote{prism_rtl::cat("`", d.name, "` is inlined where it is applied.")})});
    }
    if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
        auto&& clauses = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
        auto&& _m = crate::prelude::get(lx.g.vals, d.qk);
        if (prism_rtl::is_none(_m)) {
            return Array<crate::lower::model::Item>{};
        }
        if (prism_rtl::is_some(_m)) {
            auto&& v_ = prism_rtl::some_of(_m);
            auto&& _m = v_.scheme.ty;
            if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
                auto&& m190583_0_2 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
                if (prism_rtl::is<crate::check::types::Ty::TyAt>(m190583_0_2)) {
                    return !is_root
                        ? Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItNote{prism_rtl::cat("`", d.name, "` is inlined where it is applied.")})})
                        : ({
                        __label__ _done;
                        prism_rtl::Slot<Array<crate::lower::model::Item>> _v;
                        {
                            auto&& m190779_0 = clauses;
                            if (m190779_0.size() == 1u) {
                                {
                                    auto&& _c1 = index(m190779_0, Nat(0u));
                                    if (prism_rtl::is_some(_c1)) {
                                        auto&& c = prism_rtl::some_of(_c1);
                                        _v.set(({
                                            __label__ _done;
                                            prism_rtl::Slot<Array<crate::lower::model::Item>> _v;
                                            auto&& _m = c.body;
                                            if (prism_rtl::is<crate::syntax::FnBody::BodyBlock>(_m)) {
                                                auto&& b = prism_rtl::as<crate::syntax::FnBody::BodyBlock>(_m).a0;
                                                _v.set(node_items(crate::lower::node_::node_def_of(lx, d.qk, c.params, b, v_.scheme, true)));
                                                goto _done;
                                            }
                                            {
                                                _v.set(Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItRefused{prism_rtl::cat("`", d.name, "`, a root widget whose body is one expression")})}));
                                                goto _done;
                                            }
                                        _done:
                                            _v.take();
                                        }));
                                        goto _done;
                                    }
                                }
                            }
                        }
                        {
                            _v.set(Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItRefused{prism_rtl::cat("`", d.name, "`, a root widget of several clauses")})}));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                }
            }
            {
                auto f = crate::lower::model::Item(crate::lower::model::Item::ItFn{fn_def_of(lx, d.qk, clauses, v_.scheme)});
                return crate::check::types::has_text(lx.unbs, d.qk)
                    ? Array(std::vector{f, crate::lower::model::Item(crate::lower::model::Item::ItJob{job_def_of(lx, d.qk, clauses, v_.scheme)})})
                    : Array(std::vector{f});
            }
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::check::env::DefBody::DbLet>(_m)) {
        auto&& l = prism_rtl::as<crate::check::env::DefBody::DbLet>(_m).a0;
        return Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItFn{let_getter(lx, d.qk, l)})});
    }
    {
        return Array<crate::lower::model::Item>{};
    }
}


prism_rtl::Turn<Array<crate::lower::model::Item>> DefItems::cycle() const {
    const auto& lx = this->lx;
    const auto& d = this->d;
    const auto& roots = this->roots;
    auto is_root = crate::check::types::has_text(each(roots, [&](const std::tuple<Text, bool>& _p0) {
        auto&& q = std::get<0>(_p0);
        return q;
    }), d.qk);
    return ({
        auto&& _m = d.body;
        prism_rtl::is<crate::check::env::DefBody::DbWidget>(_m) ? ({
        auto&& w = prism_rtl::as<crate::check::env::DefBody::DbWidget>(_m).a0;
        is_root
        ? ({
        auto d_1 = d;
        auto lx_2 = lx;
        auto w_3 = w;
        call_then(crate::lower::node_::start_node_def_of(lx_2, d_1.qk, Array<crate::syntax::Pattern_>{}, w_3.body, or_(crate::prelude::get(lx_2.g.vals, d_1.qk), crate::check::env::builtin(d_1.qk, crate::check::types::mono(crate::check::types::Ty(crate::check::types::Ty::TyErr{})))).scheme, true), [=](crate::lower::model::NodeDef node_def_of_190326) { return prism_rtl::finished(node_items(node_def_of_190326)); });
    })
        : prism_rtl::finished(Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItNote{prism_rtl::cat("`", d.name, "` is inlined where it is applied.")})}));
    })
        : prism_rtl::is<crate::check::env::DefBody::DbFn>(_m) ? ({
        auto&& clauses = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
        ({
        auto&& _m = crate::prelude::get(lx.g.vals, d.qk);
        prism_rtl::is_none(_m) ? prism_rtl::finished(Array<crate::lower::model::Item>{})
        : prism_rtl::is_some(_m) ? ({
        auto&& v_ = prism_rtl::some_of(_m);
        ({
        auto&& _m = v_.scheme.ty;
        prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && ({
        auto&& m190583_0_2 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
        prism_rtl::is<crate::check::types::Ty::TyAt>(m190583_0_2);
    }) ? ({
        auto&& m190583_0_2 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
        !is_root
        ? prism_rtl::finished(Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItNote{prism_rtl::cat("`", d.name, "` is inlined where it is applied.")})}))
        : ({
        ({
        auto&& m190779_0 = clauses;
        (m190779_0.size() == 1u) && ({
        auto&& _c1 = index(m190779_0, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m190779_0 = clauses;
        auto&& _c1 = index(m190779_0, Nat(0u));
        auto&& c = prism_rtl::some_of(_c1);
        ({
        auto&& _m = c.body;
        prism_rtl::is<crate::syntax::FnBody::BodyBlock>(_m) ? ({
        auto&& b = prism_rtl::as<crate::syntax::FnBody::BodyBlock>(_m).a0;
        ({
        auto b_1 = b;
        auto d_2 = d;
        auto lx_3 = lx;
        call_then(crate::lower::node_::start_node_def_of(lx_3, d_2.qk, c.params, b_1, v_.scheme, true), [=](crate::lower::model::NodeDef node_def_of_190891) { return prism_rtl::finished(node_items(node_def_of_190891)); });
    });
    })
        : prism_rtl::finished(Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItRefused{prism_rtl::cat("`", d.name, "`, a root widget whose body is one expression")})}));
    });
    })
        : prism_rtl::finished(Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItRefused{prism_rtl::cat("`", d.name, "`, a root widget of several clauses")})}));
    });
    })
        : ({
        auto clauses_1 = clauses;
        auto d_2 = d;
        auto lx_3 = lx;
        call_then(start_fn_def_of(lx_3, d_2.qk, clauses_1, v_.scheme), [=](crate::lower::model::FnDef fn_def_of_191207) {
        return ({
            auto f = crate::lower::model::Item(crate::lower::model::Item::ItFn{fn_def_of_191207});
            (crate::check::types::has_text(lx_3.unbs, d_2.qk)
            ? call_then(start_job_def_of(lx_3, d_2.qk, clauses_1, v_.scheme), [=](crate::lower::model::JobDef job_def_of_191302) { return prism_rtl::finished(Array(std::vector{f, crate::lower::model::Item(crate::lower::model::Item::ItJob{job_def_of_191302})})); })
            : prism_rtl::finished(Array(std::vector{f})));
        });
    });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is<crate::check::env::DefBody::DbLet>(_m) ? ({
        auto&& l = prism_rtl::as<crate::check::env::DefBody::DbLet>(_m).a0;
        ({
        auto d_1 = d;
        auto l_2 = l;
        auto lx_3 = lx;
        call_then(start_let_getter(lx_3, d_1.qk, l_2), [=](crate::lower::model::FnDef let_getter_191379) { return prism_rtl::finished(Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItFn{let_getter_191379})})); });
    });
    })
        : prism_rtl::finished(Array<crate::lower::model::Item>{});
    });
}


/// `Start DefItems, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::Item>> start_def_items(Lx lx, crate::check::env::Def d, Array<std::tuple<Text, bool>> roots) {
    return prism_rtl::make_rc<DefItems>(lx, d, roots);
}


/// NodeItems: fn NodeDef -> [Item]
Array<crate::lower::model::Item> node_items(const crate::lower::model::NodeDef& n) {
    return append(Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItNode{n})}), each(n.children, [&](const crate::lower::model::NodeDef& c) { return crate::lower::model::Item(crate::lower::model::Item::ItNode{c}); }));
}


/// TyDefs: unbounded fn Lx, TyInfo -> [Item]
Array<crate::lower::model::Item> ty_defs(const Lx& lx, const crate::check::env::TyInfo& ti) {
    auto derives = each(ti.derives, [&](const Text& dn) { return crate::check::types::bare_name(dn); });
    auto params = each(ti.params, [&](const Text& p_) { return camel(p_); });
    auto floaty_ = floaty(lx.g, crate::check::types::Ty(crate::check::types::Ty::TyCon{ti.name, Array<crate::check::types::Ty>{}}), Array<Text>{});
    auto bare = crate::check::types::bare_name(ti.name);
    auto mk_fn = ({
        auto bare_1 = bare;
        auto params_2 = params;
        auto derives_3 = derives;
        auto floaty__4 = floaty_;
        auto lx_5 = lx;
        auto ti_6 = ti;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::TyDef>(std::tuple<crate::lower::model::TyShape, Array<crate::lower::model::CaseDef>>)>>(prism_rtl::rc([=](std::tuple<crate::lower::model::TyShape, Array<crate::lower::model::CaseDef>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto bare_1_7 = bare_1;
            auto params_2_7 = params_2;
            auto derives_3_7 = derives_3;
            auto floaty__4_7 = floaty__4;
            auto lx_5_7 = lx_5;
            auto ti_6_7 = ti_6;
            entered(once_job([=]() {
            return ({
                auto shape = p0;
                auto cases = p1;
                call_then(start_ty_podable(lx_5_7, crate::check::types::Ty(crate::check::types::Ty::TyCon{ti_6_7.name, Array<crate::check::types::Ty>{}}), Array<Text>{}), [=](bool ty_podable_192169) {
                return prism_rtl::finished(crate::lower::model::TyDef{.name = camel(bare_1_7), .prism = bare_1_7, .params = params_2_7, .shape = shape, .cases_ = cases, .eq = crate::check::types::has_text(derives_3_7, Text::lit("Eq")), .ord = crate::check::types::has_text(derives_3_7, Text::lit("Ord")), .floaty = floaty__4_7, .show_ = has_own_show(lx_5_7, ti_6_7.name)
                    ? crate::lower::model::Shown(crate::lower::model::Shown::ShownOwn{})
                    : crate::check::types::has_text(derives_3_7, Text::lit("Show"))
                    ? crate::lower::model::Shown(crate::lower::model::Shown::ShownDerived{})
                    : crate::lower::model::Shown(crate::lower::model::Shown::NotShown{}), .pod = ty_podable_192169 && run_to_end(fold_job(cases, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::CaseDef>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::CaseDef> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return entered(once_job([=]() {
                        return ({
                            auto ok = p0;
                            auto c = p1;
                            (prism_rtl::finished(ok && run_to_end(fold_job(c.fields, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, crate::lower::model::OutTy>> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return entered(once_job([=]() {
                                return ({
                                    auto ok2 = p0;
                                    auto&& _ft = p1;
                                    auto&& ft = std::get<1>(_ft);
                                    (prism_rtl::finished(ok2 && podable(ft)));
                                });
                            }));
                        }))))));
                        });
                    }));
                })))), .doc = type_doc(lx_5_7, ti_6_7)});
            });
            });
        }));
        });
    })));
    });
    auto&& _m = ti.body;
    if (prism_rtl::is<crate::check::env::TyBody::BRecord>(_m)) {
        auto&& fs = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
        auto fields = run_to_end(each_job(crate::check::errors::range0(len(fs)), ({
            auto fs_1 = fs;
            auto lx_2 = lx;
            auto ti_3 = ti;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::lower::model::OutTy>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto fs_1_4 = fs_1;
                auto lx_2_4 = lx_2;
                auto ti_3_4 = ti_3;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    ({
                    auto [fname, ft] = or_(index(fs_1_4, i), std::tuple{Text::lit(""), crate::check::types::Ty(crate::check::types::Ty::TyErr{})});
                    call_then(start_out_ty_of(lx_2_4, ft), [=](crate::lower::model::OutTy out_ty_of_192515) {
                    return ({
                        auto rt = out_ty_of_192515;
                        (prism_rtl::finished(std::tuple{snake(fname), rc_field(lx_2_4, ti_3_4.name, i)
                        ? crate::lower::model::OutTy(crate::lower::model::OutTy::OutRc{prism_rtl::rc(rt)})
                        : rt}));
                    });
                });
                });
                });
            }));
            });
        }));
        })));
        return Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItType{run_to_end(mk_fn(std::tuple{crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeRecord{}), Array(std::vector{crate::lower::model::CaseDef{.name = camel(bare), .prism = bare, .fields = fields}})}))})});
    }
    if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
        auto&& cases = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
        auto defs = run_to_end(each_job(cases, ({
            auto ti_1 = ti;
            auto lx_2 = lx;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::CaseDef>(std::tuple<Text, Array<crate::check::types::Ty>>)>>(prism_rtl::rc([=](std::tuple<Text, Array<crate::check::types::Ty>> p0) {
            return ({
                auto ti_1_3 = ti_1;
                auto lx_2_3 = lx_2;
                entered(once_job([=]() {
                return ({
                    auto [cn, ats] = p0;
                    ({
                    auto ck = crate::check::env::qual_key(ti_1_3.home, cn);
                    call_value(each_job(crate::check::errors::range0(len(ats)), ({
                    auto lx_2_3_3 = lx_2_3;
                    auto ck_3 = ck;
                    auto ats_4 = ats;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::lower::model::OutTy>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                    return ({
                        auto lx_2_3_3_5 = lx_2_3_3;
                        auto ck_3_5 = ck_3;
                        auto ats_4_5 = ats_4;
                        entered(once_job([=]() {
                        return ({
                            auto i = p0;
                            call_then(start_case_field(lx_2_3_3_5, ck_3_5, i, or_(index(ats_4_5, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::lower::model::OutTy case_field_192923) { return prism_rtl::finished(std::tuple{Text::lit(""), case_field_192923}); });
                        });
                    }));
                    });
                }));
                })), [=](Array<std::tuple<Text, crate::lower::model::OutTy>> each_192886) { return prism_rtl::finished(crate::lower::model::CaseDef{.name = camel(cn), .prism = cn, .fields = each_192886}); });
                });
                });
            }));
            });
        })));
        })));
        auto shape = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::TyShape> _v;
            {
                auto&& m192992_0 = cases;
                if (m192992_0.size() == 1u) {
                    {
                        auto&& _c2 = index(m192992_0, Nat(0u));
                        if (prism_rtl::is_some(_c2)) {
                            auto&& cn = std::get<0>(prism_rtl::some_of(_c2));
                            auto&& m192992_0_0_1 = std::get<1>(prism_rtl::some_of(_c2));
                            if (m192992_0_0_1.size() == 0u) {
                                _v.set(crate::check::env::is_lower_text(cn)
                                    ? crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeUnit{})
                                    : crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeChoice{}));
                                goto _done;
                            }
                        }
                    }
                }
            }
            {
                auto&& m192992_1 = cases;
                if (m192992_1.size() == 1u) {
                    {
                        auto&& _c1 = index(m192992_1, Nat(0u));
                        if (prism_rtl::is_some(_c1)) {
                            auto&& cn = std::get<0>(prism_rtl::some_of(_c1));
                            _v.set(cn == bare
                                ? crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeNewtype{})
                                : crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeChoice{}));
                            goto _done;
                        }
                    }
                }
            }
            {
                _v.set(crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeChoice{}));
                goto _done;
            }
        _done:
            _v.take();
        });
        return Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItType{run_to_end(mk_fn(std::tuple{shape, defs}))})});
    }
    if (prism_rtl::is<crate::check::env::TyBody::BRowKind>(_m)) {
        return ti.name == Text::lit("Prelude.Fault")
            ? Array<crate::lower::model::Item>{}
            : Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItRow{row_def_of(lx, ti)})});
    }
    {
        return Array<crate::lower::model::Item>{};
    }
}


prism_rtl::Turn<Array<crate::lower::model::Item>> TyDefs::cycle() const {
    const auto& lx = this->lx;
    const auto& ti = this->ti;
    auto derives = each(ti.derives, [&](const Text& dn) { return crate::check::types::bare_name(dn); });
    auto params = each(ti.params, [&](const Text& p_) { return camel(p_); });
    auto lx_1 = lx;
    auto ti_2 = ti;
    return call_then(start_floaty(lx_1.g, crate::check::types::Ty(crate::check::types::Ty::TyCon{ti_2.name, Array<crate::check::types::Ty>{}}), Array<Text>{}), [=](bool floaty_191804) {
        return ({
            auto floaty_ = floaty_191804;
            auto bare = crate::check::types::bare_name(ti_2.name);
            auto mk_fn = ({
                auto bare_3 = bare;
                auto params_4 = params;
                auto derives_5 = derives;
                auto floaty__6 = floaty_;
                auto lx_1_7 = lx_1;
                auto ti_2_7 = ti_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::TyDef>(std::tuple<crate::lower::model::TyShape, Array<crate::lower::model::CaseDef>>)>>(prism_rtl::rc([=](std::tuple<crate::lower::model::TyShape, Array<crate::lower::model::CaseDef>> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto bare_3_7 = bare_3;
                    auto params_4_7 = params_4;
                    auto derives_5_7 = derives_5;
                    auto floaty__6_7 = floaty__6;
                    auto lx_1_7_7 = lx_1_7;
                    auto ti_2_7_7 = ti_2_7;
                    entered(once_job([=]() {
                    return ({
                        auto shape = p0;
                        auto cases = p1;
                        call_then(start_ty_podable(lx_1_7_7, crate::check::types::Ty(crate::check::types::Ty::TyCon{ti_2_7_7.name, Array<crate::check::types::Ty>{}}), Array<Text>{}), [=](bool ty_podable_192169) {
                        return prism_rtl::finished(crate::lower::model::TyDef{.name = camel(bare_3_7), .prism = bare_3_7, .params = params_4_7, .shape = shape, .cases_ = cases, .eq = crate::check::types::has_text(derives_5_7, Text::lit("Eq")), .ord = crate::check::types::has_text(derives_5_7, Text::lit("Ord")), .floaty = floaty__6_7, .show_ = has_own_show(lx_1_7_7, ti_2_7_7.name)
                            ? crate::lower::model::Shown(crate::lower::model::Shown::ShownOwn{})
                            : crate::check::types::has_text(derives_5_7, Text::lit("Show"))
                            ? crate::lower::model::Shown(crate::lower::model::Shown::ShownDerived{})
                            : crate::lower::model::Shown(crate::lower::model::Shown::NotShown{}), .pod = ty_podable_192169 && run_to_end(fold_job(cases, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::CaseDef>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::CaseDef> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return entered(once_job([=]() {
                                return ({
                                    auto ok = p0;
                                    auto c = p1;
                                    (prism_rtl::finished(ok && run_to_end(fold_job(c.fields, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, crate::lower::model::OutTy>> _p0) {
                                    auto&& p0 = std::get<0>(_p0);
                                    auto&& p1 = std::get<1>(_p0);
                                    return entered(once_job([=]() {
                                        return ({
                                            auto ok2 = p0;
                                            auto&& _ft = p1;
                                            auto&& ft = std::get<1>(_ft);
                                            (prism_rtl::finished(ok2 && podable(ft)));
                                        });
                                    }));
                                }))))));
                                });
                            }));
                        })))), .doc = type_doc(lx_1_7_7, ti_2_7_7)});
                    });
                    });
                }));
                });
            })));
            });
            ({
            auto&& _m = ti_2.body;
            prism_rtl::is<crate::check::env::TyBody::BRecord>(_m) ? ({
            auto&& fs = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
            ({
            auto fs_3 = fs;
            call_value(each_job(crate::check::errors::range0(len(fs_3)), ({
            auto fs_3_4 = fs_3;
            auto lx_1_4 = lx_1;
            auto ti_2_4 = ti_2;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::lower::model::OutTy>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto fs_3_4_4 = fs_3_4;
                auto lx_1_4_4 = lx_1_4;
                auto ti_2_4_4 = ti_2_4;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    ({
                    auto [fname, ft] = or_(index(fs_3_4_4, i), std::tuple{Text::lit(""), crate::check::types::Ty(crate::check::types::Ty::TyErr{})});
                    call_then(start_out_ty_of(lx_1_4_4, ft), [=](crate::lower::model::OutTy out_ty_of_192515) {
                    return ({
                        auto rt = out_ty_of_192515;
                        (prism_rtl::finished(std::tuple{snake(fname), rc_field(lx_1_4_4, ti_2_4_4.name, i)
                        ? crate::lower::model::OutTy(crate::lower::model::OutTy::OutRc{prism_rtl::rc(rt)})
                        : rt}));
                    });
                });
                });
                });
            }));
            });
        }));
        })), [=](Array<std::tuple<Text, crate::lower::model::OutTy>> each_192401) {
            return ({
                auto fields = each_192401;
                call_value(mk_fn(std::tuple{crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeRecord{}), Array(std::vector{crate::lower::model::CaseDef{.name = camel(bare), .prism = bare, .fields = fields}})}), [=](crate::lower::model::TyDef mk_192632) { return prism_rtl::finished(Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItType{mk_192632})})); });
            });
        });
        });
        })
            : prism_rtl::is<crate::check::env::TyBody::BChoice>(_m) ? ({
            auto&& cases = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
            ({
            auto cases_3 = cases;
            call_value(each_job(cases_3, ({
            auto ti_2_4 = ti_2;
            auto lx_1_4 = lx_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::CaseDef>(std::tuple<Text, Array<crate::check::types::Ty>>)>>(prism_rtl::rc([=](std::tuple<Text, Array<crate::check::types::Ty>> p0) {
            return ({
                auto ti_2_4_4 = ti_2_4;
                auto lx_1_4_4 = lx_1_4;
                entered(once_job([=]() {
                return ({
                    auto [cn, ats] = p0;
                    ({
                    auto ck = crate::check::env::qual_key(ti_2_4_4.home, cn);
                    call_value(each_job(crate::check::errors::range0(len(ats)), ({
                    auto lx_1_4_4_4 = lx_1_4_4;
                    auto ck_4 = ck;
                    auto ats_5 = ats;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::lower::model::OutTy>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                    return ({
                        auto lx_1_4_4_4_6 = lx_1_4_4_4;
                        auto ck_4_6 = ck_4;
                        auto ats_5_6 = ats_5;
                        entered(once_job([=]() {
                        return ({
                            auto i = p0;
                            call_then(start_case_field(lx_1_4_4_4_6, ck_4_6, i, or_(index(ats_5_6, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::lower::model::OutTy case_field_192923) { return prism_rtl::finished(std::tuple{Text::lit(""), case_field_192923}); });
                        });
                    }));
                    });
                }));
                })), [=](Array<std::tuple<Text, crate::lower::model::OutTy>> each_192886) { return prism_rtl::finished(crate::lower::model::CaseDef{.name = camel(cn), .prism = cn, .fields = each_192886}); });
                });
                });
            }));
            });
        })));
        })), [=](Array<crate::lower::model::CaseDef> each_192755) {
            return ({
                auto defs = each_192755;
                auto shape = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::lower::model::TyShape> _v;
                    {
                        auto&& m192992_0 = cases;
                        if (m192992_0.size() == 1u) {
                            {
                                auto&& _c2 = index(m192992_0, Nat(0u));
                                if (prism_rtl::is_some(_c2)) {
                                    auto&& cn = std::get<0>(prism_rtl::some_of(_c2));
                                    auto&& m192992_0_0_1 = std::get<1>(prism_rtl::some_of(_c2));
                                    if (m192992_0_0_1.size() == 0u) {
                                        _v.set(crate::check::env::is_lower_text(cn)
                                            ? crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeUnit{})
                                            : crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeChoice{}));
                                        goto _done;
                                    }
                                }
                            }
                        }
                    }
                    {
                        auto&& m192992_1 = cases;
                        if (m192992_1.size() == 1u) {
                            {
                                auto&& _c1 = index(m192992_1, Nat(0u));
                                if (prism_rtl::is_some(_c1)) {
                                    auto&& cn = std::get<0>(prism_rtl::some_of(_c1));
                                    _v.set(cn == bare
                                        ? crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeNewtype{})
                                        : crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeChoice{}));
                                    goto _done;
                                }
                            }
                        }
                    }
                    {
                        _v.set(crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeChoice{}));
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                call_value(mk_fn(std::tuple{shape, defs}), [=](crate::lower::model::TyDef mk_193229) { return prism_rtl::finished(Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItType{mk_193229})})); });
            });
        });
        });
        })
            : prism_rtl::is<crate::check::env::TyBody::BRowKind>(_m) ? ti_2.name == Text::lit("Prelude.Fault")
            ? prism_rtl::finished(Array<crate::lower::model::Item>{})
            : call_then(start_row_def_of(lx_1, ti_2), [=](crate::lower::model::RowDef row_def_of_193316) { return prism_rtl::finished(Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItRow{row_def_of_193316})})); })
            : prism_rtl::finished(Array<crate::lower::model::Item>{});
        });
        });
    });
}


/// `Start TyDefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::Item>> start_ty_defs(Lx lx, crate::check::env::TyInfo ti) {
    return prism_rtl::make_rc<TyDefs>(lx, ti);
}


/// TyPodable: unbounded fn Lx, Ty, [Text] -> Bool
bool ty_podable(const Lx& lx, const crate::check::types::Ty& t, const Array<Text>& seen) {
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t)) {
        return false;
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t)) {
        return false;
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& m193637_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        if (m193637_2_0 == Text::lit("!")) {
            return false;
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& m193637_3_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        if (m193637_3_0 == Text::lit("$")) {
            return false;
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        return ty_podable(lx, i, seen);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        return run_to_end(fold_job(ts, true, ({
            auto lx_1 = lx;
            auto seen_2 = seen;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_1_3 = lx_1;
                auto seen_2_3 = seen_2;
                entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto x = p1;
                    (prism_rtl::finished(ok && ty_podable(lx_1_3, x, seen_2_3)));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        return ty_podable(lx, e, seen);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        return ty_podable(lx, k, seen) && ty_podable(lx, v_, seen);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        return crate::check::types::has_text(seen, n)
            ? true
            : ({
            auto more = crate::prelude::push(seen, n);
            auto args_ok = run_to_end(fold_job(args, true, ({
                auto lx_1 = lx;
                auto more_2 = more;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto lx_1_3 = lx_1;
                    auto more_2_3 = more_2;
                    entered(once_job([=]() {
                    return ({
                        auto ok = p0;
                        auto x = p1;
                        (prism_rtl::finished(ok && ty_podable(lx_1_3, x, more_2_3)));
                    });
                }));
                });
            })));
            })));
            args_ok && ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = crate::prelude::get(lx.g.types, n);
            if (prism_rtl::is_some(_m)) {
                auto&& ti = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = ti.body;
                    if (prism_rtl::is<crate::check::env::TyBody::BRecord>(_m)) {
                        auto&& fs = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
                        _v.set(run_to_end(fold_job(fs, true, ({
                            auto lx_1 = lx;
                            auto more_2 = more;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, crate::check::types::Ty>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, crate::check::types::Ty>> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto lx_1_3 = lx_1;
                                auto more_2_3 = more_2;
                                entered(once_job([=]() {
                                return ({
                                    auto ok = p0;
                                    auto&& _ft = p1;
                                    auto&& ft = std::get<1>(_ft);
                                    (prism_rtl::finished(ok && ty_podable(lx_1_3, ft, more_2_3)));
                                });
                            }));
                            });
                        })));
                        }))));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
                        auto&& cs = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
                        _v.set(run_to_end(fold_job(cs, true, ({
                            auto lx_1 = lx;
                            auto more_2 = more;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Array<crate::check::types::Ty>>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Array<crate::check::types::Ty>>> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto lx_1_3 = lx_1;
                                auto more_2_3 = more_2;
                                entered(once_job([=]() {
                                return ({
                                    auto ok = p0;
                                    auto&& _ats = p1;
                                    auto&& ats = std::get<1>(_ats);
                                    (prism_rtl::finished(ok && run_to_end(fold_job(ats, true, ({
                                    auto lx_1_3_3 = lx_1_3;
                                    auto more_2_3_3 = more_2_3;
                                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
                                    auto&& p0 = std::get<0>(_p0);
                                    auto&& p1 = std::get<1>(_p0);
                                    return ({
                                        auto lx_1_3_3_3 = lx_1_3_3;
                                        auto more_2_3_3_3 = more_2_3_3;
                                        entered(once_job([=]() {
                                        return ({
                                            auto ok2 = p0;
                                            auto x = p1;
                                            (prism_rtl::finished(ok2 && ty_podable(lx_1_3_3_3, x, more_2_3_3_3)));
                                        });
                                    }));
                                    });
                                })));
                                })))));
                                });
                            }));
                            });
                        })));
                        }))));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::env::TyBody::BAlias>(_m)) {
                        auto&& a = prism_rtl::as<crate::check::env::TyBody::BAlias>(_m).a0;
                        _v.set(ty_podable(lx, a, more));
                        goto _done;
                    }
                    {
                        _v.set(true);
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(true);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        });
    }
    {
        return true;
    }
}


prism_rtl::Turn<bool> TyPodable::cycle() const {
    const auto& lx = this->lx;
    const auto& t = this->t;
    const auto& seen = this->seen;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyFn>(t) ? prism_rtl::finished(false)
        : prism_rtl::is<crate::check::types::Ty::TyAt>(t) ? prism_rtl::finished(false)
        : prism_rtl::is<crate::check::types::Ty::TySig>(t) && ({
        auto&& m193637_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        (m193637_2_0 == Text::lit("!"));
    }) ? ({
        auto&& m193637_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        prism_rtl::finished(false);
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t) && ({
        auto&& m193637_3_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        (m193637_3_0 == Text::lit("$"));
    }) ? ({
        auto&& m193637_3_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        prism_rtl::finished(false);
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t) ? ({
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        prism_rtl::more(prism_rtl::rc(TyPodable(lx, i, seen)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        fold_job(ts, true, ({
        auto lx_1 = lx;
        auto seen_2 = seen;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_3 = lx_1;
            auto seen_2_3 = seen_2;
            entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto x = p1;
                (prism_rtl::finished(ok && ty_podable(lx_1_3, x, seen_2_3)));
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        prism_rtl::more(prism_rtl::rc(TyPodable(lx, e, seen)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        ({
        auto k_1 = k;
        auto lx_2 = lx;
        auto seen_3 = seen;
        auto v__4 = v_;
        call_then(start_ty_podable(lx_2, k_1, seen_3), [=](bool ty_podable_193940) { return prism_rtl::finished(ty_podable_193940 && ty_podable(lx_2, v__4, seen_3)); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        crate::check::types::has_text(seen, n)
        ? prism_rtl::finished(true)
        : ({
        auto more = crate::prelude::push(seen, n);
        auto args_1 = args;
        auto lx_2 = lx;
        auto n_3 = n;
        call_value(fold_job(args_1, true, ({
        auto lx_2_4 = lx_2;
        auto more_4 = more;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_2_4_5 = lx_2_4;
            auto more_4_5 = more_4;
            entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto x = p1;
                (prism_rtl::finished(ok && ty_podable(lx_2_4_5, x, more_4_5)));
            });
        }));
        });
    })));
    })), [=](bool fold_194116) {
        return ({
            auto args_ok = fold_194116;
            (prism_rtl::finished(args_ok && ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = crate::prelude::get(lx_2.g.types, n_3);
            if (prism_rtl::is_some(_m)) {
                auto&& ti = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = ti.body;
                    if (prism_rtl::is<crate::check::env::TyBody::BRecord>(_m)) {
                        auto&& fs = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
                        _v.set(run_to_end(fold_job(fs, true, ({
                            auto lx_2_4 = lx_2;
                            auto more_4 = more;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, crate::check::types::Ty>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, crate::check::types::Ty>> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto lx_2_4_5 = lx_2_4;
                                auto more_4_5 = more_4;
                                entered(once_job([=]() {
                                return ({
                                    auto ok = p0;
                                    auto&& _ft = p1;
                                    auto&& ft = std::get<1>(_ft);
                                    (prism_rtl::finished(ok && ty_podable(lx_2_4_5, ft, more_4_5)));
                                });
                            }));
                            });
                        })));
                        }))));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
                        auto&& cs = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
                        _v.set(run_to_end(fold_job(cs, true, ({
                            auto lx_2_4 = lx_2;
                            auto more_4 = more;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Array<crate::check::types::Ty>>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Array<crate::check::types::Ty>>> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto lx_2_4_5 = lx_2_4;
                                auto more_4_5 = more_4;
                                entered(once_job([=]() {
                                return ({
                                    auto ok = p0;
                                    auto&& _ats = p1;
                                    auto&& ats = std::get<1>(_ats);
                                    (prism_rtl::finished(ok && run_to_end(fold_job(ats, true, ({
                                    auto lx_2_4_5_5 = lx_2_4_5;
                                    auto more_4_5_5 = more_4_5;
                                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
                                    auto&& p0 = std::get<0>(_p0);
                                    auto&& p1 = std::get<1>(_p0);
                                    return ({
                                        auto lx_2_4_5_5_5 = lx_2_4_5_5;
                                        auto more_4_5_5_5 = more_4_5_5;
                                        entered(once_job([=]() {
                                        return ({
                                            auto ok2 = p0;
                                            auto x = p1;
                                            (prism_rtl::finished(ok2 && ty_podable(lx_2_4_5_5_5, x, more_4_5_5_5)));
                                        });
                                    }));
                                    });
                                })));
                                })))));
                                });
                            }));
                            });
                        })));
                        }))));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::env::TyBody::BAlias>(_m)) {
                        auto&& a = prism_rtl::as<crate::check::env::TyBody::BAlias>(_m).a0;
                        _v.set(ty_podable(lx_2, a, more));
                        goto _done;
                    }
                    {
                        _v.set(true);
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(true);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        })));
        });
    });
    });
    })
        : prism_rtl::finished(true);
    });
}


/// `Start TyPodable, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_ty_podable(Lx lx, crate::check::types::Ty t, Array<Text> seen) {
    return prism_rtl::make_rc<TyPodable>(lx, t, seen);
}


/// TyHasEq: unbounded fn Lx, Ty, [Text] -> Bool
bool ty_has_eq(const Lx& lx, const crate::check::types::Ty& t, const Array<Text>& seen) {
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t)) {
        return false;
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t)) {
        return false;
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& m195070_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        if (m195070_2_0 == Text::lit("!")) {
            return false;
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& m195070_3_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        if (m195070_3_0 == Text::lit("$")) {
            return false;
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        return ty_has_eq(lx, i, seen);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        return run_to_end(fold_job(ts, true, ({
            auto lx_1 = lx;
            auto seen_2 = seen;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_1_3 = lx_1;
                auto seen_2_3 = seen_2;
                entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto x = p1;
                    (prism_rtl::finished(ok && ty_has_eq(lx_1_3, x, seen_2_3)));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        return ty_has_eq(lx, e, seen);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        return ty_has_eq(lx, k, seen) && ty_has_eq(lx, v_, seen);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t)) {
        return true;
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(t)) {
        return true;
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        return crate::check::types::has_text(seen, n)
            ? true
            : ({
            auto args_ok = run_to_end(fold_job(args, true, ({
                auto lx_1 = lx;
                auto seen_2 = seen;
                auto n_3 = n;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto lx_1_4 = lx_1;
                    auto seen_2_4 = seen_2;
                    auto n_3_4 = n_3;
                    entered(once_job([=]() {
                    return ({
                        auto ok = p0;
                        auto x = p1;
                        (prism_rtl::finished(ok && ty_has_eq(lx_1_4, x, crate::prelude::push(seen_2_4, n_3_4))));
                    });
                }));
                });
            })));
            })));
            args_ok && ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = crate::prelude::get(lx.g.types, n);
            if (prism_rtl::is_some(_m)) {
                auto&& ti = prism_rtl::some_of(_m);
                _v.set(fold(ti.derives, false, [&](const bool& f, const Text& d) { return f || (crate::check::types::bare_name(d) == Text::lit("Eq")); }) || has_own_eq(lx, n));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(true);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        });
    }
    {
        return false;
    }
}


/// HasOwnEq: fn Lx, Text -> Bool
bool has_own_eq(const Lx& lx, const Text& tn) {
    return fold(or_(crate::prelude::get(lx.g.impls, Text::lit("Prelude.Eq")), Array<crate::check::env::ImplInfo>{}), false, [&](const bool& f, const crate::check::env::ImplInfo& im) { return f || (head_name(im.head) == tn); });
}


/// CaseField: unbounded fn Lx, Text, Nat, Ty -> OutTy
crate::lower::model::OutTy case_field(const Lx& lx, const Text& ck, const Nat& i, const crate::check::types::Ty& t) {
    auto rt = out_ty_of(lx, t);
    return rc_field(lx, ck, i)
        ? crate::lower::model::OutTy(crate::lower::model::OutTy::OutRc{prism_rtl::rc(rt)})
        : rt;
}


prism_rtl::Turn<crate::lower::model::OutTy> CaseField::cycle() const {
    const auto& lx = this->lx;
    const auto& ck = this->ck;
    const auto& i = this->i;
    const auto& t = this->t;
    auto ck_1 = ck;
    auto i_2 = i;
    auto lx_3 = lx;
    auto t_4 = t;
    return call_then(start_out_ty_of(lx_3, t_4), [=](crate::lower::model::OutTy out_ty_of_196048) {
        return ({
            auto rt = out_ty_of_196048;
            rc_field(lx_3, ck_1, i_2)
            ? prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutRc{prism_rtl::rc(rt)}))
            : prism_rtl::finished(rt);
        });
    });
}


/// `Start CaseField, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::OutTy> start_case_field(Lx lx, Text ck, Nat i, crate::check::types::Ty t) {
    return prism_rtl::make_rc<CaseField>(lx, ck, i, t);
}


/// TypeDoc: fn Lx, TyInfo -> Text
Text type_doc(const Lx& lx, const crate::check::env::TyInfo& ti) {
    auto&& _m = index(lx.g.srcs, ti->file);
    if (prism_rtl::is_some(_m)) {
        auto&& src = prism_rtl::some_of(_m);
        return crate::syntax::lexer::trim(crate::check::errors::line_text(src, crate::check::errors::cline_of(src.starts, ti.span.start)));
    }
    if (prism_rtl::is_none(_m)) {
        return ti.name;
    }
    prism_rtl::unreachable("no arm matched");
}


/// TagDefOf: unbounded fn Lx, TagInfo -> TagDef
crate::lower::model::TagDef tag_def_of(const Lx& lx, const crate::check::env::TagInfo& tg) {
    auto fields = run_to_end(each_job(level_fields(tg), ({
        auto lx_1 = lx;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text, crate::lower::model::OutTy>>(std::tuple<Text, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Text, crate::check::types::Ty> p0) {
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto [fname, ft] = p0;
                call_then(start_out_ty_of(lx_1_2, peel(ft)), [=](crate::lower::model::OutTy out_ty_of_196558) { return prism_rtl::finished(std::tuple{fname, snake(fname), out_ty_of_196558}); });
            });
        }));
        });
    }));
    })));
    return crate::lower::model::TagDef{.name = tag_struct(tg.name), .tag_name = tg.name, .fields = fields, .doc = type_doc(lx, crate::check::env::TyInfo{.name = tg.name, .home = tg.home, .params = Array<Text>{}, .body = crate::check::env::TyBody(crate::check::env::TyBody::BOpaque{}), .derives = Array<Text>{}, .file = tg->file, .span = tg.span}), .pod = run_to_end(fold_job(fields, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto&& _t = p1;
                auto&& t = std::get<2>(_t);
                (prism_rtl::finished(ok && podable(t)));
            });
        }));
    }))))};
}


prism_rtl::Turn<crate::lower::model::TagDef> TagDefOf::cycle() const {
    const auto& lx = this->lx;
    const auto& tg = this->tg;
    auto lx_1 = lx;
    auto tg_2 = tg;
    return call_value(each_job(level_fields(tg_2), ({
        auto lx_1_3 = lx_1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text, crate::lower::model::OutTy>>(std::tuple<Text, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Text, crate::check::types::Ty> p0) {
        return ({
            auto lx_1_3_3 = lx_1_3;
            entered(once_job([=]() {
            return ({
                auto [fname, ft] = p0;
                call_then(start_out_ty_of(lx_1_3_3, peel(ft)), [=](crate::lower::model::OutTy out_ty_of_196558) { return prism_rtl::finished(std::tuple{fname, snake(fname), out_ty_of_196558}); });
            });
        }));
        });
    }));
    })), [=](Array<std::tuple<Text, Text, crate::lower::model::OutTy>> each_196493) {
        return ({
            auto fields = each_196493;
            call_value(fold_job(fields, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto&& _t = p1;
                    auto&& t = std::get<2>(_t);
                    (prism_rtl::finished(ok && podable(t)));
                });
            }));
        }))), [=](bool fold_196782) { return prism_rtl::finished(crate::lower::model::TagDef{.name = tag_struct(tg_2.name), .tag_name = tg_2.name, .fields = fields, .doc = type_doc(lx_1, crate::check::env::TyInfo{.name = tg_2.name, .home = tg_2.home, .params = Array<Text>{}, .body = crate::check::env::TyBody(crate::check::env::TyBody::BOpaque{}), .derives = Array<Text>{}, .file = tg_2->file, .span = tg_2.span}), .pod = fold_196782}); });
        });
    });
}


/// `Start TagDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::TagDef> start_tag_def_of(Lx lx, crate::check::env::TagInfo tg) {
    return prism_rtl::make_rc<TagDefOf>(lx, tg);
}


/// LevelFields: fn TagInfo -> [((Text, Ty))]
Array<std::tuple<Text, crate::check::types::Ty>> level_fields(const crate::check::env::TagInfo& tg) {
    return filter(tg.fields, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
        auto&& ft = std::get<1>(_p0);
        return layer_of(ft) != Layer(Layer::LyEv{});
    });
}


/// KindTags: fn Lx, Text, [Text] -> [TagInfo]
Array<crate::check::env::TagInfo> kind_tags(const Lx& lx, const Text& kind, const Array<Text>& mods) {
    return filter(values(lx.g.tags), [&](const crate::check::env::TagInfo& tg) { return (tg.kind == kind) && crate::check::types::has_text(mods, tg.home); });
}


/// RowDefOf: unbounded fn Lx, TyInfo -> RowDef
crate::lower::model::RowDef row_def_of(const Lx& lx, const crate::check::env::TyInfo& ti) {
    auto tags = kind_tags(lx, ti.name, keys(lx.rs_mods));
    auto cases = each(tags, [&](const crate::check::env::TagInfo& tg) { return std::tuple{tag_struct(tg.name), path_in(lx, tg.home, tag_struct(tg.name))}; });
    auto pod = run_to_end(fold_job(tags, true, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::env::TagInfo>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::env::TagInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto tg = p1;
                (prism_rtl::finished(ok && tag_def_of(lx_1_2, tg).pod));
            });
        }));
        });
    })));
    })));
    return crate::lower::model::RowDef{.name = camel(crate::check::types::bare_name(ti.name)), .prism = ti.name, .cases_ = cases, .pod = pod, .doc = type_doc(lx, ti)};
}


prism_rtl::Turn<crate::lower::model::RowDef> RowDefOf::cycle() const {
    const auto& lx = this->lx;
    const auto& ti = this->ti;
    auto tags = kind_tags(lx, ti.name, keys(lx.rs_mods));
    auto cases = each(tags, [&](const crate::check::env::TagInfo& tg) { return std::tuple{tag_struct(tg.name), path_in(lx, tg.home, tag_struct(tg.name))}; });
    auto lx_1 = lx;
    auto ti_2 = ti;
    return call_value(fold_job(tags, true, ({
        auto lx_1_3 = lx_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::env::TagInfo>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::env::TagInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_3_3 = lx_1_3;
            entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto tg = p1;
                (prism_rtl::finished(ok && tag_def_of(lx_1_3_3, tg).pod));
            });
        }));
        });
    })));
    })), [=](bool fold_197496) {
        return ({
            auto pod = fold_197496;
            (prism_rtl::finished(crate::lower::model::RowDef{.name = camel(crate::check::types::bare_name(ti_2.name)), .prism = ti_2.name, .cases_ = cases, .pod = pod, .doc = type_doc(lx_1, ti_2)}));
        });
    });
}


/// `Start RowDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::RowDef> start_row_def_of(Lx lx, crate::check::env::TyInfo ti) {
    return prism_rtl::make_rc<RowDefOf>(lx, ti);
}


/// ElemRow: unbounded fn Lx, [Text] -> RowDef
crate::lower::model::RowDef elem_row(const Lx& lx, const Array<Text>& mods) {
    auto tags = kind_tags(lx, Text::lit("Element"), crate::prelude::push(mods, Text::lit("Prelude")));
    auto cases = each(tags, [&](const crate::check::env::TagInfo& tg) { return std::tuple{tag_struct(tg.name), prism_rtl::cat(rust_mod_name(tg.home), "::", tag_struct(tg.name))}; });
    auto pod = run_to_end(fold_job(tags, true, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::env::TagInfo>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::env::TagInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto tg = p1;
                (prism_rtl::finished(ok && tag_def_of(lx_1_2, tg).pod));
            });
        }));
        });
    })));
    })));
    return crate::lower::model::RowDef{.name = Text::lit("Elem"), .prism = Text::lit("Elem"), .cases_ = cases, .pod = pod, .doc = Text::lit("`Elem r`: an element as a document holds it, its `Level` in a tick.")};
}


prism_rtl::Turn<crate::lower::model::RowDef> ElemRow::cycle() const {
    const auto& lx = this->lx;
    const auto& mods = this->mods;
    auto tags = kind_tags(lx, Text::lit("Element"), crate::prelude::push(mods, Text::lit("Prelude")));
    auto cases = each(tags, [&](const crate::check::env::TagInfo& tg) { return std::tuple{tag_struct(tg.name), prism_rtl::cat(rust_mod_name(tg.home), "::", tag_struct(tg.name))}; });
    auto lx_1 = lx;
    return call_value(fold_job(tags, true, ({
        auto lx_1_2 = lx_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::env::TagInfo>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::env::TagInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2_2 = lx_1_2;
            entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto tg = p1;
                (prism_rtl::finished(ok && tag_def_of(lx_1_2_2, tg).pod));
            });
        }));
        });
    })));
    })), [=](bool fold_198098) {
        return ({
            auto pod = fold_198098;
            (prism_rtl::finished(crate::lower::model::RowDef{.name = Text::lit("Elem"), .prism = Text::lit("Elem"), .cases_ = cases, .pod = pod, .doc = Text::lit("`Elem r`: an element as a document holds it, its `Level` in a tick.")}));
        });
    });
}


/// `Start ElemRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::RowDef> start_elem_row(Lx lx, Array<Text> mods) {
    return prism_rtl::make_rc<ElemRow>(lx, mods);
}


/// AnswerEnum: unbounded fn Lx, [Text] -> AnswerDef
crate::lower::model::AnswerDef answer_enum(const Lx& lx, const Array<Text>& mods) {
    auto tags = kind_tags(lx, Text::lit("Element"), crate::prelude::push(mods, Text::lit("Prelude")));
    return crate::lower::model::AnswerDef{.cases_ = run_to_end(each_job(tags, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::AnswerCase>(crate::check::env::TagInfo)>>(prism_rtl::rc([=](crate::check::env::TagInfo p0) {
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto tg = p0;
                call_then(start_answer_ty(lx_1_2, tg), [=](crate::lower::model::OutTy answer_ty_198689) { return prism_rtl::finished(crate::lower::model::AnswerCase{.variant = tag_struct(tg.name), .accessor = crate::lower::node_::answer_accessor(tg), .struct_path = prism_rtl::cat(rust_mod_name(tg.home), "::", tag_struct(tg.name)), .tag_name = tg.name, .ty = answer_ty_198689}); });
            });
        }));
        });
    })));
    })))};
}


prism_rtl::Turn<crate::lower::model::AnswerDef> AnswerEnum::cycle() const {
    const auto& lx = this->lx;
    const auto& mods = this->mods;
    auto tags = kind_tags(lx, Text::lit("Element"), crate::prelude::push(mods, Text::lit("Prelude")));
    auto lx_1 = lx;
    return call_value(each_job(tags, ({
        auto lx_1_2 = lx_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::AnswerCase>(crate::check::env::TagInfo)>>(prism_rtl::rc([=](crate::check::env::TagInfo p0) {
        return ({
            auto lx_1_2_2 = lx_1_2;
            entered(once_job([=]() {
            return ({
                auto tg = p0;
                call_then(start_answer_ty(lx_1_2_2, tg), [=](crate::lower::model::OutTy answer_ty_198689) { return prism_rtl::finished(crate::lower::model::AnswerCase{.variant = tag_struct(tg.name), .accessor = crate::lower::node_::answer_accessor(tg), .struct_path = prism_rtl::cat(rust_mod_name(tg.home), "::", tag_struct(tg.name)), .tag_name = tg.name, .ty = answer_ty_198689}); });
            });
        }));
        });
    })));
    })), [=](Array<crate::lower::model::AnswerCase> each_198524) { return prism_rtl::finished(crate::lower::model::AnswerDef{.cases_ = each_198524}); });
}


/// `Start AnswerEnum, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::AnswerDef> start_answer_enum(Lx lx, Array<Text> mods) {
    return prism_rtl::make_rc<AnswerEnum>(lx, mods);
}


/// AnswerTy: unbounded fn Lx, TagInfo -> OutTy
crate::lower::model::OutTy answer_ty(const Lx& lx, const crate::check::env::TagInfo& tg) {
    auto out = peel(tg->out);
    auto part = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::Ty> _v;
        if (prism_rtl::is<crate::check::types::Ty::TyTuple>(out)) {
            auto&& cs = prism_rtl::as<crate::check::types::Ty::TyTuple>(out).a0;
            _v.set(fold(cs, out, [&](const crate::check::types::Ty& found, const crate::check::types::Ty& c) { return layer_of(c) == Layer(Layer::LyEv{}) ? peel(c) : found; }));
            goto _done;
        }
        {
            _v.set(out);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto&& _m = out_ty_of(lx, part);
    if (prism_rtl::is<crate::lower::model::OutTy::OutGen>(_m)) {
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutPod{});
    }
    {
        auto&& t = _m;
        return t;
    }
}


prism_rtl::Turn<crate::lower::model::OutTy> AnswerTy::cycle() const {
    const auto& lx = this->lx;
    const auto& tg = this->tg;
    auto out = peel(tg->out);
    auto part = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::Ty> _v;
        if (prism_rtl::is<crate::check::types::Ty::TyTuple>(out)) {
            auto&& cs = prism_rtl::as<crate::check::types::Ty::TyTuple>(out).a0;
            _v.set(fold(cs, out, [&](const crate::check::types::Ty& found, const crate::check::types::Ty& c) { return layer_of(c) == Layer(Layer::LyEv{}) ? peel(c) : found; }));
            goto _done;
        }
        {
            _v.set(out);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto lx_1 = lx;
    return call_then(start_out_ty_of(lx_1, part), [=](crate::lower::model::OutTy out_ty_of_199216) {
        return ({
            prism_rtl::is<crate::lower::model::OutTy::OutGen>(out_ty_of_199216) ? prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutPod{}))
            : ({
            auto&& t = out_ty_of_199216;
            prism_rtl::finished(t);
        });
        });
    });
}


/// `Start AnswerTy, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::OutTy> start_answer_ty(Lx lx, crate::check::env::TagInfo tg) {
    return prism_rtl::make_rc<AnswerTy>(lx, tg);
}


/// TagPaths: fn Lx, TagInfo -> ((Text, Text))
std::tuple<Text, Text> tag_paths(const Lx& lx, const crate::check::env::TagInfo& tg) {
    auto st = tag_struct(tg.name);
    auto struct_path = path_in(lx, tg.home, st);
    return std::tuple{prism_rtl::cat(kind_path(lx, tg.kind), "::", st), struct_path};
}


/// VariantOf: fn Lx, TagInfo -> Text
Text variant_of(const Lx& lx, const crate::check::env::TagInfo& tg) {
    return prism_rtl::cat(kind_path(lx, tg.kind), "::", tag_struct(tg.name));
}


/// KindPath: fn Lx, Text -> Text
Text kind_path(const Lx& lx, const Text& kind) {
    return kind == Text::lit("Element")
        ? Text::lit("crate::Elem")
        : path_in(lx, or_(crate::prelude::get(lx.g.types, kind), crate::check::env::dummy_ty_info()).home, camel(crate::check::types::bare_name(kind)));
}


/// CheckDefOf: unbounded fn Lx, CheckDecl -> CheckDef
crate::lower::model::CheckDef check_def_of(const Lx& lx, const crate::syntax::CheckDecl& c) {
    return crate::lower::model::CheckDef{.name = c.name.name, .lines = run_to_end(each_job(c.lines, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::CheckLine)>>(prism_rtl::rc([=](crate::syntax::CheckLine p0) {
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto l = p0;
                call_then(start_value_of(lx_1_2, empty_env(), l.expr), [=](Vl value_of_200064) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Ok"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(own(value_of_200064)), Text::lit("to_pod"), Array<crate::lower::model::Ex>{}})})})); });
            });
        }));
        });
    })));
    })))};
}


prism_rtl::Turn<crate::lower::model::CheckDef> CheckDefOf::cycle() const {
    const auto& lx = this->lx;
    const auto& c = this->c;
    auto c_1 = c;
    auto lx_2 = lx;
    return call_value(each_job(c_1.lines, ({
        auto lx_2_3 = lx_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::CheckLine)>>(prism_rtl::rc([=](crate::syntax::CheckLine p0) {
        return ({
            auto lx_2_3_3 = lx_2_3;
            entered(once_job([=]() {
            return ({
                auto l = p0;
                call_then(start_value_of(lx_2_3_3, empty_env(), l.expr), [=](Vl value_of_200064) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Ok"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(own(value_of_200064)), Text::lit("to_pod"), Array<crate::lower::model::Ex>{}})})})); });
            });
        }));
        });
    })));
    })), [=](Array<crate::lower::model::Ex> each_200016) { return prism_rtl::finished(crate::lower::model::CheckDef{.name = c_1.name.name, .lines = each_200016}); });
}


/// `Start CheckDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::CheckDef> start_check_def_of(Lx lx, crate::syntax::CheckDecl c) {
    return prism_rtl::make_rc<CheckDefOf>(lx, c);
}

}  // namespace crate::lower
