// The module `Lower`, from `target/bootstrap/cpp-src/prismc/lower/mod.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <lower/module.hpp>
#include <lower/node_/module.hpp>
#include <syntax/module.hpp>
#include <check/env/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/passes/module.hpp>
#include <check/shrink/module.hpp>
#include <check/typed/module.hpp>
#include <check/types/module.hpp>
#include <lower/model/module.hpp>
#include <syntax/lexer/module.hpp>
#include <lower/node_/generic.hpp>
#include <check/env/generic.hpp>
#include <syntax/lexer/generic.hpp>

namespace crate::lower {

/// `Start PlaceOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_place_of(Lx lx, Env env, crate::syntax::Expr e) {
    return prism_rtl::make_rc<PlaceOf>(lx, env, e);
}


/// Assign: unbounded fn Lx, Env, Expr, Ex -> Do
crate::lower::model::Do assign(const Lx& lx, const Env& env, const crate::syntax::Expr& target, const crate::lower::model::Ex& v_) {
    auto&& _m = target.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& k = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        auto rt = out_ty_of(lx, peel(type_at(lx, r.span)));
        auto f = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(rt)) {
                _v.set(Text::lit("set_key"));
                goto _done;
            }
            {
                _v.set(Text::lit("set_index"));
                goto _done;
            }
        _done:
            _v.take();
        });
        return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XCall{f, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRefMut{prism_rtl::rc(place_of(lx, env, r))}), argument(lx, env, k), v_})})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return assign(lx, env, x, v_);
    }
    {
        return crate::lower::model::Do(crate::lower::model::Do::DoAssign{place_of(lx, env, target), v_});
    }
}


prism_rtl::Turn<crate::lower::model::Do> Assign::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& target = this->target;
    const auto& v_ = this->v_;
    return ({
        auto&& _m = target.kind;
        prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m) ? ({
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& k = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        ({
        auto env_1 = env;
        auto k_2 = k;
        auto lx_3 = lx;
        auto r_4 = r;
        auto v__5 = v_;
        call_then(start_out_ty_of(lx_3, peel(type_at(lx_3, r_4.span))), [=](crate::lower::model::OutTy out_ty_of_125684) {
        return ({
            auto rt = out_ty_of_125684;
            auto f = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(rt)) {
                    _v.set(Text::lit("set_key"));
                    goto _done;
                }
                {
                    _v.set(Text::lit("set_index"));
                    goto _done;
                }
            _done:
                _v.take();
            });
            call_then(start_place_of(lx_3, env_1, r_4), [=](crate::lower::model::Ex place_of_125866) { return call_then(start_argument(lx_3, env_1, k_2), [=](crate::lower::model::Ex argument_125889) { return prism_rtl::finished(crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XCall{f, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRefMut{prism_rtl::rc(place_of_125866)}), argument_125889, v__5})})})); }); });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(Assign(lx, env, x, v_)));
    })
        : ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto target_3 = target;
        auto v__4 = v_;
        call_then(start_place_of(lx_2, env_1, target_3), [=](crate::lower::model::Ex place_of_125976) { return prism_rtl::finished(crate::lower::model::Do(crate::lower::model::Do::DoAssign{place_of_125976, v__4})); });
    });
    });
}


/// `Start Assign, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Do> start_assign(Lx lx, Env env, crate::syntax::Expr target, crate::lower::model::Ex v_) {
    return prism_rtl::make_rc<Assign>(lx, env, target, v_);
}


/// BoundOf: fn Lx, Text -> [Text]
Array<Text> bound_of(const Lx& lx, const Text& text1) {
    {
        auto&& c0_1 = text1;
        if (c0_1 == Text::lit("Prelude.Eq")) {
            return Array(std::vector{Text::lit("PartialEq")});
        }
    }
    {
        auto&& c1_1 = text1;
        if (c1_1 == Text::lit("Prelude.Ord")) {
            return Array(std::vector{Text::lit("PartialOrd")});
        }
    }
    {
        auto&& c2_1 = text1;
        if (c2_1 == Text::lit("Prelude.Show")) {
            return Array(std::vector{Text::lit("Show")});
        }
    }
    {
        auto&& c3_1 = text1;
        if (c3_1 == Text::lit("Prelude.Num")) {
            return Array(std::vector{Text::lit("Num")});
        }
    }
    {
        auto&& c4_1 = text1;
        if (c4_1 == Text::lit("Prelude.Pod")) {
            return Array(std::vector{Text::lit("ToPod"), Text::lit("FromPod")});
        }
    }
    {
        auto&& cls = text1;
        auto&& _m = crate::prelude::get(lx.g.traits, cls);
        if (prism_rtl::is_some(_m)) {
            auto&& tr = prism_rtl::some_of(_m);
            return Array(std::vector{path_in(lx, tr.home, camel(crate::check::types::bare_name(cls)))});
        }
        if (prism_rtl::is_none(_m)) {
            return Array<Text>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
}


/// SchemeGenerics: fn Lx, Scheme -> [((Text, [Text]))]
Array<std::tuple<Text, Array<Text>>> scheme_generics(const Lx& lx, const crate::check::types::Scheme& sc) {
    return each(sc.qs, [&](const Text& q) {
        return ({
            auto bs = fold(sc.bounds, Array(std::vector{Text::lit("Clone")}), [&](const Array<Text>& acc, const std::tuple<Text, Text>& _p1) {
                auto&& v_ = std::get<0>(_p1);
                auto&& cls = std::get<1>(_p1);
                return v_ == q ? crate::check::types::union_texts(acc, bound_of(lx, cls)) : acc;
            });
            std::tuple{camel(q), bs};
        });
    });
}


/// ParamNames: fn Lx, [FnClause], [OutTy] -> [((Text, Bool))]
Array<std::tuple<Text, bool>> param_names(const Lx& lx, const Array<crate::syntax::FnClause>& clauses, const Array<crate::lower::model::OutTy>& pts) {
    return each(crate::check::errors::range0(len(pts)), [&](const Nat& i) {
        return ({
            auto names = each(clauses, [&](const crate::syntax::FnClause& c) { return plain_binder(lx, or_(index(c.params, i), dummy_pat())); });
            auto first_ = or_(index(names, Nat(0u)), Text::lit(""));
            auto same = (first_ != Text::lit("")) && fold(names, true, [&](const bool& ok, const Text& n) { return ok && (n == first_); });
            same
            ? std::tuple{local_name(lx, first_), false}
            : std::tuple{param_word(or_(index(pts, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})), i), true};
        });
    });
}


/// PlainBinder: fn Lx, Pattern -> Text
Text plain_binder(const Lx& lx, const crate::syntax::Pattern_& p_) {
    auto&& _m = p_.kind;
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        auto [qk_opt, why] = crate::check::env::resolve_value(lx.g, lx.home, n);
        auto is_ctor = ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& qk = prism_rtl::some_of(qk_opt);
                _v.set(crate::check::env::has_key(lx.g.ctors, qk) && (crate::check::env::is_upper_text(base(crate::check::env::sname_key(n))) || is_unit_ctor(lx, qk)));
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return is_ctor ? Text::lit("") : crate::check::env::sname_key(n);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return plain_binder(lx, q);
    }
    {
        return Text::lit("");
    }
}


/// ParamWord: fn OutTy, Nat -> Text
Text param_word(const crate::lower::model::OutTy& t, const Nat& i) {
    auto base_ = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t)) {
            auto&& n = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a0;
            _v.set(snake(or_(crate::syntax::lexer::last(split(n, Text::lit("::"))), Text::lit("arg"))));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::OutTy::OutText>(t)) {
            _v.set(Text::lit("text"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::OutTy::OutNat>(t)) {
            _v.set(Text::lit("n"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::OutTy::OutInt>(t)) {
            _v.set(Text::lit("i"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::OutTy::OutArray>(t)) {
            _v.set(Text::lit("xs"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(t)) {
            _v.set(Text::lit("map"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t)) {
            _v.set(Text::lit("opt"));
            goto _done;
        }
        {
            _v.set(Text::lit("arg"));
            goto _done;
        }
    _done:
        _v.take();
    });
    return prism_rtl::cat(base_, i);
}


/// ClausesBody: unbounded fn Lx, Env, [FnClause], [((Text, Bool))], [Ty], (fn Lx, Env, FnBody -> Ex), Text, OutTy -> Ex
crate::lower::model::Ex clauses_body(const Lx& lx, const Env& env, const Array<crate::syntax::FnClause>& clauses, const Array<std::tuple<Text, bool>>& names, const Array<crate::check::types::Ty>& ptys, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Lx, Env, crate::syntax::FnBody>)>& body_fn, const Text& label, const crate::lower::model::OutTy& t) {
    auto env1 = run_to_end(fold_job(crate::check::errors::range0(len(names)), env, ({
        auto names_1 = names;
        auto lx_2 = lx;
        auto clauses_3 = clauses;
        auto ptys_4 = ptys;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Env>(std::tuple<Env, Nat>)>>(prism_rtl::rc([=](std::tuple<Env, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto names_1_5 = names_1;
            auto lx_2_5 = lx_2;
            auto clauses_3_5 = clauses_3;
            auto ptys_4_5 = ptys_4;
            entered(once_job([=]() {
            return ({
                auto en = p0;
                auto i = p1;
                ({
                auto [rs, matched] = or_(index(names_1_5, i), std::tuple{Text::lit(""), true});
                matched
                ? prism_rtl::finished(en)
                : call_then(start_out_ty_of(lx_2_5, peel(or_(index(ptys_4_5, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})))), [=](crate::lower::model::OutTy out_ty_of_129269) { return prism_rtl::finished(bind(en, plain_binder(lx_2_5, or_(index(or_(index(clauses_3_5, Nat(0u)), dummy_clause()).params, i), dummy_pat())), Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs}), Holding(Holding::ByRef{}), out_ty_of_129269}))); });
            });
            });
        }));
        });
    })));
    })));
    auto scrut_ix = filter(crate::check::errors::range0(len(names)), [&](const Nat& i) {
        return ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = index(names, i);
            if (prism_rtl::is_some(_m) && std::get<1>(prism_rtl::some_of(_m))) {
                _v.set(true);
                goto _done;
            }
            {
                _v.set(false);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return len(scrut_ix) == Nat(0u)
        ? ({
        auto c = or_(index(clauses, Nat(0u)), dummy_clause());
        run_to_end(body_fn(std::tuple{lx, env1, c.body}));
    })
        : ({
        auto scrut = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::Ex> _v;
            {
                auto&& m129566_0 = scrut_ix;
                if (m129566_0.size() == 1u) {
                    {
                        auto&& _c1 = index(m129566_0, Nat(0u));
                        if (prism_rtl::is_some(_c1)) {
                            auto&& i = prism_rtl::some_of(_c1);
                            _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XVar{or_(index(each(names, [&](const std::tuple<Text, bool>& _p0) {
                                auto&& n = std::get<0>(_p0);
                                return n;
                            }), i), Text::lit("arg"))}));
                            goto _done;
                        }
                    }
                }
            }
            {
                _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XTuple{each(scrut_ix, [&](const Nat& i) {
                    return crate::lower::model::Ex(crate::lower::model::Ex::XVar{or_(index(each(names, [&](const std::tuple<Text, bool>& _p0) {
                        auto&& n = std::get<0>(_p0);
                        return n;
                    }), i), Text::lit("arg"))});
                })}));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto arms = run_to_end(each_job(crate::check::errors::range0(len(clauses)), ({
            auto clauses_1 = clauses;
            auto scrut_ix_2 = scrut_ix;
            auto lx_3 = lx;
            auto ptys_4 = ptys;
            auto label_5 = label;
            auto body_fn_6 = body_fn;
            auto env1_7 = env1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::XArm>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto clauses_1_8 = clauses_1;
                auto scrut_ix_2_8 = scrut_ix_2;
                auto lx_3_8 = lx_3;
                auto ptys_4_8 = ptys_4;
                auto label_5_8 = label_5;
                auto body_fn_6_8 = body_fn_6;
                auto env1_7_8 = env1_7;
                entered(once_job([=]() {
                return ({
                    auto ci = p0;
                    ({
                    auto c = or_(index(clauses_1_8, ci), dummy_clause());
                    call_value(each_job(scrut_ix_2_8, ({
                    auto lx_3_8_8 = lx_3_8;
                    auto c_8 = c;
                    auto ptys_4_8_9 = ptys_4_8;
                    auto label_5_8_9 = label_5_8;
                    auto ci_9 = ci;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                    return ({
                        auto lx_3_8_8_10 = lx_3_8_8;
                        auto c_8_10 = c_8;
                        auto ptys_4_8_9_10 = ptys_4_8_9;
                        auto label_5_8_9_10 = label_5_8_9;
                        auto ci_9_10 = ci_9;
                        entered(once_job([=]() {
                        return ({
                            auto i = p0;
                            (prism_rtl::more(prism_rtl::rc(RustPat(lx_3_8_8_10, or_(index(c_8_10.params, i), dummy_pat()), or_(index(ptys_4_8_9_10, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), Holding(Holding::ByRef{}), prism_rtl::cat(label_5_8_9_10, ci_9_10, "_", i)))));
                        });
                    }));
                    });
                })));
                })), [=](Array<PatOut> each_129881) {
                    return ({
                        auto pos = each_129881;
                        auto pa = ({
                            __label__ _done;
                            prism_rtl::Slot<crate::lower::model::Pa> _v;
                            {
                                auto&& m130007_0 = pos;
                                if (m130007_0.size() == 1u) {
                                    {
                                        auto&& _c1 = index(m130007_0, Nat(0u));
                                        if (prism_rtl::is_some(_c1)) {
                                            auto&& o = prism_rtl::some_of(_c1);
                                            _v.set(o.pa);
                                            goto _done;
                                        }
                                    }
                                }
                            }
                            {
                                _v.set(crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(pos, [&](const PatOut& o) { return o.pa; })}));
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                        auto conds = fold(pos, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc, const PatOut& o) { return append(acc, o.conds); });
                        auto binds = fold(pos, Array<std::tuple<Text, Bn>>{}, [&](const Array<std::tuple<Text, Bn>>& acc, const PatOut& o) { return append(acc, o.binds); });
                        call_value(body_fn_6_8(std::tuple{lx_3_8, bind_all(env1_7_8, binds), c.body}), [=](crate::lower::model::Ex body_130287) { return prism_rtl::finished(crate::lower::model::XArm{.pat = pa, .conds = conds, .body = body_130287}); });
                    });
                });
                });
                });
            }));
            });
        })));
        })));
        own(arms_value(scrut, arms, prism_rtl::cat("'", label), t));
    });
}


prism_rtl::Turn<crate::lower::model::Ex> ClausesBody::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& clauses = this->clauses;
    const auto& names = this->names;
    const auto& ptys = this->ptys;
    const auto& body_fn = this->body_fn;
    const auto& label = this->label;
    const auto& t = this->t;
    auto body_fn_1 = body_fn;
    auto clauses_2 = clauses;
    auto env_3 = env;
    auto label_4 = label;
    auto lx_5 = lx;
    auto names_6 = names;
    auto ptys_7 = ptys;
    auto t_8 = t;
    return call_value(fold_job(crate::check::errors::range0(len(names_6)), env_3, ({
        auto names_6_9 = names_6;
        auto lx_5_9 = lx_5;
        auto clauses_2_9 = clauses_2;
        auto ptys_7_9 = ptys_7;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Env>(std::tuple<Env, Nat>)>>(prism_rtl::rc([=](std::tuple<Env, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto names_6_9_9 = names_6_9;
            auto lx_5_9_9 = lx_5_9;
            auto clauses_2_9_9 = clauses_2_9;
            auto ptys_7_9_9 = ptys_7_9;
            entered(once_job([=]() {
            return ({
                auto en = p0;
                auto i = p1;
                ({
                auto [rs, matched] = or_(index(names_6_9_9, i), std::tuple{Text::lit(""), true});
                matched
                ? prism_rtl::finished(en)
                : call_then(start_out_ty_of(lx_5_9_9, peel(or_(index(ptys_7_9_9, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})))), [=](crate::lower::model::OutTy out_ty_of_129269) { return prism_rtl::finished(bind(en, plain_binder(lx_5_9_9, or_(index(or_(index(clauses_2_9_9, Nat(0u)), dummy_clause()).params, i), dummy_pat())), Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs}), Holding(Holding::ByRef{}), out_ty_of_129269}))); });
            });
            });
        }));
        });
    })));
    })), [=](Env fold_129025) {
        return ({
            auto env1 = fold_129025;
            auto scrut_ix = filter(crate::check::errors::range0(len(names_6)), [&](const Nat& i) {
                return ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = index(names_6, i);
                    if (prism_rtl::is_some(_m) && std::get<1>(prism_rtl::some_of(_m))) {
                        _v.set(true);
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            });
            len(scrut_ix) == Nat(0u)
            ? ({
            auto c = or_(index(clauses_2, Nat(0u)), dummy_clause());
            body_fn_1(std::tuple{lx_5, env1, c.body})->cycle();
        })
            : ({
            auto scrut = ({
                __label__ _done;
                prism_rtl::Slot<crate::lower::model::Ex> _v;
                {
                    auto&& m129566_0 = scrut_ix;
                    if (m129566_0.size() == 1u) {
                        {
                            auto&& _c1 = index(m129566_0, Nat(0u));
                            if (prism_rtl::is_some(_c1)) {
                                auto&& i = prism_rtl::some_of(_c1);
                                _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XVar{or_(index(each(names_6, [&](const std::tuple<Text, bool>& _p0) {
                                    auto&& n = std::get<0>(_p0);
                                    return n;
                                }), i), Text::lit("arg"))}));
                                goto _done;
                            }
                        }
                    }
                }
                {
                    _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XTuple{each(scrut_ix, [&](const Nat& i) {
                        return crate::lower::model::Ex(crate::lower::model::Ex::XVar{or_(index(each(names_6, [&](const std::tuple<Text, bool>& _p0) {
                            auto&& n = std::get<0>(_p0);
                            return n;
                        }), i), Text::lit("arg"))});
                    })}));
                    goto _done;
                }
            _done:
                _v.take();
            });
            call_value(each_job(crate::check::errors::range0(len(clauses_2)), ({
            auto clauses_2_9 = clauses_2;
            auto scrut_ix_9 = scrut_ix;
            auto lx_5_10 = lx_5;
            auto ptys_7_10 = ptys_7;
            auto label_4_10 = label_4;
            auto body_fn_1_10 = body_fn_1;
            auto env1_10 = env1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::XArm>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto clauses_2_9_11 = clauses_2_9;
                auto scrut_ix_9_11 = scrut_ix_9;
                auto lx_5_10_11 = lx_5_10;
                auto ptys_7_10_11 = ptys_7_10;
                auto label_4_10_11 = label_4_10;
                auto body_fn_1_10_11 = body_fn_1_10;
                auto env1_10_11 = env1_10;
                entered(once_job([=]() {
                return ({
                    auto ci = p0;
                    ({
                    auto c = or_(index(clauses_2_9_11, ci), dummy_clause());
                    call_value(each_job(scrut_ix_9_11, ({
                    auto lx_5_10_11_11 = lx_5_10_11;
                    auto c_11 = c;
                    auto ptys_7_10_11_12 = ptys_7_10_11;
                    auto label_4_10_11_12 = label_4_10_11;
                    auto ci_12 = ci;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                    return ({
                        auto lx_5_10_11_11_13 = lx_5_10_11_11;
                        auto c_11_13 = c_11;
                        auto ptys_7_10_11_12_13 = ptys_7_10_11_12;
                        auto label_4_10_11_12_13 = label_4_10_11_12;
                        auto ci_12_13 = ci_12;
                        entered(once_job([=]() {
                        return ({
                            auto i = p0;
                            (prism_rtl::more(prism_rtl::rc(RustPat(lx_5_10_11_11_13, or_(index(c_11_13.params, i), dummy_pat()), or_(index(ptys_7_10_11_12_13, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), Holding(Holding::ByRef{}), prism_rtl::cat(label_4_10_11_12_13, ci_12_13, "_", i)))));
                        });
                    }));
                    });
                })));
                })), [=](Array<PatOut> each_129881) {
                    return ({
                        auto pos = each_129881;
                        auto pa = ({
                            __label__ _done;
                            prism_rtl::Slot<crate::lower::model::Pa> _v;
                            {
                                auto&& m130007_0 = pos;
                                if (m130007_0.size() == 1u) {
                                    {
                                        auto&& _c1 = index(m130007_0, Nat(0u));
                                        if (prism_rtl::is_some(_c1)) {
                                            auto&& o = prism_rtl::some_of(_c1);
                                            _v.set(o.pa);
                                            goto _done;
                                        }
                                    }
                                }
                            }
                            {
                                _v.set(crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(pos, [&](const PatOut& o) { return o.pa; })}));
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                        auto conds = fold(pos, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc, const PatOut& o) { return append(acc, o.conds); });
                        auto binds = fold(pos, Array<std::tuple<Text, Bn>>{}, [&](const Array<std::tuple<Text, Bn>>& acc, const PatOut& o) { return append(acc, o.binds); });
                        call_value(body_fn_1_10_11(std::tuple{lx_5_10_11, bind_all(env1_10_11, binds), c.body}), [=](crate::lower::model::Ex body_130287) { return prism_rtl::finished(crate::lower::model::XArm{.pat = pa, .conds = conds, .body = body_130287}); });
                    });
                });
                });
                });
            }));
            });
        })));
        })), [=](Array<crate::lower::model::XArm> each_129776) {
            return ({
                auto arms = each_129776;
                (prism_rtl::finished(own(arms_value(scrut, arms, prism_rtl::cat("'", label_4), t_8))));
            });
        });
        });
        });
    });
}


/// `Start ClausesBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_clauses_body(Lx lx, Env env, Array<crate::syntax::FnClause> clauses, Array<std::tuple<Text, bool>> names, Array<crate::check::types::Ty> ptys, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Lx, Env, crate::syntax::FnBody>)> body_fn, Text label, crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<ClausesBody>(lx, env, clauses, names, ptys, body_fn, label, t);
}


/// let dummyClause
crate::syntax::FnClause dummy_clause() {
    return crate::syntax::FnClause{.name = crate::syntax::DefName(crate::syntax::DefName::DefOp{Text::lit(""), crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}}), .params = Array<crate::syntax::Pattern_>{}, .body = crate::syntax::FnBody(crate::syntax::FnBody::BodyExpr{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}}}), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// FnBodyValue: unbounded fn Lx, Env, FnBody -> Ex
crate::lower::model::Ex fn_body_value(const Lx& lx, const Env& env, const crate::syntax::FnBody& fn_body2) {
    if (prism_rtl::is<crate::syntax::FnBody::BodyExpr>(fn_body2)) {
        auto&& x = prism_rtl::as<crate::syntax::FnBody::BodyExpr>(fn_body2).a0;
        return own(value_of(lx, env, x));
    }
    if (prism_rtl::is<crate::syntax::FnBody::BodyBlock>(fn_body2)) {
        auto&& b = prism_rtl::as<crate::syntax::FnBody::BodyBlock>(fn_body2).a0;
        return own(block_value(lx, env, b));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::model::Ex> FnBodyValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& fn_body2 = this->fn_body2;
    return ({
        prism_rtl::is<crate::syntax::FnBody::BodyExpr>(fn_body2) ? ({
        auto&& x = prism_rtl::as<crate::syntax::FnBody::BodyExpr>(fn_body2).a0;
        ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto x_3 = x;
        call_then(start_value_of(lx_2, env_1, x_3), [=](Vl value_of_130646) { return prism_rtl::finished(own(value_of_130646)); });
    });
    })
        : prism_rtl::is<crate::syntax::FnBody::BodyBlock>(fn_body2) ? ({
        auto&& b = prism_rtl::as<crate::syntax::FnBody::BodyBlock>(fn_body2).a0;
        ({
        auto b_1 = b;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(start_block_value(lx_3, env_2, b_1), [=](Vl block_value_130711) { return prism_rtl::finished(own(block_value_130711)); });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start FnBodyValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_fn_body_value(Lx lx, Env env, crate::syntax::FnBody fn_body2) {
    return prism_rtl::make_rc<FnBodyValue>(lx, env, fn_body2);
}


/// FnDefOf: unbounded fn Lx, Text, [FnClause], Scheme -> FnDef
crate::lower::model::FnDef fn_def_of(const Lx& lx, const Text& qk, const Array<crate::syntax::FnClause>& clauses, const crate::check::types::Scheme& sc) {
    auto [ptys0, res] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::check::types::Ty>, crate::check::types::Ty>> _v;
        auto&& _m = sc.ty;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            auto&& r = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
            _v.set(std::tuple{ps, r});
            goto _done;
        }
        {
            auto&& other = _m;
            _v.set(std::tuple{Array<crate::check::types::Ty>{}, other});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto ptys = has_blueprint(res)
        ? each(ptys0, [&](const crate::check::types::Ty& p_) { return event_param(p_); })
        : ptys0;
    auto pts = run_to_end(each_job(ptys, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_1_2, peel(p_)))));
            });
        }));
        });
    })));
    })));
    auto names = param_names(lx, clauses, pts);
    auto body = clauses_body(lx, empty_env(), clauses, names, ptys, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Lx, Env, crate::syntax::FnBody>)>>(prism_rtl::rc([&](std::tuple<Lx, Env, crate::syntax::FnBody> _p0) {
        auto&& a0 = std::get<0>(_p0);
        auto&& a1 = std::get<1>(_p0);
        auto&& a2 = std::get<2>(_p0);
        return entered(start_fn_body_value(a0, a1, a2));
    })), Text::lit("c"), out_ty_of(lx, peel(res)));
    auto params = each(crate::check::errors::range0(len(pts)), [&](const Nat& i) {
        return std::tuple{or_(index(each(names, [&](const std::tuple<Text, bool>& _p0) {
            auto&& n = std::get<0>(_p0);
            return n;
        }), i), Text::lit("arg")), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(or_(index(pts, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})))})};
    });
    auto ret = out_ty_of(lx, peel(res));
    auto used = fold(crate::prelude::push(pts, ret), Array<Text>{}, [&](const Array<Text>& acc, const crate::lower::model::OutTy& t) { return crate::check::types::union_texts(acc, ty_params_in(t)); });
    auto generics = filter(scheme_generics(lx, sc), [&](const std::tuple<Text, Array<Text>>& _p0) {
        auto&& g = std::get<0>(_p0);
        return crate::check::types::has_text(used, g);
    });
    return crate::lower::model::FnDef{.name = or_(crate::prelude::get(lx.rs_names, qk), snake(crate::check::types::bare_name(qk))), .generics = generics, .params = params, .ret = ret, .body = body, .doc = signature_text(lx, qk), .public_ = true};
}


prism_rtl::Turn<crate::lower::model::FnDef> FnDefOf::cycle() const {
    const auto& lx = this->lx;
    const auto& qk = this->qk;
    const auto& clauses = this->clauses;
    const auto& sc = this->sc;
    auto [ptys0, res] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::check::types::Ty>, crate::check::types::Ty>> _v;
        auto&& _m = sc.ty;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            auto&& r = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
            _v.set(std::tuple{ps, r});
            goto _done;
        }
        {
            auto&& other = _m;
            _v.set(std::tuple{Array<crate::check::types::Ty>{}, other});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto ptys = has_blueprint(res)
        ? each(ptys0, [&](const crate::check::types::Ty& p_) { return event_param(p_); })
        : ptys0;
    auto clauses_1 = clauses;
    auto lx_2 = lx;
    auto qk_3 = qk;
    auto sc_4 = sc;
    return call_value(each_job(ptys, ({
        auto lx_2_5 = lx_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return ({
            auto lx_2_5_5 = lx_2_5;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_2_5_5, peel(p_)))));
            });
        }));
        });
    })));
    })), [=](Array<crate::lower::model::OutTy> each_131268) {
        return ({
            auto pts = each_131268;
            auto names = param_names(lx_2, clauses_1, pts);
            call_then(start_out_ty_of(lx_2, peel(res)), [=](crate::lower::model::OutTy out_ty_of_131431) {
            return call_then(start_clauses_body(lx_2, empty_env(), clauses_1, names, ptys, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Lx, Env, crate::syntax::FnBody>)>>(prism_rtl::rc([&](std::tuple<Lx, Env, crate::syntax::FnBody> _p0) {
                auto&& a0 = std::get<0>(_p0);
                auto&& a1 = std::get<1>(_p0);
                auto&& a2 = std::get<2>(_p0);
                return entered(start_fn_body_value(a0, a1, a2));
            })), Text::lit("c"), out_ty_of_131431), [=](crate::lower::model::Ex clauses_body_131364) {
                return ({
                    auto body = clauses_body_131364;
                    auto params = each(crate::check::errors::range0(len(pts)), [&](const Nat& i) {
                        return std::tuple{or_(index(each(names, [&](const std::tuple<Text, bool>& _p0) {
                            auto&& n = std::get<0>(_p0);
                            return n;
                        }), i), Text::lit("arg")), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(or_(index(pts, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})))})};
                    });
                    call_then(start_out_ty_of(lx_2, peel(res)), [=](crate::lower::model::OutTy out_ty_of_131599) {
                    return ({
                        auto ret = out_ty_of_131599;
                        auto used = fold(crate::prelude::push(pts, ret), Array<Text>{}, [&](const Array<Text>& acc, const crate::lower::model::OutTy& t) { return crate::check::types::union_texts(acc, ty_params_in(t)); });
                        auto generics = filter(scheme_generics(lx_2, sc_4), [&](const std::tuple<Text, Array<Text>>& _p0) {
                            auto&& g = std::get<0>(_p0);
                            return crate::check::types::has_text(used, g);
                        });
                        (prism_rtl::finished(crate::lower::model::FnDef{.name = or_(crate::prelude::get(lx_2.rs_names, qk_3), snake(crate::check::types::bare_name(qk_3))), .generics = generics, .params = params, .ret = ret, .body = body, .doc = signature_text(lx_2, qk_3), .public_ = true}));
                    });
                });
                });
            });
        });
        });
    });
}


/// `Start FnDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::FnDef> start_fn_def_of(Lx lx, Text qk, Array<crate::syntax::FnClause> clauses, crate::check::types::Scheme sc) {
    return prism_rtl::make_rc<FnDefOf>(lx, qk, clauses, sc);
}


/// TyParamsIn: fn OutTy -> [Text]
Array<Text> ty_params_in(const crate::lower::model::OutTy& t) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutGen>(t)) {
        auto&& n = prism_rtl::as<crate::lower::model::OutTy::OutGen>(t).a0;
        return Array(std::vector{n});
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t)) {
        auto&& ts = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        return fold(ts, Array<Text>{}, [&](const Array<Text>& acc, const crate::lower::model::OutTy& x) { return crate::check::types::union_texts(acc, ty_params_in(x)); });
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t).a0;
        return fold(ts, Array<Text>{}, [&](const Array<Text>& acc, const crate::lower::model::OutTy& x) { return crate::check::types::union_texts(acc, ty_params_in(x)); });
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(t)) {
        auto&& ts = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t).a0;
        auto&& r = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t).a1;
        return fold(ts, ty_params_in(r), [&](const Array<Text>& acc, const crate::lower::model::OutTy& x) { return crate::check::types::union_texts(acc, ty_params_in(x)); });
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t)) {
        auto&& a = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t).a0;
        auto&& r = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t).a1;
        return crate::check::types::union_texts(ty_params_in(a), ty_params_in(r));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(t)) {
        auto&& k = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t).a1;
        return crate::check::types::union_texts(ty_params_in(k), ty_params_in(v_));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t)) {
        auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t).a0;
        return ty_params_in(x);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t)) {
        auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t).a0;
        return ty_params_in(x);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutArray>(t)) {
        auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t).a0;
        return ty_params_in(x);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutJob>(t)) {
        auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutJob>(t).a0;
        return ty_params_in(x);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t)) {
        auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutEvent>(t).a0;
        return ty_params_in(x);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(t)) {
        auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(t).a0;
        return ty_params_in(x);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRc>(t)) {
        auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t).a0;
        return ty_params_in(x);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRef>(t)) {
        auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutRef>(t).a0;
        return ty_params_in(x);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutHold>(t)) {
        auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutHold>(t).a0;
        return ty_params_in(x);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutCell>(t)) {
        auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutCell>(t).a0;
        return ty_params_in(x);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutLive>(t)) {
        auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutLive>(t).a0;
        return ty_params_in(x);
    }
    {
        return Array<Text>{};
    }
}


/// SignatureText: fn Lx, Text -> Text
Text signature_text(const Lx& lx, const Text& qk) {
    auto&& _m = crate::prelude::get(lx.g.vals, qk);
    if (prism_rtl::is_some(_m)) {
        auto&& v_ = prism_rtl::some_of(_m);
        auto&& _m = index(lx.g.srcs, v_->file);
        if (prism_rtl::is_some(_m)) {
            auto&& src = prism_rtl::some_of(_m);
            return crate::syntax::lexer::trim(crate::check::errors::span_text(src, v_.span));
        }
        if (prism_rtl::is_none(_m)) {
            return crate::check::types::bare_name(qk);
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_none(_m)) {
        return crate::check::types::bare_name(qk);
    }
    prism_rtl::unreachable("no arm matched");
}


/// DefinitionText: fn Lx, Text -> Text
Text definition_text(const Lx& lx, const Text& qk) {
    auto spans = fold(lx.g.defs, Array<std::tuple<Nat, crate::syntax::Range>>{}, [&](const Array<std::tuple<Nat, crate::syntax::Range>>& acc, const crate::check::env::Def& d) { return d.qk == qk ? crate::prelude::push(acc, std::tuple{d->file, d.span}) : acc; });
    auto sig = ({
        __label__ _done;
        prism_rtl::Slot<Array<std::tuple<Nat, crate::syntax::Range>>> _v;
        auto&& _m = crate::prelude::get(lx.g.vals, qk);
        if (prism_rtl::is_some(_m)) {
            auto&& v_ = prism_rtl::some_of(_m);
            _v.set(v_.span.start < or_(index(each(spans, [&](const std::tuple<Nat, crate::syntax::Range>& _p0) {
                auto&& r = std::get<1>(_p0);
                return r.start;
            }), Nat(0u)), Nat(0u))
                ? Array(std::vector{std::tuple{v_->file, v_.span}})
                : Array<std::tuple<Nat, crate::syntax::Range>>{});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<std::tuple<Nat, crate::syntax::Range>>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return crate::syntax::lexer::join(each(append(sig, spans), [&](const std::tuple<Nat, crate::syntax::Range>& _p0) {
        auto&& f = std::get<0>(_p0);
        auto&& r = std::get<1>(_p0);
        return src_text(lx, f, r);
    }), Text::lit("\n"));
}


/// SrcText: fn Lx, Nat, Range -> Text
Text src_text(const Lx& lx, const Nat& f, const crate::syntax::Range& r) {
    auto&& _m = index(lx.g.srcs, f);
    if (prism_rtl::is_some(_m)) {
        auto&& src = prism_rtl::some_of(_m);
        return drop_trailing_comments(crate::check::errors::span_text(src, r));
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// DropTrailingComments: fn Text -> Text
Text drop_trailing_comments(const Text& t) {
    auto lines = split(t, Text::lit("\n"));
    auto keep = fold(crate::check::errors::range0(len(lines)), Nat(0u), [&](const Nat& k, const Nat& i) { return is_code_line(or_(index(lines, i), Text::lit(""))) ? i + Nat(1u) : k; });
    return crate::syntax::lexer::trim_end(crate::syntax::lexer::join(take(lines, keep), Text::lit("\n")));
}


/// IsCodeLine: fn Text -> Bool
bool is_code_line(const Text& l) {
    auto s = crate::syntax::lexer::trim(l);
    return (s != Text::lit("")) && (!crate::syntax::lexer::has_prefix(s, Text::lit("#")));
}


/// LetGetter: unbounded fn Lx, Text, LetDecl -> FnDef
crate::lower::model::FnDef let_getter(const Lx& lx, const Text& qk, const crate::syntax::LetDecl& l) {
    auto t = out_ty_of(lx, peel(type_at(lx, l->value.span)));
    auto v_ = value_of(lx, empty_env(), l->value);
    return crate::lower::model::FnDef{.name = or_(crate::prelude::get(lx.rs_names, qk), snake(crate::check::types::bare_name(qk))), .generics = Array<std::tuple<Text, Array<Text>>>{}, .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .ret = t, .body = own(v_), .doc = prism_rtl::cat("let ", crate::check::types::bare_name(qk)), .public_ = true};
}


prism_rtl::Turn<crate::lower::model::FnDef> LetGetter::cycle() const {
    const auto& lx = this->lx;
    const auto& qk = this->qk;
    const auto& l = this->l;
    auto l_1 = l;
    auto lx_2 = lx;
    auto qk_3 = qk;
    return call_then(start_out_ty_of(lx_2, peel(type_at(lx_2, l_1->value.span))), [=](crate::lower::model::OutTy out_ty_of_134448) {
        return ({
            auto t = out_ty_of_134448;
            call_then(start_value_of(lx_2, empty_env(), l_1->value), [=](Vl value_of_134505) {
            return ({
                auto v_ = value_of_134505;
                (prism_rtl::finished(crate::lower::model::FnDef{.name = or_(crate::prelude::get(lx_2.rs_names, qk_3), snake(crate::check::types::bare_name(qk_3))), .generics = Array<std::tuple<Text, Array<Text>>>{}, .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .ret = t, .body = own(v_), .doc = prism_rtl::cat("let ", crate::check::types::bare_name(qk_3)), .public_ = true}));
            });
        });
        });
    });
}


/// `Start LetGetter, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::FnDef> start_let_getter(Lx lx, Text qk, crate::syntax::LetDecl l) {
    return prism_rtl::make_rc<LetGetter>(lx, qk, l);
}


/// HasOwnShow: fn Lx, Text -> Bool
bool has_own_show(const Lx& lx, const Text& tn) {
    return fold(or_(crate::prelude::get(lx.g.impls, Text::lit("Prelude.Show")), Array<crate::check::env::ImplInfo>{}), false, [&](const bool& f, const crate::check::env::ImplInfo& im) { return f || ((!im.derived) && (head_name(im.head) == tn)); });
}


/// HeadName: fn Ty -> Text
Text head_name(const crate::check::types::Ty& ty0) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(ty0)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(ty0).a0;
        return n;
    }
    {
        auto&& other = ty0;
        return Text::lit("");
    }
}


/// SelfIn: unbounded fn Ty, Text -> Ty
crate::check::types::Ty self_in(const crate::check::types::Ty& t, const Text& param) {
    return instantiated(t, Array(std::vector{param}), Array(std::vector{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("\000Self"sv), Array<crate::check::types::Ty>{}})}));
}


prism_rtl::Turn<crate::check::types::Ty> SelfIn::cycle() const {
    const auto& t = this->t;
    const auto& param = this->param;
    return prism_rtl::more(prism_rtl::rc(Instantiated(t, Array(std::vector{param}), Array(std::vector{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("\000Self"sv), Array<crate::check::types::Ty>{}})}))));
}


/// `Start SelfIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_self_in(crate::check::types::Ty t, Text param) {
    return prism_rtl::make_rc<SelfIn>(t, param);
}


/// TraitDefOf: unbounded fn Lx, TraitInfo -> TraitDef
crate::lower::model::TraitDef trait_def_of(const Lx& lx0, const crate::check::env::TraitInfo& tr) {
    auto lx = in_module(lx0, tr->file, tr.home);
    auto methods = run_to_end(each_job(tr.methods, ({
        auto lx_1 = lx;
        auto tr_2 = tr;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::FnDef>(Text)>>(prism_rtl::rc([=](Text p0) {
        return ({
            auto lx_1_3 = lx_1;
            auto tr_2_3 = tr_2;
            entered(once_job([=]() {
            return ({
                auto mq = p0;
                ({
                auto v_ = or_(crate::prelude::get(lx_1_3.g.vals, mq), crate::check::env::builtin(mq, crate::check::types::mono(crate::check::types::Ty(crate::check::types::Ty::TyErr{}))));
                auto sc = ({
                    crate::check::types::Scheme this_ = v_.scheme;
                    this_.ty = self_in(this_.ty, tr_2_3.param);
                    this_.qs = filter(this_.qs, [&](const Text& q) { return q != tr_2_3.param; });
                    this_.bounds = filter(this_.bounds, [&](const std::tuple<Text, Text>& _p0) {
                        auto&& q = std::get<0>(_p0);
                        return q != tr_2_3.param;
                    });
                    this_;
                });
                auto default_qk = fold(tr_2_3.defaults, Text::lit(""), [&](const Text& f, const Text& dq) {
                    return crate::check::types::bare_name(dq) == crate::check::types::bare_name(mq)
                        ? dq
                        : f;
                });
                auto clauses = default_qk == Text::lit("")
                    ? Array<crate::syntax::FnClause>{}
                    : default_clauses(lx_1_3.g, default_qk);
                call_then(start_fn_def_of(lx_1_3, mq, len(clauses) == Nat(0u) ? Array(std::vector{dummy_clause()}) : clauses, sc), [=](crate::lower::model::FnDef fn_def_of_136042) {
                return ({
                    auto fd = fn_def_of_136042;
                    (prism_rtl::finished(({
                    crate::lower::model::FnDef this_ = fd;
                    this_.public_ = len(clauses) > Nat(0u);
                    this_;
                })));
                });
            });
            });
            });
        }));
        });
    })));
    })));
    return crate::lower::model::TraitDef{.name = camel(crate::check::types::bare_name(tr.name)), .methods = methods, .defaults = tr.defaults, .doc = type_doc(lx, crate::check::env::TyInfo{.name = tr.name, .home = tr.home, .params = Array<Text>{}, .body = crate::check::env::TyBody(crate::check::env::TyBody::BOpaque{}), .derives = Array<Text>{}, .file = tr->file, .span = tr.span})};
}


prism_rtl::Turn<crate::lower::model::TraitDef> TraitDefOf::cycle() const {
    const auto& lx0 = this->lx0;
    const auto& tr = this->tr;
    auto lx = in_module(lx0, tr->file, tr.home);
    auto tr_1 = tr;
    return call_value(each_job(tr_1.methods, ({
        auto lx_2 = lx;
        auto tr_1_3 = tr_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::FnDef>(Text)>>(prism_rtl::rc([=](Text p0) {
        return ({
            auto lx_2_3 = lx_2;
            auto tr_1_3_3 = tr_1_3;
            entered(once_job([=]() {
            return ({
                auto mq = p0;
                ({
                auto v_ = or_(crate::prelude::get(lx_2_3.g.vals, mq), crate::check::env::builtin(mq, crate::check::types::mono(crate::check::types::Ty(crate::check::types::Ty::TyErr{}))));
                auto sc = ({
                    crate::check::types::Scheme this_ = v_.scheme;
                    this_.ty = self_in(this_.ty, tr_1_3_3.param);
                    this_.qs = filter(this_.qs, [&](const Text& q) { return q != tr_1_3_3.param; });
                    this_.bounds = filter(this_.bounds, [&](const std::tuple<Text, Text>& _p0) {
                        auto&& q = std::get<0>(_p0);
                        return q != tr_1_3_3.param;
                    });
                    this_;
                });
                auto default_qk = fold(tr_1_3_3.defaults, Text::lit(""), [&](const Text& f, const Text& dq) {
                    return crate::check::types::bare_name(dq) == crate::check::types::bare_name(mq)
                        ? dq
                        : f;
                });
                auto clauses = default_qk == Text::lit("")
                    ? Array<crate::syntax::FnClause>{}
                    : default_clauses(lx_2_3.g, default_qk);
                call_then(start_fn_def_of(lx_2_3, mq, len(clauses) == Nat(0u) ? Array(std::vector{dummy_clause()}) : clauses, sc), [=](crate::lower::model::FnDef fn_def_of_136042) {
                return ({
                    auto fd = fn_def_of_136042;
                    (prism_rtl::finished(({
                    crate::lower::model::FnDef this_ = fd;
                    this_.public_ = len(clauses) > Nat(0u);
                    this_;
                })));
                });
            });
            });
            });
        }));
        });
    })));
    })), [=](Array<crate::lower::model::FnDef> each_135550) {
        return ({
            auto methods = each_135550;
            (prism_rtl::finished(crate::lower::model::TraitDef{.name = camel(crate::check::types::bare_name(tr_1.name)), .methods = methods, .defaults = tr_1.defaults, .doc = type_doc(lx, crate::check::env::TyInfo{.name = tr_1.name, .home = tr_1.home, .params = Array<Text>{}, .body = crate::check::env::TyBody(crate::check::env::TyBody::BOpaque{}), .derives = Array<Text>{}, .file = tr_1->file, .span = tr_1.span})}));
        });
    });
}


/// `Start TraitDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::TraitDef> start_trait_def_of(Lx lx0, crate::check::env::TraitInfo tr) {
    return prism_rtl::make_rc<TraitDefOf>(lx0, tr);
}


/// DefaultClauses: fn G, Text -> [FnClause]
Array<crate::syntax::FnClause> default_clauses(const crate::check::env::G& g, const Text& qk) {
    return fold(g.defs, Array<crate::syntax::FnClause>{}, [&](const Array<crate::syntax::FnClause>& acc, const crate::check::env::Def& d) { return d.qk == qk ? default_of(d, acc) : acc; });
}


/// DefaultOf: fn Def, [FnClause] -> [FnClause]
Array<crate::syntax::FnClause> default_of(const crate::check::env::Def& d, const Array<crate::syntax::FnClause>& other) {
    auto&& _m = d.body;
    if (prism_rtl::is<crate::check::env::DefBody::DbDefault>(_m)) {
        auto&& cs = prism_rtl::as<crate::check::env::DefBody::DbDefault>(_m).a0;
        return cs;
    }
    {
        return other;
    }
}


/// ImplDefOf: unbounded fn Lx, ImplInfo -> ImplDef
crate::lower::model::ImplDef impl_def_of(const Lx& lx, const crate::check::env::ImplInfo& im) {
    auto tr = or_(crate::prelude::get(lx.g.traits, im.cls), dummy_trait_info());
    auto head = out_ty_of(lx, im.head);
    auto defs = filter(lx.g.defs, [&](const crate::check::env::Def& d) { return is_method_of(d, im); });
    auto methods = run_to_end(each_job(defs, ({
        auto tr_1 = tr;
        auto lx_2 = lx;
        auto im_3 = im;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::FnDef>(crate::check::env::Def)>>(prism_rtl::rc([=](crate::check::env::Def p0) {
        return ({
            auto tr_1_4 = tr_1;
            auto lx_2_4 = lx_2;
            auto im_3_4 = im_3;
            entered(once_job([=]() {
            return ({
                auto d = p0;
                ({
                auto mq = fold(tr_1_4.methods, Text::lit(""), [&](const Text& found, const Text& q) { return crate::check::types::bare_name(q) == d.name ? q : found; });
                auto v_ = or_(crate::prelude::get(lx_2_4.g.vals, mq), crate::check::env::builtin(mq, crate::check::types::mono(crate::check::types::Ty(crate::check::types::Ty::TyErr{}))));
                auto sc = ({
                    crate::check::types::Scheme this_ = v_.scheme;
                    this_.ty = instantiated(this_.ty, Array(std::vector{tr_1_4.param}), Array(std::vector{im_3_4.head}));
                    this_.qs = filter(this_.qs, [&](const Text& q) { return q != tr_1_4.param; });
                    this_.bounds = filter(this_.bounds, [&](const std::tuple<Text, Text>& _p0) {
                        auto&& q = std::get<0>(_p0);
                        return q != tr_1_4.param;
                    });
                    this_;
                });
                call_then(start_fn_def_of(lx_2_4, mq, method_clauses(d), sc), [=](crate::lower::model::FnDef fn_def_of_137375) {
                return ({
                    auto fd = fn_def_of_137375;
                    (crate::syntax::lexer::has_prefix(im_3_4.cls, Text::lit("Prelude."))
                    ? prism_rtl::finished(renamed(fd, prism_rtl::cat(snake(d.name), "_", snake(crate::check::types::bare_name(head_name(im_3_4.head))))))
                    : prism_rtl::finished(fd));
                });
            });
            });
            });
        }));
        });
    })));
    })));
    auto generics = each(im.qs, [&](const Text& q) { return std::tuple{camel(q), Array(std::vector{Text::lit("Clone")})}; });
    return crate::lower::model::ImplDef{.cls = im.cls, .tr = path_in(lx, tr.home, camel(crate::check::types::bare_name(im.cls))), .head = head, .generics = generics, .methods = methods, .doc = Text::lit("")};
}


prism_rtl::Turn<crate::lower::model::ImplDef> ImplDefOf::cycle() const {
    const auto& lx = this->lx;
    const auto& im = this->im;
    auto tr = or_(crate::prelude::get(lx.g.traits, im.cls), dummy_trait_info());
    auto im_1 = im;
    auto lx_2 = lx;
    return call_then(start_out_ty_of(lx_2, im_1.head), [=](crate::lower::model::OutTy out_ty_of_136868) {
        return ({
            auto head = out_ty_of_136868;
            auto defs = filter(lx_2.g.defs, [&](const crate::check::env::Def& d) { return is_method_of(d, im_1); });
            call_value(each_job(defs, ({
            auto tr_3 = tr;
            auto lx_2_4 = lx_2;
            auto im_1_4 = im_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::FnDef>(crate::check::env::Def)>>(prism_rtl::rc([=](crate::check::env::Def p0) {
            return ({
                auto tr_3_4 = tr_3;
                auto lx_2_4_4 = lx_2_4;
                auto im_1_4_4 = im_1_4;
                entered(once_job([=]() {
                return ({
                    auto d = p0;
                    ({
                    auto mq = fold(tr_3_4.methods, Text::lit(""), [&](const Text& found, const Text& q) { return crate::check::types::bare_name(q) == d.name ? q : found; });
                    auto v_ = or_(crate::prelude::get(lx_2_4_4.g.vals, mq), crate::check::env::builtin(mq, crate::check::types::mono(crate::check::types::Ty(crate::check::types::Ty::TyErr{}))));
                    auto sc = ({
                        crate::check::types::Scheme this_ = v_.scheme;
                        this_.ty = instantiated(this_.ty, Array(std::vector{tr_3_4.param}), Array(std::vector{im_1_4_4.head}));
                        this_.qs = filter(this_.qs, [&](const Text& q) { return q != tr_3_4.param; });
                        this_.bounds = filter(this_.bounds, [&](const std::tuple<Text, Text>& _p0) {
                            auto&& q = std::get<0>(_p0);
                            return q != tr_3_4.param;
                        });
                        this_;
                    });
                    call_then(start_fn_def_of(lx_2_4_4, mq, method_clauses(d), sc), [=](crate::lower::model::FnDef fn_def_of_137375) {
                    return ({
                        auto fd = fn_def_of_137375;
                        (crate::syntax::lexer::has_prefix(im_1_4_4.cls, Text::lit("Prelude."))
                        ? prism_rtl::finished(renamed(fd, prism_rtl::cat(snake(d.name), "_", snake(crate::check::types::bare_name(head_name(im_1_4_4.head))))))
                        : prism_rtl::finished(fd));
                    });
                });
                });
                });
            }));
            });
        })));
        })), [=](Array<crate::lower::model::FnDef> each_136961) {
            return ({
                auto methods = each_136961;
                auto generics = each(im_1.qs, [&](const Text& q) { return std::tuple{camel(q), Array(std::vector{Text::lit("Clone")})}; });
                (prism_rtl::finished(crate::lower::model::ImplDef{.cls = im_1.cls, .tr = path_in(lx_2, tr.home, camel(crate::check::types::bare_name(im_1.cls))), .head = head, .generics = generics, .methods = methods, .doc = Text::lit("")}));
            });
        });
        });
    });
}


/// `Start ImplDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::ImplDef> start_impl_def_of(Lx lx, crate::check::env::ImplInfo im) {
    return prism_rtl::make_rc<ImplDefOf>(lx, im);
}


/// Renamed: fn FnDef, Text -> FnDef
crate::lower::model::FnDef renamed(const crate::lower::model::FnDef& fd, const Text& n) {
    crate::lower::model::FnDef this_ = fd;
    this_.name = n;
    return this_;
}


/// IsMethodOf: fn Def, ImplInfo -> Bool
bool is_method_of(const crate::check::env::Def& d, const crate::check::env::ImplInfo& im) {
    auto&& _m = d.body;
    if (prism_rtl::is<crate::check::env::DefBody::DbMethod>(_m)) {
        auto&& cls = prism_rtl::as<crate::check::env::DefBody::DbMethod>(_m).a1;
        auto&& other = prism_rtl::as<crate::check::env::DefBody::DbMethod>(_m).a2;
        return ((cls == im.cls) && (other.span == im.span)) && (other->file == im->file);
    }
    {
        return false;
    }
}


/// MethodClauses: fn Def -> [FnClause]
Array<crate::syntax::FnClause> method_clauses(const crate::check::env::Def& d) {
    auto&& _m = d.body;
    if (prism_rtl::is<crate::check::env::DefBody::DbMethod>(_m)) {
        auto&& cs = prism_rtl::as<crate::check::env::DefBody::DbMethod>(_m).a0;
        return cs;
    }
    {
        return Array<crate::syntax::FnClause>{};
    }
}


/// IfGenLine: unbounded fn Wx, Env, Expr, Block, Block, Expr -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> if_gen_line(const crate::lower::node_::Wx& wx, const Env& menv, const crate::syntax::Expr& c, const crate::syntax::Block& then_b, const crate::syntax::Block& else_b, const crate::syntax::Expr& e) {
    auto lx = wx.lx;
    auto pos = wx.pos;
    auto wx1 = ({
        crate::lower::node_::Wx this_ = wx;
        this_.pos = crate::lower::model::next_pos(this_.pos);
        this_;
    });
    auto [name, wx2] = crate::lower::node_::fresh_name(wx1, Text::lit("arm"));
    auto base_ = prism_rtl::cat(wx.node_, camel(name), crate::lower::node_::row_suffix(wx));
    auto yes = crate::lower::node_::gen_row_of(wx2, menv, then_b, crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), prism_rtl::cat(base_, "Then"), name);
    auto no = crate::lower::node_::gen_row_of(yes->parent, menv, else_b, crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), prism_rtl::cat(base_, "Else"), name);
    auto cond = as_bool(value_of(lx, menv, c));
    auto tail_ = append(append(Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XWeak{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})}), crate::lower::node_::hosted_passed(wx)), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})}));
    auto mk_fn = ({
        auto tail__1 = tail_;
        (prism_rtl::rc([=](const crate::lower::model::NodeDef& n) { return crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(try_of(crate::lower::model::Ex(crate::lower::model::Ex::XCall{prism_rtl::cat(n.name, "::build"), append(Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("path")}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("value")})}), tail__1)}))), crate::lower::model::OutTy(crate::lower::model::OutTy::OutObj{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Row"), Array<crate::lower::model::OutTy>{}}))})}); }));
    });
    auto select = crate::lower::model::Ex(crate::lower::model::Ex::XIf{prism_rtl::rc(cond), prism_rtl::rc(mk_fn(yes.node_)), prism_rtl::rc(mk_fn(no.node_))});
    auto wx3 = ({
        crate::lower::node_::Wx this_ = no->parent;
        this_.gens = crate::prelude::push(this_.gens, crate::lower::model::GenDef{.name = name, .pos = pos, .at = crate::lower::node_::place_at(wx, Text::lit("self"), pos), .source = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .value_ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .select = select, .transparent = false, .width = Nat(0u)});
        this_.gen_holds = crate::prelude::push(this_.gen_holds, std::tuple{name, Array<crate::lower::node_::Read>{}});
        this_.rows = append(append(append(crate::prelude::push(this_.rows, yes.node_), yes.node_.children), Array(std::vector{no.node_})), no.node_.children);
        this_.getters = crate::prelude::push(this_.getters, crate::lower::model::MethDef{.name = prism_rtl::cat(name, "_up"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array(std::vector{std::tuple{Text::lit("v"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}}), .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = Array<crate::lower::model::Do>{}, .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = Text::lit("An arm's result, which a building `if` of widgets drops.")});
        this_;
    });
    return std::tuple{wx3, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
}


prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> IfGenLine::cycle() const {
    const auto& wx = this->wx;
    const auto& menv = this->menv;
    const auto& c = this->c;
    const auto& then_b = this->then_b;
    const auto& else_b = this->else_b;
    const auto& e = this->e;
    auto lx = wx.lx;
    auto pos = wx.pos;
    auto wx1 = ({
        crate::lower::node_::Wx this_ = wx;
        this_.pos = crate::lower::model::next_pos(this_.pos);
        this_;
    });
    auto [name, wx2] = crate::lower::node_::fresh_name(wx1, Text::lit("arm"));
    auto base_ = prism_rtl::cat(wx.node_, camel(name), crate::lower::node_::row_suffix(wx));
    auto yes = crate::lower::node_::gen_row_of(wx2, menv, then_b, crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), prism_rtl::cat(base_, "Then"), name);
    auto no = crate::lower::node_::gen_row_of(yes->parent, menv, else_b, crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), prism_rtl::cat(base_, "Else"), name);
    auto c_1 = c;
    auto menv_2 = menv;
    auto wx_3 = wx;
    return call_then(start_value_of(lx, menv_2, c_1), [=](Vl value_of_138841) {
        return ({
            auto cond = as_bool(value_of_138841);
            auto tail_ = append(append(Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XWeak{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})}), crate::lower::node_::hosted_passed(wx_3)), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})}));
            auto mk_fn = ({
                auto tail__4 = tail_;
                (prism_rtl::rc([=](const crate::lower::model::NodeDef& n) { return crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(try_of(crate::lower::model::Ex(crate::lower::model::Ex::XCall{prism_rtl::cat(n.name, "::build"), append(Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("path")}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("value")})}), tail__4)}))), crate::lower::model::OutTy(crate::lower::model::OutTy::OutObj{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Row"), Array<crate::lower::model::OutTy>{}}))})}); }));
            });
            auto select = crate::lower::model::Ex(crate::lower::model::Ex::XIf{prism_rtl::rc(cond), prism_rtl::rc(mk_fn(yes.node_)), prism_rtl::rc(mk_fn(no.node_))});
            auto wx3 = ({
                crate::lower::node_::Wx this_ = no->parent;
                this_.gens = crate::prelude::push(this_.gens, crate::lower::model::GenDef{.name = name, .pos = pos, .at = crate::lower::node_::place_at(wx_3, Text::lit("self"), pos), .source = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .value_ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .select = select, .transparent = false, .width = Nat(0u)});
                this_.gen_holds = crate::prelude::push(this_.gen_holds, std::tuple{name, Array<crate::lower::node_::Read>{}});
                this_.rows = append(append(append(crate::prelude::push(this_.rows, yes.node_), yes.node_.children), Array(std::vector{no.node_})), no.node_.children);
                this_.getters = crate::prelude::push(this_.getters, crate::lower::model::MethDef{.name = prism_rtl::cat(name, "_up"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array(std::vector{std::tuple{Text::lit("v"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}}), .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = Array<crate::lower::model::Do>{}, .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = Text::lit("An arm's result, which a building `if` of widgets drops.")});
                this_;
            });
            (prism_rtl::finished(std::tuple{wx3, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})}));
        });
    });
}


/// `Start IfGenLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> start_if_gen_line(crate::lower::node_::Wx wx, Env menv, crate::syntax::Expr c, crate::syntax::Block then_b, crate::syntax::Block else_b, crate::syntax::Expr e) {
    return prism_rtl::make_rc<IfGenLine>(wx, menv, c, then_b, else_b, e);
}


/// Tail: unbounded fn Lx, Env, Expr -> Ex
crate::lower::model::Ex tail(const Lx& lx, const Env& env, const crate::syntax::Expr& e) {
    auto&& _m = frame_call(lx, env, e, true);
    if (prism_rtl::is_some(_m)) {
        auto&& c = prism_rtl::some_of(_m);
        return frame(lx, env, c, rest_text(lx, e.span, c.span, e.span), ({
            auto lx_1 = lx;
            auto e_2 = e;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Env)>>(prism_rtl::rc([=](Env p0) {
            return ({
                auto lx_1_3 = lx_1;
                auto e_2_3 = e_2;
                entered(once_job([=]() {
                return ({
                    auto env2 = p0;
                    (prism_rtl::more(prism_rtl::rc(Tail(lx_1_3, env2, e_2_3))));
                });
            }));
            });
        })));
        }));
    }
    if (prism_rtl::is_none(_m)) {
        return tail_here(lx, env, e);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::model::Ex> Tail::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    auto e_1 = e;
    auto env_2 = env;
    auto lx_3 = lx;
    return call_then(start_frame_call(lx_3, env_2, e_1, true), [=](std::optional<crate::syntax::Expr> frame_call_140748) {
        return ({
            prism_rtl::is_some(frame_call_140748) ? ({
            auto&& c = prism_rtl::some_of(frame_call_140748);
            prism_rtl::more(prism_rtl::rc(Frame(lx_3, env_2, c, rest_text(lx_3, e_1.span, c.span, e_1.span), ({
            auto lx_3_4 = lx_3;
            auto e_1_4 = e_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Env)>>(prism_rtl::rc([=](Env p0) {
            return ({
                auto lx_3_4_4 = lx_3_4;
                auto e_1_4_4 = e_1_4;
                entered(once_job([=]() {
                return ({
                    auto env2 = p0;
                    (prism_rtl::more(prism_rtl::rc(Tail(lx_3_4_4, env2, e_1_4_4))));
                });
            }));
            });
        })));
        }))));
        })
            : prism_rtl::is_none(frame_call_140748) ? prism_rtl::more(prism_rtl::rc(TailHere(lx_3, env_2, e_1)))
            : throw prism_rtl::Panic("no arm matched");
        });
    });
}


/// `Start Tail, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_tail(Lx lx, Env env, crate::syntax::Expr e) {
    return prism_rtl::make_rc<Tail>(lx, env, e);
}


/// TailHere: unbounded fn Lx, Env, Expr -> Ex
crate::lower::model::Ex tail_here(const Lx& lx, const Env& env, const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return tail(lx, env, x);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m)) {
        auto&& target = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
        return has_top_while(lx, b)
            ? upd_tail(lx, env, target, b, e.span, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<Env, crate::lower::model::Ex> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return once_job([=]() {
                return ({
                    auto en = p0;
                    auto v_ = p1;
                    (prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{v_})})));
                });
            });
        })))
            : crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{own(value_of(lx, env, e))})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        return tail_match(lx, env, s, arms, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2)) {
        auto&& m140966_3_0 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
        if (prism_rtl::is<crate::syntax::Cond::CondExpr>(m140966_3_0)) {
            auto&& c = prism_rtl::as<crate::syntax::Cond::CondExpr>(m140966_3_0).a0;
            return crate::lower::model::Ex(crate::lower::model::Ex::XIf{prism_rtl::rc(as_bool(value_of(lx, env, c))), prism_rtl::rc(tail_block(lx, env, then_b)), prism_rtl::rc(tail_block(lx, env, else_b))});
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& callee = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        auto&& _m = tail_callee(lx, env, callee);
        if (prism_rtl::is_some(_m)) {
            auto&& qk = prism_rtl::some_of(_m);
            auto job = or_(crate::prelude::get(lx.rs_names, qk), snake(crate::check::types::bare_name(qk)));
            auto job_name = path_in(lx, owner_of(qk), camel(crate::check::types::bare_name(qk)));
            auto&& _ptys = scheme_parts(lx, qk);
            auto&& ptys = std::get<0>(_ptys);
            auto fields = job_field_names(lx, qk);
            auto vals = named_args_owned(lx, env, qk, args);
            return enters_at_once(lx, qk, args)
                ? crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{path_in(lx, owner_of(qk), prism_rtl::cat("start_", job)), vals})), Text::lit("cycle"), Array<crate::lower::model::Ex>{}})
                : is_color_poly(lx, qk)
                ? crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::More"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{path_in(lx, owner_of(qk), prism_rtl::cat("start_", job)), vals})})})
                : crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::More"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRecord{job_name, each(crate::check::errors::range0(len(vals)), [&](const Nat& i) { return std::tuple{or_(index(fields, i), Text::lit("arg")), or_(index(vals, i), crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}))}; })})})})})});
        }
        if (prism_rtl::is_none(_m)) {
            auto&& _m = local_job_fn(lx, env, callee);
            if (prism_rtl::is_some(_m)) {
                auto&& f = prism_rtl::some_of(_m);
                return crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(start_call(f, start_args(lx, env, f, args))), Text::lit("cycle"), Array<crate::lower::model::Ex>{}});
            }
            if (prism_rtl::is_none(_m)) {
                auto&& _m = prelude_job_call(lx, env, e);
                if (prism_rtl::is_some(_m)) {
                    auto&& job = prism_rtl::some_of(_m);
                    return crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(job), Text::lit("cycle"), Array<crate::lower::model::Ex>{}});
                }
                if (prism_rtl::is_none(_m)) {
                    return crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{own(value_of(lx, env, e))})});
                }
                prism_rtl::unreachable("no arm matched");
            }
            prism_rtl::unreachable("no arm matched");
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        return crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{own(value_of(lx, env, e))})});
    }
}


prism_rtl::Turn<crate::lower::model::Ex> TailHere::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(Tail(lx, env, x)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m) ? ({
        auto&& target = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
        has_top_while(lx, b)
        ? prism_rtl::more(prism_rtl::rc(UpdTail(lx, env, target, b, e.span, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<Env, crate::lower::model::Ex> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return once_job([=]() {
            return ({
                auto en = p0;
                auto v_ = p1;
                (prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{v_})})));
            });
        });
    })))))
        : ({
        auto e_1 = e;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(start_value_of(lx_3, env_2, e_1), [=](Vl value_of_141205) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{own(value_of_141205)})})); });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
        auto&& s = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        prism_rtl::more(prism_rtl::rc(TailMatch(lx, env, s, arms, e.span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2) && ({
        auto&& m140966_3_0 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
        prism_rtl::is<crate::syntax::Cond::CondExpr>(m140966_3_0);
    }) ? ({
        auto&& m140966_3_0 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
        auto&& c = prism_rtl::as<crate::syntax::Cond::CondExpr>(m140966_3_0).a0;
        ({
        auto c_1 = c;
        auto else_b_2 = else_b;
        auto env_3 = env;
        auto lx_4 = lx;
        auto then_b_5 = then_b;
        call_then(start_value_of(lx_4, env_3, c_1), [=](Vl value_of_141335) { return call_then(start_tail_block(lx_4, env_3, then_b_5), [=](crate::lower::model::Ex tail_block_141358) { return call_then(start_tail_block(lx_4, env_3, else_b_2), [=](crate::lower::model::Ex tail_block_141386) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XIf{prism_rtl::rc(as_bool(value_of_141335)), prism_rtl::rc(tail_block_141358), prism_rtl::rc(tail_block_141386)})); }); }); });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::ECall>(_m) ? ({
        auto&& callee = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        ({
        auto&& _m = tail_callee(lx, env, callee);
        prism_rtl::is_some(_m) ? ({
        auto&& qk = prism_rtl::some_of(_m);
        ({
        auto job = or_(crate::prelude::get(lx.rs_names, qk), snake(crate::check::types::bare_name(qk)));
        auto job_name = path_in(lx, owner_of(qk), camel(crate::check::types::bare_name(qk)));
        auto&& _ptys = scheme_parts(lx, qk);
        auto&& ptys = std::get<0>(_ptys);
        auto args_1 = args;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(start_job_field_names(lx_3, qk), [=](Array<Text> job_field_names_141716) {
        return ({
            auto fields = job_field_names_141716;
            call_then(start_named_args_owned(lx_3, env_2, qk, args_1), [=](Array<crate::lower::model::Ex> named_args_owned_141760) {
            return ({
                auto vals = named_args_owned_141760;
                enters_at_once(lx_3, qk, args_1)
                ? prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{path_in(lx_3, owner_of(qk), prism_rtl::cat("start_", job)), vals})), Text::lit("cycle"), Array<crate::lower::model::Ex>{}}))
                : is_color_poly(lx_3, qk)
                ? prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::More"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{path_in(lx_3, owner_of(qk), prism_rtl::cat("start_", job)), vals})})}))
                : prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::More"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRecord{job_name, each(crate::check::errors::range0(len(vals)), [&](const Nat& i) { return std::tuple{or_(index(fields, i), Text::lit("arg")), or_(index(vals, i), crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}))}; })})})})})}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto args_1 = args;
        auto callee_2 = callee;
        auto e_3 = e;
        auto env_4 = env;
        auto lx_5 = lx;
        call_then(start_local_job_fn(lx_5, env_4, callee_2), [=](std::optional<Vl> local_job_fn_142240) {
        return ({
            prism_rtl::is_some(local_job_fn_142240) ? ({
            auto&& f = prism_rtl::some_of(local_job_fn_142240);
            call_then(start_start_args(lx_5, env_4, f, args_1), [=](Array<crate::lower::model::Ex> start_args_142309) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(start_call(f, start_args_142309)), Text::lit("cycle"), Array<crate::lower::model::Ex>{}})); });
        })
            : prism_rtl::is_none(local_job_fn_142240) ? call_then(start_prelude_job_call(lx_5, env_4, e_3), [=](std::optional<crate::lower::model::Ex> prelude_job_call_142376) {
            return ({
                prism_rtl::is_some(prelude_job_call_142376) ? ({
                auto&& job = prism_rtl::some_of(prelude_job_call_142376);
                prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(job), Text::lit("cycle"), Array<crate::lower::model::Ex>{}}));
            })
                : prism_rtl::is_none(prelude_job_call_142376) ? call_then(start_value_of(lx_5, env_4, e_3), [=](Vl value_of_142517) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{own(value_of_142517)})})); })
                : throw prism_rtl::Panic("no arm matched");
            });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : ({
        auto e_1 = e;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(start_value_of(lx_3, env_2, e_1), [=](Vl value_of_142596) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{own(value_of_142596)})})); });
    });
    });
}


/// `Start TailHere, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_tail_here(Lx lx, Env env, crate::syntax::Expr e) {
    return prism_rtl::make_rc<TailHere>(lx, env, e);
}


/// TailBlock: unbounded fn Lx, Env, Block -> Ex
crate::lower::model::Ex tail_block(const Lx& lx, const Env& env, const crate::syntax::Block& b) {
    return tail_from(lx, env, b, Nat(0u));
}


prism_rtl::Turn<crate::lower::model::Ex> TailBlock::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& b = this->b;
    return prism_rtl::more(prism_rtl::rc(TailFrom(lx, env, b, Nat(0u))));
}


/// `Start TailBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_tail_block(Lx lx, Env env, crate::syntax::Block b) {
    return prism_rtl::make_rc<TailBlock>(lx, env, b);
}


/// TailFrom: unbounded fn Lx, Env, Block, Nat -> Ex
crate::lower::model::Ex tail_from(const Lx& lx, const Env& env, const crate::syntax::Block& b, const Nat& i) {
    auto s = or_(index(b.stmts, i), dummy_stmt_l());
    return (i + Nat(1u)) >= len(b.stmts)
        ? ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Ex> _v;
        auto&& _m = s.kind;
        if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
            auto&& x = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
            _v.set(tail(lx, env, x));
            goto _done;
        }
        {
            _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})})}));
            goto _done;
        }
    _done:
        _v.take();
    })
        : ({
        auto found_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
            auto&& _m = s.kind;
            if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
                auto&& x = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
                _v.set(frame_call(lx, env, x, false));
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
                auto&& x = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                _v.set(frame_call(lx, env, x, false));
                goto _done;
            }
            {
                _v.set(std::optional<crate::syntax::Expr>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto looping_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<std::tuple<crate::syntax::Pattern_, crate::syntax::Expr, crate::syntax::Block, crate::syntax::Expr>>> _v;
            auto&& _m = s.kind;
            if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
                auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
                auto&& x = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<std::optional<std::tuple<crate::syntax::Pattern_, crate::syntax::Expr, crate::syntax::Block, crate::syntax::Expr>>> _v;
                    auto&& _m = x.kind;
                    if (prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m)) {
                        auto&& target = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
                        auto&& ub = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
                        _v.set(has_top_while(lx, ub)
                            ? std::optional(std::tuple{p_, target, ub, x})
                            : std::optional<std::tuple<crate::syntax::Pattern_, crate::syntax::Expr, crate::syntax::Block, crate::syntax::Expr>>{});
                        goto _done;
                    }
                    {
                        _v.set(std::optional<std::tuple<crate::syntax::Pattern_, crate::syntax::Expr, crate::syntax::Block, crate::syntax::Expr>>{});
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(std::optional<std::tuple<crate::syntax::Pattern_, crate::syntax::Expr, crate::syntax::Block, crate::syntax::Expr>>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Ex> _v;
        if (prism_rtl::is_some(looping_opt)) {
            auto&& p_ = std::get<0>(prism_rtl::some_of(looping_opt));
            auto&& target = std::get<1>(prism_rtl::some_of(looping_opt));
            auto&& ub = std::get<2>(prism_rtl::some_of(looping_opt));
            auto&& x = std::get<3>(prism_rtl::some_of(looping_opt));
            _v.set(upd_tail(lx, env, target, ub, b.span, ({
                auto lx_1 = lx;
                auto p__2 = p_;
                auto x_3 = x;
                auto s_4 = s;
                auto b_5 = b;
                auto i_6 = i;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<Env, crate::lower::model::Ex> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto lx_1_7 = lx_1;
                    auto p__2_7 = p__2;
                    auto x_3_7 = x_3;
                    auto s_4_7 = s_4;
                    auto b_5_7 = b_5;
                    auto i_6_7 = i_6;
                    entered(once_job([=]() {
                    return ({
                        auto en = p0;
                        auto v_ = p1;
                        call_then(start_rust_pat(lx_1_7, p__2_7, type_at(lx_1_7, x_3_7.span), Holding(Holding::Owned{}), prism_rtl::cat("l", s_4_7.span.start)), [=](PatOut rust_pat_143719) {
                        return ({
                            auto po = rust_pat_143719;
                            call_then(start_tail_from(lx_1_7, bind_all(en, po.binds), b_5_7, i_6_7 + Nat(1u)), [=](crate::lower::model::Ex tail_from_143811) {
                            return ({
                                auto rest = tail_from_143811;
                                (prism_rtl::finished(prepend(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{po.pa, v_})}), rest)));
                            });
                        });
                        });
                    });
                    });
                }));
                });
            })));
            })));
            goto _done;
        }
        if (prism_rtl::is_none(looping_opt)) {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<crate::lower::model::Ex> _v;
                if (prism_rtl::is_some(found_opt)) {
                    auto&& c = prism_rtl::some_of(found_opt);
                    _v.set(frame(lx, env, c, rest_text(lx, s.span, c.span, b.span), ({
                        auto lx_1 = lx;
                        auto b_2 = b;
                        auto i_3 = i;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Env)>>(prism_rtl::rc([=](Env p0) {
                        return ({
                            auto lx_1_4 = lx_1;
                            auto b_2_4 = b_2;
                            auto i_3_4 = i_3;
                            entered(once_job([=]() {
                            return ({
                                auto env2 = p0;
                                (prism_rtl::more(prism_rtl::rc(TailFrom(lx_1_4, env2, b_2_4, i_3_4))));
                            });
                        }));
                        });
                    })));
                    })));
                    goto _done;
                }
                if (prism_rtl::is_none(found_opt)) {
                    _v.set(({
                        auto [dos, env2] = block_stmt(lx, env, s);
                        ({
                        __label__ _done;
                        prism_rtl::Slot<crate::lower::model::Ex> _v;
                        auto&& _m = tail_from(lx, env2, b, i + Nat(1u));
                        if (prism_rtl::is<crate::lower::model::Ex::XBlock>(_m)) {
                            auto&& more = prism_rtl::as<crate::lower::model::Ex::XBlock>(_m).a0;
                            auto&& last = prism_rtl::as<crate::lower::model::Ex::XBlock>(_m).a1;
                            _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XBlock{append(dos, more), prism_rtl::rc(last)}));
                            goto _done;
                        }
                        {
                            auto&& last = _m;
                            _v.set(len(dos) == Nat(0u)
                                ? last
                                : crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos, prism_rtl::rc(last)}));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    });
}


prism_rtl::Turn<crate::lower::model::Ex> TailFrom::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& b = this->b;
    const auto& i = this->i;
    auto s = or_(index(b.stmts, i), dummy_stmt_l());
    return (i + Nat(1u)) >= len(b.stmts)
        ? ({
        auto&& _m = s.kind;
        prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        prism_rtl::more(prism_rtl::rc(Tail(lx, env, x)));
    })
        : prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})})}));
    })
        : ({
        auto found_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
            auto&& _m = s.kind;
            if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
                auto&& x = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
                _v.set(frame_call(lx, env, x, false));
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
                auto&& x = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                _v.set(frame_call(lx, env, x, false));
                goto _done;
            }
            {
                _v.set(std::optional<crate::syntax::Expr>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto looping_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<std::tuple<crate::syntax::Pattern_, crate::syntax::Expr, crate::syntax::Block, crate::syntax::Expr>>> _v;
            auto&& _m = s.kind;
            if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
                auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
                auto&& x = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<std::optional<std::tuple<crate::syntax::Pattern_, crate::syntax::Expr, crate::syntax::Block, crate::syntax::Expr>>> _v;
                    auto&& _m = x.kind;
                    if (prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m)) {
                        auto&& target = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
                        auto&& ub = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
                        _v.set(has_top_while(lx, ub)
                            ? std::optional(std::tuple{p_, target, ub, x})
                            : std::optional<std::tuple<crate::syntax::Pattern_, crate::syntax::Expr, crate::syntax::Block, crate::syntax::Expr>>{});
                        goto _done;
                    }
                    {
                        _v.set(std::optional<std::tuple<crate::syntax::Pattern_, crate::syntax::Expr, crate::syntax::Block, crate::syntax::Expr>>{});
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(std::optional<std::tuple<crate::syntax::Pattern_, crate::syntax::Expr, crate::syntax::Block, crate::syntax::Expr>>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        ({
        prism_rtl::is_some(looping_opt) ? ({
        auto&& p_ = std::get<0>(prism_rtl::some_of(looping_opt));
        auto&& target = std::get<1>(prism_rtl::some_of(looping_opt));
        auto&& ub = std::get<2>(prism_rtl::some_of(looping_opt));
        auto&& x = std::get<3>(prism_rtl::some_of(looping_opt));
        prism_rtl::more(prism_rtl::rc(UpdTail(lx, env, target, ub, b.span, ({
        auto lx_1 = lx;
        auto p__2 = p_;
        auto x_3 = x;
        auto s_4 = s;
        auto b_5 = b;
        auto i_6 = i;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<Env, crate::lower::model::Ex> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_7 = lx_1;
            auto p__2_7 = p__2;
            auto x_3_7 = x_3;
            auto s_4_7 = s_4;
            auto b_5_7 = b_5;
            auto i_6_7 = i_6;
            entered(once_job([=]() {
            return ({
                auto en = p0;
                auto v_ = p1;
                call_then(start_rust_pat(lx_1_7, p__2_7, type_at(lx_1_7, x_3_7.span), Holding(Holding::Owned{}), prism_rtl::cat("l", s_4_7.span.start)), [=](PatOut rust_pat_143719) {
                return ({
                    auto po = rust_pat_143719;
                    call_then(start_tail_from(lx_1_7, bind_all(en, po.binds), b_5_7, i_6_7 + Nat(1u)), [=](crate::lower::model::Ex tail_from_143811) {
                    return ({
                        auto rest = tail_from_143811;
                        (prism_rtl::finished(prepend(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{po.pa, v_})}), rest)));
                    });
                });
                });
            });
            });
        }));
        });
    })));
    }))));
    })
        : prism_rtl::is_none(looping_opt) ? ({
        prism_rtl::is_some(found_opt) ? ({
        auto&& c = prism_rtl::some_of(found_opt);
        prism_rtl::more(prism_rtl::rc(Frame(lx, env, c, rest_text(lx, s.span, c.span, b.span), ({
        auto lx_1 = lx;
        auto b_2 = b;
        auto i_3 = i;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Env)>>(prism_rtl::rc([=](Env p0) {
        return ({
            auto lx_1_4 = lx_1;
            auto b_2_4 = b_2;
            auto i_3_4 = i_3;
            entered(once_job([=]() {
            return ({
                auto env2 = p0;
                (prism_rtl::more(prism_rtl::rc(TailFrom(lx_1_4, env2, b_2_4, i_3_4))));
            });
        }));
        });
    })));
    }))));
    })
        : prism_rtl::is_none(found_opt) ? ({
        auto b_1 = b;
        auto env_2 = env;
        auto i_3 = i;
        auto lx_4 = lx;
        call_then(start_block_stmt(lx_4, env_2, s), [=](std::tuple<Array<crate::lower::model::Do>, Env> block_stmt_144114) {
        return ({
            auto [dos, env2] = block_stmt_144114;
            call_then(start_tail_from(lx_4, env2, b_1, i_3 + Nat(1u)), [=](crate::lower::model::Ex tail_from_144161) {
            return ({
                prism_rtl::is<crate::lower::model::Ex::XBlock>(tail_from_144161) ? ({
                auto&& more = prism_rtl::as<crate::lower::model::Ex::XBlock>(tail_from_144161).a0;
                auto&& last = prism_rtl::as<crate::lower::model::Ex::XBlock>(tail_from_144161).a1;
                prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XBlock{append(dos, more), prism_rtl::rc(last)}));
            })
                : ({
                auto&& last = tail_from_144161;
                len(dos) == Nat(0u)
                ? prism_rtl::finished(last)
                : prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos, prism_rtl::rc(last)}));
            });
            });
        });
        });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    });
}


/// `Start TailFrom, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_tail_from(Lx lx, Env env, crate::syntax::Block b, Nat i) {
    return prism_rtl::make_rc<TailFrom>(lx, env, b, i);
}


/// HasTopWhile: fn Lx, Block -> Bool
bool has_top_while(const Lx& lx, const crate::syntax::Block& b) {
    return fold(b.stmts, false, [&](const bool& f, const crate::syntax::Stmt& st) { return (f || is_cycle_while(lx, st)) || holds_cycle_while(lx, st); });
}


/// IsCycleWhile: fn Lx, Stmt -> Bool
bool is_cycle_while(const Lx& lx, const crate::syntax::Stmt& st) {
    auto&& _m = st.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m)) {
        return crate::check::env::has_key(lx.unshrunk, place_key(lx, st.span));
    }
    {
        return false;
    }
}


/// ElseHasTopWhile: fn Lx, ?Block -> Bool
bool else_has_top_while(const Lx& lx, const std::optional<crate::syntax::Block>& opt1) {
    if (prism_rtl::is_some(opt1)) {
        auto&& b = prism_rtl::some_of(opt1);
        return has_top_while(lx, b);
    }
    if (prism_rtl::is_none(opt1)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// HoldsCycleWhile: fn Lx, Stmt -> Bool
bool holds_cycle_while(const Lx& lx, const crate::syntax::Stmt& st) {
    auto&& _m = st.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m)) {
        auto&& wb = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
        return has_top_while(lx, wb);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        auto&& _m = x.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
            auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
            auto&& else_b_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
            return has_top_while(lx, then_b) || else_has_top_while(lx, else_b_opt);
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
            auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
            return fold(arms, false, [&](const bool& f, const crate::syntax::Arm& a) { return f || has_top_while(lx, a.body); });
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EFor>(_m)) {
            auto&& fb = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
            return has_top_while(lx, fb);
        }
        {
            return false;
        }
    }
    {
        return false;
    }
}


/// UpdTail: unbounded fn Lx, Env, Expr, Block, Range, (unbounded fn Env, Ex -> Ex) -> Ex
crate::lower::model::Ex upd_tail(const Lx& lx, const Env& env, const crate::syntax::Expr& target, const crate::syntax::Block& b, const crate::syntax::Range& to, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, crate::lower::model::Ex>)>& cont_fn) {
    auto t = out_ty_of(lx, peel(type_at(lx, target.span)));
    auto tv = value_of(lx, env, target);
    auto env1 = bind(env, Text::lit("&_"), Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("this")}), Holding(Holding::Owned{}), t}));
    return prepend(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("this")})), t}), own(tv)})}), upd_tail_from(lx, env, env1, b, Nat(0u), to, cont_fn));
}


prism_rtl::Turn<crate::lower::model::Ex> UpdTail::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& target = this->target;
    const auto& b = this->b;
    const auto& to = this->to;
    const auto& cont_fn = this->cont_fn;
    auto cont_fn_1 = cont_fn;
    auto b_2 = b;
    auto env_3 = env;
    auto lx_4 = lx;
    auto target_5 = target;
    auto to_6 = to;
    return call_then(start_out_ty_of(lx_4, peel(type_at(lx_4, target_5.span))), [=](crate::lower::model::OutTy out_ty_of_146719) {
        return ({
            auto t = out_ty_of_146719;
            call_then(start_value_of(lx_4, env_3, target_5), [=](Vl value_of_146776) {
            return ({
                auto tv = value_of_146776;
                auto env1 = bind(env_3, Text::lit("&_"), Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("this")}), Holding(Holding::Owned{}), t}));
                call_then(start_upd_tail_from(lx_4, env_3, env1, b_2, Nat(0u), to_6, cont_fn_1), [=](crate::lower::model::Ex upd_tail_from_146929) { return prism_rtl::finished(prepend(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("this")})), t}), own(tv)})}), upd_tail_from_146929)); });
            });
        });
        });
    });
}


/// `Start UpdTail, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_upd_tail(Lx lx, Env env, crate::syntax::Expr target, crate::syntax::Block b, crate::syntax::Range to, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, crate::lower::model::Ex>)> cont_fn) {
    return prism_rtl::make_rc<UpdTail>(lx, env, target, b, to, cont_fn);
}


/// UpdTailFrom: unbounded fn Lx, Env, Env, Block, Nat, Range, (unbounded fn Env, Ex -> Ex) -> Ex
crate::lower::model::Ex upd_tail_from(const Lx& lx, const Env& outer, const Env& env, const crate::syntax::Block& b, const Nat& i, const crate::syntax::Range& to, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, crate::lower::model::Ex>)>& cont_fn) {
    return i >= len(b.stmts)
        ? run_to_end(cont_fn(std::tuple{outer, crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("this")})}))
        : ({
        auto s = or_(index(b.stmts, i), dummy_stmt_l());
        auto rest = rest_text(lx, crate::syntax::Range{.start = s.span.end, .end = s.span.end}, crate::syntax::Range{.start = s.span.end, .end = s.span.end}, to);
        auto next_fn = ({
            auto lx_1 = lx;
            auto b_2 = b;
            auto i_3 = i;
            auto to_4 = to;
            auto cont_fn_5 = cont_fn;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, Env>)>>(prism_rtl::rc([=](std::tuple<Env, Env> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_1_6 = lx_1;
                auto b_2_6 = b_2;
                auto i_3_6 = i_3;
                auto to_4_6 = to_4;
                auto cont_fn_5_6 = cont_fn_5;
                entered(once_job([=]() {
                return ({
                    auto o2 = p0;
                    auto e2 = p1;
                    (prism_rtl::more(prism_rtl::rc(UpdTailFrom(lx_1_6, o2, e2, b_2_6, i_3_6 + Nat(1u), to_4_6, cont_fn_5_6))));
                });
            }));
            });
        })));
        });
        is_cycle_while(lx, s) || holds_cycle_while(lx, s)
        ? stmt_job(lx, outer, env, s, rest, next_fn)
        : ({
        auto [dos, env2] = upd_stmt(lx, env, s);
        prepend(dos, upd_tail_from(lx, outer, env2, b, i + Nat(1u), to, cont_fn));
    });
    });
}


prism_rtl::Turn<crate::lower::model::Ex> UpdTailFrom::cycle() const {
    const auto& lx = this->lx;
    const auto& outer = this->outer;
    const auto& env = this->env;
    const auto& b = this->b;
    const auto& i = this->i;
    const auto& to = this->to;
    const auto& cont_fn = this->cont_fn;
    return i >= len(b.stmts)
        ? cont_fn(std::tuple{outer, crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("this")})})->cycle()
        : ({
        auto s = or_(index(b.stmts, i), dummy_stmt_l());
        auto rest = rest_text(lx, crate::syntax::Range{.start = s.span.end, .end = s.span.end}, crate::syntax::Range{.start = s.span.end, .end = s.span.end}, to);
        auto next_fn = ({
            auto lx_1 = lx;
            auto b_2 = b;
            auto i_3 = i;
            auto to_4 = to;
            auto cont_fn_5 = cont_fn;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, Env>)>>(prism_rtl::rc([=](std::tuple<Env, Env> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_1_6 = lx_1;
                auto b_2_6 = b_2;
                auto i_3_6 = i_3;
                auto to_4_6 = to_4;
                auto cont_fn_5_6 = cont_fn_5;
                entered(once_job([=]() {
                return ({
                    auto o2 = p0;
                    auto e2 = p1;
                    (prism_rtl::more(prism_rtl::rc(UpdTailFrom(lx_1_6, o2, e2, b_2_6, i_3_6 + Nat(1u), to_4_6, cont_fn_5_6))));
                });
            }));
            });
        })));
        });
        is_cycle_while(lx, s) || holds_cycle_while(lx, s)
        ? prism_rtl::more(prism_rtl::rc(StmtJob(lx, outer, env, s, rest, next_fn)))
        : ({
        auto cont_fn_1 = cont_fn;
        auto b_2 = b;
        auto env_3 = env;
        auto i_4 = i;
        auto lx_5 = lx;
        auto outer_6 = outer;
        auto to_7 = to;
        call_then(start_upd_stmt(lx_5, env_3, s), [=](std::tuple<Array<crate::lower::model::Do>, Env> upd_stmt_147556) {
        return ({
            auto [dos, env2] = upd_stmt_147556;
            call_then(start_upd_tail_from(lx_5, outer_6, env2, b_2, i_4 + Nat(1u), to_7, cont_fn_1), [=](crate::lower::model::Ex upd_tail_from_147601) { return prism_rtl::finished(prepend(dos, upd_tail_from_147601)); });
        });
    });
    });
    });
}


/// `Start UpdTailFrom, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_upd_tail_from(Lx lx, Env outer, Env env, crate::syntax::Block b, Nat i, crate::syntax::Range to, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, crate::lower::model::Ex>)> cont_fn) {
    return prism_rtl::make_rc<UpdTailFrom>(lx, outer, env, b, i, to, cont_fn);
}


/// StmtJob: unbounded fn Lx, Env, Env, Stmt, Text, (unbounded fn Env, Env -> Ex) -> Ex
crate::lower::model::Ex stmt_job(const Lx& lx, const Env& outer, const Env& env, const crate::syntax::Stmt& s, const Text& rest, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, Env>)>& cont_fn) {
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
        auto&& wb = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
        return while_job(lx, outer, env, c, wb, s.span, rest, cont_fn);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        auto&& _m = x.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
            auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
            auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
            auto&& else_b_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
            return if_job(lx, outer, env, c, then_b, else_b_opt, s.span, rest, cont_fn);
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
            auto&& scrut = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
            auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
            return match_job(lx, outer, env, scrut, arms, s.span, rest, cont_fn);
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EFor>(_m)) {
            auto&& binders_opt = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
            auto&& source = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
            auto&& body = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
            auto&& _m = ref_binder(binders_opt);
            if (prism_rtl::is_some(_m)) {
                return refusal(Text::lit("a cycle-point `while` in a `for &` of an `update` block, whose references a job cannot keep (gap LP)"));
            }
            if (prism_rtl::is_none(_m)) {
                return for_job(lx, outer, env, binders_opt, source, body, s.span, rest, cont_fn);
            }
            prism_rtl::unreachable("no arm matched");
        }
        {
            return refusal(prism_rtl::cat("a cycle-point `while` in ", kind_words(x.kind), " (gap LP)"));
        }
    }
    {
        return refusal(Text::lit("a cycle-point `while` in this statement (gap LP)"));
    }
}


prism_rtl::Turn<crate::lower::model::Ex> StmtJob::cycle() const {
    const auto& lx = this->lx;
    const auto& outer = this->outer;
    const auto& env = this->env;
    const auto& s = this->s;
    const auto& rest = this->rest;
    const auto& cont_fn = this->cont_fn;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
        auto&& wb = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
        prism_rtl::more(prism_rtl::rc(WhileJob(lx, outer, env, c, wb, s.span, rest, cont_fn)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        ({
        auto&& _m = x.kind;
        prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        prism_rtl::more(prism_rtl::rc(IfJob(lx, outer, env, c, then_b, else_b_opt, s.span, rest, cont_fn)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
        auto&& scrut = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        prism_rtl::more(prism_rtl::rc(MatchJob(lx, outer, env, scrut, arms, s.span, rest, cont_fn)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EFor>(_m) ? ({
        auto&& binders_opt = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
        auto&& source = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
        ({
        auto&& _m = ref_binder(binders_opt);
        prism_rtl::is_some(_m) ? prism_rtl::finished(refusal(Text::lit("a cycle-point `while` in a `for &` of an `update` block, whose references a job cannot keep (gap LP)")))
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(ForJob(lx, outer, env, binders_opt, source, body, s.span, rest, cont_fn)))
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::finished(refusal(prism_rtl::cat("a cycle-point `while` in ", kind_words(x.kind), " (gap LP)")));
    });
    })
        : prism_rtl::finished(refusal(Text::lit("a cycle-point `while` in this statement (gap LP)")));
    });
}


/// `Start StmtJob, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_stmt_job(Lx lx, Env outer, Env env, crate::syntax::Stmt s, Text rest, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, Env>)> cont_fn) {
    return prism_rtl::make_rc<StmtJob>(lx, outer, env, s, rest, cont_fn);
}


/// Prepend: fn [Do], Ex -> Ex
crate::lower::model::Ex prepend(const Array<crate::lower::model::Do>& dos, const crate::lower::model::Ex& ex1) {
    if (prism_rtl::is<crate::lower::model::Ex::XBlock>(ex1)) {
        auto&& more = prism_rtl::as<crate::lower::model::Ex::XBlock>(ex1).a0;
        auto&& last = prism_rtl::as<crate::lower::model::Ex::XBlock>(ex1).a1;
        return crate::lower::model::Ex(crate::lower::model::Ex::XBlock{append(dos, more), prism_rtl::rc(last)});
    }
    {
        auto&& x = ex1;
        return len(dos) == Nat(0u)
            ? x
            : crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos, prism_rtl::rc(x)});
    }
}


/// WhileJob: unbounded fn Lx, Env, Env, Cond, Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
crate::lower::model::Ex while_job(const Lx& lx, const Env& outer, const Env& env, const crate::syntax::Cond& c, const crate::syntax::Block& wb, const crate::syntax::Range& span, const Text& rest_text_, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, Env>)>& cont_fn) {
    auto state = fold(keys(env->names), Array<std::tuple<Text, Text, crate::lower::model::OutTy>>{}, [&](const Array<std::tuple<Text, Text, crate::lower::model::OutTy>>& acc, const Text& k) {
        return !crate::syntax::lexer::has_prefix(k, Text::lit("&"))
            ? acc
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, Text, crate::lower::model::OutTy>>> _v;
            auto&& _m = crate::prelude::get(env->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& bt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(crate::prelude::push(acc, std::tuple{k, place_stem(rs), bt}));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto names = each(state, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        return rs;
    });
    auto st_ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{each(state, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& bt = std::get<2>(_p0);
        return bt;
    })});
    auto pat = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(names, [&](const Text& n) { return crate::lower::model::Pa(crate::lower::model::Pa::PaMut{prism_rtl::cat(n)}); })});
    auto pack = crate::lower::model::Ex(crate::lower::model::Ex::XTuple{each(names, [&](const Text& n) { return crate::lower::model::Ex(crate::lower::model::Ex::XVar{n}); })});
    auto env_s = fold(state, env, [&](const Env& en, const std::tuple<Text, Text, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<2>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs}), Holding(Holding::Owned{}), bt}));
    });
    auto loop_text = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(lx.g.srcs, lx->file);
        if (prism_rtl::is_some(_m)) {
            auto&& src = prism_rtl::some_of(_m);
            _v.set(crate::check::errors::span_text(src, span));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto caps = caps_in(env_s, loop_text, names);
    auto cap_dos = each(caps, [&](const std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        auto&& mode = std::get<2>(_p0);
        auto&& bt = std::get<3>(_p0);
        return crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{place_stem(rs)}), own(Vl(Vl::VlPlace{rs, mode, bt}))});
    });
    auto env_c = fold(caps, env_s, [&](const Env& en, const std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto jobs = has_top_while(lx, wb);
    auto finish_fn = ({
        auto jobs_1 = jobs;
        (prism_rtl::rc([=](const crate::lower::model::Ex& x) {
        return jobs_1
            ? crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{x})})
            : x;
    }));
    });
    auto step_ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Result"), Array(std::vector{st_ty, st_ty})});
    auto again = finish_fn(crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Ok"), Array(std::vector{pack})})), step_ty}));
    auto stop = finish_fn(crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{pack})})), step_ty}));
    auto body_fn = ({
        auto jobs_1 = jobs;
        auto lx_2 = lx;
        auto wb_3 = wb;
        auto again_4 = again;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Env)>>(prism_rtl::rc([=](Env p0) {
        return ({
            auto jobs_1_5 = jobs_1;
            auto lx_2_5 = lx_2;
            auto wb_3_5 = wb_3;
            auto again_4_5 = again_4;
            entered(once_job([=]() {
            return ({
                auto en = p0;
                jobs_1_5
                ? prism_rtl::more(prism_rtl::rc(UpdTailFrom(lx_2_5, en, en, wb_3_5, Nat(0u), wb_3_5.span, ({
                auto again_4_5_5 = again_4_5;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<Env, crate::lower::model::Ex> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto again_4_5_5_5 = again_4_5_5;
                    once_job([=]() {
                    return ({
                        auto o2 = p0;
                        auto e2 = p1;
                        (prism_rtl::finished(again_4_5_5_5));
                    });
                });
                });
            })));
            }))))
                : prism_rtl::more(prism_rtl::rc(StmtsThen(lx_2_5, en, wb_3_5, again_4_5)));
            });
        }));
        });
    })));
    });
    auto res_ty = jobs
        ? crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("prism_rtl::Turn"), Array(std::vector{step_ty})})
        : st_ty;
    auto turn = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Ex> _v;
        if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c)) {
            auto&& x = prism_rtl::as<crate::syntax::Cond::CondExpr>(c).a0;
            _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XIf{prism_rtl::rc(as_bool(value_of(lx, env_c, x))), prism_rtl::rc(run_to_end(body_fn(env_c))), prism_rtl::rc(stop)}));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::Cond::CondBind>(c)) {
            auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a0;
            auto&& x = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a1;
            auto&& g_opt = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a2;
            _v.set(({
                auto po = rust_pat(lx, p_, type_at(lx, x.span), Holding(Holding::Owned{}), prism_rtl::cat("w", span.start));
                auto env_b = bind_all(env_c, po.binds);
                auto conds = append(po.conds, guard_conds(lx, env_b, g_opt));
                own(arms_value(own(value_of(lx, env_c, x)), Array(std::vector{crate::lower::model::XArm{.pat = po.pa, .conds = conds, .body = run_to_end(body_fn(env_b))}, crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .body = stop}}), prism_rtl::cat("'w", span.start), res_ty));
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto out_caps = caps_in(outer, rest_text_, names);
    auto out_dos = each(out_caps, [&](const std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        auto&& mode = std::get<2>(_p0);
        auto&& bt = std::get<3>(_p0);
        return crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{place_stem(rs)}), own(Vl(Vl::VlPlace{rs, mode, bt}))});
    });
    auto outer2 = fold(out_caps, outer, [&](const Env& en, const std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto env2 = fold(out_caps, env_s, [&](const Env& en, const std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto step_fn = prepend(cap_dos, crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(pat), st_ty})}), prism_rtl::rc(turn)}));
    auto looping = jobs ? Text::lit("loop_turns") : Text::lit("loop_job");
    auto enter = crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("call_then"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{looping, Array(std::vector{pack, step_fn})}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(pat), st_ty})}), prism_rtl::rc(run_to_end(cont_fn(std::tuple{outer2, env2})))})})});
    return prepend(out_dos, enter);
}


prism_rtl::Turn<crate::lower::model::Ex> WhileJob::cycle() const {
    const auto& lx = this->lx;
    const auto& outer = this->outer;
    const auto& env = this->env;
    const auto& c = this->c;
    const auto& wb = this->wb;
    const auto& span = this->span;
    const auto& rest_text_ = this->rest_text_;
    const auto& cont_fn = this->cont_fn;
    auto state = fold(keys(env->names), Array<std::tuple<Text, Text, crate::lower::model::OutTy>>{}, [&](const Array<std::tuple<Text, Text, crate::lower::model::OutTy>>& acc, const Text& k) {
        return !crate::syntax::lexer::has_prefix(k, Text::lit("&"))
            ? acc
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, Text, crate::lower::model::OutTy>>> _v;
            auto&& _m = crate::prelude::get(env->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& bt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(crate::prelude::push(acc, std::tuple{k, place_stem(rs), bt}));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto names = each(state, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        return rs;
    });
    auto st_ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{each(state, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& bt = std::get<2>(_p0);
        return bt;
    })});
    auto pat = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(names, [&](const Text& n) { return crate::lower::model::Pa(crate::lower::model::Pa::PaMut{prism_rtl::cat(n)}); })});
    auto pack = crate::lower::model::Ex(crate::lower::model::Ex::XTuple{each(names, [&](const Text& n) { return crate::lower::model::Ex(crate::lower::model::Ex::XVar{n}); })});
    auto env_s = fold(state, env, [&](const Env& en, const std::tuple<Text, Text, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<2>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs}), Holding(Holding::Owned{}), bt}));
    });
    auto loop_text = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(lx.g.srcs, lx->file);
        if (prism_rtl::is_some(_m)) {
            auto&& src = prism_rtl::some_of(_m);
            _v.set(crate::check::errors::span_text(src, span));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto caps = caps_in(env_s, loop_text, names);
    auto cap_dos = each(caps, [&](const std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        auto&& mode = std::get<2>(_p0);
        auto&& bt = std::get<3>(_p0);
        return crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{place_stem(rs)}), own(Vl(Vl::VlPlace{rs, mode, bt}))});
    });
    auto env_c = fold(caps, env_s, [&](const Env& en, const std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto jobs = has_top_while(lx, wb);
    auto finish_fn = ({
        auto jobs_1 = jobs;
        (prism_rtl::rc([=](const crate::lower::model::Ex& x) {
        return jobs_1
            ? crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{x})})
            : x;
    }));
    });
    auto step_ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Result"), Array(std::vector{st_ty, st_ty})});
    auto again = finish_fn(crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Ok"), Array(std::vector{pack})})), step_ty}));
    auto stop = finish_fn(crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{pack})})), step_ty}));
    auto body_fn = ({
        auto jobs_1 = jobs;
        auto lx_2 = lx;
        auto wb_3 = wb;
        auto again_4 = again;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Env)>>(prism_rtl::rc([=](Env p0) {
        return ({
            auto jobs_1_5 = jobs_1;
            auto lx_2_5 = lx_2;
            auto wb_3_5 = wb_3;
            auto again_4_5 = again_4;
            entered(once_job([=]() {
            return ({
                auto en = p0;
                jobs_1_5
                ? prism_rtl::more(prism_rtl::rc(UpdTailFrom(lx_2_5, en, en, wb_3_5, Nat(0u), wb_3_5.span, ({
                auto again_4_5_5 = again_4_5;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<Env, crate::lower::model::Ex> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto again_4_5_5_5 = again_4_5_5;
                    once_job([=]() {
                    return ({
                        auto o2 = p0;
                        auto e2 = p1;
                        (prism_rtl::finished(again_4_5_5_5));
                    });
                });
                });
            })));
            }))))
                : prism_rtl::more(prism_rtl::rc(StmtsThen(lx_2_5, en, wb_3_5, again_4_5)));
            });
        }));
        });
    })));
    });
    auto res_ty = jobs
        ? crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("prism_rtl::Turn"), Array(std::vector{step_ty})})
        : st_ty;
    auto turn = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Ex> _v;
        if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c)) {
            auto&& x = prism_rtl::as<crate::syntax::Cond::CondExpr>(c).a0;
            _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XIf{prism_rtl::rc(as_bool(value_of(lx, env_c, x))), prism_rtl::rc(run_to_end(body_fn(env_c))), prism_rtl::rc(stop)}));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::Cond::CondBind>(c)) {
            auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a0;
            auto&& x = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a1;
            auto&& g_opt = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a2;
            _v.set(({
                auto po = rust_pat(lx, p_, type_at(lx, x.span), Holding(Holding::Owned{}), prism_rtl::cat("w", span.start));
                auto env_b = bind_all(env_c, po.binds);
                auto conds = append(po.conds, guard_conds(lx, env_b, g_opt));
                own(arms_value(own(value_of(lx, env_c, x)), Array(std::vector{crate::lower::model::XArm{.pat = po.pa, .conds = conds, .body = run_to_end(body_fn(env_b))}, crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .body = stop}}), prism_rtl::cat("'w", span.start), res_ty));
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto out_caps = caps_in(outer, rest_text_, names);
    auto out_dos = each(out_caps, [&](const std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        auto&& mode = std::get<2>(_p0);
        auto&& bt = std::get<3>(_p0);
        return crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{place_stem(rs)}), own(Vl(Vl::VlPlace{rs, mode, bt}))});
    });
    auto outer2 = fold(out_caps, outer, [&](const Env& en, const std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto env2 = fold(out_caps, env_s, [&](const Env& en, const std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto step_fn = prepend(cap_dos, crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(pat), st_ty})}), prism_rtl::rc(turn)}));
    auto looping = jobs ? Text::lit("loop_turns") : Text::lit("loop_job");
    auto cont_fn_1 = cont_fn;
    return call_value(cont_fn_1(std::tuple{outer2, env2}), [=](crate::lower::model::Ex cont_152106) {
        return ({
            auto enter = crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("call_then"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{looping, Array(std::vector{pack, step_fn})}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(pat), st_ty})}), prism_rtl::rc(cont_152106)})})});
            (prism_rtl::finished(prepend(out_dos, enter)));
        });
    });
}


/// `Start WhileJob, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_while_job(Lx lx, Env outer, Env env, crate::syntax::Cond c, crate::syntax::Block wb, crate::syntax::Range span, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, Env>)> cont_fn) {
    return prism_rtl::make_rc<WhileJob>(lx, outer, env, c, wb, span, rest_text_, cont_fn);
}


/// StmtsThen: unbounded fn Lx, Env, Block, Ex -> Ex
crate::lower::model::Ex stmts_then(const Lx& lx, const Env& env, const crate::syntax::Block& b, const crate::lower::model::Ex& last) {
    auto&& _dos = upd_stmts(lx, env, b.stmts);
    auto&& dos = std::get<0>(_dos);
    return crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos, prism_rtl::rc(last)});
}


prism_rtl::Turn<crate::lower::model::Ex> StmtsThen::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& b = this->b;
    const auto& last = this->last;
    auto b_1 = b;
    auto env_2 = env;
    auto last_3 = last;
    auto lx_4 = lx;
    return call_then(start_upd_stmts(lx_4, env_2, b_1.stmts), [=](std::tuple<Array<crate::lower::model::Do>, Env> upd_stmts_152319) {
        return ({
            auto&& _dos = upd_stmts_152319;
            auto&& dos = std::get<0>(_dos);
            (prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos, prism_rtl::rc(last_3)})));
        });
    });
}


/// `Start StmtsThen, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_stmts_then(Lx lx, Env env, crate::syntax::Block b, crate::lower::model::Ex last) {
    return prism_rtl::make_rc<StmtsThen>(lx, env, b, last);
}


/// IfJob: unbounded fn Lx, Env, Env, Cond, Block, ?Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
crate::lower::model::Ex if_job(const Lx& lx, const Env& outer, const Env& env, const crate::syntax::Cond& c, const crate::syntax::Block& then_b, const std::optional<crate::syntax::Block>& else_b_opt, const crate::syntax::Range& span, const Text& rest_text_, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, Env>)>& cont_fn) {
    auto state = fold(keys(env->names), Array<std::tuple<Text, Text, crate::lower::model::OutTy>>{}, [&](const Array<std::tuple<Text, Text, crate::lower::model::OutTy>>& acc, const Text& k) {
        return !crate::syntax::lexer::has_prefix(k, Text::lit("&"))
            ? acc
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, Text, crate::lower::model::OutTy>>> _v;
            auto&& _m = crate::prelude::get(env->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& bt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(crate::prelude::push(acc, std::tuple{k, place_stem(rs), bt}));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto names = each(state, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        return rs;
    });
    auto st_ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{each(state, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& bt = std::get<2>(_p0);
        return bt;
    })});
    auto pat = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(names, [&](const Text& n) { return crate::lower::model::Pa(crate::lower::model::Pa::PaMut{prism_rtl::cat(n)}); })});
    auto pack = crate::lower::model::Ex(crate::lower::model::Ex::XTuple{each(names, [&](const Text& n) { return crate::lower::model::Ex(crate::lower::model::Ex::XVar{n}); })});
    auto env_s = fold(state, env, [&](const Env& en, const std::tuple<Text, Text, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<2>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs}), Holding(Holding::Owned{}), bt}));
    });
    auto out_caps = caps_in(outer, rest_text_, names);
    auto out_dos = each(out_caps, [&](const std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        auto&& mode = std::get<2>(_p0);
        auto&& bt = std::get<3>(_p0);
        return crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{place_stem(rs)}), own(Vl(Vl::VlPlace{rs, mode, bt}))});
    });
    auto outer2 = fold(out_caps, outer, [&](const Env& en, const std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto env2 = fold(out_caps, env_s, [&](const Env& en, const std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto k_name = prism_rtl::cat("k_if", span.start);
    auto k_do = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{k_name}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(pat), st_ty})}), prism_rtl::rc(run_to_end(cont_fn(std::tuple{outer2, env2})))})});
    auto to_k_fn = ({
        auto k_name_1 = k_name;
        auto pack_2 = pack;
        (prism_rtl::rc([=](const Env& o2, const crate::lower::model::Ex& e2) { return crate::lower::model::Ex(crate::lower::model::Ex::XCall{k_name_1, Array(std::vector{pack_2})}); }));
    });
    auto branch_fn = ({
        auto lx_1 = lx;
        auto env_2 = env;
        auto to_k_fn_3 = to_k_fn;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Block)>>(prism_rtl::rc([=](crate::syntax::Block p0) {
        return ({
            auto lx_1_4 = lx_1;
            auto env_2_4 = env_2;
            auto to_k_fn_3_4 = to_k_fn_3;
            entered(once_job([=]() {
            return ({
                auto b = p0;
                (prism_rtl::more(prism_rtl::rc(UpdTailFrom(lx_1_4, env_2_4, env_2_4, b, Nat(0u), b.span, ({
                auto f = to_k_fn_3_4;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<Env, crate::lower::model::Ex> _p0) {
                auto&& a0 = std::get<0>(_p0);
                auto&& a1 = std::get<1>(_p0);
                return ({
                    auto f_4 = f;
                    once_job([=]() { return prism_rtl::finished(f_4(a0, a1)); });
                });
            })));
            })))));
            });
        }));
        });
    })));
    });
    auto else_x = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Ex> _v;
        if (prism_rtl::is_some(else_b_opt)) {
            auto&& eb = prism_rtl::some_of(else_b_opt);
            _v.set(run_to_end(branch_fn(eb)));
            goto _done;
        }
        if (prism_rtl::is_none(else_b_opt)) {
            _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XCall{k_name, Array(std::vector{pack})}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto choose = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Ex> _v;
        if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c)) {
            auto&& x = prism_rtl::as<crate::syntax::Cond::CondExpr>(c).a0;
            _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XIf{prism_rtl::rc(as_bool(value_of(lx, env, x))), prism_rtl::rc(run_to_end(branch_fn(then_b))), prism_rtl::rc(else_x)}));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::Cond::CondBind>(c)) {
            auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a0;
            auto&& x = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a1;
            _v.set(({
                auto po = rust_pat(lx, p_, type_at(lx, x.span), Holding(Holding::Owned{}), prism_rtl::cat("u", x.span.start));
                auto then_x = upd_tail_from(lx, bind_all(env, po.binds), bind_all(env, po.binds), then_b, Nat(0u), then_b.span, ({
                    auto f = to_k_fn;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<Env, crate::lower::model::Ex> _p0) {
                    auto&& a0 = std::get<0>(_p0);
                    auto&& a1 = std::get<1>(_p0);
                    return ({
                        auto f_1 = f;
                        once_job([=]() { return prism_rtl::finished(f_1(a0, a1)); });
                    });
                })));
                }));
                own(arms_value(own(value_of(lx, env, x)), Array(std::vector{crate::lower::model::XArm{.pat = po.pa, .conds = po.conds, .body = then_x}, crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .body = else_x}}), prism_rtl::cat("'u", x.span.start), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{Text::lit("the job's turn")})));
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return prepend(crate::prelude::push(out_dos, k_do), choose);
}


prism_rtl::Turn<crate::lower::model::Ex> IfJob::cycle() const {
    const auto& lx = this->lx;
    const auto& outer = this->outer;
    const auto& env = this->env;
    const auto& c = this->c;
    const auto& then_b = this->then_b;
    const auto& else_b_opt = this->else_b_opt;
    const auto& span = this->span;
    const auto& rest_text_ = this->rest_text_;
    const auto& cont_fn = this->cont_fn;
    auto state = fold(keys(env->names), Array<std::tuple<Text, Text, crate::lower::model::OutTy>>{}, [&](const Array<std::tuple<Text, Text, crate::lower::model::OutTy>>& acc, const Text& k) {
        return !crate::syntax::lexer::has_prefix(k, Text::lit("&"))
            ? acc
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, Text, crate::lower::model::OutTy>>> _v;
            auto&& _m = crate::prelude::get(env->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& bt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(crate::prelude::push(acc, std::tuple{k, place_stem(rs), bt}));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto names = each(state, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        return rs;
    });
    auto st_ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{each(state, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& bt = std::get<2>(_p0);
        return bt;
    })});
    auto pat = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(names, [&](const Text& n) { return crate::lower::model::Pa(crate::lower::model::Pa::PaMut{prism_rtl::cat(n)}); })});
    auto pack = crate::lower::model::Ex(crate::lower::model::Ex::XTuple{each(names, [&](const Text& n) { return crate::lower::model::Ex(crate::lower::model::Ex::XVar{n}); })});
    auto env_s = fold(state, env, [&](const Env& en, const std::tuple<Text, Text, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<2>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs}), Holding(Holding::Owned{}), bt}));
    });
    auto out_caps = caps_in(outer, rest_text_, names);
    auto out_dos = each(out_caps, [&](const std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        auto&& mode = std::get<2>(_p0);
        auto&& bt = std::get<3>(_p0);
        return crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{place_stem(rs)}), own(Vl(Vl::VlPlace{rs, mode, bt}))});
    });
    auto outer2 = fold(out_caps, outer, [&](const Env& en, const std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto env2 = fold(out_caps, env_s, [&](const Env& en, const std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto k_name = prism_rtl::cat("k_if", span.start);
    auto else_b_opt_1 = else_b_opt;
    auto cont_fn_2 = cont_fn;
    auto c_3 = c;
    auto env_4 = env;
    auto lx_5 = lx;
    auto span_6 = span;
    auto then_b_7 = then_b;
    return call_value(cont_fn_2(std::tuple{outer2, env2}), [=](crate::lower::model::Ex cont_154031) {
        return ({
            auto k_do = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{k_name}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(pat), st_ty})}), prism_rtl::rc(cont_154031)})});
            auto to_k_fn = ({
                auto k_name_8 = k_name;
                auto pack_9 = pack;
                (prism_rtl::rc([=](const Env& o2, const crate::lower::model::Ex& e2) { return crate::lower::model::Ex(crate::lower::model::Ex::XCall{k_name_8, Array(std::vector{pack_9})}); }));
            });
            auto branch_fn = ({
                auto lx_5_8 = lx_5;
                auto env_4_8 = env_4;
                auto to_k_fn_8 = to_k_fn;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Block)>>(prism_rtl::rc([=](crate::syntax::Block p0) {
                return ({
                    auto lx_5_8_9 = lx_5_8;
                    auto env_4_8_9 = env_4_8;
                    auto to_k_fn_8_9 = to_k_fn_8;
                    entered(once_job([=]() {
                    return ({
                        auto b = p0;
                        (prism_rtl::more(prism_rtl::rc(UpdTailFrom(lx_5_8_9, env_4_8_9, env_4_8_9, b, Nat(0u), b.span, ({
                        auto f = to_k_fn_8_9;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<Env, crate::lower::model::Ex> _p0) {
                        auto&& a0 = std::get<0>(_p0);
                        auto&& a1 = std::get<1>(_p0);
                        return ({
                            auto f_9 = f;
                            once_job([=]() { return prism_rtl::finished(f_9(a0, a1)); });
                        });
                    })));
                    })))));
                    });
                }));
                });
            })));
            });
            auto else_x = ({
                __label__ _done;
                prism_rtl::Slot<crate::lower::model::Ex> _v;
                if (prism_rtl::is_some(else_b_opt)) {
                    auto&& eb = prism_rtl::some_of(else_b_opt);
                    _v.set(run_to_end(branch_fn(eb)));
                    goto _done;
                }
                if (prism_rtl::is_none(else_b_opt)) {
                    _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XCall{k_name, Array(std::vector{pack})}));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto choose = ({
                __label__ _done;
                prism_rtl::Slot<crate::lower::model::Ex> _v;
                if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c)) {
                    auto&& x = prism_rtl::as<crate::syntax::Cond::CondExpr>(c).a0;
                    _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XIf{prism_rtl::rc(as_bool(value_of(lx_5, env_4, x))), prism_rtl::rc(run_to_end(branch_fn(then_b_7))), prism_rtl::rc(else_x)}));
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::Cond::CondBind>(c)) {
                    auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a0;
                    auto&& x = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a1;
                    _v.set(({
                        auto po = rust_pat(lx_5, p_, type_at(lx_5, x.span), Holding(Holding::Owned{}), prism_rtl::cat("u", x.span.start));
                        auto then_x = upd_tail_from(lx_5, bind_all(env_4, po.binds), bind_all(env_4, po.binds), then_b_7, Nat(0u), then_b_7.span, ({
                            auto f = to_k_fn;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<Env, crate::lower::model::Ex> _p0) {
                            auto&& a0 = std::get<0>(_p0);
                            auto&& a1 = std::get<1>(_p0);
                            return ({
                                auto f_8 = f;
                                once_job([=]() { return prism_rtl::finished(f_8(a0, a1)); });
                            });
                        })));
                        }));
                        own(arms_value(own(value_of(lx_5, env_4, x)), Array(std::vector{crate::lower::model::XArm{.pat = po.pa, .conds = po.conds, .body = then_x}, crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .body = else_x}}), prism_rtl::cat("'u", x.span.start), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{Text::lit("the job's turn")})));
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (prism_rtl::finished(prepend(crate::prelude::push(out_dos, k_do), choose)));
        });
    });
}


/// `Start IfJob, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_if_job(Lx lx, Env outer, Env env, crate::syntax::Cond c, crate::syntax::Block then_b, std::optional<crate::syntax::Block> else_b_opt, crate::syntax::Range span, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, Env>)> cont_fn) {
    return prism_rtl::make_rc<IfJob>(lx, outer, env, c, then_b, else_b_opt, span, rest_text_, cont_fn);
}


/// MatchJob: unbounded fn Lx, Env, Env, Expr, [Arm], Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
crate::lower::model::Ex match_job(const Lx& lx, const Env& outer, const Env& env, const crate::syntax::Expr& scrut, const Array<crate::syntax::Arm>& arms, const crate::syntax::Range& span, const Text& rest_text_, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, Env>)>& cont_fn) {
    auto state = fold(keys(env->names), Array<std::tuple<Text, Text, crate::lower::model::OutTy>>{}, [&](const Array<std::tuple<Text, Text, crate::lower::model::OutTy>>& acc, const Text& k) {
        return !crate::syntax::lexer::has_prefix(k, Text::lit("&"))
            ? acc
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, Text, crate::lower::model::OutTy>>> _v;
            auto&& _m = crate::prelude::get(env->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& bt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(crate::prelude::push(acc, std::tuple{k, place_stem(rs), bt}));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto names = each(state, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        return rs;
    });
    auto st_ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{each(state, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& bt = std::get<2>(_p0);
        return bt;
    })});
    auto pat = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(names, [&](const Text& n) { return crate::lower::model::Pa(crate::lower::model::Pa::PaMut{prism_rtl::cat(n)}); })});
    auto pack = crate::lower::model::Ex(crate::lower::model::Ex::XTuple{each(names, [&](const Text& n) { return crate::lower::model::Ex(crate::lower::model::Ex::XVar{n}); })});
    auto env_s = fold(state, env, [&](const Env& en, const std::tuple<Text, Text, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<2>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs}), Holding(Holding::Owned{}), bt}));
    });
    auto out_caps = caps_in(outer, rest_text_, names);
    auto out_dos = each(out_caps, [&](const std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        auto&& mode = std::get<2>(_p0);
        auto&& bt = std::get<3>(_p0);
        return crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{place_stem(rs)}), own(Vl(Vl::VlPlace{rs, mode, bt}))});
    });
    auto outer2 = fold(out_caps, outer, [&](const Env& en, const std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto env2 = fold(out_caps, env_s, [&](const Env& en, const std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto k_name = prism_rtl::cat("k_match", span.start);
    auto k_do = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{k_name}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(pat), st_ty})}), prism_rtl::rc(run_to_end(cont_fn(std::tuple{outer2, env2})))})});
    auto to_k_fn = ({
        auto k_name_1 = k_name;
        auto pack_2 = pack;
        (prism_rtl::rc([=](const Env& o2, const crate::lower::model::Ex& e2) { return crate::lower::model::Ex(crate::lower::model::Ex::XCall{k_name_1, Array(std::vector{pack_2})}); }));
    });
    auto sty = type_at(lx, scrut.span);
    auto xarms = run_to_end(each_job(crate::check::errors::range0(len(arms)), ({
        auto arms_1 = arms;
        auto lx_2 = lx;
        auto sty_3 = sty;
        auto scrut_4 = scrut;
        auto env_5 = env;
        auto to_k_fn_6 = to_k_fn;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::XArm>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto arms_1_7 = arms_1;
            auto lx_2_7 = lx_2;
            auto sty_3_7 = sty_3;
            auto scrut_4_7 = scrut_4;
            auto env_5_7 = env_5;
            auto to_k_fn_6_7 = to_k_fn_6;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto arm = or_(index(arms_1_7, i), dummy_arm());
                call_then(start_arm_pat(lx_2_7, arm.pattern, sty_3_7, Holding(Holding::Owned{}), prism_rtl::cat("u", scrut_4_7.span.start, "_", i)), [=](PatOut arm_pat_156598) {
                return ({
                    auto po = arm_pat_156598;
                    auto env_a = bind_all(env_5_7, po.binds);
                    call_then(start_guard_conds(lx_2_7, env_a, arm.guard), [=](Array<crate::lower::model::Cc> guard_conds_156742) {
                    return ({
                        auto guarded = append(po.conds, guard_conds_156742);
                        call_then(start_upd_tail_from(lx_2_7, env_a, env_a, arm.body, Nat(0u), arm.body.span, ({
                        auto f = to_k_fn_6_7;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<Env, crate::lower::model::Ex> _p0) {
                        auto&& a0 = std::get<0>(_p0);
                        auto&& a1 = std::get<1>(_p0);
                        return ({
                            auto f_7 = f;
                            once_job([=]() { return prism_rtl::finished(f_7(a0, a1)); });
                        });
                    })));
                    })), [=](crate::lower::model::Ex upd_tail_from_156820) { return prism_rtl::finished(crate::lower::model::XArm{.pat = po.pa, .conds = guarded, .body = upd_tail_from_156820}); });
                    });
                });
                });
            });
            });
            });
        }));
        });
    })));
    })));
    return prepend(crate::prelude::push(out_dos, k_do), own(arms_value(own(value_of(lx, env, scrut)), xarms, prism_rtl::cat("'u", scrut.span.start), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{Text::lit("the job's turn")}))));
}


prism_rtl::Turn<crate::lower::model::Ex> MatchJob::cycle() const {
    const auto& lx = this->lx;
    const auto& outer = this->outer;
    const auto& env = this->env;
    const auto& scrut = this->scrut;
    const auto& arms = this->arms;
    const auto& span = this->span;
    const auto& rest_text_ = this->rest_text_;
    const auto& cont_fn = this->cont_fn;
    auto state = fold(keys(env->names), Array<std::tuple<Text, Text, crate::lower::model::OutTy>>{}, [&](const Array<std::tuple<Text, Text, crate::lower::model::OutTy>>& acc, const Text& k) {
        return !crate::syntax::lexer::has_prefix(k, Text::lit("&"))
            ? acc
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, Text, crate::lower::model::OutTy>>> _v;
            auto&& _m = crate::prelude::get(env->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& bt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(crate::prelude::push(acc, std::tuple{k, place_stem(rs), bt}));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto names = each(state, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        return rs;
    });
    auto st_ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{each(state, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& bt = std::get<2>(_p0);
        return bt;
    })});
    auto pat = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(names, [&](const Text& n) { return crate::lower::model::Pa(crate::lower::model::Pa::PaMut{prism_rtl::cat(n)}); })});
    auto pack = crate::lower::model::Ex(crate::lower::model::Ex::XTuple{each(names, [&](const Text& n) { return crate::lower::model::Ex(crate::lower::model::Ex::XVar{n}); })});
    auto env_s = fold(state, env, [&](const Env& en, const std::tuple<Text, Text, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<2>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs}), Holding(Holding::Owned{}), bt}));
    });
    auto out_caps = caps_in(outer, rest_text_, names);
    auto out_dos = each(out_caps, [&](const std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        auto&& mode = std::get<2>(_p0);
        auto&& bt = std::get<3>(_p0);
        return crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{place_stem(rs)}), own(Vl(Vl::VlPlace{rs, mode, bt}))});
    });
    auto outer2 = fold(out_caps, outer, [&](const Env& en, const std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto env2 = fold(out_caps, env_s, [&](const Env& en, const std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto k_name = prism_rtl::cat("k_match", span.start);
    auto cont_fn_1 = cont_fn;
    auto arms_2 = arms;
    auto env_3 = env;
    auto lx_4 = lx;
    auto scrut_5 = scrut;
    auto span_6 = span;
    return call_value(cont_fn_1(std::tuple{outer2, env2}), [=](crate::lower::model::Ex cont_156393) {
        return ({
            auto k_do = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{k_name}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(pat), st_ty})}), prism_rtl::rc(cont_156393)})});
            auto to_k_fn = ({
                auto k_name_7 = k_name;
                auto pack_8 = pack;
                (prism_rtl::rc([=](const Env& o2, const crate::lower::model::Ex& e2) { return crate::lower::model::Ex(crate::lower::model::Ex::XCall{k_name_7, Array(std::vector{pack_8})}); }));
            });
            auto sty = type_at(lx_4, scrut_5.span);
            call_value(each_job(crate::check::errors::range0(len(arms_2)), ({
            auto arms_2_7 = arms_2;
            auto lx_4_7 = lx_4;
            auto sty_7 = sty;
            auto scrut_5_8 = scrut_5;
            auto env_3_8 = env_3;
            auto to_k_fn_8 = to_k_fn;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::XArm>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto arms_2_7_9 = arms_2_7;
                auto lx_4_7_9 = lx_4_7;
                auto sty_7_9 = sty_7;
                auto scrut_5_8_9 = scrut_5_8;
                auto env_3_8_9 = env_3_8;
                auto to_k_fn_8_9 = to_k_fn_8;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    ({
                    auto arm = or_(index(arms_2_7_9, i), dummy_arm());
                    call_then(start_arm_pat(lx_4_7_9, arm.pattern, sty_7_9, Holding(Holding::Owned{}), prism_rtl::cat("u", scrut_5_8_9.span.start, "_", i)), [=](PatOut arm_pat_156598) {
                    return ({
                        auto po = arm_pat_156598;
                        auto env_a = bind_all(env_3_8_9, po.binds);
                        call_then(start_guard_conds(lx_4_7_9, env_a, arm.guard), [=](Array<crate::lower::model::Cc> guard_conds_156742) {
                        return ({
                            auto guarded = append(po.conds, guard_conds_156742);
                            call_then(start_upd_tail_from(lx_4_7_9, env_a, env_a, arm.body, Nat(0u), arm.body.span, ({
                            auto f = to_k_fn_8_9;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<Env, crate::lower::model::Ex> _p0) {
                            auto&& a0 = std::get<0>(_p0);
                            auto&& a1 = std::get<1>(_p0);
                            return ({
                                auto f_9 = f;
                                once_job([=]() { return prism_rtl::finished(f_9(a0, a1)); });
                            });
                        })));
                        })), [=](crate::lower::model::Ex upd_tail_from_156820) { return prism_rtl::finished(crate::lower::model::XArm{.pat = po.pa, .conds = guarded, .body = upd_tail_from_156820}); });
                        });
                    });
                    });
                });
                });
                });
            }));
            });
        })));
        })), [=](Array<crate::lower::model::XArm> each_156511) {
            return ({
                auto xarms = each_156511;
                call_then(start_value_of(lx_4, env_3, scrut_5), [=](Vl value_of_156936) { return prism_rtl::finished(prepend(crate::prelude::push(out_dos, k_do), own(arms_value(own(value_of_156936), xarms, prism_rtl::cat("'u", scrut_5.span.start), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{Text::lit("the job's turn")}))))); });
            });
        });
        });
    });
}


/// `Start MatchJob, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_match_job(Lx lx, Env outer, Env env, crate::syntax::Expr scrut, Array<crate::syntax::Arm> arms, crate::syntax::Range span, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, Env>)> cont_fn) {
    return prism_rtl::make_rc<MatchJob>(lx, outer, env, scrut, arms, span, rest_text_, cont_fn);
}


/// ForJob: unbounded fn Lx, Env, Env, ?ForBinders, Expr, Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
crate::lower::model::Ex for_job(const Lx& lx, const Env& outer, const Env& env, const std::optional<crate::syntax::ForBinders>& binders_opt, const crate::syntax::Expr& source, const crate::syntax::Block& body, const crate::syntax::Range& span, const Text& rest_text_, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, Env>)>& cont_fn) {
    auto state = fold(keys(env->names), Array<std::tuple<Text, Text, crate::lower::model::OutTy>>{}, [&](const Array<std::tuple<Text, Text, crate::lower::model::OutTy>>& acc, const Text& k) {
        return !crate::syntax::lexer::has_prefix(k, Text::lit("&"))
            ? acc
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, Text, crate::lower::model::OutTy>>> _v;
            auto&& _m = crate::prelude::get(env->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& bt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(crate::prelude::push(acc, std::tuple{k, place_stem(rs), bt}));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto names = each(state, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        return rs;
    });
    auto st_ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{each(state, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& bt = std::get<2>(_p0);
        return bt;
    })});
    auto pat = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(names, [&](const Text& n) { return crate::lower::model::Pa(crate::lower::model::Pa::PaMut{prism_rtl::cat(n)}); })});
    auto pack = crate::lower::model::Ex(crate::lower::model::Ex::XTuple{each(names, [&](const Text& n) { return crate::lower::model::Ex(crate::lower::model::Ex::XVar{n}); })});
    auto env_s = fold(state, env, [&](const Env& en, const std::tuple<Text, Text, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<2>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs}), Holding(Holding::Owned{}), bt}));
    });
    auto src = own(value_of(lx, env, source));
    auto sty = peel(type_at(lx, source.span));
    auto [kt, vt, is_array] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::lower::model::OutTy, crate::lower::model::OutTy, bool>> _v;
        if (prism_rtl::is<crate::check::types::Ty::TyArray>(sty)) {
            auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyArray>(sty).a0;
            _v.set(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{}), out_ty_of(lx, v_), true});
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyMap>(sty)) {
            auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(sty).a0;
            auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(sty).a1;
            _v.set(std::tuple{out_ty_of(lx, k), out_ty_of(lx, v_), false});
            goto _done;
        }
        {
            _v.set(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), true});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [vty, kty] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::Ty>> _v;
        if (prism_rtl::is<crate::check::types::Ty::TyArray>(sty)) {
            auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyArray>(sty).a0;
            _v.set(std::tuple{v_, crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Nat"), Array<crate::check::types::Ty>{}})});
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyMap>(sty)) {
            auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(sty).a0;
            auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(sty).a1;
            _v.set(std::tuple{v_, k});
            goto _done;
        }
        {
            _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::Ty(crate::check::types::Ty::TyErr{})});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto key_name = prism_rtl::cat("k", span.start);
    auto val_name = prism_rtl::cat("v", span.start);
    auto loop_text = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(lx.g.srcs, lx->file);
        if (prism_rtl::is_some(_m)) {
            auto&& src2 = prism_rtl::some_of(_m);
            _v.set(crate::check::errors::span_text(src2, span));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto caps = caps_in(env_s, loop_text, names);
    auto cap_dos = each(caps, [&](const std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        auto&& mode = std::get<2>(_p0);
        auto&& bt = std::get<3>(_p0);
        return crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{place_stem(rs)}), own(Vl(Vl::VlPlace{rs, mode, bt}))});
    });
    auto env_c = fold(caps, env_s, [&](const Env& en, const std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto env1 = bind(bind(env_c, Text::lit("key"), Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name}), Holding(Holding::Owned{}), kt})), Text::lit("_"), Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{val_name}), Holding(Holding::Owned{}), vt}));
    auto env_k = is_array
        ? bind(env1, Text::lit("ix"), Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name}), Holding(Holding::Owned{}), kt}))
        : env1;
    auto [binds, env_b] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, Env>> _v;
        if (prism_rtl::is_none(binders_opt)) {
            _v.set(std::tuple{Array<crate::lower::model::Do>{}, env_k});
            goto _done;
        }
        if (prism_rtl::is_some(binders_opt)) {
            auto&& fb = prism_rtl::some_of(binders_opt);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, Env>> _v;
                auto&& _m = fb.second;
                if (prism_rtl::is_none(_m)) {
                    _v.set(({
                        auto po = rust_pat(lx, fb.first, vty, Holding(Holding::Owned{}), prism_rtl::cat("e", span.start));
                        std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{po.pa, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{val_name}))})})}), bind_all(env_k, po.binds)};
                    }));
                    goto _done;
                }
                if (prism_rtl::is_some(_m)) {
                    auto&& second = prism_rtl::some_of(_m);
                    _v.set(({
                        auto pk = rust_pat(lx, fb.first, kty, Holding(Holding::Owned{}), prism_rtl::cat("k", span.start, "_"));
                        auto pv = rust_pat(lx, second, vty, Holding(Holding::Owned{}), prism_rtl::cat("e", span.start));
                        std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{pk.pa, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name}))})}), crate::lower::model::Do(crate::lower::model::Do::DoLet{pv.pa, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{val_name}))})})}), bind_all(bind_all(env_k, pk.binds), pv.binds)};
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto turn = prepend(binds, upd_tail_from(lx, env_b, env_b, body, Nat(0u), body.span, ({
        auto pack_1 = pack;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<Env, crate::lower::model::Ex> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto pack_1_2 = pack_1;
            once_job([=]() {
            return ({
                auto o2 = p0;
                auto e2 = p1;
                (prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{pack_1_2})})));
            });
        });
        });
    })));
    })));
    auto step_fn = prepend(cap_dos, crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(pat), st_ty}), crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{key_name})), kt}), crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{val_name})), vt})}), prism_rtl::rc(turn)}));
    auto out_caps = caps_in(outer, rest_text_, names);
    auto out_dos = each(out_caps, [&](const std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        auto&& mode = std::get<2>(_p0);
        auto&& bt = std::get<3>(_p0);
        return crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{place_stem(rs)}), own(Vl(Vl::VlPlace{rs, mode, bt}))});
    });
    auto outer2 = fold(out_caps, outer, [&](const Env& en, const std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto env2 = fold(out_caps, env_s, [&](const Env& en, const std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto looping = is_array ? Text::lit("for_turns_indexed") : Text::lit("for_turns_keyed");
    auto enter = crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("call_then"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{looping, Array(std::vector{src, pack, step_fn})}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(pat), st_ty})}), prism_rtl::rc(run_to_end(cont_fn(std::tuple{outer2, env2})))})})});
    return prepend(out_dos, enter);
}


prism_rtl::Turn<crate::lower::model::Ex> ForJob::cycle() const {
    const auto& lx = this->lx;
    const auto& outer = this->outer;
    const auto& env = this->env;
    const auto& binders_opt = this->binders_opt;
    const auto& source = this->source;
    const auto& body = this->body;
    const auto& span = this->span;
    const auto& rest_text_ = this->rest_text_;
    const auto& cont_fn = this->cont_fn;
    auto state = fold(keys(env->names), Array<std::tuple<Text, Text, crate::lower::model::OutTy>>{}, [&](const Array<std::tuple<Text, Text, crate::lower::model::OutTy>>& acc, const Text& k) {
        return !crate::syntax::lexer::has_prefix(k, Text::lit("&"))
            ? acc
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, Text, crate::lower::model::OutTy>>> _v;
            auto&& _m = crate::prelude::get(env->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& bt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(crate::prelude::push(acc, std::tuple{k, place_stem(rs), bt}));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto names = each(state, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        return rs;
    });
    auto st_ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{each(state, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& bt = std::get<2>(_p0);
        return bt;
    })});
    auto pat = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(names, [&](const Text& n) { return crate::lower::model::Pa(crate::lower::model::Pa::PaMut{prism_rtl::cat(n)}); })});
    auto pack = crate::lower::model::Ex(crate::lower::model::Ex::XTuple{each(names, [&](const Text& n) { return crate::lower::model::Ex(crate::lower::model::Ex::XVar{n}); })});
    auto env_s = fold(state, env, [&](const Env& en, const std::tuple<Text, Text, crate::lower::model::OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<2>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs}), Holding(Holding::Owned{}), bt}));
    });
    auto binders_opt_1 = binders_opt;
    auto cont_fn_2 = cont_fn;
    auto body_3 = body;
    auto env_4 = env;
    auto lx_5 = lx;
    auto outer_6 = outer;
    auto rest_text__7 = rest_text_;
    auto source_8 = source;
    auto span_9 = span;
    return call_then(start_value_of(lx_5, env_4, source_8), [=](Vl value_of_158173) {
        return ({
            auto src = own(value_of_158173);
            auto sty = peel(type_at(lx_5, source_8.span));
            auto [kt, vt, is_array] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::lower::model::OutTy, crate::lower::model::OutTy, bool>> _v;
                if (prism_rtl::is<crate::check::types::Ty::TyArray>(sty)) {
                    auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyArray>(sty).a0;
                    _v.set(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{}), out_ty_of(lx_5, v_), true});
                    goto _done;
                }
                if (prism_rtl::is<crate::check::types::Ty::TyMap>(sty)) {
                    auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(sty).a0;
                    auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(sty).a1;
                    _v.set(std::tuple{out_ty_of(lx_5, k), out_ty_of(lx_5, v_), false});
                    goto _done;
                }
                {
                    _v.set(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), true});
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto [vty, kty] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::Ty>> _v;
                if (prism_rtl::is<crate::check::types::Ty::TyArray>(sty)) {
                    auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyArray>(sty).a0;
                    _v.set(std::tuple{v_, crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Nat"), Array<crate::check::types::Ty>{}})});
                    goto _done;
                }
                if (prism_rtl::is<crate::check::types::Ty::TyMap>(sty)) {
                    auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(sty).a0;
                    auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(sty).a1;
                    _v.set(std::tuple{v_, k});
                    goto _done;
                }
                {
                    _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::Ty(crate::check::types::Ty::TyErr{})});
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto key_name = prism_rtl::cat("k", span_9.start);
            auto val_name = prism_rtl::cat("v", span_9.start);
            auto loop_text = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = index(lx_5.g.srcs, lx_5->file);
                if (prism_rtl::is_some(_m)) {
                    auto&& src2 = prism_rtl::some_of(_m);
                    _v.set(crate::check::errors::span_text(src2, span_9));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Text::lit(""));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto caps = caps_in(env_s, loop_text, names);
            auto cap_dos = each(caps, [&](const std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>& _p0) {
                auto&& rs = std::get<1>(_p0);
                auto&& mode = std::get<2>(_p0);
                auto&& bt = std::get<3>(_p0);
                return crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{place_stem(rs)}), own(Vl(Vl::VlPlace{rs, mode, bt}))});
            });
            auto env_c = fold(caps, env_s, [&](const Env& en, const std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>& _p1) {
                auto&& k = std::get<0>(_p1);
                auto&& rs = std::get<1>(_p1);
                auto&& bt = std::get<3>(_p1);
                return bind(en, k, Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
            });
            auto env1 = bind(bind(env_c, Text::lit("key"), Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name}), Holding(Holding::Owned{}), kt})), Text::lit("_"), Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{val_name}), Holding(Holding::Owned{}), vt}));
            auto env_k = is_array
                ? bind(env1, Text::lit("ix"), Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name}), Holding(Holding::Owned{}), kt}))
                : env1;
            auto [binds, env_b] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, Env>> _v;
                if (prism_rtl::is_none(binders_opt)) {
                    _v.set(std::tuple{Array<crate::lower::model::Do>{}, env_k});
                    goto _done;
                }
                if (prism_rtl::is_some(binders_opt)) {
                    auto&& fb = prism_rtl::some_of(binders_opt);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, Env>> _v;
                        auto&& _m = fb.second;
                        if (prism_rtl::is_none(_m)) {
                            _v.set(({
                                auto po = rust_pat(lx_5, fb.first, vty, Holding(Holding::Owned{}), prism_rtl::cat("e", span_9.start));
                                std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{po.pa, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{val_name}))})})}), bind_all(env_k, po.binds)};
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_some(_m)) {
                            auto&& second = prism_rtl::some_of(_m);
                            _v.set(({
                                auto pk = rust_pat(lx_5, fb.first, kty, Holding(Holding::Owned{}), prism_rtl::cat("k", span_9.start, "_"));
                                auto pv = rust_pat(lx_5, second, vty, Holding(Holding::Owned{}), prism_rtl::cat("e", span_9.start));
                                std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{pk.pa, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name}))})}), crate::lower::model::Do(crate::lower::model::Do::DoLet{pv.pa, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{val_name}))})})}), bind_all(bind_all(env_k, pk.binds), pv.binds)};
                            }));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            call_then(start_upd_tail_from(lx_5, env_b, env_b, body_3, Nat(0u), body_3.span, ({
            auto pack_10 = pack;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<Env, crate::lower::model::Ex> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto pack_10_11 = pack_10;
                once_job([=]() {
                return ({
                    auto o2 = p0;
                    auto e2 = p1;
                    (prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{pack_10_11})})));
                });
            });
            });
        })));
        })), [=](crate::lower::model::Ex upd_tail_from_159938) {
            return ({
                auto turn = prepend(binds, upd_tail_from_159938);
                auto step_fn = prepend(cap_dos, crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(pat), st_ty}), crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{key_name})), kt}), crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{val_name})), vt})}), prism_rtl::rc(turn)}));
                auto out_caps = caps_in(outer_6, rest_text__7, names);
                auto out_dos = each(out_caps, [&](const std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>& _p0) {
                    auto&& rs = std::get<1>(_p0);
                    auto&& mode = std::get<2>(_p0);
                    auto&& bt = std::get<3>(_p0);
                    return crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{place_stem(rs)}), own(Vl(Vl::VlPlace{rs, mode, bt}))});
                });
                auto outer2 = fold(out_caps, outer_6, [&](const Env& en, const std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>& _p1) {
                    auto&& k = std::get<0>(_p1);
                    auto&& rs = std::get<1>(_p1);
                    auto&& bt = std::get<3>(_p1);
                    return bind(en, k, Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
                });
                auto env2 = fold(out_caps, env_s, [&](const Env& en, const std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>& _p1) {
                    auto&& k = std::get<0>(_p1);
                    auto&& rs = std::get<1>(_p1);
                    auto&& bt = std::get<3>(_p1);
                    return bind(en, k, Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
                });
                auto looping = is_array ? Text::lit("for_turns_indexed") : Text::lit("for_turns_keyed");
                call_value(cont_fn_2(std::tuple{outer2, env2}), [=](crate::lower::model::Ex cont_160786) {
                return ({
                    auto enter = crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("call_then"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{looping, Array(std::vector{src, pack, step_fn})}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(pat), st_ty})}), prism_rtl::rc(cont_160786)})})});
                    (prism_rtl::finished(prepend(out_dos, enter)));
                });
            });
            });
        });
        });
    });
}


/// `Start ForJob, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_for_job(Lx lx, Env outer, Env env, std::optional<crate::syntax::ForBinders> binders_opt, crate::syntax::Expr source, crate::syntax::Block body, crate::syntax::Range span, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<Env, Env>)> cont_fn) {
    return prism_rtl::make_rc<ForJob>(lx, outer, env, binders_opt, source, body, span, rest_text_, cont_fn);
}


/// InstanceOf: fn Text -> Text
Text instance_of(const Text& k) {
    return or_(index(split(k, Text::lit("#inst")), Nat(0u)), k);
}


/// CapsIn: fn Env, Text, [Text] -> [((Text, Ex, Holding, OutTy))]
Array<std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>> caps_in(const Env& env, const Text& text, const Array<Text>& skip) {
    return fold(keys(env->names), Array<std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>>{}, [&](const Array<std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>>& acc, const Text& k) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>>> _v;
            auto&& _m = crate::prelude::get(env->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& mode = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                auto&& bt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set((crate::check::types::has_text(skip, place_stem(rs)) || on_self(rs)) || (!mentions(text, crate::syntax::lexer::drop_prefix(instance_of(k), crate::check::types::marks_of(k))))
                    ? acc
                    : crate::prelude::push(acc, std::tuple{k, rs, mode, bt}));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// ?FrameCall: unbounded fn Lx, Env, Expr, Bool -> ?Expr
std::optional<crate::syntax::Expr> frame_call(const Lx& lx, const Env& env, const crate::syntax::Expr& e, const bool& top) {
    return crate::check::env::has_key(env.spans, place_key(lx, e.span))
        ? std::optional<crate::syntax::Expr>{}
        : ({
        __label__ _done;
        prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
            _v.set(frame_call(lx, env, x, top));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
            auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
            auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                auto&& _m = first_frame(lx, env, each(args, [&](const crate::syntax::Arg& a) { return a->value; }));
                if (prism_rtl::is_some(_m)) {
                    auto&& x = prism_rtl::some_of(_m);
                    _v.set(std::optional(x));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(top
                        ? std::optional<crate::syntax::Expr>{}
                        : ({
                        __label__ _done;
                        prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                        auto&& _m = tail_callee(lx, env, c);
                        if (prism_rtl::is_some(_m)) {
                            _v.set(std::optional(e));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(({
                                __label__ _done;
                                prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                                auto&& _m = local_job_fn(lx, env, c);
                                if (prism_rtl::is_some(_m)) {
                                    _v.set(std::optional(e));
                                    goto _done;
                                }
                                if (prism_rtl::is_none(_m)) {
                                    _v.set(({
                                        __label__ _done;
                                        prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                                        auto&& _m = prelude_job_call(lx, env, e);
                                        if (prism_rtl::is_some(_m)) {
                                            _v.set(std::optional(e));
                                            goto _done;
                                        }
                                        if (prism_rtl::is_none(_m)) {
                                            _v.set(std::optional<crate::syntax::Expr>{});
                                            goto _done;
                                        }
                                        prism_rtl::unreachable("no arm matched");
                                    _done:
                                        _v.take();
                                    }));
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
            _v.set(frame_call(lx, env, x, false));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
            auto&& m161952_3_0 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
            if (prism_rtl::is<crate::syntax::Cond::CondExpr>(m161952_3_0)) {
                auto&& x = prism_rtl::as<crate::syntax::Cond::CondExpr>(m161952_3_0).a0;
                _v.set(frame_call(lx, env, x, false));
                goto _done;
            }
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
            auto&& op = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
            auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
            auto&& r = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
            _v.set((op == Text::lit("and")) || (op == Text::lit("or"))
                ? frame_call(lx, env, l, false)
                : first_frame(lx, env, Array(std::vector{l, r})));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m)) {
            auto&& es = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
            _v.set(first_frame(lx, env, es));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EArray>(_m)) {
            auto&& es = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
            _v.set(first_frame(lx, env, es));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m)) {
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
            _v.set(frame_call(lx, env, x, false));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
            _v.set(frame_call(lx, env, x, false));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
            auto&& i = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
            _v.set(first_frame(lx, env, Array(std::vector{x, i})));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m)) {
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
            auto&& args = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
            _v.set(first_frame(lx, env, append(Array(std::vector{x}), each(args, [&](const crate::syntax::Arg& a) { return a->value; }))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ECast>(_m)) {
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a0;
            _v.set(frame_call(lx, env, x, false));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ELit>(_m)) {
            auto&& l = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                auto&& _m = l.kind;
                if (prism_rtl::is<crate::syntax::LitKind::LText>(_m)) {
                    auto&& segs = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
                    _v.set(first_frame(lx, env, placeholders(segs)));
                    goto _done;
                }
                {
                    _v.set(std::optional<crate::syntax::Expr>{});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(std::optional<crate::syntax::Expr>{});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::optional<crate::syntax::Expr>> FrameCall::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    const auto& top = this->top;
    return crate::check::env::has_key(env.spans, place_key(lx, e.span))
        ? prism_rtl::finished(std::optional<crate::syntax::Expr>{})
        : ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(FrameCall(lx, env, x, top)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ECall>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        ({
        auto args_1 = args;
        auto c_2 = c;
        auto e_3 = e;
        auto env_4 = env;
        auto lx_5 = lx;
        auto top_6 = top;
        call_then(start_first_frame(lx_5, env_4, each(args_1, [&](const crate::syntax::Arg& a) { return a->value; })), [=](std::optional<crate::syntax::Expr> first_frame_162056) {
        return ({
            prism_rtl::is_some(first_frame_162056) ? ({
            auto&& x = prism_rtl::some_of(first_frame_162056);
            prism_rtl::finished(std::optional(x));
        })
            : prism_rtl::is_none(first_frame_162056) ? top_6
            ? prism_rtl::finished(std::optional<crate::syntax::Expr>{})
            : ({
            auto&& _m = tail_callee(lx_5, env_4, c_2);
            prism_rtl::is_some(_m) ? prism_rtl::finished(std::optional(e_3))
            : prism_rtl::is_none(_m) ? call_then(start_local_job_fn(lx_5, env_4, c_2), [=](std::optional<Vl> local_job_fn_162287) {
            return ({
                prism_rtl::is_some(local_job_fn_162287) ? prism_rtl::finished(std::optional(e_3))
                : prism_rtl::is_none(local_job_fn_162287) ? call_then(start_prelude_job_call(lx_5, env_4, e_3), [=](std::optional<crate::lower::model::Ex> prelude_job_call_162384) {
                return ({
                    prism_rtl::is_some(prelude_job_call_162384) ? prism_rtl::finished(std::optional(e_3))
                    : prism_rtl::is_none(prelude_job_call_162384) ? prism_rtl::finished(std::optional<crate::syntax::Expr>{})
                    : throw prism_rtl::Panic("no arm matched");
                });
            })
                : throw prism_rtl::Panic("no arm matched");
            });
        })
            : throw prism_rtl::Panic("no arm matched");
        })
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        prism_rtl::more(prism_rtl::rc(FrameCall(lx, env, x, false)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) && ({
        auto&& m161952_3_0 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        prism_rtl::is<crate::syntax::Cond::CondExpr>(m161952_3_0);
    }) ? ({
        auto&& m161952_3_0 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& x = prism_rtl::as<crate::syntax::Cond::CondExpr>(m161952_3_0).a0;
        prism_rtl::more(prism_rtl::rc(FrameCall(lx, env, x, false)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m) ? ({
        auto&& op = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        (op == Text::lit("and")) || (op == Text::lit("or"))
        ? prism_rtl::more(prism_rtl::rc(FrameCall(lx, env, l, false)))
        : prism_rtl::more(prism_rtl::rc(FirstFrame(lx, env, Array(std::vector{l, r}))));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m) ? ({
        auto&& es = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
        prism_rtl::more(prism_rtl::rc(FirstFrame(lx, env, es)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EArray>(_m) ? ({
        auto&& es = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
        prism_rtl::more(prism_rtl::rc(FirstFrame(lx, env, es)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
        prism_rtl::more(prism_rtl::rc(FrameCall(lx, env, x, false)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EField>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        prism_rtl::more(prism_rtl::rc(FrameCall(lx, env, x, false)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& i = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        prism_rtl::more(prism_rtl::rc(FirstFrame(lx, env, Array(std::vector{x, i}))));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
        prism_rtl::more(prism_rtl::rc(FirstFrame(lx, env, append(Array(std::vector{x}), each(args, [&](const crate::syntax::Arg& a) { return a->value; })))));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ECast>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a0;
        prism_rtl::more(prism_rtl::rc(FrameCall(lx, env, x, false)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ELit>(_m) ? ({
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
        ({
        auto&& _m = l.kind;
        prism_rtl::is<crate::syntax::LitKind::LText>(_m) ? ({
        auto&& segs = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
        prism_rtl::more(prism_rtl::rc(FirstFrame(lx, env, placeholders(segs))));
    })
        : prism_rtl::finished(std::optional<crate::syntax::Expr>{});
    });
    })
        : prism_rtl::finished(std::optional<crate::syntax::Expr>{});
    });
}


/// `Start FrameCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<crate::syntax::Expr>> start_frame_call(Lx lx, Env env, crate::syntax::Expr e, bool top) {
    return prism_rtl::make_rc<FrameCall>(lx, env, e, top);
}


/// Placeholders: fn [TextSeg] -> [Expr]
Array<crate::syntax::Expr> placeholders(const Array<crate::syntax::TextSeg>& segs) {
    return fold(segs, Array<crate::syntax::Expr>{}, [&](const Array<crate::syntax::Expr>& acc, const crate::syntax::TextSeg& sg) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
            if (prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(sg)) {
                auto&& x = prism_rtl::as<crate::syntax::TextSeg::SegPlaceholder>(sg).a0;
                _v.set(crate::prelude::push(acc, x));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// ?FirstFrame: unbounded fn Lx, Env, [Expr] -> ?Expr
std::optional<crate::syntax::Expr> first_frame(const Lx& lx, const Env& env, const Array<crate::syntax::Expr>& es) {
    return run_to_end(fold_job(es, std::optional<crate::syntax::Expr>{}, ({
        auto lx_1 = lx;
        auto env_2 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<crate::syntax::Expr>>(std::tuple<std::optional<crate::syntax::Expr>, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<std::optional<crate::syntax::Expr>, crate::syntax::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_3 = lx_1;
            auto env_2_3 = env_2;
            entered(once_job([=]() {
            return ({
                auto found_opt = p0;
                auto x = p1;
                ({
                prism_rtl::is_some(found_opt) ? ({
                auto&& f = prism_rtl::some_of(found_opt);
                prism_rtl::finished(std::optional(f));
            })
                : prism_rtl::is_none(found_opt) ? prism_rtl::more(prism_rtl::rc(FrameCall(lx_1_3, env_2_3, x, false)))
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<std::optional<crate::syntax::Expr>> FirstFrame::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& es = this->es;
    return fold_job(es, std::optional<crate::syntax::Expr>{}, ({
        auto lx_1 = lx;
        auto env_2 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<crate::syntax::Expr>>(std::tuple<std::optional<crate::syntax::Expr>, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<std::optional<crate::syntax::Expr>, crate::syntax::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_3 = lx_1;
            auto env_2_3 = env_2;
            entered(once_job([=]() {
            return ({
                auto found_opt = p0;
                auto x = p1;
                ({
                prism_rtl::is_some(found_opt) ? ({
                auto&& f = prism_rtl::some_of(found_opt);
                prism_rtl::finished(std::optional(f));
            })
                : prism_rtl::is_none(found_opt) ? prism_rtl::more(prism_rtl::rc(FrameCall(lx_1_3, env_2_3, x, false)))
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start FirstFrame, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<crate::syntax::Expr>> start_first_frame(Lx lx, Env env, Array<crate::syntax::Expr> es) {
    return prism_rtl::make_rc<FirstFrame>(lx, env, es);
}


/// Frame: unbounded fn Lx, Env, Expr, Text, (unbounded fn Env -> Ex) -> Ex
crate::lower::model::Ex frame(const Lx& lx, const Env& env, const crate::syntax::Expr& call, const Text& rest_text_, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Env)>& cont_fn) {
    auto&& _m = call.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        auto qk_opt = tail_callee(lx, env, c);
        auto qk = or_(qk_opt, Text::lit(""));
        auto base_ = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& q = prism_rtl::some_of(qk_opt);
                _v.set(or_(crate::prelude::get(lx.rs_names, q), snake(crate::check::types::bare_name(q))));
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(snake(callee_text(c)));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto v_ = prism_rtl::cat(base_, "_", call.span.start);
        auto t = out_ty_of(lx, peel(type_at(lx, call.span)));
        auto caps = fold(keys(env->names), Array<std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>>{}, [&](const Array<std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>>& acc, const Text& k) {
            return ({
                __label__ _done;
                prism_rtl::Slot<Array<std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>>> _v;
                auto&& _m = crate::prelude::get(env->names, k);
                if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                    auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                    auto&& mode = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                    auto&& bt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                    _v.set(((mode == Holding(Holding::ByRef{})) || (mode == Holding(Holding::RcRef{}))) && mentions(rest_text_, instance_of(k))
                        ? crate::prelude::push(acc, std::tuple{k, rs, mode, bt})
                        : acc);
                    goto _done;
                }
                {
                    _v.set(acc);
                    goto _done;
                }
            _done:
                _v.take();
            });
        });
        auto dos = each(caps, [&](const std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>& _p0) {
            auto&& rs = std::get<1>(_p0);
            auto&& mode = std::get<2>(_p0);
            auto&& bt = std::get<3>(_p0);
            return crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{place_stem(rs)}), own(Vl(Vl::VlPlace{rs, mode, bt}))});
        });
        auto env2 = fold(caps, env, [&](const Env& en, const std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>& _p1) {
            auto&& k = std::get<0>(_p1);
            auto&& rs = std::get<1>(_p1);
            auto&& bt = std::get<3>(_p1);
            return bind(en, k, Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
        });
        auto vals = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& q = prism_rtl::some_of(qk_opt);
                _v.set(named_args_owned(lx, env2, q, args));
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
                    auto&& _m = local_job_fn(lx, env2, c);
                    if (prism_rtl::is_some(_m)) {
                        auto&& f = prism_rtl::some_of(_m);
                        _v.set(start_args(lx, env2, f, args));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(run_to_end(each_job(args, ({
                            auto lx_1 = lx;
                            auto env2_2 = env2;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=](crate::syntax::Arg p0) {
                            return ({
                                auto lx_1_3 = lx_1;
                                auto env2_2_3 = env2_2;
                                entered(once_job([=]() {
                                return ({
                                    auto a = p0;
                                    call_then(start_value_of(lx_1_3, env2_2_3, a->value), [=](Vl value_of_165107) { return prism_rtl::finished(own(value_of_165107)); });
                                });
                            }));
                            });
                        })));
                        }))));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto env3 = bind_span(env2, place_key(lx, call.span), Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XVar{v_}), t}));
        auto body = run_to_end(cont_fn(env3));
        auto [job, how] = ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<crate::lower::model::Ex, Text>> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& q = prism_rtl::some_of(qk_opt);
                _v.set(std::tuple{crate::lower::model::Ex(crate::lower::model::Ex::XCall{path_in(lx, owner_of(q), prism_rtl::cat("start_", base_)), vals}), enters_at_once(lx, q, args)
                    ? Text::lit("call_value")
                    : Text::lit("call_then")});
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<crate::lower::model::Ex, Text>> _v;
                    auto&& _m = local_job_fn(lx, env2, c);
                    if (prism_rtl::is_some(_m)) {
                        auto&& f = prism_rtl::some_of(_m);
                        _v.set(std::tuple{start_call(f, vals), Text::lit("call_value")});
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<std::tuple<crate::lower::model::Ex, Text>> _v;
                            auto&& _m = prelude_job_call(lx, env2, call);
                            if (prism_rtl::is_some(_m)) {
                                auto&& pj = prism_rtl::some_of(_m);
                                _v.set(std::tuple{pj, Text::lit("call_value")});
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(std::tuple{refusal(Text::lit("a call this frame cannot enter")), Text::lit("call_then")});
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto enter = crate::lower::model::Ex(crate::lower::model::Ex::XCall{how, Array(std::vector{job, crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{v_})), t})}), prism_rtl::rc(body)})})});
        return len(dos) == Nat(0u)
            ? enter
            : crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos, prism_rtl::rc(enter)});
    }
    {
        return run_to_end(cont_fn(env));
    }
}


prism_rtl::Turn<crate::lower::model::Ex> Frame::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& call = this->call;
    const auto& rest_text_ = this->rest_text_;
    const auto& cont_fn = this->cont_fn;
    return ({
        auto&& _m = call.kind;
        prism_rtl::is<crate::syntax::ExprKind::ECall>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        ({
        auto qk_opt = tail_callee(lx, env, c);
        auto qk = or_(qk_opt, Text::lit(""));
        auto base_ = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& q = prism_rtl::some_of(qk_opt);
                _v.set(or_(crate::prelude::get(lx.rs_names, q), snake(crate::check::types::bare_name(q))));
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(snake(callee_text(c)));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto v_ = prism_rtl::cat(base_, "_", call.span.start);
        auto cont_fn_1 = cont_fn;
        auto args_2 = args;
        auto c_3 = c;
        auto call_4 = call;
        auto env_5 = env;
        auto lx_6 = lx;
        auto rest_text__7 = rest_text_;
        call_then(start_out_ty_of(lx_6, peel(type_at(lx_6, call_4.span))), [=](crate::lower::model::OutTy out_ty_of_164352) {
        return ({
            auto t = out_ty_of_164352;
            auto caps = fold(keys(env_5->names), Array<std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>>{}, [&](const Array<std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>>& acc, const Text& k) {
                return ({
                    __label__ _done;
                    prism_rtl::Slot<Array<std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>>> _v;
                    auto&& _m = crate::prelude::get(env_5->names, k);
                    if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                        auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                        auto&& mode = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                        auto&& bt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                        _v.set(((mode == Holding(Holding::ByRef{})) || (mode == Holding(Holding::RcRef{}))) && mentions(rest_text__7, instance_of(k))
                            ? crate::prelude::push(acc, std::tuple{k, rs, mode, bt})
                            : acc);
                        goto _done;
                    }
                    {
                        _v.set(acc);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            });
            auto dos = each(caps, [&](const std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>& _p0) {
                auto&& rs = std::get<1>(_p0);
                auto&& mode = std::get<2>(_p0);
                auto&& bt = std::get<3>(_p0);
                return crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{place_stem(rs)}), own(Vl(Vl::VlPlace{rs, mode, bt}))});
            });
            auto env2 = fold(caps, env_5, [&](const Env& en, const std::tuple<Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy>& _p1) {
                auto&& k = std::get<0>(_p1);
                auto&& rs = std::get<1>(_p1);
                auto&& bt = std::get<3>(_p1);
                return bind(en, k, Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
            });
            auto vals = ({
                __label__ _done;
                prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
                if (prism_rtl::is_some(qk_opt)) {
                    auto&& q = prism_rtl::some_of(qk_opt);
                    _v.set(named_args_owned(lx_6, env2, q, args_2));
                    goto _done;
                }
                if (prism_rtl::is_none(qk_opt)) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
                        auto&& _m = local_job_fn(lx_6, env2, c_3);
                        if (prism_rtl::is_some(_m)) {
                            auto&& f = prism_rtl::some_of(_m);
                            _v.set(start_args(lx_6, env2, f, args_2));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(run_to_end(each_job(args_2, ({
                                auto lx_6_8 = lx_6;
                                auto env2_8 = env2;
                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=](crate::syntax::Arg p0) {
                                return ({
                                    auto lx_6_8_9 = lx_6_8;
                                    auto env2_8_9 = env2_8;
                                    entered(once_job([=]() {
                                    return ({
                                        auto a = p0;
                                        call_then(start_value_of(lx_6_8_9, env2_8_9, a->value), [=](Vl value_of_165107) { return prism_rtl::finished(own(value_of_165107)); });
                                    });
                                }));
                                });
                            })));
                            }))));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto env3 = bind_span(env2, place_key(lx_6, call_4.span), Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XVar{v_}), t}));
            call_value(cont_fn_1(env3), [=](crate::lower::model::Ex cont_165235) {
            return ({
                auto body = cont_165235;
                auto [job, how] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<crate::lower::model::Ex, Text>> _v;
                    if (prism_rtl::is_some(qk_opt)) {
                        auto&& q = prism_rtl::some_of(qk_opt);
                        _v.set(std::tuple{crate::lower::model::Ex(crate::lower::model::Ex::XCall{path_in(lx_6, owner_of(q), prism_rtl::cat("start_", base_)), vals}), enters_at_once(lx_6, q, args_2)
                            ? Text::lit("call_value")
                            : Text::lit("call_then")});
                        goto _done;
                    }
                    if (prism_rtl::is_none(qk_opt)) {
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<std::tuple<crate::lower::model::Ex, Text>> _v;
                            auto&& _m = local_job_fn(lx_6, env2, c_3);
                            if (prism_rtl::is_some(_m)) {
                                auto&& f = prism_rtl::some_of(_m);
                                _v.set(std::tuple{start_call(f, vals), Text::lit("call_value")});
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(({
                                    __label__ _done;
                                    prism_rtl::Slot<std::tuple<crate::lower::model::Ex, Text>> _v;
                                    auto&& _m = prelude_job_call(lx_6, env2, call_4);
                                    if (prism_rtl::is_some(_m)) {
                                        auto&& pj = prism_rtl::some_of(_m);
                                        _v.set(std::tuple{pj, Text::lit("call_value")});
                                        goto _done;
                                    }
                                    if (prism_rtl::is_none(_m)) {
                                        _v.set(std::tuple{refusal(Text::lit("a call this frame cannot enter")), Text::lit("call_then")});
                                        goto _done;
                                    }
                                    prism_rtl::unreachable("no arm matched");
                                _done:
                                    _v.take();
                                }));
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto enter = crate::lower::model::Ex(crate::lower::model::Ex::XCall{how, Array(std::vector{job, crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{v_})), t})}), prism_rtl::rc(body)})})});
                len(dos) == Nat(0u)
                ? prism_rtl::finished(enter)
                : prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos, prism_rtl::rc(enter)}));
            });
        });
        });
    });
    });
    })
        : cont_fn(env)->cycle();
    });
}


/// `Start Frame, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_frame(Lx lx, Env env, crate::syntax::Expr call, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Env)> cont_fn) {
    return prism_rtl::make_rc<Frame>(lx, env, call, rest_text_, cont_fn);
}


/// ?LocalJobFn: unbounded fn Lx, Env, Expr -> ?Vl
std::optional<Vl> local_job_fn(const Lx& lx, const Env& env, const crate::syntax::Expr& c) {
    auto&& _m = c.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return (len(n->path_) == Nat(1u)) && crate::check::env::has_key(env->names, crate::check::env::sname_key(n))
            ? job_value(name_value(lx, env, n, c.span))
            : std::optional<Vl>{};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return local_job_fn(lx, env, x);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        return job_value(value_of(lx, env, c));
    }
    {
        return std::optional<Vl>{};
    }
}


prism_rtl::Turn<std::optional<Vl>> LocalJobFn::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& c = this->c;
    return ({
        auto&& _m = c.kind;
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        (len(n->path_) == Nat(1u)) && crate::check::env::has_key(env->names, crate::check::env::sname_key(n))
        ? ({
        auto c_1 = c;
        auto env_2 = env;
        auto lx_3 = lx;
        auto n_4 = n;
        call_then(start_name_value(lx_3, env_2, n_4, c_1.span), [=](Vl name_value_166152) { return prism_rtl::finished(job_value(name_value_166152)); });
    })
        : prism_rtl::finished(std::optional<Vl>{});
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(LocalJobFn(lx, env, x)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EField>(_m) ? ({
        auto c_1 = c;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(start_value_of(lx_3, env_2, c_1), [=](Vl value_of_166283) { return prism_rtl::finished(job_value(value_of_166283)); });
    })
        : prism_rtl::finished(std::optional<Vl>{});
    });
}


/// `Start LocalJobFn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Vl>> start_local_job_fn(Lx lx, Env env, crate::syntax::Expr c) {
    return prism_rtl::make_rc<LocalJobFn>(lx, env, c);
}


/// ?JobValue: fn Vl -> ?Vl
std::optional<Vl> job_value(const Vl& f) {
    auto&& _m = value_ty(f);
    if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m)) {
        return std::optional(f);
    }
    {
        return std::optional<Vl>{};
    }
}


/// StartCall: fn Vl, [Ex] -> Ex
crate::lower::model::Ex start_call(const Vl& f, const Array<crate::lower::model::Ex>& vals) {
    return crate::lower::model::Ex(crate::lower::model::Ex::XApply{prism_rtl::rc(ref_(f)), Array(std::vector{one_or_tuple(vals)})});
}


/// OneOrTuple: fn [Ex] -> Ex
crate::lower::model::Ex one_or_tuple(const Array<crate::lower::model::Ex>& xs0) {
    {
        auto&& c0_0 = xs0;
        if (c0_0.size() == 1u) {
            {
                auto&& _c1 = index(c0_0, Nat(0u));
                if (prism_rtl::is_some(_c1)) {
                    auto&& one = prism_rtl::some_of(_c1);
                    return one;
                }
            }
        }
    }
    {
        auto&& vals = xs0;
        return crate::lower::model::Ex(crate::lower::model::Ex::XTuple{vals});
    }
}


/// CalleeText: fn Expr -> Text
Text callee_text(const crate::syntax::Expr& c) {
    auto&& _m = c.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return crate::check::env::dotted(n->path_);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return callee_text(x);
    }
    {
        return Text::lit("call");
    }
}


/// RestText: fn Lx, Range, Range, Range -> Text
Text rest_text(const Lx& lx, const crate::syntax::Range& from, const crate::syntax::Range& call, const crate::syntax::Range& to) {
    auto&& _m = index(lx.g.srcs, lx->file);
    if (prism_rtl::is_some(_m)) {
        auto&& src = prism_rtl::some_of(_m);
        return crate::check::errors::span_text(src, crate::syntax::Range{.start = from.start, .end = to.end});
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// Mentions: fn Text, Text -> Bool
bool mentions(const Text& text, const Text& name) {
    auto parts = split(text, name);
    auto last = crate::syntax::lexer::dec(len(parts));
    return fold(crate::check::errors::range0(last), false, [&](const bool& found, const Nat& i) {
        return ({
            auto before_ = or_(index(parts, i), Text::lit(""));
            auto after_ = or_(index(parts, i + Nat(1u)), Text::lit(""));
            auto left_word = before_ != Text::lit("")
                ? ends_ident(before_)
                : (i > Nat(0u)) && ends_ident(name);
            auto right_word = after_ != Text::lit("")
                ? starts_ident(after_)
                : ((i + Nat(1u)) < last) && starts_ident(name);
            found || ((!left_word) && (!right_word));
        });
    });
}


/// EndsIdent: fn Text -> Bool
bool ends_ident(const Text& t) {
    return (len_text(t) > Nat(0u)) && crate::syntax::lexer::is_ident_char(crate::syntax::lexer::last_char(t));
}


/// StartsIdent: fn Text -> Bool
bool starts_ident(const Text& t) {
    return (len_text(t) > Nat(0u)) && crate::syntax::lexer::is_ident_char(crate::syntax::lexer::head(t));
}


/// TailBody: unbounded fn Lx, Env, FnBody -> Ex
crate::lower::model::Ex tail_body(const Lx& lx, const Env& env, const crate::syntax::FnBody& fn_body2) {
    if (prism_rtl::is<crate::syntax::FnBody::BodyExpr>(fn_body2)) {
        auto&& x = prism_rtl::as<crate::syntax::FnBody::BodyExpr>(fn_body2).a0;
        return tail(lx, env, x);
    }
    if (prism_rtl::is<crate::syntax::FnBody::BodyBlock>(fn_body2)) {
        auto&& b = prism_rtl::as<crate::syntax::FnBody::BodyBlock>(fn_body2).a0;
        return tail_block(lx, env, b);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::model::Ex> TailBody::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& fn_body2 = this->fn_body2;
    return ({
        prism_rtl::is<crate::syntax::FnBody::BodyExpr>(fn_body2) ? ({
        auto&& x = prism_rtl::as<crate::syntax::FnBody::BodyExpr>(fn_body2).a0;
        prism_rtl::more(prism_rtl::rc(Tail(lx, env, x)));
    })
        : prism_rtl::is<crate::syntax::FnBody::BodyBlock>(fn_body2) ? ({
        auto&& b = prism_rtl::as<crate::syntax::FnBody::BodyBlock>(fn_body2).a0;
        prism_rtl::more(prism_rtl::rc(TailBlock(lx, env, b)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}

}  // namespace crate::lower
