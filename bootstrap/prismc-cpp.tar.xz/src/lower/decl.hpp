// The module `Lower`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace lower {

struct Lx;

struct ValueNames;

struct GlobalBase;

struct FieldSpell;

struct GlobalNames;

struct LocalNameAt;

struct LocalBase;

struct TrimUnderscores;

struct Base32;

}  // namespace lower

}  // namespace crate
