// The module `Lower`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace lower {

class Bn;

struct Env;

class Holding;

class Layer;

struct Lx;

struct PatOut;

class Vl;

struct OutTyOf;

struct RustTyOfParams;

struct NamedTy;

struct Layouts;

struct Reaches;

struct Floaty;

struct Podable;

struct LiteralValue;

struct TextValue;

struct SegEx;

struct ValueOf;

struct UnboundValueOf;

struct IsEventValue;

struct HasEventSource;

struct IsEventSource;

struct EventValueOf;

struct ValueByKind;

struct PureBlueprint;

struct PlainBlueprint;

struct DynamicBlueprint;

struct ElementBlueprint;

struct NameValue;

struct GlobalValue;

struct Application;

struct InlineLocalFn;

struct Argument;

struct ArgumentByKind;

struct TagValue;

struct GlobalCall;

struct ArgsFor;

struct CtorApp;

struct CtorFn;

struct CtorArgs;

struct MethodCall;

struct PreludeMethod;

struct BinaryValue;

struct PreludeCall;

struct PreludeJob;

struct PreludeJobCall;

struct AsJobValue;

struct NamedArgsOwned;

struct StartArgs;

struct FieldValue;

struct FieldInfo;

struct Instantiated;

struct IndexValue;

struct ReadNames;

struct LambdaExprs;

struct LambdaValue;

struct PlainLambda;

struct LambdaParamTys;

struct IsKnownTy;

struct JobLambda;

struct LambdaArg;

struct LambdaBodyValue;

struct ClosureParams;

struct IfValue;

struct MatchValue;

struct ArmPat;

struct BlockValue;

struct BlockTy;

struct PlainBlockValue;

struct BlockStmt;

struct GenericLet;

struct Instantiations;

struct Expanded;

struct OpenQ;

struct OpenTyQs;

struct WidgetLetLx;

struct PlainLet;

struct RustPat;

struct WrapPat;

struct LitPat;

struct CtorPat;

struct SubPat;

struct BehindRc;

struct RecordPat;

struct FieldsPat;

struct TagPat;

struct LiveFieldPat;

struct FamilyPat;

struct ErrorPat;

struct ArrayPat;

struct TemplateValue;

struct TemplatePartDos;

struct TemplateArgs;

struct GivenValue;

struct UpdateValue;

struct UpdStmts;

struct UpdStmt;

struct UpdFor;

struct UpdForRefs;

struct UpdForValues;

struct UpdIf;

struct UpdMatch;

struct GuardConds;

struct PlaceOf;

struct Assign;

struct ClausesBody;

struct FnBodyValue;

struct FnDefOf;

struct LetGetter;

struct SelfIn;

struct TraitDefOf;

struct ImplDefOf;

struct IfGenLine;

struct Tail;

struct TailHere;

struct TailBlock;

struct TailFrom;

struct UpdTail;

struct UpdTailFrom;

struct StmtJob;

struct WhileJob;

struct StmtsThen;

struct IfJob;

struct MatchJob;

struct ForJob;

struct FrameCall;

struct FirstFrame;

struct Frame;

struct LocalJobFn;

struct TailBody;

struct TailMatch;

struct JobFieldNames;

struct JobDefOf;

struct JobClauses;

struct LowerProgram;

struct WithNeeds;

struct NamedMods;

struct WithGroups;

struct ReachedBy;

struct NeededMods;

struct ModRefs;

struct ProgDefOf;

struct JobRoots;

struct UnboundedValues;

struct RunTargets;

struct TailTargets;

struct TailsOfBody;

struct ModDefOf;

struct DefItems;

struct TyDefs;

struct TyPodable;

struct CaseField;

struct TagDefOf;

struct RowDefOf;

struct ElemRow;

struct AnswerEnum;

struct AnswerTy;

struct CheckDefOf;

}  // namespace lower

namespace lower {

/// `Bn`:
///
/// ```prism
/// type Bn = choice:
/// ```
class Bn {
public:
    using prism_value = void;
    struct BnLocal;
    struct BnHold;
    struct BnDyn;
    struct BnEv;
    struct BnParts;
    struct BnWidget;
    struct BnLocalFn;
    using Cases = std::variant<BnLocal, BnHold, BnDyn, BnEv, BnParts, BnWidget, BnLocalFn>;
    template <class C>
        requires prism_rtl::one_of<C, BnLocal, BnHold, BnDyn, BnEv, BnParts, BnWidget, BnLocalFn>
    Bn(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `Holding`:
///
/// ```prism
/// type Holding = choice:
/// ```
class Holding {
public:
    using prism_value = void;
    struct ByRef;
    struct Owned;
    struct RcRef;
    struct RcOwned;
    using Cases = std::variant<ByRef, Owned, RcRef, RcOwned>;
    template <class C>
        requires prism_rtl::one_of<C, ByRef, Owned, RcRef, RcOwned>
    Holding(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Holding> from_pod(const Pod& whole);
    friend inline bool operator==(const Holding& a, const Holding& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `Layer`:
///
/// ```prism
/// type Layer = choice:
/// ```
class Layer {
public:
    using prism_value = void;
    struct LyPlain;
    struct LyDyn;
    struct LyEv;
    struct LyBlueprint;
    using Cases = std::variant<LyPlain, LyDyn, LyEv, LyBlueprint>;
    template <class C>
        requires prism_rtl::one_of<C, LyPlain, LyDyn, LyEv, LyBlueprint>
    Layer(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Layer> from_pod(const Pod& whole);
    friend inline bool operator==(const Layer& a, const Layer& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `Vl`:
///
/// ```prism
/// type Vl = choice:
/// ```
class Vl {
public:
    using prism_value = void;
    struct VlPlace;
    struct VlOwned;
    using Cases = std::variant<VlPlace, VlOwned>;
    template <class C>
        requires prism_rtl::one_of<C, VlPlace, VlOwned>
    Vl(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    Pod to_pod() const;
    static Result<Vl> from_pod(const Pod& whole);

private:
    prism_rtl::Rc<const Cases> cases_;
};


}  // namespace lower

}  // namespace crate
