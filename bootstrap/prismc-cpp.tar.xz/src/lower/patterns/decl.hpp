// The module `Lower.Patterns`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace lower::patterns {

struct PatOut;

struct RustPat;

struct WrapPat;

struct LitPat;

struct CtorPat;

struct SubPat;

struct BehindRc;

struct RecordPat;

struct FieldsPat;

struct TagPat;

struct LiveFieldPat;

struct FamilyPat;

struct ErrorPat;

struct ArrayPat;

}  // namespace lower::patterns

}  // namespace crate
