// The module `Lower.Patterns`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <lower/patterns/types.hpp>
#include "elem.types.hpp"
#include <lower/model/types.hpp>
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace lower::patterns {

PatOut pat_only(const crate::lower::model::Pa& pa_p0);

PatOut rust_pat(const crate::lower::Lx& lx_p0, const crate::syntax::Pattern_& p_p1, const crate::check::types::Ty& ty_p2, const crate::lower::types::Holding& mode_p3, const Text& fresh_p4);

prism_rtl::JobRef<PatOut> start_rust_pat(crate::lower::Lx lx_p0, crate::syntax::Pattern_ p_p1, crate::check::types::Ty ty_p2, crate::lower::types::Holding mode_p3, Text fresh_p4);

crate::syntax::Pattern_ dummy_pat();

crate::check::types::Ty inner_ty(const crate::check::types::Ty& t_p0);

bool is_unit_ctor(const crate::lower::Lx& lx_p0, const Text& qk_p1);

PatOut wrap_pat(const crate::lower::Lx& lx_p0, const Text& ctor_p1, const crate::syntax::Pattern_& q_p2, const crate::check::types::Ty& inner_p3, const crate::lower::types::Holding& mode_p4, const Text& fresh_p5);

prism_rtl::JobRef<PatOut> start_wrap_pat(crate::lower::Lx lx_p0, Text ctor_p1, crate::syntax::Pattern_ q_p2, crate::check::types::Ty inner_p3, crate::lower::types::Holding mode_p4, Text fresh_p5);

PatOut lit_pat(const crate::lower::Lx& lx_p0, const crate::syntax::Literal& l_p1, const crate::check::types::Ty& ty_p2, const crate::lower::types::Holding& mode_p3, const Text& fresh_p4, const bool& neg_p5);

prism_rtl::JobRef<PatOut> start_lit_pat(crate::lower::Lx lx_p0, crate::syntax::Literal l_p1, crate::check::types::Ty ty_p2, crate::lower::types::Holding mode_p3, Text fresh_p4, bool neg_p5);

PatOut ctor_pat(const crate::lower::Lx& lx_p0, const crate::syntax::SName& n_p1, const Array<crate::syntax::Pattern_>& ps_p2, const crate::check::types::Ty& ty_p3, const crate::lower::types::Holding& mode_p4, const Text& fresh_p5);

prism_rtl::JobRef<PatOut> start_ctor_pat(crate::lower::Lx lx_p0, crate::syntax::SName n_p1, Array<crate::syntax::Pattern_> ps_p2, crate::check::types::Ty ty_p3, crate::lower::types::Holding mode_p4, Text fresh_p5);

PatOut sub_pat(const crate::lower::Lx& lx_p0, const crate::check::env::CtorInfo& c_p1, const Nat& i_p2, const crate::syntax::Pattern_& p_p3, const crate::check::types::Ty& ty_p4, const crate::lower::types::Holding& mode_p5, const Text& fresh_p6);

prism_rtl::JobRef<PatOut> start_sub_pat(crate::lower::Lx lx_p0, crate::check::env::CtorInfo c_p1, Nat i_p2, crate::syntax::Pattern_ p_p3, crate::check::types::Ty ty_p4, crate::lower::types::Holding mode_p5, Text fresh_p6);

PatOut behind_rc(const crate::lower::Lx& lx_p0, const crate::syntax::Pattern_& p_p1, const crate::check::types::Ty& ty_p2, const crate::lower::types::Holding& rc_mode_p3, const Text& fresh_p4);

prism_rtl::JobRef<PatOut> start_behind_rc(crate::lower::Lx lx_p0, crate::syntax::Pattern_ p_p1, crate::check::types::Ty ty_p2, crate::lower::types::Holding rc_mode_p3, Text fresh_p4);

PatOut record_pat(const crate::lower::Lx& lx_p0, const crate::syntax::SName& n_p1, const Array<crate::syntax::FieldPat>& fps_p2, const bool& rest_p3, const crate::check::types::Ty& ty_p4, const crate::lower::types::Holding& mode_p5, const Text& fresh_p6);

prism_rtl::JobRef<PatOut> start_record_pat(crate::lower::Lx lx_p0, crate::syntax::SName n_p1, Array<crate::syntax::FieldPat> fps_p2, bool rest_p3, crate::check::types::Ty ty_p4, crate::lower::types::Holding mode_p5, Text fresh_p6);

PatOut rest_case_pat(const crate::check::env::CtorInfo& c_p0, const Array<std::tuple<Text, Array<crate::check::types::Ty>>>& cases_p1, const Text& ty_path_p2);

PatOut fields_pat(const crate::lower::Lx& lx_p0, const crate::check::env::CtorInfo& c_p1, const Array<crate::syntax::FieldPat>& fps_p2, const bool& rest_p3, const crate::check::types::Ty& ty_p4, const crate::lower::types::Holding& mode_p5, const Text& fresh_p6, const Text& ty_path_p7);

prism_rtl::JobRef<PatOut> start_fields_pat(crate::lower::Lx lx_p0, crate::check::env::CtorInfo c_p1, Array<crate::syntax::FieldPat> fps_p2, bool rest_p3, crate::check::types::Ty ty_p4, crate::lower::types::Holding mode_p5, Text fresh_p6, Text ty_path_p7);

crate::syntax::FieldPat dummy_field_pat();

crate::check::env::TagInfo dummy_tag_info();

bool is_live(const crate::check::types::Ty& t_p0);

Text tag_field_name(const crate::syntax::FieldPat& fp_p0, const Array<Text>& names_p1, const Nat& i_p2);

PatOut tag_pat(const crate::lower::Lx& lx_p0, const crate::check::env::TagInfo& tg_p1, const Array<crate::syntax::FieldPat>& fps_p2, const bool& rest_p3, const crate::check::types::Ty& ty_p4, const crate::lower::types::Holding& mode_p5, const Text& fresh_p6);

prism_rtl::JobRef<PatOut> start_tag_pat(crate::lower::Lx lx_p0, crate::check::env::TagInfo tg_p1, Array<crate::syntax::FieldPat> fps_p2, bool rest_p3, crate::check::types::Ty ty_p4, crate::lower::types::Holding mode_p5, Text fresh_p6);

PatOut live_field_pat(const crate::lower::Lx& lx_p0, const crate::syntax::Pattern_& p_p1, const Text& variant_p2, const Text& fname_p3, const crate::check::types::Ty& ft_p4, const Text& fresh_p5);

prism_rtl::JobRef<PatOut> start_live_field_pat(crate::lower::Lx lx_p0, crate::syntax::Pattern_ p_p1, Text variant_p2, Text fname_p3, crate::check::types::Ty ft_p4, Text fresh_p5);

crate::lower::model::Ex live_projection(const Text& fresh_p0, const Text& variant_p1, const Text& fname_p2, const crate::lower::model::OutTy& ft_p3);

PatOut family_pat(const crate::lower::Lx& lx_p0, const crate::syntax::QualName& q_p1, const crate::check::types::Ty& ty_p2, const Text& fresh_p3);

prism_rtl::JobRef<PatOut> start_family_pat(crate::lower::Lx lx_p0, crate::syntax::QualName q_p1, crate::check::types::Ty ty_p2, Text fresh_p3);

PatOut error_pat(const crate::lower::Lx& lx_p0, const Array<crate::syntax::FieldPat>& fps_p1, const crate::check::types::Ty& ty_p2, const crate::lower::types::Holding& mode_p3, const Text& fresh_p4);

prism_rtl::JobRef<PatOut> start_error_pat(crate::lower::Lx lx_p0, Array<crate::syntax::FieldPat> fps_p1, crate::check::types::Ty ty_p2, crate::lower::types::Holding mode_p3, Text fresh_p4);

PatOut array_pat(const crate::lower::Lx& lx_p0, const Array<crate::syntax::Pattern_>& ps_p1, const crate::check::types::Ty& ty_p2, const crate::lower::types::Holding& mode_p3, const Text& fresh_p4);

prism_rtl::JobRef<PatOut> start_array_pat(crate::lower::Lx lx_p0, Array<crate::syntax::Pattern_> ps_p1, crate::check::types::Ty ty_p2, crate::lower::types::Holding mode_p3, Text fresh_p4);

}  // namespace lower::patterns


namespace lower::patterns {

/// The step machine of `RustPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustPat: unbounded fn Lx, Pattern, Ty, Holding, Text -> PatOut
struct RustPat : prism_rtl::Job<PatOut> {
    crate::lower::Lx lx_p0;
    crate::syntax::Pattern_ p_p1;
    crate::check::types::Ty ty_p2;
    crate::lower::types::Holding mode_p3;
    Text fresh_p4;
    RustPat(crate::lower::Lx lx_p0, crate::syntax::Pattern_ p_p1, crate::check::types::Ty ty_p2, crate::lower::types::Holding mode_p3, Text fresh_p4) : lx_p0(std::move(lx_p0)), p_p1(std::move(p_p1)), ty_p2(std::move(ty_p2)), mode_p3(std::move(mode_p3)), fresh_p4(std::move(fresh_p4)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `WrapPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WrapPat: unbounded fn Lx, Text, Pattern, Ty, Holding, Text -> PatOut
struct WrapPat : prism_rtl::Job<PatOut> {
    crate::lower::Lx lx_p0;
    Text ctor_p1;
    crate::syntax::Pattern_ q_p2;
    crate::check::types::Ty inner_p3;
    crate::lower::types::Holding mode_p4;
    Text fresh_p5;
    WrapPat(crate::lower::Lx lx_p0, Text ctor_p1, crate::syntax::Pattern_ q_p2, crate::check::types::Ty inner_p3, crate::lower::types::Holding mode_p4, Text fresh_p5) : lx_p0(std::move(lx_p0)), ctor_p1(std::move(ctor_p1)), q_p2(std::move(q_p2)), inner_p3(std::move(inner_p3)), mode_p4(std::move(mode_p4)), fresh_p5(std::move(fresh_p5)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `LitPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LitPat: unbounded fn Lx, Literal, Ty, Holding, Text, Bool -> PatOut
struct LitPat : prism_rtl::Job<PatOut> {
    crate::lower::Lx lx_p0;
    crate::syntax::Literal l_p1;
    crate::check::types::Ty ty_p2;
    crate::lower::types::Holding mode_p3;
    Text fresh_p4;
    bool neg_p5;
    LitPat(crate::lower::Lx lx_p0, crate::syntax::Literal l_p1, crate::check::types::Ty ty_p2, crate::lower::types::Holding mode_p3, Text fresh_p4, bool neg_p5) : lx_p0(std::move(lx_p0)), l_p1(std::move(l_p1)), ty_p2(std::move(ty_p2)), mode_p3(std::move(mode_p3)), fresh_p4(std::move(fresh_p4)), neg_p5(std::move(neg_p5)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `CtorPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CtorPat: unbounded fn Lx, SName, [Pattern], Ty, Holding, Text -> PatOut
struct CtorPat : prism_rtl::Job<PatOut> {
    crate::lower::Lx lx_p0;
    crate::syntax::SName n_p1;
    Array<crate::syntax::Pattern_> ps_p2;
    crate::check::types::Ty ty_p3;
    crate::lower::types::Holding mode_p4;
    Text fresh_p5;
    CtorPat(crate::lower::Lx lx_p0, crate::syntax::SName n_p1, Array<crate::syntax::Pattern_> ps_p2, crate::check::types::Ty ty_p3, crate::lower::types::Holding mode_p4, Text fresh_p5) : lx_p0(std::move(lx_p0)), n_p1(std::move(n_p1)), ps_p2(std::move(ps_p2)), ty_p3(std::move(ty_p3)), mode_p4(std::move(mode_p4)), fresh_p5(std::move(fresh_p5)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `SubPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SubPat: unbounded fn Lx, CtorInfo, Nat, Pattern, Ty, Holding, Text -> PatOut
struct SubPat : prism_rtl::Job<PatOut> {
    crate::lower::Lx lx_p0;
    crate::check::env::CtorInfo c_p1;
    Nat i_p2;
    crate::syntax::Pattern_ p_p3;
    crate::check::types::Ty ty_p4;
    crate::lower::types::Holding mode_p5;
    Text fresh_p6;
    SubPat(crate::lower::Lx lx_p0, crate::check::env::CtorInfo c_p1, Nat i_p2, crate::syntax::Pattern_ p_p3, crate::check::types::Ty ty_p4, crate::lower::types::Holding mode_p5, Text fresh_p6) : lx_p0(std::move(lx_p0)), c_p1(std::move(c_p1)), i_p2(std::move(i_p2)), p_p3(std::move(p_p3)), ty_p4(std::move(ty_p4)), mode_p5(std::move(mode_p5)), fresh_p6(std::move(fresh_p6)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `BehindRc`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BehindRc: unbounded fn Lx, Pattern, Ty, Holding, Text -> PatOut
struct BehindRc : prism_rtl::Job<PatOut> {
    crate::lower::Lx lx_p0;
    crate::syntax::Pattern_ p_p1;
    crate::check::types::Ty ty_p2;
    crate::lower::types::Holding rc_mode_p3;
    Text fresh_p4;
    BehindRc(crate::lower::Lx lx_p0, crate::syntax::Pattern_ p_p1, crate::check::types::Ty ty_p2, crate::lower::types::Holding rc_mode_p3, Text fresh_p4) : lx_p0(std::move(lx_p0)), p_p1(std::move(p_p1)), ty_p2(std::move(ty_p2)), rc_mode_p3(std::move(rc_mode_p3)), fresh_p4(std::move(fresh_p4)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `RecordPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RecordPat: unbounded fn Lx, SName, [FieldPat], Bool, Ty, Holding, Text -> PatOut
struct RecordPat : prism_rtl::Job<PatOut> {
    crate::lower::Lx lx_p0;
    crate::syntax::SName n_p1;
    Array<crate::syntax::FieldPat> fps_p2;
    bool rest_p3;
    crate::check::types::Ty ty_p4;
    crate::lower::types::Holding mode_p5;
    Text fresh_p6;
    RecordPat(crate::lower::Lx lx_p0, crate::syntax::SName n_p1, Array<crate::syntax::FieldPat> fps_p2, bool rest_p3, crate::check::types::Ty ty_p4, crate::lower::types::Holding mode_p5, Text fresh_p6) : lx_p0(std::move(lx_p0)), n_p1(std::move(n_p1)), fps_p2(std::move(fps_p2)), rest_p3(std::move(rest_p3)), ty_p4(std::move(ty_p4)), mode_p5(std::move(mode_p5)), fresh_p6(std::move(fresh_p6)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `FieldsPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FieldsPat: unbounded fn Lx, CtorInfo, [FieldPat], Bool, Ty, Holding, Text, Text -> PatOut
struct FieldsPat : prism_rtl::Job<PatOut> {
    crate::lower::Lx lx_p0;
    crate::check::env::CtorInfo c_p1;
    Array<crate::syntax::FieldPat> fps_p2;
    bool rest_p3;
    crate::check::types::Ty ty_p4;
    crate::lower::types::Holding mode_p5;
    Text fresh_p6;
    Text ty_path_p7;
    FieldsPat(crate::lower::Lx lx_p0, crate::check::env::CtorInfo c_p1, Array<crate::syntax::FieldPat> fps_p2, bool rest_p3, crate::check::types::Ty ty_p4, crate::lower::types::Holding mode_p5, Text fresh_p6, Text ty_path_p7) : lx_p0(std::move(lx_p0)), c_p1(std::move(c_p1)), fps_p2(std::move(fps_p2)), rest_p3(std::move(rest_p3)), ty_p4(std::move(ty_p4)), mode_p5(std::move(mode_p5)), fresh_p6(std::move(fresh_p6)), ty_path_p7(std::move(ty_path_p7)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `TagPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TagPat: unbounded fn Lx, TagInfo, [FieldPat], Bool, Ty, Holding, Text -> PatOut
struct TagPat : prism_rtl::Job<PatOut> {
    crate::lower::Lx lx_p0;
    crate::check::env::TagInfo tg_p1;
    Array<crate::syntax::FieldPat> fps_p2;
    bool rest_p3;
    crate::check::types::Ty ty_p4;
    crate::lower::types::Holding mode_p5;
    Text fresh_p6;
    TagPat(crate::lower::Lx lx_p0, crate::check::env::TagInfo tg_p1, Array<crate::syntax::FieldPat> fps_p2, bool rest_p3, crate::check::types::Ty ty_p4, crate::lower::types::Holding mode_p5, Text fresh_p6) : lx_p0(std::move(lx_p0)), tg_p1(std::move(tg_p1)), fps_p2(std::move(fps_p2)), rest_p3(std::move(rest_p3)), ty_p4(std::move(ty_p4)), mode_p5(std::move(mode_p5)), fresh_p6(std::move(fresh_p6)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `LiveFieldPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LiveFieldPat: unbounded fn Lx, Pattern, Text, Text, Ty, Text -> PatOut
struct LiveFieldPat : prism_rtl::Job<PatOut> {
    crate::lower::Lx lx_p0;
    crate::syntax::Pattern_ p_p1;
    Text variant_p2;
    Text fname_p3;
    crate::check::types::Ty ft_p4;
    Text fresh_p5;
    LiveFieldPat(crate::lower::Lx lx_p0, crate::syntax::Pattern_ p_p1, Text variant_p2, Text fname_p3, crate::check::types::Ty ft_p4, Text fresh_p5) : lx_p0(std::move(lx_p0)), p_p1(std::move(p_p1)), variant_p2(std::move(variant_p2)), fname_p3(std::move(fname_p3)), ft_p4(std::move(ft_p4)), fresh_p5(std::move(fresh_p5)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `FamilyPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FamilyPat: unbounded fn Lx, QualName, Ty, Text -> PatOut
struct FamilyPat : prism_rtl::Job<PatOut> {
    crate::lower::Lx lx_p0;
    crate::syntax::QualName q_p1;
    crate::check::types::Ty ty_p2;
    Text fresh_p3;
    FamilyPat(crate::lower::Lx lx_p0, crate::syntax::QualName q_p1, crate::check::types::Ty ty_p2, Text fresh_p3) : lx_p0(std::move(lx_p0)), q_p1(std::move(q_p1)), ty_p2(std::move(ty_p2)), fresh_p3(std::move(fresh_p3)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `ErrorPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ErrorPat: unbounded fn Lx, [FieldPat], Ty, Holding, Text -> PatOut
struct ErrorPat : prism_rtl::Job<PatOut> {
    crate::lower::Lx lx_p0;
    Array<crate::syntax::FieldPat> fps_p1;
    crate::check::types::Ty ty_p2;
    crate::lower::types::Holding mode_p3;
    Text fresh_p4;
    ErrorPat(crate::lower::Lx lx_p0, Array<crate::syntax::FieldPat> fps_p1, crate::check::types::Ty ty_p2, crate::lower::types::Holding mode_p3, Text fresh_p4) : lx_p0(std::move(lx_p0)), fps_p1(std::move(fps_p1)), ty_p2(std::move(ty_p2)), mode_p3(std::move(mode_p3)), fresh_p4(std::move(fresh_p4)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `ArrayPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ArrayPat: unbounded fn Lx, [Pattern], Ty, Holding, Text -> PatOut
struct ArrayPat : prism_rtl::Job<PatOut> {
    crate::lower::Lx lx_p0;
    Array<crate::syntax::Pattern_> ps_p1;
    crate::check::types::Ty ty_p2;
    crate::lower::types::Holding mode_p3;
    Text fresh_p4;
    ArrayPat(crate::lower::Lx lx_p0, Array<crate::syntax::Pattern_> ps_p1, crate::check::types::Ty ty_p2, crate::lower::types::Holding mode_p3, Text fresh_p4) : lx_p0(std::move(lx_p0)), ps_p1(std::move(ps_p1)), ty_p2(std::move(ty_p2)), mode_p3(std::move(mode_p3)), fresh_p4(std::move(fresh_p4)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


}  // namespace lower::patterns

}  // namespace crate
