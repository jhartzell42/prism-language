// The module `Lower.Patterns`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <lower/patterns/types.hpp>
#include "elem.types.hpp"
#include <lower/model/types.hpp>
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace lower::patterns {

PatOut pat_only(const crate::lower::model::Pa& pa);

PatOut rust_pat(const crate::lower::Lx& lx, const crate::syntax::Pattern_& p_, const crate::check::types::Ty& ty, const crate::lower::types::Holding& mode, const Text& fresh);

prism_rtl::JobRef<PatOut> start_rust_pat(crate::lower::Lx lx, crate::syntax::Pattern_ p_, crate::check::types::Ty ty, crate::lower::types::Holding mode, Text fresh);

crate::syntax::Pattern_ dummy_pat();

crate::check::types::Ty inner_ty(const crate::check::types::Ty& t);

bool is_unit_ctor(const crate::lower::Lx& lx, const Text& qk);

PatOut wrap_pat(const crate::lower::Lx& lx, const Text& ctor, const crate::syntax::Pattern_& q, const crate::check::types::Ty& inner, const crate::lower::types::Holding& mode, const Text& fresh);

prism_rtl::JobRef<PatOut> start_wrap_pat(crate::lower::Lx lx, Text ctor, crate::syntax::Pattern_ q, crate::check::types::Ty inner, crate::lower::types::Holding mode, Text fresh);

PatOut lit_pat(const crate::lower::Lx& lx, const crate::syntax::Literal& l, const crate::check::types::Ty& ty, const crate::lower::types::Holding& mode, const Text& fresh, const bool& neg);

prism_rtl::JobRef<PatOut> start_lit_pat(crate::lower::Lx lx, crate::syntax::Literal l, crate::check::types::Ty ty, crate::lower::types::Holding mode, Text fresh, bool neg);

PatOut ctor_pat(const crate::lower::Lx& lx, const crate::syntax::SName& n, const Array<crate::syntax::Pattern_>& ps, const crate::check::types::Ty& ty, const crate::lower::types::Holding& mode, const Text& fresh);

prism_rtl::JobRef<PatOut> start_ctor_pat(crate::lower::Lx lx, crate::syntax::SName n, Array<crate::syntax::Pattern_> ps, crate::check::types::Ty ty, crate::lower::types::Holding mode, Text fresh);

PatOut sub_pat(const crate::lower::Lx& lx, const crate::check::env::CtorInfo& c, const Nat& i, const crate::syntax::Pattern_& p_, const crate::check::types::Ty& ty, const crate::lower::types::Holding& mode, const Text& fresh);

prism_rtl::JobRef<PatOut> start_sub_pat(crate::lower::Lx lx, crate::check::env::CtorInfo c, Nat i, crate::syntax::Pattern_ p_, crate::check::types::Ty ty, crate::lower::types::Holding mode, Text fresh);

PatOut behind_rc(const crate::lower::Lx& lx, const crate::syntax::Pattern_& p_, const crate::check::types::Ty& ty, const crate::lower::types::Holding& rc_mode, const Text& fresh);

prism_rtl::JobRef<PatOut> start_behind_rc(crate::lower::Lx lx, crate::syntax::Pattern_ p_, crate::check::types::Ty ty, crate::lower::types::Holding rc_mode, Text fresh);

PatOut record_pat(const crate::lower::Lx& lx, const crate::syntax::SName& n, const Array<crate::syntax::FieldPat>& fps, const bool& rest, const crate::check::types::Ty& ty, const crate::lower::types::Holding& mode, const Text& fresh);

prism_rtl::JobRef<PatOut> start_record_pat(crate::lower::Lx lx, crate::syntax::SName n, Array<crate::syntax::FieldPat> fps, bool rest, crate::check::types::Ty ty, crate::lower::types::Holding mode, Text fresh);

PatOut rest_case_pat(const crate::check::env::CtorInfo& c, const Array<std::tuple<Text, Array<crate::check::types::Ty>>>& cases, const Text& ty_path);

PatOut fields_pat(const crate::lower::Lx& lx, const crate::check::env::CtorInfo& c, const Array<crate::syntax::FieldPat>& fps, const bool& rest, const crate::check::types::Ty& ty, const crate::lower::types::Holding& mode, const Text& fresh, const Text& ty_path);

prism_rtl::JobRef<PatOut> start_fields_pat(crate::lower::Lx lx, crate::check::env::CtorInfo c, Array<crate::syntax::FieldPat> fps, bool rest, crate::check::types::Ty ty, crate::lower::types::Holding mode, Text fresh, Text ty_path);

crate::syntax::FieldPat dummy_field_pat();

crate::check::env::TagInfo dummy_tag_info();

bool is_live(const crate::check::types::Ty& t);

Text tag_field_name(const crate::syntax::FieldPat& fp, const Array<Text>& names, const Nat& i);

PatOut tag_pat(const crate::lower::Lx& lx, const crate::check::env::TagInfo& tg, const Array<crate::syntax::FieldPat>& fps, const bool& rest, const crate::check::types::Ty& ty, const crate::lower::types::Holding& mode, const Text& fresh);

prism_rtl::JobRef<PatOut> start_tag_pat(crate::lower::Lx lx, crate::check::env::TagInfo tg, Array<crate::syntax::FieldPat> fps, bool rest, crate::check::types::Ty ty, crate::lower::types::Holding mode, Text fresh);

PatOut live_field_pat(const crate::lower::Lx& lx, const crate::syntax::Pattern_& p_, const Text& variant, const Text& fname, const crate::check::types::Ty& ft, const Text& fresh);

prism_rtl::JobRef<PatOut> start_live_field_pat(crate::lower::Lx lx, crate::syntax::Pattern_ p_, Text variant, Text fname, crate::check::types::Ty ft, Text fresh);

crate::lower::model::Ex live_projection(const Text& fresh, const Text& variant, const Text& fname, const crate::lower::model::OutTy& ft);

PatOut family_pat(const crate::lower::Lx& lx, const crate::syntax::QualName& q, const crate::check::types::Ty& ty, const Text& fresh);

prism_rtl::JobRef<PatOut> start_family_pat(crate::lower::Lx lx, crate::syntax::QualName q, crate::check::types::Ty ty, Text fresh);

PatOut error_pat(const crate::lower::Lx& lx, const Array<crate::syntax::FieldPat>& fps, const crate::check::types::Ty& ty, const crate::lower::types::Holding& mode, const Text& fresh);

prism_rtl::JobRef<PatOut> start_error_pat(crate::lower::Lx lx, Array<crate::syntax::FieldPat> fps, crate::check::types::Ty ty, crate::lower::types::Holding mode, Text fresh);

PatOut array_pat(const crate::lower::Lx& lx, const Array<crate::syntax::Pattern_>& ps, const crate::check::types::Ty& ty, const crate::lower::types::Holding& mode, const Text& fresh);

prism_rtl::JobRef<PatOut> start_array_pat(crate::lower::Lx lx, Array<crate::syntax::Pattern_> ps, crate::check::types::Ty ty, crate::lower::types::Holding mode, Text fresh);

}  // namespace lower::patterns


namespace lower::patterns {

/// The step machine of `RustPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustPat: unbounded fn Lx, Pattern, Ty, Holding, Text -> PatOut
struct RustPat : prism_rtl::Job<PatOut> {
    crate::lower::Lx lx;
    crate::syntax::Pattern_ p_;
    crate::check::types::Ty ty;
    crate::lower::types::Holding mode;
    Text fresh;
    RustPat(crate::lower::Lx lx, crate::syntax::Pattern_ p_, crate::check::types::Ty ty, crate::lower::types::Holding mode, Text fresh) : lx(std::move(lx)), p_(std::move(p_)), ty(std::move(ty)), mode(std::move(mode)), fresh(std::move(fresh)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `WrapPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WrapPat: unbounded fn Lx, Text, Pattern, Ty, Holding, Text -> PatOut
struct WrapPat : prism_rtl::Job<PatOut> {
    crate::lower::Lx lx;
    Text ctor;
    crate::syntax::Pattern_ q;
    crate::check::types::Ty inner;
    crate::lower::types::Holding mode;
    Text fresh;
    WrapPat(crate::lower::Lx lx, Text ctor, crate::syntax::Pattern_ q, crate::check::types::Ty inner, crate::lower::types::Holding mode, Text fresh) : lx(std::move(lx)), ctor(std::move(ctor)), q(std::move(q)), inner(std::move(inner)), mode(std::move(mode)), fresh(std::move(fresh)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `LitPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LitPat: unbounded fn Lx, Literal, Ty, Holding, Text, Bool -> PatOut
struct LitPat : prism_rtl::Job<PatOut> {
    crate::lower::Lx lx;
    crate::syntax::Literal l;
    crate::check::types::Ty ty;
    crate::lower::types::Holding mode;
    Text fresh;
    bool neg;
    LitPat(crate::lower::Lx lx, crate::syntax::Literal l, crate::check::types::Ty ty, crate::lower::types::Holding mode, Text fresh, bool neg) : lx(std::move(lx)), l(std::move(l)), ty(std::move(ty)), mode(std::move(mode)), fresh(std::move(fresh)), neg(std::move(neg)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `CtorPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CtorPat: unbounded fn Lx, SName, [Pattern], Ty, Holding, Text -> PatOut
struct CtorPat : prism_rtl::Job<PatOut> {
    crate::lower::Lx lx;
    crate::syntax::SName n;
    Array<crate::syntax::Pattern_> ps;
    crate::check::types::Ty ty;
    crate::lower::types::Holding mode;
    Text fresh;
    CtorPat(crate::lower::Lx lx, crate::syntax::SName n, Array<crate::syntax::Pattern_> ps, crate::check::types::Ty ty, crate::lower::types::Holding mode, Text fresh) : lx(std::move(lx)), n(std::move(n)), ps(std::move(ps)), ty(std::move(ty)), mode(std::move(mode)), fresh(std::move(fresh)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `SubPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SubPat: unbounded fn Lx, CtorInfo, Nat, Pattern, Ty, Holding, Text -> PatOut
struct SubPat : prism_rtl::Job<PatOut> {
    crate::lower::Lx lx;
    crate::check::env::CtorInfo c;
    Nat i;
    crate::syntax::Pattern_ p_;
    crate::check::types::Ty ty;
    crate::lower::types::Holding mode;
    Text fresh;
    SubPat(crate::lower::Lx lx, crate::check::env::CtorInfo c, Nat i, crate::syntax::Pattern_ p_, crate::check::types::Ty ty, crate::lower::types::Holding mode, Text fresh) : lx(std::move(lx)), c(std::move(c)), i(std::move(i)), p_(std::move(p_)), ty(std::move(ty)), mode(std::move(mode)), fresh(std::move(fresh)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `BehindRc`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BehindRc: unbounded fn Lx, Pattern, Ty, Holding, Text -> PatOut
struct BehindRc : prism_rtl::Job<PatOut> {
    crate::lower::Lx lx;
    crate::syntax::Pattern_ p_;
    crate::check::types::Ty ty;
    crate::lower::types::Holding rc_mode;
    Text fresh;
    BehindRc(crate::lower::Lx lx, crate::syntax::Pattern_ p_, crate::check::types::Ty ty, crate::lower::types::Holding rc_mode, Text fresh) : lx(std::move(lx)), p_(std::move(p_)), ty(std::move(ty)), rc_mode(std::move(rc_mode)), fresh(std::move(fresh)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `RecordPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RecordPat: unbounded fn Lx, SName, [FieldPat], Bool, Ty, Holding, Text -> PatOut
struct RecordPat : prism_rtl::Job<PatOut> {
    crate::lower::Lx lx;
    crate::syntax::SName n;
    Array<crate::syntax::FieldPat> fps;
    bool rest;
    crate::check::types::Ty ty;
    crate::lower::types::Holding mode;
    Text fresh;
    RecordPat(crate::lower::Lx lx, crate::syntax::SName n, Array<crate::syntax::FieldPat> fps, bool rest, crate::check::types::Ty ty, crate::lower::types::Holding mode, Text fresh) : lx(std::move(lx)), n(std::move(n)), fps(std::move(fps)), rest(std::move(rest)), ty(std::move(ty)), mode(std::move(mode)), fresh(std::move(fresh)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `FieldsPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FieldsPat: unbounded fn Lx, CtorInfo, [FieldPat], Bool, Ty, Holding, Text, Text -> PatOut
struct FieldsPat : prism_rtl::Job<PatOut> {
    crate::lower::Lx lx;
    crate::check::env::CtorInfo c;
    Array<crate::syntax::FieldPat> fps;
    bool rest;
    crate::check::types::Ty ty;
    crate::lower::types::Holding mode;
    Text fresh;
    Text ty_path;
    FieldsPat(crate::lower::Lx lx, crate::check::env::CtorInfo c, Array<crate::syntax::FieldPat> fps, bool rest, crate::check::types::Ty ty, crate::lower::types::Holding mode, Text fresh, Text ty_path) : lx(std::move(lx)), c(std::move(c)), fps(std::move(fps)), rest(std::move(rest)), ty(std::move(ty)), mode(std::move(mode)), fresh(std::move(fresh)), ty_path(std::move(ty_path)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `TagPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TagPat: unbounded fn Lx, TagInfo, [FieldPat], Bool, Ty, Holding, Text -> PatOut
struct TagPat : prism_rtl::Job<PatOut> {
    crate::lower::Lx lx;
    crate::check::env::TagInfo tg;
    Array<crate::syntax::FieldPat> fps;
    bool rest;
    crate::check::types::Ty ty;
    crate::lower::types::Holding mode;
    Text fresh;
    TagPat(crate::lower::Lx lx, crate::check::env::TagInfo tg, Array<crate::syntax::FieldPat> fps, bool rest, crate::check::types::Ty ty, crate::lower::types::Holding mode, Text fresh) : lx(std::move(lx)), tg(std::move(tg)), fps(std::move(fps)), rest(std::move(rest)), ty(std::move(ty)), mode(std::move(mode)), fresh(std::move(fresh)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `LiveFieldPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LiveFieldPat: unbounded fn Lx, Pattern, Text, Text, Ty, Text -> PatOut
struct LiveFieldPat : prism_rtl::Job<PatOut> {
    crate::lower::Lx lx;
    crate::syntax::Pattern_ p_;
    Text variant;
    Text fname;
    crate::check::types::Ty ft;
    Text fresh;
    LiveFieldPat(crate::lower::Lx lx, crate::syntax::Pattern_ p_, Text variant, Text fname, crate::check::types::Ty ft, Text fresh) : lx(std::move(lx)), p_(std::move(p_)), variant(std::move(variant)), fname(std::move(fname)), ft(std::move(ft)), fresh(std::move(fresh)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `FamilyPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FamilyPat: unbounded fn Lx, QualName, Ty, Text -> PatOut
struct FamilyPat : prism_rtl::Job<PatOut> {
    crate::lower::Lx lx;
    crate::syntax::QualName q;
    crate::check::types::Ty ty;
    Text fresh;
    FamilyPat(crate::lower::Lx lx, crate::syntax::QualName q, crate::check::types::Ty ty, Text fresh) : lx(std::move(lx)), q(std::move(q)), ty(std::move(ty)), fresh(std::move(fresh)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `ErrorPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ErrorPat: unbounded fn Lx, [FieldPat], Ty, Holding, Text -> PatOut
struct ErrorPat : prism_rtl::Job<PatOut> {
    crate::lower::Lx lx;
    Array<crate::syntax::FieldPat> fps;
    crate::check::types::Ty ty;
    crate::lower::types::Holding mode;
    Text fresh;
    ErrorPat(crate::lower::Lx lx, Array<crate::syntax::FieldPat> fps, crate::check::types::Ty ty, crate::lower::types::Holding mode, Text fresh) : lx(std::move(lx)), fps(std::move(fps)), ty(std::move(ty)), mode(std::move(mode)), fresh(std::move(fresh)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `ArrayPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ArrayPat: unbounded fn Lx, [Pattern], Ty, Holding, Text -> PatOut
struct ArrayPat : prism_rtl::Job<PatOut> {
    crate::lower::Lx lx;
    Array<crate::syntax::Pattern_> ps;
    crate::check::types::Ty ty;
    crate::lower::types::Holding mode;
    Text fresh;
    ArrayPat(crate::lower::Lx lx, Array<crate::syntax::Pattern_> ps, crate::check::types::Ty ty, crate::lower::types::Holding mode, Text fresh) : lx(std::move(lx)), ps(std::move(ps)), ty(std::move(ty)), mode(std::move(mode)), fresh(std::move(fresh)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


}  // namespace lower::patterns

}  // namespace crate
