// The module `Lower`, from `target/bootstrap/cpp-src/prismc/lower/mod.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <lower/module.hpp>
#include <check/env/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate::lower {

void Lx::show(Printer& p) const {
    p.record("Lx", {{"g", g}, {"tys", tys}, {"apps", apps}, {"binders", binders}, {"impls", impls}, {"file", file}, {"home", home}, {"site", site}, {"rs_mods", rs_mods}, {"rs_names", rs_names}, {"layouts", layouts}, {"unbs", unbs}, {"notes", notes}, {"globals", globals}, {"in_node", in_node}, {"unshrunk", unshrunk}, {"gens", gens}, {"insts", insts}, {"quants", quants}, {"gen_of_q", gen_of_q}, {"use_insts", use_insts}, {"subst", subst}, {"csubst", csubst}});
}

Pod Lx::to_pod() const {
    return Pod::record("Lx", {{"g", prism_rtl::to_pod(g)}, {"tys", prism_rtl::to_pod(tys)}, {"apps", prism_rtl::to_pod(apps)}, {"binders", prism_rtl::to_pod(binders)}, {"impls", prism_rtl::to_pod(impls)}, {"file", prism_rtl::to_pod(file)}, {"home", prism_rtl::to_pod(home)}, {"site", prism_rtl::to_pod(site)}, {"rs_mods", prism_rtl::to_pod(rs_mods)}, {"rs_names", prism_rtl::to_pod(rs_names)}, {"layouts", prism_rtl::to_pod(layouts)}, {"unbs", prism_rtl::to_pod(unbs)}, {"notes", prism_rtl::to_pod(notes)}, {"globals", prism_rtl::to_pod(globals)}, {"in_node", prism_rtl::to_pod(in_node)}, {"unshrunk", prism_rtl::to_pod(unshrunk)}, {"gens", prism_rtl::to_pod(gens)}, {"insts", prism_rtl::to_pod(insts)}, {"quants", prism_rtl::to_pod(quants)}, {"gen_of_q", prism_rtl::to_pod(gen_of_q)}, {"use_insts", prism_rtl::to_pod(use_insts)}, {"subst", prism_rtl::to_pod(subst)}, {"csubst", prism_rtl::to_pod(csubst)}});
}

Result<Lx> Lx::from_pod(const Pod& whole) {
    return Lx{.g = TRY(prism_rtl::from_pod<crate::check::env::G>(TRY(crate::prelude::field(whole, "g")))), .tys = TRY(prism_rtl::from_pod<Map<Text, crate::check::types::Ty>>(TRY(crate::prelude::field(whole, "tys")))), .apps = TRY(prism_rtl::from_pod<Map<Text, crate::check::typed::AppNote>>(TRY(crate::prelude::field(whole, "apps")))), .binders = TRY(prism_rtl::from_pod<Map<Text, crate::check::types::Ty>>(TRY(crate::prelude::field(whole, "binders")))), .impls = TRY(prism_rtl::from_pod<Map<Text, Array<crate::check::typed::ImplNote>>>(TRY(crate::prelude::field(whole, "impls")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .home = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "home")))), .site = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "site")))), .rs_mods = TRY(prism_rtl::from_pod<Map<Text, Text>>(TRY(crate::prelude::field(whole, "rs_mods")))), .rs_names = TRY(prism_rtl::from_pod<Map<Text, Text>>(TRY(crate::prelude::field(whole, "rs_names")))), .layouts = TRY(prism_rtl::from_pod<Map<Text, Array<bool>>>(TRY(crate::prelude::field(whole, "layouts")))), .unbs = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "unbs")))), .notes = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "notes")))), .globals = TRY(prism_rtl::from_pod<Map<Text, bool>>(TRY(crate::prelude::field(whole, "globals")))), .in_node = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "in_node")))), .unshrunk = TRY(prism_rtl::from_pod<Map<Text, bool>>(TRY(crate::prelude::field(whole, "unshrunk")))), .gens = TRY(prism_rtl::from_pod<Map<Text, crate::check::typed::GenNote>>(TRY(crate::prelude::field(whole, "gens")))), .insts = TRY(prism_rtl::from_pod<Map<Text, Array<crate::check::typed::InstNote>>>(TRY(crate::prelude::field(whole, "insts")))), .quants = TRY(prism_rtl::from_pod<Map<Text, Text>>(TRY(crate::prelude::field(whole, "quants")))), .gen_of_q = TRY(prism_rtl::from_pod<Map<Text, crate::check::typed::GenNote>>(TRY(crate::prelude::field(whole, "gen_of_q")))), .use_insts = TRY(prism_rtl::from_pod<Map<Text, crate::check::typed::InstNote>>(TRY(crate::prelude::field(whole, "use_insts")))), .subst = TRY(prism_rtl::from_pod<Map<Text, crate::check::types::Ty>>(TRY(crate::prelude::field(whole, "subst")))), .csubst = TRY(prism_rtl::from_pod<Map<Text, crate::check::types::Col>>(TRY(crate::prelude::field(whole, "csubst"))))};
}


/// PlaceKey: fn Lx, Range -> Text
Text place_key(const Lx& lx, const crate::syntax::Range& r) {
    return prism_rtl::cat(lx->file, ":", r.start, ":", r.end);
}


/// TypeAt: fn Lx, Range -> Ty
crate::check::types::Ty type_at(const Lx& lx, const crate::syntax::Range& r) {
    return subst_ty(lx, or_(crate::prelude::get(lx.tys, place_key(lx, r)), crate::check::types::Ty(crate::check::types::Ty::TyErr{})));
}


/// BinderTy: fn Lx, Range -> Ty
crate::check::types::Ty binder_ty(const Lx& lx, const crate::syntax::Range& r) {
    auto&& _m = crate::prelude::get(lx.binders, place_key(lx, r));
    if (prism_rtl::is_some(_m)) {
        auto&& t = prism_rtl::some_of(_m);
        return subst_ty(lx, t);
    }
    if (prism_rtl::is_none(_m)) {
        return type_at(lx, r);
    }
    prism_rtl::unreachable("no arm matched");
}


/// SubstTy: fn Lx, Ty -> Ty
crate::check::types::Ty subst_ty(const Lx& lx, const crate::check::types::Ty& t) {
    return (len(keys(lx.subst)) == Nat(0u)) && (len(keys(lx.csubst)) == Nat(0u))
        ? t
        : subst_ty_in(lx, t);
}


/// SubstTyIn: fn Lx, Ty -> Ty
crate::check::types::Ty subst_ty_in(const Lx& lx, const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyFlex>(t).a0;
        return or_(crate::prelude::get(lx.subst, prism_rtl::cat("'", n)), t);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyCon{n, each(args, [&](const crate::check::types::Ty& a) { return subst_ty_in(lx, a); })});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t)) {
        auto&& c = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        return crate::check::types::Ty(crate::check::types::Ty::TyFn{inst_col(lx, c), each(ps, [&](const crate::check::types::Ty& p_) { return subst_ty_in(lx, p_); }), prism_rtl::rc(subst_ty_in(lx, res))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyTuple{each(ts, [&](const crate::check::types::Ty& a) { return subst_ty_in(lx, a); })});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(subst_ty_in(lx, e))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(subst_ty_in(lx, k)), prism_rtl::rc(subst_ty_in(lx, v_))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& s = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TySig{s, prism_rtl::rc(subst_ty_in(lx, i))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a0;
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(subst_ty_in(lx, i)), rw});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t)) {
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a0;
        auto&& o = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyElem{rw, prism_rtl::rc(subst_ty_in(lx, o))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t).a0;
        auto&& a = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyAssoc{n, prism_rtl::rc(subst_ty_in(lx, a))});
    }
    {
        auto&& other = t;
        return other;
    }
}


/// InstCol: fn Lx, Col -> Col
crate::check::types::Col inst_col(const Lx& lx, const crate::check::types::Col& col1) {
    if (prism_rtl::is<crate::check::types::Col::CQ>(col1)) {
        auto&& q = prism_rtl::as<crate::check::types::Col::CQ>(col1).a0;
        return or_(crate::prelude::get(lx.csubst, q), crate::check::types::Col(crate::check::types::Col::CQ{q}));
    }
    {
        auto&& c = col1;
        return c;
    }
}


/// IsQuantCol: fn Lx, Col -> Bool
bool is_quant_col(const Lx& lx, const crate::check::types::Col& col1) {
    if (prism_rtl::is<crate::check::types::Col::CQ>(col1)) {
        auto&& q = prism_rtl::as<crate::check::types::Col::CQ>(col1).a0;
        return crate::check::env::has_key(lx.quants, q);
    }
    {
        auto&& c = col1;
        return false;
    }
}


/// TypedTables: fn TProgram -> (((Text ==> Ty), (Text ==> AppNote), (Text ==> Ty), (Text ==> [ImplNote])))
std::tuple<Map<Text, crate::check::types::Ty>, Map<Text, crate::check::typed::AppNote>, Map<Text, crate::check::types::Ty>, Map<Text, Array<crate::check::typed::ImplNote>>> typed_tables(const crate::check::typed::TProgram& tp) {
    auto tys = fold(tp.exprs, Map<Text, crate::check::types::Ty>{}, [&](const Map<Text, crate::check::types::Ty>& m, const crate::check::typed::TyNote& n) { return insert(m, crate::check::typed::at_key(n.at), n.ty); });
    auto apps = fold(tp.apps, Map<Text, crate::check::typed::AppNote>{}, [&](const Map<Text, crate::check::typed::AppNote>& m, const crate::check::typed::AppNote& n) { return insert(m, crate::check::typed::at_key(n.at), n); });
    auto bs = fold(tp.binders, Map<Text, crate::check::types::Ty>{}, [&](const Map<Text, crate::check::types::Ty>& m, const crate::check::typed::BinderNote& n) { return insert(m, crate::check::typed::at_key(n.at), n.ty); });
    auto ims = fold(tp.impls, Map<Text, Array<crate::check::typed::ImplNote>>{}, [&](const Map<Text, Array<crate::check::typed::ImplNote>>& m, const crate::check::typed::ImplNote& n) { return insert(m, crate::check::typed::at_key(n.at), crate::prelude::push(or_(crate::prelude::get(m, crate::check::typed::at_key(n.at)), Array<crate::check::typed::ImplNote>{}), n)); });
    return std::tuple{tys, apps, bs, ims};
}


/// let rustKeywords
Array<Text> rust_keywords() {
    return Array(std::vector{Text::lit("as"), Text::lit("async"), Text::lit("await"), Text::lit("box"), Text::lit("break"), Text::lit("const"), Text::lit("continue"), Text::lit("crate"), Text::lit("do"), Text::lit("dyn"), Text::lit("else"), Text::lit("enum"), Text::lit("extern"), Text::lit("false"), Text::lit("final"), Text::lit("fn"), Text::lit("for"), Text::lit("gen"), Text::lit("if"), Text::lit("impl"), Text::lit("in"), Text::lit("let"), Text::lit("loop"), Text::lit("macro"), Text::lit("match"), Text::lit("mod"), Text::lit("move"), Text::lit("mut"), Text::lit("override"), Text::lit("priv"), Text::lit("pub"), Text::lit("ref"), Text::lit("return"), Text::lit("self"), Text::lit("static"), Text::lit("struct"), Text::lit("super"), Text::lit("trait"), Text::lit("true"), Text::lit("try"), Text::lit("type"), Text::lit("typeof"), Text::lit("unsafe"), Text::lit("unsized"), Text::lit("use"), Text::lit("virtual"), Text::lit("where"), Text::lit("while"), Text::lit("yield"), Text::lit("u8"), Text::lit("u16"), Text::lit("u32"), Text::lit("u64"), Text::lit("i8"), Text::lit("i16"), Text::lit("i32"), Text::lit("i64"), Text::lit("f32"), Text::lit("f64"), Text::lit("bool"), Text::lit("char"), Text::lit("str"), Text::lit("usize"), Text::lit("isize"), Text::lit("cx"), Text::lit("node"), Text::lit("path"), Text::lit("v"), Text::lit("p")});
}


/// Base: fn Text -> Text
Text base(const Text& name) {
    return crate::syntax::lexer::chars::drop_prefix(name, crate::check::types::unify::marks_of(name));
}


/// Snake: fn Text -> Text
Text snake(const Text& name) {
    auto&& _out = crate::syntax::lexer::chars::fold_chars(base(name), std::tuple{Text::lit(""), Text::lit("")}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text>>(std::tuple<std::tuple<Text, Text>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Text, Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return once_job([=]() {
            return ({
                auto [acc, prev] = p0;
                auto c = p1;
                ({
                auto sep = crate::syntax::lexer::chars::is_upper(c) && (crate::syntax::lexer::chars::is_lower(prev) || crate::syntax::lexer::chars::is_digit(prev))
                    ? Text::lit("_")
                    : Text::lit("");
                (prism_rtl::finished(std::tuple{prism_rtl::cat(acc, sep, lower_char(c)), c}));
            });
            });
        });
    })));
    auto&& out = std::get<0>(_out);
    auto plain = out == Text::lit("") ? Text::lit("x") : out;
    return crate::check::types::has_text(rust_keywords(), plain)
        ? prism_rtl::cat(plain, "_")
        : plain;
}


/// LowerChar: fn Text -> Text
Text lower_char(const Text& c) {
    return crate::syntax::lexer::chars::is_upper(c) ? crate::prelude::lower(c) : c;
}


/// Camel: fn Text -> Text
Text camel(const Text& name) {
    auto b = base(name);
    auto first_ = crate::syntax::lexer::chars::head(b);
    auto fixed = crate::syntax::lexer::chars::is_lower(first_)
        ? prism_rtl::cat(upper(first_), crate::syntax::lexer::chars::after_first(b))
        : b;
    return (fixed == Text::lit("Self")) || crate::check::types::has_text(runtime_names(), fixed)
        ? prism_rtl::cat(fixed, "_")
        : fixed;
}


/// let runtimeNames
Array<Text> runtime_names() {
    return Array(std::vector{Text::lit("AnswerOf"), Text::lit("BigInt"), Text::lit("Blueprint"), Text::lit("Box"), Text::lit("Built"), Text::lit("Cache"), Text::lit("Case"), Text::lit("Cell"), Text::lit("Clickable"), Text::lit("Collector"), Text::lit("Cursor"), Text::lit("Cx"), Text::lit("Defer"), Text::lit("Demand"), Text::lit("Document"), Text::lit("Done"), Text::lit("DynShow"), Text::lit("Dynamic"), Text::lit("Edit"), Text::lit("Err"), Text::lit("Event"), Text::lit("F64"), Text::lit("Fallible"), Text::lit("Fields"), Text::lit("Finishing"), Text::lit("Fn"), Text::lit("Forward"), Text::lit("FromPod"), Text::lit("Gathered"), Text::lit("Gen"), Text::lit("Handle"), Text::lit("Hold"), Text::lit("Host"), Text::lit("HostOf"), Text::lit("HostRow"), Text::lit("Inert"), Text::lit("IsShared"), Text::lit("IsValue"), Text::lit("Job"), Text::lit("JobRef"), Text::lit("Later"), Text::lit("Link"), Text::lit("List"), Text::lit("Live"), Text::lit("MakeNew"), Text::lit("MutElements"), Text::lit("Nanos"), Text::lit("NeverEvent"), Text::lit("NewSnapshot"), Text::lit("Node"), Text::lit("NodeRef"), Text::lit("None"), Text::lit("Ok"), Text::lit("OkUnit"), Text::lit("Option"), Text::lit("Outcome"), Text::lit("Panic"), Text::lit("Patch"), Text::lit("Path"), Text::lit("Pattern"), Text::lit("Pod"), Text::lit("Port"), Text::lit("Pos"), Text::lit("Printer"), Text::lit("Program"), Text::lit("Rc"), Text::lit("ReadyMap"), Text::lit("ReadyState"), Text::lit("RefCell"), Text::lit("Report"), Text::lit("Request"), Text::lit("Result"), Text::lit("Row"), Text::lit("Rows"), Text::lit("Runtime"), Text::lit("Scope"), Text::lit("Segment"), Text::lit("ShowRef"), Text::lit("ShownText"), Text::lit("Sink"), Text::lit("Slot"), Text::lit("Snapshot"), Text::lit("Some"), Text::lit("Stamped"), Text::lit("String"), Text::lit("Subscribed"), Text::lit("Subscriber"), Text::lit("Supplied"), Text::lit("Supplier"), Text::lit("TestWorld"), Text::lit("Tick"), Text::lit("TickIn"), Text::lit("TickOut"), Text::lit("ToPod"), Text::lit("Unexpected"), Text::lit("Unit"), Text::lit("Vec"), Text::lit("Weak"), Text::lit("World"), Text::lit("XorShift")});
}


/// RustModName: fn Text -> Text
Text rust_mod_name(const Text& m) {
    return m == Text::lit("")
        ? Text::lit("program")
        : crate::syntax::lexer::chars::join(each(split_on(m, Text::lit(".")), [&](const Text& s) { return mod_segment(s); }), Text::lit("::"));
}


/// ModSegment: fn Text -> Text
Text mod_segment(const Text& s) {
    auto n = snake(s);
    return crate::check::types::has_text(cpp_keywords(), n)
        ? prism_rtl::cat(n, "_")
        : n;
}


/// let cppKeywords
Array<Text> cpp_keywords() {
    return Array(std::vector{Text::lit("explicit"), Text::lit("and"), Text::lit("and_eq"), Text::lit("asm"), Text::lit("auto"), Text::lit("bitand"), Text::lit("bitor"), Text::lit("bool"), Text::lit("case"), Text::lit("catch"), Text::lit("char"), Text::lit("char8_t"), Text::lit("char16_t"), Text::lit("char32_t"), Text::lit("class"), Text::lit("compl"), Text::lit("concept"), Text::lit("const_cast"), Text::lit("consteval"), Text::lit("constexpr"), Text::lit("constinit"), Text::lit("co_await"), Text::lit("co_return"), Text::lit("co_yield"), Text::lit("decltype"), Text::lit("default"), Text::lit("delete"), Text::lit("double"), Text::lit("dynamic_cast"), Text::lit("explicit"), Text::lit("export"), Text::lit("extern"), Text::lit("float"), Text::lit("friend"), Text::lit("goto"), Text::lit("inline"), Text::lit("int"), Text::lit("long"), Text::lit("mutable"), Text::lit("namespace"), Text::lit("new"), Text::lit("noexcept"), Text::lit("not"), Text::lit("not_eq"), Text::lit("nullptr"), Text::lit("operator"), Text::lit("or"), Text::lit("or_eq"), Text::lit("private"), Text::lit("protected"), Text::lit("public"), Text::lit("register"), Text::lit("reinterpret_cast"), Text::lit("requires"), Text::lit("short"), Text::lit("signed"), Text::lit("sizeof"), Text::lit("static_assert"), Text::lit("static_cast"), Text::lit("switch"), Text::lit("template"), Text::lit("this"), Text::lit("thread_local"), Text::lit("throw"), Text::lit("try"), Text::lit("typedef"), Text::lit("typeid"), Text::lit("typename"), Text::lit("union"), Text::lit("unsigned"), Text::lit("using"), Text::lit("virtual"), Text::lit("void"), Text::lit("volatile"), Text::lit("wchar_t"), Text::lit("xor"), Text::lit("xor_eq"), Text::lit("errno"), Text::lit("assert"), Text::lit("NULL"), Text::lit("EOF"), Text::lit("stdin"), Text::lit("stdout"), Text::lit("stderr"), Text::lit("major"), Text::lit("minor")});
}


/// PathIn: fn Lx, Text, Text -> Text
Text path_in(const Lx& lx, const Text& owner, const Text& name) {
    return owner == lx.site
        ? name
        : owner == Text::lit("Prelude")
        ? prelude_path(lx, name)
        : prism_rtl::cat("crate::", or_(crate::prelude::get(lx.rs_mods, owner), rust_mod_name(owner)), "::", name);
}


/// PreludePath: fn Lx, Text -> Text
Text prelude_path(const Lx& lx, const Text& name) {
    return crate::check::env::has_key(lx.globals, prism_rtl::cat(lx.site, ".", name))
        ? prism_rtl::cat("crate::prelude::", name)
        : name;
}


/// ValueNames: fn G -> (Text ==> Text)
Map<Text, Text> value_names(const crate::check::env::G& g) {
    auto lets = fold(g.defs, Array<Text>{}, [&](const Array<Text>& acc, const crate::check::env::Def& d) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = d.body;
            if (prism_rtl::is<crate::check::env::DefBody::DbLet>(_m)) {
                _v.set(crate::check::types::add_text(acc, d.qk));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto keys_ = crate::check::types::union_texts(keys(g.vals), lets);
    auto bases = fold(keys_, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& m, const Text& k) { return insert(m, base_key(k), crate::prelude::push(or_(crate::prelude::get(m, base_key(k)), Array<Text>{}), k)); });
    return fold(keys_, Map<Text, Text>{}, [&](const Map<Text, Text>& m, const Text& k) { return insert(m, k, value_name(k, len(or_(crate::prelude::get(bases, base_key(k)), Array<Text>{})))); });
}


/// GlobalNames: fn G -> (Text ==> Bool)
Map<Text, bool> global_names(const crate::check::env::G& g) {
    auto names = value_names(g);
    return fold(keys(names), Map<Text, bool>{}, [&](const Map<Text, bool>& m, const Text& k) { return insert(m, prism_rtl::cat(owner_of(k), ".", or_(crate::prelude::get(names, k), Text::lit(""))), true); });
}


/// LocalName: fn Lx, Text -> Text
Text local_name(const Lx& lx, const Text& nkey) {
    auto marks = crate::check::types::unify::marks_of(nkey);
    auto base_ = snake(nkey);
    auto bare = crate::syntax::lexer::chars::drop_prefix(nkey, marks);
    auto s0 = crate::syntax::lexer::chars::contains(marks, Text::lit("?"))
        ? prism_rtl::cat(base_, "_opt")
        : crate::syntax::lexer::chars::contains(marks, Text::lit("~"))
        ? prism_rtl::cat(base_, "_try")
        : base_;
    auto s1 = crate::check::env::is_upper_text(crate::syntax::lexer::chars::head(bare))
        ? prism_rtl::cat(s0, "_fn")
        : s0;
    return crate::check::env::has_key(lx.globals, prism_rtl::cat(lx.site, ".", s1)) || crate::check::env::has_key(lx.globals, prism_rtl::cat("Prelude.", s1))
        ? prism_rtl::cat(s1, "_")
        : s1;
}


/// BaseKey: fn Text -> Text
Text base_key(const Text& k) {
    auto parts = split_on(k, Text::lit("."));
    auto last_1 = or_(crate::syntax::lexer::chars::last(parts), k);
    return prism_rtl::cat(crate::syntax::lexer::chars::join(take(parts, crate::syntax::lexer::chars::dec(len(parts))), Text::lit(".")), ".", snake(last_1));
}


/// ValueName: fn Text, Nat -> Text
Text value_name(const Text& k, const Nat& count) {
    auto last = crate::check::types::bare_name(k);
    auto marks = crate::check::types::unify::marks_of(last);
    auto base_ = snake(last);
    return (count > Nat(1u)) && (marks != Text::lit(""))
        ? prism_rtl::cat(base_, "_", sigil_word(crate::syntax::lexer::chars::head(marks)))
        : (count > Nat(1u)) && (!crate::check::env::is_upper_text(crate::syntax::lexer::chars::head(last)))
        ? prism_rtl::cat(base_, "_value")
        : base_;
}


/// SigilWord: fn Text -> Text
Text sigil_word(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("?")) {
            return Text::lit("opt");
        }
    }
    {
        auto&& c1_0 = text0;
        if (c1_0 == Text::lit("~")) {
            return Text::lit("try");
        }
    }
    {
        auto&& c2_0 = text0;
        if (c2_0 == Text::lit("!")) {
            return Text::lit("ev");
        }
    }
    {
        auto&& c3_0 = text0;
        if (c3_0 == Text::lit("$")) {
            return Text::lit("dyn");
        }
    }
    {
        auto&& c4_0 = text0;
        if (c4_0 == Text::lit("@")) {
            return Text::lit("widget");
        }
    }
    {
        auto&& c5_0 = text0;
        if (c5_0 == Text::lit("&")) {
            return Text::lit("ref");
        }
    }
    {
        auto&& other = text0;
        return Text::lit("x");
    }
}


/// ValuePath: fn Lx, Text -> Text
Text value_path(const Lx& lx, const Text& qk) {
    auto owner = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = crate::prelude::get(lx.g.vals, qk);
        if (prism_rtl::is_some(_m)) {
            auto&& v_ = prism_rtl::some_of(_m);
            _v.set(v_.home);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(owner_of(qk));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return path_in(lx, owner, or_(crate::prelude::get(lx.rs_names, qk), snake(crate::check::types::bare_name(qk))));
}


/// OwnerOf: fn Text -> Text
Text owner_of(const Text& qk) {
    auto parts = split_on(qk, Text::lit("."));
    return crate::syntax::lexer::chars::join(take(parts, crate::syntax::lexer::chars::dec(len(parts))), Text::lit("."));
}


/// TagStruct: fn Text -> Text
Text tag_struct(const Text& tn) {
    return concat(each(split_on(tn, Text::lit(".")), [&](const Text& p_) { return camel(p_); }));
}

}  // namespace crate::lower
