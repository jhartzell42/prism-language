// The module `Lower`, from `target/bootstrap/cpp-src/prismc/lower/mod.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include <lower/module.hpp>
#include <lower/node_/module.hpp>
#include <syntax/module.hpp>
#include <check/env/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/passes/module.hpp>
#include <check/shrink/module.hpp>
#include <check/typed/module.hpp>
#include <check/types/module.hpp>
#include <lower/model/module.hpp>
#include <syntax/lexer/module.hpp>
#include <lower/node_/generic.hpp>
#include <check/env/generic.hpp>
#include <syntax/lexer/generic.hpp>

namespace crate::lower {





void Holding::show(Printer& p) const {
    if (auto c = std::get_if<ByRef>(&cases())) p.choice("ByRef", {});
    else if (auto c = std::get_if<Owned>(&cases())) p.choice("Owned", {});
    else if (auto c = std::get_if<RcRef>(&cases())) p.choice("RcRef", {});
    else if (auto c = std::get_if<RcOwned>(&cases())) p.choice("RcOwned", {});
}

Pod Holding::to_pod() const {
    return std::holds_alternative<ByRef>(cases()) ? Pod::choice("ByRef", {})
        : std::holds_alternative<Owned>(cases()) ? Pod::choice("Owned", {})
        : std::holds_alternative<RcRef>(cases()) ? Pod::choice("RcRef", {})
        : std::holds_alternative<RcOwned>(cases()) ? Pod::choice("RcOwned", {})
        : Pod();
}

Result<Holding> Holding::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "ByRef" && c->args.size() == 0) return Holding(ByRef{});
        if (c->ctor == "Owned" && c->args.size() == 0) return Holding(Owned{});
        if (c->ctor == "RcRef" && c->args.size() == 0) return Holding(RcRef{});
        if (c->ctor == "RcOwned" && c->args.size() == 0) return Holding(RcOwned{});
    }
    return mismatch<Holding>("a Holding", p);
}


void Layer::show(Printer& p) const {
    if (auto c = std::get_if<LyPlain>(&cases())) p.choice("LyPlain", {});
    else if (auto c = std::get_if<LyDyn>(&cases())) p.choice("LyDyn", {});
    else if (auto c = std::get_if<LyEv>(&cases())) p.choice("LyEv", {});
    else if (auto c = std::get_if<LyBlueprint>(&cases())) p.choice("LyBlueprint", {});
}

Pod Layer::to_pod() const {
    return std::holds_alternative<LyPlain>(cases()) ? Pod::choice("LyPlain", {})
        : std::holds_alternative<LyDyn>(cases()) ? Pod::choice("LyDyn", {})
        : std::holds_alternative<LyEv>(cases()) ? Pod::choice("LyEv", {})
        : std::holds_alternative<LyBlueprint>(cases()) ? Pod::choice("LyBlueprint", {})
        : Pod();
}

Result<Layer> Layer::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "LyPlain" && c->args.size() == 0) return Layer(LyPlain{});
        if (c->ctor == "LyDyn" && c->args.size() == 0) return Layer(LyDyn{});
        if (c->ctor == "LyEv" && c->args.size() == 0) return Layer(LyEv{});
        if (c->ctor == "LyBlueprint" && c->args.size() == 0) return Layer(LyBlueprint{});
    }
    return mismatch<Layer>("a Layer", p);
}


void Lx::show(Printer& p) const {
    p.record("Lx", {{"g", g}, {"tys", tys}, {"apps", apps}, {"binders", binders}, {"impls", impls}, {"file", file}, {"home", home}, {"site", site}, {"rs_mods", rs_mods}, {"rs_names", rs_names}, {"layouts", layouts}, {"unbs", unbs}, {"notes", notes}, {"globals", globals}, {"in_node", in_node}, {"unshrunk", unshrunk}, {"gens", gens}, {"insts", insts}, {"quants", quants}, {"gen_of_q", gen_of_q}, {"use_insts", use_insts}, {"subst", subst}, {"csubst", csubst}});
}

Pod Lx::to_pod() const {
    return Pod::record("Lx", {{"g", prism_rtl::to_pod(g)}, {"tys", prism_rtl::to_pod(tys)}, {"apps", prism_rtl::to_pod(apps)}, {"binders", prism_rtl::to_pod(binders)}, {"impls", prism_rtl::to_pod(impls)}, {"file", prism_rtl::to_pod(file)}, {"home", prism_rtl::to_pod(home)}, {"site", prism_rtl::to_pod(site)}, {"rs_mods", prism_rtl::to_pod(rs_mods)}, {"rs_names", prism_rtl::to_pod(rs_names)}, {"layouts", prism_rtl::to_pod(layouts)}, {"unbs", prism_rtl::to_pod(unbs)}, {"notes", prism_rtl::to_pod(notes)}, {"globals", prism_rtl::to_pod(globals)}, {"in_node", prism_rtl::to_pod(in_node)}, {"unshrunk", prism_rtl::to_pod(unshrunk)}, {"gens", prism_rtl::to_pod(gens)}, {"insts", prism_rtl::to_pod(insts)}, {"quants", prism_rtl::to_pod(quants)}, {"gen_of_q", prism_rtl::to_pod(gen_of_q)}, {"use_insts", prism_rtl::to_pod(use_insts)}, {"subst", prism_rtl::to_pod(subst)}, {"csubst", prism_rtl::to_pod(csubst)}});
}

Result<Lx> Lx::from_pod(const Pod& whole) {
    return Lx{.g = TRY(prism_rtl::from_pod<crate::check::env::G>(TRY(crate::prelude::field(whole, "g")))), .tys = TRY(prism_rtl::from_pod<Map<Text, crate::check::types::Ty>>(TRY(crate::prelude::field(whole, "tys")))), .apps = TRY(prism_rtl::from_pod<Map<Text, crate::check::typed::AppNote>>(TRY(crate::prelude::field(whole, "apps")))), .binders = TRY(prism_rtl::from_pod<Map<Text, crate::check::types::Ty>>(TRY(crate::prelude::field(whole, "binders")))), .impls = TRY(prism_rtl::from_pod<Map<Text, Array<crate::check::typed::ImplNote>>>(TRY(crate::prelude::field(whole, "impls")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .home = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "home")))), .site = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "site")))), .rs_mods = TRY(prism_rtl::from_pod<Map<Text, Text>>(TRY(crate::prelude::field(whole, "rs_mods")))), .rs_names = TRY(prism_rtl::from_pod<Map<Text, Text>>(TRY(crate::prelude::field(whole, "rs_names")))), .layouts = TRY(prism_rtl::from_pod<Map<Text, Array<bool>>>(TRY(crate::prelude::field(whole, "layouts")))), .unbs = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "unbs")))), .notes = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "notes")))), .globals = TRY(prism_rtl::from_pod<Map<Text, bool>>(TRY(crate::prelude::field(whole, "globals")))), .in_node = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "in_node")))), .unshrunk = TRY(prism_rtl::from_pod<Map<Text, bool>>(TRY(crate::prelude::field(whole, "unshrunk")))), .gens = TRY(prism_rtl::from_pod<Map<Text, crate::check::typed::GenNote>>(TRY(crate::prelude::field(whole, "gens")))), .insts = TRY(prism_rtl::from_pod<Map<Text, Array<crate::check::typed::InstNote>>>(TRY(crate::prelude::field(whole, "insts")))), .quants = TRY(prism_rtl::from_pod<Map<Text, Text>>(TRY(crate::prelude::field(whole, "quants")))), .gen_of_q = TRY(prism_rtl::from_pod<Map<Text, crate::check::typed::GenNote>>(TRY(crate::prelude::field(whole, "gen_of_q")))), .use_insts = TRY(prism_rtl::from_pod<Map<Text, crate::check::typed::InstNote>>(TRY(crate::prelude::field(whole, "use_insts")))), .subst = TRY(prism_rtl::from_pod<Map<Text, crate::check::types::Ty>>(TRY(crate::prelude::field(whole, "subst")))), .csubst = TRY(prism_rtl::from_pod<Map<Text, crate::check::types::Col>>(TRY(crate::prelude::field(whole, "csubst"))))};
}




Pod Vl::to_pod() const {
    return std::holds_alternative<VlPlace>(cases()) ? Pod::choice("VlPlace", {prism_rtl::to_pod(std::get<VlPlace>(cases()).a0), prism_rtl::to_pod(std::get<VlPlace>(cases()).a1), prism_rtl::to_pod(std::get<VlPlace>(cases()).a2)})
        : std::holds_alternative<VlOwned>(cases()) ? Pod::choice("VlOwned", {prism_rtl::to_pod(std::get<VlOwned>(cases()).a0), prism_rtl::to_pod(std::get<VlOwned>(cases()).a1)})
        : Pod();
}

Result<Vl> Vl::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "VlPlace" && c->args.size() == 3) return Vl(VlPlace{TRY(prism_rtl::from_pod<crate::lower::model::Ex>(c->args[0])), TRY(prism_rtl::from_pod<Holding>(c->args[1])), TRY(prism_rtl::from_pod<crate::lower::model::OutTy>(c->args[2]))});
        if (c->ctor == "VlOwned" && c->args.size() == 2) return Vl(VlOwned{TRY(prism_rtl::from_pod<crate::lower::model::Ex>(c->args[0])), TRY(prism_rtl::from_pod<crate::lower::model::OutTy>(c->args[1]))});
    }
    return mismatch<Vl>("a Vl", p);
}


/// PlaceKey: fn Lx, Range -> Text
Text place_key(const Lx& lx, const crate::syntax::Range& r) {
    return prism_rtl::cat(lx->file, ":", r.start, ":", r.end);
}


/// TypeAt: fn Lx, Range -> Ty
crate::check::types::Ty type_at(const Lx& lx, const crate::syntax::Range& r) {
    return subst_ty(lx, or_(crate::prelude::get(lx.tys, place_key(lx, r)), crate::check::types::Ty(crate::check::types::Ty::TyErr{})));
}


/// BinderTy: fn Lx, Range -> Ty
crate::check::types::Ty binder_ty(const Lx& lx, const crate::syntax::Range& r) {
    auto&& _m = crate::prelude::get(lx.binders, place_key(lx, r));
    if (prism_rtl::is_some(_m)) {
        auto&& t = prism_rtl::some_of(_m);
        return subst_ty(lx, t);
    }
    if (prism_rtl::is_none(_m)) {
        return type_at(lx, r);
    }
    prism_rtl::unreachable("no arm matched");
}


/// SubstTy: fn Lx, Ty -> Ty
crate::check::types::Ty subst_ty(const Lx& lx, const crate::check::types::Ty& t) {
    return (len(keys(lx.subst)) == Nat(0u)) && (len(keys(lx.csubst)) == Nat(0u))
        ? t
        : subst_ty_in(lx, t);
}


/// SubstTyIn: fn Lx, Ty -> Ty
crate::check::types::Ty subst_ty_in(const Lx& lx, const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyFlex>(t).a0;
        return or_(crate::prelude::get(lx.subst, prism_rtl::cat("'", n)), t);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyCon{n, each(args, [&](const crate::check::types::Ty& a) { return subst_ty_in(lx, a); })});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t)) {
        auto&& c = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        return crate::check::types::Ty(crate::check::types::Ty::TyFn{inst_col(lx, c), each(ps, [&](const crate::check::types::Ty& p_) { return subst_ty_in(lx, p_); }), prism_rtl::rc(subst_ty_in(lx, res))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyTuple{each(ts, [&](const crate::check::types::Ty& a) { return subst_ty_in(lx, a); })});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(subst_ty_in(lx, e))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(subst_ty_in(lx, k)), prism_rtl::rc(subst_ty_in(lx, v_))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& s = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TySig{s, prism_rtl::rc(subst_ty_in(lx, i))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a0;
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(subst_ty_in(lx, i)), rw});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t)) {
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a0;
        auto&& o = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyElem{rw, prism_rtl::rc(subst_ty_in(lx, o))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t).a0;
        auto&& a = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyAssoc{n, prism_rtl::rc(subst_ty_in(lx, a))});
    }
    {
        auto&& other = t;
        return other;
    }
}


/// InstCol: fn Lx, Col -> Col
crate::check::types::Col inst_col(const Lx& lx, const crate::check::types::Col& col1) {
    if (prism_rtl::is<crate::check::types::Col::CQ>(col1)) {
        auto&& q = prism_rtl::as<crate::check::types::Col::CQ>(col1).a0;
        return or_(crate::prelude::get(lx.csubst, q), crate::check::types::Col(crate::check::types::Col::CQ{q}));
    }
    {
        auto&& c = col1;
        return c;
    }
}


/// IsQuantCol: fn Lx, Col -> Bool
bool is_quant_col(const Lx& lx, const crate::check::types::Col& col1) {
    if (prism_rtl::is<crate::check::types::Col::CQ>(col1)) {
        auto&& q = prism_rtl::as<crate::check::types::Col::CQ>(col1).a0;
        return crate::check::env::has_key(lx.quants, q);
    }
    {
        auto&& c = col1;
        return false;
    }
}


/// TypedTables: fn TProgram -> (((Text ==> Ty), (Text ==> AppNote), (Text ==> Ty), (Text ==> [ImplNote])))
std::tuple<Map<Text, crate::check::types::Ty>, Map<Text, crate::check::typed::AppNote>, Map<Text, crate::check::types::Ty>, Map<Text, Array<crate::check::typed::ImplNote>>> typed_tables(const crate::check::typed::TProgram& tp) {
    auto tys = fold(tp.exprs, Map<Text, crate::check::types::Ty>{}, [&](const Map<Text, crate::check::types::Ty>& m, const crate::check::typed::TyNote& n) { return insert(m, crate::check::typed::at_key(n.at), n.ty); });
    auto apps = fold(tp.apps, Map<Text, crate::check::typed::AppNote>{}, [&](const Map<Text, crate::check::typed::AppNote>& m, const crate::check::typed::AppNote& n) { return insert(m, crate::check::typed::at_key(n.at), n); });
    auto bs = fold(tp.binders, Map<Text, crate::check::types::Ty>{}, [&](const Map<Text, crate::check::types::Ty>& m, const crate::check::typed::BinderNote& n) { return insert(m, crate::check::typed::at_key(n.at), n.ty); });
    auto ims = fold(tp.impls, Map<Text, Array<crate::check::typed::ImplNote>>{}, [&](const Map<Text, Array<crate::check::typed::ImplNote>>& m, const crate::check::typed::ImplNote& n) { return insert(m, crate::check::typed::at_key(n.at), crate::prelude::push(or_(crate::prelude::get(m, crate::check::typed::at_key(n.at)), Array<crate::check::typed::ImplNote>{}), n)); });
    return std::tuple{tys, apps, bs, ims};
}


/// let rustKeywords
Array<Text> rust_keywords() {
    return Array(std::vector{Text::lit("as"), Text::lit("async"), Text::lit("await"), Text::lit("box"), Text::lit("break"), Text::lit("const"), Text::lit("continue"), Text::lit("crate"), Text::lit("do"), Text::lit("dyn"), Text::lit("else"), Text::lit("enum"), Text::lit("extern"), Text::lit("false"), Text::lit("final"), Text::lit("fn"), Text::lit("for"), Text::lit("gen"), Text::lit("if"), Text::lit("impl"), Text::lit("in"), Text::lit("let"), Text::lit("loop"), Text::lit("macro"), Text::lit("match"), Text::lit("mod"), Text::lit("move"), Text::lit("mut"), Text::lit("override"), Text::lit("priv"), Text::lit("pub"), Text::lit("ref"), Text::lit("return"), Text::lit("self"), Text::lit("static"), Text::lit("struct"), Text::lit("super"), Text::lit("trait"), Text::lit("true"), Text::lit("try"), Text::lit("type"), Text::lit("typeof"), Text::lit("unsafe"), Text::lit("unsized"), Text::lit("use"), Text::lit("virtual"), Text::lit("where"), Text::lit("while"), Text::lit("yield"), Text::lit("u8"), Text::lit("u16"), Text::lit("u32"), Text::lit("u64"), Text::lit("i8"), Text::lit("i16"), Text::lit("i32"), Text::lit("i64"), Text::lit("f32"), Text::lit("f64"), Text::lit("bool"), Text::lit("char"), Text::lit("str"), Text::lit("usize"), Text::lit("isize"), Text::lit("cx"), Text::lit("node"), Text::lit("path"), Text::lit("v"), Text::lit("p")});
}


/// Base: fn Text -> Text
Text base(const Text& name) {
    return crate::syntax::lexer::drop_prefix(name, crate::check::types::marks_of(name));
}


/// Snake: fn Text -> Text
Text snake(const Text& name) {
    auto&& _out = crate::syntax::lexer::fold_chars(base(name), std::tuple{Text::lit(""), Text::lit("")}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text>>(std::tuple<std::tuple<Text, Text>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Text, Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return once_job([=]() {
            return ({
                auto [acc, prev] = p0;
                auto c = p1;
                ({
                auto sep = crate::syntax::lexer::is_upper(c) && (crate::syntax::lexer::is_lower(prev) || crate::syntax::lexer::is_digit(prev))
                    ? Text::lit("_")
                    : Text::lit("");
                (prism_rtl::finished(std::tuple{prism_rtl::cat(acc, sep, lower_char(c)), c}));
            });
            });
        });
    })));
    auto&& out = std::get<0>(_out);
    auto plain = out == Text::lit("") ? Text::lit("x") : out;
    return crate::check::types::has_text(rust_keywords(), plain)
        ? prism_rtl::cat(plain, "_")
        : plain;
}


/// LowerChar: fn Text -> Text
Text lower_char(const Text& c) {
    return crate::syntax::lexer::is_upper(c) ? crate::prelude::lower(c) : c;
}


/// Camel: fn Text -> Text
Text camel(const Text& name) {
    auto b = base(name);
    auto first_ = crate::syntax::lexer::head(b);
    auto fixed = crate::syntax::lexer::is_lower(first_)
        ? prism_rtl::cat(upper(first_), crate::syntax::lexer::after_first(b))
        : b;
    return (fixed == Text::lit("Self")) || crate::check::types::has_text(runtime_names(), fixed)
        ? prism_rtl::cat(fixed, "_")
        : fixed;
}


/// let runtimeNames
Array<Text> runtime_names() {
    return Array(std::vector{Text::lit("AnswerOf"), Text::lit("BigInt"), Text::lit("Blueprint"), Text::lit("Box"), Text::lit("Built"), Text::lit("Cache"), Text::lit("Case"), Text::lit("Cell"), Text::lit("Clickable"), Text::lit("Collector"), Text::lit("Cursor"), Text::lit("Cx"), Text::lit("Defer"), Text::lit("Demand"), Text::lit("Document"), Text::lit("Done"), Text::lit("DynShow"), Text::lit("Dynamic"), Text::lit("Edit"), Text::lit("Err"), Text::lit("Event"), Text::lit("F64"), Text::lit("Fallible"), Text::lit("Fields"), Text::lit("Finishing"), Text::lit("Fn"), Text::lit("Forward"), Text::lit("FromPod"), Text::lit("Gathered"), Text::lit("Gen"), Text::lit("Handle"), Text::lit("Hold"), Text::lit("Host"), Text::lit("HostOf"), Text::lit("HostRow"), Text::lit("Inert"), Text::lit("IsShared"), Text::lit("IsValue"), Text::lit("Job"), Text::lit("JobRef"), Text::lit("Later"), Text::lit("Link"), Text::lit("List"), Text::lit("Live"), Text::lit("MakeNew"), Text::lit("MutElements"), Text::lit("Nanos"), Text::lit("NeverEvent"), Text::lit("NewSnapshot"), Text::lit("Node"), Text::lit("NodeRef"), Text::lit("None"), Text::lit("Ok"), Text::lit("OkUnit"), Text::lit("Option"), Text::lit("Outcome"), Text::lit("Panic"), Text::lit("Patch"), Text::lit("Path"), Text::lit("Pattern"), Text::lit("Pod"), Text::lit("Port"), Text::lit("Pos"), Text::lit("Printer"), Text::lit("Program"), Text::lit("Rc"), Text::lit("ReadyMap"), Text::lit("ReadyState"), Text::lit("RefCell"), Text::lit("Report"), Text::lit("Request"), Text::lit("Result"), Text::lit("Row"), Text::lit("Rows"), Text::lit("Runtime"), Text::lit("Scope"), Text::lit("Segment"), Text::lit("ShowRef"), Text::lit("ShownText"), Text::lit("Sink"), Text::lit("Slot"), Text::lit("Snapshot"), Text::lit("Some"), Text::lit("Stamped"), Text::lit("String"), Text::lit("Subscribed"), Text::lit("Subscriber"), Text::lit("Supplied"), Text::lit("Supplier"), Text::lit("TestWorld"), Text::lit("Tick"), Text::lit("TickIn"), Text::lit("TickOut"), Text::lit("ToPod"), Text::lit("Unexpected"), Text::lit("Unit"), Text::lit("Vec"), Text::lit("Weak"), Text::lit("World"), Text::lit("XorShift")});
}


/// RustModName: fn Text -> Text
Text rust_mod_name(const Text& m) {
    return m == Text::lit("")
        ? Text::lit("program")
        : crate::syntax::lexer::join(each(split(m, Text::lit(".")), [&](const Text& s) { return snake(s); }), Text::lit("::"));
}


/// PathIn: fn Lx, Text, Text -> Text
Text path_in(const Lx& lx, const Text& owner, const Text& name) {
    return owner == lx.site
        ? name
        : owner == Text::lit("Prelude")
        ? prelude_path(lx, name)
        : prism_rtl::cat("crate::", or_(crate::prelude::get(lx.rs_mods, owner), rust_mod_name(owner)), "::", name);
}


/// PreludePath: fn Lx, Text -> Text
Text prelude_path(const Lx& lx, const Text& name) {
    return crate::check::env::has_key(lx.globals, prism_rtl::cat(lx.site, ".", name))
        ? prism_rtl::cat("crate::prelude::", name)
        : name;
}


/// ValueNames: fn G -> (Text ==> Text)
Map<Text, Text> value_names(const crate::check::env::G& g) {
    auto lets = fold(g.defs, Array<Text>{}, [&](const Array<Text>& acc, const crate::check::env::Def& d) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = d.body;
            if (prism_rtl::is<crate::check::env::DefBody::DbLet>(_m)) {
                _v.set(crate::check::types::add_text(acc, d.qk));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto keys_ = crate::check::types::union_texts(keys(g.vals), lets);
    auto bases = fold(keys_, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& m, const Text& k) { return insert(m, base_key(k), crate::prelude::push(or_(crate::prelude::get(m, base_key(k)), Array<Text>{}), k)); });
    return fold(keys_, Map<Text, Text>{}, [&](const Map<Text, Text>& m, const Text& k) { return insert(m, k, value_name(k, len(or_(crate::prelude::get(bases, base_key(k)), Array<Text>{})))); });
}


/// GlobalNames: fn G -> (Text ==> Bool)
Map<Text, bool> global_names(const crate::check::env::G& g) {
    auto names = value_names(g);
    return fold(keys(names), Map<Text, bool>{}, [&](const Map<Text, bool>& m, const Text& k) { return insert(m, prism_rtl::cat(owner_of(k), ".", or_(crate::prelude::get(names, k), Text::lit(""))), true); });
}


/// LocalName: fn Lx, Text -> Text
Text local_name(const Lx& lx, const Text& nkey) {
    auto marks = crate::check::types::marks_of(nkey);
    auto base_ = snake(nkey);
    auto bare = crate::syntax::lexer::drop_prefix(nkey, marks);
    auto s0 = crate::syntax::lexer::contains(marks, Text::lit("?"))
        ? prism_rtl::cat(base_, "_opt")
        : crate::syntax::lexer::contains(marks, Text::lit("~"))
        ? prism_rtl::cat(base_, "_try")
        : base_;
    auto s1 = crate::check::env::is_upper_text(crate::syntax::lexer::head(bare))
        ? prism_rtl::cat(s0, "_fn")
        : s0;
    return crate::check::env::has_key(lx.globals, prism_rtl::cat(lx.site, ".", s1)) || crate::check::env::has_key(lx.globals, prism_rtl::cat("Prelude.", s1))
        ? prism_rtl::cat(s1, "_")
        : s1;
}


/// BaseKey: fn Text -> Text
Text base_key(const Text& k) {
    auto parts = split(k, Text::lit("."));
    auto last_1 = or_(crate::syntax::lexer::last(parts), k);
    return prism_rtl::cat(crate::syntax::lexer::join(take(parts, crate::syntax::lexer::dec(len(parts))), Text::lit(".")), ".", snake(last_1));
}


/// ValueName: fn Text, Nat -> Text
Text value_name(const Text& k, const Nat& count) {
    auto last = crate::check::types::bare_name(k);
    auto marks = crate::check::types::marks_of(last);
    auto base_ = snake(last);
    return (count > Nat(1u)) && (marks != Text::lit(""))
        ? prism_rtl::cat(base_, "_", sigil_word(crate::syntax::lexer::head(marks)))
        : (count > Nat(1u)) && (!crate::check::env::is_upper_text(crate::syntax::lexer::head(last)))
        ? prism_rtl::cat(base_, "_value")
        : base_;
}


/// SigilWord: fn Text -> Text
Text sigil_word(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("?")) {
            return Text::lit("opt");
        }
    }
    {
        auto&& c1_0 = text0;
        if (c1_0 == Text::lit("~")) {
            return Text::lit("try");
        }
    }
    {
        auto&& c2_0 = text0;
        if (c2_0 == Text::lit("!")) {
            return Text::lit("ev");
        }
    }
    {
        auto&& c3_0 = text0;
        if (c3_0 == Text::lit("$")) {
            return Text::lit("dyn");
        }
    }
    {
        auto&& c4_0 = text0;
        if (c4_0 == Text::lit("@")) {
            return Text::lit("widget");
        }
    }
    {
        auto&& c5_0 = text0;
        if (c5_0 == Text::lit("&")) {
            return Text::lit("ref");
        }
    }
    {
        auto&& other = text0;
        return Text::lit("x");
    }
}


/// ValuePath: fn Lx, Text -> Text
Text value_path(const Lx& lx, const Text& qk) {
    auto owner = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = crate::prelude::get(lx.g.vals, qk);
        if (prism_rtl::is_some(_m)) {
            auto&& v_ = prism_rtl::some_of(_m);
            _v.set(v_.home);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(owner_of(qk));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return path_in(lx, owner, or_(crate::prelude::get(lx.rs_names, qk), snake(crate::check::types::bare_name(qk))));
}


/// OwnerOf: fn Text -> Text
Text owner_of(const Text& qk) {
    auto parts = split(qk, Text::lit("."));
    return crate::syntax::lexer::join(take(parts, crate::syntax::lexer::dec(len(parts))), Text::lit("."));
}


/// TagStruct: fn Text -> Text
Text tag_struct(const Text& tn) {
    return concat(each(split(tn, Text::lit(".")), [&](const Text& p_) { return camel(p_); }));
}


/// OutTyOf: unbounded fn Lx, Ty -> OutTy
crate::lower::model::OutTy out_ty_of(const Lx& lx, const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m13002_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m13002_0_0 == Text::lit("Nat")) {
            if (m13002_0_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m13002_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m13002_1_0 == Text::lit("Int")) {
            if (m13002_1_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutInt{});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m13002_2_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_2_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m13002_2_0 == Text::lit("U8")) {
            if (m13002_2_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutU8{});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m13002_3_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_3_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m13002_3_0 == Text::lit("Float")) {
            if (m13002_3_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutFloat{});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m13002_4_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_4_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m13002_4_0 == Text::lit("Bool")) {
            if (m13002_4_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m13002_5_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_5_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m13002_5_0 == Text::lit("Char")) {
            if (m13002_5_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutChar{});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m13002_6_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_6_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m13002_6_0 == Text::lit("Text")) {
            if (m13002_6_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m13002_7_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_7_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m13002_7_0 == Text::lit("unit")) {
            if (m13002_7_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m13002_8_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_8_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m13002_8_0 == Text::lit("Path")) {
            if (m13002_8_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutPath{});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m13002_9_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_9_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m13002_9_0 == Text::lit("Cursor")) {
            if (m13002_9_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutCursor{});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m13002_10_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_10_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m13002_10_0 == Text::lit("Duration")) {
            if (m13002_10_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutDuration{});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m13002_11_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_11_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m13002_11_0 == Text::lit("Prelude.Error")) {
            if (m13002_11_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutError{});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m13002_12_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_12_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m13002_12_0 == Text::lit("\000Self"sv)) {
            if (m13002_12_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Self"), Array<crate::lower::model::OutTy>{}});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m13002_13_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_13_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m13002_13_0 == Text::lit("Buffer")) {
            if (m13002_13_1.size() == 1u) {
                {
                    auto&& _c1 = index(m13002_13_1, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& a = prism_rtl::some_of(_c1);
                        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutArray{prism_rtl::rc(out_ty_of(lx, a))});
                    }
                }
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m13002_14_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_14_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m13002_14_0 == Text::lit("Table")) {
            if (m13002_14_1.size() == 2u) {
                {
                    auto&& _c2 = index(m13002_14_1, Nat(0u));
                    if (prism_rtl::is_some(_c2)) {
                        auto&& k = prism_rtl::some_of(_c2);
                        {
                            auto&& _c1 = index(m13002_14_1, Nat(1u));
                            if (prism_rtl::is_some(_c1)) {
                                auto&& v_ = prism_rtl::some_of(_c1);
                                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutArray{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{Array(std::vector{out_ty_of(lx, k), out_ty_of(lx, v_)})}))});
                            }
                        }
                    }
                }
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m13002_15_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_15_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m13002_15_0 == Text::lit("\000Event"sv)) {
            if (m13002_15_1.size() == 1u) {
                {
                    auto&& _c1 = index(m13002_15_1, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& a = prism_rtl::some_of(_c1);
                        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutEvent{prism_rtl::rc(out_ty_of(lx, a))});
                    }
                }
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        return named_ty(lx, n, run_to_end(each_job(args, ({
            auto lx_1 = lx;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
            return ({
                auto lx_1_2 = lx_1;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_1_2, a))));
                });
            }));
            });
        })));
        }))));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t)) {
        auto&& c = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        auto c2 = inst_col(lx, c);
        return c2 == crate::check::types::Col(crate::check::types::Col::CBound{})
            ? crate::lower::model::OutTy(crate::lower::model::OutTy::OutFn{run_to_end(each_job(ps, ({
            auto lx_1 = lx;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
            return ({
                auto lx_1_2 = lx_1;
                entered(once_job([=]() {
                return ({
                    auto p_ = p0;
                    (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_1_2, p_))));
                });
            }));
            });
        })));
        }))), prism_rtl::rc(out_ty_of(lx, res))})
            : is_quant_col(lx, c2)
            ? crate::lower::model::OutTy(crate::lower::model::OutTy::OutQuantified{or_(crate::prelude::get(lx.quants, col_name(c2)), Text::lit(""))})
            : crate::lower::model::OutTy(crate::lower::model::OutTy::OutJobFn{prism_rtl::rc(rust_ty_of_params(lx, each(ps, [&](const crate::check::types::Ty& p_) { return job_param(p_); }))), prism_rtl::rc(out_ty_of(lx, res))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t)) {
        auto&& m13002_18_0 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        if (m13002_18_0.size() == 0u) {
            return crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{});
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{run_to_end(each_job(ts, ({
            auto lx_1 = lx;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
            return ({
                auto lx_1_2 = lx_1;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_1_2, a))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutArray{prism_rtl::rc(out_ty_of(lx, e))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(out_ty_of(lx, k)), prism_rtl::rc(out_ty_of(lx, v_))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& m13002_22_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        if (m13002_22_0 == Text::lit("?")) {
            return crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(out_ty_of(lx, i))});
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& m13002_23_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        if (m13002_23_0 == Text::lit("~")) {
            return crate::lower::model::OutTy(crate::lower::model::OutTy::OutRes{prism_rtl::rc(out_ty_of(lx, i))});
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& m13002_24_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        if (m13002_24_0 == Text::lit("!")) {
            return crate::lower::model::OutTy(crate::lower::model::OutTy::OutEvent{prism_rtl::rc(out_ty_of(lx, i))});
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& m13002_25_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        if (m13002_25_0 == Text::lit("$")) {
            return crate::lower::model::OutTy(crate::lower::model::OutTy::OutDyn{prism_rtl::rc(out_ty_of(lx, i))});
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& m13002_26_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        if (m13002_26_0 == Text::lit("&")) {
            return out_ty_of(lx, i);
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        return out_ty_of(lx, i);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyQ>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyQ>(t).a0;
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutGen{camel(n)});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyRigid>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyRigid>(t).a0;
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutGen{camel(n)});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyFlex>(t).a0;
        auto&& _m = crate::prelude::get(lx.subst, prism_rtl::cat("'", n));
        if (prism_rtl::is_some(_m)) {
            auto&& x = prism_rtl::some_of(_m);
            return out_ty_of(lx, x);
        }
        if (prism_rtl::is_none(_m)) {
            auto&& _m = crate::prelude::get(lx.quants, prism_rtl::cat("'", n));
            if (prism_rtl::is_some(_m)) {
                auto&& b = prism_rtl::some_of(_m);
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutQuantified{b});
            }
            if (prism_rtl::is_none(_m)) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{});
            }
            prism_rtl::unreachable("no arm matched");
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAny>(t)) {
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutShowAny{});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t)) {
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutLive{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("crate::Elem"), Array<crate::lower::model::OutTy>{}}))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(t)) {
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("crate::Elem"), Array<crate::lower::model::OutTy>{}});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a0;
        return blueprint_ty();
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t)) {
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{Text::lit("an associated type")});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyErr>(t)) {
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{Text::lit("a type the checker did not find")});
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::model::OutTy> OutTyOf::cycle() const {
    const auto& lx = this->lx;
    const auto& t = this->t;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m13002_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m13002_0_0 == Text::lit("Nat")) && (m13002_0_1.size() == 0u);
    }) ? ({
        auto&& m13002_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m13002_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m13002_1_0 == Text::lit("Int")) && (m13002_1_1.size() == 0u);
    }) ? ({
        auto&& m13002_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutInt{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m13002_2_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_2_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m13002_2_0 == Text::lit("U8")) && (m13002_2_1.size() == 0u);
    }) ? ({
        auto&& m13002_2_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_2_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutU8{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m13002_3_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_3_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m13002_3_0 == Text::lit("Float")) && (m13002_3_1.size() == 0u);
    }) ? ({
        auto&& m13002_3_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_3_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutFloat{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m13002_4_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_4_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m13002_4_0 == Text::lit("Bool")) && (m13002_4_1.size() == 0u);
    }) ? ({
        auto&& m13002_4_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_4_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m13002_5_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_5_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m13002_5_0 == Text::lit("Char")) && (m13002_5_1.size() == 0u);
    }) ? ({
        auto&& m13002_5_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_5_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutChar{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m13002_6_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_6_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m13002_6_0 == Text::lit("Text")) && (m13002_6_1.size() == 0u);
    }) ? ({
        auto&& m13002_6_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_6_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m13002_7_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_7_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m13002_7_0 == Text::lit("unit")) && (m13002_7_1.size() == 0u);
    }) ? ({
        auto&& m13002_7_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_7_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m13002_8_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_8_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m13002_8_0 == Text::lit("Path")) && (m13002_8_1.size() == 0u);
    }) ? ({
        auto&& m13002_8_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_8_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutPath{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m13002_9_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_9_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m13002_9_0 == Text::lit("Cursor")) && (m13002_9_1.size() == 0u);
    }) ? ({
        auto&& m13002_9_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_9_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutCursor{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m13002_10_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_10_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m13002_10_0 == Text::lit("Duration")) && (m13002_10_1.size() == 0u);
    }) ? ({
        auto&& m13002_10_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_10_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutDuration{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m13002_11_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_11_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m13002_11_0 == Text::lit("Prelude.Error")) && (m13002_11_1.size() == 0u);
    }) ? ({
        auto&& m13002_11_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_11_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutError{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m13002_12_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_12_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m13002_12_0 == Text::lit("\000Self"sv)) && (m13002_12_1.size() == 0u);
    }) ? ({
        auto&& m13002_12_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_12_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Self"), Array<crate::lower::model::OutTy>{}}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m13002_13_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_13_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m13002_13_0 == Text::lit("Buffer")) && (m13002_13_1.size() == 1u) && ({
        auto&& _c1 = index(m13002_13_1, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m13002_13_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_13_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        auto&& _c1 = index(m13002_13_1, Nat(0u));
        auto&& a = prism_rtl::some_of(_c1);
        ({
        auto lx_1 = lx;
        call_then(start_out_ty_of(lx_1, a), [=](crate::lower::model::OutTy out_ty_of_13499) { return prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutArray{prism_rtl::rc(out_ty_of_13499)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m13002_14_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_14_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m13002_14_0 == Text::lit("Table")) && (m13002_14_1.size() == 2u) && ({
        auto&& _c2 = index(m13002_14_1, Nat(0u));
        prism_rtl::is_some(_c2) && ({
        auto&& k = prism_rtl::some_of(_c2);
        ({
        auto&& _c1 = index(m13002_14_1, Nat(1u));
        prism_rtl::is_some(_c1);
    });
    });
    });
    }) ? ({
        auto&& m13002_14_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_14_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        auto&& _c2 = index(m13002_14_1, Nat(0u));
        auto&& k = prism_rtl::some_of(_c2);
        auto&& _c1 = index(m13002_14_1, Nat(1u));
        auto&& v_ = prism_rtl::some_of(_c1);
        ({
        auto lx_1 = lx;
        call_then(start_out_ty_of(lx_1, k), [=](crate::lower::model::OutTy out_ty_of_13565) { return call_then(start_out_ty_of(lx_1, v_), [=](crate::lower::model::OutTy out_ty_of_13582) { return prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutArray{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{Array(std::vector{out_ty_of_13565, out_ty_of_13582})}))})); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m13002_15_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_15_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m13002_15_0 == Text::lit("\000Event"sv)) && (m13002_15_1.size() == 1u) && ({
        auto&& _c1 = index(m13002_15_1, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m13002_15_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m13002_15_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        auto&& _c1 = index(m13002_15_1, Nat(0u));
        auto&& a = prism_rtl::some_of(_c1);
        ({
        auto lx_1 = lx;
        call_then(start_out_ty_of(lx_1, a), [=](crate::lower::model::OutTy out_ty_of_13641) { return prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutEvent{prism_rtl::rc(out_ty_of_13641)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        ({
        auto args_1 = args;
        auto lx_2 = lx;
        auto n_3 = n;
        call_value(each_job(args_1, ({
        auto lx_2_4 = lx_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return ({
            auto lx_2_4_4 = lx_2_4;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_2_4_4, a))));
            });
        }));
        });
    })));
    })), [=](Array<crate::lower::model::OutTy> each_13691) { return prism_rtl::more(prism_rtl::rc(NamedTy(lx_2, n_3, each_13691))); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(t) ? ({
        auto&& c = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        ({
        auto c2 = inst_col(lx, c);
        c2 == crate::check::types::Col(crate::check::types::Col::CBound{})
        ? ({
        auto lx_1 = lx;
        auto ps_2 = ps;
        auto res_3 = res;
        call_value(each_job(ps_2, ({
        auto lx_1_4 = lx_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return ({
            auto lx_1_4_4 = lx_1_4;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_1_4_4, p_))));
            });
        }));
        });
    })));
    })), [=](Array<crate::lower::model::OutTy> each_13972) { return call_then(start_out_ty_of(lx_1, res_3), [=](crate::lower::model::OutTy out_ty_of_14003) { return prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutFn{each_13972, prism_rtl::rc(out_ty_of_14003)})); }); });
    })
        : is_quant_col(lx, c2)
        ? prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutQuantified{or_(crate::prelude::get(lx.quants, col_name(c2)), Text::lit(""))}))
        : ({
        auto lx_1 = lx;
        auto ps_2 = ps;
        auto res_3 = res;
        call_then(start_rust_ty_of_params(lx_1, each(ps_2, [&](const crate::check::types::Ty& p_) { return job_param(p_); })), [=](crate::lower::model::OutTy rust_ty_of_params_14125) { return call_then(start_out_ty_of(lx_1, res_3), [=](crate::lower::model::OutTy out_ty_of_14174) { return prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutJobFn{prism_rtl::rc(rust_ty_of_params_14125), prism_rtl::rc(out_ty_of_14174)})); }); });
    });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t) && ({
        auto&& m13002_18_0 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        (m13002_18_0.size() == 0u);
    }) ? ({
        auto&& m13002_18_0 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        ({
        auto lx_1 = lx;
        auto ts_2 = ts;
        call_value(each_job(ts_2, ({
        auto lx_1_3 = lx_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return ({
            auto lx_1_3_3 = lx_1_3;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_1_3_3, a))));
            });
        }));
        });
    })));
    })), [=](Array<crate::lower::model::OutTy> each_14243) { return prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{each_14243})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        ({
        auto e_1 = e;
        auto lx_2 = lx;
        call_then(start_out_ty_of(lx_2, e_1), [=](crate::lower::model::OutTy out_ty_of_14297) { return prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutArray{prism_rtl::rc(out_ty_of_14297)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        ({
        auto k_1 = k;
        auto lx_2 = lx;
        auto v__3 = v_;
        call_then(start_out_ty_of(lx_2, k_1), [=](crate::lower::model::OutTy out_ty_of_14336) { return call_then(start_out_ty_of(lx_2, v__3), [=](crate::lower::model::OutTy out_ty_of_14353) { return prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(out_ty_of_14336), prism_rtl::rc(out_ty_of_14353)})); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t) && ({
        auto&& m13002_22_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        (m13002_22_0 == Text::lit("?"));
    }) ? ({
        auto&& m13002_22_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        ({
        auto i_1 = i;
        auto lx_2 = lx;
        call_then(start_out_ty_of(lx_2, i_1), [=](crate::lower::model::OutTy out_ty_of_14394) { return prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(out_ty_of_14394)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t) && ({
        auto&& m13002_23_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        (m13002_23_0 == Text::lit("~"));
    }) ? ({
        auto&& m13002_23_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        ({
        auto i_1 = i;
        auto lx_2 = lx;
        call_then(start_out_ty_of(lx_2, i_1), [=](crate::lower::model::OutTy out_ty_of_14435) { return prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutRes{prism_rtl::rc(out_ty_of_14435)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t) && ({
        auto&& m13002_24_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        (m13002_24_0 == Text::lit("!"));
    }) ? ({
        auto&& m13002_24_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        ({
        auto i_1 = i;
        auto lx_2 = lx;
        call_then(start_out_ty_of(lx_2, i_1), [=](crate::lower::model::OutTy out_ty_of_14478) { return prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutEvent{prism_rtl::rc(out_ty_of_14478)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t) && ({
        auto&& m13002_25_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        (m13002_25_0 == Text::lit("$"));
    }) ? ({
        auto&& m13002_25_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        ({
        auto i_1 = i;
        auto lx_2 = lx;
        call_then(start_out_ty_of(lx_2, i_1), [=](crate::lower::model::OutTy out_ty_of_14519) { return prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutDyn{prism_rtl::rc(out_ty_of_14519)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t) && ({
        auto&& m13002_26_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        (m13002_26_0 == Text::lit("&"));
    }) ? ({
        auto&& m13002_26_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        prism_rtl::more(prism_rtl::rc(OutTyOf(lx, i)));
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t) ? ({
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        prism_rtl::more(prism_rtl::rc(OutTyOf(lx, i)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyQ>(t) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyQ>(t).a0;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutGen{camel(n)}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyRigid>(t) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyRigid>(t).a0;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutGen{camel(n)}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyFlex>(t) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyFlex>(t).a0;
        ({
        auto&& _m = crate::prelude::get(lx.subst, prism_rtl::cat("'", n));
        prism_rtl::is_some(_m) ? ({
        auto&& x = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(OutTyOf(lx, x)));
    })
        : prism_rtl::is_none(_m) ? ({
        auto&& _m = crate::prelude::get(lx.quants, prism_rtl::cat("'", n));
        prism_rtl::is_some(_m) ? ({
        auto&& b = prism_rtl::some_of(_m);
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutQuantified{b}));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyAny>(t) ? prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutShowAny{}))
        : prism_rtl::is<crate::check::types::Ty::TyElem>(t) ? prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutLive{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("crate::Elem"), Array<crate::lower::model::OutTy>{}}))}))
        : prism_rtl::is<crate::check::types::Ty::TyElemAny>(t) ? prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("crate::Elem"), Array<crate::lower::model::OutTy>{}}))
        : prism_rtl::is<crate::check::types::Ty::TyAt>(t) ? ({
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a0;
        prism_rtl::finished(blueprint_ty());
    })
        : prism_rtl::is<crate::check::types::Ty::TyAssoc>(t) ? prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{Text::lit("an associated type")}))
        : prism_rtl::is<crate::check::types::Ty::TyErr>(t) ? prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{Text::lit("a type the checker did not find")}))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start OutTyOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::OutTy> start_out_ty_of(Lx lx, crate::check::types::Ty t) {
    return prism_rtl::make_rc<OutTyOf>(lx, t);
}


/// let blueprintTy
crate::lower::model::OutTy blueprint_ty() {
    return crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("prism_rtl::Blueprint"), Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("crate::Elem"), Array<crate::lower::model::OutTy>{}}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("crate::Answer"), Array<crate::lower::model::OutTy>{}})})});
}


/// let elemTy
crate::lower::model::OutTy elem_ty() {
    return crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("crate::Elem"), Array<crate::lower::model::OutTy>{}});
}


/// let answerTy
crate::lower::model::OutTy answer_ty_value() {
    return crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("crate::Answer"), Array<crate::lower::model::OutTy>{}});
}


/// let hostOfTy
crate::lower::model::OutTy host_of_ty() {
    return crate::lower::model::OutTy(crate::lower::model::OutTy::OutObj{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("prism_rtl::HostOf"), Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("crate::Elem"), Array<crate::lower::model::OutTy>{}}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("crate::Answer"), Array<crate::lower::model::OutTy>{}})})}))});
}


/// HasBlueprint: fn Ty -> Bool
bool has_blueprint(const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t)) {
        return true;
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        return has_blueprint(i);
    }
    {
        return false;
    }
}


/// EventParam: fn Ty -> Ty
crate::check::types::Ty event_param(const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& m16025_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        if (m16025_0_0 == Text::lit("!")) {
            return crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("\000Event"sv), Array(std::vector{peel(i)})});
        }
    }
    {
        return t;
    }
}


/// JobParam: fn Ty -> Ty
crate::check::types::Ty job_param(const crate::check::types::Ty& ty0) {
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(ty0)) {
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(ty0).a1;
        auto&& r = prism_rtl::as<crate::check::types::Ty::TyFn>(ty0).a2;
        return crate::check::types::Ty(crate::check::types::Ty::TyFn{crate::check::types::Col(crate::check::types::Col::CUnbound{}), ps, prism_rtl::rc(r)});
    }
    {
        auto&& t = ty0;
        return t;
    }
}


/// RustTyOfParams: unbounded fn Lx, [Ty] -> OutTy
crate::lower::model::OutTy rust_ty_of_params(const Lx& lx, const Array<crate::check::types::Ty>& ps) {
    {
        auto&& m16588_0 = ps;
        if (m16588_0.size() == 1u) {
            {
                auto&& _c1 = index(m16588_0, Nat(0u));
                if (prism_rtl::is_some(_c1)) {
                    auto&& p_ = prism_rtl::some_of(_c1);
                    return out_ty_of(lx, p_);
                }
            }
        }
    }
    {
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{run_to_end(each_job(ps, ({
            auto lx_1 = lx;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
            return ({
                auto lx_1_2 = lx_1;
                entered(once_job([=]() {
                return ({
                    auto p_ = p0;
                    (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_1_2, p_))));
                });
            }));
            });
        })));
        })))});
    }
}


prism_rtl::Turn<crate::lower::model::OutTy> RustTyOfParams::cycle() const {
    const auto& lx = this->lx;
    const auto& ps = this->ps;
    return ({
        ({
        auto&& m16588_0 = ps;
        (m16588_0.size() == 1u) && ({
        auto&& _c1 = index(m16588_0, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m16588_0 = ps;
        auto&& _c1 = index(m16588_0, Nat(0u));
        auto&& p_ = prism_rtl::some_of(_c1);
        prism_rtl::more(prism_rtl::rc(OutTyOf(lx, p_)));
    })
        : ({
        auto lx_1 = lx;
        auto ps_2 = ps;
        call_value(each_job(ps_2, ({
        auto lx_1_3 = lx_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return ({
            auto lx_1_3_3 = lx_1_3;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_1_3_3, p_))));
            });
        }));
        });
    })));
    })), [=](Array<crate::lower::model::OutTy> each_16648) { return prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{each_16648})); });
    });
    });
}


/// `Start RustTyOfParams, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::OutTy> start_rust_ty_of_params(Lx lx, Array<crate::check::types::Ty> ps) {
    return prism_rtl::make_rc<RustTyOfParams>(lx, ps);
}


/// NamedTy: unbounded fn Lx, Text, [OutTy] -> OutTy
crate::lower::model::OutTy named_ty(const Lx& lx, const Text& n, const Array<crate::lower::model::OutTy>& args) {
    auto&& _m = crate::prelude::get(lx.g.types, n);
    if (prism_rtl::is_some(_m)) {
        auto&& ti = prism_rtl::some_of(_m);
        auto&& _m = ti.body;
        if (prism_rtl::is<crate::check::env::TyBody::BAlias>(_m)) {
            auto&& a = prism_rtl::as<crate::check::env::TyBody::BAlias>(_m).a0;
            return out_ty_of(lx, a);
        }
        if (prism_rtl::is<crate::check::env::TyBody::BRowKind>(_m)) {
            return n == Text::lit("Prelude.Fault")
                ? crate::lower::model::OutTy(crate::lower::model::OutTy::OutPod{})
                : crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{path_in(lx, ti.home, camel(crate::check::types::bare_name(n))), Array<crate::lower::model::OutTy>{}});
        }
        {
            return crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{path_in(lx, ti.home, camel(crate::check::types::bare_name(n))), args});
        }
    }
    if (prism_rtl::is_none(_m)) {
        return crate::check::env::has_key(lx.g.families, n)
            ? crate::lower::model::OutTy(crate::lower::model::OutTy::OutPod{})
            : crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{camel(crate::check::types::bare_name(n)), args});
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::model::OutTy> NamedTy::cycle() const {
    const auto& lx = this->lx;
    const auto& n = this->n;
    const auto& args = this->args;
    return ({
        auto&& _m = crate::prelude::get(lx.g.types, n);
        prism_rtl::is_some(_m) ? ({
        auto&& ti = prism_rtl::some_of(_m);
        ({
        auto&& _m = ti.body;
        prism_rtl::is<crate::check::env::TyBody::BAlias>(_m) ? ({
        auto&& a = prism_rtl::as<crate::check::env::TyBody::BAlias>(_m).a0;
        prism_rtl::more(prism_rtl::rc(OutTyOf(lx, a)));
    })
        : prism_rtl::is<crate::check::env::TyBody::BRowKind>(_m) ? n == Text::lit("Prelude.Fault")
        ? prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutPod{}))
        : prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{path_in(lx, ti.home, camel(crate::check::types::bare_name(n))), Array<crate::lower::model::OutTy>{}}))
        : prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{path_in(lx, ti.home, camel(crate::check::types::bare_name(n))), args}));
    });
    })
        : prism_rtl::is_none(_m) ? crate::check::env::has_key(lx.g.families, n)
        ? prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutPod{}))
        : prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{camel(crate::check::types::bare_name(n)), args}))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start NamedTy, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::OutTy> start_named_ty(Lx lx, Text n, Array<crate::lower::model::OutTy> args) {
    return prism_rtl::make_rc<NamedTy>(lx, n, args);
}


/// Peel: fn Ty -> Ty
crate::check::types::Ty peel(const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& m17386_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        if (m17386_0_0 == Text::lit("$")) {
            return peel(i);
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& m17386_1_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        if (m17386_1_0 == Text::lit("!")) {
            return peel(i);
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& m17386_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        if (m17386_2_0 == Text::lit("&")) {
            return peel(i);
        }
    }
    {
        return t;
    }
}


/// OutOf: fn Ty -> Ty
crate::check::types::Ty out_of(const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a0;
        return peel(i);
    }
    {
        return peel(t);
    }
}


/// LayerOf: fn Ty -> Layer
Layer layer_of(const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& m17902_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        if (m17902_0_0 == Text::lit("$")) {
            return Layer(Layer::LyDyn{});
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& m17902_1_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        if (m17902_1_0 == Text::lit("!")) {
            return Layer(Layer::LyEv{});
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& m17902_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        if (m17902_2_0 == Text::lit("&")) {
            return layer_of(i);
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t)) {
        return Layer(Layer::LyBlueprint{});
    }
    {
        return Layer(Layer::LyPlain{});
    }
}


/// Layouts: unbounded fn G -> (Text ==> [Bool])
Map<Text, Array<bool>> layouts(const crate::check::env::G& g) {
    return run_to_end(fold_job(values(g.ctors), Map<Text, Array<bool>>{}, ({
        auto g_1 = g;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<bool>>>(std::tuple<Map<Text, Array<bool>>, crate::check::env::CtorInfo>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Array<bool>>, crate::check::env::CtorInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_2 = g_1;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                auto c = p1;
                call_value(each_job(c->args, ({
                auto g_1_2_2 = g_1_2;
                auto c_2 = c;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
                return ({
                    auto g_1_2_2_3 = g_1_2_2;
                    auto c_2_3 = c_2;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        (prism_rtl::more(prism_rtl::rc(Reaches(g_1_2_2_3, a, c_2_3.owner, Array<Text>{}))));
                    });
                }));
                });
            })));
            })), [=](Array<bool> each_18408) { return prism_rtl::finished(insert(m, c.name, each_18408)); });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<Map<Text, Array<bool>>> Layouts::cycle() const {
    const auto& g = this->g;
    return fold_job(values(g.ctors), Map<Text, Array<bool>>{}, ({
        auto g_1 = g;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<bool>>>(std::tuple<Map<Text, Array<bool>>, crate::check::env::CtorInfo>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Array<bool>>, crate::check::env::CtorInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_2 = g_1;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                auto c = p1;
                call_value(each_job(c->args, ({
                auto g_1_2_2 = g_1_2;
                auto c_2 = c;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
                return ({
                    auto g_1_2_2_3 = g_1_2_2;
                    auto c_2_3 = c_2;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        (prism_rtl::more(prism_rtl::rc(Reaches(g_1_2_2_3, a, c_2_3.owner, Array<Text>{}))));
                    });
                }));
                });
            })));
            })), [=](Array<bool> each_18408) { return prism_rtl::finished(insert(m, c.name, each_18408)); });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start Layouts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Array<bool>>> start_layouts(crate::check::env::G g) {
    return prism_rtl::make_rc<Layouts>(g);
}


/// Reaches: unbounded fn G, Ty, Text, [Text] -> Bool
bool reaches(const crate::check::env::G& g, const crate::check::types::Ty& t, const Text& target, const Array<Text>& seen) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        return n == target
            ? true
            : crate::check::types::has_text(seen, n)
            ? false
            : run_to_end(fold_job(args, false, ({
            auto g_1 = g;
            auto target_2 = target;
            auto seen_3 = seen;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto g_1_4 = g_1;
                auto target_2_4 = target_2;
                auto seen_3_4 = seen_3;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    auto a = p1;
                    (prism_rtl::finished(f || reaches(g_1_4, a, target_2_4, seen_3_4)));
                });
            }));
            });
        })));
        })))
            ? true
            : ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = crate::prelude::get(g.types, n);
            if (prism_rtl::is_some(_m)) {
                auto&& ti = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = ti.body;
                    if (prism_rtl::is<crate::check::env::TyBody::BRecord>(_m)) {
                        auto&& fs = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
                        _v.set(run_to_end(fold_job(fs, false, ({
                            auto g_1 = g;
                            auto target_2 = target;
                            auto seen_3 = seen;
                            auto n_4 = n;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, crate::check::types::Ty>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, crate::check::types::Ty>> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto g_1_5 = g_1;
                                auto target_2_5 = target_2;
                                auto seen_3_5 = seen_3;
                                auto n_4_5 = n_4;
                                entered(once_job([=]() {
                                return ({
                                    auto f = p0;
                                    auto&& _ft = p1;
                                    auto&& ft = std::get<1>(_ft);
                                    (prism_rtl::finished(f || reaches(g_1_5, ft, target_2_5, crate::prelude::push(seen_3_5, n_4_5))));
                                });
                            }));
                            });
                        })));
                        }))));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
                        auto&& cs = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
                        _v.set(run_to_end(fold_job(cs, false, ({
                            auto g_1 = g;
                            auto target_2 = target;
                            auto seen_3 = seen;
                            auto n_4 = n;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Array<crate::check::types::Ty>>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Array<crate::check::types::Ty>>> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto g_1_5 = g_1;
                                auto target_2_5 = target_2;
                                auto seen_3_5 = seen_3;
                                auto n_4_5 = n_4;
                                entered(once_job([=]() {
                                return ({
                                    auto f = p0;
                                    auto&& _ats = p1;
                                    auto&& ats = std::get<1>(_ats);
                                    (prism_rtl::finished(f || run_to_end(fold_job(ats, false, ({
                                    auto g_1_5_5 = g_1_5;
                                    auto target_2_5_5 = target_2_5;
                                    auto seen_3_5_5 = seen_3_5;
                                    auto n_4_5_5 = n_4_5;
                                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
                                    auto&& p0 = std::get<0>(_p0);
                                    auto&& p1 = std::get<1>(_p0);
                                    return ({
                                        auto g_1_5_5_5 = g_1_5_5;
                                        auto target_2_5_5_5 = target_2_5_5;
                                        auto seen_3_5_5_5 = seen_3_5_5;
                                        auto n_4_5_5_5 = n_4_5_5;
                                        entered(once_job([=]() {
                                        return ({
                                            auto f2 = p0;
                                            auto at_ = p1;
                                            (prism_rtl::finished(f2 || reaches(g_1_5_5_5, at_, target_2_5_5_5, crate::prelude::push(seen_3_5_5_5, n_4_5_5_5))));
                                        });
                                    }));
                                    });
                                })));
                                })))));
                                });
                            }));
                            });
                        })));
                        }))));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::env::TyBody::BAlias>(_m)) {
                        auto&& a = prism_rtl::as<crate::check::env::TyBody::BAlias>(_m).a0;
                        _v.set(reaches(g, a, target, crate::prelude::push(seen, n)));
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& m18538_1_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        if (m18538_1_0 == Text::lit("?")) {
            return reaches(g, i, target, seen);
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& m18538_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        if (m18538_2_0 == Text::lit("~")) {
            return reaches(g, i, target, seen);
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        return run_to_end(fold_job(ts, false, ({
            auto g_1 = g;
            auto target_2 = target;
            auto seen_3 = seen;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto g_1_4 = g_1;
                auto target_2_4 = target_2;
                auto seen_3_4 = seen_3;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    auto a = p1;
                    (prism_rtl::finished(f || reaches(g_1_4, a, target_2_4, seen_3_4)));
                });
            }));
            });
        })));
        })));
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> Reaches::cycle() const {
    const auto& g = this->g;
    const auto& t = this->t;
    const auto& target = this->target;
    const auto& seen = this->seen;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyCon>(t) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        n == target
        ? prism_rtl::finished(true)
        : crate::check::types::has_text(seen, n)
        ? prism_rtl::finished(false)
        : ({
        auto args_1 = args;
        auto g_2 = g;
        auto n_3 = n;
        auto seen_4 = seen;
        auto target_5 = target;
        call_value(fold_job(args_1, false, ({
        auto g_2_6 = g_2;
        auto target_5_6 = target_5;
        auto seen_4_6 = seen_4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_2_6_6 = g_2_6;
            auto target_5_6_6 = target_5_6;
            auto seen_4_6_6 = seen_4_6;
            entered(once_job([=]() {
            return ({
                auto f = p0;
                auto a = p1;
                (prism_rtl::finished(f || reaches(g_2_6_6, a, target_5_6_6, seen_4_6_6)));
            });
        }));
        });
    })));
    })), [=](bool fold_18652) {
        return fold_18652
            ? prism_rtl::finished(true)
            : ({
            auto&& _m = crate::prelude::get(g_2.types, n_3);
            prism_rtl::is_some(_m) ? ({
            auto&& ti = prism_rtl::some_of(_m);
            ({
            auto&& _m = ti.body;
            prism_rtl::is<crate::check::env::TyBody::BRecord>(_m) ? ({
            auto&& fs = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
            fold_job(fs, false, ({
            auto g_2_6 = g_2;
            auto target_5_6 = target_5;
            auto seen_4_6 = seen_4;
            auto n_3_6 = n_3;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, crate::check::types::Ty>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, crate::check::types::Ty>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto g_2_6_6 = g_2_6;
                auto target_5_6_6 = target_5_6;
                auto seen_4_6_6 = seen_4_6;
                auto n_3_6_6 = n_3_6;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    auto&& _ft = p1;
                    auto&& ft = std::get<1>(_ft);
                    (prism_rtl::finished(f || reaches(g_2_6_6, ft, target_5_6_6, crate::prelude::push(seen_4_6_6, n_3_6_6))));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::check::env::TyBody::BChoice>(_m) ? ({
            auto&& cs = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
            fold_job(cs, false, ({
            auto g_2_6 = g_2;
            auto target_5_6 = target_5;
            auto seen_4_6 = seen_4;
            auto n_3_6 = n_3;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Array<crate::check::types::Ty>>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Array<crate::check::types::Ty>>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto g_2_6_6 = g_2_6;
                auto target_5_6_6 = target_5_6;
                auto seen_4_6_6 = seen_4_6;
                auto n_3_6_6 = n_3_6;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    auto&& _ats = p1;
                    auto&& ats = std::get<1>(_ats);
                    (prism_rtl::finished(f || run_to_end(fold_job(ats, false, ({
                    auto g_2_6_6_6 = g_2_6_6;
                    auto target_5_6_6_6 = target_5_6_6;
                    auto seen_4_6_6_6 = seen_4_6_6;
                    auto n_3_6_6_6 = n_3_6_6;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto g_2_6_6_6_6 = g_2_6_6_6;
                        auto target_5_6_6_6_6 = target_5_6_6_6;
                        auto seen_4_6_6_6_6 = seen_4_6_6_6;
                        auto n_3_6_6_6_6 = n_3_6_6_6;
                        entered(once_job([=]() {
                        return ({
                            auto f2 = p0;
                            auto at_ = p1;
                            (prism_rtl::finished(f2 || reaches(g_2_6_6_6_6, at_, target_5_6_6_6_6, crate::prelude::push(seen_4_6_6_6_6, n_3_6_6_6_6))));
                        });
                    }));
                    });
                })));
                })))));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::check::env::TyBody::BAlias>(_m) ? ({
            auto&& a = prism_rtl::as<crate::check::env::TyBody::BAlias>(_m).a0;
            prism_rtl::more(prism_rtl::rc(Reaches(g_2, a, target_5, crate::prelude::push(seen_4, n_3))));
        })
            : prism_rtl::finished(false);
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t) && ({
        auto&& m18538_1_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        (m18538_1_0 == Text::lit("?"));
    }) ? ({
        auto&& m18538_1_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        prism_rtl::more(prism_rtl::rc(Reaches(g, i, target, seen)));
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t) && ({
        auto&& m18538_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        (m18538_2_0 == Text::lit("~"));
    }) ? ({
        auto&& m18538_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        prism_rtl::more(prism_rtl::rc(Reaches(g, i, target, seen)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        fold_job(ts, false, ({
        auto g_1 = g;
        auto target_2 = target;
        auto seen_3 = seen;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_4 = g_1;
            auto target_2_4 = target_2;
            auto seen_3_4 = seen_3;
            entered(once_job([=]() {
            return ({
                auto f = p0;
                auto a = p1;
                (prism_rtl::finished(f || reaches(g_1_4, a, target_2_4, seen_3_4)));
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::finished(false);
    });
}


/// `Start Reaches, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_reaches(crate::check::env::G g, crate::check::types::Ty t, Text target, Array<Text> seen) {
    return prism_rtl::make_rc<Reaches>(g, t, target, seen);
}


/// RcField: fn Lx, Text, Nat -> Bool
bool rc_field(const Lx& lx, const Text& ctor, const Nat& i) {
    return or_(index(or_(crate::prelude::get(lx.layouts, ctor), Array<bool>{}), i), false);
}


/// Floaty: unbounded fn G, Ty, [Text] -> Bool
bool floaty(const crate::check::env::G& g, const crate::check::types::Ty& t, const Array<Text>& seen) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m19642_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m19642_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m19642_0_0 == Text::lit("Float")) {
            if (m19642_0_1.size() == 0u) {
                return true;
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        return run_to_end(fold_job(args, false, ({
            auto g_1 = g;
            auto seen_2 = seen;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto g_1_3 = g_1;
                auto seen_2_3 = seen_2;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    auto a = p1;
                    (prism_rtl::finished(f || floaty(g_1_3, a, seen_2_3)));
                });
            }));
            });
        })));
        })))
            ? true
            : crate::check::types::has_text(seen, n)
            ? false
            : ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = crate::prelude::get(g.types, n);
            if (prism_rtl::is_some(_m)) {
                auto&& ti = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = ti.body;
                    if (prism_rtl::is<crate::check::env::TyBody::BRecord>(_m)) {
                        auto&& fs = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
                        _v.set(run_to_end(fold_job(fs, false, ({
                            auto g_1 = g;
                            auto seen_2 = seen;
                            auto n_3 = n;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, crate::check::types::Ty>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, crate::check::types::Ty>> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto g_1_4 = g_1;
                                auto seen_2_4 = seen_2;
                                auto n_3_4 = n_3;
                                entered(once_job([=]() {
                                return ({
                                    auto f = p0;
                                    auto&& _ft = p1;
                                    auto&& ft = std::get<1>(_ft);
                                    (prism_rtl::finished(f || floaty(g_1_4, ft, crate::prelude::push(seen_2_4, n_3_4))));
                                });
                            }));
                            });
                        })));
                        }))));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
                        auto&& cs = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
                        _v.set(run_to_end(fold_job(cs, false, ({
                            auto g_1 = g;
                            auto seen_2 = seen;
                            auto n_3 = n;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Array<crate::check::types::Ty>>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Array<crate::check::types::Ty>>> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto g_1_4 = g_1;
                                auto seen_2_4 = seen_2;
                                auto n_3_4 = n_3;
                                entered(once_job([=]() {
                                return ({
                                    auto f = p0;
                                    auto&& _ats = p1;
                                    auto&& ats = std::get<1>(_ats);
                                    (prism_rtl::finished(f || run_to_end(fold_job(ats, false, ({
                                    auto g_1_4_4 = g_1_4;
                                    auto seen_2_4_4 = seen_2_4;
                                    auto n_3_4_4 = n_3_4;
                                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
                                    auto&& p0 = std::get<0>(_p0);
                                    auto&& p1 = std::get<1>(_p0);
                                    return ({
                                        auto g_1_4_4_4 = g_1_4_4;
                                        auto seen_2_4_4_4 = seen_2_4_4;
                                        auto n_3_4_4_4 = n_3_4_4;
                                        entered(once_job([=]() {
                                        return ({
                                            auto f2 = p0;
                                            auto at_ = p1;
                                            (prism_rtl::finished(f2 || floaty(g_1_4_4_4, at_, crate::prelude::push(seen_2_4_4_4, n_3_4_4_4))));
                                        });
                                    }));
                                    });
                                })));
                                })))));
                                });
                            }));
                            });
                        })));
                        }))));
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        return floaty(g, i, seen);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        return run_to_end(fold_job(ts, false, ({
            auto g_1 = g;
            auto seen_2 = seen;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto g_1_3 = g_1;
                auto seen_2_3 = seen_2;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    auto a = p1;
                    (prism_rtl::finished(f || floaty(g_1_3, a, seen_2_3)));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        return floaty(g, e, seen);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        return floaty(g, k, seen) || floaty(g, v_, seen);
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> Floaty::cycle() const {
    const auto& g = this->g;
    const auto& t = this->t;
    const auto& seen = this->seen;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m19642_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m19642_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m19642_0_0 == Text::lit("Float")) && (m19642_0_1.size() == 0u);
    }) ? ({
        auto&& m19642_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m19642_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        prism_rtl::finished(true);
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        ({
        auto args_1 = args;
        auto g_2 = g;
        auto n_3 = n;
        auto seen_4 = seen;
        call_value(fold_job(args_1, false, ({
        auto g_2_5 = g_2;
        auto seen_4_5 = seen_4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_2_5_5 = g_2_5;
            auto seen_4_5_5 = seen_4_5;
            entered(once_job([=]() {
            return ({
                auto f = p0;
                auto a = p1;
                (prism_rtl::finished(f || floaty(g_2_5_5, a, seen_4_5_5)));
            });
        }));
        });
    })));
    })), [=](bool fold_19711) {
        return fold_19711
            ? prism_rtl::finished(true)
            : crate::check::types::has_text(seen_4, n_3)
            ? prism_rtl::finished(false)
            : ({
            auto&& _m = crate::prelude::get(g_2.types, n_3);
            prism_rtl::is_some(_m) ? ({
            auto&& ti = prism_rtl::some_of(_m);
            ({
            auto&& _m = ti.body;
            prism_rtl::is<crate::check::env::TyBody::BRecord>(_m) ? ({
            auto&& fs = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
            fold_job(fs, false, ({
            auto g_2_5 = g_2;
            auto seen_4_5 = seen_4;
            auto n_3_5 = n_3;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, crate::check::types::Ty>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, crate::check::types::Ty>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto g_2_5_5 = g_2_5;
                auto seen_4_5_5 = seen_4_5;
                auto n_3_5_5 = n_3_5;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    auto&& _ft = p1;
                    auto&& ft = std::get<1>(_ft);
                    (prism_rtl::finished(f || floaty(g_2_5_5, ft, crate::prelude::push(seen_4_5_5, n_3_5_5))));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::check::env::TyBody::BChoice>(_m) ? ({
            auto&& cs = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
            fold_job(cs, false, ({
            auto g_2_5 = g_2;
            auto seen_4_5 = seen_4;
            auto n_3_5 = n_3;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Array<crate::check::types::Ty>>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Array<crate::check::types::Ty>>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto g_2_5_5 = g_2_5;
                auto seen_4_5_5 = seen_4_5;
                auto n_3_5_5 = n_3_5;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    auto&& _ats = p1;
                    auto&& ats = std::get<1>(_ats);
                    (prism_rtl::finished(f || run_to_end(fold_job(ats, false, ({
                    auto g_2_5_5_5 = g_2_5_5;
                    auto seen_4_5_5_5 = seen_4_5_5;
                    auto n_3_5_5_5 = n_3_5_5;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto g_2_5_5_5_5 = g_2_5_5_5;
                        auto seen_4_5_5_5_5 = seen_4_5_5_5;
                        auto n_3_5_5_5_5 = n_3_5_5_5;
                        entered(once_job([=]() {
                        return ({
                            auto f2 = p0;
                            auto at_ = p1;
                            (prism_rtl::finished(f2 || floaty(g_2_5_5_5_5, at_, crate::prelude::push(seen_4_5_5_5_5, n_3_5_5_5_5))));
                        });
                    }));
                    });
                })));
                })))));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::finished(false);
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t) ? ({
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        prism_rtl::more(prism_rtl::rc(Floaty(g, i, seen)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        fold_job(ts, false, ({
        auto g_1 = g;
        auto seen_2 = seen;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_3 = g_1;
            auto seen_2_3 = seen_2;
            entered(once_job([=]() {
            return ({
                auto f = p0;
                auto a = p1;
                (prism_rtl::finished(f || floaty(g_1_3, a, seen_2_3)));
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        prism_rtl::more(prism_rtl::rc(Floaty(g, e, seen)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        ({
        auto g_1 = g;
        auto k_2 = k;
        auto seen_3 = seen;
        auto v__4 = v_;
        call_then(start_floaty(g_1, k_2, seen_3), [=](bool floaty_20311) { return prism_rtl::finished(floaty_20311 || floaty(g_1, v__4, seen_3)); });
    });
    })
        : prism_rtl::finished(false);
    });
}


/// `Start Floaty, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_floaty(crate::check::env::G g, crate::check::types::Ty t, Array<Text> seen) {
    return prism_rtl::make_rc<Floaty>(g, t, seen);
}


/// Podable: unbounded fn OutTy -> Bool
bool podable(const crate::lower::model::OutTy& t) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(t)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutJob>(t)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(t)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutShowAny>(t)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutLive>(t)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutUnknown>(t)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutGen>(t)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t)) {
        auto&& args = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        return run_to_end(fold_job(args, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto a = p1;
                    (prism_rtl::finished(ok && podable(a)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t).a0;
        return podable(i);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t).a0;
        return podable(i);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRc>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t).a0;
        return podable(i);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t).a0;
        return run_to_end(fold_job(ts, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto a = p1;
                    (prism_rtl::finished(ok && podable(a)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutArray>(t)) {
        auto&& e = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t).a0;
        return podable(e);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(t)) {
        auto&& k = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t).a1;
        return podable(k) && podable(v_);
    }
    {
        return true;
    }
}


prism_rtl::Turn<bool> Podable::cycle() const {
    const auto& t = this->t;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutFn>(t) ? prism_rtl::finished(false)
        : prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t) ? prism_rtl::finished(false)
        : prism_rtl::is<crate::lower::model::OutTy::OutJob>(t) ? prism_rtl::finished(false)
        : prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t) ? prism_rtl::finished(false)
        : prism_rtl::is<crate::lower::model::OutTy::OutDyn>(t) ? prism_rtl::finished(false)
        : prism_rtl::is<crate::lower::model::OutTy::OutShowAny>(t) ? prism_rtl::finished(false)
        : prism_rtl::is<crate::lower::model::OutTy::OutLive>(t) ? prism_rtl::finished(false)
        : prism_rtl::is<crate::lower::model::OutTy::OutUnknown>(t) ? prism_rtl::finished(false)
        : prism_rtl::is<crate::lower::model::OutTy::OutGen>(t) ? prism_rtl::finished(true)
        : prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t) ? ({
        auto&& args = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        fold_job(args, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto a = p1;
                (prism_rtl::finished(ok && podable(a)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t).a0;
        prism_rtl::more(prism_rtl::rc(Podable(i)));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRes>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t).a0;
        prism_rtl::more(prism_rtl::rc(Podable(i)));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRc>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t).a0;
        prism_rtl::more(prism_rtl::rc(Podable(i)));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t) ? ({
        auto&& ts = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t).a0;
        fold_job(ts, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto a = p1;
                (prism_rtl::finished(ok && podable(a)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutArray>(t) ? ({
        auto&& e = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t).a0;
        prism_rtl::more(prism_rtl::rc(Podable(e)));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutMap>(t) ? ({
        auto&& k = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t).a1;
        ({
        auto k_1 = k;
        auto v__2 = v_;
        call_then(start_podable(k_1), [=](bool podable_20986) { return prism_rtl::finished(podable_20986 && podable(v__2)); });
    });
    })
        : prism_rtl::finished(true);
    });
}


/// `Start Podable, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_podable(crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<Podable>(t);
}


/// let emptyEnv
Env empty_env() {
    return Env{.names = Map<Text, Bn>{}, .spans = Map<Text, Vl>{}, .uses = Map<Text, Text>{}};
}


/// NameKeyAt: fn Lx, Env, SName, Range -> Text
Text name_key_at(const Lx& lx, const Env& env, const crate::syntax::SName& n, const crate::syntax::Range& span) {
    auto&& _m = crate::prelude::get(lx.use_insts, place_key(lx, span));
    if (prism_rtl::is_some(_m)) {
        auto&& u = prism_rtl::some_of(_m);
        return or_(crate::prelude::get(env.uses, prism_rtl::cat(crate::check::env::sname_key(n), "#", show_text(inst_at(lx, u)))), crate::check::env::sname_key(n));
    }
    if (prism_rtl::is_none(_m)) {
        return crate::check::env::sname_key(n);
    }
    prism_rtl::unreachable("no arm matched");
}


/// WithInstances: fn Env, [Text] -> [Text]
Array<Text> with_instances(const Env& env, const Array<Text>& names) {
    return fold(names, names, [&](const Array<Text>& acc, const Text& n) { return append(acc, filter(keys(env->names), [&](const Text& k) { return crate::syntax::lexer::has_prefix(k, prism_rtl::cat(n, "#inst")); })); });
}


/// BindSpan: fn Env, Text, Vl -> Env
Env bind_span(const Env& env, const Text& nkey, const Vl& v_) {
    Env this_ = env;
    this_.spans = insert(this_.spans, nkey, v_);
    return this_;
}


/// Bind: fn Env, Text, Bn -> Env
Env bind(const Env& env, const Text& name, const Bn& b) {
    Env this_ = env;
    this_.names = insert(this_.names, name, b);
    return this_;
}


/// ValueTy: fn Vl -> OutTy
crate::lower::model::OutTy value_ty(const Vl& vl0) {
    if (prism_rtl::is<Vl::VlPlace>(vl0)) {
        auto&& t = prism_rtl::as<Vl::VlPlace>(vl0).a2;
        return t;
    }
    if (prism_rtl::is<Vl::VlOwned>(vl0)) {
        auto&& t = prism_rtl::as<Vl::VlOwned>(vl0).a1;
        return t;
    }
    prism_rtl::unreachable("no arm matched");
}


/// LocalPlace: fn Ex, Holding, OutTy -> Vl
Vl local_place(const crate::lower::model::Ex& x, const Holding& mode, const crate::lower::model::OutTy& t) {
    return Vl(Vl::VlPlace{x, mode, t});
}


/// PlaceStem: fn Ex -> Text
Text place_stem(const crate::lower::model::Ex& x) {
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(x)) {
        auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(x).a0;
        return n;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x)) {
        auto&& f = prism_rtl::as<crate::lower::model::Ex::XField>(x).a1;
        return f;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTarget>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XTarget>(x).a0;
        return place_stem(y);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XPart>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XPart>(x).a0;
        auto&& k = prism_rtl::as<crate::lower::model::Ex::XPart>(x).a1;
        return prism_rtl::cat(place_stem(y), "_", k);
    }
    {
        return Text::lit("place");
    }
}


/// OnSelf: fn Ex -> Bool
bool on_self(const crate::lower::model::Ex& x) {
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x)) {
        auto&& m24473_0_0 = prism_rtl::as<crate::lower::model::Ex::XField>(x).a0;
        if (prism_rtl::is<crate::lower::model::Ex::XSelf>(m24473_0_0)) {
            return true;
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XField>(x).a0;
        return on_self(y);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XPart>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XPart>(x).a0;
        return on_self(y);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XMethod>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XMethod>(x).a0;
        return on_self(y);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUpgrade>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XUpgrade>(x).a0;
        return on_self(y);
    }
    {
        return false;
    }
}


/// ?ThroughParent: fn Ex -> ?Ex
std::optional<crate::lower::model::Ex> through_parent(const crate::lower::model::Ex& x) {
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x)) {
        auto&& m24877_0_0 = prism_rtl::as<crate::lower::model::Ex::XField>(x).a0;
        auto&& m24877_0_1 = prism_rtl::as<crate::lower::model::Ex::XField>(x).a1;
        if (prism_rtl::is<crate::lower::model::Ex::XSelf>(m24877_0_0)) {
            if (m24877_0_1 == Text::lit("parent")) {
                return std::optional(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("parent")}));
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XField>(x).a0;
        auto&& f = prism_rtl::as<crate::lower::model::Ex::XField>(x).a1;
        auto&& _m = through_parent(y);
        if (prism_rtl::is_some(_m)) {
            auto&& z = prism_rtl::some_of(_m);
            return std::optional(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(z), f}));
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional<crate::lower::model::Ex>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XPart>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XPart>(x).a0;
        auto&& k = prism_rtl::as<crate::lower::model::Ex::XPart>(x).a1;
        auto&& _m = through_parent(y);
        if (prism_rtl::is_some(_m)) {
            auto&& z = prism_rtl::some_of(_m);
            return std::optional(crate::lower::model::Ex(crate::lower::model::Ex::XPart{prism_rtl::rc(z), k}));
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional<crate::lower::model::Ex>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XMethod>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XMethod>(x).a0;
        auto&& m = prism_rtl::as<crate::lower::model::Ex::XMethod>(x).a1;
        auto&& xs = prism_rtl::as<crate::lower::model::Ex::XMethod>(x).a2;
        auto&& _m = through_parent(y);
        if (prism_rtl::is_some(_m)) {
            auto&& z = prism_rtl::some_of(_m);
            return std::optional(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(z), m, xs}));
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional<crate::lower::model::Ex>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUpgrade>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XUpgrade>(x).a0;
        auto&& _m = through_parent(y);
        if (prism_rtl::is_some(_m)) {
            auto&& z = prism_rtl::some_of(_m);
            return std::optional(crate::lower::model::Ex(crate::lower::model::Ex::XUpgrade{prism_rtl::rc(z)}));
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional<crate::lower::model::Ex>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        return std::optional<crate::lower::model::Ex>{};
    }
}


/// Own: fn Vl -> Ex
crate::lower::model::Ex own(const Vl& vl0) {
    if (prism_rtl::is<Vl::VlPlace>(vl0) && prism_rtl::is<Holding::RcRef>(prism_rtl::as<Vl::VlPlace>(vl0).a1)) {
        auto&& x = prism_rtl::as<Vl::VlPlace>(vl0).a0;
        return crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(x)}))}))});
    }
    if (prism_rtl::is<Vl::VlPlace>(vl0) && prism_rtl::is<Holding::RcOwned>(prism_rtl::as<Vl::VlPlace>(vl0).a1)) {
        auto&& x = prism_rtl::as<Vl::VlPlace>(vl0).a0;
        return crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(x)}))});
    }
    if (prism_rtl::is<Vl::VlPlace>(vl0)) {
        auto&& x = prism_rtl::as<Vl::VlPlace>(vl0).a0;
        auto&& mode = prism_rtl::as<Vl::VlPlace>(vl0).a1;
        auto&& t = prism_rtl::as<Vl::VlPlace>(vl0).a2;
        return is_copy(t)
            ? crate::lower::copy(Vl(Vl::VlPlace{x, mode, t}))
            : crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(x)});
    }
    if (prism_rtl::is<Vl::VlOwned>(vl0)) {
        auto&& e = prism_rtl::as<Vl::VlOwned>(vl0).a0;
        return e;
    }
    prism_rtl::unreachable("no arm matched");
}


/// Ref: fn Vl -> Ex
crate::lower::model::Ex ref_(const Vl& vl0) {
    if (prism_rtl::is<Vl::VlPlace>(vl0) && prism_rtl::is<Holding::ByRef>(prism_rtl::as<Vl::VlPlace>(vl0).a1)) {
        auto&& x = prism_rtl::as<Vl::VlPlace>(vl0).a0;
        return x;
    }
    if (prism_rtl::is<Vl::VlPlace>(vl0) && prism_rtl::is<Holding::RcRef>(prism_rtl::as<Vl::VlPlace>(vl0).a1)) {
        auto&& x = prism_rtl::as<Vl::VlPlace>(vl0).a0;
        return crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(x)}))}))});
    }
    if (prism_rtl::is<Vl::VlPlace>(vl0) && prism_rtl::is<Holding::RcOwned>(prism_rtl::as<Vl::VlPlace>(vl0).a1)) {
        auto&& x = prism_rtl::as<Vl::VlPlace>(vl0).a0;
        return crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(x)}))});
    }
    if (prism_rtl::is<Vl::VlPlace>(vl0)) {
        auto&& x = prism_rtl::as<Vl::VlPlace>(vl0).a0;
        return crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(x)});
    }
    if (prism_rtl::is<Vl::VlOwned>(vl0)) {
        auto&& e = prism_rtl::as<Vl::VlOwned>(vl0).a0;
        return crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(e)});
    }
    prism_rtl::unreachable("no arm matched");
}


/// Copy: fn Vl -> Ex
crate::lower::model::Ex copy(const Vl& vl0) {
    if (prism_rtl::is<Vl::VlPlace>(vl0) && prism_rtl::is<Holding::ByRef>(prism_rtl::as<Vl::VlPlace>(vl0).a1)) {
        auto&& x = prism_rtl::as<Vl::VlPlace>(vl0).a0;
        return crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(x)});
    }
    if (prism_rtl::is<Vl::VlPlace>(vl0) && prism_rtl::is<Holding::RcRef>(prism_rtl::as<Vl::VlPlace>(vl0).a1)) {
        auto&& x = prism_rtl::as<Vl::VlPlace>(vl0).a0;
        return crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(x)}))}))});
    }
    if (prism_rtl::is<Vl::VlPlace>(vl0)) {
        auto&& x = prism_rtl::as<Vl::VlPlace>(vl0).a0;
        return x;
    }
    if (prism_rtl::is<Vl::VlOwned>(vl0)) {
        auto&& e = prism_rtl::as<Vl::VlOwned>(vl0).a0;
        return e;
    }
    prism_rtl::unreachable("no arm matched");
}


/// IsCopy: fn OutTy -> Bool
bool is_copy(const crate::lower::model::OutTy& t) {
    return ((((t == crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})) || (t == crate::lower::model::OutTy(crate::lower::model::OutTy::OutFloat{}))) || (t == crate::lower::model::OutTy(crate::lower::model::OutTy::OutU8{}))) || (t == crate::lower::model::OutTy(crate::lower::model::OutTy::OutChar{}))) || (t == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
}


/// AsBool: fn Vl -> Ex
crate::lower::model::Ex as_bool(const Vl& v_) {
    return crate::lower::copy(v_);
}


/// Escape: fn Text -> Text
Text escape(const Text& t) {
    return crate::syntax::lexer::map_chars(t, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Text)>>(prism_rtl::rc([=](Text p0) {
        return once_job([=]() {
            return ({
                auto c = p0;
                (prism_rtl::finished(char_escape(c)));
            });
        });
    })));
}


/// CharEscape: fn Text -> Text
Text char_escape(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("\\")) {
            return Text::lit("\\\\");
        }
    }
    {
        auto&& c1_0 = text0;
        if (c1_0 == Text::lit("\"")) {
            return Text::lit("\\\"");
        }
    }
    {
        auto&& c2_0 = text0;
        if (c2_0 == Text::lit("\n")) {
            return Text::lit("\\n");
        }
    }
    {
        auto&& c3_0 = text0;
        if (c3_0 == Text::lit("\t")) {
            return Text::lit("\\t");
        }
    }
    {
        auto&& c4_0 = text0;
        if (c4_0 == Text::lit("\r")) {
            return Text::lit("\\r");
        }
    }
    {
        auto&& c5_0 = text0;
        if (c5_0 == Text::lit("\000"sv)) {
            return Text::lit("\\0");
        }
    }
    {
        auto&& c = text0;
        return c;
    }
}


/// Number: fn OutTy, Text, Bool -> Ex
crate::lower::model::Ex number(const crate::lower::model::OutTy& t, const Text& digits, const bool& neg) {
    auto clean = decimal_digits(concat(split(digits, Text::lit("_"))));
    auto signed_ = neg ? prism_rtl::cat("-", clean) : clean;
    if (prism_rtl::is<crate::lower::model::OutTy::OutNat>(t)) {
        return crate::lower::model::Ex(crate::lower::model::Ex::XNat{clean});
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutInt>(t)) {
        return crate::lower::model::Ex(crate::lower::model::Ex::XInt{signed_});
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutU8>(t)) {
        return crate::lower::model::Ex(crate::lower::model::Ex::XByte{clean});
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutFloat>(t)) {
        return crate::lower::model::Ex(crate::lower::model::Ex::XFloat{crate::syntax::lexer::contains(clean, Text::lit("."))
            ? signed_
            : prism_rtl::cat(signed_, ".0")});
    }
    {
        return crate::lower::model::Ex(crate::lower::model::Ex::XInt{signed_});
    }
}


/// DecimalDigits: fn Text -> Text
Text decimal_digits(const Text& d) {
    auto r = crate::syntax::lexer::head(d) == Text::lit("0")
        ? crate::syntax::lexer::head(crate::syntax::lexer::after_first(d))
        : Text::lit("");
    auto base_ = r == Text::lit("x")
        ? Nat(16u)
        : r == Text::lit("o") ? Nat(8u) : r == Text::lit("b") ? Nat(2u) : Nat(10u);
    auto ds = base_ == Nat(10u)
        ? d
        : crate::syntax::lexer::after_first(crate::syntax::lexer::after_first(d));
    return (crate::syntax::lexer::contains(d, Text::lit(".")) || (crate::syntax::lexer::head(d) != Text::lit("0"))) || (d == Text::lit("0"))
        ? d
        : prism_rtl::cat(crate::syntax::lexer::fold_chars(ds, Nat(0u), ({
        auto base__1 = base_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Nat>(std::tuple<Nat, Text>)>>(prism_rtl::rc([=](std::tuple<Nat, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto base__1_2 = base__1;
            once_job([=]() {
            return ({
                auto n = p0;
                auto c = p1;
                (prism_rtl::finished((n * base__1_2) + crate::syntax::lexer::hex_value(c)));
            });
        });
        });
    })));
    })));
}


/// LiteralValue: unbounded fn Lx, Env, Literal, Range, Bool -> Vl
Vl literal_value(const Lx& lx, const Env& env, const crate::syntax::Literal& l, const crate::syntax::Range& span, const bool& neg) {
    auto t = out_ty_of(lx, peel(type_at(lx, span)));
    auto&& _m = l.kind;
    if (prism_rtl::is<crate::syntax::LitKind::LInt>(_m)) {
        auto&& d = prism_rtl::as<crate::syntax::LitKind::LInt>(_m).a0;
        return Vl(Vl::VlOwned{number(t, d, neg), t});
    }
    if (prism_rtl::is<crate::syntax::LitKind::LFloat>(_m)) {
        auto&& d = prism_rtl::as<crate::syntax::LitKind::LFloat>(_m).a0;
        return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XFloat{neg ? prism_rtl::cat("-", d) : d}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutFloat{})});
    }
    if (prism_rtl::is<crate::syntax::LitKind::LChar>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::LitKind::LChar>(_m).a0;
        return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XChar{c}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutChar{})});
    }
    if (prism_rtl::is<crate::syntax::LitKind::LDuration>(_m)) {
        auto&& d = prism_rtl::as<crate::syntax::LitKind::LDuration>(_m).a0;
        auto&& u = prism_rtl::as<crate::syntax::LitKind::LDuration>(_m).a1;
        return Vl(Vl::VlOwned{refusal(Text::lit("a Duration literal")), crate::lower::model::OutTy(crate::lower::model::OutTy::OutDuration{})});
    }
    if (prism_rtl::is<crate::syntax::LitKind::LText>(_m)) {
        auto&& segs = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
        return text_value(lx, env, segs);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Vl> LiteralValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& l = this->l;
    const auto& span = this->span;
    const auto& neg = this->neg;
    auto env_1 = env;
    auto l_2 = l;
    auto lx_3 = lx;
    auto neg_4 = neg;
    auto span_5 = span;
    return call_then(start_out_ty_of(lx_3, peel(type_at(lx_3, span_5))), [=](crate::lower::model::OutTy out_ty_of_28270) {
        return ({
            auto t = out_ty_of_28270;
            ({
            auto&& _m = l_2.kind;
            prism_rtl::is<crate::syntax::LitKind::LInt>(_m) ? ({
            auto&& d = prism_rtl::as<crate::syntax::LitKind::LInt>(_m).a0;
            prism_rtl::finished(Vl(Vl::VlOwned{number(t, d, neg_4), t}));
        })
            : prism_rtl::is<crate::syntax::LitKind::LFloat>(_m) ? ({
            auto&& d = prism_rtl::as<crate::syntax::LitKind::LFloat>(_m).a0;
            prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XFloat{neg_4 ? prism_rtl::cat("-", d) : d}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutFloat{})}));
        })
            : prism_rtl::is<crate::syntax::LitKind::LChar>(_m) ? ({
            auto&& c = prism_rtl::as<crate::syntax::LitKind::LChar>(_m).a0;
            prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XChar{c}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutChar{})}));
        })
            : prism_rtl::is<crate::syntax::LitKind::LDuration>(_m) ? ({
            auto&& d = prism_rtl::as<crate::syntax::LitKind::LDuration>(_m).a0;
            auto&& u = prism_rtl::as<crate::syntax::LitKind::LDuration>(_m).a1;
            prism_rtl::finished(Vl(Vl::VlOwned{refusal(Text::lit("a Duration literal")), crate::lower::model::OutTy(crate::lower::model::OutTy::OutDuration{})}));
        })
            : prism_rtl::is<crate::syntax::LitKind::LText>(_m) ? ({
            auto&& segs = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
            prism_rtl::more(prism_rtl::rc(TextValue(lx_3, env_1, segs)));
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
}


/// `Start LiteralValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_literal_value(Lx lx, Env env, crate::syntax::Literal l, crate::syntax::Range span, bool neg) {
    return prism_rtl::make_rc<LiteralValue>(lx, env, l, span, neg);
}


/// TextValue: unbounded fn Lx, Env, [TextSeg] -> Vl
Vl text_value(const Lx& lx, const Env& env, const Array<crate::syntax::TextSeg>& segs) {
    auto plain = fold(segs, true, [&](const bool& ok, const crate::syntax::TextSeg& s) { return ok && is_plain_seg(s); });
    return plain
        ? Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XText{concat(each(segs, [&](const crate::syntax::TextSeg& s) { return plain_text(s); }))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})})
        : Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XFormat{run_to_end(each_job(segs, ({
        auto lx_1 = lx;
        auto env_2 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::TextSeg)>>(prism_rtl::rc([=](crate::syntax::TextSeg p0) {
        return ({
            auto lx_1_3 = lx_1;
            auto env_2_3 = env_2;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                (prism_rtl::more(prism_rtl::rc(SegEx(lx_1_3, env_2_3, s))));
            });
        }));
        });
    })));
    })))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})});
}


prism_rtl::Turn<Vl> TextValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& segs = this->segs;
    auto plain = fold(segs, true, [&](const bool& ok, const crate::syntax::TextSeg& s) { return ok && is_plain_seg(s); });
    return plain
        ? prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XText{concat(each(segs, [&](const crate::syntax::TextSeg& s) { return plain_text(s); }))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})}))
        : ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto segs_3 = segs;
        call_value(each_job(segs_3, ({
        auto lx_2_4 = lx_2;
        auto env_1_4 = env_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::TextSeg)>>(prism_rtl::rc([=](crate::syntax::TextSeg p0) {
        return ({
            auto lx_2_4_4 = lx_2_4;
            auto env_1_4_4 = env_1_4;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                (prism_rtl::more(prism_rtl::rc(SegEx(lx_2_4_4, env_1_4_4, s))));
            });
        }));
        });
    })));
    })), [=](Array<crate::lower::model::Ex> each_28986) { return prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XFormat{each_28986}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})})); });
    });
}


/// `Start TextValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_text_value(Lx lx, Env env, Array<crate::syntax::TextSeg> segs) {
    return prism_rtl::make_rc<TextValue>(lx, env, segs);
}


/// IsPlainSeg: fn TextSeg -> Bool
bool is_plain_seg(const crate::syntax::TextSeg& text_seg0) {
    if (prism_rtl::is<crate::syntax::TextSeg::SegPlain>(text_seg0)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(text_seg0)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// PlainText: fn TextSeg -> Text
Text plain_text(const crate::syntax::TextSeg& text_seg0) {
    if (prism_rtl::is<crate::syntax::TextSeg::SegPlain>(text_seg0)) {
        auto&& t = prism_rtl::as<crate::syntax::TextSeg::SegPlain>(text_seg0).a0;
        return t;
    }
    if (prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(text_seg0)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SegEx: unbounded fn Lx, Env, TextSeg -> Ex
crate::lower::model::Ex seg_ex(const Lx& lx, const Env& env, const crate::syntax::TextSeg& text_seg2) {
    if (prism_rtl::is<crate::syntax::TextSeg::SegPlain>(text_seg2)) {
        auto&& t = prism_rtl::as<crate::syntax::TextSeg::SegPlain>(text_seg2).a0;
        return crate::lower::model::Ex(crate::lower::model::Ex::XText{t});
    }
    if (prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(text_seg2)) {
        auto&& e = prism_rtl::as<crate::syntax::TextSeg::SegPlaceholder>(text_seg2).a0;
        auto v_ = value_of(lx, env, e);
        return shown_part(v_);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::model::Ex> SegEx::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& text_seg2 = this->text_seg2;
    return ({
        prism_rtl::is<crate::syntax::TextSeg::SegPlain>(text_seg2) ? ({
        auto&& t = prism_rtl::as<crate::syntax::TextSeg::SegPlain>(text_seg2).a0;
        prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XText{t}));
    })
        : prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(text_seg2) ? ({
        auto&& e = prism_rtl::as<crate::syntax::TextSeg::SegPlaceholder>(text_seg2).a0;
        ({
        auto e_1 = e;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(start_value_of(lx_3, env_2, e_1), [=](Vl value_of_29385) {
        return ({
            auto v_ = value_of_29385;
            (prism_rtl::finished(shown_part(v_)));
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SegEx, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_seg_ex(Lx lx, Env env, crate::syntax::TextSeg text_seg2) {
    return prism_rtl::make_rc<SegEx>(lx, env, text_seg2);
}


/// ShownPart: fn Vl -> Ex
crate::lower::model::Ex shown_part(const Vl& v_) {
    auto&& _m = value_ty(v_);
    if (prism_rtl::is<crate::lower::model::OutTy::OutText>(_m)) {
        return ref_(v_);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNat>(_m)) {
        return ref_(v_);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutInt>(_m)) {
        return ref_(v_);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutU8>(_m)) {
        return ref_(v_);
    }
    {
        return crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("show"), Array(std::vector{ref_(v_)})});
    }
}


/// Refusal: fn Text -> Ex
crate::lower::model::Ex refusal(const Text& what) {
    return crate::lower::model::Ex(crate::lower::model::Ex::XRefusal{what});
}


/// TryOf: fn Ex -> Ex
crate::lower::model::Ex try_of(const crate::lower::model::Ex& x) {
    return is_named_place(x)
        ? refusal(prism_rtl::cat("`?` of the place `", place_stem(x), "`, which C++'s TRY would move out of (only a temporary may be tried)"))
        : crate::lower::model::Ex(crate::lower::model::Ex::XTry{prism_rtl::rc(x)});
}


/// IsNamedPlace: fn Ex -> Bool
bool is_named_place(const crate::lower::model::Ex& x) {
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(x)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XPart>(x)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTarget>(x)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRef>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XRef>(x).a0;
        return is_named_place(y);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XDeref>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XDeref>(x).a0;
        return is_named_place(y);
    }
    {
        return false;
    }
}


/// let loweringRefusal
Text lowering_refusal() {
    return Text::lit("prismc does not lower ");
}


/// RefusalDo: fn Text -> Do
crate::lower::model::Do refusal_do(const Text& what) {
    return crate::lower::model::Do(crate::lower::model::Do::DoExpr{refusal(what)});
}


/// ValueOf: unbounded fn Lx, Env, Expr -> Vl
Vl value_of(const Lx& lx, const Env& env, const crate::syntax::Expr& e) {
    auto&& _m = crate::prelude::get(env.spans, place_key(lx, e.span));
    if (prism_rtl::is_some(_m)) {
        auto&& v_ = prism_rtl::some_of(_m);
        return v_;
    }
    if (prism_rtl::is_none(_m)) {
        return unbound_value_of(lx, env, e);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Vl> ValueOf::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    return ({
        auto&& _m = crate::prelude::get(env.spans, place_key(lx, e.span));
        prism_rtl::is_some(_m) ? ({
        auto&& v_ = prism_rtl::some_of(_m);
        prism_rtl::finished(v_);
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(UnboundValueOf(lx, env, e)))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ValueOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_value_of(Lx lx, Env env, crate::syntax::Expr e) {
    return prism_rtl::make_rc<ValueOf>(lx, env, e);
}


/// UnboundValueOf: unbounded fn Lx, Env, Expr -> Vl
Vl unbound_value_of(const Lx& lx, const Env& env, const crate::syntax::Expr& e) {
    return is_event_value(lx, env, e)
        ? event_value_of(lx, env, e)
        : value_by_kind(lx, env, e);
}


prism_rtl::Turn<Vl> UnboundValueOf::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    auto e_1 = e;
    auto env_2 = env;
    auto lx_3 = lx;
    return call_then(start_is_event_value(lx_3, env_2, e_1), [=](bool is_event_value_31358) {
        return is_event_value_31358
            ? prism_rtl::more(prism_rtl::rc(EventValueOf(lx_3, env_2, e_1)))
            : prism_rtl::more(prism_rtl::rc(ValueByKind(lx_3, env_2, e_1)));
    });
}


/// `Start UnboundValueOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_unbound_value_of(Lx lx, Env env, crate::syntax::Expr e) {
    return prism_rtl::make_rc<UnboundValueOf>(lx, env, e);
}


/// IsEventValue: unbounded fn Lx, Env, Expr -> Bool
bool is_event_value(const Lx& lx, const Env& env, const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        return false;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        return false;
    }
    {
        return ((layer_of(type_at(lx, e.span)) == Layer(Layer::LyEv{})) && (!fold(crate::lower::node_::operands(e), false, [&](const bool& bound, const crate::syntax::Expr& c) { return bound || crate::check::env::has_key(env.spans, place_key(lx, c.span)); }))) && has_event_source(lx, env, e);
    }
}


prism_rtl::Turn<bool> IsEventValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? prism_rtl::finished(false)
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? prism_rtl::finished(false)
        : prism_rtl::finished(((layer_of(type_at(lx, e.span)) == Layer(Layer::LyEv{})) && (!fold(crate::lower::node_::operands(e), false, [&](const bool& bound, const crate::syntax::Expr& c) { return bound || crate::check::env::has_key(env.spans, place_key(lx, c.span)); }))) && has_event_source(lx, env, e));
    });
}


/// `Start IsEventValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_event_value(Lx lx, Env env, crate::syntax::Expr e) {
    return prism_rtl::make_rc<IsEventValue>(lx, env, e);
}


/// HasEventSource: unbounded fn Lx, Env, Expr -> Bool
bool has_event_source(const Lx& lx, const Env& env, const crate::syntax::Expr& e) {
    return run_to_end(fold_job(crate::lower::node_::operands(e), false, ({
        auto lx_1 = lx;
        auto env_2 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_3 = lx_1;
            auto env_2_3 = env_2;
            entered(once_job([=]() {
            return ({
                auto found = p0;
                auto c = p1;
                (prism_rtl::finished(found || is_event_source(lx_1_3, env_2_3, c)));
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<bool> HasEventSource::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    return fold_job(crate::lower::node_::operands(e), false, ({
        auto lx_1 = lx;
        auto env_2 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_3 = lx_1;
            auto env_2_3 = env_2;
            entered(once_job([=]() {
            return ({
                auto found = p0;
                auto c = p1;
                (prism_rtl::finished(found || is_event_source(lx_1_3, env_2_3, c)));
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start HasEventSource, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_has_event_source(Lx lx, Env env, crate::syntax::Expr e) {
    return prism_rtl::make_rc<HasEventSource>(lx, env, e);
}


/// IsEventSource: unbounded fn Lx, Env, Expr -> Bool
bool is_event_source(const Lx& lx, const Env& env, const crate::syntax::Expr& c) {
    return layer_of(type_at(lx, c.span)) != Layer(Layer::LyEv{})
        ? false
        : ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = c.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = crate::prelude::get(env->names, crate::check::env::sname_key(n));
                if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m)) && prism_rtl::is<crate::lower::model::OutTy::OutEvent>(prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2)) {
                    _v.set(true);
                    goto _done;
                }
                if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnEv>(prism_rtl::some_of(_m))) {
                    _v.set(crate::check::env::has_key(env->names, prism_rtl::cat(crate::check::env::sname_key(n), "#port")));
                    goto _done;
                }
                {
                    _v.set(false);
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
            _v.set(is_event_source(lx, env, x));
            goto _done;
        }
        {
            _v.set(has_event_source(lx, env, c));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<bool> IsEventSource::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& c = this->c;
    return layer_of(type_at(lx, c.span)) != Layer(Layer::LyEv{})
        ? prism_rtl::finished(false)
        : ({
        auto&& _m = c.kind;
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        ({
        auto&& _m = crate::prelude::get(env->names, crate::check::env::sname_key(n));
        prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m)) && prism_rtl::is<crate::lower::model::OutTy::OutEvent>(prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2) ? prism_rtl::finished(true)
        : prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnEv>(prism_rtl::some_of(_m)) ? prism_rtl::finished(crate::check::env::has_key(env->names, prism_rtl::cat(crate::check::env::sname_key(n), "#port")))
        : prism_rtl::finished(false);
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(IsEventSource(lx, env, x)));
    })
        : prism_rtl::more(prism_rtl::rc(HasEventSource(lx, env, c)));
    });
}


/// `Start IsEventSource, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_event_source(Lx lx, Env env, crate::syntax::Expr c) {
    return prism_rtl::make_rc<IsEventSource>(lx, env, c);
}


/// EventValueOf: unbounded fn Lx, Env, Expr -> Vl
Vl event_value_of(const Lx& lx, const Env& env, const crate::syntax::Expr& e) {
    auto t = out_ty_of(lx, peel(type_at(lx, e.span)));
    auto et = crate::lower::model::OutTy(crate::lower::model::OutTy::OutEvent{prism_rtl::rc(t)});
    auto filtered_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<crate::syntax::Arg>> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
            auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
            auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
            _v.set(crate::lower::node_::callee_key(lx, c) == Text::lit("Prelude.!Filter")
                ? index(args, Nat(0u))
                : std::optional<crate::syntax::Arg>{});
            goto _done;
        }
        {
            _v.set(std::optional<crate::syntax::Arg>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    if (prism_rtl::is_some(filtered_opt)) {
        auto&& a = prism_rtl::some_of(filtered_opt);
        return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(own(value_of(lx, env, a->value))), Text::lit("filter_some"), Array<crate::lower::model::Ex>{}}), et});
    }
    if (prism_rtl::is_none(filtered_opt)) {
        auto evs = filter(crate::lower::node_::operands(e), [&](const crate::syntax::Expr& x) { return layer_of(type_at(lx, x.span)) == Layer(Layer::LyEv{}); });
        {
            auto&& m33425_0 = evs;
            if (m33425_0.size() == 1u) {
                {
                    auto&& _c1 = index(m33425_0, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& one = prism_rtl::some_of(_c1);
                        auto src = own(value_of(lx, env, one));
                        auto it = out_ty_of(lx, peel(type_at(lx, one.span)));
                        auto caps = filter(with_instances(env, read_names(crate::check::typed::exprs_in(e))), [&](const Text& n) {
                            return ({
                                __label__ _done;
                                prism_rtl::Slot<bool> _v;
                                auto&& _m = crate::prelude::get(env->names, n);
                                if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                                    _v.set(true);
                                    goto _done;
                                }
                                {
                                    _v.set(false);
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            });
                        });
                        auto [dos, env1] = fold(caps, std::tuple{Array<crate::lower::model::Do>{}, env}, [&](const std::tuple<Array<crate::lower::model::Do>, Env>& _p0, const Text& n) {
                            auto&& acc = std::get<0>(_p0);
                            auto&& en = std::get<1>(_p0);
                            return ({
                                __label__ _done;
                                prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, Env>> _v;
                                auto&& _m = crate::prelude::get(env->names, n);
                                if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                                    auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                                    auto&& mode = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                                    auto&& ct = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                                    _v.set(({
                                        auto local = prism_rtl::cat(place_stem(rs), "_c");
                                        std::tuple{crate::prelude::push(acc, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{local}), own(local_place(rs, mode, ct))})), bind(en, n, Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{local}), Holding(Holding::Owned{}), ct}))};
                                    }));
                                    goto _done;
                                }
                                {
                                    _v.set(std::tuple{acc, en});
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            });
                        });
                        auto env2 = bind_span(env1, place_key(lx, one.span), Vl(Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("y_ev")}), Holding(Holding::ByRef{}), it}));
                        auto body = own(value_by_kind(lx, env2, e));
                        auto mapped = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(src), Text::lit("map"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("y_ev")})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(it)})})}), prism_rtl::rc(body)})})});
                        return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{crate::prelude::push(dos, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("src_ev")}), src})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("src_ev")})), Text::lit("map"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("y_ev")})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(it)})})}), prism_rtl::rc(body)})})}))}), et});
                    }
                }
            }
        }
        {
            return Vl(Vl::VlOwned{refusal(Text::lit("an event value of several events")), et});
        }
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Vl> EventValueOf::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    auto e_1 = e;
    auto env_2 = env;
    auto lx_3 = lx;
    return call_then(start_out_ty_of(lx_3, peel(type_at(lx_3, e_1.span))), [=](crate::lower::model::OutTy out_ty_of_32984) {
        return ({
            auto t = out_ty_of_32984;
            auto et = crate::lower::model::OutTy(crate::lower::model::OutTy::OutEvent{prism_rtl::rc(t)});
            auto filtered_opt = ({
                __label__ _done;
                prism_rtl::Slot<std::optional<crate::syntax::Arg>> _v;
                auto&& _m = e_1.kind;
                if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
                    auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
                    auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
                    _v.set(crate::lower::node_::callee_key(lx_3, c) == Text::lit("Prelude.!Filter")
                        ? index(args, Nat(0u))
                        : std::optional<crate::syntax::Arg>{});
                    goto _done;
                }
                {
                    _v.set(std::optional<crate::syntax::Arg>{});
                    goto _done;
                }
            _done:
                _v.take();
            });
            ({
            prism_rtl::is_some(filtered_opt) ? ({
            auto&& a = prism_rtl::some_of(filtered_opt);
            ({
            auto a_4 = a;
            call_then(start_value_of(lx_3, env_2, a_4->value), [=](Vl value_of_33261) { return prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(own(value_of_33261)), Text::lit("filter_some"), Array<crate::lower::model::Ex>{}}), et})); });
        });
        })
            : prism_rtl::is_none(filtered_opt) ? ({
            auto evs = filter(crate::lower::node_::operands(e_1), [&](const crate::syntax::Expr& x) { return layer_of(type_at(lx_3, x.span)) == Layer(Layer::LyEv{}); });
            ({
            ({
            auto&& m33425_0 = evs;
            (m33425_0.size() == 1u) && ({
            auto&& _c1 = index(m33425_0, Nat(0u));
            prism_rtl::is_some(_c1);
        });
        }) ? ({
            auto&& m33425_0 = evs;
            auto&& _c1 = index(m33425_0, Nat(0u));
            auto&& one = prism_rtl::some_of(_c1);
            call_then(start_value_of(lx_3, env_2, one), [=](Vl value_of_33496) {
            return ({
                auto src = own(value_of_33496);
                call_then(start_out_ty_of(lx_3, peel(type_at(lx_3, one.span))), [=](crate::lower::model::OutTy out_ty_of_33547) {
                return ({
                    auto it = out_ty_of_33547;
                    call_then(crate::check::typed::start_exprs_in(e_1), [=](Array<crate::syntax::Expr> exprs_in_33658) {
                    return call_then(start_read_names(exprs_in_33658), [=](Array<Text> read_names_33647) {
                        return ({
                            auto caps = filter(with_instances(env_2, read_names_33647), [&](const Text& n) {
                                return ({
                                    __label__ _done;
                                    prism_rtl::Slot<bool> _v;
                                    auto&& _m = crate::prelude::get(env_2->names, n);
                                    if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                                        _v.set(true);
                                        goto _done;
                                    }
                                    {
                                        _v.set(false);
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                });
                            });
                            auto [dos, env1] = fold(caps, std::tuple{Array<crate::lower::model::Do>{}, env_2}, [&](const std::tuple<Array<crate::lower::model::Do>, Env>& _p0, const Text& n) {
                                auto&& acc = std::get<0>(_p0);
                                auto&& en = std::get<1>(_p0);
                                return ({
                                    __label__ _done;
                                    prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, Env>> _v;
                                    auto&& _m = crate::prelude::get(env_2->names, n);
                                    if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                                        auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                                        auto&& mode = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                                        auto&& ct = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                                        _v.set(({
                                            auto local = prism_rtl::cat(place_stem(rs), "_c");
                                            std::tuple{crate::prelude::push(acc, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{local}), own(local_place(rs, mode, ct))})), bind(en, n, Bn(Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{local}), Holding(Holding::Owned{}), ct}))};
                                        }));
                                        goto _done;
                                    }
                                    {
                                        _v.set(std::tuple{acc, en});
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                });
                            });
                            auto env2 = bind_span(env1, place_key(lx_3, one.span), Vl(Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("y_ev")}), Holding(Holding::ByRef{}), it}));
                            call_then(start_value_by_kind(lx_3, env2, e_1), [=](Vl value_by_kind_34354) {
                            return ({
                                auto body = own(value_by_kind_34354);
                                auto mapped = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(src), Text::lit("map"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("y_ev")})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(it)})})}), prism_rtl::rc(body)})})});
                                (prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{crate::prelude::push(dos, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("src_ev")}), src})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("src_ev")})), Text::lit("map"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("y_ev")})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(it)})})}), prism_rtl::rc(body)})})}))}), et})));
                            });
                        });
                        });
                    });
                });
                });
            });
            });
        });
        })
            : prism_rtl::finished(Vl(Vl::VlOwned{refusal(Text::lit("an event value of several events")), et}));
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
}


/// `Start EventValueOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_event_value_of(Lx lx, Env env, crate::syntax::Expr e) {
    return prism_rtl::make_rc<EventValueOf>(lx, env, e);
}


/// ValueByKind: unbounded fn Lx, Env, Expr -> Vl
Vl value_by_kind(const Lx& lx, const Env& env, const crate::syntax::Expr& e) {
    auto t = out_ty_of(lx, peel(type_at(lx, e.span)));
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return name_value(lx, env, n, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELit>(_m)) {
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
        return literal_value(lx, env, l, e.span, false);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUnit>(_m)) {
        return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBound>(_m)) {
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EBound>(_m).a0;
        auto&& _m = crate::prelude::get(env->names, b);
        if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
            auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
            auto&& mode = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
            auto&& bt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
            return local_place(rs, mode, bt);
        }
        {
            return Vl(Vl::VlOwned{refusal(prism_rtl::cat("`", b, "` outside a `for`")), t});
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ENil>(_m)) {
        return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XNone{})), t}), t});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m)) {
        auto&& es = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
        return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XTuple{run_to_end(each_job(es, ({
            auto lx_1 = lx;
            auto env_2 = env;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Expr)>>(prism_rtl::rc([=](crate::syntax::Expr p0) {
            return ({
                auto lx_1_3 = lx_1;
                auto env_2_3 = env_2;
                entered(once_job([=]() {
                return ({
                    auto x = p0;
                    call_then(start_value_of(lx_1_3, env_2_3, x), [=](Vl value_of_35341) { return prism_rtl::finished(own(value_of_35341)); });
                });
            }));
            });
        })));
        })))}), t});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EArray>(_m)) {
        auto&& m34904_6_0 = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
        if (m34904_6_0.size() == 0u) {
            return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Array::new"), Array<crate::lower::model::Ex>{}})), t}), t});
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EArray>(_m)) {
        auto&& es = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
        return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Array::from"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVec{run_to_end(each_job(es, ({
            auto lx_1 = lx;
            auto env_2 = env;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Expr)>>(prism_rtl::rc([=](crate::syntax::Expr p0) {
            return ({
                auto lx_1_3 = lx_1;
                auto env_2_3 = env_2;
                entered(once_job([=]() {
                return ({
                    auto x = p0;
                    call_then(start_value_of(lx_1_3, env_2_3, x), [=](Vl value_of_35513) { return prism_rtl::finished(own(value_of_35513)); });
                });
            }));
            });
        })));
        })))})})}), t});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMap>(_m)) {
        auto&& m34904_8_0 = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
        if (m34904_8_0.size() == 0u) {
            return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Map::new"), Array<crate::lower::model::Ex>{}})), t}), t});
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMap>(_m)) {
        auto&& kvs = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
        return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("map_of"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVec{run_to_end(each_job(kvs, ({
            auto lx_1 = lx;
            auto env_2 = env;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::syntax::Expr, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<crate::syntax::Expr, crate::syntax::Expr> p0) {
            return ({
                auto lx_1_3 = lx_1;
                auto env_2_3 = env_2;
                entered(once_job([=]() {
                return ({
                    auto [k, v_] = p0;
                    call_then(start_value_of(lx_1_3, env_2_3, k), [=](Vl value_of_35694) { return call_then(start_value_of(lx_1_3, env_2_3, v_), [=](Vl value_of_35720) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XTuple{Array(std::vector{own(value_of_35694), own(value_of_35720)})})); }); });
                });
            }));
            });
        })));
        })))})})}), t});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return value_of(lx, env, x);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        return application(lx, env, c, args, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
        auto&& m = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a1;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
        return application(lx, env, crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{m})), .span = m.span}, append(Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = r, .span = r.span}}), args), e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
        auto&& op = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        return binary_value(lx, env, op, l, r, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m)) {
        auto&& m34904_14_0 = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a0;
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
        if (m34904_14_0 == Text::lit("not")) {
            return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{Text::lit("!"), prism_rtl::rc(as_bool(value_of(lx, env, x)))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})});
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m)) {
        auto&& m34904_15_0 = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a0;
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
        if (m34904_15_0 == Text::lit("neg")) {
            auto&& _m = x.kind;
            if (prism_rtl::is<crate::syntax::ExprKind::ELit>(_m)) {
                auto&& l = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
                return literal_value(lx, env, l, x.span, true);
            }
            {
                auto v_ = value_of(lx, env, x);
                return is_copy(t)
                    ? Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{Text::lit("-"), prism_rtl::rc(crate::lower::copy(v_))}), t})
                    : Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{Text::lit("-"), prism_rtl::rc(ref_(v_))}), t});
            }
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
        return value_of(lx, env, x);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
        auto&& m34904_17_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        if (m34904_17_0 == Text::lit("?")) {
            return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{own(value_of(lx, env, x))})}), t});
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
        auto&& m34904_18_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        if (m34904_18_0 == Text::lit("~")) {
            return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Ok"), Array(std::vector{own(value_of(lx, env, x))})}), t});
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
        auto&& m34904_19_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        if (m34904_19_0 == Text::lit("@")) {
            return pure_blueprint(lx, env, x, t);
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        return value_of(lx, env, x);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        auto&& name = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a2;
        return field_value(lx, env, r, name.name);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& i = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        return index_value(lx, env, r, i, t);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
        auto&& ps_opt = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
        return lambda_value(lx, env, e, or_(ps_opt, Array<crate::syntax::Pattern_>{}), body);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        return if_value(lx, env, c, then_b, else_b_opt, t);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        return match_value(lx, env, s, arms, t, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETemplate>(_m)) {
        auto&& tp = prism_rtl::as<crate::syntax::ExprKind::ETemplate>(_m).a0;
        return template_value(lx, env, tp);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECast>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a0;
        return value_of(lx, env, x);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
        return value_of(lx, env, x);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGiven>(_m)) {
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EGiven>(_m).a0;
        return given_value(lx, env, b, t, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m)) {
        auto&& target = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
        return update_value(lx, env, target, b, t, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EAny>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EAny>(_m).a0;
        return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{own(value_of(lx, env, x))})}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutShowAny{})});
    }
    {
        return Vl(Vl::VlOwned{refusal(prism_rtl::cat(kind_words(e.kind), " as a value")), t});
    }
}


prism_rtl::Turn<Vl> ValueByKind::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    auto e_1 = e;
    auto env_2 = env;
    auto lx_3 = lx;
    return call_then(start_out_ty_of(lx_3, peel(type_at(lx_3, e_1.span))), [=](crate::lower::model::OutTy out_ty_of_34861) {
        return ({
            auto t = out_ty_of_34861;
            ({
            auto&& _m = e_1.kind;
            prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            prism_rtl::more(prism_rtl::rc(NameValue(lx_3, env_2, n, e_1.span)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::ELit>(_m) ? ({
            auto&& l = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
            prism_rtl::more(prism_rtl::rc(LiteralValue(lx_3, env_2, l, e_1.span, false)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EUnit>(_m) ? prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}))
            : prism_rtl::is<crate::syntax::ExprKind::EBound>(_m) ? ({
            auto&& b = prism_rtl::as<crate::syntax::ExprKind::EBound>(_m).a0;
            ({
            auto&& _m = crate::prelude::get(env_2->names, b);
            prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m)) ? ({
            auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
            auto&& mode = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
            auto&& bt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
            prism_rtl::finished(local_place(rs, mode, bt));
        })
            : prism_rtl::finished(Vl(Vl::VlOwned{refusal(prism_rtl::cat("`", b, "` outside a `for`")), t}));
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::ENil>(_m) ? prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XNone{})), t}), t}))
            : prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m) ? ({
            auto&& es = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
            ({
            auto es_4 = es;
            call_value(each_job(es_4, ({
            auto lx_3_5 = lx_3;
            auto env_2_5 = env_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Expr)>>(prism_rtl::rc([=](crate::syntax::Expr p0) {
            return ({
                auto lx_3_5_5 = lx_3_5;
                auto env_2_5_5 = env_2_5;
                entered(once_job([=]() {
                return ({
                    auto x = p0;
                    call_then(start_value_of(lx_3_5_5, env_2_5_5, x), [=](Vl value_of_35341) { return prism_rtl::finished(own(value_of_35341)); });
                });
            }));
            });
        })));
        })), [=](Array<crate::lower::model::Ex> each_35322) { return prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XTuple{each_35322}), t})); });
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EArray>(_m) && ({
            auto&& m34904_6_0 = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
            (m34904_6_0.size() == 0u);
        }) ? ({
            auto&& m34904_6_0 = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
            prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Array::new"), Array<crate::lower::model::Ex>{}})), t}), t}));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EArray>(_m) ? ({
            auto&& es = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
            ({
            auto es_4 = es;
            call_value(each_job(es_4, ({
            auto lx_3_5 = lx_3;
            auto env_2_5 = env_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Expr)>>(prism_rtl::rc([=](crate::syntax::Expr p0) {
            return ({
                auto lx_3_5_5 = lx_3_5;
                auto env_2_5_5 = env_2_5;
                entered(once_job([=]() {
                return ({
                    auto x = p0;
                    call_then(start_value_of(lx_3_5_5, env_2_5_5, x), [=](Vl value_of_35513) { return prism_rtl::finished(own(value_of_35513)); });
                });
            }));
            });
        })));
        })), [=](Array<crate::lower::model::Ex> each_35494) { return prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Array::from"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVec{each_35494})})}), t})); });
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EMap>(_m) && ({
            auto&& m34904_8_0 = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
            (m34904_8_0.size() == 0u);
        }) ? ({
            auto&& m34904_8_0 = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
            prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Map::new"), Array<crate::lower::model::Ex>{}})), t}), t}));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EMap>(_m) ? ({
            auto&& kvs = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
            ({
            auto kvs_4 = kvs;
            call_value(each_job(kvs_4, ({
            auto lx_3_5 = lx_3;
            auto env_2_5 = env_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::syntax::Expr, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<crate::syntax::Expr, crate::syntax::Expr> p0) {
            return ({
                auto lx_3_5_5 = lx_3_5;
                auto env_2_5_5 = env_2_5;
                entered(once_job([=]() {
                return ({
                    auto [k, v_] = p0;
                    call_then(start_value_of(lx_3_5_5, env_2_5_5, k), [=](Vl value_of_35694) { return call_then(start_value_of(lx_3_5_5, env_2_5_5, v_), [=](Vl value_of_35720) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XTuple{Array(std::vector{own(value_of_35694), own(value_of_35720)})})); }); });
                });
            }));
            });
        })));
        })), [=](Array<crate::lower::model::Ex> each_35658) { return prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("map_of"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVec{each_35658})})}), t})); });
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
            prism_rtl::more(prism_rtl::rc(ValueOf(lx_3, env_2, x)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::ECall>(_m) ? ({
            auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
            auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
            prism_rtl::more(prism_rtl::rc(Application(lx_3, env_2, c, args, e_1.span)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m) ? ({
            auto&& r = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
            auto&& m = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a1;
            auto&& args = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
            prism_rtl::more(prism_rtl::rc(Application(lx_3, env_2, crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{m})), .span = m.span}, append(Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = r, .span = r.span}}), args), e_1.span)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m) ? ({
            auto&& op = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
            auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
            auto&& r = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
            prism_rtl::more(prism_rtl::rc(BinaryValue(lx_3, env_2, op, l, r, e_1.span)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m) && ({
            auto&& m34904_14_0 = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a0;
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
            (m34904_14_0 == Text::lit("not"));
        }) ? ({
            auto&& m34904_14_0 = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a0;
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
            ({
            auto x_4 = x;
            call_then(start_value_of(lx_3, env_2, x_4), [=](Vl value_of_36130) { return prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{Text::lit("!"), prism_rtl::rc(as_bool(value_of_36130))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})})); });
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m) && ({
            auto&& m34904_15_0 = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a0;
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
            (m34904_15_0 == Text::lit("neg"));
        }) ? ({
            auto&& m34904_15_0 = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a0;
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
            ({
            auto&& _m = x.kind;
            prism_rtl::is<crate::syntax::ExprKind::ELit>(_m) ? ({
            auto&& l = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
            prism_rtl::more(prism_rtl::rc(LiteralValue(lx_3, env_2, l, x.span, true)));
        })
            : ({
            auto x_4 = x;
            call_then(start_value_of(lx_3, env_2, x_4), [=](Vl value_of_36305) {
            return ({
                auto v_ = value_of_36305;
                is_copy(t)
                ? prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{Text::lit("-"), prism_rtl::rc(crate::lower::copy(v_))}), t}))
                : prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{Text::lit("-"), prism_rtl::rc(ref_(v_))}), t}));
            });
        });
        });
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m) ? ({
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
            prism_rtl::more(prism_rtl::rc(ValueOf(lx_3, env_2, x)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m) && ({
            auto&& m34904_17_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
            (m34904_17_0 == Text::lit("?"));
        }) ? ({
            auto&& m34904_17_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
            ({
            auto x_4 = x;
            call_then(start_value_of(lx_3, env_2, x_4), [=](Vl value_of_36528) { return prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{own(value_of_36528)})}), t})); });
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m) && ({
            auto&& m34904_18_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
            (m34904_18_0 == Text::lit("~"));
        }) ? ({
            auto&& m34904_18_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
            ({
            auto x_4 = x;
            call_then(start_value_of(lx_3, env_2, x_4), [=](Vl value_of_36609) { return prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Ok"), Array(std::vector{own(value_of_36609)})}), t})); });
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m) && ({
            auto&& m34904_19_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
            (m34904_19_0 == Text::lit("@"));
        }) ? ({
            auto&& m34904_19_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
            prism_rtl::more(prism_rtl::rc(PureBlueprint(lx_3, env_2, x, t)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m) ? ({
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
            prism_rtl::more(prism_rtl::rc(ValueOf(lx_3, env_2, x)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EField>(_m) ? ({
            auto&& r = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
            auto&& name = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a2;
            prism_rtl::more(prism_rtl::rc(FieldValue(lx_3, env_2, r, name.name)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m) ? ({
            auto&& r = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
            auto&& i = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
            prism_rtl::more(prism_rtl::rc(IndexValue(lx_3, env_2, r, i, t)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) ? ({
            auto&& ps_opt = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
            auto&& body = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
            prism_rtl::more(prism_rtl::rc(LambdaValue(lx_3, env_2, e_1, or_(ps_opt, Array<crate::syntax::Pattern_>{}), body)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
            auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
            auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
            auto&& else_b_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
            prism_rtl::more(prism_rtl::rc(IfValue(lx_3, env_2, c, then_b, else_b_opt, t)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
            auto&& s = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
            auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
            prism_rtl::more(prism_rtl::rc(MatchValue(lx_3, env_2, s, arms, t, e_1.span)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::ETemplate>(_m) ? ({
            auto&& tp = prism_rtl::as<crate::syntax::ExprKind::ETemplate>(_m).a0;
            prism_rtl::more(prism_rtl::rc(TemplateValue(lx_3, env_2, tp)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::ECast>(_m) ? ({
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a0;
            prism_rtl::more(prism_rtl::rc(ValueOf(lx_3, env_2, x)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m) ? ({
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
            prism_rtl::more(prism_rtl::rc(ValueOf(lx_3, env_2, x)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EGiven>(_m) ? ({
            auto&& b = prism_rtl::as<crate::syntax::ExprKind::EGiven>(_m).a0;
            prism_rtl::more(prism_rtl::rc(GivenValue(lx_3, env_2, b, t, e_1.span)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m) ? ({
            auto&& target = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
            auto&& b = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
            prism_rtl::more(prism_rtl::rc(UpdateValue(lx_3, env_2, target, b, t, e_1.span)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EAny>(_m) ? ({
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EAny>(_m).a0;
            ({
            auto x_4 = x;
            call_then(start_value_of(lx_3, env_2, x_4), [=](Vl value_of_37372) { return prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{own(value_of_37372)})}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutShowAny{})})); });
        });
        })
            : prism_rtl::finished(Vl(Vl::VlOwned{refusal(prism_rtl::cat(kind_words(e_1.kind), " as a value")), t}));
        });
        });
    });
}


/// `Start ValueByKind, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_value_by_kind(Lx lx, Env env, crate::syntax::Expr e) {
    return prism_rtl::make_rc<ValueByKind>(lx, env, e);
}


/// PureBlueprint: unbounded fn Lx, Env, Expr, OutTy -> Vl
Vl pure_blueprint(const Lx& lx, const Env& env, const crate::syntax::Expr& x, const crate::lower::model::OutTy& t) {
    auto is_never = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = x.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            _v.set(({
                auto&& _qk_opt = crate::check::env::resolve_value(lx.g, lx.home, n);
                auto&& qk_opt = std::get<0>(_qk_opt);
                qk_opt == std::optional(Text::lit("Prelude.never"));
            }));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    return is_never
        ? Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::never_blueprint::<crate::Elem, crate::Answer>"), Array<crate::lower::model::Ex>{}}), t})
        : ({
        __label__ _done;
        prism_rtl::Slot<Vl> _v;
        auto&& _m = crate::prelude::get(env->names, Text::lit("#tag"));
        if (prism_rtl::is_none(_m)) {
            _v.set(Vl(Vl::VlOwned{refusal(prism_rtl::cat("`@ ", src_text(lx, lx->file, x.span), "` as a supplier's answer outside a tag arm: which tag's output it answers cannot be known")), t}));
            goto _done;
        }
        if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m)) && prism_rtl::is<crate::lower::model::Ex::XPath>(prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0)) {
            auto&& variant = prism_rtl::as<crate::lower::model::Ex::XPath>(prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Vl> _v;
                auto&& _m = layer_of(type_at(lx, x.span));
                if (prism_rtl::is<Layer::LyEv>(_m)) {
                    _v.set(({
                        auto wrapped = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(own(value_of(lx, env, x))), Text::lit("map"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("v")})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}))})})}))})})});
                        (Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::event_blueprint::<crate::Elem, _>"), Array(std::vector{wrapped})}), t}));
                    }));
                    goto _done;
                }
                if (prism_rtl::is<Layer::LyDyn>(_m)) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Vl> _v;
                        auto&& _m = crate::lower::node_::dynamic_answer(lx, x);
                        if (prism_rtl::is_none(_m)) {
                            _v.set(({
                                __label__ _done;
                                prism_rtl::Slot<Vl> _v;
                                auto&& _m = x.kind;
                                if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
                                    auto&& m39074_0_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
                                    auto&& inner = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
                                    if (m39074_0_0 == Text::lit("$")) {
                                        _v.set(plain_blueprint(lx, env, inner, variant, t));
                                        goto _done;
                                    }
                                }
                                {
                                    _v.set(Vl(Vl::VlOwned{refusal(prism_rtl::cat("`@ ", src_text(lx, lx->file, x.span), "`, a supplier's dynamic answer of no known form")), t}));
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_some(_m)) {
                            auto&& d = prism_rtl::some_of(_m);
                            _v.set(dynamic_blueprint(lx, env, x, d, variant, t));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                {
                    _v.set(plain_blueprint(lx, env, x, variant, t));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(Vl(Vl::VlOwned{refusal(Text::lit("a supplier's answer under a tag the arm does not name")), t}));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Vl> PureBlueprint::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& x = this->x;
    const auto& t = this->t;
    auto is_never = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = x.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            _v.set(({
                auto&& _qk_opt = crate::check::env::resolve_value(lx.g, lx.home, n);
                auto&& qk_opt = std::get<0>(_qk_opt);
                qk_opt == std::optional(Text::lit("Prelude.never"));
            }));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    return is_never
        ? prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::never_blueprint::<crate::Elem, crate::Answer>"), Array<crate::lower::model::Ex>{}}), t}))
        : ({
        auto&& _m = crate::prelude::get(env->names, Text::lit("#tag"));
        prism_rtl::is_none(_m) ? prism_rtl::finished(Vl(Vl::VlOwned{refusal(prism_rtl::cat("`@ ", src_text(lx, lx->file, x.span), "` as a supplier's answer outside a tag arm: which tag's output it answers cannot be known")), t}))
        : prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m)) && prism_rtl::is<crate::lower::model::Ex::XPath>(prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0) ? ({
        auto&& variant = prism_rtl::as<crate::lower::model::Ex::XPath>(prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0).a0;
        ({
        auto&& _m = layer_of(type_at(lx, x.span));
        prism_rtl::is<Layer::LyEv>(_m) ? ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto t_3 = t;
        auto x_4 = x;
        call_then(start_value_of(lx_2, env_1, x_4), [=](Vl value_of_38803) {
        return ({
            auto wrapped = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(own(value_of_38803)), Text::lit("map"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("v")})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}))})})}))})})});
            (prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::event_blueprint::<crate::Elem, _>"), Array(std::vector{wrapped})}), t_3})));
        });
    });
    })
        : prism_rtl::is<Layer::LyDyn>(_m) ? ({
        auto&& _m = crate::lower::node_::dynamic_answer(lx, x);
        prism_rtl::is_none(_m) ? ({
        auto&& _m = x.kind;
        prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m) && ({
        auto&& m39074_0_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        auto&& inner = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        (m39074_0_0 == Text::lit("$"));
    }) ? ({
        auto&& m39074_0_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        auto&& inner = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        prism_rtl::more(prism_rtl::rc(PlainBlueprint(lx, env, inner, variant, t)));
    })
        : prism_rtl::finished(Vl(Vl::VlOwned{refusal(prism_rtl::cat("`@ ", src_text(lx, lx->file, x.span), "`, a supplier's dynamic answer of no known form")), t}));
    })
        : prism_rtl::is_some(_m) ? ({
        auto&& d = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(DynamicBlueprint(lx, env, x, d, variant, t)));
    })
        : throw prism_rtl::Panic("no arm matched");
    })
        : prism_rtl::more(prism_rtl::rc(PlainBlueprint(lx, env, x, variant, t)));
    });
    })
        : prism_rtl::finished(Vl(Vl::VlOwned{refusal(Text::lit("a supplier's answer under a tag the arm does not name")), t}));
    });
}


/// `Start PureBlueprint, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_pure_blueprint(Lx lx, Env env, crate::syntax::Expr x, crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<PureBlueprint>(lx, env, x, t);
}


/// PlainBlueprint: unbounded fn Lx, Env, Expr, Text, OutTy -> Vl
Vl plain_blueprint(const Lx& lx, const Env& env, const crate::syntax::Expr& x, const Text& variant, const crate::lower::model::OutTy& t) {
    return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::plain_blueprint::<crate::Elem, _>"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant, Array(std::vector{own(value_of(lx, env, x))})})})}), t});
}


prism_rtl::Turn<Vl> PlainBlueprint::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& x = this->x;
    const auto& variant = this->variant;
    const auto& t = this->t;
    auto env_1 = env;
    auto lx_2 = lx;
    auto t_3 = t;
    auto variant_4 = variant;
    auto x_5 = x;
    return call_then(start_value_of(lx_2, env_1, x_5), [=](Vl value_of_39722) { return prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::plain_blueprint::<crate::Elem, _>"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant_4, Array(std::vector{own(value_of_39722)})})})}), t_3})); });
}


/// `Start PlainBlueprint, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_plain_blueprint(Lx lx, Env env, crate::syntax::Expr x, Text variant, crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<PlainBlueprint>(lx, env, x, variant, t);
}


/// DynamicBlueprint: unbounded fn Lx, Env, Expr, Expr, Text, OutTy -> Vl
Vl dynamic_blueprint(const Lx& lx, const Env& env, const crate::syntax::Expr& x, const crate::syntax::Expr& d, const Text& variant, const crate::lower::model::OutTy& t) {
    auto&& _m = std::tuple{crate::prelude::get(env->names, prism_rtl::cat("#dyn", crate::lower::node_::dyn_key(x))), crate::prelude::get(env->names, Text::lit("#owner"))};
    if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(std::get<0>(_m))) && prism_rtl::is<crate::lower::model::Ex::XVar>(prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(std::get<0>(_m))).a0) && prism_rtl::is_some(std::get<1>(_m)) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(std::get<1>(_m))) && prism_rtl::is<crate::lower::model::Ex::XVar>(prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(std::get<1>(_m))).a0)) {
        auto&& getter = prism_rtl::as<crate::lower::model::Ex::XVar>(prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(std::get<0>(_m))).a0).a0;
        auto&& dt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(std::get<0>(_m))).a2;
        auto&& owner = prism_rtl::as<crate::lower::model::Ex::XVar>(prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(std::get<1>(_m))).a0).a0;
        auto at_build = own(value_of(lx, crate::lower::node_::init_env(env), d));
        auto arms = Array(std::vector{crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("owner")})})}), .conds = Array<crate::lower::model::Cc>{}, .body = crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("owner")})), getter, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})})}, crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{Text::lit("None")}), .conds = Array<crate::lower::model::Cc>{}, .body = crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("at_build")}))})})})}});
        auto read = crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("cx")})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Cx"), Array<crate::lower::model::OutTy>{}}))})})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMatch{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("link")})), Text::lit("owner"), Array<crate::lower::model::Ex>{}})), arms, false, crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("crate::Answer"), Array<crate::lower::model::OutTy>{}})}))});
        auto dynamic = crate::lower::model::Ex(crate::lower::model::Ex::XBlock{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("link")}), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{owner}))})}), crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("at_build")}), at_build})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::Dynamic::of"), Array(std::vector{read, crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat(getter, "_port")}))})})}))});
        return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::dynamic_blueprint::<crate::Elem, _>"), Array(std::vector{dynamic})}), t});
    }
    {
        return Vl(Vl::VlOwned{refusal(prism_rtl::cat("`@ ", src_text(lx, lx->file, x.span), "`, a supplier's dynamic answer that reads what has no value at the owner's build (a pushed place, a structural dynamic, or a `let` after the host's line)")), t});
    }
}


prism_rtl::Turn<Vl> DynamicBlueprint::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& x = this->x;
    const auto& d = this->d;
    const auto& variant = this->variant;
    const auto& t = this->t;
    return ({
        auto&& _m = std::tuple{crate::prelude::get(env->names, prism_rtl::cat("#dyn", crate::lower::node_::dyn_key(x))), crate::prelude::get(env->names, Text::lit("#owner"))};
        prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(std::get<0>(_m))) && prism_rtl::is<crate::lower::model::Ex::XVar>(prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(std::get<0>(_m))).a0) && prism_rtl::is_some(std::get<1>(_m)) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(std::get<1>(_m))) && prism_rtl::is<crate::lower::model::Ex::XVar>(prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(std::get<1>(_m))).a0) ? ({
        auto&& getter = prism_rtl::as<crate::lower::model::Ex::XVar>(prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(std::get<0>(_m))).a0).a0;
        auto&& dt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(std::get<0>(_m))).a2;
        auto&& owner = prism_rtl::as<crate::lower::model::Ex::XVar>(prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(std::get<1>(_m))).a0).a0;
        ({
        auto d_1 = d;
        auto env_2 = env;
        auto lx_3 = lx;
        auto t_4 = t;
        auto variant_5 = variant;
        call_then(start_value_of(lx_3, crate::lower::node_::init_env(env_2), d_1), [=](Vl value_of_40534) {
        return ({
            auto at_build = own(value_of_40534);
            auto arms = Array(std::vector{crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("owner")})})}), .conds = Array<crate::lower::model::Cc>{}, .body = crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant_5, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("owner")})), getter, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})})}, crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{Text::lit("None")}), .conds = Array<crate::lower::model::Cc>{}, .body = crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant_5, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("at_build")}))})})})}});
            auto read = crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("cx")})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Cx"), Array<crate::lower::model::OutTy>{}}))})})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMatch{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("link")})), Text::lit("owner"), Array<crate::lower::model::Ex>{}})), arms, false, crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("crate::Answer"), Array<crate::lower::model::OutTy>{}})}))});
            auto dynamic = crate::lower::model::Ex(crate::lower::model::Ex::XBlock{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("link")}), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{owner}))})}), crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("at_build")}), at_build})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::Dynamic::of"), Array(std::vector{read, crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat(getter, "_port")}))})})}))});
            (prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::dynamic_blueprint::<crate::Elem, _>"), Array(std::vector{dynamic})}), t_4})));
        });
    });
    });
    })
        : prism_rtl::finished(Vl(Vl::VlOwned{refusal(prism_rtl::cat("`@ ", src_text(lx, lx->file, x.span), "`, a supplier's dynamic answer that reads what has no value at the owner's build (a pushed place, a structural dynamic, or a `let` after the host's line)")), t}));
    });
}


/// `Start DynamicBlueprint, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_dynamic_blueprint(Lx lx, Env env, crate::syntax::Expr x, crate::syntax::Expr d, Text variant, crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<DynamicBlueprint>(lx, env, x, d, variant, t);
}


/// ElementBlueprint: unbounded fn Lx, Env, [Arg], OutTy -> Vl
Vl element_blueprint(const Lx& lx, const Env& env, const Array<crate::syntax::Arg>& args, const crate::lower::model::OutTy& t) {
    auto&& _m = index(args, Nat(0u));
    if (prism_rtl::is_some(_m)) {
        auto&& a = prism_rtl::some_of(_m);
        return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::element_blueprint::<crate::Elem, crate::Answer>"), Array(std::vector{ref_(value_of(lx, env, a->value))})}), t});
    }
    if (prism_rtl::is_none(_m)) {
        return Vl(Vl::VlOwned{refusal(Text::lit("`@Element` without its element")), t});
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Vl> ElementBlueprint::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& args = this->args;
    const auto& t = this->t;
    return ({
        auto&& _m = index(args, Nat(0u));
        prism_rtl::is_some(_m) ? ({
        auto&& a = prism_rtl::some_of(_m);
        ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto t_3 = t;
        call_then(start_value_of(lx_2, env_1, a->value), [=](Vl value_of_41817) { return prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::element_blueprint::<crate::Elem, crate::Answer>"), Array(std::vector{ref_(value_of_41817)})}), t_3})); });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(Vl(Vl::VlOwned{refusal(Text::lit("`@Element` without its element")), t}))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ElementBlueprint, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_element_blueprint(Lx lx, Env env, Array<crate::syntax::Arg> args, crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<ElementBlueprint>(lx, env, args, t);
}


/// KindWords: fn ExprKind -> Text
Text kind_words(const crate::syntax::ExprKind& k) {
    if (prism_rtl::is<crate::syntax::ExprKind::ESuffixed>(k)) {
        auto&& op = prism_rtl::as<crate::syntax::ExprKind::ESuffixed>(k).a0;
        return prism_rtl::cat("a suffixed `", op, "`");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(k)) {
        auto&& sg = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(k).a0;
        return prism_rtl::cat("a free `", sg, "`");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETopicField>(k)) {
        return Text::lit("a topic field (`&_.f` outside an `update`)");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETopicIndex>(k)) {
        return Text::lit("a topic index");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ENonEmpty>(k)) {
        return Text::lit("a non-empty literal");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EAbsent>(k)) {
        return Text::lit("an absent value");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ERest>(k)) {
        return Text::lit("a `..` rest");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(k)) {
        return Text::lit("a lambda");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ERebuild>(k)) {
        return Text::lit("a `rebuild` outside a widget block");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFor>(k)) {
        return Text::lit("a `for` outside a widget block");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(k)) {
        return Text::lit("a widget block");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMonad>(k)) {
        return Text::lit("a monadic block");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELens>(k)) {
        return Text::lit("a lens");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EError>(k)) {
        return Text::lit("an expression the parser could not read");
    }
    {
        return Text::lit("an expression");
    }
}


/// NameValue: unbounded fn Lx, Env, SName, Range -> Vl
Vl name_value(const Lx& lx, const Env& env, const crate::syntax::SName& n, const crate::syntax::Range& span) {
    auto nkey = name_key_at(lx, env, n, span);
    auto t = out_ty_of(lx, peel(type_at(lx, span)));
    auto local_opt = len(n->path_) == Nat(1u)
        ? crate::prelude::get(env->names, nkey)
        : std::optional<Bn>{};
    if (prism_rtl::is_some(local_opt) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(local_opt))) {
        auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(local_opt)).a0;
        auto&& mode = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(local_opt)).a1;
        auto&& lt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(local_opt)).a2;
        return local_place(rs, mode, lt);
    }
    if (prism_rtl::is_some(local_opt) && prism_rtl::is<Bn::BnHold>(prism_rtl::some_of(local_opt))) {
        auto&& f = prism_rtl::as<Bn::BnHold>(prism_rtl::some_of(local_opt)).a0;
        auto&& ht = prism_rtl::as<Bn::BnHold>(prism_rtl::some_of(local_opt)).a1;
        return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f)})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), ht});
    }
    if (prism_rtl::is_some(local_opt) && prism_rtl::is<Bn::BnDyn>(prism_rtl::some_of(local_opt))) {
        auto&& x = prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(local_opt)).a0;
        auto&& dt = prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(local_opt)).a2;
        return Vl(Vl::VlOwned{x, dt});
    }
    if (prism_rtl::is_some(local_opt) && prism_rtl::is<Bn::BnEv>(prism_rtl::some_of(local_opt))) {
        auto&& et = prism_rtl::as<Bn::BnEv>(prism_rtl::some_of(local_opt)).a1;
        auto&& _m = crate::prelude::get(env->names, prism_rtl::cat(nkey, "#port"));
        if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
            auto&& pf = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
            return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::Event::of"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(pf)})})}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutEvent{prism_rtl::rc(out_ty_of(lx, peel(peel(type_at(lx, span)))))})});
        }
        {
            return Vl(Vl::VlOwned{refusal(Text::lit("an event read as a value")), et});
        }
    }
    if (prism_rtl::is_some(local_opt) && prism_rtl::is<Bn::BnParts>(prism_rtl::some_of(local_opt))) {
        return Vl(Vl::VlOwned{refusal(Text::lit("a tuple pattern's binding as a value")), t});
    }
    if (prism_rtl::is_some(local_opt) && prism_rtl::is<Bn::BnWidget>(prism_rtl::some_of(local_opt))) {
        return Vl(Vl::VlOwned{refusal(Text::lit("a widget parameter read as a plain value")), t});
    }
    if (prism_rtl::is_some(local_opt) && prism_rtl::is<Bn::BnLocalFn>(prism_rtl::some_of(local_opt))) {
        return Vl(Vl::VlOwned{refusal(Text::lit("a local function as a value")), t});
    }
    if (prism_rtl::is_none(local_opt)) {
        auto [qk_opt, why] = crate::check::env::resolve_value(lx.g, lx.home, n);
        if (prism_rtl::is_some(qk_opt)) {
            auto&& m43893_0 = prism_rtl::some_of(qk_opt);
            if (m43893_0 == Text::lit("True")) {
                return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBool{true}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})});
            }
        }
        if (prism_rtl::is_some(qk_opt)) {
            auto&& m43893_1 = prism_rtl::some_of(qk_opt);
            if (m43893_1 == Text::lit("False")) {
                return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBool{false}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})});
            }
        }
        if (prism_rtl::is_some(qk_opt)) {
            auto&& m43893_2 = prism_rtl::some_of(qk_opt);
            if (m43893_2 == Text::lit("Prelude.never")) {
                return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Event::never"), Array<crate::lower::model::Ex>{}}), t});
            }
        }
        if (prism_rtl::is_some(qk_opt)) {
            auto&& qk = prism_rtl::some_of(qk_opt);
            auto&& _m = crate::prelude::get(lx.g.tags, qk);
            if (prism_rtl::is_some(_m)) {
                auto&& tg = prism_rtl::some_of(_m);
                if ((tg.kind != Text::lit("Prelude.Fault")) && (why == Text::lit("tag"))) {
                    return tag_value(lx, env, tg, Array<crate::syntax::Arg>{});
                }
            }
            {
                return global_value(lx, qk, span, t);
            }
        }
        if (prism_rtl::is_none(qk_opt)) {
            return Vl(Vl::VlOwned{refusal(prism_rtl::cat("the name ", nkey, ", which nothing declares")), t});
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Vl> NameValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& n = this->n;
    const auto& span = this->span;
    auto nkey = name_key_at(lx, env, n, span);
    auto env_1 = env;
    auto lx_2 = lx;
    auto n_3 = n;
    auto span_4 = span;
    return call_then(start_out_ty_of(lx_2, peel(type_at(lx_2, span_4))), [=](crate::lower::model::OutTy out_ty_of_42923) {
        return ({
            auto t = out_ty_of_42923;
            auto local_opt = len(n_3->path_) == Nat(1u)
                ? crate::prelude::get(env_1->names, nkey)
                : std::optional<Bn>{};
            ({
            prism_rtl::is_some(local_opt) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(local_opt)) ? ({
            auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(local_opt)).a0;
            auto&& mode = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(local_opt)).a1;
            auto&& lt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(local_opt)).a2;
            prism_rtl::finished(local_place(rs, mode, lt));
        })
            : prism_rtl::is_some(local_opt) && prism_rtl::is<Bn::BnHold>(prism_rtl::some_of(local_opt)) ? ({
            auto&& f = prism_rtl::as<Bn::BnHold>(prism_rtl::some_of(local_opt)).a0;
            auto&& ht = prism_rtl::as<Bn::BnHold>(prism_rtl::some_of(local_opt)).a1;
            prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f)})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), ht}));
        })
            : prism_rtl::is_some(local_opt) && prism_rtl::is<Bn::BnDyn>(prism_rtl::some_of(local_opt)) ? ({
            auto&& x = prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(local_opt)).a0;
            auto&& dt = prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(local_opt)).a2;
            prism_rtl::finished(Vl(Vl::VlOwned{x, dt}));
        })
            : prism_rtl::is_some(local_opt) && prism_rtl::is<Bn::BnEv>(prism_rtl::some_of(local_opt)) ? ({
            auto&& et = prism_rtl::as<Bn::BnEv>(prism_rtl::some_of(local_opt)).a1;
            ({
            auto&& _m = crate::prelude::get(env_1->names, prism_rtl::cat(nkey, "#port"));
            prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m)) ? ({
            auto&& pf = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
            call_then(start_out_ty_of(lx_2, peel(peel(type_at(lx_2, span_4)))), [=](crate::lower::model::OutTy out_ty_of_43403) { return prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::Event::of"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(pf)})})}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutEvent{prism_rtl::rc(out_ty_of_43403)})})); });
        })
            : prism_rtl::finished(Vl(Vl::VlOwned{refusal(Text::lit("an event read as a value")), et}));
        });
        })
            : prism_rtl::is_some(local_opt) && prism_rtl::is<Bn::BnParts>(prism_rtl::some_of(local_opt)) ? prism_rtl::finished(Vl(Vl::VlOwned{refusal(Text::lit("a tuple pattern's binding as a value")), t}))
            : prism_rtl::is_some(local_opt) && prism_rtl::is<Bn::BnWidget>(prism_rtl::some_of(local_opt)) ? prism_rtl::finished(Vl(Vl::VlOwned{refusal(Text::lit("a widget parameter read as a plain value")), t}))
            : prism_rtl::is_some(local_opt) && prism_rtl::is<Bn::BnLocalFn>(prism_rtl::some_of(local_opt)) ? prism_rtl::finished(Vl(Vl::VlOwned{refusal(Text::lit("a local function as a value")), t}))
            : prism_rtl::is_none(local_opt) ? ({
            auto [qk_opt, why] = crate::check::env::resolve_value(lx_2.g, lx_2.home, n_3);
            ({
            prism_rtl::is_some(qk_opt) && ({
            auto&& m43893_0 = prism_rtl::some_of(qk_opt);
            (m43893_0 == Text::lit("True"));
        }) ? ({
            auto&& m43893_0 = prism_rtl::some_of(qk_opt);
            prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBool{true}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})}));
        })
            : prism_rtl::is_some(qk_opt) && ({
            auto&& m43893_1 = prism_rtl::some_of(qk_opt);
            (m43893_1 == Text::lit("False"));
        }) ? ({
            auto&& m43893_1 = prism_rtl::some_of(qk_opt);
            prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBool{false}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})}));
        })
            : prism_rtl::is_some(qk_opt) && ({
            auto&& m43893_2 = prism_rtl::some_of(qk_opt);
            (m43893_2 == Text::lit("Prelude.never"));
        }) ? ({
            auto&& m43893_2 = prism_rtl::some_of(qk_opt);
            prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Event::never"), Array<crate::lower::model::Ex>{}}), t}));
        })
            : prism_rtl::is_some(qk_opt) ? ({
            auto&& qk = prism_rtl::some_of(qk_opt);
            ({
            auto&& _m = crate::prelude::get(lx_2.g.tags, qk);
            prism_rtl::is_some(_m) && ({
            auto&& tg = prism_rtl::some_of(_m);
            ((tg.kind != Text::lit("Prelude.Fault")) && (why == Text::lit("tag")));
        }) ? ({
            auto&& tg = prism_rtl::some_of(_m);
            prism_rtl::more(prism_rtl::rc(TagValue(lx_2, env_1, tg, Array<crate::syntax::Arg>{})));
        })
            : prism_rtl::more(prism_rtl::rc(GlobalValue(lx_2, qk, span_4, t)));
        });
        })
            : prism_rtl::is_none(qk_opt) ? prism_rtl::finished(Vl(Vl::VlOwned{refusal(prism_rtl::cat("the name ", nkey, ", which nothing declares")), t}))
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
}


/// `Start NameValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_name_value(Lx lx, Env env, crate::syntax::SName n, crate::syntax::Range span) {
    return prism_rtl::make_rc<NameValue>(lx, env, n, span);
}


/// GlobalValue: unbounded fn Lx, Text, Range, OutTy -> Vl
Vl global_value(const Lx& lx, const Text& qk, const crate::syntax::Range& span, const crate::lower::model::OutTy& t) {
    auto&& _m = crate::prelude::get(lx.g.ctors, qk);
    if (prism_rtl::is_some(_m)) {
        auto&& c = prism_rtl::some_of(_m);
        auto arity = len(c.fields) > Nat(0u) ? len(c.fields) : len(c->args);
        if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(t)) {
            auto&& pts = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t).a0;
            return arity > Nat(0u)
                ? ctor_fn(lx, c, pts, span, t, false)
                : ctor_app(lx, empty_env(), c, Array<crate::syntax::Arg>{}, span);
        }
        if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t)) {
            auto&& a = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t).a0;
            auto pts = ({
                __label__ _done;
                prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
                auto&& _m = a;
                if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(_m)) {
                    auto&& ts = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(_m).a0;
                    _v.set(arity == Nat(1u) ? Array(std::vector{a}) : ts);
                    goto _done;
                }
                {
                    _v.set(Array(std::vector{a}));
                    goto _done;
                }
            _done:
                _v.take();
            });
            return arity > Nat(0u)
                ? ctor_fn(lx, c, pts, span, t, true)
                : ctor_app(lx, empty_env(), c, Array<crate::syntax::Arg>{}, span);
        }
        {
            return ctor_app(lx, empty_env(), c, Array<crate::syntax::Arg>{}, span);
        }
    }
    if (prism_rtl::is_none(_m)) {
        auto&& _m = crate::prelude::get(lx.g.tags, qk);
        if (prism_rtl::is_some(_m)) {
            auto&& tg = prism_rtl::some_of(_m);
            return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XStr{tg.name}), t});
        }
        if (prism_rtl::is_none(_m)) {
            return fold(lx.g.defs, false, [&](const bool& f, const crate::check::env::Def& d) { return f || ((d.qk == qk) && is_let_def(d)); })
                ? Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{value_path(lx, qk), Array<crate::lower::model::Ex>{}}), t})
                : ({
                __label__ _done;
                prism_rtl::Slot<Vl> _v;
                auto&& _m = crate::prelude::get(lx.g.vals, qk);
                if (prism_rtl::is_some(_m)) {
                    auto&& v_ = prism_rtl::some_of(_m);
                    _v.set(({
                        auto is_let = fold(lx.g.defs, false, [&](const bool& f, const crate::check::env::Def& d) { return f || ((d.qk == qk) && is_let_def(d)); });
                        is_let
                        ? Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{value_path(lx, qk), Array<crate::lower::model::Ex>{}}), t})
                        : ({
                        __label__ _done;
                        prism_rtl::Slot<Vl> _v;
                        if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t)) {
                            auto&& a = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t).a0;
                            _v.set(({
                                auto [ps, ignore2] = scheme_parts(lx, qk);
                                auto names = each(crate::check::errors::range0(len(ps)), [&](const Nat& i) { return prism_rtl::cat("a", i); });
                                auto pa = len(ps) == Nat(1u)
                                    ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("a0")})), a})
                                    : crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(names, [&](const Text& nm) { return crate::lower::model::Pa(crate::lower::model::Pa::PaBind{nm}); })})), a});
                                auto f = crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{pa}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("entered"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{start_path(lx, qk), each(names, [&](const Text& nm) { return crate::lower::model::Ex(crate::lower::model::Ex::XVar{nm}); })})})}))});
                                (Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{f})})), t}), t}));
                            }));
                            goto _done;
                        }
                        {
                            _v.set(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XPath{value_path(lx, qk)})})}), t}));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Vl(Vl::VlOwned{refusal(prism_rtl::cat("the global ", qk)), t}));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Vl> GlobalValue::cycle() const {
    const auto& lx = this->lx;
    const auto& qk = this->qk;
    const auto& span = this->span;
    const auto& t = this->t;
    return ({
        auto&& _m = crate::prelude::get(lx.g.ctors, qk);
        prism_rtl::is_some(_m) ? ({
        auto&& c = prism_rtl::some_of(_m);
        ({
        auto arity = len(c.fields) > Nat(0u) ? len(c.fields) : len(c->args);
        ({
        prism_rtl::is<crate::lower::model::OutTy::OutFn>(t) ? ({
        auto&& pts = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t).a0;
        arity > Nat(0u)
        ? prism_rtl::more(prism_rtl::rc(CtorFn(lx, c, pts, span, t, false)))
        : prism_rtl::more(prism_rtl::rc(CtorApp(lx, empty_env(), c, Array<crate::syntax::Arg>{}, span)));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t) ? ({
        auto&& a = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t).a0;
        ({
        auto pts = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
            auto&& _m = a;
            if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(_m)) {
                auto&& ts = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(_m).a0;
                _v.set(arity == Nat(1u) ? Array(std::vector{a}) : ts);
                goto _done;
            }
            {
                _v.set(Array(std::vector{a}));
                goto _done;
            }
        _done:
            _v.take();
        });
        arity > Nat(0u)
        ? prism_rtl::more(prism_rtl::rc(CtorFn(lx, c, pts, span, t, true)))
        : prism_rtl::more(prism_rtl::rc(CtorApp(lx, empty_env(), c, Array<crate::syntax::Arg>{}, span)));
    });
    })
        : prism_rtl::more(prism_rtl::rc(CtorApp(lx, empty_env(), c, Array<crate::syntax::Arg>{}, span)));
    });
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto&& _m = crate::prelude::get(lx.g.tags, qk);
        prism_rtl::is_some(_m) ? ({
        auto&& tg = prism_rtl::some_of(_m);
        prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XStr{tg.name}), t}));
    })
        : prism_rtl::is_none(_m) ? fold(lx.g.defs, false, [&](const bool& f, const crate::check::env::Def& d) { return f || ((d.qk == qk) && is_let_def(d)); })
        ? prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{value_path(lx, qk), Array<crate::lower::model::Ex>{}}), t}))
        : ({
        auto&& _m = crate::prelude::get(lx.g.vals, qk);
        prism_rtl::is_some(_m) ? ({
        auto&& v_ = prism_rtl::some_of(_m);
        ({
        auto is_let = fold(lx.g.defs, false, [&](const bool& f, const crate::check::env::Def& d) { return f || ((d.qk == qk) && is_let_def(d)); });
        is_let
        ? prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{value_path(lx, qk), Array<crate::lower::model::Ex>{}}), t}))
        : ({
        prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t) ? ({
        auto&& a = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t).a0;
        ({
        auto [ps, ignore2] = scheme_parts(lx, qk);
        auto names = each(crate::check::errors::range0(len(ps)), [&](const Nat& i) { return prism_rtl::cat("a", i); });
        auto pa = len(ps) == Nat(1u)
            ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("a0")})), a})
            : crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(names, [&](const Text& nm) { return crate::lower::model::Pa(crate::lower::model::Pa::PaBind{nm}); })})), a});
        auto f = crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{pa}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("entered"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{start_path(lx, qk), each(names, [&](const Text& nm) { return crate::lower::model::Ex(crate::lower::model::Ex::XVar{nm}); })})})}))});
        (prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{f})})), t}), t})));
    });
    })
        : prism_rtl::finished(Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XPath{value_path(lx, qk)})})}), t}));
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(Vl(Vl::VlOwned{refusal(prism_rtl::cat("the global ", qk)), t}))
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start GlobalValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_global_value(Lx lx, Text qk, crate::syntax::Range span, crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<GlobalValue>(lx, qk, span, t);
}


/// IsLetDef: fn Def -> Bool
bool is_let_def(const crate::check::env::Def& d) {
    auto&& _m = d.body;
    if (prism_rtl::is<crate::check::env::DefBody::DbLet>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// StartPath: fn Lx, Text -> Text
Text start_path(const Lx& lx, const Text& qk) {
    auto owner = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = crate::prelude::get(lx.g.vals, qk);
        if (prism_rtl::is_some(_m)) {
            auto&& v_ = prism_rtl::some_of(_m);
            _v.set(v_.home);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(owner_of(qk));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return path_in(lx, owner, prism_rtl::cat("start_", or_(crate::prelude::get(lx.rs_names, qk), snake(crate::check::types::bare_name(qk)))));
}


/// Application: unbounded fn Lx, Env, Expr, [Arg], Range -> Vl
Vl application(const Lx& lx, const Env& env, const crate::syntax::Expr& callee, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span) {
    auto t = out_ty_of(lx, peel(type_at(lx, span)));
    auto&& _m = callee.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        auto nkey = name_key_at(lx, env, n, callee.span);
        auto local_opt = len(n->path_) == Nat(1u)
            ? crate::prelude::get(env->names, nkey)
            : std::optional<Bn>{};
        if (prism_rtl::is_some(local_opt) && prism_rtl::is<Bn::BnLocalFn>(prism_rtl::some_of(local_opt))) {
            auto&& c = prism_rtl::as<Bn::BnLocalFn>(prism_rtl::some_of(local_opt)).a0;
            return inline_local_fn(lx, env, c, args, t);
        }
        if (prism_rtl::is_some(local_opt)) {
            auto&& b = prism_rtl::some_of(local_opt);
            auto f = name_value(lx, env, n, callee.span);
            auto&& _m = value_ty(f);
            if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m)) {
                return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("run_to_end"), Array(std::vector{start_call(f, start_args(lx, env, f, args))})}), t});
            }
            {
                return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XApply{prism_rtl::rc(ref_(f)), run_to_end(each_job(args, ({
                    auto lx_1 = lx;
                    auto env_2 = env;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=](crate::syntax::Arg p0) {
                    return ({
                        auto lx_1_3 = lx_1;
                        auto env_2_3 = env_2;
                        entered(once_job([=]() {
                        return ({
                            auto a = p0;
                            (prism_rtl::more(prism_rtl::rc(Argument(lx_1_3, env_2_3, a->value))));
                        });
                    }));
                    });
                })));
                })))}), t});
            }
        }
        if (prism_rtl::is_none(local_opt)) {
            auto [qk_opt, why] = crate::check::env::resolve_value(lx.g, lx.home, n);
            if (prism_rtl::is_some(qk_opt)) {
                auto&& qk = prism_rtl::some_of(qk_opt);
                auto&& _m = crate::prelude::get(lx.g.tags, qk);
                if (prism_rtl::is_some(_m)) {
                    auto&& tg = prism_rtl::some_of(_m);
                    if (why == Text::lit("tag")) {
                        return tag_value(lx, env, tg, args);
                    }
                }
                {
                    return qk == Text::lit("Prelude.@Element")
                        ? element_blueprint(lx, env, args, t)
                        : global_call(lx, env, qk, args, span, t);
                }
            }
            if (prism_rtl::is_none(qk_opt)) {
                return Vl(Vl::VlOwned{refusal(prism_rtl::cat("a call of ", nkey, ", which nothing declares")), t});
            }
            prism_rtl::unreachable("no arm matched");
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return application(lx, env, x, args, span);
    }
    {
        auto f = value_of(lx, env, callee);
        auto&& _m = value_ty(f);
        if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m)) {
            return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("run_to_end"), Array(std::vector{start_call(f, start_args(lx, env, f, args))})}), t});
        }
        {
            return Vl(Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XApply{prism_rtl::rc(ref_(f)), run_to_end(each_job(args, ({
                auto lx_1 = lx;
                auto env_2 = env;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=](crate::syntax::Arg p0) {
                return ({
                    auto lx_1_3 = lx_1;
                    auto env_2_3 = env_2;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        (prism_rtl::more(prism_rtl::rc(Argument(lx_1_3, env_2_3, a->value))));
                    });
                }));
                });
            })));
            })))}), t});
        }
    }
}

}  // namespace crate::lower
