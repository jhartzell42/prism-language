// The module `Lower.Expr`, from `target/bootstrap/cpp-src/prismc/lower/expr.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <lower/expr/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate::lower::expr {

/// `Start AsJobValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_as_job_value(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e) {
    return prism_rtl::make_rc<AsJobValue>(lx, env, e);
}


/// WrapAsJob: fn Ex, [OutTy], OutTy, OutTy -> Ex
crate::lower::model::Ex wrap_as_job(const crate::lower::model::Ex& f, const Array<crate::lower::model::OutTy>& pts, const crate::lower::model::OutTy& target, const crate::lower::model::OutTy& a) {
    auto names = each(crate::check::errors::range0(len(pts)), [&](const Nat& i) { return prism_rtl::cat("a", i); });
    auto pa = len(pts) == Nat(1u)
        ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("a0")})), a})
        : crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(names, [&](const Text& nm) { return crate::lower::model::Pa(crate::lower::model::Pa::PaBind{nm}); })})), a});
    auto call = crate::lower::model::Ex(crate::lower::model::Ex::XApply{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("f")})), each(names, [&](const Text& nm) { return crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{nm}))}); })});
    auto body = crate::lower::model::Ex(crate::lower::model::Ex::XBlock{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("f")}), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("f")}))})})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("once_job"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array<crate::lower::model::Pa>{}, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{call})}))})})}))});
    return crate::lower::model::Ex(crate::lower::model::Ex::XBlock{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("f")}), f})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{pa}), prism_rtl::rc(body)})})})), target}))});
}


/// NamedArgsOwned: unbounded fn Lx, Env, Text, [Arg] -> [Ex]
Array<crate::lower::model::Ex> named_args_owned(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const Text& qk, const Array<crate::syntax::Arg>& args) {
    auto&& _ps = crate::lower::jobs::scheme_parts(lx, qk);
    auto&& ps = std::get<0>(_ps);
    return run_to_end(each_job(crate::check::errors::range0(len(args)), ({
        auto args_1 = args;
        auto ps_2 = ps;
        auto lx_3 = lx;
        auto env_4 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto args_1_5 = args_1;
            auto ps_2_5 = ps_2;
            auto lx_3_5 = lx_3;
            auto env_4_5 = env_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto a = or_(index(args_1_5, i), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = dummy_expr(), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}});
                ({
                auto&& _m = crate::lower::types::peel(or_(index(ps_2_5, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})));
                prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CBound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0) ? call_then(start_value_of(lx_3_5, env_4_5, a->value), [=](crate::lower::types::Vl value_of_41167) { return prism_rtl::finished(crate::lower::types::own(value_of_41167)); })
                : prism_rtl::is<crate::check::types::Ty::TyFn>(_m) ? prism_rtl::more(prism_rtl::rc(AsJobValue(lx_3_5, env_4_5, a->value)))
                : call_then(start_value_of(lx_3_5, env_4_5, a->value), [=](crate::lower::types::Vl value_of_41290) { return prism_rtl::finished(crate::lower::types::own(value_of_41290)); });
            });
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<crate::lower::model::Ex>> NamedArgsOwned::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& qk = this->qk;
    const auto& args = this->args;
    auto&& _ps = crate::lower::jobs::scheme_parts(lx, qk);
    auto&& ps = std::get<0>(_ps);
    return each_job(crate::check::errors::range0(len(args)), ({
        auto args_1 = args;
        auto ps_2 = ps;
        auto lx_3 = lx;
        auto env_4 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto args_1_5 = args_1;
            auto ps_2_5 = ps_2;
            auto lx_3_5 = lx_3;
            auto env_4_5 = env_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto a = or_(index(args_1_5, i), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = dummy_expr(), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}});
                ({
                auto&& _m = crate::lower::types::peel(or_(index(ps_2_5, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})));
                prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CBound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0) ? call_then(start_value_of(lx_3_5, env_4_5, a->value), [=](crate::lower::types::Vl value_of_41167) { return prism_rtl::finished(crate::lower::types::own(value_of_41167)); })
                : prism_rtl::is<crate::check::types::Ty::TyFn>(_m) ? prism_rtl::more(prism_rtl::rc(AsJobValue(lx_3_5, env_4_5, a->value)))
                : call_then(start_value_of(lx_3_5, env_4_5, a->value), [=](crate::lower::types::Vl value_of_41290) { return prism_rtl::finished(crate::lower::types::own(value_of_41290)); });
            });
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start NamedArgsOwned, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::Ex>> start_named_args_owned(crate::lower::Lx lx, crate::lower::types::Env env, Text qk, Array<crate::syntax::Arg> args) {
    return prism_rtl::make_rc<NamedArgsOwned>(lx, env, qk, args);
}


/// StartArgs: unbounded fn Lx, Env, Vl, [Arg] -> [Ex]
Array<crate::lower::model::Ex> start_args(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::lower::types::Vl& f, const Array<crate::syntax::Arg>& args) {
    auto pts = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
        auto&& _m = crate::lower::types::value_ty(f);
        if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m)) {
            auto&& m41502_0_0 = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(_m).a0;
            if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(m41502_0_0)) {
                auto&& ts = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(m41502_0_0).a0;
                _v.set(len(args) == Nat(1u)
                    ? Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{ts})})
                    : ts);
                goto _done;
            }
        }
        if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m)) {
            auto&& a = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(_m).a0;
            _v.set(Array(std::vector{a}));
            goto _done;
        }
        {
            _v.set(Array<crate::lower::model::OutTy>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return run_to_end(each_job(crate::check::errors::range0(len(args)), ({
        auto args_1 = args;
        auto pts_2 = pts;
        auto lx_3 = lx;
        auto env_4 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto args_1_5 = args_1;
            auto pts_2_5 = pts_2;
            auto lx_3_5 = lx_3;
            auto env_4_5 = env_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto a = or_(index(args_1_5, i), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = dummy_expr(), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}});
                ({
                auto&& _m = or_(index(pts_2_5, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
                prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m) ? prism_rtl::more(prism_rtl::rc(AsJobValue(lx_3_5, env_4_5, a->value)))
                : call_then(start_value_of(lx_3_5, env_4_5, a->value), [=](crate::lower::types::Vl value_of_41913) { return prism_rtl::finished(crate::lower::types::own(value_of_41913)); });
            });
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<crate::lower::model::Ex>> StartArgs::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& f = this->f;
    const auto& args = this->args;
    auto pts = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
        auto&& _m = crate::lower::types::value_ty(f);
        if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m)) {
            auto&& m41502_0_0 = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(_m).a0;
            if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(m41502_0_0)) {
                auto&& ts = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(m41502_0_0).a0;
                _v.set(len(args) == Nat(1u)
                    ? Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{ts})})
                    : ts);
                goto _done;
            }
        }
        if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m)) {
            auto&& a = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(_m).a0;
            _v.set(Array(std::vector{a}));
            goto _done;
        }
        {
            _v.set(Array<crate::lower::model::OutTy>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return each_job(crate::check::errors::range0(len(args)), ({
        auto args_1 = args;
        auto pts_2 = pts;
        auto lx_3 = lx;
        auto env_4 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto args_1_5 = args_1;
            auto pts_2_5 = pts_2;
            auto lx_3_5 = lx_3;
            auto env_4_5 = env_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto a = or_(index(args_1_5, i), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = dummy_expr(), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}});
                ({
                auto&& _m = or_(index(pts_2_5, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
                prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m) ? prism_rtl::more(prism_rtl::rc(AsJobValue(lx_3_5, env_4_5, a->value)))
                : call_then(start_value_of(lx_3_5, env_4_5, a->value), [=](crate::lower::types::Vl value_of_41913) { return prism_rtl::finished(crate::lower::types::own(value_of_41913)); });
            });
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start StartArgs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::Ex>> start_start_args(crate::lower::Lx lx, crate::lower::types::Env env, crate::lower::types::Vl f, Array<crate::syntax::Arg> args) {
    return prism_rtl::make_rc<StartArgs>(lx, env, f, args);
}


/// PreludeVariant: fn Text, OutTy -> Text
Text prelude_variant(const Text& name, const crate::lower::model::OutTy& first_) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutText>(first_)) {
        return name == Text::lit("len") ? Text::lit("len_text") : name;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(first_)) {
        return crate::check::types::has_text(Array(std::vector{Text::lit("len"), Text::lit("fold"), Text::lit("each"), Text::lit("filter")}), name)
            ? prism_rtl::cat(name, "_map")
            : name;
    }
    {
        return name;
    }
}


/// FieldValue: unbounded fn Lx, Env, Expr, Text -> Vl
crate::lower::types::Vl field_value(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& r, const Text& name) {
    auto rv = value_of(lx, env, r);
    auto rty = crate::lower::types::peel(crate::lower::type_at(lx, r.span));
    auto [ft, rc] = field_info(lx, rty, name);
    auto f = crate::lower::snake(name);
    auto mode = rc
        ? crate::lower::types::Holding(crate::lower::types::Holding::RcOwned{})
        : crate::lower::types::Holding(crate::lower::types::Holding::Owned{});
    if (prism_rtl::is<crate::lower::types::Vl::VlPlace>(rv)) {
        auto&& x = prism_rtl::as<crate::lower::types::Vl::VlPlace>(rv).a0;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(x), f}), mode, ft});
    }
    if (prism_rtl::is<crate::lower::types::Vl::VlOwned>(rv)) {
        auto&& x = prism_rtl::as<crate::lower::types::Vl::VlOwned>(rv).a0;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(x), f}), mode, ft});
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::types::Vl> FieldValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& r = this->r;
    const auto& name = this->name;
    auto env_1 = env;
    auto lx_2 = lx;
    auto name_3 = name;
    auto r_4 = r;
    return call_then(start_value_of(lx_2, env_1, r_4), [=](crate::lower::types::Vl value_of_42408) {
        return ({
            auto rv = value_of_42408;
            auto rty = crate::lower::types::peel(crate::lower::type_at(lx_2, r_4.span));
            call_then(start_field_info(lx_2, rty, name_3), [=](std::tuple<crate::lower::model::OutTy, bool> field_info_42487) {
            return ({
                auto [ft, rc] = field_info_42487;
                auto f = crate::lower::snake(name_3);
                auto mode = rc
                    ? crate::lower::types::Holding(crate::lower::types::Holding::RcOwned{})
                    : crate::lower::types::Holding(crate::lower::types::Holding::Owned{});
                ({
                prism_rtl::is<crate::lower::types::Vl::VlPlace>(rv) ? ({
                auto&& x = prism_rtl::as<crate::lower::types::Vl::VlPlace>(rv).a0;
                prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(x), f}), mode, ft}));
            })
                : prism_rtl::is<crate::lower::types::Vl::VlOwned>(rv) ? ({
                auto&& x = prism_rtl::as<crate::lower::types::Vl::VlOwned>(rv).a0;
                prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(x), f}), mode, ft}));
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        });
        });
    });
}


/// `Start FieldValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_field_value(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr r, Text name) {
    return prism_rtl::make_rc<FieldValue>(lx, env, r, name);
}


/// FieldInfo: unbounded fn Lx, Ty, Text -> ((OutTy, Bool))
std::tuple<crate::lower::model::OutTy, bool> field_info(const crate::lower::Lx& lx, const crate::check::types::Ty& rty, const Text& name) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(rty)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(rty).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(rty).a1;
        auto&& _m = crate::prelude::get(lx.g.ctors, n);
        if (prism_rtl::is_some(_m)) {
            auto&& c = prism_rtl::some_of(_m);
            auto fix_opt = fold(crate::check::errors::range0(len(c.fields)), std::optional<Nat>{}, [&](const std::optional<Nat>& found_opt, const Nat& i) {
                return or_(index(c.fields, i), Text::lit("")) == name
                    ? std::optional(i)
                    : found_opt;
            });
            if (prism_rtl::is_some(fix_opt)) {
                auto&& i = prism_rtl::some_of(fix_opt);
                auto ft = or_(index(c->args, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
                auto inst = instantiated(ft, c.params, args);
                return std::tuple{crate::lower::types::out_ty_of(lx, inst), crate::lower::types::rc_field(lx, c.name, i)};
            }
            if (prism_rtl::is_none(fix_opt)) {
                return std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{prism_rtl::cat("a field ", name)}), false};
            }
            prism_rtl::unreachable("no arm matched");
        }
        if (prism_rtl::is_none(_m)) {
            return std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{prism_rtl::cat("a field ", name)}), false};
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        return std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{prism_rtl::cat("a field ", name, " of a non-record")}), false};
    }
}


prism_rtl::Turn<std::tuple<crate::lower::model::OutTy, bool>> FieldInfo::cycle() const {
    const auto& lx = this->lx;
    const auto& rty = this->rty;
    const auto& name = this->name;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyCon>(rty) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(rty).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(rty).a1;
        ({
        auto&& _m = crate::prelude::get(lx.g.ctors, n);
        prism_rtl::is_some(_m) ? ({
        auto&& c = prism_rtl::some_of(_m);
        ({
        auto fix_opt = fold(crate::check::errors::range0(len(c.fields)), std::optional<Nat>{}, [&](const std::optional<Nat>& found_opt, const Nat& i) {
            return or_(index(c.fields, i), Text::lit("")) == name
                ? std::optional(i)
                : found_opt;
        });
        ({
        prism_rtl::is_some(fix_opt) ? ({
        auto&& i = prism_rtl::some_of(fix_opt);
        ({
        auto ft = or_(index(c->args, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
        auto args_1 = args;
        auto i_2 = i;
        auto lx_3 = lx;
        auto name_4 = name;
        call_then(start_instantiated(ft, c.params, args_1), [=](crate::check::types::Ty instantiated_43175) {
        return ({
            auto inst = instantiated_43175;
            call_then(crate::lower::types::start_out_ty_of(lx_3, inst), [=](crate::lower::model::OutTy out_ty_of_43230) { return prism_rtl::finished(std::tuple{out_ty_of_43230, crate::lower::types::rc_field(lx_3, c.name, i_2)}); });
        });
    });
    });
    })
        : prism_rtl::is_none(fix_opt) ? prism_rtl::finished(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{prism_rtl::cat("a field ", name)}), false})
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{prism_rtl::cat("a field ", name)}), false})
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::finished(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{prism_rtl::cat("a field ", name, " of a non-record")}), false});
    });
}


/// `Start FieldInfo, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::model::OutTy, bool>> start_field_info(crate::lower::Lx lx, crate::check::types::Ty rty, Text name) {
    return prism_rtl::make_rc<FieldInfo>(lx, rty, name);
}


/// Instantiated: unbounded fn Ty, [Text], [Ty] -> Ty
crate::check::types::Ty instantiated(const crate::check::types::Ty& t, const Array<Text>& params, const Array<crate::check::types::Ty>& args) {
    if (prism_rtl::is<crate::check::types::Ty::TyQ>(t)) {
        auto&& q = prism_rtl::as<crate::check::types::Ty::TyQ>(t).a0;
        auto hit_opt = fold(crate::check::errors::range0(len(params)), std::optional<crate::check::types::Ty>{}, [&](const std::optional<crate::check::types::Ty>& found_opt, const Nat& i) { return or_(index(params, i), Text::lit("")) == q ? index(args, i) : found_opt; });
        return or_(hit_opt, t);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& xs = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyCon{n, run_to_end(each_job(xs, ({
            auto params_1 = params;
            auto args_2 = args;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
            return ({
                auto params_1_3 = params_1;
                auto args_2_3 = args_2;
                entered(once_job([=]() {
                return ({
                    auto x = p0;
                    (prism_rtl::more(prism_rtl::rc(Instantiated(x, params_1_3, args_2_3))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t)) {
        auto&& c = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        return crate::check::types::Ty(crate::check::types::Ty::TyFn{c, run_to_end(each_job(ps, ({
            auto params_1 = params;
            auto args_2 = args;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
            return ({
                auto params_1_3 = params_1;
                auto args_2_3 = args_2;
                entered(once_job([=]() {
                return ({
                    auto x = p0;
                    (prism_rtl::more(prism_rtl::rc(Instantiated(x, params_1_3, args_2_3))));
                });
            }));
            });
        })));
        }))), prism_rtl::rc(instantiated(res, params, args))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyTuple{run_to_end(each_job(ts, ({
            auto params_1 = params;
            auto args_2 = args;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
            return ({
                auto params_1_3 = params_1;
                auto args_2_3 = args_2;
                entered(once_job([=]() {
                return ({
                    auto x = p0;
                    (prism_rtl::more(prism_rtl::rc(Instantiated(x, params_1_3, args_2_3))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(instantiated(e, params, args))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(instantiated(k, params, args)), prism_rtl::rc(instantiated(v_, params, args))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& s = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TySig{s, prism_rtl::rc(instantiated(i, params, args))});
    }
    {
        return t;
    }
}


prism_rtl::Turn<crate::check::types::Ty> Instantiated::cycle() const {
    const auto& t = this->t;
    const auto& params = this->params;
    const auto& args = this->args;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyQ>(t) ? ({
        auto&& q = prism_rtl::as<crate::check::types::Ty::TyQ>(t).a0;
        ({
        auto hit_opt = fold(crate::check::errors::range0(len(params)), std::optional<crate::check::types::Ty>{}, [&](const std::optional<crate::check::types::Ty>& found_opt, const Nat& i) { return or_(index(params, i), Text::lit("")) == q ? index(args, i) : found_opt; });
        (prism_rtl::finished(or_(hit_opt, t)));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& xs = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        ({
        auto args_1 = args;
        auto n_2 = n;
        auto params_3 = params;
        auto xs_4 = xs;
        call_value(each_job(xs_4, ({
        auto params_3_5 = params_3;
        auto args_1_5 = args_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return ({
            auto params_3_5_5 = params_3_5;
            auto args_1_5_5 = args_1_5;
            entered(once_job([=]() {
            return ({
                auto x = p0;
                (prism_rtl::more(prism_rtl::rc(Instantiated(x, params_3_5_5, args_1_5_5))));
            });
        }));
        });
    })));
    })), [=](Array<crate::check::types::Ty> each_43810) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyCon{n_2, each_43810})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(t) ? ({
        auto&& c = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        ({
        auto args_1 = args;
        auto c_2 = c;
        auto params_3 = params;
        auto ps_4 = ps;
        auto res_5 = res;
        call_value(each_job(ps_4, ({
        auto params_3_6 = params_3;
        auto args_1_6 = args_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return ({
            auto params_3_6_6 = params_3_6;
            auto args_1_6_6 = args_1_6;
            entered(once_job([=]() {
            return ({
                auto x = p0;
                (prism_rtl::more(prism_rtl::rc(Instantiated(x, params_3_6_6, args_1_6_6))));
            });
        }));
        });
    })));
    })), [=](Array<crate::check::types::Ty> each_43884) { return call_then(start_instantiated(res_5, params_3, args_1), [=](crate::check::types::Ty instantiated_43930) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyFn{c_2, each_43884, prism_rtl::rc(instantiated_43930)})); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        ({
        auto args_1 = args;
        auto params_2 = params;
        auto ts_3 = ts;
        call_value(each_job(ts_3, ({
        auto params_2_4 = params_2;
        auto args_1_4 = args_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return ({
            auto params_2_4_4 = params_2_4;
            auto args_1_4_4 = args_1_4;
            entered(once_job([=]() {
            return ({
                auto x = p0;
                (prism_rtl::more(prism_rtl::rc(Instantiated(x, params_2_4_4, args_1_4_4))));
            });
        }));
        });
    })));
    })), [=](Array<crate::check::types::Ty> each_43987) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyTuple{each_43987})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        ({
        auto args_1 = args;
        auto e_2 = e;
        auto params_3 = params;
        call_then(start_instantiated(e_2, params_3, args_1), [=](crate::check::types::Ty instantiated_44055) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(instantiated_44055)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        ({
        auto args_1 = args;
        auto k_2 = k;
        auto params_3 = params;
        auto v__4 = v_;
        call_then(start_instantiated(k_2, params_3, args_1), [=](crate::check::types::Ty instantiated_44108) { return call_then(start_instantiated(v__4, params_3, args_1), [=](crate::check::types::Ty instantiated_44140) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(instantiated_44108), prism_rtl::rc(instantiated_44140)})); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t) ? ({
        auto&& s = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        ({
        auto args_1 = args;
        auto i_2 = i;
        auto params_3 = params;
        auto s_4 = s;
        call_then(start_instantiated(i_2, params_3, args_1), [=](crate::check::types::Ty instantiated_44196) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TySig{s_4, prism_rtl::rc(instantiated_44196)})); });
    });
    })
        : prism_rtl::finished(t);
    });
}


/// `Start Instantiated, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_instantiated(crate::check::types::Ty t, Array<Text> params, Array<crate::check::types::Ty> args) {
    return prism_rtl::make_rc<Instantiated>(t, params, args);
}


/// IndexValue: unbounded fn Lx, Env, Expr, Expr, OutTy -> Vl
crate::lower::types::Vl index_value(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& r, const crate::syntax::Expr& i, const crate::lower::model::OutTy& t) {
    auto rt = crate::lower::types::out_ty_of(lx, crate::lower::types::peel(crate::lower::type_at(lx, r.span)));
    auto f = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(rt)) {
            _v.set(Text::lit("get"));
            goto _done;
        }
        {
            _v.set(Text::lit("index"));
            goto _done;
        }
    _done:
        _v.take();
    });
    return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{f, Array(std::vector{argument(lx, env, r), argument(lx, env, i)})}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(t)})});
}


prism_rtl::Turn<crate::lower::types::Vl> IndexValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& r = this->r;
    const auto& i = this->i;
    const auto& t = this->t;
    auto env_1 = env;
    auto i_2 = i;
    auto lx_3 = lx;
    auto r_4 = r;
    auto t_5 = t;
    return call_then(crate::lower::types::start_out_ty_of(lx_3, crate::lower::types::peel(crate::lower::type_at(lx_3, r_4.span))), [=](crate::lower::model::OutTy out_ty_of_44439) {
        return ({
            auto rt = out_ty_of_44439;
            auto f = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(rt)) {
                    _v.set(Text::lit("get"));
                    goto _done;
                }
                {
                    _v.set(Text::lit("index"));
                    goto _done;
                }
            _done:
                _v.take();
            });
            call_then(start_argument(lx_3, env_1, r_4), [=](crate::lower::model::Ex argument_44589) { return call_then(start_argument(lx_3, env_1, i_2), [=](crate::lower::model::Ex argument_44612) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{f, Array(std::vector{argument_44589, argument_44612})}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(t_5)})})); }); });
        });
    });
}


/// `Start IndexValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_index_value(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr r, crate::syntax::Expr i, crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<IndexValue>(lx, env, r, i, t);
}


/// ReadNames: unbounded fn [Expr] -> [Text]
Array<Text> read_names(const Array<crate::syntax::Expr>& es) {
    return fold(es, Array<Text>{}, [&](const Array<Text>& acc, const crate::syntax::Expr& x) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = x.kind;
            if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                _v.set(len(n->path_) == Nat(1u)
                    ? crate::check::types::add_text(acc, crate::check::env::sname_key(n))
                    : acc);
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Array<Text>> ReadNames::cycle() const {
    const auto& es = this->es;
    return prism_rtl::finished(fold(es, Array<Text>{}, [&](const Array<Text>& acc, const crate::syntax::Expr& x) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = x.kind;
            if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                _v.set(len(n->path_) == Nat(1u)
                    ? crate::check::types::add_text(acc, crate::check::env::sname_key(n))
                    : acc);
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    }));
}


/// `Start ReadNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_read_names(Array<crate::syntax::Expr> es) {
    return prism_rtl::make_rc<ReadNames>(es);
}


/// LambdaExprs: unbounded fn LambdaBody -> [Expr]
Array<crate::syntax::Expr> lambda_exprs(const crate::syntax::LambdaBody& lambda_body0) {
    if (prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(lambda_body0)) {
        auto&& x = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(lambda_body0).a0;
        return crate::check::typed::print::exprs_in(x);
    }
    if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(lambda_body0)) {
        auto&& b = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(lambda_body0).a0;
        return crate::check::typed::print::block_exprs(b);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<crate::syntax::Expr>> LambdaExprs::cycle() const {
    const auto& lambda_body0 = this->lambda_body0;
    return ({
        prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(lambda_body0) ? ({
        auto&& x = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(lambda_body0).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::typed::print::ExprsIn(x)));
    })
        : prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(lambda_body0) ? ({
        auto&& b = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(lambda_body0).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::typed::print::BlockExprs(b)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start LambdaExprs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::syntax::Expr>> start_lambda_exprs(crate::syntax::LambdaBody lambda_body0) {
    return prism_rtl::make_rc<LambdaExprs>(lambda_body0);
}


/// LambdaValue: unbounded fn Lx, Env, Expr, [Pattern], LambdaBody -> Vl
crate::lower::types::Vl lambda_value(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& e, const Array<crate::syntax::Pattern_>& ps, const crate::syntax::LambdaBody& body) {
    auto ft = crate::lower::types::out_ty_of(lx, crate::lower::types::peel(crate::lower::type_at(lx, e.span)));
    if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(ft)) {
        auto&& a = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(ft).a0;
        return job_lambda(lx, env, ps, body, ft, a, enters_lambda(lx, e));
    }
    {
        return plain_lambda(lx, env, ps, body, ft);
    }
}


prism_rtl::Turn<crate::lower::types::Vl> LambdaValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    const auto& ps = this->ps;
    const auto& body = this->body;
    auto body_1 = body;
    auto e_2 = e;
    auto env_3 = env;
    auto lx_4 = lx;
    auto ps_5 = ps;
    return call_then(crate::lower::types::start_out_ty_of(lx_4, crate::lower::types::peel(crate::lower::type_at(lx_4, e_2.span))), [=](crate::lower::model::OutTy out_ty_of_45279) {
        return ({
            auto ft = out_ty_of_45279;
            ({
            prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(ft) ? ({
            auto&& a = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(ft).a0;
            prism_rtl::more(prism_rtl::rc(JobLambda(lx_4, env_3, ps_5, body_1, ft, a, enters_lambda(lx_4, e_2))));
        })
            : prism_rtl::more(prism_rtl::rc(PlainLambda(lx_4, env_3, ps_5, body_1, ft)));
        });
        });
    });
}


/// `Start LambdaValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_lambda_value(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e, Array<crate::syntax::Pattern_> ps, crate::syntax::LambdaBody body) {
    return prism_rtl::make_rc<LambdaValue>(lx, env, e, ps, body);
}


/// PlainLambda: unbounded fn Lx, Env, [Pattern], LambdaBody, OutTy -> Vl
crate::lower::types::Vl plain_lambda(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const Array<crate::syntax::Pattern_>& ps, const crate::syntax::LambdaBody& body, const crate::lower::model::OutTy& ft) {
    auto pts = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
        if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(ft)) {
            auto&& xs = prism_rtl::as<crate::lower::model::OutTy::OutFn>(ft).a0;
            _v.set(xs);
            goto _done;
        }
        {
            _v.set(Array<crate::lower::model::OutTy>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto read = crate::lower::types::with_instances(env, read_names(lambda_exprs(body)));
    auto caps0 = filter(read, [&](const Text& n) {
        return ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = crate::prelude::get(env->names, n);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                _v.set(true);
                goto _done;
            }
            {
                _v.set(false);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto caps = append(append(caps0, filter(each(read, [&](const Text& n) { return prism_rtl::cat(n, "#port"); }), [&](const Text& n) { return crate::check::env::has_key(env->names, n); })), filter(each(read, [&](const Text& n) { return prism_rtl::cat(n, "#init"); }), [&](const Text& n) { return crate::check::env::has_key(env->names, n); }));
    auto [dos, env1] = fold(caps, std::tuple{Array<crate::lower::model::Do>{}, env}, [&](const std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>& _p0, const Text& n) {
        auto&& acc = std::get<0>(_p0);
        auto&& en = std::get<1>(_p0);
        return ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
            auto&& _m = crate::prelude::get(env->names, n);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& mode = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                auto&& ct = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(({
                    auto local = crate::lower::types::place_stem(rs);
                    auto d = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{local}), crate::lower::types::own(crate::lower::types::local_place(rs, mode, ct))});
                    std::tuple{crate::prelude::push(acc, d), crate::lower::types::bind(en, n, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{local}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), ct}))};
                }));
                goto _done;
            }
            {
                _v.set(std::tuple{acc, en});
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto [pas, env2] = closure_params(lx, env1, ps, pts, true);
    auto v_ = lambda_body_value(lx, env2, body);
    return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, pas, prism_rtl::rc(crate::lower::types::own(v_))})})}))}), ft});
}


prism_rtl::Turn<crate::lower::types::Vl> PlainLambda::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& ps = this->ps;
    const auto& body = this->body;
    const auto& ft = this->ft;
    auto pts = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
        if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(ft)) {
            auto&& xs = prism_rtl::as<crate::lower::model::OutTy::OutFn>(ft).a0;
            _v.set(xs);
            goto _done;
        }
        {
            _v.set(Array<crate::lower::model::OutTy>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto body_1 = body;
    auto env_2 = env;
    auto ft_3 = ft;
    auto lx_4 = lx;
    auto ps_5 = ps;
    return call_then(start_lambda_exprs(body_1), [=](Array<crate::syntax::Expr> lambda_exprs_45702) {
        return call_then(start_read_names(lambda_exprs_45702), [=](Array<Text> read_names_45691) {
            return ({
                auto read = crate::lower::types::with_instances(env_2, read_names_45691);
                auto caps0 = filter(read, [&](const Text& n) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<bool> _v;
                        auto&& _m = crate::prelude::get(env_2->names, n);
                        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                            _v.set(true);
                            goto _done;
                        }
                        {
                            _v.set(false);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                });
                auto caps = append(append(caps0, filter(each(read, [&](const Text& n) { return prism_rtl::cat(n, "#port"); }), [&](const Text& n) { return crate::check::env::has_key(env_2->names, n); })), filter(each(read, [&](const Text& n) { return prism_rtl::cat(n, "#init"); }), [&](const Text& n) { return crate::check::env::has_key(env_2->names, n); }));
                auto [dos, env1] = fold(caps, std::tuple{Array<crate::lower::model::Do>{}, env_2}, [&](const std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>& _p0, const Text& n) {
                    auto&& acc = std::get<0>(_p0);
                    auto&& en = std::get<1>(_p0);
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
                        auto&& _m = crate::prelude::get(env_2->names, n);
                        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                            auto&& rs = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                            auto&& mode = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                            auto&& ct = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                            _v.set(({
                                auto local = crate::lower::types::place_stem(rs);
                                auto d = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{local}), crate::lower::types::own(crate::lower::types::local_place(rs, mode, ct))});
                                std::tuple{crate::prelude::push(acc, d), crate::lower::types::bind(en, n, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{local}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), ct}))};
                            }));
                            goto _done;
                        }
                        {
                            _v.set(std::tuple{acc, en});
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                });
                call_then(start_closure_params(lx_4, env1, ps_5, pts, true), [=](std::tuple<Array<crate::lower::model::Pa>, crate::lower::types::Env> closure_params_46585) {
                return ({
                    auto [pas, env2] = closure_params_46585;
                    call_then(start_lambda_body_value(lx_4, env2, body_1), [=](crate::lower::types::Vl lambda_body_value_46635) {
                    return ({
                        auto v_ = lambda_body_value_46635;
                        (prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, pas, prism_rtl::rc(crate::lower::types::own(v_))})})}))}), ft_3})));
                    });
                });
                });
            });
            });
        });
    });
}


/// `Start PlainLambda, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_plain_lambda(crate::lower::Lx lx, crate::lower::types::Env env, Array<crate::syntax::Pattern_> ps, crate::syntax::LambdaBody body, crate::lower::model::OutTy ft) {
    return prism_rtl::make_rc<PlainLambda>(lx, env, ps, body, ft);
}


/// LambdaParamTys: unbounded fn Lx, Expr, Nat -> [OutTy]
Array<crate::lower::model::OutTy> lambda_param_tys(const crate::lower::Lx& lx, const crate::syntax::Expr& e, const Nat& n) {
    auto ts = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
        auto&& _m = crate::lower::types::out_ty_of(lx, crate::lower::types::peel(crate::lower::type_at(lx, e.span)));
        if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(_m)) {
            auto&& xs = prism_rtl::as<crate::lower::model::OutTy::OutFn>(_m).a0;
            _v.set(xs);
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m)) {
            auto&& a = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
                auto&& _m = a;
                if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(_m)) {
                    auto&& xs = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(_m).a0;
                    _v.set(n == Nat(1u) ? Array(std::vector{a}) : xs);
                    goto _done;
                }
                {
                    _v.set(Array(std::vector{a}));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(Array<crate::lower::model::OutTy>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return (len(ts) == n) && run_to_end(fold_job(ts, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto t = p1;
                (prism_rtl::finished(ok && is_known_ty(t)));
            });
        }));
    }))))
        ? ts
        : Array<crate::lower::model::OutTy>{};
}


prism_rtl::Turn<Array<crate::lower::model::OutTy>> LambdaParamTys::cycle() const {
    const auto& lx = this->lx;
    const auto& e = this->e;
    const auto& n = this->n;
    auto e_1 = e;
    auto lx_2 = lx;
    auto n_3 = n;
    return call_then(crate::lower::types::start_out_ty_of(lx_2, crate::lower::types::peel(crate::lower::type_at(lx_2, e_1.span))), [=](crate::lower::model::OutTy out_ty_of_47039) {
        return ({
            auto ts = ({
                __label__ _done;
                prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
                if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(out_ty_of_47039)) {
                    auto&& xs = prism_rtl::as<crate::lower::model::OutTy::OutFn>(out_ty_of_47039).a0;
                    _v.set(xs);
                    goto _done;
                }
                if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(out_ty_of_47039)) {
                    auto&& a = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(out_ty_of_47039).a0;
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
                        auto&& _m = a;
                        if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(_m)) {
                            auto&& xs = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(_m).a0;
                            _v.set(n_3 == Nat(1u) ? Array(std::vector{a}) : xs);
                            goto _done;
                        }
                        {
                            _v.set(Array(std::vector{a}));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                {
                    _v.set(Array<crate::lower::model::OutTy>{});
                    goto _done;
                }
            _done:
                _v.take();
            });
            (len(ts) == n_3) && run_to_end(fold_job(ts, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto t = p1;
                    (prism_rtl::finished(ok && is_known_ty(t)));
                });
            }));
        }))))
            ? prism_rtl::finished(ts)
            : prism_rtl::finished(Array<crate::lower::model::OutTy>{});
        });
    });
}


/// `Start LambdaParamTys, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::OutTy>> start_lambda_param_tys(crate::lower::Lx lx, crate::syntax::Expr e, Nat n) {
    return prism_rtl::make_rc<LambdaParamTys>(lx, e, n);
}


/// IsKnownTy: unbounded fn OutTy -> Bool
bool is_known_ty(const crate::lower::model::OutTy& t) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutUnknown>(t)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t)) {
        auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t).a0;
        return is_known_ty(x);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t)) {
        auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t).a0;
        return is_known_ty(x);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutArray>(t)) {
        auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t).a0;
        return is_known_ty(x);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRc>(t)) {
        auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t).a0;
        return is_known_ty(x);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(t)) {
        auto&& k = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t).a1;
        return is_known_ty(k) && is_known_ty(v_);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t)) {
        auto&& xs = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t).a0;
        return run_to_end(fold_job(xs, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto x = p1;
                    (prism_rtl::finished(ok && is_known_ty(x)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t)) {
        auto&& xs = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        return run_to_end(fold_job(xs, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto x = p1;
                    (prism_rtl::finished(ok && is_known_ty(x)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(t)) {
        auto&& xs = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t).a0;
        auto&& r = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t).a1;
        return run_to_end(fold_job(xs, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto x = p1;
                    (prism_rtl::finished(ok && is_known_ty(x)));
                });
            }));
        })))) && is_known_ty(r);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t)) {
        auto&& a = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t).a0;
        auto&& b = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t).a1;
        return is_known_ty(a) && is_known_ty(b);
    }
    {
        return true;
    }
}


prism_rtl::Turn<bool> IsKnownTy::cycle() const {
    const auto& t = this->t;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutUnknown>(t) ? prism_rtl::finished(false)
        : prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t) ? ({
        auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t).a0;
        prism_rtl::more(prism_rtl::rc(IsKnownTy(x)));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRes>(t) ? ({
        auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t).a0;
        prism_rtl::more(prism_rtl::rc(IsKnownTy(x)));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutArray>(t) ? ({
        auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t).a0;
        prism_rtl::more(prism_rtl::rc(IsKnownTy(x)));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRc>(t) ? ({
        auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t).a0;
        prism_rtl::more(prism_rtl::rc(IsKnownTy(x)));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutMap>(t) ? ({
        auto&& k = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t).a1;
        ({
        auto k_1 = k;
        auto v__2 = v_;
        call_then(start_is_known_ty(k_1), [=](bool is_known_ty_47549) { return prism_rtl::finished(is_known_ty_47549 && is_known_ty(v__2)); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t) ? ({
        auto&& xs = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t).a0;
        fold_job(xs, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto x = p1;
                (prism_rtl::finished(ok && is_known_ty(x)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t) ? ({
        auto&& xs = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        fold_job(xs, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto x = p1;
                (prism_rtl::finished(ok && is_known_ty(x)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutFn>(t) ? ({
        auto&& xs = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t).a0;
        auto&& r = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t).a1;
        ({
        auto r_1 = r;
        auto xs_2 = xs;
        call_value(fold_job(xs_2, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto x = p1;
                (prism_rtl::finished(ok && is_known_ty(x)));
            });
        }));
    }))), [=](bool fold_47724) { return prism_rtl::finished(fold_47724 && is_known_ty(r_1)); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t) ? ({
        auto&& a = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t).a0;
        auto&& b = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t).a1;
        ({
        auto a_1 = a;
        auto b_2 = b;
        call_then(start_is_known_ty(a_1), [=](bool is_known_ty_47804) { return prism_rtl::finished(is_known_ty_47804 && is_known_ty(b_2)); });
    });
    })
        : prism_rtl::finished(true);
    });
}


/// `Start IsKnownTy, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_known_ty(crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<IsKnownTy>(t);
}


/// JobLambda: unbounded fn Lx, Env, [Pattern], LambdaBody, OutTy, OutTy, Bool -> Vl
crate::lower::types::Vl job_lambda(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const Array<crate::syntax::Pattern_>& ps, const crate::syntax::LambdaBody& body, const crate::lower::model::OutTy& ft, const crate::lower::model::OutTy& a, const bool& enter) {
    auto caps = filter(crate::lower::types::with_instances(env, read_names(lambda_exprs(body))), [&](const Text& n) {
        return ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = crate::prelude::get(env->names, n);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                _v.set(true);
                goto _done;
            }
            {
                _v.set(false);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto [dos, env1] = fold(caps, std::tuple{Array<crate::lower::model::Do>{}, env}, [&](const std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>& _p0, const Text& n) {
        auto&& acc = std::get<0>(_p0);
        auto&& en = std::get<1>(_p0);
        return ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
            auto&& _m = crate::prelude::get(env->names, n);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& mode = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                auto&& ct = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(({
                    auto d = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{crate::lower::types::place_stem(rs)}), crate::lower::types::own(crate::lower::types::local_place(rs, mode, ct))});
                    std::tuple{crate::prelude::push(acc, d), crate::lower::types::bind(en, n, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::types::place_stem(rs)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), ct}))};
                }));
                goto _done;
            }
            {
                _v.set(std::tuple{acc, en});
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto again = fold(caps, Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc, const Text& n) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::model::Do>> _v;
            auto&& _m = crate::prelude::get(env1->names, n);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& ct = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(crate::prelude::push(acc, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{crate::lower::types::place_stem(rs)}), crate::lower::types::own(crate::lower::types::local_place(rs, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), ct))})));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto pts = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
        if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(a)) {
            auto&& ts = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(a).a0;
            _v.set(len(ps) == Nat(1u) ? Array(std::vector{a}) : ts);
            goto _done;
        }
        {
            _v.set(Array(std::vector{a}));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto env1b = only_captured(env1, caps);
    auto pos = run_to_end(each_job(crate::check::errors::range0(len(ps)), ({
        auto ps_1 = ps;
        auto lx_2 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::patterns::PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto ps_1_3 = ps_1;
            auto lx_2_3 = lx_2;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto p_ = or_(index(ps_1_3, i), crate::lower::patterns::dummy_pat());
                (prism_rtl::more(prism_rtl::rc(crate::lower::patterns::RustPat(lx_2_3, p_, binder_ty_of_pattern(lx_2_3, p_), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("p", i, "_")))));
            });
            });
        }));
        });
    })));
    })));
    auto unpack = fold(crate::check::errors::range0(len(pos)), Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc, const Nat& i) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::model::Do>> _v;
            auto&& _m = index(pos, i);
            if (prism_rtl::is_some(_m)) {
                auto&& po = prism_rtl::some_of(_m);
                _v.set(append(crate::prelude::push(acc, crate::lower::model::Do(crate::lower::model::Do::DoLet{po.pa, crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("p", i)})})), each(po.conds, [&](const crate::lower::model::Cc& c) { return cond_as_let(c); })));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(acc);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    auto pos2 = each(crate::check::errors::range0(len(pos)), [&](const Nat& i) {
        return ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::patterns::PatOut> _v;
            auto&& _m = index(pos, i);
            if (prism_rtl::is_some(_m)) {
                auto&& po = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<crate::lower::patterns::PatOut> _v;
                    auto&& _m = or_(index(ps, i), crate::lower::patterns::dummy_pat()).kind;
                    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                        _v.set(({
                            crate::lower::patterns::PatOut this_ = po;
                            this_.binds = each(this_.binds, [&](const std::tuple<Text, crate::lower::types::Bn>& _p0) {
                                auto&& n = std::get<0>(_p0);
                                auto&& b = std::get<1>(_p0);
                                return ({
                                    __label__ _done;
                                    prism_rtl::Slot<std::tuple<Text, crate::lower::types::Bn>> _v;
                                    if (prism_rtl::is<crate::lower::types::Bn::BnLocal>(b)) {
                                        auto&& rs = prism_rtl::as<crate::lower::types::Bn::BnLocal>(b).a0;
                                        auto&& mode = prism_rtl::as<crate::lower::types::Bn::BnLocal>(b).a1;
                                        auto&& bt = prism_rtl::as<crate::lower::types::Bn::BnLocal>(b).a2;
                                        _v.set(std::tuple{n, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{rs, mode, or_(index(pts, i), bt)})});
                                        goto _done;
                                    }
                                    {
                                        _v.set(std::tuple{n, b});
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                });
                            });
                            this_;
                        }));
                        goto _done;
                    }
                    {
                        _v.set(po);
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(crate::lower::patterns::PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    auto env2 = fold(pos2, env1b, [&](const crate::lower::types::Env& en, const crate::lower::patterns::PatOut& po) { return bind_all(en, po.binds); });
    auto names = each(crate::check::errors::range0(len(ps)), [&](const Nat& i) { return prism_rtl::cat("p", i); });
    auto pa = len(ps) == Nat(1u)
        ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("p0")})), a})
        : crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(names, [&](const Text& nm) { return crate::lower::model::Pa(crate::lower::model::Pa::PaBind{nm}); })})), a});
    auto tail0 = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Ex> _v;
        if (prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(body)) {
            auto&& x = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(body).a0;
            _v.set(crate::lower::jobs::tail(lx, env2, x));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(body)) {
            auto&& bl = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(body).a0;
            _v.set(crate::lower::jobs::tail_block(lx, env2, bl));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto tail = len(unpack) == Nat(0u)
        ? tail0
        : crate::lower::model::Ex(crate::lower::model::Ex::XBlock{unpack, prism_rtl::rc(tail0)});
    auto job0 = crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("once_job"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array<crate::lower::model::Pa>{}, prism_rtl::rc(tail)})})});
    auto job = enter
        ? crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("entered"), Array(std::vector{job0})})
        : job0;
    auto call = len(again) == Nat(0u)
        ? job
        : crate::lower::model::Ex(crate::lower::model::Ex::XBlock{again, prism_rtl::rc(job)});
    return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{pa}), prism_rtl::rc(call)})})})), ft}))}), ft});
}


prism_rtl::Turn<crate::lower::types::Vl> JobLambda::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& ps = this->ps;
    const auto& body = this->body;
    const auto& ft = this->ft;
    const auto& a = this->a;
    const auto& enter = this->enter;
    auto a_1 = a;
    auto body_2 = body;
    auto enter_3 = enter;
    auto env_4 = env;
    auto ft_5 = ft;
    auto lx_6 = lx;
    auto ps_7 = ps;
    return call_then(start_lambda_exprs(body_2), [=](Array<crate::syntax::Expr> lambda_exprs_48682) {
        return call_then(start_read_names(lambda_exprs_48682), [=](Array<Text> read_names_48671) {
            return ({
                auto caps = filter(crate::lower::types::with_instances(env_4, read_names_48671), [&](const Text& n) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<bool> _v;
                        auto&& _m = crate::prelude::get(env_4->names, n);
                        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                            _v.set(true);
                            goto _done;
                        }
                        {
                            _v.set(false);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                });
                auto [dos, env1] = fold(caps, std::tuple{Array<crate::lower::model::Do>{}, env_4}, [&](const std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>& _p0, const Text& n) {
                    auto&& acc = std::get<0>(_p0);
                    auto&& en = std::get<1>(_p0);
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
                        auto&& _m = crate::prelude::get(env_4->names, n);
                        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                            auto&& rs = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                            auto&& mode = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                            auto&& ct = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                            _v.set(({
                                auto d = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{crate::lower::types::place_stem(rs)}), crate::lower::types::own(crate::lower::types::local_place(rs, mode, ct))});
                                std::tuple{crate::prelude::push(acc, d), crate::lower::types::bind(en, n, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::types::place_stem(rs)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), ct}))};
                            }));
                            goto _done;
                        }
                        {
                            _v.set(std::tuple{acc, en});
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                });
                auto again = fold(caps, Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc, const Text& n) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<crate::lower::model::Do>> _v;
                        auto&& _m = crate::prelude::get(env1->names, n);
                        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                            auto&& rs = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                            auto&& ct = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                            _v.set(crate::prelude::push(acc, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{crate::lower::types::place_stem(rs)}), crate::lower::types::own(crate::lower::types::local_place(rs, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), ct))})));
                            goto _done;
                        }
                        {
                            _v.set(acc);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                });
                auto pts = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
                    if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(a)) {
                        auto&& ts = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(a).a0;
                        _v.set(len(ps_7) == Nat(1u) ? Array(std::vector{a_1}) : ts);
                        goto _done;
                    }
                    {
                        _v.set(Array(std::vector{a_1}));
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto env1b = only_captured(env1, caps);
                call_value(each_job(crate::check::errors::range0(len(ps_7)), ({
                auto ps_7_8 = ps_7;
                auto lx_6_8 = lx_6;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::patterns::PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                return ({
                    auto ps_7_8_8 = ps_7_8;
                    auto lx_6_8_8 = lx_6_8;
                    entered(once_job([=]() {
                    return ({
                        auto i = p0;
                        ({
                        auto p_ = or_(index(ps_7_8_8, i), crate::lower::patterns::dummy_pat());
                        (prism_rtl::more(prism_rtl::rc(crate::lower::patterns::RustPat(lx_6_8_8, p_, binder_ty_of_pattern(lx_6_8_8, p_), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("p", i, "_")))));
                    });
                    });
                }));
                });
            })));
            })), [=](Array<crate::lower::patterns::PatOut> each_49710) {
                return ({
                    auto pos = each_49710;
                    auto unpack = fold(crate::check::errors::range0(len(pos)), Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc, const Nat& i) {
                        return ({
                            __label__ _done;
                            prism_rtl::Slot<Array<crate::lower::model::Do>> _v;
                            auto&& _m = index(pos, i);
                            if (prism_rtl::is_some(_m)) {
                                auto&& po = prism_rtl::some_of(_m);
                                _v.set(append(crate::prelude::push(acc, crate::lower::model::Do(crate::lower::model::Do::DoLet{po.pa, crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("p", i)})})), each(po.conds, [&](const crate::lower::model::Cc& c) { return cond_as_let(c); })));
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(acc);
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        });
                    });
                    auto pos2 = each(crate::check::errors::range0(len(pos)), [&](const Nat& i) {
                        return ({
                            __label__ _done;
                            prism_rtl::Slot<crate::lower::patterns::PatOut> _v;
                            auto&& _m = index(pos, i);
                            if (prism_rtl::is_some(_m)) {
                                auto&& po = prism_rtl::some_of(_m);
                                _v.set(({
                                    __label__ _done;
                                    prism_rtl::Slot<crate::lower::patterns::PatOut> _v;
                                    auto&& _m = or_(index(ps_7, i), crate::lower::patterns::dummy_pat()).kind;
                                    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                                        _v.set(({
                                            crate::lower::patterns::PatOut this_ = po;
                                            this_.binds = each(this_.binds, [&](const std::tuple<Text, crate::lower::types::Bn>& _p0) {
                                                auto&& n = std::get<0>(_p0);
                                                auto&& b = std::get<1>(_p0);
                                                return ({
                                                    __label__ _done;
                                                    prism_rtl::Slot<std::tuple<Text, crate::lower::types::Bn>> _v;
                                                    if (prism_rtl::is<crate::lower::types::Bn::BnLocal>(b)) {
                                                        auto&& rs = prism_rtl::as<crate::lower::types::Bn::BnLocal>(b).a0;
                                                        auto&& mode = prism_rtl::as<crate::lower::types::Bn::BnLocal>(b).a1;
                                                        auto&& bt = prism_rtl::as<crate::lower::types::Bn::BnLocal>(b).a2;
                                                        _v.set(std::tuple{n, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{rs, mode, or_(index(pts, i), bt)})});
                                                        goto _done;
                                                    }
                                                    {
                                                        _v.set(std::tuple{n, b});
                                                        goto _done;
                                                    }
                                                _done:
                                                    _v.take();
                                                });
                                            });
                                            this_;
                                        }));
                                        goto _done;
                                    }
                                    {
                                        _v.set(po);
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                }));
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(crate::lower::patterns::PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}});
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        });
                    });
                    auto env2 = fold(pos2, env1b, [&](const crate::lower::types::Env& en, const crate::lower::patterns::PatOut& po) { return bind_all(en, po.binds); });
                    auto names = each(crate::check::errors::range0(len(ps_7)), [&](const Nat& i) { return prism_rtl::cat("p", i); });
                    auto pa = len(ps_7) == Nat(1u)
                        ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("p0")})), a_1})
                        : crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(names, [&](const Text& nm) { return crate::lower::model::Pa(crate::lower::model::Pa::PaBind{nm}); })})), a_1});
                    auto tail0 = ({
                        __label__ _done;
                        prism_rtl::Slot<crate::lower::model::Ex> _v;
                        if (prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(body)) {
                            auto&& x = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(body).a0;
                            _v.set(crate::lower::jobs::tail(lx_6, env2, x));
                            goto _done;
                        }
                        if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(body)) {
                            auto&& bl = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(body).a0;
                            _v.set(crate::lower::jobs::tail_block(lx_6, env2, bl));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    auto tail = len(unpack) == Nat(0u)
                        ? tail0
                        : crate::lower::model::Ex(crate::lower::model::Ex::XBlock{unpack, prism_rtl::rc(tail0)});
                    auto job0 = crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("once_job"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array<crate::lower::model::Pa>{}, prism_rtl::rc(tail)})})});
                    auto job = enter_3
                        ? crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("entered"), Array(std::vector{job0})})
                        : job0;
                    auto call = len(again) == Nat(0u)
                        ? job
                        : crate::lower::model::Ex(crate::lower::model::Ex::XBlock{again, prism_rtl::rc(job)});
                    (prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{pa}), prism_rtl::rc(call)})})})), ft_5}))}), ft_5})));
                });
            });
            });
        });
    });
}


/// `Start JobLambda, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_job_lambda(crate::lower::Lx lx, crate::lower::types::Env env, Array<crate::syntax::Pattern_> ps, crate::syntax::LambdaBody body, crate::lower::model::OutTy ft, crate::lower::model::OutTy a, bool enter) {
    return prism_rtl::make_rc<JobLambda>(lx, env, ps, body, ft, a, enter);
}


/// EntersLambda: fn Lx, Expr -> Bool
bool enters_lambda(const crate::lower::Lx& lx, const crate::syntax::Expr& e) {
    auto&& _m = crate::lower::types::peel(crate::lower::type_at(lx, e.span));
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CBound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0)) {
        return false;
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// OnlyCaptured: fn Env, [Text] -> Env
crate::lower::types::Env only_captured(const crate::lower::types::Env& env, const Array<Text>& caps) {
    crate::lower::types::Env this_ = env;
    this_.names = fold(keys(env->names), Map<Text, crate::lower::types::Bn>{}, [&](const Map<Text, crate::lower::types::Bn>& m, const Text& k) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, crate::lower::types::Bn>> _v;
            auto&& _m = crate::prelude::get(env->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& mode = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                auto&& t = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(crate::check::types::has_text(caps, k) || (mode == crate::lower::types::Holding(crate::lower::types::Holding::Owned{}))
                    ? insert(m, k, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{rs, mode, t}))
                    : m);
                goto _done;
            }
            if (prism_rtl::is_some(_m)) {
                auto&& b = prism_rtl::some_of(_m);
                _v.set(insert(m, k, b));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(m);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    return this_;
}


/// CondAsLet: fn Cc -> Do
crate::lower::model::Do cond_as_let(const crate::lower::model::Cc& cc0) {
    if (prism_rtl::is<crate::lower::model::Cc::CcLet>(cc0)) {
        auto&& pa = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc0).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc0).a1;
        return crate::lower::model::Do(crate::lower::model::Do::DoLet{pa, x});
    }
    if (prism_rtl::is<crate::lower::model::Cc::CcIf>(cc0)) {
        auto&& x = prism_rtl::as<crate::lower::model::Cc::CcIf>(cc0).a0;
        return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})});
    }
    prism_rtl::unreachable("no arm matched");
}


/// LambdaArg: unbounded fn Lx, Env, [Pattern], LambdaBody, [OutTy] -> Ex
crate::lower::model::Ex lambda_arg(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const Array<crate::syntax::Pattern_>& ps, const crate::syntax::LambdaBody& body, const Array<crate::lower::model::OutTy>& pts) {
    auto [pas, env2] = closure_params(lx, env, ps, pts, len(pts) > Nat(0u));
    auto v_ = lambda_body_value(lx, env2, body);
    return crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, pas, prism_rtl::rc(crate::lower::types::own(v_))});
}


prism_rtl::Turn<crate::lower::model::Ex> LambdaArg::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& ps = this->ps;
    const auto& body = this->body;
    const auto& pts = this->pts;
    auto body_1 = body;
    auto env_2 = env;
    auto lx_3 = lx;
    auto ps_4 = ps;
    auto pts_5 = pts;
    return call_then(start_closure_params(lx_3, env_2, ps_4, pts_5, len(pts_5) > Nat(0u)), [=](std::tuple<Array<crate::lower::model::Pa>, crate::lower::types::Env> closure_params_52450) {
        return ({
            auto [pas, env2] = closure_params_52450;
            call_then(start_lambda_body_value(lx_3, env2, body_1), [=](crate::lower::types::Vl lambda_body_value_52508) {
            return ({
                auto v_ = lambda_body_value_52508;
                (prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, pas, prism_rtl::rc(crate::lower::types::own(v_))})));
            });
        });
        });
    });
}


/// `Start LambdaArg, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_lambda_arg(crate::lower::Lx lx, crate::lower::types::Env env, Array<crate::syntax::Pattern_> ps, crate::syntax::LambdaBody body, Array<crate::lower::model::OutTy> pts) {
    return prism_rtl::make_rc<LambdaArg>(lx, env, ps, body, pts);
}


/// LambdaBodyValue: unbounded fn Lx, Env, LambdaBody -> Vl
crate::lower::types::Vl lambda_body_value(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::LambdaBody& lambda_body2) {
    if (prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(lambda_body2)) {
        auto&& x = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(lambda_body2).a0;
        return value_of(lx, env, x);
    }
    if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(lambda_body2)) {
        auto&& b = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(lambda_body2).a0;
        return block_value(lx, env, b);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::types::Vl> LambdaBodyValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& lambda_body2 = this->lambda_body2;
    return ({
        prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(lambda_body2) ? ({
        auto&& x = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(lambda_body2).a0;
        prism_rtl::more(prism_rtl::rc(ValueOf(lx, env, x)));
    })
        : prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(lambda_body2) ? ({
        auto&& b = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(lambda_body2).a0;
        prism_rtl::more(prism_rtl::rc(BlockValue(lx, env, b)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start LambdaBodyValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_lambda_body_value(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::LambdaBody lambda_body2) {
    return prism_rtl::make_rc<LambdaBodyValue>(lx, env, lambda_body2);
}


/// ClosureParams: unbounded fn Lx, Env, [Pattern], [OutTy], Bool -> (([Pa], Env))
std::tuple<Array<crate::lower::model::Pa>, crate::lower::types::Env> closure_params(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const Array<crate::syntax::Pattern_>& ps, const Array<crate::lower::model::OutTy>& pts, const bool& typed) {
    return run_to_end(fold_job(crate::check::errors::range0(len(ps)), std::tuple{Array<crate::lower::model::Pa>{}, env}, ({
        auto ps_1 = ps;
        auto lx_2 = lx;
        auto typed_3 = typed;
        auto pts_4 = pts;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Pa>, crate::lower::types::Env>>(std::tuple<std::tuple<Array<crate::lower::model::Pa>, crate::lower::types::Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::lower::model::Pa>, crate::lower::types::Env>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto ps_1_5 = ps_1;
            auto lx_2_5 = lx_2;
            auto typed_3_5 = typed_3;
            auto pts_4_5 = pts_4;
            entered(once_job([=]() {
            return ({
                auto [acc, en] = p0;
                auto i = p1;
                ({
                auto&& _m = index(ps_1_5, i);
                prism_rtl::is_some(_m) ? ({
                auto&& p_ = prism_rtl::some_of(_m);
                call_then(crate::lower::patterns::start_rust_pat(lx_2_5, p_, binder_ty_of_pattern(lx_2_5, p_), crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), prism_rtl::cat("a", p_.span.start)), [=](crate::lower::patterns::PatOut rust_pat_53071) {
                return ({
                    auto po = rust_pat_53071;
                    auto en2 = bind_all(en, po.binds);
                    auto pa = typed_3_5
                        ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(po.pa), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(or_(index(pts_4_5, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{Text::lit("a parameter")})))})})
                        : po.pa;
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc, pa), en2}));
                });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{acc, en})
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Array<crate::lower::model::Pa>, crate::lower::types::Env>> ClosureParams::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& ps = this->ps;
    const auto& pts = this->pts;
    const auto& typed = this->typed;
    return fold_job(crate::check::errors::range0(len(ps)), std::tuple{Array<crate::lower::model::Pa>{}, env}, ({
        auto ps_1 = ps;
        auto lx_2 = lx;
        auto typed_3 = typed;
        auto pts_4 = pts;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Pa>, crate::lower::types::Env>>(std::tuple<std::tuple<Array<crate::lower::model::Pa>, crate::lower::types::Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::lower::model::Pa>, crate::lower::types::Env>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto ps_1_5 = ps_1;
            auto lx_2_5 = lx_2;
            auto typed_3_5 = typed_3;
            auto pts_4_5 = pts_4;
            entered(once_job([=]() {
            return ({
                auto [acc, en] = p0;
                auto i = p1;
                ({
                auto&& _m = index(ps_1_5, i);
                prism_rtl::is_some(_m) ? ({
                auto&& p_ = prism_rtl::some_of(_m);
                call_then(crate::lower::patterns::start_rust_pat(lx_2_5, p_, binder_ty_of_pattern(lx_2_5, p_), crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), prism_rtl::cat("a", p_.span.start)), [=](crate::lower::patterns::PatOut rust_pat_53071) {
                return ({
                    auto po = rust_pat_53071;
                    auto en2 = bind_all(en, po.binds);
                    auto pa = typed_3_5
                        ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(po.pa), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(or_(index(pts_4_5, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{Text::lit("a parameter")})))})})
                        : po.pa;
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc, pa), en2}));
                });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{acc, en})
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start ClosureParams, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Pa>, crate::lower::types::Env>> start_closure_params(crate::lower::Lx lx, crate::lower::types::Env env, Array<crate::syntax::Pattern_> ps, Array<crate::lower::model::OutTy> pts, bool typed) {
    return prism_rtl::make_rc<ClosureParams>(lx, env, ps, pts, typed);
}


/// BindAll: fn Env, [((Text, Bn))] -> Env
crate::lower::types::Env bind_all(const crate::lower::types::Env& env, const Array<std::tuple<Text, crate::lower::types::Bn>>& bs) {
    return fold(bs, env, [&](const crate::lower::types::Env& en, const std::tuple<Text, crate::lower::types::Bn>& _p1) {
        auto&& n = std::get<0>(_p1);
        auto&& b = std::get<1>(_p1);
        return crate::lower::types::bind(en, n, b);
    });
}


/// BinderTyOfPattern: fn Lx, Pattern -> Ty
crate::check::types::Ty binder_ty_of_pattern(const crate::lower::Lx& lx, const crate::syntax::Pattern_& p_) {
    auto&& _m = p_.kind;
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        return crate::lower::binder_ty(lx, n.span);
    }
    {
        return crate::lower::type_at(lx, p_.span);
    }
}


/// IfValue: unbounded fn Lx, Env, Cond, Block, ?Block, OutTy -> Vl
crate::lower::types::Vl if_value(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Cond& c, const crate::syntax::Block& then_b, const std::optional<crate::syntax::Block>& else_b_opt, const crate::lower::model::OutTy& t) {
    auto else_v = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Ex> _v;
        if (prism_rtl::is_some(else_b_opt)) {
            auto&& b = prism_rtl::some_of(else_b_opt);
            _v.set(crate::lower::node_::def::own_as(t, block_value(lx, env, b)));
            goto _done;
        }
        if (prism_rtl::is_none(else_b_opt)) {
            _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c)) {
        auto&& x = prism_rtl::as<crate::syntax::Cond::CondExpr>(c).a0;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XIf{prism_rtl::rc(crate::lower::types::as_bool(value_of(lx, env, x))), prism_rtl::rc(crate::lower::node_::def::own_as(t, block_value(lx, env, then_b))), prism_rtl::rc(else_v)}), t});
    }
    if (prism_rtl::is<crate::syntax::Cond::CondBind>(c)) {
        auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a0;
        auto&& x = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a1;
        auto&& g_opt = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a2;
        auto sv = value_of(lx, env, x);
        auto po = crate::lower::patterns::rust_pat(lx, p_, crate::lower::type_at(lx, x.span), crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), prism_rtl::cat("c", x.span.start));
        auto env2 = bind_all(env, po.binds);
        auto guard = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::model::Cc>> _v;
            auto&& _m = g_opt;
            if (prism_rtl::is_some(_m)) {
                auto&& ge = prism_rtl::some_of(_m);
                _v.set(Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::types::as_bool(value_of(lx, env2, ge))})}));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<crate::lower::model::Cc>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto arm = crate::lower::model::XArm{.pat = po.pa, .conds = append(po.conds, guard), .body = crate::lower::node_::def::own_as(t, block_value(lx, env2, then_b))};
        auto other = crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .body = else_v};
        return arms_value(crate::lower::types::ref_(sv), Array(std::vector{arm, other}), prism_rtl::cat("c", x.span.start), t);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::types::Vl> IfValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& c = this->c;
    const auto& then_b = this->then_b;
    const auto& else_b_opt = this->else_b_opt;
    const auto& t = this->t;
    auto else_v = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Ex> _v;
        if (prism_rtl::is_some(else_b_opt)) {
            auto&& b = prism_rtl::some_of(else_b_opt);
            _v.set(crate::lower::node_::def::own_as(t, block_value(lx, env, b)));
            goto _done;
        }
        if (prism_rtl::is_none(else_b_opt)) {
            _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ({
        prism_rtl::is<crate::syntax::Cond::CondExpr>(c) ? ({
        auto&& x = prism_rtl::as<crate::syntax::Cond::CondExpr>(c).a0;
        ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto t_3 = t;
        auto then_b_4 = then_b;
        auto x_5 = x;
        call_then(start_value_of(lx_2, env_1, x_5), [=](crate::lower::types::Vl value_of_53977) { return call_then(start_block_value(lx_2, env_1, then_b_4), [=](crate::lower::types::Vl block_value_54010) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XIf{prism_rtl::rc(crate::lower::types::as_bool(value_of_53977)), prism_rtl::rc(crate::lower::node_::def::own_as(t_3, block_value_54010)), prism_rtl::rc(else_v)}), t_3})); }); });
    });
    })
        : prism_rtl::is<crate::syntax::Cond::CondBind>(c) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a0;
        auto&& x = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a1;
        auto&& g_opt = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a2;
        ({
        auto g_opt_1 = g_opt;
        auto c_2 = c;
        auto env_3 = env;
        auto lx_4 = lx;
        auto p__5 = p_;
        auto t_6 = t;
        auto then_b_7 = then_b;
        auto x_8 = x;
        call_then(start_value_of(lx_4, env_3, x_8), [=](crate::lower::types::Vl value_of_54097) {
        return ({
            auto sv = value_of_54097;
            call_then(crate::lower::patterns::start_rust_pat(lx_4, p__5, crate::lower::type_at(lx_4, x_8.span), crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), prism_rtl::cat("c", x_8.span.start)), [=](crate::lower::patterns::PatOut rust_pat_54137) {
            return ({
                auto po = rust_pat_54137;
                auto env2 = bind_all(env_3, po.binds);
                auto guard = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::lower::model::Cc>> _v;
                    if (prism_rtl::is_some(g_opt)) {
                        auto&& ge = prism_rtl::some_of(g_opt);
                        _v.set(Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::types::as_bool(value_of(lx_4, env2, ge))})}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(g_opt)) {
                        _v.set(Array<crate::lower::model::Cc>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                call_then(start_block_value(lx_4, env2, then_b_7), [=](crate::lower::types::Vl block_value_54452) {
                return ({
                    auto arm = crate::lower::model::XArm{.pat = po.pa, .conds = append(po.conds, guard), .body = crate::lower::node_::def::own_as(t_6, block_value_54452)};
                    auto other = crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .body = else_v};
                    (prism_rtl::finished(arms_value(crate::lower::types::ref_(sv), Array(std::vector{arm, other}), prism_rtl::cat("c", x_8.span.start), t_6)));
                });
            });
            });
        });
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start IfValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_if_value(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Cond c, crate::syntax::Block then_b, std::optional<crate::syntax::Block> else_b_opt, crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<IfValue>(lx, env, c, then_b, else_b_opt, t);
}


/// ArmsValue: fn Ex, [XArm], Text, OutTy -> Vl
crate::lower::types::Vl arms_value(const crate::lower::model::Ex& scrut, const Array<crate::lower::model::XArm>& arms, const Text& label, const crate::lower::model::OutTy& t) {
    auto chain = fold(arms, false, [&](const bool& f, const crate::lower::model::XArm& a) { return f || fold(a.conds, false, [&](const bool& f2, const crate::lower::model::Cc& c) { return f2 || is_let_cond(c); }); });
    auto guarded = fold(arms, false, [&](const bool& f, const crate::lower::model::XArm& a) { return f || (len(a.conds) > Nat(0u)); });
    return chain
        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XChain{label, prism_rtl::rc(scrut), arms, t}), t})
        : crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XMatch{prism_rtl::rc(scrut), arms, guarded, t}), t});
}


/// IsLetCond: fn Cc -> Bool
bool is_let_cond(const crate::lower::model::Cc& cc0) {
    if (prism_rtl::is<crate::lower::model::Cc::CcLet>(cc0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Cc::CcIf>(cc0)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// MatchValue: unbounded fn Lx, Env, Expr, [Arm], OutTy, Range -> Vl
crate::lower::types::Vl match_value(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& s, const Array<crate::syntax::Arm>& arms, const crate::lower::model::OutTy& t, const crate::syntax::Range& span) {
    auto sv = value_of(lx, env, s);
    auto sty = crate::lower::type_at(lx, s.span);
    auto label = prism_rtl::cat("m", span.start);
    auto by_ref = run_to_end(each_job(crate::check::errors::range0(len(arms)), ({
        auto lx_1 = lx;
        auto arms_2 = arms;
        auto sty_3 = sty;
        auto label_4 = label;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::patterns::PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto lx_1_5 = lx_1;
            auto arms_2_5 = arms_2;
            auto sty_3_5 = sty_3;
            auto label_4_5 = label_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(ArmPat(lx_1_5, or_(index(arms_2_5, i), dummy_arm()).pattern, sty_3_5, crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), prism_rtl::cat(label_4_5, "_", i)))));
            });
        }));
        });
    })));
    })));
    auto chain = fold(by_ref, false, [&](const bool& f, const crate::lower::patterns::PatOut& po) { return f || fold(po.conds, false, [&](const bool& f2, const crate::lower::model::Cc& c) { return f2 || is_let_cond(c); }); });
    auto owned = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<crate::lower::types::Vl::VlOwned>(sv)) {
            _v.set(!chain);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto pats = owned
        ? run_to_end(each_job(crate::check::errors::range0(len(arms)), ({
        auto lx_1 = lx;
        auto arms_2 = arms;
        auto sty_3 = sty;
        auto label_4 = label;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::patterns::PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto lx_1_5 = lx_1;
            auto arms_2_5 = arms_2;
            auto sty_3_5 = sty_3;
            auto label_4_5 = label_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(ArmPat(lx_1_5, or_(index(arms_2_5, i), dummy_arm()).pattern, sty_3_5, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat(label_4_5, "_", i)))));
            });
        }));
        });
    })));
    })))
        : by_ref;
    auto xarms = run_to_end(each_job(crate::check::errors::range0(len(arms)), ({
        auto arms_1 = arms;
        auto pats_2 = pats;
        auto env_3 = env;
        auto lx_4 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::XArm>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto arms_1_5 = arms_1;
            auto pats_2_5 = pats_2;
            auto env_3_5 = env_3;
            auto lx_4_5 = lx_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto arm = or_(index(arms_1_5, i), dummy_arm());
                auto po = or_(index(pats_2_5, i), crate::lower::patterns::PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}});
                auto env2 = bind_all(env_3_5, po.binds);
                auto guard = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::lower::model::Cc>> _v;
                    auto&& _m = arm.guard;
                    if (prism_rtl::is_some(_m)) {
                        auto&& ge = prism_rtl::some_of(_m);
                        _v.set(Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::types::as_bool(value_of(lx_4_5, env2, ge))})}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Array<crate::lower::model::Cc>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                call_then(start_block_value(lx_4_5, env2, arm.body), [=](crate::lower::types::Vl block_value_56344) { return prism_rtl::finished(crate::lower::model::XArm{.pat = po.pa, .conds = append(po.conds, guard), .body = crate::lower::types::own(block_value_56344)}); });
            });
            });
        }));
        });
    })));
    })));
    auto scrut = owned ? crate::lower::types::own(sv) : crate::lower::types::ref_(sv);
    return arms_value(scrut, xarms, label, t);
}


prism_rtl::Turn<crate::lower::types::Vl> MatchValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& s = this->s;
    const auto& arms = this->arms;
    const auto& t = this->t;
    const auto& span = this->span;
    auto arms_1 = arms;
    auto env_2 = env;
    auto lx_3 = lx;
    auto s_4 = s;
    auto span_5 = span;
    auto t_6 = t;
    return call_then(start_value_of(lx_3, env_2, s_4), [=](crate::lower::types::Vl value_of_55429) {
        return ({
            auto sv = value_of_55429;
            auto sty = crate::lower::type_at(lx_3, s_4.span);
            auto label = prism_rtl::cat("m", span_5.start);
            call_value(each_job(crate::check::errors::range0(len(arms_1)), ({
            auto lx_3_7 = lx_3;
            auto arms_1_7 = arms_1;
            auto sty_7 = sty;
            auto label_8 = label;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::patterns::PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto lx_3_7_9 = lx_3_7;
                auto arms_1_7_9 = arms_1_7;
                auto sty_7_9 = sty_7;
                auto label_8_9 = label_8;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    (prism_rtl::more(prism_rtl::rc(ArmPat(lx_3_7_9, or_(index(arms_1_7_9, i), dummy_arm()).pattern, sty_7_9, crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), prism_rtl::cat(label_8_9, "_", i)))));
                });
            }));
            });
        })));
        })), [=](Array<crate::lower::patterns::PatOut> each_55528) {
            return ({
                auto by_ref = each_55528;
                auto chain = fold(by_ref, false, [&](const bool& f, const crate::lower::patterns::PatOut& po) { return f || fold(po.conds, false, [&](const bool& f2, const crate::lower::model::Cc& c) { return f2 || is_let_cond(c); }); });
                auto owned = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    if (prism_rtl::is<crate::lower::types::Vl::VlOwned>(sv)) {
                        _v.set(!chain);
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto pats = owned
                    ? run_to_end(each_job(crate::check::errors::range0(len(arms_1)), ({
                    auto lx_3_7 = lx_3;
                    auto arms_1_7 = arms_1;
                    auto sty_7 = sty;
                    auto label_8 = label;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::patterns::PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                    return ({
                        auto lx_3_7_9 = lx_3_7;
                        auto arms_1_7_9 = arms_1_7;
                        auto sty_7_9 = sty_7;
                        auto label_8_9 = label_8;
                        entered(once_job([=]() {
                        return ({
                            auto i = p0;
                            (prism_rtl::more(prism_rtl::rc(ArmPat(lx_3_7_9, or_(index(arms_1_7_9, i), dummy_arm()).pattern, sty_7_9, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat(label_8_9, "_", i)))));
                        });
                    }));
                    });
                })));
                })))
                    : by_ref;
                call_value(each_job(crate::check::errors::range0(len(arms_1)), ({
                auto arms_1_7 = arms_1;
                auto pats_7 = pats;
                auto env_2_8 = env_2;
                auto lx_3_8 = lx_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::XArm>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                return ({
                    auto arms_1_7_8 = arms_1_7;
                    auto pats_7_8 = pats_7;
                    auto env_2_8_8 = env_2_8;
                    auto lx_3_8_8 = lx_3_8;
                    entered(once_job([=]() {
                    return ({
                        auto i = p0;
                        ({
                        auto arm = or_(index(arms_1_7_8, i), dummy_arm());
                        auto po = or_(index(pats_7_8, i), crate::lower::patterns::PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}});
                        auto env2 = bind_all(env_2_8_8, po.binds);
                        auto guard = ({
                            __label__ _done;
                            prism_rtl::Slot<Array<crate::lower::model::Cc>> _v;
                            auto&& _m = arm.guard;
                            if (prism_rtl::is_some(_m)) {
                                auto&& ge = prism_rtl::some_of(_m);
                                _v.set(Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::types::as_bool(value_of(lx_3_8_8, env2, ge))})}));
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(Array<crate::lower::model::Cc>{});
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        });
                        call_then(start_block_value(lx_3_8_8, env2, arm.body), [=](crate::lower::types::Vl block_value_56344) { return prism_rtl::finished(crate::lower::model::XArm{.pat = po.pa, .conds = append(po.conds, guard), .body = crate::lower::types::own(block_value_56344)}); });
                    });
                    });
                }));
                });
            })));
            })), [=](Array<crate::lower::model::XArm> each_55974) {
                return ({
                    auto xarms = each_55974;
                    auto scrut = owned ? crate::lower::types::own(sv) : crate::lower::types::ref_(sv);
                    (prism_rtl::finished(arms_value(scrut, xarms, label, t_6)));
                });
            });
            });
        });
        });
    });
}


/// `Start MatchValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_match_value(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr s, Array<crate::syntax::Arm> arms, crate::lower::model::OutTy t, crate::syntax::Range span) {
    return prism_rtl::make_rc<MatchValue>(lx, env, s, arms, t, span);
}


/// let dummyArm
crate::syntax::Arm dummy_arm() {
    return crate::syntax::Arm{.pattern = std::optional<crate::syntax::Pattern_>{}, .guard = std::optional<crate::syntax::Expr>{}, .body = crate::syntax::Block{.stmts = Array<crate::syntax::Stmt>{}, .inline_ = true, .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}}, .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// ArmPat: unbounded fn Lx, ?Pattern, Ty, Holding, Text -> PatOut
crate::lower::patterns::PatOut arm_pat(const crate::lower::Lx& lx, const std::optional<crate::syntax::Pattern_>& opt1, const crate::check::types::Ty& ty, const crate::lower::types::Holding& mode, const Text& fresh) {
    if (prism_rtl::is_some(opt1)) {
        auto&& p_ = prism_rtl::some_of(opt1);
        return crate::lower::patterns::rust_pat(lx, p_, ty, mode, fresh);
    }
    if (prism_rtl::is_none(opt1)) {
        return crate::lower::patterns::PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::patterns::PatOut> ArmPat::cycle() const {
    const auto& lx = this->lx;
    const auto& opt1 = this->opt1;
    const auto& ty = this->ty;
    const auto& mode = this->mode;
    const auto& fresh = this->fresh;
    return ({
        prism_rtl::is_some(opt1) ? ({
        auto&& p_ = prism_rtl::some_of(opt1);
        prism_rtl::more(prism_rtl::rc(crate::lower::patterns::RustPat(lx, p_, ty, mode, fresh)));
    })
        : prism_rtl::is_none(opt1) ? prism_rtl::finished(crate::lower::patterns::PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ArmPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::patterns::PatOut> start_arm_pat(crate::lower::Lx lx, std::optional<crate::syntax::Pattern_> opt1, crate::check::types::Ty ty, crate::lower::types::Holding mode, Text fresh) {
    return prism_rtl::make_rc<ArmPat>(lx, opt1, ty, mode, fresh);
}


/// BlockValue: unbounded fn Lx, Env, Block -> Vl
crate::lower::types::Vl block_value(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Block& b) {
    return is_given_block(b.stmts)
        ? crate::lower::templates::given_value(lx, env, b, block_ty(lx, b), b.span)
        : plain_block_value(lx, env, b);
}


prism_rtl::Turn<crate::lower::types::Vl> BlockValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& b = this->b;
    return is_given_block(b.stmts)
        ? ({
        auto b_1 = b;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(start_block_ty(lx_3, b_1), [=](crate::lower::model::OutTy block_ty_57071) { return prism_rtl::more(prism_rtl::rc(crate::lower::templates::GivenValue(lx_3, env_2, b_1, block_ty_57071, b_1.span))); });
    })
        : prism_rtl::more(prism_rtl::rc(PlainBlockValue(lx, env, b)));
}


/// `Start BlockValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_block_value(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Block b) {
    return prism_rtl::make_rc<BlockValue>(lx, env, b);
}


/// IsGivenBlock: fn [Stmt] -> Bool
bool is_given_block(const Array<crate::syntax::Stmt>& stmts) {
    return fold(stmts, false, [&](const bool& f, const crate::syntax::Stmt& s) { return f || is_guardish(s); });
}


/// IsGuardish: fn Stmt -> Bool
bool is_guardish(const crate::syntax::Stmt& s) {
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SRequire>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SForbid>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// BlockTy: unbounded fn Lx, Block -> OutTy
crate::lower::model::OutTy block_ty(const crate::lower::Lx& lx, const crate::syntax::Block& b) {
    auto&& _m = or_(index(b.stmts, crate::syntax::lexer::chars::dec(len(b.stmts))), dummy_stmt_l()).kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        return crate::lower::types::out_ty_of(lx, crate::lower::types::peel(crate::lower::type_at(lx, x.span)));
    }
    {
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{});
    }
}


prism_rtl::Turn<crate::lower::model::OutTy> BlockTy::cycle() const {
    const auto& lx = this->lx;
    const auto& b = this->b;
    return ({
        auto&& _m = or_(index(b.stmts, crate::syntax::lexer::chars::dec(len(b.stmts))), dummy_stmt_l()).kind;
        prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        prism_rtl::more(prism_rtl::rc(crate::lower::types::OutTyOf(lx, crate::lower::types::peel(crate::lower::type_at(lx, x.span)))));
    })
        : prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
    });
}


/// `Start BlockTy, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::OutTy> start_block_ty(crate::lower::Lx lx, crate::syntax::Block b) {
    return prism_rtl::make_rc<BlockTy>(lx, b);
}


/// PlainBlockValue: unbounded fn Lx, Env, Block -> Vl
crate::lower::types::Vl plain_block_value(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Block& b) {
    auto n = len(b.stmts);
    auto [dos, env2, last_opt] = run_to_end(fold_job(crate::check::errors::range0(n), std::tuple{Array<crate::lower::model::Do>{}, env, std::optional<crate::lower::types::Vl>{}}, ({
        auto b_1 = b;
        auto n_2 = n;
        auto lx_3 = lx;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env, std::optional<crate::lower::types::Vl>>>(std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env, std::optional<crate::lower::types::Vl>>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env, std::optional<crate::lower::types::Vl>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto b_1_4 = b_1;
            auto n_2_4 = n_2;
            auto lx_3_4 = lx_3;
            entered(once_job([=]() {
            return ({
                auto [acc, en, lv_opt] = p0;
                auto i = p1;
                ({
                auto s = or_(index(b_1_4.stmts, i), dummy_stmt_l());
                (i + Nat(1u)) == n_2_4
                ? ({
                auto&& _m = s.kind;
                prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
                auto&& x = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                prism_rtl::finished(std::tuple{acc, en, std::optional(value_of(lx_3_4, en, x))});
            })
                : call_then(start_block_stmt(lx_3_4, en, s), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> block_stmt_58113) {
                return ({
                    auto [more, en2] = block_stmt_58113;
                    (prism_rtl::finished(std::tuple{append(acc, more), en2, std::optional<crate::lower::types::Vl>{}}));
                });
            });
            })
                : call_then(start_block_stmt(lx_3_4, en, s), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> block_stmt_58228) {
                return ({
                    auto [more, en2] = block_stmt_58228;
                    (prism_rtl::finished(std::tuple{append(acc, more), en2, lv_opt}));
                });
            });
            });
            });
        }));
        });
    }));
    })));
    auto last = or_(last_opt, crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}));
    return len(dos) == Nat(0u)
        ? last
        : crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos, prism_rtl::rc(crate::lower::types::own(last))}), crate::lower::types::value_ty(last)});
}


prism_rtl::Turn<crate::lower::types::Vl> PlainBlockValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& b = this->b;
    auto n = len(b.stmts);
    auto b_1 = b;
    auto env_2 = env;
    auto lx_3 = lx;
    return call_value(fold_job(crate::check::errors::range0(n), std::tuple{Array<crate::lower::model::Do>{}, env_2, std::optional<crate::lower::types::Vl>{}}, ({
        auto b_1_4 = b_1;
        auto n_4 = n;
        auto lx_3_5 = lx_3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env, std::optional<crate::lower::types::Vl>>>(std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env, std::optional<crate::lower::types::Vl>>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env, std::optional<crate::lower::types::Vl>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto b_1_4_5 = b_1_4;
            auto n_4_5 = n_4;
            auto lx_3_5_5 = lx_3_5;
            entered(once_job([=]() {
            return ({
                auto [acc, en, lv_opt] = p0;
                auto i = p1;
                ({
                auto s = or_(index(b_1_4_5.stmts, i), dummy_stmt_l());
                (i + Nat(1u)) == n_4_5
                ? ({
                auto&& _m = s.kind;
                prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
                auto&& x = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                prism_rtl::finished(std::tuple{acc, en, std::optional(value_of(lx_3_5_5, en, x))});
            })
                : call_then(start_block_stmt(lx_3_5_5, en, s), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> block_stmt_58113) {
                return ({
                    auto [more, en2] = block_stmt_58113;
                    (prism_rtl::finished(std::tuple{append(acc, more), en2, std::optional<crate::lower::types::Vl>{}}));
                });
            });
            })
                : call_then(start_block_stmt(lx_3_5_5, en, s), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> block_stmt_58228) {
                return ({
                    auto [more, en2] = block_stmt_58228;
                    (prism_rtl::finished(std::tuple{append(acc, more), en2, lv_opt}));
                });
            });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env, std::optional<crate::lower::types::Vl>> fold_57859) {
        return ({
            auto [dos, env2, last_opt] = fold_57859;
            auto last = or_(last_opt, crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}));
            len(dos) == Nat(0u)
            ? prism_rtl::finished(last)
            : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos, prism_rtl::rc(crate::lower::types::own(last))}), crate::lower::types::value_ty(last)}));
        });
    });
}


/// `Start PlainBlockValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_plain_block_value(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Block b) {
    return prism_rtl::make_rc<PlainBlockValue>(lx, env, b);
}


/// let dummyStmtL
crate::syntax::Stmt dummy_stmt_l() {
    return crate::syntax::Stmt{.kind = crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}}}), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// BlockStmt: unbounded fn Lx, Env, Stmt -> (([Do], Env))
std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> block_stmt(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Stmt& s) {
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& x = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        auto&& _m = p_.kind;
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            auto&& _m = crate::prelude::get(lx.gens, crate::lower::place_key(lx, n.span));
            if (prism_rtl::is_some(_m)) {
                auto&& gn = prism_rtl::some_of(_m);
                return generic_let(lx, env, n, gn, x);
            }
            if (prism_rtl::is_none(_m)) {
                return plain_let(lx, env, s, p_, x);
            }
            prism_rtl::unreachable("no arm matched");
        }
        {
            return plain_let(lx, env, s, p_, x);
        }
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        return std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::types::own(value_of(lx, env, x))})}), env};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m)) {
        return std::tuple{Array<crate::lower::model::Do>{}, env};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        auto&& f = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        return std::tuple{Array(std::vector{refusal_do(prism_rtl::cat("a local function ", crate::check::env::def_name_text(f.name), ": not lowered yet"))}), env};
    }
    {
        return std::tuple{Array(std::vector{refusal_do(Text::lit("a statement this back end does not lower yet"))}), env};
    }
}


prism_rtl::Turn<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> BlockStmt::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& s = this->s;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& x = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        ({
        auto&& _m = p_.kind;
        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        ({
        auto&& _m = crate::prelude::get(lx.gens, crate::lower::place_key(lx, n.span));
        prism_rtl::is_some(_m) ? ({
        auto&& gn = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(GenericLet(lx, env, n, gn, x)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(PlainLet(lx, env, s, p_, x)))
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::more(prism_rtl::rc(PlainLet(lx, env, s, p_, x)));
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto x_3 = x;
        call_then(start_value_of(lx_2, env_1, x_3), [=](crate::lower::types::Vl value_of_58936) { return prism_rtl::finished(std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::types::own(value_of_58936)})}), env_1}); });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m) ? prism_rtl::finished(std::tuple{Array<crate::lower::model::Do>{}, env})
        : prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? ({
        auto&& f = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        prism_rtl::finished(std::tuple{Array(std::vector{refusal_do(prism_rtl::cat("a local function ", crate::check::env::def_name_text(f.name), ": not lowered yet"))}), env});
    })
        : prism_rtl::finished(std::tuple{Array(std::vector{refusal_do(Text::lit("a statement this back end does not lower yet"))}), env});
    });
}


/// `Start BlockStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> start_block_stmt(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Stmt s) {
    return prism_rtl::make_rc<BlockStmt>(lx, env, s);
}


/// GenericLet: unbounded fn Lx, Env, SName, GenNote, Expr -> (([Do], Env))
std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> generic_let(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::SName& n, const crate::check::typed::GenNote& gn, const crate::syntax::Expr& x) {
    auto nkey = crate::check::env::sname_key(n);
    auto distinct_ = instantiations(lx, gn);
    auto one = len(distinct_) == Nat(1u);
    auto rs = crate::lower::local_name(lx, nkey);
    return run_to_end(fold_job(crate::check::errors::range0(len(distinct_)), std::tuple{Array<crate::lower::model::Do>{}, env}, ({
        auto distinct__1 = distinct_;
        auto lx_2 = lx;
        auto one_3 = one;
        auto rs_4 = rs;
        auto nkey_5 = nkey;
        auto n_6 = n;
        auto env_7 = env;
        auto x_8 = x;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>>(std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto distinct__1_9 = distinct__1;
            auto lx_2_9 = lx_2;
            auto one_3_9 = one_3;
            auto rs_4_9 = rs_4;
            auto nkey_5_9 = nkey_5;
            auto n_6_9 = n_6;
            auto env_7_9 = env_7;
            auto x_8_9 = x_8;
            entered(once_job([=]() {
            return ({
                auto [dos, en] = p0;
                auto k = p1;
                ({
                auto [tys, cols] = or_(index(distinct__1_9, k), std::tuple{Array<std::tuple<Text, crate::check::types::Ty>>{}, Array<std::tuple<Text, crate::check::types::Col>>{}});
                auto lxk = at_instance(lx_2_9, std::tuple{tys, cols});
                auto rk = one_3_9 ? rs_4_9 : prism_rtl::cat(rs_4_9, "_", k);
                auto bkey = k == Nat(0u) ? nkey_5_9 : prism_rtl::cat(nkey_5_9, "#inst", k);
                call_then(crate::lower::types::start_out_ty_of(lxk, crate::lower::types::peel(crate::lower::binder_ty(lxk, n_6_9.span))), [=](crate::lower::model::OutTy out_ty_of_60098) {
                return ({
                    auto bt = out_ty_of_60098;
                    call_then(start_value_of(lxk, env_7_9, x_8_9), [=](crate::lower::types::Vl value_of_60157) {
                    return ({
                        auto v_ = value_of_60157;
                        auto en1 = crate::lower::types::bind(en, bkey, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rk}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt}));
                        auto en2 = ({
                            crate::lower::types::Env this_ = en1;
                            this_.uses = insert(this_.uses, prism_rtl::cat(nkey_5_9, "#", show_text(std::tuple{tys, cols})), bkey);
                            this_;
                        });
                        auto d = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{rk}), crate::lower::types::own(v_)});
                        (prism_rtl::finished(std::tuple{crate::prelude::push(dos, d), en2}));
                    });
                });
                });
            });
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> GenericLet::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& n = this->n;
    const auto& gn = this->gn;
    const auto& x = this->x;
    auto nkey = crate::check::env::sname_key(n);
    auto env_1 = env;
    auto gn_2 = gn;
    auto lx_3 = lx;
    auto n_4 = n;
    auto x_5 = x;
    return call_then(start_instantiations(lx_3, gn_2), [=](Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> instantiations_59717) {
        return ({
            auto distinct_ = instantiations_59717;
            auto one = len(distinct_) == Nat(1u);
            auto rs = crate::lower::local_name(lx_3, nkey);
            fold_job(crate::check::errors::range0(len(distinct_)), std::tuple{Array<crate::lower::model::Do>{}, env_1}, ({
            auto distinct__6 = distinct_;
            auto lx_3_7 = lx_3;
            auto one_7 = one;
            auto rs_8 = rs;
            auto nkey_9 = nkey;
            auto n_4_10 = n_4;
            auto env_1_10 = env_1;
            auto x_5_10 = x_5;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>>(std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto distinct__6_10 = distinct__6;
                auto lx_3_7_10 = lx_3_7;
                auto one_7_10 = one_7;
                auto rs_8_10 = rs_8;
                auto nkey_9_10 = nkey_9;
                auto n_4_10_10 = n_4_10;
                auto env_1_10_10 = env_1_10;
                auto x_5_10_10 = x_5_10;
                entered(once_job([=]() {
                return ({
                    auto [dos, en] = p0;
                    auto k = p1;
                    ({
                    auto [tys, cols] = or_(index(distinct__6_10, k), std::tuple{Array<std::tuple<Text, crate::check::types::Ty>>{}, Array<std::tuple<Text, crate::check::types::Col>>{}});
                    auto lxk = at_instance(lx_3_7_10, std::tuple{tys, cols});
                    auto rk = one_7_10 ? rs_8_10 : prism_rtl::cat(rs_8_10, "_", k);
                    auto bkey = k == Nat(0u) ? nkey_9_10 : prism_rtl::cat(nkey_9_10, "#inst", k);
                    call_then(crate::lower::types::start_out_ty_of(lxk, crate::lower::types::peel(crate::lower::binder_ty(lxk, n_4_10_10.span))), [=](crate::lower::model::OutTy out_ty_of_60098) {
                    return ({
                        auto bt = out_ty_of_60098;
                        call_then(start_value_of(lxk, env_1_10_10, x_5_10_10), [=](crate::lower::types::Vl value_of_60157) {
                        return ({
                            auto v_ = value_of_60157;
                            auto en1 = crate::lower::types::bind(en, bkey, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rk}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt}));
                            auto en2 = ({
                                crate::lower::types::Env this_ = en1;
                                this_.uses = insert(this_.uses, prism_rtl::cat(nkey_9_10, "#", show_text(std::tuple{tys, cols})), bkey);
                                this_;
                            });
                            auto d = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{rk}), crate::lower::types::own(v_)});
                            (prism_rtl::finished(std::tuple{crate::prelude::push(dos, d), en2}));
                        });
                    });
                    });
                });
                });
                });
            }));
            });
        }));
        }))->cycle();
        });
    });
}


/// `Start GenericLet, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> start_generic_let(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::SName n, crate::check::typed::GenNote gn, crate::syntax::Expr x) {
    return prism_rtl::make_rc<GenericLet>(lx, env, n, gn, x);
}


/// Instantiations: unbounded fn Lx, GenNote -> [(([((Text, Ty))], [((Text, Col))]))]
Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> instantiations(const crate::lower::Lx& lx, const crate::check::typed::GenNote& gn) {
    return run_to_end(fold_job(or_(crate::prelude::get(lx.insts, gen_key(gn)), Array<crate::check::typed::InstNote>{}), Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>{}, ({
        auto lx_1 = lx;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>(std::tuple<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>, crate::check::typed::InstNote>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>, crate::check::typed::InstNote> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto u = p1;
                call_then(start_expanded(lx_1_2, inst_at(lx_1_2, u)), [=](Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> expanded_60822) {
                return prism_rtl::finished(fold(expanded_60822, acc, [&](const Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>& a, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& i) {
                    return fold(a, false, [&](const bool& seen, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& j) { return seen || (show_text(j) == show_text(i)); })
                        ? a
                        : crate::prelude::push(a, i);
                }));
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> Instantiations::cycle() const {
    const auto& lx = this->lx;
    const auto& gn = this->gn;
    return fold_job(or_(crate::prelude::get(lx.insts, gen_key(gn)), Array<crate::check::typed::InstNote>{}), Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>{}, ({
        auto lx_1 = lx;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>(std::tuple<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>, crate::check::typed::InstNote>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>, crate::check::typed::InstNote> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto u = p1;
                call_then(start_expanded(lx_1_2, inst_at(lx_1_2, u)), [=](Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> expanded_60822) {
                return prism_rtl::finished(fold(expanded_60822, acc, [&](const Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>& a, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& i) {
                    return fold(a, false, [&](const bool& seen, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& j) { return seen || (show_text(j) == show_text(i)); })
                        ? a
                        : crate::prelude::push(a, i);
                }));
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start Instantiations, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> start_instantiations(crate::lower::Lx lx, crate::check::typed::GenNote gn) {
    return prism_rtl::make_rc<Instantiations>(lx, gn);
}


/// Expanded: unbounded fn Lx, (([((Text, Ty))], [((Text, Col))])) -> [(([((Text, Ty))], [((Text, Col))]))]
Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> expanded(const crate::lower::Lx& lx, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& i) {
    auto&& _m = open_q(lx, i);
    if (prism_rtl::is_none(_m)) {
        return Array(std::vector{i});
    }
    if (prism_rtl::is_some(_m)) {
        auto&& q = prism_rtl::some_of(_m);
        auto&& _m = crate::prelude::get(lx.gen_of_q, q);
        if (prism_rtl::is_some(_m)) {
            auto&& g = prism_rtl::some_of(_m);
            return run_to_end(fold_job(instantiations(lx, g), Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>{}, ({
                auto lx_1 = lx;
                auto i_2 = i;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>(std::tuple<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>, std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>, std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto lx_1_3 = lx_1;
                    auto i_2_3 = i_2;
                    entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto gi = p1;
                        ({
                        auto lx2 = at_instance(lx_1_3, gi);
                        call_then(start_expanded(lx2, subst_inst(lx2, i_2_3)), [=](Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> expanded_61255) { return prism_rtl::finished(append(acc, expanded_61255)); });
                    });
                    });
                }));
                });
            }));
            })));
        }
        if (prism_rtl::is_none(_m)) {
            return Array(std::vector{i});
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> Expanded::cycle() const {
    const auto& lx = this->lx;
    const auto& i = this->i;
    auto i_1 = i;
    auto lx_2 = lx;
    return call_then(start_open_q(lx_2, i_1), [=](std::optional<Text> open_q_61073) {
        return ({
            prism_rtl::is_none(open_q_61073) ? prism_rtl::finished(Array(std::vector{i_1}))
            : prism_rtl::is_some(open_q_61073) ? ({
            auto&& q = prism_rtl::some_of(open_q_61073);
            ({
            auto&& _m = crate::prelude::get(lx_2.gen_of_q, q);
            prism_rtl::is_some(_m) ? ({
            auto&& g = prism_rtl::some_of(_m);
            call_then(start_instantiations(lx_2, g), [=](Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> instantiations_61150) {
            return fold_job(instantiations_61150, Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>{}, ({
                auto lx_2_3 = lx_2;
                auto i_1_3 = i_1;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>(std::tuple<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>, std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>, std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto lx_2_3_3 = lx_2_3;
                    auto i_1_3_3 = i_1_3;
                    entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto gi = p1;
                        ({
                        auto lx2 = at_instance(lx_2_3_3, gi);
                        call_then(start_expanded(lx2, subst_inst(lx2, i_1_3_3)), [=](Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> expanded_61255) { return prism_rtl::finished(append(acc, expanded_61255)); });
                    });
                    });
                }));
                });
            }));
            }))->cycle();
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(Array(std::vector{i_1}))
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
    });
}


/// `Start Expanded, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> start_expanded(crate::lower::Lx lx, std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>> i) {
    return prism_rtl::make_rc<Expanded>(lx, i);
}


/// SubstInst: fn Lx, (([((Text, Ty))], [((Text, Col))])) -> (([((Text, Ty))], [((Text, Col))]))
std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>> subst_inst(const crate::lower::Lx& lx, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& arg1) {
    {
        auto&& tys = std::get<0>(arg1);
        auto&& cols = std::get<1>(arg1);
        auto tys2 = each(tys, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
            auto&& q = std::get<0>(_p0);
            auto&& t = std::get<1>(_p0);
            return std::tuple{q, crate::lower::subst_ty(lx, t)};
        });
        auto cols2 = each(cols, [&](const std::tuple<Text, crate::check::types::Col>& _p0) {
            auto&& q = std::get<0>(_p0);
            auto&& c = std::get<1>(_p0);
            return std::tuple{q, crate::lower::inst_col(lx, c)};
        });
        return std::tuple{tys2, cols2};
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?OpenQ: unbounded fn Lx, (([((Text, Ty))], [((Text, Col))])) -> ?Text
std::optional<Text> open_q(const crate::lower::Lx& lx, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& arg1) {
    {
        auto&& tys = std::get<0>(arg1);
        auto&& cols = std::get<1>(arg1);
        auto from_cols = fold(cols, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, crate::check::types::Col>& _p1) {
            auto&& c = std::get<1>(_p1);
            return append(acc, open_cols(lx, c));
        });
        auto all = run_to_end(fold_job(tys, from_cols, ({
            auto lx_1 = lx;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, std::tuple<Text, crate::check::types::Ty>>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, std::tuple<Text, crate::check::types::Ty>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_1_2 = lx_1;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto&& _t = p1;
                    auto&& t = std::get<1>(_t);
                    call_then(start_open_ty_qs(lx_1_2, t), [=](Array<Text> open_ty_qs_61936) { return prism_rtl::finished(append(acc, open_ty_qs_61936)); });
                });
            }));
            });
        })));
        })));
        return index(all, Nat(0u));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::optional<Text>> OpenQ::cycle() const {
    const auto& lx = this->lx;
    const auto& arg1 = this->arg1;
    return ({
        ({
        auto&& tys = std::get<0>(arg1);
        auto&& cols = std::get<1>(arg1);
        ({
        auto from_cols = fold(cols, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, crate::check::types::Col>& _p1) {
            auto&& c = std::get<1>(_p1);
            return append(acc, open_cols(lx, c));
        });
        auto lx_1 = lx;
        auto tys_2 = tys;
        call_value(fold_job(tys_2, from_cols, ({
        auto lx_1_3 = lx_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, std::tuple<Text, crate::check::types::Ty>>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, std::tuple<Text, crate::check::types::Ty>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_3_3 = lx_1_3;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto&& _t = p1;
                auto&& t = std::get<1>(_t);
                call_then(start_open_ty_qs(lx_1_3_3, t), [=](Array<Text> open_ty_qs_61936) { return prism_rtl::finished(append(acc, open_ty_qs_61936)); });
            });
        }));
        });
    })));
    })), [=](Array<Text> fold_61881) {
        return ({
            auto all = fold_61881;
            (prism_rtl::finished(index(all, Nat(0u))));
        });
    });
    });
    });
    });
}


/// `Start OpenQ, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Text>> start_open_q(crate::lower::Lx lx, std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>> arg1) {
    return prism_rtl::make_rc<OpenQ>(lx, arg1);
}


/// OpenCols: fn Lx, Col -> [Text]
Array<Text> open_cols(const crate::lower::Lx& lx, const crate::check::types::Col& col1) {
    if (prism_rtl::is<crate::check::types::Col::CQ>(col1)) {
        auto&& q = prism_rtl::as<crate::check::types::Col::CQ>(col1).a0;
        return crate::check::env::has_key(lx.gen_of_q, q) && (!crate::check::env::has_key(lx.csubst, q))
            ? Array(std::vector{q})
            : Array<Text>{};
    }
    {
        auto&& c = col1;
        return Array<Text>{};
    }
}


/// OpenTyQs: unbounded fn Lx, Ty -> [Text]
Array<Text> open_ty_qs(const crate::lower::Lx& lx, const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyFlex>(t).a0;
        return crate::check::env::has_key(lx.gen_of_q, prism_rtl::cat("\'", n)) && (!crate::check::env::has_key(lx.subst, prism_rtl::cat("\'", n)))
            ? Array(std::vector{prism_rtl::cat("\'", n)})
            : Array<Text>{};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t)) {
        auto&& c = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        return run_to_end(fold_job(crate::prelude::push(ps, res), open_cols(lx, c), ({
            auto lx_1 = lx;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_1_2 = lx_1;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto x = p1;
                    call_then(start_open_ty_qs(lx_1_2, x), [=](Array<Text> open_ty_qs_62372) { return prism_rtl::finished(append(acc, open_ty_qs_62372)); });
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        return run_to_end(fold_job(args, Array<Text>{}, ({
            auto lx_1 = lx;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_1_2 = lx_1;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto x = p1;
                    call_then(start_open_ty_qs(lx_1_2, x), [=](Array<Text> open_ty_qs_62452) { return prism_rtl::finished(append(acc, open_ty_qs_62452)); });
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        return run_to_end(fold_job(ts, Array<Text>{}, ({
            auto lx_1 = lx;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_1_2 = lx_1;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto x = p1;
                    call_then(start_open_ty_qs(lx_1_2, x), [=](Array<Text> open_ty_qs_62522) { return prism_rtl::finished(append(acc, open_ty_qs_62522)); });
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        return open_ty_qs(lx, e);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        return append(open_ty_qs(lx, k), open_ty_qs(lx, v_));
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        return open_ty_qs(lx, i);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a0;
        return open_ty_qs(lx, i);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t)) {
        auto&& o = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a1;
        return open_ty_qs(lx, o);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t)) {
        auto&& a = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t).a1;
        return open_ty_qs(lx, a);
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> OpenTyQs::cycle() const {
    const auto& lx = this->lx;
    const auto& t = this->t;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyFlex>(t) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyFlex>(t).a0;
        crate::check::env::has_key(lx.gen_of_q, prism_rtl::cat("\'", n)) && (!crate::check::env::has_key(lx.subst, prism_rtl::cat("\'", n)))
        ? prism_rtl::finished(Array(std::vector{prism_rtl::cat("\'", n)}))
        : prism_rtl::finished(Array<Text>{});
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(t) ? ({
        auto&& c = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        fold_job(crate::prelude::push(ps, res), open_cols(lx, c), ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto x = p1;
                call_then(start_open_ty_qs(lx_1_2, x), [=](Array<Text> open_ty_qs_62372) { return prism_rtl::finished(append(acc, open_ty_qs_62372)); });
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) ? ({
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        fold_job(args, Array<Text>{}, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto x = p1;
                call_then(start_open_ty_qs(lx_1_2, x), [=](Array<Text> open_ty_qs_62452) { return prism_rtl::finished(append(acc, open_ty_qs_62452)); });
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        fold_job(ts, Array<Text>{}, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto x = p1;
                call_then(start_open_ty_qs(lx_1_2, x), [=](Array<Text> open_ty_qs_62522) { return prism_rtl::finished(append(acc, open_ty_qs_62522)); });
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        prism_rtl::more(prism_rtl::rc(OpenTyQs(lx, e)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        ({
        auto k_1 = k;
        auto lx_2 = lx;
        auto v__3 = v_;
        call_then(start_open_ty_qs(lx_2, k_1), [=](Array<Text> open_ty_qs_62592) { return call_then(start_open_ty_qs(lx_2, v__3), [=](Array<Text> open_ty_qs_62610) { return prism_rtl::finished(append(open_ty_qs_62592, open_ty_qs_62610)); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t) ? ({
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        prism_rtl::more(prism_rtl::rc(OpenTyQs(lx, i)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyAt>(t) ? ({
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a0;
        prism_rtl::more(prism_rtl::rc(OpenTyQs(lx, i)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyElem>(t) ? ({
        auto&& o = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a1;
        prism_rtl::more(prism_rtl::rc(OpenTyQs(lx, o)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyAssoc>(t) ? ({
        auto&& a = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t).a1;
        prism_rtl::more(prism_rtl::rc(OpenTyQs(lx, a)));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start OpenTyQs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_open_ty_qs(crate::lower::Lx lx, crate::check::types::Ty t) {
    return prism_rtl::make_rc<OpenTyQs>(lx, t);
}


/// AtInstance: fn Lx, (([((Text, Ty))], [((Text, Col))])) -> Lx
crate::lower::Lx at_instance(const crate::lower::Lx& lx, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& arg1) {
    {
        auto&& tys = std::get<0>(arg1);
        auto&& cols = std::get<1>(arg1);
        crate::lower::Lx this_ = lx;
        this_.subst = fold(tys, this_.subst, [&](const Map<Text, crate::check::types::Ty>& m, const std::tuple<Text, crate::check::types::Ty>& _p1) {
            auto&& q = std::get<0>(_p1);
            auto&& t = std::get<1>(_p1);
            return insert(m, q, t);
        });
        this_.csubst = fold(cols, this_.csubst, [&](const Map<Text, crate::check::types::Col>& m, const std::tuple<Text, crate::check::types::Col>& _p1) {
            auto&& q = std::get<0>(_p1);
            auto&& c = std::get<1>(_p1);
            return insert(m, q, c);
        });
        return this_;
    }
    prism_rtl::unreachable("no arm matched");
}


/// WidgetLetLx: unbounded fn Lx, Range -> Lx
crate::lower::Lx widget_let_lx(const crate::lower::Lx& lx, const crate::syntax::Range& span) {
    auto&& _m = crate::prelude::get(lx.gens, crate::lower::place_key(lx, span));
    if (prism_rtl::is_some(_m)) {
        auto&& gn = prism_rtl::some_of(_m);
        auto&& _m = instantiations(lx, gn);
        {
            auto&& m63431_0 = _m;
            if (m63431_0.size() == 1u) {
                {
                    auto&& _c1 = index(m63431_0, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& i = prism_rtl::some_of(_c1);
                        return at_instance(lx, i);
                    }
                }
            }
        }
        {
            return lx;
        }
    }
    if (prism_rtl::is_none(_m)) {
        return lx;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::Lx> WidgetLetLx::cycle() const {
    const auto& lx = this->lx;
    const auto& span = this->span;
    return ({
        auto&& _m = crate::prelude::get(lx.gens, crate::lower::place_key(lx, span));
        prism_rtl::is_some(_m) ? ({
        auto&& gn = prism_rtl::some_of(_m);
        ({
        auto lx_1 = lx;
        call_then(start_instantiations(lx_1, gn), [=](Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> instantiations_63437) {
        return ({
            ({
            auto&& m63431_0 = instantiations_63437;
            (m63431_0.size() == 1u) && ({
            auto&& _c1 = index(m63431_0, Nat(0u));
            prism_rtl::is_some(_c1);
        });
        }) ? ({
            auto&& m63431_0 = instantiations_63437;
            auto&& _c1 = index(m63431_0, Nat(0u));
            auto&& i = prism_rtl::some_of(_c1);
            prism_rtl::finished(at_instance(lx_1, i));
        })
            : prism_rtl::finished(lx_1);
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(lx)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start WidgetLetLx, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::Lx> start_widget_let_lx(crate::lower::Lx lx, crate::syntax::Range span) {
    return prism_rtl::make_rc<WidgetLetLx>(lx, span);
}


/// InstAt: fn Lx, InstNote -> (([((Text, Ty))], [((Text, Col))]))
std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>> inst_at(const crate::lower::Lx& lx, const crate::check::typed::InstNote& u) {
    auto tys = each(u.tys, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
        auto&& q = std::get<0>(_p0);
        auto&& t = std::get<1>(_p0);
        return std::tuple{q, crate::lower::subst_ty(lx, t)};
    });
    auto cols = each(u.cols, [&](const std::tuple<Text, crate::check::types::Col>& _p0) {
        auto&& q = std::get<0>(_p0);
        auto&& c = std::get<1>(_p0);
        return std::tuple{q, crate::lower::inst_col(lx, c)};
    });
    return std::tuple{tys, cols};
}


/// GenKey: fn GenNote -> Text
Text gen_key(const crate::check::typed::GenNote& gn) {
    return or_(index(append(gn.tys, gn.cols), Nat(0u)), Text::lit(""));
}


/// InstKey: fn InstNote -> Text
Text inst_key(const crate::check::typed::InstNote& u) {
    return or_(index(append(each(u.tys, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
        auto&& q = std::get<0>(_p0);
        return q;
    }), each(u.cols, [&](const std::tuple<Text, crate::check::types::Col>& _p0) {
        auto&& q = std::get<0>(_p0);
        return q;
    })), Nat(0u)), Text::lit(""));
}


/// ColName: fn Col -> Text
Text col_name(const crate::check::types::Col& col0) {
    if (prism_rtl::is<crate::check::types::Col::CQ>(col0)) {
        auto&& q = prism_rtl::as<crate::check::types::Col::CQ>(col0).a0;
        return q;
    }
    {
        auto&& c = col0;
        return Text::lit("");
    }
}


/// PlainLet: unbounded fn Lx, Env, Stmt, Pattern, Expr -> (([Do], Env))
std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> plain_let(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Stmt& s, const crate::syntax::Pattern_& p_, const crate::syntax::Expr& x) {
    auto v_ = value_of(lx, env, x);
    auto po = crate::lower::patterns::rust_pat(lx, p_, crate::lower::type_at(lx, x.span), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("l", s.span.start));
    return std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{po.pa, crate::lower::types::own(v_)})}), bind_all(env, po.binds)};
}


prism_rtl::Turn<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> PlainLet::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& s = this->s;
    const auto& p_ = this->p_;
    const auto& x = this->x;
    auto env_1 = env;
    auto lx_2 = lx;
    auto p__3 = p_;
    auto s_4 = s;
    auto x_5 = x;
    return call_then(start_value_of(lx_2, env_1, x_5), [=](crate::lower::types::Vl value_of_64222) {
        return ({
            auto v_ = value_of_64222;
            call_then(crate::lower::patterns::start_rust_pat(lx_2, p__3, crate::lower::type_at(lx_2, x_5.span), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("l", s_4.span.start)), [=](crate::lower::patterns::PatOut rust_pat_64258) {
            return ({
                auto po = rust_pat_64258;
                (prism_rtl::finished(std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{po.pa, crate::lower::types::own(v_)})}), bind_all(env_1, po.binds)}));
            });
        });
        });
    });
}


/// `Start PlainLet, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> start_plain_let(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Stmt s, crate::syntax::Pattern_ p_, crate::syntax::Expr x) {
    return prism_rtl::make_rc<PlainLet>(lx, env, s, p_, x);
}

}  // namespace crate::lower::expr
