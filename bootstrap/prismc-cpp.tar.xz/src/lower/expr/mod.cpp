// The module `Lower.Expr`, from `target/bootstrap/cpp-src/prismc/lower/expr.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <lower/expr/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate::lower::expr {

/// Escape: fn Text -> Text
Text escape(const Text& t) {
    return crate::syntax::lexer::chars::map_chars(t, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Text)>>(prism_rtl::rc([=](Text p0) {
        return once_job([=]() {
            return ({
                auto c = p0;
                (prism_rtl::finished(char_escape(c)));
            });
        });
    })));
}


/// CharEscape: fn Text -> Text
Text char_escape(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("\\")) {
            return Text::lit("\\\\");
        }
    }
    {
        auto&& c1_0 = text0;
        if (c1_0 == Text::lit("\"")) {
            return Text::lit("\\\"");
        }
    }
    {
        auto&& c2_0 = text0;
        if (c2_0 == Text::lit("\n")) {
            return Text::lit("\\n");
        }
    }
    {
        auto&& c3_0 = text0;
        if (c3_0 == Text::lit("\t")) {
            return Text::lit("\\t");
        }
    }
    {
        auto&& c4_0 = text0;
        if (c4_0 == Text::lit("\r")) {
            return Text::lit("\\r");
        }
    }
    {
        auto&& c5_0 = text0;
        if (c5_0 == Text::lit("\000"sv)) {
            return Text::lit("\\0");
        }
    }
    {
        auto&& c = text0;
        return c;
    }
}


/// Number: fn OutTy, Text, Bool -> Ex
crate::lower::model::Ex number(const crate::lower::model::OutTy& t, const Text& digits, const bool& neg) {
    auto clean = decimal_digits(concat(split_on(digits, Text::lit("_"))));
    auto signed_ = neg ? prism_rtl::cat("-", clean) : clean;
    if (prism_rtl::is<crate::lower::model::OutTy::OutNat>(t)) {
        return crate::lower::model::Ex(crate::lower::model::Ex::XNat{clean});
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutInt>(t)) {
        return crate::lower::model::Ex(crate::lower::model::Ex::XInt{signed_});
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutU8>(t)) {
        return crate::lower::model::Ex(crate::lower::model::Ex::XByte{clean});
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutFloat>(t)) {
        return crate::lower::model::Ex(crate::lower::model::Ex::XFloat{crate::syntax::lexer::chars::contains(clean, Text::lit("."))
            ? signed_
            : prism_rtl::cat(signed_, ".0")});
    }
    {
        return crate::lower::model::Ex(crate::lower::model::Ex::XInt{signed_});
    }
}


/// DecimalDigits: fn Text -> Text
Text decimal_digits(const Text& d) {
    auto r = crate::syntax::lexer::chars::head(d) == Text::lit("0")
        ? crate::syntax::lexer::chars::head(crate::syntax::lexer::chars::after_first(d))
        : Text::lit("");
    auto base = r == Text::lit("x")
        ? Nat(16u)
        : r == Text::lit("o") ? Nat(8u) : r == Text::lit("b") ? Nat(2u) : Nat(10u);
    auto ds = base == Nat(10u)
        ? d
        : crate::syntax::lexer::chars::after_first(crate::syntax::lexer::chars::after_first(d));
    return (crate::syntax::lexer::chars::contains(d, Text::lit(".")) || (crate::syntax::lexer::chars::head(d) != Text::lit("0"))) || (d == Text::lit("0"))
        ? d
        : prism_rtl::cat(crate::syntax::lexer::chars::fold_chars(ds, Nat(0u), ({
        auto base_1 = base;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Nat>(std::tuple<Nat, Text>)>>(prism_rtl::rc([=](std::tuple<Nat, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto base_1_2 = base_1;
            once_job([=]() {
            return ({
                auto n = p0;
                auto c = p1;
                (prism_rtl::finished((n * base_1_2) + crate::syntax::lexer::chars::hex_value(c)));
            });
        });
        });
    })));
    })));
}


/// LiteralValue: unbounded fn Lx, Env, Literal, Range, Bool -> Vl
crate::lower::types::Vl literal_value(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Literal& l, const crate::syntax::Range& span, const bool& neg) {
    auto t = crate::lower::types::out_ty_of(lx, crate::lower::types::peel(crate::lower::type_at(lx, span)));
    auto&& _m = l.kind;
    if (prism_rtl::is<crate::syntax::LitKind::LInt>(_m)) {
        auto&& d = prism_rtl::as<crate::syntax::LitKind::LInt>(_m).a0;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{number(t, d, neg), t});
    }
    if (prism_rtl::is<crate::syntax::LitKind::LFloat>(_m)) {
        auto&& d = prism_rtl::as<crate::syntax::LitKind::LFloat>(_m).a0;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XFloat{neg ? prism_rtl::cat("-", d) : d}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutFloat{})});
    }
    if (prism_rtl::is<crate::syntax::LitKind::LChar>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::LitKind::LChar>(_m).a0;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XChar{c}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutChar{})});
    }
    if (prism_rtl::is<crate::syntax::LitKind::LDuration>(_m)) {
        auto&& d = prism_rtl::as<crate::syntax::LitKind::LDuration>(_m).a0;
        auto&& u = prism_rtl::as<crate::syntax::LitKind::LDuration>(_m).a1;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(Text::lit("a Duration literal")), crate::lower::model::OutTy(crate::lower::model::OutTy::OutDuration{})});
    }
    if (prism_rtl::is<crate::syntax::LitKind::LText>(_m)) {
        auto&& segs = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
        return text_value(lx, env, segs);
    }
    if (prism_rtl::is<crate::syntax::LitKind::LRegex>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::LitKind::LRegex>(_m).a0;
        auto&& _m = r.replacement;
        if (prism_rtl::is_none(_m)) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XRegex{r.pattern, r.flags}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRegex{})});
        }
        if (prism_rtl::is_some(_m)) {
            auto&& t = prism_rtl::some_of(_m);
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XReplacement{r.pattern, t, r.flags}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutReplacement{})});
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::types::Vl> LiteralValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& l = this->l;
    const auto& span = this->span;
    const auto& neg = this->neg;
    auto env_1 = env;
    auto l_2 = l;
    auto lx_3 = lx;
    auto neg_4 = neg;
    auto span_5 = span;
    return call_then(crate::lower::types::start_out_ty_of(lx_3, crate::lower::types::peel(crate::lower::type_at(lx_3, span_5))), [=](crate::lower::model::OutTy out_ty_of_2717) {
        return ({
            auto t = out_ty_of_2717;
            ({
            auto&& _m = l_2.kind;
            prism_rtl::is<crate::syntax::LitKind::LInt>(_m) ? ({
            auto&& d = prism_rtl::as<crate::syntax::LitKind::LInt>(_m).a0;
            prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{number(t, d, neg_4), t}));
        })
            : prism_rtl::is<crate::syntax::LitKind::LFloat>(_m) ? ({
            auto&& d = prism_rtl::as<crate::syntax::LitKind::LFloat>(_m).a0;
            prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XFloat{neg_4 ? prism_rtl::cat("-", d) : d}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutFloat{})}));
        })
            : prism_rtl::is<crate::syntax::LitKind::LChar>(_m) ? ({
            auto&& c = prism_rtl::as<crate::syntax::LitKind::LChar>(_m).a0;
            prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XChar{c}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutChar{})}));
        })
            : prism_rtl::is<crate::syntax::LitKind::LDuration>(_m) ? ({
            auto&& d = prism_rtl::as<crate::syntax::LitKind::LDuration>(_m).a0;
            auto&& u = prism_rtl::as<crate::syntax::LitKind::LDuration>(_m).a1;
            prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(Text::lit("a Duration literal")), crate::lower::model::OutTy(crate::lower::model::OutTy::OutDuration{})}));
        })
            : prism_rtl::is<crate::syntax::LitKind::LText>(_m) ? ({
            auto&& segs = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
            prism_rtl::more(prism_rtl::rc(TextValue(lx_3, env_1, segs)));
        })
            : prism_rtl::is<crate::syntax::LitKind::LRegex>(_m) ? ({
            auto&& r = prism_rtl::as<crate::syntax::LitKind::LRegex>(_m).a0;
            ({
            auto&& _m = r.replacement;
            prism_rtl::is_none(_m) ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XRegex{r.pattern, r.flags}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRegex{})}))
            : prism_rtl::is_some(_m) ? ({
            auto&& t = prism_rtl::some_of(_m);
            prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XReplacement{r.pattern, t, r.flags}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutReplacement{})}));
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
}


/// `Start LiteralValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_literal_value(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Literal l, crate::syntax::Range span, bool neg) {
    return prism_rtl::make_rc<LiteralValue>(lx, env, l, span, neg);
}


/// TextValue: unbounded fn Lx, Env, [TextSeg] -> Vl
crate::lower::types::Vl text_value(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const Array<crate::syntax::TextSeg>& segs) {
    auto plain = fold(segs, true, [&](const bool& ok, const crate::syntax::TextSeg& s) { return ok && is_plain_seg(s); });
    return plain
        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XText{concat(each(segs, [&](const crate::syntax::TextSeg& s) { return plain_text(s); }))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})})
        : crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XFormat{run_to_end(each_job(segs, ({
        auto lx_1 = lx;
        auto env_2 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::TextSeg)>>(prism_rtl::rc([=](crate::syntax::TextSeg p0) {
        return ({
            auto lx_1_3 = lx_1;
            auto env_2_3 = env_2;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                (prism_rtl::more(prism_rtl::rc(SegEx(lx_1_3, env_2_3, s))));
            });
        }));
        });
    })));
    })))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})});
}


prism_rtl::Turn<crate::lower::types::Vl> TextValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& segs = this->segs;
    auto plain = fold(segs, true, [&](const bool& ok, const crate::syntax::TextSeg& s) { return ok && is_plain_seg(s); });
    return plain
        ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XText{concat(each(segs, [&](const crate::syntax::TextSeg& s) { return plain_text(s); }))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})}))
        : ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto segs_3 = segs;
        call_value(each_job(segs_3, ({
        auto lx_2_4 = lx_2;
        auto env_1_4 = env_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::TextSeg)>>(prism_rtl::rc([=](crate::syntax::TextSeg p0) {
        return ({
            auto lx_2_4_4 = lx_2_4;
            auto env_1_4_4 = env_1_4;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                (prism_rtl::more(prism_rtl::rc(SegEx(lx_2_4_4, env_1_4_4, s))));
            });
        }));
        });
    })));
    })), [=](Array<crate::lower::model::Ex> each_3614) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XFormat{each_3614}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})})); });
    });
}


/// `Start TextValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_text_value(crate::lower::Lx lx, crate::lower::types::Env env, Array<crate::syntax::TextSeg> segs) {
    return prism_rtl::make_rc<TextValue>(lx, env, segs);
}


/// IsPlainSeg: fn TextSeg -> Bool
bool is_plain_seg(const crate::syntax::TextSeg& text_seg0) {
    if (prism_rtl::is<crate::syntax::TextSeg::SegPlain>(text_seg0)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(text_seg0)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// PlainText: fn TextSeg -> Text
Text plain_text(const crate::syntax::TextSeg& text_seg0) {
    if (prism_rtl::is<crate::syntax::TextSeg::SegPlain>(text_seg0)) {
        auto&& t = prism_rtl::as<crate::syntax::TextSeg::SegPlain>(text_seg0).a0;
        return t;
    }
    if (prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(text_seg0)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SegEx: unbounded fn Lx, Env, TextSeg -> Ex
crate::lower::model::Ex seg_ex(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::TextSeg& text_seg2) {
    if (prism_rtl::is<crate::syntax::TextSeg::SegPlain>(text_seg2)) {
        auto&& t = prism_rtl::as<crate::syntax::TextSeg::SegPlain>(text_seg2).a0;
        return crate::lower::model::Ex(crate::lower::model::Ex::XText{t});
    }
    if (prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(text_seg2)) {
        auto&& e = prism_rtl::as<crate::syntax::TextSeg::SegPlaceholder>(text_seg2).a0;
        auto v_ = value_of(lx, env, e);
        return shown_part(v_);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::model::Ex> SegEx::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& text_seg2 = this->text_seg2;
    return ({
        prism_rtl::is<crate::syntax::TextSeg::SegPlain>(text_seg2) ? ({
        auto&& t = prism_rtl::as<crate::syntax::TextSeg::SegPlain>(text_seg2).a0;
        prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XText{t}));
    })
        : prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(text_seg2) ? ({
        auto&& e = prism_rtl::as<crate::syntax::TextSeg::SegPlaceholder>(text_seg2).a0;
        ({
        auto e_1 = e;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(start_value_of(lx_3, env_2, e_1), [=](crate::lower::types::Vl value_of_4013) {
        return ({
            auto v_ = value_of_4013;
            (prism_rtl::finished(shown_part(v_)));
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SegEx, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_seg_ex(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::TextSeg text_seg2) {
    return prism_rtl::make_rc<SegEx>(lx, env, text_seg2);
}


/// ShownPart: fn Vl -> Ex
crate::lower::model::Ex shown_part(const crate::lower::types::Vl& v_) {
    auto&& _m = crate::lower::types::value_ty(v_);
    if (prism_rtl::is<crate::lower::model::OutTy::OutText>(_m)) {
        return crate::lower::types::ref_(v_);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNat>(_m)) {
        return crate::lower::types::ref_(v_);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutInt>(_m)) {
        return crate::lower::types::ref_(v_);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutU8>(_m)) {
        return crate::lower::types::ref_(v_);
    }
    {
        return crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("show"), Array(std::vector{crate::lower::types::ref_(v_)})});
    }
}


/// Refusal: fn Text -> Ex
crate::lower::model::Ex refusal(const Text& what) {
    return crate::lower::model::Ex(crate::lower::model::Ex::XRefusal{what});
}


/// TryOf: fn Ex -> Ex
crate::lower::model::Ex try_of(const crate::lower::model::Ex& x) {
    return is_named_place(x)
        ? refusal(prism_rtl::cat("`?` of the place `", crate::lower::types::place_stem(x), "`, which C++'s TRY would move out of (only a temporary may be tried)"))
        : crate::lower::model::Ex(crate::lower::model::Ex::XTry{prism_rtl::rc(x)});
}


/// IsNamedPlace: fn Ex -> Bool
bool is_named_place(const crate::lower::model::Ex& x) {
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(x)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XPart>(x)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTarget>(x)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRef>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XRef>(x).a0;
        return is_named_place(y);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XDeref>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XDeref>(x).a0;
        return is_named_place(y);
    }
    {
        return false;
    }
}


/// let loweringRefusal
Text lowering_refusal() {
    return Text::lit("prismc does not lower ");
}


/// RefusalDo: fn Text -> Do
crate::lower::model::Do refusal_do(const Text& what) {
    return crate::lower::model::Do(crate::lower::model::Do::DoExpr{refusal(what)});
}


/// ValueOf: unbounded fn Lx, Env, Expr -> Vl
crate::lower::types::Vl value_of(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& e) {
    auto&& _m = crate::prelude::get(env.spans, crate::lower::place_key(lx, e.span));
    if (prism_rtl::is_some(_m)) {
        auto&& v_ = prism_rtl::some_of(_m);
        return v_;
    }
    if (prism_rtl::is_none(_m)) {
        return unbound_value_of(lx, env, e);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::types::Vl> ValueOf::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    return ({
        auto&& _m = crate::prelude::get(env.spans, crate::lower::place_key(lx, e.span));
        prism_rtl::is_some(_m) ? ({
        auto&& v_ = prism_rtl::some_of(_m);
        prism_rtl::finished(v_);
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(UnboundValueOf(lx, env, e)))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ValueOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_value_of(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e) {
    return prism_rtl::make_rc<ValueOf>(lx, env, e);
}


/// UnboundValueOf: unbounded fn Lx, Env, Expr -> Vl
crate::lower::types::Vl unbound_value_of(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& e) {
    return is_event_value(lx, env, e)
        ? event_value_of(lx, env, e)
        : value_by_kind(lx, env, e);
}


prism_rtl::Turn<crate::lower::types::Vl> UnboundValueOf::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    auto e_1 = e;
    auto env_2 = env;
    auto lx_3 = lx;
    return call_then(start_is_event_value(lx_3, env_2, e_1), [=](bool is_event_value_5988) {
        return is_event_value_5988
            ? prism_rtl::more(prism_rtl::rc(EventValueOf(lx_3, env_2, e_1)))
            : prism_rtl::more(prism_rtl::rc(ValueByKind(lx_3, env_2, e_1)));
    });
}


/// `Start UnboundValueOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_unbound_value_of(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e) {
    return prism_rtl::make_rc<UnboundValueOf>(lx, env, e);
}


/// IsEventValue: unbounded fn Lx, Env, Expr -> Bool
bool is_event_value(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        return false;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        return false;
    }
    {
        return ((crate::lower::types::layer_of(crate::lower::type_at(lx, e.span)) == crate::lower::types::Layer(crate::lower::types::Layer::LyEv{})) && (!fold(crate::lower::node_::dynamics::operands(e), false, [&](const bool& bound, const crate::syntax::Expr& c) { return bound || crate::check::env::has_key(env.spans, crate::lower::place_key(lx, c.span)); }))) && has_event_source(lx, env, e);
    }
}


prism_rtl::Turn<bool> IsEventValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? prism_rtl::finished(false)
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? prism_rtl::finished(false)
        : prism_rtl::finished(((crate::lower::types::layer_of(crate::lower::type_at(lx, e.span)) == crate::lower::types::Layer(crate::lower::types::Layer::LyEv{})) && (!fold(crate::lower::node_::dynamics::operands(e), false, [&](const bool& bound, const crate::syntax::Expr& c) { return bound || crate::check::env::has_key(env.spans, crate::lower::place_key(lx, c.span)); }))) && has_event_source(lx, env, e));
    });
}


/// `Start IsEventValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_event_value(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e) {
    return prism_rtl::make_rc<IsEventValue>(lx, env, e);
}


/// HasEventSource: unbounded fn Lx, Env, Expr -> Bool
bool has_event_source(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& e) {
    return run_to_end(fold_job(crate::lower::node_::dynamics::operands(e), false, ({
        auto lx_1 = lx;
        auto env_2 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_3 = lx_1;
            auto env_2_3 = env_2;
            entered(once_job([=]() {
            return ({
                auto found = p0;
                auto c = p1;
                (prism_rtl::finished(found || is_event_source(lx_1_3, env_2_3, c)));
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<bool> HasEventSource::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    return fold_job(crate::lower::node_::dynamics::operands(e), false, ({
        auto lx_1 = lx;
        auto env_2 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_3 = lx_1;
            auto env_2_3 = env_2;
            entered(once_job([=]() {
            return ({
                auto found = p0;
                auto c = p1;
                (prism_rtl::finished(found || is_event_source(lx_1_3, env_2_3, c)));
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start HasEventSource, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_has_event_source(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e) {
    return prism_rtl::make_rc<HasEventSource>(lx, env, e);
}


/// IsEventSource: unbounded fn Lx, Env, Expr -> Bool
bool is_event_source(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& c) {
    return crate::lower::types::layer_of(crate::lower::type_at(lx, c.span)) != crate::lower::types::Layer(crate::lower::types::Layer::LyEv{})
        ? false
        : ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = c.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = crate::prelude::get(env->names, crate::check::env::sname_key(n));
                if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)) && prism_rtl::is<crate::lower::model::OutTy::OutEvent>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2)) {
                    _v.set(true);
                    goto _done;
                }
                if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(_m))) {
                    _v.set(crate::check::env::has_key(env->names, prism_rtl::cat(crate::check::env::sname_key(n), "#port")));
                    goto _done;
                }
                {
                    _v.set(false);
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
            _v.set(is_event_source(lx, env, x));
            goto _done;
        }
        {
            _v.set(has_event_source(lx, env, c));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<bool> IsEventSource::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& c = this->c;
    return crate::lower::types::layer_of(crate::lower::type_at(lx, c.span)) != crate::lower::types::Layer(crate::lower::types::Layer::LyEv{})
        ? prism_rtl::finished(false)
        : ({
        auto&& _m = c.kind;
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        ({
        auto&& _m = crate::prelude::get(env->names, crate::check::env::sname_key(n));
        prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)) && prism_rtl::is<crate::lower::model::OutTy::OutEvent>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2) ? prism_rtl::finished(true)
        : prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(_m)) ? prism_rtl::finished(crate::check::env::has_key(env->names, prism_rtl::cat(crate::check::env::sname_key(n), "#port")))
        : prism_rtl::finished(false);
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(IsEventSource(lx, env, x)));
    })
        : prism_rtl::more(prism_rtl::rc(HasEventSource(lx, env, c)));
    });
}


/// `Start IsEventSource, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_event_source(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr c) {
    return prism_rtl::make_rc<IsEventSource>(lx, env, c);
}


/// EventValueOf: unbounded fn Lx, Env, Expr -> Vl
crate::lower::types::Vl event_value_of(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& e) {
    auto t = crate::lower::types::out_ty_of(lx, crate::lower::types::peel(crate::lower::type_at(lx, e.span)));
    auto et = crate::lower::model::OutTy(crate::lower::model::OutTy::OutEvent{prism_rtl::rc(t)});
    auto filtered_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<crate::syntax::Arg>> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
            auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
            auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
            _v.set(crate::lower::node_::dynamics::callee_key(lx, c) == Text::lit("Prelude.!Filter")
                ? index(args, Nat(0u))
                : std::optional<crate::syntax::Arg>{});
            goto _done;
        }
        {
            _v.set(std::optional<crate::syntax::Arg>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    if (prism_rtl::is_some(filtered_opt)) {
        auto&& a = prism_rtl::some_of(filtered_opt);
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::types::own(value_of(lx, env, a->value))), Text::lit("filter_some"), Array<crate::lower::model::Ex>{}}), et});
    }
    if (prism_rtl::is_none(filtered_opt)) {
        auto evs = filter(crate::lower::node_::dynamics::operands(e), [&](const crate::syntax::Expr& x) { return crate::lower::types::layer_of(crate::lower::type_at(lx, x.span)) == crate::lower::types::Layer(crate::lower::types::Layer::LyEv{}); });
        {
            auto&& m8055_0 = evs;
            if (m8055_0.size() == 1u) {
                {
                    auto&& _c1 = index(m8055_0, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& one = prism_rtl::some_of(_c1);
                        auto src = crate::lower::types::own(value_of(lx, env, one));
                        auto it = crate::lower::types::out_ty_of(lx, crate::lower::types::peel(crate::lower::type_at(lx, one.span)));
                        auto caps = filter(crate::lower::types::with_instances(env, read_names(crate::check::typed::print::exprs_in(e))), [&](const Text& n) {
                            return ({
                                __label__ _done;
                                prism_rtl::Slot<bool> _v;
                                auto&& _m = crate::prelude::get(env->names, n);
                                if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                                    _v.set(true);
                                    goto _done;
                                }
                                {
                                    _v.set(false);
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            });
                        });
                        auto [dos, env1] = fold(caps, std::tuple{Array<crate::lower::model::Do>{}, env}, [&](const std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>& _p0, const Text& n) {
                            auto&& acc = std::get<0>(_p0);
                            auto&& en = std::get<1>(_p0);
                            return ({
                                __label__ _done;
                                prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
                                auto&& _m = crate::prelude::get(env->names, n);
                                if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                                    auto&& rs = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                                    auto&& mode = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                                    auto&& ct = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                                    _v.set(({
                                        auto local = prism_rtl::cat(crate::lower::types::place_stem(rs), "_c");
                                        std::tuple{crate::prelude::push(acc, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{local}), crate::lower::types::own(crate::lower::types::local_place(rs, mode, ct))})), crate::lower::types::bind(en, n, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{local}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), ct}))};
                                    }));
                                    goto _done;
                                }
                                {
                                    _v.set(std::tuple{acc, en});
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            });
                        });
                        auto env2 = crate::lower::types::bind_span(env1, crate::lower::place_key(lx, one.span), crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("y_ev")}), crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), it}));
                        auto body = crate::lower::types::own(value_by_kind(lx, env2, e));
                        auto mapped = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(src), Text::lit("map"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("y_ev")})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(it)})})}), prism_rtl::rc(body)})})});
                        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{crate::prelude::push(dos, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("src_ev")}), src})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("src_ev")})), Text::lit("map"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("y_ev")})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(it)})})}), prism_rtl::rc(body)})})}))}), et});
                    }
                }
            }
        }
        {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(Text::lit("an event value of several events")), et});
        }
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::types::Vl> EventValueOf::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    auto e_1 = e;
    auto env_2 = env;
    auto lx_3 = lx;
    return call_then(crate::lower::types::start_out_ty_of(lx_3, crate::lower::types::peel(crate::lower::type_at(lx_3, e_1.span))), [=](crate::lower::model::OutTy out_ty_of_7614) {
        return ({
            auto t = out_ty_of_7614;
            auto et = crate::lower::model::OutTy(crate::lower::model::OutTy::OutEvent{prism_rtl::rc(t)});
            auto filtered_opt = ({
                __label__ _done;
                prism_rtl::Slot<std::optional<crate::syntax::Arg>> _v;
                auto&& _m = e_1.kind;
                if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
                    auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
                    auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
                    _v.set(crate::lower::node_::dynamics::callee_key(lx_3, c) == Text::lit("Prelude.!Filter")
                        ? index(args, Nat(0u))
                        : std::optional<crate::syntax::Arg>{});
                    goto _done;
                }
                {
                    _v.set(std::optional<crate::syntax::Arg>{});
                    goto _done;
                }
            _done:
                _v.take();
            });
            ({
            prism_rtl::is_some(filtered_opt) ? ({
            auto&& a = prism_rtl::some_of(filtered_opt);
            ({
            auto a_4 = a;
            call_then(start_value_of(lx_3, env_2, a_4->value), [=](crate::lower::types::Vl value_of_7891) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::types::own(value_of_7891)), Text::lit("filter_some"), Array<crate::lower::model::Ex>{}}), et})); });
        });
        })
            : prism_rtl::is_none(filtered_opt) ? ({
            auto evs = filter(crate::lower::node_::dynamics::operands(e_1), [&](const crate::syntax::Expr& x) { return crate::lower::types::layer_of(crate::lower::type_at(lx_3, x.span)) == crate::lower::types::Layer(crate::lower::types::Layer::LyEv{}); });
            ({
            ({
            auto&& m8055_0 = evs;
            (m8055_0.size() == 1u) && ({
            auto&& _c1 = index(m8055_0, Nat(0u));
            prism_rtl::is_some(_c1);
        });
        }) ? ({
            auto&& m8055_0 = evs;
            auto&& _c1 = index(m8055_0, Nat(0u));
            auto&& one = prism_rtl::some_of(_c1);
            call_then(start_value_of(lx_3, env_2, one), [=](crate::lower::types::Vl value_of_8126) {
            return ({
                auto src = crate::lower::types::own(value_of_8126);
                call_then(crate::lower::types::start_out_ty_of(lx_3, crate::lower::types::peel(crate::lower::type_at(lx_3, one.span))), [=](crate::lower::model::OutTy out_ty_of_8177) {
                return ({
                    auto it = out_ty_of_8177;
                    call_then(crate::check::typed::print::start_exprs_in(e_1), [=](Array<crate::syntax::Expr> exprs_in_8288) {
                    return call_then(start_read_names(exprs_in_8288), [=](Array<Text> read_names_8277) {
                        return ({
                            auto caps = filter(crate::lower::types::with_instances(env_2, read_names_8277), [&](const Text& n) {
                                return ({
                                    __label__ _done;
                                    prism_rtl::Slot<bool> _v;
                                    auto&& _m = crate::prelude::get(env_2->names, n);
                                    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                                        _v.set(true);
                                        goto _done;
                                    }
                                    {
                                        _v.set(false);
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                });
                            });
                            auto [dos, env1] = fold(caps, std::tuple{Array<crate::lower::model::Do>{}, env_2}, [&](const std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>& _p0, const Text& n) {
                                auto&& acc = std::get<0>(_p0);
                                auto&& en = std::get<1>(_p0);
                                return ({
                                    __label__ _done;
                                    prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
                                    auto&& _m = crate::prelude::get(env_2->names, n);
                                    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                                        auto&& rs = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                                        auto&& mode = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                                        auto&& ct = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                                        _v.set(({
                                            auto local = prism_rtl::cat(crate::lower::types::place_stem(rs), "_c");
                                            std::tuple{crate::prelude::push(acc, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{local}), crate::lower::types::own(crate::lower::types::local_place(rs, mode, ct))})), crate::lower::types::bind(en, n, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{local}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), ct}))};
                                        }));
                                        goto _done;
                                    }
                                    {
                                        _v.set(std::tuple{acc, en});
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                });
                            });
                            auto env2 = crate::lower::types::bind_span(env1, crate::lower::place_key(lx_3, one.span), crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("y_ev")}), crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), it}));
                            call_then(start_value_by_kind(lx_3, env2, e_1), [=](crate::lower::types::Vl value_by_kind_8984) {
                            return ({
                                auto body = crate::lower::types::own(value_by_kind_8984);
                                auto mapped = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(src), Text::lit("map"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("y_ev")})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(it)})})}), prism_rtl::rc(body)})})});
                                (prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{crate::prelude::push(dos, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("src_ev")}), src})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("src_ev")})), Text::lit("map"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("y_ev")})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(it)})})}), prism_rtl::rc(body)})})}))}), et})));
                            });
                        });
                        });
                    });
                });
                });
            });
            });
        });
        })
            : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(Text::lit("an event value of several events")), et}));
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
}


/// `Start EventValueOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_event_value_of(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e) {
    return prism_rtl::make_rc<EventValueOf>(lx, env, e);
}


/// ValueByKind: unbounded fn Lx, Env, Expr -> Vl
crate::lower::types::Vl value_by_kind(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& e) {
    auto t = crate::lower::types::out_ty_of(lx, crate::lower::types::peel(crate::lower::type_at(lx, e.span)));
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return name_value(lx, env, n, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELit>(_m)) {
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
        return literal_value(lx, env, l, e.span, false);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUnit>(_m)) {
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBound>(_m)) {
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EBound>(_m).a0;
        auto&& _m = crate::prelude::get(env->names, b);
        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
            auto&& rs = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
            auto&& mode = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
            auto&& bt = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
            return crate::lower::types::local_place(rs, mode, bt);
        }
        {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("`", b, "` outside a `for`")), t});
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ENil>(_m)) {
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XNone{})), t}), t});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m)) {
        auto&& es = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XTuple{run_to_end(each_job(es, ({
            auto lx_1 = lx;
            auto env_2 = env;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Expr)>>(prism_rtl::rc([=](crate::syntax::Expr p0) {
            return ({
                auto lx_1_3 = lx_1;
                auto env_2_3 = env_2;
                entered(once_job([=]() {
                return ({
                    auto x = p0;
                    call_then(start_value_of(lx_1_3, env_2_3, x), [=](crate::lower::types::Vl value_of_9971) { return prism_rtl::finished(crate::lower::types::own(value_of_9971)); });
                });
            }));
            });
        })));
        })))}), t});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EArray>(_m)) {
        auto&& m9534_6_0 = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
        if (m9534_6_0.size() == 0u) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Array::new"), Array<crate::lower::model::Ex>{}})), t}), t});
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EArray>(_m)) {
        auto&& es = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Array::from"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVec{run_to_end(each_job(es, ({
            auto lx_1 = lx;
            auto env_2 = env;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Expr)>>(prism_rtl::rc([=](crate::syntax::Expr p0) {
            return ({
                auto lx_1_3 = lx_1;
                auto env_2_3 = env_2;
                entered(once_job([=]() {
                return ({
                    auto x = p0;
                    call_then(start_value_of(lx_1_3, env_2_3, x), [=](crate::lower::types::Vl value_of_10143) { return prism_rtl::finished(crate::lower::types::own(value_of_10143)); });
                });
            }));
            });
        })));
        })))})})}), t});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMap>(_m)) {
        auto&& m9534_8_0 = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
        if (m9534_8_0.size() == 0u) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Map::new"), Array<crate::lower::model::Ex>{}})), t}), t});
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMap>(_m)) {
        auto&& kvs = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("map_of"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVec{run_to_end(each_job(kvs, ({
            auto lx_1 = lx;
            auto env_2 = env;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::syntax::Expr, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<crate::syntax::Expr, crate::syntax::Expr> p0) {
            return ({
                auto lx_1_3 = lx_1;
                auto env_2_3 = env_2;
                entered(once_job([=]() {
                return ({
                    auto [k, v_] = p0;
                    call_then(start_value_of(lx_1_3, env_2_3, k), [=](crate::lower::types::Vl value_of_10324) { return call_then(start_value_of(lx_1_3, env_2_3, v_), [=](crate::lower::types::Vl value_of_10350) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XTuple{Array(std::vector{crate::lower::types::own(value_of_10324), crate::lower::types::own(value_of_10350)})})); }); });
                });
            }));
            });
        })));
        })))})})}), t});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return value_of(lx, env, x);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        return application(lx, env, c, args, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
        auto&& m = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a1;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
        return application(lx, env, crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{m})), .span = m.span}, append(Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = r, .span = r.span}}), args), e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
        auto&& op = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        return binary_value(lx, env, op, l, r, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m)) {
        auto&& m9534_14_0 = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a0;
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
        if (m9534_14_0 == Text::lit("not")) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{Text::lit("!"), prism_rtl::rc(crate::lower::types::as_bool(value_of(lx, env, x)))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})});
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m)) {
        auto&& m9534_15_0 = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a0;
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
        if (m9534_15_0 == Text::lit("neg")) {
            auto&& _m = x.kind;
            if (prism_rtl::is<crate::syntax::ExprKind::ELit>(_m)) {
                auto&& l = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
                return literal_value(lx, env, l, x.span, true);
            }
            {
                auto v_ = value_of(lx, env, x);
                return crate::lower::types::is_copy(t)
                    ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{Text::lit("-"), prism_rtl::rc(crate::lower::types::copy(v_))}), t})
                    : crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{Text::lit("-"), prism_rtl::rc(crate::lower::types::ref_(v_))}), t});
            }
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
        return value_of(lx, env, x);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
        auto&& m9534_17_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        if (m9534_17_0 == Text::lit("?")) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::types::own(value_of(lx, env, x))})}), t});
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
        auto&& m9534_18_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        if (m9534_18_0 == Text::lit("~")) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Ok"), Array(std::vector{crate::lower::types::own(value_of(lx, env, x))})}), t});
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
        auto&& m9534_19_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        if (m9534_19_0 == Text::lit("@")) {
            return pure_blueprint(lx, env, x, t);
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        return value_of(lx, env, x);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        auto&& name = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a2;
        return field_value(lx, env, r, name.name);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& i = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        return index_value(lx, env, r, i, t);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
        auto&& ps_opt = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
        return lambda_value(lx, env, e, or_(ps_opt, Array<crate::syntax::Pattern_>{}), body);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        return if_value(lx, env, c, then_b, else_b_opt, t);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        return match_value(lx, env, s, arms, t, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETemplate>(_m)) {
        auto&& tp = prism_rtl::as<crate::syntax::ExprKind::ETemplate>(_m).a0;
        return crate::lower::templates::template_value(lx, env, tp);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECast>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a0;
        return value_of(lx, env, x);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
        return value_of(lx, env, x);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGiven>(_m)) {
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EGiven>(_m).a0;
        return crate::lower::templates::given_value(lx, env, b, t, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m)) {
        auto&& target = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
        return crate::lower::templates::update_value(lx, env, target, b, t, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EAny>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EAny>(_m).a0;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::types::own(value_of(lx, env, x))})}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutShowAny{})});
    }
    {
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat(kind_words(e.kind), " as a value")), t});
    }
}


prism_rtl::Turn<crate::lower::types::Vl> ValueByKind::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    auto e_1 = e;
    auto env_2 = env;
    auto lx_3 = lx;
    return call_then(crate::lower::types::start_out_ty_of(lx_3, crate::lower::types::peel(crate::lower::type_at(lx_3, e_1.span))), [=](crate::lower::model::OutTy out_ty_of_9491) {
        return ({
            auto t = out_ty_of_9491;
            ({
            auto&& _m = e_1.kind;
            prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            prism_rtl::more(prism_rtl::rc(NameValue(lx_3, env_2, n, e_1.span)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::ELit>(_m) ? ({
            auto&& l = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
            prism_rtl::more(prism_rtl::rc(LiteralValue(lx_3, env_2, l, e_1.span, false)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EUnit>(_m) ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}))
            : prism_rtl::is<crate::syntax::ExprKind::EBound>(_m) ? ({
            auto&& b = prism_rtl::as<crate::syntax::ExprKind::EBound>(_m).a0;
            ({
            auto&& _m = crate::prelude::get(env_2->names, b);
            prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)) ? ({
            auto&& rs = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
            auto&& mode = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
            auto&& bt = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
            prism_rtl::finished(crate::lower::types::local_place(rs, mode, bt));
        })
            : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("`", b, "` outside a `for`")), t}));
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::ENil>(_m) ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XNone{})), t}), t}))
            : prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m) ? ({
            auto&& es = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
            ({
            auto es_4 = es;
            call_value(each_job(es_4, ({
            auto lx_3_5 = lx_3;
            auto env_2_5 = env_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Expr)>>(prism_rtl::rc([=](crate::syntax::Expr p0) {
            return ({
                auto lx_3_5_5 = lx_3_5;
                auto env_2_5_5 = env_2_5;
                entered(once_job([=]() {
                return ({
                    auto x = p0;
                    call_then(start_value_of(lx_3_5_5, env_2_5_5, x), [=](crate::lower::types::Vl value_of_9971) { return prism_rtl::finished(crate::lower::types::own(value_of_9971)); });
                });
            }));
            });
        })));
        })), [=](Array<crate::lower::model::Ex> each_9952) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XTuple{each_9952}), t})); });
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EArray>(_m) && ({
            auto&& m9534_6_0 = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
            (m9534_6_0.size() == 0u);
        }) ? ({
            auto&& m9534_6_0 = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
            prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Array::new"), Array<crate::lower::model::Ex>{}})), t}), t}));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EArray>(_m) ? ({
            auto&& es = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
            ({
            auto es_4 = es;
            call_value(each_job(es_4, ({
            auto lx_3_5 = lx_3;
            auto env_2_5 = env_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Expr)>>(prism_rtl::rc([=](crate::syntax::Expr p0) {
            return ({
                auto lx_3_5_5 = lx_3_5;
                auto env_2_5_5 = env_2_5;
                entered(once_job([=]() {
                return ({
                    auto x = p0;
                    call_then(start_value_of(lx_3_5_5, env_2_5_5, x), [=](crate::lower::types::Vl value_of_10143) { return prism_rtl::finished(crate::lower::types::own(value_of_10143)); });
                });
            }));
            });
        })));
        })), [=](Array<crate::lower::model::Ex> each_10124) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Array::from"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVec{each_10124})})}), t})); });
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EMap>(_m) && ({
            auto&& m9534_8_0 = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
            (m9534_8_0.size() == 0u);
        }) ? ({
            auto&& m9534_8_0 = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
            prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Map::new"), Array<crate::lower::model::Ex>{}})), t}), t}));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EMap>(_m) ? ({
            auto&& kvs = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
            ({
            auto kvs_4 = kvs;
            call_value(each_job(kvs_4, ({
            auto lx_3_5 = lx_3;
            auto env_2_5 = env_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::syntax::Expr, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<crate::syntax::Expr, crate::syntax::Expr> p0) {
            return ({
                auto lx_3_5_5 = lx_3_5;
                auto env_2_5_5 = env_2_5;
                entered(once_job([=]() {
                return ({
                    auto [k, v_] = p0;
                    call_then(start_value_of(lx_3_5_5, env_2_5_5, k), [=](crate::lower::types::Vl value_of_10324) { return call_then(start_value_of(lx_3_5_5, env_2_5_5, v_), [=](crate::lower::types::Vl value_of_10350) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XTuple{Array(std::vector{crate::lower::types::own(value_of_10324), crate::lower::types::own(value_of_10350)})})); }); });
                });
            }));
            });
        })));
        })), [=](Array<crate::lower::model::Ex> each_10288) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("map_of"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVec{each_10288})})}), t})); });
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
            prism_rtl::more(prism_rtl::rc(ValueOf(lx_3, env_2, x)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::ECall>(_m) ? ({
            auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
            auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
            prism_rtl::more(prism_rtl::rc(Application(lx_3, env_2, c, args, e_1.span)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m) ? ({
            auto&& r = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
            auto&& m = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a1;
            auto&& args = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
            prism_rtl::more(prism_rtl::rc(Application(lx_3, env_2, crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{m})), .span = m.span}, append(Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = r, .span = r.span}}), args), e_1.span)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m) ? ({
            auto&& op = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
            auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
            auto&& r = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
            prism_rtl::more(prism_rtl::rc(BinaryValue(lx_3, env_2, op, l, r, e_1.span)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m) && ({
            auto&& m9534_14_0 = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a0;
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
            (m9534_14_0 == Text::lit("not"));
        }) ? ({
            auto&& m9534_14_0 = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a0;
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
            ({
            auto x_4 = x;
            call_then(start_value_of(lx_3, env_2, x_4), [=](crate::lower::types::Vl value_of_10760) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{Text::lit("!"), prism_rtl::rc(crate::lower::types::as_bool(value_of_10760))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})})); });
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m) && ({
            auto&& m9534_15_0 = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a0;
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
            (m9534_15_0 == Text::lit("neg"));
        }) ? ({
            auto&& m9534_15_0 = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a0;
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
            ({
            auto&& _m = x.kind;
            prism_rtl::is<crate::syntax::ExprKind::ELit>(_m) ? ({
            auto&& l = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
            prism_rtl::more(prism_rtl::rc(LiteralValue(lx_3, env_2, l, x.span, true)));
        })
            : ({
            auto x_4 = x;
            call_then(start_value_of(lx_3, env_2, x_4), [=](crate::lower::types::Vl value_of_10935) {
            return ({
                auto v_ = value_of_10935;
                (crate::lower::types::is_copy(t)
                ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{Text::lit("-"), prism_rtl::rc(crate::lower::types::copy(v_))}), t}))
                : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{Text::lit("-"), prism_rtl::rc(crate::lower::types::ref_(v_))}), t})));
            });
        });
        });
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m) ? ({
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
            prism_rtl::more(prism_rtl::rc(ValueOf(lx_3, env_2, x)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m) && ({
            auto&& m9534_17_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
            (m9534_17_0 == Text::lit("?"));
        }) ? ({
            auto&& m9534_17_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
            ({
            auto x_4 = x;
            call_then(start_value_of(lx_3, env_2, x_4), [=](crate::lower::types::Vl value_of_11158) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::types::own(value_of_11158)})}), t})); });
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m) && ({
            auto&& m9534_18_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
            (m9534_18_0 == Text::lit("~"));
        }) ? ({
            auto&& m9534_18_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
            ({
            auto x_4 = x;
            call_then(start_value_of(lx_3, env_2, x_4), [=](crate::lower::types::Vl value_of_11239) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Ok"), Array(std::vector{crate::lower::types::own(value_of_11239)})}), t})); });
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m) && ({
            auto&& m9534_19_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
            (m9534_19_0 == Text::lit("@"));
        }) ? ({
            auto&& m9534_19_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
            prism_rtl::more(prism_rtl::rc(PureBlueprint(lx_3, env_2, x, t)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m) ? ({
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
            prism_rtl::more(prism_rtl::rc(ValueOf(lx_3, env_2, x)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EField>(_m) ? ({
            auto&& r = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
            auto&& name = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a2;
            prism_rtl::more(prism_rtl::rc(FieldValue(lx_3, env_2, r, name.name)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m) ? ({
            auto&& r = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
            auto&& i = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
            prism_rtl::more(prism_rtl::rc(IndexValue(lx_3, env_2, r, i, t)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) ? ({
            auto&& ps_opt = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
            auto&& body = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
            prism_rtl::more(prism_rtl::rc(LambdaValue(lx_3, env_2, e_1, or_(ps_opt, Array<crate::syntax::Pattern_>{}), body)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
            auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
            auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
            auto&& else_b_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
            prism_rtl::more(prism_rtl::rc(IfValue(lx_3, env_2, c, then_b, else_b_opt, t)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
            auto&& s = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
            auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
            prism_rtl::more(prism_rtl::rc(MatchValue(lx_3, env_2, s, arms, t, e_1.span)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::ETemplate>(_m) ? ({
            auto&& tp = prism_rtl::as<crate::syntax::ExprKind::ETemplate>(_m).a0;
            prism_rtl::more(prism_rtl::rc(crate::lower::templates::TemplateValue(lx_3, env_2, tp)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::ECast>(_m) ? ({
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a0;
            prism_rtl::more(prism_rtl::rc(ValueOf(lx_3, env_2, x)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m) ? ({
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
            prism_rtl::more(prism_rtl::rc(ValueOf(lx_3, env_2, x)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EGiven>(_m) ? ({
            auto&& b = prism_rtl::as<crate::syntax::ExprKind::EGiven>(_m).a0;
            prism_rtl::more(prism_rtl::rc(crate::lower::templates::GivenValue(lx_3, env_2, b, t, e_1.span)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m) ? ({
            auto&& target = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
            auto&& b = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
            prism_rtl::more(prism_rtl::rc(crate::lower::templates::UpdateValue(lx_3, env_2, target, b, t, e_1.span)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EAny>(_m) ? ({
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EAny>(_m).a0;
            ({
            auto x_4 = x;
            call_then(start_value_of(lx_3, env_2, x_4), [=](crate::lower::types::Vl value_of_12002) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::types::own(value_of_12002)})}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutShowAny{})})); });
        });
        })
            : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat(kind_words(e_1.kind), " as a value")), t}));
        });
        });
    });
}


/// `Start ValueByKind, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_value_by_kind(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e) {
    return prism_rtl::make_rc<ValueByKind>(lx, env, e);
}


/// PureBlueprint: unbounded fn Lx, Env, Expr, OutTy -> Vl
crate::lower::types::Vl pure_blueprint(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& x, const crate::lower::model::OutTy& t) {
    auto is_never = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = x.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            _v.set(({
                auto&& _qk_opt = crate::check::env::names::resolve_value(lx.g, lx.home, n);
                auto&& qk_opt = std::get<0>(_qk_opt);
                qk_opt == std::optional(Text::lit("Prelude.never"));
            }));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    return is_never
        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::never_blueprint::<crate::Elem, crate::Answer>"), Array<crate::lower::model::Ex>{}}), t})
        : ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::types::Vl> _v;
        auto&& _m = crate::prelude::get(env->names, Text::lit("#tag"));
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("`@ ", crate::lower::functions::src_text(lx, lx->file, x.span), "` as a supplier's answer outside a tag arm: which tag's output it answers cannot be known")), t}));
            goto _done;
        }
        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)) && prism_rtl::is<crate::lower::model::Ex::XPath>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0)) {
            auto&& variant = prism_rtl::as<crate::lower::model::Ex::XPath>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<crate::lower::types::Vl> _v;
                auto&& _m = crate::lower::types::layer_of(crate::lower::type_at(lx, x.span));
                if (prism_rtl::is<crate::lower::types::Layer::LyEv>(_m)) {
                    _v.set(({
                        auto wrapped = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::types::own(value_of(lx, env, x))), Text::lit("map"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("v")})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}))})})}))})})});
                        (crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::event_blueprint::<crate::Elem, _>"), Array(std::vector{wrapped})}), t}));
                    }));
                    goto _done;
                }
                if (prism_rtl::is<crate::lower::types::Layer::LyDyn>(_m)) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<crate::lower::types::Vl> _v;
                        auto&& _m = crate::lower::node_::static_::dynamic_answer(lx, x);
                        if (prism_rtl::is_none(_m)) {
                            _v.set(({
                                __label__ _done;
                                prism_rtl::Slot<crate::lower::types::Vl> _v;
                                auto&& _m = x.kind;
                                if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
                                    auto&& m13704_0_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
                                    auto&& inner = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
                                    if (m13704_0_0 == Text::lit("$")) {
                                        _v.set(plain_blueprint(lx, env, inner, variant, t));
                                        goto _done;
                                    }
                                }
                                {
                                    _v.set(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("`@ ", crate::lower::functions::src_text(lx, lx->file, x.span), "`, a supplier's dynamic answer of no known form")), t}));
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_some(_m)) {
                            auto&& d = prism_rtl::some_of(_m);
                            _v.set(dynamic_blueprint(lx, env, x, d, variant, t));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                {
                    _v.set(plain_blueprint(lx, env, x, variant, t));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(Text::lit("a supplier's answer under a tag the arm does not name")), t}));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<crate::lower::types::Vl> PureBlueprint::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& x = this->x;
    const auto& t = this->t;
    auto is_never = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = x.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            _v.set(({
                auto&& _qk_opt = crate::check::env::names::resolve_value(lx.g, lx.home, n);
                auto&& qk_opt = std::get<0>(_qk_opt);
                qk_opt == std::optional(Text::lit("Prelude.never"));
            }));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    return is_never
        ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::never_blueprint::<crate::Elem, crate::Answer>"), Array<crate::lower::model::Ex>{}}), t}))
        : ({
        auto&& _m = crate::prelude::get(env->names, Text::lit("#tag"));
        prism_rtl::is_none(_m) ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("`@ ", crate::lower::functions::src_text(lx, lx->file, x.span), "` as a supplier's answer outside a tag arm: which tag's output it answers cannot be known")), t}))
        : prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)) && prism_rtl::is<crate::lower::model::Ex::XPath>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0) ? ({
        auto&& variant = prism_rtl::as<crate::lower::model::Ex::XPath>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0).a0;
        ({
        auto&& _m = crate::lower::types::layer_of(crate::lower::type_at(lx, x.span));
        prism_rtl::is<crate::lower::types::Layer::LyEv>(_m) ? ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto t_3 = t;
        auto x_4 = x;
        call_then(start_value_of(lx_2, env_1, x_4), [=](crate::lower::types::Vl value_of_13433) {
        return ({
            auto wrapped = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::types::own(value_of_13433)), Text::lit("map"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("v")})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}))})})}))})})});
            (prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::event_blueprint::<crate::Elem, _>"), Array(std::vector{wrapped})}), t_3})));
        });
    });
    })
        : prism_rtl::is<crate::lower::types::Layer::LyDyn>(_m) ? ({
        auto&& _m = crate::lower::node_::static_::dynamic_answer(lx, x);
        prism_rtl::is_none(_m) ? ({
        auto&& _m = x.kind;
        prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m) && ({
        auto&& m13704_0_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        auto&& inner = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        (m13704_0_0 == Text::lit("$"));
    }) ? ({
        auto&& m13704_0_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        auto&& inner = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        prism_rtl::more(prism_rtl::rc(PlainBlueprint(lx, env, inner, variant, t)));
    })
        : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("`@ ", crate::lower::functions::src_text(lx, lx->file, x.span), "`, a supplier's dynamic answer of no known form")), t}));
    })
        : prism_rtl::is_some(_m) ? ({
        auto&& d = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(DynamicBlueprint(lx, env, x, d, variant, t)));
    })
        : throw prism_rtl::Panic("no arm matched");
    })
        : prism_rtl::more(prism_rtl::rc(PlainBlueprint(lx, env, x, variant, t)));
    });
    })
        : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(Text::lit("a supplier's answer under a tag the arm does not name")), t}));
    });
}


/// `Start PureBlueprint, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_pure_blueprint(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr x, crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<PureBlueprint>(lx, env, x, t);
}


/// PlainBlueprint: unbounded fn Lx, Env, Expr, Text, OutTy -> Vl
crate::lower::types::Vl plain_blueprint(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& x, const Text& variant, const crate::lower::model::OutTy& t) {
    return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::plain_blueprint::<crate::Elem, _>"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant, Array(std::vector{crate::lower::types::own(value_of(lx, env, x))})})})}), t});
}


prism_rtl::Turn<crate::lower::types::Vl> PlainBlueprint::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& x = this->x;
    const auto& variant = this->variant;
    const auto& t = this->t;
    auto env_1 = env;
    auto lx_2 = lx;
    auto t_3 = t;
    auto variant_4 = variant;
    auto x_5 = x;
    return call_then(start_value_of(lx_2, env_1, x_5), [=](crate::lower::types::Vl value_of_14352) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::plain_blueprint::<crate::Elem, _>"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant_4, Array(std::vector{crate::lower::types::own(value_of_14352)})})})}), t_3})); });
}


/// `Start PlainBlueprint, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_plain_blueprint(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr x, Text variant, crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<PlainBlueprint>(lx, env, x, variant, t);
}


/// DynamicBlueprint: unbounded fn Lx, Env, Expr, Expr, Text, OutTy -> Vl
crate::lower::types::Vl dynamic_blueprint(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& x, const crate::syntax::Expr& d, const Text& variant, const crate::lower::model::OutTy& t) {
    auto&& _m = std::tuple{crate::prelude::get(env->names, prism_rtl::cat("#dyn", crate::lower::node_::static_::dyn_key(x))), crate::prelude::get(env->names, Text::lit("#owner"))};
    if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(std::get<0>(_m))) && prism_rtl::is<crate::lower::model::Ex::XVar>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(std::get<0>(_m))).a0) && prism_rtl::is_some(std::get<1>(_m)) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(std::get<1>(_m))) && prism_rtl::is<crate::lower::model::Ex::XVar>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(std::get<1>(_m))).a0)) {
        auto&& getter = prism_rtl::as<crate::lower::model::Ex::XVar>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(std::get<0>(_m))).a0).a0;
        auto&& dt = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(std::get<0>(_m))).a2;
        auto&& owner = prism_rtl::as<crate::lower::model::Ex::XVar>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(std::get<1>(_m))).a0).a0;
        auto at_build = crate::lower::types::own(value_of(lx, crate::lower::node_::def::init_env(env), d));
        auto arms = Array(std::vector{crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("owner")})})}), .conds = Array<crate::lower::model::Cc>{}, .body = crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("owner")})), getter, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})})}, crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{Text::lit("None")}), .conds = Array<crate::lower::model::Cc>{}, .body = crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("at_build")}))})})})}});
        auto read = crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("cx")})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Cx"), Array<crate::lower::model::OutTy>{}}))})})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMatch{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("link")})), Text::lit("owner"), Array<crate::lower::model::Ex>{}})), arms, false, crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("crate::Answer"), Array<crate::lower::model::OutTy>{}})}))});
        auto dynamic = crate::lower::model::Ex(crate::lower::model::Ex::XBlock{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("link")}), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{owner}))})}), crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("at_build")}), at_build})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::Dynamic::of"), Array(std::vector{read, crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat(getter, "_port")}))})})}))});
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::dynamic_blueprint::<crate::Elem, _>"), Array(std::vector{dynamic})}), t});
    }
    {
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("`@ ", crate::lower::functions::src_text(lx, lx->file, x.span), "`, a supplier's dynamic answer that reads what has no value at the owner's build (a pushed place, a structural dynamic, or a `let` after the host's line)")), t});
    }
}


prism_rtl::Turn<crate::lower::types::Vl> DynamicBlueprint::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& x = this->x;
    const auto& d = this->d;
    const auto& variant = this->variant;
    const auto& t = this->t;
    return ({
        auto&& _m = std::tuple{crate::prelude::get(env->names, prism_rtl::cat("#dyn", crate::lower::node_::static_::dyn_key(x))), crate::prelude::get(env->names, Text::lit("#owner"))};
        prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(std::get<0>(_m))) && prism_rtl::is<crate::lower::model::Ex::XVar>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(std::get<0>(_m))).a0) && prism_rtl::is_some(std::get<1>(_m)) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(std::get<1>(_m))) && prism_rtl::is<crate::lower::model::Ex::XVar>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(std::get<1>(_m))).a0) ? ({
        auto&& getter = prism_rtl::as<crate::lower::model::Ex::XVar>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(std::get<0>(_m))).a0).a0;
        auto&& dt = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(std::get<0>(_m))).a2;
        auto&& owner = prism_rtl::as<crate::lower::model::Ex::XVar>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(std::get<1>(_m))).a0).a0;
        ({
        auto d_1 = d;
        auto env_2 = env;
        auto lx_3 = lx;
        auto t_4 = t;
        auto variant_5 = variant;
        call_then(start_value_of(lx_3, crate::lower::node_::def::init_env(env_2), d_1), [=](crate::lower::types::Vl value_of_15164) {
        return ({
            auto at_build = crate::lower::types::own(value_of_15164);
            auto arms = Array(std::vector{crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("owner")})})}), .conds = Array<crate::lower::model::Cc>{}, .body = crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant_5, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("owner")})), getter, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})})}, crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{Text::lit("None")}), .conds = Array<crate::lower::model::Cc>{}, .body = crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant_5, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("at_build")}))})})})}});
            auto read = crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("cx")})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Cx"), Array<crate::lower::model::OutTy>{}}))})})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMatch{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("link")})), Text::lit("owner"), Array<crate::lower::model::Ex>{}})), arms, false, crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("crate::Answer"), Array<crate::lower::model::OutTy>{}})}))});
            auto dynamic = crate::lower::model::Ex(crate::lower::model::Ex::XBlock{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("link")}), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{owner}))})}), crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("at_build")}), at_build})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::Dynamic::of"), Array(std::vector{read, crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat(getter, "_port")}))})})}))});
            (prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::dynamic_blueprint::<crate::Elem, _>"), Array(std::vector{dynamic})}), t_4})));
        });
    });
    });
    })
        : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("`@ ", crate::lower::functions::src_text(lx, lx->file, x.span), "`, a supplier's dynamic answer that reads what has no value at the owner's build (a pushed place, a structural dynamic, or a `let` after the host's line)")), t}));
    });
}


/// `Start DynamicBlueprint, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_dynamic_blueprint(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr x, crate::syntax::Expr d, Text variant, crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<DynamicBlueprint>(lx, env, x, d, variant, t);
}


/// ElementBlueprint: unbounded fn Lx, Env, [Arg], OutTy -> Vl
crate::lower::types::Vl element_blueprint(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const Array<crate::syntax::Arg>& args, const crate::lower::model::OutTy& t) {
    auto&& _m = index(args, Nat(0u));
    if (prism_rtl::is_some(_m)) {
        auto&& a = prism_rtl::some_of(_m);
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::element_blueprint::<crate::Elem, crate::Answer>"), Array(std::vector{crate::lower::types::ref_(value_of(lx, env, a->value))})}), t});
    }
    if (prism_rtl::is_none(_m)) {
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(Text::lit("`@Element` without its element")), t});
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::types::Vl> ElementBlueprint::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& args = this->args;
    const auto& t = this->t;
    return ({
        auto&& _m = index(args, Nat(0u));
        prism_rtl::is_some(_m) ? ({
        auto&& a = prism_rtl::some_of(_m);
        ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto t_3 = t;
        call_then(start_value_of(lx_2, env_1, a->value), [=](crate::lower::types::Vl value_of_16447) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::element_blueprint::<crate::Elem, crate::Answer>"), Array(std::vector{crate::lower::types::ref_(value_of_16447)})}), t_3})); });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(Text::lit("`@Element` without its element")), t}))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ElementBlueprint, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_element_blueprint(crate::lower::Lx lx, crate::lower::types::Env env, Array<crate::syntax::Arg> args, crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<ElementBlueprint>(lx, env, args, t);
}


/// KindWords: fn ExprKind -> Text
Text kind_words(const crate::syntax::ExprKind& k) {
    if (prism_rtl::is<crate::syntax::ExprKind::ESuffixed>(k)) {
        auto&& op = prism_rtl::as<crate::syntax::ExprKind::ESuffixed>(k).a0;
        return prism_rtl::cat("a suffixed `", op, "`");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(k)) {
        auto&& sg = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(k).a0;
        return prism_rtl::cat("a free `", sg, "`");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETopicField>(k)) {
        return Text::lit("a topic field (`&_.f` outside an `update`)");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETopicIndex>(k)) {
        return Text::lit("a topic index");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ENonEmpty>(k)) {
        return Text::lit("a non-empty literal");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EAbsent>(k)) {
        return Text::lit("an absent value");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ERest>(k)) {
        return Text::lit("a `..` rest");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(k)) {
        return Text::lit("a lambda");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ERebuild>(k)) {
        return Text::lit("a `rebuild` outside a widget block");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFor>(k)) {
        return Text::lit("a `for` outside a widget block");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(k)) {
        return Text::lit("a widget block");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMonad>(k)) {
        return Text::lit("a monadic block");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELens>(k)) {
        return Text::lit("a lens");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EError>(k)) {
        return Text::lit("an expression the parser could not read");
    }
    {
        return Text::lit("an expression");
    }
}


/// NameValue: unbounded fn Lx, Env, SName, Range -> Vl
crate::lower::types::Vl name_value(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::SName& n, const crate::syntax::Range& span) {
    auto nkey = crate::lower::types::name_key_at(lx, env, n, span);
    auto t = crate::lower::types::out_ty_of(lx, crate::lower::types::peel(crate::lower::type_at(lx, span)));
    auto local_opt = len(n->path_) == Nat(1u)
        ? crate::prelude::get(env->names, nkey)
        : std::optional<crate::lower::types::Bn>{};
    if (prism_rtl::is_some(local_opt) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(local_opt))) {
        auto&& rs = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(local_opt)).a0;
        auto&& mode = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(local_opt)).a1;
        auto&& lt = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(local_opt)).a2;
        return crate::lower::types::local_place(rs, mode, lt);
    }
    if (prism_rtl::is_some(local_opt) && prism_rtl::is<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(local_opt))) {
        auto&& f = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(local_opt)).a0;
        auto&& ht = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(local_opt)).a1;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f)})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), ht});
    }
    if (prism_rtl::is_some(local_opt) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(local_opt))) {
        auto&& x = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(local_opt)).a0;
        auto&& dt = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(local_opt)).a2;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{x, dt});
    }
    if (prism_rtl::is_some(local_opt) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(local_opt))) {
        auto&& et = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(local_opt)).a1;
        auto&& _m = crate::prelude::get(env->names, prism_rtl::cat(nkey, "#port"));
        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
            auto&& pf = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::Event::of"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(pf)})})}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutEvent{prism_rtl::rc(crate::lower::types::out_ty_of(lx, crate::lower::types::peel(crate::lower::types::peel(crate::lower::type_at(lx, span)))))})});
        }
        {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(Text::lit("an event read as a value")), et});
        }
    }
    if (prism_rtl::is_some(local_opt) && prism_rtl::is<crate::lower::types::Bn::BnParts>(prism_rtl::some_of(local_opt))) {
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(Text::lit("a tuple pattern's binding as a value")), t});
    }
    if (prism_rtl::is_some(local_opt) && prism_rtl::is<crate::lower::types::Bn::BnWidget>(prism_rtl::some_of(local_opt))) {
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(Text::lit("a widget parameter read as a plain value")), t});
    }
    if (prism_rtl::is_some(local_opt) && prism_rtl::is<crate::lower::types::Bn::BnLocalFn>(prism_rtl::some_of(local_opt))) {
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(Text::lit("a local function as a value")), t});
    }
    if (prism_rtl::is_none(local_opt)) {
        auto [qk_opt, why] = crate::check::env::names::resolve_value(lx.g, lx.home, n);
        if (prism_rtl::is_some(qk_opt)) {
            auto&& m18523_0 = prism_rtl::some_of(qk_opt);
            if (m18523_0 == Text::lit("True")) {
                return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBool{true}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})});
            }
        }
        if (prism_rtl::is_some(qk_opt)) {
            auto&& m18523_1 = prism_rtl::some_of(qk_opt);
            if (m18523_1 == Text::lit("False")) {
                return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBool{false}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})});
            }
        }
        if (prism_rtl::is_some(qk_opt)) {
            auto&& m18523_2 = prism_rtl::some_of(qk_opt);
            if (m18523_2 == Text::lit("Prelude.never")) {
                return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Event::never"), Array<crate::lower::model::Ex>{}}), t});
            }
        }
        if (prism_rtl::is_some(qk_opt)) {
            auto&& qk = prism_rtl::some_of(qk_opt);
            auto&& _m = crate::prelude::get(lx.g.tags, qk);
            if (prism_rtl::is_some(_m)) {
                auto&& tg = prism_rtl::some_of(_m);
                if ((tg.kind != Text::lit("Prelude.Fault")) && (why == Text::lit("tag"))) {
                    return tag_value(lx, env, tg, Array<crate::syntax::Arg>{});
                }
            }
            {
                return global_value(lx, qk, span, t);
            }
        }
        if (prism_rtl::is_none(qk_opt)) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("the name ", nkey, ", which nothing declares")), t});
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::types::Vl> NameValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& n = this->n;
    const auto& span = this->span;
    auto nkey = crate::lower::types::name_key_at(lx, env, n, span);
    auto env_1 = env;
    auto lx_2 = lx;
    auto n_3 = n;
    auto span_4 = span;
    return call_then(crate::lower::types::start_out_ty_of(lx_2, crate::lower::types::peel(crate::lower::type_at(lx_2, span_4))), [=](crate::lower::model::OutTy out_ty_of_17553) {
        return ({
            auto t = out_ty_of_17553;
            auto local_opt = len(n_3->path_) == Nat(1u)
                ? crate::prelude::get(env_1->names, nkey)
                : std::optional<crate::lower::types::Bn>{};
            ({
            prism_rtl::is_some(local_opt) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(local_opt)) ? ({
            auto&& rs = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(local_opt)).a0;
            auto&& mode = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(local_opt)).a1;
            auto&& lt = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(local_opt)).a2;
            prism_rtl::finished(crate::lower::types::local_place(rs, mode, lt));
        })
            : prism_rtl::is_some(local_opt) && prism_rtl::is<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(local_opt)) ? ({
            auto&& f = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(local_opt)).a0;
            auto&& ht = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(local_opt)).a1;
            prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f)})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), ht}));
        })
            : prism_rtl::is_some(local_opt) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(local_opt)) ? ({
            auto&& x = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(local_opt)).a0;
            auto&& dt = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(local_opt)).a2;
            prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{x, dt}));
        })
            : prism_rtl::is_some(local_opt) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(local_opt)) ? ({
            auto&& et = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(local_opt)).a1;
            ({
            auto&& _m = crate::prelude::get(env_1->names, prism_rtl::cat(nkey, "#port"));
            prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)) ? ({
            auto&& pf = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
            call_then(crate::lower::types::start_out_ty_of(lx_2, crate::lower::types::peel(crate::lower::types::peel(crate::lower::type_at(lx_2, span_4)))), [=](crate::lower::model::OutTy out_ty_of_18033) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::Event::of"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(pf)})})}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutEvent{prism_rtl::rc(out_ty_of_18033)})})); });
        })
            : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(Text::lit("an event read as a value")), et}));
        });
        })
            : prism_rtl::is_some(local_opt) && prism_rtl::is<crate::lower::types::Bn::BnParts>(prism_rtl::some_of(local_opt)) ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(Text::lit("a tuple pattern's binding as a value")), t}))
            : prism_rtl::is_some(local_opt) && prism_rtl::is<crate::lower::types::Bn::BnWidget>(prism_rtl::some_of(local_opt)) ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(Text::lit("a widget parameter read as a plain value")), t}))
            : prism_rtl::is_some(local_opt) && prism_rtl::is<crate::lower::types::Bn::BnLocalFn>(prism_rtl::some_of(local_opt)) ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(Text::lit("a local function as a value")), t}))
            : prism_rtl::is_none(local_opt) ? ({
            auto [qk_opt, why] = crate::check::env::names::resolve_value(lx_2.g, lx_2.home, n_3);
            ({
            prism_rtl::is_some(qk_opt) && ({
            auto&& m18523_0 = prism_rtl::some_of(qk_opt);
            (m18523_0 == Text::lit("True"));
        }) ? ({
            auto&& m18523_0 = prism_rtl::some_of(qk_opt);
            prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBool{true}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})}));
        })
            : prism_rtl::is_some(qk_opt) && ({
            auto&& m18523_1 = prism_rtl::some_of(qk_opt);
            (m18523_1 == Text::lit("False"));
        }) ? ({
            auto&& m18523_1 = prism_rtl::some_of(qk_opt);
            prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBool{false}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})}));
        })
            : prism_rtl::is_some(qk_opt) && ({
            auto&& m18523_2 = prism_rtl::some_of(qk_opt);
            (m18523_2 == Text::lit("Prelude.never"));
        }) ? ({
            auto&& m18523_2 = prism_rtl::some_of(qk_opt);
            prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Event::never"), Array<crate::lower::model::Ex>{}}), t}));
        })
            : prism_rtl::is_some(qk_opt) ? ({
            auto&& qk = prism_rtl::some_of(qk_opt);
            ({
            auto&& _m = crate::prelude::get(lx_2.g.tags, qk);
            prism_rtl::is_some(_m) && ({
            auto&& tg = prism_rtl::some_of(_m);
            ((tg.kind != Text::lit("Prelude.Fault")) && (why == Text::lit("tag")));
        }) ? ({
            auto&& tg = prism_rtl::some_of(_m);
            prism_rtl::more(prism_rtl::rc(TagValue(lx_2, env_1, tg, Array<crate::syntax::Arg>{})));
        })
            : prism_rtl::more(prism_rtl::rc(GlobalValue(lx_2, qk, span_4, t)));
        });
        })
            : prism_rtl::is_none(qk_opt) ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("the name ", nkey, ", which nothing declares")), t}))
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
}


/// `Start NameValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_name_value(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::SName n, crate::syntax::Range span) {
    return prism_rtl::make_rc<NameValue>(lx, env, n, span);
}


/// GlobalValue: unbounded fn Lx, Text, Range, OutTy -> Vl
crate::lower::types::Vl global_value(const crate::lower::Lx& lx, const Text& qk, const crate::syntax::Range& span, const crate::lower::model::OutTy& t) {
    auto&& _m = crate::prelude::get(lx.g.ctors, qk);
    if (prism_rtl::is_some(_m)) {
        auto&& c = prism_rtl::some_of(_m);
        auto arity = len(c.fields) > Nat(0u) ? len(c.fields) : len(c->args);
        if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(t)) {
            auto&& pts = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t).a0;
            return arity > Nat(0u)
                ? ctor_fn(lx, c, pts, span, t, false)
                : ctor_app(lx, crate::lower::types::empty_env(), c, Array<crate::syntax::Arg>{}, span);
        }
        if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t)) {
            auto&& a = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t).a0;
            auto pts = ({
                __label__ _done;
                prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
                auto&& _m = a;
                if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(_m)) {
                    auto&& ts = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(_m).a0;
                    _v.set(arity == Nat(1u) ? Array(std::vector{a}) : ts);
                    goto _done;
                }
                {
                    _v.set(Array(std::vector{a}));
                    goto _done;
                }
            _done:
                _v.take();
            });
            return arity > Nat(0u)
                ? ctor_fn(lx, c, pts, span, t, true)
                : ctor_app(lx, crate::lower::types::empty_env(), c, Array<crate::syntax::Arg>{}, span);
        }
        {
            return ctor_app(lx, crate::lower::types::empty_env(), c, Array<crate::syntax::Arg>{}, span);
        }
    }
    if (prism_rtl::is_none(_m)) {
        auto&& _m = crate::prelude::get(lx.g.tags, qk);
        if (prism_rtl::is_some(_m)) {
            auto&& tg = prism_rtl::some_of(_m);
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XStr{tg.name}), t});
        }
        if (prism_rtl::is_none(_m)) {
            return fold(lx.g.defs, false, [&](const bool& f, const crate::check::env::Def& d) { return f || ((d.qk == qk) && is_let_def(d)); })
                ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::value_path(lx, qk), Array<crate::lower::model::Ex>{}}), t})
                : ({
                __label__ _done;
                prism_rtl::Slot<crate::lower::types::Vl> _v;
                auto&& _m = crate::prelude::get(lx.g.vals, qk);
                if (prism_rtl::is_some(_m)) {
                    auto&& v_ = prism_rtl::some_of(_m);
                    _v.set(({
                        auto is_let = fold(lx.g.defs, false, [&](const bool& f, const crate::check::env::Def& d) { return f || ((d.qk == qk) && is_let_def(d)); });
                        is_let
                        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::value_path(lx, qk), Array<crate::lower::model::Ex>{}}), t})
                        : ({
                        __label__ _done;
                        prism_rtl::Slot<crate::lower::types::Vl> _v;
                        if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t)) {
                            auto&& a = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t).a0;
                            _v.set(({
                                auto [ps, ignore2] = crate::lower::jobs::scheme_parts(lx, qk);
                                auto names = each(crate::check::errors::range0(len(ps)), [&](const Nat& i) { return prism_rtl::cat("a", i); });
                                auto pa = len(ps) == Nat(1u)
                                    ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("a0")})), a})
                                    : crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(names, [&](const Text& nm) { return crate::lower::model::Pa(crate::lower::model::Pa::PaBind{nm}); })})), a});
                                auto f = crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{pa}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("entered"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{start_path(lx, qk), each(names, [&](const Text& nm) { return crate::lower::model::Ex(crate::lower::model::Ex::XVar{nm}); })})})}))});
                                (crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{f})})), t}), t}));
                            }));
                            goto _done;
                        }
                        {
                            _v.set(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XPath{crate::lower::value_path(lx, qk)})})}), t}));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("the global ", qk)), t}));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::types::Vl> GlobalValue::cycle() const {
    const auto& lx = this->lx;
    const auto& qk = this->qk;
    const auto& span = this->span;
    const auto& t = this->t;
    return ({
        auto&& _m = crate::prelude::get(lx.g.ctors, qk);
        prism_rtl::is_some(_m) ? ({
        auto&& c = prism_rtl::some_of(_m);
        ({
        auto arity = len(c.fields) > Nat(0u) ? len(c.fields) : len(c->args);
        ({
        prism_rtl::is<crate::lower::model::OutTy::OutFn>(t) ? ({
        auto&& pts = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t).a0;
        arity > Nat(0u)
        ? prism_rtl::more(prism_rtl::rc(CtorFn(lx, c, pts, span, t, false)))
        : prism_rtl::more(prism_rtl::rc(CtorApp(lx, crate::lower::types::empty_env(), c, Array<crate::syntax::Arg>{}, span)));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t) ? ({
        auto&& a = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t).a0;
        ({
        auto pts = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
            auto&& _m = a;
            if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(_m)) {
                auto&& ts = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(_m).a0;
                _v.set(arity == Nat(1u) ? Array(std::vector{a}) : ts);
                goto _done;
            }
            {
                _v.set(Array(std::vector{a}));
                goto _done;
            }
        _done:
            _v.take();
        });
        arity > Nat(0u)
        ? prism_rtl::more(prism_rtl::rc(CtorFn(lx, c, pts, span, t, true)))
        : prism_rtl::more(prism_rtl::rc(CtorApp(lx, crate::lower::types::empty_env(), c, Array<crate::syntax::Arg>{}, span)));
    });
    })
        : prism_rtl::more(prism_rtl::rc(CtorApp(lx, crate::lower::types::empty_env(), c, Array<crate::syntax::Arg>{}, span)));
    });
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto&& _m = crate::prelude::get(lx.g.tags, qk);
        prism_rtl::is_some(_m) ? ({
        auto&& tg = prism_rtl::some_of(_m);
        prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XStr{tg.name}), t}));
    })
        : prism_rtl::is_none(_m) ? fold(lx.g.defs, false, [&](const bool& f, const crate::check::env::Def& d) { return f || ((d.qk == qk) && is_let_def(d)); })
        ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::value_path(lx, qk), Array<crate::lower::model::Ex>{}}), t}))
        : ({
        auto&& _m = crate::prelude::get(lx.g.vals, qk);
        prism_rtl::is_some(_m) ? ({
        auto&& v_ = prism_rtl::some_of(_m);
        ({
        auto is_let = fold(lx.g.defs, false, [&](const bool& f, const crate::check::env::Def& d) { return f || ((d.qk == qk) && is_let_def(d)); });
        is_let
        ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::value_path(lx, qk), Array<crate::lower::model::Ex>{}}), t}))
        : ({
        prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t) ? ({
        auto&& a = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t).a0;
        ({
        auto [ps, ignore2] = crate::lower::jobs::scheme_parts(lx, qk);
        auto names = each(crate::check::errors::range0(len(ps)), [&](const Nat& i) { return prism_rtl::cat("a", i); });
        auto pa = len(ps) == Nat(1u)
            ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("a0")})), a})
            : crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(names, [&](const Text& nm) { return crate::lower::model::Pa(crate::lower::model::Pa::PaBind{nm}); })})), a});
        auto f = crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{pa}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("entered"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{start_path(lx, qk), each(names, [&](const Text& nm) { return crate::lower::model::Ex(crate::lower::model::Ex::XVar{nm}); })})})}))});
        (prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{f})})), t}), t})));
    });
    })
        : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XPath{crate::lower::value_path(lx, qk)})})}), t}));
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("the global ", qk)), t}))
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start GlobalValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_global_value(crate::lower::Lx lx, Text qk, crate::syntax::Range span, crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<GlobalValue>(lx, qk, span, t);
}


/// IsLetDef: fn Def -> Bool
bool is_let_def(const crate::check::env::Def& d) {
    auto&& _m = d.body;
    if (prism_rtl::is<crate::check::env::DefBody::DbLet>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// StartPath: fn Lx, Text -> Text
Text start_path(const crate::lower::Lx& lx, const Text& qk) {
    auto owner = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = crate::prelude::get(lx.g.vals, qk);
        if (prism_rtl::is_some(_m)) {
            auto&& v_ = prism_rtl::some_of(_m);
            _v.set(v_.home);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::lower::owner_of(qk));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return crate::lower::path_in(lx, owner, prism_rtl::cat("start_", or_(crate::prelude::get(lx.rs_names, qk), crate::lower::snake(crate::check::types::bare_name(qk)))));
}


/// Application: unbounded fn Lx, Env, Expr, [Arg], Range -> Vl
crate::lower::types::Vl application(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& callee, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span) {
    auto t = crate::lower::types::out_ty_of(lx, crate::lower::types::peel(crate::lower::type_at(lx, span)));
    auto&& _m = callee.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        auto nkey = crate::lower::types::name_key_at(lx, env, n, callee.span);
        auto local_opt = len(n->path_) == Nat(1u)
            ? crate::prelude::get(env->names, nkey)
            : std::optional<crate::lower::types::Bn>{};
        if (prism_rtl::is_some(local_opt) && prism_rtl::is<crate::lower::types::Bn::BnLocalFn>(prism_rtl::some_of(local_opt))) {
            auto&& c = prism_rtl::as<crate::lower::types::Bn::BnLocalFn>(prism_rtl::some_of(local_opt)).a0;
            return inline_local_fn(lx, env, c, args, t);
        }
        if (prism_rtl::is_some(local_opt)) {
            auto&& b = prism_rtl::some_of(local_opt);
            auto f = name_value(lx, env, n, callee.span);
            auto&& _m = crate::lower::types::value_ty(f);
            if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m)) {
                return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("run_to_end"), Array(std::vector{crate::lower::jobs::start_call(f, start_args(lx, env, f, args))})}), t});
            }
            {
                return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XApply{prism_rtl::rc(crate::lower::types::ref_(f)), run_to_end(each_job(args, ({
                    auto lx_1 = lx;
                    auto env_2 = env;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=](crate::syntax::Arg p0) {
                    return ({
                        auto lx_1_3 = lx_1;
                        auto env_2_3 = env_2;
                        entered(once_job([=]() {
                        return ({
                            auto a = p0;
                            (prism_rtl::more(prism_rtl::rc(Argument(lx_1_3, env_2_3, a->value))));
                        });
                    }));
                    });
                })));
                })))}), t});
            }
        }
        if (prism_rtl::is_none(local_opt)) {
            auto [qk_opt, why] = crate::check::env::names::resolve_value(lx.g, lx.home, n);
            if (prism_rtl::is_some(qk_opt)) {
                auto&& qk = prism_rtl::some_of(qk_opt);
                auto&& _m = crate::prelude::get(lx.g.tags, qk);
                if (prism_rtl::is_some(_m)) {
                    auto&& tg = prism_rtl::some_of(_m);
                    if (why == Text::lit("tag")) {
                        return tag_value(lx, env, tg, args);
                    }
                }
                {
                    return qk == Text::lit("Prelude.@Element")
                        ? element_blueprint(lx, env, args, t)
                        : global_call(lx, env, qk, args, span, t);
                }
            }
            if (prism_rtl::is_none(qk_opt)) {
                return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("a call of ", nkey, ", which nothing declares")), t});
            }
            prism_rtl::unreachable("no arm matched");
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return application(lx, env, x, args, span);
    }
    {
        auto f = value_of(lx, env, callee);
        auto&& _m = crate::lower::types::value_ty(f);
        if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m)) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("run_to_end"), Array(std::vector{crate::lower::jobs::start_call(f, start_args(lx, env, f, args))})}), t});
        }
        {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XApply{prism_rtl::rc(crate::lower::types::ref_(f)), run_to_end(each_job(args, ({
                auto lx_1 = lx;
                auto env_2 = env;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=](crate::syntax::Arg p0) {
                return ({
                    auto lx_1_3 = lx_1;
                    auto env_2_3 = env_2;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        (prism_rtl::more(prism_rtl::rc(Argument(lx_1_3, env_2_3, a->value))));
                    });
                }));
                });
            })));
            })))}), t});
        }
    }
}


prism_rtl::Turn<crate::lower::types::Vl> Application::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& callee = this->callee;
    const auto& args = this->args;
    const auto& span = this->span;
    auto args_1 = args;
    auto callee_2 = callee;
    auto env_3 = env;
    auto lx_4 = lx;
    auto span_5 = span;
    return call_then(crate::lower::types::start_out_ty_of(lx_4, crate::lower::types::peel(crate::lower::type_at(lx_4, span_5))), [=](crate::lower::model::OutTy out_ty_of_21424) {
        return ({
            auto t = out_ty_of_21424;
            ({
            auto&& _m = callee_2.kind;
            prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            ({
            auto nkey = crate::lower::types::name_key_at(lx_4, env_3, n, callee_2.span);
            auto local_opt = len(n->path_) == Nat(1u)
                ? crate::prelude::get(env_3->names, nkey)
                : std::optional<crate::lower::types::Bn>{};
            ({
            prism_rtl::is_some(local_opt) && prism_rtl::is<crate::lower::types::Bn::BnLocalFn>(prism_rtl::some_of(local_opt)) ? ({
            auto&& c = prism_rtl::as<crate::lower::types::Bn::BnLocalFn>(prism_rtl::some_of(local_opt)).a0;
            prism_rtl::more(prism_rtl::rc(InlineLocalFn(lx_4, env_3, c, args_1, t)));
        })
            : prism_rtl::is_some(local_opt) ? ({
            auto&& b = prism_rtl::some_of(local_opt);
            ({
            auto n_6 = n;
            call_then(start_name_value(lx_4, env_3, n_6, callee_2.span), [=](crate::lower::types::Vl name_value_21773) {
            return ({
                auto f = name_value_21773;
                ({
                auto&& _m = crate::lower::types::value_ty(f);
                prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m) ? call_then(start_start_args(lx_4, env_3, f, args_1), [=](Array<crate::lower::model::Ex> start_args_21967) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("run_to_end"), Array(std::vector{crate::lower::jobs::start_call(f, start_args_21967)})}), t})); })
                : call_value(each_job(args_1, ({
                auto lx_4_7 = lx_4;
                auto env_3_7 = env_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=](crate::syntax::Arg p0) {
                return ({
                    auto lx_4_7_7 = lx_4_7;
                    auto env_3_7_7 = env_3_7;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        (prism_rtl::more(prism_rtl::rc(Argument(lx_4_7_7, env_3_7_7, a->value))));
                    });
                }));
                });
            })));
            })), [=](Array<crate::lower::model::Ex> each_22063) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XApply{prism_rtl::rc(crate::lower::types::ref_(f)), each_22063}), t})); });
            });
            });
        });
        });
        })
            : prism_rtl::is_none(local_opt) ? ({
            auto [qk_opt, why] = crate::check::env::names::resolve_value(lx_4.g, lx_4.home, n);
            ({
            prism_rtl::is_some(qk_opt) ? ({
            auto&& qk = prism_rtl::some_of(qk_opt);
            ({
            auto&& _m = crate::prelude::get(lx_4.g.tags, qk);
            prism_rtl::is_some(_m) && ({
            auto&& tg = prism_rtl::some_of(_m);
            (why == Text::lit("tag"));
        }) ? ({
            auto&& tg = prism_rtl::some_of(_m);
            prism_rtl::more(prism_rtl::rc(TagValue(lx_4, env_3, tg, args_1)));
        })
            : qk == Text::lit("Prelude.@Element")
            ? prism_rtl::more(prism_rtl::rc(ElementBlueprint(lx_4, env_3, args_1, t)))
            : prism_rtl::more(prism_rtl::rc(GlobalCall(lx_4, env_3, qk, args_1, span_5, t)));
        });
        })
            : prism_rtl::is_none(qk_opt) ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("a call of ", nkey, ", which nothing declares")), t}))
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
            prism_rtl::more(prism_rtl::rc(Application(lx_4, env_3, x, args_1, span_5)));
        })
            : call_then(start_value_of(lx_4, env_3, callee_2), [=](crate::lower::types::Vl value_of_22886) {
            return ({
                auto f = value_of_22886;
                ({
                auto&& _m = crate::lower::types::value_ty(f);
                prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m) ? call_then(start_start_args(lx_4, env_3, f, args_1), [=](Array<crate::lower::model::Ex> start_args_23026) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("run_to_end"), Array(std::vector{crate::lower::jobs::start_call(f, start_args_23026)})}), t})); })
                : call_value(each_job(args_1, ({
                auto lx_4_6 = lx_4;
                auto env_3_6 = env_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=](crate::syntax::Arg p0) {
                return ({
                    auto lx_4_6_6 = lx_4_6;
                    auto env_3_6_6 = env_3_6;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        (prism_rtl::more(prism_rtl::rc(Argument(lx_4_6_6, env_3_6_6, a->value))));
                    });
                }));
                });
            })));
            })), [=](Array<crate::lower::model::Ex> each_23114) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XApply{prism_rtl::rc(crate::lower::types::ref_(f)), each_23114}), t})); });
            });
            });
        });
        });
        });
    });
}


/// `Start Application, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_application(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr callee, Array<crate::syntax::Arg> args, crate::syntax::Range span) {
    return prism_rtl::make_rc<Application>(lx, env, callee, args, span);
}


/// InlineLocalFn: unbounded fn Lx, Env, FnClause, [Arg], OutTy -> Vl
crate::lower::types::Vl inline_local_fn(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::decls::FnClause& c, const Array<crate::syntax::Arg>& args, const crate::lower::model::OutTy& t) {
    auto names = each(c.params, [&](const crate::syntax::Pattern_& p_) { return crate::lower::functions::plain_binder(lx, p_); });
    return fold(names, false, [&](const bool& bad, const Text& nm) { return bad || (nm == Text::lit("")); })
        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(Text::lit("a local function whose parameters are not names")), t})
        : ({
        auto [dos, env2] = run_to_end(fold_job(crate::check::errors::range0(len(names)), std::tuple{Array<crate::lower::model::Do>{}, env}, ({
            auto names_1 = names;
            auto lx_2 = lx;
            auto c_3 = c;
            auto args_4 = args;
            auto env_5 = env;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>>(std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto names_1_6 = names_1;
                auto lx_2_6 = lx_2;
                auto c_3_6 = c_3;
                auto args_4_6 = args_4;
                auto env_5_6 = env_5;
                entered(once_job([=]() {
                return ({
                    auto [acc, en] = p0;
                    auto i = p1;
                    ({
                    auto nm = or_(index(names_1_6, i), Text::lit(""));
                    auto rs = prism_rtl::cat(crate::lower::local_name(lx_2_6, nm), "_", c_3_6.span.start);
                    auto v_ = ({
                        __label__ _done;
                        prism_rtl::Slot<crate::lower::types::Vl> _v;
                        auto&& _m = index(args_4_6, i);
                        if (prism_rtl::is_some(_m)) {
                            auto&& a = prism_rtl::some_of(_m);
                            _v.set(value_of(lx_2_6, env_5_6, a->value));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    auto bt = crate::lower::types::value_ty(v_);
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{rs}), crate::lower::types::own(v_)})), crate::lower::types::bind(en, nm, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt}))}));
                });
                });
            }));
            });
        }));
        })));
        (crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos, prism_rtl::rc(crate::lower::functions::fn_body_value(lx, env2, c.body))}), t}));
    });
}


prism_rtl::Turn<crate::lower::types::Vl> InlineLocalFn::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& c = this->c;
    const auto& args = this->args;
    const auto& t = this->t;
    auto names = each(c.params, [&](const crate::syntax::Pattern_& p_) { return crate::lower::functions::plain_binder(lx, p_); });
    return fold(names, false, [&](const bool& bad, const Text& nm) { return bad || (nm == Text::lit("")); })
        ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(Text::lit("a local function whose parameters are not names")), t}))
        : ({
        auto args_1 = args;
        auto c_2 = c;
        auto env_3 = env;
        auto lx_4 = lx;
        auto t_5 = t;
        call_value(fold_job(crate::check::errors::range0(len(names)), std::tuple{Array<crate::lower::model::Do>{}, env_3}, ({
        auto names_6 = names;
        auto lx_4_7 = lx_4;
        auto c_2_7 = c_2;
        auto args_1_7 = args_1;
        auto env_3_7 = env_3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>>(std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto names_6_7 = names_6;
            auto lx_4_7_7 = lx_4_7;
            auto c_2_7_7 = c_2_7;
            auto args_1_7_7 = args_1_7;
            auto env_3_7_7 = env_3_7;
            entered(once_job([=]() {
            return ({
                auto [acc, en] = p0;
                auto i = p1;
                ({
                auto nm = or_(index(names_6_7, i), Text::lit(""));
                auto rs = prism_rtl::cat(crate::lower::local_name(lx_4_7_7, nm), "_", c_2_7_7.span.start);
                auto v_ = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::lower::types::Vl> _v;
                    auto&& _m = index(args_1_7_7, i);
                    if (prism_rtl::is_some(_m)) {
                        auto&& a = prism_rtl::some_of(_m);
                        _v.set(value_of(lx_4_7_7, env_3_7_7, a->value));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto bt = crate::lower::types::value_ty(v_);
                (prism_rtl::finished(std::tuple{crate::prelude::push(acc, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{rs}), crate::lower::types::own(v_)})), crate::lower::types::bind(en, nm, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt}))}));
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> fold_23700) {
        return ({
            auto [dos, env2] = fold_23700;
            call_then(crate::lower::functions::start_fn_body_value(lx_4, env2, c_2.body), [=](crate::lower::model::Ex fn_body_value_24146) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos, prism_rtl::rc(fn_body_value_24146)}), t_5})); });
        });
    });
    });
}


/// `Start InlineLocalFn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_inline_local_fn(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::decls::FnClause c, Array<crate::syntax::Arg> args, crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<InlineLocalFn>(lx, env, c, args, t);
}


/// Argument: unbounded fn Lx, Env, Expr -> Ex
crate::lower::model::Ex argument(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& e) {
    auto&& _m = crate::prelude::get(env.spans, crate::lower::place_key(lx, e.span));
    if (prism_rtl::is_some(_m)) {
        auto&& v_ = prism_rtl::some_of(_m);
        return crate::lower::types::ref_(v_);
    }
    if (prism_rtl::is_none(_m)) {
        return argument_by_kind(lx, env, e);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::model::Ex> Argument::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    return ({
        auto&& _m = crate::prelude::get(env.spans, crate::lower::place_key(lx, e.span));
        prism_rtl::is_some(_m) ? ({
        auto&& v_ = prism_rtl::some_of(_m);
        prism_rtl::finished(crate::lower::types::ref_(v_));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(ArgumentByKind(lx, env, e)))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start Argument, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_argument(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e) {
    return prism_rtl::make_rc<Argument>(lx, env, e);
}


/// ArgumentByKind: unbounded fn Lx, Env, Expr -> Ex
crate::lower::model::Ex argument_by_kind(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
        auto&& ps_opt = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
        return crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(lambda_arg(lx, env, or_(ps_opt, Array<crate::syntax::Pattern_>{}), body, lambda_param_tys(lx, e, len(or_(ps_opt, Array<crate::syntax::Pattern_>{})))))});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return argument(lx, env, x);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        auto t = crate::lower::type_at(lx, e.span);
        auto&& _m = crate::lower::types::peel(t);
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CBound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0)) {
            auto local_opt = len(n->path_) == Nat(1u)
                ? crate::prelude::get(env->names, crate::lower::types::name_key_at(lx, env, n, e.span))
                : std::optional<crate::lower::types::Bn>{};
            if (prism_rtl::is_some(local_opt)) {
                return closure_ref(value_of(lx, env, e));
            }
            if (prism_rtl::is_none(local_opt)) {
                auto&& _qk_opt = crate::check::env::names::resolve_value(lx.g, lx.home, n);
                auto&& qk_opt = std::get<0>(_qk_opt);
                if (prism_rtl::is_some(qk_opt)) {
                    auto&& qk = prism_rtl::some_of(qk_opt);
                    return crate::check::env::has_key(lx.g.ctors, qk)
                        ? closure_ref(value_of(lx, env, e))
                        : crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XPath{crate::lower::value_path(lx, qk)}))});
                }
                if (prism_rtl::is_none(qk_opt)) {
                    return crate::lower::types::ref_(value_of(lx, env, e));
                }
                prism_rtl::unreachable("no arm matched");
            }
            prism_rtl::unreachable("no arm matched");
        }
        {
            return crate::lower::types::ref_(value_of(lx, env, e));
        }
    }
    {
        return crate::lower::types::ref_(value_of(lx, env, e));
    }
}


prism_rtl::Turn<crate::lower::model::Ex> ArgumentByKind::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) ? ({
        auto&& ps_opt = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
        ({
        auto ps_opt_1 = ps_opt;
        auto body_2 = body;
        auto e_3 = e;
        auto env_4 = env;
        auto lx_5 = lx;
        call_then(start_lambda_param_tys(lx_5, e_3, len(or_(ps_opt_1, Array<crate::syntax::Pattern_>{}))), [=](Array<crate::lower::model::OutTy> lambda_param_tys_24584) { return call_then(start_lambda_arg(lx_5, env_4, or_(ps_opt_1, Array<crate::syntax::Pattern_>{}), body_2, lambda_param_tys_24584), [=](crate::lower::model::Ex lambda_arg_24542) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(lambda_arg_24542)})); }); });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(Argument(lx, env, x)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        ({
        auto t = crate::lower::type_at(lx, e.span);
        ({
        auto&& _m = crate::lower::types::peel(t);
        prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CBound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0) ? ({
        auto local_opt = len(n->path_) == Nat(1u)
            ? crate::prelude::get(env->names, crate::lower::types::name_key_at(lx, env, n, e.span))
            : std::optional<crate::lower::types::Bn>{};
        ({
        prism_rtl::is_some(local_opt) ? ({
        auto e_1 = e;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(start_value_of(lx_3, env_2, e_1), [=](crate::lower::types::Vl value_of_24946) { return prism_rtl::finished(closure_ref(value_of_24946)); });
    })
        : prism_rtl::is_none(local_opt) ? ({
        auto&& _qk_opt = crate::check::env::names::resolve_value(lx.g, lx.home, n);
        auto&& qk_opt = std::get<0>(_qk_opt);
        ({
        prism_rtl::is_some(qk_opt) ? ({
        auto&& qk = prism_rtl::some_of(qk_opt);
        crate::check::env::has_key(lx.g.ctors, qk)
        ? ({
        auto e_1 = e;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(start_value_of(lx_3, env_2, e_1), [=](crate::lower::types::Vl value_of_25174) { return prism_rtl::finished(closure_ref(value_of_25174)); });
    })
        : prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XPath{crate::lower::value_path(lx, qk)}))}));
    })
        : prism_rtl::is_none(qk_opt) ? ({
        auto e_1 = e;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(start_value_of(lx_3, env_2, e_1), [=](crate::lower::types::Vl value_of_25270) { return prism_rtl::finished(crate::lower::types::ref_(value_of_25270)); });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : ({
        auto e_1 = e;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(start_value_of(lx_3, env_2, e_1), [=](crate::lower::types::Vl value_of_25318) { return prism_rtl::finished(crate::lower::types::ref_(value_of_25318)); });
    });
    });
    });
    })
        : ({
        auto e_1 = e;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(start_value_of(lx_3, env_2, e_1), [=](crate::lower::types::Vl value_of_25358) { return prism_rtl::finished(crate::lower::types::ref_(value_of_25358)); });
    });
    });
}


/// `Start ArgumentByKind, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_argument_by_kind(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e) {
    return prism_rtl::make_rc<ArgumentByKind>(lx, env, e);
}


/// ClosureRef: fn Vl -> Ex
crate::lower::model::Ex closure_ref(const crate::lower::types::Vl& vl0) {
    if (prism_rtl::is<crate::lower::types::Vl::VlPlace>(vl0) && prism_rtl::is<crate::lower::types::Holding::ByRef>(prism_rtl::as<crate::lower::types::Vl::VlPlace>(vl0).a1)) {
        auto&& x = prism_rtl::as<crate::lower::types::Vl::VlPlace>(vl0).a0;
        auto&& t = prism_rtl::as<crate::lower::types::Vl::VlPlace>(vl0).a2;
        return x;
    }
    if (prism_rtl::is<crate::lower::types::Vl::VlPlace>(vl0)) {
        auto&& x = prism_rtl::as<crate::lower::types::Vl::VlPlace>(vl0).a0;
        auto&& t = prism_rtl::as<crate::lower::types::Vl::VlPlace>(vl0).a2;
        return crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(x)}))});
    }
    if (prism_rtl::is<crate::lower::types::Vl::VlOwned>(vl0)) {
        auto&& x = prism_rtl::as<crate::lower::types::Vl::VlOwned>(vl0).a0;
        auto&& t = prism_rtl::as<crate::lower::types::Vl::VlOwned>(vl0).a1;
        return crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(x)}))});
    }
    prism_rtl::unreachable("no arm matched");
}


/// TagValue: unbounded fn Lx, Env, TagInfo, [Arg] -> Vl
crate::lower::types::Vl tag_value(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::check::env::TagInfo& tg, const Array<crate::syntax::Arg>& args) {
    auto [variant, struct_path] = crate::lower::program::tag_paths(lx, tg);
    auto t = crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{crate::lower::program::kind_path(lx, tg.kind), Array<crate::lower::model::OutTy>{}});
    auto&& _m = tg.kind;
    {
        auto&& m26109_0 = _m;
        if (m26109_0 == Text::lit("Element")) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("an element as a plain value (", tg.name, "): a live element comes from its host")), t});
        }
    }
    {
        auto&& m26109_1 = _m;
        if (m26109_1 == Text::lit("Prelude.Fault")) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("a fault kind applied (", tg.name, ")")), t});
        }
    }
    {
        auto named = fold(args, false, [&](const bool& f, const crate::syntax::Arg& a) { return f || is_named_arg(a); });
        auto fields = run_to_end(each_job(crate::check::errors::range0(len(tg.fields)), ({
            auto tg_1 = tg;
            auto named_2 = named;
            auto args_3 = args;
            auto lx_4 = lx;
            auto env_5 = env;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::lower::model::Ex>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto tg_1_6 = tg_1;
                auto named_2_6 = named_2;
                auto args_3_6 = args_3;
                auto lx_4_6 = lx_4;
                auto env_5_6 = env_5;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    ({
                    auto&& _fname = or_(index(tg_1_6.fields, i), std::tuple{Text::lit(""), crate::check::types::Ty(crate::check::types::Ty::TyErr{})});
                    auto&& fname = std::get<0>(_fname);
                    auto arg_opt = named_2_6
                        ? crate::lower::node_::elements::tag_arg(args_3_6, fname)
                        : ({
                        __label__ _done;
                        prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                        auto&& _m = index(args_3_6, i);
                        if (prism_rtl::is_some(_m)) {
                            auto&& a = prism_rtl::some_of(_m);
                            _v.set(std::optional(a->value));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(std::optional<crate::syntax::Expr>{});
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    auto v_ = ({
                        __label__ _done;
                        prism_rtl::Slot<crate::lower::model::Ex> _v;
                        if (prism_rtl::is_some(arg_opt)) {
                            auto&& x = prism_rtl::some_of(arg_opt);
                            _v.set(crate::lower::types::own(value_of(lx_4_6, env_5_6, x)));
                            goto _done;
                        }
                        if (prism_rtl::is_none(arg_opt)) {
                            _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Default::default"), Array<crate::lower::model::Ex>{}}));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    (prism_rtl::finished(std::tuple{crate::lower::snake(fname), v_}));
                });
                });
            }));
            });
        }));
        })));
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRecord{struct_path, fields})})}), t});
    }
}


prism_rtl::Turn<crate::lower::types::Vl> TagValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& tg = this->tg;
    const auto& args = this->args;
    auto [variant, struct_path] = crate::lower::program::tag_paths(lx, tg);
    auto t = crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{crate::lower::program::kind_path(lx, tg.kind), Array<crate::lower::model::OutTy>{}});
    return ({
        auto&& _m = tg.kind;
        ({
        auto&& m26109_0 = _m;
        (m26109_0 == Text::lit("Element"));
    }) ? ({
        auto&& m26109_0 = _m;
        prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("an element as a plain value (", tg.name, "): a live element comes from its host")), t}));
    })
        : ({
        auto&& m26109_1 = _m;
        (m26109_1 == Text::lit("Prelude.Fault"));
    }) ? ({
        auto&& m26109_1 = _m;
        prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("a fault kind applied (", tg.name, ")")), t}));
    })
        : ({
        auto named = fold(args, false, [&](const bool& f, const crate::syntax::Arg& a) { return f || is_named_arg(a); });
        auto args_1 = args;
        auto env_2 = env;
        auto lx_3 = lx;
        auto tg_4 = tg;
        call_value(each_job(crate::check::errors::range0(len(tg_4.fields)), ({
        auto tg_4_5 = tg_4;
        auto named_5 = named;
        auto args_1_6 = args_1;
        auto lx_3_6 = lx_3;
        auto env_2_6 = env_2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::lower::model::Ex>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto tg_4_5_6 = tg_4_5;
            auto named_5_6 = named_5;
            auto args_1_6_6 = args_1_6;
            auto lx_3_6_6 = lx_3_6;
            auto env_2_6_6 = env_2_6;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto&& _fname = or_(index(tg_4_5_6.fields, i), std::tuple{Text::lit(""), crate::check::types::Ty(crate::check::types::Ty::TyErr{})});
                auto&& fname = std::get<0>(_fname);
                auto arg_opt = named_5_6
                    ? crate::lower::node_::elements::tag_arg(args_1_6_6, fname)
                    : ({
                    __label__ _done;
                    prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                    auto&& _m = index(args_1_6_6, i);
                    if (prism_rtl::is_some(_m)) {
                        auto&& a = prism_rtl::some_of(_m);
                        _v.set(std::optional(a->value));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(std::optional<crate::syntax::Expr>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto v_ = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::lower::model::Ex> _v;
                    if (prism_rtl::is_some(arg_opt)) {
                        auto&& x = prism_rtl::some_of(arg_opt);
                        _v.set(crate::lower::types::own(value_of(lx_3_6_6, env_2_6_6, x)));
                        goto _done;
                    }
                    if (prism_rtl::is_none(arg_opt)) {
                        _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Default::default"), Array<crate::lower::model::Ex>{}}));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                (prism_rtl::finished(std::tuple{crate::lower::snake(fname), v_}));
            });
            });
        }));
        });
    }));
    })), [=](Array<std::tuple<Text, crate::lower::model::Ex>> each_26435) {
        return ({
            auto fields = each_26435;
            (prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRecord{struct_path, fields})})}), t})));
        });
    });
    });
    });
}


/// `Start TagValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_tag_value(crate::lower::Lx lx, crate::lower::types::Env env, crate::check::env::TagInfo tg, Array<crate::syntax::Arg> args) {
    return prism_rtl::make_rc<TagValue>(lx, env, tg, args);
}


/// GlobalCall: unbounded fn Lx, Env, Text, [Arg], Range, OutTy -> Vl
crate::lower::types::Vl global_call(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const Text& qk, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span, const crate::lower::model::OutTy& t) {
    auto&& _m = crate::prelude::get(lx.g.ctors, qk);
    if (prism_rtl::is_some(_m)) {
        auto&& c = prism_rtl::some_of(_m);
        return ctor_app(lx, env, c, args, span);
    }
    if (prism_rtl::is_none(_m)) {
        auto&& _m = crate::prelude::get(lx.g.vals, qk);
        if (prism_rtl::is_some(_m)) {
            auto&& v_ = prism_rtl::some_of(_m);
            return v_.sort == Text::lit("method")
                ? method_call(lx, env, v_, args, span, t)
                : v_.home == Text::lit("Prelude")
                ? prelude_call(lx, env, qk, args, span, t)
                : crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::value_path(lx, qk), args_for(lx, env, v_, args)}), t});
        }
        if (prism_rtl::is_none(_m)) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("a call of ", qk)), t});
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::types::Vl> GlobalCall::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& qk = this->qk;
    const auto& args = this->args;
    const auto& span = this->span;
    const auto& t = this->t;
    return ({
        auto&& _m = crate::prelude::get(lx.g.ctors, qk);
        prism_rtl::is_some(_m) ? ({
        auto&& c = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(CtorApp(lx, env, c, args, span)));
    })
        : prism_rtl::is_none(_m) ? ({
        auto&& _m = crate::prelude::get(lx.g.vals, qk);
        prism_rtl::is_some(_m) ? ({
        auto&& v_ = prism_rtl::some_of(_m);
        v_.sort == Text::lit("method")
        ? prism_rtl::more(prism_rtl::rc(MethodCall(lx, env, v_, args, span, t)))
        : v_.home == Text::lit("Prelude")
        ? prism_rtl::more(prism_rtl::rc(PreludeCall(lx, env, qk, args, span, t)))
        : ({
        auto args_1 = args;
        auto env_2 = env;
        auto lx_3 = lx;
        auto qk_4 = qk;
        auto t_5 = t;
        call_then(start_args_for(lx_3, env_2, v_, args_1), [=](Array<crate::lower::model::Ex> args_for_27475) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::value_path(lx_3, qk_4), args_for_27475}), t_5})); });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("a call of ", qk)), t}))
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start GlobalCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_global_call(crate::lower::Lx lx, crate::lower::types::Env env, Text qk, Array<crate::syntax::Arg> args, crate::syntax::Range span, crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<GlobalCall>(lx, env, qk, args, span, t);
}


/// ArgsFor: unbounded fn Lx, Env, ValInfo, [Arg] -> [Ex]
Array<crate::lower::model::Ex> args_for(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::check::env::ValInfo& v_, const Array<crate::syntax::Arg>& args) {
    auto ps = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
        auto&& _m = v_.scheme.ty;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& xs = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            _v.set(xs);
            goto _done;
        }
        {
            _v.set(Array<crate::check::types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return run_to_end(each_job(crate::check::errors::range0(len(args)), ({
        auto args_1 = args;
        auto ps_2 = ps;
        auto lx_3 = lx;
        auto env_4 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto args_1_5 = args_1;
            auto ps_2_5 = ps_2;
            auto lx_3_5 = lx_3;
            auto env_4_5 = env_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto a = or_(index(args_1_5, i), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = dummy_expr(), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}});
                auto is_try = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = crate::lower::types::peel(or_(index(ps_2_5, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})));
                    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
                        auto&& m28041_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
                        if (m28041_0_0 == Text::lit("~")) {
                            _v.set(true);
                            goto _done;
                        }
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto is_error = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = crate::lower::types::peel(crate::lower::type_at(lx_3_5, a->value.span));
                    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
                        auto&& m28158_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
                        if (m28158_0_0 == Text::lit("Prelude.Error")) {
                            _v.set(true);
                            goto _done;
                        }
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto to_unbounded = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = crate::lower::types::peel(or_(index(ps_2_5, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})));
                    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CBound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0)) {
                        _v.set(false);
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
                        _v.set(true);
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                is_try && is_error
                ? call_then(start_value_of(lx_3_5, env_4_5, a->value), [=](crate::lower::types::Vl value_of_28507) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{crate::lower::types::own(value_of_28507)})}))})); })
                : to_unbounded
                ? call_then(start_as_job_value(lx_3_5, env_4_5, a->value), [=](crate::lower::model::Ex as_job_value_28572) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(as_job_value_28572)})); })
                : prism_rtl::more(prism_rtl::rc(Argument(lx_3_5, env_4_5, a->value)));
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<crate::lower::model::Ex>> ArgsFor::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& v_ = this->v_;
    const auto& args = this->args;
    auto ps = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
        auto&& _m = v_.scheme.ty;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& xs = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            _v.set(xs);
            goto _done;
        }
        {
            _v.set(Array<crate::check::types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return each_job(crate::check::errors::range0(len(args)), ({
        auto args_1 = args;
        auto ps_2 = ps;
        auto lx_3 = lx;
        auto env_4 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto args_1_5 = args_1;
            auto ps_2_5 = ps_2;
            auto lx_3_5 = lx_3;
            auto env_4_5 = env_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto a = or_(index(args_1_5, i), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = dummy_expr(), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}});
                auto is_try = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = crate::lower::types::peel(or_(index(ps_2_5, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})));
                    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
                        auto&& m28041_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
                        if (m28041_0_0 == Text::lit("~")) {
                            _v.set(true);
                            goto _done;
                        }
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto is_error = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = crate::lower::types::peel(crate::lower::type_at(lx_3_5, a->value.span));
                    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
                        auto&& m28158_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
                        if (m28158_0_0 == Text::lit("Prelude.Error")) {
                            _v.set(true);
                            goto _done;
                        }
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto to_unbounded = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = crate::lower::types::peel(or_(index(ps_2_5, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})));
                    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CBound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0)) {
                        _v.set(false);
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
                        _v.set(true);
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                is_try && is_error
                ? call_then(start_value_of(lx_3_5, env_4_5, a->value), [=](crate::lower::types::Vl value_of_28507) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{crate::lower::types::own(value_of_28507)})}))})); })
                : to_unbounded
                ? call_then(start_as_job_value(lx_3_5, env_4_5, a->value), [=](crate::lower::model::Ex as_job_value_28572) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(as_job_value_28572)})); })
                : prism_rtl::more(prism_rtl::rc(Argument(lx_3_5, env_4_5, a->value)));
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start ArgsFor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::Ex>> start_args_for(crate::lower::Lx lx, crate::lower::types::Env env, crate::check::env::ValInfo v_, Array<crate::syntax::Arg> args) {
    return prism_rtl::make_rc<ArgsFor>(lx, env, v_, args);
}


/// let dummyExpr
crate::syntax::Expr dummy_expr() {
    return crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// CtorApp: unbounded fn Lx, Env, CtorInfo, [Arg], Range -> Vl
crate::lower::types::Vl ctor_app(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::check::env::CtorInfo& c, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span) {
    auto t = crate::lower::types::out_ty_of(lx, crate::lower::types::peel(crate::lower::type_at(lx, span)));
    auto owner = or_(crate::prelude::get(lx.g.types, c.owner), crate::check::env::names::dummy_ty_info());
    auto ty_path = crate::lower::path_in(lx, owner.home, crate::lower::camel(crate::check::types::bare_name(c.owner)));
    auto vals = ctor_args(lx, env, c, args);
    auto&& _m = c.owner;
    {
        auto&& m29189_0 = _m;
        if (m29189_0 == Text::lit("Bool")) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBool{c.name == Text::lit("True")}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})});
        }
    }
    {
        auto&& m29189_1 = _m;
        if (m29189_1 == Text::lit("Prelude.Error")) {
            auto kind = or_(index(vals, Nat(0u)), crate::lower::model::Ex(crate::lower::model::Ex::XStr{Text::lit("")}));
            auto msg = or_(index(vals, Nat(1u)), crate::lower::model::Ex(crate::lower::model::Ex::XText{Text::lit("")}));
            auto made = crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Error::new"), Array(std::vector{kind, msg})});
            if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t)) {
                return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{made})}), t});
            }
            {
                return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{made, crate::lower::model::OutTy(crate::lower::model::OutTy::OutError{})});
            }
        }
    }
    {
        auto&& _m = owner.body;
        if (prism_rtl::is<crate::check::env::TyBody::BRecord>(_m)) {
            auto&& fs = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
            return len(c.fields) == Nat(0u)
                ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XPath{ty_path}), t})
                : crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XRecord{ty_path, each(crate::check::errors::range0(len(c.fields)), [&](const Nat& i) { return std::tuple{crate::lower::snake(or_(index(c.fields, i), Text::lit(""))), or_(index(vals, i), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Default::default"), Array<crate::lower::model::Ex>{}}))}; })}), t});
        }
        if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
            auto&& cases = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
            auto is_unit_type = ((len(cases) == Nat(1u)) && (len(c->args) == Nat(0u))) && crate::check::env::is_lower_text(crate::check::types::bare_name(c.name));
            auto is_newtype = (len(cases) == Nat(1u)) && (crate::check::types::bare_name(c.name) == crate::check::types::bare_name(c.owner));
            auto path_ = is_unit_type || is_newtype
                ? ty_path
                : prism_rtl::cat(ty_path, "::", crate::lower::camel(crate::check::types::bare_name(c.name)));
            return len(c->args) == Nat(0u)
                ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XPath{path_}), t})
                : crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{path_, vals}), t});
        }
        {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("a constructor of ", c.owner)), t});
        }
    }
}


prism_rtl::Turn<crate::lower::types::Vl> CtorApp::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& c = this->c;
    const auto& args = this->args;
    const auto& span = this->span;
    auto args_1 = args;
    auto c_2 = c;
    auto env_3 = env;
    auto lx_4 = lx;
    auto span_5 = span;
    return call_then(crate::lower::types::start_out_ty_of(lx_4, crate::lower::types::peel(crate::lower::type_at(lx_4, span_5))), [=](crate::lower::model::OutTy out_ty_of_28988) {
        return ({
            auto t = out_ty_of_28988;
            auto owner = or_(crate::prelude::get(lx_4.g.types, c_2.owner), crate::check::env::names::dummy_ty_info());
            auto ty_path = crate::lower::path_in(lx_4, owner.home, crate::lower::camel(crate::check::types::bare_name(c_2.owner)));
            call_then(start_ctor_args(lx_4, env_3, c_2, args_1), [=](Array<crate::lower::model::Ex> ctor_args_29159) {
            return ({
                auto vals = ctor_args_29159;
                ({
                auto&& _m = c_2.owner;
                ({
                auto&& m29189_0 = _m;
                (m29189_0 == Text::lit("Bool"));
            }) ? ({
                auto&& m29189_0 = _m;
                prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBool{c_2.name == Text::lit("True")}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})}));
            })
                : ({
                auto&& m29189_1 = _m;
                (m29189_1 == Text::lit("Prelude.Error"));
            }) ? ({
                auto&& m29189_1 = _m;
                ({
                auto kind = or_(index(vals, Nat(0u)), crate::lower::model::Ex(crate::lower::model::Ex::XStr{Text::lit("")}));
                auto msg = or_(index(vals, Nat(1u)), crate::lower::model::Ex(crate::lower::model::Ex::XText{Text::lit("")}));
                auto made = crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Error::new"), Array(std::vector{kind, msg})});
                ({
                prism_rtl::is<crate::lower::model::OutTy::OutRes>(t) ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{made})}), t}))
                : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{made, crate::lower::model::OutTy(crate::lower::model::OutTy::OutError{})}));
            });
            });
            })
                : ({
                auto&& _m = owner.body;
                prism_rtl::is<crate::check::env::TyBody::BRecord>(_m) ? ({
                auto&& fs = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
                len(c_2.fields) == Nat(0u)
                ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XPath{ty_path}), t}))
                : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XRecord{ty_path, each(crate::check::errors::range0(len(c_2.fields)), [&](const Nat& i) { return std::tuple{crate::lower::snake(or_(index(c_2.fields, i), Text::lit(""))), or_(index(vals, i), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Default::default"), Array<crate::lower::model::Ex>{}}))}; })}), t}));
            })
                : prism_rtl::is<crate::check::env::TyBody::BChoice>(_m) ? ({
                auto&& cases = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
                ({
                auto is_unit_type = ((len(cases) == Nat(1u)) && (len(c_2->args) == Nat(0u))) && crate::check::env::is_lower_text(crate::check::types::bare_name(c_2.name));
                auto is_newtype = (len(cases) == Nat(1u)) && (crate::check::types::bare_name(c_2.name) == crate::check::types::bare_name(c_2.owner));
                auto path_ = is_unit_type || is_newtype
                    ? ty_path
                    : prism_rtl::cat(ty_path, "::", crate::lower::camel(crate::check::types::bare_name(c_2.name)));
                len(c_2->args) == Nat(0u)
                ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XPath{path_}), t}))
                : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{path_, vals}), t}));
            });
            })
                : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("a constructor of ", c_2.owner)), t}));
            });
            });
            });
        });
        });
    });
}


/// `Start CtorApp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_ctor_app(crate::lower::Lx lx, crate::lower::types::Env env, crate::check::env::CtorInfo c, Array<crate::syntax::Arg> args, crate::syntax::Range span) {
    return prism_rtl::make_rc<CtorApp>(lx, env, c, args, span);
}


/// CtorFn: unbounded fn Lx, CtorInfo, [OutTy], Range, OutTy, Bool -> Vl
crate::lower::types::Vl ctor_fn(const crate::lower::Lx& lx, const crate::check::env::CtorInfo& c, const Array<crate::lower::model::OutTy>& pts, const crate::syntax::Range& span, const crate::lower::model::OutTy& t, const bool& job) {
    auto names = each(crate::check::errors::range0(len(pts)), [&](const Nat& i) { return prism_rtl::cat("a", i); });
    auto fakes = each(crate::check::errors::range0(len(pts)), [&](const Nat& i) { return crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EAbsent{})), .span = crate::syntax::Range{.start = *Nat::from_int(Int(4000000000ll)) + i, .end = *Nat::from_int(Int(4000000000ll)) + i}}, .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}}; });
    auto env = fold(crate::check::errors::range0(len(pts)), crate::lower::types::empty_env(), [&](const crate::lower::types::Env& en, const Nat& i) {
        return crate::lower::types::bind_span(en, crate::lower::place_key(lx, crate::syntax::Range{.start = *Nat::from_int(Int(4000000000ll)) + i, .end = *Nat::from_int(Int(4000000000ll)) + i}), crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XVar{or_(index(names, i), Text::lit("a"))}), job
            ? crate::lower::types::Holding(crate::lower::types::Holding::Owned{})
            : crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), or_(index(pts, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))}));
    });
    auto made = crate::lower::types::own(ctor_app(lx, env, c, fakes, span));
    return job
        ? ({
        auto a = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::OutTy> _v;
            if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t)) {
                auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t).a0;
                _v.set(x);
                goto _done;
            }
            {
                _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto pa = len(pts) == Nat(1u)
            ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("a0")})), a})
            : crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(names, [&](const Text& nm) { return crate::lower::model::Pa(crate::lower::model::Pa::PaBind{nm}); })})), a});
        (crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{pa}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("once_job"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array<crate::lower::model::Pa>{}, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{made})}))})})}))})})})), t}), t}));
    })
        : ({
        auto pas = each(crate::check::errors::range0(len(pts)), [&](const Nat& i) { return crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{or_(index(names, i), Text::lit("a"))})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(or_(index(pts, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})))})}); });
        (crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, pas, prism_rtl::rc(made)})})}), t}));
    });
}


prism_rtl::Turn<crate::lower::types::Vl> CtorFn::cycle() const {
    const auto& lx = this->lx;
    const auto& c = this->c;
    const auto& pts = this->pts;
    const auto& span = this->span;
    const auto& t = this->t;
    const auto& job = this->job;
    auto names = each(crate::check::errors::range0(len(pts)), [&](const Nat& i) { return prism_rtl::cat("a", i); });
    auto fakes = each(crate::check::errors::range0(len(pts)), [&](const Nat& i) { return crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EAbsent{})), .span = crate::syntax::Range{.start = *Nat::from_int(Int(4000000000ll)) + i, .end = *Nat::from_int(Int(4000000000ll)) + i}}, .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}}; });
    auto env = fold(crate::check::errors::range0(len(pts)), crate::lower::types::empty_env(), [&](const crate::lower::types::Env& en, const Nat& i) {
        return crate::lower::types::bind_span(en, crate::lower::place_key(lx, crate::syntax::Range{.start = *Nat::from_int(Int(4000000000ll)) + i, .end = *Nat::from_int(Int(4000000000ll)) + i}), crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XVar{or_(index(names, i), Text::lit("a"))}), job
            ? crate::lower::types::Holding(crate::lower::types::Holding::Owned{})
            : crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), or_(index(pts, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))}));
    });
    auto c_1 = c;
    auto job_2 = job;
    auto lx_3 = lx;
    auto pts_4 = pts;
    auto span_5 = span;
    auto t_6 = t;
    return call_then(start_ctor_app(lx_3, env, c_1, fakes, span_5), [=](crate::lower::types::Vl ctor_app_31307) {
        return ({
            auto made = crate::lower::types::own(ctor_app_31307);
            job_2
            ? ({
            auto a = ({
                __label__ _done;
                prism_rtl::Slot<crate::lower::model::OutTy> _v;
                if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t)) {
                    auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t).a0;
                    _v.set(x);
                    goto _done;
                }
                {
                    _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto pa = len(pts_4) == Nat(1u)
                ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("a0")})), a})
                : crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(names, [&](const Text& nm) { return crate::lower::model::Pa(crate::lower::model::Pa::PaBind{nm}); })})), a});
            (prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{pa}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("once_job"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array<crate::lower::model::Pa>{}, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{made})}))})})}))})})})), t_6}), t_6})));
        })
            : ({
            auto pas = each(crate::check::errors::range0(len(pts_4)), [&](const Nat& i) { return crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{or_(index(names, i), Text::lit("a"))})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(or_(index(pts_4, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})))})}); });
            (prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, pas, prism_rtl::rc(made)})})}), t_6})));
        });
        });
    });
}


/// `Start CtorFn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_ctor_fn(crate::lower::Lx lx, crate::check::env::CtorInfo c, Array<crate::lower::model::OutTy> pts, crate::syntax::Range span, crate::lower::model::OutTy t, bool job) {
    return prism_rtl::make_rc<CtorFn>(lx, c, pts, span, t, job);
}


/// IsNamedArg: fn Arg -> Bool
bool is_named_arg(const crate::syntax::Arg& a) {
    auto&& _m = a.name;
    if (prism_rtl::is_some(_m)) {
        return true;
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// CtorArgs: unbounded fn Lx, Env, CtorInfo, [Arg] -> [Ex]
Array<crate::lower::model::Ex> ctor_args(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::check::env::CtorInfo& c, const Array<crate::syntax::Arg>& args) {
    auto named = fold(args, false, [&](const bool& f, const crate::syntax::Arg& a) { return f || is_named_arg(a); });
    auto ordered = named
        ? each(c.fields, [&](const Text& f) {
        return fold(args, std::optional<crate::syntax::Expr>{}, [&](const std::optional<crate::syntax::Expr>& found_opt, const crate::syntax::Arg& a) {
            return ({
                __label__ _done;
                prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                auto&& _m = a.name;
                if (prism_rtl::is_some(_m)) {
                    auto&& n = prism_rtl::some_of(_m);
                    _v.set(n.name == f ? std::optional(a->value) : found_opt);
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(found_opt);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        });
    })
        : each(args, [&](const crate::syntax::Arg& a) { return std::optional(a->value); });
    return run_to_end(each_job(crate::check::errors::range0(len(ordered)), ({
        auto ordered_1 = ordered;
        auto lx_2 = lx;
        auto env_3 = env;
        auto c_4 = c;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto ordered_1_5 = ordered_1;
            auto lx_2_5 = lx_2;
            auto env_3_5 = env_3;
            auto c_4_5 = c_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto&& _m = index(ordered_1_5, i);
                prism_rtl::is_some(_m) && prism_rtl::is_some(prism_rtl::some_of(_m)) ? ({
                auto&& x = prism_rtl::some_of(prism_rtl::some_of(_m));
                call_then(start_value_of(lx_2_5, env_3_5, x), [=](crate::lower::types::Vl value_of_32572) {
                return ({
                    auto v_ = crate::lower::types::own(value_of_32572);
                    (c_4_5.owner == Text::lit("Prelude.Error")) && (i == Nat(0u))
                    ? prism_rtl::finished(v_)
                    : crate::lower::types::rc_field(lx_2_5, c_4_5.name, i)
                    ? prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{v_})}))
                    : prism_rtl::finished(v_);
                });
            });
            })
                : prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Default::default"), Array<crate::lower::model::Ex>{}}));
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<crate::lower::model::Ex>> CtorArgs::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& c = this->c;
    const auto& args = this->args;
    auto named = fold(args, false, [&](const bool& f, const crate::syntax::Arg& a) { return f || is_named_arg(a); });
    auto ordered = named
        ? each(c.fields, [&](const Text& f) {
        return fold(args, std::optional<crate::syntax::Expr>{}, [&](const std::optional<crate::syntax::Expr>& found_opt, const crate::syntax::Arg& a) {
            return ({
                __label__ _done;
                prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                auto&& _m = a.name;
                if (prism_rtl::is_some(_m)) {
                    auto&& n = prism_rtl::some_of(_m);
                    _v.set(n.name == f ? std::optional(a->value) : found_opt);
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(found_opt);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        });
    })
        : each(args, [&](const crate::syntax::Arg& a) { return std::optional(a->value); });
    return each_job(crate::check::errors::range0(len(ordered)), ({
        auto ordered_1 = ordered;
        auto lx_2 = lx;
        auto env_3 = env;
        auto c_4 = c;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto ordered_1_5 = ordered_1;
            auto lx_2_5 = lx_2;
            auto env_3_5 = env_3;
            auto c_4_5 = c_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto&& _m = index(ordered_1_5, i);
                prism_rtl::is_some(_m) && prism_rtl::is_some(prism_rtl::some_of(_m)) ? ({
                auto&& x = prism_rtl::some_of(prism_rtl::some_of(_m));
                call_then(start_value_of(lx_2_5, env_3_5, x), [=](crate::lower::types::Vl value_of_32572) {
                return ({
                    auto v_ = crate::lower::types::own(value_of_32572);
                    (c_4_5.owner == Text::lit("Prelude.Error")) && (i == Nat(0u))
                    ? prism_rtl::finished(v_)
                    : crate::lower::types::rc_field(lx_2_5, c_4_5.name, i)
                    ? prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{v_})}))
                    : prism_rtl::finished(v_);
                });
            });
            })
                : prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Default::default"), Array<crate::lower::model::Ex>{}}));
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start CtorArgs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::Ex>> start_ctor_args(crate::lower::Lx lx, crate::lower::types::Env env, crate::check::env::CtorInfo c, Array<crate::syntax::Arg> args) {
    return prism_rtl::make_rc<CtorArgs>(lx, env, c, args);
}


/// MethodCall: unbounded fn Lx, Env, ValInfo, [Arg], Range, OutTy -> Vl
crate::lower::types::Vl method_call(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::check::env::ValInfo& v_, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span, const crate::lower::model::OutTy& t) {
    auto cls = or_(index(each(v_.scheme.bounds, [&](const std::tuple<Text, Text>& _p0) {
        auto&& c = std::get<1>(_p0);
        return c;
    }), Nat(0u)), Text::lit(""));
    auto m = crate::check::types::bare_name(v_.qk);
    auto vals = run_to_end(each_job(args, ({
        auto lx_1 = lx;
        auto env_2 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::types::Vl>(crate::syntax::Arg)>>(prism_rtl::rc([=](crate::syntax::Arg p0) {
        return ({
            auto lx_1_3 = lx_1;
            auto env_2_3 = env_2;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(ValueOf(lx_1_3, env_2_3, a->value))));
            });
        }));
        });
    })));
    })));
    return crate::syntax::lexer::chars::has_prefix(cls, Text::lit("Prelude."))
        ? prelude_method(lx, cls, m, vals, span, t)
        : ({
        auto tr = or_(crate::prelude::get(lx.g.traits, cls), dummy_trait_info());
        auto path_ = crate::lower::path_in(lx, tr.home, prism_rtl::cat(crate::lower::camel(crate::check::types::bare_name(cls)), "::", crate::lower::snake(m)));
        (crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{path_, run_to_end(each_job(args, ({
        auto lx_1 = lx;
        auto env_2 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=](crate::syntax::Arg p0) {
        return ({
            auto lx_1_3 = lx_1;
            auto env_2_3 = env_2;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(Argument(lx_1_3, env_2_3, a->value))));
            });
        }));
        });
    })));
    })))}), t}));
    });
}


prism_rtl::Turn<crate::lower::types::Vl> MethodCall::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& v_ = this->v_;
    const auto& args = this->args;
    const auto& span = this->span;
    const auto& t = this->t;
    auto cls = or_(index(each(v_.scheme.bounds, [&](const std::tuple<Text, Text>& _p0) {
        auto&& c = std::get<1>(_p0);
        return c;
    }), Nat(0u)), Text::lit(""));
    auto m = crate::check::types::bare_name(v_.qk);
    auto args_1 = args;
    auto env_2 = env;
    auto lx_3 = lx;
    auto span_4 = span;
    auto t_5 = t;
    return call_value(each_job(args_1, ({
        auto lx_3_6 = lx_3;
        auto env_2_6 = env_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::types::Vl>(crate::syntax::Arg)>>(prism_rtl::rc([=](crate::syntax::Arg p0) {
        return ({
            auto lx_3_6_6 = lx_3_6;
            auto env_2_6_6 = env_2_6;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(ValueOf(lx_3_6_6, env_2_6_6, a->value))));
            });
        }));
        });
    })));
    })), [=](Array<crate::lower::types::Vl> each_33190) {
        return ({
            auto vals = each_33190;
            (crate::syntax::lexer::chars::has_prefix(cls, Text::lit("Prelude."))
            ? prism_rtl::more(prism_rtl::rc(PreludeMethod(lx_3, cls, m, vals, span_4, t_5)))
            : ({
            auto tr = or_(crate::prelude::get(lx_3.g.traits, cls), dummy_trait_info());
            auto path_ = crate::lower::path_in(lx_3, tr.home, prism_rtl::cat(crate::lower::camel(crate::check::types::bare_name(cls)), "::", crate::lower::snake(m)));
            call_value(each_job(args_1, ({
            auto lx_3_6 = lx_3;
            auto env_2_6 = env_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=](crate::syntax::Arg p0) {
            return ({
                auto lx_3_6_6 = lx_3_6;
                auto env_2_6_6 = env_2_6;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(Argument(lx_3_6_6, env_2_6_6, a->value))));
                });
            }));
            });
        })));
        })), [=](Array<crate::lower::model::Ex> each_33475) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{path_, each_33475}), t_5})); });
        }));
        });
    });
}


/// `Start MethodCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_method_call(crate::lower::Lx lx, crate::lower::types::Env env, crate::check::env::ValInfo v_, Array<crate::syntax::Arg> args, crate::syntax::Range span, crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<MethodCall>(lx, env, v_, args, span, t);
}


/// let dummyTraitInfo
crate::check::env::TraitInfo dummy_trait_info() {
    return crate::check::env::TraitInfo{.name = Text::lit(""), .home = Text::lit(""), .param = Text::lit("a"), .supers = Array<Text>{}, .methods = Array<Text>{}, .defaults = Array<Text>{}, .assocs = Array<Text>{}, .file = Nat(0u), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// PreludeMethod: unbounded fn Lx, Text, Text, [Vl], Range, OutTy -> Vl
crate::lower::types::Vl prelude_method(const crate::lower::Lx& lx, const Text& cls, const Text& m, const Array<crate::lower::types::Vl>& vals, const crate::syntax::Range& span, const crate::lower::model::OutTy& t) {
    auto a = or_(index(vals, Nat(0u)), crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}));
    auto b = or_(index(vals, Nat(1u)), crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}));
    {
        auto&& m33894_0 = m;
        if (m33894_0 == Text::lit("Show")) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("show_text"), Array(std::vector{crate::lower::types::ref_(a)})}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})});
        }
    }
    {
        auto&& m33894_1 = m;
        if (m33894_1 == Text::lit("Compare")) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("compare"), Array(std::vector{crate::lower::types::ref_(a), crate::lower::types::ref_(b)})}), t});
        }
    }
    {
        auto&& m33894_2 = m;
        if (m33894_2 == Text::lit("Children")) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("children"), Array(std::vector{crate::lower::types::ref_(a)})}), t});
        }
    }
    {
        return op_value(lx, m, a, b, span, t);
    }
}


prism_rtl::Turn<crate::lower::types::Vl> PreludeMethod::cycle() const {
    const auto& lx = this->lx;
    const auto& cls = this->cls;
    const auto& m = this->m;
    const auto& vals = this->vals;
    const auto& span = this->span;
    const auto& t = this->t;
    auto a = or_(index(vals, Nat(0u)), crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}));
    auto b = or_(index(vals, Nat(1u)), crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}));
    return ({
        ({
        auto&& m33894_0 = m;
        (m33894_0 == Text::lit("Show"));
    }) ? ({
        auto&& m33894_0 = m;
        prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("show_text"), Array(std::vector{crate::lower::types::ref_(a)})}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})}));
    })
        : ({
        auto&& m33894_1 = m;
        (m33894_1 == Text::lit("Compare"));
    }) ? ({
        auto&& m33894_1 = m;
        prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("compare"), Array(std::vector{crate::lower::types::ref_(a), crate::lower::types::ref_(b)})}), t}));
    })
        : ({
        auto&& m33894_2 = m;
        (m33894_2 == Text::lit("Children"));
    }) ? ({
        auto&& m33894_2 = m;
        prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("children"), Array(std::vector{crate::lower::types::ref_(a)})}), t}));
    })
        : prism_rtl::finished(op_value(lx, m, a, b, span, t));
    });
}


/// `Start PreludeMethod, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_prelude_method(crate::lower::Lx lx, Text cls, Text m, Array<crate::lower::types::Vl> vals, crate::syntax::Range span, crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<PreludeMethod>(lx, cls, m, vals, span, t);
}


/// BinaryValue: unbounded fn Lx, Env, Text, Expr, Expr, Range -> Vl
crate::lower::types::Vl binary_value(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const Text& op, const crate::syntax::Expr& l, const crate::syntax::Expr& r, const crate::syntax::Range& span) {
    auto t = crate::lower::types::out_ty_of(lx, crate::lower::types::peel(crate::lower::type_at(lx, span)));
    {
        auto&& m34322_0 = op;
        if (m34322_0 == Text::lit("and")) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("&&"), prism_rtl::rc(crate::lower::types::as_bool(value_of(lx, env, l))), prism_rtl::rc(crate::lower::types::as_bool(value_of(lx, env, r)))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})});
        }
    }
    {
        auto&& m34322_1 = op;
        if (m34322_1 == Text::lit("or")) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("||"), prism_rtl::rc(crate::lower::types::as_bool(value_of(lx, env, l))), prism_rtl::rc(crate::lower::types::as_bool(value_of(lx, env, r)))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})});
        }
    }
    {
        auto&& m34322_2 = op;
        if (m34322_2 == Text::lit("on")) {
            return value_of(lx, env, l);
        }
    }
    {
        return op_value(lx, op, value_of(lx, env, l), value_of(lx, env, r), span, t);
    }
}


prism_rtl::Turn<crate::lower::types::Vl> BinaryValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& op = this->op;
    const auto& l = this->l;
    const auto& r = this->r;
    const auto& span = this->span;
    auto env_1 = env;
    auto l_2 = l;
    auto lx_3 = lx;
    auto op_4 = op;
    auto r_5 = r;
    auto span_6 = span;
    return call_then(crate::lower::types::start_out_ty_of(lx_3, crate::lower::types::peel(crate::lower::type_at(lx_3, span_6))), [=](crate::lower::model::OutTy out_ty_of_34281) {
        return ({
            auto t = out_ty_of_34281;
            ({
            ({
            auto&& m34322_0 = op_4;
            (m34322_0 == Text::lit("and"));
        }) ? ({
            auto&& m34322_0 = op_4;
            call_then(start_value_of(lx_3, env_1, l_2), [=](crate::lower::types::Vl value_of_34376) { return call_then(start_value_of(lx_3, env_1, r_5), [=](crate::lower::types::Vl value_of_34407) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("&&"), prism_rtl::rc(crate::lower::types::as_bool(value_of_34376)), prism_rtl::rc(crate::lower::types::as_bool(value_of_34407))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})})); }); });
        })
            : ({
            auto&& m34322_1 = op_4;
            (m34322_1 == Text::lit("or"));
        }) ? ({
            auto&& m34322_1 = op_4;
            call_then(start_value_of(lx_3, env_1, l_2), [=](crate::lower::types::Vl value_of_34481) { return call_then(start_value_of(lx_3, env_1, r_5), [=](crate::lower::types::Vl value_of_34512) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("||"), prism_rtl::rc(crate::lower::types::as_bool(value_of_34481)), prism_rtl::rc(crate::lower::types::as_bool(value_of_34512))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})})); }); });
        })
            : ({
            auto&& m34322_2 = op_4;
            (m34322_2 == Text::lit("on"));
        }) ? ({
            auto&& m34322_2 = op_4;
            prism_rtl::more(prism_rtl::rc(ValueOf(lx_3, env_1, l_2)));
        })
            : call_then(start_value_of(lx_3, env_1, l_2), [=](crate::lower::types::Vl value_of_34778) { return call_then(start_value_of(lx_3, env_1, r_5), [=](crate::lower::types::Vl value_of_34800) { return prism_rtl::finished(op_value(lx_3, op_4, value_of_34778, value_of_34800, span_6, t)); }); });
        });
        });
    });
}


/// `Start BinaryValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_binary_value(crate::lower::Lx lx, crate::lower::types::Env env, Text op, crate::syntax::Expr l, crate::syntax::Expr r, crate::syntax::Range span) {
    return prism_rtl::make_rc<BinaryValue>(lx, env, op, l, r, span);
}


/// OpValue: fn Lx, Text, Vl, Vl, Range, OutTy -> Vl
crate::lower::types::Vl op_value(const crate::lower::Lx& lx, const Text& op, const crate::lower::types::Vl& a, const crate::lower::types::Vl& b, const crate::syntax::Range& span, const crate::lower::model::OutTy& t) {
    auto at_ = crate::lower::types::value_ty(a);
    auto generic = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<crate::lower::model::OutTy::OutGen>(at_)) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    return crate::check::types::has_text(Array(std::vector{Text::lit("=="), Text::lit("!="), Text::lit("<"), Text::lit("<="), Text::lit(">"), Text::lit(">=")}), op)
        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBin{op, prism_rtl::rc(crate::lower::types::ref_(a)), prism_rtl::rc(crate::lower::types::ref_(b))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})})
        : op == Text::lit("mod")
        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::types::ref_(a)), Text::lit("modulo"), Array(std::vector{crate::lower::types::ref_(b)})}), t})
        : generic
        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{prism_rtl::cat("Num::", num_method(op)), Array(std::vector{crate::lower::types::ref_(a), crate::lower::types::ref_(b)})}), t})
        : op == Text::lit("/")
        ? at_ == crate::lower::model::OutTy(crate::lower::model::OutTy::OutFloat{})
        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("/"), prism_rtl::rc(crate::lower::types::copy(a)), prism_rtl::rc(crate::lower::types::copy(b))}), t})
        : crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::types::ref_(a)), Text::lit("div"), Array(std::vector{crate::lower::types::ref_(b)})}), t})
        : op == Text::lit("-?")
        ? at_ == crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{})
        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::types::ref_(a)), Text::lit("checked_sub"), Array(std::vector{crate::lower::types::ref_(b)})}), t})
        : crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("-"), prism_rtl::rc(crate::lower::types::ref_(a)), prism_rtl::rc(crate::lower::types::ref_(b))})})}), t})
        : op == Text::lit("+?")
        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("+"), prism_rtl::rc(crate::lower::types::ref_(a)), prism_rtl::rc(crate::lower::types::ref_(b))})})}), t})
        : op == Text::lit("*?")
        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("*"), prism_rtl::rc(crate::lower::types::ref_(a)), prism_rtl::rc(crate::lower::types::ref_(b))})})}), t})
        : crate::lower::types::is_copy(at_)
        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBin{op, prism_rtl::rc(crate::lower::types::copy(a)), prism_rtl::rc(crate::lower::types::copy(b))}), t})
        : crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBin{op, prism_rtl::rc(crate::lower::types::ref_(a)), prism_rtl::rc(crate::lower::types::ref_(b))}), t});
}


/// NumMethod: fn Text -> Text
Text num_method(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("+")) {
            return Text::lit("add");
        }
    }
    {
        auto&& c1_0 = text0;
        if (c1_0 == Text::lit("-")) {
            return Text::lit("sub");
        }
    }
    {
        auto&& c2_0 = text0;
        if (c2_0 == Text::lit("*")) {
            return Text::lit("mul");
        }
    }
    {
        auto&& c3_0 = text0;
        if (c3_0 == Text::lit("/")) {
            return Text::lit("div_opt");
        }
    }
    {
        auto&& c4_0 = text0;
        if (c4_0 == Text::lit("+?")) {
            return Text::lit("add_opt");
        }
    }
    {
        auto&& c5_0 = text0;
        if (c5_0 == Text::lit("-?")) {
            return Text::lit("sub_opt");
        }
    }
    {
        auto&& c6_0 = text0;
        if (c6_0 == Text::lit("*?")) {
            return Text::lit("mul_opt");
        }
    }
    {
        auto&& other = text0;
        return Text::lit("add");
    }
}


/// PreludeCall: unbounded fn Lx, Env, Text, [Arg], Range, OutTy -> Vl
crate::lower::types::Vl prelude_call(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const Text& qk, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span, const crate::lower::model::OutTy& t) {
    auto name = or_(crate::prelude::get(lx.rs_names, qk), crate::lower::snake(crate::check::types::bare_name(qk)));
    auto first_ = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::OutTy> _v;
        auto&& _m = index(args, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& a = prism_rtl::some_of(_m);
            _v.set(crate::lower::types::out_ty_of(lx, crate::lower::types::peel(crate::lower::type_at(lx, a->value.span))));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto variant = prelude_variant(name, first_);
    auto&& _m = prelude_job(lx, env, variant, args);
    if (prism_rtl::is_some(_m)) {
        auto&& job = prism_rtl::some_of(_m);
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("run_to_end"), Array(std::vector{job})}), t});
    }
    if (prism_rtl::is_none(_m)) {
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::prelude_path(lx, variant), run_to_end(each_job(args, ({
            auto lx_1 = lx;
            auto env_2 = env;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=](crate::syntax::Arg p0) {
            return ({
                auto lx_1_3 = lx_1;
                auto env_2_3 = env_2;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(Argument(lx_1_3, env_2_3, a->value))));
                });
            }));
            });
        })));
        })))}), t});
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::types::Vl> PreludeCall::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& qk = this->qk;
    const auto& args = this->args;
    const auto& span = this->span;
    const auto& t = this->t;
    auto name = or_(crate::prelude::get(lx.rs_names, qk), crate::lower::snake(crate::check::types::bare_name(qk)));
    auto first_ = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::OutTy> _v;
        auto&& _m = index(args, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& a = prism_rtl::some_of(_m);
            _v.set(crate::lower::types::out_ty_of(lx, crate::lower::types::peel(crate::lower::type_at(lx, a->value.span))));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto variant = prelude_variant(name, first_);
    auto args_1 = args;
    auto env_2 = env;
    auto lx_3 = lx;
    auto t_4 = t;
    return call_then(start_prelude_job(lx_3, env_2, variant, args_1), [=](std::optional<crate::lower::model::Ex> prelude_job_36814) {
        return ({
            prism_rtl::is_some(prelude_job_36814) ? ({
            auto&& job = prism_rtl::some_of(prelude_job_36814);
            prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("run_to_end"), Array(std::vector{job})}), t_4}));
        })
            : prism_rtl::is_none(prelude_job_36814) ? call_value(each_job(args_1, ({
            auto lx_3_5 = lx_3;
            auto env_2_5 = env_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=](crate::syntax::Arg p0) {
            return ({
                auto lx_3_5_5 = lx_3_5;
                auto env_2_5_5 = env_2_5;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(Argument(lx_3_5_5, env_2_5_5, a->value))));
                });
            }));
            });
        })));
        })), [=](Array<crate::lower::model::Ex> each_36962) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::prelude_path(lx_3, variant), each_36962}), t_4})); })
            : throw prism_rtl::Panic("no arm matched");
        });
    });
}


/// `Start PreludeCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_prelude_call(crate::lower::Lx lx, crate::lower::types::Env env, Text qk, Array<crate::syntax::Arg> args, crate::syntax::Range span, crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<PreludeCall>(lx, env, qk, args, span, t);
}


/// ?PreludeJob: unbounded fn Lx, Env, Text, [Arg] -> ?Ex
std::optional<crate::lower::model::Ex> prelude_job(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const Text& variant, const Array<crate::syntax::Arg>& args) {
    return crate::check::types::has_text(Array(std::vector{Text::lit("fold"), Text::lit("fold_map"), Text::lit("each"), Text::lit("each_map"), Text::lit("filter"), Text::lit("filter_map")}), variant)
        ? ({
        auto last = or_(index(args, crate::syntax::lexer::chars::dec(len(args))), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = dummy_expr(), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}});
        ({
        __label__ _done;
        prism_rtl::Slot<std::optional<crate::lower::model::Ex>> _v;
        auto&& _m = crate::lower::types::out_ty_of(lx, crate::lower::types::peel(crate::lower::type_at(lx, last->value.span)));
        if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m)) {
            _v.set(({
                auto front_ = run_to_end(each_job(take(args, crate::syntax::lexer::chars::dec(len(args))), ({
                    auto lx_1 = lx;
                    auto env_2 = env;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=](crate::syntax::Arg p0) {
                    return ({
                        auto lx_1_3 = lx_1;
                        auto env_2_3 = env_2;
                        entered(once_job([=]() {
                        return ({
                            auto a = p0;
                            call_then(start_value_of(lx_1_3, env_2_3, a->value), [=](crate::lower::types::Vl value_of_37828) { return prism_rtl::finished(crate::lower::types::own(value_of_37828)); });
                        });
                    }));
                    });
                })));
                })));
                (std::optional(crate::lower::model::Ex(crate::lower::model::Ex::XCall{prism_rtl::cat(variant, "_job"), crate::prelude::push(front_, as_job_value(lx, env, last->value))})));
            }));
            goto _done;
        }
        {
            _v.set(std::optional<crate::lower::model::Ex>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    })
        : std::optional<crate::lower::model::Ex>{};
}


prism_rtl::Turn<std::optional<crate::lower::model::Ex>> PreludeJob::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& variant = this->variant;
    const auto& args = this->args;
    return crate::check::types::has_text(Array(std::vector{Text::lit("fold"), Text::lit("fold_map"), Text::lit("each"), Text::lit("each_map"), Text::lit("filter"), Text::lit("filter_map")}), variant)
        ? ({
        auto last = or_(index(args, crate::syntax::lexer::chars::dec(len(args))), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = dummy_expr(), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}});
        auto args_1 = args;
        auto env_2 = env;
        auto lx_3 = lx;
        auto variant_4 = variant;
        call_then(crate::lower::types::start_out_ty_of(lx_3, crate::lower::types::peel(crate::lower::type_at(lx_3, last->value.span))), [=](crate::lower::model::OutTy out_ty_of_37668) {
        return ({
            prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(out_ty_of_37668) ? call_value(each_job(take(args_1, crate::syntax::lexer::chars::dec(len(args_1))), ({
            auto lx_3_5 = lx_3;
            auto env_2_5 = env_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=](crate::syntax::Arg p0) {
            return ({
                auto lx_3_5_5 = lx_3_5;
                auto env_2_5_5 = env_2_5;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    call_then(start_value_of(lx_3_5_5, env_2_5_5, a->value), [=](crate::lower::types::Vl value_of_37828) { return prism_rtl::finished(crate::lower::types::own(value_of_37828)); });
                });
            }));
            });
        })));
        })), [=](Array<crate::lower::model::Ex> each_37782) {
            return ({
                auto front_ = each_37782;
                (prism_rtl::finished(std::optional(crate::lower::model::Ex(crate::lower::model::Ex::XCall{prism_rtl::cat(variant_4, "_job"), crate::prelude::push(front_, as_job_value(lx_3, env_2, last->value))}))));
            });
        })
            : prism_rtl::finished(std::optional<crate::lower::model::Ex>{});
        });
    });
    })
        : prism_rtl::finished(std::optional<crate::lower::model::Ex>{});
}


/// `Start PreludeJob, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<crate::lower::model::Ex>> start_prelude_job(crate::lower::Lx lx, crate::lower::types::Env env, Text variant, Array<crate::syntax::Arg> args) {
    return prism_rtl::make_rc<PreludeJob>(lx, env, variant, args);
}


/// ?PreludeJobCall: unbounded fn Lx, Env, Expr -> ?Ex
std::optional<crate::lower::model::Ex> prelude_job_call(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        auto&& _m = c.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            return (len(n->path_) == Nat(1u)) && crate::check::env::has_key(env->names, crate::check::env::sname_key(n))
                ? std::optional<crate::lower::model::Ex>{}
                : ({
                auto&& _qk_opt = crate::check::env::names::resolve_value(lx.g, lx.home, n);
                auto&& qk_opt = std::get<0>(_qk_opt);
                ({
                __label__ _done;
                prism_rtl::Slot<std::optional<crate::lower::model::Ex>> _v;
                if (prism_rtl::is_some(qk_opt)) {
                    auto&& qk = prism_rtl::some_of(qk_opt);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::optional<crate::lower::model::Ex>> _v;
                        auto&& _m = crate::prelude::get(lx.g.vals, qk);
                        if (prism_rtl::is_some(_m)) {
                            auto&& v_ = prism_rtl::some_of(_m);
                            _v.set(v_.home == Text::lit("Prelude")
                                ? ({
                                auto name = or_(crate::prelude::get(lx.rs_names, qk), crate::lower::snake(crate::check::types::bare_name(qk)));
                                auto first_ = ({
                                    __label__ _done;
                                    prism_rtl::Slot<crate::lower::model::OutTy> _v;
                                    auto&& _m = index(args, Nat(0u));
                                    if (prism_rtl::is_some(_m)) {
                                        auto&& a = prism_rtl::some_of(_m);
                                        _v.set(crate::lower::types::out_ty_of(lx, crate::lower::types::peel(crate::lower::type_at(lx, a->value.span))));
                                        goto _done;
                                    }
                                    if (prism_rtl::is_none(_m)) {
                                        _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
                                        goto _done;
                                    }
                                    prism_rtl::unreachable("no arm matched");
                                _done:
                                    _v.take();
                                });
                                prelude_job(lx, env, prelude_variant(name, first_), args);
                            })
                                : std::optional<crate::lower::model::Ex>{});
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(std::optional<crate::lower::model::Ex>{});
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(qk_opt)) {
                    _v.set(std::optional<crate::lower::model::Ex>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            });
        }
        {
            return std::optional<crate::lower::model::Ex>{};
        }
    }
    {
        return std::optional<crate::lower::model::Ex>{};
    }
}


prism_rtl::Turn<std::optional<crate::lower::model::Ex>> PreludeJobCall::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::ECall>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        ({
        auto&& _m = c.kind;
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        (len(n->path_) == Nat(1u)) && crate::check::env::has_key(env->names, crate::check::env::sname_key(n))
        ? prism_rtl::finished(std::optional<crate::lower::model::Ex>{})
        : ({
        auto&& _qk_opt = crate::check::env::names::resolve_value(lx.g, lx.home, n);
        auto&& qk_opt = std::get<0>(_qk_opt);
        ({
        prism_rtl::is_some(qk_opt) ? ({
        auto&& qk = prism_rtl::some_of(qk_opt);
        ({
        auto&& _m = crate::prelude::get(lx.g.vals, qk);
        prism_rtl::is_some(_m) ? ({
        auto&& v_ = prism_rtl::some_of(_m);
        v_.home == Text::lit("Prelude")
        ? ({
        auto name = or_(crate::prelude::get(lx.rs_names, qk), crate::lower::snake(crate::check::types::bare_name(qk)));
        auto first_ = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::OutTy> _v;
            auto&& _m = index(args, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& a = prism_rtl::some_of(_m);
                _v.set(crate::lower::types::out_ty_of(lx, crate::lower::types::peel(crate::lower::type_at(lx, a->value.span))));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        (prism_rtl::more(prism_rtl::rc(PreludeJob(lx, env, prelude_variant(name, first_), args))));
    })
        : prism_rtl::finished(std::optional<crate::lower::model::Ex>{});
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<crate::lower::model::Ex>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is_none(qk_opt) ? prism_rtl::finished(std::optional<crate::lower::model::Ex>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : prism_rtl::finished(std::optional<crate::lower::model::Ex>{});
    });
    })
        : prism_rtl::finished(std::optional<crate::lower::model::Ex>{});
    });
}


/// `Start PreludeJobCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<crate::lower::model::Ex>> start_prelude_job_call(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e) {
    return prism_rtl::make_rc<PreludeJobCall>(lx, env, e);
}


/// AsJobValue: unbounded fn Lx, Env, Expr -> Ex
crate::lower::model::Ex as_job_value(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return as_job_value(lx, env, x);
    }
    {
        auto target = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::OutTy> _v;
            auto&& _m = crate::lower::types::peel(crate::lower::type_at(lx, e.span));
            if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
                auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
                auto&& r = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
                _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutJobFn{prism_rtl::rc(crate::lower::types::rust_ty_of_params(lx, ps)), prism_rtl::rc(crate::lower::types::out_ty_of(lx, r))}));
                goto _done;
            }
            {
                auto&& other = _m;
                _v.set(crate::lower::types::out_ty_of(lx, other));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto a = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::OutTy> _v;
            if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(target)) {
                auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(target).a0;
                _v.set(x);
                goto _done;
            }
            {
                _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto&& _m = e.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
            auto&& ps_opt = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
            auto&& body = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
            return crate::lower::types::own(job_lambda(lx, env, or_(ps_opt, Array<crate::syntax::Pattern_>{}), body, target, a, enters_lambda(lx, e)));
        }
        {
            auto v_ = value_of(lx, env, e);
            auto&& _m = crate::lower::types::value_ty(v_);
            if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(_m)) {
                auto&& pts = prism_rtl::as<crate::lower::model::OutTy::OutFn>(_m).a0;
                return wrap_as_job(crate::lower::types::own(v_), pts, target, a);
            }
            {
                return crate::lower::types::own(v_);
            }
        }
    }
}


prism_rtl::Turn<crate::lower::model::Ex> AsJobValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(AsJobValue(lx, env, x)));
    })
        : ({
        auto target = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::OutTy> _v;
            auto&& _m = crate::lower::types::peel(crate::lower::type_at(lx, e.span));
            if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
                auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
                auto&& r = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
                _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutJobFn{prism_rtl::rc(crate::lower::types::rust_ty_of_params(lx, ps)), prism_rtl::rc(crate::lower::types::out_ty_of(lx, r))}));
                goto _done;
            }
            {
                auto&& other = _m;
                _v.set(crate::lower::types::out_ty_of(lx, other));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto a = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::OutTy> _v;
            if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(target)) {
                auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(target).a0;
                _v.set(x);
                goto _done;
            }
            {
                _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
                goto _done;
            }
        _done:
            _v.take();
        });
        ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) ? ({
        auto&& ps_opt = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
        ({
        auto ps_opt_1 = ps_opt;
        auto body_2 = body;
        auto e_3 = e;
        auto env_4 = env;
        auto lx_5 = lx;
        call_then(start_job_lambda(lx_5, env_4, or_(ps_opt_1, Array<crate::syntax::Pattern_>{}), body_2, target, a, enters_lambda(lx_5, e_3)), [=](crate::lower::types::Vl job_lambda_39717) { return prism_rtl::finished(crate::lower::types::own(job_lambda_39717)); });
    });
    })
        : ({
        auto e_1 = e;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(start_value_of(lx_3, env_2, e_1), [=](crate::lower::types::Vl value_of_39838) {
        return ({
            auto v_ = value_of_39838;
            ({
            auto&& _m = crate::lower::types::value_ty(v_);
            prism_rtl::is<crate::lower::model::OutTy::OutFn>(_m) ? ({
            auto&& pts = prism_rtl::as<crate::lower::model::OutTy::OutFn>(_m).a0;
            prism_rtl::finished(wrap_as_job(crate::lower::types::own(v_), pts, target, a));
        })
            : prism_rtl::finished(crate::lower::types::own(v_));
        });
        });
    });
    });
    });
    });
    });
}

}  // namespace crate::lower::expr
