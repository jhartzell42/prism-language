// The module `Lower.Expr`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace lower::expr {

struct LiteralValue;

struct TextValue;

struct SegEx;

struct ValueOf;

struct UnboundValueOf;

struct IsEventValue;

struct HasEventSource;

struct IsEventSource;

struct EventValueOf;

struct ValueByKind;

struct LiftedValue;

struct LiftOperands;

struct PlainValueByKind;

struct PureBlueprint;

struct PlainBlueprint;

struct DynamicBlueprint;

struct ElementBlueprint;

struct NameValue;

struct GlobalValue;

struct Application;

struct InlineLocalFn;

struct Argument;

struct ArgumentByKind;

struct TagValue;

struct GlobalCall;

struct ArgsFor;

struct CtorApp;

struct CtorFn;

struct CtorArgs;

struct MethodCall;

struct PreludeMethod;

struct BinaryValue;

struct PreludeCall;

struct PreludeJob;

struct PreludeJobCall;

struct AsJobValue;

struct NamedArgsOwned;

struct StartArgs;

struct FieldValue;

struct FieldInfo;

struct Instantiated;

struct IndexValue;

struct ReadNames;

struct LambdaExprs;

struct LambdaValue;

struct PlainLambda;

struct LambdaParamTys;

struct IsKnownTy;

struct JobLambda;

struct LambdaArg;

struct LambdaBodyValue;

struct ClosureParams;

struct IfValue;

struct MatchValue;

struct MovedOnce;

struct OnlyRead;

struct ArmPat;

struct BlockValue;

struct BlockTy;

struct PlainBlockValue;

struct BlockStmt;

struct GenericLet;

struct Instantiations;

struct Expanded;

struct OpenQ;

struct OpenTyQs;

struct WidgetLetLx;

struct PlainLet;

}  // namespace lower::expr


}  // namespace crate
