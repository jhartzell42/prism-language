// The module `Lower.Expr`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <lower/expr/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace lower::expr {

Text escape(const Text& t_p0);

Text char_escape(const Text& text0);

crate::lower::model::Ex number(const crate::lower::model::OutTy& t_p0, const Text& digits_p1, const bool& neg_p2);

Text decimal_digits(const Text& d_p0);

crate::lower::types::Vl literal_value(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Literal& l_p2, const crate::syntax::Range& span_p3, const bool& neg_p4);

prism_rtl::JobRef<crate::lower::types::Vl> start_literal_value(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Literal l_p2, crate::syntax::Range span_p3, bool neg_p4);

crate::lower::types::Vl text_value(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Array<crate::syntax::TextSeg>& segs_p2);

prism_rtl::JobRef<crate::lower::types::Vl> start_text_value(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Array<crate::syntax::TextSeg> segs_p2);

bool is_plain_seg(const crate::syntax::TextSeg& text_seg0);

Text plain_text(const crate::syntax::TextSeg& text_seg0);

crate::lower::model::Ex seg_ex(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::TextSeg& text_seg2);

prism_rtl::JobRef<crate::lower::model::Ex> start_seg_ex(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::TextSeg text_seg2);

crate::lower::model::Ex shown_part(const crate::lower::types::Vl& v_p0);

crate::lower::model::Ex refusal(const Text& what_p0);

crate::lower::model::Ex try_of(const crate::lower::model::Ex& x_p0);

bool is_named_place(const crate::lower::model::Ex& x_p0);

Text lowering_refusal();

crate::lower::model::Do refusal_do(const Text& what_p0);

crate::lower::types::Vl value_of(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2);

prism_rtl::JobRef<crate::lower::types::Vl> start_value_of(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2);

crate::lower::types::Vl unbound_value_of(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2);

prism_rtl::JobRef<crate::lower::types::Vl> start_unbound_value_of(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2);

bool is_event_value(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2);

prism_rtl::JobRef<bool> start_is_event_value(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2);

bool has_event_source(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2);

prism_rtl::JobRef<bool> start_has_event_source(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2);

bool is_event_source(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& c_p2);

prism_rtl::JobRef<bool> start_is_event_source(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr c_p2);

crate::lower::types::Vl event_value_of(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2);

prism_rtl::JobRef<crate::lower::types::Vl> start_event_value_of(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2);

crate::lower::types::Vl value_by_kind(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2);

prism_rtl::JobRef<crate::lower::types::Vl> start_value_by_kind(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2);

crate::lower::types::Vl lifted_value(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2, const crate::check::typed::LiftNote& ln_p3);

prism_rtl::JobRef<crate::lower::types::Vl> start_lifted_value(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2, crate::check::typed::LiftNote ln_p3);

crate::lower::model::Ex lift_operands(const crate::lower::Lx& lx_p0, const crate::lower::Lx& lx_in_p1, const crate::lower::types::Env& env_p2, const crate::syntax::Expr& e_p3, const Text& sigil_p4, const Array<crate::syntax::Range>& operands_p5, const crate::lower::model::OutTy& t_p6);

prism_rtl::JobRef<crate::lower::model::Ex> start_lift_operands(crate::lower::Lx lx_p0, crate::lower::Lx lx_in_p1, crate::lower::types::Env env_p2, crate::syntax::Expr e_p3, Text sigil_p4, Array<crate::syntax::Range> operands_p5, crate::lower::model::OutTy t_p6);

bool is_lifted_at(const crate::lower::Lx& lx_p0, const crate::syntax::Range& r_p1);

std::optional<crate::syntax::Expr> operand_at(const crate::syntax::Expr& e_p0, const crate::syntax::Range& r_p1);

Array<crate::syntax::Expr> direct_operands(const crate::syntax::Expr& e_p0);

crate::lower::types::Vl plain_value_by_kind(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2);

prism_rtl::JobRef<crate::lower::types::Vl> start_plain_value_by_kind(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2);

crate::lower::types::Vl pure_blueprint(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& x_p2, const crate::lower::model::OutTy& t_p3);

prism_rtl::JobRef<crate::lower::types::Vl> start_pure_blueprint(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr x_p2, crate::lower::model::OutTy t_p3);

crate::lower::types::Vl plain_blueprint_(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& x_p2, const Text& variant_p3, const crate::lower::model::OutTy& t_p4);

prism_rtl::JobRef<crate::lower::types::Vl> start_plain_blueprint_(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr x_p2, Text variant_p3, crate::lower::model::OutTy t_p4);

crate::lower::types::Vl dynamic_blueprint_(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& x_p2, const crate::syntax::Expr& d_p3, const Text& variant_p4, const crate::lower::model::OutTy& t_p5);

prism_rtl::JobRef<crate::lower::types::Vl> start_dynamic_blueprint_(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr x_p2, crate::syntax::Expr d_p3, Text variant_p4, crate::lower::model::OutTy t_p5);

crate::lower::types::Vl element_blueprint_(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Array<crate::syntax::Arg>& args_p2, const crate::lower::model::OutTy& t_p3);

prism_rtl::JobRef<crate::lower::types::Vl> start_element_blueprint_(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Array<crate::syntax::Arg> args_p2, crate::lower::model::OutTy t_p3);

Text kind_words(const crate::syntax::ExprKind& k_p0);

crate::lower::types::Vl name_value(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::SName& n_p2, const crate::syntax::Range& span_p3);

prism_rtl::JobRef<crate::lower::types::Vl> start_name_value(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::SName n_p2, crate::syntax::Range span_p3);

crate::lower::types::Vl global_value(const crate::lower::Lx& lx_p0, const Text& qk_p1, const crate::syntax::Range& span_p2, const crate::lower::model::OutTy& t_p3);

prism_rtl::JobRef<crate::lower::types::Vl> start_global_value(crate::lower::Lx lx_p0, Text qk_p1, crate::syntax::Range span_p2, crate::lower::model::OutTy t_p3);

bool is_let_def(const crate::check::env::Def& d_p0);

Text start_path(const crate::lower::Lx& lx_p0, const Text& qk_p1);

crate::lower::types::Vl application(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& callee_p2, const Array<crate::syntax::Arg>& args_p3, const crate::syntax::Range& span_p4);

prism_rtl::JobRef<crate::lower::types::Vl> start_application(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr callee_p2, Array<crate::syntax::Arg> args_p3, crate::syntax::Range span_p4);

crate::lower::types::Vl inline_local_fn(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::decls::FnClause& c_p2, const Array<crate::syntax::Arg>& args_p3, const crate::lower::model::OutTy& t_p4);

prism_rtl::JobRef<crate::lower::types::Vl> start_inline_local_fn(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::decls::FnClause c_p2, Array<crate::syntax::Arg> args_p3, crate::lower::model::OutTy t_p4);

crate::lower::model::Ex argument(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2);

prism_rtl::JobRef<crate::lower::model::Ex> start_argument(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2);

crate::lower::model::Ex argument_by_kind(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2);

prism_rtl::JobRef<crate::lower::model::Ex> start_argument_by_kind(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2);

crate::lower::model::Ex closure_ref(const crate::lower::types::Vl& vl0);

crate::lower::types::Vl tag_value(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::check::env::TagInfo& tg_p2, const Array<crate::syntax::Arg>& args_p3);

prism_rtl::JobRef<crate::lower::types::Vl> start_tag_value(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::check::env::TagInfo tg_p2, Array<crate::syntax::Arg> args_p3);

crate::lower::types::Vl global_call(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Text& qk_p2, const Array<crate::syntax::Arg>& args_p3, const crate::syntax::Range& span_p4, const crate::lower::model::OutTy& t_p5);

prism_rtl::JobRef<crate::lower::types::Vl> start_global_call(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Text qk_p2, Array<crate::syntax::Arg> args_p3, crate::syntax::Range span_p4, crate::lower::model::OutTy t_p5);

crate::lower::model::OutTy result_repr(const crate::lower::Lx& lx_p0, const crate::check::env::ValInfo& v_p1);

prism_rtl::JobRef<crate::lower::model::OutTy> start_result_repr(crate::lower::Lx lx_p0, crate::check::env::ValInfo v_p1);

crate::lower::types::Vl as_instance(const crate::lower::model::Ex& call_p0, const crate::lower::model::OutTy& declared_p1, const crate::lower::model::OutTy& t_p2);

prism_rtl::JobRef<crate::lower::types::Vl> start_as_instance(crate::lower::model::Ex call_p0, crate::lower::model::OutTy declared_p1, crate::lower::model::OutTy t_p2);

bool has_job_fn(const crate::lower::model::OutTy& t_p0);

prism_rtl::JobRef<bool> start_has_job_fn(crate::lower::model::OutTy t_p0);

crate::lower::model::Ex wrap_as_bounded(const crate::lower::model::Ex& f_p0, const Array<crate::lower::model::OutTy>& pts_p1, const crate::lower::model::OutTy& target_p2);

Array<crate::lower::model::Ex> args_for(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::check::env::ValInfo& v_p2, const Array<crate::syntax::Arg>& args_p3);

prism_rtl::JobRef<Array<crate::lower::model::Ex>> start_args_for(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::check::env::ValInfo v_p2, Array<crate::syntax::Arg> args_p3);

crate::syntax::Expr dummy_expr();

crate::lower::types::Vl ctor_app(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::check::env::CtorInfo& c_p2, const Array<crate::syntax::Arg>& args_p3, const crate::syntax::Range& span_p4);

prism_rtl::JobRef<crate::lower::types::Vl> start_ctor_app(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::check::env::CtorInfo c_p2, Array<crate::syntax::Arg> args_p3, crate::syntax::Range span_p4);

crate::lower::model::OutTy built_ty(const crate::lower::model::OutTy& t_p0);

crate::lower::types::Vl ctor_fn(const crate::lower::Lx& lx_p0, const crate::check::env::CtorInfo& c_p1, const Array<crate::lower::model::OutTy>& pts_p2, const crate::syntax::Range& span_p3, const crate::lower::model::OutTy& t_p4, const bool& job_p5);

prism_rtl::JobRef<crate::lower::types::Vl> start_ctor_fn(crate::lower::Lx lx_p0, crate::check::env::CtorInfo c_p1, Array<crate::lower::model::OutTy> pts_p2, crate::syntax::Range span_p3, crate::lower::model::OutTy t_p4, bool job_p5);

bool is_named_arg(const crate::syntax::Arg& a_p0);

Array<crate::lower::model::Ex> ctor_args(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::check::env::CtorInfo& c_p2, const Array<crate::syntax::Arg>& args_p3);

prism_rtl::JobRef<Array<crate::lower::model::Ex>> start_ctor_args(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::check::env::CtorInfo c_p2, Array<crate::syntax::Arg> args_p3);

crate::lower::types::Vl method_call(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::check::env::ValInfo& v_p2, const Array<crate::syntax::Arg>& args_p3, const crate::syntax::Range& span_p4, const crate::lower::model::OutTy& t_p5);

prism_rtl::JobRef<crate::lower::types::Vl> start_method_call(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::check::env::ValInfo v_p2, Array<crate::syntax::Arg> args_p3, crate::syntax::Range span_p4, crate::lower::model::OutTy t_p5);

crate::check::env::TraitInfo dummy_trait_info();

crate::lower::types::Vl prelude_method(const crate::lower::Lx& lx_p0, const Text& cls_p1, const Text& m_p2, const Array<crate::lower::types::Vl>& vals_p3, const crate::syntax::Range& span_p4, const crate::lower::model::OutTy& t_p5);

prism_rtl::JobRef<crate::lower::types::Vl> start_prelude_method(crate::lower::Lx lx_p0, Text cls_p1, Text m_p2, Array<crate::lower::types::Vl> vals_p3, crate::syntax::Range span_p4, crate::lower::model::OutTy t_p5);

crate::lower::types::Vl binary_value(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Text& op_p2, const crate::syntax::Expr& l_p3, const crate::syntax::Expr& r_p4, const crate::syntax::Range& span_p5);

prism_rtl::JobRef<crate::lower::types::Vl> start_binary_value(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Text op_p2, crate::syntax::Expr l_p3, crate::syntax::Expr r_p4, crate::syntax::Range span_p5);

crate::lower::types::Vl op_value(const crate::lower::Lx& lx_p0, const Text& op_p1, const crate::lower::types::Vl& a_p2, const crate::lower::types::Vl& b_p3, const crate::syntax::Range& span_p4, const crate::lower::model::OutTy& t_p5);

Text num_method(const Text& text0);

crate::lower::types::Vl prelude_call(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Text& qk_p2, const Array<crate::syntax::Arg>& args_p3, const crate::syntax::Range& span_p4, const crate::lower::model::OutTy& t_p5);

prism_rtl::JobRef<crate::lower::types::Vl> start_prelude_call(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Text qk_p2, Array<crate::syntax::Arg> args_p3, crate::syntax::Range span_p4, crate::lower::model::OutTy t_p5);

std::optional<crate::lower::model::Ex> prelude_job(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Text& variant_p2, const Array<crate::syntax::Arg>& args_p3);

prism_rtl::JobRef<std::optional<crate::lower::model::Ex>> start_prelude_job(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Text variant_p2, Array<crate::syntax::Arg> args_p3);

std::optional<crate::lower::model::Ex> prelude_job_call(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2);

prism_rtl::JobRef<std::optional<crate::lower::model::Ex>> start_prelude_job_call(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2);

crate::lower::model::Ex as_job_value(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2);

prism_rtl::JobRef<crate::lower::model::Ex> start_as_job_value(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2);

crate::lower::model::Ex wrap_as_job(const crate::lower::model::Ex& f_p0, const Array<crate::lower::model::OutTy>& pts_p1, const crate::lower::model::OutTy& target_p2, const crate::lower::model::OutTy& a_p3);

Array<crate::lower::model::Ex> named_args_owned(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Text& qk_p2, const Array<crate::syntax::Arg>& args_p3);

prism_rtl::JobRef<Array<crate::lower::model::Ex>> start_named_args_owned(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Text qk_p2, Array<crate::syntax::Arg> args_p3);

Array<crate::lower::model::Ex> start_args(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::lower::types::Vl& f_p2, const Array<crate::syntax::Arg>& args_p3);

prism_rtl::JobRef<Array<crate::lower::model::Ex>> start_start_args(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::lower::types::Vl f_p2, Array<crate::syntax::Arg> args_p3);

Text prelude_variant(const Text& name_p0, const crate::lower::model::OutTy& first_p1);

crate::lower::types::Vl field_value(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& r_p2, const Text& name_p3);

prism_rtl::JobRef<crate::lower::types::Vl> start_field_value(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr r_p2, Text name_p3);

std::tuple<crate::lower::model::OutTy, bool> field_info(const crate::lower::Lx& lx_p0, const crate::check::types::Ty& rty_p1, const Text& name_p2);

prism_rtl::JobRef<std::tuple<crate::lower::model::OutTy, bool>> start_field_info(crate::lower::Lx lx_p0, crate::check::types::Ty rty_p1, Text name_p2);

crate::check::types::Ty instantiated(const crate::check::types::Ty& t_p0, const Array<Text>& params_p1, const Array<crate::check::types::Ty>& args_p2);

prism_rtl::JobRef<crate::check::types::Ty> start_instantiated(crate::check::types::Ty t_p0, Array<Text> params_p1, Array<crate::check::types::Ty> args_p2);

crate::lower::types::Vl index_value(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& r_p2, const crate::syntax::Expr& i_p3, const crate::lower::model::OutTy& t_p4);

prism_rtl::JobRef<crate::lower::types::Vl> start_index_value(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr r_p2, crate::syntax::Expr i_p3, crate::lower::model::OutTy t_p4);

Array<Text> read_names(const Array<crate::syntax::Expr>& es_p0);

prism_rtl::JobRef<Array<Text>> start_read_names(Array<crate::syntax::Expr> es_p0);

Array<crate::syntax::Expr> lambda_exprs(const crate::syntax::LambdaBody& lambda_body0);

prism_rtl::JobRef<Array<crate::syntax::Expr>> start_lambda_exprs(crate::syntax::LambdaBody lambda_body0);

Array<Text> free_reads(const Array<crate::syntax::Expr>& es_p0, const Array<std::tuple<Array<Text>, crate::syntax::Range>>& outer_p1);

prism_rtl::JobRef<Array<Text>> start_free_reads(Array<crate::syntax::Expr> es_p0, Array<std::tuple<Array<Text>, crate::syntax::Range>> outer_p1);

Array<std::tuple<Array<Text>, crate::syntax::Range>> scopes_of(const crate::syntax::Expr& e_p0);

prism_rtl::JobRef<Array<std::tuple<Array<Text>, crate::syntax::Range>>> start_scopes_of(crate::syntax::Expr e_p0);

Array<Text> opt_pattern_names(const std::optional<crate::syntax::Pattern_>& opt0);

Array<std::tuple<Array<Text>, crate::syntax::Range>> block_scopes(const crate::syntax::Block& b_p0);

Array<Text> lambda_reads(const Array<crate::syntax::Pattern_>& ps_p0, const crate::syntax::LambdaBody& body_p1);

prism_rtl::JobRef<Array<Text>> start_lambda_reads(Array<crate::syntax::Pattern_> ps_p0, crate::syntax::LambdaBody body_p1);

crate::lower::types::Vl lambda_value(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2, const Array<crate::syntax::Pattern_>& ps_p3, const crate::syntax::LambdaBody& body_p4);

prism_rtl::JobRef<crate::lower::types::Vl> start_lambda_value(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2, Array<crate::syntax::Pattern_> ps_p3, crate::syntax::LambdaBody body_p4);

crate::lower::types::Vl plain_lambda(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Array<crate::syntax::Pattern_>& ps_p2, const crate::syntax::LambdaBody& body_p3, const crate::lower::model::OutTy& ft_p4);

prism_rtl::JobRef<crate::lower::types::Vl> start_plain_lambda(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Array<crate::syntax::Pattern_> ps_p2, crate::syntax::LambdaBody body_p3, crate::lower::model::OutTy ft_p4);

Array<crate::lower::model::OutTy> lambda_param_tys(const crate::lower::Lx& lx_p0, const crate::syntax::Expr& e_p1, const Nat& n_p2);

prism_rtl::JobRef<Array<crate::lower::model::OutTy>> start_lambda_param_tys(crate::lower::Lx lx_p0, crate::syntax::Expr e_p1, Nat n_p2);

bool is_known_ty(const crate::lower::model::OutTy& t_p0);

prism_rtl::JobRef<bool> start_is_known_ty(crate::lower::model::OutTy t_p0);

crate::lower::types::Vl job_lambda(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Array<crate::syntax::Pattern_>& ps_p2, const crate::syntax::LambdaBody& body_p3, const crate::lower::model::OutTy& ft_p4, const crate::lower::model::OutTy& a_p5, const bool& enter_p6);

prism_rtl::JobRef<crate::lower::types::Vl> start_job_lambda(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Array<crate::syntax::Pattern_> ps_p2, crate::syntax::LambdaBody body_p3, crate::lower::model::OutTy ft_p4, crate::lower::model::OutTy a_p5, bool enter_p6);

bool enters_lambda(const crate::lower::Lx& lx_p0, const crate::syntax::Expr& e_p1);

crate::lower::types::Env only_captured(const crate::lower::types::Env& env_p0, const Array<Text>& caps_p1);

crate::lower::model::Do cond_as_let(const crate::lower::model::Cc& cc0);

crate::lower::model::Ex lambda_arg(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Array<crate::syntax::Pattern_>& ps_p2, const crate::syntax::LambdaBody& body_p3, const Array<crate::lower::model::OutTy>& pts_p4);

prism_rtl::JobRef<crate::lower::model::Ex> start_lambda_arg(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Array<crate::syntax::Pattern_> ps_p2, crate::syntax::LambdaBody body_p3, Array<crate::lower::model::OutTy> pts_p4);

crate::lower::types::Vl lambda_body_value(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::LambdaBody& lambda_body2);

prism_rtl::JobRef<crate::lower::types::Vl> start_lambda_body_value(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::LambdaBody lambda_body2);

std::tuple<Array<crate::lower::model::Pa>, crate::lower::types::Env> closure_params(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Array<crate::syntax::Pattern_>& ps_p2, const Array<crate::lower::model::OutTy>& pts_p3, const bool& typed_p4);

prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Pa>, crate::lower::types::Env>> start_closure_params(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Array<crate::syntax::Pattern_> ps_p2, Array<crate::lower::model::OutTy> pts_p3, bool typed_p4);

crate::lower::types::Env bind_all(const crate::lower::types::Env& env_p0, const Array<std::tuple<Text, crate::lower::types::Bn>>& bs_p1);

crate::check::types::Ty binder_ty_of_pattern(const crate::lower::Lx& lx_p0, const crate::syntax::Pattern_& p_p1);

crate::lower::types::Vl if_value(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Cond& c_p2, const crate::syntax::Block& then_b_p3, const std::optional<crate::syntax::Block>& else_b_o4, const crate::lower::model::OutTy& t_p5);

prism_rtl::JobRef<crate::lower::types::Vl> start_if_value(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Cond c_p2, crate::syntax::Block then_b_p3, std::optional<crate::syntax::Block> else_b_o4, crate::lower::model::OutTy t_p5);

crate::lower::types::Vl arms_value(const crate::lower::model::Ex& scrut_p0, const Array<crate::lower::model::XArm>& arms_p1, const Text& label_p2, const crate::lower::model::OutTy& t_p3);

bool is_let_cond(const crate::lower::model::Cc& cc0);

crate::lower::types::Vl match_value(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& s_p2, const Array<crate::syntax::Arm>& arms_p3, const crate::lower::model::OutTy& t_p4, const crate::syntax::Range& span_p5);

prism_rtl::JobRef<crate::lower::types::Vl> start_match_value(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr s_p2, Array<crate::syntax::Arm> arms_p3, crate::lower::model::OutTy t_p4, crate::syntax::Range span_p5);

crate::lower::types::Env moved_once(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Arm& arm_p2, const Array<std::tuple<Text, crate::lower::types::Bn>>& binds_p3);

prism_rtl::JobRef<crate::lower::types::Env> start_moved_once(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Arm arm_p2, Array<std::tuple<Text, crate::lower::types::Bn>> binds_p3);

std::optional<crate::syntax::Expr> only_read(const crate::lower::Lx& lx_p0, const crate::syntax::Arm& arm_p1, const Text& nkey_p2);

prism_rtl::JobRef<std::optional<crate::syntax::Expr>> start_only_read(crate::lower::Lx lx_p0, crate::syntax::Arm arm_p1, Text nkey_p2);

Nat word_count(const Text& text_p0, const Text& name_p1);

crate::syntax::Arm dummy_arm();

crate::lower::patterns::PatOut arm_pat(const crate::lower::Lx& lx_p0, const std::optional<crate::syntax::Pattern_>& opt1, const crate::check::types::Ty& ty_p2, const crate::lower::types::Holding& mode_p3, const Text& fresh_p4);

prism_rtl::JobRef<crate::lower::patterns::PatOut> start_arm_pat(crate::lower::Lx lx_p0, std::optional<crate::syntax::Pattern_> opt1, crate::check::types::Ty ty_p2, crate::lower::types::Holding mode_p3, Text fresh_p4);

crate::lower::types::Vl block_value(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Block& b_p2);

prism_rtl::JobRef<crate::lower::types::Vl> start_block_value(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Block b_p2);

bool is_given_block(const Array<crate::syntax::Stmt>& stmts_p0);

bool is_guardish(const crate::syntax::Stmt& s_p0);

crate::lower::model::OutTy block_ty(const crate::lower::Lx& lx_p0, const crate::syntax::Block& b_p1);

prism_rtl::JobRef<crate::lower::model::OutTy> start_block_ty(crate::lower::Lx lx_p0, crate::syntax::Block b_p1);

crate::lower::types::Vl plain_block_value(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Block& b_p2);

prism_rtl::JobRef<crate::lower::types::Vl> start_plain_block_value(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Block b_p2);

crate::syntax::Stmt dummy_stmt_l();

std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> block_stmt(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Stmt& s_p2);

prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> start_block_stmt(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Stmt s_p2);

std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> generic_let(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::SName& n_p2, const crate::check::typed::GenNote& gn_p3, const crate::syntax::Expr& x_p4);

prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> start_generic_let(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::SName n_p2, crate::check::typed::GenNote gn_p3, crate::syntax::Expr x_p4);

Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> instantiations(const crate::lower::Lx& lx_p0, const crate::check::typed::GenNote& gn_p1);

prism_rtl::JobRef<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> start_instantiations(crate::lower::Lx lx_p0, crate::check::typed::GenNote gn_p1);

Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> expanded(const crate::lower::Lx& lx_p0, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& i_p1);

prism_rtl::JobRef<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> start_expanded(crate::lower::Lx lx_p0, std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>> i_p1);

std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>> subst_inst(const crate::lower::Lx& lx_p0, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& arg1);

std::optional<Text> open_q(const crate::lower::Lx& lx_p0, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& arg1);

prism_rtl::JobRef<std::optional<Text>> start_open_q(crate::lower::Lx lx_p0, std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>> arg1);

Array<Text> open_cols(const crate::lower::Lx& lx_p0, const crate::check::types::Col& col1);

Array<Text> open_ty_qs(const crate::lower::Lx& lx_p0, const crate::check::types::Ty& t_p1);

prism_rtl::JobRef<Array<Text>> start_open_ty_qs(crate::lower::Lx lx_p0, crate::check::types::Ty t_p1);

crate::lower::Lx at_instance(const crate::lower::Lx& lx_p0, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& arg1);

crate::lower::Lx widget_let_lx(const crate::lower::Lx& lx_p0, const crate::syntax::Range& span_p1);

prism_rtl::JobRef<crate::lower::Lx> start_widget_let_lx(crate::lower::Lx lx_p0, crate::syntax::Range span_p1);

std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>> inst_at(const crate::lower::Lx& lx_p0, const crate::check::typed::InstNote& u_p1);

Text gen_key(const crate::check::typed::GenNote& gn_p0);

Text inst_key(const crate::check::typed::InstNote& u_p0);

Text col_name(const crate::check::types::Col& col0);

std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> plain_let(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Stmt& s_p2, const crate::syntax::Pattern_& p_p3, const crate::syntax::Expr& x_p4);

prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> start_plain_let(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Stmt s_p2, crate::syntax::Pattern_ p_p3, crate::syntax::Expr x_p4);

}  // namespace lower::expr


namespace lower::expr {

/// The step machine of `LiteralValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LiteralValue: unbounded fn Lx, Env, Literal, Range, Bool -> Vl
struct LiteralValue : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Literal l_p2;
    crate::syntax::Range span_p3;
    bool neg_p4;
    LiteralValue(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Literal l_p2, crate::syntax::Range span_p3, bool neg_p4) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), l_p2(std::move(l_p2)), span_p3(std::move(span_p3)), neg_p4(std::move(neg_p4)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `TextValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TextValue: unbounded fn Lx, Env, [TextSeg] -> Vl
struct TextValue : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    Array<crate::syntax::TextSeg> segs_p2;
    TextValue(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Array<crate::syntax::TextSeg> segs_p2) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), segs_p2(std::move(segs_p2)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `SegEx`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SegEx: unbounded fn Lx, Env, TextSeg -> Ex
struct SegEx : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::TextSeg text_seg2;
    SegEx(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::TextSeg text_seg2) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), text_seg2(std::move(text_seg2)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `ValueOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ValueOf: unbounded fn Lx, Env, Expr -> Vl
struct ValueOf : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Expr e_p2;
    ValueOf(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), e_p2(std::move(e_p2)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `UnboundValueOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UnboundValueOf: unbounded fn Lx, Env, Expr -> Vl
struct UnboundValueOf : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Expr e_p2;
    UnboundValueOf(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), e_p2(std::move(e_p2)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `IsEventValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IsEventValue: unbounded fn Lx, Env, Expr -> Bool
struct IsEventValue : prism_rtl::Job<bool> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Expr e_p2;
    IsEventValue(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), e_p2(std::move(e_p2)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `HasEventSource`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// HasEventSource: unbounded fn Lx, Env, Expr -> Bool
struct HasEventSource : prism_rtl::Job<bool> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Expr e_p2;
    HasEventSource(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), e_p2(std::move(e_p2)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `IsEventSource`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IsEventSource: unbounded fn Lx, Env, Expr -> Bool
struct IsEventSource : prism_rtl::Job<bool> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Expr c_p2;
    IsEventSource(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr c_p2) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), c_p2(std::move(c_p2)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `EventValueOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// EventValueOf: unbounded fn Lx, Env, Expr -> Vl
struct EventValueOf : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Expr e_p2;
    EventValueOf(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), e_p2(std::move(e_p2)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `ValueByKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ValueByKind: unbounded fn Lx, Env, Expr -> Vl
struct ValueByKind : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Expr e_p2;
    ValueByKind(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), e_p2(std::move(e_p2)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `LiftedValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LiftedValue: unbounded fn Lx, Env, Expr, LiftNote -> Vl
struct LiftedValue : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Expr e_p2;
    crate::check::typed::LiftNote ln_p3;
    LiftedValue(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2, crate::check::typed::LiftNote ln_p3) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), e_p2(std::move(e_p2)), ln_p3(std::move(ln_p3)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `LiftOperands`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LiftOperands: unbounded fn Lx, Lx, Env, Expr, Text, [Range], OutTy -> Ex
struct LiftOperands : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx_p0;
    crate::lower::Lx lx_in_p1;
    crate::lower::types::Env env_p2;
    crate::syntax::Expr e_p3;
    Text sigil_p4;
    Array<crate::syntax::Range> operands_p5;
    crate::lower::model::OutTy t_p6;
    LiftOperands(crate::lower::Lx lx_p0, crate::lower::Lx lx_in_p1, crate::lower::types::Env env_p2, crate::syntax::Expr e_p3, Text sigil_p4, Array<crate::syntax::Range> operands_p5, crate::lower::model::OutTy t_p6) : lx_p0(std::move(lx_p0)), lx_in_p1(std::move(lx_in_p1)), env_p2(std::move(env_p2)), e_p3(std::move(e_p3)), sigil_p4(std::move(sigil_p4)), operands_p5(std::move(operands_p5)), t_p6(std::move(t_p6)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `PlainValueByKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PlainValueByKind: unbounded fn Lx, Env, Expr -> Vl
struct PlainValueByKind : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Expr e_p2;
    PlainValueByKind(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), e_p2(std::move(e_p2)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `PureBlueprint`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PureBlueprint: unbounded fn Lx, Env, Expr, OutTy -> Vl
struct PureBlueprint : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Expr x_p2;
    crate::lower::model::OutTy t_p3;
    PureBlueprint(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr x_p2, crate::lower::model::OutTy t_p3) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), x_p2(std::move(x_p2)), t_p3(std::move(t_p3)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `PlainBlueprint`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PlainBlueprint: unbounded fn Lx, Env, Expr, Text, OutTy -> Vl
struct PlainBlueprint : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Expr x_p2;
    Text variant_p3;
    crate::lower::model::OutTy t_p4;
    PlainBlueprint(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr x_p2, Text variant_p3, crate::lower::model::OutTy t_p4) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), x_p2(std::move(x_p2)), variant_p3(std::move(variant_p3)), t_p4(std::move(t_p4)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `DynamicBlueprint`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DynamicBlueprint: unbounded fn Lx, Env, Expr, Expr, Text, OutTy -> Vl
struct DynamicBlueprint : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Expr x_p2;
    crate::syntax::Expr d_p3;
    Text variant_p4;
    crate::lower::model::OutTy t_p5;
    DynamicBlueprint(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr x_p2, crate::syntax::Expr d_p3, Text variant_p4, crate::lower::model::OutTy t_p5) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), x_p2(std::move(x_p2)), d_p3(std::move(d_p3)), variant_p4(std::move(variant_p4)), t_p5(std::move(t_p5)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `ElementBlueprint`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ElementBlueprint: unbounded fn Lx, Env, [Arg], OutTy -> Vl
struct ElementBlueprint : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    Array<crate::syntax::Arg> args_p2;
    crate::lower::model::OutTy t_p3;
    ElementBlueprint(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Array<crate::syntax::Arg> args_p2, crate::lower::model::OutTy t_p3) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), args_p2(std::move(args_p2)), t_p3(std::move(t_p3)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `NameValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NameValue: unbounded fn Lx, Env, SName, Range -> Vl
struct NameValue : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::SName n_p2;
    crate::syntax::Range span_p3;
    NameValue(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::SName n_p2, crate::syntax::Range span_p3) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), n_p2(std::move(n_p2)), span_p3(std::move(span_p3)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `GlobalValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GlobalValue: unbounded fn Lx, Text, Range, OutTy -> Vl
struct GlobalValue : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx_p0;
    Text qk_p1;
    crate::syntax::Range span_p2;
    crate::lower::model::OutTy t_p3;
    GlobalValue(crate::lower::Lx lx_p0, Text qk_p1, crate::syntax::Range span_p2, crate::lower::model::OutTy t_p3) : lx_p0(std::move(lx_p0)), qk_p1(std::move(qk_p1)), span_p2(std::move(span_p2)), t_p3(std::move(t_p3)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `Application`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Application: unbounded fn Lx, Env, Expr, [Arg], Range -> Vl
struct Application : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Expr callee_p2;
    Array<crate::syntax::Arg> args_p3;
    crate::syntax::Range span_p4;
    Application(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr callee_p2, Array<crate::syntax::Arg> args_p3, crate::syntax::Range span_p4) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), callee_p2(std::move(callee_p2)), args_p3(std::move(args_p3)), span_p4(std::move(span_p4)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `InlineLocalFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InlineLocalFn: unbounded fn Lx, Env, FnClause, [Arg], OutTy -> Vl
struct InlineLocalFn : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::decls::FnClause c_p2;
    Array<crate::syntax::Arg> args_p3;
    crate::lower::model::OutTy t_p4;
    InlineLocalFn(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::decls::FnClause c_p2, Array<crate::syntax::Arg> args_p3, crate::lower::model::OutTy t_p4) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), c_p2(std::move(c_p2)), args_p3(std::move(args_p3)), t_p4(std::move(t_p4)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `Argument`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Argument: unbounded fn Lx, Env, Expr -> Ex
struct Argument : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Expr e_p2;
    Argument(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), e_p2(std::move(e_p2)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `ArgumentByKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ArgumentByKind: unbounded fn Lx, Env, Expr -> Ex
struct ArgumentByKind : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Expr e_p2;
    ArgumentByKind(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), e_p2(std::move(e_p2)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `TagValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TagValue: unbounded fn Lx, Env, TagInfo, [Arg] -> Vl
struct TagValue : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::check::env::TagInfo tg_p2;
    Array<crate::syntax::Arg> args_p3;
    TagValue(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::check::env::TagInfo tg_p2, Array<crate::syntax::Arg> args_p3) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), tg_p2(std::move(tg_p2)), args_p3(std::move(args_p3)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `GlobalCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GlobalCall: unbounded fn Lx, Env, Text, [Arg], Range, OutTy -> Vl
struct GlobalCall : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    Text qk_p2;
    Array<crate::syntax::Arg> args_p3;
    crate::syntax::Range span_p4;
    crate::lower::model::OutTy t_p5;
    GlobalCall(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Text qk_p2, Array<crate::syntax::Arg> args_p3, crate::syntax::Range span_p4, crate::lower::model::OutTy t_p5) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), qk_p2(std::move(qk_p2)), args_p3(std::move(args_p3)), span_p4(std::move(span_p4)), t_p5(std::move(t_p5)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `ResultRepr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ResultRepr: unbounded fn Lx, ValInfo -> OutTy
struct ResultRepr : prism_rtl::Job<crate::lower::model::OutTy> {
    crate::lower::Lx lx_p0;
    crate::check::env::ValInfo v_p1;
    ResultRepr(crate::lower::Lx lx_p0, crate::check::env::ValInfo v_p1) : lx_p0(std::move(lx_p0)), v_p1(std::move(v_p1)) {}
    prism_rtl::Turn<crate::lower::model::OutTy> cycle() const override;
};


/// The step machine of `AsInstance`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AsInstance: unbounded fn Ex, OutTy, OutTy -> Vl
struct AsInstance : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::model::Ex call_p0;
    crate::lower::model::OutTy declared_p1;
    crate::lower::model::OutTy t_p2;
    AsInstance(crate::lower::model::Ex call_p0, crate::lower::model::OutTy declared_p1, crate::lower::model::OutTy t_p2) : call_p0(std::move(call_p0)), declared_p1(std::move(declared_p1)), t_p2(std::move(t_p2)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `HasJobFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// HasJobFn: unbounded fn OutTy -> Bool
struct HasJobFn : prism_rtl::Job<bool> {
    crate::lower::model::OutTy t_p0;
    HasJobFn(crate::lower::model::OutTy t_p0) : t_p0(std::move(t_p0)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `ArgsFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ArgsFor: unbounded fn Lx, Env, ValInfo, [Arg] -> [Ex]
struct ArgsFor : prism_rtl::Job<Array<crate::lower::model::Ex>> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::check::env::ValInfo v_p2;
    Array<crate::syntax::Arg> args_p3;
    ArgsFor(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::check::env::ValInfo v_p2, Array<crate::syntax::Arg> args_p3) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), v_p2(std::move(v_p2)), args_p3(std::move(args_p3)) {}
    prism_rtl::Turn<Array<crate::lower::model::Ex>> cycle() const override;
};


/// The step machine of `CtorApp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CtorApp: unbounded fn Lx, Env, CtorInfo, [Arg], Range -> Vl
struct CtorApp : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::check::env::CtorInfo c_p2;
    Array<crate::syntax::Arg> args_p3;
    crate::syntax::Range span_p4;
    CtorApp(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::check::env::CtorInfo c_p2, Array<crate::syntax::Arg> args_p3, crate::syntax::Range span_p4) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), c_p2(std::move(c_p2)), args_p3(std::move(args_p3)), span_p4(std::move(span_p4)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `CtorFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CtorFn: unbounded fn Lx, CtorInfo, [OutTy], Range, OutTy, Bool -> Vl
struct CtorFn : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx_p0;
    crate::check::env::CtorInfo c_p1;
    Array<crate::lower::model::OutTy> pts_p2;
    crate::syntax::Range span_p3;
    crate::lower::model::OutTy t_p4;
    bool job_p5;
    CtorFn(crate::lower::Lx lx_p0, crate::check::env::CtorInfo c_p1, Array<crate::lower::model::OutTy> pts_p2, crate::syntax::Range span_p3, crate::lower::model::OutTy t_p4, bool job_p5) : lx_p0(std::move(lx_p0)), c_p1(std::move(c_p1)), pts_p2(std::move(pts_p2)), span_p3(std::move(span_p3)), t_p4(std::move(t_p4)), job_p5(std::move(job_p5)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `CtorArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CtorArgs: unbounded fn Lx, Env, CtorInfo, [Arg] -> [Ex]
struct CtorArgs : prism_rtl::Job<Array<crate::lower::model::Ex>> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::check::env::CtorInfo c_p2;
    Array<crate::syntax::Arg> args_p3;
    CtorArgs(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::check::env::CtorInfo c_p2, Array<crate::syntax::Arg> args_p3) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), c_p2(std::move(c_p2)), args_p3(std::move(args_p3)) {}
    prism_rtl::Turn<Array<crate::lower::model::Ex>> cycle() const override;
};


/// The step machine of `MethodCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MethodCall: unbounded fn Lx, Env, ValInfo, [Arg], Range, OutTy -> Vl
struct MethodCall : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::check::env::ValInfo v_p2;
    Array<crate::syntax::Arg> args_p3;
    crate::syntax::Range span_p4;
    crate::lower::model::OutTy t_p5;
    MethodCall(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::check::env::ValInfo v_p2, Array<crate::syntax::Arg> args_p3, crate::syntax::Range span_p4, crate::lower::model::OutTy t_p5) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), v_p2(std::move(v_p2)), args_p3(std::move(args_p3)), span_p4(std::move(span_p4)), t_p5(std::move(t_p5)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `PreludeMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PreludeMethod: unbounded fn Lx, Text, Text, [Vl], Range, OutTy -> Vl
struct PreludeMethod : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx_p0;
    Text cls_p1;
    Text m_p2;
    Array<crate::lower::types::Vl> vals_p3;
    crate::syntax::Range span_p4;
    crate::lower::model::OutTy t_p5;
    PreludeMethod(crate::lower::Lx lx_p0, Text cls_p1, Text m_p2, Array<crate::lower::types::Vl> vals_p3, crate::syntax::Range span_p4, crate::lower::model::OutTy t_p5) : lx_p0(std::move(lx_p0)), cls_p1(std::move(cls_p1)), m_p2(std::move(m_p2)), vals_p3(std::move(vals_p3)), span_p4(std::move(span_p4)), t_p5(std::move(t_p5)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `BinaryValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BinaryValue: unbounded fn Lx, Env, Text, Expr, Expr, Range -> Vl
struct BinaryValue : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    Text op_p2;
    crate::syntax::Expr l_p3;
    crate::syntax::Expr r_p4;
    crate::syntax::Range span_p5;
    BinaryValue(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Text op_p2, crate::syntax::Expr l_p3, crate::syntax::Expr r_p4, crate::syntax::Range span_p5) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), op_p2(std::move(op_p2)), l_p3(std::move(l_p3)), r_p4(std::move(r_p4)), span_p5(std::move(span_p5)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `PreludeCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PreludeCall: unbounded fn Lx, Env, Text, [Arg], Range, OutTy -> Vl
struct PreludeCall : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    Text qk_p2;
    Array<crate::syntax::Arg> args_p3;
    crate::syntax::Range span_p4;
    crate::lower::model::OutTy t_p5;
    PreludeCall(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Text qk_p2, Array<crate::syntax::Arg> args_p3, crate::syntax::Range span_p4, crate::lower::model::OutTy t_p5) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), qk_p2(std::move(qk_p2)), args_p3(std::move(args_p3)), span_p4(std::move(span_p4)), t_p5(std::move(t_p5)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `PreludeJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?PreludeJob: unbounded fn Lx, Env, Text, [Arg] -> ?Ex
struct PreludeJob : prism_rtl::Job<std::optional<crate::lower::model::Ex>> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    Text variant_p2;
    Array<crate::syntax::Arg> args_p3;
    PreludeJob(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Text variant_p2, Array<crate::syntax::Arg> args_p3) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), variant_p2(std::move(variant_p2)), args_p3(std::move(args_p3)) {}
    prism_rtl::Turn<std::optional<crate::lower::model::Ex>> cycle() const override;
};


/// The step machine of `PreludeJobCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?PreludeJobCall: unbounded fn Lx, Env, Expr -> ?Ex
struct PreludeJobCall : prism_rtl::Job<std::optional<crate::lower::model::Ex>> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Expr e_p2;
    PreludeJobCall(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), e_p2(std::move(e_p2)) {}
    prism_rtl::Turn<std::optional<crate::lower::model::Ex>> cycle() const override;
};


/// The step machine of `AsJobValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AsJobValue: unbounded fn Lx, Env, Expr -> Ex
struct AsJobValue : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Expr e_p2;
    AsJobValue(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), e_p2(std::move(e_p2)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `NamedArgsOwned`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NamedArgsOwned: unbounded fn Lx, Env, Text, [Arg] -> [Ex]
struct NamedArgsOwned : prism_rtl::Job<Array<crate::lower::model::Ex>> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    Text qk_p2;
    Array<crate::syntax::Arg> args_p3;
    NamedArgsOwned(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Text qk_p2, Array<crate::syntax::Arg> args_p3) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), qk_p2(std::move(qk_p2)), args_p3(std::move(args_p3)) {}
    prism_rtl::Turn<Array<crate::lower::model::Ex>> cycle() const override;
};


/// The step machine of `StartArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StartArgs: unbounded fn Lx, Env, Vl, [Arg] -> [Ex]
struct StartArgs : prism_rtl::Job<Array<crate::lower::model::Ex>> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::lower::types::Vl f_p2;
    Array<crate::syntax::Arg> args_p3;
    StartArgs(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::lower::types::Vl f_p2, Array<crate::syntax::Arg> args_p3) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), f_p2(std::move(f_p2)), args_p3(std::move(args_p3)) {}
    prism_rtl::Turn<Array<crate::lower::model::Ex>> cycle() const override;
};


/// The step machine of `FieldValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FieldValue: unbounded fn Lx, Env, Expr, Text -> Vl
struct FieldValue : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Expr r_p2;
    Text name_p3;
    FieldValue(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr r_p2, Text name_p3) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), r_p2(std::move(r_p2)), name_p3(std::move(name_p3)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `FieldInfo`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FieldInfo: unbounded fn Lx, Ty, Text -> ((OutTy, Bool))
struct FieldInfo : prism_rtl::Job<std::tuple<crate::lower::model::OutTy, bool>> {
    crate::lower::Lx lx_p0;
    crate::check::types::Ty rty_p1;
    Text name_p2;
    FieldInfo(crate::lower::Lx lx_p0, crate::check::types::Ty rty_p1, Text name_p2) : lx_p0(std::move(lx_p0)), rty_p1(std::move(rty_p1)), name_p2(std::move(name_p2)) {}
    prism_rtl::Turn<std::tuple<crate::lower::model::OutTy, bool>> cycle() const override;
};


/// The step machine of `Instantiated`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Instantiated: unbounded fn Ty, [Text], [Ty] -> Ty
struct Instantiated : prism_rtl::Job<crate::check::types::Ty> {
    crate::check::types::Ty t_p0;
    Array<Text> params_p1;
    Array<crate::check::types::Ty> args_p2;
    Instantiated(crate::check::types::Ty t_p0, Array<Text> params_p1, Array<crate::check::types::Ty> args_p2) : t_p0(std::move(t_p0)), params_p1(std::move(params_p1)), args_p2(std::move(args_p2)) {}
    prism_rtl::Turn<crate::check::types::Ty> cycle() const override;
};


/// The step machine of `IndexValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IndexValue: unbounded fn Lx, Env, Expr, Expr, OutTy -> Vl
struct IndexValue : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Expr r_p2;
    crate::syntax::Expr i_p3;
    crate::lower::model::OutTy t_p4;
    IndexValue(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr r_p2, crate::syntax::Expr i_p3, crate::lower::model::OutTy t_p4) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), r_p2(std::move(r_p2)), i_p3(std::move(i_p3)), t_p4(std::move(t_p4)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `ReadNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ReadNames: unbounded fn [Expr] -> [Text]
struct ReadNames : prism_rtl::Job<Array<Text>> {
    Array<crate::syntax::Expr> es_p0;
    ReadNames(Array<crate::syntax::Expr> es_p0) : es_p0(std::move(es_p0)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `LambdaExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LambdaExprs: unbounded fn LambdaBody -> [Expr]
struct LambdaExprs : prism_rtl::Job<Array<crate::syntax::Expr>> {
    crate::syntax::LambdaBody lambda_body0;
    LambdaExprs(crate::syntax::LambdaBody lambda_body0) : lambda_body0(std::move(lambda_body0)) {}
    prism_rtl::Turn<Array<crate::syntax::Expr>> cycle() const override;
};


/// The step machine of `FreeReads`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FreeReads: unbounded fn [Expr], [(([Text], Range))] -> [Text]
struct FreeReads : prism_rtl::Job<Array<Text>> {
    Array<crate::syntax::Expr> es_p0;
    Array<std::tuple<Array<Text>, crate::syntax::Range>> outer_p1;
    FreeReads(Array<crate::syntax::Expr> es_p0, Array<std::tuple<Array<Text>, crate::syntax::Range>> outer_p1) : es_p0(std::move(es_p0)), outer_p1(std::move(outer_p1)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `ScopesOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ScopesOf: unbounded fn Expr -> [(([Text], Range))]
struct ScopesOf : prism_rtl::Job<Array<std::tuple<Array<Text>, crate::syntax::Range>>> {
    crate::syntax::Expr e_p0;
    ScopesOf(crate::syntax::Expr e_p0) : e_p0(std::move(e_p0)) {}
    prism_rtl::Turn<Array<std::tuple<Array<Text>, crate::syntax::Range>>> cycle() const override;
};


/// The step machine of `LambdaReads`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LambdaReads: unbounded fn [Pattern], LambdaBody -> [Text]
struct LambdaReads : prism_rtl::Job<Array<Text>> {
    Array<crate::syntax::Pattern_> ps_p0;
    crate::syntax::LambdaBody body_p1;
    LambdaReads(Array<crate::syntax::Pattern_> ps_p0, crate::syntax::LambdaBody body_p1) : ps_p0(std::move(ps_p0)), body_p1(std::move(body_p1)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `LambdaValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LambdaValue: unbounded fn Lx, Env, Expr, [Pattern], LambdaBody -> Vl
struct LambdaValue : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Expr e_p2;
    Array<crate::syntax::Pattern_> ps_p3;
    crate::syntax::LambdaBody body_p4;
    LambdaValue(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2, Array<crate::syntax::Pattern_> ps_p3, crate::syntax::LambdaBody body_p4) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), e_p2(std::move(e_p2)), ps_p3(std::move(ps_p3)), body_p4(std::move(body_p4)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `PlainLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PlainLambda: unbounded fn Lx, Env, [Pattern], LambdaBody, OutTy -> Vl
struct PlainLambda : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    Array<crate::syntax::Pattern_> ps_p2;
    crate::syntax::LambdaBody body_p3;
    crate::lower::model::OutTy ft_p4;
    PlainLambda(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Array<crate::syntax::Pattern_> ps_p2, crate::syntax::LambdaBody body_p3, crate::lower::model::OutTy ft_p4) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), ps_p2(std::move(ps_p2)), body_p3(std::move(body_p3)), ft_p4(std::move(ft_p4)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `LambdaParamTys`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LambdaParamTys: unbounded fn Lx, Expr, Nat -> [OutTy]
struct LambdaParamTys : prism_rtl::Job<Array<crate::lower::model::OutTy>> {
    crate::lower::Lx lx_p0;
    crate::syntax::Expr e_p1;
    Nat n_p2;
    LambdaParamTys(crate::lower::Lx lx_p0, crate::syntax::Expr e_p1, Nat n_p2) : lx_p0(std::move(lx_p0)), e_p1(std::move(e_p1)), n_p2(std::move(n_p2)) {}
    prism_rtl::Turn<Array<crate::lower::model::OutTy>> cycle() const override;
};


/// The step machine of `IsKnownTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IsKnownTy: unbounded fn OutTy -> Bool
struct IsKnownTy : prism_rtl::Job<bool> {
    crate::lower::model::OutTy t_p0;
    IsKnownTy(crate::lower::model::OutTy t_p0) : t_p0(std::move(t_p0)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `JobLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// JobLambda: unbounded fn Lx, Env, [Pattern], LambdaBody, OutTy, OutTy, Bool -> Vl
struct JobLambda : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    Array<crate::syntax::Pattern_> ps_p2;
    crate::syntax::LambdaBody body_p3;
    crate::lower::model::OutTy ft_p4;
    crate::lower::model::OutTy a_p5;
    bool enter_p6;
    JobLambda(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Array<crate::syntax::Pattern_> ps_p2, crate::syntax::LambdaBody body_p3, crate::lower::model::OutTy ft_p4, crate::lower::model::OutTy a_p5, bool enter_p6) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), ps_p2(std::move(ps_p2)), body_p3(std::move(body_p3)), ft_p4(std::move(ft_p4)), a_p5(std::move(a_p5)), enter_p6(std::move(enter_p6)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `LambdaArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LambdaArg: unbounded fn Lx, Env, [Pattern], LambdaBody, [OutTy] -> Ex
struct LambdaArg : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    Array<crate::syntax::Pattern_> ps_p2;
    crate::syntax::LambdaBody body_p3;
    Array<crate::lower::model::OutTy> pts_p4;
    LambdaArg(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Array<crate::syntax::Pattern_> ps_p2, crate::syntax::LambdaBody body_p3, Array<crate::lower::model::OutTy> pts_p4) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), ps_p2(std::move(ps_p2)), body_p3(std::move(body_p3)), pts_p4(std::move(pts_p4)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `LambdaBodyValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LambdaBodyValue: unbounded fn Lx, Env, LambdaBody -> Vl
struct LambdaBodyValue : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::LambdaBody lambda_body2;
    LambdaBodyValue(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::LambdaBody lambda_body2) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), lambda_body2(std::move(lambda_body2)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `ClosureParams`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClosureParams: unbounded fn Lx, Env, [Pattern], [OutTy], Bool -> (([Pa], Env))
struct ClosureParams : prism_rtl::Job<std::tuple<Array<crate::lower::model::Pa>, crate::lower::types::Env>> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    Array<crate::syntax::Pattern_> ps_p2;
    Array<crate::lower::model::OutTy> pts_p3;
    bool typed_p4;
    ClosureParams(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Array<crate::syntax::Pattern_> ps_p2, Array<crate::lower::model::OutTy> pts_p3, bool typed_p4) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), ps_p2(std::move(ps_p2)), pts_p3(std::move(pts_p3)), typed_p4(std::move(typed_p4)) {}
    prism_rtl::Turn<std::tuple<Array<crate::lower::model::Pa>, crate::lower::types::Env>> cycle() const override;
};


/// The step machine of `IfValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IfValue: unbounded fn Lx, Env, Cond, Block, ?Block, OutTy -> Vl
struct IfValue : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Cond c_p2;
    crate::syntax::Block then_b_p3;
    std::optional<crate::syntax::Block> else_b_o4;
    crate::lower::model::OutTy t_p5;
    IfValue(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Cond c_p2, crate::syntax::Block then_b_p3, std::optional<crate::syntax::Block> else_b_o4, crate::lower::model::OutTy t_p5) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), c_p2(std::move(c_p2)), then_b_p3(std::move(then_b_p3)), else_b_o4(std::move(else_b_o4)), t_p5(std::move(t_p5)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `MatchValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MatchValue: unbounded fn Lx, Env, Expr, [Arm], OutTy, Range -> Vl
struct MatchValue : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Expr s_p2;
    Array<crate::syntax::Arm> arms_p3;
    crate::lower::model::OutTy t_p4;
    crate::syntax::Range span_p5;
    MatchValue(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr s_p2, Array<crate::syntax::Arm> arms_p3, crate::lower::model::OutTy t_p4, crate::syntax::Range span_p5) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), s_p2(std::move(s_p2)), arms_p3(std::move(arms_p3)), t_p4(std::move(t_p4)), span_p5(std::move(span_p5)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `MovedOnce`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MovedOnce: unbounded fn Lx, Env, Arm, [((Text, Bn))] -> Env
struct MovedOnce : prism_rtl::Job<crate::lower::types::Env> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Arm arm_p2;
    Array<std::tuple<Text, crate::lower::types::Bn>> binds_p3;
    MovedOnce(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Arm arm_p2, Array<std::tuple<Text, crate::lower::types::Bn>> binds_p3) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), arm_p2(std::move(arm_p2)), binds_p3(std::move(binds_p3)) {}
    prism_rtl::Turn<crate::lower::types::Env> cycle() const override;
};


/// The step machine of `OnlyRead`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?OnlyRead: unbounded fn Lx, Arm, Text -> ?Expr
struct OnlyRead : prism_rtl::Job<std::optional<crate::syntax::Expr>> {
    crate::lower::Lx lx_p0;
    crate::syntax::Arm arm_p1;
    Text nkey_p2;
    OnlyRead(crate::lower::Lx lx_p0, crate::syntax::Arm arm_p1, Text nkey_p2) : lx_p0(std::move(lx_p0)), arm_p1(std::move(arm_p1)), nkey_p2(std::move(nkey_p2)) {}
    prism_rtl::Turn<std::optional<crate::syntax::Expr>> cycle() const override;
};


/// The step machine of `ArmPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ArmPat: unbounded fn Lx, ?Pattern, Ty, Holding, Text -> PatOut
struct ArmPat : prism_rtl::Job<crate::lower::patterns::PatOut> {
    crate::lower::Lx lx_p0;
    std::optional<crate::syntax::Pattern_> opt1;
    crate::check::types::Ty ty_p2;
    crate::lower::types::Holding mode_p3;
    Text fresh_p4;
    ArmPat(crate::lower::Lx lx_p0, std::optional<crate::syntax::Pattern_> opt1, crate::check::types::Ty ty_p2, crate::lower::types::Holding mode_p3, Text fresh_p4) : lx_p0(std::move(lx_p0)), opt1(std::move(opt1)), ty_p2(std::move(ty_p2)), mode_p3(std::move(mode_p3)), fresh_p4(std::move(fresh_p4)) {}
    prism_rtl::Turn<crate::lower::patterns::PatOut> cycle() const override;
};


/// The step machine of `BlockValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BlockValue: unbounded fn Lx, Env, Block -> Vl
struct BlockValue : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Block b_p2;
    BlockValue(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Block b_p2) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), b_p2(std::move(b_p2)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `BlockTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BlockTy: unbounded fn Lx, Block -> OutTy
struct BlockTy : prism_rtl::Job<crate::lower::model::OutTy> {
    crate::lower::Lx lx_p0;
    crate::syntax::Block b_p1;
    BlockTy(crate::lower::Lx lx_p0, crate::syntax::Block b_p1) : lx_p0(std::move(lx_p0)), b_p1(std::move(b_p1)) {}
    prism_rtl::Turn<crate::lower::model::OutTy> cycle() const override;
};


/// The step machine of `PlainBlockValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PlainBlockValue: unbounded fn Lx, Env, Block -> Vl
struct PlainBlockValue : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Block b_p2;
    PlainBlockValue(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Block b_p2) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), b_p2(std::move(b_p2)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `BlockStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BlockStmt: unbounded fn Lx, Env, Stmt -> (([Do], Env))
struct BlockStmt : prism_rtl::Job<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Stmt s_p2;
    BlockStmt(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Stmt s_p2) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), s_p2(std::move(s_p2)) {}
    prism_rtl::Turn<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> cycle() const override;
};


/// The step machine of `GenericLet`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GenericLet: unbounded fn Lx, Env, SName, GenNote, Expr -> (([Do], Env))
struct GenericLet : prism_rtl::Job<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::SName n_p2;
    crate::check::typed::GenNote gn_p3;
    crate::syntax::Expr x_p4;
    GenericLet(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::SName n_p2, crate::check::typed::GenNote gn_p3, crate::syntax::Expr x_p4) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), n_p2(std::move(n_p2)), gn_p3(std::move(gn_p3)), x_p4(std::move(x_p4)) {}
    prism_rtl::Turn<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> cycle() const override;
};


/// The step machine of `Instantiations`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Instantiations: unbounded fn Lx, GenNote -> [(([((Text, Ty))], [((Text, Col))]))]
struct Instantiations : prism_rtl::Job<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> {
    crate::lower::Lx lx_p0;
    crate::check::typed::GenNote gn_p1;
    Instantiations(crate::lower::Lx lx_p0, crate::check::typed::GenNote gn_p1) : lx_p0(std::move(lx_p0)), gn_p1(std::move(gn_p1)) {}
    prism_rtl::Turn<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> cycle() const override;
};


/// The step machine of `Expanded`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Expanded: unbounded fn Lx, (([((Text, Ty))], [((Text, Col))])) -> [(([((Text, Ty))], [((Text, Col))]))]
struct Expanded : prism_rtl::Job<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> {
    crate::lower::Lx lx_p0;
    std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>> i_p1;
    Expanded(crate::lower::Lx lx_p0, std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>> i_p1) : lx_p0(std::move(lx_p0)), i_p1(std::move(i_p1)) {}
    prism_rtl::Turn<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> cycle() const override;
};


/// The step machine of `OpenQ`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?OpenQ: unbounded fn Lx, (([((Text, Ty))], [((Text, Col))])) -> ?Text
struct OpenQ : prism_rtl::Job<std::optional<Text>> {
    crate::lower::Lx lx_p0;
    std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>> arg1;
    OpenQ(crate::lower::Lx lx_p0, std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>> arg1) : lx_p0(std::move(lx_p0)), arg1(std::move(arg1)) {}
    prism_rtl::Turn<std::optional<Text>> cycle() const override;
};


/// The step machine of `OpenTyQs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OpenTyQs: unbounded fn Lx, Ty -> [Text]
struct OpenTyQs : prism_rtl::Job<Array<Text>> {
    crate::lower::Lx lx_p0;
    crate::check::types::Ty t_p1;
    OpenTyQs(crate::lower::Lx lx_p0, crate::check::types::Ty t_p1) : lx_p0(std::move(lx_p0)), t_p1(std::move(t_p1)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `WidgetLetLx`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WidgetLetLx: unbounded fn Lx, Range -> Lx
struct WidgetLetLx : prism_rtl::Job<crate::lower::Lx> {
    crate::lower::Lx lx_p0;
    crate::syntax::Range span_p1;
    WidgetLetLx(crate::lower::Lx lx_p0, crate::syntax::Range span_p1) : lx_p0(std::move(lx_p0)), span_p1(std::move(span_p1)) {}
    prism_rtl::Turn<crate::lower::Lx> cycle() const override;
};


/// The step machine of `PlainLet`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PlainLet: unbounded fn Lx, Env, Stmt, Pattern, Expr -> (([Do], Env))
struct PlainLet : prism_rtl::Job<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> {
    crate::lower::Lx lx_p0;
    crate::lower::types::Env env_p1;
    crate::syntax::Stmt s_p2;
    crate::syntax::Pattern_ p_p3;
    crate::syntax::Expr x_p4;
    PlainLet(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Stmt s_p2, crate::syntax::Pattern_ p_p3, crate::syntax::Expr x_p4) : lx_p0(std::move(lx_p0)), env_p1(std::move(env_p1)), s_p2(std::move(s_p2)), p_p3(std::move(p_p3)), x_p4(std::move(x_p4)) {}
    prism_rtl::Turn<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> cycle() const override;
};


}  // namespace lower::expr

}  // namespace crate
