// The module `Lower.Expr`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <lower/expr/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace lower::expr {

Text escape(const Text& t);

Text char_escape(const Text& text0);

crate::lower::model::Ex number(const crate::lower::model::OutTy& t, const Text& digits, const bool& neg);

Text decimal_digits(const Text& d);

crate::lower::types::Vl literal_value(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Literal& l, const crate::syntax::Range& span, const bool& neg);

prism_rtl::JobRef<crate::lower::types::Vl> start_literal_value(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Literal l, crate::syntax::Range span, bool neg);

crate::lower::types::Vl text_value(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const Array<crate::syntax::TextSeg>& segs);

prism_rtl::JobRef<crate::lower::types::Vl> start_text_value(crate::lower::Lx lx, crate::lower::types::Env env, Array<crate::syntax::TextSeg> segs);

bool is_plain_seg(const crate::syntax::TextSeg& text_seg0);

Text plain_text(const crate::syntax::TextSeg& text_seg0);

crate::lower::model::Ex seg_ex(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::TextSeg& text_seg2);

prism_rtl::JobRef<crate::lower::model::Ex> start_seg_ex(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::TextSeg text_seg2);

crate::lower::model::Ex shown_part(const crate::lower::types::Vl& v_);

crate::lower::model::Ex refusal(const Text& what);

crate::lower::model::Ex try_of(const crate::lower::model::Ex& x);

bool is_named_place(const crate::lower::model::Ex& x);

Text lowering_refusal();

crate::lower::model::Do refusal_do(const Text& what);

crate::lower::types::Vl value_of(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& e);

prism_rtl::JobRef<crate::lower::types::Vl> start_value_of(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e);

crate::lower::types::Vl unbound_value_of(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& e);

prism_rtl::JobRef<crate::lower::types::Vl> start_unbound_value_of(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e);

bool is_event_value(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& e);

prism_rtl::JobRef<bool> start_is_event_value(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e);

bool has_event_source(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& e);

prism_rtl::JobRef<bool> start_has_event_source(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e);

bool is_event_source(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& c);

prism_rtl::JobRef<bool> start_is_event_source(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr c);

crate::lower::types::Vl event_value_of(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& e);

prism_rtl::JobRef<crate::lower::types::Vl> start_event_value_of(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e);

crate::lower::types::Vl value_by_kind(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& e);

prism_rtl::JobRef<crate::lower::types::Vl> start_value_by_kind(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e);

crate::lower::types::Vl lifted_value(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& e, const crate::check::typed::LiftNote& ln);

prism_rtl::JobRef<crate::lower::types::Vl> start_lifted_value(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e, crate::check::typed::LiftNote ln);

crate::lower::model::Ex lift_operands(const crate::lower::Lx& lx, const crate::lower::Lx& lx_in, const crate::lower::types::Env& env, const crate::syntax::Expr& e, const Text& sigil, const Array<crate::syntax::Range>& operands, const crate::lower::model::OutTy& t);

prism_rtl::JobRef<crate::lower::model::Ex> start_lift_operands(crate::lower::Lx lx, crate::lower::Lx lx_in, crate::lower::types::Env env, crate::syntax::Expr e, Text sigil, Array<crate::syntax::Range> operands, crate::lower::model::OutTy t);

bool is_lifted_at(const crate::lower::Lx& lx, const crate::syntax::Range& r);

std::optional<crate::syntax::Expr> operand_at(const crate::syntax::Expr& e, const crate::syntax::Range& r);

Array<crate::syntax::Expr> direct_operands(const crate::syntax::Expr& e);

crate::lower::types::Vl plain_value_by_kind(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& e);

prism_rtl::JobRef<crate::lower::types::Vl> start_plain_value_by_kind(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e);

crate::lower::types::Vl pure_blueprint(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& x, const crate::lower::model::OutTy& t);

prism_rtl::JobRef<crate::lower::types::Vl> start_pure_blueprint(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr x, crate::lower::model::OutTy t);

crate::lower::types::Vl plain_blueprint_(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& x, const Text& variant, const crate::lower::model::OutTy& t);

prism_rtl::JobRef<crate::lower::types::Vl> start_plain_blueprint_(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr x, Text variant, crate::lower::model::OutTy t);

crate::lower::types::Vl dynamic_blueprint_(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& x, const crate::syntax::Expr& d, const Text& variant, const crate::lower::model::OutTy& t);

prism_rtl::JobRef<crate::lower::types::Vl> start_dynamic_blueprint_(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr x, crate::syntax::Expr d, Text variant, crate::lower::model::OutTy t);

crate::lower::types::Vl element_blueprint_(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const Array<crate::syntax::Arg>& args, const crate::lower::model::OutTy& t);

prism_rtl::JobRef<crate::lower::types::Vl> start_element_blueprint_(crate::lower::Lx lx, crate::lower::types::Env env, Array<crate::syntax::Arg> args, crate::lower::model::OutTy t);

Text kind_words(const crate::syntax::ExprKind& k);

crate::lower::types::Vl name_value(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::SName& n, const crate::syntax::Range& span);

prism_rtl::JobRef<crate::lower::types::Vl> start_name_value(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::SName n, crate::syntax::Range span);

crate::lower::types::Vl global_value(const crate::lower::Lx& lx, const Text& qk, const crate::syntax::Range& span, const crate::lower::model::OutTy& t);

prism_rtl::JobRef<crate::lower::types::Vl> start_global_value(crate::lower::Lx lx, Text qk, crate::syntax::Range span, crate::lower::model::OutTy t);

bool is_let_def(const crate::check::env::Def& d);

Text start_path(const crate::lower::Lx& lx, const Text& qk);

crate::lower::types::Vl application(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& callee, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span);

prism_rtl::JobRef<crate::lower::types::Vl> start_application(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr callee, Array<crate::syntax::Arg> args, crate::syntax::Range span);

crate::lower::types::Vl inline_local_fn(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::decls::FnClause& c, const Array<crate::syntax::Arg>& args, const crate::lower::model::OutTy& t);

prism_rtl::JobRef<crate::lower::types::Vl> start_inline_local_fn(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::decls::FnClause c, Array<crate::syntax::Arg> args, crate::lower::model::OutTy t);

crate::lower::model::Ex argument(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& e);

prism_rtl::JobRef<crate::lower::model::Ex> start_argument(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e);

crate::lower::model::Ex argument_by_kind(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& e);

prism_rtl::JobRef<crate::lower::model::Ex> start_argument_by_kind(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e);

crate::lower::model::Ex closure_ref(const crate::lower::types::Vl& vl0);

crate::lower::types::Vl tag_value(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::check::env::TagInfo& tg, const Array<crate::syntax::Arg>& args);

prism_rtl::JobRef<crate::lower::types::Vl> start_tag_value(crate::lower::Lx lx, crate::lower::types::Env env, crate::check::env::TagInfo tg, Array<crate::syntax::Arg> args);

crate::lower::types::Vl global_call(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const Text& qk, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span, const crate::lower::model::OutTy& t);

prism_rtl::JobRef<crate::lower::types::Vl> start_global_call(crate::lower::Lx lx, crate::lower::types::Env env, Text qk, Array<crate::syntax::Arg> args, crate::syntax::Range span, crate::lower::model::OutTy t);

Array<crate::lower::model::Ex> args_for(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::check::env::ValInfo& v_, const Array<crate::syntax::Arg>& args);

prism_rtl::JobRef<Array<crate::lower::model::Ex>> start_args_for(crate::lower::Lx lx, crate::lower::types::Env env, crate::check::env::ValInfo v_, Array<crate::syntax::Arg> args);

crate::syntax::Expr dummy_expr();

crate::lower::types::Vl ctor_app(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::check::env::CtorInfo& c, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span);

prism_rtl::JobRef<crate::lower::types::Vl> start_ctor_app(crate::lower::Lx lx, crate::lower::types::Env env, crate::check::env::CtorInfo c, Array<crate::syntax::Arg> args, crate::syntax::Range span);

crate::lower::types::Vl ctor_fn(const crate::lower::Lx& lx, const crate::check::env::CtorInfo& c, const Array<crate::lower::model::OutTy>& pts, const crate::syntax::Range& span, const crate::lower::model::OutTy& t, const bool& job);

prism_rtl::JobRef<crate::lower::types::Vl> start_ctor_fn(crate::lower::Lx lx, crate::check::env::CtorInfo c, Array<crate::lower::model::OutTy> pts, crate::syntax::Range span, crate::lower::model::OutTy t, bool job);

bool is_named_arg(const crate::syntax::Arg& a);

Array<crate::lower::model::Ex> ctor_args(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::check::env::CtorInfo& c, const Array<crate::syntax::Arg>& args);

prism_rtl::JobRef<Array<crate::lower::model::Ex>> start_ctor_args(crate::lower::Lx lx, crate::lower::types::Env env, crate::check::env::CtorInfo c, Array<crate::syntax::Arg> args);

crate::lower::types::Vl method_call(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::check::env::ValInfo& v_, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span, const crate::lower::model::OutTy& t);

prism_rtl::JobRef<crate::lower::types::Vl> start_method_call(crate::lower::Lx lx, crate::lower::types::Env env, crate::check::env::ValInfo v_, Array<crate::syntax::Arg> args, crate::syntax::Range span, crate::lower::model::OutTy t);

crate::check::env::TraitInfo dummy_trait_info();

crate::lower::types::Vl prelude_method(const crate::lower::Lx& lx, const Text& cls, const Text& m, const Array<crate::lower::types::Vl>& vals, const crate::syntax::Range& span, const crate::lower::model::OutTy& t);

prism_rtl::JobRef<crate::lower::types::Vl> start_prelude_method(crate::lower::Lx lx, Text cls, Text m, Array<crate::lower::types::Vl> vals, crate::syntax::Range span, crate::lower::model::OutTy t);

crate::lower::types::Vl binary_value(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const Text& op, const crate::syntax::Expr& l, const crate::syntax::Expr& r, const crate::syntax::Range& span);

prism_rtl::JobRef<crate::lower::types::Vl> start_binary_value(crate::lower::Lx lx, crate::lower::types::Env env, Text op, crate::syntax::Expr l, crate::syntax::Expr r, crate::syntax::Range span);

crate::lower::types::Vl op_value(const crate::lower::Lx& lx, const Text& op, const crate::lower::types::Vl& a, const crate::lower::types::Vl& b, const crate::syntax::Range& span, const crate::lower::model::OutTy& t);

Text num_method(const Text& text0);

crate::lower::types::Vl prelude_call(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const Text& qk, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span, const crate::lower::model::OutTy& t);

prism_rtl::JobRef<crate::lower::types::Vl> start_prelude_call(crate::lower::Lx lx, crate::lower::types::Env env, Text qk, Array<crate::syntax::Arg> args, crate::syntax::Range span, crate::lower::model::OutTy t);

std::optional<crate::lower::model::Ex> prelude_job(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const Text& variant, const Array<crate::syntax::Arg>& args);

prism_rtl::JobRef<std::optional<crate::lower::model::Ex>> start_prelude_job(crate::lower::Lx lx, crate::lower::types::Env env, Text variant, Array<crate::syntax::Arg> args);

std::optional<crate::lower::model::Ex> prelude_job_call(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& e);

prism_rtl::JobRef<std::optional<crate::lower::model::Ex>> start_prelude_job_call(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e);

crate::lower::model::Ex as_job_value(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& e);

prism_rtl::JobRef<crate::lower::model::Ex> start_as_job_value(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e);

crate::lower::model::Ex wrap_as_job(const crate::lower::model::Ex& f, const Array<crate::lower::model::OutTy>& pts, const crate::lower::model::OutTy& target, const crate::lower::model::OutTy& a);

Array<crate::lower::model::Ex> named_args_owned(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const Text& qk, const Array<crate::syntax::Arg>& args);

prism_rtl::JobRef<Array<crate::lower::model::Ex>> start_named_args_owned(crate::lower::Lx lx, crate::lower::types::Env env, Text qk, Array<crate::syntax::Arg> args);

Array<crate::lower::model::Ex> start_args(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::lower::types::Vl& f, const Array<crate::syntax::Arg>& args);

prism_rtl::JobRef<Array<crate::lower::model::Ex>> start_start_args(crate::lower::Lx lx, crate::lower::types::Env env, crate::lower::types::Vl f, Array<crate::syntax::Arg> args);

Text prelude_variant(const Text& name, const crate::lower::model::OutTy& first_);

crate::lower::types::Vl field_value(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& r, const Text& name);

prism_rtl::JobRef<crate::lower::types::Vl> start_field_value(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr r, Text name);

std::tuple<crate::lower::model::OutTy, bool> field_info(const crate::lower::Lx& lx, const crate::check::types::Ty& rty, const Text& name);

prism_rtl::JobRef<std::tuple<crate::lower::model::OutTy, bool>> start_field_info(crate::lower::Lx lx, crate::check::types::Ty rty, Text name);

crate::check::types::Ty instantiated(const crate::check::types::Ty& t, const Array<Text>& params, const Array<crate::check::types::Ty>& args);

prism_rtl::JobRef<crate::check::types::Ty> start_instantiated(crate::check::types::Ty t, Array<Text> params, Array<crate::check::types::Ty> args);

crate::lower::types::Vl index_value(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& r, const crate::syntax::Expr& i, const crate::lower::model::OutTy& t);

prism_rtl::JobRef<crate::lower::types::Vl> start_index_value(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr r, crate::syntax::Expr i, crate::lower::model::OutTy t);

Array<Text> read_names(const Array<crate::syntax::Expr>& es);

prism_rtl::JobRef<Array<Text>> start_read_names(Array<crate::syntax::Expr> es);

Array<crate::syntax::Expr> lambda_exprs(const crate::syntax::LambdaBody& lambda_body0);

prism_rtl::JobRef<Array<crate::syntax::Expr>> start_lambda_exprs(crate::syntax::LambdaBody lambda_body0);

crate::lower::types::Vl lambda_value(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& e, const Array<crate::syntax::Pattern_>& ps, const crate::syntax::LambdaBody& body);

prism_rtl::JobRef<crate::lower::types::Vl> start_lambda_value(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e, Array<crate::syntax::Pattern_> ps, crate::syntax::LambdaBody body);

crate::lower::types::Vl plain_lambda(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const Array<crate::syntax::Pattern_>& ps, const crate::syntax::LambdaBody& body, const crate::lower::model::OutTy& ft);

prism_rtl::JobRef<crate::lower::types::Vl> start_plain_lambda(crate::lower::Lx lx, crate::lower::types::Env env, Array<crate::syntax::Pattern_> ps, crate::syntax::LambdaBody body, crate::lower::model::OutTy ft);

Array<crate::lower::model::OutTy> lambda_param_tys(const crate::lower::Lx& lx, const crate::syntax::Expr& e, const Nat& n);

prism_rtl::JobRef<Array<crate::lower::model::OutTy>> start_lambda_param_tys(crate::lower::Lx lx, crate::syntax::Expr e, Nat n);

bool is_known_ty(const crate::lower::model::OutTy& t);

prism_rtl::JobRef<bool> start_is_known_ty(crate::lower::model::OutTy t);

crate::lower::types::Vl job_lambda(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const Array<crate::syntax::Pattern_>& ps, const crate::syntax::LambdaBody& body, const crate::lower::model::OutTy& ft, const crate::lower::model::OutTy& a, const bool& enter);

prism_rtl::JobRef<crate::lower::types::Vl> start_job_lambda(crate::lower::Lx lx, crate::lower::types::Env env, Array<crate::syntax::Pattern_> ps, crate::syntax::LambdaBody body, crate::lower::model::OutTy ft, crate::lower::model::OutTy a, bool enter);

bool enters_lambda(const crate::lower::Lx& lx, const crate::syntax::Expr& e);

crate::lower::types::Env only_captured(const crate::lower::types::Env& env, const Array<Text>& caps);

crate::lower::model::Do cond_as_let(const crate::lower::model::Cc& cc0);

crate::lower::model::Ex lambda_arg(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const Array<crate::syntax::Pattern_>& ps, const crate::syntax::LambdaBody& body, const Array<crate::lower::model::OutTy>& pts);

prism_rtl::JobRef<crate::lower::model::Ex> start_lambda_arg(crate::lower::Lx lx, crate::lower::types::Env env, Array<crate::syntax::Pattern_> ps, crate::syntax::LambdaBody body, Array<crate::lower::model::OutTy> pts);

crate::lower::types::Vl lambda_body_value(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::LambdaBody& lambda_body2);

prism_rtl::JobRef<crate::lower::types::Vl> start_lambda_body_value(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::LambdaBody lambda_body2);

std::tuple<Array<crate::lower::model::Pa>, crate::lower::types::Env> closure_params(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const Array<crate::syntax::Pattern_>& ps, const Array<crate::lower::model::OutTy>& pts, const bool& typed);

prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Pa>, crate::lower::types::Env>> start_closure_params(crate::lower::Lx lx, crate::lower::types::Env env, Array<crate::syntax::Pattern_> ps, Array<crate::lower::model::OutTy> pts, bool typed);

crate::lower::types::Env bind_all(const crate::lower::types::Env& env, const Array<std::tuple<Text, crate::lower::types::Bn>>& bs);

crate::check::types::Ty binder_ty_of_pattern(const crate::lower::Lx& lx, const crate::syntax::Pattern_& p_);

crate::lower::types::Vl if_value(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Cond& c, const crate::syntax::Block& then_b, const std::optional<crate::syntax::Block>& else_b_opt, const crate::lower::model::OutTy& t);

prism_rtl::JobRef<crate::lower::types::Vl> start_if_value(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Cond c, crate::syntax::Block then_b, std::optional<crate::syntax::Block> else_b_opt, crate::lower::model::OutTy t);

crate::lower::types::Vl arms_value(const crate::lower::model::Ex& scrut, const Array<crate::lower::model::XArm>& arms, const Text& label, const crate::lower::model::OutTy& t);

bool is_let_cond(const crate::lower::model::Cc& cc0);

crate::lower::types::Vl match_value(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Expr& s, const Array<crate::syntax::Arm>& arms, const crate::lower::model::OutTy& t, const crate::syntax::Range& span);

prism_rtl::JobRef<crate::lower::types::Vl> start_match_value(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr s, Array<crate::syntax::Arm> arms, crate::lower::model::OutTy t, crate::syntax::Range span);

crate::lower::types::Env moved_once(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Arm& arm, const Array<std::tuple<Text, crate::lower::types::Bn>>& binds);

prism_rtl::JobRef<crate::lower::types::Env> start_moved_once(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Arm arm, Array<std::tuple<Text, crate::lower::types::Bn>> binds);

std::optional<crate::syntax::Expr> only_read(const crate::lower::Lx& lx, const crate::syntax::Arm& arm, const Text& nkey);

prism_rtl::JobRef<std::optional<crate::syntax::Expr>> start_only_read(crate::lower::Lx lx, crate::syntax::Arm arm, Text nkey);

Nat word_count(const Text& text_, const Text& name);

crate::syntax::Arm dummy_arm();

crate::lower::patterns::PatOut arm_pat(const crate::lower::Lx& lx, const std::optional<crate::syntax::Pattern_>& opt1, const crate::check::types::Ty& ty, const crate::lower::types::Holding& mode, const Text& fresh);

prism_rtl::JobRef<crate::lower::patterns::PatOut> start_arm_pat(crate::lower::Lx lx, std::optional<crate::syntax::Pattern_> opt1, crate::check::types::Ty ty, crate::lower::types::Holding mode, Text fresh);

crate::lower::types::Vl block_value(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Block& b);

prism_rtl::JobRef<crate::lower::types::Vl> start_block_value(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Block b);

bool is_given_block(const Array<crate::syntax::Stmt>& stmts);

bool is_guardish(const crate::syntax::Stmt& s);

crate::lower::model::OutTy block_ty(const crate::lower::Lx& lx, const crate::syntax::Block& b);

prism_rtl::JobRef<crate::lower::model::OutTy> start_block_ty(crate::lower::Lx lx, crate::syntax::Block b);

crate::lower::types::Vl plain_block_value(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Block& b);

prism_rtl::JobRef<crate::lower::types::Vl> start_plain_block_value(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Block b);

crate::syntax::Stmt dummy_stmt_l();

std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> block_stmt(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Stmt& s);

prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> start_block_stmt(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Stmt s);

std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> generic_let(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::SName& n, const crate::check::typed::GenNote& gn, const crate::syntax::Expr& x);

prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> start_generic_let(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::SName n, crate::check::typed::GenNote gn, crate::syntax::Expr x);

Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> instantiations(const crate::lower::Lx& lx, const crate::check::typed::GenNote& gn);

prism_rtl::JobRef<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> start_instantiations(crate::lower::Lx lx, crate::check::typed::GenNote gn);

Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> expanded(const crate::lower::Lx& lx, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& i);

prism_rtl::JobRef<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> start_expanded(crate::lower::Lx lx, std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>> i);

std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>> subst_inst(const crate::lower::Lx& lx, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& arg1);

std::optional<Text> open_q(const crate::lower::Lx& lx, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& arg1);

prism_rtl::JobRef<std::optional<Text>> start_open_q(crate::lower::Lx lx, std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>> arg1);

Array<Text> open_cols(const crate::lower::Lx& lx, const crate::check::types::Col& col1);

Array<Text> open_ty_qs(const crate::lower::Lx& lx, const crate::check::types::Ty& t);

prism_rtl::JobRef<Array<Text>> start_open_ty_qs(crate::lower::Lx lx, crate::check::types::Ty t);

crate::lower::Lx at_instance(const crate::lower::Lx& lx, const std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>& arg1);

crate::lower::Lx widget_let_lx(const crate::lower::Lx& lx, const crate::syntax::Range& span);

prism_rtl::JobRef<crate::lower::Lx> start_widget_let_lx(crate::lower::Lx lx, crate::syntax::Range span);

std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>> inst_at(const crate::lower::Lx& lx, const crate::check::typed::InstNote& u);

Text gen_key(const crate::check::typed::GenNote& gn);

Text inst_key(const crate::check::typed::InstNote& u);

Text col_name(const crate::check::types::Col& col0);

std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> plain_let(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::Stmt& s, const crate::syntax::Pattern_& p_, const crate::syntax::Expr& x);

prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> start_plain_let(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Stmt s, crate::syntax::Pattern_ p_, crate::syntax::Expr x);

}  // namespace lower::expr


namespace lower::expr {

/// The step machine of `LiteralValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LiteralValue: unbounded fn Lx, Env, Literal, Range, Bool -> Vl
struct LiteralValue : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::Literal l;
    crate::syntax::Range span;
    bool neg;
    LiteralValue(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Literal l, crate::syntax::Range span, bool neg) : lx(std::move(lx)), env(std::move(env)), l(std::move(l)), span(std::move(span)), neg(std::move(neg)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `TextValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TextValue: unbounded fn Lx, Env, [TextSeg] -> Vl
struct TextValue : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    Array<crate::syntax::TextSeg> segs;
    TextValue(crate::lower::Lx lx, crate::lower::types::Env env, Array<crate::syntax::TextSeg> segs) : lx(std::move(lx)), env(std::move(env)), segs(std::move(segs)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `SegEx`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SegEx: unbounded fn Lx, Env, TextSeg -> Ex
struct SegEx : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::TextSeg text_seg2;
    SegEx(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::TextSeg text_seg2) : lx(std::move(lx)), env(std::move(env)), text_seg2(std::move(text_seg2)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `ValueOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ValueOf: unbounded fn Lx, Env, Expr -> Vl
struct ValueOf : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::Expr e;
    ValueOf(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `UnboundValueOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UnboundValueOf: unbounded fn Lx, Env, Expr -> Vl
struct UnboundValueOf : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::Expr e;
    UnboundValueOf(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `IsEventValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IsEventValue: unbounded fn Lx, Env, Expr -> Bool
struct IsEventValue : prism_rtl::Job<bool> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::Expr e;
    IsEventValue(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `HasEventSource`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// HasEventSource: unbounded fn Lx, Env, Expr -> Bool
struct HasEventSource : prism_rtl::Job<bool> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::Expr e;
    HasEventSource(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `IsEventSource`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IsEventSource: unbounded fn Lx, Env, Expr -> Bool
struct IsEventSource : prism_rtl::Job<bool> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::Expr c;
    IsEventSource(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr c) : lx(std::move(lx)), env(std::move(env)), c(std::move(c)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `EventValueOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// EventValueOf: unbounded fn Lx, Env, Expr -> Vl
struct EventValueOf : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::Expr e;
    EventValueOf(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `ValueByKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ValueByKind: unbounded fn Lx, Env, Expr -> Vl
struct ValueByKind : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::Expr e;
    ValueByKind(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `LiftedValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LiftedValue: unbounded fn Lx, Env, Expr, LiftNote -> Vl
struct LiftedValue : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::Expr e;
    crate::check::typed::LiftNote ln;
    LiftedValue(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e, crate::check::typed::LiftNote ln) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)), ln(std::move(ln)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `LiftOperands`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LiftOperands: unbounded fn Lx, Lx, Env, Expr, Text, [Range], OutTy -> Ex
struct LiftOperands : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx;
    crate::lower::Lx lx_in;
    crate::lower::types::Env env;
    crate::syntax::Expr e;
    Text sigil;
    Array<crate::syntax::Range> operands;
    crate::lower::model::OutTy t;
    LiftOperands(crate::lower::Lx lx, crate::lower::Lx lx_in, crate::lower::types::Env env, crate::syntax::Expr e, Text sigil, Array<crate::syntax::Range> operands, crate::lower::model::OutTy t) : lx(std::move(lx)), lx_in(std::move(lx_in)), env(std::move(env)), e(std::move(e)), sigil(std::move(sigil)), operands(std::move(operands)), t(std::move(t)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `PlainValueByKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PlainValueByKind: unbounded fn Lx, Env, Expr -> Vl
struct PlainValueByKind : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::Expr e;
    PlainValueByKind(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `PureBlueprint`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PureBlueprint: unbounded fn Lx, Env, Expr, OutTy -> Vl
struct PureBlueprint : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::Expr x;
    crate::lower::model::OutTy t;
    PureBlueprint(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr x, crate::lower::model::OutTy t) : lx(std::move(lx)), env(std::move(env)), x(std::move(x)), t(std::move(t)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `PlainBlueprint`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PlainBlueprint: unbounded fn Lx, Env, Expr, Text, OutTy -> Vl
struct PlainBlueprint : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::Expr x;
    Text variant;
    crate::lower::model::OutTy t;
    PlainBlueprint(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr x, Text variant, crate::lower::model::OutTy t) : lx(std::move(lx)), env(std::move(env)), x(std::move(x)), variant(std::move(variant)), t(std::move(t)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `DynamicBlueprint`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DynamicBlueprint: unbounded fn Lx, Env, Expr, Expr, Text, OutTy -> Vl
struct DynamicBlueprint : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::Expr x;
    crate::syntax::Expr d;
    Text variant;
    crate::lower::model::OutTy t;
    DynamicBlueprint(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr x, crate::syntax::Expr d, Text variant, crate::lower::model::OutTy t) : lx(std::move(lx)), env(std::move(env)), x(std::move(x)), d(std::move(d)), variant(std::move(variant)), t(std::move(t)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `ElementBlueprint`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ElementBlueprint: unbounded fn Lx, Env, [Arg], OutTy -> Vl
struct ElementBlueprint : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    Array<crate::syntax::Arg> args;
    crate::lower::model::OutTy t;
    ElementBlueprint(crate::lower::Lx lx, crate::lower::types::Env env, Array<crate::syntax::Arg> args, crate::lower::model::OutTy t) : lx(std::move(lx)), env(std::move(env)), args(std::move(args)), t(std::move(t)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `NameValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NameValue: unbounded fn Lx, Env, SName, Range -> Vl
struct NameValue : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::SName n;
    crate::syntax::Range span;
    NameValue(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::SName n, crate::syntax::Range span) : lx(std::move(lx)), env(std::move(env)), n(std::move(n)), span(std::move(span)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `GlobalValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GlobalValue: unbounded fn Lx, Text, Range, OutTy -> Vl
struct GlobalValue : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx;
    Text qk;
    crate::syntax::Range span;
    crate::lower::model::OutTy t;
    GlobalValue(crate::lower::Lx lx, Text qk, crate::syntax::Range span, crate::lower::model::OutTy t) : lx(std::move(lx)), qk(std::move(qk)), span(std::move(span)), t(std::move(t)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `Application`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Application: unbounded fn Lx, Env, Expr, [Arg], Range -> Vl
struct Application : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::Expr callee;
    Array<crate::syntax::Arg> args;
    crate::syntax::Range span;
    Application(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr callee, Array<crate::syntax::Arg> args, crate::syntax::Range span) : lx(std::move(lx)), env(std::move(env)), callee(std::move(callee)), args(std::move(args)), span(std::move(span)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `InlineLocalFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InlineLocalFn: unbounded fn Lx, Env, FnClause, [Arg], OutTy -> Vl
struct InlineLocalFn : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::decls::FnClause c;
    Array<crate::syntax::Arg> args;
    crate::lower::model::OutTy t;
    InlineLocalFn(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::decls::FnClause c, Array<crate::syntax::Arg> args, crate::lower::model::OutTy t) : lx(std::move(lx)), env(std::move(env)), c(std::move(c)), args(std::move(args)), t(std::move(t)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `Argument`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Argument: unbounded fn Lx, Env, Expr -> Ex
struct Argument : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::Expr e;
    Argument(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `ArgumentByKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ArgumentByKind: unbounded fn Lx, Env, Expr -> Ex
struct ArgumentByKind : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::Expr e;
    ArgumentByKind(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `TagValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TagValue: unbounded fn Lx, Env, TagInfo, [Arg] -> Vl
struct TagValue : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::check::env::TagInfo tg;
    Array<crate::syntax::Arg> args;
    TagValue(crate::lower::Lx lx, crate::lower::types::Env env, crate::check::env::TagInfo tg, Array<crate::syntax::Arg> args) : lx(std::move(lx)), env(std::move(env)), tg(std::move(tg)), args(std::move(args)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `GlobalCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GlobalCall: unbounded fn Lx, Env, Text, [Arg], Range, OutTy -> Vl
struct GlobalCall : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    Text qk;
    Array<crate::syntax::Arg> args;
    crate::syntax::Range span;
    crate::lower::model::OutTy t;
    GlobalCall(crate::lower::Lx lx, crate::lower::types::Env env, Text qk, Array<crate::syntax::Arg> args, crate::syntax::Range span, crate::lower::model::OutTy t) : lx(std::move(lx)), env(std::move(env)), qk(std::move(qk)), args(std::move(args)), span(std::move(span)), t(std::move(t)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `ArgsFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ArgsFor: unbounded fn Lx, Env, ValInfo, [Arg] -> [Ex]
struct ArgsFor : prism_rtl::Job<Array<crate::lower::model::Ex>> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::check::env::ValInfo v_;
    Array<crate::syntax::Arg> args;
    ArgsFor(crate::lower::Lx lx, crate::lower::types::Env env, crate::check::env::ValInfo v_, Array<crate::syntax::Arg> args) : lx(std::move(lx)), env(std::move(env)), v_(std::move(v_)), args(std::move(args)) {}
    prism_rtl::Turn<Array<crate::lower::model::Ex>> cycle() const override;
};


/// The step machine of `CtorApp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CtorApp: unbounded fn Lx, Env, CtorInfo, [Arg], Range -> Vl
struct CtorApp : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::check::env::CtorInfo c;
    Array<crate::syntax::Arg> args;
    crate::syntax::Range span;
    CtorApp(crate::lower::Lx lx, crate::lower::types::Env env, crate::check::env::CtorInfo c, Array<crate::syntax::Arg> args, crate::syntax::Range span) : lx(std::move(lx)), env(std::move(env)), c(std::move(c)), args(std::move(args)), span(std::move(span)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `CtorFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CtorFn: unbounded fn Lx, CtorInfo, [OutTy], Range, OutTy, Bool -> Vl
struct CtorFn : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx;
    crate::check::env::CtorInfo c;
    Array<crate::lower::model::OutTy> pts;
    crate::syntax::Range span;
    crate::lower::model::OutTy t;
    bool job;
    CtorFn(crate::lower::Lx lx, crate::check::env::CtorInfo c, Array<crate::lower::model::OutTy> pts, crate::syntax::Range span, crate::lower::model::OutTy t, bool job) : lx(std::move(lx)), c(std::move(c)), pts(std::move(pts)), span(std::move(span)), t(std::move(t)), job(std::move(job)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `CtorArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CtorArgs: unbounded fn Lx, Env, CtorInfo, [Arg] -> [Ex]
struct CtorArgs : prism_rtl::Job<Array<crate::lower::model::Ex>> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::check::env::CtorInfo c;
    Array<crate::syntax::Arg> args;
    CtorArgs(crate::lower::Lx lx, crate::lower::types::Env env, crate::check::env::CtorInfo c, Array<crate::syntax::Arg> args) : lx(std::move(lx)), env(std::move(env)), c(std::move(c)), args(std::move(args)) {}
    prism_rtl::Turn<Array<crate::lower::model::Ex>> cycle() const override;
};


/// The step machine of `MethodCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MethodCall: unbounded fn Lx, Env, ValInfo, [Arg], Range, OutTy -> Vl
struct MethodCall : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::check::env::ValInfo v_;
    Array<crate::syntax::Arg> args;
    crate::syntax::Range span;
    crate::lower::model::OutTy t;
    MethodCall(crate::lower::Lx lx, crate::lower::types::Env env, crate::check::env::ValInfo v_, Array<crate::syntax::Arg> args, crate::syntax::Range span, crate::lower::model::OutTy t) : lx(std::move(lx)), env(std::move(env)), v_(std::move(v_)), args(std::move(args)), span(std::move(span)), t(std::move(t)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `PreludeMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PreludeMethod: unbounded fn Lx, Text, Text, [Vl], Range, OutTy -> Vl
struct PreludeMethod : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx;
    Text cls;
    Text m;
    Array<crate::lower::types::Vl> vals;
    crate::syntax::Range span;
    crate::lower::model::OutTy t;
    PreludeMethod(crate::lower::Lx lx, Text cls, Text m, Array<crate::lower::types::Vl> vals, crate::syntax::Range span, crate::lower::model::OutTy t) : lx(std::move(lx)), cls(std::move(cls)), m(std::move(m)), vals(std::move(vals)), span(std::move(span)), t(std::move(t)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `BinaryValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BinaryValue: unbounded fn Lx, Env, Text, Expr, Expr, Range -> Vl
struct BinaryValue : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    Text op;
    crate::syntax::Expr l;
    crate::syntax::Expr r;
    crate::syntax::Range span;
    BinaryValue(crate::lower::Lx lx, crate::lower::types::Env env, Text op, crate::syntax::Expr l, crate::syntax::Expr r, crate::syntax::Range span) : lx(std::move(lx)), env(std::move(env)), op(std::move(op)), l(std::move(l)), r(std::move(r)), span(std::move(span)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `PreludeCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PreludeCall: unbounded fn Lx, Env, Text, [Arg], Range, OutTy -> Vl
struct PreludeCall : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    Text qk;
    Array<crate::syntax::Arg> args;
    crate::syntax::Range span;
    crate::lower::model::OutTy t;
    PreludeCall(crate::lower::Lx lx, crate::lower::types::Env env, Text qk, Array<crate::syntax::Arg> args, crate::syntax::Range span, crate::lower::model::OutTy t) : lx(std::move(lx)), env(std::move(env)), qk(std::move(qk)), args(std::move(args)), span(std::move(span)), t(std::move(t)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `PreludeJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?PreludeJob: unbounded fn Lx, Env, Text, [Arg] -> ?Ex
struct PreludeJob : prism_rtl::Job<std::optional<crate::lower::model::Ex>> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    Text variant;
    Array<crate::syntax::Arg> args;
    PreludeJob(crate::lower::Lx lx, crate::lower::types::Env env, Text variant, Array<crate::syntax::Arg> args) : lx(std::move(lx)), env(std::move(env)), variant(std::move(variant)), args(std::move(args)) {}
    prism_rtl::Turn<std::optional<crate::lower::model::Ex>> cycle() const override;
};


/// The step machine of `PreludeJobCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?PreludeJobCall: unbounded fn Lx, Env, Expr -> ?Ex
struct PreludeJobCall : prism_rtl::Job<std::optional<crate::lower::model::Ex>> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::Expr e;
    PreludeJobCall(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)) {}
    prism_rtl::Turn<std::optional<crate::lower::model::Ex>> cycle() const override;
};


/// The step machine of `AsJobValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AsJobValue: unbounded fn Lx, Env, Expr -> Ex
struct AsJobValue : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::Expr e;
    AsJobValue(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `NamedArgsOwned`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NamedArgsOwned: unbounded fn Lx, Env, Text, [Arg] -> [Ex]
struct NamedArgsOwned : prism_rtl::Job<Array<crate::lower::model::Ex>> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    Text qk;
    Array<crate::syntax::Arg> args;
    NamedArgsOwned(crate::lower::Lx lx, crate::lower::types::Env env, Text qk, Array<crate::syntax::Arg> args) : lx(std::move(lx)), env(std::move(env)), qk(std::move(qk)), args(std::move(args)) {}
    prism_rtl::Turn<Array<crate::lower::model::Ex>> cycle() const override;
};


/// The step machine of `StartArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StartArgs: unbounded fn Lx, Env, Vl, [Arg] -> [Ex]
struct StartArgs : prism_rtl::Job<Array<crate::lower::model::Ex>> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::lower::types::Vl f;
    Array<crate::syntax::Arg> args;
    StartArgs(crate::lower::Lx lx, crate::lower::types::Env env, crate::lower::types::Vl f, Array<crate::syntax::Arg> args) : lx(std::move(lx)), env(std::move(env)), f(std::move(f)), args(std::move(args)) {}
    prism_rtl::Turn<Array<crate::lower::model::Ex>> cycle() const override;
};


/// The step machine of `FieldValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FieldValue: unbounded fn Lx, Env, Expr, Text -> Vl
struct FieldValue : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::Expr r;
    Text name;
    FieldValue(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr r, Text name) : lx(std::move(lx)), env(std::move(env)), r(std::move(r)), name(std::move(name)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `FieldInfo`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FieldInfo: unbounded fn Lx, Ty, Text -> ((OutTy, Bool))
struct FieldInfo : prism_rtl::Job<std::tuple<crate::lower::model::OutTy, bool>> {
    crate::lower::Lx lx;
    crate::check::types::Ty rty;
    Text name;
    FieldInfo(crate::lower::Lx lx, crate::check::types::Ty rty, Text name) : lx(std::move(lx)), rty(std::move(rty)), name(std::move(name)) {}
    prism_rtl::Turn<std::tuple<crate::lower::model::OutTy, bool>> cycle() const override;
};


/// The step machine of `Instantiated`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Instantiated: unbounded fn Ty, [Text], [Ty] -> Ty
struct Instantiated : prism_rtl::Job<crate::check::types::Ty> {
    crate::check::types::Ty t;
    Array<Text> params;
    Array<crate::check::types::Ty> args;
    Instantiated(crate::check::types::Ty t, Array<Text> params, Array<crate::check::types::Ty> args) : t(std::move(t)), params(std::move(params)), args(std::move(args)) {}
    prism_rtl::Turn<crate::check::types::Ty> cycle() const override;
};


/// The step machine of `IndexValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IndexValue: unbounded fn Lx, Env, Expr, Expr, OutTy -> Vl
struct IndexValue : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::Expr r;
    crate::syntax::Expr i;
    crate::lower::model::OutTy t;
    IndexValue(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr r, crate::syntax::Expr i, crate::lower::model::OutTy t) : lx(std::move(lx)), env(std::move(env)), r(std::move(r)), i(std::move(i)), t(std::move(t)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `ReadNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ReadNames: unbounded fn [Expr] -> [Text]
struct ReadNames : prism_rtl::Job<Array<Text>> {
    Array<crate::syntax::Expr> es;
    ReadNames(Array<crate::syntax::Expr> es) : es(std::move(es)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `LambdaExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LambdaExprs: unbounded fn LambdaBody -> [Expr]
struct LambdaExprs : prism_rtl::Job<Array<crate::syntax::Expr>> {
    crate::syntax::LambdaBody lambda_body0;
    LambdaExprs(crate::syntax::LambdaBody lambda_body0) : lambda_body0(std::move(lambda_body0)) {}
    prism_rtl::Turn<Array<crate::syntax::Expr>> cycle() const override;
};


/// The step machine of `LambdaValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LambdaValue: unbounded fn Lx, Env, Expr, [Pattern], LambdaBody -> Vl
struct LambdaValue : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::Expr e;
    Array<crate::syntax::Pattern_> ps;
    crate::syntax::LambdaBody body;
    LambdaValue(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr e, Array<crate::syntax::Pattern_> ps, crate::syntax::LambdaBody body) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)), ps(std::move(ps)), body(std::move(body)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `PlainLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PlainLambda: unbounded fn Lx, Env, [Pattern], LambdaBody, OutTy -> Vl
struct PlainLambda : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    Array<crate::syntax::Pattern_> ps;
    crate::syntax::LambdaBody body;
    crate::lower::model::OutTy ft;
    PlainLambda(crate::lower::Lx lx, crate::lower::types::Env env, Array<crate::syntax::Pattern_> ps, crate::syntax::LambdaBody body, crate::lower::model::OutTy ft) : lx(std::move(lx)), env(std::move(env)), ps(std::move(ps)), body(std::move(body)), ft(std::move(ft)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `LambdaParamTys`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LambdaParamTys: unbounded fn Lx, Expr, Nat -> [OutTy]
struct LambdaParamTys : prism_rtl::Job<Array<crate::lower::model::OutTy>> {
    crate::lower::Lx lx;
    crate::syntax::Expr e;
    Nat n;
    LambdaParamTys(crate::lower::Lx lx, crate::syntax::Expr e, Nat n) : lx(std::move(lx)), e(std::move(e)), n(std::move(n)) {}
    prism_rtl::Turn<Array<crate::lower::model::OutTy>> cycle() const override;
};


/// The step machine of `IsKnownTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IsKnownTy: unbounded fn OutTy -> Bool
struct IsKnownTy : prism_rtl::Job<bool> {
    crate::lower::model::OutTy t;
    IsKnownTy(crate::lower::model::OutTy t) : t(std::move(t)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `JobLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// JobLambda: unbounded fn Lx, Env, [Pattern], LambdaBody, OutTy, OutTy, Bool -> Vl
struct JobLambda : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    Array<crate::syntax::Pattern_> ps;
    crate::syntax::LambdaBody body;
    crate::lower::model::OutTy ft;
    crate::lower::model::OutTy a;
    bool enter;
    JobLambda(crate::lower::Lx lx, crate::lower::types::Env env, Array<crate::syntax::Pattern_> ps, crate::syntax::LambdaBody body, crate::lower::model::OutTy ft, crate::lower::model::OutTy a, bool enter) : lx(std::move(lx)), env(std::move(env)), ps(std::move(ps)), body(std::move(body)), ft(std::move(ft)), a(std::move(a)), enter(std::move(enter)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `LambdaArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LambdaArg: unbounded fn Lx, Env, [Pattern], LambdaBody, [OutTy] -> Ex
struct LambdaArg : prism_rtl::Job<crate::lower::model::Ex> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    Array<crate::syntax::Pattern_> ps;
    crate::syntax::LambdaBody body;
    Array<crate::lower::model::OutTy> pts;
    LambdaArg(crate::lower::Lx lx, crate::lower::types::Env env, Array<crate::syntax::Pattern_> ps, crate::syntax::LambdaBody body, Array<crate::lower::model::OutTy> pts) : lx(std::move(lx)), env(std::move(env)), ps(std::move(ps)), body(std::move(body)), pts(std::move(pts)) {}
    prism_rtl::Turn<crate::lower::model::Ex> cycle() const override;
};


/// The step machine of `LambdaBodyValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LambdaBodyValue: unbounded fn Lx, Env, LambdaBody -> Vl
struct LambdaBodyValue : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::LambdaBody lambda_body2;
    LambdaBodyValue(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::LambdaBody lambda_body2) : lx(std::move(lx)), env(std::move(env)), lambda_body2(std::move(lambda_body2)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `ClosureParams`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClosureParams: unbounded fn Lx, Env, [Pattern], [OutTy], Bool -> (([Pa], Env))
struct ClosureParams : prism_rtl::Job<std::tuple<Array<crate::lower::model::Pa>, crate::lower::types::Env>> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    Array<crate::syntax::Pattern_> ps;
    Array<crate::lower::model::OutTy> pts;
    bool typed;
    ClosureParams(crate::lower::Lx lx, crate::lower::types::Env env, Array<crate::syntax::Pattern_> ps, Array<crate::lower::model::OutTy> pts, bool typed) : lx(std::move(lx)), env(std::move(env)), ps(std::move(ps)), pts(std::move(pts)), typed(std::move(typed)) {}
    prism_rtl::Turn<std::tuple<Array<crate::lower::model::Pa>, crate::lower::types::Env>> cycle() const override;
};


/// The step machine of `IfValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IfValue: unbounded fn Lx, Env, Cond, Block, ?Block, OutTy -> Vl
struct IfValue : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::Cond c;
    crate::syntax::Block then_b;
    std::optional<crate::syntax::Block> else_b_opt;
    crate::lower::model::OutTy t;
    IfValue(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Cond c, crate::syntax::Block then_b, std::optional<crate::syntax::Block> else_b_opt, crate::lower::model::OutTy t) : lx(std::move(lx)), env(std::move(env)), c(std::move(c)), then_b(std::move(then_b)), else_b_opt(std::move(else_b_opt)), t(std::move(t)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `MatchValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MatchValue: unbounded fn Lx, Env, Expr, [Arm], OutTy, Range -> Vl
struct MatchValue : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::Expr s;
    Array<crate::syntax::Arm> arms;
    crate::lower::model::OutTy t;
    crate::syntax::Range span;
    MatchValue(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Expr s, Array<crate::syntax::Arm> arms, crate::lower::model::OutTy t, crate::syntax::Range span) : lx(std::move(lx)), env(std::move(env)), s(std::move(s)), arms(std::move(arms)), t(std::move(t)), span(std::move(span)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `MovedOnce`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MovedOnce: unbounded fn Lx, Env, Arm, [((Text, Bn))] -> Env
struct MovedOnce : prism_rtl::Job<crate::lower::types::Env> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::Arm arm;
    Array<std::tuple<Text, crate::lower::types::Bn>> binds;
    MovedOnce(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Arm arm, Array<std::tuple<Text, crate::lower::types::Bn>> binds) : lx(std::move(lx)), env(std::move(env)), arm(std::move(arm)), binds(std::move(binds)) {}
    prism_rtl::Turn<crate::lower::types::Env> cycle() const override;
};


/// The step machine of `OnlyRead`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?OnlyRead: unbounded fn Lx, Arm, Text -> ?Expr
struct OnlyRead : prism_rtl::Job<std::optional<crate::syntax::Expr>> {
    crate::lower::Lx lx;
    crate::syntax::Arm arm;
    Text nkey;
    OnlyRead(crate::lower::Lx lx, crate::syntax::Arm arm, Text nkey) : lx(std::move(lx)), arm(std::move(arm)), nkey(std::move(nkey)) {}
    prism_rtl::Turn<std::optional<crate::syntax::Expr>> cycle() const override;
};


/// The step machine of `ArmPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ArmPat: unbounded fn Lx, ?Pattern, Ty, Holding, Text -> PatOut
struct ArmPat : prism_rtl::Job<crate::lower::patterns::PatOut> {
    crate::lower::Lx lx;
    std::optional<crate::syntax::Pattern_> opt1;
    crate::check::types::Ty ty;
    crate::lower::types::Holding mode;
    Text fresh;
    ArmPat(crate::lower::Lx lx, std::optional<crate::syntax::Pattern_> opt1, crate::check::types::Ty ty, crate::lower::types::Holding mode, Text fresh) : lx(std::move(lx)), opt1(std::move(opt1)), ty(std::move(ty)), mode(std::move(mode)), fresh(std::move(fresh)) {}
    prism_rtl::Turn<crate::lower::patterns::PatOut> cycle() const override;
};


/// The step machine of `BlockValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BlockValue: unbounded fn Lx, Env, Block -> Vl
struct BlockValue : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::Block b;
    BlockValue(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Block b) : lx(std::move(lx)), env(std::move(env)), b(std::move(b)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `BlockTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BlockTy: unbounded fn Lx, Block -> OutTy
struct BlockTy : prism_rtl::Job<crate::lower::model::OutTy> {
    crate::lower::Lx lx;
    crate::syntax::Block b;
    BlockTy(crate::lower::Lx lx, crate::syntax::Block b) : lx(std::move(lx)), b(std::move(b)) {}
    prism_rtl::Turn<crate::lower::model::OutTy> cycle() const override;
};


/// The step machine of `PlainBlockValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PlainBlockValue: unbounded fn Lx, Env, Block -> Vl
struct PlainBlockValue : prism_rtl::Job<crate::lower::types::Vl> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::Block b;
    PlainBlockValue(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Block b) : lx(std::move(lx)), env(std::move(env)), b(std::move(b)) {}
    prism_rtl::Turn<crate::lower::types::Vl> cycle() const override;
};


/// The step machine of `BlockStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BlockStmt: unbounded fn Lx, Env, Stmt -> (([Do], Env))
struct BlockStmt : prism_rtl::Job<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::Stmt s;
    BlockStmt(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Stmt s) : lx(std::move(lx)), env(std::move(env)), s(std::move(s)) {}
    prism_rtl::Turn<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> cycle() const override;
};


/// The step machine of `GenericLet`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GenericLet: unbounded fn Lx, Env, SName, GenNote, Expr -> (([Do], Env))
struct GenericLet : prism_rtl::Job<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::SName n;
    crate::check::typed::GenNote gn;
    crate::syntax::Expr x;
    GenericLet(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::SName n, crate::check::typed::GenNote gn, crate::syntax::Expr x) : lx(std::move(lx)), env(std::move(env)), n(std::move(n)), gn(std::move(gn)), x(std::move(x)) {}
    prism_rtl::Turn<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> cycle() const override;
};


/// The step machine of `Instantiations`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Instantiations: unbounded fn Lx, GenNote -> [(([((Text, Ty))], [((Text, Col))]))]
struct Instantiations : prism_rtl::Job<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> {
    crate::lower::Lx lx;
    crate::check::typed::GenNote gn;
    Instantiations(crate::lower::Lx lx, crate::check::typed::GenNote gn) : lx(std::move(lx)), gn(std::move(gn)) {}
    prism_rtl::Turn<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> cycle() const override;
};


/// The step machine of `Expanded`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Expanded: unbounded fn Lx, (([((Text, Ty))], [((Text, Col))])) -> [(([((Text, Ty))], [((Text, Col))]))]
struct Expanded : prism_rtl::Job<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> {
    crate::lower::Lx lx;
    std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>> i;
    Expanded(crate::lower::Lx lx, std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>> i) : lx(std::move(lx)), i(std::move(i)) {}
    prism_rtl::Turn<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> cycle() const override;
};


/// The step machine of `OpenQ`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?OpenQ: unbounded fn Lx, (([((Text, Ty))], [((Text, Col))])) -> ?Text
struct OpenQ : prism_rtl::Job<std::optional<Text>> {
    crate::lower::Lx lx;
    std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>> arg1;
    OpenQ(crate::lower::Lx lx, std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>> arg1) : lx(std::move(lx)), arg1(std::move(arg1)) {}
    prism_rtl::Turn<std::optional<Text>> cycle() const override;
};


/// The step machine of `OpenTyQs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OpenTyQs: unbounded fn Lx, Ty -> [Text]
struct OpenTyQs : prism_rtl::Job<Array<Text>> {
    crate::lower::Lx lx;
    crate::check::types::Ty t;
    OpenTyQs(crate::lower::Lx lx, crate::check::types::Ty t) : lx(std::move(lx)), t(std::move(t)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `WidgetLetLx`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WidgetLetLx: unbounded fn Lx, Range -> Lx
struct WidgetLetLx : prism_rtl::Job<crate::lower::Lx> {
    crate::lower::Lx lx;
    crate::syntax::Range span;
    WidgetLetLx(crate::lower::Lx lx, crate::syntax::Range span) : lx(std::move(lx)), span(std::move(span)) {}
    prism_rtl::Turn<crate::lower::Lx> cycle() const override;
};


/// The step machine of `PlainLet`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PlainLet: unbounded fn Lx, Env, Stmt, Pattern, Expr -> (([Do], Env))
struct PlainLet : prism_rtl::Job<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> {
    crate::lower::Lx lx;
    crate::lower::types::Env env;
    crate::syntax::Stmt s;
    crate::syntax::Pattern_ p_;
    crate::syntax::Expr x;
    PlainLet(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::Stmt s, crate::syntax::Pattern_ p_, crate::syntax::Expr x) : lx(std::move(lx)), env(std::move(env)), s(std::move(s)), p_(std::move(p_)), x(std::move(x)) {}
    prism_rtl::Turn<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> cycle() const override;
};


}  // namespace lower::expr

}  // namespace crate
