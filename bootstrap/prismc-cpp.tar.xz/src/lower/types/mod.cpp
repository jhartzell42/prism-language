// The module `Lower.Types`, from `target/bootstrap/cpp-src/prismc/lower/types.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <lower/types/module.hpp>
#include <lower/node_/module.hpp>
#include <syntax/module.hpp>
#include <lower/module.hpp>
#include <syntax/decls/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate::lower::types {





void Holding::show(Printer& p) const {
    if (auto c = std::get_if<ByRef>(&cases())) p.choice("ByRef", {});
    else if (auto c = std::get_if<Owned>(&cases())) p.choice("Owned", {});
    else if (auto c = std::get_if<RcRef>(&cases())) p.choice("RcRef", {});
    else if (auto c = std::get_if<RcOwned>(&cases())) p.choice("RcOwned", {});
}

Pod Holding::to_pod() const {
    return std::holds_alternative<ByRef>(cases()) ? Pod::choice("ByRef", {})
        : std::holds_alternative<Owned>(cases()) ? Pod::choice("Owned", {})
        : std::holds_alternative<RcRef>(cases()) ? Pod::choice("RcRef", {})
        : std::holds_alternative<RcOwned>(cases()) ? Pod::choice("RcOwned", {})
        : Pod();
}

Result<Holding> Holding::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "ByRef" && c->args.size() == 0) return Holding(ByRef{});
        if (c->ctor == "Owned" && c->args.size() == 0) return Holding(Owned{});
        if (c->ctor == "RcRef" && c->args.size() == 0) return Holding(RcRef{});
        if (c->ctor == "RcOwned" && c->args.size() == 0) return Holding(RcOwned{});
    }
    return mismatch<Holding>("a Holding", p);
}


void Layer::show(Printer& p) const {
    if (auto c = std::get_if<LyPlain>(&cases())) p.choice("LyPlain", {});
    else if (auto c = std::get_if<LyDyn>(&cases())) p.choice("LyDyn", {});
    else if (auto c = std::get_if<LyEv>(&cases())) p.choice("LyEv", {});
    else if (auto c = std::get_if<LyBlueprint>(&cases())) p.choice("LyBlueprint", {});
}

Pod Layer::to_pod() const {
    return std::holds_alternative<LyPlain>(cases()) ? Pod::choice("LyPlain", {})
        : std::holds_alternative<LyDyn>(cases()) ? Pod::choice("LyDyn", {})
        : std::holds_alternative<LyEv>(cases()) ? Pod::choice("LyEv", {})
        : std::holds_alternative<LyBlueprint>(cases()) ? Pod::choice("LyBlueprint", {})
        : Pod();
}

Result<Layer> Layer::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "LyPlain" && c->args.size() == 0) return Layer(LyPlain{});
        if (c->ctor == "LyDyn" && c->args.size() == 0) return Layer(LyDyn{});
        if (c->ctor == "LyEv" && c->args.size() == 0) return Layer(LyEv{});
        if (c->ctor == "LyBlueprint" && c->args.size() == 0) return Layer(LyBlueprint{});
    }
    return mismatch<Layer>("a Layer", p);
}


Pod Vl::to_pod() const {
    return std::holds_alternative<VlPlace>(cases()) ? Pod::choice("VlPlace", {prism_rtl::to_pod(std::get<VlPlace>(cases()).a0), prism_rtl::to_pod(std::get<VlPlace>(cases()).a1), prism_rtl::to_pod(std::get<VlPlace>(cases()).a2)})
        : std::holds_alternative<VlOwned>(cases()) ? Pod::choice("VlOwned", {prism_rtl::to_pod(std::get<VlOwned>(cases()).a0), prism_rtl::to_pod(std::get<VlOwned>(cases()).a1)})
        : Pod();
}

Result<Vl> Vl::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "VlPlace" && c->args.size() == 3) return Vl(VlPlace{TRY(prism_rtl::from_pod<crate::lower::model::Ex>(c->args[0])), TRY(prism_rtl::from_pod<Holding>(c->args[1])), TRY(prism_rtl::from_pod<crate::lower::model::OutTy>(c->args[2]))});
        if (c->ctor == "VlOwned" && c->args.size() == 2) return Vl(VlOwned{TRY(prism_rtl::from_pod<crate::lower::model::Ex>(c->args[0])), TRY(prism_rtl::from_pod<crate::lower::model::OutTy>(c->args[1]))});
    }
    return mismatch<Vl>("a Vl", p);
}


/// OutTyOf: unbounded fn Lx, Ty -> OutTy
crate::lower::model::OutTy out_ty_of(const crate::lower::Lx& lx, const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m1375_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m1375_0_0 == Text::lit("Nat")) {
            if (m1375_0_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m1375_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m1375_1_0 == Text::lit("Int")) {
            if (m1375_1_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutInt{});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m1375_2_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_2_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m1375_2_0 == Text::lit("U8")) {
            if (m1375_2_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutU8{});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m1375_3_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_3_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m1375_3_0 == Text::lit("Float")) {
            if (m1375_3_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutFloat{});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m1375_4_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_4_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m1375_4_0 == Text::lit("Bool")) {
            if (m1375_4_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m1375_5_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_5_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m1375_5_0 == Text::lit("Char")) {
            if (m1375_5_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutChar{});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m1375_6_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_6_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m1375_6_0 == Text::lit("Text")) {
            if (m1375_6_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m1375_7_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_7_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m1375_7_0 == Text::lit("unit")) {
            if (m1375_7_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m1375_8_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_8_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m1375_8_0 == Text::lit("Path")) {
            if (m1375_8_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutPath{});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m1375_9_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_9_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m1375_9_0 == Text::lit("Cursor")) {
            if (m1375_9_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutCursor{});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m1375_10_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_10_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m1375_10_0 == Text::lit("Regex")) {
            if (m1375_10_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutRegex{});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m1375_11_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_11_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m1375_11_0 == Text::lit("RegexReplacement")) {
            if (m1375_11_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutReplacement{});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m1375_12_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_12_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m1375_12_0 == Text::lit("Duration")) {
            if (m1375_12_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutDuration{});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m1375_13_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_13_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m1375_13_0 == Text::lit("Prelude.Error")) {
            if (m1375_13_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutError{});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m1375_14_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_14_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m1375_14_0 == Text::lit("\000Self"sv)) {
            if (m1375_14_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Self"), Array<crate::lower::model::OutTy>{}});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m1375_15_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_15_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m1375_15_0 == Text::lit("Buffer")) {
            if (m1375_15_1.size() == 1u) {
                {
                    auto&& _c1 = index(m1375_15_1, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& a = prism_rtl::some_of(_c1);
                        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutArray{prism_rtl::rc(out_ty_of(lx, a))});
                    }
                }
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m1375_16_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_16_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m1375_16_0 == Text::lit("Table")) {
            if (m1375_16_1.size() == 2u) {
                {
                    auto&& _c2 = index(m1375_16_1, Nat(0u));
                    if (prism_rtl::is_some(_c2)) {
                        auto&& k = prism_rtl::some_of(_c2);
                        {
                            auto&& _c1 = index(m1375_16_1, Nat(1u));
                            if (prism_rtl::is_some(_c1)) {
                                auto&& v_ = prism_rtl::some_of(_c1);
                                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutArray{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{Array(std::vector{out_ty_of(lx, k), out_ty_of(lx, v_)})}))});
                            }
                        }
                    }
                }
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m1375_17_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_17_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m1375_17_0 == Text::lit("\000Event"sv)) {
            if (m1375_17_1.size() == 1u) {
                {
                    auto&& _c1 = index(m1375_17_1, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& a = prism_rtl::some_of(_c1);
                        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutEvent{prism_rtl::rc(out_ty_of(lx, a))});
                    }
                }
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        return named_ty(lx, n, run_to_end(each_job(args, ({
            auto lx_1 = lx;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
            return ({
                auto lx_1_2 = lx_1;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_1_2, a))));
                });
            }));
            });
        })));
        }))));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t)) {
        auto&& c = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        auto c2 = crate::lower::inst_col(lx, c);
        return c2 == crate::check::types::Col(crate::check::types::Col::CBound{})
            ? crate::lower::model::OutTy(crate::lower::model::OutTy::OutFn{run_to_end(each_job(ps, ({
            auto lx_1 = lx;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
            return ({
                auto lx_1_2 = lx_1;
                entered(once_job([=]() {
                return ({
                    auto p_ = p0;
                    (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_1_2, p_))));
                });
            }));
            });
        })));
        }))), prism_rtl::rc(out_ty_of(lx, res))})
            : crate::lower::is_quant_col(lx, c2)
            ? crate::lower::model::OutTy(crate::lower::model::OutTy::OutQuantified{or_(crate::prelude::get(lx.quants, crate::lower::expr::col_name(c2)), Text::lit(""))})
            : crate::lower::model::OutTy(crate::lower::model::OutTy::OutJobFn{prism_rtl::rc(rust_ty_of_params(lx, each(ps, [&](const crate::check::types::Ty& p_) { return job_param(p_); }))), prism_rtl::rc(out_ty_of(lx, res))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t)) {
        auto&& m1375_20_0 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        if (m1375_20_0.size() == 0u) {
            return crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{});
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{run_to_end(each_job(ts, ({
            auto lx_1 = lx;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
            return ({
                auto lx_1_2 = lx_1;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_1_2, a))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutArray{prism_rtl::rc(out_ty_of(lx, e))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(out_ty_of(lx, k)), prism_rtl::rc(out_ty_of(lx, v_))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& m1375_24_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        if (m1375_24_0 == Text::lit("?")) {
            return crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(out_ty_of(lx, i))});
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& m1375_25_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        if (m1375_25_0 == Text::lit("~")) {
            return crate::lower::model::OutTy(crate::lower::model::OutTy::OutRes{prism_rtl::rc(out_ty_of(lx, i))});
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& m1375_26_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        if (m1375_26_0 == Text::lit("!")) {
            return crate::lower::model::OutTy(crate::lower::model::OutTy::OutEvent{prism_rtl::rc(out_ty_of(lx, i))});
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& m1375_27_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        if (m1375_27_0 == Text::lit("$")) {
            return crate::lower::model::OutTy(crate::lower::model::OutTy::OutDyn{prism_rtl::rc(out_ty_of(lx, i))});
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& m1375_28_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        if (m1375_28_0 == Text::lit("&")) {
            return out_ty_of(lx, i);
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        return out_ty_of(lx, i);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyQ>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyQ>(t).a0;
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutGen{crate::lower::camel(n)});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyRigid>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyRigid>(t).a0;
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutGen{crate::lower::camel(n)});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyFlex>(t).a0;
        auto&& _m = crate::prelude::get(lx.subst, prism_rtl::cat("\'", n));
        if (prism_rtl::is_some(_m)) {
            auto&& x = prism_rtl::some_of(_m);
            return out_ty_of(lx, x);
        }
        if (prism_rtl::is_none(_m)) {
            auto&& _m = crate::prelude::get(lx.quants, prism_rtl::cat("\'", n));
            if (prism_rtl::is_some(_m)) {
                auto&& b = prism_rtl::some_of(_m);
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutQuantified{b});
            }
            if (prism_rtl::is_none(_m)) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{});
            }
            prism_rtl::unreachable("no arm matched");
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAny>(t)) {
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutShowAny{});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t)) {
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutLive{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("crate::Elem"), Array<crate::lower::model::OutTy>{}}))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(t)) {
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("crate::Elem"), Array<crate::lower::model::OutTy>{}});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a0;
        return blueprint_ty();
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t)) {
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{Text::lit("an associated type")});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyErr>(t)) {
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{Text::lit("a type the checker did not find")});
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::model::OutTy> OutTyOf::cycle() const {
    const auto& lx = this->lx;
    const auto& t = this->t;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m1375_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m1375_0_0 == Text::lit("Nat")) && (m1375_0_1.size() == 0u);
    }) ? ({
        auto&& m1375_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m1375_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m1375_1_0 == Text::lit("Int")) && (m1375_1_1.size() == 0u);
    }) ? ({
        auto&& m1375_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutInt{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m1375_2_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_2_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m1375_2_0 == Text::lit("U8")) && (m1375_2_1.size() == 0u);
    }) ? ({
        auto&& m1375_2_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_2_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutU8{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m1375_3_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_3_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m1375_3_0 == Text::lit("Float")) && (m1375_3_1.size() == 0u);
    }) ? ({
        auto&& m1375_3_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_3_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutFloat{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m1375_4_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_4_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m1375_4_0 == Text::lit("Bool")) && (m1375_4_1.size() == 0u);
    }) ? ({
        auto&& m1375_4_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_4_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m1375_5_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_5_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m1375_5_0 == Text::lit("Char")) && (m1375_5_1.size() == 0u);
    }) ? ({
        auto&& m1375_5_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_5_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutChar{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m1375_6_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_6_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m1375_6_0 == Text::lit("Text")) && (m1375_6_1.size() == 0u);
    }) ? ({
        auto&& m1375_6_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_6_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m1375_7_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_7_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m1375_7_0 == Text::lit("unit")) && (m1375_7_1.size() == 0u);
    }) ? ({
        auto&& m1375_7_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_7_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m1375_8_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_8_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m1375_8_0 == Text::lit("Path")) && (m1375_8_1.size() == 0u);
    }) ? ({
        auto&& m1375_8_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_8_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutPath{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m1375_9_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_9_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m1375_9_0 == Text::lit("Cursor")) && (m1375_9_1.size() == 0u);
    }) ? ({
        auto&& m1375_9_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_9_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutCursor{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m1375_10_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_10_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m1375_10_0 == Text::lit("Regex")) && (m1375_10_1.size() == 0u);
    }) ? ({
        auto&& m1375_10_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_10_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutRegex{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m1375_11_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_11_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m1375_11_0 == Text::lit("RegexReplacement")) && (m1375_11_1.size() == 0u);
    }) ? ({
        auto&& m1375_11_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_11_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutReplacement{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m1375_12_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_12_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m1375_12_0 == Text::lit("Duration")) && (m1375_12_1.size() == 0u);
    }) ? ({
        auto&& m1375_12_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_12_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutDuration{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m1375_13_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_13_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m1375_13_0 == Text::lit("Prelude.Error")) && (m1375_13_1.size() == 0u);
    }) ? ({
        auto&& m1375_13_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_13_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutError{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m1375_14_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_14_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m1375_14_0 == Text::lit("\000Self"sv)) && (m1375_14_1.size() == 0u);
    }) ? ({
        auto&& m1375_14_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_14_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Self"), Array<crate::lower::model::OutTy>{}}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m1375_15_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_15_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m1375_15_0 == Text::lit("Buffer")) && (m1375_15_1.size() == 1u) && ({
        auto&& _c1 = index(m1375_15_1, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m1375_15_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_15_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        auto&& _c1 = index(m1375_15_1, Nat(0u));
        auto&& a = prism_rtl::some_of(_c1);
        ({
        auto lx_1 = lx;
        call_then(start_out_ty_of(lx_1, a), [=](crate::lower::model::OutTy out_ty_of_1957) { return prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutArray{prism_rtl::rc(out_ty_of_1957)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m1375_16_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_16_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m1375_16_0 == Text::lit("Table")) && (m1375_16_1.size() == 2u) && ({
        auto&& _c2 = index(m1375_16_1, Nat(0u));
        prism_rtl::is_some(_c2) && ({
        auto&& k = prism_rtl::some_of(_c2);
        ({
        auto&& _c1 = index(m1375_16_1, Nat(1u));
        prism_rtl::is_some(_c1);
    });
    });
    });
    }) ? ({
        auto&& m1375_16_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_16_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        auto&& _c2 = index(m1375_16_1, Nat(0u));
        auto&& k = prism_rtl::some_of(_c2);
        auto&& _c1 = index(m1375_16_1, Nat(1u));
        auto&& v_ = prism_rtl::some_of(_c1);
        ({
        auto lx_1 = lx;
        call_then(start_out_ty_of(lx_1, k), [=](crate::lower::model::OutTy out_ty_of_2023) { return call_then(start_out_ty_of(lx_1, v_), [=](crate::lower::model::OutTy out_ty_of_2040) { return prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutArray{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{Array(std::vector{out_ty_of_2023, out_ty_of_2040})}))})); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m1375_17_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_17_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m1375_17_0 == Text::lit("\000Event"sv)) && (m1375_17_1.size() == 1u) && ({
        auto&& _c1 = index(m1375_17_1, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m1375_17_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m1375_17_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        auto&& _c1 = index(m1375_17_1, Nat(0u));
        auto&& a = prism_rtl::some_of(_c1);
        ({
        auto lx_1 = lx;
        call_then(start_out_ty_of(lx_1, a), [=](crate::lower::model::OutTy out_ty_of_2099) { return prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutEvent{prism_rtl::rc(out_ty_of_2099)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        ({
        auto args_1 = args;
        auto lx_2 = lx;
        auto n_3 = n;
        call_value(each_job(args_1, ({
        auto lx_2_4 = lx_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return ({
            auto lx_2_4_4 = lx_2_4;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_2_4_4, a))));
            });
        }));
        });
    })));
    })), [=](Array<crate::lower::model::OutTy> each_2149) { return prism_rtl::more(prism_rtl::rc(NamedTy(lx_2, n_3, each_2149))); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(t) ? ({
        auto&& c = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        ({
        auto c2 = crate::lower::inst_col(lx, c);
        c2 == crate::check::types::Col(crate::check::types::Col::CBound{})
        ? ({
        auto lx_1 = lx;
        auto ps_2 = ps;
        auto res_3 = res;
        call_value(each_job(ps_2, ({
        auto lx_1_4 = lx_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return ({
            auto lx_1_4_4 = lx_1_4;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_1_4_4, p_))));
            });
        }));
        });
    })));
    })), [=](Array<crate::lower::model::OutTy> each_2430) { return call_then(start_out_ty_of(lx_1, res_3), [=](crate::lower::model::OutTy out_ty_of_2461) { return prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutFn{each_2430, prism_rtl::rc(out_ty_of_2461)})); }); });
    })
        : crate::lower::is_quant_col(lx, c2)
        ? prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutQuantified{or_(crate::prelude::get(lx.quants, crate::lower::expr::col_name(c2)), Text::lit(""))}))
        : ({
        auto lx_1 = lx;
        auto ps_2 = ps;
        auto res_3 = res;
        call_then(start_rust_ty_of_params(lx_1, each(ps_2, [&](const crate::check::types::Ty& p_) { return job_param(p_); })), [=](crate::lower::model::OutTy rust_ty_of_params_2583) { return call_then(start_out_ty_of(lx_1, res_3), [=](crate::lower::model::OutTy out_ty_of_2632) { return prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutJobFn{prism_rtl::rc(rust_ty_of_params_2583), prism_rtl::rc(out_ty_of_2632)})); }); });
    });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t) && ({
        auto&& m1375_20_0 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        (m1375_20_0.size() == 0u);
    }) ? ({
        auto&& m1375_20_0 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        ({
        auto lx_1 = lx;
        auto ts_2 = ts;
        call_value(each_job(ts_2, ({
        auto lx_1_3 = lx_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return ({
            auto lx_1_3_3 = lx_1_3;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_1_3_3, a))));
            });
        }));
        });
    })));
    })), [=](Array<crate::lower::model::OutTy> each_2701) { return prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{each_2701})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        ({
        auto e_1 = e;
        auto lx_2 = lx;
        call_then(start_out_ty_of(lx_2, e_1), [=](crate::lower::model::OutTy out_ty_of_2755) { return prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutArray{prism_rtl::rc(out_ty_of_2755)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        ({
        auto k_1 = k;
        auto lx_2 = lx;
        auto v__3 = v_;
        call_then(start_out_ty_of(lx_2, k_1), [=](crate::lower::model::OutTy out_ty_of_2794) { return call_then(start_out_ty_of(lx_2, v__3), [=](crate::lower::model::OutTy out_ty_of_2811) { return prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(out_ty_of_2794), prism_rtl::rc(out_ty_of_2811)})); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t) && ({
        auto&& m1375_24_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        (m1375_24_0 == Text::lit("?"));
    }) ? ({
        auto&& m1375_24_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        ({
        auto i_1 = i;
        auto lx_2 = lx;
        call_then(start_out_ty_of(lx_2, i_1), [=](crate::lower::model::OutTy out_ty_of_2852) { return prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(out_ty_of_2852)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t) && ({
        auto&& m1375_25_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        (m1375_25_0 == Text::lit("~"));
    }) ? ({
        auto&& m1375_25_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        ({
        auto i_1 = i;
        auto lx_2 = lx;
        call_then(start_out_ty_of(lx_2, i_1), [=](crate::lower::model::OutTy out_ty_of_2893) { return prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutRes{prism_rtl::rc(out_ty_of_2893)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t) && ({
        auto&& m1375_26_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        (m1375_26_0 == Text::lit("!"));
    }) ? ({
        auto&& m1375_26_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        ({
        auto i_1 = i;
        auto lx_2 = lx;
        call_then(start_out_ty_of(lx_2, i_1), [=](crate::lower::model::OutTy out_ty_of_2936) { return prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutEvent{prism_rtl::rc(out_ty_of_2936)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t) && ({
        auto&& m1375_27_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        (m1375_27_0 == Text::lit("$"));
    }) ? ({
        auto&& m1375_27_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        ({
        auto i_1 = i;
        auto lx_2 = lx;
        call_then(start_out_ty_of(lx_2, i_1), [=](crate::lower::model::OutTy out_ty_of_2977) { return prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutDyn{prism_rtl::rc(out_ty_of_2977)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t) && ({
        auto&& m1375_28_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        (m1375_28_0 == Text::lit("&"));
    }) ? ({
        auto&& m1375_28_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        prism_rtl::more(prism_rtl::rc(OutTyOf(lx, i)));
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t) ? ({
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        prism_rtl::more(prism_rtl::rc(OutTyOf(lx, i)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyQ>(t) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyQ>(t).a0;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutGen{crate::lower::camel(n)}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyRigid>(t) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyRigid>(t).a0;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutGen{crate::lower::camel(n)}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyFlex>(t) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyFlex>(t).a0;
        ({
        auto&& _m = crate::prelude::get(lx.subst, prism_rtl::cat("\'", n));
        prism_rtl::is_some(_m) ? ({
        auto&& x = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(OutTyOf(lx, x)));
    })
        : prism_rtl::is_none(_m) ? ({
        auto&& _m = crate::prelude::get(lx.quants, prism_rtl::cat("\'", n));
        prism_rtl::is_some(_m) ? ({
        auto&& b = prism_rtl::some_of(_m);
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutQuantified{b}));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyAny>(t) ? prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutShowAny{}))
        : prism_rtl::is<crate::check::types::Ty::TyElem>(t) ? prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutLive{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("crate::Elem"), Array<crate::lower::model::OutTy>{}}))}))
        : prism_rtl::is<crate::check::types::Ty::TyElemAny>(t) ? prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("crate::Elem"), Array<crate::lower::model::OutTy>{}}))
        : prism_rtl::is<crate::check::types::Ty::TyAt>(t) ? ({
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a0;
        prism_rtl::finished(blueprint_ty());
    })
        : prism_rtl::is<crate::check::types::Ty::TyAssoc>(t) ? prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{Text::lit("an associated type")}))
        : prism_rtl::is<crate::check::types::Ty::TyErr>(t) ? prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{Text::lit("a type the checker did not find")}))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start OutTyOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::OutTy> start_out_ty_of(crate::lower::Lx lx, crate::check::types::Ty t) {
    return prism_rtl::make_rc<OutTyOf>(lx, t);
}


/// let blueprintTy
crate::lower::model::OutTy blueprint_ty() {
    return crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("prism_rtl::Blueprint"), Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("crate::Elem"), Array<crate::lower::model::OutTy>{}}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("crate::Answer"), Array<crate::lower::model::OutTy>{}})})});
}


/// let elemTy
crate::lower::model::OutTy elem_ty() {
    return crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("crate::Elem"), Array<crate::lower::model::OutTy>{}});
}


/// let answerTy
crate::lower::model::OutTy answer_ty() {
    return crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("crate::Answer"), Array<crate::lower::model::OutTy>{}});
}


/// let hostOfTy
crate::lower::model::OutTy host_of_ty() {
    return crate::lower::model::OutTy(crate::lower::model::OutTy::OutObj{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("prism_rtl::HostOf"), Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("crate::Elem"), Array<crate::lower::model::OutTy>{}}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("crate::Answer"), Array<crate::lower::model::OutTy>{}})})}))});
}


/// HasBlueprint: fn Ty -> Bool
bool has_blueprint(const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t)) {
        return true;
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        return has_blueprint(i);
    }
    {
        return false;
    }
}


/// EventParam: fn Ty -> Ty
crate::check::types::Ty event_param(const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& m4483_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        if (m4483_0_0 == Text::lit("!")) {
            return crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("\000Event"sv), Array(std::vector{peel(i)})});
        }
    }
    {
        return t;
    }
}


/// JobParam: fn Ty -> Ty
crate::check::types::Ty job_param(const crate::check::types::Ty& ty0) {
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(ty0)) {
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(ty0).a1;
        auto&& r = prism_rtl::as<crate::check::types::Ty::TyFn>(ty0).a2;
        return crate::check::types::Ty(crate::check::types::Ty::TyFn{crate::check::types::Col(crate::check::types::Col::CUnbound{}), ps, prism_rtl::rc(r)});
    }
    {
        auto&& t = ty0;
        return t;
    }
}


/// RustTyOfParams: unbounded fn Lx, [Ty] -> OutTy
crate::lower::model::OutTy rust_ty_of_params(const crate::lower::Lx& lx, const Array<crate::check::types::Ty>& ps) {
    {
        auto&& m5046_0 = ps;
        if (m5046_0.size() == 1u) {
            {
                auto&& _c1 = index(m5046_0, Nat(0u));
                if (prism_rtl::is_some(_c1)) {
                    auto&& p_ = prism_rtl::some_of(_c1);
                    return out_ty_of(lx, p_);
                }
            }
        }
    }
    {
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{run_to_end(each_job(ps, ({
            auto lx_1 = lx;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
            return ({
                auto lx_1_2 = lx_1;
                entered(once_job([=]() {
                return ({
                    auto p_ = p0;
                    (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_1_2, p_))));
                });
            }));
            });
        })));
        })))});
    }
}


prism_rtl::Turn<crate::lower::model::OutTy> RustTyOfParams::cycle() const {
    const auto& lx = this->lx;
    const auto& ps = this->ps;
    return ({
        ({
        auto&& m5046_0 = ps;
        (m5046_0.size() == 1u) && ({
        auto&& _c1 = index(m5046_0, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m5046_0 = ps;
        auto&& _c1 = index(m5046_0, Nat(0u));
        auto&& p_ = prism_rtl::some_of(_c1);
        prism_rtl::more(prism_rtl::rc(OutTyOf(lx, p_)));
    })
        : ({
        auto lx_1 = lx;
        auto ps_2 = ps;
        call_value(each_job(ps_2, ({
        auto lx_1_3 = lx_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return ({
            auto lx_1_3_3 = lx_1_3;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_1_3_3, p_))));
            });
        }));
        });
    })));
    })), [=](Array<crate::lower::model::OutTy> each_5106) { return prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{each_5106})); });
    });
    });
}


/// `Start RustTyOfParams, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::OutTy> start_rust_ty_of_params(crate::lower::Lx lx, Array<crate::check::types::Ty> ps) {
    return prism_rtl::make_rc<RustTyOfParams>(lx, ps);
}


/// NamedTy: unbounded fn Lx, Text, [OutTy] -> OutTy
crate::lower::model::OutTy named_ty(const crate::lower::Lx& lx, const Text& n, const Array<crate::lower::model::OutTy>& args) {
    auto&& _m = crate::prelude::get(lx.g.types, n);
    if (prism_rtl::is_some(_m)) {
        auto&& ti = prism_rtl::some_of(_m);
        auto&& _m = ti.body;
        if (prism_rtl::is<crate::check::env::TyBody::BAlias>(_m)) {
            auto&& a = prism_rtl::as<crate::check::env::TyBody::BAlias>(_m).a0;
            return out_ty_of(lx, a);
        }
        if (prism_rtl::is<crate::check::env::TyBody::BRowKind>(_m)) {
            return n == Text::lit("Prelude.Fault")
                ? crate::lower::model::OutTy(crate::lower::model::OutTy::OutPod{})
                : crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{crate::lower::path_in(lx, ti.home, crate::lower::camel(crate::check::types::bare_name(n))), Array<crate::lower::model::OutTy>{}});
        }
        {
            return crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{crate::lower::path_in(lx, ti.home, crate::lower::camel(crate::check::types::bare_name(n))), args});
        }
    }
    if (prism_rtl::is_none(_m)) {
        return crate::check::env::has_key(lx.g.families, n)
            ? crate::lower::model::OutTy(crate::lower::model::OutTy::OutPod{})
            : crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{crate::lower::camel(crate::check::types::bare_name(n)), args});
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::model::OutTy> NamedTy::cycle() const {
    const auto& lx = this->lx;
    const auto& n = this->n;
    const auto& args = this->args;
    return ({
        auto&& _m = crate::prelude::get(lx.g.types, n);
        prism_rtl::is_some(_m) ? ({
        auto&& ti = prism_rtl::some_of(_m);
        ({
        auto&& _m = ti.body;
        prism_rtl::is<crate::check::env::TyBody::BAlias>(_m) ? ({
        auto&& a = prism_rtl::as<crate::check::env::TyBody::BAlias>(_m).a0;
        prism_rtl::more(prism_rtl::rc(OutTyOf(lx, a)));
    })
        : prism_rtl::is<crate::check::env::TyBody::BRowKind>(_m) ? n == Text::lit("Prelude.Fault")
        ? prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutPod{}))
        : prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{crate::lower::path_in(lx, ti.home, crate::lower::camel(crate::check::types::bare_name(n))), Array<crate::lower::model::OutTy>{}}))
        : prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{crate::lower::path_in(lx, ti.home, crate::lower::camel(crate::check::types::bare_name(n))), args}));
    });
    })
        : prism_rtl::is_none(_m) ? crate::check::env::has_key(lx.g.families, n)
        ? prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutPod{}))
        : prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{crate::lower::camel(crate::check::types::bare_name(n)), args}))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start NamedTy, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::OutTy> start_named_ty(crate::lower::Lx lx, Text n, Array<crate::lower::model::OutTy> args) {
    return prism_rtl::make_rc<NamedTy>(lx, n, args);
}


/// Peel: fn Ty -> Ty
crate::check::types::Ty peel(const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& m5844_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        if (m5844_0_0 == Text::lit("$")) {
            return peel(i);
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& m5844_1_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        if (m5844_1_0 == Text::lit("!")) {
            return peel(i);
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& m5844_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        if (m5844_2_0 == Text::lit("&")) {
            return peel(i);
        }
    }
    {
        return t;
    }
}


/// OutOf: fn Ty -> Ty
crate::check::types::Ty out_of(const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a0;
        return peel(i);
    }
    {
        return peel(t);
    }
}


/// LayerOf: fn Ty -> Layer
Layer layer_of(const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& m6360_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        if (m6360_0_0 == Text::lit("$")) {
            return Layer(Layer::LyDyn{});
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& m6360_1_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        if (m6360_1_0 == Text::lit("!")) {
            return Layer(Layer::LyEv{});
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& m6360_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        if (m6360_2_0 == Text::lit("&")) {
            return layer_of(i);
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t)) {
        return Layer(Layer::LyBlueprint{});
    }
    {
        return Layer(Layer::LyPlain{});
    }
}


/// Layouts: unbounded fn G -> (Text ==> [Bool])
Map<Text, Array<bool>> layouts(const crate::check::env::G& g) {
    return run_to_end(fold_job(values(g.ctors), Map<Text, Array<bool>>{}, ({
        auto g_1 = g;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<bool>>>(std::tuple<Map<Text, Array<bool>>, crate::check::env::CtorInfo>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Array<bool>>, crate::check::env::CtorInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_2 = g_1;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                auto c = p1;
                call_value(each_job(c->args, ({
                auto g_1_2_2 = g_1_2;
                auto c_2 = c;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
                return ({
                    auto g_1_2_2_3 = g_1_2_2;
                    auto c_2_3 = c_2;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        (prism_rtl::more(prism_rtl::rc(Reaches(g_1_2_2_3, a, c_2_3.owner, Array<Text>{}))));
                    });
                }));
                });
            })));
            })), [=](Array<bool> each_6868) { return prism_rtl::finished(insert(m, c.name, each_6868)); });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<Map<Text, Array<bool>>> Layouts::cycle() const {
    const auto& g = this->g;
    return fold_job(values(g.ctors), Map<Text, Array<bool>>{}, ({
        auto g_1 = g;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<bool>>>(std::tuple<Map<Text, Array<bool>>, crate::check::env::CtorInfo>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Array<bool>>, crate::check::env::CtorInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_2 = g_1;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                auto c = p1;
                call_value(each_job(c->args, ({
                auto g_1_2_2 = g_1_2;
                auto c_2 = c;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
                return ({
                    auto g_1_2_2_3 = g_1_2_2;
                    auto c_2_3 = c_2;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        (prism_rtl::more(prism_rtl::rc(Reaches(g_1_2_2_3, a, c_2_3.owner, Array<Text>{}))));
                    });
                }));
                });
            })));
            })), [=](Array<bool> each_6868) { return prism_rtl::finished(insert(m, c.name, each_6868)); });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start Layouts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Array<bool>>> start_layouts(crate::check::env::G g) {
    return prism_rtl::make_rc<Layouts>(g);
}


/// Reaches: unbounded fn G, Ty, Text, [Text] -> Bool
bool reaches(const crate::check::env::G& g, const crate::check::types::Ty& t, const Text& target, const Array<Text>& seen) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        return n == target
            ? true
            : crate::check::types::has_text(seen, n)
            ? false
            : run_to_end(fold_job(args, false, ({
            auto g_1 = g;
            auto target_2 = target;
            auto seen_3 = seen;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto g_1_4 = g_1;
                auto target_2_4 = target_2;
                auto seen_3_4 = seen_3;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    auto a = p1;
                    (prism_rtl::finished(f || reaches(g_1_4, a, target_2_4, seen_3_4)));
                });
            }));
            });
        })));
        })))
            ? true
            : ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = crate::prelude::get(g.types, n);
            if (prism_rtl::is_some(_m)) {
                auto&& ti = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = ti.body;
                    if (prism_rtl::is<crate::check::env::TyBody::BRecord>(_m)) {
                        auto&& fs = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
                        _v.set(run_to_end(fold_job(fs, false, ({
                            auto g_1 = g;
                            auto target_2 = target;
                            auto seen_3 = seen;
                            auto n_4 = n;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, crate::check::types::Ty>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, crate::check::types::Ty>> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto g_1_5 = g_1;
                                auto target_2_5 = target_2;
                                auto seen_3_5 = seen_3;
                                auto n_4_5 = n_4;
                                entered(once_job([=]() {
                                return ({
                                    auto f = p0;
                                    auto&& _ft = p1;
                                    auto&& ft = std::get<1>(_ft);
                                    (prism_rtl::finished(f || reaches(g_1_5, ft, target_2_5, crate::prelude::push(seen_3_5, n_4_5))));
                                });
                            }));
                            });
                        })));
                        }))));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
                        auto&& cs = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
                        _v.set(run_to_end(fold_job(cs, false, ({
                            auto g_1 = g;
                            auto target_2 = target;
                            auto seen_3 = seen;
                            auto n_4 = n;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Array<crate::check::types::Ty>>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Array<crate::check::types::Ty>>> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto g_1_5 = g_1;
                                auto target_2_5 = target_2;
                                auto seen_3_5 = seen_3;
                                auto n_4_5 = n_4;
                                entered(once_job([=]() {
                                return ({
                                    auto f = p0;
                                    auto&& _ats = p1;
                                    auto&& ats = std::get<1>(_ats);
                                    (prism_rtl::finished(f || run_to_end(fold_job(ats, false, ({
                                    auto g_1_5_5 = g_1_5;
                                    auto target_2_5_5 = target_2_5;
                                    auto seen_3_5_5 = seen_3_5;
                                    auto n_4_5_5 = n_4_5;
                                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
                                    auto&& p0 = std::get<0>(_p0);
                                    auto&& p1 = std::get<1>(_p0);
                                    return ({
                                        auto g_1_5_5_5 = g_1_5_5;
                                        auto target_2_5_5_5 = target_2_5_5;
                                        auto seen_3_5_5_5 = seen_3_5_5;
                                        auto n_4_5_5_5 = n_4_5_5;
                                        entered(once_job([=]() {
                                        return ({
                                            auto f2 = p0;
                                            auto at_ = p1;
                                            (prism_rtl::finished(f2 || reaches(g_1_5_5_5, at_, target_2_5_5_5, crate::prelude::push(seen_3_5_5_5, n_4_5_5_5))));
                                        });
                                    }));
                                    });
                                })));
                                })))));
                                });
                            }));
                            });
                        })));
                        }))));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::env::TyBody::BAlias>(_m)) {
                        auto&& a = prism_rtl::as<crate::check::env::TyBody::BAlias>(_m).a0;
                        _v.set(reaches(g, a, target, crate::prelude::push(seen, n)));
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& m6998_1_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        if (m6998_1_0 == Text::lit("?")) {
            return reaches(g, i, target, seen);
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& m6998_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        if (m6998_2_0 == Text::lit("~")) {
            return reaches(g, i, target, seen);
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        return run_to_end(fold_job(ts, false, ({
            auto g_1 = g;
            auto target_2 = target;
            auto seen_3 = seen;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto g_1_4 = g_1;
                auto target_2_4 = target_2;
                auto seen_3_4 = seen_3;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    auto a = p1;
                    (prism_rtl::finished(f || reaches(g_1_4, a, target_2_4, seen_3_4)));
                });
            }));
            });
        })));
        })));
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> Reaches::cycle() const {
    const auto& g = this->g;
    const auto& t = this->t;
    const auto& target = this->target;
    const auto& seen = this->seen;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyCon>(t) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        n == target
        ? prism_rtl::finished(true)
        : crate::check::types::has_text(seen, n)
        ? prism_rtl::finished(false)
        : ({
        auto args_1 = args;
        auto g_2 = g;
        auto n_3 = n;
        auto seen_4 = seen;
        auto target_5 = target;
        call_value(fold_job(args_1, false, ({
        auto g_2_6 = g_2;
        auto target_5_6 = target_5;
        auto seen_4_6 = seen_4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_2_6_6 = g_2_6;
            auto target_5_6_6 = target_5_6;
            auto seen_4_6_6 = seen_4_6;
            entered(once_job([=]() {
            return ({
                auto f = p0;
                auto a = p1;
                (prism_rtl::finished(f || reaches(g_2_6_6, a, target_5_6_6, seen_4_6_6)));
            });
        }));
        });
    })));
    })), [=](bool fold_7112) {
        return fold_7112
            ? prism_rtl::finished(true)
            : ({
            auto&& _m = crate::prelude::get(g_2.types, n_3);
            prism_rtl::is_some(_m) ? ({
            auto&& ti = prism_rtl::some_of(_m);
            ({
            auto&& _m = ti.body;
            prism_rtl::is<crate::check::env::TyBody::BRecord>(_m) ? ({
            auto&& fs = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
            fold_job(fs, false, ({
            auto g_2_6 = g_2;
            auto target_5_6 = target_5;
            auto seen_4_6 = seen_4;
            auto n_3_6 = n_3;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, crate::check::types::Ty>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, crate::check::types::Ty>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto g_2_6_6 = g_2_6;
                auto target_5_6_6 = target_5_6;
                auto seen_4_6_6 = seen_4_6;
                auto n_3_6_6 = n_3_6;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    auto&& _ft = p1;
                    auto&& ft = std::get<1>(_ft);
                    (prism_rtl::finished(f || reaches(g_2_6_6, ft, target_5_6_6, crate::prelude::push(seen_4_6_6, n_3_6_6))));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::check::env::TyBody::BChoice>(_m) ? ({
            auto&& cs = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
            fold_job(cs, false, ({
            auto g_2_6 = g_2;
            auto target_5_6 = target_5;
            auto seen_4_6 = seen_4;
            auto n_3_6 = n_3;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Array<crate::check::types::Ty>>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Array<crate::check::types::Ty>>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto g_2_6_6 = g_2_6;
                auto target_5_6_6 = target_5_6;
                auto seen_4_6_6 = seen_4_6;
                auto n_3_6_6 = n_3_6;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    auto&& _ats = p1;
                    auto&& ats = std::get<1>(_ats);
                    (prism_rtl::finished(f || run_to_end(fold_job(ats, false, ({
                    auto g_2_6_6_6 = g_2_6_6;
                    auto target_5_6_6_6 = target_5_6_6;
                    auto seen_4_6_6_6 = seen_4_6_6;
                    auto n_3_6_6_6 = n_3_6_6;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto g_2_6_6_6_6 = g_2_6_6_6;
                        auto target_5_6_6_6_6 = target_5_6_6_6;
                        auto seen_4_6_6_6_6 = seen_4_6_6_6;
                        auto n_3_6_6_6_6 = n_3_6_6_6;
                        entered(once_job([=]() {
                        return ({
                            auto f2 = p0;
                            auto at_ = p1;
                            (prism_rtl::finished(f2 || reaches(g_2_6_6_6_6, at_, target_5_6_6_6_6, crate::prelude::push(seen_4_6_6_6_6, n_3_6_6_6_6))));
                        });
                    }));
                    });
                })));
                })))));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::check::env::TyBody::BAlias>(_m) ? ({
            auto&& a = prism_rtl::as<crate::check::env::TyBody::BAlias>(_m).a0;
            prism_rtl::more(prism_rtl::rc(Reaches(g_2, a, target_5, crate::prelude::push(seen_4, n_3))));
        })
            : prism_rtl::finished(false);
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t) && ({
        auto&& m6998_1_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        (m6998_1_0 == Text::lit("?"));
    }) ? ({
        auto&& m6998_1_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        prism_rtl::more(prism_rtl::rc(Reaches(g, i, target, seen)));
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t) && ({
        auto&& m6998_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        (m6998_2_0 == Text::lit("~"));
    }) ? ({
        auto&& m6998_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        prism_rtl::more(prism_rtl::rc(Reaches(g, i, target, seen)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        fold_job(ts, false, ({
        auto g_1 = g;
        auto target_2 = target;
        auto seen_3 = seen;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_4 = g_1;
            auto target_2_4 = target_2;
            auto seen_3_4 = seen_3;
            entered(once_job([=]() {
            return ({
                auto f = p0;
                auto a = p1;
                (prism_rtl::finished(f || reaches(g_1_4, a, target_2_4, seen_3_4)));
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::finished(false);
    });
}


/// `Start Reaches, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_reaches(crate::check::env::G g, crate::check::types::Ty t, Text target, Array<Text> seen) {
    return prism_rtl::make_rc<Reaches>(g, t, target, seen);
}


/// RcField: fn Lx, Text, Nat -> Bool
bool rc_field(const crate::lower::Lx& lx, const Text& ctor, const Nat& i) {
    return or_(index(or_(crate::prelude::get(lx.layouts, ctor), Array<bool>{}), i), false);
}


/// Floaty: unbounded fn G, Ty, [Text] -> Bool
bool floaty(const crate::check::env::G& g, const crate::check::types::Ty& t, const Array<Text>& seen) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m8102_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m8102_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m8102_0_0 == Text::lit("Float")) {
            if (m8102_0_1.size() == 0u) {
                return true;
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        return run_to_end(fold_job(args, false, ({
            auto g_1 = g;
            auto seen_2 = seen;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto g_1_3 = g_1;
                auto seen_2_3 = seen_2;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    auto a = p1;
                    (prism_rtl::finished(f || floaty(g_1_3, a, seen_2_3)));
                });
            }));
            });
        })));
        })))
            ? true
            : crate::check::types::has_text(seen, n)
            ? false
            : ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = crate::prelude::get(g.types, n);
            if (prism_rtl::is_some(_m)) {
                auto&& ti = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = ti.body;
                    if (prism_rtl::is<crate::check::env::TyBody::BRecord>(_m)) {
                        auto&& fs = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
                        _v.set(run_to_end(fold_job(fs, false, ({
                            auto g_1 = g;
                            auto seen_2 = seen;
                            auto n_3 = n;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, crate::check::types::Ty>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, crate::check::types::Ty>> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto g_1_4 = g_1;
                                auto seen_2_4 = seen_2;
                                auto n_3_4 = n_3;
                                entered(once_job([=]() {
                                return ({
                                    auto f = p0;
                                    auto&& _ft = p1;
                                    auto&& ft = std::get<1>(_ft);
                                    (prism_rtl::finished(f || floaty(g_1_4, ft, crate::prelude::push(seen_2_4, n_3_4))));
                                });
                            }));
                            });
                        })));
                        }))));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
                        auto&& cs = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
                        _v.set(run_to_end(fold_job(cs, false, ({
                            auto g_1 = g;
                            auto seen_2 = seen;
                            auto n_3 = n;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Array<crate::check::types::Ty>>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Array<crate::check::types::Ty>>> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto g_1_4 = g_1;
                                auto seen_2_4 = seen_2;
                                auto n_3_4 = n_3;
                                entered(once_job([=]() {
                                return ({
                                    auto f = p0;
                                    auto&& _ats = p1;
                                    auto&& ats = std::get<1>(_ats);
                                    (prism_rtl::finished(f || run_to_end(fold_job(ats, false, ({
                                    auto g_1_4_4 = g_1_4;
                                    auto seen_2_4_4 = seen_2_4;
                                    auto n_3_4_4 = n_3_4;
                                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
                                    auto&& p0 = std::get<0>(_p0);
                                    auto&& p1 = std::get<1>(_p0);
                                    return ({
                                        auto g_1_4_4_4 = g_1_4_4;
                                        auto seen_2_4_4_4 = seen_2_4_4;
                                        auto n_3_4_4_4 = n_3_4_4;
                                        entered(once_job([=]() {
                                        return ({
                                            auto f2 = p0;
                                            auto at_ = p1;
                                            (prism_rtl::finished(f2 || floaty(g_1_4_4_4, at_, crate::prelude::push(seen_2_4_4_4, n_3_4_4_4))));
                                        });
                                    }));
                                    });
                                })));
                                })))));
                                });
                            }));
                            });
                        })));
                        }))));
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        return floaty(g, i, seen);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        return run_to_end(fold_job(ts, false, ({
            auto g_1 = g;
            auto seen_2 = seen;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto g_1_3 = g_1;
                auto seen_2_3 = seen_2;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    auto a = p1;
                    (prism_rtl::finished(f || floaty(g_1_3, a, seen_2_3)));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        return floaty(g, e, seen);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        return floaty(g, k, seen) || floaty(g, v_, seen);
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> Floaty::cycle() const {
    const auto& g = this->g;
    const auto& t = this->t;
    const auto& seen = this->seen;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m8102_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m8102_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m8102_0_0 == Text::lit("Float")) && (m8102_0_1.size() == 0u);
    }) ? ({
        auto&& m8102_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m8102_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        prism_rtl::finished(true);
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        ({
        auto args_1 = args;
        auto g_2 = g;
        auto n_3 = n;
        auto seen_4 = seen;
        call_value(fold_job(args_1, false, ({
        auto g_2_5 = g_2;
        auto seen_4_5 = seen_4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_2_5_5 = g_2_5;
            auto seen_4_5_5 = seen_4_5;
            entered(once_job([=]() {
            return ({
                auto f = p0;
                auto a = p1;
                (prism_rtl::finished(f || floaty(g_2_5_5, a, seen_4_5_5)));
            });
        }));
        });
    })));
    })), [=](bool fold_8171) {
        return fold_8171
            ? prism_rtl::finished(true)
            : crate::check::types::has_text(seen_4, n_3)
            ? prism_rtl::finished(false)
            : ({
            auto&& _m = crate::prelude::get(g_2.types, n_3);
            prism_rtl::is_some(_m) ? ({
            auto&& ti = prism_rtl::some_of(_m);
            ({
            auto&& _m = ti.body;
            prism_rtl::is<crate::check::env::TyBody::BRecord>(_m) ? ({
            auto&& fs = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
            fold_job(fs, false, ({
            auto g_2_5 = g_2;
            auto seen_4_5 = seen_4;
            auto n_3_5 = n_3;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, crate::check::types::Ty>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, crate::check::types::Ty>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto g_2_5_5 = g_2_5;
                auto seen_4_5_5 = seen_4_5;
                auto n_3_5_5 = n_3_5;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    auto&& _ft = p1;
                    auto&& ft = std::get<1>(_ft);
                    (prism_rtl::finished(f || floaty(g_2_5_5, ft, crate::prelude::push(seen_4_5_5, n_3_5_5))));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::check::env::TyBody::BChoice>(_m) ? ({
            auto&& cs = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
            fold_job(cs, false, ({
            auto g_2_5 = g_2;
            auto seen_4_5 = seen_4;
            auto n_3_5 = n_3;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Array<crate::check::types::Ty>>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Array<crate::check::types::Ty>>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto g_2_5_5 = g_2_5;
                auto seen_4_5_5 = seen_4_5;
                auto n_3_5_5 = n_3_5;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    auto&& _ats = p1;
                    auto&& ats = std::get<1>(_ats);
                    (prism_rtl::finished(f || run_to_end(fold_job(ats, false, ({
                    auto g_2_5_5_5 = g_2_5_5;
                    auto seen_4_5_5_5 = seen_4_5_5;
                    auto n_3_5_5_5 = n_3_5_5;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto g_2_5_5_5_5 = g_2_5_5_5;
                        auto seen_4_5_5_5_5 = seen_4_5_5_5;
                        auto n_3_5_5_5_5 = n_3_5_5_5;
                        entered(once_job([=]() {
                        return ({
                            auto f2 = p0;
                            auto at_ = p1;
                            (prism_rtl::finished(f2 || floaty(g_2_5_5_5_5, at_, crate::prelude::push(seen_4_5_5_5_5, n_3_5_5_5_5))));
                        });
                    }));
                    });
                })));
                })))));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::finished(false);
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t) ? ({
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        prism_rtl::more(prism_rtl::rc(Floaty(g, i, seen)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        fold_job(ts, false, ({
        auto g_1 = g;
        auto seen_2 = seen;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_3 = g_1;
            auto seen_2_3 = seen_2;
            entered(once_job([=]() {
            return ({
                auto f = p0;
                auto a = p1;
                (prism_rtl::finished(f || floaty(g_1_3, a, seen_2_3)));
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        prism_rtl::more(prism_rtl::rc(Floaty(g, e, seen)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        ({
        auto g_1 = g;
        auto k_2 = k;
        auto seen_3 = seen;
        auto v__4 = v_;
        call_then(start_floaty(g_1, k_2, seen_3), [=](bool floaty_8771) { return prism_rtl::finished(floaty_8771 || floaty(g_1, v__4, seen_3)); });
    });
    })
        : prism_rtl::finished(false);
    });
}


/// `Start Floaty, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_floaty(crate::check::env::G g, crate::check::types::Ty t, Array<Text> seen) {
    return prism_rtl::make_rc<Floaty>(g, t, seen);
}


/// Podable: unbounded fn OutTy -> Bool
bool podable(const crate::lower::model::OutTy& t) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(t)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutJob>(t)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(t)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutShowAny>(t)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutLive>(t)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutUnknown>(t)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutGen>(t)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t)) {
        auto&& args = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        return run_to_end(fold_job(args, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto a = p1;
                    (prism_rtl::finished(ok && podable(a)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t).a0;
        return podable(i);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t).a0;
        return podable(i);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRc>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t).a0;
        return podable(i);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t).a0;
        return run_to_end(fold_job(ts, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto a = p1;
                    (prism_rtl::finished(ok && podable(a)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutArray>(t)) {
        auto&& e = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t).a0;
        return podable(e);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(t)) {
        auto&& k = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t).a1;
        return podable(k) && podable(v_);
    }
    {
        return true;
    }
}


prism_rtl::Turn<bool> Podable::cycle() const {
    const auto& t = this->t;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutFn>(t) ? prism_rtl::finished(false)
        : prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t) ? prism_rtl::finished(false)
        : prism_rtl::is<crate::lower::model::OutTy::OutJob>(t) ? prism_rtl::finished(false)
        : prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t) ? prism_rtl::finished(false)
        : prism_rtl::is<crate::lower::model::OutTy::OutDyn>(t) ? prism_rtl::finished(false)
        : prism_rtl::is<crate::lower::model::OutTy::OutShowAny>(t) ? prism_rtl::finished(false)
        : prism_rtl::is<crate::lower::model::OutTy::OutLive>(t) ? prism_rtl::finished(false)
        : prism_rtl::is<crate::lower::model::OutTy::OutUnknown>(t) ? prism_rtl::finished(false)
        : prism_rtl::is<crate::lower::model::OutTy::OutGen>(t) ? prism_rtl::finished(true)
        : prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t) ? ({
        auto&& args = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        fold_job(args, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto a = p1;
                (prism_rtl::finished(ok && podable(a)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t).a0;
        prism_rtl::more(prism_rtl::rc(Podable(i)));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRes>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t).a0;
        prism_rtl::more(prism_rtl::rc(Podable(i)));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRc>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t).a0;
        prism_rtl::more(prism_rtl::rc(Podable(i)));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t) ? ({
        auto&& ts = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t).a0;
        fold_job(ts, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto a = p1;
                (prism_rtl::finished(ok && podable(a)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutArray>(t) ? ({
        auto&& e = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t).a0;
        prism_rtl::more(prism_rtl::rc(Podable(e)));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutMap>(t) ? ({
        auto&& k = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t).a1;
        ({
        auto k_1 = k;
        auto v__2 = v_;
        call_then(start_podable(k_1), [=](bool podable_9446) { return prism_rtl::finished(podable_9446 && podable(v__2)); });
    });
    })
        : prism_rtl::finished(true);
    });
}


/// `Start Podable, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_podable(crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<Podable>(t);
}


/// let emptyEnv
Env empty_env() {
    return Env{.names = Map<Text, Bn>{}, .spans = Map<Text, Vl>{}, .uses = Map<Text, Text>{}};
}


/// NameKeyAt: fn Lx, Env, SName, Range -> Text
Text name_key_at(const crate::lower::Lx& lx, const Env& env, const crate::syntax::SName& n, const crate::syntax::Range& span) {
    auto&& _m = crate::prelude::get(lx.use_insts, crate::lower::place_key(lx, span));
    if (prism_rtl::is_some(_m)) {
        auto&& u = prism_rtl::some_of(_m);
        return or_(crate::prelude::get(env.uses, prism_rtl::cat(crate::check::env::sname_key(n), "#", show_text(crate::lower::expr::inst_at(lx, u)))), crate::check::env::sname_key(n));
    }
    if (prism_rtl::is_none(_m)) {
        return crate::check::env::sname_key(n);
    }
    prism_rtl::unreachable("no arm matched");
}


/// WithInstances: fn Env, [Text] -> [Text]
Array<Text> with_instances(const Env& env, const Array<Text>& names) {
    return fold(names, names, [&](const Array<Text>& acc, const Text& n) { return append(acc, filter(keys(env->names), [&](const Text& k) { return crate::syntax::lexer::chars::has_prefix(k, prism_rtl::cat(n, "#inst")); })); });
}


/// BindSpan: fn Env, Text, Vl -> Env
Env bind_span(const Env& env, const Text& nkey, const Vl& v_) {
    Env this_ = env;
    this_.spans = insert(this_.spans, nkey, v_);
    return this_;
}


/// Bind: fn Env, Text, Bn -> Env
Env bind(const Env& env, const Text& name, const Bn& b) {
    Env this_ = env;
    this_.names = insert(this_.names, name, b);
    return this_;
}


/// ValueTy: fn Vl -> OutTy
crate::lower::model::OutTy value_ty(const Vl& vl0) {
    if (prism_rtl::is<Vl::VlPlace>(vl0)) {
        auto&& t = prism_rtl::as<Vl::VlPlace>(vl0).a2;
        return t;
    }
    if (prism_rtl::is<Vl::VlOwned>(vl0)) {
        auto&& t = prism_rtl::as<Vl::VlOwned>(vl0).a1;
        return t;
    }
    prism_rtl::unreachable("no arm matched");
}


/// LocalPlace: fn Ex, Holding, OutTy -> Vl
Vl local_place(const crate::lower::model::Ex& x, const Holding& mode, const crate::lower::model::OutTy& t) {
    return Vl(Vl::VlPlace{x, mode, t});
}


/// PlaceStem: fn Ex -> Text
Text place_stem(const crate::lower::model::Ex& x) {
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(x)) {
        auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(x).a0;
        return n;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x)) {
        auto&& f = prism_rtl::as<crate::lower::model::Ex::XField>(x).a1;
        return f;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTarget>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XTarget>(x).a0;
        return place_stem(y);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XPart>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XPart>(x).a0;
        auto&& k = prism_rtl::as<crate::lower::model::Ex::XPart>(x).a1;
        return prism_rtl::cat(place_stem(y), "_", k);
    }
    {
        return Text::lit("place");
    }
}


/// OnSelf: fn Ex -> Bool
bool on_self(const crate::lower::model::Ex& x) {
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x)) {
        auto&& m12933_0_0 = prism_rtl::as<crate::lower::model::Ex::XField>(x).a0;
        if (prism_rtl::is<crate::lower::model::Ex::XSelf>(m12933_0_0)) {
            return true;
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XField>(x).a0;
        return on_self(y);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XPart>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XPart>(x).a0;
        return on_self(y);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XMethod>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XMethod>(x).a0;
        return on_self(y);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUpgrade>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XUpgrade>(x).a0;
        return on_self(y);
    }
    {
        return false;
    }
}


/// ?ThroughParent: fn Ex -> ?Ex
std::optional<crate::lower::model::Ex> through_parent(const crate::lower::model::Ex& x) {
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x)) {
        auto&& m13337_0_0 = prism_rtl::as<crate::lower::model::Ex::XField>(x).a0;
        auto&& m13337_0_1 = prism_rtl::as<crate::lower::model::Ex::XField>(x).a1;
        if (prism_rtl::is<crate::lower::model::Ex::XSelf>(m13337_0_0)) {
            if (m13337_0_1 == Text::lit("parent")) {
                return std::optional(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("parent")}));
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XField>(x).a0;
        auto&& f = prism_rtl::as<crate::lower::model::Ex::XField>(x).a1;
        auto&& _m = through_parent(y);
        if (prism_rtl::is_some(_m)) {
            auto&& z = prism_rtl::some_of(_m);
            return std::optional(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(z), f}));
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional<crate::lower::model::Ex>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XPart>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XPart>(x).a0;
        auto&& k = prism_rtl::as<crate::lower::model::Ex::XPart>(x).a1;
        auto&& _m = through_parent(y);
        if (prism_rtl::is_some(_m)) {
            auto&& z = prism_rtl::some_of(_m);
            return std::optional(crate::lower::model::Ex(crate::lower::model::Ex::XPart{prism_rtl::rc(z), k}));
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional<crate::lower::model::Ex>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XMethod>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XMethod>(x).a0;
        auto&& m = prism_rtl::as<crate::lower::model::Ex::XMethod>(x).a1;
        auto&& xs = prism_rtl::as<crate::lower::model::Ex::XMethod>(x).a2;
        auto&& _m = through_parent(y);
        if (prism_rtl::is_some(_m)) {
            auto&& z = prism_rtl::some_of(_m);
            return std::optional(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(z), m, xs}));
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional<crate::lower::model::Ex>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUpgrade>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XUpgrade>(x).a0;
        auto&& _m = through_parent(y);
        if (prism_rtl::is_some(_m)) {
            auto&& z = prism_rtl::some_of(_m);
            return std::optional(crate::lower::model::Ex(crate::lower::model::Ex::XUpgrade{prism_rtl::rc(z)}));
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional<crate::lower::model::Ex>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        return std::optional<crate::lower::model::Ex>{};
    }
}


/// Own: fn Vl -> Ex
crate::lower::model::Ex own(const Vl& vl0) {
    if (prism_rtl::is<Vl::VlPlace>(vl0) && prism_rtl::is<Holding::RcRef>(prism_rtl::as<Vl::VlPlace>(vl0).a1)) {
        auto&& x = prism_rtl::as<Vl::VlPlace>(vl0).a0;
        return crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(x)}))}))});
    }
    if (prism_rtl::is<Vl::VlPlace>(vl0) && prism_rtl::is<Holding::RcOwned>(prism_rtl::as<Vl::VlPlace>(vl0).a1)) {
        auto&& x = prism_rtl::as<Vl::VlPlace>(vl0).a0;
        return crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(x)}))});
    }
    if (prism_rtl::is<Vl::VlPlace>(vl0)) {
        auto&& x = prism_rtl::as<Vl::VlPlace>(vl0).a0;
        auto&& mode = prism_rtl::as<Vl::VlPlace>(vl0).a1;
        auto&& t = prism_rtl::as<Vl::VlPlace>(vl0).a2;
        return is_copy(t)
            ? crate::lower::types::copy(Vl(Vl::VlPlace{x, mode, t}))
            : crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(x)});
    }
    if (prism_rtl::is<Vl::VlOwned>(vl0)) {
        auto&& e = prism_rtl::as<Vl::VlOwned>(vl0).a0;
        return e;
    }
    prism_rtl::unreachable("no arm matched");
}


/// Ref: fn Vl -> Ex
crate::lower::model::Ex ref_(const Vl& vl0) {
    if (prism_rtl::is<Vl::VlPlace>(vl0) && prism_rtl::is<Holding::ByRef>(prism_rtl::as<Vl::VlPlace>(vl0).a1)) {
        auto&& x = prism_rtl::as<Vl::VlPlace>(vl0).a0;
        return x;
    }
    if (prism_rtl::is<Vl::VlPlace>(vl0) && prism_rtl::is<Holding::RcRef>(prism_rtl::as<Vl::VlPlace>(vl0).a1)) {
        auto&& x = prism_rtl::as<Vl::VlPlace>(vl0).a0;
        return crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(x)}))}))});
    }
    if (prism_rtl::is<Vl::VlPlace>(vl0) && prism_rtl::is<Holding::RcOwned>(prism_rtl::as<Vl::VlPlace>(vl0).a1)) {
        auto&& x = prism_rtl::as<Vl::VlPlace>(vl0).a0;
        return crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(x)}))});
    }
    if (prism_rtl::is<Vl::VlPlace>(vl0)) {
        auto&& x = prism_rtl::as<Vl::VlPlace>(vl0).a0;
        return crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(x)});
    }
    if (prism_rtl::is<Vl::VlOwned>(vl0)) {
        auto&& e = prism_rtl::as<Vl::VlOwned>(vl0).a0;
        return crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(e)});
    }
    prism_rtl::unreachable("no arm matched");
}


/// Copy: fn Vl -> Ex
crate::lower::model::Ex copy(const Vl& vl0) {
    if (prism_rtl::is<Vl::VlPlace>(vl0) && prism_rtl::is<Holding::ByRef>(prism_rtl::as<Vl::VlPlace>(vl0).a1)) {
        auto&& x = prism_rtl::as<Vl::VlPlace>(vl0).a0;
        return crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(x)});
    }
    if (prism_rtl::is<Vl::VlPlace>(vl0) && prism_rtl::is<Holding::RcRef>(prism_rtl::as<Vl::VlPlace>(vl0).a1)) {
        auto&& x = prism_rtl::as<Vl::VlPlace>(vl0).a0;
        return crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(x)}))}))});
    }
    if (prism_rtl::is<Vl::VlPlace>(vl0)) {
        auto&& x = prism_rtl::as<Vl::VlPlace>(vl0).a0;
        return x;
    }
    if (prism_rtl::is<Vl::VlOwned>(vl0)) {
        auto&& e = prism_rtl::as<Vl::VlOwned>(vl0).a0;
        return e;
    }
    prism_rtl::unreachable("no arm matched");
}


/// IsCopy: fn OutTy -> Bool
bool is_copy(const crate::lower::model::OutTy& t) {
    return ((((t == crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})) || (t == crate::lower::model::OutTy(crate::lower::model::OutTy::OutFloat{}))) || (t == crate::lower::model::OutTy(crate::lower::model::OutTy::OutU8{}))) || (t == crate::lower::model::OutTy(crate::lower::model::OutTy::OutChar{}))) || (t == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
}


/// AsBool: fn Vl -> Ex
crate::lower::model::Ex as_bool(const Vl& v_) {
    return crate::lower::types::copy(v_);
}

}  // namespace crate::lower::types
