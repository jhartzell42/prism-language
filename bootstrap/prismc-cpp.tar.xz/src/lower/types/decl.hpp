// The module `Lower.Types`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace lower::types {

class Bn;

struct Env;

class Holding;

class Layer;

class Vl;

struct OutTyOf;

struct RustTyOfParams;

struct NamedTy;

struct Layouts;

struct Reaches;

struct Floaty;

struct Podable;

}  // namespace lower::types

namespace lower::types {

/// `Bn`:
///
/// ```prism
/// type Bn = choice:
/// ```
class Bn {
public:
    using prism_value = void;
    struct BnLocal;
    struct BnHold;
    struct BnDyn;
    struct BnEv;
    struct BnParts;
    struct BnWidget;
    struct BnLocalFn;
    using Cases = std::variant<BnLocal, BnHold, BnDyn, BnEv, BnParts, BnWidget, BnLocalFn>;
    template <class C>
        requires prism_rtl::one_of<C, BnLocal, BnHold, BnDyn, BnEv, BnParts, BnWidget, BnLocalFn>
    Bn(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `Holding`:
///
/// ```prism
/// type Holding = choice:
/// ```
class Holding {
public:
    using prism_value = void;
    struct ByRef;
    struct Owned;
    struct RcRef;
    struct RcOwned;
    using Cases = std::variant<ByRef, Owned, RcRef, RcOwned>;
    template <class C>
        requires prism_rtl::one_of<C, ByRef, Owned, RcRef, RcOwned>
    Holding(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Holding> from_pod(const Pod& whole);
    friend inline bool operator==(const Holding& a, const Holding& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `Layer`:
///
/// ```prism
/// type Layer = choice:
/// ```
class Layer {
public:
    using prism_value = void;
    struct LyPlain;
    struct LyDyn;
    struct LyEv;
    struct LyBlueprint;
    using Cases = std::variant<LyPlain, LyDyn, LyEv, LyBlueprint>;
    template <class C>
        requires prism_rtl::one_of<C, LyPlain, LyDyn, LyEv, LyBlueprint>
    Layer(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Layer> from_pod(const Pod& whole);
    friend inline bool operator==(const Layer& a, const Layer& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `Vl`:
///
/// ```prism
/// type Vl = choice:
/// ```
class Vl {
public:
    using prism_value = void;
    struct VlPlace;
    struct VlOwned;
    using Cases = std::variant<VlPlace, VlOwned>;
    template <class C>
        requires prism_rtl::one_of<C, VlPlace, VlOwned>
    Vl(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    Pod to_pod() const;
    static Result<Vl> from_pod(const Pod& whole);

private:
    prism_rtl::Rc<const Cases> cases_;
};


}  // namespace lower::types

}  // namespace crate
