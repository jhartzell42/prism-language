// The module `Lower.Types`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace lower::types {

class Bn;

struct Env;

class Holding;

class Layer;

class Vl;

struct OutTyOf;

struct RustTyOfParams;

struct NamedTy;

struct Layouts;

struct Reaches;

struct Floaty;

struct Podable;

struct RuntimeEq;

struct HoldsDyn;

}  // namespace lower::types

}  // namespace crate
