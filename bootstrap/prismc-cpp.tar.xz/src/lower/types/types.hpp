// The module `Lower.Types`: its records, tags and newtypes and its choices' cases are defined with those
// of the modules whose types it holds by value and which hold its own, in `lower_node_-lower_types.types.hpp`,
// emitted by prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <lower_node_-lower_types.types.hpp>
