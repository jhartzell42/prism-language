// The module `Lower.Types`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <lower/types/types.hpp>
#include "elem.types.hpp"
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <syntax/types.hpp>
#include <lower/types.hpp>
#include <syntax/decls/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace lower::types {

crate::lower::model::OutTy out_ty_of_f(const crate::lower::Lx& lx_p0, const crate::check::types::Ty& t_p1);

prism_rtl::JobRef<crate::lower::model::OutTy> start_out_ty_of_f(crate::lower::Lx lx_p0, crate::check::types::Ty t_p1);

crate::lower::model::OutTy blueprint_ty_p();

crate::lower::model::OutTy elem_ty_p();

crate::lower::model::OutTy answer_ty_p();

crate::lower::model::OutTy entry_ty_p();

crate::lower::model::OutTy host_doc_ty_p();

crate::lower::model::OutTy host_of_ty_p();

bool has_blueprint_f(const crate::check::types::Ty& t_p0);

crate::check::types::Ty event_param_f(const crate::check::types::Ty& t_p0);

crate::check::types::Ty job_param_f(const crate::check::types::Ty& ty0);

crate::lower::model::OutTy rust_ty_of_params_f(const crate::lower::Lx& lx_p0, const Array<crate::check::types::Ty>& ps_p1);

prism_rtl::JobRef<crate::lower::model::OutTy> start_rust_ty_of_params_f(crate::lower::Lx lx_p0, Array<crate::check::types::Ty> ps_p1);

crate::lower::model::OutTy named_ty_f(const crate::lower::Lx& lx_p0, const Text& n_p1, const Array<crate::lower::model::OutTy>& args_p2);

prism_rtl::JobRef<crate::lower::model::OutTy> start_named_ty_f(crate::lower::Lx lx_p0, Text n_p1, Array<crate::lower::model::OutTy> args_p2);

crate::check::types::Ty peel_f(const crate::check::types::Ty& t_p0);

crate::check::types::Ty out_of_f(const crate::check::types::Ty& t_p0);

bool is_bundle_f(const crate::check::types::Ty& t_p0);

Layer layer_of_f(const crate::check::types::Ty& t_p0);

bool is_show_only_f(const Array<Text>& bounds_p0);

Map<Text, Array<bool>> layouts_f(const crate::check::env::G& g_p0);

prism_rtl::JobRef<Map<Text, Array<bool>>> start_layouts_f(crate::check::env::G g_p0);

bool reaches_f(const crate::check::env::G& g_p0, const crate::check::types::Ty& t_p1, const Text& target_p2, const Array<Text>& seen_p3);

prism_rtl::JobRef<bool> start_reaches_f(crate::check::env::G g_p0, crate::check::types::Ty t_p1, Text target_p2, Array<Text> seen_p3);

bool rc_field_f(const crate::lower::Lx& lx_p0, const Text& ctor_p1, const Nat& i_p2);

bool podable_f(const crate::lower::model::OutTy& t_p0);

prism_rtl::JobRef<bool> start_podable_f(crate::lower::model::OutTy t_p0);

bool runtime_eq_f(const crate::lower::model::OutTy& t_p0);

prism_rtl::JobRef<bool> start_runtime_eq_f(crate::lower::model::OutTy t_p0);

bool holds_dyn_f(const crate::lower::model::OutTy& t_p0);

prism_rtl::JobRef<bool> start_holds_dyn_f(crate::lower::model::OutTy t_p0);

Env empty_env_p();

Text name_key_at_f(const crate::lower::Lx& lx_p0, const Env& env_p1, const crate::syntax::SName& n_p2, const crate::syntax::Range& span_p3);

Array<Text> with_instances_f(const Env& env_p0, const Array<Text>& names_p1);

Env bind_span_f(const Env& env_p0, const Text& nkey_p1, const Vl& v_p2);

Env bind_f(const Env& env_p0, const Text& name_p1, const Bn& b_p2);

crate::lower::model::OutTy value_ty_f(const Vl& vl0);

Vl local_place_f(const crate::lower::model::Ex& x_p0, const Holding& mode_p1, const crate::lower::model::OutTy& t_p2);

Text place_stem_f(const crate::lower::model::Ex& x_p0);

bool on_self_f(const crate::lower::model::Ex& x_p0);

std::optional<crate::lower::model::Ex> through_parent_o(const crate::lower::model::Ex& x_p0);

crate::lower::model::Ex own_f(const Vl& vl0);

crate::lower::model::Ex ref_f(const Vl& vl0);

crate::lower::model::Ex copy_f(const Vl& vl0);

bool is_copy_f(const crate::lower::model::OutTy& t_p0);

crate::lower::model::Ex as_bool_f(const Vl& v_p0);

}  // namespace lower::types


namespace lower::types {

/// The step machine of `OutTyOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OutTyOf: unbounded fn Lx, Ty -> OutTy
struct OutTyOf : prism_rtl::Job<crate::lower::model::OutTy> {
    crate::lower::Lx lx_p0;
    crate::check::types::Ty t_p1;
    OutTyOf(crate::lower::Lx lx_p0, crate::check::types::Ty t_p1) : lx_p0(std::move(lx_p0)), t_p1(std::move(t_p1)) {}
    prism_rtl::Turn<crate::lower::model::OutTy> cycle() const override;
};


/// The step machine of `RustTyOfParams`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustTyOfParams: unbounded fn Lx, [Ty] -> OutTy
struct RustTyOfParams : prism_rtl::Job<crate::lower::model::OutTy> {
    crate::lower::Lx lx_p0;
    Array<crate::check::types::Ty> ps_p1;
    RustTyOfParams(crate::lower::Lx lx_p0, Array<crate::check::types::Ty> ps_p1) : lx_p0(std::move(lx_p0)), ps_p1(std::move(ps_p1)) {}
    prism_rtl::Turn<crate::lower::model::OutTy> cycle() const override;
};


/// The step machine of `NamedTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NamedTy: unbounded fn Lx, Text, [OutTy] -> OutTy
struct NamedTy : prism_rtl::Job<crate::lower::model::OutTy> {
    crate::lower::Lx lx_p0;
    Text n_p1;
    Array<crate::lower::model::OutTy> args_p2;
    NamedTy(crate::lower::Lx lx_p0, Text n_p1, Array<crate::lower::model::OutTy> args_p2) : lx_p0(std::move(lx_p0)), n_p1(std::move(n_p1)), args_p2(std::move(args_p2)) {}
    prism_rtl::Turn<crate::lower::model::OutTy> cycle() const override;
};


/// The step machine of `Layouts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Layouts: unbounded fn G -> (Text ==> [Bool])
struct Layouts : prism_rtl::Job<Map<Text, Array<bool>>> {
    crate::check::env::G g_p0;
    Layouts(crate::check::env::G g_p0) : g_p0(std::move(g_p0)) {}
    prism_rtl::Turn<Map<Text, Array<bool>>> cycle() const override;
};


/// The step machine of `Reaches`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Reaches: unbounded fn G, Ty, Text, [Text] -> Bool
struct Reaches : prism_rtl::Job<bool> {
    crate::check::env::G g_p0;
    crate::check::types::Ty t_p1;
    Text target_p2;
    Array<Text> seen_p3;
    Reaches(crate::check::env::G g_p0, crate::check::types::Ty t_p1, Text target_p2, Array<Text> seen_p3) : g_p0(std::move(g_p0)), t_p1(std::move(t_p1)), target_p2(std::move(target_p2)), seen_p3(std::move(seen_p3)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `Podable`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Podable: unbounded fn OutTy -> Bool
struct Podable : prism_rtl::Job<bool> {
    crate::lower::model::OutTy t_p0;
    Podable(crate::lower::model::OutTy t_p0) : t_p0(std::move(t_p0)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `RuntimeEq`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RuntimeEq: unbounded fn OutTy -> Bool
struct RuntimeEq : prism_rtl::Job<bool> {
    crate::lower::model::OutTy t_p0;
    RuntimeEq(crate::lower::model::OutTy t_p0) : t_p0(std::move(t_p0)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `HoldsDyn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// HoldsDyn: unbounded fn OutTy -> Bool
struct HoldsDyn : prism_rtl::Job<bool> {
    crate::lower::model::OutTy t_p0;
    HoldsDyn(crate::lower::model::OutTy t_p0) : t_p0(std::move(t_p0)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


}  // namespace lower::types

}  // namespace crate
