// The module `Lower.Types`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <lower/types/types.hpp>
#include "elem.types.hpp"
#include <lower/node_/types.hpp>
#include <syntax/types.hpp>
#include <lower/types.hpp>
#include <syntax/decls/types.hpp>
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace lower::types {

crate::lower::model::OutTy out_ty_of(const crate::lower::Lx& lx, const crate::check::types::Ty& t);

prism_rtl::JobRef<crate::lower::model::OutTy> start_out_ty_of(crate::lower::Lx lx, crate::check::types::Ty t);

crate::lower::model::OutTy blueprint_ty();

crate::lower::model::OutTy elem_ty();

crate::lower::model::OutTy answer_ty();

crate::lower::model::OutTy host_of_ty();

bool has_blueprint(const crate::check::types::Ty& t);

crate::check::types::Ty event_param(const crate::check::types::Ty& t);

crate::check::types::Ty job_param(const crate::check::types::Ty& ty0);

crate::lower::model::OutTy rust_ty_of_params(const crate::lower::Lx& lx, const Array<crate::check::types::Ty>& ps);

prism_rtl::JobRef<crate::lower::model::OutTy> start_rust_ty_of_params(crate::lower::Lx lx, Array<crate::check::types::Ty> ps);

crate::lower::model::OutTy named_ty(const crate::lower::Lx& lx, const Text& n, const Array<crate::lower::model::OutTy>& args);

prism_rtl::JobRef<crate::lower::model::OutTy> start_named_ty(crate::lower::Lx lx, Text n, Array<crate::lower::model::OutTy> args);

crate::check::types::Ty peel(const crate::check::types::Ty& t);

crate::check::types::Ty out_of(const crate::check::types::Ty& t);

Layer layer_of(const crate::check::types::Ty& t);

Map<Text, Array<bool>> layouts(const crate::check::env::G& g);

prism_rtl::JobRef<Map<Text, Array<bool>>> start_layouts(crate::check::env::G g);

bool reaches(const crate::check::env::G& g, const crate::check::types::Ty& t, const Text& target, const Array<Text>& seen);

prism_rtl::JobRef<bool> start_reaches(crate::check::env::G g, crate::check::types::Ty t, Text target, Array<Text> seen);

bool rc_field(const crate::lower::Lx& lx, const Text& ctor, const Nat& i);

bool floaty(const crate::check::env::G& g, const crate::check::types::Ty& t, const Array<Text>& seen);

prism_rtl::JobRef<bool> start_floaty(crate::check::env::G g, crate::check::types::Ty t, Array<Text> seen);

bool podable(const crate::lower::model::OutTy& t);

prism_rtl::JobRef<bool> start_podable(crate::lower::model::OutTy t);

Env empty_env();

Text name_key_at(const crate::lower::Lx& lx, const Env& env, const crate::syntax::SName& n, const crate::syntax::Range& span);

Array<Text> with_instances(const Env& env, const Array<Text>& names);

Env bind_span(const Env& env, const Text& nkey, const Vl& v_);

Env bind(const Env& env, const Text& name, const Bn& b);

crate::lower::model::OutTy value_ty(const Vl& vl0);

Vl local_place(const crate::lower::model::Ex& x, const Holding& mode, const crate::lower::model::OutTy& t);

Text place_stem(const crate::lower::model::Ex& x);

bool on_self(const crate::lower::model::Ex& x);

std::optional<crate::lower::model::Ex> through_parent(const crate::lower::model::Ex& x);

crate::lower::model::Ex own(const Vl& vl0);

crate::lower::model::Ex ref_(const Vl& vl0);

crate::lower::model::Ex copy(const Vl& vl0);

bool is_copy(const crate::lower::model::OutTy& t);

crate::lower::model::Ex as_bool(const Vl& v_);

}  // namespace lower::types


namespace lower::types {

/// The step machine of `OutTyOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OutTyOf: unbounded fn Lx, Ty -> OutTy
struct OutTyOf : prism_rtl::Job<crate::lower::model::OutTy> {
    crate::lower::Lx lx;
    crate::check::types::Ty t;
    OutTyOf(crate::lower::Lx lx, crate::check::types::Ty t) : lx(std::move(lx)), t(std::move(t)) {}
    prism_rtl::Turn<crate::lower::model::OutTy> cycle() const override;
};


/// The step machine of `RustTyOfParams`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustTyOfParams: unbounded fn Lx, [Ty] -> OutTy
struct RustTyOfParams : prism_rtl::Job<crate::lower::model::OutTy> {
    crate::lower::Lx lx;
    Array<crate::check::types::Ty> ps;
    RustTyOfParams(crate::lower::Lx lx, Array<crate::check::types::Ty> ps) : lx(std::move(lx)), ps(std::move(ps)) {}
    prism_rtl::Turn<crate::lower::model::OutTy> cycle() const override;
};


/// The step machine of `NamedTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NamedTy: unbounded fn Lx, Text, [OutTy] -> OutTy
struct NamedTy : prism_rtl::Job<crate::lower::model::OutTy> {
    crate::lower::Lx lx;
    Text n;
    Array<crate::lower::model::OutTy> args;
    NamedTy(crate::lower::Lx lx, Text n, Array<crate::lower::model::OutTy> args) : lx(std::move(lx)), n(std::move(n)), args(std::move(args)) {}
    prism_rtl::Turn<crate::lower::model::OutTy> cycle() const override;
};


/// The step machine of `Layouts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Layouts: unbounded fn G -> (Text ==> [Bool])
struct Layouts : prism_rtl::Job<Map<Text, Array<bool>>> {
    crate::check::env::G g;
    Layouts(crate::check::env::G g) : g(std::move(g)) {}
    prism_rtl::Turn<Map<Text, Array<bool>>> cycle() const override;
};


/// The step machine of `Reaches`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Reaches: unbounded fn G, Ty, Text, [Text] -> Bool
struct Reaches : prism_rtl::Job<bool> {
    crate::check::env::G g;
    crate::check::types::Ty t;
    Text target;
    Array<Text> seen;
    Reaches(crate::check::env::G g, crate::check::types::Ty t, Text target, Array<Text> seen) : g(std::move(g)), t(std::move(t)), target(std::move(target)), seen(std::move(seen)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `Floaty`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Floaty: unbounded fn G, Ty, [Text] -> Bool
struct Floaty : prism_rtl::Job<bool> {
    crate::check::env::G g;
    crate::check::types::Ty t;
    Array<Text> seen;
    Floaty(crate::check::env::G g, crate::check::types::Ty t, Array<Text> seen) : g(std::move(g)), t(std::move(t)), seen(std::move(seen)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `Podable`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Podable: unbounded fn OutTy -> Bool
struct Podable : prism_rtl::Job<bool> {
    crate::lower::model::OutTy t;
    Podable(crate::lower::model::OutTy t) : t(std::move(t)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


}  // namespace lower::types

}  // namespace crate
