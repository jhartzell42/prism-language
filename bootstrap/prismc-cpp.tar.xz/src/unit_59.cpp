// The module `Reading`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Reading`, from `target/bootstrap/cpp-src/prismc/reading.prism`.
namespace crate::reading {

bool Assembled::operator==(const Assembled& o) const { return units == o.units && prelude == o.prelude && scripts == o.scripts && errors == o.errors; }

void Assembled::show(Printer& p) const {
    p.record("Assembled", {{"units", units}, {"prelude", prelude}, {"scripts", scripts}, {"errors", errors}});
}

Pod Assembled::to_pod() const {
    return Pod::record("Assembled", {{"units", prism_rtl::to_pod(units)}, {"prelude", prism_rtl::to_pod(prelude)}, {"scripts", prism_rtl::to_pod(scripts)}, {"errors", prism_rtl::to_pod(errors)}});
}

Result<Assembled> Assembled::from_pod(const Pod& whole) {
    return Assembled{.units = TRY(prism_rtl::from_pod<Array<ModFiles>>(TRY(crate::prelude::field(whole, "units")))), .prelude = TRY(prism_rtl::from_pod<Array<ModFiles>>(TRY(crate::prelude::field(whole, "prelude")))), .scripts = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "scripts")))), .errors = TRY(prism_rtl::from_pod<Array<TreeDiag>>(TRY(crate::prelude::field(whole, "errors"))))};
}


void CheckOpts::show(Printer& p) const {
    p.record("CheckOpts", {{"world", world}, {"out", out}, {"typed", typed}, {"unused", unused}});
}

Pod CheckOpts::to_pod() const {
    return Pod::record("CheckOpts", {{"world", prism_rtl::to_pod(world)}, {"out", prism_rtl::to_pod(out)}, {"typed", prism_rtl::to_pod(typed)}, {"unused", prism_rtl::to_pod(unused)}});
}

Result<CheckOpts> CheckOpts::from_pod(const Pod& whole) {
    return CheckOpts{.world = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "world")))), .out = TRY(prism_rtl::from_pod<std::optional<Text>>(TRY(crate::prelude::field(whole, "out")))), .typed = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "typed")))), .unused = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "unused"))))};
}


void CompileSettings::show(Printer& p) const {
    p.record("CompileSettings", {{"out", out}, {"prelude", prelude}, {"name", name}, {"runtime", runtime}, {"target", target}});
}

Pod CompileSettings::to_pod() const {
    return Pod::record("CompileSettings", {{"out", prism_rtl::to_pod(out)}, {"prelude", prism_rtl::to_pod(prelude)}, {"name", prism_rtl::to_pod(name)}, {"runtime", prism_rtl::to_pod(runtime)}, {"target", prism_rtl::to_pod(target)}});
}

Result<CompileSettings> CompileSettings::from_pod(const Pod& whole) {
    return CompileSettings{.out = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "out")))), .prelude = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "prelude")))), .name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .runtime = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "runtime")))), .target = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "target"))))};
}


void HeadLine::show(Printer& p) const {
    p.record("HeadLine", {{"word", word}, {"arg", arg}, {"span", span}});
}

Pod HeadLine::to_pod() const {
    return Pod::record("HeadLine", {{"word", prism_rtl::to_pod(word)}, {"arg", prism_rtl::to_pod(arg)}, {"span", prism_rtl::to_pod(span)}});
}

Result<HeadLine> HeadLine::from_pod(const Pod& whole) {
    return HeadLine{.word = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "word")))), .arg = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "arg")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


bool ModFiles::operator==(const ModFiles& o) const { return name == o.name && named == o.named && segs == o.segs && parent == o.parent; }

void ModFiles::show(Printer& p) const {
    p.record("ModFiles", {{"name", name}, {"named", named}, {"segs", segs}, {"parent", parent}});
}

Pod ModFiles::to_pod() const {
    return Pod::record("ModFiles", {{"name", prism_rtl::to_pod(name)}, {"named", prism_rtl::to_pod(named)}, {"segs", prism_rtl::to_pod(segs)}, {"parent", prism_rtl::to_pod(parent)}});
}

Result<ModFiles> ModFiles::from_pod(const Pod& whole) {
    return ModFiles{.name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .named = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "named")))), .segs = TRY(prism_rtl::from_pod<Array<Seg>>(TRY(crate::prelude::field(whole, "segs")))), .parent = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "parent"))))};
}


bool ParsedProgram::operator==(const ParsedProgram& o) const { return srcs == o.srcs && trees == o.trees && shown == o.shown && parents == o.parents && errors == o.errors; }

void ParsedProgram::show(Printer& p) const {
    p.record("ParsedProgram", {{"srcs", srcs}, {"trees", trees}, {"shown", shown}, {"parents", parents}, {"errors", errors}});
}

Pod ParsedProgram::to_pod() const {
    return Pod::record("ParsedProgram", {{"srcs", prism_rtl::to_pod(srcs)}, {"trees", prism_rtl::to_pod(trees)}, {"shown", prism_rtl::to_pod(shown)}, {"parents", prism_rtl::to_pod(parents)}, {"errors", prism_rtl::to_pod(errors)}});
}

Result<ParsedProgram> ParsedProgram::from_pod(const Pod& whole) {
    return ParsedProgram{.srcs = TRY(prism_rtl::from_pod<Array<crate::check::errors::Src>>(TRY(crate::prelude::field(whole, "srcs")))), .trees = TRY(prism_rtl::from_pod<Array<crate::syntax::Module>>(TRY(crate::prelude::field(whole, "trees")))), .shown = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "shown")))), .parents = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "parents")))), .errors = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "errors"))))};
}


void ReadInput::show(Printer& p) const {
    p.record("ReadInput", {{"args", args}, {"prelude", prelude}, {"listings", listings}, {"paths", paths}, {"texts", texts}, {"tests", tests}, {"compiling", compiling}});
}

Pod ReadInput::to_pod() const {
    return Pod::record("ReadInput", {{"args", prism_rtl::to_pod(args)}, {"prelude", prism_rtl::to_pod(prelude)}, {"listings", prism_rtl::to_pod(listings)}, {"paths", prism_rtl::to_pod(paths)}, {"texts", prism_rtl::to_pod(texts)}, {"tests", prism_rtl::to_pod(tests)}, {"compiling", prism_rtl::to_pod(compiling)}});
}

Result<ReadInput> ReadInput::from_pod(const Pod& whole) {
    return ReadInput{.args = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "args")))), .prelude = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "prelude")))), .listings = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Array<Text>>>>(TRY(crate::prelude::field(whole, "listings")))), .paths = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "paths")))), .texts = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text>>>(TRY(crate::prelude::field(whole, "texts")))), .tests = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "tests")))), .compiling = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "compiling"))))};
}


void ReadMode::show(Printer& p) const {
    if (auto c = std::get_if<Checking>(&cases())) p.choice("Checking", {c->a0});
    else if (auto c = std::get_if<Compiling>(&cases())) p.choice("Compiling", {c->a0});
}

Pod ReadMode::to_pod() const {
    return std::holds_alternative<Checking>(cases()) ? Pod::choice("Checking", {prism_rtl::to_pod(std::get<Checking>(cases()).a0)})
        : std::holds_alternative<Compiling>(cases()) ? Pod::choice("Compiling", {prism_rtl::to_pod(std::get<Compiling>(cases()).a0)})
        : Pod();
}

Result<ReadMode> ReadMode::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "Checking" && c->args.size() == 1) return ReadMode(Checking{TRY(prism_rtl::from_pod<CheckOpts>(c->args[0]))});
        if (c->ctor == "Compiling" && c->args.size() == 1) return ReadMode(Compiling{TRY(prism_rtl::from_pod<CompileSettings>(c->args[0]))});
    }
    return mismatch<ReadMode>("a ReadMode", p);
}


void Seg::show(Printer& p) const {
    p.record("Seg", {{"path", path_}, {"text", text}, {"role", role}});
}

Pod Seg::to_pod() const {
    return Pod::record("Seg", {{"path", prism_rtl::to_pod(path_)}, {"text", prism_rtl::to_pod(text)}, {"role", prism_rtl::to_pod(role)}});
}

Result<Seg> Seg::from_pod(const Pod& whole) {
    return Seg{.path_ = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "path")))), .text = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "text")))), .role = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "role"))))};
}


bool TreeAcc::operator==(const TreeAcc& o) const { return units == o.units && declared == o.declared && diags == o.diags; }

void TreeAcc::show(Printer& p) const {
    p.record("TreeAcc", {{"units", units}, {"declared", declared}, {"diags", diags}});
}

Pod TreeAcc::to_pod() const {
    return Pod::record("TreeAcc", {{"units", prism_rtl::to_pod(units)}, {"declared", prism_rtl::to_pod(declared)}, {"diags", prism_rtl::to_pod(diags)}});
}

Result<TreeAcc> TreeAcc::from_pod(const Pod& whole) {
    return TreeAcc{.units = TRY(prism_rtl::from_pod<Array<ModFiles>>(TRY(crate::prelude::field(whole, "units")))), .declared = TRY(prism_rtl::from_pod<Map<Text, bool>>(TRY(crate::prelude::field(whole, "declared")))), .diags = TRY(prism_rtl::from_pod<Array<TreeDiag>>(TRY(crate::prelude::field(whole, "diags"))))};
}


void TreeDiag::show(Printer& p) const {
    p.record("TreeDiag", {{"path", path_}, {"span", span}, {"code", code}, {"message", message}, {"fix", fix}});
}

Pod TreeDiag::to_pod() const {
    return Pod::record("TreeDiag", {{"path", prism_rtl::to_pod(path_)}, {"span", prism_rtl::to_pod(span)}, {"code", prism_rtl::to_pod(code)}, {"message", prism_rtl::to_pod(message)}, {"fix", prism_rtl::to_pod(fix)}});
}

Result<TreeDiag> TreeDiag::from_pod(const Pod& whole) {
    return TreeDiag{.path_ = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "path")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span")))), .code = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "code")))), .message = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "message")))), .fix = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "fix"))))};
}


/// IsCompiling: fn ReadMode -> Bool
bool is_compiling(const ReadMode& read_mode0) {
    if (prism_rtl::is<ReadMode::Compiling>(read_mode0)) {
        return true;
    }
    if (prism_rtl::is<ReadMode::Checking>(read_mode0)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


// `@ReadSources` is inlined where it is applied.

// `@ReadUp` is inlined where it is applied.

// `@ReadTexts` is inlined where it is applied.

// `@ReadRun` is inlined where it is applied.

// `@RunRead` is inlined where it is applied.

// `@CheckRun` is inlined where it is applied.

// `@CompileRun` is inlined where it is applied.

/// Pairs: fn [Text], (Nat ==> [Text]) -> [((Text, [Text]))]
Array<std::tuple<Text, Array<Text>>> pairs(const Array<Text>& ds_p0, const Map<Nat, Array<Text>>& m_p1) {
    return each(crate::check::errors::range0(len(ds_p0)), [&](const Nat& i_p2) { return std::tuple{or_(index(ds_p0, i_p2), Text::lit("")), or_(crate::prelude::get(m_p1, i_p2), Array<Text>{})}; });
}


/// ReadFailure: fn ?~Contents -> Text
Text read_failure(const std::optional<Fallible<crate::fs::Contents>>& opt0) {
    if (prism_rtl::is_some(opt0)) {
        auto&& c_r0 = prism_rtl::some_of(opt0);
        return contents_failure(c_r0);
    }
    if (prism_rtl::is_none(opt0)) {
        return Text::lit("nothing was read");
    }
    prism_rtl::unreachable("no arm matched");
}


/// ContentsFailure: fn ~Contents -> Text
Text contents_failure(const Fallible<crate::fs::Contents>& arg0) {
    if (prism_rtl::is_ok(arg0)) {
        auto&& c_p0 = *arg0;
        return Text::lit("");
    }
    if (prism_rtl::is_err(arg0)) {
        auto&& c1_0 = arg0.error();
        return prism_rtl::deref(c1_0).message;
    }
    prism_rtl::unreachable("no arm matched");
}


/// ContentsText: fn ~Contents -> Text
Text contents_text(const Fallible<crate::fs::Contents>& arg0) {
    if (prism_rtl::is_ok(arg0)) {
        auto&& c_p0 = *arg0;
        return c_p0->text;
    }
    if (prism_rtl::is_err(arg0)) {
        auto&& c1_0 = arg0.error();
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// IsSourcePath: fn Text -> Bool
bool is_source_path(const Text& f_p0) {
    return crate::syntax::lexer::chars::has_suffix(f_p0, Text::lit(".prism")) || crate::syntax::lexer::chars::has_suffix(f_p0, Text::lit(".prismtest"));
}


/// DirOf: fn Text -> Text
Text dir_of(const Text& p_p0) {
    return crate::syntax::lexer::chars::join(crate::syntax::lexer::chars::pop(split_on(p_p0, Text::lit("/"))), Text::lit("/"));
}


/// BaseOf: fn Text -> Text
Text base_of(const Text& p_p0) {
    return or_(crate::syntax::lexer::chars::last(split_on(p_p0, Text::lit("/"))), p_p0);
}


/// Under: fn Text, Text -> Text
Text under(const Text& d_p0, const Text& n_p1) {
    return (d_p0 == Text::lit("")) || (d_p0 == Text::lit("."))
        ? n_p1
        : prism_rtl::cat(d_p0, "/", n_p1);
}


/// Ancestors: fn Text -> [Text]
Array<Text> ancestors(const Text& d_p0) {
    auto parts_p1 = split_on(d_p0, Text::lit("/"));
    auto n_p2 = len(parts_p1);
    return filter(each(crate::check::errors::range0(crate::syntax::lexer::chars::dec(n_p2)), [&](const Nat& i_p3) { return crate::syntax::lexer::chars::join(take(parts_p1, or_(crate::syntax::lexer::chars::dec(n_p2).checked_sub(i_p3), Nat(0u))), Text::lit("/")); }), [&](const Text& a_p4) { return (a_p4 != Text::lit("")) && (a_p4 != Text::lit(".")); });
}


/// DirName: fn Text -> Text
Text dir_name(const Text& name_p0) {
    auto&& _out_p5 = crate::syntax::lexer::chars::fold_chars(name_p0, std::tuple{Text::lit(""), Text::lit("")}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text>>(std::tuple<std::tuple<Text, Text>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Text, Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return once_job([=]() {
            return ({
                auto [acc_p1, prev_p2] = p0;
                auto c_p3 = p1;
                ({
                auto sep_p4 = crate::syntax::lexer::chars::is_upper(c_p3) && (crate::syntax::lexer::chars::is_lower(prev_p2) || crate::syntax::lexer::chars::is_digit(prev_p2))
                    ? Text::lit("_")
                    : Text::lit("");
                (prism_rtl::finished(std::tuple{prism_rtl::cat(acc_p1, sep_p4, crate::syntax::lexer::chars::is_upper(c_p3)
                ? crate::prelude::lower(c_p3)
                : c_p3), c_p3}));
            });
            });
        });
    })));
    auto&& out_p5 = std::get<0>(_out_p5);
    return out_p5;
}


/// ModOfDir: fn Text -> Text
Text mod_of_dir(const Text& d_p0) {
    return concat(each(split_on(d_p0, Text::lit("_")), [&](const Text& w_p1) { return prism_rtl::cat(upper(crate::syntax::lexer::chars::head(w_p1)), crate::syntax::lexer::chars::after_first(w_p1)); }));
}


/// HeaderLines: fn Text -> [HeadLine]
Array<HeadLine> header_lines(const Text& text_p0) {
    auto&& _lines_p7 = fold(split_on(text_p0, Text::lit("\n")), std::tuple{Array<HeadLine>{}, Nat(0u), true}, [&](const std::tuple<Array<HeadLine>, Nat, bool>& _p0, const Text& line_p4) {
        auto&& acc_p1 = std::get<0>(_p0);
        auto&& at_p2 = std::get<1>(_p0);
        auto&& open_p3 = std::get<2>(_p0);
        return ({
            auto next_p5 = (at_p2 + len_text(line_p4)) + Nat(1u);
            (!prism_rtl::deref(open_p3)
            ? std::tuple{acc_p1, next_p5, false}
            : ((crate::syntax::lexer::chars::trim(line_p4) == Text::lit("")) || crate::syntax::lexer::chars::has_prefix(line_p4, Text::lit("#"))) || crate::syntax::lexer::chars::has_prefix(line_p4, Text::lit(" "))
            ? std::tuple{acc_p1, next_p5, true}
            : ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Array<HeadLine>, Nat, bool>> _v;
            auto&& _m = head_line_of(line_p4, at_p2);
            if (prism_rtl::is_some(_m)) {
                auto&& h_p6 = prism_rtl::some_of(_m);
                _v.set(std::tuple{crate::prelude::push(acc_p1, h_p6), next_p5, true});
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(std::tuple{acc_p1, next_p5, false});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        }));
        });
    });
    auto&& lines_p7 = std::get<0>(_lines_p7);
    return lines_p7;
}


/// ?HeadLineOf: fn Text, Nat -> ?HeadLine
std::optional<HeadLine> head_line_of(const Text& line_p0, const Nat& at_p1) {
    auto code_p2 = crate::syntax::lexer::chars::trim_end(or_(index(split_on(line_p0, Text::lit(" #")), Nat(0u)), line_p0));
    auto words_p4 = filter(split_on(code_p2, Text::lit(" ")), [&](const Text& w_p3) { return w_p3 != Text::lit(""); });
    auto first_p5 = or_(index(words_p4, Nat(0u)), Text::lit(""));
    auto second_p6 = or_(index(words_p4, Nat(1u)), Text::lit(""));
    auto span_p7 = crate::syntax::Range{.start = at_p1, .end = at_p1 + len_text(code_p2)};
    return (first_p5 == Text::lit("test")) && (second_p6 == Text::lit("mod"))
        ? std::optional(HeadLine{.word = Text::lit("test mod"), .arg = or_(index(words_p4, Nat(2u)), Text::lit("")), .span = span_p7})
        : crate::check::types::has_text(Array(std::vector{Text::lit("module"), Text::lit("emit"), Text::lit("mod"), Text::lit("use")}), first_p5)
        ? std::optional(HeadLine{.word = first_p5, .arg = or_(crate::syntax::lexer::chars::before_suffix(second_p6, Text::lit(".*")), second_p6), .span = span_p7})
        : std::optional<HeadLine>{};
}


/// ?FirstDeclLine: fn Text -> ?Range
std::optional<crate::syntax::Range> first_decl_line(const Text& text_p0) {
    auto&& _found_o5 = fold(split_on(text_p0, Text::lit("\n")), std::tuple{std::optional<crate::syntax::Range>{}, Nat(0u)}, [&](const std::tuple<std::optional<crate::syntax::Range>, Nat>& _p0, const Text& line_p3) {
        auto&& f_o1 = std::get<0>(_p0);
        auto&& at_p2 = std::get<1>(_p0);
        return ({
            auto next_p4 = (at_p2 + len_text(line_p3)) + Nat(1u);
            ((((f_o1 != std::optional<crate::syntax::Range>{}) || (crate::syntax::lexer::chars::trim(line_p3) == Text::lit(""))) || crate::syntax::lexer::chars::has_prefix(line_p3, Text::lit("#"))) || crate::syntax::lexer::chars::has_prefix(line_p3, Text::lit(" "))) || (head_line_of(line_p3, at_p2) != std::optional<HeadLine>{})
            ? std::tuple{f_o1, next_p4}
            : std::tuple{std::optional(crate::syntax::Range{.start = at_p2, .end = at_p2 + len_text(crate::syntax::lexer::chars::trim_end(line_p3))}), next_p4};
        });
    });
    auto&& found_o5 = std::get<0>(_found_o5);
    return found_o5;
}


/// let noAssembly
Assembled no_assembly() {
    return Assembled{.units = Array<ModFiles>{}, .prelude = Array<ModFiles>{}, .scripts = Array<Text>{}, .errors = Array<TreeDiag>{}};
}


/// let noSpan
crate::syntax::Range no_span() {
    return crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)};
}


/// AddTreeDiag: fn TreeAcc, Text, Range, Text, Text, Text -> TreeAcc
TreeAcc add_tree_diag(const TreeAcc& acc_p0, const Text& path_p1, const crate::syntax::Range& span_p2, const Text& code_p3, const Text& message_p4, const Text& fix_p5) {
    TreeAcc this_ = acc_p0;
    this_.diags = crate::prelude::push(this_.diags, TreeDiag{.path_ = path_p1, .span = span_p2, .code = code_p3, .message = message_p4, .fix = fix_p5});
    return this_;
}


/// IsModuleDir: fn Text, [Text] -> Bool
bool is_module_dir(const Text& d_p0, const Array<Text>& files_p1) {
    return (crate::check::types::has_text(files_p1, under(d_p0, Text::lit("mod.prism"))) && (!crate::check::types::has_text(files_p1, under(d_p0, Text::lit("app.prism"))))) && (!crate::check::types::has_text(files_p1, under(d_p0, Text::lit("lib.prism"))));
}


/// IsRootDir: fn Text, [Text] -> Bool
bool is_root_dir(const Text& d_p0, const Array<Text>& files_p1) {
    return crate::check::types::has_text(files_p1, under(d_p0, Text::lit("app.prism"))) || crate::check::types::has_text(files_p1, under(d_p0, Text::lit("lib.prism")));
}


/// ?TreeRootOf: fn Text, (Text ==> [Text]) -> ?Text
std::optional<Text> tree_root_of(const Text& d_p0, const Map<Text, Array<Text>>& listings_p1) {
    auto files_p2 = or_(crate::prelude::get(listings_p1, d_p0), Array<Text>{});
    return is_root_dir(d_p0, files_p2)
        ? std::optional(d_p0)
        : is_module_dir(d_p0, files_p2)
        ? fold(ancestors(d_p0), std::optional<Text>{}, [&](const std::optional<Text>& found_o3, const Text& a_p4) {
        return (found_o3 == std::optional<Text>{}) && is_root_dir(a_p4, or_(crate::prelude::get(listings_p1, a_p4), Array<Text>{}))
            ? std::optional(a_p4)
            : found_o3;
    })
        : std::optional<Text>{};
}


/// ToRead: fn [Text], (Text ==> [Text]) -> [Text]
Array<Text> to_read(const Array<Text>& args_p0, const Map<Text, Array<Text>>& listings_p1) {
    return fold(args_p0, Array<Text>{}, [&](const Array<Text>& acc_p2, const Text& a_p3) {
        return is_source_path(a_p3)
            ? crate::check::types::add_text(acc_p2, a_p3)
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = tree_root_of(a_p3, listings_p1);
            if (prism_rtl::is_some(_m)) {
                auto&& root_p4 = prism_rtl::some_of(_m);
                _v.set(crate::check::types::union_texts(acc_p2, or_(crate::prelude::get(listings_p1, root_p4), Array<Text>{})));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(acc_p2);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// Assemble: unbounded fn ReadInput -> Assembled
Assembled assemble(const ReadInput& input_p0) {
    auto listings_p1 = map(input_p0.listings);
    auto texts_p2 = map(input_p0.texts);
    auto progs_p3 = run_to_end(fold_job(input_p0.args, no_assembly(), ({
        auto listings_p1_1 = listings_p1;
        auto texts_p2_2 = texts_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Assembled>(std::tuple<Assembled, Text>)>>(prism_rtl::rc([=, listings_p1_1 = std::move(listings_p1_1), texts_p2_2 = std::move(texts_p2_2)](std::tuple<Assembled, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto listings_p1_1_3 = listings_p1_1;
            auto texts_p2_2_3 = texts_p2_2;
            entered(once_job([=, listings_p1_1_3 = std::move(listings_p1_1_3), texts_p2_2_3 = std::move(texts_p2_2_3)]() {
            return ({
                auto acc_p7 = p0;
                auto a_p8 = p1;
                (prism_rtl::more(prism_rtl::rc(AddArg(acc_p7, listings_p1_1_3, texts_p2_2_3, a_p8))));
            });
        }));
        });
    })));
    })));
    auto pre_p4 = add_arg(no_assembly(), listings_p1, texts_p2, input_p0.prelude);
    auto units_p5 = filter(each(prism_rtl::deref(progs_p3).units, [&](const ModFiles& u_p9) { return kept_segs(u_p9, input_p0.tests); }), [&](const ModFiles& u_pa) { return len(prism_rtl::deref(u_pa).segs) > Nat(0u); });
    auto kept_p6 = fold(units_p5, Array<Text>{}, [&](const Array<Text>& acc_pb, const ModFiles& u_pc) { return append(acc_pb, each(prism_rtl::deref(u_pc).segs, [&](const Seg& s_pd) { return s_pd->path_; })); });
    Assembled this_ = progs_p3;
    this_.units = units_p5;
    this_.prelude = filter(each(prism_rtl::deref(pre_p4).units, [&](const ModFiles& u_pe) { return kept_segs(u_pe, false); }), [&](const ModFiles& u_pf) { return len(prism_rtl::deref(u_pf).segs) > Nat(0u); });
    this_.scripts = filter(this_.scripts, [&](const Text& p_pg) { return crate::check::types::has_text(kept_p6, p_pg); });
    this_.errors = append(this_.errors, prism_rtl::deref(pre_p4).errors);
    return this_;
}


prism_rtl::Turn<Assembled> Assemble::cycle() const {
    const auto& input_p0 = this->input_p0;
    auto listings_p1 = map(input_p0->listings);
    auto texts_p2 = map(input_p0->texts);
    auto input_p0_1 = input_p0;
    return call_value(fold_job(input_p0_1->args, no_assembly(), ({
        auto listings_p1_2 = listings_p1;
        auto texts_p2_3 = texts_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Assembled>(std::tuple<Assembled, Text>)>>(prism_rtl::rc([=, listings_p1_2 = std::move(listings_p1_2), texts_p2_3 = std::move(texts_p2_3)](std::tuple<Assembled, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto listings_p1_2_4 = listings_p1_2;
            auto texts_p2_3_4 = texts_p2_3;
            entered(once_job([=, listings_p1_2_4 = std::move(listings_p1_2_4), texts_p2_3_4 = std::move(texts_p2_3_4)]() {
            return ({
                auto acc_p7 = p0;
                auto a_p8 = p1;
                (prism_rtl::more(prism_rtl::rc(AddArg(acc_p7, listings_p1_2_4, texts_p2_3_4, a_p8))));
            });
        }));
        });
    })));
    })), [=](Assembled fold_12106) {
        return ({
            auto progs_p3 = fold_12106;
            call_then(start_add_arg(no_assembly(), listings_p1, texts_p2, input_p0_1->prelude), [=, progs_p3 = std::move(progs_p3)](Assembled add_arg_12190) {
            return ({
                auto pre_p4 = add_arg_12190;
                auto units_p5 = filter(each(prism_rtl::deref(progs_p3).units, [&](const ModFiles& u_p9) { return kept_segs(u_p9, input_p0_1->tests); }), [&](const ModFiles& u_pa) { return len(prism_rtl::deref(u_pa).segs) > Nat(0u); });
                auto kept_p6 = fold(units_p5, Array<Text>{}, [&](const Array<Text>& acc_pb, const ModFiles& u_pc) { return append(acc_pb, each(prism_rtl::deref(u_pc).segs, [&](const Seg& s_pd) { return s_pd->path_; })); });
                (prism_rtl::finished(({
                Assembled this_ = progs_p3;
                this_.units = units_p5;
                this_.prelude = filter(each(prism_rtl::deref(pre_p4).units, [&](const ModFiles& u_pe) { return kept_segs(u_pe, false); }), [&](const ModFiles& u_pf) { return len(prism_rtl::deref(u_pf).segs) > Nat(0u); });
                this_.scripts = filter(this_.scripts, [&](const Text& p_pg) { return crate::check::types::has_text(kept_p6, p_pg); });
                this_.errors = append(this_.errors, prism_rtl::deref(pre_p4).errors);
                (std::move(this_));
            })));
            });
        });
        });
    });
}


/// `Start Assemble, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Assembled> start_assemble(ReadInput input_p0) {
    return prism_rtl::make_rc<Assemble>(input_p0);
}


/// KeptSegs: fn ModFiles, Bool -> ModFiles
ModFiles kept_segs(const ModFiles& u_p0, const bool& tests_p1) {
    ModFiles this_ = u_p0;
    this_.segs = filter(this_.segs, [&](const Seg& s_p2) { return (prism_rtl::deref(s_p2).role != Text::lit("test")) || tests_p1; });
    return this_;
}


/// AddArg: unbounded fn Assembled, (Text ==> [Text]), (Text ==> Text), Text -> Assembled
Assembled add_arg(const Assembled& acc_p0, const Map<Text, Array<Text>>& listings_p1, const Map<Text, Text>& texts_p2, const Text& a_p3) {
    return crate::syntax::lexer::chars::has_suffix(a_p3, Text::lit(".prismtest"))
        ? ({
        Assembled this_ = acc_p0;
        this_.errors = crate::prelude::push(this_.errors, TreeDiag{.path_ = a_p3, .span = no_span(), .code = Text::lit("prismtest"), .message = prism_rtl::cat("`", a_p3, "`: a `.prismtest` is not read: a module\'s tests are in its test modules, a loose file\'s inline"), .fix = Text::lit("move its declarations into a test module (`test mod tests`), or into the file it tests")});
        (std::move(this_));
    })
        : crate::syntax::lexer::chars::has_suffix(a_p3, Text::lit(".prism"))
        ? ({
        Assembled this_ = acc_p0;
        this_.units = crate::prelude::push(this_.units, ModFiles{.name = Text::lit(""), .named = false, .segs = Array(std::vector{Seg{.path_ = a_p3, .text = or_(crate::prelude::get(texts_p2, a_p3), Text::lit("")), .role = Text::lit("loose")}}), .parent = Text::lit("")});
        (std::move(this_));
    })
        : ({
        __label__ _done;
        prism_rtl::Slot<Assembled> _v;
        auto&& _m = tree_root_of(a_p3, listings_p1);
        if (prism_rtl::is_some(_m)) {
            auto&& root_p4 = prism_rtl::some_of(_m);
            _v.set(({
                auto tree_p5 = walk_tree(root_p4, or_(crate::prelude::get(listings_p1, root_p4), Array<Text>{}), texts_p2);
                auto start_p6 = under(a_p3, Text::lit("mod.prism"));
                auto units_p7 = root_p4 == a_p3
                    ? prism_rtl::deref(tree_p5).units
                    : reach_tree(prism_rtl::deref(tree_p5).units, start_p6);
                auto scripts_p8 = root_p4 == a_p3
                    ? fold(units_p7, Array<Text>{}, [&](const Array<Text>& s_p9, const ModFiles& u_pa) { return append(s_p9, test_paths(u_pa)); })
                    : fold(filter(units_p7, [&](const ModFiles& u_pb) { return (main_path(u_pb) == start_p6) || (u_pb->parent == start_p6); }), Array<Text>{}, [&](const Array<Text>& s_pc, const ModFiles& u_pd) { return append(s_pc, test_paths(u_pd)); });
                ({
                Assembled this_ = acc_p0;
                this_.units = append(this_.units, units_p7);
                this_.scripts = append(this_.scripts, scripts_p8);
                this_.errors = append(this_.errors, prism_rtl::deref(tree_p5).diags);
                (std::move(this_));
            });
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(({
                Assembled this_ = acc_p0;
                this_.errors = crate::prelude::push(this_.errors, TreeDiag{.path_ = a_p3, .span = no_span(), .code = Text::lit("no-root"), .message = prism_rtl::cat("`", a_p3, "` holds no app.prism, lib.prism or mod.prism, and a directory argument is a tree"), .fix = Text::lit("give it a root, or name its files")});
                (std::move(this_));
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Assembled> AddArg::cycle() const {
    const auto& acc_p0 = this->acc_p0;
    const auto& listings_p1 = this->listings_p1;
    const auto& texts_p2 = this->texts_p2;
    const auto& a_p3 = this->a_p3;
    return crate::syntax::lexer::chars::has_suffix(a_p3, Text::lit(".prismtest"))
        ? prism_rtl::finished(({
        Assembled this_ = acc_p0;
        this_.errors = crate::prelude::push(this_.errors, TreeDiag{.path_ = a_p3, .span = no_span(), .code = Text::lit("prismtest"), .message = prism_rtl::cat("`", a_p3, "`: a `.prismtest` is not read: a module\'s tests are in its test modules, a loose file\'s inline"), .fix = Text::lit("move its declarations into a test module (`test mod tests`), or into the file it tests")});
        (std::move(this_));
    }))
        : crate::syntax::lexer::chars::has_suffix(a_p3, Text::lit(".prism"))
        ? prism_rtl::finished(({
        Assembled this_ = acc_p0;
        this_.units = crate::prelude::push(this_.units, ModFiles{.name = Text::lit(""), .named = false, .segs = Array(std::vector{Seg{.path_ = a_p3, .text = or_(crate::prelude::get(texts_p2, a_p3), Text::lit("")), .role = Text::lit("loose")}}), .parent = Text::lit("")});
        (std::move(this_));
    }))
        : ({
        auto&& _m = tree_root_of(a_p3, listings_p1);
        prism_rtl::is_some(_m) ? ({
        auto&& root_p4 = prism_rtl::some_of(_m);
        ({
        auto a_p3_1 = a_p3;
        auto acc_p0_2 = acc_p0;
        auto listings_p1_3 = listings_p1;
        auto texts_p2_4 = texts_p2;
        call_then(start_walk_tree(root_p4, or_(crate::prelude::get(listings_p1_3, root_p4), Array<Text>{}), texts_p2_4), [=, a_p3_1 = std::move(a_p3_1), acc_p0_2 = std::move(acc_p0_2)](TreeAcc walk_tree_13644) {
        return ({
            auto tree_p5 = walk_tree_13644;
            auto start_p6 = under(a_p3_1, Text::lit("mod.prism"));
            auto units_p7 = root_p4 == a_p3_1
                ? prism_rtl::deref(tree_p5).units
                : reach_tree(prism_rtl::deref(tree_p5).units, start_p6);
            auto scripts_p8 = root_p4 == a_p3_1
                ? fold(units_p7, Array<Text>{}, [&](const Array<Text>& s_p9, const ModFiles& u_pa) { return append(s_p9, test_paths(u_pa)); })
                : fold(filter(units_p7, [&](const ModFiles& u_pb) { return (main_path(u_pb) == start_p6) || (u_pb->parent == start_p6); }), Array<Text>{}, [&](const Array<Text>& s_pc, const ModFiles& u_pd) { return append(s_pc, test_paths(u_pd)); });
            (prism_rtl::finished(({
            Assembled this_ = acc_p0_2;
            this_.units = append(this_.units, units_p7);
            this_.scripts = append(this_.scripts, scripts_p8);
            this_.errors = append(this_.errors, prism_rtl::deref(tree_p5).diags);
            (std::move(this_));
        })));
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(({
        Assembled this_ = acc_p0;
        this_.errors = crate::prelude::push(this_.errors, TreeDiag{.path_ = a_p3, .span = no_span(), .code = Text::lit("no-root"), .message = prism_rtl::cat("`", a_p3, "` holds no app.prism, lib.prism or mod.prism, and a directory argument is a tree"), .fix = Text::lit("give it a root, or name its files")});
        (std::move(this_));
    }))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start AddArg, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Assembled> start_add_arg(Assembled acc_p0, Map<Text, Array<Text>> listings_p1, Map<Text, Text> texts_p2, Text a_p3) {
    return prism_rtl::make_rc<AddArg>(acc_p0, listings_p1, texts_p2, a_p3);
}


/// MainPath: fn ModFiles -> Text
Text main_path(const ModFiles& u_p0) {
    auto&& _m = index(u_p0.segs, Nat(0u));
    if (prism_rtl::is_some(_m)) {
        auto&& s_p1 = prism_rtl::some_of(_m);
        return s_p1->path_;
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// MainText: fn ModFiles -> Text
Text main_text(const ModFiles& u_p0) {
    auto&& _m = index(u_p0.segs, Nat(0u));
    if (prism_rtl::is_some(_m)) {
        auto&& s_p1 = prism_rtl::some_of(_m);
        return s_p1->text;
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// TestPaths: fn ModFiles -> [Text]
Array<Text> test_paths(const ModFiles& u_p0) {
    return each(filter(u_p0.segs, [&](const Seg& s_p1) { return prism_rtl::deref(s_p1).role == Text::lit("test"); }), [&](const Seg& s_p2) { return s_p2->path_; });
}


/// WalkTree: unbounded fn Text, [Text], (Text ==> Text) -> TreeAcc
TreeAcc walk_tree(const Text& root_p0, const Array<Text>& files_p1, const Map<Text, Text>& texts_p2) {
    auto has_p3 = fold(files_p1, Map<Text, bool>{}, [&](const Map<Text, bool>& m_pa, const Text& f_pb) { return insert(m_pa, f_pb, true); });
    auto app_p4 = under(root_p0, Text::lit("app.prism"));
    auto lib_p5 = under(root_p0, Text::lit("lib.prism"));
    auto acc0_p6 = TreeAcc{.units = Array<ModFiles>{}, .declared = Map<Text, bool>{}, .diags = Array<TreeDiag>{}};
    auto acc1_p7 = crate::check::env::has_key(has_p3, app_p4) && crate::check::env::has_key(has_p3, lib_p5)
        ? add_tree_diag(acc0_p6, lib_p5, no_span(), Text::lit("two-roots"), Text::lit("`app.prism` and `lib.prism` in one directory: a tree has one root"), Text::lit("keep app.prism for a program or lib.prism for a library"))
        : acc0_p6;
    auto acc2_p8 = crate::check::env::has_key(has_p3, app_p4)
        ? walk_module(has_p3, texts_p2, acc1_p7, app_p4, Text::lit(""), Text::lit(""), false)
        : walk_lib(has_p3, texts_p2, acc1_p7, lib_p5);
    auto acc3_p9 = ({
        TreeAcc this_ = acc2_p8;
        this_.declared = insert(this_.declared, lib_p5, true);
        (std::move(this_));
    });
    return fold(files_p1, acc3_p9, [&](const TreeAcc& a_pc, const Text& f_pd) {
        return crate::check::env::has_key(prism_rtl::deref(a_pc).declared, f_pd)
            ? a_pc
            : stray(has_p3, texts_p2, a_pc, f_pd);
    });
}


prism_rtl::Turn<TreeAcc> WalkTree::cycle() const {
    const auto& root_p0 = this->root_p0;
    const auto& files_p1 = this->files_p1;
    const auto& texts_p2 = this->texts_p2;
    auto has_p3 = fold(files_p1, Map<Text, bool>{}, [&](const Map<Text, bool>& m_pa, const Text& f_pb) { return insert(m_pa, f_pb, true); });
    auto app_p4 = under(root_p0, Text::lit("app.prism"));
    auto lib_p5 = under(root_p0, Text::lit("lib.prism"));
    auto acc0_p6 = TreeAcc{.units = Array<ModFiles>{}, .declared = Map<Text, bool>{}, .diags = Array<TreeDiag>{}};
    auto acc1_p7 = crate::check::env::has_key(has_p3, app_p4) && crate::check::env::has_key(has_p3, lib_p5)
        ? add_tree_diag(acc0_p6, lib_p5, no_span(), Text::lit("two-roots"), Text::lit("`app.prism` and `lib.prism` in one directory: a tree has one root"), Text::lit("keep app.prism for a program or lib.prism for a library"))
        : acc0_p6;
    auto acc2_p8 = crate::check::env::has_key(has_p3, app_p4)
        ? walk_module(has_p3, texts_p2, acc1_p7, app_p4, Text::lit(""), Text::lit(""), false)
        : walk_lib(has_p3, texts_p2, acc1_p7, lib_p5);
    auto acc3_p9 = ({
        TreeAcc this_ = acc2_p8;
        this_.declared = insert(this_.declared, lib_p5, true);
        (std::move(this_));
    });
    return prism_rtl::finished(fold(files_p1, acc3_p9, [&](const TreeAcc& a_pc, const Text& f_pd) {
        return crate::check::env::has_key(prism_rtl::deref(a_pc).declared, f_pd)
            ? a_pc
            : stray(has_p3, texts_p2, a_pc, f_pd);
    }));
}


/// `Start WalkTree, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<TreeAcc> start_walk_tree(Text root_p0, Array<Text> files_p1, Map<Text, Text> texts_p2) {
    return prism_rtl::make_rc<WalkTree>(root_p0, files_p1, texts_p2);
}


/// WalkLib: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text -> TreeAcc
TreeAcc walk_lib(const Map<Text, bool>& has_p0, const Map<Text, Text>& texts_p1, const TreeAcc& acc_p2, const Text& lib_p3) {
    auto text_p4 = or_(crate::prelude::get(texts_p1, lib_p3), Text::lit(""));
    auto heads_p5 = header_lines(text_p4);
    auto bad_p6 = filter(heads_p5, [&](const HeadLine& h_pa) { return !((prism_rtl::deref(h_pa).word == Text::lit("mod")) && crate::check::env::is_upper_text(prism_rtl::deref(h_pa).arg)); });
    auto acc1_p7 = fold(bad_p6, acc_p2, [&](const TreeAcc& a_pb, const HeadLine& h_pc) { return add_tree_diag(a_pb, lib_p3, prism_rtl::deref(h_pc).span, Text::lit("lib-header"), prism_rtl::cat("lib.prism holds only `mod Name` lines, the library\'s modules: `", prism_rtl::deref(h_pc).word, "` belongs in a module"), Text::lit("move the line to a module\'s mod.prism")); });
    auto acc2_p8 = ({
        __label__ _done;
        prism_rtl::Slot<TreeAcc> _v;
        auto&& _m = first_decl_line(text_p4);
        if (prism_rtl::is_some(_m)) {
            auto&& r_pd = prism_rtl::some_of(_m);
            _v.set(add_tree_diag(acc1_p7, lib_p3, r_pd, Text::lit("lib-header"), Text::lit("lib.prism holds only `mod Name` lines, the library\'s modules"), Text::lit("move the declaration to a module")));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(acc1_p7);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto dir_p9 = dir_of(lib_p3);
    return run_to_end(fold_job(filter(heads_p5, [&](const HeadLine& h_pe) { return (prism_rtl::deref(h_pe).word == Text::lit("mod")) && crate::check::env::is_upper_text(prism_rtl::deref(h_pe).arg); }), acc2_p8, ({
        auto has_p0_1 = has_p0;
        auto texts_p1_2 = texts_p1;
        auto lib_p3_3 = lib_p3;
        auto dir_p9_4 = dir_p9;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<TreeAcc>(std::tuple<TreeAcc, HeadLine>)>>(prism_rtl::rc([=, has_p0_1 = std::move(has_p0_1), texts_p1_2 = std::move(texts_p1_2), lib_p3_3 = std::move(lib_p3_3), dir_p9_4 = std::move(dir_p9_4)](std::tuple<TreeAcc, HeadLine> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto has_p0_1_5 = has_p0_1;
            auto texts_p1_2_5 = texts_p1_2;
            auto lib_p3_3_5 = lib_p3_3;
            auto dir_p9_4_5 = dir_p9_4;
            entered(once_job([=, has_p0_1_5 = std::move(has_p0_1_5), texts_p1_2_5 = std::move(texts_p1_2_5), lib_p3_3_5 = std::move(lib_p3_3_5), dir_p9_4_5 = std::move(dir_p9_4_5)]() {
            return ({
                auto a_pf = p0;
                auto h_pg = p1;
                (prism_rtl::more(prism_rtl::rc(Child(has_p0_1_5, texts_p1_2_5, a_pf, lib_p3_3_5, dir_p9_4_5, h_pg, Text::lit(""), false))));
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<TreeAcc> WalkLib::cycle() const {
    const auto& has_p0 = this->has_p0;
    const auto& texts_p1 = this->texts_p1;
    const auto& acc_p2 = this->acc_p2;
    const auto& lib_p3 = this->lib_p3;
    auto text_p4 = or_(crate::prelude::get(texts_p1, lib_p3), Text::lit(""));
    auto heads_p5 = header_lines(text_p4);
    auto bad_p6 = filter(heads_p5, [&](const HeadLine& h_pa) { return !((prism_rtl::deref(h_pa).word == Text::lit("mod")) && crate::check::env::is_upper_text(prism_rtl::deref(h_pa).arg)); });
    auto acc1_p7 = fold(bad_p6, acc_p2, [&](const TreeAcc& a_pb, const HeadLine& h_pc) { return add_tree_diag(a_pb, lib_p3, prism_rtl::deref(h_pc).span, Text::lit("lib-header"), prism_rtl::cat("lib.prism holds only `mod Name` lines, the library\'s modules: `", prism_rtl::deref(h_pc).word, "` belongs in a module"), Text::lit("move the line to a module\'s mod.prism")); });
    auto acc2_p8 = ({
        __label__ _done;
        prism_rtl::Slot<TreeAcc> _v;
        auto&& _m = first_decl_line(text_p4);
        if (prism_rtl::is_some(_m)) {
            auto&& r_pd = prism_rtl::some_of(_m);
            _v.set(add_tree_diag(acc1_p7, lib_p3, r_pd, Text::lit("lib-header"), Text::lit("lib.prism holds only `mod Name` lines, the library\'s modules"), Text::lit("move the declaration to a module")));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(acc1_p7);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto dir_p9 = dir_of(lib_p3);
    return fold_job(filter(heads_p5, [&](const HeadLine& h_pe) { return (prism_rtl::deref(h_pe).word == Text::lit("mod")) && crate::check::env::is_upper_text(prism_rtl::deref(h_pe).arg); }), acc2_p8, ({
        auto has_p0_1 = has_p0;
        auto texts_p1_2 = texts_p1;
        auto lib_p3_3 = lib_p3;
        auto dir_p9_4 = dir_p9;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<TreeAcc>(std::tuple<TreeAcc, HeadLine>)>>(prism_rtl::rc([=, has_p0_1 = std::move(has_p0_1), texts_p1_2 = std::move(texts_p1_2), lib_p3_3 = std::move(lib_p3_3), dir_p9_4 = std::move(dir_p9_4)](std::tuple<TreeAcc, HeadLine> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto has_p0_1_5 = has_p0_1;
            auto texts_p1_2_5 = texts_p1_2;
            auto lib_p3_3_5 = lib_p3_3;
            auto dir_p9_4_5 = dir_p9_4;
            entered(once_job([=, has_p0_1_5 = std::move(has_p0_1_5), texts_p1_2_5 = std::move(texts_p1_2_5), lib_p3_3_5 = std::move(lib_p3_3_5), dir_p9_4_5 = std::move(dir_p9_4_5)]() {
            return ({
                auto a_pf = p0;
                auto h_pg = p1;
                (prism_rtl::more(prism_rtl::rc(Child(has_p0_1_5, texts_p1_2_5, a_pf, lib_p3_3_5, dir_p9_4_5, h_pg, Text::lit(""), false))));
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start WalkLib, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<TreeAcc> start_walk_lib(Map<Text, bool> has_p0, Map<Text, Text> texts_p1, TreeAcc acc_p2, Text lib_p3) {
    return prism_rtl::make_rc<WalkLib>(has_p0, texts_p1, acc_p2, lib_p3);
}


/// WalkModule: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text, Text, Text, Bool -> TreeAcc
TreeAcc walk_module(const Map<Text, bool>& has_p0, const Map<Text, Text>& texts_p1, const TreeAcc& acc_p2, const Text& main_p3, const Text& name_p4, const Text& parent_p5, const bool& in_test_p6) {
    auto dir_p7 = dir_of(main_p3);
    auto text_p8 = or_(crate::prelude::get(texts_p1, main_p3), Text::lit(""));
    auto heads_p9 = header_lines(text_p8);
    auto mods_pa = filter(heads_p9, [&](const HeadLine& h_pk) { return (prism_rtl::deref(h_pk).word == Text::lit("mod")) || (prism_rtl::deref(h_pk).word == Text::lit("test mod")); });
    auto subs_pb = filter(mods_pa, [&](const HeadLine& h_pl) { return crate::check::env::is_upper_text(prism_rtl::deref(h_pl).arg); });
    auto lower_pc = filter(mods_pa, [&](const HeadLine& h_pm) { return !crate::check::env::is_upper_text(prism_rtl::deref(h_pm).arg); });
    auto named_pd = name_p4 == Text::lit("")
        ? Text::lit("its path makes it the root")
        : prism_rtl::cat("its path names the module `", name_p4, "`");
    auto acc1_pe = fold(filter(heads_p9, [&](const HeadLine& h_pn) { return prism_rtl::deref(h_pn).word == Text::lit("module"); }), acc_p2, [&](const TreeAcc& a_po, const HeadLine& h_pp) { return add_tree_diag(a_po, main_p3, prism_rtl::deref(h_pp).span, Text::lit("module-line"), prism_rtl::cat("a module\'s file has no `module` line: ", named_pd), Text::lit("delete the line")); });
    auto leaf_pf = !crate::check::types::has_text(Array(std::vector{Text::lit("mod.prism"), Text::lit("app.prism"), Text::lit("lib.prism")}), base_of(main_p3));
    auto stem_pg = or_(crate::syntax::lexer::chars::before_suffix(base_of(main_p3), Text::lit(".prism")), main_p3);
    auto acc2_ph = std::move(leaf_pf)
        ? fold(mods_pa, acc1_pe, [&](const TreeAcc& a_pq, const HeadLine& h_pr) { return add_tree_diag(a_pq, main_p3, prism_rtl::deref(h_pr).span, Text::lit("mod-leaf"), prism_rtl::cat("`", base_of(main_p3), "` declares `", prism_rtl::deref(h_pr).word, " ", prism_rtl::deref(h_pr).arg, "`, and a module with children is a directory"), prism_rtl::cat("move ", base_of(main_p3), " to ", stem_pg, "/mod.prism")); })
        : acc1_pe;
    auto acc3_pi = fold(lower_pc, acc2_ph, [&](const TreeAcc& a_ps, const HeadLine& h_pt) { return lowercase(a_ps, main_p3, dir_p7, h_pt); });
    auto acc4_pj = ({
        TreeAcc this_ = acc3_pi;
        this_.declared = insert(this_.declared, main_p3, true);
        this_.units = crate::prelude::push(this_.units, ModFiles{.name = name_p4, .named = true, .segs = Array(std::vector{Seg{.path_ = main_p3, .text = text_p8, .role = in_test_p6 ? Text::lit("test") : Text::lit("main")}}), .parent = parent_p5});
        (std::move(this_));
    });
    return std::move(leaf_pf)
        ? acc4_pj
        : run_to_end(fold_job(subs_pb, acc4_pj, ({
        auto has_p0_1 = has_p0;
        auto texts_p1_2 = texts_p1;
        auto main_p3_3 = main_p3;
        auto dir_p7_4 = dir_p7;
        auto name_p4_5 = name_p4;
        auto in_test_p6_6 = in_test_p6;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<TreeAcc>(std::tuple<TreeAcc, HeadLine>)>>(prism_rtl::rc([=, has_p0_1 = std::move(has_p0_1), texts_p1_2 = std::move(texts_p1_2), main_p3_3 = std::move(main_p3_3), dir_p7_4 = std::move(dir_p7_4), name_p4_5 = std::move(name_p4_5), in_test_p6_6 = std::move(in_test_p6_6)](std::tuple<TreeAcc, HeadLine> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto has_p0_1_7 = has_p0_1;
            auto texts_p1_2_7 = texts_p1_2;
            auto main_p3_3_7 = main_p3_3;
            auto dir_p7_4_7 = dir_p7_4;
            auto name_p4_5_7 = name_p4_5;
            auto in_test_p6_6_7 = in_test_p6_6;
            entered(once_job([=, has_p0_1_7 = std::move(has_p0_1_7), texts_p1_2_7 = std::move(texts_p1_2_7), main_p3_3_7 = std::move(main_p3_3_7), dir_p7_4_7 = std::move(dir_p7_4_7), name_p4_5_7 = std::move(name_p4_5_7), in_test_p6_6_7 = std::move(in_test_p6_6_7)]() {
            return ({
                auto a_pu = p0;
                auto h_pv = p1;
                (prism_rtl::more(prism_rtl::rc(Child(has_p0_1_7, texts_p1_2_7, a_pu, main_p3_3_7, dir_p7_4_7, h_pv, name_p4_5_7, in_test_p6_6_7))));
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<TreeAcc> WalkModule::cycle() const {
    const auto& has_p0 = this->has_p0;
    const auto& texts_p1 = this->texts_p1;
    const auto& acc_p2 = this->acc_p2;
    const auto& main_p3 = this->main_p3;
    const auto& name_p4 = this->name_p4;
    const auto& parent_p5 = this->parent_p5;
    const auto& in_test_p6 = this->in_test_p6;
    auto dir_p7 = dir_of(main_p3);
    auto text_p8 = or_(crate::prelude::get(texts_p1, main_p3), Text::lit(""));
    auto heads_p9 = header_lines(text_p8);
    auto mods_pa = filter(heads_p9, [&](const HeadLine& h_pk) { return (prism_rtl::deref(h_pk).word == Text::lit("mod")) || (prism_rtl::deref(h_pk).word == Text::lit("test mod")); });
    auto subs_pb = filter(mods_pa, [&](const HeadLine& h_pl) { return crate::check::env::is_upper_text(prism_rtl::deref(h_pl).arg); });
    auto lower_pc = filter(mods_pa, [&](const HeadLine& h_pm) { return !crate::check::env::is_upper_text(prism_rtl::deref(h_pm).arg); });
    auto named_pd = name_p4 == Text::lit("")
        ? Text::lit("its path makes it the root")
        : prism_rtl::cat("its path names the module `", name_p4, "`");
    auto acc1_pe = fold(filter(heads_p9, [&](const HeadLine& h_pn) { return prism_rtl::deref(h_pn).word == Text::lit("module"); }), acc_p2, [&](const TreeAcc& a_po, const HeadLine& h_pp) { return add_tree_diag(a_po, main_p3, prism_rtl::deref(h_pp).span, Text::lit("module-line"), prism_rtl::cat("a module\'s file has no `module` line: ", named_pd), Text::lit("delete the line")); });
    auto leaf_pf = !crate::check::types::has_text(Array(std::vector{Text::lit("mod.prism"), Text::lit("app.prism"), Text::lit("lib.prism")}), base_of(main_p3));
    auto stem_pg = or_(crate::syntax::lexer::chars::before_suffix(base_of(main_p3), Text::lit(".prism")), main_p3);
    auto acc2_ph = std::move(leaf_pf)
        ? fold(mods_pa, acc1_pe, [&](const TreeAcc& a_pq, const HeadLine& h_pr) { return add_tree_diag(a_pq, main_p3, prism_rtl::deref(h_pr).span, Text::lit("mod-leaf"), prism_rtl::cat("`", base_of(main_p3), "` declares `", prism_rtl::deref(h_pr).word, " ", prism_rtl::deref(h_pr).arg, "`, and a module with children is a directory"), prism_rtl::cat("move ", base_of(main_p3), " to ", stem_pg, "/mod.prism")); })
        : acc1_pe;
    auto acc3_pi = fold(lower_pc, acc2_ph, [&](const TreeAcc& a_ps, const HeadLine& h_pt) { return lowercase(a_ps, main_p3, dir_p7, h_pt); });
    auto acc4_pj = ({
        TreeAcc this_ = acc3_pi;
        this_.declared = insert(this_.declared, main_p3, true);
        this_.units = crate::prelude::push(this_.units, ModFiles{.name = name_p4, .named = true, .segs = Array(std::vector{Seg{.path_ = main_p3, .text = text_p8, .role = prism_rtl::deref(in_test_p6) ? Text::lit("test") : Text::lit("main")}}), .parent = parent_p5});
        (std::move(this_));
    });
    return std::move(leaf_pf)
        ? prism_rtl::finished(acc4_pj)
        : fold_job(subs_pb, acc4_pj, ({
        auto has_p0_1 = has_p0;
        auto texts_p1_2 = texts_p1;
        auto main_p3_3 = main_p3;
        auto dir_p7_4 = dir_p7;
        auto name_p4_5 = name_p4;
        auto in_test_p6_6 = prism_rtl::deref(in_test_p6);
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<TreeAcc>(std::tuple<TreeAcc, HeadLine>)>>(prism_rtl::rc([=, has_p0_1 = std::move(has_p0_1), texts_p1_2 = std::move(texts_p1_2), main_p3_3 = std::move(main_p3_3), dir_p7_4 = std::move(dir_p7_4), name_p4_5 = std::move(name_p4_5), in_test_p6_6 = std::move(in_test_p6_6)](std::tuple<TreeAcc, HeadLine> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto has_p0_1_7 = has_p0_1;
            auto texts_p1_2_7 = texts_p1_2;
            auto main_p3_3_7 = main_p3_3;
            auto dir_p7_4_7 = dir_p7_4;
            auto name_p4_5_7 = name_p4_5;
            auto in_test_p6_6_7 = in_test_p6_6;
            entered(once_job([=, has_p0_1_7 = std::move(has_p0_1_7), texts_p1_2_7 = std::move(texts_p1_2_7), main_p3_3_7 = std::move(main_p3_3_7), dir_p7_4_7 = std::move(dir_p7_4_7), name_p4_5_7 = std::move(name_p4_5_7), in_test_p6_6_7 = std::move(in_test_p6_6_7)]() {
            return ({
                auto a_pu = p0;
                auto h_pv = p1;
                (prism_rtl::more(prism_rtl::rc(Child(has_p0_1_7, texts_p1_2_7, a_pu, main_p3_3_7, dir_p7_4_7, h_pv, name_p4_5_7, in_test_p6_6_7))));
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start WalkModule, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<TreeAcc> start_walk_module(Map<Text, bool> has_p0, Map<Text, Text> texts_p1, TreeAcc acc_p2, Text main_p3, Text name_p4, Text parent_p5, bool in_test_p6) {
    return prism_rtl::make_rc<WalkModule>(has_p0, texts_p1, acc_p2, main_p3, name_p4, parent_p5, in_test_p6);
}


/// Lowercase: fn TreeAcc, Text, Text, HeadLine -> TreeAcc
TreeAcc lowercase(const TreeAcc& a_p0, const Text& main_p1, const Text& dir_p2, const HeadLine& h_p3) {
    auto up_p4 = prism_rtl::cat(upper(crate::syntax::lexer::chars::head(h_p3.arg)), crate::syntax::lexer::chars::after_first(h_p3.arg));
    auto marked_p5 = ({
        TreeAcc this_ = a_p0;
        this_.declared = insert(this_.declared, under(dir_p2, prism_rtl::cat(h_p3.arg, ".prism")), true);
        (std::move(this_));
    });
    return add_tree_diag(marked_p5, main_p1, h_p3.span, Text::lit("mod-lowercase"), prism_rtl::cat("`", h_p3.word, " ", h_p3.arg, "`: a module\'s name is capitalised, and every `mod` line declares a module with a namespace of its own"), prism_rtl::cat("write `", h_p3.word, " ", up_p4, "` (its file ", h_p3.arg, ".prism, with a header of its own)"));
}


/// Child: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text, Text, HeadLine, Text, Bool -> TreeAcc
TreeAcc child(const Map<Text, bool>& has_p0, const Map<Text, Text>& texts_p1, const TreeAcc& acc_p2, const Text& main_p3, const Text& dir_p4, const HeadLine& h_p5, const Text& parent_p6, const bool& in_test_p7) {
    auto snake_p8 = dir_name(h_p5.arg);
    auto file_p9 = under(dir_p4, prism_rtl::cat(snake_p8, ".prism"));
    auto nested_pa = under(dir_p4, prism_rtl::cat(snake_p8, "/mod.prism"));
    auto name_pb = parent_p6 == Text::lit("")
        ? h_p5.arg
        : prism_rtl::cat(parent_p6, ".", h_p5.arg);
    auto is_test_pc = in_test_p7 || (h_p5.word == Text::lit("test mod"));
    auto line_pd = prism_rtl::cat(h_p5.word, " ", h_p5.arg);
    return (file_p9 == main_p3) || (nested_pa == main_p3)
        ? add_tree_diag(acc_p2, main_p3, h_p5.span, Text::lit("mod-self"), prism_rtl::cat("`", line_pd, "` names `", base_of(main_p3), "`, the file that declares it"), Text::lit("rename the module"))
        : crate::check::env::has_key(has_p0, file_p9) && crate::check::env::has_key(has_p0, nested_pa)
        ? ({
        auto both_pe = ({
            TreeAcc this_ = acc_p2;
            this_.declared = insert(insert(this_.declared, file_p9, true), nested_pa, true);
            (std::move(this_));
        });
        add_tree_diag(both_pe, main_p3, h_p5.span, Text::lit("mod-both"), prism_rtl::cat("`", line_pd, "` declares `", snake_p8, ".prism` or `", snake_p8, "/mod.prism`, and both are there"), prism_rtl::cat("keep one: ", snake_p8, "/mod.prism when the module has children, else ", snake_p8, ".prism"));
    })
        : crate::check::env::has_key(has_p0, file_p9)
        ? walk_module(has_p0, texts_p1, acc_p2, file_p9, name_pb, main_p3, is_test_pc)
        : crate::check::env::has_key(has_p0, nested_pa)
        ? walk_module(has_p0, texts_p1, acc_p2, nested_pa, name_pb, main_p3, is_test_pc)
        : add_tree_diag(acc_p2, main_p3, h_p5.span, Text::lit("mod-missing"), prism_rtl::cat("`", line_pd, "` declares `", snake_p8, ".prism` or `", snake_p8, "/mod.prism`, and neither is there"), prism_rtl::cat("create ", snake_p8, ".prism, or delete the line"));
}


prism_rtl::Turn<TreeAcc> Child::cycle() const {
    const auto& has_p0 = this->has_p0;
    const auto& texts_p1 = this->texts_p1;
    const auto& acc_p2 = this->acc_p2;
    const auto& main_p3 = this->main_p3;
    const auto& dir_p4 = this->dir_p4;
    const auto& h_p5 = this->h_p5;
    const auto& parent_p6 = this->parent_p6;
    const auto& in_test_p7 = this->in_test_p7;
    auto snake_p8 = dir_name(prism_rtl::deref(h_p5).arg);
    auto file_p9 = under(dir_p4, prism_rtl::cat(snake_p8, ".prism"));
    auto nested_pa = under(dir_p4, prism_rtl::cat(snake_p8, "/mod.prism"));
    auto name_pb = parent_p6 == Text::lit("")
        ? prism_rtl::deref(h_p5).arg
        : prism_rtl::cat(parent_p6, ".", prism_rtl::deref(h_p5).arg);
    auto is_test_pc = prism_rtl::deref(in_test_p7) || (prism_rtl::deref(h_p5).word == Text::lit("test mod"));
    auto line_pd = prism_rtl::cat(prism_rtl::deref(h_p5).word, " ", prism_rtl::deref(h_p5).arg);
    return (file_p9 == main_p3) || (nested_pa == main_p3)
        ? prism_rtl::finished(add_tree_diag(acc_p2, main_p3, prism_rtl::deref(h_p5).span, Text::lit("mod-self"), prism_rtl::cat("`", line_pd, "` names `", base_of(main_p3), "`, the file that declares it"), Text::lit("rename the module")))
        : crate::check::env::has_key(has_p0, file_p9) && crate::check::env::has_key(has_p0, nested_pa)
        ? ({
        auto both_pe = ({
            TreeAcc this_ = acc_p2;
            this_.declared = insert(insert(this_.declared, file_p9, true), nested_pa, true);
            (std::move(this_));
        });
        (prism_rtl::finished(add_tree_diag(both_pe, main_p3, prism_rtl::deref(h_p5).span, Text::lit("mod-both"), prism_rtl::cat("`", line_pd, "` declares `", snake_p8, ".prism` or `", snake_p8, "/mod.prism`, and both are there"), prism_rtl::cat("keep one: ", snake_p8, "/mod.prism when the module has children, else ", snake_p8, ".prism"))));
    })
        : crate::check::env::has_key(has_p0, file_p9)
        ? prism_rtl::more(prism_rtl::rc(WalkModule(has_p0, texts_p1, acc_p2, file_p9, name_pb, main_p3, std::move(is_test_pc))))
        : crate::check::env::has_key(has_p0, nested_pa)
        ? prism_rtl::more(prism_rtl::rc(WalkModule(has_p0, texts_p1, acc_p2, nested_pa, name_pb, main_p3, std::move(is_test_pc))))
        : prism_rtl::finished(add_tree_diag(acc_p2, main_p3, prism_rtl::deref(h_p5).span, Text::lit("mod-missing"), prism_rtl::cat("`", line_pd, "` declares `", snake_p8, ".prism` or `", snake_p8, "/mod.prism`, and neither is there"), prism_rtl::cat("create ", snake_p8, ".prism, or delete the line")));
}


/// `Start Child, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<TreeAcc> start_child(Map<Text, bool> has_p0, Map<Text, Text> texts_p1, TreeAcc acc_p2, Text main_p3, Text dir_p4, HeadLine h_p5, Text parent_p6, bool in_test_p7) {
    return prism_rtl::make_rc<Child>(has_p0, texts_p1, acc_p2, main_p3, dir_p4, h_p5, parent_p6, in_test_p7);
}


/// Stray: fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text -> TreeAcc
TreeAcc stray(const Map<Text, bool>& has_p0, const Map<Text, Text>& texts_p1, const TreeAcc& acc_p2, const Text& f_p3) {
    auto text_p4 = or_(crate::prelude::get(texts_p1, f_p3), Text::lit(""));
    return crate::syntax::lexer::chars::has_suffix(f_p3, Text::lit(".prismtest"))
        ? add_tree_diag(acc_p2, f_p3, no_span(), Text::lit("mod-stray"), prism_rtl::cat("`", base_of(f_p3), "` is a test script in a tree, where tests are in test modules"), Text::lit("put its declarations in a test module, declared by `test mod Tests`"))
        : ({
        auto dir_p5 = dir_of(f_p3);
        auto is_main_p6 = base_of(f_p3) == Text::lit("mod.prism");
        auto home_p7 = std::move(is_main_p6) ? dir_of(dir_p5) : dir_p5;
        auto main_p8 = fold(Array(std::vector{Text::lit("mod.prism"), Text::lit("app.prism"), Text::lit("lib.prism")}), Text::lit(""), [&](const Text& m_pb, const Text& n_pc) {
            return (m_pb == Text::lit("")) && crate::check::env::has_key(has_p0, under(home_p7, n_pc))
                ? n_pc
                : m_pb;
        });
        auto line_p9 = std::move(is_main_p6)
            ? prism_rtl::cat("mod ", mod_of_dir(base_of(dir_p5)))
            : prism_rtl::cat("mod ", mod_of_dir(or_(crate::syntax::lexer::chars::before_suffix(base_of(f_p3), Text::lit(".prism")), f_p3)));
        auto shown_pa = std::move(is_main_p6)
            ? prism_rtl::cat(base_of(dir_p5), "/mod.prism")
            : base_of(f_p3);
        main_p8 == Text::lit("")
        ? add_tree_diag(acc_p2, f_p3, no_span(), Text::lit("mod-stray"), prism_rtl::cat("`", f_p3, "` is in a tree, in no module\'s directory"), Text::lit("move it into a module\'s directory and declare it with a `mod` line"))
        : add_tree_diag(acc_p2, f_p3, no_span(), Text::lit("mod-stray"), prism_rtl::cat("`", shown_pa, "` is in the directory of `", main_p8, "`, which declares no `", line_p9, "`"), prism_rtl::cat("declare it with `", line_p9, "` in ", main_p8, ", or move it out of the directory"));
    });
}


/// ReachTree: unbounded fn [ModFiles], Text -> [ModFiles]
Array<ModFiles> reach_tree(const Array<ModFiles>& units_p0, const Text& main_p1) {
    auto by_name_p2 = fold(units_p0, Map<Text, ModFiles>{}, [&](const Map<Text, ModFiles>& m_p5, const ModFiles& u_p6) { return insert(m_p5, unit_name(u_p6), u_p6); });
    auto start_p3 = fold(units_p0, Array<Text>{}, [&](const Array<Text>& s_p7, const ModFiles& u_p8) {
        return (main_path(u_p8) == main_p1) || ((u_p8->parent == main_p1) && is_test_unit(u_p8))
            ? crate::prelude::push(s_p7, unit_name(u_p8))
            : s_p7;
    });
    auto reached_p4 = reach_names(by_name_p2, start_p3, start_p3);
    return filter(units_p0, [&](const ModFiles& u_p9) { return crate::check::types::has_text(reached_p4, unit_name(u_p9)); });
}


prism_rtl::Turn<Array<ModFiles>> ReachTree::cycle() const {
    const auto& units_p0 = this->units_p0;
    const auto& main_p1 = this->main_p1;
    auto by_name_p2 = fold(units_p0, Map<Text, ModFiles>{}, [&](const Map<Text, ModFiles>& m_p5, const ModFiles& u_p6) { return insert(m_p5, unit_name(u_p6), u_p6); });
    auto start_p3 = fold(units_p0, Array<Text>{}, [&](const Array<Text>& s_p7, const ModFiles& u_p8) {
        return (main_path(u_p8) == main_p1) || ((u_p8->parent == main_p1) && is_test_unit(u_p8))
            ? crate::prelude::push(s_p7, unit_name(u_p8))
            : s_p7;
    });
    auto units_p0_1 = units_p0;
    return call_then(start_reach_names(by_name_p2, start_p3, start_p3), [=](Array<Text> reach_names_22458) {
        return ({
            auto reached_p4 = reach_names_22458;
            (prism_rtl::finished(filter(units_p0_1, [&](const ModFiles& u_p9) { return crate::check::types::has_text(reached_p4, unit_name(u_p9)); })));
        });
    });
}


/// `Start ReachTree, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<ModFiles>> start_reach_tree(Array<ModFiles> units_p0, Text main_p1) {
    return prism_rtl::make_rc<ReachTree>(units_p0, main_p1);
}


/// ReachNames: unbounded fn (Text ==> ModFiles), [Text], [Text] -> [Text]
Array<Text> reach_names(const Map<Text, ModFiles>& by_name_p0, const Array<Text>& seen_p1, const Array<Text>& todo_p2) {
    auto&& _m = index(todo_p2, Nat(0u));
    if (prism_rtl::is_none(_m)) {
        return seen_p1;
    }
    if (prism_rtl::is_some(_m)) {
        auto&& n_p3 = prism_rtl::some_of(_m);
        auto uses_p4 = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = crate::prelude::get(by_name_p0, n_p3);
            if (prism_rtl::is_some(_m)) {
                auto&& u_p6 = prism_rtl::some_of(_m);
                _v.set(each(filter(header_lines(main_text(u_p6)), [&](const HeadLine& h_p7) { return prism_rtl::deref(h_p7).word == Text::lit("use"); }), [&](const HeadLine& h_p8) { return use_target(by_name_p0, prism_rtl::deref(h_p8).arg); }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto fresh_p5 = filter(uses_p4, [&](const Text& x_p9) { return (!crate::check::types::has_text(seen_p1, x_p9)) && crate::check::env::has_key(by_name_p0, x_p9); });
        return reach_names(by_name_p0, crate::check::types::union_texts(seen_p1, fresh_p5), append(drop(todo_p2, Nat(1u)), fresh_p5));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> ReachNames::cycle() const {
    const auto& by_name_p0 = this->by_name_p0;
    const auto& seen_p1 = this->seen_p1;
    const auto& todo_p2 = this->todo_p2;
    return ({
        auto&& _m = index(todo_p2, Nat(0u));
        prism_rtl::is_none(_m) ? prism_rtl::finished(seen_p1)
        : prism_rtl::is_some(_m) ? ({
        auto&& n_p3 = prism_rtl::some_of(_m);
        ({
        auto uses_p4 = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = crate::prelude::get(by_name_p0, n_p3);
            if (prism_rtl::is_some(_m)) {
                auto&& u_p6 = prism_rtl::some_of(_m);
                _v.set(each(filter(header_lines(main_text(u_p6)), [&](const HeadLine& h_p7) { return prism_rtl::deref(h_p7).word == Text::lit("use"); }), [&](const HeadLine& h_p8) { return use_target(by_name_p0, prism_rtl::deref(h_p8).arg); }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto fresh_p5 = filter(uses_p4, [&](const Text& x_p9) { return (!crate::check::types::has_text(seen_p1, x_p9)) && crate::check::env::has_key(by_name_p0, x_p9); });
        (prism_rtl::more(prism_rtl::rc(ReachNames(by_name_p0, crate::check::types::union_texts(seen_p1, fresh_p5), append(drop(todo_p2, Nat(1u)), fresh_p5)))));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ReachNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_reach_names(Map<Text, ModFiles> by_name_p0, Array<Text> seen_p1, Array<Text> todo_p2) {
    return prism_rtl::make_rc<ReachNames>(by_name_p0, seen_p1, todo_p2);
}


/// UseTarget: fn (Text ==> ModFiles), Text -> Text
Text use_target(const Map<Text, ModFiles>& by_name_p0, const Text& u_p1) {
    return (u_p1 == Text::lit("App")) && (!crate::check::env::has_key(by_name_p0, Text::lit("App")))
        ? Text::lit("")
        : u_p1;
}


/// IsTestUnit: fn ModFiles -> Bool
bool is_test_unit(const ModFiles& u_p0) {
    auto&& _m = index(u_p0.segs, Nat(0u));
    if (prism_rtl::is_some(_m)) {
        auto&& s_p1 = prism_rtl::some_of(_m);
        return prism_rtl::deref(s_p1).role == Text::lit("test");
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// UnitName: fn ModFiles -> Text
Text unit_name(const ModFiles& u_p0) {
    return u_p0.named
        ? u_p0.name
        : fold(header_lines(main_text(u_p0)), Text::lit(""), [&](const Text& n_p1, const HeadLine& h_p2) {
        return prism_rtl::deref(h_p2).word == Text::lit("module")
            ? prism_rtl::deref(h_p2).arg
            : n_p1;
    });
}


/// RenderTreeDiag: fn (Text ==> Text), TreeDiag -> Text
Text render_tree_diag(const Map<Text, Text>& texts_p0, const TreeDiag& d_p1) {
    return crate::check::errors::render_cdiag(Array(std::vector{crate::check::errors::mk_src(d_p1.path_, or_(crate::prelude::get(texts_p0, d_p1.path_), Text::lit("")))}), crate::check::errors::CDiag{.code = d_p1.code, .file = Nat(0u), .span = d_p1.span, .message = d_p1.message, .fix = d_p1.fix});
}


/// TreeReport: fn ReadInput, [TreeDiag] -> Text
Text tree_report(const ReadInput& input_p0, const Array<TreeDiag>& ds_p1) {
    auto texts_p2 = map(input_p0.texts);
    auto n_p3 = len(ds_p1);
    return prism_rtl::cat(concat(each(ds_p1, [&](const TreeDiag& d_p4) { return render_tree_diag(texts_p2, d_p4); })), n_p3, " error", n_p3 == Nat(1u) ? Text::lit("") : Text::lit("s"));
}


/// ParseUnit: unbounded fn ModFiles -> ((Src, Parsed))
std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed> parse_unit(const ModFiles& u_p0) {
    auto src_p1 = crate::check::errors::mk_joined_src(each(u_p0.segs, [&](const Seg& s_p5) { return std::tuple{s_p5->path_, s_p5->text, prism_rtl::deref(s_p5).role}; }));
    auto parsed_p2 = crate::syntax::parser::parse_file(src_p1->text);
    auto t0_p3 = prism_rtl::deref(parsed_p2).tree;
    auto tree_p4 = !u_p0.named
        ? t0_p3
        : ({
        crate::syntax::Module this_ = t0_p3;
        this_.name = u_p0.name == Text::lit("")
            ? std::optional<crate::syntax::QualName>{}
            : std::optional(crate::syntax::QualName{.path_ = split_on(u_p0.name, Text::lit(".")), .span = no_span()});
        (std::move(this_));
    });
    return std::tuple{src_p1, crate::syntax::parser::Parsed{.tree = tree_p4, .diags = prism_rtl::deref(parsed_p2).diags}};
}


prism_rtl::Turn<std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>> ParseUnit::cycle() const {
    const auto& u_p0 = this->u_p0;
    auto src_p1 = crate::check::errors::mk_joined_src(each(prism_rtl::deref(u_p0).segs, [&](const Seg& s_p5) { return std::tuple{s_p5->path_, s_p5->text, prism_rtl::deref(s_p5).role}; }));
    auto u_p0_1 = u_p0;
    return call_then(crate::syntax::parser::start_parse_file(src_p1->text), [=](crate::syntax::parser::Parsed parse_file_24471) {
        return ({
            auto parsed_p2 = parse_file_24471;
            auto t0_p3 = prism_rtl::deref(parsed_p2).tree;
            auto tree_p4 = !prism_rtl::deref(u_p0_1).named
                ? t0_p3
                : ({
                crate::syntax::Module this_ = t0_p3;
                this_.name = prism_rtl::deref(u_p0_1).name == Text::lit("")
                    ? std::optional<crate::syntax::QualName>{}
                    : std::optional(crate::syntax::QualName{.path_ = split_on(prism_rtl::deref(u_p0_1).name, Text::lit(".")), .span = no_span()});
                (std::move(this_));
            });
            (prism_rtl::finished(std::tuple{src_p1, crate::syntax::parser::Parsed{.tree = tree_p4, .diags = prism_rtl::deref(parsed_p2).diags}}));
        });
    });
}


/// `Start ParseUnit, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>> start_parse_unit(ModFiles u_p0) {
    return prism_rtl::make_rc<ParseUnit>(u_p0);
}


/// ParseProgram: unbounded fn Assembled -> ParsedProgram
ParsedProgram parse_program(const Assembled& read_p0) {
    auto parsed_p1 = run_to_end(each_job(read_p0.units, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>>(ModFiles)>>(prism_rtl::rc([=](ModFiles p0) {
        return entered(once_job([=]() {
            return ({
                auto u_p8 = p0;
                (prism_rtl::more(prism_rtl::rc(ParseUnit(u_p8))));
            });
        }));
    }))));
    auto user_mods_p2 = fold(parsed_p1, Array<Text>{}, [&](const Array<Text>& acc_p9, const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p1) {
        auto&& p_pa = std::get<1>(_p1);
        return crate::prelude::push(acc_p9, crate::check::env::mod_name(prism_rtl::deref(p_pa).tree));
    });
    auto user_fams_p3 = fold(parsed_p1, Array<Text>{}, [&](const Array<Text>& acc_pb, const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p1) {
        auto&& p_pc = std::get<1>(_p1);
        return append(acc_pb, tag_families(prism_rtl::deref(p_pc).tree));
    });
    auto pre_parsed_p4 = run_to_end(each_job(read_p0.prelude, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>>(ModFiles)>>(prism_rtl::rc([=](ModFiles p0) {
        return entered(once_job([=]() {
            return ({
                auto u_pd = p0;
                (prism_rtl::more(prism_rtl::rc(ParseUnit(u_pd))));
            });
        }));
    }))));
    auto kept_p5 = filter(pre_parsed_p4, [&](const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p0) {
        auto&& p_pe = std::get<1>(_p0);
        return (!crate::check::types::has_text(user_mods_p2, crate::check::env::mod_name(prism_rtl::deref(p_pe).tree))) && (!any_in(tag_families(prism_rtl::deref(p_pe).tree), user_fams_p3));
    });
    auto all_p6 = append(parsed_p1, kept_p5);
    auto errors_p7 = fold(all_p6, Text::lit(""), [&](const Text& acc_pf, const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p1) {
        auto&& src_pg = std::get<0>(_p1);
        auto&& p_ph = std::get<1>(_p1);
        return crate::program::any_errors(prism_rtl::deref(p_ph).diags)
            ? prism_rtl::cat(acc_pf, render_parse(src_pg, prism_rtl::deref(p_ph).diags))
            : acc_pf;
    });
    return ParsedProgram{.srcs = each(all_p6, [&](const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p0) {
        auto&& s_pi = std::get<0>(_p0);
        return s_pi;
    }), .trees = each(all_p6, [&](const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p0) {
        auto&& p_pj = std::get<1>(_p0);
        return prism_rtl::deref(p_pj).tree;
    }), .shown = len(parsed_p1), .parents = each(read_p0.units, [&](const ModFiles& u_pk) { return u_pk->parent; }), .errors = errors_p7};
}


prism_rtl::Turn<ParsedProgram> ParseProgram::cycle() const {
    const auto& read_p0 = this->read_p0;
    auto read_p0_1 = read_p0;
    return call_value(each_job(prism_rtl::deref(read_p0_1).units, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>>(ModFiles)>>(prism_rtl::rc([=](ModFiles p0) {
        return entered(once_job([=]() {
            return ({
                auto u_p8 = p0;
                (prism_rtl::more(prism_rtl::rc(ParseUnit(u_p8))));
            });
        }));
    }))), [=](Array<std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>> each_25155) {
        return ({
            auto parsed_p1 = each_25155;
            auto user_mods_p2 = fold(parsed_p1, Array<Text>{}, [&](const Array<Text>& acc_p9, const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p1) {
                auto&& p_pa = std::get<1>(_p1);
                return crate::prelude::push(acc_p9, crate::check::env::mod_name(prism_rtl::deref(p_pa).tree));
            });
            auto user_fams_p3 = fold(parsed_p1, Array<Text>{}, [&](const Array<Text>& acc_pb, const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p1) {
                auto&& p_pc = std::get<1>(_p1);
                return append(acc_pb, tag_families(prism_rtl::deref(p_pc).tree));
            });
            call_value(each_job(read_p0_1->prelude, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>>(ModFiles)>>(prism_rtl::rc([=](ModFiles p0) {
            return entered(once_job([=]() {
                return ({
                    auto u_pd = p0;
                    (prism_rtl::more(prism_rtl::rc(ParseUnit(u_pd))));
                });
            }));
        }))), [=, parsed_p1 = std::move(parsed_p1), user_mods_p2 = std::move(user_mods_p2), user_fams_p3 = std::move(user_fams_p3)](Array<std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>> each_25389) {
            return ({
                auto pre_parsed_p4 = each_25389;
                auto kept_p5 = filter(pre_parsed_p4, [&](const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p0) {
                    auto&& p_pe = std::get<1>(_p0);
                    return (!crate::check::types::has_text(user_mods_p2, crate::check::env::mod_name(prism_rtl::deref(p_pe).tree))) && (!any_in(tag_families(prism_rtl::deref(p_pe).tree), user_fams_p3));
                });
                auto all_p6 = append(parsed_p1, kept_p5);
                auto errors_p7 = fold(all_p6, Text::lit(""), [&](const Text& acc_pf, const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p1) {
                    auto&& src_pg = std::get<0>(_p1);
                    auto&& p_ph = std::get<1>(_p1);
                    return crate::program::any_errors(prism_rtl::deref(p_ph).diags)
                        ? prism_rtl::cat(acc_pf, render_parse(src_pg, prism_rtl::deref(p_ph).diags))
                        : acc_pf;
                });
                (prism_rtl::finished(ParsedProgram{.srcs = each(all_p6, [&](const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p0) {
                auto&& s_pi = std::get<0>(_p0);
                return s_pi;
            }), .trees = each(all_p6, [&](const std::tuple<crate::check::errors::Src, crate::syntax::parser::Parsed>& _p0) {
                auto&& p_pj = std::get<1>(_p0);
                return prism_rtl::deref(p_pj).tree;
            }), .shown = len(parsed_p1), .parents = each(prism_rtl::deref(read_p0_1).units, [&](const ModFiles& u_pk) { return u_pk->parent; }), .errors = errors_p7}));
            });
        });
        });
    });
}


/// `Start ParseProgram, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<ParsedProgram> start_parse_program(Assembled read_p0) {
    return prism_rtl::make_rc<ParseProgram>(read_p0);
}


/// TreeDeclDiags: fn ParsedProgram -> [CDiag]
Array<crate::check::errors::CDiag> tree_decl_diags(const ParsedProgram& pp_p0) {
    return fold(crate::check::errors::range0(pp_p0.shown), Array<crate::check::errors::CDiag>{}, [&](const Array<crate::check::errors::CDiag>& acc_p1, const Nat& i_p2) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::errors::CDiag>> _v;
            auto&& _m = index(pp_p0.srcs, i_p2);
            if (prism_rtl::is_some(_m)) {
                auto&& src_p3 = prism_rtl::some_of(_m);
                _v.set(fold(prism_rtl::deref(or_(index(pp_p0.trees, i_p2), crate::check::env::empty_module())).decls, acc_p1, [&](const Array<crate::check::errors::CDiag>& a_p4, const crate::syntax::decls::Decl& d_p5) { return append(a_p4, decl_role_diags(src_p3, or_(index(pp_p0.parents, i_p2), Text::lit("")), i_p2, d_p5)); }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(acc_p1);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// DeclRoleDiags: fn Src, Text, Nat, Decl -> [CDiag]
Array<crate::check::errors::CDiag> decl_role_diags(const crate::check::errors::Src& src_p0, const Text& parent_p1, const Nat& i_p2, const crate::syntax::decls::Decl& d_p3) {
    auto seg_p4 = crate::check::errors::seg_at(src_p0, prism_rtl::deref(d_p3.span).start);
    auto role_p5 = prism_rtl::deref(seg_p4).role;
    auto main_p6 = base_of(src_p0.path_);
    auto tested_p7 = (seg_p4->path_ == src_p0.path_) && (parent_p1 != Text::lit(""))
        ? base_of(parent_p1)
        : main_p6;
    auto what_p8 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = d_p3.kind;
        if (prism_rtl::is<crate::syntax::decls::DeclKind::DTest>(_m)) {
            _v.set(Text::lit("test"));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::decls::DeclKind::DCheck>(_m)) {
            _v.set(Text::lit("check"));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::decls::DeclKind::DTag>(_m)) {
            _v.set(Text::lit("tag"));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::decls::DeclKind::DTrait>(_m)) {
            _v.set(Text::lit("trait"));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::decls::DeclKind::DImpl>(_m)) {
            _v.set(Text::lit("impl"));
            goto _done;
        }
        {
            _v.set(Text::lit(""));
            goto _done;
        }
    _done:
        _v.take();
    });
    return (role_p5 == Text::lit("main")) && ((what_p8 == Text::lit("test")) || (what_p8 == Text::lit("check")))
        ? Array(std::vector{crate::check::errors::CDiag{.code = Text::lit("test-outside"), .file = i_p2, .span = d_p3.span, .message = prism_rtl::cat("a `", what_p8, "` in a tree stands only in a test module"), .fix = prism_rtl::cat("move it to a test module: `test mod Tests` in ", main_p6, ", and tests.prism")}})
        : (role_p5 == Text::lit("test")) && (((what_p8 == Text::lit("tag")) || (what_p8 == Text::lit("trait"))) || (what_p8 == Text::lit("impl")))
        ? Array(std::vector{crate::check::errors::CDiag{.code = Text::lit("test-declares"), .file = i_p2, .span = d_p3.span, .message = Text::lit("a test module declares no tag, trait or impl"), .fix = prism_rtl::cat("declare it in ", tested_p7, ", the module the test module tests")}})
        : Array<crate::check::errors::CDiag>{};
}


/// TagFamilies: fn Module -> [Text]
Array<Text> tag_families(const crate::syntax::Module& m_p0) {
    return fold(m_p0.decls, Array<Text>{}, [&](const Array<Text>& acc_p1, const crate::syntax::decls::Decl& d_p2) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = prism_rtl::deref(d_p2).kind;
            if (prism_rtl::is<crate::syntax::decls::DeclKind::DTag>(_m)) {
                auto&& t_p3 = prism_rtl::as<crate::syntax::decls::DeclKind::DTag>(_m).a0;
                _v.set(crate::prelude::push(acc_p1, crate::syntax::lexer::chars::join(take(prism_rtl::deref(t_p3).name->path_, crate::syntax::lexer::chars::dec(len(prism_rtl::deref(t_p3).name->path_))), Text::lit("."))));
                goto _done;
            }
            {
                _v.set(acc_p1);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// AnyIn: fn [Text], [Text] -> Bool
bool any_in(const Array<Text>& xs_p0, const Array<Text>& ys_p1) {
    return fold(xs_p0, false, [&](const bool& seen_p2, const Text& x_p3) { return prism_rtl::deref(seen_p2) || crate::check::types::has_text(ys_p1, x_p3); });
}


/// RenderParse: fn Src, [Diag] -> Text
Text render_parse(const crate::check::errors::Src& src_p0, const Array<crate::syntax::Diag>& ds_p1) {
    return concat(each(filter(ds_p1, [&](const crate::syntax::Diag& d_p2) { return prism_rtl::deref(d_p2).stage != Text::lit("out"); }), [&](const crate::syntax::Diag& d_p3) { return prism_rtl::cat(crate::check::errors::src_place(src_p0, prism_rtl::deref(prism_rtl::deref(d_p3).span).start), ":", crate::syntax::lexer::chars::column_of(src_p0.text, or_(index(src_p0.starts, crate::check::errors::cline_of(src_p0.starts, prism_rtl::deref(prism_rtl::deref(d_p3).span).start)), Nat(0u)), prism_rtl::deref(prism_rtl::deref(d_p3).span).start) + Nat(1u), ": ", prism_rtl::deref(d_p3).message, "\n"); }));
}

}  // namespace crate::reading
