// The module `Syntax.Parser.Decls`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Syntax.Parser.Decls`, from `target/bootstrap/cpp-src/prismc/syntax/parser/decls.prism`.
namespace crate::syntax::parser::decls {

void ModRead::show(Printer& p) const {
    p.record("ModRead", {{"p", p_}, {"m", m}, {"stage", stage}});
}

Pod ModRead::to_pod() const {
    return Pod::record("ModRead", {{"p", prism_rtl::to_pod(p_)}, {"m", prism_rtl::to_pod(m)}, {"stage", prism_rtl::to_pod(stage)}});
}

Result<ModRead> ModRead::from_pod(const Pod& whole) {
    return ModRead{.p_ = TRY(prism_rtl::from_pod<crate::syntax::parser::Ps>(TRY(crate::prelude::field(whole, "p")))), .m = TRY(prism_rtl::from_pod<crate::syntax::Module>(TRY(crate::prelude::field(whole, "m")))), .stage = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "stage"))))};
}


/// ParseModule: unbounded fn Ps, Bool -> ((Module, Ps))
std::tuple<crate::syntax::Module, crate::syntax::parser::Ps> parse_module(const crate::syntax::parser::Ps& p0, const bool& fragment) {
    auto start = crate::syntax::parser::here(p0);
    auto [template_opt, p1] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<std::optional<crate::syntax::Template>, crate::syntax::parser::Ps>> _v;
        auto&& _m = crate::syntax::parser::kind(p0);
        if (prism_rtl::is<crate::syntax::lexer::TokKind::KTemplate>(_m)) {
            auto&& t = prism_rtl::as<crate::syntax::lexer::TokKind::KTemplate>(_m).a0;
            _v.set(({
                auto [tpl, q] = crate::syntax::parser::expr::parse_template(crate::syntax::parser::adv(p0), t, crate::syntax::parser::here(p0));
                std::tuple{std::optional(tpl), q};
            }));
            goto _done;
        }
        {
            _v.set(std::tuple{std::optional<crate::syntax::Template>{}, p0});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto m0 = crate::syntax::Module{.name = std::optional<crate::syntax::QualName>{}, .emit_row = std::optional<crate::syntax::Row_>{}, .mods = Array<crate::syntax::ModLine>{}, .uses = Array<crate::syntax::Use>{}, .decls = Array<crate::syntax::decls::Decl>{}, .template_ = template_opt, .span = start};
    auto r = ({
        ModRead this_ = ModRead{.p_ = p1, .m = m0, .stage = Nat(0u)};
        while (!crate::syntax::parser::at_eof(this_.p_)) {
            this_ = module_item(this_, fragment);
        }
        (std::move(this_));
    });
    auto m = ({
        crate::syntax::Module this_ = r->m;
        this_.span = crate::syntax::parser::to(start, crate::syntax::parser::prev(prism_rtl::deref(r).p_));
        (std::move(this_));
    });
    return std::tuple{m, prism_rtl::deref(r).p_};
}


prism_rtl::Turn<std::tuple<crate::syntax::Module, crate::syntax::parser::Ps>> ParseModule::cycle() const {
    const auto& p0 = this->p0;
    const auto& fragment = this->fragment;
    auto start = crate::syntax::parser::here(p0);
    auto [template_opt, p1] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<std::optional<crate::syntax::Template>, crate::syntax::parser::Ps>> _v;
        auto&& _m = crate::syntax::parser::kind(p0);
        if (prism_rtl::is<crate::syntax::lexer::TokKind::KTemplate>(_m)) {
            auto&& t = prism_rtl::as<crate::syntax::lexer::TokKind::KTemplate>(_m).a0;
            _v.set(({
                auto [tpl, q] = crate::syntax::parser::expr::parse_template(crate::syntax::parser::adv(p0), t, crate::syntax::parser::here(p0));
                std::tuple{std::optional(tpl), q};
            }));
            goto _done;
        }
        {
            _v.set(std::tuple{std::optional<crate::syntax::Template>{}, p0});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto m0 = crate::syntax::Module{.name = std::optional<crate::syntax::QualName>{}, .emit_row = std::optional<crate::syntax::Row_>{}, .mods = Array<crate::syntax::ModLine>{}, .uses = Array<crate::syntax::Use>{}, .decls = Array<crate::syntax::decls::Decl>{}, .template_ = template_opt, .span = start};
    ModRead this_ = ModRead{.p_ = p1, .m = m0, .stage = Nat(0u)};
    auto start_1 = start;
    return call_then(loop_job(std::tuple{std::move(this_)}, ({
        auto fragment_2 = prism_rtl::deref(fragment);
        [=, fragment_2 = std::move(fragment_2)](std::tuple<ModRead> _p0) {
        auto this_ = std::get<0>(_p0);
        return !crate::syntax::parser::at_eof(prism_rtl::deref(this_).p_)
            ? ({
            this_ = module_item(this_, fragment_2);
            Expected<std::tuple<ModRead>, std::tuple<ModRead>>(std::tuple{this_});
        })
            : Expected<std::tuple<ModRead>, std::tuple<ModRead>>(unexpected(std::tuple{this_}));
    };
    })), [=](std::tuple<ModRead> _p0) {
        auto this_ = std::get<0>(_p0);
        return ({
            auto r = this_;
            auto m = ({
                crate::syntax::Module this_ = r->m;
                this_.span = crate::syntax::parser::to(start_1, crate::syntax::parser::prev(prism_rtl::deref(r).p_));
                (std::move(this_));
            });
            (prism_rtl::finished(std::tuple{m, prism_rtl::deref(r).p_}));
        });
    });
}


/// `Start ParseModule, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Module, crate::syntax::parser::Ps>> start_parse_module(crate::syntax::parser::Ps p0, bool fragment) {
    return prism_rtl::make_rc<ParseModule>(p0, fragment);
}


/// ModuleItem: unbounded fn ModRead, Bool -> ModRead
ModRead module_item(const ModRead& s, const bool& fragment) {
    return crate::syntax::parser::at_sep(s.p_)
        ? ({
        ModRead this_ = s;
        this_.p_ = crate::syntax::parser::adv(this_.p_);
        (std::move(this_));
    })
        : ({
        auto s1 = header_or_decl(s, fragment, crate::syntax::parser::here(s.p_));
        auto p2 = crate::syntax::parser::recovered(prism_rtl::deref(s1).p_);
        auto p3 = crate::syntax::parser::at_close_l(p2)
            ? crate::syntax::parser::adv(p2)
            : crate::syntax::parser::at_eof(p2)
            ? p2
            : crate::syntax::parser::expect_stmt_end(p2, Text::lit("declaration"));
        ({
        ModRead this_ = s1;
        this_.p_ = p3;
        (std::move(this_));
    });
    });
}


prism_rtl::Turn<ModRead> ModuleItem::cycle() const {
    const auto& s = this->s;
    const auto& fragment = this->fragment;
    return crate::syntax::parser::at_sep(prism_rtl::deref(s).p_)
        ? prism_rtl::finished(({
        ModRead this_ = s;
        this_.p_ = crate::syntax::parser::adv(this_.p_);
        (std::move(this_));
    }))
        : ({
        auto fragment_1 = prism_rtl::deref(fragment);
        auto s_2 = s;
        call_then(start_header_or_decl(s_2, std::move(fragment_1), crate::syntax::parser::here(prism_rtl::deref(s_2).p_)), [=](ModRead header_or_decl_1962) {
        return ({
            auto s1 = header_or_decl_1962;
            call_then(crate::syntax::parser::start_recovered(prism_rtl::deref(s1).p_), [=](crate::syntax::parser::Ps recovered_2016) {
            return ({
                auto p2 = recovered_2016;
                auto p3 = crate::syntax::parser::at_close_l(p2)
                    ? crate::syntax::parser::adv(p2)
                    : crate::syntax::parser::at_eof(p2)
                    ? p2
                    : crate::syntax::parser::expect_stmt_end(p2, Text::lit("declaration"));
                (prism_rtl::finished(({
                ModRead this_ = s1;
                this_.p_ = p3;
                (std::move(this_));
            })));
            });
        });
        });
    });
    });
}


/// `Start ModuleItem, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<ModRead> start_module_item(ModRead s, bool fragment) {
    return prism_rtl::make_rc<ModuleItem>(s, fragment);
}


/// HeaderOrDecl: unbounded fn ModRead, Bool, Range -> ModRead
ModRead header_or_decl(const ModRead& s, const bool& fragment, const crate::syntax::Range& item_start) {
    auto&& _m = crate::syntax::parser::kind(s.p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m2338_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m2338_0_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m2338_0_0 == Text::lit("module")) {
            if (m2338_0_1 == Text::lit("")) {
                auto [name, p_] = crate::syntax::parser::parse_qual_name(crate::syntax::parser::adv(s.p_));
                return p_->bad
                    ? ({
                    ModRead this_ = s;
                    this_.p_ = p_;
                    (std::move(this_));
                })
                    : ({
                    auto late = (s.stage > Nat(0u)) || (prism_rtl::deref(s.m).name != std::optional<crate::syntax::QualName>{});
                    ({
                    ModRead this_ = s;
                    this_.p_ = std::move(late)
                        ? crate::syntax::parser::note_error(p_, item_start, Text::lit("the `module` line comes first in a file"))
                        : p_;
                    prism_rtl::deref(this_.m).name = std::optional(name);
                    this_.stage = Nat(1u);
                    (std::move(this_));
                });
                });
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m2338_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m2338_1_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m2338_1_0 == Text::lit("emit")) {
            if (m2338_1_1 == Text::lit("")) {
                auto [emit_row, p_] = crate::syntax::parser::types::parse_row(crate::syntax::parser::adv(s.p_));
                return p_->bad
                    ? ({
                    ModRead this_ = s;
                    this_.p_ = p_;
                    (std::move(this_));
                })
                    : ({
                    auto late = (s.stage > Nat(1u)) || (prism_rtl::deref(s.m).emit_row != std::optional<crate::syntax::Row_>{});
                    ({
                    ModRead this_ = s;
                    this_.p_ = std::move(late)
                        ? crate::syntax::parser::note_error(p_, item_start, Text::lit("`emit` comes after `module` and above `use`, once (Semantics ch. 6)"))
                        : p_;
                    prism_rtl::deref(this_.m).emit_row = std::optional(emit_row);
                    this_.stage = Nat(2u);
                    (std::move(this_));
                });
                });
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m2338_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m2338_2_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m2338_2_0 == Text::lit("use")) {
            if (m2338_2_1 == Text::lit("")) {
                auto [u, p_] = parse_use(crate::syntax::parser::adv(s.p_), item_start);
                return p_->bad
                    ? ({
                    ModRead this_ = s;
                    this_.p_ = p_;
                    (std::move(this_));
                })
                    : ({
                    ModRead this_ = s;
                    this_.p_ = s.stage > Nat(4u)
                        ? crate::syntax::parser::note_error(p_, item_start, Text::lit("`use` lines belong to the header, above the declarations"))
                        : p_;
                    prism_rtl::deref(this_.m).uses = crate::prelude::push(prism_rtl::deref(this_.m).uses, u);
                    this_.stage = Nat(4u);
                    (std::move(this_));
                });
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m2338_3_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m2338_3_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m2338_3_0 == Text::lit("mod")) {
            if (m2338_3_1 == Text::lit("")) {
                return mod_header(s, crate::syntax::parser::adv(s.p_), false, item_start);
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m2338_4_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m2338_4_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m2338_4_0 == Text::lit("test")) {
            if (m2338_4_1 == Text::lit("")) {
                if (is_kw_kind(crate::syntax::parser::kind(crate::syntax::parser::adv(s.p_)), Text::lit("mod"))) {
                    return mod_header(s, crate::syntax::parser::adv(crate::syntax::parser::adv(s.p_)), true, item_start);
                }
            }
        }
    }
    {
        auto [d, p_] = parse_decl(s.p_, fragment);
        ModRead this_ = s;
        this_.p_ = p_;
        this_.stage = Nat(5u);
        if (!p_->bad) {
            prism_rtl::deref(this_.m).decls = crate::prelude::push(prism_rtl::deref(this_.m).decls, d);
        }
        return this_;
    }
}


prism_rtl::Turn<ModRead> HeaderOrDecl::cycle() const {
    const auto& s = this->s;
    const auto& fragment = this->fragment;
    const auto& item_start = this->item_start;
    return ({
        auto&& _m = crate::syntax::parser::kind(prism_rtl::deref(s).p_);
        prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m2338_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m2338_0_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m2338_0_0 == Text::lit("module")) && (m2338_0_1 == Text::lit(""));
    }) ? ({
        auto&& m2338_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m2338_0_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto [name, p_] = crate::syntax::parser::parse_qual_name(crate::syntax::parser::adv(prism_rtl::deref(s).p_));
        p_->bad
        ? prism_rtl::finished(({
        ModRead this_ = s;
        this_.p_ = p_;
        (std::move(this_));
    }))
        : ({
        auto late = (prism_rtl::deref(s).stage > Nat(0u)) || (prism_rtl::deref(s->m).name != std::optional<crate::syntax::QualName>{});
        (prism_rtl::finished(({
        ModRead this_ = s;
        this_.p_ = std::move(late)
            ? crate::syntax::parser::note_error(p_, item_start, Text::lit("the `module` line comes first in a file"))
            : p_;
        prism_rtl::deref(this_.m).name = std::optional(name);
        this_.stage = Nat(1u);
        (std::move(this_));
    })));
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m2338_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m2338_1_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m2338_1_0 == Text::lit("emit")) && (m2338_1_1 == Text::lit(""));
    }) ? ({
        auto&& m2338_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m2338_1_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto item_start_1 = item_start;
        auto s_2 = s;
        call_then(crate::syntax::parser::types::start_parse_row(crate::syntax::parser::adv(prism_rtl::deref(s_2).p_)), [=, item_start_1 = std::move(item_start_1)](std::tuple<crate::syntax::Row_, crate::syntax::parser::Ps> parse_row_2789) {
        return ({
            auto [emit_row, p_] = parse_row_2789;
            p_->bad
            ? prism_rtl::finished(({
            ModRead this_ = s_2;
            this_.p_ = p_;
            (std::move(this_));
        }))
            : ({
            auto late = (prism_rtl::deref(s_2).stage > Nat(1u)) || (prism_rtl::deref(s_2->m).emit_row != std::optional<crate::syntax::Row_>{});
            (prism_rtl::finished(({
            ModRead this_ = s_2;
            this_.p_ = std::move(late)
                ? crate::syntax::parser::note_error(p_, item_start_1, Text::lit("`emit` comes after `module` and above `use`, once (Semantics ch. 6)"))
                : p_;
            prism_rtl::deref(this_.m).emit_row = std::optional(emit_row);
            this_.stage = Nat(2u);
            (std::move(this_));
        })));
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m2338_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m2338_2_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m2338_2_0 == Text::lit("use")) && (m2338_2_1 == Text::lit(""));
    }) ? ({
        auto&& m2338_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m2338_2_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto [u, p_] = parse_use(crate::syntax::parser::adv(prism_rtl::deref(s).p_), item_start);
        p_->bad
        ? prism_rtl::finished(({
        ModRead this_ = s;
        this_.p_ = p_;
        (std::move(this_));
    }))
        : prism_rtl::finished(({
        ModRead this_ = s;
        this_.p_ = prism_rtl::deref(s).stage > Nat(4u)
            ? crate::syntax::parser::note_error(p_, item_start, Text::lit("`use` lines belong to the header, above the declarations"))
            : p_;
        prism_rtl::deref(this_.m).uses = crate::prelude::push(prism_rtl::deref(this_.m).uses, u);
        this_.stage = Nat(4u);
        (std::move(this_));
    }));
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m2338_3_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m2338_3_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m2338_3_0 == Text::lit("mod")) && (m2338_3_1 == Text::lit(""));
    }) ? ({
        auto&& m2338_3_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m2338_3_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        prism_rtl::finished(mod_header(s, crate::syntax::parser::adv(prism_rtl::deref(s).p_), false, item_start));
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m2338_4_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m2338_4_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m2338_4_0 == Text::lit("test")) && (m2338_4_1 == Text::lit("")) && is_kw_kind(crate::syntax::parser::kind(crate::syntax::parser::adv(prism_rtl::deref(s).p_)), Text::lit("mod"));
    }) ? ({
        auto&& m2338_4_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m2338_4_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        prism_rtl::finished(mod_header(s, crate::syntax::parser::adv(crate::syntax::parser::adv(prism_rtl::deref(s).p_)), true, item_start));
    })
        : ({
        auto fragment_1 = prism_rtl::deref(fragment);
        auto s_2 = s;
        call_then(start_parse_decl(prism_rtl::deref(s_2).p_, std::move(fragment_1)), [=](std::tuple<crate::syntax::decls::Decl, crate::syntax::parser::Ps> parse_decl_3725) {
        return ({
            auto [d, p_] = parse_decl_3725;
            (prism_rtl::finished(({
            ModRead this_ = s_2;
            this_.p_ = p_;
            this_.stage = Nat(5u);
            if (!p_->bad) {
                prism_rtl::deref(this_.m).decls = crate::prelude::push(prism_rtl::deref(this_.m).decls, d);
            }
            (std::move(this_));
        })));
        });
    });
    });
    });
}


/// `Start HeaderOrDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<ModRead> start_header_or_decl(ModRead s, bool fragment, crate::syntax::Range item_start) {
    return prism_rtl::make_rc<HeaderOrDecl>(s, fragment, item_start);
}


/// ModHeader: fn ModRead, Ps, Bool, Range -> ModRead
ModRead mod_header(const ModRead& s, const crate::syntax::parser::Ps& p_, const bool& is_test, const crate::syntax::Range& item_start) {
    auto&& _m = crate::syntax::parser::kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        if ((prism_rtl::deref(n).sigils == Text::lit("")) && (len(n->path_) == Nat(1u))) {
            auto line = crate::syntax::ModLine{.name = crate::syntax::Ident{.name = or_(index(n->path_, Nat(0u)), Text::lit("")), .span = crate::syntax::parser::here(p_)}, .is_test = is_test, .span = crate::syntax::parser::to(item_start, crate::syntax::parser::here(p_))};
            ModRead this_ = s;
            this_.p_ = s.stage > Nat(3u)
                ? crate::syntax::parser::note_error(crate::syntax::parser::adv(p_), item_start, Text::lit("`mod` lines come after `emit` and above `use` (claude/modules-style-pass.md)"))
                : crate::syntax::parser::adv(p_);
            prism_rtl::deref(this_.m).mods = crate::prelude::push(prism_rtl::deref(this_.m).mods, line);
            this_.stage = Nat(3u);
            return this_;
        }
    }
    {
        ModRead this_ = s;
        this_.p_ = crate::syntax::parser::error_here(p_, is_test
            ? Text::lit("expected a test module\'s name after `test mod`")
            : Text::lit("expected a module\'s name after `mod`"));
        return this_;
    }
}


/// IsKwKind: fn TokKind, Text -> Bool
bool is_kw_kind(const crate::syntax::lexer::TokKind& k, const Text& w) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(k)) {
        auto&& x = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(k).a0;
        return x == w;
    }
    {
        return false;
    }
}


/// let noQual
crate::syntax::QualName no_qual() {
    return crate::syntax::QualName{.path_ = Array<Text>{}, .span = crate::syntax::parser::no_range()};
}


/// ParseUse: fn Ps, Range -> ((Use, Ps))
std::tuple<crate::syntax::Use, crate::syntax::parser::Ps> parse_use(const crate::syntax::parser::Ps& p_, const crate::syntax::Range& start) {
    auto&& _m = crate::syntax::parser::kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFamily>(_m)) {
        auto&& path_ = prism_rtl::as<crate::syntax::lexer::TokKind::KFamily>(_m).a0;
        return std::tuple{crate::syntax::Use{.target = crate::syntax::QualName{.path_ = path_, .span = crate::syntax::parser::here(p_)}, .star = true, .span = crate::syntax::parser::to(start, crate::syntax::parser::here(p_))}, crate::syntax::parser::adv(p_)};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        if ((prism_rtl::deref(n).sigils == Text::lit("")) && (prism_rtl::deref(n).case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseUpper{}))) {
            return std::tuple{crate::syntax::Use{.target = crate::syntax::QualName{.path_ = n->path_, .span = crate::syntax::parser::here(p_)}, .star = false, .span = crate::syntax::parser::to(start, crate::syntax::parser::here(p_))}, crate::syntax::parser::adv(p_)};
        }
    }
    {
        return std::tuple{crate::syntax::Use{.target = no_qual(), .star = false, .span = crate::syntax::parser::no_range()}, crate::syntax::parser::error_here(p_, Text::lit("expected a module name after `use`"))};
    }
}


/// let noExpr
crate::syntax::Expr no_expr() {
    return crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = crate::syntax::parser::no_range()};
}


/// let noType
crate::syntax::Type no_type() {
    return crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TAbsent{})), .span = crate::syntax::parser::no_range()};
}


/// let noPattern
crate::syntax::Pattern_ no_pattern() {
    return crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span = crate::syntax::parser::no_range()};
}


/// let noBlock
crate::syntax::Block no_block() {
    return crate::syntax::Block{.stmts = Array<crate::syntax::Stmt>{}, .inline_ = true, .span = crate::syntax::parser::no_range()};
}


/// ParseDecl: unbounded fn Ps, Bool -> ((Decl, Ps))
std::tuple<crate::syntax::decls::Decl, crate::syntax::parser::Ps> parse_decl(const crate::syntax::parser::Ps& p_, const bool& fragment) {
    auto start = crate::syntax::parser::here(p_);
    auto [kind, q] = decl_kind_of(p_, fragment, start);
    return std::tuple{crate::syntax::decls::Decl{.kind = kind, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(q))}, q};
}


prism_rtl::Turn<std::tuple<crate::syntax::decls::Decl, crate::syntax::parser::Ps>> ParseDecl::cycle() const {
    const auto& p_ = this->p_;
    const auto& fragment = this->fragment;
    auto start = crate::syntax::parser::here(p_);
    auto fragment_1 = prism_rtl::deref(fragment);
    auto p__2 = p_;
    return call_then(start_decl_kind_of(p__2, std::move(fragment_1), start), [=](std::tuple<crate::syntax::decls::DeclKind, crate::syntax::parser::Ps> decl_kind_of_5602) {
        return ({
            auto [kind, q] = decl_kind_of_5602;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::Decl{.kind = kind, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(q))}, q}));
        });
    });
}


/// `Start ParseDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::decls::Decl, crate::syntax::parser::Ps>> start_parse_decl(crate::syntax::parser::Ps p_, bool fragment) {
    return prism_rtl::make_rc<ParseDecl>(p_, fragment);
}


/// DeclKindOf: unbounded fn Ps, Bool, Range -> ((DeclKind, Ps))
std::tuple<crate::syntax::decls::DeclKind, crate::syntax::parser::Ps> decl_kind_of(const crate::syntax::parser::Ps& p_, const bool& fragment, const crate::syntax::Range& start) {
    auto&& _m = crate::syntax::parser::kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m5783_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        if (m5783_0_0 == Text::lit("type")) {
            auto [d, q] = parse_type_decl(p_);
            return std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DType{d}), q};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m5783_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        if (m5783_1_0 == Text::lit("tag")) {
            auto [d, q] = parse_tag_decl(p_);
            return std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DTag{d}), q};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m5783_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        if (m5783_2_0 == Text::lit("derive")) {
            auto [traits, q] = crate::syntax::parser::commas(crate::syntax::parser::adv(p_), ({
                auto f = prism_rtl::rc(crate::syntax::parser::parse_trait_ref);
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::TraitRef, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([=, f = std::move(f)](crate::syntax::parser::Ps a0) {
                return ({
                    auto f_1 = f;
                    once_job([=, f_1 = std::move(f_1)]() { return prism_rtl::finished(f_1(a0)); });
                });
            }));
            }));
            return std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DDerive{traits}), q};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m5783_3_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        if (m5783_3_0 == Text::lit("trait")) {
            auto [d, q] = parse_trait_decl(p_);
            return std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DTrait{d}), q};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m5783_4_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        if (m5783_4_0 == Text::lit("impl")) {
            auto [d, q] = parse_impl_decl(p_);
            return std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DImpl{d}), q};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m5783_5_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        if (m5783_5_0 == Text::lit("check")) {
            auto [d, q] = crate::syntax::parser::test_language::parse_check_decl(p_);
            return std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DCheck{d}), q};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m5783_6_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        if (m5783_6_0 == Text::lit("test")) {
            auto [d, q] = crate::syntax::parser::test_language::parse_test_decl(p_);
            return std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DTest{d}), q};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m5783_7_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        if (m5783_7_0 == Text::lit("fn")) {
            auto [d, q] = parse_fn_clause(p_);
            return std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DFn{d}), q};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m5783_8_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        if (m5783_8_0 == Text::lit("let")) {
            auto [pattern, p1] = crate::syntax::parser::types::parse_pattern(crate::syntax::parser::adv(p_), false);
            auto [ty_opt, p2] = optional_annotation(p1);
            auto [value, p3] = crate::syntax::parser::expr::parse_rhs_expr(crate::syntax::parser::expect_op(p2, Text::lit("=")));
            return std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DLet{crate::syntax::decls::LetDecl{.pattern = pattern, .ty = ty_opt, .value = value, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(p3))}}), p3};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        if (crate::syntax::parser::kind_at(p_, Nat(1u)) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KColon{})) {
            return crate::syntax::parser::kind_at(p_, Nat(2u)) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLayOpen{})
                ? ({
                auto [name, p1] = crate::syntax::parser::parse_sname(p_);
                auto [body, p2] = crate::syntax::parser::blocks::parse_block_after_colon(p1);
                std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DWidget{crate::syntax::decls::WidgetDecl{.name = name, .body = body, .span = crate::syntax::parser::to(start, prism_rtl::deref(body).span)}}), p2};
            })
                : ({
                auto [sig, q] = parse_signature(p_);
                std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DSignature{sig}), q};
            });
        }
    }
    {
        return fragment
            ? ({
            auto [st, q] = crate::syntax::parser::blocks::parse_stmt(p_);
            std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DStmt{st}), q};
        })
            : ({
            auto [st, q] = crate::syntax::parser::blocks::parse_stmt(p_);
            ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<crate::syntax::decls::DeclKind, crate::syntax::parser::Ps>> _v;
            auto&& _m = prism_rtl::deref(st).kind;
            if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m)) {
                if (!q->bad) {
                    _v.set(std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DStmt{st}), crate::syntax::parser::error_at(q, start, Text::lit("a bind or hold is a statement of a widget block: nothing at top level is built (Semantics ch. 6)"))});
                    goto _done;
                }
            }
            {
                _v.set(({
                    auto at_ = q->bad ? p_ : q;
                    std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DStmt{st}), crate::syntax::parser::error_here(at_, Text::lit("expected a declaration (`fn`, `let`, `type`, `tag`, `derive`, `trait`, `impl`, `test`, `check`, or a signature `Name: type`)"))};
                }));
                goto _done;
            }
        _done:
            _v.take();
        });
        });
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::decls::DeclKind, crate::syntax::parser::Ps>> DeclKindOf::cycle() const {
    const auto& p_ = this->p_;
    const auto& fragment = this->fragment;
    const auto& start = this->start;
    return ({
        auto&& _m = crate::syntax::parser::kind(p_);
        prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m5783_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        (m5783_0_0 == Text::lit("type"));
    }) ? ({
        auto&& m5783_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        ({
        auto p__1 = p_;
        call_then(start_parse_type_decl(p__1), [=](std::tuple<crate::syntax::decls::TypeDecl, crate::syntax::parser::Ps> parse_type_decl_5844) {
        return ({
            auto [d, q] = parse_type_decl_5844;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DType{d}), q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m5783_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        (m5783_1_0 == Text::lit("tag"));
    }) ? ({
        auto&& m5783_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        ({
        auto p__1 = p_;
        call_then(start_parse_tag_decl(p__1), [=](std::tuple<crate::syntax::decls::TagDecl, crate::syntax::parser::Ps> parse_tag_decl_5929) {
        return ({
            auto [d, q] = parse_tag_decl_5929;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DTag{d}), q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m5783_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        (m5783_2_0 == Text::lit("derive"));
    }) ? ({
        auto&& m5783_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        ({
        auto p__1 = p_;
        call_then(crate::syntax::parser::start_commas(crate::syntax::parser::adv(p__1), ({
        auto f = prism_rtl::rc(crate::syntax::parser::parse_trait_ref);
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::TraitRef, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([=, f = std::move(f)](crate::syntax::parser::Ps a0) {
        return ({
            auto f_2 = f;
            once_job([=, f_2 = std::move(f_2)]() { return prism_rtl::finished(f_2(a0)); });
        });
    }));
    })), [=](std::tuple<Array<crate::syntax::TraitRef>, crate::syntax::parser::Ps> commas_6020) {
        return ({
            auto [traits, q] = commas_6020;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DDerive{traits}), q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m5783_3_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        (m5783_3_0 == Text::lit("trait"));
    }) ? ({
        auto&& m5783_3_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        ({
        auto p__1 = p_;
        call_then(start_parse_trait_decl(p__1), [=](std::tuple<crate::syntax::decls::TraitDecl, crate::syntax::parser::Ps> parse_trait_decl_6128) {
        return ({
            auto [d, q] = parse_trait_decl_6128;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DTrait{d}), q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m5783_4_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        (m5783_4_0 == Text::lit("impl"));
    }) ? ({
        auto&& m5783_4_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        ({
        auto p__1 = p_;
        call_then(start_parse_impl_decl(p__1), [=](std::tuple<crate::syntax::decls::ImplDecl, crate::syntax::parser::Ps> parse_impl_decl_6216) {
        return ({
            auto [d, q] = parse_impl_decl_6216;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DImpl{d}), q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m5783_5_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        (m5783_5_0 == Text::lit("check"));
    }) ? ({
        auto&& m5783_5_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        ({
        auto p__1 = p_;
        call_then(crate::syntax::parser::test_language::start_parse_check_decl(p__1), [=](std::tuple<crate::syntax::decls::CheckDecl, crate::syntax::parser::Ps> parse_check_decl_6303) {
        return ({
            auto [d, q] = parse_check_decl_6303;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DCheck{d}), q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m5783_6_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        (m5783_6_0 == Text::lit("test"));
    }) ? ({
        auto&& m5783_6_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        ({
        auto p__1 = p_;
        call_then(crate::syntax::parser::test_language::start_parse_test_decl(p__1), [=](std::tuple<crate::syntax::decls::TestDecl, crate::syntax::parser::Ps> parse_test_decl_6391) {
        return ({
            auto [d, q] = parse_test_decl_6391;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DTest{d}), q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m5783_7_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        (m5783_7_0 == Text::lit("fn"));
    }) ? ({
        auto&& m5783_7_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        ({
        auto p__1 = p_;
        call_then(start_parse_fn_clause(p__1), [=](std::tuple<crate::syntax::decls::FnClause, crate::syntax::parser::Ps> parse_fn_clause_6475) {
        return ({
            auto [d, q] = parse_fn_clause_6475;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DFn{d}), q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m5783_8_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        (m5783_8_0 == Text::lit("let"));
    }) ? ({
        auto&& m5783_8_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        ({
        auto p__1 = p_;
        auto start_2 = start;
        call_then(crate::syntax::parser::types::start_parse_pattern(crate::syntax::parser::adv(p__1), false), [=, start_2 = std::move(start_2)](std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps> parse_pattern_6565) {
        return ({
            auto [pattern, p1] = parse_pattern_6565;
            call_then(start_optional_annotation(p1), [=](std::tuple<std::optional<crate::syntax::Type>, crate::syntax::parser::Ps> optional_annotation_6619) {
            return ({
                auto [ty_opt, p2] = optional_annotation_6619;
                call_then(crate::syntax::parser::expr::start_parse_rhs_expr(crate::syntax::parser::expect_op(p2, Text::lit("="))), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr_6669) {
                return ({
                    auto [value, p3] = parse_rhs_expr_6669;
                    (prism_rtl::finished(std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DLet{crate::syntax::decls::LetDecl{.pattern = pattern, .ty = ty_opt, .value = value, .span = crate::syntax::parser::to(start_2, crate::syntax::parser::prev(p3))}}), p3}));
                });
            });
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m) && ({
        (crate::syntax::parser::kind_at(p_, Nat(1u)) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KColon{}));
    }) ? crate::syntax::parser::kind_at(p_, Nat(2u)) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLayOpen{})
        ? ({
        auto [name, p1] = crate::syntax::parser::parse_sname(p_);
        auto start_1 = start;
        call_then(crate::syntax::parser::blocks::start_parse_block_after_colon(p1), [=, start_1 = std::move(start_1)](std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_block_after_colon_6954) {
        return ({
            auto [body, p2] = parse_block_after_colon_6954;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DWidget{crate::syntax::decls::WidgetDecl{.name = name, .body = body, .span = crate::syntax::parser::to(start_1, prism_rtl::deref(body).span)}}), p2}));
        });
    });
    })
        : ({
        auto p__1 = p_;
        call_then(start_parse_signature(p__1), [=](std::tuple<crate::syntax::decls::Signature, crate::syntax::parser::Ps> parse_signature_7110) {
        return ({
            auto [sig, q] = parse_signature_7110;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DSignature{sig}), q}));
        });
    });
    })
        : prism_rtl::deref(fragment)
        ? ({
        auto p__1 = p_;
        call_then(crate::syntax::parser::blocks::start_parse_stmt(p__1), [=](std::tuple<crate::syntax::Stmt, crate::syntax::parser::Ps> parse_stmt_7225) {
        return ({
            auto [st, q] = parse_stmt_7225;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DStmt{st}), q}));
        });
    });
    })
        : ({
        auto p__1 = p_;
        auto start_2 = start;
        call_then(crate::syntax::parser::blocks::start_parse_stmt(p__1), [=, start_2 = std::move(start_2)](std::tuple<crate::syntax::Stmt, crate::syntax::parser::Ps> parse_stmt_7433) {
        return ({
            auto [st, q] = parse_stmt_7433;
            ({
            auto&& _m = prism_rtl::deref(st).kind;
            prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && ({
            (!q->bad);
        }) ? prism_rtl::finished(std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DStmt{st}), crate::syntax::parser::error_at(q, start_2, Text::lit("a bind or hold is a statement of a widget block: nothing at top level is built (Semantics ch. 6)"))})
            : ({
            auto at_ = q->bad ? p__1 : q;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DStmt{st}), crate::syntax::parser::error_here(at_, Text::lit("expected a declaration (`fn`, `let`, `type`, `tag`, `derive`, `trait`, `impl`, `test`, `check`, or a signature `Name: type`)"))}));
        });
        });
        });
    });
    });
    });
}


/// `Start DeclKindOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::decls::DeclKind, crate::syntax::parser::Ps>> start_decl_kind_of(crate::syntax::parser::Ps p_, bool fragment, crate::syntax::Range start) {
    return prism_rtl::make_rc<DeclKindOf>(p_, fragment, start);
}


/// OptionalAnnotation: unbounded fn Ps -> ((?Type, Ps))
std::tuple<std::optional<crate::syntax::Type>, crate::syntax::parser::Ps> optional_annotation(const crate::syntax::parser::Ps& p_) {
    return crate::syntax::parser::at_colon(p_)
        ? ({
        auto [ty, q] = crate::syntax::parser::types::parse_type(crate::syntax::parser::adv(p_));
        std::tuple{std::optional(ty), q};
    })
        : std::tuple{std::optional<crate::syntax::Type>{}, p_};
}


prism_rtl::Turn<std::tuple<std::optional<crate::syntax::Type>, crate::syntax::parser::Ps>> OptionalAnnotation::cycle() const {
    const auto& p_ = this->p_;
    return crate::syntax::parser::at_colon(p_)
        ? ({
        auto p__1 = p_;
        call_then(crate::syntax::parser::types::start_parse_type(crate::syntax::parser::adv(p__1)), [=](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_type_8123) {
        return ({
            auto [ty, q] = parse_type_8123;
            (prism_rtl::finished(std::tuple{std::optional(ty), q}));
        });
    });
    })
        : prism_rtl::finished(std::tuple{std::optional<crate::syntax::Type>{}, p_});
}


/// `Start OptionalAnnotation, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<std::optional<crate::syntax::Type>, crate::syntax::parser::Ps>> start_optional_annotation(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<OptionalAnnotation>(p_);
}


/// ParseSignature: unbounded fn Ps -> ((Signature, Ps))
std::tuple<crate::syntax::decls::Signature, crate::syntax::parser::Ps> parse_signature(const crate::syntax::parser::Ps& p_) {
    auto start = crate::syntax::parser::here(p_);
    auto [name, p1] = parse_def_name(p_);
    auto [ty, p2] = crate::syntax::parser::types::parse_type(crate::syntax::parser::expect_colon(p1));
    auto [bounds, p3] = optional_bounds(p2);
    return std::tuple{crate::syntax::decls::Signature{.name = name, .ty = ty, .bounds = bounds, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(p3))}, p3};
}


prism_rtl::Turn<std::tuple<crate::syntax::decls::Signature, crate::syntax::parser::Ps>> ParseSignature::cycle() const {
    const auto& p_ = this->p_;
    auto start = crate::syntax::parser::here(p_);
    auto [name, p1] = parse_def_name(p_);
    return call_then(crate::syntax::parser::types::start_parse_type(crate::syntax::parser::expect_colon(p1)), [=](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_type_8405) {
        return ({
            auto [ty, p2] = parse_type_8405;
            call_then(start_optional_bounds(p2), [=](std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps> optional_bounds_8457) {
            return ({
                auto [bounds, p3] = optional_bounds_8457;
                (prism_rtl::finished(std::tuple{crate::syntax::decls::Signature{.name = name, .ty = ty, .bounds = bounds, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(p3))}, p3}));
            });
        });
        });
    });
}


/// `Start ParseSignature, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::decls::Signature, crate::syntax::parser::Ps>> start_parse_signature(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<ParseSignature>(p_);
}


/// OptionalBounds: unbounded fn Ps -> (([Bound], Ps))
std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps> optional_bounds(const crate::syntax::parser::Ps& p_) {
    return crate::syntax::parser::at_kw(p_, Text::lit("where"))
        ? crate::syntax::parser::types::parse_bounds(crate::syntax::parser::adv(p_))
        : std::tuple{Array<crate::syntax::decls::Bound>{}, p_};
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps>> OptionalBounds::cycle() const {
    const auto& p_ = this->p_;
    return crate::syntax::parser::at_kw(p_, Text::lit("where"))
        ? prism_rtl::more(prism_rtl::rc(crate::syntax::parser::types::ParseBounds(crate::syntax::parser::adv(p_))))
        : prism_rtl::finished(std::tuple{Array<crate::syntax::decls::Bound>{}, p_});
}


/// `Start OptionalBounds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps>> start_optional_bounds(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<OptionalBounds>(p_);
}


/// ParseDefName: fn Ps -> ((DefName, Ps))
std::tuple<crate::syntax::decls::DefName, crate::syntax::parser::Ps> parse_def_name(const crate::syntax::parser::Ps& p_) {
    auto&& _m = crate::syntax::parser::kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        auto [name, q] = crate::syntax::parser::parse_sname(p_);
        auto lens = crate::syntax::lexer::chars::has_prefix(prism_rtl::deref(n).sigils, Text::lit("&")) && crate::syntax::parser::is_upper_name(name);
        auto q2 = std::move(lens)
            ? crate::syntax::parser::out_of_scope(q, prism_rtl::deref(name).span, Text::lit("named lenses `&Home` and `Over`"), prism_rtl::cat("the named lens `", crate::syntax::parser::name_text(name), "` is out of this compiler"))
            : q;
        return std::tuple{crate::syntax::decls::DefName(crate::syntax::decls::DefName::DefSName{name}), q2};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(_m)) {
        auto&& op = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
        if (p_.in_trait) {
            auto name = crate::syntax::decls::DefName(crate::syntax::decls::DefName::DefOp{op, crate::syntax::parser::here(p_)});
            return std::tuple{name, crate::syntax::parser::adv(p_)};
        }
    }
    {
        return std::tuple{crate::syntax::decls::DefName(crate::syntax::decls::DefName::DefSName{crate::syntax::parser::no_sname()}), crate::syntax::parser::error_here(p_, Text::lit("expected a name"))};
    }
}


/// ParseFnClause: unbounded fn Ps -> ((FnClause, Ps))
std::tuple<crate::syntax::decls::FnClause, crate::syntax::parser::Ps> parse_fn_clause(const crate::syntax::parser::Ps& p0) {
    auto start = crate::syntax::parser::here(p0);
    auto [name, p1] = parse_def_name(crate::syntax::parser::expect_kw(p0, Text::lit("fn")));
    auto [params, p2] = crate::syntax::parser::at_op(p1, Text::lit("=")) || crate::syntax::parser::at_colon(p1)
        ? std::tuple{Array<crate::syntax::Pattern_>{}, p1}
        : crate::syntax::parser::commas(p1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([=](crate::syntax::parser::Ps p0) {
        return entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(crate::syntax::parser::types::ParsePattern(q, false))));
            });
        }));
    })));
    auto [body, p3] = parse_fn_body(p2);
    return std::tuple{crate::syntax::decls::FnClause{.name = name, .params = params, .body = body, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(p3))}, p3};
}


prism_rtl::Turn<std::tuple<crate::syntax::decls::FnClause, crate::syntax::parser::Ps>> ParseFnClause::cycle() const {
    const auto& p0 = this->p0;
    auto start = crate::syntax::parser::here(p0);
    auto [name, p1] = parse_def_name(crate::syntax::parser::expect_kw(p0, Text::lit("fn")));
    auto [params, p2] = crate::syntax::parser::at_op(p1, Text::lit("=")) || crate::syntax::parser::at_colon(p1)
        ? std::tuple{Array<crate::syntax::Pattern_>{}, p1}
        : crate::syntax::parser::commas(p1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([=](crate::syntax::parser::Ps p0) {
        return entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(crate::syntax::parser::types::ParsePattern(q, false))));
            });
        }));
    })));
    return call_then(start_parse_fn_body(p2), [=](std::tuple<crate::syntax::decls::FnBody, crate::syntax::parser::Ps> parse_fn_body_9580) {
        return ({
            auto [body, p3] = parse_fn_body_9580;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::FnClause{.name = name, .params = params, .body = body, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(p3))}, p3}));
        });
    });
}


/// `Start ParseFnClause, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::decls::FnClause, crate::syntax::parser::Ps>> start_parse_fn_clause(crate::syntax::parser::Ps p0) {
    return prism_rtl::make_rc<ParseFnClause>(p0);
}


/// ParseFnBody: unbounded fn Ps -> ((FnBody, Ps))
std::tuple<crate::syntax::decls::FnBody, crate::syntax::parser::Ps> parse_fn_body(const crate::syntax::parser::Ps& p_) {
    return crate::syntax::parser::at_op(p_, Text::lit("="))
        ? ({
        auto [e, q] = crate::syntax::parser::expr::parse_rhs_expr(crate::syntax::parser::adv(p_));
        std::tuple{crate::syntax::decls::FnBody(crate::syntax::decls::FnBody::BodyExpr{e}), q};
    })
        : crate::syntax::parser::at_colon(p_)
        ? ({
        auto [b, q] = crate::syntax::parser::blocks::parse_block_after_colon(p_);
        std::tuple{crate::syntax::decls::FnBody(crate::syntax::decls::FnBody::BodyBlock{b}), q};
    })
        : std::tuple{crate::syntax::decls::FnBody(crate::syntax::decls::FnBody::BodyExpr{no_expr()}), crate::syntax::parser::error_here(p_, Text::lit("expected `=` and an expression, or `:` and a block, after the parameters"))};
}


prism_rtl::Turn<std::tuple<crate::syntax::decls::FnBody, crate::syntax::parser::Ps>> ParseFnBody::cycle() const {
    const auto& p_ = this->p_;
    return crate::syntax::parser::at_op(p_, Text::lit("="))
        ? ({
        auto p__1 = p_;
        call_then(crate::syntax::parser::expr::start_parse_rhs_expr(crate::syntax::parser::adv(p__1)), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr_9790) {
        return ({
            auto [e, q] = parse_rhs_expr_9790;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::FnBody(crate::syntax::decls::FnBody::BodyExpr{e}), q}));
        });
    });
    })
        : crate::syntax::parser::at_colon(p_)
        ? ({
        auto p__1 = p_;
        call_then(crate::syntax::parser::blocks::start_parse_block_after_colon(p__1), [=](std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_block_after_colon_9884) {
        return ({
            auto [b, q] = parse_block_after_colon_9884;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::FnBody(crate::syntax::decls::FnBody::BodyBlock{b}), q}));
        });
    });
    })
        : prism_rtl::finished(std::tuple{crate::syntax::decls::FnBody(crate::syntax::decls::FnBody::BodyExpr{no_expr()}), crate::syntax::parser::error_here(p_, Text::lit("expected `=` and an expression, or `:` and a block, after the parameters"))});
}


/// `Start ParseFnBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::decls::FnBody, crate::syntax::parser::Ps>> start_parse_fn_body(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<ParseFnBody>(p_);
}


/// LowerParams: fn Ps -> (([Ident], Ps))
std::tuple<Array<crate::syntax::Ident>, crate::syntax::parser::Ps> lower_params(const crate::syntax::parser::Ps& p0) {
    std::tuple<Array<crate::syntax::Ident>, crate::syntax::parser::Ps> this_ = std::tuple{Array<crate::syntax::Ident>{}, p0};
    Array<crate::syntax::Ident> ps = Array<crate::syntax::Ident>{};
    crate::syntax::parser::Ps p_ = p0;
    Nat fuel = len(p0.toks);
    while (true) {
        auto&& _m = fuel.checked_sub(Nat(1u));
        if (!(prism_rtl::is_some(_m))) break;
        auto&& left = prism_rtl::some_of(_m);
        if (!is_plain_lower(crate::syntax::parser::kind(p_))) {
            break;
        }
        fuel = left;
        auto [i, q] = crate::syntax::parser::parse_ident(p_);
        ps = crate::prelude::push(ps, i);
        p_ = q;
    }
    this_ = std::tuple{ps, p_};
    return this_;
}


/// IsPlainLower: fn TokKind -> Bool
bool is_plain_lower(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(tok_kind0)) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(tok_kind0).a0;
        return (prism_rtl::deref(n).case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseLower{})) && (prism_rtl::deref(n).sigils == Text::lit(""));
    }
    {
        return false;
    }
}


/// ParseTypeDecl: unbounded fn Ps -> ((TypeDecl, Ps))
std::tuple<crate::syntax::decls::TypeDecl, crate::syntax::parser::Ps> parse_type_decl(const crate::syntax::parser::Ps& p0) {
    auto start = crate::syntax::parser::here(p0);
    auto [name, p1] = crate::syntax::parser::parse_qual_name(crate::syntax::parser::adv(p0));
    auto [params, p2] = lower_params(p1);
    auto [body_opt, p3] = crate::syntax::parser::at_op(p2, Text::lit("="))
        ? parse_type_body(crate::syntax::parser::adv(p2), name, params)
        : std::tuple{std::optional<crate::syntax::decls::TypeBody>{}, p2};
    return std::tuple{crate::syntax::decls::TypeDecl{.name = name, .params = params, .body = body_opt, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(p3))}, p3};
}


prism_rtl::Turn<std::tuple<crate::syntax::decls::TypeDecl, crate::syntax::parser::Ps>> ParseTypeDecl::cycle() const {
    const auto& p0 = this->p0;
    auto start = crate::syntax::parser::here(p0);
    auto [name, p1] = crate::syntax::parser::parse_qual_name(crate::syntax::parser::adv(p0));
    auto [params, p2] = lower_params(p1);
    auto [body_opt, p3] = crate::syntax::parser::at_op(p2, Text::lit("="))
        ? parse_type_body(crate::syntax::parser::adv(p2), name, params)
        : std::tuple{std::optional<crate::syntax::decls::TypeBody>{}, p2};
    return prism_rtl::finished(std::tuple{crate::syntax::decls::TypeDecl{.name = name, .params = params, .body = body_opt, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(p3))}, p3});
}


/// `Start ParseTypeDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::decls::TypeDecl, crate::syntax::parser::Ps>> start_parse_type_decl(crate::syntax::parser::Ps p0) {
    return prism_rtl::make_rc<ParseTypeDecl>(p0);
}


/// ParseTypeBody: unbounded fn Ps, QualName, [Ident] -> ((?TypeBody, Ps))
std::tuple<std::optional<crate::syntax::decls::TypeBody>, crate::syntax::parser::Ps> parse_type_body(const crate::syntax::parser::Ps& p_, const crate::syntax::QualName& name, const Array<crate::syntax::Ident>& params) {
    auto&& _m = crate::syntax::parser::kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m11097_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m11097_0_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m11097_0_0 == Text::lit("record")) {
            if (m11097_0_1 == Text::lit("")) {
                auto [fields, q] = parse_field_block(crate::syntax::parser::adv(p_));
                return std::tuple{std::optional(crate::syntax::decls::TypeBody(crate::syntax::decls::TypeBody::TbRecord{fields})), q};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m11097_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m11097_1_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m11097_1_0 == Text::lit("choice")) {
            if (m11097_1_1 == Text::lit("")) {
                auto p1 = crate::syntax::parser::expect_colon(crate::syntax::parser::adv(p_));
                return crate::syntax::parser::at_open_l(p1)
                    ? ({
                    auto [cases, q] = crate::syntax::parser::layout_items(crate::syntax::parser::adv(p1), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::decls::Case_, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(start_parse_case(a0)); })));
                    std::tuple{std::optional(crate::syntax::decls::TypeBody(crate::syntax::decls::TypeBody::TbChoice{cases})), q};
                })
                    : std::tuple{std::optional<crate::syntax::decls::TypeBody>{}, crate::syntax::parser::error_here(p1, Text::lit("a choice\'s cases stand in an indented block after `choice:`"))};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m11097_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m11097_2_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m11097_2_0 == Text::lit("row")) {
            if (m11097_2_1 == Text::lit("")) {
                return std::tuple{std::optional(crate::syntax::decls::TypeBody(crate::syntax::decls::TypeBody::TbRow{})), crate::syntax::parser::adv(p_)};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        if (((prism_rtl::deref(n).sigils == Text::lit("")) && (len(n->path_) == Nat(1u))) && (crate::syntax::lexer::chars::last(n->path_) == crate::syntax::lexer::chars::last(name.path_))) {
            auto [c, q] = parse_case(p_);
            return std::tuple{std::optional(crate::syntax::decls::TypeBody(crate::syntax::decls::TypeBody::TbNewtype{c})), q};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        if (is_unit_body(p_, n, params)) {
            auto [i, q] = crate::syntax::parser::parse_ident(p_);
            return std::tuple{std::optional(crate::syntax::decls::TypeBody(crate::syntax::decls::TypeBody::TbUnit{i})), q};
        }
    }
    {
        auto [ty, q] = crate::syntax::parser::types::parse_type(p_);
        return std::tuple{std::optional(crate::syntax::decls::TypeBody(crate::syntax::decls::TypeBody::TbAlias{ty})), q};
    }
}


prism_rtl::Turn<std::tuple<std::optional<crate::syntax::decls::TypeBody>, crate::syntax::parser::Ps>> ParseTypeBody::cycle() const {
    const auto& p_ = this->p_;
    const auto& name = this->name;
    const auto& params = this->params;
    return ({
        auto&& _m = crate::syntax::parser::kind(p_);
        prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m11097_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m11097_0_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m11097_0_0 == Text::lit("record")) && (m11097_0_1 == Text::lit(""));
    }) ? ({
        auto&& m11097_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m11097_0_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto p__1 = p_;
        call_then(start_parse_field_block(crate::syntax::parser::adv(p__1)), [=](std::tuple<Array<crate::syntax::decls::Field>, crate::syntax::parser::Ps> parse_field_block_11161) {
        return ({
            auto [fields, q] = parse_field_block_11161;
            (prism_rtl::finished(std::tuple{std::optional(crate::syntax::decls::TypeBody(crate::syntax::decls::TypeBody::TbRecord{fields})), q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m11097_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m11097_1_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m11097_1_0 == Text::lit("choice")) && (m11097_1_1 == Text::lit(""));
    }) ? ({
        auto&& m11097_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m11097_1_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto p1 = crate::syntax::parser::expect_colon(crate::syntax::parser::adv(p_));
        (crate::syntax::parser::at_open_l(p1)
        ? call_then(crate::syntax::parser::start_layout_items(crate::syntax::parser::adv(p1), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::decls::Case_, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(start_parse_case(a0)); }))), [=](std::tuple<Array<crate::syntax::decls::Case_>, crate::syntax::parser::Ps> layout_items_11333) {
        return ({
            auto [cases, q] = layout_items_11333;
            (prism_rtl::finished(std::tuple{std::optional(crate::syntax::decls::TypeBody(crate::syntax::decls::TypeBody::TbChoice{cases})), q}));
        });
    })
        : prism_rtl::finished(std::tuple{std::optional<crate::syntax::decls::TypeBody>{}, crate::syntax::parser::error_here(p1, Text::lit("a choice\'s cases stand in an indented block after `choice:`"))}));
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m11097_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m11097_2_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m11097_2_0 == Text::lit("row")) && (m11097_2_1 == Text::lit(""));
    }) ? ({
        auto&& m11097_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m11097_2_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        prism_rtl::finished(std::tuple{std::optional(crate::syntax::decls::TypeBody(crate::syntax::decls::TypeBody::TbRow{})), crate::syntax::parser::adv(p_)});
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m) && ({
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        (((prism_rtl::deref(n).sigils == Text::lit("")) && (len(n->path_) == Nat(1u))) && (crate::syntax::lexer::chars::last(n->path_) == crate::syntax::lexer::chars::last(name->path_)));
    }) ? ({
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        ({
        auto p__1 = p_;
        call_then(start_parse_case(p__1), [=](std::tuple<crate::syntax::decls::Case_, crate::syntax::parser::Ps> parse_case_11752) {
        return ({
            auto [c, q] = parse_case_11752;
            (prism_rtl::finished(std::tuple{std::optional(crate::syntax::decls::TypeBody(crate::syntax::decls::TypeBody::TbNewtype{c})), q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m) && ({
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        is_unit_body(p_, n, params);
    }) ? ({
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        ({
        auto [i, q] = crate::syntax::parser::parse_ident(p_);
        (prism_rtl::finished(std::tuple{std::optional(crate::syntax::decls::TypeBody(crate::syntax::decls::TypeBody::TbUnit{i})), q}));
    });
    })
        : ({
        auto p__1 = p_;
        call_then(crate::syntax::parser::types::start_parse_type(p__1), [=](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_type_12008) {
        return ({
            auto [ty, q] = parse_type_12008;
            (prism_rtl::finished(std::tuple{std::optional(crate::syntax::decls::TypeBody(crate::syntax::decls::TypeBody::TbAlias{ty})), q}));
        });
    });
    });
    });
}


/// `Start ParseTypeBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<std::optional<crate::syntax::decls::TypeBody>, crate::syntax::parser::Ps>> start_parse_type_body(crate::syntax::parser::Ps p_, crate::syntax::QualName name, Array<crate::syntax::Ident> params) {
    return prism_rtl::make_rc<ParseTypeBody>(p_, name, params);
}


/// IsUnitBody: fn Ps, NameTok, [Ident] -> Bool
bool is_unit_body(const crate::syntax::parser::Ps& p_, const crate::syntax::lexer::NameTok& n, const Array<crate::syntax::Ident>& params) {
    auto w = or_(index(n.path_, Nat(0u)), Text::lit(""));
    auto param = fold(params, false, [&](const bool& seen, const crate::syntax::Ident& i) { return prism_rtl::deref(seen) || (prism_rtl::deref(i).name == w); });
    auto ends = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = crate::syntax::parser::kind_at(p_, Nat(1u));
        if (prism_rtl::is<crate::syntax::lexer::TokKind::KLaySep>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayOpen>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayClose>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::lexer::TokKind::KEof>(_m)) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    return ((((n.sigils == Text::lit("")) && (n.case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseLower{}))) && (len(n.path_) == Nat(1u))) && (!std::move(param))) && std::move(ends);
}


/// ParseFieldBlock: unbounded fn Ps -> (([Field], Ps))
std::tuple<Array<crate::syntax::decls::Field>, crate::syntax::parser::Ps> parse_field_block(const crate::syntax::parser::Ps& p0) {
    auto p_ = crate::syntax::parser::expect_colon(p0);
    return crate::syntax::parser::at_open_l(p_)
        ? crate::syntax::parser::layout_items(crate::syntax::parser::adv(p_), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::decls::Field, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(start_parse_field(a0)); })))
        : std::tuple{Array<crate::syntax::decls::Field>{}, crate::syntax::parser::error_here(p_, Text::lit("fields stand in an indented block, one `name: Type` per line"))};
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::decls::Field>, crate::syntax::parser::Ps>> ParseFieldBlock::cycle() const {
    const auto& p0 = this->p0;
    auto p_ = crate::syntax::parser::expect_colon(p0);
    return crate::syntax::parser::at_open_l(p_)
        ? prism_rtl::more(prism_rtl::rc(crate::syntax::parser::LayoutItems(crate::syntax::parser::adv(p_), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::decls::Field, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(start_parse_field(a0)); })))))
        : prism_rtl::finished(std::tuple{Array<crate::syntax::decls::Field>{}, crate::syntax::parser::error_here(p_, Text::lit("fields stand in an indented block, one `name: Type` per line"))});
}


/// `Start ParseFieldBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::decls::Field>, crate::syntax::parser::Ps>> start_parse_field_block(crate::syntax::parser::Ps p0) {
    return prism_rtl::make_rc<ParseFieldBlock>(p0);
}


/// ParseField: unbounded fn Ps -> ((Field, Ps))
std::tuple<crate::syntax::decls::Field, crate::syntax::parser::Ps> parse_field(const crate::syntax::parser::Ps& p_) {
    auto start = crate::syntax::parser::here(p_);
    auto [name, p1] = crate::syntax::parser::parse_ident(p_);
    auto [ty, p2] = crate::syntax::parser::types::parse_type(crate::syntax::parser::expect_colon(p1));
    return std::tuple{crate::syntax::decls::Field{.name = name, .ty = ty, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(p2))}, p2};
}


prism_rtl::Turn<std::tuple<crate::syntax::decls::Field, crate::syntax::parser::Ps>> ParseField::cycle() const {
    const auto& p_ = this->p_;
    auto start = crate::syntax::parser::here(p_);
    auto [name, p1] = crate::syntax::parser::parse_ident(p_);
    return call_then(crate::syntax::parser::types::start_parse_type(crate::syntax::parser::expect_colon(p1)), [=](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_type_12885) {
        return ({
            auto [ty, p2] = parse_type_12885;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::Field{.name = name, .ty = ty, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(p2))}, p2}));
        });
    });
}


/// `Start ParseField, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::decls::Field, crate::syntax::parser::Ps>> start_parse_field(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<ParseField>(p_);
}


/// ParseCase: unbounded fn Ps -> ((Case, Ps))
std::tuple<crate::syntax::decls::Case_, crate::syntax::parser::Ps> parse_case(const crate::syntax::parser::Ps& p0) {
    auto start = crate::syntax::parser::here(p0);
    auto [name, p1] = crate::syntax::parser::parse_sname(p0);
    auto p2 = prism_rtl::deref(name).sigils != Text::lit("")
        ? crate::syntax::parser::note_error(p1, prism_rtl::deref(name).span, Text::lit("a constructor takes no sigil"))
        : p1;
    return crate::syntax::parser::at_colon(p2)
        ? ({
        auto p3 = crate::syntax::parser::adv(p2);
        auto [args, p4] = crate::syntax::parser::at_op(p3, Text::lit("->"))
            ? std::tuple{Array<crate::syntax::Type>{}, p3}
            : crate::syntax::parser::commas(p3, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(crate::syntax::parser::types::start_parse_emit_type(a0)); })));
        auto [result, p5] = crate::syntax::parser::types::parse_type(crate::syntax::parser::expect_op(p4, Text::lit("->")));
        auto p6 = crate::syntax::parser::out_of_scope(p5, start, Text::lit("indexed choices/GADTs for user types"), prism_rtl::cat("`", crate::syntax::parser::name_text(name), "` is an indexed alternative: indexed choices for user types are out of this compiler"));
        std::tuple{crate::syntax::decls::Case_{.name = name, .args = args, .indexed = std::optional(result), .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(p6))}, p6};
    })
        : ({
        auto [args, p3] = crate::syntax::parser::at_stmt_boundary(p2)
            ? std::tuple{Array<crate::syntax::Type>{}, p2}
            : crate::syntax::parser::commas(p2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(crate::syntax::parser::types::start_parse_type(a0)); })));
        std::tuple{crate::syntax::decls::Case_{.name = name, .args = args, .indexed = std::optional<crate::syntax::Type>{}, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(p3))}, p3};
    });
}


prism_rtl::Turn<std::tuple<crate::syntax::decls::Case_, crate::syntax::parser::Ps>> ParseCase::cycle() const {
    const auto& p0 = this->p0;
    auto start = crate::syntax::parser::here(p0);
    auto [name, p1] = crate::syntax::parser::parse_sname(p0);
    auto p2 = prism_rtl::deref(name).sigils != Text::lit("")
        ? crate::syntax::parser::note_error(p1, prism_rtl::deref(name).span, Text::lit("a constructor takes no sigil"))
        : p1;
    return crate::syntax::parser::at_colon(p2)
        ? ({
        auto p3 = crate::syntax::parser::adv(p2);
        auto [args, p4] = crate::syntax::parser::at_op(p3, Text::lit("->"))
            ? std::tuple{Array<crate::syntax::Type>{}, p3}
            : crate::syntax::parser::commas(p3, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(crate::syntax::parser::types::start_parse_emit_type(a0)); })));
        call_then(crate::syntax::parser::types::start_parse_type(crate::syntax::parser::expect_op(p4, Text::lit("->"))), [=](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_type_13499) {
        return ({
            auto [result, p5] = parse_type_13499;
            auto p6 = crate::syntax::parser::out_of_scope(p5, start, Text::lit("indexed choices/GADTs for user types"), prism_rtl::cat("`", crate::syntax::parser::name_text(name), "` is an indexed alternative: indexed choices for user types are out of this compiler"));
            (prism_rtl::finished(std::tuple{crate::syntax::decls::Case_{.name = name, .args = args, .indexed = std::optional(result), .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(p6))}, p6}));
        });
    });
    })
        : ({
        auto [args, p3] = crate::syntax::parser::at_stmt_boundary(p2)
            ? std::tuple{Array<crate::syntax::Type>{}, p2}
            : crate::syntax::parser::commas(p2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(crate::syntax::parser::types::start_parse_type(a0)); })));
        (prism_rtl::finished(std::tuple{crate::syntax::decls::Case_{.name = name, .args = args, .indexed = std::optional<crate::syntax::Type>{}, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(p3))}, p3}));
    });
}


/// `Start ParseCase, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::decls::Case_, crate::syntax::parser::Ps>> start_parse_case(crate::syntax::parser::Ps p0) {
    return prism_rtl::make_rc<ParseCase>(p0);
}


/// ParseTagDecl: unbounded fn Ps -> ((TagDecl, Ps))
std::tuple<crate::syntax::decls::TagDecl, crate::syntax::parser::Ps> parse_tag_decl(const crate::syntax::parser::Ps& p0) {
    auto start = crate::syntax::parser::here(p0);
    auto [name, p1] = crate::syntax::parser::parse_qual_name(crate::syntax::parser::adv(p0));
    auto [of_type, p2] = crate::syntax::parser::types::parse_type(crate::syntax::parser::expect_kw(p1, Text::lit("of")));
    auto [bounds, p3] = optional_bounds(p2);
    auto [fields, p4] = crate::syntax::parser::at_colon(p3)
        ? parse_field_block(p3)
        : std::tuple{Array<crate::syntax::decls::Field>{}, p3};
    return std::tuple{crate::syntax::decls::TagDecl{.name = name, .of_type = of_type, .bounds = bounds, .fields = fields, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(p4))}, p4};
}


prism_rtl::Turn<std::tuple<crate::syntax::decls::TagDecl, crate::syntax::parser::Ps>> ParseTagDecl::cycle() const {
    const auto& p0 = this->p0;
    auto start = crate::syntax::parser::here(p0);
    auto [name, p1] = crate::syntax::parser::parse_qual_name(crate::syntax::parser::adv(p0));
    return call_then(crate::syntax::parser::types::start_parse_type(crate::syntax::parser::expect_kw(p1, Text::lit("of"))), [=](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_type_14203) {
        return ({
            auto [of_type, p2] = parse_type_14203;
            call_then(start_optional_bounds(p2), [=](std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps> optional_bounds_14258) {
            return ({
                auto [bounds, p3] = optional_bounds_14258;
                auto [fields, p4] = crate::syntax::parser::at_colon(p3)
                    ? parse_field_block(p3)
                    : std::tuple{Array<crate::syntax::decls::Field>{}, p3};
                (prism_rtl::finished(std::tuple{crate::syntax::decls::TagDecl{.name = name, .of_type = of_type, .bounds = bounds, .fields = fields, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(p4))}, p4}));
            });
        });
        });
    });
}


/// `Start ParseTagDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::decls::TagDecl, crate::syntax::parser::Ps>> start_parse_tag_decl(crate::syntax::parser::Ps p0) {
    return prism_rtl::make_rc<ParseTagDecl>(p0);
}


/// ParseTraitDecl: unbounded fn Ps -> ((TraitDecl, Ps))
std::tuple<crate::syntax::decls::TraitDecl, crate::syntax::parser::Ps> parse_trait_decl(const crate::syntax::parser::Ps& p0) {
    auto start = crate::syntax::parser::here(p0);
    auto [name, p1] = crate::syntax::parser::parse_trait_ref(crate::syntax::parser::adv(p0));
    auto [params, p2] = lower_params(p1);
    auto [bounds, p3] = optional_bounds(p2);
    auto [items, p4] = parse_trait_items(p3);
    auto decl = crate::syntax::decls::TraitDecl{.name = name, .params = params, .bounds = bounds, .items = items, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(p4))};
    return std::tuple{decl, check_higher_kinded(p4, decl)};
}


prism_rtl::Turn<std::tuple<crate::syntax::decls::TraitDecl, crate::syntax::parser::Ps>> ParseTraitDecl::cycle() const {
    const auto& p0 = this->p0;
    auto start = crate::syntax::parser::here(p0);
    auto [name, p1] = crate::syntax::parser::parse_trait_ref(crate::syntax::parser::adv(p0));
    auto [params, p2] = lower_params(p1);
    return call_then(start_optional_bounds(p2), [=](std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps> optional_bounds_14716) {
        return ({
            auto [bounds, p3] = optional_bounds_14716;
            call_then(start_parse_trait_items(p3), [=](std::tuple<Array<crate::syntax::decls::TraitItem>, crate::syntax::parser::Ps> parse_trait_items_14758) {
            return ({
                auto [items, p4] = parse_trait_items_14758;
                auto decl = crate::syntax::decls::TraitDecl{.name = name, .params = params, .bounds = bounds, .items = items, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(p4))};
                (prism_rtl::finished(std::tuple{decl, check_higher_kinded(p4, decl)}));
            });
        });
        });
    });
}


/// `Start ParseTraitDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::decls::TraitDecl, crate::syntax::parser::Ps>> start_parse_trait_decl(crate::syntax::parser::Ps p0) {
    return prism_rtl::make_rc<ParseTraitDecl>(p0);
}


/// ParseImplDecl: unbounded fn Ps -> ((ImplDecl, Ps))
std::tuple<crate::syntax::decls::ImplDecl, crate::syntax::parser::Ps> parse_impl_decl(const crate::syntax::parser::Ps& p0) {
    auto start = crate::syntax::parser::here(p0);
    auto [trait_ref, p1] = crate::syntax::parser::parse_trait_ref(crate::syntax::parser::adv(p0));
    auto [ty, p2] = crate::syntax::parser::types::parse_type(p1);
    auto [bounds, p3] = optional_bounds(p2);
    auto [items, p4] = parse_trait_items(p3);
    return std::tuple{crate::syntax::decls::ImplDecl{.trait_ref = trait_ref, .ty = ty, .bounds = bounds, .items = items, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(p4))}, p4};
}


prism_rtl::Turn<std::tuple<crate::syntax::decls::ImplDecl, crate::syntax::parser::Ps>> ParseImplDecl::cycle() const {
    const auto& p0 = this->p0;
    auto start = crate::syntax::parser::here(p0);
    auto [trait_ref, p1] = crate::syntax::parser::parse_trait_ref(crate::syntax::parser::adv(p0));
    return call_then(crate::syntax::parser::types::start_parse_type(p1), [=](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_type_15144) {
        return ({
            auto [ty, p2] = parse_type_15144;
            call_then(start_optional_bounds(p2), [=](std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps> optional_bounds_15182) {
            return ({
                auto [bounds, p3] = optional_bounds_15182;
                call_then(start_parse_trait_items(p3), [=](std::tuple<Array<crate::syntax::decls::TraitItem>, crate::syntax::parser::Ps> parse_trait_items_15224) {
                return ({
                    auto [items, p4] = parse_trait_items_15224;
                    (prism_rtl::finished(std::tuple{crate::syntax::decls::ImplDecl{.trait_ref = trait_ref, .ty = ty, .bounds = bounds, .items = items, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(p4))}, p4}));
                });
            });
            });
        });
        });
    });
}


/// `Start ParseImplDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::decls::ImplDecl, crate::syntax::parser::Ps>> start_parse_impl_decl(crate::syntax::parser::Ps p0) {
    return prism_rtl::make_rc<ParseImplDecl>(p0);
}


/// ParseTraitItems: unbounded fn Ps -> (([TraitItem], Ps))
std::tuple<Array<crate::syntax::decls::TraitItem>, crate::syntax::parser::Ps> parse_trait_items(const crate::syntax::parser::Ps& p0) {
    auto p_ = crate::syntax::parser::expect_colon(p0);
    return crate::syntax::parser::at_open_l(p_)
        ? ({
        auto inside = ({
            crate::syntax::parser::Ps this_ = crate::syntax::parser::adv(p_);
            this_.in_trait = true;
            (std::move(this_));
        });
        auto [items, q] = crate::syntax::parser::layout_items(inside, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::decls::TraitItem, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(start_parse_trait_item(a0)); })));
        std::tuple{items, ({
        crate::syntax::parser::Ps this_ = q;
        this_.in_trait = prism_rtl::deref(p_).in_trait;
        (std::move(this_));
    })};
    })
        : std::tuple{Array<crate::syntax::decls::TraitItem>{}, crate::syntax::parser::error_here(p_, Text::lit("a trait\'s or impl\'s items stand in an indented block"))};
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::decls::TraitItem>, crate::syntax::parser::Ps>> ParseTraitItems::cycle() const {
    const auto& p0 = this->p0;
    auto p_ = crate::syntax::parser::expect_colon(p0);
    return crate::syntax::parser::at_open_l(p_)
        ? ({
        auto inside = ({
            crate::syntax::parser::Ps this_ = crate::syntax::parser::adv(p_);
            this_.in_trait = true;
            (std::move(this_));
        });
        call_then(crate::syntax::parser::start_layout_items(inside, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::decls::TraitItem, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(start_parse_trait_item(a0)); }))), [=](std::tuple<Array<crate::syntax::decls::TraitItem>, crate::syntax::parser::Ps> layout_items_15566) {
        return ({
            auto [items, q] = layout_items_15566;
            (prism_rtl::finished(std::tuple{items, ({
            crate::syntax::parser::Ps this_ = q;
            this_.in_trait = prism_rtl::deref(p_).in_trait;
            (std::move(this_));
        })}));
        });
    });
    })
        : prism_rtl::finished(std::tuple{Array<crate::syntax::decls::TraitItem>{}, crate::syntax::parser::error_here(p_, Text::lit("a trait\'s or impl\'s items stand in an indented block"))});
}


/// `Start ParseTraitItems, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::decls::TraitItem>, crate::syntax::parser::Ps>> start_parse_trait_items(crate::syntax::parser::Ps p0) {
    return prism_rtl::make_rc<ParseTraitItems>(p0);
}


/// ParseTraitItem: unbounded fn Ps -> ((TraitItem, Ps))
std::tuple<crate::syntax::decls::TraitItem, crate::syntax::parser::Ps> parse_trait_item(const crate::syntax::parser::Ps& p_) {
    auto&& _m = crate::syntax::parser::kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m15834_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        if (m15834_0_0 == Text::lit("fn")) {
            auto [f, q] = parse_fn_clause(p_);
            return std::tuple{crate::syntax::decls::TraitItem(crate::syntax::decls::TraitItem::TiFn{f}), q};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m15834_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        if (m15834_1_0 == Text::lit("type")) {
            auto start = crate::syntax::parser::here(p_);
            auto p1 = crate::syntax::parser::adv(p_);
            auto&& _m = crate::syntax::parser::kind(p1);
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
                auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
                if (((prism_rtl::deref(n).case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseUpper{})) && (prism_rtl::deref(n).sigils == Text::lit(""))) && (len(n->path_) == Nat(1u))) {
                    auto name = crate::syntax::Ident{.name = or_(index(n->path_, Nat(0u)), Text::lit("")), .span = crate::syntax::parser::here(p1)};
                    auto [params, p2] = lower_params(crate::syntax::parser::adv(p1));
                    auto [value_opt, p3] = crate::syntax::parser::at_op(p2, Text::lit("="))
                        ? optional_type(crate::syntax::parser::adv(p2))
                        : std::tuple{std::optional<crate::syntax::Type>{}, p2};
                    auto item = crate::syntax::decls::TraitItem(crate::syntax::decls::TraitItem::TiAssocType{name, params, value_opt, crate::syntax::parser::to(start, crate::syntax::parser::prev(p3))});
                    return std::tuple{item, p3};
                }
            }
            {
                auto item = crate::syntax::decls::TraitItem(crate::syntax::decls::TraitItem::TiAssocType{crate::syntax::parser::no_ident(), Array<crate::syntax::Ident>{}, std::optional<crate::syntax::Type>{}, crate::syntax::parser::no_range()});
                return std::tuple{item, crate::syntax::parser::error_here(p1, Text::lit("expected the associated type\'s name"))};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m15834_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        if (m15834_2_0 == Text::lit("row")) {
            auto start = crate::syntax::parser::here(p_);
            auto [name, q] = crate::syntax::parser::parse_sname(crate::syntax::parser::adv(p_));
            auto item = crate::syntax::decls::TraitItem(crate::syntax::decls::TraitItem::TiAssocRow{name, crate::syntax::parser::to(start, crate::syntax::parser::prev(q))});
            return std::tuple{item, q};
        }
    }
    {
        auto [sig, q] = parse_signature(p_);
        return std::tuple{crate::syntax::decls::TraitItem(crate::syntax::decls::TraitItem::TiSignature{sig}), q};
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::decls::TraitItem, crate::syntax::parser::Ps>> ParseTraitItem::cycle() const {
    const auto& p_ = this->p_;
    return ({
        auto&& _m = crate::syntax::parser::kind(p_);
        prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m15834_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        (m15834_0_0 == Text::lit("fn"));
    }) ? ({
        auto&& m15834_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        ({
        auto p__1 = p_;
        call_then(start_parse_fn_clause(p__1), [=](std::tuple<crate::syntax::decls::FnClause, crate::syntax::parser::Ps> parse_fn_clause_15893) {
        return ({
            auto [f, q] = parse_fn_clause_15893;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::TraitItem(crate::syntax::decls::TraitItem::TiFn{f}), q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m15834_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        (m15834_1_0 == Text::lit("type"));
    }) ? ({
        auto&& m15834_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        ({
        auto start = crate::syntax::parser::here(p_);
        auto p1 = crate::syntax::parser::adv(p_);
        ({
        auto&& _m = crate::syntax::parser::kind(p1);
        prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m) && ({
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        (((prism_rtl::deref(n).case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseUpper{})) && (prism_rtl::deref(n).sigils == Text::lit(""))) && (len(n->path_) == Nat(1u)));
    }) ? ({
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        ({
        auto name = crate::syntax::Ident{.name = or_(index(n->path_, Nat(0u)), Text::lit("")), .span = crate::syntax::parser::here(p1)};
        auto [params, p2] = lower_params(crate::syntax::parser::adv(p1));
        auto [value_opt, p3] = crate::syntax::parser::at_op(p2, Text::lit("="))
            ? optional_type(crate::syntax::parser::adv(p2))
            : std::tuple{std::optional<crate::syntax::Type>{}, p2};
        auto item = crate::syntax::decls::TraitItem(crate::syntax::decls::TraitItem::TiAssocType{name, params, value_opt, crate::syntax::parser::to(start, crate::syntax::parser::prev(p3))});
        (prism_rtl::finished(std::tuple{item, p3}));
    });
    })
        : ({
        auto item = crate::syntax::decls::TraitItem(crate::syntax::decls::TraitItem::TiAssocType{crate::syntax::parser::no_ident(), Array<crate::syntax::Ident>{}, std::optional<crate::syntax::Type>{}, crate::syntax::parser::no_range()});
        (prism_rtl::finished(std::tuple{item, crate::syntax::parser::error_here(p1, Text::lit("expected the associated type\'s name"))}));
    });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m15834_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        (m15834_2_0 == Text::lit("row"));
    }) ? ({
        auto&& m15834_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        ({
        auto start = crate::syntax::parser::here(p_);
        auto [name, q] = crate::syntax::parser::parse_sname(crate::syntax::parser::adv(p_));
        auto item = crate::syntax::decls::TraitItem(crate::syntax::decls::TraitItem::TiAssocRow{name, crate::syntax::parser::to(start, crate::syntax::parser::prev(q))});
        (prism_rtl::finished(std::tuple{item, q}));
    });
    })
        : ({
        auto p__1 = p_;
        call_then(start_parse_signature(p__1), [=](std::tuple<crate::syntax::decls::Signature, crate::syntax::parser::Ps> parse_signature_16833) {
        return ({
            auto [sig, q] = parse_signature_16833;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::TraitItem(crate::syntax::decls::TraitItem::TiSignature{sig}), q}));
        });
    });
    });
    });
}


/// `Start ParseTraitItem, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::decls::TraitItem, crate::syntax::parser::Ps>> start_parse_trait_item(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<ParseTraitItem>(p_);
}


/// OptionalType: unbounded fn Ps -> ((?Type, Ps))
std::tuple<std::optional<crate::syntax::Type>, crate::syntax::parser::Ps> optional_type(const crate::syntax::parser::Ps& p_) {
    auto [ty, q] = crate::syntax::parser::types::parse_type(p_);
    return std::tuple{std::optional(ty), q};
}


prism_rtl::Turn<std::tuple<std::optional<crate::syntax::Type>, crate::syntax::parser::Ps>> OptionalType::cycle() const {
    const auto& p_ = this->p_;
    auto p__1 = p_;
    return call_then(crate::syntax::parser::types::start_parse_type(p__1), [=](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_type_16968) {
        return ({
            auto [ty, q] = parse_type_16968;
            (prism_rtl::finished(std::tuple{std::optional(ty), q}));
        });
    });
}


/// `Start OptionalType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<std::optional<crate::syntax::Type>, crate::syntax::parser::Ps>> start_optional_type(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<OptionalType>(p_);
}


/// CheckHigherKinded: fn Ps, TraitDecl -> Ps
crate::syntax::parser::Ps check_higher_kinded(const crate::syntax::parser::Ps& p_, const crate::syntax::decls::TraitDecl& t) {
    auto hk = fold(t.items, false, [&](const bool& seen, const crate::syntax::decls::TraitItem& item) { return prism_rtl::deref(seen) || item_applies(item, t.params); });
    return std::move(hk) && (t.name->path_ != Array(std::vector{Text::lit("Monad")}))
        ? crate::syntax::parser::out_of_scope(p_, prism_rtl::deref(t.name).span, Text::lit("higher-kinded traits"), prism_rtl::cat("`^", crate::syntax::lexer::chars::join(t.name->path_, Text::lit(".")), "` applies its parameter to arguments: higher-kinded traits are out of this compiler"))
        : p_;
}


/// ItemApplies: fn TraitItem, [Ident] -> Bool
bool item_applies(const crate::syntax::decls::TraitItem& trait_item0, const Array<crate::syntax::Ident>& xs1) {
    auto&& _m = std::tuple{trait_item0, xs1};
    if (prism_rtl::is<crate::syntax::decls::TraitItem::TiSignature>(std::get<0>(_m))) {
        auto&& s = prism_rtl::as<crate::syntax::decls::TraitItem::TiSignature>(std::get<0>(_m)).a0;
        auto&& params = std::get<1>(_m);
        return applies(prism_rtl::deref(s).ty, params);
    }
    {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// AnyApplies: fn [Type], [Ident] -> Bool
bool any_applies(const Array<crate::syntax::Type>& ts, const Array<crate::syntax::Ident>& params) {
    return fold(ts, false, [&](const bool& seen, const crate::syntax::Type& t) { return prism_rtl::deref(seen) || applies(t, params); });
}


/// Applies: fn Type, [Ident] -> Bool
bool applies(const crate::syntax::Type& ty, const Array<crate::syntax::Ident>& params) {
    auto&& _m = prism_rtl::deref(ty.kind);
    if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
        auto&& name = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        auto head = ((len(args) > Nat(0u)) && (len(name->path_) == Nat(1u))) && fold(params, false, [&](const bool& seen, const crate::syntax::Ident& i) { return prism_rtl::deref(seen) || (prism_rtl::deref(i).name == or_(index(name->path_, Nat(0u)), Text::lit(""))); });
        return std::move(head) || any_applies(args, params);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m)) {
        auto&& inner = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a1;
        return applies(prism_rtl::deref(prism_rtl::deref(inner)), params);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m)) {
        auto&& inner = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        return applies(prism_rtl::deref(prism_rtl::deref(inner)), params);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TNonEmpty>(_m)) {
        auto&& inner = prism_rtl::as<crate::syntax::TypeKind::TNonEmpty>(_m).a0;
        return applies(prism_rtl::deref(prism_rtl::deref(inner)), params);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TArray>(_m)) {
        auto&& elem = prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a0;
        return applies(prism_rtl::deref(prism_rtl::deref(elem)), params);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TTuple>(_m)) {
        auto&& ts = prism_rtl::as<crate::syntax::TypeKind::TTuple>(_m).a0;
        return any_applies(ts, params);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TRowUnion>(_m)) {
        auto&& ts = prism_rtl::as<crate::syntax::TypeKind::TRowUnion>(_m).a0;
        return any_applies(ts, params);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TMap>(_m)) {
        auto&& k = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a1;
        return applies(prism_rtl::deref(prism_rtl::deref(k)), params) || applies(prism_rtl::deref(prism_rtl::deref(v_)), params);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TFn>(_m)) {
        auto&& ps = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& result = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        return any_applies(ps, params) || applies(prism_rtl::deref(prism_rtl::deref(result)), params);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TEmit>(_m)) {
        auto&& t = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a0;
        auto&& r = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a1;
        return applies(prism_rtl::deref(prism_rtl::deref(t)), params) || applies(prism_rtl::deref(prism_rtl::deref(r)), params);
    }
    {
        return false;
    }
}

}  // namespace crate::syntax::parser::decls
