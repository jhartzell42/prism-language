// The module `Lower.Program`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <lower/program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Lower.Program`, from `target/bootstrap/cpp-src/prismc/lower/program.prism`.
namespace crate::lower::program {

/// `Start RowDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::RowDef> start_row_def_of_f(crate::lower::Lx lx_p0, crate::check::env::TyInfo ti_p1) {
    return prism_rtl::make_rc<RowDefOf>(lx_p0, ti_p1);
}


/// ElemRow: unbounded fn Lx, [Text] -> RowDef
crate::lower::model::RowDef elem_row_f(const crate::lower::Lx& lx_p0, const Array<Text>& mods_p1) {
    auto tags_p2 = kind_tags_f(lx_p0, Text::lit("Element"), crate::prelude::push(mods_p1, Text::lit("Prelude")));
    auto cases_p3 = crate::prelude::each(tags_p2, [&](const crate::check::env::TagInfo& tg_p7) { return std::tuple{crate::lower::tag_struct_f(prism_rtl::deref(tg_p7).name_p), prism_rtl::cat(crate::lower::rust_mod_name_f(prism_rtl::deref(tg_p7).home_p), "::", crate::lower::tag_struct_f(prism_rtl::deref(tg_p7).name_p))}; });
    auto pod_p4 = crate::prelude::run_to_end(crate::prelude::fold_job(tags_p2, true, ({
        auto lx_p0x = lx_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::env::TagInfo>)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x)](std::tuple<bool, crate::check::env::TagInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0xy = lx_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy)]() {
            return ({
                auto ok_p8 = p0;
                auto tg_p9 = p1;
                (prism_rtl::finished(std::move(ok_p8) && prism_rtl::deref(tag_def_of_f(lx_p0xy, tg_p9)).pod_p));
            });
        })));
        });
    })));
    })));
    auto eq_p5 = crate::prelude::run_to_end(crate::prelude::fold_job(tags_p2, true, ({
        auto lx_p0x = lx_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::env::TagInfo>)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x)](std::tuple<bool, crate::check::env::TagInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0xy = lx_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy)]() {
            return ({
                auto ok_pa = p0;
                auto tg_pb = p1;
                (prism_rtl::finished(std::move(ok_pa) && prism_rtl::deref(tag_def_of_f(lx_p0xy, tg_pb)).eq_p));
            });
        })));
        });
    })));
    })));
    auto deep_p6 = crate::prelude::run_to_end(crate::prelude::fold_job(tags_p2, Array<Text>{}, ({
        auto lx_p0x = lx_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::env::TagInfo>)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x)](std::tuple<Array<Text>, crate::check::env::TagInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0xy = lx_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy)]() {
            return ({
                auto acc_pc = p0;
                auto tg_pd = p1;
                (crate::prelude::call_then(start_tag_holds_dyn_f(lx_p0xy, tg_pd), [=, acc_pc = std::move(acc_pc)](bool tag_holds_dyn_f_30753) {
                return tag_holds_dyn_f_30753
                    ? prism_rtl::finished(crate::prelude::push(acc_pc, crate::lower::tag_struct_f(prism_rtl::deref(tg_pd).name_p)))
                    : prism_rtl::finished(acc_pc);
            }));
            });
        })));
        });
    })));
    })));
    return crate::lower::model::RowDef{.name_p = Text::lit("Elem"), .prism_p = Text::lit("Elem"), .cases_p = cases_p3, .pod_p = std::move(pod_p4), .doc_p = Text::lit("`Elem r`: an element as a document holds it, its `Level` in a tick."), .eq_p = std::move(eq_p5), .level_p = true, .deep_p = deep_p6};
}


prism_rtl::Turn<crate::lower::model::RowDef> ElemRow::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& mods_p1 = this->mods_p1;
    auto tags_p2 = kind_tags_f(lx_p0, Text::lit("Element"), crate::prelude::push(mods_p1, Text::lit("Prelude")));
    auto cases_p3 = crate::prelude::each(tags_p2, [&](const crate::check::env::TagInfo& tg_p7) { return std::tuple{crate::lower::tag_struct_f(prism_rtl::deref(tg_p7).name_p), prism_rtl::cat(crate::lower::rust_mod_name_f(prism_rtl::deref(tg_p7).home_p), "::", crate::lower::tag_struct_f(prism_rtl::deref(tg_p7).name_p))}; });
    auto lx_p0x = lx_p0;
    return crate::prelude::call_value(crate::prelude::fold_job(tags_p2, true, ({
        auto lx_p0xx = lx_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::env::TagInfo>)>>(prism_rtl::rc([=, lx_p0xx = std::move(lx_p0xx)](std::tuple<bool, crate::check::env::TagInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0xxy = lx_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxy = std::move(lx_p0xxy)]() {
            return ({
                auto ok_p8 = p0;
                auto tg_p9 = p1;
                (prism_rtl::finished(std::move(ok_p8) && prism_rtl::deref(tag_def_of_f(lx_p0xxy, tg_p9)).pod_p));
            });
        })));
        });
    })));
    })), [=](bool fold_30583) {
        return ({
            auto pod_p4 = fold_30583;
            (crate::prelude::call_value(crate::prelude::fold_job(tags_p2, true, ({
            auto lx_p0xx = lx_p0x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::env::TagInfo>)>>(prism_rtl::rc([=, lx_p0xx = std::move(lx_p0xx)](std::tuple<bool, crate::check::env::TagInfo> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_p0xxy = lx_p0xx;
                (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxy = std::move(lx_p0xxy)]() {
                return ({
                    auto ok_pa = p0;
                    auto tg_pb = p1;
                    (prism_rtl::finished(std::move(ok_pa) && prism_rtl::deref(tag_def_of_f(lx_p0xxy, tg_pb)).eq_p));
                });
            })));
            });
        })));
        })), [=, pod_p4 = std::move(pod_p4)](bool fold_30652) {
            return ({
                auto eq_p5 = fold_30652;
                (crate::prelude::call_value(crate::prelude::fold_job(tags_p2, Array<Text>{}, ({
                auto lx_p0xx = lx_p0x;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::env::TagInfo>)>>(prism_rtl::rc([=, lx_p0xx = std::move(lx_p0xx)](std::tuple<Array<Text>, crate::check::env::TagInfo> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto lx_p0xxy = lx_p0xx;
                    (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxy = std::move(lx_p0xxy)]() {
                    return ({
                        auto acc_pc = p0;
                        auto tg_pd = p1;
                        (crate::prelude::call_then(start_tag_holds_dyn_f(lx_p0xxy, tg_pd), [=, acc_pc = std::move(acc_pc)](bool tag_holds_dyn_f_30753) {
                        return tag_holds_dyn_f_30753
                            ? prism_rtl::finished(crate::prelude::push(acc_pc, crate::lower::tag_struct_f(prism_rtl::deref(tg_pd).name_p)))
                            : prism_rtl::finished(acc_pc);
                    }));
                    });
                })));
                });
            })));
            })), [=, eq_p5 = std::move(eq_p5)](Array<Text> fold_30722) {
                return ({
                    auto deep_p6 = fold_30722;
                    (prism_rtl::finished(crate::lower::model::RowDef{.name_p = Text::lit("Elem"), .prism_p = Text::lit("Elem"), .cases_p = cases_p3, .pod_p = pod_p4, .doc_p = Text::lit("`Elem r`: an element as a document holds it, its `Level` in a tick."), .eq_p = eq_p5, .level_p = true, .deep_p = deep_p6}));
                });
            }));
            });
        }));
        });
    });
}


/// `Start ElemRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::RowDef> start_elem_row_f(crate::lower::Lx lx_p0, Array<Text> mods_p1) {
    return prism_rtl::make_rc<ElemRow>(lx_p0, mods_p1);
}


/// TagHoldsDyn: unbounded fn Lx, TagInfo -> Bool
bool tag_holds_dyn_f(const crate::lower::Lx& lx_p0, const crate::check::env::TagInfo& tg_p1) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(prism_rtl::deref(tag_def_of_f(lx_p0, tg_p1)).fields_p, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto f_p2 = p0;
                auto&& _t_p3 = p1;
                auto&& t_p3 = std::get<2>(_t_p3);
                (prism_rtl::finished(std::move(f_p2) || crate::lower::types::holds_dyn_f(t_p3)));
            });
        }));
    }))));
}


prism_rtl::Turn<bool> TagHoldsDyn::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& tg_p1 = this->tg_p1;
    auto lx_p0x = lx_p0;
    auto tg_p1x = tg_p1;
    return crate::prelude::call_then(start_tag_def_of_f(lx_p0x, tg_p1x), [=](crate::lower::model::TagDef tag_def_of_f_31174) {
        return crate::prelude::fold_job(prism_rtl::deref(tag_def_of_f_31174).fields_p, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto f_p2 = p0;
                    auto&& _t_p3 = p1;
                    auto&& t_p3 = std::get<2>(_t_p3);
                    (prism_rtl::finished(std::move(f_p2) || crate::lower::types::holds_dyn_f(t_p3)));
                });
            }));
        })))->cycle();
    });
}


/// `Start TagHoldsDyn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_tag_holds_dyn_f(crate::lower::Lx lx_p0, crate::check::env::TagInfo tg_p1) {
    return prism_rtl::make_rc<TagHoldsDyn>(lx_p0, tg_p1);
}


/// AnswerEnum: unbounded fn Lx, [Text] -> AnswerDef
crate::lower::model::AnswerDef answer_enum_f(const crate::lower::Lx& lx_p0, const Array<Text>& mods_p1) {
    auto tags_p2 = kind_tags_f(lx_p0, Text::lit("Element"), crate::prelude::push(mods_p1, Text::lit("Prelude")));
    return crate::lower::model::AnswerDef{.cases_p = crate::prelude::run_to_end(crate::prelude::each_job(tags_p2, ({
        auto lx_p0x = lx_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::AnswerCase>(crate::check::env::TagInfo)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x)](crate::check::env::TagInfo p0) {
        return ({
            auto lx_p0xy = lx_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy)]() {
            return ({
                auto tg_p3 = p0;
                (crate::prelude::call_then(start_answer_ty_f(lx_p0xy, tg_p3), [=](crate::lower::model::OutTy answer_ty_f_31650) { return prism_rtl::finished(crate::lower::model::AnswerCase{.variant_p = crate::lower::tag_struct_f(prism_rtl::deref(tg_p3).name_p), .accessor_p = crate::lower::node_::elements::answer_accessor_f(tg_p3), .struct_path_p = prism_rtl::cat(crate::lower::rust_mod_name_f(prism_rtl::deref(tg_p3).home_p), "::", crate::lower::tag_struct_f(prism_rtl::deref(tg_p3).name_p)), .tag_name_p = prism_rtl::deref(tg_p3).name_p, .ty_p = answer_ty_f_31650}); }));
            });
        })));
        });
    })));
    })))};
}


prism_rtl::Turn<crate::lower::model::AnswerDef> AnswerEnum::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& mods_p1 = this->mods_p1;
    auto tags_p2 = kind_tags_f(lx_p0, Text::lit("Element"), crate::prelude::push(mods_p1, Text::lit("Prelude")));
    auto lx_p0x = lx_p0;
    return crate::prelude::call_value(crate::prelude::each_job(tags_p2, ({
        auto lx_p0xx = lx_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::AnswerCase>(crate::check::env::TagInfo)>>(prism_rtl::rc([=, lx_p0xx = std::move(lx_p0xx)](crate::check::env::TagInfo p0) {
        return ({
            auto lx_p0xxy = lx_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxy = std::move(lx_p0xxy)]() {
            return ({
                auto tg_p3 = p0;
                (crate::prelude::call_then(start_answer_ty_f(lx_p0xxy, tg_p3), [=](crate::lower::model::OutTy answer_ty_f_31650) { return prism_rtl::finished(crate::lower::model::AnswerCase{.variant_p = crate::lower::tag_struct_f(prism_rtl::deref(tg_p3).name_p), .accessor_p = crate::lower::node_::elements::answer_accessor_f(tg_p3), .struct_path_p = prism_rtl::cat(crate::lower::rust_mod_name_f(prism_rtl::deref(tg_p3).home_p), "::", crate::lower::tag_struct_f(prism_rtl::deref(tg_p3).name_p)), .tag_name_p = prism_rtl::deref(tg_p3).name_p, .ty_p = answer_ty_f_31650}); }));
            });
        })));
        });
    })));
    })), [=](Array<crate::lower::model::AnswerCase> each_31485) { return prism_rtl::finished(crate::lower::model::AnswerDef{.cases_p = each_31485}); });
}


/// `Start AnswerEnum, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::AnswerDef> start_answer_enum_f(crate::lower::Lx lx_p0, Array<Text> mods_p1) {
    return prism_rtl::make_rc<AnswerEnum>(lx_p0, mods_p1);
}


/// AnswerTy: unbounded fn Lx, TagInfo -> OutTy
crate::lower::model::OutTy answer_ty_f(const crate::lower::Lx& lx_p0, const crate::check::env::TagInfo& tg_p1) {
    auto out_p2 = crate::lower::types::peel_f(tg_p1.out_p);
    auto part_p3 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::Ty> _v;
        if (prism_rtl::is<crate::check::types::Ty::TyTuple>(out_p2)) {
            auto&& cs_p4 = prism_rtl::as<crate::check::types::Ty::TyTuple>(out_p2).a0;
            _v.set(crate::prelude::fold(cs_p4, out_p2, [&](const crate::check::types::Ty& found_p5, const crate::check::types::Ty& c_p6) {
                return crate::lower::types::layer_of_f(c_p6) == crate::lower::types::Layer(crate::lower::types::Layer::LyEv{})
                    ? crate::lower::types::peel_f(c_p6)
                    : found_p5;
            }));
            goto _done;
        }
        {
            _v.set(out_p2);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto&& _m = crate::lower::types::out_ty_of_f(lx_p0, part_p3);
    if (prism_rtl::is<crate::lower::model::OutTy::OutGen>(_m)) {
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutPod{});
    }
    {
        auto&& t_p7 = _m;
        return t_p7;
    }
}


prism_rtl::Turn<crate::lower::model::OutTy> AnswerTy::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& tg_p1 = this->tg_p1;
    auto out_p2 = crate::lower::types::peel_f(prism_rtl::deref(tg_p1).out_p);
    auto part_p3 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::Ty> _v;
        if (prism_rtl::is<crate::check::types::Ty::TyTuple>(out_p2)) {
            auto&& cs_p4 = prism_rtl::as<crate::check::types::Ty::TyTuple>(out_p2).a0;
            _v.set(crate::prelude::fold(cs_p4, out_p2, [&](const crate::check::types::Ty& found_p5, const crate::check::types::Ty& c_p6) {
                return crate::lower::types::layer_of_f(c_p6) == crate::lower::types::Layer(crate::lower::types::Layer::LyEv{})
                    ? crate::lower::types::peel_f(c_p6)
                    : found_p5;
            }));
            goto _done;
        }
        {
            _v.set(out_p2);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto lx_p0x = lx_p0;
    return crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x, part_p3), [=](crate::lower::model::OutTy out_ty_of_f_32177) {
        return ({
            prism_rtl::is<crate::lower::model::OutTy::OutGen>(out_ty_of_f_32177) ? prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutPod{}))
            : ({
            auto&& t_p7 = out_ty_of_f_32177;
            prism_rtl::finished(t_p7);
        });
        });
    });
}


/// `Start AnswerTy, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::OutTy> start_answer_ty_f(crate::lower::Lx lx_p0, crate::check::env::TagInfo tg_p1) {
    return prism_rtl::make_rc<AnswerTy>(lx_p0, tg_p1);
}


/// TagPaths: fn Lx, TagInfo -> ((Text, Text))
std::tuple<Text, Text> tag_paths_f(const crate::lower::Lx& lx_p0, const crate::check::env::TagInfo& tg_p1) {
    auto st_p2 = crate::lower::tag_struct_f(tg_p1.name_p);
    auto struct_path_p3 = crate::lower::path_in_f(lx_p0, tg_p1.home_p, st_p2);
    return std::tuple{prism_rtl::cat(kind_path_f(lx_p0, tg_p1.kind_p), "::", st_p2), struct_path_p3};
}


/// VariantOf: fn Lx, TagInfo -> Text
Text variant_of_f(const crate::lower::Lx& lx_p0, const crate::check::env::TagInfo& tg_p1) {
    return prism_rtl::cat(kind_path_f(lx_p0, tg_p1.kind_p), "::", crate::lower::tag_struct_f(tg_p1.name_p));
}


/// KindPath: fn Lx, Text -> Text
Text kind_path_f(const crate::lower::Lx& lx_p0, const Text& kind_p1) {
    return kind_p1 == Text::lit("Element")
        ? Text::lit("crate::Elem")
        : crate::lower::path_in_f(lx_p0, prism_rtl::deref(crate::prelude::or_(crate::prelude::get(prism_rtl::deref(lx_p0.g_p).types_p, kind_p1), crate::check::env::names::dummy_ty_info_p())).home_p, crate::lower::camel_f(crate::check::types::bare_name_f(kind_p1)));
}


/// CheckDefOf: unbounded fn Lx, CheckDecl -> CheckDef
crate::lower::model::CheckDef check_def_of_f(const crate::lower::Lx& lx_p0, const crate::syntax::decls::CheckDecl& c_p1) {
    return crate::lower::model::CheckDef{.name_p = prism_rtl::deref(c_p1.name_p).name_p, .lines_p = crate::prelude::run_to_end(crate::prelude::each_job(c_p1.lines_p, ({
        auto lx_p0x = lx_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::decls::CheckLine)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x)](crate::syntax::decls::CheckLine p0) {
        return ({
            auto lx_p0xy = lx_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy)]() {
            return ({
                auto l_p2 = p0;
                (crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0xy, crate::lower::types::empty_env_p(), prism_rtl::deref(l_p2).expr_p), [=](crate::lower::types::Vl value_of_f_33025) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Ok"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::types::own_f(value_of_f_33025)), Text::lit("to_pod"), Array<crate::lower::model::Ex>{}})})})); }));
            });
        })));
        });
    })));
    })))};
}


prism_rtl::Turn<crate::lower::model::CheckDef> CheckDefOf::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& c_p1 = this->c_p1;
    auto c_p1x = c_p1;
    auto lx_p0x = lx_p0;
    return crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(c_p1x).lines_p, ({
        auto lx_p0xx = lx_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::decls::CheckLine)>>(prism_rtl::rc([=, lx_p0xx = std::move(lx_p0xx)](crate::syntax::decls::CheckLine p0) {
        return ({
            auto lx_p0xxy = lx_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxy = std::move(lx_p0xxy)]() {
            return ({
                auto l_p2 = p0;
                (crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0xxy, crate::lower::types::empty_env_p(), prism_rtl::deref(l_p2).expr_p), [=](crate::lower::types::Vl value_of_f_33025) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Ok"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::types::own_f(value_of_f_33025)), Text::lit("to_pod"), Array<crate::lower::model::Ex>{}})})})); }));
            });
        })));
        });
    })));
    })), [=](Array<crate::lower::model::Ex> each_32977) { return prism_rtl::finished(crate::lower::model::CheckDef{.name_p = prism_rtl::deref(prism_rtl::deref(c_p1x).name_p).name_p, .lines_p = each_32977}); });
}


/// `Start CheckDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::CheckDef> start_check_def_of_f(crate::lower::Lx lx_p0, crate::syntax::decls::CheckDecl c_p1) {
    return prism_rtl::make_rc<CheckDefOf>(lx_p0, c_p1);
}

}  // namespace crate::lower::program
