// The module `EmitCpp`, from `target/bootstrap/cpp-src/prismc/emit_cpp.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include "emit_cpp.hpp"
#include "ast.hpp"
#include "check_env.hpp"
#include "check_errors.hpp"
#include "check_types.hpp"
#include "cpp_prelude_template.hpp"
#include "cpp_templates.hpp"
#include "lexer.hpp"
#include "lower.hpp"
#include "prelude_template.hpp"
#include "typed.hpp"
#include "check_env.generic.hpp"
#include "lexer.generic.hpp"
#include "lower.generic.hpp"

namespace crate::emit_cpp {

Pod Cp::to_pod() const {
    return Pod::record("Cp", {{"home", prism_rtl::to_pod(home)}, {"mods", prism_rtl::to_pod(mods)}, {"types", prism_rtl::to_pod(types)}, {"ctors", prism_rtl::to_pod(ctors)}, {"members", prism_rtl::to_pod(members)}, {"methods", prism_rtl::to_pod(methods)}, {"field_names", prism_rtl::to_pod(field_names)}, {"fns", prism_rtl::to_pod(fns)}, {"fields", prism_rtl::to_pod(fields)}, {"renames", prism_rtl::to_pod(renames)}, {"pointers", prism_rtl::to_pod(pointers)}});
}

Result<Cp> Cp::from_pod(const Pod& whole) {
    return Cp{.home = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "home")))), .mods = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "mods")))), .types = TRY(prism_rtl::from_pod<Map<Text, TyInfo>>(TRY(prelude::field(whole, "types")))), .ctors = TRY(prism_rtl::from_pod<Map<Text, Text>>(TRY(prelude::field(whole, "ctors")))), .members = TRY(prism_rtl::from_pod<Map<Text, bool>>(TRY(prelude::field(whole, "members")))), .methods = TRY(prism_rtl::from_pod<Map<Text, bool>>(TRY(prelude::field(whole, "methods")))), .field_names = TRY(prism_rtl::from_pod<Map<Text, bool>>(TRY(prelude::field(whole, "field_names")))), .fns = TRY(prism_rtl::from_pod<Map<Text, bool>>(TRY(prelude::field(whole, "fns")))), .fields = TRY(prism_rtl::from_pod<Map<Text, lower::OutTy>>(TRY(prelude::field(whole, "fields")))), .renames = TRY(prism_rtl::from_pod<Map<Text, Text>>(TRY(prelude::field(whole, "renames")))), .pointers = TRY(prism_rtl::from_pod<Map<Text, bool>>(TRY(prelude::field(whole, "pointers"))))};
}


void Parts::show(Printer& p) const {
    p.record("Parts", {{"forward", forward}, {"handles", handles}, {"values", values}, {"cases", cases_}, {"protos", protos}, {"classes", classes}, {"outer", outer}, {"generic", generic}, {"defs", defs}});
}

Pod Parts::to_pod() const {
    return Pod::record("Parts", {{"forward", prism_rtl::to_pod(forward)}, {"handles", prism_rtl::to_pod(handles)}, {"values", prism_rtl::to_pod(values)}, {"cases", prism_rtl::to_pod(cases_)}, {"protos", prism_rtl::to_pod(protos)}, {"classes", prism_rtl::to_pod(classes)}, {"outer", prism_rtl::to_pod(outer)}, {"generic", prism_rtl::to_pod(generic)}, {"defs", prism_rtl::to_pod(defs)}});
}

Result<Parts> Parts::from_pod(const Pod& whole) {
    return Parts{.forward = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "forward")))), .handles = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "handles")))), .values = TRY(prism_rtl::from_pod<Array<ValueDecl>>(TRY(prelude::field(whole, "values")))), .cases_ = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "cases")))), .protos = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "protos")))), .classes = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "classes")))), .outer = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "outer")))), .generic = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "generic")))), .defs = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "defs"))))};
}


void TyInfo::show(Printer& p) const {
    p.record("TyInfo", {{"kind", kind}, {"fields", fields}, {"params", params}});
}

Pod TyInfo::to_pod() const {
    return Pod::record("TyInfo", {{"kind", prism_rtl::to_pod(kind)}, {"fields", prism_rtl::to_pod(fields)}, {"params", prism_rtl::to_pod(params)}});
}

Result<TyInfo> TyInfo::from_pod(const Pod& whole) {
    return TyInfo{.kind = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "kind")))), .fields = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "fields")))), .params = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "params"))))};
}


void ValueDecl::show(Printer& p) const {
    p.record("ValueDecl", {{"path", path_}, {"deps", deps}, {"text", text}});
}

Pod ValueDecl::to_pod() const {
    return Pod::record("ValueDecl", {{"path", prism_rtl::to_pod(path_)}, {"deps", prism_rtl::to_pod(deps)}, {"text", prism_rtl::to_pod(text)}});
}

Result<ValueDecl> ValueDecl::from_pod(const Pod& whole) {
    return ValueDecl{.path_ = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "path")))), .deps = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "deps")))), .text = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "text"))))};
}


/// CppId: fn Text -> Text
Text cpp_id(const Text& n) {
    return in_list(cpp_keywords(), n) ? prism_rtl::cat(n, "_") : n;
}


/// let cppKeywords
Array<Text> cpp_keywords() {
    return Array(std::vector{Text::lit("explicit"), Text::lit("and"), Text::lit("and_eq"), Text::lit("asm"), Text::lit("auto"), Text::lit("bitand"), Text::lit("bitor"), Text::lit("bool"), Text::lit("case"), Text::lit("catch"), Text::lit("char"), Text::lit("char8_t"), Text::lit("char16_t"), Text::lit("char32_t"), Text::lit("class"), Text::lit("compl"), Text::lit("concept"), Text::lit("const_cast"), Text::lit("consteval"), Text::lit("constexpr"), Text::lit("constinit"), Text::lit("co_await"), Text::lit("co_return"), Text::lit("co_yield"), Text::lit("decltype"), Text::lit("default"), Text::lit("delete"), Text::lit("double"), Text::lit("dynamic_cast"), Text::lit("explicit"), Text::lit("export"), Text::lit("extern"), Text::lit("float"), Text::lit("friend"), Text::lit("goto"), Text::lit("inline"), Text::lit("int"), Text::lit("long"), Text::lit("mutable"), Text::lit("namespace"), Text::lit("new"), Text::lit("noexcept"), Text::lit("not"), Text::lit("not_eq"), Text::lit("nullptr"), Text::lit("operator"), Text::lit("or"), Text::lit("or_eq"), Text::lit("private"), Text::lit("protected"), Text::lit("public"), Text::lit("register"), Text::lit("reinterpret_cast"), Text::lit("requires"), Text::lit("short"), Text::lit("signed"), Text::lit("sizeof"), Text::lit("static_assert"), Text::lit("static_cast"), Text::lit("switch"), Text::lit("template"), Text::lit("this"), Text::lit("thread_local"), Text::lit("throw"), Text::lit("try"), Text::lit("typedef"), Text::lit("typeid"), Text::lit("typename"), Text::lit("union"), Text::lit("unsigned"), Text::lit("using"), Text::lit("virtual"), Text::lit("void"), Text::lit("volatile"), Text::lit("wchar_t"), Text::lit("xor"), Text::lit("xor_eq"), Text::lit("errno"), Text::lit("assert"), Text::lit("NULL"), Text::lit("EOF"), Text::lit("stdin"), Text::lit("stdout"), Text::lit("stderr"), Text::lit("major"), Text::lit("minor")});
}


/// FieldId: fn Text -> Text
Text field_id(const Text& f) {
    return in_list(Array(std::vector{Text::lit("show"), Text::lit("to_pod"), Text::lit("from_pod"), Text::lit("cases")}), f)
        ? prism_rtl::cat(f, "_")
        : cpp_id(f);
}


/// CppPathId: fn Text -> Text
Text cpp_path_id(const Text& p_) {
    return lexer::join(each(split(p_, Text::lit("::")), [&](const Text& s) { return cpp_id(s); }), Text::lit("::"));
}


/// InList: fn [Text], Text -> Bool
bool in_list(const Array<Text>& xs, const Text& x) {
    return fold(xs, false, [&](const bool& seen, const Text& y) { return seen || (y == x); });
}


/// Absolute: fn Cp, Text -> Text
Text absolute(const Cp& cp, const Text& p_) {
    auto q = lexer::drop_prefix(p_, Text::lit("crate::"));
    auto first_ = or_(index(split(q, Text::lit("::")), Nat(0u)), Text::lit(""));
    return in_list(cp.mods, first_) ? q : prism_rtl::cat(cp.home, "::", q);
}


/// ?TypeOf: fn Cp, Text -> ?TyInfo
std::optional<TyInfo> type_of(const Cp& cp, const Text& p_) {
    auto q = lexer::drop_prefix(p_, Text::lit("crate::"));
    auto&& _m = prelude::get(cp.types, absolute(cp, q));
    if (prism_rtl::is_some(_m)) {
        auto&& t = prism_rtl::some_of(_m);
        return std::optional(t);
    }
    if (prism_rtl::is_none(_m)) {
        auto&& _m = prelude::get(cp.types, prism_rtl::cat("prelude::", q));
        if (prism_rtl::is_some(_m)) {
            auto&& t = prism_rtl::some_of(_m);
            return std::optional(t);
        }
        if (prism_rtl::is_none(_m)) {
            return prelude::get(cp.types, q);
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?CaseOf: fn Cp, Text -> ?Text
std::optional<Text> case_of(const Cp& cp, const Text& p_) {
    auto q = lexer::drop_prefix(p_, Text::lit("crate::"));
    auto&& _m = prelude::get(cp.ctors, absolute(cp, q));
    if (prism_rtl::is_some(_m)) {
        return std::optional(parent_path(p_));
    }
    if (prism_rtl::is_none(_m)) {
        auto&& _m = prelude::get(cp.ctors, prism_rtl::cat("prelude::", q));
        if (prism_rtl::is_some(_m)) {
            return std::optional(parent_path(p_));
        }
        if (prism_rtl::is_none(_m)) {
            auto&& _m = prelude::get(cp.ctors, q);
            if (prism_rtl::is_some(_m)) {
                return std::optional(parent_path(p_));
            }
            if (prism_rtl::is_none(_m)) {
                return std::optional<Text>{};
            }
            prism_rtl::unreachable("no arm matched");
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


/// ParentPath: fn Text -> Text
Text parent_path(const Text& p_) {
    auto segs = split(p_, Text::lit("::"));
    return lexer::join(take(segs, lexer::dec(len(segs))), Text::lit("::"));
}


/// LastSegment: fn Text -> Text
Text last_segment(const Text& p_) {
    return or_(lexer::last(split(p_, Text::lit("::"))), p_);
}


/// Context: fn Model -> Cp
Cp context(const lower::Model& model) {
    auto mods = prelude::push(each(model.mods, [&](const lower::ModDef& m) { return m.name; }), Text::lit("prelude"));
    auto base = Cp{.home = Text::lit(""), .mods = mods, .types = prelude_types(), .ctors = prelude_ctors(), .members = node_base(), .methods = Map<Text, bool>{}, .field_names = Map<Text, bool>{}, .fns = Map<Text, bool>{}, .fields = Map<Text, lower::OutTy>{}, .renames = Map<Text, Text>{}, .pointers = Map<Text, bool>{}};
    auto with_elem = add_row(add_answer(base, model->answer), Text::lit(""), model.elem);
    return fold(model.mods, with_elem, [&](const Cp& cp, const lower::ModDef& m) { return fold(m.items, cp, [&](const Cp& c, const lower::Item& it) { return add_model_item(c, m.name, it); }); });
}


/// let preludeTypes
Map<Text, TyInfo> prelude_types() {
    return map_of(std::vector{std::tuple{Text::lit("prelude::Ordering"), TyInfo{.kind = Text::lit("choice"), .fields = Array<Text>{}, .params = Array<Text>{}}}, std::tuple{Text::lit("prelude::Span"), TyInfo{.kind = Text::lit("record"), .fields = Array(std::vector{Text::lit("file"), Text::lit("line"), Text::lit("column"), Text::lit("binding")}), .params = Array<Text>{}}}, std::tuple{Text::lit("prelude::Exception"), TyInfo{.kind = Text::lit("record"), .fields = Array(std::vector{Text::lit("kind"), Text::lit("message"), Text::lit("spans"), Text::lit("path_")}), .params = Array<Text>{}}}, std::tuple{Text::lit("prelude::Duration"), TyInfo{.kind = Text::lit("newtype"), .fields = Array<Text>{}, .params = Array<Text>{}}}, std::tuple{Text::lit("prelude::PreludeUnwrap"), TyInfo{.kind = Text::lit("tag"), .fields = Array<Text>{}, .params = Array<Text>{}}}, std::tuple{Text::lit("prelude::PreludeExceptions"), TyInfo{.kind = Text::lit("tag"), .fields = Array<Text>{}, .params = Array<Text>{}}}});
}


/// let preludeCtors
Map<Text, Text> prelude_ctors() {
    return map_of(std::vector{std::tuple{Text::lit("prelude::Ordering::Less"), Text::lit("choice")}, std::tuple{Text::lit("prelude::Ordering::Equal"), Text::lit("choice")}, std::tuple{Text::lit("prelude::Ordering::Greater"), Text::lit("choice")}});
}


/// let nodeBase
Map<Text, bool> node_base() {
    return map_of(std::vector{std::tuple{Text::lit("make"), true}, std::tuple{Text::lit("push"), true}, std::tuple{Text::lit("wake"), true}, std::tuple{Text::lit("started"), true}, std::tuple{Text::lit("deferred"), true}, std::tuple{Text::lit("build"), true}, std::tuple{Text::lit("swap"), true}, std::tuple{Text::lit("leave"), true}, std::tuple{Text::lit("patch"), true}, std::tuple{Text::lit("edges"), true}, std::tuple{Text::lit("release"), true}, std::tuple{Text::lit("clean_up"), true}, std::tuple{Text::lit("path"), true}, std::tuple{Text::lit("leave_row"), true}, std::tuple{Text::lit("answer"), true}, std::tuple{Text::lit("document"), true}, std::tuple{Text::lit("deliver"), true}, std::tuple{Text::lit("document_moved"), true}, std::tuple{Text::lit("me"), true}, std::tuple{Text::lit("result_dynamic"), true}});
}


/// AddModelItem: fn Cp, Text, Item -> Cp
Cp add_model_item(const Cp& cp, const Text& m, const lower::Item& it) {
    if (prism_rtl::is<lower::Item::ItType>(it)) {
        auto&& t = prism_rtl::as<lower::Item::ItType>(it).a0;
        return add_type(cp, m, t);
    }
    if (prism_rtl::is<lower::Item::ItTag>(it)) {
        auto&& t = prism_rtl::as<lower::Item::ItTag>(it).a0;
        return add_ty(cp, prism_rtl::cat(m, "::", t.name), TyInfo{.kind = Text::lit("tag"), .fields = each(t.fields, [&](const std::tuple<Text, Text, lower::OutTy>& _p0) {
            auto&& f = std::get<1>(_p0);
            return f;
        }), .params = Array<Text>{}});
    }
    if (prism_rtl::is<lower::Item::ItRow>(it)) {
        auto&& r = prism_rtl::as<lower::Item::ItRow>(it).a0;
        return add_row(cp, m, r);
    }
    if (prism_rtl::is<lower::Item::ItJob>(it)) {
        auto&& j = prism_rtl::as<lower::Item::ItJob>(it).a0;
        return add_ty(cp, prism_rtl::cat(m, "::", j.name), TyInfo{.kind = Text::lit("job"), .fields = each(j.fields, [&](const std::tuple<Text, lower::OutTy>& _p0) {
            auto&& f = std::get<0>(_p0);
            return f;
        }), .params = each(j.generics, [&](const std::tuple<Text, Array<Text>>& _p0) {
            auto&& g = std::get<0>(_p0);
            return g;
        })});
    }
    if (prism_rtl::is<lower::Item::ItNode>(it)) {
        auto&& n = prism_rtl::as<lower::Item::ItNode>(it).a0;
        return add_node(cp, m, n);
    }
    if (prism_rtl::is<lower::Item::ItFn>(it)) {
        auto&& f = prism_rtl::as<lower::Item::ItFn>(it).a0;
        Cp this_ = cp;
        this_.fns = insert(this_.fns, prism_rtl::cat(m, "::", f.name), true);
        return this_;
    }
    {
        return cp;
    }
}


/// AddTy: fn Cp, Text, TyInfo -> Cp
Cp add_ty(const Cp& cp, const Text& path_, const TyInfo& info) {
    Cp this_ = cp;
    this_.types = insert(this_.types, path_, info);
    return this_;
}


/// AddCtor: fn Cp, Text, Text -> Cp
Cp add_ctor(const Cp& cp, const Text& path_, const Text& kind) {
    Cp this_ = cp;
    this_.ctors = insert(this_.ctors, path_, kind);
    return this_;
}


/// AddMember: fn Cp, Text -> Cp
Cp add_member(const Cp& cp, const Text& name) {
    Cp this_ = cp;
    this_.members = insert(this_.members, name, true);
    return this_;
}


/// AddType: fn Cp, Text, TyDef -> Cp
Cp add_type(const Cp& cp, const Text& m, const lower::TyDef& t) {
    auto path_ = prism_rtl::cat(m, "::", t.name);
    auto first_ = or_(index(t.cases_, Nat(0u)), lower::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, lower::OutTy>>{}});
    auto&& _m = t.shape;
    if (prism_rtl::is<lower::TyShape::ShapeRecord>(_m)) {
        return add_ty(cp, path_, TyInfo{.kind = Text::lit("record"), .fields = each(first_.fields, [&](const std::tuple<Text, lower::OutTy>& _p0) {
            auto&& f = std::get<0>(_p0);
            return f;
        }), .params = t.params});
    }
    if (prism_rtl::is<lower::TyShape::ShapeNewtype>(_m)) {
        return add_ty(cp, path_, TyInfo{.kind = Text::lit("newtype"), .fields = Array<Text>{}, .params = t.params});
    }
    if (prism_rtl::is<lower::TyShape::ShapeUnit>(_m)) {
        return add_ty(cp, path_, TyInfo{.kind = Text::lit("unit"), .fields = Array<Text>{}, .params = t.params});
    }
    if (prism_rtl::is<lower::TyShape::ShapeChoice>(_m)) {
        return fold(t.cases_, add_ty(cp, path_, TyInfo{.kind = Text::lit("choice"), .fields = Array<Text>{}, .params = t.params}), [&](const Cp& c, const lower::CaseDef& k) { return add_ctor(c, prism_rtl::cat(path_, "::", k.name), Text::lit("choice")); });
    }
    prism_rtl::unreachable("no arm matched");
}


/// AddRow: fn Cp, Text, RowDef -> Cp
Cp add_row(const Cp& cp, const Text& m, const lower::RowDef& r) {
    auto path_ = m == Text::lit("") ? r.name : prism_rtl::cat(m, "::", r.name);
    return fold(r.cases_, add_ty(cp, path_, TyInfo{.kind = Text::lit("choice"), .fields = Array<Text>{}, .params = Array<Text>{}}), [&](const Cp& c, const std::tuple<Text, Text>& _p1) {
        auto&& v_ = std::get<0>(_p1);
        return add_ctor(c, prism_rtl::cat(path_, "::", v_), Text::lit("choice"));
    });
}


/// AddAnswer: fn Cp, AnswerDef -> Cp
Cp add_answer(const Cp& cp, const lower::AnswerDef& a) {
    return fold(a.cases_, add_ty(cp, Text::lit("Answer"), TyInfo{.kind = Text::lit("choice"), .fields = Array<Text>{}, .params = Array<Text>{}}), [&](const Cp& c, const lower::AnswerCase& k) { return add_ctor(c, prism_rtl::cat("Answer::", k.variant), Text::lit("choice")); });
}


/// AddNode: fn Cp, Text, NodeDef -> Cp
Cp add_node(const Cp& cp, const Text& m, const lower::NodeDef& n) {
    auto with_fields_ = fold(n.fields, cp, [&](const Cp& c, const std::tuple<Text, lower::OutTy, Text>& _p1) {
        auto&& f = std::get<0>(_p1);
        return ({
            Cp this_ = add_member(c, f);
            this_.field_names = insert(this_.field_names, f, true);
            this_;
        });
    });
    auto with_methods = fold(append(n.methods, n.hosted), with_fields_, [&](const Cp& c, const lower::MethDef& md) {
        return ({
            Cp this_ = add_member(c, md.name);
            this_.methods = insert(this_.methods, md.name, true);
            this_;
        });
    });
    auto with_builders = fold(n.builders, with_methods, [&](const Cp& c, const lower::ForDef& b) { return add_member(c, prism_rtl::cat(b.name, "_build")); });
    auto with_gens = fold(n.gens, with_builders, [&](const Cp& c, const lower::GenDef& g) { return add_member(c, prism_rtl::cat(g.name, "_build")); });
    return add_ty(with_gens, prism_rtl::cat(m, "::", n.name), TyInfo{.kind = Text::lit("node"), .fields = each(n.fields, [&](const std::tuple<Text, lower::OutTy, Text>& _p0) {
        auto&& f = std::get<0>(_p0);
        return f;
    }), .params = Array<Text>{}});
}


/// InHome: fn Cp, Text -> Cp
Cp in_home(const Cp& cp, const Text& m) {
    Cp this_ = cp;
    this_.home = m;
    return this_;
}


/// WithFields: fn Cp, [((Text, OutTy))] -> Cp
Cp with_fields(const Cp& cp, const Array<std::tuple<Text, lower::OutTy>>& fs) {
    Cp this_ = cp;
    this_.fields = fold(fs, Map<Text, lower::OutTy>{}, [&](const Map<Text, lower::OutTy>& acc, const std::tuple<Text, lower::OutTy>& _p1) {
        auto&& f = std::get<0>(_p1);
        auto&& t = std::get<1>(_p1);
        return insert(acc, f, t);
    });
    return this_;
}


/// CppType: unbounded fn Cp, OutTy -> Text
Text cpp_type(const Cp& cp, const lower::OutTy& t) {
    if (prism_rtl::is<lower::OutTy::OutNat>(t)) {
        return Text::lit("Nat");
    }
    if (prism_rtl::is<lower::OutTy::OutInt>(t)) {
        return Text::lit("Int");
    }
    if (prism_rtl::is<lower::OutTy::OutU8>(t)) {
        return Text::lit("std::uint8_t");
    }
    if (prism_rtl::is<lower::OutTy::OutFloat>(t)) {
        return Text::lit("double");
    }
    if (prism_rtl::is<lower::OutTy::OutBool>(t)) {
        return Text::lit("bool");
    }
    if (prism_rtl::is<lower::OutTy::OutChar>(t)) {
        return Text::lit("char32_t");
    }
    if (prism_rtl::is<lower::OutTy::OutText>(t)) {
        return Text::lit("Text");
    }
    if (prism_rtl::is<lower::OutTy::OutCursor>(t)) {
        return Text::lit("Cursor");
    }
    if (prism_rtl::is<lower::OutTy::OutUnit>(t)) {
        return Text::lit("Unit");
    }
    if (prism_rtl::is<lower::OutTy::OutPath>(t)) {
        return Text::lit("Path");
    }
    if (prism_rtl::is<lower::OutTy::OutDuration>(t)) {
        return Text::lit("Duration");
    }
    if (prism_rtl::is<lower::OutTy::OutError>(t)) {
        return Text::lit("Error");
    }
    if (prism_rtl::is<lower::OutTy::OutNamed>(t)) {
        auto&& m10650_12_0 = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& m10650_12_1 = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
        if (m10650_12_0 == Text::lit("Cell")) {
            if (m10650_12_1.size() == 1u) {
                {
                    auto&& _c1 = index(m10650_12_1, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& i = prism_rtl::some_of(_c1);
                        return cpp_type(cp, i);
                    }
                }
            }
        }
    }
    if (prism_rtl::is<lower::OutTy::OutNamed>(t)) {
        auto&& m10650_13_0 = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& m10650_13_1 = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
        if (m10650_13_0 == Text::lit("RefCell")) {
            if (m10650_13_1.size() == 1u) {
                {
                    auto&& _c1 = index(m10650_13_1, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& i = prism_rtl::some_of(_c1);
                        return cpp_type(cp, i);
                    }
                }
            }
        }
    }
    if (prism_rtl::is<lower::OutTy::OutNamed>(t)) {
        auto&& m10650_14_0 = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& m10650_14_1 = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
        if (m10650_14_0 == Text::lit("Vec")) {
            if (m10650_14_1.size() == 1u) {
                {
                    auto&& _c1 = index(m10650_14_1, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& i = prism_rtl::some_of(_c1);
                        return prism_rtl::cat("std::vector<", cpp_type(cp, i), ">");
                    }
                }
            }
        }
    }
    if (prism_rtl::is<lower::OutTy::OutNamed>(t)) {
        auto&& m10650_15_0 = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& m10650_15_1 = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
        if (m10650_15_0 == Text::lit("Result")) {
            if (m10650_15_1.size() == 2u) {
                {
                    auto&& _c2 = index(m10650_15_1, Nat(0u));
                    if (prism_rtl::is_some(_c2)) {
                        auto&& a = prism_rtl::some_of(_c2);
                        {
                            auto&& _c1 = index(m10650_15_1, Nat(1u));
                            if (prism_rtl::is_some(_c1)) {
                                auto&& b = prism_rtl::some_of(_c1);
                                return prism_rtl::cat("Expected<", cpp_type(cp, a), ", ", cpp_type(cp, b), ">");
                            }
                        }
                    }
                }
            }
        }
    }
    if (prism_rtl::is<lower::OutTy::OutNamed>(t)) {
        auto&& n = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& m10650_16_1 = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
        if (m10650_16_1.size() == 0u) {
            return own_type_path(cp, n);
        }
    }
    if (prism_rtl::is<lower::OutTy::OutNamed>(t)) {
        auto&& n = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& args = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
        return prism_rtl::cat(own_type_path(cp, n), "<", cpp_types(cp, args), ">");
    }
    if (prism_rtl::is<lower::OutTy::OutOpt>(t)) {
        auto&& i = prism_rtl::as<lower::OutTy::OutOpt>(t).a0;
        return prism_rtl::cat("std::optional<", cpp_type(cp, i), ">");
    }
    if (prism_rtl::is<lower::OutTy::OutRes>(t)) {
        auto&& i = prism_rtl::as<lower::OutTy::OutRes>(t).a0;
        return prism_rtl::cat("Fallible<", cpp_type(cp, i), ">");
    }
    if (prism_rtl::is<lower::OutTy::OutTuple>(t)) {
        auto&& ts = prism_rtl::as<lower::OutTy::OutTuple>(t).a0;
        return prism_rtl::cat("std::tuple<", cpp_types(cp, ts), ">");
    }
    if (prism_rtl::is<lower::OutTy::OutArray>(t)) {
        auto&& e = prism_rtl::as<lower::OutTy::OutArray>(t).a0;
        return prism_rtl::cat("Array<", cpp_type(cp, e), ">");
    }
    if (prism_rtl::is<lower::OutTy::OutMap>(t)) {
        auto&& k = prism_rtl::as<lower::OutTy::OutMap>(t).a0;
        auto&& v_ = prism_rtl::as<lower::OutTy::OutMap>(t).a1;
        return prism_rtl::cat("Map<", cpp_type(cp, k), ", ", cpp_type(cp, v_), ">");
    }
    if (prism_rtl::is<lower::OutTy::OutFn>(t)) {
        auto&& ps = prism_rtl::as<lower::OutTy::OutFn>(t).a0;
        auto&& r = prism_rtl::as<lower::OutTy::OutFn>(t).a1;
        return prism_rtl::cat("Fn<", cpp_type(cp, r), "(", param_types(cp, ps), ")>");
    }
    if (prism_rtl::is<lower::OutTy::OutRef>(t)) {
        auto&& m10650_24_0 = prism_rtl::as<lower::OutTy::OutRef>(t).a0;
        if (prism_rtl::is<lower::OutTy::OutFn>(m10650_24_0)) {
            auto&& ps = prism_rtl::as<lower::OutTy::OutFn>(m10650_24_0).a0;
            auto&& r = prism_rtl::as<lower::OutTy::OutFn>(m10650_24_0).a1;
            return prism_rtl::cat("const std::function<", cpp_type(cp, r), "(", param_types(cp, ps), ")>&");
        }
    }
    if (prism_rtl::is<lower::OutTy::OutRef>(t)) {
        auto&& m10650_25_0 = prism_rtl::as<lower::OutTy::OutRef>(t).a0;
        if (prism_rtl::is<lower::OutTy::OutSlice>(m10650_25_0)) {
            auto&& i = prism_rtl::as<lower::OutTy::OutSlice>(m10650_25_0).a0;
            return prism_rtl::cat("std::span<const ", cpp_type(cp, i), ">");
        }
    }
    if (prism_rtl::is<lower::OutTy::OutRef>(t)) {
        auto&& i = prism_rtl::as<lower::OutTy::OutRef>(t).a0;
        return prism_rtl::cat("const ", cpp_type(cp, i), "&");
    }
    if (prism_rtl::is<lower::OutTy::OutJobFn>(t)) {
        auto&& a = prism_rtl::as<lower::OutTy::OutJobFn>(t).a0;
        auto&& b = prism_rtl::as<lower::OutTy::OutJobFn>(t).a1;
        return prism_rtl::cat("prism_rtl::Fn<prism_rtl::JobRef<", cpp_type(cp, b), ">(", cpp_type(cp, a), ")>");
    }
    if (prism_rtl::is<lower::OutTy::OutJob>(t)) {
        auto&& b = prism_rtl::as<lower::OutTy::OutJob>(t).a0;
        return prism_rtl::cat("prism_rtl::JobRef<", cpp_type(cp, b), ">");
    }
    if (prism_rtl::is<lower::OutTy::OutEvent>(t)) {
        auto&& i = prism_rtl::as<lower::OutTy::OutEvent>(t).a0;
        return prism_rtl::cat("Event<", cpp_type(cp, i), ">");
    }
    if (prism_rtl::is<lower::OutTy::OutDyn>(t)) {
        auto&& i = prism_rtl::as<lower::OutTy::OutDyn>(t).a0;
        return prism_rtl::cat("Dynamic<", cpp_type(cp, i), ">");
    }
    if (prism_rtl::is<lower::OutTy::OutGen>(t)) {
        auto&& n = prism_rtl::as<lower::OutTy::OutGen>(t).a0;
        return n;
    }
    if (prism_rtl::is<lower::OutTy::OutRc>(t)) {
        auto&& i = prism_rtl::as<lower::OutTy::OutRc>(t).a0;
        return is_value_ty(cp, i)
            ? cpp_type(cp, i)
            : prism_rtl::cat("prism_rtl::Rc<", cpp_type(cp, i), ">");
    }
    if (prism_rtl::is<lower::OutTy::OutPod>(t)) {
        return Text::lit("Pod");
    }
    if (prism_rtl::is<lower::OutTy::OutShowAny>(t)) {
        return Text::lit("prism_rtl::Rc<const DynShow>");
    }
    if (prism_rtl::is<lower::OutTy::OutHold>(t)) {
        auto&& i = prism_rtl::as<lower::OutTy::OutHold>(t).a0;
        return prism_rtl::cat("Hold<", cpp_type(cp, i), ">");
    }
    if (prism_rtl::is<lower::OutTy::OutStamped>(t)) {
        auto&& i = prism_rtl::as<lower::OutTy::OutStamped>(t).a0;
        return prism_rtl::cat("Stamped<", cpp_type(cp, i), ">");
    }
    if (prism_rtl::is<lower::OutTy::OutSnapshot>(t)) {
        auto&& i = prism_rtl::as<lower::OutTy::OutSnapshot>(t).a0;
        return prism_rtl::cat("Snapshot<", cpp_type(cp, i), ">");
    }
    if (prism_rtl::is<lower::OutTy::OutDefer>(t)) {
        auto&& i = prism_rtl::as<lower::OutTy::OutDefer>(t).a0;
        return prism_rtl::cat("Defer<", cpp_type(cp, i), ">");
    }
    if (prism_rtl::is<lower::OutTy::OutWeak>(t)) {
        auto&& n = prism_rtl::as<lower::OutTy::OutWeak>(t).a0;
        return prism_rtl::cat("prism_rtl::Weak<", type_path(n), ">");
    }
    if (prism_rtl::is<lower::OutTy::OutCell>(t)) {
        auto&& i = prism_rtl::as<lower::OutTy::OutCell>(t).a0;
        return cpp_type(cp, i);
    }
    if (prism_rtl::is<lower::OutTy::OutWakes>(t)) {
        return Text::lit("Wakes");
    }
    if (prism_rtl::is<lower::OutTy::OutCount>(t)) {
        return Text::lit("std::uint32_t");
    }
    if (prism_rtl::is<lower::OutTy::OutObj>(t)) {
        auto&& i = prism_rtl::as<lower::OutTy::OutObj>(t).a0;
        return prism_rtl::cat("prism_rtl::Rc<", cpp_type(cp, i), ">");
    }
    if (prism_rtl::is<lower::OutTy::OutSlice>(t)) {
        auto&& i = prism_rtl::as<lower::OutTy::OutSlice>(t).a0;
        return prism_rtl::cat("std::span<const ", cpp_type(cp, i), ">");
    }
    if (prism_rtl::is<lower::OutTy::OutPort>(t)) {
        auto&& i = prism_rtl::as<lower::OutTy::OutPort>(t).a0;
        return prism_rtl::cat("Port<", cpp_type(cp, i), ">");
    }
    if (prism_rtl::is<lower::OutTy::OutLive>(t)) {
        auto&& i = prism_rtl::as<lower::OutTy::OutLive>(t).a0;
        return prism_rtl::cat("Live<", cpp_type(cp, i), ">");
    }
    if (prism_rtl::is<lower::OutTy::OutUnknown>(t)) {
        auto&& m10650_47_0 = prism_rtl::as<lower::OutTy::OutUnknown>(t).a0;
        if (m10650_47_0 == Text::lit("the job's turn")) {
            return Text::lit("decltype(this->cycle())");
        }
    }
    if (prism_rtl::is<lower::OutTy::OutUnknown>(t)) {
        auto&& what = prism_rtl::as<lower::OutTy::OutUnknown>(t).a0;
        return prism_rtl::cat("Unit /* ", what, " */");
    }
    if (prism_rtl::is<lower::OutTy::OutQuantified>(t)) {
        auto&& b = prism_rtl::as<lower::OutTy::OutQuantified>(t).a0;
        return prism_rtl::cat("compile_error!(\"", lower::lowering_refusal(), "a quantified type variable of `", b, "`: no instantiation gives it a type\")");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> CppType::cycle() const {
    const auto& cp = this->cp;
    const auto& t = this->t;
    return ({
        prism_rtl::is<lower::OutTy::OutNat>(t) ? prism_rtl::finished(Text::lit("Nat"))
        : prism_rtl::is<lower::OutTy::OutInt>(t) ? prism_rtl::finished(Text::lit("Int"))
        : prism_rtl::is<lower::OutTy::OutU8>(t) ? prism_rtl::finished(Text::lit("std::uint8_t"))
        : prism_rtl::is<lower::OutTy::OutFloat>(t) ? prism_rtl::finished(Text::lit("double"))
        : prism_rtl::is<lower::OutTy::OutBool>(t) ? prism_rtl::finished(Text::lit("bool"))
        : prism_rtl::is<lower::OutTy::OutChar>(t) ? prism_rtl::finished(Text::lit("char32_t"))
        : prism_rtl::is<lower::OutTy::OutText>(t) ? prism_rtl::finished(Text::lit("Text"))
        : prism_rtl::is<lower::OutTy::OutCursor>(t) ? prism_rtl::finished(Text::lit("Cursor"))
        : prism_rtl::is<lower::OutTy::OutUnit>(t) ? prism_rtl::finished(Text::lit("Unit"))
        : prism_rtl::is<lower::OutTy::OutPath>(t) ? prism_rtl::finished(Text::lit("Path"))
        : prism_rtl::is<lower::OutTy::OutDuration>(t) ? prism_rtl::finished(Text::lit("Duration"))
        : prism_rtl::is<lower::OutTy::OutError>(t) ? prism_rtl::finished(Text::lit("Error"))
        : prism_rtl::is<lower::OutTy::OutNamed>(t) && ({
        auto&& m10650_12_0 = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& m10650_12_1 = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
        (m10650_12_0 == Text::lit("Cell")) && (m10650_12_1.size() == 1u) && ({
        auto&& _c1 = index(m10650_12_1, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m10650_12_0 = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& m10650_12_1 = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
        auto&& _c1 = index(m10650_12_1, Nat(0u));
        auto&& i = prism_rtl::some_of(_c1);
        prism_rtl::more(prism_rtl::rc(CppType(cp, i)));
    })
        : prism_rtl::is<lower::OutTy::OutNamed>(t) && ({
        auto&& m10650_13_0 = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& m10650_13_1 = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
        (m10650_13_0 == Text::lit("RefCell")) && (m10650_13_1.size() == 1u) && ({
        auto&& _c1 = index(m10650_13_1, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m10650_13_0 = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& m10650_13_1 = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
        auto&& _c1 = index(m10650_13_1, Nat(0u));
        auto&& i = prism_rtl::some_of(_c1);
        prism_rtl::more(prism_rtl::rc(CppType(cp, i)));
    })
        : prism_rtl::is<lower::OutTy::OutNamed>(t) && ({
        auto&& m10650_14_0 = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& m10650_14_1 = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
        (m10650_14_0 == Text::lit("Vec")) && (m10650_14_1.size() == 1u) && ({
        auto&& _c1 = index(m10650_14_1, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m10650_14_0 = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& m10650_14_1 = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
        auto&& _c1 = index(m10650_14_1, Nat(0u));
        auto&& i = prism_rtl::some_of(_c1);
        ({
        auto cp_1 = cp;
        call_then(start_cpp_type(cp_1, i), [=](Text cpp_type_11050) { return prism_rtl::finished(prism_rtl::cat("std::vector<", cpp_type_11050, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutNamed>(t) && ({
        auto&& m10650_15_0 = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& m10650_15_1 = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
        (m10650_15_0 == Text::lit("Result")) && (m10650_15_1.size() == 2u) && ({
        auto&& _c2 = index(m10650_15_1, Nat(0u));
        prism_rtl::is_some(_c2) && ({
        auto&& a = prism_rtl::some_of(_c2);
        ({
        auto&& _c1 = index(m10650_15_1, Nat(1u));
        prism_rtl::is_some(_c1);
    });
    });
    });
    }) ? ({
        auto&& m10650_15_0 = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& m10650_15_1 = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
        auto&& _c2 = index(m10650_15_1, Nat(0u));
        auto&& a = prism_rtl::some_of(_c2);
        auto&& _c1 = index(m10650_15_1, Nat(1u));
        auto&& b = prism_rtl::some_of(_c1);
        ({
        auto cp_1 = cp;
        call_then(start_cpp_type(cp_1, a), [=](Text cpp_type_11111) { return call_then(start_cpp_type(cp_1, b), [=](Text cpp_type_11128) { return prism_rtl::finished(prism_rtl::cat("Expected<", cpp_type_11111, ", ", cpp_type_11128, ">")); }); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutNamed>(t) && ({
        auto&& n = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& m10650_16_1 = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
        (m10650_16_1.size() == 0u);
    }) ? ({
        auto&& n = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& m10650_16_1 = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
        prism_rtl::finished(own_type_path(cp, n));
    })
        : prism_rtl::is<lower::OutTy::OutNamed>(t) ? ({
        auto&& n = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& args = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        auto n_3 = n;
        call_then(start_cpp_types(cp_2, args_1), [=](Text cpp_types_11229) { return prism_rtl::finished(prism_rtl::cat(own_type_path(cp_2, n_3), "<", cpp_types_11229, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutOpt>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutOpt>(t).a0;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_11280) { return prism_rtl::finished(prism_rtl::cat("std::optional<", cpp_type_11280, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutRes>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutRes>(t).a0;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_11322) { return prism_rtl::finished(prism_rtl::cat("Fallible<", cpp_type_11322, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutTuple>(t) ? ({
        auto&& ts = prism_rtl::as<lower::OutTy::OutTuple>(t).a0;
        ({
        auto cp_1 = cp;
        auto ts_2 = ts;
        call_then(start_cpp_types(cp_1, ts_2), [=](Text cpp_types_11369) { return prism_rtl::finished(prism_rtl::cat("std::tuple<", cpp_types_11369, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutArray>(t) ? ({
        auto&& e = prism_rtl::as<lower::OutTy::OutArray>(t).a0;
        ({
        auto cp_1 = cp;
        auto e_2 = e;
        call_then(start_cpp_type(cp_1, e_2), [=](Text cpp_type_11412) { return prism_rtl::finished(prism_rtl::cat("Array<", cpp_type_11412, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutMap>(t) ? ({
        auto&& k = prism_rtl::as<lower::OutTy::OutMap>(t).a0;
        auto&& v_ = prism_rtl::as<lower::OutTy::OutMap>(t).a1;
        ({
        auto cp_1 = cp;
        auto k_2 = k;
        auto v__3 = v_;
        call_then(start_cpp_type(cp_1, k_2), [=](Text cpp_type_11452) { return call_then(start_cpp_type(cp_1, v__3), [=](Text cpp_type_11469) { return prism_rtl::finished(prism_rtl::cat("Map<", cpp_type_11452, ", ", cpp_type_11469, ">")); }); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutFn>(t) ? ({
        auto&& ps = prism_rtl::as<lower::OutTy::OutFn>(t).a0;
        auto&& r = prism_rtl::as<lower::OutTy::OutFn>(t).a1;
        ({
        auto cp_1 = cp;
        auto ps_2 = ps;
        auto r_3 = r;
        call_then(start_cpp_type(cp_1, r_3), [=](Text cpp_type_11508) { return call_then(start_param_types(cp_1, ps_2), [=](Text param_types_11524) { return prism_rtl::finished(prism_rtl::cat("Fn<", cpp_type_11508, "(", param_types_11524, ")>")); }); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutRef>(t) && ({
        auto&& m10650_24_0 = prism_rtl::as<lower::OutTy::OutRef>(t).a0;
        prism_rtl::is<lower::OutTy::OutFn>(m10650_24_0);
    }) ? ({
        auto&& m10650_24_0 = prism_rtl::as<lower::OutTy::OutRef>(t).a0;
        auto&& ps = prism_rtl::as<lower::OutTy::OutFn>(m10650_24_0).a0;
        auto&& r = prism_rtl::as<lower::OutTy::OutFn>(m10650_24_0).a1;
        ({
        auto cp_1 = cp;
        auto ps_2 = ps;
        auto r_3 = r;
        call_then(start_cpp_type(cp_1, r_3), [=](Text cpp_type_11594) { return call_then(start_param_types(cp_1, ps_2), [=](Text param_types_11610) { return prism_rtl::finished(prism_rtl::cat("const std::function<", cpp_type_11594, "(", param_types_11610, ")>&")); }); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutRef>(t) && ({
        auto&& m10650_25_0 = prism_rtl::as<lower::OutTy::OutRef>(t).a0;
        prism_rtl::is<lower::OutTy::OutSlice>(m10650_25_0);
    }) ? ({
        auto&& m10650_25_0 = prism_rtl::as<lower::OutTy::OutRef>(t).a0;
        auto&& i = prism_rtl::as<lower::OutTy::OutSlice>(m10650_25_0).a0;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_11676) { return prism_rtl::finished(prism_rtl::cat("std::span<const ", cpp_type_11676, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutRef>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutRef>(t).a0;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_11715) { return prism_rtl::finished(prism_rtl::cat("const ", cpp_type_11715, "&")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutJobFn>(t) ? ({
        auto&& a = prism_rtl::as<lower::OutTy::OutJobFn>(t).a0;
        auto&& b = prism_rtl::as<lower::OutTy::OutJobFn>(t).a1;
        ({
        auto a_1 = a;
        auto b_2 = b;
        auto cp_3 = cp;
        call_then(start_cpp_type(cp_3, b_2), [=](Text cpp_type_11785) { return call_then(start_cpp_type(cp_3, a_1), [=](Text cpp_type_11802) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::Fn<prism_rtl::JobRef<", cpp_type_11785, ">(", cpp_type_11802, ")>")); }); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutJob>(t) ? ({
        auto&& b = prism_rtl::as<lower::OutTy::OutJob>(t).a0;
        ({
        auto b_1 = b;
        auto cp_2 = cp;
        call_then(start_cpp_type(cp_2, b_1), [=](Text cpp_type_11854) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::JobRef<", cpp_type_11854, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutEvent>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutEvent>(t).a0;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_11895) { return prism_rtl::finished(prism_rtl::cat("Event<", cpp_type_11895, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutDyn>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutDyn>(t).a0;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_11936) { return prism_rtl::finished(prism_rtl::cat("Dynamic<", cpp_type_11936, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutGen>(t) ? ({
        auto&& n = prism_rtl::as<lower::OutTy::OutGen>(t).a0;
        prism_rtl::finished(n);
    })
        : prism_rtl::is<lower::OutTy::OutRc>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutRc>(t).a0;
        is_value_ty(cp, i)
        ? prism_rtl::more(prism_rtl::rc(CppType(cp, i)))
        : ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_12038) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::Rc<", cpp_type_12038, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutPod>(t) ? prism_rtl::finished(Text::lit("Pod"))
        : prism_rtl::is<lower::OutTy::OutShowAny>(t) ? prism_rtl::finished(Text::lit("prism_rtl::Rc<const DynShow>"))
        : prism_rtl::is<lower::OutTy::OutHold>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutHold>(t).a0;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_12142) { return prism_rtl::finished(prism_rtl::cat("Hold<", cpp_type_12142, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutStamped>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutStamped>(t).a0;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_12187) { return prism_rtl::finished(prism_rtl::cat("Stamped<", cpp_type_12187, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutSnapshot>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutSnapshot>(t).a0;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_12234) { return prism_rtl::finished(prism_rtl::cat("Snapshot<", cpp_type_12234, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutDefer>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutDefer>(t).a0;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_12275) { return prism_rtl::finished(prism_rtl::cat("Defer<", cpp_type_12275, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutWeak>(t) ? ({
        auto&& n = prism_rtl::as<lower::OutTy::OutWeak>(t).a0;
        prism_rtl::finished(prism_rtl::cat("prism_rtl::Weak<", type_path(n), ">"));
    })
        : prism_rtl::is<lower::OutTy::OutCell>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutCell>(t).a0;
        prism_rtl::more(prism_rtl::rc(CppType(cp, i)));
    })
        : prism_rtl::is<lower::OutTy::OutWakes>(t) ? prism_rtl::finished(Text::lit("Wakes"))
        : prism_rtl::is<lower::OutTy::OutCount>(t) ? prism_rtl::finished(Text::lit("std::uint32_t"))
        : prism_rtl::is<lower::OutTy::OutObj>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutObj>(t).a0;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_12450) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::Rc<", cpp_type_12450, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutSlice>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutSlice>(t).a0;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_12501) { return prism_rtl::finished(prism_rtl::cat("std::span<const ", cpp_type_12501, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutPort>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutPort>(t).a0;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_12540) { return prism_rtl::finished(prism_rtl::cat("Port<", cpp_type_12540, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutLive>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutLive>(t).a0;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_12579) { return prism_rtl::finished(prism_rtl::cat("Live<", cpp_type_12579, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutUnknown>(t) && ({
        auto&& m10650_47_0 = prism_rtl::as<lower::OutTy::OutUnknown>(t).a0;
        (m10650_47_0 == Text::lit("the job's turn"));
    }) ? ({
        auto&& m10650_47_0 = prism_rtl::as<lower::OutTy::OutUnknown>(t).a0;
        prism_rtl::finished(Text::lit("decltype(this->cycle())"));
    })
        : prism_rtl::is<lower::OutTy::OutUnknown>(t) ? ({
        auto&& what = prism_rtl::as<lower::OutTy::OutUnknown>(t).a0;
        prism_rtl::finished(prism_rtl::cat("Unit /* ", what, " */"));
    })
        : prism_rtl::is<lower::OutTy::OutQuantified>(t) ? ({
        auto&& b = prism_rtl::as<lower::OutTy::OutQuantified>(t).a0;
        prism_rtl::finished(prism_rtl::cat("compile_error!(\"", lower::lowering_refusal(), "a quantified type variable of `", b, "`: no instantiation gives it a type\")"));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CppType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_type(Cp cp, lower::OutTy t) {
    return prism_rtl::make_rc<CppType>(cp, t);
}


/// CppTypes: unbounded fn Cp, [OutTy] -> Text
Text cpp_types(const Cp& cp, const Array<lower::OutTy>& ts) {
    return lexer::join(run_to_end(each_job(ts, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::OutTy)>>(prism_rtl::rc([=](lower::OutTy p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto t = p0;
                (prism_rtl::more(prism_rtl::rc(CppType(cp_1_2, t))));
            });
        }));
        });
    })));
    }))), Text::lit(", "));
}


prism_rtl::Turn<Text> CppTypes::cycle() const {
    const auto& cp = this->cp;
    const auto& ts = this->ts;
    auto cp_1 = cp;
    auto ts_2 = ts;
    return call_value(each_job(ts_2, ({
        auto cp_1_3 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::OutTy)>>(prism_rtl::rc([=](lower::OutTy p0) {
        return ({
            auto cp_1_3_3 = cp_1_3;
            entered(once_job([=]() {
            return ({
                auto t = p0;
                (prism_rtl::more(prism_rtl::rc(CppType(cp_1_3_3, t))));
            });
        }));
        });
    })));
    })), [=](Array<Text> each_12897) { return prism_rtl::finished(lexer::join(each_12897, Text::lit(", "))); });
}


/// `Start CppTypes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_types(Cp cp, Array<lower::OutTy> ts) {
    return prism_rtl::make_rc<CppTypes>(cp, ts);
}


/// ParamTypes: unbounded fn Cp, [OutTy] -> Text
Text param_types(const Cp& cp, const Array<lower::OutTy>& ts) {
    return lexer::join(run_to_end(each_job(ts, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::OutTy)>>(prism_rtl::rc([=](lower::OutTy p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto t = p0;
                call_then(start_cpp_type(cp_1_2, t), [=](Text cpp_type_13112) { return prism_rtl::finished(prism_rtl::cat("const ", cpp_type_13112, "&")); });
            });
        }));
        });
    })));
    }))), Text::lit(", "));
}


prism_rtl::Turn<Text> ParamTypes::cycle() const {
    const auto& cp = this->cp;
    const auto& ts = this->ts;
    auto cp_1 = cp;
    auto ts_2 = ts;
    return call_value(each_job(ts_2, ({
        auto cp_1_3 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::OutTy)>>(prism_rtl::rc([=](lower::OutTy p0) {
        return ({
            auto cp_1_3_3 = cp_1_3;
            entered(once_job([=]() {
            return ({
                auto t = p0;
                call_then(start_cpp_type(cp_1_3_3, t), [=](Text cpp_type_13112) { return prism_rtl::finished(prism_rtl::cat("const ", cpp_type_13112, "&")); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_13090) { return prism_rtl::finished(lexer::join(each_13090, Text::lit(", "))); });
}


/// `Start ParamTypes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_param_types(Cp cp, Array<lower::OutTy> ts) {
    return prism_rtl::make_rc<ParamTypes>(cp, ts);
}


/// OwnTypePath: fn Cp, Text -> Text
Text own_type_path(const Cp& cp, const Text& n) {
    auto shadowed = (!lexer::contains(n, Text::lit(":"))) && in_list(Array(std::vector{Text::lit("Job"), Text::lit("Node"), Text::lit("Row"), Text::lit("Turn"), Text::lit("Program")}), n);
    auto&& _m = type_of(cp, n);
    if (prism_rtl::is_some(_m)) {
        return shadowed ? prism_rtl::cat("crate::", cp.home, "::", n) : type_path(n);
    }
    if (prism_rtl::is_none(_m)) {
        return type_path(n);
    }
    prism_rtl::unreachable("no arm matched");
}


/// TypePath: fn Text -> Text
Text type_path(const Text& p_) {
    auto no_fish = lexer::join(split(p_, Text::lit("::<")), Text::lit("<"));
    auto no_holes = lexer::join(split(no_fish, Text::lit(", _>")), Text::lit(">"));
    return lexer::join(split(no_holes, Text::lit("<_>")), Text::lit(""));
}


/// IsValueTy: fn Cp, OutTy -> Bool
bool is_value_ty(const Cp& cp, const lower::OutTy& t) {
    if (prism_rtl::is<lower::OutTy::OutNamed>(t)) {
        auto&& n = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& _m = type_of(cp, n);
        if (prism_rtl::is_some(_m)) {
            auto&& info = prism_rtl::some_of(_m);
            return (info.kind != Text::lit("node")) && (info.kind != Text::lit("job"));
        }
        if (prism_rtl::is_none(_m)) {
            return false;
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<lower::OutTy::OutCell>(t)) {
        return false;
    }
    if (prism_rtl::is<lower::OutTy::OutPort>(t)) {
        return false;
    }
    if (prism_rtl::is<lower::OutTy::OutHold>(t)) {
        return false;
    }
    if (prism_rtl::is<lower::OutTy::OutStamped>(t)) {
        return false;
    }
    if (prism_rtl::is<lower::OutTy::OutSnapshot>(t)) {
        return false;
    }
    if (prism_rtl::is<lower::OutTy::OutDefer>(t)) {
        return false;
    }
    if (prism_rtl::is<lower::OutTy::OutObj>(t)) {
        return false;
    }
    if (prism_rtl::is<lower::OutTy::OutWakes>(t)) {
        return false;
    }
    {
        return true;
    }
}


/// CppLoose: fn Ex -> Bool
bool cpp_loose(const lower::Ex& x) {
    if (prism_rtl::is<lower::Ex::XBlock>(x)) {
        auto&& m14711_0_0 = prism_rtl::as<lower::Ex::XBlock>(x).a0;
        auto&& inner = prism_rtl::as<lower::Ex::XBlock>(x).a1;
        if (m14711_0_0.size() == 0u) {
            return cpp_loose(inner);
        }
    }
    if (prism_rtl::is<lower::Ex::XBin>(x)) {
        return true;
    }
    if (prism_rtl::is<lower::Ex::XUnary>(x)) {
        return true;
    }
    if (prism_rtl::is<lower::Ex::XIf>(x)) {
        return true;
    }
    if (prism_rtl::is<lower::Ex::XRef>(x)) {
        auto&& y = prism_rtl::as<lower::Ex::XRef>(x).a0;
        return cpp_loose(y);
    }
    if (prism_rtl::is<lower::Ex::XRefMut>(x)) {
        auto&& y = prism_rtl::as<lower::Ex::XRefMut>(x).a0;
        return cpp_loose(y);
    }
    if (prism_rtl::is<lower::Ex::XDeref>(x)) {
        auto&& y = prism_rtl::as<lower::Ex::XDeref>(x).a0;
        return cpp_loose(y);
    }
    if (prism_rtl::is<lower::Ex::XClone>(x)) {
        auto&& y = prism_rtl::as<lower::Ex::XClone>(x).a0;
        return cpp_loose(y);
    }
    {
        return false;
    }
}


/// CppTight: unbounded fn Cp, Ex -> Text
Text cpp_tight(const Cp& cp, const lower::Ex& x) {
    return cpp_loose(x) ? prism_rtl::cat("(", cpp_expr(cp, x), ")") : cpp_expr(cp, x);
}


prism_rtl::Turn<Text> CppTight::cycle() const {
    const auto& cp = this->cp;
    const auto& x = this->x;
    return cpp_loose(x)
        ? ({
        auto cp_1 = cp;
        auto x_2 = x;
        call_then(start_cpp_expr(cp_1, x_2), [=](Text cpp_expr_15063) { return prism_rtl::finished(prism_rtl::cat("(", cpp_expr_15063, ")")); });
    })
        : prism_rtl::more(prism_rtl::rc(CppExpr(cp, x)));
}


/// `Start CppTight, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_tight(Cp cp, lower::Ex x) {
    return prism_rtl::make_rc<CppTight>(cp, x);
}


/// CppArgs: unbounded fn Cp, [Ex] -> Text
Text cpp_args(const Cp& cp, const Array<lower::Ex>& xs) {
    return lexer::join(run_to_end(each_job(xs, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Ex)>>(prism_rtl::rc([=](lower::Ex p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto x = p0;
                (prism_rtl::more(prism_rtl::rc(CppExpr(cp_1_2, x))));
            });
        }));
        });
    })));
    }))), Text::lit(", "));
}


prism_rtl::Turn<Text> CppArgs::cycle() const {
    const auto& cp = this->cp;
    const auto& xs = this->xs;
    auto cp_1 = cp;
    auto xs_2 = xs;
    return call_value(each_job(xs_2, ({
        auto cp_1_3 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Ex)>>(prism_rtl::rc([=](lower::Ex p0) {
        return ({
            auto cp_1_3_3 = cp_1_3;
            entered(once_job([=]() {
            return ({
                auto x = p0;
                (prism_rtl::more(prism_rtl::rc(CppExpr(cp_1_3_3, x))));
            });
        }));
        });
    })));
    })), [=](Array<Text> each_15166) { return prism_rtl::finished(lexer::join(each_15166, Text::lit(", "))); });
}


/// `Start CppArgs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_args(Cp cp, Array<lower::Ex> xs) {
    return prism_rtl::make_rc<CppArgs>(cp, xs);
}


/// CppExpr: unbounded fn Cp, Ex -> Text
Text cpp_expr(const Cp& cp, const lower::Ex& x) {
    if (prism_rtl::is<lower::Ex::XVar>(x)) {
        auto&& n = prism_rtl::as<lower::Ex::XVar>(x).a0;
        return var_name(cp, n);
    }
    if (prism_rtl::is<lower::Ex::XPath>(x)) {
        auto&& p_ = prism_rtl::as<lower::Ex::XPath>(x).a0;
        return path_value(cp, p_);
    }
    if (prism_rtl::is<lower::Ex::XSelf>(x)) {
        return Text::lit("prism_rtl::share(this)");
    }
    if (prism_rtl::is<lower::Ex::XCx>(x)) {
        return Text::lit("cx");
    }
    if (prism_rtl::is<lower::Ex::XConst>(x)) {
        auto&& n = prism_rtl::as<lower::Ex::XConst>(x).a0;
        return n;
    }
    if (prism_rtl::is<lower::Ex::XUnit>(x)) {
        return Text::lit("Unit{}");
    }
    if (prism_rtl::is<lower::Ex::XNone>(x)) {
        return Text::lit("std::nullopt");
    }
    if (prism_rtl::is<lower::Ex::XBool>(x)) {
        auto&& b = prism_rtl::as<lower::Ex::XBool>(x).a0;
        return b ? Text::lit("true") : Text::lit("false");
    }
    if (prism_rtl::is<lower::Ex::XNat>(x)) {
        auto&& d = prism_rtl::as<lower::Ex::XNat>(x).a0;
        return len_text(d) <= Nat(9u)
            ? prism_rtl::cat("Nat(", d, "u)")
            : prism_rtl::cat("*Nat::from_int(", cpp_expr(cp, lower::Ex(lower::Ex::XInt{d})), ")");
    }
    if (prism_rtl::is<lower::Ex::XInt>(x)) {
        auto&& d = prism_rtl::as<lower::Ex::XInt>(x).a0;
        return len_text(lexer::has_prefix(d, Text::lit("-")) ? lexer::after_first(d) : d) <= Nat(18u)
            ? prism_rtl::cat("Int(", d, "ll)")
            : prism_rtl::cat("*Int::parse(\"", d, "\")");
    }
    if (prism_rtl::is<lower::Ex::XByte>(x)) {
        auto&& d = prism_rtl::as<lower::Ex::XByte>(x).a0;
        return prism_rtl::cat("std::uint8_t(", d, ")");
    }
    if (prism_rtl::is<lower::Ex::XFloat>(x)) {
        auto&& d = prism_rtl::as<lower::Ex::XFloat>(x).a0;
        return d;
    }
    if (prism_rtl::is<lower::Ex::XIndex>(x)) {
        auto&& n = prism_rtl::as<lower::Ex::XIndex>(x).a0;
        return prism_rtl::cat(n, "u");
    }
    if (prism_rtl::is<lower::Ex::XChar>(x)) {
        auto&& c = prism_rtl::as<lower::Ex::XChar>(x).a0;
        return prism_rtl::cat("U'", cpp_char_escape(c), "'");
    }
    if (prism_rtl::is<lower::Ex::XStr>(x)) {
        auto&& t = prism_rtl::as<lower::Ex::XStr>(x).a0;
        return cpp_string(t);
    }
    if (prism_rtl::is<lower::Ex::XRef>(x)) {
        auto&& y = prism_rtl::as<lower::Ex::XRef>(x).a0;
        return cpp_expr(cp, y);
    }
    if (prism_rtl::is<lower::Ex::XRefMut>(x)) {
        auto&& y = prism_rtl::as<lower::Ex::XRefMut>(x).a0;
        return cpp_expr(cp, y);
    }
    if (prism_rtl::is<lower::Ex::XDeref>(x)) {
        auto&& y = prism_rtl::as<lower::Ex::XDeref>(x).a0;
        return cpp_expr(cp, y);
    }
    if (prism_rtl::is<lower::Ex::XTarget>(x)) {
        auto&& y = prism_rtl::as<lower::Ex::XTarget>(x).a0;
        return cpp_expr(cp, y);
    }
    if (prism_rtl::is<lower::Ex::XClone>(x)) {
        auto&& y = prism_rtl::as<lower::Ex::XClone>(x).a0;
        return cpp_expr(cp, y);
    }
    if (prism_rtl::is<lower::Ex::XWeak>(x)) {
        auto&& y = prism_rtl::as<lower::Ex::XWeak>(x).a0;
        return prism_rtl::cat("prism_rtl::weaken(", cpp_expr(cp, y), ")");
    }
    if (prism_rtl::is<lower::Ex::XUpgrade>(x)) {
        auto&& y = prism_rtl::as<lower::Ex::XUpgrade>(x).a0;
        return prism_rtl::cat("prism_rtl::upgrade(", cpp_expr(cp, y), ")");
    }
    if (prism_rtl::is<lower::Ex::XBreak>(x)) {
        auto&& l = prism_rtl::as<lower::Ex::XBreak>(x).a0;
        auto&& y = prism_rtl::as<lower::Ex::XBreak>(x).a1;
        return prism_rtl::cat("(", cpp_break(cp, l, y), ")");
    }
    if (prism_rtl::is<lower::Ex::XBreakLoop>(x)) {
        return Text::lit("({ break; })");
    }
    if (prism_rtl::is<lower::Ex::XLater>(x)) {
        auto&& y = prism_rtl::as<lower::Ex::XLater>(x).a0;
        return prism_rtl::cat("[=](Cx& cx) -> Done { ", cpp_expr(cp, y), "; return {}; }");
    }
    if (prism_rtl::is<lower::Ex::XFormatStr>(x)) {
        auto&& parts = prism_rtl::as<lower::Ex::XFormatStr>(x).a0;
        return cpp_format(cp, parts, Text::lit("prism_rtl::str"));
    }
    if (prism_rtl::is<lower::Ex::XIsCase>(x)) {
        auto&& y = prism_rtl::as<lower::Ex::XIsCase>(x).a0;
        auto&& m15258_26_1 = prism_rtl::as<lower::Ex::XIsCase>(x).a1;
        if (m15258_26_1.size() == 0u) {
            return Text::lit("false");
        }
    }
    if (prism_rtl::is<lower::Ex::XIsCase>(x)) {
        auto&& y = prism_rtl::as<lower::Ex::XIsCase>(x).a0;
        auto&& cs = prism_rtl::as<lower::Ex::XIsCase>(x).a1;
        return prism_rtl::cat("(", lexer::join(run_to_end(each_job(cs, ({
            auto cp_1 = cp;
            auto y_2 = y;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Text)>>(prism_rtl::rc([=](Text p0) {
            return ({
                auto cp_1_3 = cp_1;
                auto y_2_3 = y_2;
                entered(once_job([=]() {
                return ({
                    auto c = p0;
                    call_then(start_cpp_tight(cp_1_3, y_2_3), [=](Text cpp_tight_16348) { return prism_rtl::finished(case_test(cp_1_3, c, cpp_tight_16348)); });
                });
            }));
            });
        })));
        }))), Text::lit(" || ")), ")");
    }
    if (prism_rtl::is<lower::Ex::XRefusal>(x)) {
        auto&& what = prism_rtl::as<lower::Ex::XRefusal>(x).a0;
        return prism_rtl::cat("compile_error!(\"", lower::lowering_refusal(), lower::escape(what), "\")");
    }
    if (prism_rtl::is<lower::Ex::XUnreachable>(x)) {
        return Text::lit("throw prism_rtl::Panic(\"entered unreachable code\")");
    }
    if (prism_rtl::is<lower::Ex::XCall>(x)) {
        auto&& f = prism_rtl::as<lower::Ex::XCall>(x).a0;
        auto&& args = prism_rtl::as<lower::Ex::XCall>(x).a1;
        return cpp_call(cp, f, args);
    }
    if (prism_rtl::is<lower::Ex::XApply>(x)) {
        auto&& f = prism_rtl::as<lower::Ex::XApply>(x).a0;
        auto&& args = prism_rtl::as<lower::Ex::XApply>(x).a1;
        return prism_rtl::cat(cpp_tight(cp, f), "(", cpp_args(cp, args), ")");
    }
    if (prism_rtl::is<lower::Ex::XMethod>(x)) {
        auto&& r = prism_rtl::as<lower::Ex::XMethod>(x).a0;
        auto&& m = prism_rtl::as<lower::Ex::XMethod>(x).a1;
        auto&& args = prism_rtl::as<lower::Ex::XMethod>(x).a2;
        return cpp_method(cp, r, m, args);
    }
    if (prism_rtl::is<lower::Ex::XBin>(x)) {
        auto&& op = prism_rtl::as<lower::Ex::XBin>(x).a0;
        auto&& l = prism_rtl::as<lower::Ex::XBin>(x).a1;
        auto&& r = prism_rtl::as<lower::Ex::XBin>(x).a2;
        return prism_rtl::cat(cpp_tight(cp, l), " ", op, " ", cpp_tight(cp, r));
    }
    if (prism_rtl::is<lower::Ex::XUnary>(x)) {
        auto&& op = prism_rtl::as<lower::Ex::XUnary>(x).a0;
        auto&& y = prism_rtl::as<lower::Ex::XUnary>(x).a1;
        return prism_rtl::cat(op, cpp_tight(cp, y));
    }
    if (prism_rtl::is<lower::Ex::XCtor>(x)) {
        auto&& p_ = prism_rtl::as<lower::Ex::XCtor>(x).a0;
        auto&& args = prism_rtl::as<lower::Ex::XCtor>(x).a1;
        return cpp_ctor(cp, p_, args);
    }
    if (prism_rtl::is<lower::Ex::XRecord>(x)) {
        auto&& p_ = prism_rtl::as<lower::Ex::XRecord>(x).a0;
        auto&& fs = prism_rtl::as<lower::Ex::XRecord>(x).a1;
        return cpp_record(cp, p_, fs);
    }
    if (prism_rtl::is<lower::Ex::XTuple>(x)) {
        auto&& xs = prism_rtl::as<lower::Ex::XTuple>(x).a0;
        return prism_rtl::cat("std::tuple{", cpp_args(cp, xs), "}");
    }
    if (prism_rtl::is<lower::Ex::XVec>(x)) {
        auto&& m15258_38_0 = prism_rtl::as<lower::Ex::XVec>(x).a0;
        if (m15258_38_0.size() == 0u) {
            return Text::lit("{}");
        }
    }
    if (prism_rtl::is<lower::Ex::XVec>(x)) {
        auto&& xs = prism_rtl::as<lower::Ex::XVec>(x).a0;
        return prism_rtl::cat("std::vector{", cpp_args(cp, xs), "}");
    }
    if (prism_rtl::is<lower::Ex::XText>(x)) {
        auto&& t = prism_rtl::as<lower::Ex::XText>(x).a0;
        return prism_rtl::cat("Text::lit(", cpp_string(t), ")");
    }
    if (prism_rtl::is<lower::Ex::XFormat>(x)) {
        auto&& parts = prism_rtl::as<lower::Ex::XFormat>(x).a0;
        return fold(parts, true, [&](const bool& f, const lower::Ex& p_) { return f && is_text_piece(p_); })
            ? prism_rtl::cat("Text::lit(", cpp_string(concat(each(parts, [&](const lower::Ex& p_) { return text_piece(p_); }))), ")")
            : cpp_format(cp, parts, Text::lit("prism_rtl::cat"));
    }
    if (prism_rtl::is<lower::Ex::XMatch>(x)) {
        auto&& s = prism_rtl::as<lower::Ex::XMatch>(x).a0;
        auto&& arms = prism_rtl::as<lower::Ex::XMatch>(x).a1;
        auto&& fallback = prism_rtl::as<lower::Ex::XMatch>(x).a2;
        auto&& t = prism_rtl::as<lower::Ex::XMatch>(x).a3;
        return cpp_match(cp, s, arms, t);
    }
    if (prism_rtl::is<lower::Ex::XChain>(x)) {
        auto&& label = prism_rtl::as<lower::Ex::XChain>(x).a0;
        auto&& s = prism_rtl::as<lower::Ex::XChain>(x).a1;
        auto&& arms = prism_rtl::as<lower::Ex::XChain>(x).a2;
        auto&& t = prism_rtl::as<lower::Ex::XChain>(x).a3;
        return cpp_match(cp, s, arms, t);
    }
    if (prism_rtl::is<lower::Ex::XIf>(x)) {
        auto&& c = prism_rtl::as<lower::Ex::XIf>(x).a0;
        auto&& t = prism_rtl::as<lower::Ex::XIf>(x).a1;
        auto&& e = prism_rtl::as<lower::Ex::XIf>(x).a2;
        return cpp_if(cp, c, t, e);
    }
    if (prism_rtl::is<lower::Ex::XBlock>(x)) {
        auto&& m15258_45_0 = prism_rtl::as<lower::Ex::XBlock>(x).a0;
        auto&& e = prism_rtl::as<lower::Ex::XBlock>(x).a1;
        if (m15258_45_0.size() == 0u) {
            return cpp_expr(cp, e);
        }
    }
    if (prism_rtl::is<lower::Ex::XBlock>(x)) {
        auto&& dos = prism_rtl::as<lower::Ex::XBlock>(x).a0;
        auto&& e = prism_rtl::as<lower::Ex::XBlock>(x).a1;
        auto [st, cp2] = cpp_statements_cp(cp, dos);
        return cpp_templates::stmt_expr(st, unvexed(cpp_expr(cp2, e)));
    }
    if (prism_rtl::is<lower::Ex::XLabeled>(x)) {
        auto&& label = prism_rtl::as<lower::Ex::XLabeled>(x).a0;
        auto&& dos = prism_rtl::as<lower::Ex::XLabeled>(x).a1;
        auto&& e = prism_rtl::as<lower::Ex::XLabeled>(x).a2;
        auto&& t = prism_rtl::as<lower::Ex::XLabeled>(x).a3;
        return cpp_labeled(cp, label, dos, e, t);
    }
    if (prism_rtl::is<lower::Ex::XClosure>(x)) {
        auto&& mv = prism_rtl::as<lower::Ex::XClosure>(x).a0;
        auto&& ps = prism_rtl::as<lower::Ex::XClosure>(x).a1;
        auto&& body = prism_rtl::as<lower::Ex::XClosure>(x).a2;
        return cpp_closure(cp, mv, ps, body);
    }
    if (prism_rtl::is<lower::Ex::XTry>(x)) {
        auto&& y = prism_rtl::as<lower::Ex::XTry>(x).a0;
        return prism_rtl::cat("TRY(", cpp_expr(cp, y), ")");
    }
    if (prism_rtl::is<lower::Ex::XField>(x)) {
        auto&& r = prism_rtl::as<lower::Ex::XField>(x).a0;
        auto&& f = prism_rtl::as<lower::Ex::XField>(x).a1;
        return cpp_field(cp, r, f);
    }
    if (prism_rtl::is<lower::Ex::XPart>(x)) {
        auto&& r = prism_rtl::as<lower::Ex::XPart>(x).a0;
        auto&& k = prism_rtl::as<lower::Ex::XPart>(x).a1;
        return prism_rtl::cat("std::get<", k, ">(", cpp_expr(cp, r), ")");
    }
    if (prism_rtl::is<lower::Ex::XDecode>(x)) {
        auto&& t = prism_rtl::as<lower::Ex::XDecode>(x).a0;
        auto&& y = prism_rtl::as<lower::Ex::XDecode>(x).a1;
        return prism_rtl::cat("TRY(prism_rtl::from_pod<", cpp_type(cp, t), ">(", cpp_expr(cp, y), "))");
    }
    if (prism_rtl::is<lower::Ex::XCast>(x)) {
        auto&& y = prism_rtl::as<lower::Ex::XCast>(x).a0;
        auto&& t = prism_rtl::as<lower::Ex::XCast>(x).a1;
        return prism_rtl::cat("static_cast<", cpp_type(cp, t), ">(", cpp_expr(cp, y), ")");
    }
    if (prism_rtl::is<lower::Ex::XTyped>(x)) {
        auto&& y = prism_rtl::as<lower::Ex::XTyped>(x).a0;
        auto&& t = prism_rtl::as<lower::Ex::XTyped>(x).a1;
        auto e = cpp_expr(cp, y);
        return (e == Text::lit("{}")) || (e == Text::lit("std::nullopt"))
            ? prism_rtl::cat(cpp_type(cp, t), "{}")
            : is_ctor(y, Text::lit("Ok")) || is_ctor(y, Text::lit("Err"))
            ? prism_rtl::cat(cpp_type(cp, t), "(", e, ")")
            : e;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> CppExpr::cycle() const {
    const auto& cp = this->cp;
    const auto& x = this->x;
    return ({
        prism_rtl::is<lower::Ex::XVar>(x) ? ({
        auto&& n = prism_rtl::as<lower::Ex::XVar>(x).a0;
        prism_rtl::finished(var_name(cp, n));
    })
        : prism_rtl::is<lower::Ex::XPath>(x) ? ({
        auto&& p_ = prism_rtl::as<lower::Ex::XPath>(x).a0;
        prism_rtl::finished(path_value(cp, p_));
    })
        : prism_rtl::is<lower::Ex::XSelf>(x) ? prism_rtl::finished(Text::lit("prism_rtl::share(this)"))
        : prism_rtl::is<lower::Ex::XCx>(x) ? prism_rtl::finished(Text::lit("cx"))
        : prism_rtl::is<lower::Ex::XConst>(x) ? ({
        auto&& n = prism_rtl::as<lower::Ex::XConst>(x).a0;
        prism_rtl::finished(n);
    })
        : prism_rtl::is<lower::Ex::XUnit>(x) ? prism_rtl::finished(Text::lit("Unit{}"))
        : prism_rtl::is<lower::Ex::XNone>(x) ? prism_rtl::finished(Text::lit("std::nullopt"))
        : prism_rtl::is<lower::Ex::XBool>(x) ? ({
        auto&& b = prism_rtl::as<lower::Ex::XBool>(x).a0;
        b
        ? prism_rtl::finished(Text::lit("true"))
        : prism_rtl::finished(Text::lit("false"));
    })
        : prism_rtl::is<lower::Ex::XNat>(x) ? ({
        auto&& d = prism_rtl::as<lower::Ex::XNat>(x).a0;
        len_text(d) <= Nat(9u)
        ? prism_rtl::finished(prism_rtl::cat("Nat(", d, "u)"))
        : ({
        auto cp_1 = cp;
        auto d_2 = d;
        call_then(start_cpp_expr(cp_1, lower::Ex(lower::Ex::XInt{d_2})), [=](Text cpp_expr_15540) { return prism_rtl::finished(prism_rtl::cat("*Nat::from_int(", cpp_expr_15540, ")")); });
    });
    })
        : prism_rtl::is<lower::Ex::XInt>(x) ? ({
        auto&& d = prism_rtl::as<lower::Ex::XInt>(x).a0;
        len_text(lexer::has_prefix(d, Text::lit("-")) ? lexer::after_first(d) : d) <= Nat(18u)
        ? prism_rtl::finished(prism_rtl::cat("Int(", d, "ll)"))
        : prism_rtl::finished(prism_rtl::cat("*Int::parse(\"", d, "\")"));
    })
        : prism_rtl::is<lower::Ex::XByte>(x) ? ({
        auto&& d = prism_rtl::as<lower::Ex::XByte>(x).a0;
        prism_rtl::finished(prism_rtl::cat("std::uint8_t(", d, ")"));
    })
        : prism_rtl::is<lower::Ex::XFloat>(x) ? ({
        auto&& d = prism_rtl::as<lower::Ex::XFloat>(x).a0;
        prism_rtl::finished(d);
    })
        : prism_rtl::is<lower::Ex::XIndex>(x) ? ({
        auto&& n = prism_rtl::as<lower::Ex::XIndex>(x).a0;
        prism_rtl::finished(prism_rtl::cat(n, "u"));
    })
        : prism_rtl::is<lower::Ex::XChar>(x) ? ({
        auto&& c = prism_rtl::as<lower::Ex::XChar>(x).a0;
        prism_rtl::finished(prism_rtl::cat("U'", cpp_char_escape(c), "'"));
    })
        : prism_rtl::is<lower::Ex::XStr>(x) ? ({
        auto&& t = prism_rtl::as<lower::Ex::XStr>(x).a0;
        prism_rtl::finished(cpp_string(t));
    })
        : prism_rtl::is<lower::Ex::XRef>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XRef>(x).a0;
        prism_rtl::more(prism_rtl::rc(CppExpr(cp, y)));
    })
        : prism_rtl::is<lower::Ex::XRefMut>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XRefMut>(x).a0;
        prism_rtl::more(prism_rtl::rc(CppExpr(cp, y)));
    })
        : prism_rtl::is<lower::Ex::XDeref>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XDeref>(x).a0;
        prism_rtl::more(prism_rtl::rc(CppExpr(cp, y)));
    })
        : prism_rtl::is<lower::Ex::XTarget>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XTarget>(x).a0;
        prism_rtl::more(prism_rtl::rc(CppExpr(cp, y)));
    })
        : prism_rtl::is<lower::Ex::XClone>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XClone>(x).a0;
        prism_rtl::more(prism_rtl::rc(CppExpr(cp, y)));
    })
        : prism_rtl::is<lower::Ex::XWeak>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XWeak>(x).a0;
        ({
        auto cp_1 = cp;
        auto y_2 = y;
        call_then(start_cpp_expr(cp_1, y_2), [=](Text cpp_expr_15983) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::weaken(", cpp_expr_15983, ")")); });
    });
    })
        : prism_rtl::is<lower::Ex::XUpgrade>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XUpgrade>(x).a0;
        ({
        auto cp_1 = cp;
        auto y_2 = y;
        call_then(start_cpp_expr(cp_1, y_2), [=](Text cpp_expr_16037) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::upgrade(", cpp_expr_16037, ")")); });
    });
    })
        : prism_rtl::is<lower::Ex::XBreak>(x) ? ({
        auto&& l = prism_rtl::as<lower::Ex::XBreak>(x).a0;
        auto&& y = prism_rtl::as<lower::Ex::XBreak>(x).a1;
        ({
        auto cp_1 = cp;
        auto l_2 = l;
        auto y_3 = y;
        call_then(start_cpp_break(cp_1, l_2, y_3), [=](Text cpp_break_16074) { return prism_rtl::finished(prism_rtl::cat("(", cpp_break_16074, ")")); });
    });
    })
        : prism_rtl::is<lower::Ex::XBreakLoop>(x) ? prism_rtl::finished(Text::lit("({ break; })"))
        : prism_rtl::is<lower::Ex::XLater>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XLater>(x).a0;
        ({
        auto cp_1 = cp;
        auto y_2 = y;
        call_then(start_cpp_expr(cp_1, y_2), [=](Text cpp_expr_16167) { return prism_rtl::finished(prism_rtl::cat("[=](Cx& cx) -> Done { ", cpp_expr_16167, "; return {}; }")); });
    });
    })
        : prism_rtl::is<lower::Ex::XFormatStr>(x) ? ({
        auto&& parts = prism_rtl::as<lower::Ex::XFormatStr>(x).a0;
        prism_rtl::more(prism_rtl::rc(CppFormat(cp, parts, Text::lit("prism_rtl::str"))));
    })
        : prism_rtl::is<lower::Ex::XIsCase>(x) && ({
        auto&& y = prism_rtl::as<lower::Ex::XIsCase>(x).a0;
        auto&& m15258_26_1 = prism_rtl::as<lower::Ex::XIsCase>(x).a1;
        (m15258_26_1.size() == 0u);
    }) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XIsCase>(x).a0;
        auto&& m15258_26_1 = prism_rtl::as<lower::Ex::XIsCase>(x).a1;
        prism_rtl::finished(Text::lit("false"));
    })
        : prism_rtl::is<lower::Ex::XIsCase>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XIsCase>(x).a0;
        auto&& cs = prism_rtl::as<lower::Ex::XIsCase>(x).a1;
        ({
        auto cp_1 = cp;
        auto cs_2 = cs;
        auto y_3 = y;
        call_value(each_job(cs_2, ({
        auto cp_1_4 = cp_1;
        auto y_3_4 = y_3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Text)>>(prism_rtl::rc([=](Text p0) {
        return ({
            auto cp_1_4_4 = cp_1_4;
            auto y_3_4_4 = y_3_4;
            entered(once_job([=]() {
            return ({
                auto c = p0;
                call_then(start_cpp_tight(cp_1_4_4, y_3_4_4), [=](Text cpp_tight_16348) { return prism_rtl::finished(case_test(cp_1_4_4, c, cpp_tight_16348)); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_16317) { return prism_rtl::finished(prism_rtl::cat("(", lexer::join(each_16317, Text::lit(" || ")), ")")); });
    });
    })
        : prism_rtl::is<lower::Ex::XRefusal>(x) ? ({
        auto&& what = prism_rtl::as<lower::Ex::XRefusal>(x).a0;
        prism_rtl::finished(prism_rtl::cat("compile_error!(\"", lower::lowering_refusal(), lower::escape(what), "\")"));
    })
        : prism_rtl::is<lower::Ex::XUnreachable>(x) ? prism_rtl::finished(Text::lit("throw prism_rtl::Panic(\"entered unreachable code\")"))
        : prism_rtl::is<lower::Ex::XCall>(x) ? ({
        auto&& f = prism_rtl::as<lower::Ex::XCall>(x).a0;
        auto&& args = prism_rtl::as<lower::Ex::XCall>(x).a1;
        prism_rtl::more(prism_rtl::rc(CppCall(cp, f, args)));
    })
        : prism_rtl::is<lower::Ex::XApply>(x) ? ({
        auto&& f = prism_rtl::as<lower::Ex::XApply>(x).a0;
        auto&& args = prism_rtl::as<lower::Ex::XApply>(x).a1;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        auto f_3 = f;
        call_then(start_cpp_tight(cp_2, f_3), [=](Text cpp_tight_16582) { return call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_16599) { return prism_rtl::finished(prism_rtl::cat(cpp_tight_16582, "(", cpp_args_16599, ")")); }); });
    });
    })
        : prism_rtl::is<lower::Ex::XMethod>(x) ? ({
        auto&& r = prism_rtl::as<lower::Ex::XMethod>(x).a0;
        auto&& m = prism_rtl::as<lower::Ex::XMethod>(x).a1;
        auto&& args = prism_rtl::as<lower::Ex::XMethod>(x).a2;
        prism_rtl::more(prism_rtl::rc(CppMethod(cp, r, m, args)));
    })
        : prism_rtl::is<lower::Ex::XBin>(x) ? ({
        auto&& op = prism_rtl::as<lower::Ex::XBin>(x).a0;
        auto&& l = prism_rtl::as<lower::Ex::XBin>(x).a1;
        auto&& r = prism_rtl::as<lower::Ex::XBin>(x).a2;
        ({
        auto cp_1 = cp;
        auto l_2 = l;
        auto op_3 = op;
        auto r_4 = r;
        call_then(start_cpp_tight(cp_1, l_2), [=](Text cpp_tight_16689) { return call_then(start_cpp_tight(cp_1, r_4), [=](Text cpp_tight_16711) { return prism_rtl::finished(prism_rtl::cat(cpp_tight_16689, " ", op_3, " ", cpp_tight_16711)); }); });
    });
    })
        : prism_rtl::is<lower::Ex::XUnary>(x) ? ({
        auto&& op = prism_rtl::as<lower::Ex::XUnary>(x).a0;
        auto&& y = prism_rtl::as<lower::Ex::XUnary>(x).a1;
        ({
        auto cp_1 = cp;
        auto op_2 = op;
        auto y_3 = y;
        call_then(start_cpp_tight(cp_1, y_3), [=](Text cpp_tight_16752) { return prism_rtl::finished(prism_rtl::cat(op_2, cpp_tight_16752)); });
    });
    })
        : prism_rtl::is<lower::Ex::XCtor>(x) ? ({
        auto&& p_ = prism_rtl::as<lower::Ex::XCtor>(x).a0;
        auto&& args = prism_rtl::as<lower::Ex::XCtor>(x).a1;
        prism_rtl::more(prism_rtl::rc(CppCtor(cp, p_, args)));
    })
        : prism_rtl::is<lower::Ex::XRecord>(x) ? ({
        auto&& p_ = prism_rtl::as<lower::Ex::XRecord>(x).a0;
        auto&& fs = prism_rtl::as<lower::Ex::XRecord>(x).a1;
        prism_rtl::more(prism_rtl::rc(CppRecord(cp, p_, fs)));
    })
        : prism_rtl::is<lower::Ex::XTuple>(x) ? ({
        auto&& xs = prism_rtl::as<lower::Ex::XTuple>(x).a0;
        ({
        auto cp_1 = cp;
        auto xs_2 = xs;
        call_then(start_cpp_args(cp_1, xs_2), [=](Text cpp_args_16876) { return prism_rtl::finished(prism_rtl::cat("std::tuple{", cpp_args_16876, "}")); });
    });
    })
        : prism_rtl::is<lower::Ex::XVec>(x) && ({
        auto&& m15258_38_0 = prism_rtl::as<lower::Ex::XVec>(x).a0;
        (m15258_38_0.size() == 0u);
    }) ? ({
        auto&& m15258_38_0 = prism_rtl::as<lower::Ex::XVec>(x).a0;
        prism_rtl::finished(Text::lit("{}"));
    })
        : prism_rtl::is<lower::Ex::XVec>(x) ? ({
        auto&& xs = prism_rtl::as<lower::Ex::XVec>(x).a0;
        ({
        auto cp_1 = cp;
        auto xs_2 = xs;
        call_then(start_cpp_args(cp_1, xs_2), [=](Text cpp_args_16945) { return prism_rtl::finished(prism_rtl::cat("std::vector{", cpp_args_16945, "}")); });
    });
    })
        : prism_rtl::is<lower::Ex::XText>(x) ? ({
        auto&& t = prism_rtl::as<lower::Ex::XText>(x).a0;
        prism_rtl::finished(prism_rtl::cat("Text::lit(", cpp_string(t), ")"));
    })
        : prism_rtl::is<lower::Ex::XFormat>(x) ? ({
        auto&& parts = prism_rtl::as<lower::Ex::XFormat>(x).a0;
        fold(parts, true, [&](const bool& f, const lower::Ex& p_) { return f && is_text_piece(p_); })
        ? prism_rtl::finished(prism_rtl::cat("Text::lit(", cpp_string(concat(each(parts, [&](const lower::Ex& p_) { return text_piece(p_); }))), ")"))
        : prism_rtl::more(prism_rtl::rc(CppFormat(cp, parts, Text::lit("prism_rtl::cat"))));
    })
        : prism_rtl::is<lower::Ex::XMatch>(x) ? ({
        auto&& s = prism_rtl::as<lower::Ex::XMatch>(x).a0;
        auto&& arms = prism_rtl::as<lower::Ex::XMatch>(x).a1;
        auto&& fallback = prism_rtl::as<lower::Ex::XMatch>(x).a2;
        auto&& t = prism_rtl::as<lower::Ex::XMatch>(x).a3;
        prism_rtl::more(prism_rtl::rc(CppMatch(cp, s, arms, t)));
    })
        : prism_rtl::is<lower::Ex::XChain>(x) ? ({
        auto&& label = prism_rtl::as<lower::Ex::XChain>(x).a0;
        auto&& s = prism_rtl::as<lower::Ex::XChain>(x).a1;
        auto&& arms = prism_rtl::as<lower::Ex::XChain>(x).a2;
        auto&& t = prism_rtl::as<lower::Ex::XChain>(x).a3;
        prism_rtl::more(prism_rtl::rc(CppMatch(cp, s, arms, t)));
    })
        : prism_rtl::is<lower::Ex::XIf>(x) ? ({
        auto&& c = prism_rtl::as<lower::Ex::XIf>(x).a0;
        auto&& t = prism_rtl::as<lower::Ex::XIf>(x).a1;
        auto&& e = prism_rtl::as<lower::Ex::XIf>(x).a2;
        prism_rtl::more(prism_rtl::rc(CppIf(cp, c, t, e)));
    })
        : prism_rtl::is<lower::Ex::XBlock>(x) && ({
        auto&& m15258_45_0 = prism_rtl::as<lower::Ex::XBlock>(x).a0;
        auto&& e = prism_rtl::as<lower::Ex::XBlock>(x).a1;
        (m15258_45_0.size() == 0u);
    }) ? ({
        auto&& m15258_45_0 = prism_rtl::as<lower::Ex::XBlock>(x).a0;
        auto&& e = prism_rtl::as<lower::Ex::XBlock>(x).a1;
        prism_rtl::more(prism_rtl::rc(CppExpr(cp, e)));
    })
        : prism_rtl::is<lower::Ex::XBlock>(x) ? ({
        auto&& dos = prism_rtl::as<lower::Ex::XBlock>(x).a0;
        auto&& e = prism_rtl::as<lower::Ex::XBlock>(x).a1;
        ({
        auto cp_1 = cp;
        auto dos_2 = dos;
        auto e_3 = e;
        call_then(start_cpp_statements_cp(cp_1, dos_2), [=](std::tuple<Text, Cp> cpp_statements_cp_17407) {
        return ({
            auto [st, cp2] = cpp_statements_cp_17407;
            call_then(start_cpp_expr(cp2, e_3), [=](Text cpp_expr_17462) { return prism_rtl::finished(cpp_templates::stmt_expr(st, unvexed(cpp_expr_17462))); });
        });
    });
    });
    })
        : prism_rtl::is<lower::Ex::XLabeled>(x) ? ({
        auto&& label = prism_rtl::as<lower::Ex::XLabeled>(x).a0;
        auto&& dos = prism_rtl::as<lower::Ex::XLabeled>(x).a1;
        auto&& e = prism_rtl::as<lower::Ex::XLabeled>(x).a2;
        auto&& t = prism_rtl::as<lower::Ex::XLabeled>(x).a3;
        prism_rtl::more(prism_rtl::rc(CppLabeled(cp, label, dos, e, t)));
    })
        : prism_rtl::is<lower::Ex::XClosure>(x) ? ({
        auto&& mv = prism_rtl::as<lower::Ex::XClosure>(x).a0;
        auto&& ps = prism_rtl::as<lower::Ex::XClosure>(x).a1;
        auto&& body = prism_rtl::as<lower::Ex::XClosure>(x).a2;
        prism_rtl::more(prism_rtl::rc(CppClosure(cp, mv, ps, body)));
    })
        : prism_rtl::is<lower::Ex::XTry>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XTry>(x).a0;
        ({
        auto cp_1 = cp;
        auto y_2 = y;
        call_then(start_cpp_expr(cp_1, y_2), [=](Text cpp_expr_17615) { return prism_rtl::finished(prism_rtl::cat("TRY(", cpp_expr_17615, ")")); });
    });
    })
        : prism_rtl::is<lower::Ex::XField>(x) ? ({
        auto&& r = prism_rtl::as<lower::Ex::XField>(x).a0;
        auto&& f = prism_rtl::as<lower::Ex::XField>(x).a1;
        prism_rtl::more(prism_rtl::rc(CppField(cp, r, f)));
    })
        : prism_rtl::is<lower::Ex::XPart>(x) ? ({
        auto&& r = prism_rtl::as<lower::Ex::XPart>(x).a0;
        auto&& k = prism_rtl::as<lower::Ex::XPart>(x).a1;
        ({
        auto cp_1 = cp;
        auto k_2 = k;
        auto r_3 = r;
        call_then(start_cpp_expr(cp_1, r_3), [=](Text cpp_expr_17699) { return prism_rtl::finished(prism_rtl::cat("std::get<", k_2, ">(", cpp_expr_17699, ")")); });
    });
    })
        : prism_rtl::is<lower::Ex::XDecode>(x) ? ({
        auto&& t = prism_rtl::as<lower::Ex::XDecode>(x).a0;
        auto&& y = prism_rtl::as<lower::Ex::XDecode>(x).a1;
        ({
        auto cp_1 = cp;
        auto t_2 = t;
        auto y_3 = y;
        call_then(start_cpp_type(cp_1, t_2), [=](Text cpp_type_17760) { return call_then(start_cpp_expr(cp_1, y_3), [=](Text cpp_expr_17777) { return prism_rtl::finished(prism_rtl::cat("TRY(prism_rtl::from_pod<", cpp_type_17760, ">(", cpp_expr_17777, "))")); }); });
    });
    })
        : prism_rtl::is<lower::Ex::XCast>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XCast>(x).a0;
        auto&& t = prism_rtl::as<lower::Ex::XCast>(x).a1;
        ({
        auto cp_1 = cp;
        auto t_2 = t;
        auto y_3 = y;
        call_then(start_cpp_type(cp_1, t_2), [=](Text cpp_type_17825) { return call_then(start_cpp_expr(cp_1, y_3), [=](Text cpp_expr_17842) { return prism_rtl::finished(prism_rtl::cat("static_cast<", cpp_type_17825, ">(", cpp_expr_17842, ")")); }); });
    });
    })
        : prism_rtl::is<lower::Ex::XTyped>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XTyped>(x).a0;
        auto&& t = prism_rtl::as<lower::Ex::XTyped>(x).a1;
        ({
        auto cp_1 = cp;
        auto t_2 = t;
        auto y_3 = y;
        call_then(start_cpp_expr(cp_1, y_3), [=](Text cpp_expr_17892) {
        return ({
            auto e = cpp_expr_17892;
            (e == Text::lit("{}")) || (e == Text::lit("std::nullopt"))
            ? call_then(start_cpp_type(cp_1, t_2), [=](Text cpp_type_17955) { return prism_rtl::finished(prism_rtl::cat(cpp_type_17955, "{}")); })
            : is_ctor(y_3, Text::lit("Ok")) || is_ctor(y_3, Text::lit("Err"))
            ? call_then(start_cpp_type(cp_1, t_2), [=](Text cpp_type_18031) { return prism_rtl::finished(prism_rtl::cat(cpp_type_18031, "(", e, ")")); })
            : prism_rtl::finished(e);
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CppExpr, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_expr(Cp cp, lower::Ex x) {
    return prism_rtl::make_rc<CppExpr>(cp, x);
}


/// CppString: fn Text -> Text
Text cpp_string(const Text& t) {
    return lexer::contains(t, Text::lit("\000"sv))
        ? prism_rtl::cat("\"", cpp_escape(t), "\"sv")
        : prism_rtl::cat("\"", cpp_escape(t), "\"");
}


/// CppEscape: fn Text -> Text
Text cpp_escape(const Text& t) {
    return lexer::map_chars(t, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Text)>>(prism_rtl::rc([=](Text p0) {
        return once_job([=]() {
            return ({
                auto c = p0;
                c == Text::lit("\000"sv)
                ? prism_rtl::finished(Text::lit("\\000"))
                : prism_rtl::finished(lower::char_escape(c));
            });
        });
    })));
}


/// IsTextPiece: fn Ex -> Bool
bool is_text_piece(const lower::Ex& ex0) {
    if (prism_rtl::is<lower::Ex::XText>(ex0)) {
        return true;
    }
    {
        auto&& other = ex0;
        return false;
    }
}


/// TextPiece: fn Ex -> Text
Text text_piece(const lower::Ex& ex0) {
    if (prism_rtl::is<lower::Ex::XText>(ex0)) {
        auto&& t = prism_rtl::as<lower::Ex::XText>(ex0).a0;
        return t;
    }
    {
        auto&& other = ex0;
        return Text::lit("");
    }
}


/// CppFormat: unbounded fn Cp, [Ex], Text -> Text
Text cpp_format(const Cp& cp, const Array<lower::Ex>& parts, const Text& how) {
    return prism_rtl::cat(how, "(", lexer::join(run_to_end(each_job(parts, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Ex)>>(prism_rtl::rc([=](lower::Ex p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(FormatArg(cp_1_2, p_))));
            });
        }));
        });
    })));
    }))), Text::lit(", ")), ")");
}


prism_rtl::Turn<Text> CppFormat::cycle() const {
    const auto& cp = this->cp;
    const auto& parts = this->parts;
    const auto& how = this->how;
    auto cp_1 = cp;
    auto how_2 = how;
    auto parts_3 = parts;
    return call_value(each_job(parts_3, ({
        auto cp_1_4 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Ex)>>(prism_rtl::rc([=](lower::Ex p0) {
        return ({
            auto cp_1_4_4 = cp_1_4;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(FormatArg(cp_1_4_4, p_))));
            });
        }));
        });
    })));
    })), [=](Array<Text> each_18823) { return prism_rtl::finished(prism_rtl::cat(how_2, "(", lexer::join(each_18823, Text::lit(", ")), ")")); });
}


/// `Start CppFormat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_format(Cp cp, Array<lower::Ex> parts, Text how) {
    return prism_rtl::make_rc<CppFormat>(cp, parts, how);
}


/// FormatArg: unbounded fn Cp, Ex -> Text
Text format_arg(const Cp& cp, const lower::Ex& ex1) {
    if (prism_rtl::is<lower::Ex::XText>(ex1)) {
        auto&& t = prism_rtl::as<lower::Ex::XText>(ex1).a0;
        return cpp_string(t);
    }
    {
        auto&& x = ex1;
        return cpp_expr(cp, x);
    }
}


prism_rtl::Turn<Text> FormatArg::cycle() const {
    const auto& cp = this->cp;
    const auto& ex1 = this->ex1;
    return ({
        prism_rtl::is<lower::Ex::XText>(ex1) ? ({
        auto&& t = prism_rtl::as<lower::Ex::XText>(ex1).a0;
        prism_rtl::finished(cpp_string(t));
    })
        : ({
        auto&& x = ex1;
        prism_rtl::more(prism_rtl::rc(CppExpr(cp, x)));
    });
    });
}


/// `Start FormatArg, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_format_arg(Cp cp, lower::Ex ex1) {
    return prism_rtl::make_rc<FormatArg>(cp, ex1);
}


/// CppCharEscape: fn Text -> Text
Text cpp_char_escape(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("'")) {
            return Text::lit("\\'");
        }
    }
    {
        auto&& c = text0;
        return lower::char_escape(c);
    }
}


/// PathValue: fn Cp, Text -> Text
Text path_value(const Cp& cp, const Text& p_) {
    return is_node_method(cp, p_)
        ? prism_rtl::cat("&", type_path(parent_path(p_)), "::", node_method_name(cp, last_segment(p_)))
        : ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = case_of(cp, p_);
        if (prism_rtl::is_some(_m)) {
            auto&& ty = prism_rtl::some_of(_m);
            _v.set(prism_rtl::cat(type_path(ty), "(", type_path(p_), "{})"));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = type_of(cp, p_);
                if (prism_rtl::is_some(_m)) {
                    auto&& info = prism_rtl::some_of(_m);
                    _v.set(info.kind == Text::lit("unit")
                        ? prism_rtl::cat(type_path(p_), "{}")
                        : type_path(p_));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(type_path(p_));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// IsNodeMethod: fn Cp, Text -> Bool
bool is_node_method(const Cp& cp, const Text& p_) {
    auto named = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = prelude::get(cp.methods, last_segment(p_));
        if (prism_rtl::is_some(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return named && is_node_type(cp, parent_path(p_));
}


/// IsNodeType: fn Cp, Text -> Bool
bool is_node_type(const Cp& cp, const Text& p_) {
    auto&& _m = type_of(cp, p_);
    if (prism_rtl::is_some(_m)) {
        auto&& info = prism_rtl::some_of(_m);
        return info.kind == Text::lit("node");
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// CppField: unbounded fn Cp, Ex, Text -> Text
Text cpp_field(const Cp& cp, const lower::Ex& ex1, const Text& f) {
    if (prism_rtl::is<lower::Ex::XSelf>(ex1)) {
        return prism_rtl::cat("this->", field_id(f));
    }
    {
        auto&& r = ex1;
        auto name = is_digits(f) ? prism_rtl::cat("a", f) : field_id(f);
        auto through = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            auto&& _m = pointer(cp, r);
            if (prism_rtl::is_some(_m)) {
                auto&& b = prism_rtl::some_of(_m);
                _v.set(b ? Text::lit("->") : Text::lit("."));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = prelude::get(cp.members, f);
                    if (prism_rtl::is_some(_m)) {
                        _v.set(Text::lit("->"));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Text::lit("."));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return prism_rtl::cat(cpp_tight(cp, r), through, name);
    }
}


prism_rtl::Turn<Text> CppField::cycle() const {
    const auto& cp = this->cp;
    const auto& ex1 = this->ex1;
    const auto& f = this->f;
    return ({
        prism_rtl::is<lower::Ex::XSelf>(ex1) ? prism_rtl::finished(prism_rtl::cat("this->", field_id(f)))
        : ({
        auto&& r = ex1;
        ({
        auto name = is_digits(f) ? prism_rtl::cat("a", f) : field_id(f);
        auto through = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            auto&& _m = pointer(cp, r);
            if (prism_rtl::is_some(_m)) {
                auto&& b = prism_rtl::some_of(_m);
                _v.set(b ? Text::lit("->") : Text::lit("."));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = prelude::get(cp.members, f);
                    if (prism_rtl::is_some(_m)) {
                        _v.set(Text::lit("->"));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Text::lit("."));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto cp_1 = cp;
        auto r_2 = r;
        call_then(start_cpp_tight(cp_1, r_2), [=](Text cpp_tight_20422) { return prism_rtl::finished(prism_rtl::cat(cpp_tight_20422, through, name)); });
    });
    });
    });
}


/// `Start CppField, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_field(Cp cp, lower::Ex ex1, Text f) {
    return prism_rtl::make_rc<CppField>(cp, ex1, f);
}


/// IsDigits: fn Text -> Bool
bool is_digits(const Text& t) {
    return (t != Text::lit("")) && lexer::fold_chars(t, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Text>)>>(prism_rtl::rc([=](std::tuple<bool, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return once_job([=]() {
            return ({
                auto ok = p0;
                auto c = p1;
                (prism_rtl::finished(ok && lexer::contains(Text::lit("0123456789"), c)));
            });
        });
    })));
}


/// CppCtor: unbounded fn Cp, Text, [Ex] -> Text
Text cpp_ctor(const Cp& cp, const Text& p_, const Array<lower::Ex>& args) {
    {
        auto&& m20772_0 = p_;
        if (m20772_0 == Text::lit("Some")) {
            return prism_rtl::cat("std::optional(", cpp_args(cp, args), ")");
        }
    }
    {
        auto&& m20772_1 = p_;
        if (m20772_1 == Text::lit("Ok")) {
            return args == Array(std::vector{lower::Ex(lower::Ex::XUnit{})})
                ? Text::lit("prism_rtl::ok()")
                : cpp_args(cp, args);
        }
    }
    {
        auto&& m20772_2 = p_;
        if (m20772_2 == Text::lit("Err")) {
            return prism_rtl::cat("unexpected(", cpp_args(cp, args), ")");
        }
    }
    {
        auto&& m20772_3 = p_;
        if (m20772_3 == Text::lit("prism_rtl::Turn::More")) {
            return prism_rtl::cat("prism_rtl::more(", cpp_args(cp, args), ")");
        }
    }
    {
        auto&& m20772_4 = p_;
        if (m20772_4 == Text::lit("prism_rtl::Turn::Finished")) {
            return prism_rtl::cat("prism_rtl::finished(", cpp_args(cp, args), ")");
        }
    }
    {
        auto&& m20772_5 = p_;
        if (m20772_5 == Text::lit("Outcome::Fired")) {
            return prism_rtl::cat("Outcome::fired(", cpp_args(cp, args), ")");
        }
    }
    {
        auto&& m20772_6 = p_;
        if (m20772_6 == Text::lit("Outcome::Value")) {
            return prism_rtl::cat("Outcome::value(", cpp_args(cp, args), ")");
        }
    }
    {
        auto&& m20772_7 = p_;
        if (m20772_7 == Text::lit("Segment::Pos")) {
            return prism_rtl::cat("Segment::pos(", cpp_args(cp, args), ")");
        }
    }
    {
        auto&& m20772_8 = p_;
        if (m20772_8 == Text::lit("Segment::Gen")) {
            return prism_rtl::cat("Segment::gen(", cpp_args(cp, args), ")");
        }
    }
    {
        auto&& m20772_9 = p_;
        if (m20772_9 == Text::lit("Segment::Key")) {
            return prism_rtl::cat("Segment::key(", cpp_args(cp, args), ")");
        }
    }
    {
        auto&& _m = case_of(cp, p_);
        if (prism_rtl::is_some(_m)) {
            auto&& ty = prism_rtl::some_of(_m);
            return prism_rtl::cat(type_path(ty), "(", type_path(p_), "{", cpp_args(cp, args), "})");
        }
        if (prism_rtl::is_none(_m)) {
            return prism_rtl::cat(type_path(p_), "{", cpp_args(cp, args), "}");
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<Text> CppCtor::cycle() const {
    const auto& cp = this->cp;
    const auto& p_ = this->p_;
    const auto& args = this->args;
    return ({
        ({
        auto&& m20772_0 = p_;
        (m20772_0 == Text::lit("Some"));
    }) ? ({
        auto&& m20772_0 = p_;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_20809) { return prism_rtl::finished(prism_rtl::cat("std::optional(", cpp_args_20809, ")")); });
    });
    })
        : ({
        auto&& m20772_1 = p_;
        (m20772_1 == Text::lit("Ok"));
    }) ? ({
        auto&& m20772_1 = p_;
        args == Array(std::vector{lower::Ex(lower::Ex::XUnit{})})
        ? prism_rtl::finished(Text::lit("prism_rtl::ok()"))
        : prism_rtl::more(prism_rtl::rc(CppArgs(cp, args)));
    })
        : ({
        auto&& m20772_2 = p_;
        (m20772_2 == Text::lit("Err"));
    }) ? ({
        auto&& m20772_2 = p_;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_20926) { return prism_rtl::finished(prism_rtl::cat("unexpected(", cpp_args_20926, ")")); });
    });
    })
        : ({
        auto&& m20772_3 = p_;
        (m20772_3 == Text::lit("prism_rtl::Turn::More"));
    }) ? ({
        auto&& m20772_3 = p_;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_20993) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::more(", cpp_args_20993, ")")); });
    });
    })
        : ({
        auto&& m20772_4 = p_;
        (m20772_4 == Text::lit("prism_rtl::Turn::Finished"));
    }) ? ({
        auto&& m20772_4 = p_;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_21068) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::finished(", cpp_args_21068, ")")); });
    });
    })
        : ({
        auto&& m20772_5 = p_;
        (m20772_5 == Text::lit("Outcome::Fired"));
    }) ? ({
        auto&& m20772_5 = p_;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_21127) { return prism_rtl::finished(prism_rtl::cat("Outcome::fired(", cpp_args_21127, ")")); });
    });
    })
        : ({
        auto&& m20772_6 = p_;
        (m20772_6 == Text::lit("Outcome::Value"));
    }) ? ({
        auto&& m20772_6 = p_;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_21186) { return prism_rtl::finished(prism_rtl::cat("Outcome::value(", cpp_args_21186, ")")); });
    });
    })
        : ({
        auto&& m20772_7 = p_;
        (m20772_7 == Text::lit("Segment::Pos"));
    }) ? ({
        auto&& m20772_7 = p_;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_21241) { return prism_rtl::finished(prism_rtl::cat("Segment::pos(", cpp_args_21241, ")")); });
    });
    })
        : ({
        auto&& m20772_8 = p_;
        (m20772_8 == Text::lit("Segment::Gen"));
    }) ? ({
        auto&& m20772_8 = p_;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_21296) { return prism_rtl::finished(prism_rtl::cat("Segment::gen(", cpp_args_21296, ")")); });
    });
    })
        : ({
        auto&& m20772_9 = p_;
        (m20772_9 == Text::lit("Segment::Key"));
    }) ? ({
        auto&& m20772_9 = p_;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_21351) { return prism_rtl::finished(prism_rtl::cat("Segment::key(", cpp_args_21351, ")")); });
    });
    })
        : ({
        auto&& _m = case_of(cp, p_);
        prism_rtl::is_some(_m) ? ({
        auto&& ty = prism_rtl::some_of(_m);
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        auto p__3 = p_;
        call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_21451) { return prism_rtl::finished(prism_rtl::cat(type_path(ty), "(", type_path(p__3), "{", cpp_args_21451, "})")); });
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto args_1 = args;
        auto cp_2 = cp;
        auto p__3 = p_;
        call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_21502) { return prism_rtl::finished(prism_rtl::cat(type_path(p__3), "{", cpp_args_21502, "}")); });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    });
}


/// `Start CppCtor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_ctor(Cp cp, Text p_, Array<lower::Ex> args) {
    return prism_rtl::make_rc<CppCtor>(cp, p_, args);
}


/// CppRecord: unbounded fn Cp, Text, [((Text, Ex))] -> Text
Text cpp_record(const Cp& cp, const Text& p_, const Array<std::tuple<Text, lower::Ex>>& fs) {
    auto ordered = ({
        __label__ _done;
        prism_rtl::Slot<Array<lower::Ex>> _v;
        auto&& _m = type_of(cp, p_);
        if (prism_rtl::is_some(_m)) {
            auto&& info = prism_rtl::some_of(_m);
            _v.set(each(info.fields, [&](const Text& f) {
                return or_(fold(fs, std::optional<lower::Ex>{}, [&](const std::optional<lower::Ex>& found_opt, const std::tuple<Text, lower::Ex>& _p1) {
                    auto&& g = std::get<0>(_p1);
                    auto&& v_ = std::get<1>(_p1);
                    return g == f ? std::optional(v_) : found_opt;
                }), lower::Ex(lower::Ex::XUnit{}));
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(each(fs, [&](const std::tuple<Text, lower::Ex>& _p0) {
                auto&& v_ = std::get<1>(_p0);
                return v_;
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto names = ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = type_of(cp, p_);
        if (prism_rtl::is_some(_m)) {
            auto&& info = prism_rtl::some_of(_m);
            _v.set(info.fields);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(each(fs, [&](const std::tuple<Text, lower::Ex>& _p0) {
                auto&& g = std::get<0>(_p0);
                return g;
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto kind = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = type_of(cp, p_);
        if (prism_rtl::is_some(_m)) {
            auto&& info = prism_rtl::some_of(_m);
            _v.set(info.kind);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return kind == Text::lit("job")
        ? prism_rtl::cat(type_path(p_), "(", cpp_args(cp, ordered), ")")
        : prism_rtl::cat(type_path(p_), "{", lexer::join(run_to_end(each_job(check_errors::range0(len(names)), ({
        auto names_1 = names;
        auto cp_2 = cp;
        auto ordered_3 = ordered;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto names_1_4 = names_1;
            auto cp_2_4 = cp_2;
            auto ordered_3_4 = ordered_3;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                call_then(start_cpp_expr(cp_2_4, or_(index(ordered_3_4, i), lower::Ex(lower::Ex::XUnit{}))), [=](Text cpp_expr_22241) { return prism_rtl::finished(prism_rtl::cat(".", field_id(or_(index(names_1_4, i), Text::lit(""))), " = ", cpp_expr_22241)); });
            });
        }));
        });
    })));
    }))), Text::lit(", ")), "}");
}


prism_rtl::Turn<Text> CppRecord::cycle() const {
    const auto& cp = this->cp;
    const auto& p_ = this->p_;
    const auto& fs = this->fs;
    auto ordered = ({
        __label__ _done;
        prism_rtl::Slot<Array<lower::Ex>> _v;
        auto&& _m = type_of(cp, p_);
        if (prism_rtl::is_some(_m)) {
            auto&& info = prism_rtl::some_of(_m);
            _v.set(each(info.fields, [&](const Text& f) {
                return or_(fold(fs, std::optional<lower::Ex>{}, [&](const std::optional<lower::Ex>& found_opt, const std::tuple<Text, lower::Ex>& _p1) {
                    auto&& g = std::get<0>(_p1);
                    auto&& v_ = std::get<1>(_p1);
                    return g == f ? std::optional(v_) : found_opt;
                }), lower::Ex(lower::Ex::XUnit{}));
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(each(fs, [&](const std::tuple<Text, lower::Ex>& _p0) {
                auto&& v_ = std::get<1>(_p0);
                return v_;
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto names = ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = type_of(cp, p_);
        if (prism_rtl::is_some(_m)) {
            auto&& info = prism_rtl::some_of(_m);
            _v.set(info.fields);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(each(fs, [&](const std::tuple<Text, lower::Ex>& _p0) {
                auto&& g = std::get<0>(_p0);
                return g;
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto kind = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = type_of(cp, p_);
        if (prism_rtl::is_some(_m)) {
            auto&& info = prism_rtl::some_of(_m);
            _v.set(info.kind);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return kind == Text::lit("job")
        ? ({
        auto cp_1 = cp;
        auto p__2 = p_;
        call_then(start_cpp_args(cp_1, ordered), [=](Text cpp_args_22121) { return prism_rtl::finished(prism_rtl::cat(type_path(p__2), "(", cpp_args_22121, ")")); });
    })
        : ({
        auto cp_1 = cp;
        auto p__2 = p_;
        call_value(each_job(check_errors::range0(len(names)), ({
        auto names_3 = names;
        auto cp_1_4 = cp_1;
        auto ordered_4 = ordered;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto names_3_5 = names_3;
            auto cp_1_4_5 = cp_1_4;
            auto ordered_4_5 = ordered_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                call_then(start_cpp_expr(cp_1_4_5, or_(index(ordered_4_5, i), lower::Ex(lower::Ex::XUnit{}))), [=](Text cpp_expr_22241) { return prism_rtl::finished(prism_rtl::cat(".", field_id(or_(index(names_3_5, i), Text::lit(""))), " = ", cpp_expr_22241)); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_22176) { return prism_rtl::finished(prism_rtl::cat(type_path(p__2), "{", lexer::join(each_22176, Text::lit(", ")), "}")); });
    });
}


/// `Start CppRecord, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_record(Cp cp, Text p_, Array<std::tuple<Text, lower::Ex>> fs) {
    return prism_rtl::make_rc<CppRecord>(cp, p_, fs);
}


/// CppCall: unbounded fn Cp, Text, [Ex] -> Text
Text cpp_call(const Cp& cp, const Text& f, const Array<lower::Ex>& args) {
    auto a = cpp_args(cp, args);
    {
        auto&& m22526_0 = f;
        if (m22526_0 == Text::lit("Rc::new")) {
            return a == Text::lit("{}")
                ? Text::lit("prism_rtl::make_new()")
                : prism_rtl::cat("prism_rtl::rc(", a, ")");
        }
    }
    {
        auto&& m22526_1 = f;
        if (m22526_1 == Text::lit("is_some")) {
            return prism_rtl::cat("prism_rtl::is_some(", a, ")");
        }
    }
    {
        auto&& m22526_2 = f;
        if (m22526_2 == Text::lit("is_none")) {
            return prism_rtl::cat("prism_rtl::is_none(", a, ")");
        }
    }
    {
        auto&& m22526_3 = f;
        if (m22526_3 == Text::lit("RefCell::new")) {
            return a;
        }
    }
    {
        auto&& m22526_4 = f;
        if (m22526_4 == Text::lit("Cell::new")) {
            return a;
        }
    }
    {
        auto&& m22526_5 = f;
        if (m22526_5 == Text::lit("Hold::new")) {
            return prism_rtl::cat("{", a, "}");
        }
    }
    {
        auto&& m22526_6 = f;
        if (m22526_6 == Text::lit("Snapshot::new")) {
            return prism_rtl::cat("snapshot(", a, ")");
        }
    }
    {
        auto&& m22526_7 = f;
        if (m22526_7 == Text::lit("Path::root")) {
            return Text::lit("Path::root()");
        }
    }
    {
        auto&& m22526_8 = f;
        if (m22526_8 == Text::lit("Fault::answer")) {
            return prism_rtl::cat("Fault::answer(", a, ")");
        }
    }
    {
        auto&& m22526_9 = f;
        if (m22526_9 == Text::lit("Error::new")) {
            return prism_rtl::cat("Error(", a, ")");
        }
    }
    {
        auto&& m22526_10 = f;
        if (m22526_10 == Text::lit("Text::from")) {
            return prism_rtl::cat("Text(", a, ")");
        }
    }
    {
        auto&& m22526_11 = f;
        if (m22526_11 == Text::lit("String::new")) {
            return Text::lit("std::string()");
        }
    }
    {
        auto&& m22526_12 = f;
        if (m22526_12 == Text::lit("Array::from")) {
            return prism_rtl::cat("Array(", a, ")");
        }
    }
    {
        auto&& m22526_13 = f;
        if (m22526_13 == Text::lit("prism_rtl::Dynamic::of")) {
            return prism_rtl::cat("dynamic_of(", a, ")");
        }
    }
    {
        auto&& m22526_14 = f;
        if (m22526_14 == Text::lit("Dynamic::of")) {
            return prism_rtl::cat("dynamic_of(", a, ")");
        }
    }
    {
        auto&& m22526_15 = f;
        if (m22526_15 == Text::lit("prism_rtl::Event::of")) {
            return prism_rtl::cat("event_of(", a, ")");
        }
    }
    {
        auto&& m22526_16 = f;
        if (m22526_16 == Text::lit("prism_rtl::Host::new")) {
            return prism_rtl::cat("host_new(", a, ")");
        }
    }
    {
        auto&& m22526_17 = f;
        if (m22526_17 == Text::lit("prism_rtl::forward_on_none")) {
            return prism_rtl::cat("prism_rtl::forward_on_none<crate::Elem, crate::Answer>(", a, ")");
        }
    }
    {
        auto&& m22526_18 = f;
        if (m22526_18 == Text::lit("Event::never")) {
            return Text::lit("never_event()");
        }
    }
    {
        return is_fresh(f)
            ? Text::lit("{}")
            : prism_rtl::cat(free_call_path(cp, f), "(", a, ")");
    }
}


prism_rtl::Turn<Text> CppCall::cycle() const {
    const auto& cp = this->cp;
    const auto& f = this->f;
    const auto& args = this->args;
    auto args_1 = args;
    auto cp_2 = cp;
    auto f_3 = f;
    return call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_22505) {
        return ({
            auto a = cpp_args_22505;
            ({
            ({
            auto&& m22526_0 = f_3;
            (m22526_0 == Text::lit("Rc::new"));
        }) ? ({
            auto&& m22526_0 = f_3;
            a == Text::lit("{}")
            ? prism_rtl::finished(Text::lit("prism_rtl::make_new()"))
            : prism_rtl::finished(prism_rtl::cat("prism_rtl::rc(", a, ")"));
        })
            : ({
            auto&& m22526_1 = f_3;
            (m22526_1 == Text::lit("is_some"));
        }) ? ({
            auto&& m22526_1 = f_3;
            prism_rtl::finished(prism_rtl::cat("prism_rtl::is_some(", a, ")"));
        })
            : ({
            auto&& m22526_2 = f_3;
            (m22526_2 == Text::lit("is_none"));
        }) ? ({
            auto&& m22526_2 = f_3;
            prism_rtl::finished(prism_rtl::cat("prism_rtl::is_none(", a, ")"));
        })
            : ({
            auto&& m22526_3 = f_3;
            (m22526_3 == Text::lit("RefCell::new"));
        }) ? ({
            auto&& m22526_3 = f_3;
            prism_rtl::finished(a);
        })
            : ({
            auto&& m22526_4 = f_3;
            (m22526_4 == Text::lit("Cell::new"));
        }) ? ({
            auto&& m22526_4 = f_3;
            prism_rtl::finished(a);
        })
            : ({
            auto&& m22526_5 = f_3;
            (m22526_5 == Text::lit("Hold::new"));
        }) ? ({
            auto&& m22526_5 = f_3;
            prism_rtl::finished(prism_rtl::cat("{", a, "}"));
        })
            : ({
            auto&& m22526_6 = f_3;
            (m22526_6 == Text::lit("Snapshot::new"));
        }) ? ({
            auto&& m22526_6 = f_3;
            prism_rtl::finished(prism_rtl::cat("snapshot(", a, ")"));
        })
            : ({
            auto&& m22526_7 = f_3;
            (m22526_7 == Text::lit("Path::root"));
        }) ? ({
            auto&& m22526_7 = f_3;
            prism_rtl::finished(Text::lit("Path::root()"));
        })
            : ({
            auto&& m22526_8 = f_3;
            (m22526_8 == Text::lit("Fault::answer"));
        }) ? ({
            auto&& m22526_8 = f_3;
            prism_rtl::finished(prism_rtl::cat("Fault::answer(", a, ")"));
        })
            : ({
            auto&& m22526_9 = f_3;
            (m22526_9 == Text::lit("Error::new"));
        }) ? ({
            auto&& m22526_9 = f_3;
            prism_rtl::finished(prism_rtl::cat("Error(", a, ")"));
        })
            : ({
            auto&& m22526_10 = f_3;
            (m22526_10 == Text::lit("Text::from"));
        }) ? ({
            auto&& m22526_10 = f_3;
            prism_rtl::finished(prism_rtl::cat("Text(", a, ")"));
        })
            : ({
            auto&& m22526_11 = f_3;
            (m22526_11 == Text::lit("String::new"));
        }) ? ({
            auto&& m22526_11 = f_3;
            prism_rtl::finished(Text::lit("std::string()"));
        })
            : ({
            auto&& m22526_12 = f_3;
            (m22526_12 == Text::lit("Array::from"));
        }) ? ({
            auto&& m22526_12 = f_3;
            prism_rtl::finished(prism_rtl::cat("Array(", a, ")"));
        })
            : ({
            auto&& m22526_13 = f_3;
            (m22526_13 == Text::lit("prism_rtl::Dynamic::of"));
        }) ? ({
            auto&& m22526_13 = f_3;
            prism_rtl::finished(prism_rtl::cat("dynamic_of(", a, ")"));
        })
            : ({
            auto&& m22526_14 = f_3;
            (m22526_14 == Text::lit("Dynamic::of"));
        }) ? ({
            auto&& m22526_14 = f_3;
            prism_rtl::finished(prism_rtl::cat("dynamic_of(", a, ")"));
        })
            : ({
            auto&& m22526_15 = f_3;
            (m22526_15 == Text::lit("prism_rtl::Event::of"));
        }) ? ({
            auto&& m22526_15 = f_3;
            prism_rtl::finished(prism_rtl::cat("event_of(", a, ")"));
        })
            : ({
            auto&& m22526_16 = f_3;
            (m22526_16 == Text::lit("prism_rtl::Host::new"));
        }) ? ({
            auto&& m22526_16 = f_3;
            prism_rtl::finished(prism_rtl::cat("host_new(", a, ")"));
        })
            : ({
            auto&& m22526_17 = f_3;
            (m22526_17 == Text::lit("prism_rtl::forward_on_none"));
        }) ? ({
            auto&& m22526_17 = f_3;
            prism_rtl::finished(prism_rtl::cat("prism_rtl::forward_on_none<crate::Elem, crate::Answer>(", a, ")"));
        })
            : ({
            auto&& m22526_18 = f_3;
            (m22526_18 == Text::lit("Event::never"));
        }) ? ({
            auto&& m22526_18 = f_3;
            prism_rtl::finished(Text::lit("never_event()"));
        })
            : is_fresh(f_3)
            ? prism_rtl::finished(Text::lit("{}"))
            : prism_rtl::finished(prism_rtl::cat(free_call_path(cp_2, f_3), "(", a, ")"));
        });
        });
    });
}


/// `Start CppCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_call(Cp cp, Text f, Array<lower::Ex> args) {
    return prism_rtl::make_rc<CppCall>(cp, f, args);
}


/// FreeCallPath: fn Cp, Text -> Text
Text free_call_path(const Cp& cp, const Text& f) {
    auto p_ = call_path(f);
    auto hidden = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = prelude::get(cp.members, f);
        if (prism_rtl::is_some(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(in_list(std_names(), p_) || in_list(cp.mods, p_));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return lexer::contains(p_, Text::lit(":"))
        ? p_
        : hidden ? qualified_call(cp, f, p_) : p_;
}


/// QualifiedCall: fn Cp, Text, Text -> Text
Text qualified_call(const Cp& cp, const Text& f, const Text& p_) {
    auto&& _m = prelude::get(cp.fns, prism_rtl::cat(cp.home, "::", f));
    if (prism_rtl::is_some(_m)) {
        return prism_rtl::cat(cp.home, "::", p_);
    }
    if (prism_rtl::is_none(_m)) {
        return prism_rtl::cat("prelude::", p_);
    }
    prism_rtl::unreachable("no arm matched");
}


/// let stdNames
Array<Text> std_names() {
    return Array(std::vector{Text::lit("apply"), Text::lit("begin"), Text::lit("end"), Text::lit("size"), Text::lit("empty"), Text::lit("data"), Text::lit("get"), Text::lit("swap"), Text::lit("move"), Text::lit("forward"), Text::lit("find"), Text::lit("count"), Text::lit("copy"), Text::lit("fill"), Text::lit("sort"), Text::lit("min"), Text::lit("max"), Text::lit("visit"), Text::lit("invoke"), Text::lit("merge"), Text::lit("remove"), Text::lit("replace"), Text::lit("reverse"), Text::lit("unique"), Text::lit("transform"), Text::lit("accumulate"), Text::lit("distance"), Text::lit("next"), Text::lit("prev"), Text::lit("exchange"), Text::lit("tie"), Text::lit("to_string"), Text::lit("clamp"), Text::lit("partition"), Text::lit("equal"), Text::lit("mismatch"), Text::lit("erase"), Text::lit("search"), Text::lit("rotate")});
}


/// IsFresh: fn Text -> Bool
bool is_fresh(const Text& f) {
    return in_list(Array(std::vector{Text::lit("Stamped::new"), Text::lit("Cache::new"), Text::lit("Port::new"), Text::lit("Map::new"), Text::lit("Array::new"), Text::lit("Vec::new"), Text::lit("Default::default"), Text::lit("Wakes::default"), Text::lit("Defer::new")}), f);
}


/// CallPath: fn Text -> Text
Text call_path(const Text& f) {
    auto last = last_segment(f);
    auto owner = last_segment(parent_path(f));
    auto is_type = (parent_path(f) != Text::lit("")) && lexer::contains(Text::lit("ABCDEFGHIJKLMNOPQRSTUVWXYZ"), lexer::head(owner));
    return (last == Text::lit("build")) && is_type
        ? prism_rtl::cat(type_path(parent_path(f)), "::make")
        : last == Text::lit("new")
        ? type_path(parent_path(f))
        : cpp_path_id(type_path(f));
}


/// CppMethod: unbounded fn Cp, Ex, Text, [Ex] -> Text
Text cpp_method(const Cp& cp, const lower::Ex& r, const Text& m, const Array<lower::Ex>& args) {
    auto recv = r == lower::Ex(lower::Ex::XSelf{}) ? Text::lit("this") : cpp_tight(cp, r);
    auto a = cpp_args(cp, args);
    auto n = len(args);
    auto sep = n == Nat(0u) ? Text::lit("") : Text::lit(", ");
    auto&& _m = method_form(m, n);
    {
        auto&& m25665_0 = _m;
        if (m25665_0 == Text::lit("id")) {
            return recv;
        }
    }
    {
        auto&& m25665_1 = _m;
        if (m25665_1 == Text::lit("deref")) {
            auto&& _m = pointer(cp, r);
            if (prism_rtl::is_some(_m)) {
                auto&& b = prism_rtl::some_of(_m);
                return b ? prism_rtl::cat("(*", recv, ")") : recv;
            }
            if (prism_rtl::is_none(_m)) {
                return recv;
            }
            prism_rtl::unreachable("no arm matched");
        }
    }
    {
        auto&& m25665_2 = _m;
        if (m25665_2 == Text::lit("assign")) {
            return prism_rtl::cat(recv, " = ", a);
        }
    }
    {
        auto&& m25665_3 = _m;
        if (m25665_3 == Text::lit("take")) {
            return prism_rtl::cat("std::exchange(", recv, ", {})");
        }
    }
    {
        auto&& m25665_4 = _m;
        if (m25665_4 == Text::lit("free")) {
            return prism_rtl::cat(free_name(m), "(", recv, sep, a, ")");
        }
    }
    {
        auto&& m25665_5 = _m;
        if (m25665_5 == Text::lit("arrow")) {
            auto through = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = pointer(cp, r);
                if (prism_rtl::is_some(_m)) {
                    auto&& b = prism_rtl::some_of(_m);
                    _v.set(b ? Text::lit("->") : Text::lit("."));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Text::lit("->"));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            return prism_rtl::cat(recv, through, member_name(m), "(", a, ")");
        }
    }
    {
        auto&& m25665_6 = _m;
        if (m25665_6 == Text::lit("exchange")) {
            return prism_rtl::cat("std::exchange(", recv, ", ", a, ")");
        }
    }
    {
        auto through = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            auto&& _m = pointer(cp, r);
            if (prism_rtl::is_some(_m)) {
                auto&& b = prism_rtl::some_of(_m);
                _v.set(b ? Text::lit("->") : Text::lit("."));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = prelude::get(cp.members, m);
                    if (prism_rtl::is_some(_m)) {
                        _v.set(Text::lit("->"));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Text::lit("."));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return prism_rtl::cat(recv, through, node_method_name(cp, m), "(", a, ")");
    }
}


prism_rtl::Turn<Text> CppMethod::cycle() const {
    const auto& cp = this->cp;
    const auto& r = this->r;
    const auto& m = this->m;
    const auto& args = this->args;
    auto recv = r == lower::Ex(lower::Ex::XSelf{}) ? Text::lit("this") : cpp_tight(cp, r);
    auto args_1 = args;
    auto cp_2 = cp;
    auto m_3 = m;
    auto r_4 = r;
    return call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_25584) {
        return ({
            auto a = cpp_args_25584;
            auto n = len(args_1);
            auto sep = n == Nat(0u) ? Text::lit("") : Text::lit(", ");
            ({
            auto&& _m = method_form(m_3, n);
            ({
            auto&& m25665_0 = _m;
            (m25665_0 == Text::lit("id"));
        }) ? ({
            auto&& m25665_0 = _m;
            prism_rtl::finished(recv);
        })
            : ({
            auto&& m25665_1 = _m;
            (m25665_1 == Text::lit("deref"));
        }) ? ({
            auto&& m25665_1 = _m;
            ({
            auto&& _m = pointer(cp_2, r_4);
            prism_rtl::is_some(_m) ? ({
            auto&& b = prism_rtl::some_of(_m);
            b
            ? prism_rtl::finished(prism_rtl::cat("(*", recv, ")"))
            : prism_rtl::finished(recv);
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(recv)
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : ({
            auto&& m25665_2 = _m;
            (m25665_2 == Text::lit("assign"));
        }) ? ({
            auto&& m25665_2 = _m;
            prism_rtl::finished(prism_rtl::cat(recv, " = ", a));
        })
            : ({
            auto&& m25665_3 = _m;
            (m25665_3 == Text::lit("take"));
        }) ? ({
            auto&& m25665_3 = _m;
            prism_rtl::finished(prism_rtl::cat("std::exchange(", recv, ", {})"));
        })
            : ({
            auto&& m25665_4 = _m;
            (m25665_4 == Text::lit("free"));
        }) ? ({
            auto&& m25665_4 = _m;
            prism_rtl::finished(prism_rtl::cat(free_name(m_3), "(", recv, sep, a, ")"));
        })
            : ({
            auto&& m25665_5 = _m;
            (m25665_5 == Text::lit("arrow"));
        }) ? ({
            auto&& m25665_5 = _m;
            ({
            auto through = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = pointer(cp_2, r_4);
                if (prism_rtl::is_some(_m)) {
                    auto&& b = prism_rtl::some_of(_m);
                    _v.set(b ? Text::lit("->") : Text::lit("."));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Text::lit("->"));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (prism_rtl::finished(prism_rtl::cat(recv, through, member_name(m_3), "(", a, ")")));
        });
        })
            : ({
            auto&& m25665_6 = _m;
            (m25665_6 == Text::lit("exchange"));
        }) ? ({
            auto&& m25665_6 = _m;
            prism_rtl::finished(prism_rtl::cat("std::exchange(", recv, ", ", a, ")"));
        })
            : ({
            auto through = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = pointer(cp_2, r_4);
                if (prism_rtl::is_some(_m)) {
                    auto&& b = prism_rtl::some_of(_m);
                    _v.set(b ? Text::lit("->") : Text::lit("."));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Text> _v;
                        auto&& _m = prelude::get(cp_2.members, m_3);
                        if (prism_rtl::is_some(_m)) {
                            _v.set(Text::lit("->"));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(Text::lit("."));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (prism_rtl::finished(prism_rtl::cat(recv, through, node_method_name(cp_2, m_3), "(", a, ")")));
        });
        });
        });
    });
}


/// `Start CppMethod, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_method(Cp cp, lower::Ex r, Text m, Array<lower::Ex> args) {
    return prism_rtl::make_rc<CppMethod>(cp, r, m, args);
}


/// NodeMethodName: fn Cp, Text -> Text
Text node_method_name(const Cp& cp, const Text& m) {
    auto&& _m = std::tuple{prelude::get(cp.methods, m), prelude::get(cp.field_names, m)};
    if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
        return prism_rtl::cat(cpp_id(m), "_");
    }
    {
        return member_name(m);
    }
}


/// ?Pointer: fn Cp, Ex -> ?Bool
std::optional<bool> pointer(const Cp& cp, const lower::Ex& r) {
    if (prism_rtl::is<lower::Ex::XSelf>(r)) {
        return std::optional(true);
    }
    if (prism_rtl::is<lower::Ex::XCx>(r)) {
        return std::optional(false);
    }
    if (prism_rtl::is<lower::Ex::XVar>(r)) {
        auto&& n = prism_rtl::as<lower::Ex::XVar>(r).a0;
        return prelude::get(cp.pointers, n);
    }
    if (prism_rtl::is<lower::Ex::XClone>(r)) {
        auto&& y = prism_rtl::as<lower::Ex::XClone>(r).a0;
        return pointer(cp, y);
    }
    if (prism_rtl::is<lower::Ex::XRef>(r)) {
        auto&& y = prism_rtl::as<lower::Ex::XRef>(r).a0;
        return pointer(cp, y);
    }
    if (prism_rtl::is<lower::Ex::XField>(r)) {
        auto&& m26945_5_0 = prism_rtl::as<lower::Ex::XField>(r).a0;
        auto&& f = prism_rtl::as<lower::Ex::XField>(r).a1;
        if (prism_rtl::is<lower::Ex::XSelf>(m26945_5_0)) {
            auto&& _m = prelude::get(cp.fields, f);
            if (prism_rtl::is_some(_m)) {
                auto&& t = prism_rtl::some_of(_m);
                return std::optional(is_pointer_ty(cp, t));
            }
            if (prism_rtl::is_none(_m)) {
                return std::optional<bool>{};
            }
            prism_rtl::unreachable("no arm matched");
        }
    }
    if (prism_rtl::is<lower::Ex::XField>(r)) {
        auto&& m26945_6_0 = prism_rtl::as<lower::Ex::XField>(r).a0;
        auto&& f = prism_rtl::as<lower::Ex::XField>(r).a1;
        if (prism_rtl::is<lower::Ex::XVar>(m26945_6_0)) {
            auto&& m26945_6_0_r_0 = prism_rtl::as<lower::Ex::XVar>(m26945_6_0).a0;
            if (m26945_6_0_r_0 == Text::lit("node")) {
                auto&& _m = prelude::get(cp.fields, f);
                if (prism_rtl::is_some(_m)) {
                    auto&& t = prism_rtl::some_of(_m);
                    return std::optional(is_pointer_ty(cp, t));
                }
                if (prism_rtl::is_none(_m)) {
                    return std::optional<bool>{};
                }
                prism_rtl::unreachable("no arm matched");
            }
        }
    }
    {
        return std::optional<bool>{};
    }
}


/// IsPointerTy: fn Cp, OutTy -> Bool
bool is_pointer_ty(const Cp& cp, const lower::OutTy& t) {
    if (prism_rtl::is<lower::OutTy::OutNamed>(t)) {
        auto&& m27343_0_0 = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        if (m27343_0_0 == Text::lit("prism_rtl::Rows")) {
            return true;
        }
    }
    if (prism_rtl::is<lower::OutTy::OutPort>(t)) {
        return false;
    }
    if (prism_rtl::is<lower::OutTy::OutRc>(t)) {
        auto&& i = prism_rtl::as<lower::OutTy::OutRc>(t).a0;
        return !is_value_ty(cp, i);
    }
    if (prism_rtl::is<lower::OutTy::OutObj>(t)) {
        return true;
    }
    if (prism_rtl::is<lower::OutTy::OutJob>(t)) {
        return true;
    }
    if (prism_rtl::is<lower::OutTy::OutShowAny>(t)) {
        return true;
    }
    {
        return false;
    }
}


/// MethodForm: fn Text, Nat -> Text
Text method_form(const Text& m, const Nat& n) {
    auto&& _m = std::tuple{m, n};
    {
        auto&& m27882_0_0 = std::get<0>(_m);
        auto&& m27882_0_1 = std::get<1>(_m);
        if (m27882_0_0 == Text::lit("borrow")) {
            if (m27882_0_1 == Nat(0u)) {
                return Text::lit("deref");
            }
        }
    }
    {
        auto&& m27882_1_0 = std::get<0>(_m);
        auto&& m27882_1_1 = std::get<1>(_m);
        if (m27882_1_0 == Text::lit("borrow_mut")) {
            if (m27882_1_1 == Nat(0u)) {
                return Text::lit("deref");
            }
        }
    }
    {
        auto&& m27882_2_0 = std::get<0>(_m);
        auto&& m27882_2_1 = std::get<1>(_m);
        if (m27882_2_0 == Text::lit("clone")) {
            if (m27882_2_1 == Nat(0u)) {
                return Text::lit("id");
            }
        }
    }
    {
        auto&& m27882_3_0 = std::get<0>(_m);
        auto&& m27882_3_1 = std::get<1>(_m);
        if (m27882_3_0 == Text::lit("iter")) {
            if (m27882_3_1 == Nat(0u)) {
                return Text::lit("id");
            }
        }
    }
    {
        auto&& m27882_4_0 = std::get<0>(_m);
        auto&& m27882_4_1 = std::get<1>(_m);
        if (m27882_4_0 == Text::lit("collect")) {
            if (m27882_4_1 == Nat(0u)) {
                return Text::lit("id");
            }
        }
    }
    {
        auto&& m27882_5_0 = std::get<0>(_m);
        auto&& m27882_5_1 = std::get<1>(_m);
        if (m27882_5_0 == Text::lit("unwrap_or_default")) {
            if (m27882_5_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m27882_6_0 = std::get<0>(_m);
        auto&& m27882_6_1 = std::get<1>(_m);
        if (m27882_6_0 == Text::lit("for_each")) {
            if (m27882_6_1 == Nat(1u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m27882_7_0 = std::get<0>(_m);
        auto&& m27882_7_1 = std::get<1>(_m);
        if (m27882_7_0 == Text::lit("into_iter")) {
            if (m27882_7_1 == Nat(0u)) {
                return Text::lit("id");
            }
        }
    }
    {
        auto&& m27882_8_0 = std::get<0>(_m);
        auto&& m27882_8_1 = std::get<1>(_m);
        if (m27882_8_0 == Text::lit("as_ref")) {
            if (m27882_8_1 == Nat(0u)) {
                return Text::lit("id");
            }
        }
    }
    {
        auto&& m27882_9_0 = std::get<0>(_m);
        auto&& m27882_9_1 = std::get<1>(_m);
        if (m27882_9_0 == Text::lit("get")) {
            if (m27882_9_1 == Nat(0u)) {
                return Text::lit("id");
            }
        }
    }
    {
        auto&& m27882_10_0 = std::get<0>(_m);
        auto&& m27882_10_1 = std::get<1>(_m);
        if (m27882_10_0 == Text::lit("set")) {
            if (m27882_10_1 == Nat(1u)) {
                return Text::lit("assign");
            }
        }
    }
    {
        auto&& m27882_11_0 = std::get<0>(_m);
        auto&& m27882_11_1 = std::get<1>(_m);
        if (m27882_11_0 == Text::lit("take")) {
            if (m27882_11_1 == Nat(0u)) {
                return Text::lit("take");
            }
        }
    }
    {
        auto&& m27882_12_0 = std::get<0>(_m);
        auto&& m27882_12_1 = std::get<1>(_m);
        if (m27882_12_0 == Text::lit("replace")) {
            if (m27882_12_1 == Nat(1u)) {
                return Text::lit("exchange");
            }
        }
    }
    {
        auto&& m27882_13_0 = std::get<0>(_m);
        auto&& m27882_13_1 = std::get<1>(_m);
        if (m27882_13_0 == Text::lit("values")) {
            if (m27882_13_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m27882_14_0 = std::get<0>(_m);
        auto&& m27882_14_1 = std::get<1>(_m);
        if (m27882_14_0 == Text::lit("keys")) {
            if (m27882_14_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m27882_15_0 = std::get<0>(_m);
        auto&& m27882_15_1 = std::get<1>(_m);
        if (m27882_15_0 == Text::lit("enumerate")) {
            if (m27882_15_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m27882_16_0 = std::get<0>(_m);
        auto&& m27882_16_1 = std::get<1>(_m);
        if (m27882_16_0 == Text::lit("fire")) {
            if (m27882_16_1 == Nat(2u)) {
                return Text::lit("arrow");
            }
        }
    }
    {
        auto&& m27882_17_0 = std::get<0>(_m);
        auto&& m27882_17_1 = std::get<1>(_m);
        if (m27882_17_0 == Text::lit("subscribe")) {
            if (m27882_17_1 == Nat(1u)) {
                return Text::lit("arrow");
            }
        }
    }
    {
        auto&& m27882_18_0 = std::get<0>(_m);
        auto&& m27882_18_1 = std::get<1>(_m);
        if (m27882_18_0 == Text::lit("unsubscribe")) {
            if (m27882_18_1 == Nat(1u)) {
                return Text::lit("arrow");
            }
        }
    }
    {
        auto&& m27882_19_0 = std::get<0>(_m);
        auto&& m27882_19_1 = std::get<1>(_m);
        if (m27882_19_0 == Text::lit("cycle")) {
            if (m27882_19_1 == Nat(0u)) {
                return Text::lit("arrow");
            }
        }
    }
    {
        auto&& m27882_20_0 = std::get<0>(_m);
        auto&& m27882_20_1 = std::get<1>(_m);
        if (m27882_20_0 == Text::lit("upgrade")) {
            if (m27882_20_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m27882_21_0 = std::get<0>(_m);
        auto&& m27882_21_1 = std::get<1>(_m);
        if (m27882_21_0 == Text::lit("expect")) {
            if (m27882_21_1 == Nat(1u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m27882_22_0 = std::get<0>(_m);
        auto&& m27882_22_1 = std::get<1>(_m);
        if (m27882_22_0 == Text::lit("to_pod")) {
            if (m27882_22_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m27882_23_0 = std::get<0>(_m);
        auto&& m27882_23_1 = std::get<1>(_m);
        if (m27882_23_0 == Text::lit("cloned")) {
            if (m27882_23_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m27882_24_0 = std::get<0>(_m);
        auto&& m27882_24_1 = std::get<1>(_m);
        if (m27882_24_0 == Text::lit("ok")) {
            if (m27882_24_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m27882_25_0 = std::get<0>(_m);
        auto&& m27882_25_1 = std::get<1>(_m);
        if (m27882_25_0 == Text::lit("ok_or")) {
            if (m27882_25_1 == Nat(1u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m27882_26_0 = std::get<0>(_m);
        auto&& m27882_26_1 = std::get<1>(_m);
        if (m27882_26_0 == Text::lit("map")) {
            if (m27882_26_1 == Nat(1u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m27882_27_0 = std::get<0>(_m);
        auto&& m27882_27_1 = std::get<1>(_m);
        if (m27882_27_0 == Text::lit("iter_mut")) {
            if (m27882_27_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m27882_28_0 = std::get<0>(_m);
        auto&& m27882_28_1 = std::get<1>(_m);
        if (m27882_28_0 == Text::lit("to_vec")) {
            if (m27882_28_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m27882_29_0 = std::get<0>(_m);
        auto&& m27882_29_1 = std::get<1>(_m);
        if (m27882_29_0 == Text::lit("filter_some")) {
            if (m27882_29_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        return Text::lit("dot");
    }
}


/// FreeName: fn Text -> Text
Text free_name(const Text& m) {
    {
        auto&& m28819_0 = m;
        if (m28819_0 == Text::lit("to_pod")) {
            return Text::lit("prism_rtl::to_pod");
        }
    }
    {
        auto&& m28819_1 = m;
        if (m28819_1 == Text::lit("ok")) {
            return Text::lit("prism_rtl::ignore");
        }
    }
    {
        auto&& m28819_2 = m;
        if (m28819_2 == Text::lit("map")) {
            return Text::lit("prism_rtl::fmap");
        }
    }
    {
        auto&& m28819_3 = m;
        if (m28819_3 == Text::lit("to_vec")) {
            return Text::lit("path_of");
        }
    }
    {
        auto&& m28819_4 = m;
        if (m28819_4 == Text::lit("values")) {
            return Text::lit("prelude::values");
        }
    }
    {
        auto&& m28819_5 = m;
        if (m28819_5 == Text::lit("keys")) {
            return Text::lit("prelude::keys");
        }
    }
    {
        auto&& m28819_6 = m;
        if (m28819_6 == Text::lit("enumerate")) {
            return Text::lit("prism_rtl::enumerate");
        }
    }
    {
        auto&& m28819_7 = m;
        if (m28819_7 == Text::lit("unwrap_or_default")) {
            return Text::lit("prism_rtl::unwrap_or_default");
        }
    }
    {
        auto&& m28819_8 = m;
        if (m28819_8 == Text::lit("for_each")) {
            return Text::lit("prism_rtl::for_each");
        }
    }
    {
        return m;
    }
}


/// MemberName: fn Text -> Text
Text member_name(const Text& m) {
    {
        auto&& m29203_0 = m;
        if (m29203_0 == Text::lit("push_str")) {
            return Text::lit("append");
        }
    }
    {
        auto&& m29203_1 = m;
        if (m29203_1 == Text::lit("len")) {
            return Text::lit("size");
        }
    }
    {
        auto&& m29203_2 = m;
        if (m29203_2 == Text::lit("is_empty")) {
            return Text::lit("empty");
        }
    }
    {
        auto&& m29203_3 = m;
        if (m29203_3 == Text::lit("push")) {
            return Text::lit("push_back");
        }
    }
    {
        auto&& m29203_4 = m;
        if (m29203_4 == Text::lit("contains_key")) {
            return Text::lit("contains");
        }
    }
    {
        auto&& m29203_5 = m;
        if (m29203_5 == Text::lit("build")) {
            return Text::lit("make");
        }
    }
    {
        return cpp_id(m);
    }
}


/// CaseTest: fn Cp, Text, Text -> Text
Text case_test(const Cp& cp, const Text& c, const Text& v_) {
    {
        auto&& m29502_0 = c;
        if (m29502_0 == Text::lit("Some")) {
            return prism_rtl::cat("prism_rtl::is_some(", v_, ")");
        }
    }
    {
        auto&& m29502_1 = c;
        if (m29502_1 == Text::lit("None")) {
            return prism_rtl::cat("prism_rtl::is_none(", v_, ")");
        }
    }
    {
        auto&& m29502_2 = c;
        if (m29502_2 == Text::lit("Ok")) {
            return prism_rtl::cat("prism_rtl::is_ok(", v_, ")");
        }
    }
    {
        auto&& m29502_3 = c;
        if (m29502_3 == Text::lit("Err")) {
            return prism_rtl::cat("prism_rtl::is_err(", v_, ")");
        }
    }
    {
        auto&& m29502_4 = c;
        if (m29502_4 == Text::lit("prism_rtl::Turn::More")) {
            return prism_rtl::cat(v_, ".if_more()");
        }
    }
    {
        auto&& m29502_5 = c;
        if (m29502_5 == Text::lit("prism_rtl::Turn::Finished")) {
            return prism_rtl::cat(v_, ".if_finished()");
        }
    }
    {
        auto&& _m = case_of(cp, c);
        if (prism_rtl::is_some(_m)) {
            return prism_rtl::cat("prism_rtl::is<", case_type(c), ">(", v_, ")");
        }
        if (prism_rtl::is_none(_m)) {
            return is_runtime_case(c)
                ? prism_rtl::cat("prism_rtl::is<", case_type(c), ">(", v_, ")")
                : Text::lit("true");
        }
        prism_rtl::unreachable("no arm matched");
    }
}


/// CaseType: fn Text -> Text
Text case_type(const Text& c) {
    {
        auto&& m30054_0 = c;
        if (m30054_0 == Text::lit("Segment::Pos")) {
            return Text::lit("pat::Pos");
        }
    }
    {
        auto&& m30054_1 = c;
        if (m30054_1 == Text::lit("Segment::Gen")) {
            return Text::lit("pat::Gen");
        }
    }
    {
        auto&& m30054_2 = c;
        if (m30054_2 == Text::lit("Segment::Key")) {
            return Text::lit("pat::Key");
        }
    }
    {
        return type_path(c);
    }
}


/// Payload: fn Cp, Text, Text, Nat -> Text
Text payload(const Cp& cp, const Text& c, const Text& v_, const Nat& i) {
    {
        auto&& m30303_0 = c;
        if (m30303_0 == Text::lit("Some")) {
            return prism_rtl::cat("prism_rtl::some_of(", v_, ")");
        }
    }
    {
        auto&& m30303_1 = c;
        if (m30303_1 == Text::lit("Ok")) {
            return prism_rtl::cat("*", v_);
        }
    }
    {
        auto&& m30303_2 = c;
        if (m30303_2 == Text::lit("Err")) {
            return prism_rtl::cat(v_, ".error()");
        }
    }
    {
        auto&& m30303_3 = c;
        if (m30303_3 == Text::lit("prism_rtl::Turn::More")) {
            return prism_rtl::cat(v_, ".if_more()->next");
        }
    }
    {
        auto&& m30303_4 = c;
        if (m30303_4 == Text::lit("prism_rtl::Turn::Finished")) {
            return prism_rtl::cat(v_, ".if_finished()->value");
        }
    }
    {
        auto&& _m = case_of(cp, c);
        if (prism_rtl::is_some(_m)) {
            return prism_rtl::cat("prism_rtl::as<", case_type(c), ">(", v_, ").a", i);
        }
        if (prism_rtl::is_none(_m)) {
            return is_runtime_case(c)
                ? prism_rtl::cat("prism_rtl::as<", case_type(c), ">(", v_, ").a", i)
                : prism_rtl::cat(v_, ".a", i);
        }
        prism_rtl::unreachable("no arm matched");
    }
}


/// IsRuntimeCase: fn Text -> Bool
bool is_runtime_case(const Text& c) {
    return lexer::has_prefix(c, Text::lit("Segment::"));
}


/// CppIf: unbounded fn Cp, Ex, Ex, Ex -> Text
Text cpp_if(const Cp& cp, const lower::Ex& c, const lower::Ex& t, const lower::Ex& e) {
    auto ct = cpp_expr(cp, c);
    auto err_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<lower::Ex>> _v;
        auto&& _m = std::tuple{err_of(t), err_of(e)};
        if (prism_rtl::is_some(std::get<0>(_m))) {
            auto&& y = prism_rtl::some_of(std::get<0>(_m));
            _v.set(std::optional(y));
            goto _done;
        }
        if (prism_rtl::is_none(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
            auto&& y = prism_rtl::some_of(std::get<1>(_m));
            _v.set(std::optional(y));
            goto _done;
        }
        {
            _v.set(std::optional<lower::Ex>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto tt = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is_some(err_opt)) {
            auto&& y = prism_rtl::some_of(err_opt);
            _v.set(ok_branch(cp, t, y));
            goto _done;
        }
        if (prism_rtl::is_none(err_opt)) {
            _v.set(cpp_expr(cp, t));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto et = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is_some(err_opt)) {
            auto&& y = prism_rtl::some_of(err_opt);
            _v.set(ok_branch(cp, e, y));
            goto _done;
        }
        if (prism_rtl::is_none(err_opt)) {
            _v.set(cpp_expr(cp, e));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto short_ = (!lexer::contains(prism_rtl::cat(tt, et), Text::lit("\n"))) && (len_text(prism_rtl::cat(ct, tt, et)) < Nat(70u));
    return short_
        ? prism_rtl::cat(ct, " ? ", tt, " : ", et)
        : cpp_templates::cond_expr(ct, tt, et);
}


prism_rtl::Turn<Text> CppIf::cycle() const {
    const auto& cp = this->cp;
    const auto& c = this->c;
    const auto& t = this->t;
    const auto& e = this->e;
    auto c_1 = c;
    auto cp_2 = cp;
    auto e_3 = e;
    auto t_4 = t;
    return call_then(start_cpp_expr(cp_2, c_1), [=](Text cpp_expr_30880) {
        return ({
            auto ct = cpp_expr_30880;
            auto err_opt = ({
                __label__ _done;
                prism_rtl::Slot<std::optional<lower::Ex>> _v;
                auto&& _m = std::tuple{err_of(t_4), err_of(e_3)};
                if (prism_rtl::is_some(std::get<0>(_m))) {
                    auto&& y = prism_rtl::some_of(std::get<0>(_m));
                    _v.set(std::optional(y));
                    goto _done;
                }
                if (prism_rtl::is_none(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                    auto&& y = prism_rtl::some_of(std::get<1>(_m));
                    _v.set(std::optional(y));
                    goto _done;
                }
                {
                    _v.set(std::optional<lower::Ex>{});
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto tt = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                if (prism_rtl::is_some(err_opt)) {
                    auto&& y = prism_rtl::some_of(err_opt);
                    _v.set(ok_branch(cp_2, t_4, y));
                    goto _done;
                }
                if (prism_rtl::is_none(err_opt)) {
                    _v.set(cpp_expr(cp_2, t_4));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto et = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                if (prism_rtl::is_some(err_opt)) {
                    auto&& y = prism_rtl::some_of(err_opt);
                    _v.set(ok_branch(cp_2, e_3, y));
                    goto _done;
                }
                if (prism_rtl::is_none(err_opt)) {
                    _v.set(cpp_expr(cp_2, e_3));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto short_ = (!lexer::contains(prism_rtl::cat(tt, et), Text::lit("\n"))) && (len_text(prism_rtl::cat(ct, tt, et)) < Nat(70u));
            short_
            ? prism_rtl::finished(prism_rtl::cat(ct, " ? ", tt, " : ", et))
            : prism_rtl::finished(cpp_templates::cond_expr(ct, tt, et));
        });
    });
}


/// `Start CppIf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_if(Cp cp, lower::Ex c, lower::Ex t, lower::Ex e) {
    return prism_rtl::make_rc<CppIf>(cp, c, t, e);
}


/// IsCtor: fn Ex, Text -> Bool
bool is_ctor(const lower::Ex& ex0, const Text& c) {
    if (prism_rtl::is<lower::Ex::XCtor>(ex0)) {
        auto&& p_ = prism_rtl::as<lower::Ex::XCtor>(ex0).a0;
        return p_ == c;
    }
    {
        auto&& x = ex0;
        return false;
    }
}


/// ?ErrOf: fn Ex -> ?Ex
std::optional<lower::Ex> err_of(const lower::Ex& x) {
    if (prism_rtl::is<lower::Ex::XCtor>(x)) {
        auto&& m31519_0_0 = prism_rtl::as<lower::Ex::XCtor>(x).a0;
        auto&& m31519_0_1 = prism_rtl::as<lower::Ex::XCtor>(x).a1;
        if (m31519_0_0 == Text::lit("Err")) {
            if (m31519_0_1.size() == 1u) {
                {
                    auto&& _c1 = index(m31519_0_1, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& y = prism_rtl::some_of(_c1);
                        return std::optional(y);
                    }
                }
            }
        }
    }
    if (prism_rtl::is<lower::Ex::XBlock>(x)) {
        auto&& tail = prism_rtl::as<lower::Ex::XBlock>(x).a1;
        return err_of(tail);
    }
    {
        return std::optional<lower::Ex>{};
    }
}


/// OkBranch: unbounded fn Cp, Ex, Ex -> Text
Text ok_branch(const Cp& cp, const lower::Ex& x, const lower::Ex& y) {
    if (prism_rtl::is<lower::Ex::XCtor>(x)) {
        auto&& m31822_0_0 = prism_rtl::as<lower::Ex::XCtor>(x).a0;
        auto&& m31822_0_1 = prism_rtl::as<lower::Ex::XCtor>(x).a1;
        if (m31822_0_0 == Text::lit("Ok")) {
            if (m31822_0_1.size() == 1u) {
                {
                    auto&& _c1 = index(m31822_0_1, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& v_ = prism_rtl::some_of(_c1);
                        return prism_rtl::cat("Expected<std::decay_t<decltype(", cpp_expr(cp, v_), ")>, std::decay_t<decltype(", cpp_expr(cp, y), ")>>(", cpp_expr(cp, v_), ")");
                    }
                }
            }
        }
    }
    if (prism_rtl::is<lower::Ex::XBlock>(x)) {
        auto&& dos = prism_rtl::as<lower::Ex::XBlock>(x).a0;
        auto&& m31822_1_1 = prism_rtl::as<lower::Ex::XBlock>(x).a1;
        if (prism_rtl::is<lower::Ex::XCtor>(m31822_1_1)) {
            auto&& m31822_1_1_r_0 = prism_rtl::as<lower::Ex::XCtor>(m31822_1_1).a0;
            auto&& m31822_1_1_r_1 = prism_rtl::as<lower::Ex::XCtor>(m31822_1_1).a1;
            if (m31822_1_1_r_0 == Text::lit("Ok")) {
                if (m31822_1_1_r_1.size() == 1u) {
                    {
                        auto&& _c1 = index(m31822_1_1_r_1, Nat(0u));
                        if (prism_rtl::is_some(_c1)) {
                            auto&& v_ = prism_rtl::some_of(_c1);
                            auto [st, cp2] = cpp_statements_cp(cp, dos);
                            return cpp_templates::stmt_expr(st, prism_rtl::cat("Expected<std::decay_t<decltype(", cpp_expr(cp2, v_), ")>, std::decay_t<decltype(", cpp_expr(cp2, y), ")>>(", cpp_expr(cp2, v_), ")"));
                        }
                    }
                }
            }
        }
    }
    {
        return cpp_expr(cp, x);
    }
}


prism_rtl::Turn<Text> OkBranch::cycle() const {
    const auto& cp = this->cp;
    const auto& x = this->x;
    const auto& y = this->y;
    return ({
        prism_rtl::is<lower::Ex::XCtor>(x) && ({
        auto&& m31822_0_0 = prism_rtl::as<lower::Ex::XCtor>(x).a0;
        auto&& m31822_0_1 = prism_rtl::as<lower::Ex::XCtor>(x).a1;
        (m31822_0_0 == Text::lit("Ok")) && (m31822_0_1.size() == 1u) && ({
        auto&& _c1 = index(m31822_0_1, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m31822_0_0 = prism_rtl::as<lower::Ex::XCtor>(x).a0;
        auto&& m31822_0_1 = prism_rtl::as<lower::Ex::XCtor>(x).a1;
        auto&& _c1 = index(m31822_0_1, Nat(0u));
        auto&& v_ = prism_rtl::some_of(_c1);
        ({
        auto cp_1 = cp;
        auto y_2 = y;
        call_then(start_cpp_expr(cp_1, v_), [=](Text cpp_expr_31887) { return call_then(start_cpp_expr(cp_1, y_2), [=](Text cpp_expr_31928) { return call_then(start_cpp_expr(cp_1, v_), [=](Text cpp_expr_31947) { return prism_rtl::finished(prism_rtl::cat("Expected<std::decay_t<decltype(", cpp_expr_31887, ")>, std::decay_t<decltype(", cpp_expr_31928, ")>>(", cpp_expr_31947, ")")); }); }); });
    });
    })
        : prism_rtl::is<lower::Ex::XBlock>(x) && ({
        auto&& dos = prism_rtl::as<lower::Ex::XBlock>(x).a0;
        auto&& m31822_1_1 = prism_rtl::as<lower::Ex::XBlock>(x).a1;
        prism_rtl::is<lower::Ex::XCtor>(m31822_1_1) && ({
        auto&& m31822_1_1_r_0 = prism_rtl::as<lower::Ex::XCtor>(m31822_1_1).a0;
        auto&& m31822_1_1_r_1 = prism_rtl::as<lower::Ex::XCtor>(m31822_1_1).a1;
        (m31822_1_1_r_0 == Text::lit("Ok")) && (m31822_1_1_r_1.size() == 1u) && ({
        auto&& _c1 = index(m31822_1_1_r_1, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    });
    }) ? ({
        auto&& dos = prism_rtl::as<lower::Ex::XBlock>(x).a0;
        auto&& m31822_1_1 = prism_rtl::as<lower::Ex::XBlock>(x).a1;
        auto&& m31822_1_1_r_0 = prism_rtl::as<lower::Ex::XCtor>(m31822_1_1).a0;
        auto&& m31822_1_1_r_1 = prism_rtl::as<lower::Ex::XCtor>(m31822_1_1).a1;
        auto&& _c1 = index(m31822_1_1_r_1, Nat(0u));
        auto&& v_ = prism_rtl::some_of(_c1);
        ({
        auto cp_1 = cp;
        auto dos_2 = dos;
        auto y_3 = y;
        call_then(start_cpp_statements_cp(cp_1, dos_2), [=](std::tuple<Text, Cp> cpp_statements_cp_32027) {
        return ({
            auto [st, cp2] = cpp_statements_cp_32027;
            call_then(start_cpp_expr(cp2, v_), [=](Text cpp_expr_32105) { return call_then(start_cpp_expr(cp2, y_3), [=](Text cpp_expr_32147) { return call_then(start_cpp_expr(cp2, v_), [=](Text cpp_expr_32167) { return prism_rtl::finished(cpp_templates::stmt_expr(st, prism_rtl::cat("Expected<std::decay_t<decltype(", cpp_expr_32105, ")>, std::decay_t<decltype(", cpp_expr_32147, ")>>(", cpp_expr_32167, ")"))); }); }); });
        });
    });
    });
    })
        : prism_rtl::more(prism_rtl::rc(CppExpr(cp, x)));
    });
}


/// `Start OkBranch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_ok_branch(Cp cp, lower::Ex x, lower::Ex y) {
    return prism_rtl::make_rc<OkBranch>(cp, x, y);
}


/// CppClosure: unbounded fn Cp, Bool, [Pa], Ex -> Text
Text cpp_closure(const Cp& cp0, const bool& mv, const Array<lower::Pa>& ps, const lower::Ex& body) {
    auto cp = unbind(cp0, concat2(run_to_end(each_job(ps, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(lower::Pa)>>(prism_rtl::rc([=](lower::Pa p0) {
        return entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(PatNames(p_))));
            });
        }));
    }))))));
    auto params = lexer::join(run_to_end(each_job(check_errors::range0(len(ps)), ({
        auto cp_1 = cp;
        auto ps_2 = ps;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_1_3 = cp_1;
            auto ps_2_3 = ps_2;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(ClosureParam(cp_1_3, or_(index(ps_2_3, i), lower::Pa(lower::Pa::PaWild{})), i))));
            });
        }));
        });
    })));
    }))), Text::lit(", "));
    auto binds = concat(run_to_end(each_job(check_errors::range0(len(ps)), ({
        auto cp_1 = cp;
        auto ps_2 = ps;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_1_3 = cp_1;
            auto ps_2_3 = ps_2;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(ClosureBinds(cp_1_3, or_(index(ps_2_3, i), lower::Pa(lower::Pa::PaWild{})), i))));
            });
        }));
        });
    })));
    }))));
    auto capture = mv ? Text::lit("=") : Text::lit("&");
    auto b = cpp_expr(cp, body);
    auto [ret, value] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Text, Text>> _v;
        if (prism_rtl::is<lower::Ex::XRef>(body)) {
            _v.set(std::tuple{Text::lit(" -> decltype(auto)"), prism_rtl::cat("(", b, ")")});
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XRefMut>(body)) {
            _v.set(std::tuple{Text::lit(" -> decltype(auto)"), prism_rtl::cat("(", b, ")")});
            goto _done;
        }
        {
            _v.set(std::tuple{Text::lit(""), b});
            goto _done;
        }
    _done:
        _v.take();
    });
    return (binds == Text::lit("")) && (!lexer::contains(b, Text::lit("\n")))
        ? prism_rtl::cat("[", capture, "](", params, ")", ret, " { return ", value, "; }")
        : cpp_templates::lambda(capture, prism_rtl::cat(params, ")", ret), prism_rtl::cat(binds, "return ", value, ";"));
}


prism_rtl::Turn<Text> CppClosure::cycle() const {
    const auto& cp0 = this->cp0;
    const auto& mv = this->mv;
    const auto& ps = this->ps;
    const auto& body = this->body;
    auto body_1 = body;
    auto cp0_2 = cp0;
    auto mv_3 = mv;
    auto ps_4 = ps;
    return call_value(each_job(ps_4, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(lower::Pa)>>(prism_rtl::rc([=](lower::Pa p0) {
        return entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(PatNames(p_))));
            });
        }));
    }))), [=](Array<Array<Text>> each_32402) {
        return ({
            auto cp = unbind(cp0_2, concat2(each_32402));
            call_value(each_job(check_errors::range0(len(ps_4)), ({
            auto cp_5 = cp;
            auto ps_4_6 = ps_4;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto cp_5_6 = cp_5;
                auto ps_4_6_6 = ps_4_6;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    (prism_rtl::more(prism_rtl::rc(ClosureParam(cp_5_6, or_(index(ps_4_6_6, i), lower::Pa(lower::Pa::PaWild{})), i))));
                });
            }));
            });
        })));
        })), [=](Array<Text> each_32452) {
            return ({
                auto params = lexer::join(each_32452, Text::lit(", "));
                call_value(each_job(check_errors::range0(len(ps_4)), ({
                auto cp_5 = cp;
                auto ps_4_6 = ps_4;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                return ({
                    auto cp_5_6 = cp_5;
                    auto ps_4_6_6 = ps_4_6;
                    entered(once_job([=]() {
                    return ({
                        auto i = p0;
                        (prism_rtl::more(prism_rtl::rc(ClosureBinds(cp_5_6, or_(index(ps_4_6_6, i), lower::Pa(lower::Pa::PaWild{})), i))));
                    });
                }));
                });
            })));
            })), [=](Array<Text> each_32551) {
                return ({
                    auto binds = concat(each_32551);
                    auto capture = mv_3 ? Text::lit("=") : Text::lit("&");
                    call_then(start_cpp_expr(cp, body_1), [=](Text cpp_expr_32671) {
                    return ({
                        auto b = cpp_expr_32671;
                        auto [ret, value] = ({
                            __label__ _done;
                            prism_rtl::Slot<std::tuple<Text, Text>> _v;
                            if (prism_rtl::is<lower::Ex::XRef>(body)) {
                                _v.set(std::tuple{Text::lit(" -> decltype(auto)"), prism_rtl::cat("(", b, ")")});
                                goto _done;
                            }
                            if (prism_rtl::is<lower::Ex::XRefMut>(body)) {
                                _v.set(std::tuple{Text::lit(" -> decltype(auto)"), prism_rtl::cat("(", b, ")")});
                                goto _done;
                            }
                            {
                                _v.set(std::tuple{Text::lit(""), b});
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                        (binds == Text::lit("")) && (!lexer::contains(b, Text::lit("\n")))
                        ? prism_rtl::finished(prism_rtl::cat("[", capture, "](", params, ")", ret, " { return ", value, "; }"))
                        : prism_rtl::finished(cpp_templates::lambda(capture, prism_rtl::cat(params, ")", ret), prism_rtl::cat(binds, "return ", value, ";")));
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start CppClosure, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_closure(Cp cp0, bool mv, Array<lower::Pa> ps, lower::Ex body) {
    return prism_rtl::make_rc<CppClosure>(cp0, mv, ps, body);
}


/// ClosureParam: unbounded fn Cp, Pa, Nat -> Text
Text closure_param(const Cp& cp, const lower::Pa& pa1, const Nat& i) {
    if (prism_rtl::is<lower::Pa::PaTyped>(pa1)) {
        auto&& c0_1_0 = prism_rtl::as<lower::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<lower::Pa::PaTyped>(pa1).a1;
        if (prism_rtl::is<lower::Pa::PaBind>(c0_1_0)) {
            auto&& n = prism_rtl::as<lower::Pa::PaBind>(c0_1_0).a0;
            return prism_rtl::cat(param_type(cp, t), " ", cpp_id(n));
        }
    }
    if (prism_rtl::is<lower::Pa::PaTyped>(pa1)) {
        auto&& c1_1_0 = prism_rtl::as<lower::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<lower::Pa::PaTyped>(pa1).a1;
        if (prism_rtl::is<lower::Pa::PaMut>(c1_1_0)) {
            auto&& n = prism_rtl::as<lower::Pa::PaMut>(c1_1_0).a0;
            return prism_rtl::cat(cpp_type(cp, unref(t)), " ", cpp_id(n));
        }
    }
    if (prism_rtl::is<lower::Pa::PaTyped>(pa1)) {
        auto&& p_ = prism_rtl::as<lower::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<lower::Pa::PaTyped>(pa1).a1;
        return prism_rtl::cat(param_type(cp, t), " _p", i);
    }
    if (prism_rtl::is<lower::Pa::PaBind>(pa1)) {
        auto&& n = prism_rtl::as<lower::Pa::PaBind>(pa1).a0;
        return prism_rtl::cat("auto&& ", cpp_id(n));
    }
    if (prism_rtl::is<lower::Pa::PaMut>(pa1)) {
        auto&& n = prism_rtl::as<lower::Pa::PaMut>(pa1).a0;
        return prism_rtl::cat("auto ", cpp_id(n));
    }
    if (prism_rtl::is<lower::Pa::PaWild>(pa1)) {
        return Text::lit("const auto&");
    }
    {
        auto&& p_ = pa1;
        return prism_rtl::cat("const auto& _p", i);
    }
}


prism_rtl::Turn<Text> ClosureParam::cycle() const {
    const auto& cp = this->cp;
    const auto& pa1 = this->pa1;
    const auto& i = this->i;
    return ({
        prism_rtl::is<lower::Pa::PaTyped>(pa1) && ({
        auto&& j0_1_0 = prism_rtl::as<lower::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<lower::Pa::PaTyped>(pa1).a1;
        prism_rtl::is<lower::Pa::PaBind>(j0_1_0);
    }) ? ({
        auto&& j0_1_0 = prism_rtl::as<lower::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<lower::Pa::PaTyped>(pa1).a1;
        auto&& n = prism_rtl::as<lower::Pa::PaBind>(j0_1_0).a0;
        ({
        auto cp_1 = cp;
        auto n_2 = n;
        auto t_3 = t;
        call_then(start_param_type(cp_1, t_3), [=](Text param_type_33133) { return prism_rtl::finished(prism_rtl::cat(param_type_33133, " ", cpp_id(n_2))); });
    });
    })
        : prism_rtl::is<lower::Pa::PaTyped>(pa1) && ({
        auto&& j1_1_0 = prism_rtl::as<lower::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<lower::Pa::PaTyped>(pa1).a1;
        prism_rtl::is<lower::Pa::PaMut>(j1_1_0);
    }) ? ({
        auto&& j1_1_0 = prism_rtl::as<lower::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<lower::Pa::PaTyped>(pa1).a1;
        auto&& n = prism_rtl::as<lower::Pa::PaMut>(j1_1_0).a0;
        ({
        auto cp_1 = cp;
        auto n_2 = n;
        auto t_3 = t;
        call_then(start_cpp_type(cp_1, unref(t_3)), [=](Text cpp_type_33211) { return prism_rtl::finished(prism_rtl::cat(cpp_type_33211, " ", cpp_id(n_2))); });
    });
    })
        : prism_rtl::is<lower::Pa::PaTyped>(pa1) ? ({
        auto&& p_ = prism_rtl::as<lower::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<lower::Pa::PaTyped>(pa1).a1;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        auto t_3 = t;
        call_then(start_param_type(cp_1, t_3), [=](Text param_type_33287) { return prism_rtl::finished(prism_rtl::cat(param_type_33287, " _p", i_2)); });
    });
    })
        : prism_rtl::is<lower::Pa::PaBind>(pa1) ? ({
        auto&& n = prism_rtl::as<lower::Pa::PaBind>(pa1).a0;
        prism_rtl::finished(prism_rtl::cat("auto&& ", cpp_id(n)));
    })
        : prism_rtl::is<lower::Pa::PaMut>(pa1) ? ({
        auto&& n = prism_rtl::as<lower::Pa::PaMut>(pa1).a0;
        prism_rtl::finished(prism_rtl::cat("auto ", cpp_id(n)));
    })
        : prism_rtl::is<lower::Pa::PaWild>(pa1) ? prism_rtl::finished(Text::lit("const auto&"))
        : ({
        auto&& p_ = pa1;
        prism_rtl::finished(prism_rtl::cat("const auto& _p", i));
    });
    });
}


/// `Start ClosureParam, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_closure_param(Cp cp, lower::Pa pa1, Nat i) {
    return prism_rtl::make_rc<ClosureParam>(cp, pa1, i);
}


/// ClosureBinds: unbounded fn Cp, Pa, Nat -> Text
Text closure_binds(const Cp& cp, const lower::Pa& pa1, const Nat& i) {
    if (prism_rtl::is<lower::Pa::PaTyped>(pa1)) {
        auto&& c0_1_0 = prism_rtl::as<lower::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<lower::Pa::PaTyped>(pa1).a1;
        if (prism_rtl::is<lower::Pa::PaBind>(c0_1_0)) {
            auto&& n = prism_rtl::as<lower::Pa::PaBind>(c0_1_0).a0;
            return Text::lit("");
        }
    }
    if (prism_rtl::is<lower::Pa::PaTyped>(pa1)) {
        auto&& c1_1_0 = prism_rtl::as<lower::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<lower::Pa::PaTyped>(pa1).a1;
        if (prism_rtl::is<lower::Pa::PaMut>(c1_1_0)) {
            auto&& n = prism_rtl::as<lower::Pa::PaMut>(c1_1_0).a0;
            return Text::lit("");
        }
    }
    if (prism_rtl::is<lower::Pa::PaTyped>(pa1)) {
        auto&& p_ = prism_rtl::as<lower::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<lower::Pa::PaTyped>(pa1).a1;
        return closure_binds(cp, p_, i);
    }
    if (prism_rtl::is<lower::Pa::PaBind>(pa1)) {
        auto&& n = prism_rtl::as<lower::Pa::PaBind>(pa1).a0;
        return Text::lit("");
    }
    if (prism_rtl::is<lower::Pa::PaMut>(pa1)) {
        auto&& n = prism_rtl::as<lower::Pa::PaMut>(pa1).a0;
        return Text::lit("");
    }
    if (prism_rtl::is<lower::Pa::PaWild>(pa1)) {
        return Text::lit("");
    }
    {
        auto&& p_ = pa1;
        return concat(each(pat_binds(cp, p_, prism_rtl::cat("_p", i)), [&](const Text& b) { return prism_rtl::cat(b, "\n"); }));
    }
}


prism_rtl::Turn<Text> ClosureBinds::cycle() const {
    const auto& cp = this->cp;
    const auto& pa1 = this->pa1;
    const auto& i = this->i;
    return ({
        prism_rtl::is<lower::Pa::PaTyped>(pa1) && ({
        auto&& j0_1_0 = prism_rtl::as<lower::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<lower::Pa::PaTyped>(pa1).a1;
        prism_rtl::is<lower::Pa::PaBind>(j0_1_0);
    }) ? ({
        auto&& j0_1_0 = prism_rtl::as<lower::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<lower::Pa::PaTyped>(pa1).a1;
        auto&& n = prism_rtl::as<lower::Pa::PaBind>(j0_1_0).a0;
        prism_rtl::finished(Text::lit(""));
    })
        : prism_rtl::is<lower::Pa::PaTyped>(pa1) && ({
        auto&& j1_1_0 = prism_rtl::as<lower::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<lower::Pa::PaTyped>(pa1).a1;
        prism_rtl::is<lower::Pa::PaMut>(j1_1_0);
    }) ? ({
        auto&& j1_1_0 = prism_rtl::as<lower::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<lower::Pa::PaTyped>(pa1).a1;
        auto&& n = prism_rtl::as<lower::Pa::PaMut>(j1_1_0).a0;
        prism_rtl::finished(Text::lit(""));
    })
        : prism_rtl::is<lower::Pa::PaTyped>(pa1) ? ({
        auto&& p_ = prism_rtl::as<lower::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<lower::Pa::PaTyped>(pa1).a1;
        prism_rtl::more(prism_rtl::rc(ClosureBinds(cp, p_, i)));
    })
        : prism_rtl::is<lower::Pa::PaBind>(pa1) ? ({
        auto&& n = prism_rtl::as<lower::Pa::PaBind>(pa1).a0;
        prism_rtl::finished(Text::lit(""));
    })
        : prism_rtl::is<lower::Pa::PaMut>(pa1) ? ({
        auto&& n = prism_rtl::as<lower::Pa::PaMut>(pa1).a0;
        prism_rtl::finished(Text::lit(""));
    })
        : prism_rtl::is<lower::Pa::PaWild>(pa1) ? prism_rtl::finished(Text::lit(""))
        : ({
        auto&& p_ = pa1;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        auto p__3 = p_;
        call_then(start_pat_binds(cp_1, p__3, prism_rtl::cat("_p", i_2)), [=](Array<Text> pat_binds_33877) { return prism_rtl::finished(concat(each(pat_binds_33877, [&](const Text& b) { return prism_rtl::cat(b, "\n"); }))); });
    });
    });
    });
}


/// `Start ClosureBinds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_closure_binds(Cp cp, lower::Pa pa1, Nat i) {
    return prism_rtl::make_rc<ClosureBinds>(cp, pa1, i);
}


/// Unref: fn OutTy -> OutTy
lower::OutTy unref(const lower::OutTy& out_ty0) {
    if (prism_rtl::is<lower::OutTy::OutRef>(out_ty0)) {
        auto&& t = prism_rtl::as<lower::OutTy::OutRef>(out_ty0).a0;
        return t;
    }
    {
        auto&& t = out_ty0;
        return t;
    }
}


/// ParamType: unbounded fn Cp, OutTy -> Text
Text param_type(const Cp& cp, const lower::OutTy& t) {
    if (prism_rtl::is<lower::OutTy::OutRef>(t)) {
        return cpp_type(cp, t);
    }
    if (prism_rtl::is<lower::OutTy::OutSlice>(t)) {
        return cpp_type(cp, t);
    }
    if (prism_rtl::is<lower::OutTy::OutUnit>(t)) {
        return Text::lit("Unit");
    }
    {
        return cpp_type(cp, t);
    }
}


prism_rtl::Turn<Text> ParamType::cycle() const {
    const auto& cp = this->cp;
    const auto& t = this->t;
    return ({
        prism_rtl::is<lower::OutTy::OutRef>(t) ? prism_rtl::more(prism_rtl::rc(CppType(cp, t)))
        : prism_rtl::is<lower::OutTy::OutSlice>(t) ? prism_rtl::more(prism_rtl::rc(CppType(cp, t)))
        : prism_rtl::is<lower::OutTy::OutUnit>(t) ? prism_rtl::finished(Text::lit("Unit"))
        : prism_rtl::more(prism_rtl::rc(CppType(cp, t)));
    });
}


/// `Start ParamType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_param_type(Cp cp, lower::OutTy t) {
    return prism_rtl::make_rc<ParamType>(cp, t);
}


/// PatConds: unbounded fn Cp, Pa, Text -> [Text]
Array<Text> pat_conds(const Cp& cp, const lower::Pa& p_, const Text& v_) {
    if (prism_rtl::is<lower::Pa::PaWild>(p_)) {
        return Array<Text>{};
    }
    if (prism_rtl::is<lower::Pa::PaBind>(p_)) {
        return Array<Text>{};
    }
    if (prism_rtl::is<lower::Pa::PaMut>(p_)) {
        return Array<Text>{};
    }
    if (prism_rtl::is<lower::Pa::PaTyped>(p_)) {
        auto&& q = prism_rtl::as<lower::Pa::PaTyped>(p_).a0;
        return pat_conds(cp, q, v_);
    }
    if (prism_rtl::is<lower::Pa::PaUnit>(p_)) {
        auto&& c = prism_rtl::as<lower::Pa::PaUnit>(p_).a0;
        return Array(std::vector{case_test(cp, c, v_)});
    }
    if (prism_rtl::is<lower::Pa::PaCtor>(p_)) {
        auto&& c = prism_rtl::as<lower::Pa::PaCtor>(p_).a0;
        auto&& ps = prism_rtl::as<lower::Pa::PaCtor>(p_).a1;
        auto own = case_test(cp, c, v_);
        auto inner = concat2(run_to_end(each_job(check_errors::range0(len(ps)), ({
            auto cp_1 = cp;
            auto ps_2 = ps;
            auto c_3 = c;
            auto v__4 = v_;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto cp_1_5 = cp_1;
                auto ps_2_5 = ps_2;
                auto c_3_5 = c_3;
                auto v__4_5 = v__4;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    (prism_rtl::more(prism_rtl::rc(PatConds(cp_1_5, or_(index(ps_2_5, i), lower::Pa(lower::Pa::PaWild{})), payload(cp_1_5, c_3_5, v__4_5, i)))));
                });
            }));
            });
        })));
        }))));
        return filter(append(Array(std::vector{own}), inner), [&](const Text& t) { return t != Text::lit("true"); });
    }
    if (prism_rtl::is<lower::Pa::PaRecord>(p_)) {
        auto&& c = prism_rtl::as<lower::Pa::PaRecord>(p_).a0;
        auto&& fs = prism_rtl::as<lower::Pa::PaRecord>(p_).a1;
        return concat2(run_to_end(each_job(fs, ({
            auto cp_1 = cp;
            auto v__2 = v_;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, lower::Pa>)>>(prism_rtl::rc([=](std::tuple<Text, lower::Pa> p0) {
            return ({
                auto cp_1_3 = cp_1;
                auto v__2_3 = v__2;
                entered(once_job([=]() {
                return ({
                    auto [f, q] = p0;
                    (prism_rtl::more(prism_rtl::rc(PatConds(cp_1_3, q, prism_rtl::cat(v__2_3, ".", field_id(f))))));
                });
            }));
            });
        })));
        }))));
    }
    if (prism_rtl::is<lower::Pa::PaTuple>(p_)) {
        auto&& ps = prism_rtl::as<lower::Pa::PaTuple>(p_).a0;
        return concat2(run_to_end(each_job(check_errors::range0(len(ps)), ({
            auto cp_1 = cp;
            auto ps_2 = ps;
            auto v__3 = v_;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto cp_1_4 = cp_1;
                auto ps_2_4 = ps_2;
                auto v__3_4 = v__3;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    (prism_rtl::more(prism_rtl::rc(PatConds(cp_1_4, or_(index(ps_2_4, i), lower::Pa(lower::Pa::PaWild{})), prism_rtl::cat("std::get<", i, ">(", v__3_4, ")")))));
                });
            }));
            });
        })));
        }))));
    }
    if (prism_rtl::is<lower::Pa::PaChar>(p_)) {
        auto&& c = prism_rtl::as<lower::Pa::PaChar>(p_).a0;
        return Array(std::vector{prism_rtl::cat(v_, " == U'", cpp_char_escape(c), "'")});
    }
    if (prism_rtl::is<lower::Pa::PaBool>(p_)) {
        auto&& b = prism_rtl::as<lower::Pa::PaBool>(p_).a0;
        return Array(std::vector{b ? v_ : prism_rtl::cat("!", v_)});
    }
    if (prism_rtl::is<lower::Pa::PaIndex>(p_)) {
        auto&& n = prism_rtl::as<lower::Pa::PaIndex>(p_).a0;
        return Array(std::vector{prism_rtl::cat(v_, " == ", n, "u")});
    }
    if (prism_rtl::is<lower::Pa::PaConst>(p_)) {
        auto&& n = prism_rtl::as<lower::Pa::PaConst>(p_).a0;
        return Array(std::vector{prism_rtl::cat(v_, " == ", n)});
    }
    if (prism_rtl::is<lower::Pa::PaSlice>(p_)) {
        auto&& ps = prism_rtl::as<lower::Pa::PaSlice>(p_).a0;
        auto rest = fold(ps, false, [&](const bool& f, const lower::Pa& q) { return f || is_rest(q); });
        auto fixed = len(filter(ps, [&](const lower::Pa& q) { return !is_rest(q); }));
        auto size_ = rest
            ? prism_rtl::cat(v_, ".size() >= ", fixed)
            : prism_rtl::cat(v_, ".size() == ", fixed);
        return append(Array(std::vector{size_}), concat2(run_to_end(each_job(check_errors::range0(len(ps)), ({
            auto cp_1 = cp;
            auto ps_2 = ps;
            auto v__3 = v_;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto cp_1_4 = cp_1;
                auto ps_2_4 = ps_2;
                auto v__3_4 = v__3;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    (prism_rtl::more(prism_rtl::rc(PatConds(cp_1_4, or_(index(ps_2_4, i), lower::Pa(lower::Pa::PaWild{})), prism_rtl::cat(v__3_4, "[", i, "]")))));
                });
            }));
            });
        })));
        })))));
    }
    if (prism_rtl::is<lower::Pa::PaRest>(p_)) {
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> PatConds::cycle() const {
    const auto& cp = this->cp;
    const auto& p_ = this->p_;
    const auto& v_ = this->v_;
    return ({
        prism_rtl::is<lower::Pa::PaWild>(p_) ? prism_rtl::finished(Array<Text>{})
        : prism_rtl::is<lower::Pa::PaBind>(p_) ? prism_rtl::finished(Array<Text>{})
        : prism_rtl::is<lower::Pa::PaMut>(p_) ? prism_rtl::finished(Array<Text>{})
        : prism_rtl::is<lower::Pa::PaTyped>(p_) ? ({
        auto&& q = prism_rtl::as<lower::Pa::PaTyped>(p_).a0;
        prism_rtl::more(prism_rtl::rc(PatConds(cp, q, v_)));
    })
        : prism_rtl::is<lower::Pa::PaUnit>(p_) ? ({
        auto&& c = prism_rtl::as<lower::Pa::PaUnit>(p_).a0;
        prism_rtl::finished(Array(std::vector{case_test(cp, c, v_)}));
    })
        : prism_rtl::is<lower::Pa::PaCtor>(p_) ? ({
        auto&& c = prism_rtl::as<lower::Pa::PaCtor>(p_).a0;
        auto&& ps = prism_rtl::as<lower::Pa::PaCtor>(p_).a1;
        ({
        auto own = case_test(cp, c, v_);
        auto c_1 = c;
        auto cp_2 = cp;
        auto ps_3 = ps;
        auto v__4 = v_;
        call_value(each_job(check_errors::range0(len(ps_3)), ({
        auto cp_2_5 = cp_2;
        auto ps_3_5 = ps_3;
        auto c_1_5 = c_1;
        auto v__4_5 = v__4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_2_5_5 = cp_2_5;
            auto ps_3_5_5 = ps_3_5;
            auto c_1_5_5 = c_1_5;
            auto v__4_5_5 = v__4_5;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(PatConds(cp_2_5_5, or_(index(ps_3_5_5, i), lower::Pa(lower::Pa::PaWild{})), payload(cp_2_5_5, c_1_5_5, v__4_5_5, i)))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_34872) {
        return ({
            auto inner = concat2(each_34872);
            (prism_rtl::finished(filter(append(Array(std::vector{own}), inner), [&](const Text& t) { return t != Text::lit("true"); })));
        });
    });
    });
    })
        : prism_rtl::is<lower::Pa::PaRecord>(p_) ? ({
        auto&& c = prism_rtl::as<lower::Pa::PaRecord>(p_).a0;
        auto&& fs = prism_rtl::as<lower::Pa::PaRecord>(p_).a1;
        ({
        auto cp_1 = cp;
        auto fs_2 = fs;
        auto v__3 = v_;
        call_value(each_job(fs_2, ({
        auto cp_1_4 = cp_1;
        auto v__3_4 = v__3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, lower::Pa>)>>(prism_rtl::rc([=](std::tuple<Text, lower::Pa> p0) {
        return ({
            auto cp_1_4_4 = cp_1_4;
            auto v__3_4_4 = v__3_4;
            entered(once_job([=]() {
            return ({
                auto [f, q] = p0;
                (prism_rtl::more(prism_rtl::rc(PatConds(cp_1_4_4, q, prism_rtl::cat(v__3_4_4, ".", field_id(f))))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_35051) { return prism_rtl::finished(concat2(each_35051)); });
    });
    })
        : prism_rtl::is<lower::Pa::PaTuple>(p_) ? ({
        auto&& ps = prism_rtl::as<lower::Pa::PaTuple>(p_).a0;
        ({
        auto cp_1 = cp;
        auto ps_2 = ps;
        auto v__3 = v_;
        call_value(each_job(check_errors::range0(len(ps_2)), ({
        auto cp_1_4 = cp_1;
        auto ps_2_4 = ps_2;
        auto v__3_4 = v__3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_1_4_4 = cp_1_4;
            auto ps_2_4_4 = ps_2_4;
            auto v__3_4_4 = v__3_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(PatConds(cp_1_4_4, or_(index(ps_2_4_4, i), lower::Pa(lower::Pa::PaWild{})), prism_rtl::cat("std::get<", i, ">(", v__3_4_4, ")")))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_35132) { return prism_rtl::finished(concat2(each_35132)); });
    });
    })
        : prism_rtl::is<lower::Pa::PaChar>(p_) ? ({
        auto&& c = prism_rtl::as<lower::Pa::PaChar>(p_).a0;
        prism_rtl::finished(Array(std::vector{prism_rtl::cat(v_, " == U'", cpp_char_escape(c), "'")}));
    })
        : prism_rtl::is<lower::Pa::PaBool>(p_) ? ({
        auto&& b = prism_rtl::as<lower::Pa::PaBool>(p_).a0;
        prism_rtl::finished(Array(std::vector{b ? v_ : prism_rtl::cat("!", v_)}));
    })
        : prism_rtl::is<lower::Pa::PaIndex>(p_) ? ({
        auto&& n = prism_rtl::as<lower::Pa::PaIndex>(p_).a0;
        prism_rtl::finished(Array(std::vector{prism_rtl::cat(v_, " == ", n, "u")}));
    })
        : prism_rtl::is<lower::Pa::PaConst>(p_) ? ({
        auto&& n = prism_rtl::as<lower::Pa::PaConst>(p_).a0;
        prism_rtl::finished(Array(std::vector{prism_rtl::cat(v_, " == ", n)}));
    })
        : prism_rtl::is<lower::Pa::PaSlice>(p_) ? ({
        auto&& ps = prism_rtl::as<lower::Pa::PaSlice>(p_).a0;
        ({
        auto rest = fold(ps, false, [&](const bool& f, const lower::Pa& q) { return f || is_rest(q); });
        auto fixed = len(filter(ps, [&](const lower::Pa& q) { return !is_rest(q); }));
        auto size_ = rest
            ? prism_rtl::cat(v_, ".size() >= ", fixed)
            : prism_rtl::cat(v_, ".size() == ", fixed);
        auto cp_1 = cp;
        auto ps_2 = ps;
        auto v__3 = v_;
        call_value(each_job(check_errors::range0(len(ps_2)), ({
        auto cp_1_4 = cp_1;
        auto ps_2_4 = ps_2;
        auto v__3_4 = v__3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_1_4_4 = cp_1_4;
            auto ps_2_4_4 = ps_2_4;
            auto v__3_4_4 = v__3_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(PatConds(cp_1_4_4, or_(index(ps_2_4_4, i), lower::Pa(lower::Pa::PaWild{})), prism_rtl::cat(v__3_4_4, "[", i, "]")))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_35615) { return prism_rtl::finished(append(Array(std::vector{size_}), concat2(each_35615))); });
    });
    })
        : prism_rtl::is<lower::Pa::PaRest>(p_) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start PatConds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_pat_conds(Cp cp, lower::Pa p_, Text v_) {
    return prism_rtl::make_rc<PatConds>(cp, p_, v_);
}


/// PatBinds: unbounded fn Cp, Pa, Text -> [Text]
Array<Text> pat_binds(const Cp& cp, const lower::Pa& p_, const Text& v_) {
    if (prism_rtl::is<lower::Pa::PaWild>(p_)) {
        return Array<Text>{};
    }
    if (prism_rtl::is<lower::Pa::PaBind>(p_)) {
        auto&& n = prism_rtl::as<lower::Pa::PaBind>(p_).a0;
        return Array(std::vector{prism_rtl::cat("auto&& ", cpp_id(n), " = ", v_, ";")});
    }
    if (prism_rtl::is<lower::Pa::PaMut>(p_)) {
        auto&& n = prism_rtl::as<lower::Pa::PaMut>(p_).a0;
        return Array(std::vector{prism_rtl::cat("auto ", cpp_id(n), " = ", v_, ";")});
    }
    if (prism_rtl::is<lower::Pa::PaTyped>(p_)) {
        auto&& m35784_3_0 = prism_rtl::as<lower::Pa::PaTyped>(p_).a0;
        auto&& t = prism_rtl::as<lower::Pa::PaTyped>(p_).a1;
        if (prism_rtl::is<lower::Pa::PaBind>(m35784_3_0)) {
            auto&& n = prism_rtl::as<lower::Pa::PaBind>(m35784_3_0).a0;
            return Array(std::vector{prism_rtl::cat(cpp_type(cp, unref(t)), " ", cpp_id(n), " = ", v_, ";")});
        }
    }
    if (prism_rtl::is<lower::Pa::PaTyped>(p_)) {
        auto&& q = prism_rtl::as<lower::Pa::PaTyped>(p_).a0;
        return pat_binds(cp, q, v_);
    }
    if (prism_rtl::is<lower::Pa::PaUnit>(p_)) {
        return Array<Text>{};
    }
    if (prism_rtl::is<lower::Pa::PaCtor>(p_)) {
        auto&& c = prism_rtl::as<lower::Pa::PaCtor>(p_).a0;
        auto&& ps = prism_rtl::as<lower::Pa::PaCtor>(p_).a1;
        return concat2(run_to_end(each_job(check_errors::range0(len(ps)), ({
            auto cp_1 = cp;
            auto ps_2 = ps;
            auto c_3 = c;
            auto v__4 = v_;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto cp_1_5 = cp_1;
                auto ps_2_5 = ps_2;
                auto c_3_5 = c_3;
                auto v__4_5 = v__4;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    (prism_rtl::more(prism_rtl::rc(PatBinds(cp_1_5, or_(index(ps_2_5, i), lower::Pa(lower::Pa::PaWild{})), payload(cp_1_5, c_3_5, v__4_5, i)))));
                });
            }));
            });
        })));
        }))));
    }
    if (prism_rtl::is<lower::Pa::PaRecord>(p_)) {
        auto&& c = prism_rtl::as<lower::Pa::PaRecord>(p_).a0;
        auto&& fs = prism_rtl::as<lower::Pa::PaRecord>(p_).a1;
        return concat2(run_to_end(each_job(fs, ({
            auto cp_1 = cp;
            auto v__2 = v_;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, lower::Pa>)>>(prism_rtl::rc([=](std::tuple<Text, lower::Pa> p0) {
            return ({
                auto cp_1_3 = cp_1;
                auto v__2_3 = v__2;
                entered(once_job([=]() {
                return ({
                    auto [f, q] = p0;
                    (prism_rtl::more(prism_rtl::rc(PatBinds(cp_1_3, q, prism_rtl::cat(v__2_3, ".", field_id(f))))));
                });
            }));
            });
        })));
        }))));
    }
    if (prism_rtl::is<lower::Pa::PaTuple>(p_)) {
        auto&& ps = prism_rtl::as<lower::Pa::PaTuple>(p_).a0;
        return concat2(run_to_end(each_job(check_errors::range0(len(ps)), ({
            auto cp_1 = cp;
            auto ps_2 = ps;
            auto v__3 = v_;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto cp_1_4 = cp_1;
                auto ps_2_4 = ps_2;
                auto v__3_4 = v__3;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    (prism_rtl::more(prism_rtl::rc(PatBinds(cp_1_4, or_(index(ps_2_4, i), lower::Pa(lower::Pa::PaWild{})), prism_rtl::cat("std::get<", i, ">(", v__3_4, ")")))));
                });
            }));
            });
        })));
        }))));
    }
    if (prism_rtl::is<lower::Pa::PaSlice>(p_)) {
        auto&& ps = prism_rtl::as<lower::Pa::PaSlice>(p_).a0;
        return concat2(run_to_end(each_job(check_errors::range0(len(ps)), ({
            auto cp_1 = cp;
            auto ps_2 = ps;
            auto v__3 = v_;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto cp_1_4 = cp_1;
                auto ps_2_4 = ps_2;
                auto v__3_4 = v__3;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    (prism_rtl::more(prism_rtl::rc(SliceBinds(cp_1_4, or_(index(ps_2_4, i), lower::Pa(lower::Pa::PaWild{})), v__3_4, i))));
                });
            }));
            });
        })));
        }))));
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> PatBinds::cycle() const {
    const auto& cp = this->cp;
    const auto& p_ = this->p_;
    const auto& v_ = this->v_;
    return ({
        prism_rtl::is<lower::Pa::PaWild>(p_) ? prism_rtl::finished(Array<Text>{})
        : prism_rtl::is<lower::Pa::PaBind>(p_) ? ({
        auto&& n = prism_rtl::as<lower::Pa::PaBind>(p_).a0;
        prism_rtl::finished(Array(std::vector{prism_rtl::cat("auto&& ", cpp_id(n), " = ", v_, ";")}));
    })
        : prism_rtl::is<lower::Pa::PaMut>(p_) ? ({
        auto&& n = prism_rtl::as<lower::Pa::PaMut>(p_).a0;
        prism_rtl::finished(Array(std::vector{prism_rtl::cat("auto ", cpp_id(n), " = ", v_, ";")}));
    })
        : prism_rtl::is<lower::Pa::PaTyped>(p_) && ({
        auto&& m35784_3_0 = prism_rtl::as<lower::Pa::PaTyped>(p_).a0;
        auto&& t = prism_rtl::as<lower::Pa::PaTyped>(p_).a1;
        prism_rtl::is<lower::Pa::PaBind>(m35784_3_0);
    }) ? ({
        auto&& m35784_3_0 = prism_rtl::as<lower::Pa::PaTyped>(p_).a0;
        auto&& t = prism_rtl::as<lower::Pa::PaTyped>(p_).a1;
        auto&& n = prism_rtl::as<lower::Pa::PaBind>(m35784_3_0).a0;
        ({
        auto cp_1 = cp;
        auto n_2 = n;
        auto t_3 = t;
        auto v__4 = v_;
        call_then(start_cpp_type(cp_1, unref(t_3)), [=](Text cpp_type_35926) { return prism_rtl::finished(Array(std::vector{prism_rtl::cat(cpp_type_35926, " ", cpp_id(n_2), " = ", v__4, ";")})); });
    });
    })
        : prism_rtl::is<lower::Pa::PaTyped>(p_) ? ({
        auto&& q = prism_rtl::as<lower::Pa::PaTyped>(p_).a0;
        prism_rtl::more(prism_rtl::rc(PatBinds(cp, q, v_)));
    })
        : prism_rtl::is<lower::Pa::PaUnit>(p_) ? prism_rtl::finished(Array<Text>{})
        : prism_rtl::is<lower::Pa::PaCtor>(p_) ? ({
        auto&& c = prism_rtl::as<lower::Pa::PaCtor>(p_).a0;
        auto&& ps = prism_rtl::as<lower::Pa::PaCtor>(p_).a1;
        ({
        auto c_1 = c;
        auto cp_2 = cp;
        auto ps_3 = ps;
        auto v__4 = v_;
        call_value(each_job(check_errors::range0(len(ps_3)), ({
        auto cp_2_5 = cp_2;
        auto ps_3_5 = ps_3;
        auto c_1_5 = c_1;
        auto v__4_5 = v__4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_2_5_5 = cp_2_5;
            auto ps_3_5_5 = ps_3_5;
            auto c_1_5_5 = c_1_5;
            auto v__4_5_5 = v__4_5;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(PatBinds(cp_2_5_5, or_(index(ps_3_5_5, i), lower::Pa(lower::Pa::PaWild{})), payload(cp_2_5_5, c_1_5_5, v__4_5_5, i)))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_36061) { return prism_rtl::finished(concat2(each_36061)); });
    });
    })
        : prism_rtl::is<lower::Pa::PaRecord>(p_) ? ({
        auto&& c = prism_rtl::as<lower::Pa::PaRecord>(p_).a0;
        auto&& fs = prism_rtl::as<lower::Pa::PaRecord>(p_).a1;
        ({
        auto cp_1 = cp;
        auto fs_2 = fs;
        auto v__3 = v_;
        call_value(each_job(fs_2, ({
        auto cp_1_4 = cp_1;
        auto v__3_4 = v__3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, lower::Pa>)>>(prism_rtl::rc([=](std::tuple<Text, lower::Pa> p0) {
        return ({
            auto cp_1_4_4 = cp_1_4;
            auto v__3_4_4 = v__3_4;
            entered(once_job([=]() {
            return ({
                auto [f, q] = p0;
                (prism_rtl::more(prism_rtl::rc(PatBinds(cp_1_4_4, q, prism_rtl::cat(v__3_4_4, ".", field_id(f))))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_36183) { return prism_rtl::finished(concat2(each_36183)); });
    });
    })
        : prism_rtl::is<lower::Pa::PaTuple>(p_) ? ({
        auto&& ps = prism_rtl::as<lower::Pa::PaTuple>(p_).a0;
        ({
        auto cp_1 = cp;
        auto ps_2 = ps;
        auto v__3 = v_;
        call_value(each_job(check_errors::range0(len(ps_2)), ({
        auto cp_1_4 = cp_1;
        auto ps_2_4 = ps_2;
        auto v__3_4 = v__3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_1_4_4 = cp_1_4;
            auto ps_2_4_4 = ps_2_4;
            auto v__3_4_4 = v__3_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(PatBinds(cp_1_4_4, or_(index(ps_2_4_4, i), lower::Pa(lower::Pa::PaWild{})), prism_rtl::cat("std::get<", i, ">(", v__3_4_4, ")")))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_36264) { return prism_rtl::finished(concat2(each_36264)); });
    });
    })
        : prism_rtl::is<lower::Pa::PaSlice>(p_) ? ({
        auto&& ps = prism_rtl::as<lower::Pa::PaSlice>(p_).a0;
        ({
        auto cp_1 = cp;
        auto ps_2 = ps;
        auto v__3 = v_;
        call_value(each_job(check_errors::range0(len(ps_2)), ({
        auto cp_1_4 = cp_1;
        auto ps_2_4 = ps_2;
        auto v__3_4 = v__3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_1_4_4 = cp_1_4;
            auto ps_2_4_4 = ps_2_4;
            auto v__3_4_4 = v__3_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(SliceBinds(cp_1_4_4, or_(index(ps_2_4_4, i), lower::Pa(lower::Pa::PaWild{})), v__3_4_4, i))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_36373) { return prism_rtl::finished(concat2(each_36373)); });
    });
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start PatBinds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_pat_binds(Cp cp, lower::Pa p_, Text v_) {
    return prism_rtl::make_rc<PatBinds>(cp, p_, v_);
}


/// SliceBinds: unbounded fn Cp, Pa, Text, Nat -> [Text]
Array<Text> slice_binds(const Cp& cp, const lower::Pa& pa1, const Text& v_, const Nat& i) {
    if (prism_rtl::is<lower::Pa::PaRest>(pa1)) {
        auto&& c0_1_0 = prism_rtl::as<lower::Pa::PaRest>(pa1).a0;
        if (c0_1_0 == Text::lit("")) {
            return Array<Text>{};
        }
    }
    if (prism_rtl::is<lower::Pa::PaRest>(pa1)) {
        auto&& n = prism_rtl::as<lower::Pa::PaRest>(pa1).a0;
        return Array(std::vector{prism_rtl::cat("auto ", cpp_id(n), " = ", v_, ".subspan(", i, ");")});
    }
    {
        auto&& p_ = pa1;
        return pat_binds(cp, p_, prism_rtl::cat(v_, "[", i, "]"));
    }
}


prism_rtl::Turn<Array<Text>> SliceBinds::cycle() const {
    const auto& cp = this->cp;
    const auto& pa1 = this->pa1;
    const auto& v_ = this->v_;
    const auto& i = this->i;
    return ({
        prism_rtl::is<lower::Pa::PaRest>(pa1) && ({
        auto&& j0_1_0 = prism_rtl::as<lower::Pa::PaRest>(pa1).a0;
        (j0_1_0 == Text::lit(""));
    }) ? ({
        auto&& j0_1_0 = prism_rtl::as<lower::Pa::PaRest>(pa1).a0;
        prism_rtl::finished(Array<Text>{});
    })
        : prism_rtl::is<lower::Pa::PaRest>(pa1) ? ({
        auto&& n = prism_rtl::as<lower::Pa::PaRest>(pa1).a0;
        prism_rtl::finished(Array(std::vector{prism_rtl::cat("auto ", cpp_id(n), " = ", v_, ".subspan(", i, ");")}));
    })
        : ({
        auto&& p_ = pa1;
        prism_rtl::more(prism_rtl::rc(PatBinds(cp, p_, prism_rtl::cat(v_, "[", i, "]"))));
    });
    });
}


/// `Start SliceBinds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_slice_binds(Cp cp, lower::Pa pa1, Text v_, Nat i) {
    return prism_rtl::make_rc<SliceBinds>(cp, pa1, v_, i);
}


/// IsRest: fn Pa -> Bool
bool is_rest(const lower::Pa& pa0) {
    if (prism_rtl::is<lower::Pa::PaRest>(pa0)) {
        return true;
    }
    {
        auto&& other = pa0;
        return false;
    }
}


/// Concat2: fn [ [Text] ] -> [Text]
Array<Text> concat2(const Array<Array<Text>>& xss) {
    return fold(xss, Array<Text>{}, [&](const Array<Text>& acc, const Array<Text>& xs) { return append(acc, xs); });
}


/// Conds: fn [Text] -> Text
Text conds(const Array<Text>& xs0) {
    {
        auto&& c0_0 = xs0;
        if (c0_0.size() == 0u) {
            return Text::lit("true");
        }
    }
    {
        auto&& cs = xs0;
        return lexer::join(cs, Text::lit(" && "));
    }
}


/// IsCatchAll: fn Pa -> Bool
bool is_catch_all(const lower::Pa& p_) {
    if (prism_rtl::is<lower::Pa::PaWild>(p_)) {
        return true;
    }
    if (prism_rtl::is<lower::Pa::PaBind>(p_)) {
        return true;
    }
    if (prism_rtl::is<lower::Pa::PaMut>(p_)) {
        return true;
    }
    if (prism_rtl::is<lower::Pa::PaTyped>(p_)) {
        auto&& q = prism_rtl::as<lower::Pa::PaTyped>(p_).a0;
        return is_catch_all(q);
    }
    {
        return false;
    }
}


/// Leaves: fn Ex -> Bool
bool leaves(const lower::Ex& x) {
    if (prism_rtl::is<lower::Ex::XBreak>(x)) {
        return true;
    }
    if (prism_rtl::is<lower::Ex::XBreakLoop>(x)) {
        return true;
    }
    if (prism_rtl::is<lower::Ex::XUnreachable>(x)) {
        return true;
    }
    {
        return false;
    }
}


/// CppMatch: unbounded fn Cp, Ex, [XArm], OutTy -> Text
Text cpp_match(const Cp& cp, const lower::Ex& s, const Array<lower::XArm>& arms, const lower::OutTy& out_ty3) {
    if (prism_rtl::is<lower::OutTy::OutUnknown>(out_ty3)) {
        auto&& what = prism_rtl::as<lower::OutTy::OutUnknown>(out_ty3).a0;
        return ternary_match(cp, s, arms);
    }
    {
        auto&& t = out_ty3;
        auto bound_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Text>> _v;
            if (prism_rtl::is<lower::Ex::XVar>(s)) {
                auto&& n = prism_rtl::as<lower::Ex::XVar>(s).a0;
                _v.set(std::optional(cpp_id(n)));
                goto _done;
            }
            if (prism_rtl::is<lower::Ex::XRef>(s)) {
                auto&& m37871_1_0 = prism_rtl::as<lower::Ex::XRef>(s).a0;
                if (prism_rtl::is<lower::Ex::XVar>(m37871_1_0)) {
                    auto&& n = prism_rtl::as<lower::Ex::XVar>(m37871_1_0).a0;
                    _v.set(std::optional(cpp_id(n)));
                    goto _done;
                }
            }
            {
                _v.set(std::optional<Text>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto subject = or_(bound_opt, Text::lit("_m"));
        auto bind = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is_some(bound_opt)) {
                _v.set(Text::lit(""));
                goto _done;
            }
            if (prism_rtl::is_none(bound_opt)) {
                _v.set(prism_rtl::cat("auto&& _m = ", cpp_expr(cp, s), ";\n"));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto lines = run_to_end(each_job(arms, ({
            auto cp_1 = cp;
            auto subject_2 = subject;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::XArm)>>(prism_rtl::rc([=](lower::XArm p0) {
            return ({
                auto cp_1_3 = cp_1;
                auto subject_2_3 = subject_2;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(MatchArm(cp_1_3, subject_2_3, a, false))));
                });
            }));
            });
        })));
        })));
        return cpp_templates::match_expr(cpp_type(cp, t), prism_rtl::cat(bind, lexer::join(lines, Text::lit("\n")), "\n", match_tail(arms)));
    }
}


prism_rtl::Turn<Text> CppMatch::cycle() const {
    const auto& cp = this->cp;
    const auto& s = this->s;
    const auto& arms = this->arms;
    const auto& out_ty3 = this->out_ty3;
    return ({
        prism_rtl::is<lower::OutTy::OutUnknown>(out_ty3) ? ({
        auto&& what = prism_rtl::as<lower::OutTy::OutUnknown>(out_ty3).a0;
        prism_rtl::more(prism_rtl::rc(TernaryMatch(cp, s, arms)));
    })
        : ({
        auto&& t = out_ty3;
        ({
        auto bound_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Text>> _v;
            if (prism_rtl::is<lower::Ex::XVar>(s)) {
                auto&& n = prism_rtl::as<lower::Ex::XVar>(s).a0;
                _v.set(std::optional(cpp_id(n)));
                goto _done;
            }
            if (prism_rtl::is<lower::Ex::XRef>(s)) {
                auto&& m37871_1_0 = prism_rtl::as<lower::Ex::XRef>(s).a0;
                if (prism_rtl::is<lower::Ex::XVar>(m37871_1_0)) {
                    auto&& n = prism_rtl::as<lower::Ex::XVar>(m37871_1_0).a0;
                    _v.set(std::optional(cpp_id(n)));
                    goto _done;
                }
            }
            {
                _v.set(std::optional<Text>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto subject = or_(bound_opt, Text::lit("_m"));
        auto bind = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is_some(bound_opt)) {
                _v.set(Text::lit(""));
                goto _done;
            }
            if (prism_rtl::is_none(bound_opt)) {
                _v.set(prism_rtl::cat("auto&& _m = ", cpp_expr(cp, s), ";\n"));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto arms_1 = arms;
        auto cp_2 = cp;
        auto s_3 = s;
        auto t_4 = t;
        call_value(each_job(arms_1, ({
        auto cp_2_5 = cp_2;
        auto subject_5 = subject;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::XArm)>>(prism_rtl::rc([=](lower::XArm p0) {
        return ({
            auto cp_2_5_6 = cp_2_5;
            auto subject_5_6 = subject_5;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(MatchArm(cp_2_5_6, subject_5_6, a, false))));
            });
        }));
        });
    })));
    })), [=](Array<Text> each_38112) {
        return ({
            auto lines = each_38112;
            call_then(start_cpp_type(cp_2, t_4), [=](Text cpp_type_38174) { return prism_rtl::finished(cpp_templates::match_expr(cpp_type_38174, prism_rtl::cat(bind, lexer::join(lines, Text::lit("\n")), "\n", match_tail(arms_1)))); });
        });
    });
    });
    });
    });
}


/// `Start CppMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_match(Cp cp, lower::Ex s, Array<lower::XArm> arms, lower::OutTy out_ty3) {
    return prism_rtl::make_rc<CppMatch>(cp, s, arms, out_ty3);
}


/// ReturnMatch: unbounded fn Cp, Ex, [XArm], OutTy -> Text
Text return_match(const Cp& cp, const lower::Ex& s, const Array<lower::XArm>& arms, const lower::OutTy& out_ty3) {
    if (prism_rtl::is<lower::OutTy::OutUnknown>(out_ty3)) {
        auto&& what = prism_rtl::as<lower::OutTy::OutUnknown>(out_ty3).a0;
        return prism_rtl::cat("return ", ternary_match(cp, s, arms), ";");
    }
    {
        auto&& t = out_ty3;
        auto bound_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Text>> _v;
            if (prism_rtl::is<lower::Ex::XVar>(s)) {
                auto&& n = prism_rtl::as<lower::Ex::XVar>(s).a0;
                _v.set(std::optional(cpp_id(n)));
                goto _done;
            }
            if (prism_rtl::is<lower::Ex::XRef>(s)) {
                auto&& m38645_1_0 = prism_rtl::as<lower::Ex::XRef>(s).a0;
                if (prism_rtl::is<lower::Ex::XVar>(m38645_1_0)) {
                    auto&& n = prism_rtl::as<lower::Ex::XVar>(m38645_1_0).a0;
                    _v.set(std::optional(cpp_id(n)));
                    goto _done;
                }
            }
            {
                _v.set(std::optional<Text>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto subject = or_(bound_opt, Text::lit("_m"));
        auto bind = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is_some(bound_opt)) {
                _v.set(Text::lit(""));
                goto _done;
            }
            if (prism_rtl::is_none(bound_opt)) {
                _v.set(prism_rtl::cat("auto&& _m = ", cpp_expr(cp, s), ";\n"));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto lines = run_to_end(each_job(arms, ({
            auto cp_1 = cp;
            auto subject_2 = subject;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::XArm)>>(prism_rtl::rc([=](lower::XArm p0) {
            return ({
                auto cp_1_3 = cp_1;
                auto subject_2_3 = subject_2;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(MatchArm(cp_1_3, subject_2_3, a, true))));
                });
            }));
            });
        })));
        })));
        return prism_rtl::cat(bind, lexer::join(lines, Text::lit("\n")), "\n", match_tail(arms));
    }
}


prism_rtl::Turn<Text> ReturnMatch::cycle() const {
    const auto& cp = this->cp;
    const auto& s = this->s;
    const auto& arms = this->arms;
    const auto& out_ty3 = this->out_ty3;
    return ({
        prism_rtl::is<lower::OutTy::OutUnknown>(out_ty3) ? ({
        auto&& what = prism_rtl::as<lower::OutTy::OutUnknown>(out_ty3).a0;
        ({
        auto arms_1 = arms;
        auto cp_2 = cp;
        auto s_3 = s;
        call_then(start_ternary_match(cp_2, s_3, arms_1), [=](Text ternary_match_38569) { return prism_rtl::finished(prism_rtl::cat("return ", ternary_match_38569, ";")); });
    });
    })
        : ({
        auto&& t = out_ty3;
        ({
        auto bound_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Text>> _v;
            if (prism_rtl::is<lower::Ex::XVar>(s)) {
                auto&& n = prism_rtl::as<lower::Ex::XVar>(s).a0;
                _v.set(std::optional(cpp_id(n)));
                goto _done;
            }
            if (prism_rtl::is<lower::Ex::XRef>(s)) {
                auto&& m38645_1_0 = prism_rtl::as<lower::Ex::XRef>(s).a0;
                if (prism_rtl::is<lower::Ex::XVar>(m38645_1_0)) {
                    auto&& n = prism_rtl::as<lower::Ex::XVar>(m38645_1_0).a0;
                    _v.set(std::optional(cpp_id(n)));
                    goto _done;
                }
            }
            {
                _v.set(std::optional<Text>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto subject = or_(bound_opt, Text::lit("_m"));
        auto bind = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is_some(bound_opt)) {
                _v.set(Text::lit(""));
                goto _done;
            }
            if (prism_rtl::is_none(bound_opt)) {
                _v.set(prism_rtl::cat("auto&& _m = ", cpp_expr(cp, s), ";\n"));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto arms_1 = arms;
        auto cp_2 = cp;
        auto s_3 = s;
        call_value(each_job(arms_1, ({
        auto cp_2_4 = cp_2;
        auto subject_4 = subject;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::XArm)>>(prism_rtl::rc([=](lower::XArm p0) {
        return ({
            auto cp_2_4_5 = cp_2_4;
            auto subject_4_5 = subject_4;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(MatchArm(cp_2_4_5, subject_4_5, a, true))));
            });
        }));
        });
    })));
    })), [=](Array<Text> each_38886) {
        return ({
            auto lines = each_38886;
            (prism_rtl::finished(prism_rtl::cat(bind, lexer::join(lines, Text::lit("\n")), "\n", match_tail(arms_1))));
        });
    });
    });
    });
    });
}


/// `Start ReturnMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_return_match(Cp cp, lower::Ex s, Array<lower::XArm> arms, lower::OutTy out_ty3) {
    return prism_rtl::make_rc<ReturnMatch>(cp, s, arms, out_ty3);
}


/// MatchTail: fn [XArm] -> Text
Text match_tail(const Array<lower::XArm>& arms) {
    auto ends = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = lexer::last(arms);
        if (prism_rtl::is_some(_m)) {
            auto&& a = prism_rtl::some_of(_m);
            _v.set(is_catch_all(a.pat) && (len(a.conds) == Nat(0u)));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ends
        ? Text::lit("")
        : Text::lit("prism_rtl::unreachable(\"no arm matched\");\n");
}


/// TernaryMatch: unbounded fn Cp, Ex, [XArm] -> Text
Text ternary_match(const Cp& cp, const lower::Ex& s, const Array<lower::XArm>& arms) {
    auto bound_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Text>> _v;
        if (prism_rtl::is<lower::Ex::XVar>(s)) {
            auto&& n = prism_rtl::as<lower::Ex::XVar>(s).a0;
            _v.set(std::optional(var_name(cp, n)));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XRef>(s)) {
            auto&& m39618_1_0 = prism_rtl::as<lower::Ex::XRef>(s).a0;
            if (prism_rtl::is<lower::Ex::XVar>(m39618_1_0)) {
                auto&& n = prism_rtl::as<lower::Ex::XVar>(m39618_1_0).a0;
                _v.set(std::optional(var_name(cp, n)));
                goto _done;
            }
        }
        {
            _v.set(std::optional<Text>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto subject = or_(bound_opt, Text::lit("_m"));
    auto bind = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is_some(bound_opt)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        if (prism_rtl::is_none(bound_opt)) {
            _v.set(prism_rtl::cat("auto&& _m = ", cpp_expr(cp, s), ";\n"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto reached = run_to_end(fold_job(arms, std::tuple{Array<lower::XArm>{}, false}, ({
        auto cp_1 = cp;
        auto subject_2 = subject;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<lower::XArm>, bool>>(std::tuple<std::tuple<Array<lower::XArm>, bool>, lower::XArm>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<lower::XArm>, bool>, lower::XArm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cp_1_3 = cp_1;
            auto subject_2_3 = subject_2;
            entered(once_job([=]() {
            return ({
                auto [acc, done] = p0;
                auto a = p1;
                done
                ? prism_rtl::finished(std::tuple{acc, done})
                : call_then(start_pat_conds(cp_1_3, a.pat, subject_2_3), [=](Array<Text> pat_conds_40057) { return prism_rtl::finished(std::tuple{prelude::push(acc, a), (len(pat_conds_40057) == Nat(0u)) && (len(a.conds) == Nat(0u))}); });
            });
        }));
        });
    }));
    })));
    auto [kept, ends] = reached;
    auto parts = run_to_end(each_job(kept, ({
        auto cp_1 = cp;
        auto subject_2 = subject;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::XArm)>>(prism_rtl::rc([=](lower::XArm p0) {
        return ({
            auto cp_1_3 = cp_1;
            auto subject_2_3 = subject_2;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(TernaryArm(cp_1_3, subject_2_3, a))));
            });
        }));
        });
    })));
    })));
    auto last_text = ends
        ? Text::lit("")
        : Text::lit("\n    : throw prism_rtl::Panic(\"no arm matched\")");
    return cpp_templates::stmt_expr(prism_rtl::cat(bind), prism_rtl::cat(lexer::join(parts, Text::lit("\n    : ")), last_text));
}


prism_rtl::Turn<Text> TernaryMatch::cycle() const {
    const auto& cp = this->cp;
    const auto& s = this->s;
    const auto& arms = this->arms;
    auto bound_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Text>> _v;
        if (prism_rtl::is<lower::Ex::XVar>(s)) {
            auto&& n = prism_rtl::as<lower::Ex::XVar>(s).a0;
            _v.set(std::optional(var_name(cp, n)));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XRef>(s)) {
            auto&& m39618_1_0 = prism_rtl::as<lower::Ex::XRef>(s).a0;
            if (prism_rtl::is<lower::Ex::XVar>(m39618_1_0)) {
                auto&& n = prism_rtl::as<lower::Ex::XVar>(m39618_1_0).a0;
                _v.set(std::optional(var_name(cp, n)));
                goto _done;
            }
        }
        {
            _v.set(std::optional<Text>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto subject = or_(bound_opt, Text::lit("_m"));
    auto bind = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is_some(bound_opt)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        if (prism_rtl::is_none(bound_opt)) {
            _v.set(prism_rtl::cat("auto&& _m = ", cpp_expr(cp, s), ";\n"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto arms_1 = arms;
    auto cp_2 = cp;
    return call_value(fold_job(arms_1, std::tuple{Array<lower::XArm>{}, false}, ({
        auto cp_2_3 = cp_2;
        auto subject_3 = subject;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<lower::XArm>, bool>>(std::tuple<std::tuple<Array<lower::XArm>, bool>, lower::XArm>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<lower::XArm>, bool>, lower::XArm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cp_2_3_4 = cp_2_3;
            auto subject_3_4 = subject_3;
            entered(once_job([=]() {
            return ({
                auto [acc, done] = p0;
                auto a = p1;
                done
                ? prism_rtl::finished(std::tuple{acc, done})
                : call_then(start_pat_conds(cp_2_3_4, a.pat, subject_3_4), [=](Array<Text> pat_conds_40057) { return prism_rtl::finished(std::tuple{prelude::push(acc, a), (len(pat_conds_40057) == Nat(0u)) && (len(a.conds) == Nat(0u))}); });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<lower::XArm>, bool> fold_39957) {
        return ({
            auto reached = fold_39957;
            auto [kept, ends] = reached;
            call_value(each_job(kept, ({
            auto cp_2_3 = cp_2;
            auto subject_3 = subject;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::XArm)>>(prism_rtl::rc([=](lower::XArm p0) {
            return ({
                auto cp_2_3_4 = cp_2_3;
                auto subject_3_4 = subject_3;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(TernaryArm(cp_2_3_4, subject_3_4, a))));
                });
            }));
            });
        })));
        })), [=](Array<Text> each_40166) {
            return ({
                auto parts = each_40166;
                auto last_text = ends
                    ? Text::lit("")
                    : Text::lit("\n    : throw prism_rtl::Panic(\"no arm matched\")");
                (prism_rtl::finished(cpp_templates::stmt_expr(prism_rtl::cat(bind), prism_rtl::cat(lexer::join(parts, Text::lit("\n    : ")), last_text))));
            });
        });
        });
    });
}


/// `Start TernaryMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_ternary_match(Cp cp, lower::Ex s, Array<lower::XArm> arms) {
    return prism_rtl::make_rc<TernaryMatch>(cp, s, arms);
}


/// TernaryArm: unbounded fn Cp, Text, XArm -> Text
Text ternary_arm(const Cp& cp0, const Text& subject, const lower::XArm& a) {
    auto cp = unbind(cp0, arm_names(a));
    auto tests = pat_conds(cp, a.pat, subject);
    auto binds = pat_binds(cp, a.pat, subject);
    auto n = len(a.conds);
    auto lets = concat2(run_to_end(each_job(check_errors::range0(n), ({
        auto cp_1 = cp;
        auto a_2 = a;
        auto n_3 = n;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_1_4 = cp_1;
            auto a_2_4 = a_2;
            auto n_3_4 = n_3;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(CondBinds(cp_1_4, or_(index(a_2_4.conds, i), lower::Cc(lower::Cc::CcIf{lower::Ex(lower::Ex::XUnit{})})), or_(n_3_4.checked_sub(i), Nat(0u))))));
            });
        }));
        });
    })));
    }))));
    auto value = (len(binds) + len(lets)) == Nat(0u)
        ? cpp_expr(cp, a.body)
        : cpp_templates::stmt_expr(lexer::join(append(binds, lets), Text::lit("\n")), cpp_expr(cp, a.body));
    auto guard = len(a.conds) == Nat(0u)
        ? Array<Text>{}
        : Array(std::vector{cpp_templates::stmt_expr(lexer::join(binds, Text::lit("\n")), guard_test(cp, a.conds))});
    auto all = append(tests, guard);
    return len(all) == Nat(0u) ? value : prism_rtl::cat(conds(all), " ? ", value);
}


prism_rtl::Turn<Text> TernaryArm::cycle() const {
    const auto& cp0 = this->cp0;
    const auto& subject = this->subject;
    const auto& a = this->a;
    auto a_1 = a;
    auto cp0_2 = cp0;
    auto subject_3 = subject;
    return call_then(start_arm_names(a_1), [=](Array<Text> arm_names_40464) {
        return ({
            auto cp = unbind(cp0_2, arm_names_40464);
            call_then(start_pat_conds(cp, a_1.pat, subject_3), [=](Array<Text> pat_conds_40492) {
            return ({
                auto tests = pat_conds_40492;
                call_then(start_pat_binds(cp, a_1.pat, subject_3), [=](Array<Text> pat_binds_40536) {
                return ({
                    auto binds = pat_binds_40536;
                    auto n = len(a_1.conds);
                    call_value(each_job(check_errors::range0(n), ({
                    auto cp_4 = cp;
                    auto a_1_5 = a_1;
                    auto n_5 = n;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                    return ({
                        auto cp_4_6 = cp_4;
                        auto a_1_5_6 = a_1_5;
                        auto n_5_6 = n_5;
                        entered(once_job([=]() {
                        return ({
                            auto i = p0;
                            (prism_rtl::more(prism_rtl::rc(CondBinds(cp_4_6, or_(index(a_1_5_6.conds, i), lower::Cc(lower::Cc::CcIf{lower::Ex(lower::Ex::XUnit{})})), or_(n_5_6.checked_sub(i), Nat(0u))))));
                        });
                    }));
                    });
                })));
                })), [=](Array<Array<Text>> each_40612) {
                    return ({
                        auto lets = concat2(each_40612);
                        auto value = (len(binds) + len(lets)) == Nat(0u)
                            ? cpp_expr(cp, a_1.body)
                            : cpp_templates::stmt_expr(lexer::join(append(binds, lets), Text::lit("\n")), cpp_expr(cp, a_1.body));
                        auto guard = len(a_1.conds) == Nat(0u)
                            ? Array<Text>{}
                            : Array(std::vector{cpp_templates::stmt_expr(lexer::join(binds, Text::lit("\n")), guard_test(cp, a_1.conds))});
                        auto all = append(tests, guard);
                        len(all) == Nat(0u)
                        ? prism_rtl::finished(value)
                        : prism_rtl::finished(prism_rtl::cat(conds(all), " ? ", value));
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start TernaryArm, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_ternary_arm(Cp cp0, Text subject, lower::XArm a) {
    return prism_rtl::make_rc<TernaryArm>(cp0, subject, a);
}


/// CondBinds: unbounded fn Cp, Cc, Nat -> [Text]
Array<Text> cond_binds(const Cp& cp, const lower::Cc& cc1, const Nat& k) {
    if (prism_rtl::is<lower::Cc::CcLet>(cc1)) {
        auto&& p_ = prism_rtl::as<lower::Cc::CcLet>(cc1).a0;
        auto&& x = prism_rtl::as<lower::Cc::CcLet>(cc1).a1;
        auto [v_, pre] = cond_subject(cp, x, k);
        return append(pre, pat_binds(cp, p_, v_));
    }
    if (prism_rtl::is<lower::Cc::CcIf>(cc1)) {
        auto&& x = prism_rtl::as<lower::Cc::CcIf>(cc1).a0;
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> CondBinds::cycle() const {
    const auto& cp = this->cp;
    const auto& cc1 = this->cc1;
    const auto& k = this->k;
    return ({
        prism_rtl::is<lower::Cc::CcLet>(cc1) ? ({
        auto&& p_ = prism_rtl::as<lower::Cc::CcLet>(cc1).a0;
        auto&& x = prism_rtl::as<lower::Cc::CcLet>(cc1).a1;
        ({
        auto cp_1 = cp;
        auto k_2 = k;
        auto p__3 = p_;
        auto x_4 = x;
        call_then(start_cond_subject(cp_1, x_4, k_2), [=](std::tuple<Text, Array<Text>> cond_subject_41141) {
        return ({
            auto [v_, pre] = cond_subject_41141;
            call_then(start_pat_binds(cp_1, p__3, v_), [=](Array<Text> pat_binds_41179) { return prism_rtl::finished(append(pre, pat_binds_41179)); });
        });
    });
    });
    })
        : prism_rtl::is<lower::Cc::CcIf>(cc1) ? ({
        auto&& x = prism_rtl::as<lower::Cc::CcIf>(cc1).a0;
        prism_rtl::finished(Array<Text>{});
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CondBinds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_cond_binds(Cp cp, lower::Cc cc1, Nat k) {
    return prism_rtl::make_rc<CondBinds>(cp, cc1, k);
}


/// CondSubject: unbounded fn Cp, Ex, Nat -> ((Text, [Text]))
std::tuple<Text, Array<Text>> cond_subject(const Cp& cp, const lower::Ex& x, const Nat& k) {
    return is_place_ex(x)
        ? std::tuple{cpp_tight(cp, x), Array<Text>{}}
        : std::tuple{prism_rtl::cat("_c", k), Array(std::vector{prism_rtl::cat("auto&& _c", k, " = ", cpp_expr(cp, x), ";")})};
}


prism_rtl::Turn<std::tuple<Text, Array<Text>>> CondSubject::cycle() const {
    const auto& cp = this->cp;
    const auto& x = this->x;
    const auto& k = this->k;
    return is_place_ex(x)
        ? ({
        auto cp_1 = cp;
        auto x_2 = x;
        call_then(start_cpp_tight(cp_1, x_2), [=](Text cpp_tight_41596) { return prism_rtl::finished(std::tuple{cpp_tight_41596, Array<Text>{}}); });
    })
        : ({
        auto cp_1 = cp;
        auto k_2 = k;
        auto x_3 = x;
        call_then(start_cpp_expr(cp_1, x_3), [=](Text cpp_expr_41656) { return prism_rtl::finished(std::tuple{prism_rtl::cat("_c", k_2), Array(std::vector{prism_rtl::cat("auto&& _c", k_2, " = ", cpp_expr_41656, ";")})}); });
    });
}


/// `Start CondSubject, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, Array<Text>>> start_cond_subject(Cp cp, lower::Ex x, Nat k) {
    return prism_rtl::make_rc<CondSubject>(cp, x, k);
}


/// IsPlaceEx: fn Ex -> Bool
bool is_place_ex(const lower::Ex& x) {
    if (prism_rtl::is<lower::Ex::XVar>(x)) {
        return true;
    }
    if (prism_rtl::is<lower::Ex::XField>(x)) {
        auto&& y = prism_rtl::as<lower::Ex::XField>(x).a0;
        return is_place_ex(y);
    }
    if (prism_rtl::is<lower::Ex::XPart>(x)) {
        auto&& y = prism_rtl::as<lower::Ex::XPart>(x).a0;
        return is_place_ex(y);
    }
    if (prism_rtl::is<lower::Ex::XTarget>(x)) {
        return true;
    }
    if (prism_rtl::is<lower::Ex::XSelf>(x)) {
        return true;
    }
    if (prism_rtl::is<lower::Ex::XRef>(x)) {
        auto&& y = prism_rtl::as<lower::Ex::XRef>(x).a0;
        return is_place_ex(y);
    }
    if (prism_rtl::is<lower::Ex::XDeref>(x)) {
        auto&& y = prism_rtl::as<lower::Ex::XDeref>(x).a0;
        return is_place_ex(y);
    }
    {
        return false;
    }
}


/// GuardTest: unbounded fn Cp, [Cc] -> Text
Text guard_test(const Cp& cp, const Array<lower::Cc>& xs1) {
    {
        auto&& c0_1 = xs1;
        if (c0_1.size() == 0u) {
            return Text::lit("true");
        }
    }
    {
        auto&& cs = xs1;
        auto first_ = or_(index(cs, Nat(0u)), lower::Cc(lower::Cc::CcIf{lower::Ex(lower::Ex::XUnit{})}));
        auto rest = guard_test(cp, drop(cs, Nat(1u)));
        if (prism_rtl::is<lower::Cc::CcIf>(first_)) {
            auto&& x = prism_rtl::as<lower::Cc::CcIf>(first_).a0;
            return len(cs) == Nat(1u)
                ? cpp_tight(cp, x)
                : prism_rtl::cat(cpp_tight(cp, x), " && ", rest);
        }
        if (prism_rtl::is<lower::Cc::CcLet>(first_)) {
            auto&& p_ = prism_rtl::as<lower::Cc::CcLet>(first_).a0;
            auto&& x = prism_rtl::as<lower::Cc::CcLet>(first_).a1;
            auto [v_, pre] = cond_subject(cp, x, len(cs));
            auto tests = conds(pat_conds(cp, p_, v_));
            auto whole = len(cs) == Nat(1u)
                ? tests
                : prism_rtl::cat(tests, " && ", cpp_templates::stmt_expr(lexer::join(pat_binds(cp, p_, v_), Text::lit("\n")), rest));
            return len(pre) == Nat(0u)
                ? whole
                : cpp_templates::stmt_expr(lexer::join(pre, Text::lit("\n")), whole);
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<Text> GuardTest::cycle() const {
    const auto& cp = this->cp;
    const auto& xs1 = this->xs1;
    return ({
        ({
        auto&& j0_1 = xs1;
        (j0_1.size() == 0u);
    }) ? ({
        auto&& j0_1 = xs1;
        prism_rtl::finished(Text::lit("true"));
    })
        : ({
        auto&& cs = xs1;
        ({
        auto first_ = or_(index(cs, Nat(0u)), lower::Cc(lower::Cc::CcIf{lower::Ex(lower::Ex::XUnit{})}));
        auto cp_1 = cp;
        auto cs_2 = cs;
        call_then(start_guard_test(cp_1, drop(cs_2, Nat(1u))), [=](Text guard_test_42160) {
        return ({
            auto rest = guard_test_42160;
            ({
            prism_rtl::is<lower::Cc::CcIf>(first_) ? ({
            auto&& x = prism_rtl::as<lower::Cc::CcIf>(first_).a0;
            len(cs_2) == Nat(1u)
            ? prism_rtl::more(prism_rtl::rc(CppTight(cp_1, x)))
            : ({
            auto x_3 = x;
            call_then(start_cpp_tight(cp_1, x_3), [=](Text cpp_tight_42261) { return prism_rtl::finished(prism_rtl::cat(cpp_tight_42261, " && ", rest)); });
        });
        })
            : prism_rtl::is<lower::Cc::CcLet>(first_) ? ({
            auto&& p_ = prism_rtl::as<lower::Cc::CcLet>(first_).a0;
            auto&& x = prism_rtl::as<lower::Cc::CcLet>(first_).a1;
            ({
            auto p__3 = p_;
            auto x_4 = x;
            call_then(start_cond_subject(cp_1, x_4, len(cs_2)), [=](std::tuple<Text, Array<Text>> cond_subject_42337) {
            return ({
                auto [v_, pre] = cond_subject_42337;
                call_then(start_pat_conds(cp_1, p__3, v_), [=](Array<Text> pat_conds_42396) {
                return ({
                    auto tests = conds(pat_conds_42396);
                    auto whole = len(cs_2) == Nat(1u)
                        ? tests
                        : prism_rtl::cat(tests, " && ", cpp_templates::stmt_expr(lexer::join(pat_binds(cp_1, p__3, v_), Text::lit("\n")), rest));
                    len(pre) == Nat(0u)
                    ? prism_rtl::finished(whole)
                    : prism_rtl::finished(cpp_templates::stmt_expr(lexer::join(pre, Text::lit("\n")), whole));
                });
            });
            });
        });
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
    });
    });
    });
}


/// `Start GuardTest, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_guard_test(Cp cp, Array<lower::Cc> xs1) {
    return prism_rtl::make_rc<GuardTest>(cp, xs1);
}


/// MatchArm: unbounded fn Cp, Text, XArm, Bool -> Text
Text match_arm(const Cp& cp0, const Text& subject, const lower::XArm& a, const bool& returns) {
    auto cp = unbind(cp0, arm_names(a));
    auto tests = pat_conds(cp, a.pat, subject);
    auto binds = pat_binds(cp, a.pat, subject);
    auto body = returns
        ? cpp_body(cp, a.body)
        : leaves(a.body)
        ? prism_rtl::cat(cpp_expr(cp, a.body), ";")
        : prism_rtl::cat("_v.set(", cpp_expr(cp, a.body), ");\ngoto _done;");
    auto guarded = len(a.conds) == Nat(0u) ? body : guarded_arm(cp, a.conds, body);
    auto inner = lexer::join(append(binds, Array(std::vector{guarded})), Text::lit("\n"));
    return len(tests) == Nat(0u)
        ? cpp_templates::braced(inner)
        : cpp_templates::if_block(conds(tests), inner);
}


prism_rtl::Turn<Text> MatchArm::cycle() const {
    const auto& cp0 = this->cp0;
    const auto& subject = this->subject;
    const auto& a = this->a;
    const auto& returns = this->returns;
    auto a_1 = a;
    auto cp0_2 = cp0;
    auto returns_3 = returns;
    auto subject_4 = subject;
    return call_then(start_arm_names(a_1), [=](Array<Text> arm_names_42854) {
        return ({
            auto cp = unbind(cp0_2, arm_names_42854);
            call_then(start_pat_conds(cp, a_1.pat, subject_4), [=](Array<Text> pat_conds_42882) {
            return ({
                auto tests = pat_conds_42882;
                call_then(start_pat_binds(cp, a_1.pat, subject_4), [=](Array<Text> pat_binds_42926) {
                return ({
                    auto binds = pat_binds_42926;
                    auto body = returns_3
                        ? cpp_body(cp, a_1.body)
                        : leaves(a_1.body)
                        ? prism_rtl::cat(cpp_expr(cp, a_1.body), ";")
                        : prism_rtl::cat("_v.set(", cpp_expr(cp, a_1.body), ");\ngoto _done;");
                    auto guarded = len(a_1.conds) == Nat(0u) ? body : guarded_arm(cp, a_1.conds, body);
                    auto inner = lexer::join(append(binds, Array(std::vector{guarded})), Text::lit("\n"));
                    len(tests) == Nat(0u)
                    ? prism_rtl::finished(cpp_templates::braced(inner))
                    : prism_rtl::finished(cpp_templates::if_block(conds(tests), inner));
                });
            });
            });
        });
        });
    });
}


/// `Start MatchArm, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_match_arm(Cp cp0, Text subject, lower::XArm a, bool returns) {
    return prism_rtl::make_rc<MatchArm>(cp0, subject, a, returns);
}


/// GuardedArm: unbounded fn Cp, [Cc], Text -> Text
Text guarded_arm(const Cp& cp, const Array<lower::Cc>& xs1, const Text& body) {
    {
        auto&& c0_1 = xs1;
        if (c0_1.size() == 0u) {
            return body;
        }
    }
    {
        auto&& cs = xs1;
        auto first_ = or_(index(cs, Nat(0u)), lower::Cc(lower::Cc::CcIf{lower::Ex(lower::Ex::XUnit{})}));
        auto rest = guarded_arm(cp, drop(cs, Nat(1u)), body);
        if (prism_rtl::is<lower::Cc::CcIf>(first_)) {
            auto&& x = prism_rtl::as<lower::Cc::CcIf>(first_).a0;
            return cpp_templates::if_block(cpp_expr(cp, x), rest);
        }
        if (prism_rtl::is<lower::Cc::CcLet>(first_)) {
            auto&& p_ = prism_rtl::as<lower::Cc::CcLet>(first_).a0;
            auto&& x = prism_rtl::as<lower::Cc::CcLet>(first_).a1;
            auto [v_, pre] = cond_subject(cp, x, len(cs));
            auto inner = cpp_templates::if_block(conds(pat_conds(cp, p_, v_)), lexer::join(append(pat_binds(cp, p_, v_), Array(std::vector{rest})), Text::lit("\n")));
            return len(pre) == Nat(0u)
                ? inner
                : cpp_templates::braced(lexer::join(prelude::push(pre, inner), Text::lit("\n")));
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<Text> GuardedArm::cycle() const {
    const auto& cp = this->cp;
    const auto& xs1 = this->xs1;
    const auto& body = this->body;
    return ({
        ({
        auto&& j0_1 = xs1;
        (j0_1.size() == 0u);
    }) ? ({
        auto&& j0_1 = xs1;
        prism_rtl::finished(body);
    })
        : ({
        auto&& cs = xs1;
        ({
        auto first_ = or_(index(cs, Nat(0u)), lower::Cc(lower::Cc::CcIf{lower::Ex(lower::Ex::XUnit{})}));
        auto body_1 = body;
        auto cp_2 = cp;
        auto cs_3 = cs;
        call_then(start_guarded_arm(cp_2, drop(cs_3, Nat(1u)), body_1), [=](Text guarded_arm_43563) {
        return ({
            auto rest = guarded_arm_43563;
            ({
            prism_rtl::is<lower::Cc::CcIf>(first_) ? ({
            auto&& x = prism_rtl::as<lower::Cc::CcIf>(first_).a0;
            ({
            auto x_4 = x;
            call_then(start_cpp_expr(cp_2, x_4), [=](Text cpp_expr_43639) { return prism_rtl::finished(cpp_templates::if_block(cpp_expr_43639, rest)); });
        });
        })
            : prism_rtl::is<lower::Cc::CcLet>(first_) ? ({
            auto&& p_ = prism_rtl::as<lower::Cc::CcLet>(first_).a0;
            auto&& x = prism_rtl::as<lower::Cc::CcLet>(first_).a1;
            ({
            auto p__4 = p_;
            auto x_5 = x;
            call_then(start_cond_subject(cp_2, x_5, len(cs_3)), [=](std::tuple<Text, Array<Text>> cond_subject_43709) {
            return ({
                auto [v_, pre] = cond_subject_43709;
                call_then(start_pat_conds(cp_2, p__4, v_), [=](Array<Text> pat_conds_43777) {
                return call_then(start_pat_binds(cp_2, p__4, v_), [=](Array<Text> pat_binds_43813) {
                    return ({
                        auto inner = cpp_templates::if_block(conds(pat_conds_43777), lexer::join(append(pat_binds_43813, Array(std::vector{rest})), Text::lit("\n")));
                        len(pre) == Nat(0u)
                        ? prism_rtl::finished(inner)
                        : prism_rtl::finished(cpp_templates::braced(lexer::join(prelude::push(pre, inner), Text::lit("\n"))));
                    });
                });
            });
            });
        });
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
    });
    });
    });
}


/// `Start GuardedArm, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_guarded_arm(Cp cp, Array<lower::Cc> xs1, Text body) {
    return prism_rtl::make_rc<GuardedArm>(cp, xs1, body);
}


/// CppLabeled: unbounded fn Cp, Text, [Do], Ex, OutTy -> Text
Text cpp_labeled(const Cp& cp, const Text& label, const Array<lower::Do>& dos, const lower::Ex& e, const lower::OutTy& t) {
    auto l = cpp_label(label);
    auto last = leaves(e)
        ? prism_rtl::cat(cpp_expr(cp, e), ";")
        : prism_rtl::cat(l, "_v.set(", cpp_expr(cp, e), ");");
    return cpp_templates::labeled_expr(l, cpp_type(cp, t), lexer::join(prelude::push(run_to_end(each_job(dos, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Do)>>(prism_rtl::rc([=](lower::Do p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto d = p0;
                (prism_rtl::more(prism_rtl::rc(CppStatement(cp_1_2, d))));
            });
        }));
        });
    })));
    }))), last), Text::lit("\n")));
}


prism_rtl::Turn<Text> CppLabeled::cycle() const {
    const auto& cp = this->cp;
    const auto& label = this->label;
    const auto& dos = this->dos;
    const auto& e = this->e;
    const auto& t = this->t;
    auto l = cpp_label(label);
    auto last = leaves(e)
        ? prism_rtl::cat(cpp_expr(cp, e), ";")
        : prism_rtl::cat(l, "_v.set(", cpp_expr(cp, e), ");");
    auto cp_1 = cp;
    auto dos_2 = dos;
    auto t_3 = t;
    return call_then(start_cpp_type(cp_1, t_3), [=](Text cpp_type_44239) {
        return call_value(each_job(dos_2, ({
            auto cp_1_4 = cp_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Do)>>(prism_rtl::rc([=](lower::Do p0) {
            return ({
                auto cp_1_4_4 = cp_1_4;
                entered(once_job([=]() {
                return ({
                    auto d = p0;
                    (prism_rtl::more(prism_rtl::rc(CppStatement(cp_1_4_4, d))));
                });
            }));
            });
        })));
        })), [=](Array<Text> each_44268) { return prism_rtl::finished(cpp_templates::labeled_expr(l, cpp_type_44239, lexer::join(prelude::push(each_44268, last), Text::lit("\n")))); });
    });
}


/// `Start CppLabeled, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_labeled(Cp cp, Text label, Array<lower::Do> dos, lower::Ex e, lower::OutTy t) {
    return prism_rtl::make_rc<CppLabeled>(cp, label, dos, e, t);
}


/// CppLabel: fn Text -> Text
Text cpp_label(const Text& l) {
    return lexer::has_prefix(l, Text::lit("'")) ? lexer::after_first(l) : l;
}


/// CppBreak: unbounded fn Cp, Text, Ex -> Text
Text cpp_break(const Cp& cp, const Text& l, const lower::Ex& y) {
    auto n = cpp_label(l);
    return prism_rtl::cat("{ ", n, "_v.set(", cpp_expr(cp, y), "); goto ", n, "; }");
}


prism_rtl::Turn<Text> CppBreak::cycle() const {
    const auto& cp = this->cp;
    const auto& l = this->l;
    const auto& y = this->y;
    auto n = cpp_label(l);
    auto cp_1 = cp;
    auto y_2 = y;
    return call_then(start_cpp_expr(cp_1, y_2), [=](Text cpp_expr_44513) { return prism_rtl::finished(prism_rtl::cat("{ ", n, "_v.set(", cpp_expr_44513, "); goto ", n, "; }")); });
}


/// `Start CppBreak, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_break(Cp cp, Text l, lower::Ex y) {
    return prism_rtl::make_rc<CppBreak>(cp, l, y);
}


/// CppStatements: unbounded fn Cp, [Do] -> Text
Text cpp_statements(const Cp& cp, const Array<lower::Do>& dos) {
    auto&& _st = cpp_statements_cp(cp, dos);
    auto&& st = std::get<0>(_st);
    return st;
}


prism_rtl::Turn<Text> CppStatements::cycle() const {
    const auto& cp = this->cp;
    const auto& dos = this->dos;
    auto cp_1 = cp;
    auto dos_2 = dos;
    return call_then(start_cpp_statements_cp(cp_1, dos_2), [=](std::tuple<Text, Cp> cpp_statements_cp_44835) {
        return ({
            auto&& _st = cpp_statements_cp_44835;
            auto&& st = std::get<0>(_st);
            (prism_rtl::finished(st));
        });
    });
}


/// `Start CppStatements, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_statements(Cp cp, Array<lower::Do> dos) {
    return prism_rtl::make_rc<CppStatements>(cp, dos);
}


/// CppStatementsCp: unbounded fn Cp, [Do] -> ((Text, Cp))
std::tuple<Text, Cp> cpp_statements_cp(const Cp& cp, const Array<lower::Do>& dos) {
    auto [lines, last] = run_to_end(fold_job(dos, std::tuple{Array<Text>{}, cp}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Cp>>(std::tuple<std::tuple<Array<Text>, Cp>, lower::Do>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Text>, Cp>, lower::Do> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [acc, c] = p0;
                auto d = p1;
                call_then(start_rebound(c, d), [=](Cp rebound_45262) {
                return ({
                    auto c2 = rebound_45262;
                    auto line = ({
                        __label__ _done;
                        prism_rtl::Slot<Text> _v;
                        if (prism_rtl::is<lower::Do::DoLet>(d)) {
                            auto&& p_ = prism_rtl::as<lower::Do::DoLet>(d).a0;
                            auto&& x = prism_rtl::as<lower::Do::DoLet>(d).a1;
                            _v.set(cpp_let(c, c2, p_, x));
                            goto _done;
                        }
                        {
                            _v.set(cpp_statement(c2, d));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    (prism_rtl::finished(std::tuple{prelude::push(acc, line), c2}));
                });
            });
            });
        }));
    }))));
    return std::tuple{lexer::join(lines, Text::lit("\n")), last};
}


prism_rtl::Turn<std::tuple<Text, Cp>> CppStatementsCp::cycle() const {
    const auto& cp = this->cp;
    const auto& dos = this->dos;
    auto cp_1 = cp;
    auto dos_2 = dos;
    return call_value(fold_job(dos_2, std::tuple{Array<Text>{}, cp_1}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Cp>>(std::tuple<std::tuple<Array<Text>, Cp>, lower::Do>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Text>, Cp>, lower::Do> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [acc, c] = p0;
                auto d = p1;
                call_then(start_rebound(c, d), [=](Cp rebound_45262) {
                return ({
                    auto c2 = rebound_45262;
                    auto line = ({
                        __label__ _done;
                        prism_rtl::Slot<Text> _v;
                        if (prism_rtl::is<lower::Do::DoLet>(d)) {
                            auto&& p_ = prism_rtl::as<lower::Do::DoLet>(d).a0;
                            auto&& x = prism_rtl::as<lower::Do::DoLet>(d).a1;
                            _v.set(cpp_let(c, c2, p_, x));
                            goto _done;
                        }
                        {
                            _v.set(cpp_statement(c2, d));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    (prism_rtl::finished(std::tuple{prelude::push(acc, line), c2}));
                });
            });
            });
        }));
    }))), [=](std::tuple<Array<Text>, Cp> fold_45204) {
        return ({
            auto [lines, last] = fold_45204;
            (prism_rtl::finished(std::tuple{lexer::join(lines, Text::lit("\n")), last}));
        });
    });
}


/// `Start CppStatementsCp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, Cp>> start_cpp_statements_cp(Cp cp, Array<lower::Do> dos) {
    return prism_rtl::make_rc<CppStatementsCp>(cp, dos);
}


/// Unvexed: fn Text -> Text
Text unvexed(const Text& t) {
    auto head = or_(index(split(t, Text::lit("(")), Nat(0u)), Text::lit(""));
    auto type_like = lexer::contains(head, Text::lit(":")) || lexer::contains(Text::lit("ABCDEFGHIJKLMNOPQRSTUVWXYZ"), lexer::head(head));
    auto vexing = (((lexer::last_char(t) == Text::lit(")")) && (!lexer::contains(head, Text::lit(" ")))) && (head != Text::lit(""))) && type_like;
    return vexing ? prism_rtl::cat("(", t, ")") : t;
}


/// Rebound: unbounded fn Cp, Do -> Cp
Cp rebound(const Cp& cp, const lower::Do& d) {
    if (prism_rtl::is<lower::Do::DoLetElse>(d)) {
        auto&& p_ = prism_rtl::as<lower::Do::DoLetElse>(d).a0;
        return unbind(cp, pat_names(p_));
    }
    if (prism_rtl::is<lower::Do::DoLet>(d) && prism_rtl::is<lower::Pa::PaTuple>(prism_rtl::as<lower::Do::DoLet>(d).a0)) {
        auto&& ps = prism_rtl::as<lower::Pa::PaTuple>(prism_rtl::as<lower::Do::DoLet>(d).a0).a0;
        return unbind(cp, pat_names(lower::Pa(lower::Pa::PaTuple{ps})));
    }
    if (prism_rtl::is<lower::Do::DoLet>(d) && prism_rtl::is<lower::Pa::PaCtor>(prism_rtl::as<lower::Do::DoLet>(d).a0)) {
        auto&& c = prism_rtl::as<lower::Pa::PaCtor>(prism_rtl::as<lower::Do::DoLet>(d).a0).a0;
        auto&& ps = prism_rtl::as<lower::Pa::PaCtor>(prism_rtl::as<lower::Do::DoLet>(d).a0).a1;
        return unbind(cp, pat_names(lower::Pa(lower::Pa::PaCtor{c, ps})));
    }
    if (prism_rtl::is<lower::Do::DoLet>(d) && prism_rtl::is<lower::Pa::PaRecord>(prism_rtl::as<lower::Do::DoLet>(d).a0)) {
        auto&& c = prism_rtl::as<lower::Pa::PaRecord>(prism_rtl::as<lower::Do::DoLet>(d).a0).a0;
        auto&& fs = prism_rtl::as<lower::Pa::PaRecord>(prism_rtl::as<lower::Do::DoLet>(d).a0).a1;
        auto&& r = prism_rtl::as<lower::Pa::PaRecord>(prism_rtl::as<lower::Do::DoLet>(d).a0).a2;
        return unbind(cp, pat_names(lower::Pa(lower::Pa::PaRecord{c, fs, r})));
    }
    if (prism_rtl::is<lower::Do::DoLet>(d)) {
        auto&& p_ = prism_rtl::as<lower::Do::DoLet>(d).a0;
        auto&& x = prism_rtl::as<lower::Do::DoLet>(d).a1;
        auto&& _m = let_name(p_);
        if (prism_rtl::is_some(_m)) {
            auto&& n = prism_rtl::some_of(_m);
            auto pointing_ = is_pointer_let(cp, p_, x) ? pointing(cp, n) : known_value(cp, p_, n);
            return cpp_mentions(cpp_expr(cp, x), var_name(cp, n))
                ? ({
                auto fresh = prism_rtl::cat(var_name(cp, n), "_", inc(len(keys(cp.renames))));
                ({
                Cp this_ = pointing_;
                this_.renames = insert(this_.renames, n, fresh);
                this_;
            });
            })
                : pointing_;
        }
        if (prism_rtl::is_none(_m)) {
            return cp;
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        return cp;
    }
}

}  // namespace crate::emit_cpp
