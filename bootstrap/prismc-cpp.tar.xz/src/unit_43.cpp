// The module `Lower.Expr`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <lower/expr/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <lower/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Lower.Expr`, from `target/bootstrap/cpp-src/prismc/lower/expr.prism`.
namespace crate::lower::expr {

/// Escape: fn Text -> Text
Text escape_f(const Text& t_p0) {
    return crate::syntax::lexer::chars::map_chars_f(t_p0, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Text)>>(prism_rtl::rc([=](Text p0) {
        return crate::prelude::once_job([=]() {
            return ({
                auto c_p1 = p0;
                (prism_rtl::finished(char_escape_f(c_p1)));
            });
        });
    })));
}


/// CharEscape: fn Text -> Text
Text char_escape_f(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("\\")) {
            return Text::lit("\\\\");
        }
    }
    {
        auto&& c1_0 = text0;
        if (c1_0 == Text::lit("\"")) {
            return Text::lit("\\\"");
        }
    }
    {
        auto&& c2_0 = text0;
        if (c2_0 == Text::lit("\n")) {
            return Text::lit("\\n");
        }
    }
    {
        auto&& c3_0 = text0;
        if (c3_0 == Text::lit("\t")) {
            return Text::lit("\\t");
        }
    }
    {
        auto&& c4_0 = text0;
        if (c4_0 == Text::lit("\r")) {
            return Text::lit("\\r");
        }
    }
    {
        auto&& c5_0 = text0;
        if (c5_0 == Text::lit("\000"sv)) {
            return Text::lit("\\0");
        }
    }
    {
        auto&& c6_0 = text0;
        if (c6_0 == Text::lit("\'")) {
            return Text::lit("\\\'");
        }
    }
    {
        auto&& c_p0 = text0;
        return c_p0;
    }
}


/// Number: fn OutTy, Text, Bool -> Ex
crate::lower::model::Ex number_f(const crate::lower::model::OutTy& t_p0, const Text& digits_p1, const bool& neg_p2) {
    auto clean_p3 = decimal_digits_f(crate::prelude::concat(crate::prelude::split_on(digits_p1, Text::lit("_"))));
    auto signed_p4 = neg_p2 ? prism_rtl::cat("-", clean_p3) : clean_p3;
    if (prism_rtl::is<crate::lower::model::OutTy::OutNat>(t_p0)) {
        return crate::lower::model::Ex(crate::lower::model::Ex::XNat{clean_p3});
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutInt>(t_p0)) {
        return crate::lower::model::Ex(crate::lower::model::Ex::XInt{signed_p4});
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutU8>(t_p0)) {
        return crate::lower::model::Ex(crate::lower::model::Ex::XByte{clean_p3});
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutFloat>(t_p0)) {
        return crate::lower::model::Ex(crate::lower::model::Ex::XFloat{crate::syntax::lexer::chars::contains_f(clean_p3, Text::lit("."))
            ? signed_p4
            : prism_rtl::cat(signed_p4, ".0")});
    }
    {
        return crate::lower::model::Ex(crate::lower::model::Ex::XInt{signed_p4});
    }
}


/// DecimalDigits: fn Text -> Text
Text decimal_digits_f(const Text& d_p0) {
    auto r_p1 = crate::syntax::lexer::chars::head_f(d_p0) == Text::lit("0")
        ? crate::syntax::lexer::chars::head_f(crate::syntax::lexer::chars::after_first_f(d_p0))
        : Text::lit("");
    auto base_p2 = r_p1 == Text::lit("x")
        ? Nat(16u)
        : r_p1 == Text::lit("o")
        ? Nat(8u)
        : r_p1 == Text::lit("b") ? Nat(2u) : Nat(10u);
    auto ds_p3 = base_p2 == Nat(10u)
        ? d_p0
        : crate::syntax::lexer::chars::after_first_f(crate::syntax::lexer::chars::after_first_f(d_p0));
    return (crate::syntax::lexer::chars::contains_f(d_p0, Text::lit(".")) || (crate::syntax::lexer::chars::head_f(d_p0) != Text::lit("0"))) || (d_p0 == Text::lit("0"))
        ? d_p0
        : prism_rtl::cat(crate::syntax::lexer::chars::fold_chars_f(ds_p3, Nat(0u), ({
        auto base_p2x = base_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Nat>(std::tuple<Nat, Text>)>>(prism_rtl::rc([=, base_p2x = std::move(base_p2x)](std::tuple<Nat, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto base_p2xy = base_p2x;
            (crate::prelude::once_job([=, base_p2xy = std::move(base_p2xy)]() {
            return ({
                auto n_p4 = p0;
                auto c_p5 = p1;
                (prism_rtl::finished((n_p4 * base_p2xy) + crate::syntax::lexer::chars::hex_value_f(c_p5)));
            });
        }));
        });
    })));
    })));
}


/// LiteralValue: unbounded fn Lx, Env, Literal, Range, Bool -> Vl
crate::lower::types::Vl literal_value_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Literal& l_p2, const crate::syntax::Range& span_p3, const bool& neg_p4) {
    auto t_p5 = crate::lower::types::out_ty_of_f(lx_p0, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0, span_p3)));
    auto&& _m = l_p2.kind_p;
    if (prism_rtl::is<crate::syntax::LitKind::LInt>(_m)) {
        auto&& d_p6 = prism_rtl::as<crate::syntax::LitKind::LInt>(_m).a0;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{number_f(t_p5, d_p6, neg_p4), t_p5});
    }
    if (prism_rtl::is<crate::syntax::LitKind::LFloat>(_m)) {
        auto&& d_p7 = prism_rtl::as<crate::syntax::LitKind::LFloat>(_m).a0;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XFloat{neg_p4 ? prism_rtl::cat("-", d_p7) : d_p7}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutFloat{})});
    }
    if (prism_rtl::is<crate::syntax::LitKind::LChar>(_m)) {
        auto&& c_p8 = prism_rtl::as<crate::syntax::LitKind::LChar>(_m).a0;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XChar{c_p8}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutChar{})});
    }
    if (prism_rtl::is<crate::syntax::LitKind::LDuration>(_m)) {
        auto&& d_p9 = prism_rtl::as<crate::syntax::LitKind::LDuration>(_m).a0;
        auto&& u_pa = prism_rtl::as<crate::syntax::LitKind::LDuration>(_m).a1;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(Text::lit("a Duration literal")), crate::lower::model::OutTy(crate::lower::model::OutTy::OutDuration{})});
    }
    if (prism_rtl::is<crate::syntax::LitKind::LText>(_m)) {
        auto&& segs_pb = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
        return text_value_f(lx_p0, env_p1, segs_pb);
    }
    if (prism_rtl::is<crate::syntax::LitKind::LRegex>(_m)) {
        auto&& r_pc = prism_rtl::as<crate::syntax::LitKind::LRegex>(_m).a0;
        auto&& _m = prism_rtl::deref(r_pc).replacement_o;
        if (prism_rtl::is_none(_m)) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XRegex{prism_rtl::deref(r_pc).pattern_p, prism_rtl::deref(r_pc).flags_p}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRegex{})});
        }
        if (prism_rtl::is_some(_m)) {
            auto&& t_pd = prism_rtl::some_of(_m);
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XReplacement{prism_rtl::deref(r_pc).pattern_p, t_pd, prism_rtl::deref(r_pc).flags_p}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutReplacement{})});
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::types::Vl> LiteralValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& l_p2 = this->l_p2;
    const auto& span_p3 = this->span_p3;
    const auto& neg_p4 = this->neg_p4;
    auto env_p1x = env_p1;
    auto l_p2x = l_p2;
    auto lx_p0x = lx_p0;
    auto neg_p4x = prism_rtl::deref(neg_p4);
    auto span_p3x = span_p3;
    return crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0x, span_p3x))), [=](crate::lower::model::OutTy out_ty_of_f_2743) {
        return ({
            auto t_p5 = out_ty_of_f_2743;
            ({
            auto&& _m = prism_rtl::deref(l_p2x).kind_p;
            prism_rtl::is<crate::syntax::LitKind::LInt>(_m) ? ({
            auto&& d_p6 = prism_rtl::as<crate::syntax::LitKind::LInt>(_m).a0;
            prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{number_f(t_p5, d_p6, neg_p4x), t_p5}));
        })
            : prism_rtl::is<crate::syntax::LitKind::LFloat>(_m) ? ({
            auto&& d_p7 = prism_rtl::as<crate::syntax::LitKind::LFloat>(_m).a0;
            prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XFloat{neg_p4x ? prism_rtl::cat("-", d_p7) : d_p7}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutFloat{})}));
        })
            : prism_rtl::is<crate::syntax::LitKind::LChar>(_m) ? ({
            auto&& c_p8 = prism_rtl::as<crate::syntax::LitKind::LChar>(_m).a0;
            prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XChar{c_p8}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutChar{})}));
        })
            : prism_rtl::is<crate::syntax::LitKind::LDuration>(_m) ? ({
            auto&& d_p9 = prism_rtl::as<crate::syntax::LitKind::LDuration>(_m).a0;
            auto&& u_pa = prism_rtl::as<crate::syntax::LitKind::LDuration>(_m).a1;
            prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(Text::lit("a Duration literal")), crate::lower::model::OutTy(crate::lower::model::OutTy::OutDuration{})}));
        })
            : prism_rtl::is<crate::syntax::LitKind::LText>(_m) ? ({
            auto&& segs_pb = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
            prism_rtl::more(prism_rtl::rc(TextValue(lx_p0x, env_p1x, segs_pb)));
        })
            : prism_rtl::is<crate::syntax::LitKind::LRegex>(_m) ? ({
            auto&& r_pc = prism_rtl::as<crate::syntax::LitKind::LRegex>(_m).a0;
            ({
            auto&& _m = prism_rtl::deref(r_pc).replacement_o;
            prism_rtl::is_none(_m) ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XRegex{prism_rtl::deref(r_pc).pattern_p, prism_rtl::deref(r_pc).flags_p}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRegex{})}))
            : prism_rtl::is_some(_m) ? ({
            auto&& t_pd = prism_rtl::some_of(_m);
            prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XReplacement{prism_rtl::deref(r_pc).pattern_p, t_pd, prism_rtl::deref(r_pc).flags_p}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutReplacement{})}));
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
}


/// `Start LiteralValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_literal_value_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Literal l_p2, crate::syntax::Range span_p3, bool neg_p4) {
    return prism_rtl::make_rc<LiteralValue>(lx_p0, env_p1, l_p2, span_p3, neg_p4);
}


/// TextValue: unbounded fn Lx, Env, [TextSeg] -> Vl
crate::lower::types::Vl text_value_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Array<crate::syntax::TextSeg>& segs_p2) {
    auto plain_p3 = crate::prelude::fold(segs_p2, true, [&](const bool& ok_p4, const crate::syntax::TextSeg& s_p5) { return prism_rtl::deref(ok_p4) && is_plain_seg_f(s_p5); });
    return std::move(plain_p3)
        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XText{crate::prelude::concat(crate::prelude::each(segs_p2, [&](const crate::syntax::TextSeg& s_p6) { return plain_text_f(s_p6); }))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})})
        : crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XFormat{crate::prelude::run_to_end(crate::prelude::each_job(segs_p2, ({
        auto lx_p0x = lx_p0;
        auto env_p1x = env_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::TextSeg)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), env_p1x = std::move(env_p1x)](crate::syntax::TextSeg p0) {
        return ({
            auto lx_p0xy = lx_p0x;
            auto env_p1xy = env_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), env_p1xy = std::move(env_p1xy)]() {
            return ({
                auto s_p7 = p0;
                (prism_rtl::more(prism_rtl::rc(SegEx(lx_p0xy, env_p1xy, s_p7))));
            });
        })));
        });
    })));
    })))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})});
}


prism_rtl::Turn<crate::lower::types::Vl> TextValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& segs_p2 = this->segs_p2;
    auto plain_p3 = crate::prelude::fold(segs_p2, true, [&](const bool& ok_p4, const crate::syntax::TextSeg& s_p5) { return prism_rtl::deref(ok_p4) && is_plain_seg_f(s_p5); });
    return std::move(plain_p3)
        ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XText{crate::prelude::concat(crate::prelude::each(segs_p2, [&](const crate::syntax::TextSeg& s_p6) { return plain_text_f(s_p6); }))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})}))
        : ({
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        auto segs_p2x = segs_p2;
        (crate::prelude::call_value(crate::prelude::each_job(segs_p2x, ({
        auto lx_p0xx = lx_p0x;
        auto env_p1xx = env_p1x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::TextSeg)>>(prism_rtl::rc([=, lx_p0xx = std::move(lx_p0xx), env_p1xx = std::move(env_p1xx)](crate::syntax::TextSeg p0) {
        return ({
            auto lx_p0xxy = lx_p0xx;
            auto env_p1xxy = env_p1xx;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxy = std::move(lx_p0xxy), env_p1xxy = std::move(env_p1xxy)]() {
            return ({
                auto s_p7 = p0;
                (prism_rtl::more(prism_rtl::rc(SegEx(lx_p0xxy, env_p1xxy, s_p7))));
            });
        })));
        });
    })));
    })), [=](Array<crate::lower::model::Ex> each_3675) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XFormat{each_3675}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})})); }));
    });
}


/// `Start TextValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_text_value_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Array<crate::syntax::TextSeg> segs_p2) {
    return prism_rtl::make_rc<TextValue>(lx_p0, env_p1, segs_p2);
}


/// IsPlainSeg: fn TextSeg -> Bool
bool is_plain_seg_f(const crate::syntax::TextSeg& text_seg0) {
    if (prism_rtl::is<crate::syntax::TextSeg::SegPlain>(text_seg0)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(text_seg0)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// PlainText: fn TextSeg -> Text
Text plain_text_f(const crate::syntax::TextSeg& text_seg0) {
    if (prism_rtl::is<crate::syntax::TextSeg::SegPlain>(text_seg0)) {
        auto&& t_p0 = prism_rtl::as<crate::syntax::TextSeg::SegPlain>(text_seg0).a0;
        return t_p0;
    }
    if (prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(text_seg0)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SegEx: unbounded fn Lx, Env, TextSeg -> Ex
crate::lower::model::Ex seg_ex_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::TextSeg& text_seg2) {
    if (prism_rtl::is<crate::syntax::TextSeg::SegPlain>(text_seg2)) {
        auto&& t_p2 = prism_rtl::as<crate::syntax::TextSeg::SegPlain>(text_seg2).a0;
        return crate::lower::model::Ex(crate::lower::model::Ex::XText{t_p2});
    }
    if (prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(text_seg2)) {
        auto&& e_p5 = prism_rtl::as<crate::syntax::TextSeg::SegPlaceholder>(text_seg2).a0;
        auto v_p6 = value_of_f(lx_p0, env_p1, e_p5);
        return shown_part_f(v_p6);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::model::Ex> SegEx::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& text_seg2 = this->text_seg2;
    return ({
        prism_rtl::is<crate::syntax::TextSeg::SegPlain>(text_seg2) ? ({
        auto&& t_p2 = prism_rtl::as<crate::syntax::TextSeg::SegPlain>(text_seg2).a0;
        prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XText{t_p2}));
    })
        : prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(text_seg2) ? ({
        auto&& e_p5 = prism_rtl::as<crate::syntax::TextSeg::SegPlaceholder>(text_seg2).a0;
        ({
        auto e_p5x = e_p5;
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        (crate::prelude::call_then(start_value_of_f(lx_p0x, env_p1x, e_p5x), [=](crate::lower::types::Vl value_of_f_4074) {
        return ({
            auto v_p6 = value_of_f_4074;
            (prism_rtl::finished(shown_part_f(v_p6)));
        });
    }));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SegEx, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_seg_ex_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::TextSeg text_seg2) {
    return prism_rtl::make_rc<SegEx>(lx_p0, env_p1, text_seg2);
}


/// ShownPart: fn Vl -> Ex
crate::lower::model::Ex shown_part_f(const crate::lower::types::Vl& v_p0) {
    auto&& _m = crate::lower::types::value_ty_f(v_p0);
    if (prism_rtl::is<crate::lower::model::OutTy::OutText>(_m)) {
        return crate::lower::types::ref_f(v_p0);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutChar>(_m)) {
        return crate::lower::types::ref_f(v_p0);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNat>(_m)) {
        return crate::lower::types::ref_f(v_p0);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutInt>(_m)) {
        return crate::lower::types::ref_f(v_p0);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutU8>(_m)) {
        return crate::lower::types::ref_f(v_p0);
    }
    {
        return crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(Text::lit("show")), Array(std::vector{crate::lower::types::ref_f(v_p0)})});
    }
}


/// Refusal: fn Text -> Ex
crate::lower::model::Ex refusal_f(const Text& what_p0) {
    return crate::lower::model::Ex(crate::lower::model::Ex::XRefusal{what_p0});
}


/// TryOf: fn Ex -> Ex
crate::lower::model::Ex try_of_f(const crate::lower::model::Ex& x_p0) {
    return is_named_place_f(x_p0)
        ? refusal_f(prism_rtl::cat("`?` of the place `", crate::lower::types::place_stem_f(x_p0), "`, which C++\'s TRY would move out of (only a temporary may be tried)"))
        : crate::lower::model::Ex(crate::lower::model::Ex::XTry{prism_rtl::rc(x_p0)});
}


/// IsNamedPlace: fn Ex -> Bool
bool is_named_place_f(const crate::lower::model::Ex& x_p0) {
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XPart>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTarget>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRef>(x_p0)) {
        auto&& y_p1 = prism_rtl::as<crate::lower::model::Ex::XRef>(x_p0).a0;
        return is_named_place_f(prism_rtl::deref(prism_rtl::deref(y_p1)));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XDeref>(x_p0)) {
        auto&& y_p2 = prism_rtl::as<crate::lower::model::Ex::XDeref>(x_p0).a0;
        return is_named_place_f(prism_rtl::deref(prism_rtl::deref(y_p2)));
    }
    {
        return false;
    }
}


/// let loweringRefusal
Text lowering_refusal_p() {
    return Text::lit("prismc does not lower ");
}


/// RefusalDo: fn Text -> Do
crate::lower::model::Do refusal_do_f(const Text& what_p0) {
    return crate::lower::model::Do(crate::lower::model::Do::DoExpr{refusal_f(what_p0)});
}


/// ValueOf: unbounded fn Lx, Env, Expr -> Vl
crate::lower::types::Vl value_of_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2) {
    auto&& _m = crate::prelude::get(env_p1.spans_p, crate::lower::place_key_f(lx_p0, e_p2.span_p));
    if (prism_rtl::is_some(_m)) {
        auto&& v_p3 = prism_rtl::some_of(_m);
        return v_p3;
    }
    if (prism_rtl::is_none(_m)) {
        return unbound_value_of_f(lx_p0, env_p1, e_p2);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::types::Vl> ValueOf::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& e_p2 = this->e_p2;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(env_p1).spans_p, crate::lower::place_key_f(lx_p0, prism_rtl::deref(e_p2).span_p));
        prism_rtl::is_some(_m) ? ({
        auto&& v_p3 = prism_rtl::some_of(_m);
        prism_rtl::finished(v_p3);
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(UnboundValueOf(lx_p0, env_p1, e_p2)))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ValueOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_value_of_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2) {
    return prism_rtl::make_rc<ValueOf>(lx_p0, env_p1, e_p2);
}


/// UnboundValueOf: unbounded fn Lx, Env, Expr -> Vl
crate::lower::types::Vl unbound_value_of_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2) {
    return is_event_value_f(lx_p0, env_p1, e_p2)
        ? event_value_of_f(lx_p0, env_p1, e_p2)
        : value_by_kind_f(lx_p0, env_p1, e_p2);
}


prism_rtl::Turn<crate::lower::types::Vl> UnboundValueOf::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& e_p2 = this->e_p2;
    auto e_p2x = e_p2;
    auto env_p1x = env_p1;
    auto lx_p0x = lx_p0;
    return crate::prelude::call_then(start_is_event_value_f(lx_p0x, env_p1x, e_p2x), [=](bool is_event_value_f_6185) {
        return is_event_value_f_6185
            ? prism_rtl::more(prism_rtl::rc(EventValueOf(lx_p0x, env_p1x, e_p2x)))
            : prism_rtl::more(prism_rtl::rc(ValueByKind(lx_p0x, env_p1x, e_p2x)));
    });
}


/// `Start UnboundValueOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_unbound_value_of_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2) {
    return prism_rtl::make_rc<UnboundValueOf>(lx_p0, env_p1, e_p2);
}


/// IsEventValue: unbounded fn Lx, Env, Expr -> Bool
bool is_event_value_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2) {
    auto&& _m = prism_rtl::deref(e_p2.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        return false;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        return false;
    }
    {
        return ((crate::lower::types::layer_of_f(crate::lower::type_at_f(lx_p0, e_p2.span_p)) == crate::lower::types::Layer(crate::lower::types::Layer::LyEv{})) && (!crate::prelude::fold(crate::lower::node_::dynamics::operands_f(e_p2), false, [&](const bool& bound_p3, const crate::syntax::Expr& c_p4) { return prism_rtl::deref(bound_p3) || crate::check::env::has_key_f(env_p1.spans_p, crate::lower::place_key_f(lx_p0, prism_rtl::deref(c_p4).span_p)); }))) && has_event_source_f(lx_p0, env_p1, e_p2);
    }
}


prism_rtl::Turn<bool> IsEventValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& e_p2 = this->e_p2;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p2).kind_p);
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? prism_rtl::finished(false)
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? prism_rtl::finished(false)
        : prism_rtl::finished(((crate::lower::types::layer_of_f(crate::lower::type_at_f(lx_p0, prism_rtl::deref(e_p2).span_p)) == crate::lower::types::Layer(crate::lower::types::Layer::LyEv{})) && (!crate::prelude::fold(crate::lower::node_::dynamics::operands_f(e_p2), false, [&](const bool& bound_p3, const crate::syntax::Expr& c_p4) { return prism_rtl::deref(bound_p3) || crate::check::env::has_key_f(prism_rtl::deref(env_p1).spans_p, crate::lower::place_key_f(lx_p0, prism_rtl::deref(c_p4).span_p)); }))) && has_event_source_f(lx_p0, env_p1, e_p2));
    });
}


/// `Start IsEventValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_event_value_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2) {
    return prism_rtl::make_rc<IsEventValue>(lx_p0, env_p1, e_p2);
}


/// HasEventSource: unbounded fn Lx, Env, Expr -> Bool
bool has_event_source_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(crate::lower::node_::dynamics::operands_f(e_p2), false, ({
        auto lx_p0x = lx_p0;
        auto env_p1x = env_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Expr>)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), env_p1x = std::move(env_p1x)](std::tuple<bool, crate::syntax::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0xy = lx_p0x;
            auto env_p1xy = env_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), env_p1xy = std::move(env_p1xy)]() {
            return ({
                auto found_p3 = p0;
                auto c_p4 = p1;
                (prism_rtl::finished(std::move(found_p3) || is_event_source_f(lx_p0xy, env_p1xy, c_p4)));
            });
        })));
        });
    })));
    })));
}


prism_rtl::Turn<bool> HasEventSource::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& e_p2 = this->e_p2;
    return crate::prelude::fold_job(crate::lower::node_::dynamics::operands_f(e_p2), false, ({
        auto lx_p0x = lx_p0;
        auto env_p1x = env_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Expr>)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), env_p1x = std::move(env_p1x)](std::tuple<bool, crate::syntax::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0xy = lx_p0x;
            auto env_p1xy = env_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), env_p1xy = std::move(env_p1xy)]() {
            return ({
                auto found_p3 = p0;
                auto c_p4 = p1;
                (prism_rtl::finished(std::move(found_p3) || is_event_source_f(lx_p0xy, env_p1xy, c_p4)));
            });
        })));
        });
    })));
    }))->cycle();
}


/// `Start HasEventSource, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_has_event_source_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2) {
    return prism_rtl::make_rc<HasEventSource>(lx_p0, env_p1, e_p2);
}


/// IsEventSource: unbounded fn Lx, Env, Expr -> Bool
bool is_event_source_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& c_p2) {
    return crate::lower::types::layer_of_f(crate::lower::type_at_f(lx_p0, c_p2.span_p)) != crate::lower::types::Layer(crate::lower::types::Layer::LyEv{})
        ? false
        : ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = prism_rtl::deref(c_p2.kind_p);
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n_p3 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = crate::prelude::get(env_p1.names_p, crate::check::env::sname_key_f(n_p3));
                if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)) && prism_rtl::is<crate::lower::model::OutTy::OutEvent>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2)) {
                    _v.set(true);
                    goto _done;
                }
                if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(_m))) {
                    _v.set(crate::check::env::has_key_f(env_p1.names_p, prism_rtl::cat(crate::check::env::sname_key_f(n_p3), "#port")));
                    goto _done;
                }
                {
                    _v.set(false);
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
            auto&& x_p4 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
            _v.set(is_event_source_f(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p4))));
            goto _done;
        }
        {
            _v.set(has_event_source_f(lx_p0, env_p1, c_p2));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<bool> IsEventSource::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& c_p2 = this->c_p2;
    return crate::lower::types::layer_of_f(crate::lower::type_at_f(lx_p0, prism_rtl::deref(c_p2).span_p)) != crate::lower::types::Layer(crate::lower::types::Layer::LyEv{})
        ? prism_rtl::finished(false)
        : ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(c_p2).kind_p);
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n_p3 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(env_p1).names_p, crate::check::env::sname_key_f(n_p3));
        prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)) && prism_rtl::is<crate::lower::model::OutTy::OutEvent>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2) ? prism_rtl::finished(true)
        : prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(_m)) ? prism_rtl::finished(crate::check::env::has_key_f(prism_rtl::deref(env_p1).names_p, prism_rtl::cat(crate::check::env::sname_key_f(n_p3), "#port")))
        : prism_rtl::finished(false);
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x_p4 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(IsEventSource(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p4)))));
    })
        : prism_rtl::more(prism_rtl::rc(HasEventSource(lx_p0, env_p1, c_p2)));
    });
}


/// `Start IsEventSource, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_event_source_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr c_p2) {
    return prism_rtl::make_rc<IsEventSource>(lx_p0, env_p1, c_p2);
}


/// EventValueOf: unbounded fn Lx, Env, Expr -> Vl
crate::lower::types::Vl event_value_of_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2) {
    auto t_p3 = crate::lower::types::out_ty_of_f(lx_p0, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0, e_p2.span_p)));
    auto et_p4 = crate::lower::model::OutTy(crate::lower::model::OutTy::OutEvent{prism_rtl::rc(t_p3)});
    auto filtered_o5 = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<crate::syntax::Arg>> _v;
        auto&& _m = prism_rtl::deref(e_p2.kind_p);
        if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
            auto&& c_p6 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
            auto&& args_p7 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
            _v.set(crate::lower::node_::dynamics::callee_key_f(lx_p0, prism_rtl::deref(prism_rtl::deref(c_p6))) == Text::lit("Prelude.!Filter")
                ? crate::prelude::index(args_p7, Nat(0u))
                : std::optional<crate::syntax::Arg>{});
            goto _done;
        }
        {
            _v.set(std::optional<crate::syntax::Arg>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    if (prism_rtl::is_some(filtered_o5)) {
        auto&& a_p8 = prism_rtl::some_of(filtered_o5);
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::types::own_f(value_of_f(lx_p0, env_p1, prism_rtl::deref(a_p8).value_p))), Text::lit("filter_some"), Array<crate::lower::model::Ex>{}}), et_p4});
    }
    if (prism_rtl::is_none(filtered_o5)) {
        auto evs_p9 = crate::prelude::filter(crate::lower::node_::dynamics::operands_f(e_p2), [&](const crate::syntax::Expr& x_pa) { return crate::lower::types::layer_of_f(crate::lower::type_at_f(lx_p0, prism_rtl::deref(x_pa).span_p)) == crate::lower::types::Layer(crate::lower::types::Layer::LyEv{}); });
        {
            auto&& m8252_0 = evs_p9;
            if (m8252_0.size() == 1u) {
                {
                    auto&& _c1 = crate::prelude::index(m8252_0, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& one_pb = prism_rtl::some_of(_c1);
                        auto src_pc = crate::lower::types::own_f(value_of_f(lx_p0, env_p1, one_pb));
                        auto it_pd = crate::lower::types::out_ty_of_f(lx_p0, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0, prism_rtl::deref(one_pb).span_p)));
                        auto caps_pe = crate::prelude::filter(crate::lower::types::with_instances_f(env_p1, read_names_f(crate::check::typed::print::exprs_in_f(e_p2))), [&](const Text& n_pi) {
                            return ({
                                __label__ _done;
                                prism_rtl::Slot<bool> _v;
                                auto&& _m = crate::prelude::get(env_p1.names_p, n_pi);
                                if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                                    _v.set(true);
                                    goto _done;
                                }
                                {
                                    _v.set(false);
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            });
                        });
                        auto [dos_pq, env1_pr] = crate::prelude::fold(caps_pe, std::tuple{Array<crate::lower::model::Do>{}, env_p1}, [&](const std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>& _p0, const Text& n_pl) {
                            auto&& acc_pj = std::get<0>(_p0);
                            auto&& en_pk = std::get<1>(_p0);
                            return ({
                                __label__ _done;
                                prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
                                auto&& _m = crate::prelude::get(env_p1.names_p, n_pl);
                                if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                                    auto&& rs_pm = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                                    auto&& mode_pn = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                                    auto&& ct_po = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                                    _v.set(({
                                        auto local_pp = prism_rtl::cat(crate::lower::types::place_stem_f(rs_pm), "_c");
                                        std::tuple{crate::prelude::push(acc_pj, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{local_pp}), crate::lower::types::own_f(crate::lower::types::local_place_f(rs_pm, mode_pn, ct_po))})), crate::lower::types::bind_f(en_pk, n_pl, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{local_pp}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), ct_po}))};
                                    }));
                                    goto _done;
                                }
                                {
                                    _v.set(std::tuple{acc_pj, en_pk});
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            });
                        });
                        auto env2_pf = crate::lower::types::bind_span_f(env1_pr, crate::lower::place_key_f(lx_p0, prism_rtl::deref(one_pb).span_p), crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("y_ev")}), crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), it_pd}));
                        auto body_pg = crate::lower::types::own_f(value_by_kind_f(lx_p0, env2_pf, e_p2));
                        auto mapped_ph = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(src_pc), Text::lit("map"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("y_ev")})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(it_pd)})})}), prism_rtl::rc(body_pg)})})});
                        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{crate::prelude::push(dos_pq, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("src_ev")}), src_pc})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("src_ev")})), Text::lit("map"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("y_ev")})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(it_pd)})})}), prism_rtl::rc(body_pg)})})}))}), et_p4});
                    }
                }
            }
        }
        {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(Text::lit("an event value of several events")), et_p4});
        }
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::types::Vl> EventValueOf::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& e_p2 = this->e_p2;
    auto e_p2x = e_p2;
    auto env_p1x = env_p1;
    auto lx_p0x = lx_p0;
    return crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0x, prism_rtl::deref(e_p2x).span_p))), [=](crate::lower::model::OutTy out_ty_of_f_7811) {
        return ({
            auto t_p3 = out_ty_of_f_7811;
            auto et_p4 = crate::lower::model::OutTy(crate::lower::model::OutTy::OutEvent{prism_rtl::rc(t_p3)});
            auto filtered_o5 = ({
                __label__ _done;
                prism_rtl::Slot<std::optional<crate::syntax::Arg>> _v;
                auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p2x).kind_p);
                if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
                    auto&& c_p6 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
                    auto&& args_p7 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
                    _v.set(crate::lower::node_::dynamics::callee_key_f(lx_p0x, prism_rtl::deref(prism_rtl::deref(c_p6))) == Text::lit("Prelude.!Filter")
                        ? crate::prelude::index(args_p7, Nat(0u))
                        : std::optional<crate::syntax::Arg>{});
                    goto _done;
                }
                {
                    _v.set(std::optional<crate::syntax::Arg>{});
                    goto _done;
                }
            _done:
                _v.take();
            });
            ({
            prism_rtl::is_some(filtered_o5) ? ({
            auto&& a_p8 = prism_rtl::some_of(filtered_o5);
            ({
            auto a_p8x = a_p8;
            (crate::prelude::call_then(start_value_of_f(lx_p0x, env_p1x, prism_rtl::deref(a_p8x).value_p), [=](crate::lower::types::Vl value_of_f_8088) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::types::own_f(value_of_f_8088)), Text::lit("filter_some"), Array<crate::lower::model::Ex>{}}), et_p4})); }));
        });
        })
            : prism_rtl::is_none(filtered_o5) ? ({
            auto evs_p9 = crate::prelude::filter(crate::lower::node_::dynamics::operands_f(e_p2x), [&](const crate::syntax::Expr& x_pa) { return crate::lower::types::layer_of_f(crate::lower::type_at_f(lx_p0x, prism_rtl::deref(x_pa).span_p)) == crate::lower::types::Layer(crate::lower::types::Layer::LyEv{}); });
            ({
            ({
            auto&& m8252_0 = evs_p9;
            (m8252_0.size() == 1u) && ({
            auto&& _c1 = crate::prelude::index(m8252_0, Nat(0u));
            prism_rtl::is_some(_c1);
        });
        }) ? ({
            auto&& m8252_0 = evs_p9;
            auto&& _c1 = crate::prelude::index(m8252_0, Nat(0u));
            auto&& one_pb = prism_rtl::some_of(_c1);
            crate::prelude::call_then(start_value_of_f(lx_p0x, env_p1x, one_pb), [=](crate::lower::types::Vl value_of_f_8323) {
            return ({
                auto src_pc = crate::lower::types::own_f(value_of_f_8323);
                (crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0x, prism_rtl::deref(one_pb).span_p))), [=, src_pc = std::move(src_pc)](crate::lower::model::OutTy out_ty_of_f_8374) {
                return ({
                    auto it_pd = out_ty_of_f_8374;
                    (crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(e_p2x), [=, it_pd = std::move(it_pd)](Array<crate::syntax::Expr> exprs_in_f_8485) {
                    return crate::prelude::call_then(start_read_names_f(exprs_in_f_8485), [=](Array<Text> read_names_f_8474) {
                        return ({
                            auto caps_pe = crate::prelude::filter(crate::lower::types::with_instances_f(env_p1x, read_names_f_8474), [&](const Text& n_pi) {
                                return ({
                                    __label__ _done;
                                    prism_rtl::Slot<bool> _v;
                                    auto&& _m = crate::prelude::get(prism_rtl::deref(env_p1x).names_p, n_pi);
                                    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                                        _v.set(true);
                                        goto _done;
                                    }
                                    {
                                        _v.set(false);
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                });
                            });
                            auto [dos_pq, env1_pr] = crate::prelude::fold(caps_pe, std::tuple{Array<crate::lower::model::Do>{}, env_p1x}, [&](const std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>& _p0, const Text& n_pl) {
                                auto&& acc_pj = std::get<0>(_p0);
                                auto&& en_pk = std::get<1>(_p0);
                                return ({
                                    __label__ _done;
                                    prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
                                    auto&& _m = crate::prelude::get(prism_rtl::deref(env_p1x).names_p, n_pl);
                                    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                                        auto&& rs_pm = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                                        auto&& mode_pn = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                                        auto&& ct_po = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                                        _v.set(({
                                            auto local_pp = prism_rtl::cat(crate::lower::types::place_stem_f(rs_pm), "_c");
                                            std::tuple{crate::prelude::push(acc_pj, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{local_pp}), crate::lower::types::own_f(crate::lower::types::local_place_f(rs_pm, mode_pn, ct_po))})), crate::lower::types::bind_f(en_pk, n_pl, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{local_pp}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), ct_po}))};
                                        }));
                                        goto _done;
                                    }
                                    {
                                        _v.set(std::tuple{acc_pj, en_pk});
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                });
                            });
                            auto env2_pf = crate::lower::types::bind_span_f(env1_pr, crate::lower::place_key_f(lx_p0x, prism_rtl::deref(one_pb).span_p), crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("y_ev")}), crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), it_pd}));
                            (crate::prelude::call_then(start_value_by_kind_f(lx_p0x, env2_pf, e_p2x), [=](crate::lower::types::Vl value_by_kind_f_9181) {
                            return ({
                                auto body_pg = crate::lower::types::own_f(value_by_kind_f_9181);
                                auto mapped_ph = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(src_pc), Text::lit("map"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("y_ev")})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(it_pd)})})}), prism_rtl::rc(body_pg)})})});
                                (prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{crate::prelude::push(dos_pq, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("src_ev")}), src_pc})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("src_ev")})), Text::lit("map"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("y_ev")})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(it_pd)})})}), prism_rtl::rc(body_pg)})})}))}), et_p4})));
                            });
                        }));
                        });
                    });
                }));
                });
            }));
            });
        });
        })
            : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(Text::lit("an event value of several events")), et_p4}));
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
}


/// `Start EventValueOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_event_value_of_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2) {
    return prism_rtl::make_rc<EventValueOf>(lx_p0, env_p1, e_p2);
}


/// ValueByKind: unbounded fn Lx, Env, Expr -> Vl
crate::lower::types::Vl value_by_kind_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2) {
    auto&& _m = crate::prelude::get(lx_p0.lifts_p, crate::lower::place_key_f(lx_p0, e_p2.span_p));
    if (prism_rtl::is_some(_m)) {
        auto&& ln_p3 = prism_rtl::some_of(_m);
        if (crate::prelude::len(prism_rtl::deref(ln_p3).operands_p) > Nat(0u)) {
            return lifted_value_f(lx_p0, env_p1, e_p2, ln_p3);
        }
    }
    {
        return plain_value_by_kind_f(lx_p0, env_p1, e_p2);
    }
}


prism_rtl::Turn<crate::lower::types::Vl> ValueByKind::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& e_p2 = this->e_p2;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0).lifts_p, crate::lower::place_key_f(lx_p0, prism_rtl::deref(e_p2).span_p));
        prism_rtl::is_some(_m) && ({
        auto&& ln_p3 = prism_rtl::some_of(_m);
        (crate::prelude::len(prism_rtl::deref(ln_p3).operands_p) > Nat(0u));
    }) ? ({
        auto&& ln_p3 = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(LiftedValue(lx_p0, env_p1, e_p2, ln_p3)));
    })
        : prism_rtl::more(prism_rtl::rc(PlainValueByKind(lx_p0, env_p1, e_p2)));
    });
}


/// `Start ValueByKind, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_value_by_kind_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2) {
    return prism_rtl::make_rc<ValueByKind>(lx_p0, env_p1, e_p2);
}


/// LiftedValue: unbounded fn Lx, Env, Expr, LiftNote -> Vl
crate::lower::types::Vl lifted_value_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2, const crate::check::typed::LiftNote& ln_p3) {
    auto at_p4 = crate::lower::place_key_f(lx_p0, e_p2.span_p);
    auto t_p5 = crate::lower::types::out_ty_of_f(lx_p0, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0, e_p2.span_p)));
    auto inner_p6 = crate::lower::patterns::inner_ty_f(crate::lower::type_at_f(lx_p0, e_p2.span_p));
    auto self_operand_p7 = crate::prelude::fold(ln_p3.operands_p, false, [&](const bool& f_p9, const crate::syntax::Range& r_pa) { return prism_rtl::deref(f_p9) || (r_pa == e_p2.span_p); });
    auto missing_p8 = crate::prelude::fold(ln_p3.operands_p, false, [&](const bool& f_pb, const crate::syntax::Range& r_pc) { return prism_rtl::deref(f_pb) || (operand_at_o(e_p2, r_pc) == std::optional<crate::syntax::Expr>{}); });
    return ((inner_p6 == crate::check::types::Ty(crate::check::types::Ty::TyErr{})) || std::move(self_operand_p7)) || std::move(missing_p8)
        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(prism_rtl::cat("a lift over `", ln_p3.sigil_p, "` at `", crate::lower::functions::src_text_f(lx_p0, lx_p0.file_p, e_p2.span_p), "` of ", kind_words_f(prism_rtl::deref(e_p2.kind_p)))), t_p5})
        : ({
        auto lx1_pd = ({
            crate::lower::Lx this_ = lx_p0;
            this_.tys_p = crate::prelude::insert(this_.tys_p, at_p4, inner_p6);
            this_.lifts_p = crate::prelude::insert(this_.lifts_p, at_p4, crate::check::typed::LiftNote{.at_p = ln_p3.at_p, .sigil_p = ln_p3.sigil_p, .operands_p = Array<crate::syntax::Range>{}});
            (std::move(this_));
        });
        auto lx2_pe = crate::prelude::fold(ln_p3.operands_p, lx1_pd, [&](const crate::lower::Lx& l_pf, const crate::syntax::Range& r_pg) {
            return ({
                crate::lower::Lx this_ = l_pf;
                this_.tys_p = crate::prelude::insert(this_.tys_p, crate::lower::place_key_f(lx_p0, r_pg), crate::lower::patterns::inner_ty_f(crate::lower::type_at_f(lx_p0, r_pg)));
                (std::move(this_));
            });
        });
        (crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{lift_operands_f(lx_p0, lx2_pe, env_p1, e_p2, ln_p3.sigil_p, ln_p3.operands_p, t_p5), t_p5}));
    });
}


prism_rtl::Turn<crate::lower::types::Vl> LiftedValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& e_p2 = this->e_p2;
    const auto& ln_p3 = this->ln_p3;
    auto at_p4 = crate::lower::place_key_f(lx_p0, prism_rtl::deref(e_p2).span_p);
    auto e_p2x = e_p2;
    auto env_p1x = env_p1;
    auto ln_p3x = ln_p3;
    auto lx_p0x = lx_p0;
    return crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0x, prism_rtl::deref(e_p2x).span_p))), [=](crate::lower::model::OutTy out_ty_of_f_10527) {
        return ({
            auto t_p5 = out_ty_of_f_10527;
            auto inner_p6 = crate::lower::patterns::inner_ty_f(crate::lower::type_at_f(lx_p0x, prism_rtl::deref(e_p2x).span_p));
            auto self_operand_p7 = crate::prelude::fold(prism_rtl::deref(ln_p3x).operands_p, false, [&](const bool& f_p9, const crate::syntax::Range& r_pa) { return prism_rtl::deref(f_p9) || (r_pa == prism_rtl::deref(e_p2x).span_p); });
            auto missing_p8 = crate::prelude::fold(prism_rtl::deref(ln_p3x).operands_p, false, [&](const bool& f_pb, const crate::syntax::Range& r_pc) { return prism_rtl::deref(f_pb) || (operand_at_o(e_p2x, r_pc) == std::optional<crate::syntax::Expr>{}); });
            ((inner_p6 == crate::check::types::Ty(crate::check::types::Ty::TyErr{})) || std::move(self_operand_p7)) || std::move(missing_p8)
            ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(prism_rtl::cat("a lift over `", prism_rtl::deref(ln_p3x).sigil_p, "` at `", crate::lower::functions::src_text_f(lx_p0x, prism_rtl::deref(lx_p0x).file_p, prism_rtl::deref(e_p2x).span_p), "` of ", kind_words_f(prism_rtl::deref(prism_rtl::deref(e_p2x).kind_p)))), t_p5}))
            : ({
            auto lx1_pd = ({
                crate::lower::Lx this_ = lx_p0x;
                this_.tys_p = crate::prelude::insert(this_.tys_p, at_p4, inner_p6);
                this_.lifts_p = crate::prelude::insert(this_.lifts_p, at_p4, crate::check::typed::LiftNote{.at_p = prism_rtl::deref(ln_p3x).at_p, .sigil_p = prism_rtl::deref(ln_p3x).sigil_p, .operands_p = Array<crate::syntax::Range>{}});
                (std::move(this_));
            });
            auto lx2_pe = crate::prelude::fold(prism_rtl::deref(ln_p3x).operands_p, lx1_pd, [&](const crate::lower::Lx& l_pf, const crate::syntax::Range& r_pg) {
                return ({
                    crate::lower::Lx this_ = l_pf;
                    this_.tys_p = crate::prelude::insert(this_.tys_p, crate::lower::place_key_f(lx_p0x, r_pg), crate::lower::patterns::inner_ty_f(crate::lower::type_at_f(lx_p0x, r_pg)));
                    (std::move(this_));
                });
            });
            (crate::prelude::call_then(start_lift_operands_f(lx_p0x, lx2_pe, env_p1x, e_p2x, prism_rtl::deref(ln_p3x).sigil_p, prism_rtl::deref(ln_p3x).operands_p, t_p5), [=](crate::lower::model::Ex lift_operands_f_11254) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{lift_operands_f_11254, t_p5})); }));
        });
        });
    });
}


/// `Start LiftedValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_lifted_value_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2, crate::check::typed::LiftNote ln_p3) {
    return prism_rtl::make_rc<LiftedValue>(lx_p0, env_p1, e_p2, ln_p3);
}


/// LiftOperands: unbounded fn Lx, Lx, Env, Expr, Text, [Range], OutTy -> Ex
crate::lower::model::Ex lift_operands_f(const crate::lower::Lx& lx_p0, const crate::lower::Lx& lx_in_p1, const crate::lower::types::Env& env_p2, const crate::syntax::Expr& e_p3, const Text& sigil_p4, const Array<crate::syntax::Range>& operands_p5, const crate::lower::model::OutTy& t_p6) {
    {
        auto&& m11517_0 = operands_p5;
        if (m11517_0.size() == 0u) {
            return crate::lower::model::Ex(crate::lower::model::Ex::XCtor{sigil_p4 == Text::lit("~") ? Text::lit("Ok") : Text::lit("Some"), Array(std::vector{crate::lower::types::own_f(plain_value_by_kind_f(lx_in_p1, env_p2, e_p3))})});
        }
    }
    {
        auto r_p7 = crate::prelude::or_(crate::prelude::index(operands_p5, Nat(0u)), e_p3.span_p);
        auto sv_p8 = value_of_f(lx_p0, env_p2, crate::prelude::or_(operand_at_o(e_p3, r_p7), dummy_expr_p()));
        auto it_p9 = crate::lower::types::out_ty_of_f(lx_p0, crate::lower::patterns::inner_ty_f(crate::lower::type_at_f(lx_p0, r_p7)));
        auto owned_pa = ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            if (prism_rtl::is<crate::lower::types::Vl::VlOwned>(sv_p8)) {
                _v.set(true);
                goto _done;
            }
            {
                _v.set(false);
                goto _done;
            }
        _done:
            _v.take();
        });
        auto mode_pb = std::move(owned_pa)
            ? crate::lower::types::Holding(crate::lower::types::Holding::Owned{})
            : crate::lower::types::Holding(crate::lower::types::Holding::ByRef{});
        auto x_pc = prism_rtl::cat("o", prism_rtl::deref(r_p7).start_p, "_", prism_rtl::deref(r_p7).end_p);
        auto env2_pd = crate::lower::types::bind_span_f(env_p2, crate::lower::place_key_f(lx_p0, r_p7), crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XVar{x_pc}), mode_pb, it_p9}));
        auto body_pe = lift_operands_f(lx_p0, lx_in_p1, env2_pd, e_p3, sigil_p4, crate::prelude::drop(operands_p5, Nat(1u)), t_p6);
        auto fail_arm_pf = sigil_p4 == Text::lit("~")
            ? crate::lower::model::XArm{.pat_p = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Err"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat(x_pc, "_e")})})}), .conds_p = Array<crate::lower::model::Cc>{}, .body_p = crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{crate::lower::types::own_f(crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat(x_pc, "_e")}), mode_pb, crate::lower::model::OutTy(crate::lower::model::OutTy::OutError{})}))})})}
            : crate::lower::model::XArm{.pat_p = crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{Text::lit("None")}), .conds_p = Array<crate::lower::model::Cc>{}, .body_p = crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XNone{})), t_p6})};
        auto arms_pg = Array(std::vector{crate::lower::model::XArm{.pat_p = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{sigil_p4 == Text::lit("~") ? Text::lit("Ok") : Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{x_pc})})}), .conds_p = Array<crate::lower::model::Cc>{}, .body_p = body_pe}, fail_arm_pf});
        return crate::lower::model::Ex(crate::lower::model::Ex::XMatch{prism_rtl::rc(std::move(owned_pa)
            ? crate::lower::types::own_f(sv_p8)
            : crate::lower::types::ref_f(sv_p8)), arms_pg, false, t_p6});
    }
}


prism_rtl::Turn<crate::lower::model::Ex> LiftOperands::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& lx_in_p1 = this->lx_in_p1;
    const auto& env_p2 = this->env_p2;
    const auto& e_p3 = this->e_p3;
    const auto& sigil_p4 = this->sigil_p4;
    const auto& operands_p5 = this->operands_p5;
    const auto& t_p6 = this->t_p6;
    return ({
        ({
        auto&& m11517_0 = operands_p5;
        (m11517_0.size() == 0u);
    }) ? ({
        auto&& m11517_0 = operands_p5;
        ({
        auto e_p3x = e_p3;
        auto env_p2x = env_p2;
        auto lx_in_p1x = lx_in_p1;
        auto sigil_p4x = sigil_p4;
        (crate::prelude::call_then(start_plain_value_by_kind_f(lx_in_p1x, env_p2x, e_p3x), [=, sigil_p4x = std::move(sigil_p4x)](crate::lower::types::Vl plain_value_by_kind_f_11594) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{sigil_p4x == Text::lit("~") ? Text::lit("Ok") : Text::lit("Some"), Array(std::vector{crate::lower::types::own_f(plain_value_by_kind_f_11594)})})); }));
    });
    })
        : ({
        auto r_p7 = crate::prelude::or_(crate::prelude::index(operands_p5, Nat(0u)), prism_rtl::deref(e_p3).span_p);
        auto e_p3x = e_p3;
        auto env_p2x = env_p2;
        auto lx_p0x = lx_p0;
        auto lx_in_p1x = lx_in_p1;
        auto operands_p5x = operands_p5;
        auto sigil_p4x = sigil_p4;
        auto t_p6x = t_p6;
        (crate::prelude::call_then(start_value_of_f(lx_p0x, env_p2x, crate::prelude::or_(operand_at_o(e_p3x, r_p7), dummy_expr_p())), [=, lx_in_p1x = std::move(lx_in_p1x), operands_p5x = std::move(operands_p5x), sigil_p4x = std::move(sigil_p4x), t_p6x = std::move(t_p6x)](crate::lower::types::Vl value_of_f_11698) {
        return ({
            auto sv_p8 = value_of_f_11698;
            (crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x, crate::lower::patterns::inner_ty_f(crate::lower::type_at_f(lx_p0x, r_p7))), [=, sv_p8 = std::move(sv_p8)](crate::lower::model::OutTy out_ty_of_f_11766) {
            return ({
                auto it_p9 = out_ty_of_f_11766;
                auto owned_pa = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    if (prism_rtl::is<crate::lower::types::Vl::VlOwned>(sv_p8)) {
                        _v.set(true);
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto mode_pb = std::move(owned_pa)
                    ? crate::lower::types::Holding(crate::lower::types::Holding::Owned{})
                    : crate::lower::types::Holding(crate::lower::types::Holding::ByRef{});
                auto x_pc = prism_rtl::cat("o", prism_rtl::deref(r_p7).start_p, "_", prism_rtl::deref(r_p7).end_p);
                auto env2_pd = crate::lower::types::bind_span_f(env_p2x, crate::lower::place_key_f(lx_p0x, r_p7), crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XVar{x_pc}), mode_pb, it_p9}));
                (crate::prelude::call_then(start_lift_operands_f(lx_p0x, lx_in_p1x, env2_pd, e_p3x, sigil_p4x, crate::prelude::drop(operands_p5x, Nat(1u)), t_p6x), [=, owned_pa = std::move(owned_pa), mode_pb = std::move(mode_pb), x_pc = std::move(x_pc)](crate::lower::model::Ex lift_operands_f_12086) {
                return ({
                    auto body_pe = lift_operands_f_12086;
                    auto fail_arm_pf = sigil_p4x == Text::lit("~")
                        ? crate::lower::model::XArm{.pat_p = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Err"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat(x_pc, "_e")})})}), .conds_p = Array<crate::lower::model::Cc>{}, .body_p = crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{crate::lower::types::own_f(crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat(x_pc, "_e")}), mode_pb, crate::lower::model::OutTy(crate::lower::model::OutTy::OutError{})}))})})}
                        : crate::lower::model::XArm{.pat_p = crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{Text::lit("None")}), .conds_p = Array<crate::lower::model::Cc>{}, .body_p = crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XNone{})), t_p6x})};
                    auto arms_pg = Array(std::vector{crate::lower::model::XArm{.pat_p = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{sigil_p4x == Text::lit("~") ? Text::lit("Ok") : Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{x_pc})})}), .conds_p = Array<crate::lower::model::Cc>{}, .body_p = body_pe}, fail_arm_pf});
                    (prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XMatch{prism_rtl::rc(owned_pa
                    ? crate::lower::types::own_f(sv_p8)
                    : crate::lower::types::ref_f(sv_p8)), arms_pg, false, t_p6x})));
                });
            }));
            });
        }));
        });
    }));
    });
    });
}


/// `Start LiftOperands, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_lift_operands_f(crate::lower::Lx lx_p0, crate::lower::Lx lx_in_p1, crate::lower::types::Env env_p2, crate::syntax::Expr e_p3, Text sigil_p4, Array<crate::syntax::Range> operands_p5, crate::lower::model::OutTy t_p6) {
    return prism_rtl::make_rc<LiftOperands>(lx_p0, lx_in_p1, env_p2, e_p3, sigil_p4, operands_p5, t_p6);
}


/// IsLiftedAt: fn Lx, Range -> Bool
bool is_lifted_at_f(const crate::lower::Lx& lx_p0, const crate::syntax::Range& r_p1) {
    auto&& _m = crate::prelude::get(lx_p0.lifts_p, crate::lower::place_key_f(lx_p0, r_p1));
    if (prism_rtl::is_some(_m)) {
        auto&& ln_p2 = prism_rtl::some_of(_m);
        return crate::prelude::len(prism_rtl::deref(ln_p2).operands_p) > Nat(0u);
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?OperandAt: fn Expr, Range -> ?Expr
std::optional<crate::syntax::Expr> operand_at_o(const crate::syntax::Expr& e_p0, const crate::syntax::Range& r_p1) {
    return crate::prelude::fold(direct_operands_f(e_p0), std::optional<crate::syntax::Expr>{}, [&](const std::optional<crate::syntax::Expr>& found_o2, const crate::syntax::Expr& x_p3) {
        return (found_o2 == std::optional<crate::syntax::Expr>{}) && (prism_rtl::deref(x_p3).span_p == r_p1)
            ? std::optional(x_p3)
            : found_o2;
    });
}


/// DirectOperands: fn Expr -> [Expr]
Array<crate::syntax::Expr> direct_operands_f(const crate::syntax::Expr& e_p0) {
    auto&& _m = prism_rtl::deref(e_p0.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p1 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return direct_operands_f(prism_rtl::deref(prism_rtl::deref(x_p1)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& args_p2 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        return crate::prelude::each(args_p2, [&](const crate::syntax::Arg& a_p3) { return prism_rtl::deref(a_p3).value_p; });
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m)) {
        auto&& r_p4 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
        auto&& args_p5 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
        return crate::prelude::append(Array(std::vector{prism_rtl::deref(prism_rtl::deref(r_p4))}), crate::prelude::each(args_p5, [&](const crate::syntax::Arg& a_p6) { return prism_rtl::deref(a_p6).value_p; }));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
        auto&& l_p7 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r_p8 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        return Array(std::vector{prism_rtl::deref(prism_rtl::deref(l_p7)), prism_rtl::deref(prism_rtl::deref(r_p8))});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m)) {
        auto&& x_p9 = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
        return Array(std::vector{prism_rtl::deref(prism_rtl::deref(x_p9))});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
        auto&& x_pa = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        return Array(std::vector{prism_rtl::deref(prism_rtl::deref(x_pa))});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        auto&& r_pb = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        return Array(std::vector{prism_rtl::deref(prism_rtl::deref(r_pb))});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r_pc = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& i_pd = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        return Array(std::vector{prism_rtl::deref(prism_rtl::deref(r_pc)), prism_rtl::deref(prism_rtl::deref(i_pd))});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMap>(_m)) {
        auto&& kvs_pe = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
        return crate::prelude::fold(kvs_pe, Array<crate::syntax::Expr>{}, [&](const Array<crate::syntax::Expr>& acc_pf, const std::tuple<crate::syntax::Expr, crate::syntax::Expr>& _p1) {
            auto&& k_pg = std::get<0>(_p1);
            auto&& v_ph = std::get<1>(_p1);
            return crate::prelude::append(acc_pf, Array(std::vector{k_pg, v_ph}));
        });
    }
    {
        return Array<crate::syntax::Expr>{};
    }
}


/// PlainValueByKind: unbounded fn Lx, Env, Expr -> Vl
crate::lower::types::Vl plain_value_by_kind_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2) {
    auto t_p3 = crate::lower::types::out_ty_of_f(lx_p0, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0, e_p2.span_p)));
    auto&& _m = prism_rtl::deref(e_p2.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p4 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return name_value_f(lx_p0, env_p1, n_p4, e_p2.span_p);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELit>(_m)) {
        auto&& l_p5 = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
        return literal_value_f(lx_p0, env_p1, l_p5, e_p2.span_p, false);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUnit>(_m)) {
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBound>(_m)) {
        auto&& b_p6 = prism_rtl::as<crate::syntax::ExprKind::EBound>(_m).a0;
        auto&& _m = crate::prelude::get(env_p1.names_p, b_p6);
        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
            auto&& rs_p7 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
            auto&& mode_p8 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
            auto&& bt_p9 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
            return crate::lower::types::local_place_f(rs_p7, mode_p8, bt_p9);
        }
        {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(prism_rtl::cat("`", b_p6, "` outside a `for`")), t_p3});
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ENil>(_m)) {
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XNone{})), t_p3}), t_p3});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m)) {
        auto&& es_pa = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XTuple{crate::prelude::run_to_end(crate::prelude::each_job(es_pa, ({
            auto lx_p0x = lx_p0;
            auto env_p1x = env_p1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Expr)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), env_p1x = std::move(env_p1x)](crate::syntax::Expr p0) {
            return ({
                auto lx_p0xy = lx_p0x;
                auto env_p1xy = env_p1x;
                (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), env_p1xy = std::move(env_p1xy)]() {
                return ({
                    auto x_pb = p0;
                    (crate::prelude::call_then(start_value_of_f(lx_p0xy, env_p1xy, x_pb), [=](crate::lower::types::Vl value_of_f_14028) { return prism_rtl::finished(crate::lower::types::own_f(value_of_f_14028)); }));
                });
            })));
            });
        })));
        })))}), t_p3});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EArray>(_m)) {
        auto&& m13591_6_0 = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
        if (m13591_6_0.size() == 0u) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Array::new"), Array<crate::lower::model::Ex>{}})), t_p3}), t_p3});
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EArray>(_m)) {
        auto&& es_pc = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Array::from"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVec{crate::prelude::run_to_end(crate::prelude::each_job(es_pc, ({
            auto lx_p0x = lx_p0;
            auto env_p1x = env_p1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Expr)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), env_p1x = std::move(env_p1x)](crate::syntax::Expr p0) {
            return ({
                auto lx_p0xy = lx_p0x;
                auto env_p1xy = env_p1x;
                (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), env_p1xy = std::move(env_p1xy)]() {
                return ({
                    auto x_pd = p0;
                    (crate::prelude::call_then(start_value_of_f(lx_p0xy, env_p1xy, x_pd), [=](crate::lower::types::Vl value_of_f_14200) { return prism_rtl::finished(crate::lower::types::own_f(value_of_f_14200)); }));
                });
            })));
            });
        })));
        })))})})}), t_p3});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMap>(_m)) {
        auto&& m13591_8_0 = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
        if (m13591_8_0.size() == 0u) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Map::new"), Array<crate::lower::model::Ex>{}})), t_p3}), t_p3});
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMap>(_m)) {
        auto&& kvs_pe = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(Text::lit("map_of")), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVec{crate::prelude::run_to_end(crate::prelude::each_job(kvs_pe, ({
            auto lx_p0x = lx_p0;
            auto env_p1x = env_p1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::syntax::Expr, crate::syntax::Expr>)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), env_p1x = std::move(env_p1x)](std::tuple<crate::syntax::Expr, crate::syntax::Expr> p0) {
            return ({
                auto lx_p0xy = lx_p0x;
                auto env_p1xy = env_p1x;
                (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), env_p1xy = std::move(env_p1xy)]() {
                return ({
                    auto [k_pf, v_pg] = p0;
                    (crate::prelude::call_then(start_value_of_f(lx_p0xy, env_p1xy, k_pf), [=](crate::lower::types::Vl value_of_f_14390) { return crate::prelude::call_then(start_value_of_f(lx_p0xy, env_p1xy, v_pg), [=](crate::lower::types::Vl value_of_f_14416) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XTuple{Array(std::vector{crate::lower::types::own_f(value_of_f_14390), crate::lower::types::own_f(value_of_f_14416)})})); }); }));
                });
            })));
            });
        })));
        })))})})}), t_p3});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_ph = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return value_of_f(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_ph)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c_pi = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args_pj = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        return application_f(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(c_pi)), args_pj, e_p2.span_p);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m)) {
        auto&& r_pk = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
        auto&& m_pl = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a1;
        auto&& args_pm = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
        return application_f(lx_p0, env_p1, crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{m_pl})), .span_p = prism_rtl::deref(m_pl).span_p}, crate::prelude::append(Array(std::vector{crate::syntax::Arg{.name_o = std::optional<crate::syntax::Ident>{}, .value_p = prism_rtl::deref(prism_rtl::deref(r_pk)), .span_p = prism_rtl::deref(r_pk).span_p}}), args_pm), e_p2.span_p);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
        auto&& op_pn = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& l_po = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r_pp = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        return binary_value_f(lx_p0, env_p1, op_pn, prism_rtl::deref(prism_rtl::deref(l_po)), prism_rtl::deref(prism_rtl::deref(r_pp)), e_p2.span_p);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m)) {
        auto&& m13591_14_0 = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a0;
        auto&& x_pq = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
        if (m13591_14_0 == Text::lit("not")) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{crate::lower::model::UnOp(crate::lower::model::UnOp::OpNot{}), prism_rtl::rc(crate::lower::types::as_bool_f(value_of_f(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_pq)))))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})});
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m)) {
        auto&& m13591_15_0 = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a0;
        auto&& x_pr = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
        if (m13591_15_0 == Text::lit("neg")) {
            auto&& _m = prism_rtl::deref(prism_rtl::deref(x_pr).kind_p);
            if (prism_rtl::is<crate::syntax::ExprKind::ELit>(_m)) {
                auto&& l_ps = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
                return literal_value_f(lx_p0, env_p1, l_ps, prism_rtl::deref(x_pr).span_p, true);
            }
            {
                auto v_pt = value_of_f(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_pr)));
                return crate::lower::types::is_copy_f(t_p3)
                    ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{crate::lower::model::UnOp(crate::lower::model::UnOp::OpNeg{}), prism_rtl::rc(crate::lower::types::copy_f(v_pt))}), t_p3})
                    : crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{crate::lower::model::UnOp(crate::lower::model::UnOp::OpNeg{}), prism_rtl::rc(crate::lower::types::ref_f(v_pt))}), t_p3});
            }
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m)) {
        auto&& x_pu = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
        return value_of_f(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_pu)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
        auto&& m13591_17_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        auto&& x_pv = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        if (m13591_17_0 == Text::lit("?")) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::types::own_f(value_of_f(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_pv))))})}), t_p3});
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
        auto&& m13591_18_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        auto&& x_p10 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        if (m13591_18_0 == Text::lit("~")) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Ok"), Array(std::vector{crate::lower::types::own_f(value_of_f(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p10))))})}), t_p3});
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
        auto&& m13591_19_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        auto&& x_p11 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        if (m13591_19_0 == Text::lit("@")) {
            return pure_blueprint_f(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p11)), t_p3);
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
        auto&& x_p12 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        return value_of_f(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p12)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        auto&& r_p13 = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        auto&& name_p14 = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a2;
        return field_value_f(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(r_p13)), prism_rtl::deref(name_p14).name_p);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r_p15 = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& i_p16 = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        return index_value_f(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(r_p15)), prism_rtl::deref(prism_rtl::deref(i_p16)), t_p3);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
        auto&& ps_o17 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
        auto&& body_p18 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
        return lambda_value_f(lx_p0, env_p1, e_p2, crate::prelude::or_(ps_o17, Array<crate::syntax::Pattern_>{}), prism_rtl::deref(prism_rtl::deref(body_p18)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
        auto&& c_p19 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b_p1a = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b_o1b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        return if_value_f(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(c_p19)), then_b_p1a, else_b_o1b, t_p3);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
        auto&& s_p1c = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms_p1d = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        return match_value_f(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(s_p1c)), arms_p1d, t_p3, e_p2.span_p);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETemplate>(_m)) {
        auto&& tp_p1e = prism_rtl::as<crate::syntax::ExprKind::ETemplate>(_m).a0;
        return crate::lower::templates::template_value_f(lx_p0, env_p1, tp_p1e);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECast>(_m)) {
        auto&& x_p1f = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a0;
        return value_of_f(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p1f)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m)) {
        auto&& x_p1g = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
        return value_of_f(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p1g)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGiven>(_m)) {
        auto&& b_p1h = prism_rtl::as<crate::syntax::ExprKind::EGiven>(_m).a0;
        return crate::lower::templates::given_value_f(lx_p0, env_p1, b_p1h, t_p3, e_p2.span_p);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m)) {
        auto&& target_p1i = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
        auto&& b_p1j = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
        return crate::lower::templates::update_value_f(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(target_p1i)), b_p1j, t_p3, e_p2.span_p);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EAny>(_m)) {
        auto&& x_p1k = prism_rtl::as<crate::syntax::ExprKind::EAny>(_m).a0;
        return any_value_f(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p1k)), crate::lower::type_at_f(lx_p0, e_p2.span_p));
    }
    {
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(prism_rtl::cat(kind_words_f(prism_rtl::deref(e_p2.kind_p)), " as a value")), t_p3});
    }
}


prism_rtl::Turn<crate::lower::types::Vl> PlainValueByKind::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& e_p2 = this->e_p2;
    auto e_p2x = e_p2;
    auto env_p1x = env_p1;
    auto lx_p0x = lx_p0;
    return crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0x, prism_rtl::deref(e_p2x).span_p))), [=](crate::lower::model::OutTy out_ty_of_f_13548) {
        return ({
            auto t_p3 = out_ty_of_f_13548;
            ({
            auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p2x).kind_p);
            prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
            auto&& n_p4 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            prism_rtl::more(prism_rtl::rc(NameValue(lx_p0x, env_p1x, n_p4, prism_rtl::deref(e_p2x).span_p)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::ELit>(_m) ? ({
            auto&& l_p5 = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
            prism_rtl::more(prism_rtl::rc(LiteralValue(lx_p0x, env_p1x, l_p5, prism_rtl::deref(e_p2x).span_p, false)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EUnit>(_m) ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}))
            : prism_rtl::is<crate::syntax::ExprKind::EBound>(_m) ? ({
            auto&& b_p6 = prism_rtl::as<crate::syntax::ExprKind::EBound>(_m).a0;
            ({
            auto&& _m = crate::prelude::get(prism_rtl::deref(env_p1x).names_p, b_p6);
            prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)) ? ({
            auto&& rs_p7 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
            auto&& mode_p8 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
            auto&& bt_p9 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
            prism_rtl::finished(crate::lower::types::local_place_f(rs_p7, mode_p8, bt_p9));
        })
            : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(prism_rtl::cat("`", b_p6, "` outside a `for`")), t_p3}));
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::ENil>(_m) ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XNone{})), t_p3}), t_p3}))
            : prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m) ? ({
            auto&& es_pa = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
            ({
            auto es_pax = es_pa;
            (crate::prelude::call_value(crate::prelude::each_job(es_pax, ({
            auto lx_p0xx = lx_p0x;
            auto env_p1xx = env_p1x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Expr)>>(prism_rtl::rc([=, lx_p0xx = std::move(lx_p0xx), env_p1xx = std::move(env_p1xx)](crate::syntax::Expr p0) {
            return ({
                auto lx_p0xxy = lx_p0xx;
                auto env_p1xxy = env_p1xx;
                (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxy = std::move(lx_p0xxy), env_p1xxy = std::move(env_p1xxy)]() {
                return ({
                    auto x_pb = p0;
                    (crate::prelude::call_then(start_value_of_f(lx_p0xxy, env_p1xxy, x_pb), [=](crate::lower::types::Vl value_of_f_14028) { return prism_rtl::finished(crate::lower::types::own_f(value_of_f_14028)); }));
                });
            })));
            });
        })));
        })), [=](Array<crate::lower::model::Ex> each_14009) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XTuple{each_14009}), t_p3})); }));
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EArray>(_m) && ({
            auto&& m13591_6_0 = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
            (m13591_6_0.size() == 0u);
        }) ? ({
            auto&& m13591_6_0 = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
            prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Array::new"), Array<crate::lower::model::Ex>{}})), t_p3}), t_p3}));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EArray>(_m) ? ({
            auto&& es_pc = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
            ({
            auto es_pcx = es_pc;
            (crate::prelude::call_value(crate::prelude::each_job(es_pcx, ({
            auto lx_p0xx = lx_p0x;
            auto env_p1xx = env_p1x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Expr)>>(prism_rtl::rc([=, lx_p0xx = std::move(lx_p0xx), env_p1xx = std::move(env_p1xx)](crate::syntax::Expr p0) {
            return ({
                auto lx_p0xxy = lx_p0xx;
                auto env_p1xxy = env_p1xx;
                (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxy = std::move(lx_p0xxy), env_p1xxy = std::move(env_p1xxy)]() {
                return ({
                    auto x_pd = p0;
                    (crate::prelude::call_then(start_value_of_f(lx_p0xxy, env_p1xxy, x_pd), [=](crate::lower::types::Vl value_of_f_14200) { return prism_rtl::finished(crate::lower::types::own_f(value_of_f_14200)); }));
                });
            })));
            });
        })));
        })), [=](Array<crate::lower::model::Ex> each_14181) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Array::from"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVec{each_14181})})}), t_p3})); }));
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EMap>(_m) && ({
            auto&& m13591_8_0 = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
            (m13591_8_0.size() == 0u);
        }) ? ({
            auto&& m13591_8_0 = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
            prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Map::new"), Array<crate::lower::model::Ex>{}})), t_p3}), t_p3}));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EMap>(_m) ? ({
            auto&& kvs_pe = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
            ({
            auto kvs_pex = kvs_pe;
            (crate::prelude::call_value(crate::prelude::each_job(kvs_pex, ({
            auto lx_p0xx = lx_p0x;
            auto env_p1xx = env_p1x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::syntax::Expr, crate::syntax::Expr>)>>(prism_rtl::rc([=, lx_p0xx = std::move(lx_p0xx), env_p1xx = std::move(env_p1xx)](std::tuple<crate::syntax::Expr, crate::syntax::Expr> p0) {
            return ({
                auto lx_p0xxy = lx_p0xx;
                auto env_p1xxy = env_p1xx;
                (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxy = std::move(lx_p0xxy), env_p1xxy = std::move(env_p1xxy)]() {
                return ({
                    auto [k_pf, v_pg] = p0;
                    (crate::prelude::call_then(start_value_of_f(lx_p0xxy, env_p1xxy, k_pf), [=](crate::lower::types::Vl value_of_f_14390) { return crate::prelude::call_then(start_value_of_f(lx_p0xxy, env_p1xxy, v_pg), [=](crate::lower::types::Vl value_of_f_14416) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XTuple{Array(std::vector{crate::lower::types::own_f(value_of_f_14390), crate::lower::types::own_f(value_of_f_14416)})})); }); }));
                });
            })));
            });
        })));
        })), [=](Array<crate::lower::model::Ex> each_14354) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(Text::lit("map_of")), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVec{each_14354})})}), t_p3})); }));
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
            auto&& x_ph = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
            prism_rtl::more(prism_rtl::rc(ValueOf(lx_p0x, env_p1x, prism_rtl::deref(prism_rtl::deref(x_ph)))));
        })
            : prism_rtl::is<crate::syntax::ExprKind::ECall>(_m) ? ({
            auto&& c_pi = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
            auto&& args_pj = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
            prism_rtl::more(prism_rtl::rc(Application(lx_p0x, env_p1x, prism_rtl::deref(prism_rtl::deref(c_pi)), args_pj, prism_rtl::deref(e_p2x).span_p)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m) ? ({
            auto&& r_pk = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
            auto&& m_pl = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a1;
            auto&& args_pm = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
            prism_rtl::more(prism_rtl::rc(Application(lx_p0x, env_p1x, crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{m_pl})), .span_p = prism_rtl::deref(m_pl).span_p}, crate::prelude::append(Array(std::vector{crate::syntax::Arg{.name_o = std::optional<crate::syntax::Ident>{}, .value_p = prism_rtl::deref(prism_rtl::deref(r_pk)), .span_p = prism_rtl::deref(r_pk).span_p}}), args_pm), prism_rtl::deref(e_p2x).span_p)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m) ? ({
            auto&& op_pn = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
            auto&& l_po = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
            auto&& r_pp = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
            prism_rtl::more(prism_rtl::rc(BinaryValue(lx_p0x, env_p1x, op_pn, prism_rtl::deref(prism_rtl::deref(l_po)), prism_rtl::deref(prism_rtl::deref(r_pp)), prism_rtl::deref(e_p2x).span_p)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m) && ({
            auto&& m13591_14_0 = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a0;
            auto&& x_pq = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
            (m13591_14_0 == Text::lit("not"));
        }) ? ({
            auto&& m13591_14_0 = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a0;
            auto&& x_pq = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
            ({
            auto x_pqx = prism_rtl::deref(prism_rtl::deref(x_pq));
            (crate::prelude::call_then(start_value_of_f(lx_p0x, env_p1x, x_pqx), [=](crate::lower::types::Vl value_of_f_14828) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{crate::lower::model::UnOp(crate::lower::model::UnOp::OpNot{}), prism_rtl::rc(crate::lower::types::as_bool_f(value_of_f_14828))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})})); }));
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m) && ({
            auto&& m13591_15_0 = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a0;
            auto&& x_pr = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
            (m13591_15_0 == Text::lit("neg"));
        }) ? ({
            auto&& m13591_15_0 = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a0;
            auto&& x_pr = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
            ({
            auto&& _m = prism_rtl::deref(prism_rtl::deref(x_pr).kind_p);
            prism_rtl::is<crate::syntax::ExprKind::ELit>(_m) ? ({
            auto&& l_ps = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
            prism_rtl::more(prism_rtl::rc(LiteralValue(lx_p0x, env_p1x, l_ps, prism_rtl::deref(x_pr).span_p, true)));
        })
            : ({
            auto x_prx = prism_rtl::deref(prism_rtl::deref(x_pr));
            (crate::prelude::call_then(start_value_of_f(lx_p0x, env_p1x, x_prx), [=](crate::lower::types::Vl value_of_f_15003) {
            return ({
                auto v_pt = value_of_f_15003;
                (crate::lower::types::is_copy_f(t_p3)
                ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{crate::lower::model::UnOp(crate::lower::model::UnOp::OpNeg{}), prism_rtl::rc(crate::lower::types::copy_f(v_pt))}), t_p3}))
                : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{crate::lower::model::UnOp(crate::lower::model::UnOp::OpNeg{}), prism_rtl::rc(crate::lower::types::ref_f(v_pt))}), t_p3})));
            });
        }));
        });
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m) ? ({
            auto&& x_pu = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
            prism_rtl::more(prism_rtl::rc(ValueOf(lx_p0x, env_p1x, prism_rtl::deref(prism_rtl::deref(x_pu)))));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m) && ({
            auto&& m13591_17_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
            auto&& x_pv = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
            (m13591_17_0 == Text::lit("?"));
        }) ? ({
            auto&& m13591_17_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
            auto&& x_pv = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
            ({
            auto x_pvx = prism_rtl::deref(prism_rtl::deref(x_pv));
            (crate::prelude::call_then(start_value_of_f(lx_p0x, env_p1x, x_pvx), [=](crate::lower::types::Vl value_of_f_15230) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::types::own_f(value_of_f_15230)})}), t_p3})); }));
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m) && ({
            auto&& m13591_18_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
            auto&& x_p10 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
            (m13591_18_0 == Text::lit("~"));
        }) ? ({
            auto&& m13591_18_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
            auto&& x_p10 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
            ({
            auto x_p10x = prism_rtl::deref(prism_rtl::deref(x_p10));
            (crate::prelude::call_then(start_value_of_f(lx_p0x, env_p1x, x_p10x), [=](crate::lower::types::Vl value_of_f_15311) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Ok"), Array(std::vector{crate::lower::types::own_f(value_of_f_15311)})}), t_p3})); }));
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m) && ({
            auto&& m13591_19_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
            auto&& x_p11 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
            (m13591_19_0 == Text::lit("@"));
        }) ? ({
            auto&& m13591_19_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
            auto&& x_p11 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
            prism_rtl::more(prism_rtl::rc(PureBlueprint(lx_p0x, env_p1x, prism_rtl::deref(prism_rtl::deref(x_p11)), t_p3)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m) ? ({
            auto&& x_p12 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
            prism_rtl::more(prism_rtl::rc(ValueOf(lx_p0x, env_p1x, prism_rtl::deref(prism_rtl::deref(x_p12)))));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EField>(_m) ? ({
            auto&& r_p13 = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
            auto&& name_p14 = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a2;
            prism_rtl::more(prism_rtl::rc(FieldValue(lx_p0x, env_p1x, prism_rtl::deref(prism_rtl::deref(r_p13)), prism_rtl::deref(name_p14).name_p)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m) ? ({
            auto&& r_p15 = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
            auto&& i_p16 = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
            prism_rtl::more(prism_rtl::rc(IndexValue(lx_p0x, env_p1x, prism_rtl::deref(prism_rtl::deref(r_p15)), prism_rtl::deref(prism_rtl::deref(i_p16)), t_p3)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) ? ({
            auto&& ps_o17 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
            auto&& body_p18 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
            prism_rtl::more(prism_rtl::rc(LambdaValue(lx_p0x, env_p1x, e_p2x, crate::prelude::or_(ps_o17, Array<crate::syntax::Pattern_>{}), prism_rtl::deref(prism_rtl::deref(body_p18)))));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
            auto&& c_p19 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
            auto&& then_b_p1a = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
            auto&& else_b_o1b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
            prism_rtl::more(prism_rtl::rc(IfValue(lx_p0x, env_p1x, prism_rtl::deref(prism_rtl::deref(c_p19)), then_b_p1a, else_b_o1b, t_p3)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
            auto&& s_p1c = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
            auto&& arms_p1d = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
            prism_rtl::more(prism_rtl::rc(MatchValue(lx_p0x, env_p1x, prism_rtl::deref(prism_rtl::deref(s_p1c)), arms_p1d, t_p3, prism_rtl::deref(e_p2x).span_p)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::ETemplate>(_m) ? ({
            auto&& tp_p1e = prism_rtl::as<crate::syntax::ExprKind::ETemplate>(_m).a0;
            prism_rtl::more(prism_rtl::rc(crate::lower::templates::TemplateValue(lx_p0x, env_p1x, tp_p1e)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::ECast>(_m) ? ({
            auto&& x_p1f = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a0;
            prism_rtl::more(prism_rtl::rc(ValueOf(lx_p0x, env_p1x, prism_rtl::deref(prism_rtl::deref(x_p1f)))));
        })
            : prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m) ? ({
            auto&& x_p1g = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
            prism_rtl::more(prism_rtl::rc(ValueOf(lx_p0x, env_p1x, prism_rtl::deref(prism_rtl::deref(x_p1g)))));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EGiven>(_m) ? ({
            auto&& b_p1h = prism_rtl::as<crate::syntax::ExprKind::EGiven>(_m).a0;
            prism_rtl::more(prism_rtl::rc(crate::lower::templates::GivenValue(lx_p0x, env_p1x, b_p1h, t_p3, prism_rtl::deref(e_p2x).span_p)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m) ? ({
            auto&& target_p1i = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
            auto&& b_p1j = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
            prism_rtl::more(prism_rtl::rc(crate::lower::templates::UpdateValue(lx_p0x, env_p1x, prism_rtl::deref(prism_rtl::deref(target_p1i)), b_p1j, t_p3, prism_rtl::deref(e_p2x).span_p)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EAny>(_m) ? ({
            auto&& x_p1k = prism_rtl::as<crate::syntax::ExprKind::EAny>(_m).a0;
            prism_rtl::more(prism_rtl::rc(AnyValue(lx_p0x, env_p1x, prism_rtl::deref(prism_rtl::deref(x_p1k)), crate::lower::type_at_f(lx_p0x, prism_rtl::deref(e_p2x).span_p))));
        })
            : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(prism_rtl::cat(kind_words_f(prism_rtl::deref(prism_rtl::deref(e_p2x).kind_p)), " as a value")), t_p3}));
        });
        });
    });
}


/// `Start PlainValueByKind, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_plain_value_by_kind_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2) {
    return prism_rtl::make_rc<PlainValueByKind>(lx_p0, env_p1, e_p2);
}


/// AnyValue: unbounded fn Lx, Env, Expr, Ty -> Vl
crate::lower::types::Vl any_value_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& x_p2, const crate::check::types::Ty& t_p3) {
    auto v_p4 = crate::lower::types::own_f(value_of_f(lx_p0, env_p1, x_p2));
    auto&& _m = crate::lower::types::peel_f(t_p3);
    if (prism_rtl::is<crate::check::types::Ty::TyAny>(_m)) {
        auto&& bounds_p5 = prism_rtl::as<crate::check::types::Ty::TyAny>(_m).a0;
        return crate::lower::types::is_show_only_f(bounds_p5)
            ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{v_p4})}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutShowAny{})})
            : ({
            auto names_p6 = crate::prelude::each(bounds_p5, [&](const Text& b_p8) { return crate::check::types::bare_name_f(b_p8); });
            auto others_p7 = crate::prelude::filter(names_p6, [&](const Text& b_p9) { return !crate::check::types::has_text_f(Array(std::vector{Text::lit("Show"), Text::lit("Eq"), Text::lit("Ord")}), b_p9); });
            (crate::prelude::len(others_p7) > Nat(0u)
            ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(prism_rtl::cat("an existential of `^", crate::prelude::or_(crate::prelude::index(others_p7, Nat(0u)), Text::lit("")), "`: a packed value takes `^Eq`, `^Ord` and `^Show`")), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("prism_rtl::Packed"), Array<crate::lower::model::OutTy>{}})})
            : ({
            auto packing_pa = crate::prelude::fold(names_p6, crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::Packed::of"), Array(std::vector{v_p4})}), [&](const crate::lower::model::Ex& acc_pb, const Text& b_pc) { return crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(acc_pb), prism_rtl::cat("with_", crate::prelude::lower(b_pc)), Array<crate::lower::model::Ex>{}}); });
            (crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(packing_pa), Text::lit("packed"), Array<crate::lower::model::Ex>{}}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("prism_rtl::Packed"), Array<crate::lower::model::OutTy>{}})}));
        }));
        });
    }
    {
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{v_p4})}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutShowAny{})});
    }
}


prism_rtl::Turn<crate::lower::types::Vl> AnyValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& x_p2 = this->x_p2;
    const auto& t_p3 = this->t_p3;
    auto env_p1x = env_p1;
    auto lx_p0x = lx_p0;
    auto t_p3x = t_p3;
    auto x_p2x = x_p2;
    return crate::prelude::call_then(start_value_of_f(lx_p0x, env_p1x, x_p2x), [=](crate::lower::types::Vl value_of_f_16527) {
        return ({
            auto v_p4 = crate::lower::types::own_f(value_of_f_16527);
            ({
            auto&& _m = crate::lower::types::peel_f(t_p3x);
            prism_rtl::is<crate::check::types::Ty::TyAny>(_m) ? ({
            auto&& bounds_p5 = prism_rtl::as<crate::check::types::Ty::TyAny>(_m).a0;
            crate::lower::types::is_show_only_f(bounds_p5)
            ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{v_p4})}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutShowAny{})}))
            : ({
            auto names_p6 = crate::prelude::each(bounds_p5, [&](const Text& b_p8) { return crate::check::types::bare_name_f(b_p8); });
            auto others_p7 = crate::prelude::filter(names_p6, [&](const Text& b_p9) { return !crate::check::types::has_text_f(Array(std::vector{Text::lit("Show"), Text::lit("Eq"), Text::lit("Ord")}), b_p9); });
            (crate::prelude::len(others_p7) > Nat(0u)
            ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(prism_rtl::cat("an existential of `^", crate::prelude::or_(crate::prelude::index(others_p7, Nat(0u)), Text::lit("")), "`: a packed value takes `^Eq`, `^Ord` and `^Show`")), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("prism_rtl::Packed"), Array<crate::lower::model::OutTy>{}})}))
            : ({
            auto packing_pa = crate::prelude::fold(names_p6, crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::Packed::of"), Array(std::vector{v_p4})}), [&](const crate::lower::model::Ex& acc_pb, const Text& b_pc) { return crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(acc_pb), prism_rtl::cat("with_", crate::prelude::lower(b_pc)), Array<crate::lower::model::Ex>{}}); });
            (prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(packing_pa), Text::lit("packed"), Array<crate::lower::model::Ex>{}}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("prism_rtl::Packed"), Array<crate::lower::model::OutTy>{}})})));
        }));
        });
        })
            : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{v_p4})}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutShowAny{})}));
        });
        });
    });
}


/// `Start AnyValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_any_value_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr x_p2, crate::check::types::Ty t_p3) {
    return prism_rtl::make_rc<AnyValue>(lx_p0, env_p1, x_p2, t_p3);
}


/// PureBlueprint: unbounded fn Lx, Env, Expr, OutTy -> Vl
crate::lower::types::Vl pure_blueprint_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& x_p2, const crate::lower::model::OutTy& t_p3) {
    auto is_never_p4 = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = prism_rtl::deref(x_p2.kind_p);
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n_p5 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            _v.set(({
                auto&& _qk_o6 = crate::check::env::names::resolve_value_f(lx_p0.g_p, lx_p0.home_p, n_p5);
                auto&& qk_o6 = std::get<0>(_qk_o6);
                qk_o6 == std::optional(Text::lit("Prelude.never"));
            }));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    return std::move(is_never_p4)
        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::never_blueprint::<crate::Elem, crate::Answer>"), Array<crate::lower::model::Ex>{}}), t_p3})
        : ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::types::Vl> _v;
        auto&& _m = crate::prelude::get(env_p1.names_p, Text::lit("#tag"));
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(prism_rtl::cat("`@ ", crate::lower::functions::src_text_f(lx_p0, lx_p0.file_p, x_p2.span_p), "` as a supplier\'s answer outside a tag arm: which tag\'s output it answers cannot be known")), t_p3}));
            goto _done;
        }
        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)) && prism_rtl::is<crate::lower::model::Ex::XPath>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0)) {
            auto&& variant_p7 = prism_rtl::as<crate::lower::model::Ex::XPath>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<crate::lower::types::Vl> _v;
                auto&& _m = crate::lower::types::layer_of_f(crate::lower::type_at_f(lx_p0, x_p2.span_p));
                if (prism_rtl::is<crate::lower::types::Layer::LyEv>(_m)) {
                    _v.set(({
                        auto wrapped_p8 = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::types::own_f(value_of_f(lx_p0, env_p1, x_p2))), Text::lit("map"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("v")})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant_p7, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}))})})}))})})});
                        (crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::event_blueprint::<crate::Elem, _>"), Array(std::vector{wrapped_p8})}), t_p3}));
                    }));
                    goto _done;
                }
                if (prism_rtl::is<crate::lower::types::Layer::LyDyn>(_m)) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<crate::lower::types::Vl> _v;
                        auto&& _m = crate::lower::node_::static_::dynamic_answer_o(lx_p0, x_p2);
                        if (prism_rtl::is_none(_m)) {
                            _v.set(({
                                __label__ _done;
                                prism_rtl::Slot<crate::lower::types::Vl> _v;
                                auto&& _m = prism_rtl::deref(x_p2.kind_p);
                                if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
                                    auto&& m18926_0_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
                                    auto&& inner_p9 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
                                    if (m18926_0_0 == Text::lit("$")) {
                                        _v.set(plain_blueprint_f(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(inner_p9)), variant_p7, t_p3));
                                        goto _done;
                                    }
                                }
                                {
                                    _v.set(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(prism_rtl::cat("`@ ", crate::lower::functions::src_text_f(lx_p0, lx_p0.file_p, x_p2.span_p), "`, a supplier\'s dynamic answer of no known form")), t_p3}));
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_some(_m)) {
                            auto&& d_pa = prism_rtl::some_of(_m);
                            _v.set(dynamic_blueprint_f(lx_p0, env_p1, x_p2, d_pa, variant_p7, t_p3));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                {
                    _v.set(plain_blueprint_f(lx_p0, env_p1, x_p2, variant_p7, t_p3));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(Text::lit("a supplier\'s answer under a tag the arm does not name")), t_p3}));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<crate::lower::types::Vl> PureBlueprint::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& x_p2 = this->x_p2;
    const auto& t_p3 = this->t_p3;
    auto is_never_p4 = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(x_p2).kind_p);
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n_p5 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            _v.set(({
                auto&& _qk_o6 = crate::check::env::names::resolve_value_f(prism_rtl::deref(lx_p0).g_p, prism_rtl::deref(lx_p0).home_p, n_p5);
                auto&& qk_o6 = std::get<0>(_qk_o6);
                qk_o6 == std::optional(Text::lit("Prelude.never"));
            }));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    return std::move(is_never_p4)
        ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::never_blueprint::<crate::Elem, crate::Answer>"), Array<crate::lower::model::Ex>{}}), t_p3}))
        : ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(env_p1).names_p, Text::lit("#tag"));
        prism_rtl::is_none(_m) ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(prism_rtl::cat("`@ ", crate::lower::functions::src_text_f(lx_p0, prism_rtl::deref(lx_p0).file_p, prism_rtl::deref(x_p2).span_p), "` as a supplier\'s answer outside a tag arm: which tag\'s output it answers cannot be known")), t_p3}))
        : prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)) && prism_rtl::is<crate::lower::model::Ex::XPath>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0) ? ({
        auto&& variant_p7 = prism_rtl::as<crate::lower::model::Ex::XPath>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0).a0;
        ({
        auto&& _m = crate::lower::types::layer_of_f(crate::lower::type_at_f(lx_p0, prism_rtl::deref(x_p2).span_p));
        prism_rtl::is<crate::lower::types::Layer::LyEv>(_m) ? ({
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        auto t_p3x = t_p3;
        auto x_p2x = x_p2;
        (crate::prelude::call_then(start_value_of_f(lx_p0x, env_p1x, x_p2x), [=, t_p3x = std::move(t_p3x)](crate::lower::types::Vl value_of_f_18655) {
        return ({
            auto wrapped_p8 = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::types::own_f(value_of_f_18655)), Text::lit("map"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("v")})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant_p7, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}))})})}))})})});
            (prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::event_blueprint::<crate::Elem, _>"), Array(std::vector{wrapped_p8})}), t_p3x})));
        });
    }));
    })
        : prism_rtl::is<crate::lower::types::Layer::LyDyn>(_m) ? ({
        auto&& _m = crate::lower::node_::static_::dynamic_answer_o(lx_p0, x_p2);
        prism_rtl::is_none(_m) ? ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(x_p2).kind_p);
        prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m) && ({
        auto&& m18926_0_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        auto&& inner_p9 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        (m18926_0_0 == Text::lit("$"));
    }) ? ({
        auto&& m18926_0_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        auto&& inner_p9 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        prism_rtl::more(prism_rtl::rc(PlainBlueprint(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(inner_p9)), variant_p7, t_p3)));
    })
        : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(prism_rtl::cat("`@ ", crate::lower::functions::src_text_f(lx_p0, prism_rtl::deref(lx_p0).file_p, prism_rtl::deref(x_p2).span_p), "`, a supplier\'s dynamic answer of no known form")), t_p3}));
    })
        : prism_rtl::is_some(_m) ? ({
        auto&& d_pa = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(DynamicBlueprint(lx_p0, env_p1, x_p2, d_pa, variant_p7, t_p3)));
    })
        : throw prism_rtl::Panic("no arm matched");
    })
        : prism_rtl::more(prism_rtl::rc(PlainBlueprint(lx_p0, env_p1, x_p2, variant_p7, t_p3)));
    });
    })
        : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(Text::lit("a supplier\'s answer under a tag the arm does not name")), t_p3}));
    });
}


/// `Start PureBlueprint, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_pure_blueprint_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr x_p2, crate::lower::model::OutTy t_p3) {
    return prism_rtl::make_rc<PureBlueprint>(lx_p0, env_p1, x_p2, t_p3);
}


/// PlainBlueprint: unbounded fn Lx, Env, Expr, Text, OutTy -> Vl
crate::lower::types::Vl plain_blueprint_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& x_p2, const Text& variant_p3, const crate::lower::model::OutTy& t_p4) {
    return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::plain_blueprint::<crate::Elem, _>"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant_p3, Array(std::vector{crate::lower::types::own_f(value_of_f(lx_p0, env_p1, x_p2))})})})}), t_p4});
}


prism_rtl::Turn<crate::lower::types::Vl> PlainBlueprint::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& x_p2 = this->x_p2;
    const auto& variant_p3 = this->variant_p3;
    const auto& t_p4 = this->t_p4;
    auto env_p1x = env_p1;
    auto lx_p0x = lx_p0;
    auto t_p4x = t_p4;
    auto variant_p3x = variant_p3;
    auto x_p2x = x_p2;
    return crate::prelude::call_then(start_value_of_f(lx_p0x, env_p1x, x_p2x), [=](crate::lower::types::Vl value_of_f_19574) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::plain_blueprint::<crate::Elem, _>"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant_p3x, Array(std::vector{crate::lower::types::own_f(value_of_f_19574)})})})}), t_p4x})); });
}


/// `Start PlainBlueprint, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_plain_blueprint_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr x_p2, Text variant_p3, crate::lower::model::OutTy t_p4) {
    return prism_rtl::make_rc<PlainBlueprint>(lx_p0, env_p1, x_p2, variant_p3, t_p4);
}


/// DynamicBlueprint: unbounded fn Lx, Env, Expr, Expr, Text, OutTy -> Vl
crate::lower::types::Vl dynamic_blueprint_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& x_p2, const crate::syntax::Expr& d_p3, const Text& variant_p4, const crate::lower::model::OutTy& t_p5) {
    auto&& _m = std::tuple{crate::prelude::get(env_p1.names_p, prism_rtl::cat("#dyn", crate::lower::node_::static_::dyn_key_f(x_p2))), crate::prelude::get(env_p1.names_p, Text::lit("#owner"))};
    if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(std::get<0>(_m))) && prism_rtl::is<crate::lower::model::Ex::XVar>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(std::get<0>(_m))).a0) && prism_rtl::is_some(std::get<1>(_m)) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(std::get<1>(_m))) && prism_rtl::is<crate::lower::model::Ex::XVar>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(std::get<1>(_m))).a0)) {
        auto&& getter_p6 = prism_rtl::as<crate::lower::model::Ex::XVar>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(std::get<0>(_m))).a0).a0;
        auto&& dt_p7 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(std::get<0>(_m))).a2;
        auto&& owner_p8 = prism_rtl::as<crate::lower::model::Ex::XVar>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(std::get<1>(_m))).a0).a0;
        auto at_build_p9 = crate::lower::types::own_f(value_of_f(lx_p0, crate::lower::node_::def::init_env_f(env_p1), d_p3));
        auto arms_pa = Array(std::vector{crate::lower::model::XArm{.pat_p = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("owner")})})}), .conds_p = Array<crate::lower::model::Cc>{}, .body_p = crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant_p4, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("owner")})), getter_p6, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})})}, crate::lower::model::XArm{.pat_p = crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{Text::lit("None")}), .conds_p = Array<crate::lower::model::Cc>{}, .body_p = crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant_p4, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("at_build")}))})})})}});
        auto read_pb = crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("cx")})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Cx"), Array<crate::lower::model::OutTy>{}}))})})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMatch{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("link")})), Text::lit("owner"), Array<crate::lower::model::Ex>{}})), arms_pa, false, crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("crate::Answer"), Array<crate::lower::model::OutTy>{}})}))});
        auto dynamic_pc = crate::lower::model::Ex(crate::lower::model::Ex::XBlock{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("link")}), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{owner_p8}))})}), crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("at_build")}), at_build_p9})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::Dynamic::of"), Array(std::vector{read_pb, crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat(getter_p6, "_portx")}))})})}))});
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::dynamic_blueprint::<crate::Elem, _>"), Array(std::vector{dynamic_pc})}), t_p5});
    }
    {
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(prism_rtl::cat("`@ ", crate::lower::functions::src_text_f(lx_p0, lx_p0.file_p, x_p2.span_p), "`, a supplier\'s dynamic answer that reads what has no value at the owner\'s build (a pushed place, a structural dynamic, or a `let` after the host\'s line)")), t_p5});
    }
}


prism_rtl::Turn<crate::lower::types::Vl> DynamicBlueprint::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& x_p2 = this->x_p2;
    const auto& d_p3 = this->d_p3;
    const auto& variant_p4 = this->variant_p4;
    const auto& t_p5 = this->t_p5;
    return ({
        auto&& _m = std::tuple{crate::prelude::get(prism_rtl::deref(env_p1).names_p, prism_rtl::cat("#dyn", crate::lower::node_::static_::dyn_key_f(x_p2))), crate::prelude::get(prism_rtl::deref(env_p1).names_p, Text::lit("#owner"))};
        prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(std::get<0>(_m))) && prism_rtl::is<crate::lower::model::Ex::XVar>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(std::get<0>(_m))).a0) && prism_rtl::is_some(std::get<1>(_m)) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(std::get<1>(_m))) && prism_rtl::is<crate::lower::model::Ex::XVar>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(std::get<1>(_m))).a0) ? ({
        auto&& getter_p6 = prism_rtl::as<crate::lower::model::Ex::XVar>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(std::get<0>(_m))).a0).a0;
        auto&& dt_p7 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(std::get<0>(_m))).a2;
        auto&& owner_p8 = prism_rtl::as<crate::lower::model::Ex::XVar>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(std::get<1>(_m))).a0).a0;
        ({
        auto d_p3x = d_p3;
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        auto t_p5x = t_p5;
        auto variant_p4x = variant_p4;
        (crate::prelude::call_then(start_value_of_f(lx_p0x, crate::lower::node_::def::init_env_f(env_p1x), d_p3x), [=, t_p5x = std::move(t_p5x), variant_p4x = std::move(variant_p4x)](crate::lower::types::Vl value_of_f_20386) {
        return ({
            auto at_build_p9 = crate::lower::types::own_f(value_of_f_20386);
            auto arms_pa = Array(std::vector{crate::lower::model::XArm{.pat_p = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("owner")})})}), .conds_p = Array<crate::lower::model::Cc>{}, .body_p = crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant_p4x, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("owner")})), getter_p6, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})})}, crate::lower::model::XArm{.pat_p = crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{Text::lit("None")}), .conds_p = Array<crate::lower::model::Cc>{}, .body_p = crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant_p4x, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("at_build")}))})})})}});
            auto read_pb = crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("cx")})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Cx"), Array<crate::lower::model::OutTy>{}}))})})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMatch{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("link")})), Text::lit("owner"), Array<crate::lower::model::Ex>{}})), arms_pa, false, crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("crate::Answer"), Array<crate::lower::model::OutTy>{}})}))});
            auto dynamic_pc = crate::lower::model::Ex(crate::lower::model::Ex::XBlock{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("link")}), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{owner_p8}))})}), crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("at_build")}), at_build_p9})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::Dynamic::of"), Array(std::vector{read_pb, crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat(getter_p6, "_portx")}))})})}))});
            (prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::dynamic_blueprint::<crate::Elem, _>"), Array(std::vector{dynamic_pc})}), t_p5x})));
        });
    }));
    });
    })
        : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(prism_rtl::cat("`@ ", crate::lower::functions::src_text_f(lx_p0, prism_rtl::deref(lx_p0).file_p, prism_rtl::deref(x_p2).span_p), "`, a supplier\'s dynamic answer that reads what has no value at the owner\'s build (a pushed place, a structural dynamic, or a `let` after the host\'s line)")), t_p5}));
    });
}


/// `Start DynamicBlueprint, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_dynamic_blueprint_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr x_p2, crate::syntax::Expr d_p3, Text variant_p4, crate::lower::model::OutTy t_p5) {
    return prism_rtl::make_rc<DynamicBlueprint>(lx_p0, env_p1, x_p2, d_p3, variant_p4, t_p5);
}


/// ElementBlueprint: unbounded fn Lx, Env, [Arg], OutTy -> Vl
crate::lower::types::Vl element_blueprint_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Array<crate::syntax::Arg>& args_p2, const crate::lower::model::OutTy& t_p3) {
    auto&& _m = crate::prelude::index(args_p2, Nat(0u));
    if (prism_rtl::is_some(_m)) {
        auto&& a_p4 = prism_rtl::some_of(_m);
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::element_blueprint::<crate::Elem, crate::Answer>"), Array(std::vector{crate::lower::types::ref_f(value_of_f(lx_p0, env_p1, prism_rtl::deref(a_p4).value_p))})}), t_p3});
    }
    if (prism_rtl::is_none(_m)) {
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(Text::lit("`@Element` without its element")), t_p3});
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::types::Vl> ElementBlueprint::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& args_p2 = this->args_p2;
    const auto& t_p3 = this->t_p3;
    return ({
        auto&& _m = crate::prelude::index(args_p2, Nat(0u));
        prism_rtl::is_some(_m) ? ({
        auto&& a_p4 = prism_rtl::some_of(_m);
        ({
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        auto t_p3x = t_p3;
        (crate::prelude::call_then(start_value_of_f(lx_p0x, env_p1x, prism_rtl::deref(a_p4).value_p), [=, t_p3x = std::move(t_p3x)](crate::lower::types::Vl value_of_f_21670) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::element_blueprint::<crate::Elem, crate::Answer>"), Array(std::vector{crate::lower::types::ref_f(value_of_f_21670)})}), t_p3x})); }));
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(Text::lit("`@Element` without its element")), t_p3}))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ElementBlueprint, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_element_blueprint_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Array<crate::syntax::Arg> args_p2, crate::lower::model::OutTy t_p3) {
    return prism_rtl::make_rc<ElementBlueprint>(lx_p0, env_p1, args_p2, t_p3);
}


/// KindWords: fn ExprKind -> Text
Text kind_words_f(const crate::syntax::ExprKind& k_p0) {
    if (prism_rtl::is<crate::syntax::ExprKind::ESuffixed>(k_p0)) {
        auto&& op_p1 = prism_rtl::as<crate::syntax::ExprKind::ESuffixed>(k_p0).a0;
        return prism_rtl::cat("a suffixed `", op_p1, "`");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(k_p0)) {
        auto&& sg_p2 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(k_p0).a0;
        return prism_rtl::cat("a free `", sg_p2, "`");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETopicField>(k_p0)) {
        return Text::lit("a topic field (`&_.f` outside an `update`)");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETopicIndex>(k_p0)) {
        return Text::lit("a topic index");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ENonEmpty>(k_p0)) {
        return Text::lit("a non-empty literal");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EAbsent>(k_p0)) {
        return Text::lit("an absent value");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ERest>(k_p0)) {
        return Text::lit("a `..` rest");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(k_p0)) {
        return Text::lit("a lambda");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ERebuild>(k_p0)) {
        return Text::lit("a `rebuild` outside a widget block");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFor>(k_p0)) {
        return Text::lit("a `for` outside a widget block");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(k_p0)) {
        return Text::lit("a widget block");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMonad>(k_p0)) {
        return Text::lit("a monadic block");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELens>(k_p0)) {
        return Text::lit("a lens");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EError>(k_p0)) {
        return Text::lit("an expression the parser could not read");
    }
    {
        return Text::lit("an expression");
    }
}


/// NameValue: unbounded fn Lx, Env, SName, Range -> Vl
crate::lower::types::Vl name_value_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::SName& n_p2, const crate::syntax::Range& span_p3) {
    auto nkey_p4 = crate::lower::types::name_key_at_f(lx_p0, env_p1, n_p2, span_p3);
    auto t_p5 = crate::lower::types::out_ty_of_f(lx_p0, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0, span_p3)));
    auto local_o6 = crate::prelude::len(n_p2.path_p) == Nat(1u)
        ? crate::prelude::get(env_p1.names_p, nkey_p4)
        : std::optional<crate::lower::types::Bn>{};
    if (prism_rtl::is_some(local_o6) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(local_o6))) {
        auto&& rs_p7 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(local_o6)).a0;
        auto&& mode_p8 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(local_o6)).a1;
        auto&& lt_p9 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(local_o6)).a2;
        return crate::lower::types::local_place_f(rs_p7, mode_p8, lt_p9);
    }
    if (prism_rtl::is_some(local_o6) && prism_rtl::is<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(local_o6))) {
        auto&& f_pa = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(local_o6)).a0;
        auto&& ht_pb = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(local_o6)).a1;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f_pa)})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), ht_pb});
    }
    if (prism_rtl::is_some(local_o6) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(local_o6))) {
        auto&& x_pc = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(local_o6)).a0;
        auto&& dt_pd = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(local_o6)).a2;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{x_pc, dt_pd});
    }
    if (prism_rtl::is_some(local_o6) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(local_o6))) {
        auto&& et_pe = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(local_o6)).a1;
        auto&& _m = crate::prelude::get(env_p1.names_p, prism_rtl::cat(nkey_p4, "#port"));
        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
            auto&& pf_pf = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::Event::of"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(pf_pf)})})}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutEvent{prism_rtl::rc(crate::lower::types::out_ty_of_f(lx_p0, crate::lower::types::peel_f(crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0, span_p3)))))})});
        }
        {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(Text::lit("an event read as a value")), et_pe});
        }
    }
    if (prism_rtl::is_some(local_o6) && prism_rtl::is<crate::lower::types::Bn::BnParts>(prism_rtl::some_of(local_o6))) {
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(Text::lit("a tuple pattern\'s binding as a value")), t_p5});
    }
    if (prism_rtl::is_some(local_o6) && prism_rtl::is<crate::lower::types::Bn::BnWidget>(prism_rtl::some_of(local_o6))) {
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(Text::lit("a widget parameter read as a plain value")), t_p5});
    }
    if (prism_rtl::is_some(local_o6) && prism_rtl::is<crate::lower::types::Bn::BnLocalFn>(prism_rtl::some_of(local_o6))) {
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(Text::lit("a local function as a value")), t_p5});
    }
    if (prism_rtl::is_none(local_o6)) {
        auto [qk_og, why_ph] = crate::check::env::names::resolve_value_f(lx_p0.g_p, lx_p0.home_p, n_p2);
        if (prism_rtl::is_some(qk_og)) {
            auto&& m23746_0 = prism_rtl::some_of(qk_og);
            if (m23746_0 == Text::lit("True")) {
                return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBool{true}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})});
            }
        }
        if (prism_rtl::is_some(qk_og)) {
            auto&& m23746_1 = prism_rtl::some_of(qk_og);
            if (m23746_1 == Text::lit("False")) {
                return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBool{false}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})});
            }
        }
        if (prism_rtl::is_some(qk_og)) {
            auto&& m23746_2 = prism_rtl::some_of(qk_og);
            if (m23746_2 == Text::lit("Prelude.never")) {
                return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Event::never"), Array<crate::lower::model::Ex>{}}), t_p5});
            }
        }
        if (prism_rtl::is_some(qk_og)) {
            auto&& qk_pi = prism_rtl::some_of(qk_og);
            auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g_p).tags_p, qk_pi);
            if (prism_rtl::is_some(_m)) {
                auto&& tg_pj = prism_rtl::some_of(_m);
                if ((prism_rtl::deref(tg_pj).kind_p != Text::lit("Prelude.Fault")) && (why_ph == Text::lit("tag"))) {
                    return tag_value_f(lx_p0, env_p1, tg_pj, Array<crate::syntax::Arg>{});
                }
            }
            {
                return global_value_f(lx_p0, qk_pi, span_p3, t_p5);
            }
        }
        if (prism_rtl::is_none(qk_og)) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(prism_rtl::cat("the name ", nkey_p4, ", which nothing declares")), t_p5});
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::types::Vl> NameValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& n_p2 = this->n_p2;
    const auto& span_p3 = this->span_p3;
    auto nkey_p4 = crate::lower::types::name_key_at_f(lx_p0, env_p1, n_p2, span_p3);
    auto env_p1x = env_p1;
    auto lx_p0x = lx_p0;
    auto n_p2x = n_p2;
    auto span_p3x = span_p3;
    return crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0x, span_p3x))), [=](crate::lower::model::OutTy out_ty_of_f_22776) {
        return ({
            auto t_p5 = out_ty_of_f_22776;
            auto local_o6 = crate::prelude::len(prism_rtl::deref(n_p2x).path_p) == Nat(1u)
                ? crate::prelude::get(prism_rtl::deref(env_p1x).names_p, nkey_p4)
                : std::optional<crate::lower::types::Bn>{};
            ({
            prism_rtl::is_some(local_o6) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(local_o6)) ? ({
            auto&& rs_p7 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(local_o6)).a0;
            auto&& mode_p8 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(local_o6)).a1;
            auto&& lt_p9 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(local_o6)).a2;
            prism_rtl::finished(crate::lower::types::local_place_f(rs_p7, mode_p8, lt_p9));
        })
            : prism_rtl::is_some(local_o6) && prism_rtl::is<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(local_o6)) ? ({
            auto&& f_pa = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(local_o6)).a0;
            auto&& ht_pb = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(local_o6)).a1;
            prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f_pa)})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), ht_pb}));
        })
            : prism_rtl::is_some(local_o6) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(local_o6)) ? ({
            auto&& x_pc = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(local_o6)).a0;
            auto&& dt_pd = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(local_o6)).a2;
            prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{x_pc, dt_pd}));
        })
            : prism_rtl::is_some(local_o6) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(local_o6)) ? ({
            auto&& et_pe = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(local_o6)).a1;
            ({
            auto&& _m = crate::prelude::get(prism_rtl::deref(env_p1x).names_p, prism_rtl::cat(nkey_p4, "#port"));
            prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)) ? ({
            auto&& pf_pf = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
            crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x, crate::lower::types::peel_f(crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0x, span_p3x)))), [=](crate::lower::model::OutTy out_ty_of_f_23256) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::Event::of"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(pf_pf)})})}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutEvent{prism_rtl::rc(out_ty_of_f_23256)})})); });
        })
            : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(Text::lit("an event read as a value")), et_pe}));
        });
        })
            : prism_rtl::is_some(local_o6) && prism_rtl::is<crate::lower::types::Bn::BnParts>(prism_rtl::some_of(local_o6)) ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(Text::lit("a tuple pattern\'s binding as a value")), t_p5}))
            : prism_rtl::is_some(local_o6) && prism_rtl::is<crate::lower::types::Bn::BnWidget>(prism_rtl::some_of(local_o6)) ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(Text::lit("a widget parameter read as a plain value")), t_p5}))
            : prism_rtl::is_some(local_o6) && prism_rtl::is<crate::lower::types::Bn::BnLocalFn>(prism_rtl::some_of(local_o6)) ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(Text::lit("a local function as a value")), t_p5}))
            : prism_rtl::is_none(local_o6) ? ({
            auto [qk_og, why_ph] = crate::check::env::names::resolve_value_f(prism_rtl::deref(lx_p0x).g_p, prism_rtl::deref(lx_p0x).home_p, n_p2x);
            ({
            prism_rtl::is_some(qk_og) && ({
            auto&& m23746_0 = prism_rtl::some_of(qk_og);
            (m23746_0 == Text::lit("True"));
        }) ? ({
            auto&& m23746_0 = prism_rtl::some_of(qk_og);
            prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBool{true}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})}));
        })
            : prism_rtl::is_some(qk_og) && ({
            auto&& m23746_1 = prism_rtl::some_of(qk_og);
            (m23746_1 == Text::lit("False"));
        }) ? ({
            auto&& m23746_1 = prism_rtl::some_of(qk_og);
            prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBool{false}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})}));
        })
            : prism_rtl::is_some(qk_og) && ({
            auto&& m23746_2 = prism_rtl::some_of(qk_og);
            (m23746_2 == Text::lit("Prelude.never"));
        }) ? ({
            auto&& m23746_2 = prism_rtl::some_of(qk_og);
            prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Event::never"), Array<crate::lower::model::Ex>{}}), t_p5}));
        })
            : prism_rtl::is_some(qk_og) ? ({
            auto&& qk_pi = prism_rtl::some_of(qk_og);
            ({
            auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0x).g_p).tags_p, qk_pi);
            prism_rtl::is_some(_m) && ({
            auto&& tg_pj = prism_rtl::some_of(_m);
            ((prism_rtl::deref(tg_pj).kind_p != Text::lit("Prelude.Fault")) && (why_ph == Text::lit("tag")));
        }) ? ({
            auto&& tg_pj = prism_rtl::some_of(_m);
            prism_rtl::more(prism_rtl::rc(TagValue(lx_p0x, env_p1x, tg_pj, Array<crate::syntax::Arg>{})));
        })
            : prism_rtl::more(prism_rtl::rc(GlobalValue(lx_p0x, qk_pi, span_p3x, t_p5)));
        });
        })
            : prism_rtl::is_none(qk_og) ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(prism_rtl::cat("the name ", nkey_p4, ", which nothing declares")), t_p5}))
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
}


/// `Start NameValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_name_value_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::SName n_p2, crate::syntax::Range span_p3) {
    return prism_rtl::make_rc<NameValue>(lx_p0, env_p1, n_p2, span_p3);
}


/// GlobalValue: unbounded fn Lx, Text, Range, OutTy -> Vl
crate::lower::types::Vl global_value_f(const crate::lower::Lx& lx_p0, const Text& qk_p1, const crate::syntax::Range& span_p2, const crate::lower::model::OutTy& t_p3) {
    auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g_p).ctors_p, qk_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& c_p4 = prism_rtl::some_of(_m);
        auto arity_p5 = crate::prelude::len(prism_rtl::deref(c_p4).fields_p) > Nat(0u)
            ? crate::prelude::len(prism_rtl::deref(c_p4).fields_p)
            : crate::prelude::len(prism_rtl::deref(c_p4).args_p);
        if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(t_p3)) {
            auto&& pts_p6 = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p3).a0;
            return arity_p5 > Nat(0u)
                ? ctor_fn_f(lx_p0, c_p4, pts_p6, span_p2, t_p3, false)
                : ctor_app_f(lx_p0, crate::lower::types::empty_env_p(), c_p4, Array<crate::syntax::Arg>{}, span_p2);
        }
        if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t_p3)) {
            auto&& a_p7 = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t_p3).a0;
            auto pts_p8 = ({
                __label__ _done;
                prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
                auto&& _m = prism_rtl::deref(prism_rtl::deref(a_p7));
                if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(_m)) {
                    auto&& ts_p9 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(_m).a0;
                    _v.set(arity_p5 == Nat(1u)
                        ? Array(std::vector{prism_rtl::deref(prism_rtl::deref(a_p7))})
                        : ts_p9);
                    goto _done;
                }
                {
                    _v.set(Array(std::vector{prism_rtl::deref(prism_rtl::deref(a_p7))}));
                    goto _done;
                }
            _done:
                _v.take();
            });
            return arity_p5 > Nat(0u)
                ? ctor_fn_f(lx_p0, c_p4, pts_p8, span_p2, t_p3, true)
                : ctor_app_f(lx_p0, crate::lower::types::empty_env_p(), c_p4, Array<crate::syntax::Arg>{}, span_p2);
        }
        {
            return ctor_app_f(lx_p0, crate::lower::types::empty_env_p(), c_p4, Array<crate::syntax::Arg>{}, span_p2);
        }
    }
    if (prism_rtl::is_none(_m)) {
        auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g_p).tags_p, qk_p1);
        if (prism_rtl::is_some(_m)) {
            auto&& tg_pa = prism_rtl::some_of(_m);
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XStr{prism_rtl::deref(tg_pa).name_p}), t_p3});
        }
        if (prism_rtl::is_none(_m)) {
            return crate::prelude::fold(prism_rtl::deref(lx_p0.g_p).defs_p, false, [&](const bool& f_pb, const crate::check::env::Def& d_pc) { return prism_rtl::deref(f_pb) || ((prism_rtl::deref(d_pc).qk_p == qk_p1) && is_let_def_f(d_pc)); })
                ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::value_path_f(lx_p0, qk_p1), Array<crate::lower::model::Ex>{}}), t_p3})
                : ({
                __label__ _done;
                prism_rtl::Slot<crate::lower::types::Vl> _v;
                auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g_p).vals_p, qk_p1);
                if (prism_rtl::is_some(_m)) {
                    auto&& v_pd = prism_rtl::some_of(_m);
                    _v.set(({
                        auto is_let_pe = crate::prelude::fold(prism_rtl::deref(lx_p0.g_p).defs_p, false, [&](const bool& f_pf, const crate::check::env::Def& d_pg) { return prism_rtl::deref(f_pf) || ((prism_rtl::deref(d_pg).qk_p == qk_p1) && is_let_def_f(d_pg)); });
                        (std::move(is_let_pe)
                        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::value_path_f(lx_p0, qk_p1), Array<crate::lower::model::Ex>{}}), t_p3})
                        : ({
                        __label__ _done;
                        prism_rtl::Slot<crate::lower::types::Vl> _v;
                        if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t_p3)) {
                            auto&& a_ph = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t_p3).a0;
                            _v.set(({
                                auto [ps_pl, ignore2_pm] = crate::lower::jobs::scheme_parts_f(lx_p0, qk_p1);
                                auto names_pi = crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(ps_pl)), [&](const Nat& i_pn) { return prism_rtl::cat("a", i_pn); });
                                auto pa_pj = crate::prelude::len(ps_pl) == Nat(1u)
                                    ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("a0")})), prism_rtl::deref(prism_rtl::deref(a_ph))})
                                    : crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{crate::prelude::each(names_pi, [&](const Text& nm_po) { return crate::lower::model::Pa(crate::lower::model::Pa::PaBind{nm_po}); })})), prism_rtl::deref(prism_rtl::deref(a_ph))});
                                auto f_pk = crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{pa_pj}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(Text::lit("entered")), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{start_path_f(lx_p0, qk_p1), crate::prelude::each(names_pi, [&](const Text& nm_pp) { return crate::lower::model::Ex(crate::lower::model::Ex::XVar{nm_pp}); })})})}))});
                                (crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{f_pk})})), t_p3}), t_p3}));
                            }));
                            goto _done;
                        }
                        {
                            _v.set(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XPath{crate::lower::value_path_f(lx_p0, qk_p1)})})}), t_p3}));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(prism_rtl::cat("the global ", qk_p1)), t_p3}));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::types::Vl> GlobalValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& qk_p1 = this->qk_p1;
    const auto& span_p2 = this->span_p2;
    const auto& t_p3 = this->t_p3;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0).g_p).ctors_p, qk_p1);
        prism_rtl::is_some(_m) ? ({
        auto&& c_p4 = prism_rtl::some_of(_m);
        ({
        auto arity_p5 = crate::prelude::len(prism_rtl::deref(c_p4).fields_p) > Nat(0u)
            ? crate::prelude::len(prism_rtl::deref(c_p4).fields_p)
            : crate::prelude::len(prism_rtl::deref(c_p4).args_p);
        ({
        prism_rtl::is<crate::lower::model::OutTy::OutFn>(t_p3) ? ({
        auto&& pts_p6 = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p3).a0;
        arity_p5 > Nat(0u)
        ? prism_rtl::more(prism_rtl::rc(CtorFn(lx_p0, c_p4, pts_p6, span_p2, t_p3, false)))
        : prism_rtl::more(prism_rtl::rc(CtorApp(lx_p0, crate::lower::types::empty_env_p(), c_p4, Array<crate::syntax::Arg>{}, span_p2)));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t_p3) ? ({
        auto&& a_p7 = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t_p3).a0;
        ({
        auto pts_p8 = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(a_p7));
            if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(_m)) {
                auto&& ts_p9 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(_m).a0;
                _v.set(arity_p5 == Nat(1u)
                    ? Array(std::vector{prism_rtl::deref(prism_rtl::deref(a_p7))})
                    : ts_p9);
                goto _done;
            }
            {
                _v.set(Array(std::vector{prism_rtl::deref(prism_rtl::deref(a_p7))}));
                goto _done;
            }
        _done:
            _v.take();
        });
        arity_p5 > Nat(0u)
        ? prism_rtl::more(prism_rtl::rc(CtorFn(lx_p0, c_p4, pts_p8, span_p2, t_p3, true)))
        : prism_rtl::more(prism_rtl::rc(CtorApp(lx_p0, crate::lower::types::empty_env_p(), c_p4, Array<crate::syntax::Arg>{}, span_p2)));
    });
    })
        : prism_rtl::more(prism_rtl::rc(CtorApp(lx_p0, crate::lower::types::empty_env_p(), c_p4, Array<crate::syntax::Arg>{}, span_p2)));
    });
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0).g_p).tags_p, qk_p1);
        prism_rtl::is_some(_m) ? ({
        auto&& tg_pa = prism_rtl::some_of(_m);
        prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XStr{prism_rtl::deref(tg_pa).name_p}), t_p3}));
    })
        : prism_rtl::is_none(_m) ? crate::prelude::fold(prism_rtl::deref(prism_rtl::deref(lx_p0).g_p).defs_p, false, [&](const bool& f_pb, const crate::check::env::Def& d_pc) { return prism_rtl::deref(f_pb) || ((prism_rtl::deref(d_pc).qk_p == qk_p1) && is_let_def_f(d_pc)); })
        ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::value_path_f(lx_p0, qk_p1), Array<crate::lower::model::Ex>{}}), t_p3}))
        : ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0).g_p).vals_p, qk_p1);
        prism_rtl::is_some(_m) ? ({
        auto&& v_pd = prism_rtl::some_of(_m);
        ({
        auto is_let_pe = crate::prelude::fold(prism_rtl::deref(prism_rtl::deref(lx_p0).g_p).defs_p, false, [&](const bool& f_pf, const crate::check::env::Def& d_pg) { return prism_rtl::deref(f_pf) || ((prism_rtl::deref(d_pg).qk_p == qk_p1) && is_let_def_f(d_pg)); });
        (std::move(is_let_pe)
        ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::value_path_f(lx_p0, qk_p1), Array<crate::lower::model::Ex>{}}), t_p3}))
        : ({
        prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t_p3) ? ({
        auto&& a_ph = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t_p3).a0;
        ({
        auto [ps_pl, ignore2_pm] = crate::lower::jobs::scheme_parts_f(lx_p0, qk_p1);
        auto names_pi = crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(ps_pl)), [&](const Nat& i_pn) { return prism_rtl::cat("a", i_pn); });
        auto pa_pj = crate::prelude::len(ps_pl) == Nat(1u)
            ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("a0")})), prism_rtl::deref(prism_rtl::deref(a_ph))})
            : crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{crate::prelude::each(names_pi, [&](const Text& nm_po) { return crate::lower::model::Pa(crate::lower::model::Pa::PaBind{nm_po}); })})), prism_rtl::deref(prism_rtl::deref(a_ph))});
        auto f_pk = crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{pa_pj}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(Text::lit("entered")), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{start_path_f(lx_p0, qk_p1), crate::prelude::each(names_pi, [&](const Text& nm_pp) { return crate::lower::model::Ex(crate::lower::model::Ex::XVar{nm_pp}); })})})}))});
        (prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{f_pk})})), t_p3}), t_p3})));
    });
    })
        : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XPath{crate::lower::value_path_f(lx_p0, qk_p1)})})}), t_p3}));
    }));
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(prism_rtl::cat("the global ", qk_p1)), t_p3}))
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start GlobalValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_global_value_f(crate::lower::Lx lx_p0, Text qk_p1, crate::syntax::Range span_p2, crate::lower::model::OutTy t_p3) {
    return prism_rtl::make_rc<GlobalValue>(lx_p0, qk_p1, span_p2, t_p3);
}


/// IsLetDef: fn Def -> Bool
bool is_let_def_f(const crate::check::env::Def& d_p0) {
    auto&& _m = d_p0.body_p;
    if (prism_rtl::is<crate::check::env::DefBody::DbLet>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// StartPath: fn Lx, Text -> Text
Text start_path_f(const crate::lower::Lx& lx_p0, const Text& qk_p1) {
    auto owner_p2 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g_p).vals_p, qk_p1);
        if (prism_rtl::is_some(_m)) {
            auto&& v_p3 = prism_rtl::some_of(_m);
            _v.set(prism_rtl::deref(v_p3).home_p);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::lower::owner_of_f(qk_p1));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return crate::lower::path_in_f(lx_p0, owner_p2, prism_rtl::cat("start_", crate::prelude::or_(crate::prelude::get(lx_p0.rs_names_p, qk_p1), crate::lower::snake_f(crate::check::types::bare_name_f(qk_p1)))));
}


/// Application: unbounded fn Lx, Env, Expr, [Arg], Range -> Vl
crate::lower::types::Vl application_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& callee_p2, const Array<crate::syntax::Arg>& args_p3, const crate::syntax::Range& span_p4) {
    auto t_p5 = crate::lower::types::out_ty_of_f(lx_p0, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0, span_p4)));
    auto&& _m = prism_rtl::deref(callee_p2.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p6 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        auto nkey_p7 = crate::lower::types::name_key_at_f(lx_p0, env_p1, n_p6, callee_p2.span_p);
        auto local_o8 = crate::prelude::len(prism_rtl::deref(n_p6).path_p) == Nat(1u)
            ? crate::prelude::get(env_p1.names_p, nkey_p7)
            : std::optional<crate::lower::types::Bn>{};
        if (prism_rtl::is_some(local_o8) && prism_rtl::is<crate::lower::types::Bn::BnLocalFn>(prism_rtl::some_of(local_o8))) {
            auto&& c_p9 = prism_rtl::as<crate::lower::types::Bn::BnLocalFn>(prism_rtl::some_of(local_o8)).a0;
            return inline_local_fn_f(lx_p0, env_p1, c_p9, args_p3, t_p5);
        }
        if (prism_rtl::is_some(local_o8)) {
            auto&& b_pa = prism_rtl::some_of(local_o8);
            auto f_pb = name_value_f(lx_p0, env_p1, n_p6, callee_p2.span_p);
            auto&& _m = crate::lower::types::value_ty_f(f_pb);
            if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m)) {
                return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(Text::lit("run_to_end")), Array(std::vector{crate::lower::jobs::start_call_f(f_pb, start_args_f(lx_p0, env_p1, f_pb, args_p3))})}), t_p5});
            }
            {
                return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XApply{prism_rtl::rc(crate::lower::types::ref_f(f_pb)), crate::prelude::run_to_end(crate::prelude::each_job(args_p3, ({
                    auto lx_p0x = lx_p0;
                    auto env_p1x = env_p1;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), env_p1x = std::move(env_p1x)](crate::syntax::Arg p0) {
                    return ({
                        auto lx_p0xy = lx_p0x;
                        auto env_p1xy = env_p1x;
                        (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), env_p1xy = std::move(env_p1xy)]() {
                        return ({
                            auto a_pc = p0;
                            (prism_rtl::more(prism_rtl::rc(Argument(lx_p0xy, env_p1xy, prism_rtl::deref(a_pc).value_p))));
                        });
                    })));
                    });
                })));
                })))}), t_p5});
            }
        }
        if (prism_rtl::is_none(local_o8)) {
            auto [qk_od, why_pe] = crate::check::env::names::resolve_value_f(lx_p0.g_p, lx_p0.home_p, n_p6);
            if (prism_rtl::is_some(qk_od)) {
                auto&& qk_pf = prism_rtl::some_of(qk_od);
                auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g_p).tags_p, qk_pf);
                if (prism_rtl::is_some(_m)) {
                    auto&& tg_pg = prism_rtl::some_of(_m);
                    if (why_pe == Text::lit("tag")) {
                        return tag_value_f(lx_p0, env_p1, tg_pg, args_p3);
                    }
                }
                {
                    return qk_pf == Text::lit("Prelude.@Element")
                        ? element_blueprint_f(lx_p0, env_p1, args_p3, t_p5)
                        : global_call_f(lx_p0, env_p1, qk_pf, args_p3, span_p4, t_p5);
                }
            }
            if (prism_rtl::is_none(qk_od)) {
                return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(prism_rtl::cat("a call of ", nkey_p7, ", which nothing declares")), t_p5});
            }
            prism_rtl::unreachable("no arm matched");
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_ph = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return application_f(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_ph)), args_p3, span_p4);
    }
    {
        auto f_pi = value_of_f(lx_p0, env_p1, callee_p2);
        auto&& _m = crate::lower::types::value_ty_f(f_pi);
        if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m)) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(Text::lit("run_to_end")), Array(std::vector{crate::lower::jobs::start_call_f(f_pi, start_args_f(lx_p0, env_p1, f_pi, args_p3))})}), t_p5});
        }
        {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XApply{prism_rtl::rc(crate::lower::types::ref_f(f_pi)), crate::prelude::run_to_end(crate::prelude::each_job(args_p3, ({
                auto lx_p0x = lx_p0;
                auto env_p1x = env_p1;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), env_p1x = std::move(env_p1x)](crate::syntax::Arg p0) {
                return ({
                    auto lx_p0xy = lx_p0x;
                    auto env_p1xy = env_p1x;
                    (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), env_p1xy = std::move(env_p1xy)]() {
                    return ({
                        auto a_pj = p0;
                        (prism_rtl::more(prism_rtl::rc(Argument(lx_p0xy, env_p1xy, prism_rtl::deref(a_pj).value_p))));
                    });
                })));
                });
            })));
            })))}), t_p5});
        }
    }
}


prism_rtl::Turn<crate::lower::types::Vl> Application::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& callee_p2 = this->callee_p2;
    const auto& args_p3 = this->args_p3;
    const auto& span_p4 = this->span_p4;
    auto args_p3x = args_p3;
    auto callee_p2x = callee_p2;
    auto env_p1x = env_p1;
    auto lx_p0x = lx_p0;
    auto span_p4x = span_p4;
    return crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0x, span_p4x))), [=](crate::lower::model::OutTy out_ty_of_f_26656) {
        return ({
            auto t_p5 = out_ty_of_f_26656;
            ({
            auto&& _m = prism_rtl::deref(prism_rtl::deref(callee_p2x).kind_p);
            prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
            auto&& n_p6 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            ({
            auto nkey_p7 = crate::lower::types::name_key_at_f(lx_p0x, env_p1x, n_p6, prism_rtl::deref(callee_p2x).span_p);
            auto local_o8 = crate::prelude::len(prism_rtl::deref(n_p6).path_p) == Nat(1u)
                ? crate::prelude::get(prism_rtl::deref(env_p1x).names_p, nkey_p7)
                : std::optional<crate::lower::types::Bn>{};
            ({
            prism_rtl::is_some(local_o8) && prism_rtl::is<crate::lower::types::Bn::BnLocalFn>(prism_rtl::some_of(local_o8)) ? ({
            auto&& c_p9 = prism_rtl::as<crate::lower::types::Bn::BnLocalFn>(prism_rtl::some_of(local_o8)).a0;
            prism_rtl::more(prism_rtl::rc(InlineLocalFn(lx_p0x, env_p1x, c_p9, args_p3x, t_p5)));
        })
            : prism_rtl::is_some(local_o8) ? ({
            auto&& b_pa = prism_rtl::some_of(local_o8);
            ({
            auto n_p6x = n_p6;
            (crate::prelude::call_then(start_name_value_f(lx_p0x, env_p1x, n_p6x, prism_rtl::deref(callee_p2x).span_p), [=](crate::lower::types::Vl name_value_f_27005) {
            return ({
                auto f_pb = name_value_f_27005;
                ({
                auto&& _m = crate::lower::types::value_ty_f(f_pb);
                prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m) ? crate::prelude::call_then(start_start_args_f(lx_p0x, env_p1x, f_pb, args_p3x), [=](Array<crate::lower::model::Ex> start_args_f_27208) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(Text::lit("run_to_end")), Array(std::vector{crate::lower::jobs::start_call_f(f_pb, start_args_f_27208)})}), t_p5})); })
                : crate::prelude::call_value(crate::prelude::each_job(args_p3x, ({
                auto lx_p0xx = lx_p0x;
                auto env_p1xx = env_p1x;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=, lx_p0xx = std::move(lx_p0xx), env_p1xx = std::move(env_p1xx)](crate::syntax::Arg p0) {
                return ({
                    auto lx_p0xxy = lx_p0xx;
                    auto env_p1xxy = env_p1xx;
                    (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxy = std::move(lx_p0xxy), env_p1xxy = std::move(env_p1xxy)]() {
                    return ({
                        auto a_pc = p0;
                        (prism_rtl::more(prism_rtl::rc(Argument(lx_p0xxy, env_p1xxy, prism_rtl::deref(a_pc).value_p))));
                    });
                })));
                });
            })));
            })), [=](Array<crate::lower::model::Ex> each_27304) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XApply{prism_rtl::rc(crate::lower::types::ref_f(f_pb)), each_27304}), t_p5})); });
            });
            });
        }));
        });
        })
            : prism_rtl::is_none(local_o8) ? ({
            auto [qk_od, why_pe] = crate::check::env::names::resolve_value_f(prism_rtl::deref(lx_p0x).g_p, prism_rtl::deref(lx_p0x).home_p, n_p6);
            ({
            prism_rtl::is_some(qk_od) ? ({
            auto&& qk_pf = prism_rtl::some_of(qk_od);
            ({
            auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0x).g_p).tags_p, qk_pf);
            prism_rtl::is_some(_m) && ({
            auto&& tg_pg = prism_rtl::some_of(_m);
            (why_pe == Text::lit("tag"));
        }) ? ({
            auto&& tg_pg = prism_rtl::some_of(_m);
            prism_rtl::more(prism_rtl::rc(TagValue(lx_p0x, env_p1x, tg_pg, args_p3x)));
        })
            : qk_pf == Text::lit("Prelude.@Element")
            ? prism_rtl::more(prism_rtl::rc(ElementBlueprint(lx_p0x, env_p1x, args_p3x, t_p5)))
            : prism_rtl::more(prism_rtl::rc(GlobalCall(lx_p0x, env_p1x, qk_pf, args_p3x, span_p4x, t_p5)));
        });
        })
            : prism_rtl::is_none(qk_od) ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(prism_rtl::cat("a call of ", nkey_p7, ", which nothing declares")), t_p5}))
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
            auto&& x_ph = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
            prism_rtl::more(prism_rtl::rc(Application(lx_p0x, env_p1x, prism_rtl::deref(prism_rtl::deref(x_ph)), args_p3x, span_p4x)));
        })
            : crate::prelude::call_then(start_value_of_f(lx_p0x, env_p1x, callee_p2x), [=](crate::lower::types::Vl value_of_f_28127) {
            return ({
                auto f_pi = value_of_f_28127;
                ({
                auto&& _m = crate::lower::types::value_ty_f(f_pi);
                prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m) ? crate::prelude::call_then(start_start_args_f(lx_p0x, env_p1x, f_pi, args_p3x), [=](Array<crate::lower::model::Ex> start_args_f_28276) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(Text::lit("run_to_end")), Array(std::vector{crate::lower::jobs::start_call_f(f_pi, start_args_f_28276)})}), t_p5})); })
                : crate::prelude::call_value(crate::prelude::each_job(args_p3x, ({
                auto lx_p0xx = lx_p0x;
                auto env_p1xx = env_p1x;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=, lx_p0xx = std::move(lx_p0xx), env_p1xx = std::move(env_p1xx)](crate::syntax::Arg p0) {
                return ({
                    auto lx_p0xxy = lx_p0xx;
                    auto env_p1xxy = env_p1xx;
                    (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxy = std::move(lx_p0xxy), env_p1xxy = std::move(env_p1xxy)]() {
                    return ({
                        auto a_pj = p0;
                        (prism_rtl::more(prism_rtl::rc(Argument(lx_p0xxy, env_p1xxy, prism_rtl::deref(a_pj).value_p))));
                    });
                })));
                });
            })));
            })), [=](Array<crate::lower::model::Ex> each_28364) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XApply{prism_rtl::rc(crate::lower::types::ref_f(f_pi)), each_28364}), t_p5})); });
            });
            });
        });
        });
        });
    });
}


/// `Start Application, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_application_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr callee_p2, Array<crate::syntax::Arg> args_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<Application>(lx_p0, env_p1, callee_p2, args_p3, span_p4);
}


/// InlineLocalFn: unbounded fn Lx, Env, FnClause, [Arg], OutTy -> Vl
crate::lower::types::Vl inline_local_fn_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::decls::FnClause& c_p2, const Array<crate::syntax::Arg>& args_p3, const crate::lower::model::OutTy& t_p4) {
    auto names_p5 = crate::prelude::each(c_p2.params_p, [&](const crate::syntax::Pattern_& p_p6) { return crate::lower::functions::plain_binder_f(lx_p0, p_p6); });
    return crate::prelude::fold(names_p5, false, [&](const bool& bad_p7, const Text& nm_p8) { return prism_rtl::deref(bad_p7) || (nm_p8 == Text::lit("")); })
        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(Text::lit("a local function whose parameters are not names")), t_p4})
        : ({
        auto [dos_ph, env2_pi] = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(names_p5)), std::tuple{Array<crate::lower::model::Do>{}, env_p1}, ({
            auto names_p5x = names_p5;
            auto lx_p0x = lx_p0;
            auto c_p2x = c_p2;
            auto args_p3x = args_p3;
            auto env_p1x = env_p1;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>>(std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>, Nat>)>>(prism_rtl::rc([=, names_p5x = std::move(names_p5x), lx_p0x = std::move(lx_p0x), c_p2x = std::move(c_p2x), args_p3x = std::move(args_p3x), env_p1x = std::move(env_p1x)](std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto names_p5xy = names_p5x;
                auto lx_p0xy = lx_p0x;
                auto c_p2xy = c_p2x;
                auto args_p3xy = args_p3x;
                auto env_p1xy = env_p1x;
                (crate::prelude::entered(crate::prelude::once_job([=, names_p5xy = std::move(names_p5xy), lx_p0xy = std::move(lx_p0xy), c_p2xy = std::move(c_p2xy), args_p3xy = std::move(args_p3xy), env_p1xy = std::move(env_p1xy)]() {
                return ({
                    auto [acc_p9, en_pa] = p0;
                    auto i_pb = p1;
                    ({
                    auto nm_pc = crate::prelude::or_(crate::prelude::index(names_p5xy, i_pb), Text::lit(""));
                    auto rs_pd = prism_rtl::cat(crate::lower::local_name_f(lx_p0xy, nm_pc), "_", prism_rtl::deref(prism_rtl::deref(c_p2xy).span_p).start_p);
                    auto v_pe = ({
                        __label__ _done;
                        prism_rtl::Slot<crate::lower::types::Vl> _v;
                        auto&& _m = crate::prelude::index(args_p3xy, i_pb);
                        if (prism_rtl::is_some(_m)) {
                            auto&& a_pg = prism_rtl::some_of(_m);
                            _v.set(value_of_f(lx_p0xy, env_p1xy, prism_rtl::deref(a_pg).value_p));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    auto bt_pf = crate::lower::types::value_ty_f(v_pe);
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc_p9, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{rs_pd}), crate::lower::types::own_f(v_pe)})), crate::lower::types::bind_f(en_pa, nm_pc, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs_pd}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt_pf}))}));
                });
                });
            })));
            });
        }));
        })));
        (crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos_ph, prism_rtl::rc(crate::lower::functions::fn_body_value_f(lx_p0, env2_pi, c_p2.body_p))}), t_p4}));
    });
}


prism_rtl::Turn<crate::lower::types::Vl> InlineLocalFn::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& c_p2 = this->c_p2;
    const auto& args_p3 = this->args_p3;
    const auto& t_p4 = this->t_p4;
    auto names_p5 = crate::prelude::each(prism_rtl::deref(c_p2).params_p, [&](const crate::syntax::Pattern_& p_p6) { return crate::lower::functions::plain_binder_f(lx_p0, p_p6); });
    return crate::prelude::fold(names_p5, false, [&](const bool& bad_p7, const Text& nm_p8) { return prism_rtl::deref(bad_p7) || (nm_p8 == Text::lit("")); })
        ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(Text::lit("a local function whose parameters are not names")), t_p4}))
        : ({
        auto args_p3x = args_p3;
        auto c_p2x = c_p2;
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        auto t_p4x = t_p4;
        (crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(names_p5)), std::tuple{Array<crate::lower::model::Do>{}, env_p1x}, ({
        auto names_p5x = names_p5;
        auto lx_p0xx = lx_p0x;
        auto c_p2xx = c_p2x;
        auto args_p3xx = args_p3x;
        auto env_p1xx = env_p1x;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>>(std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>, Nat>)>>(prism_rtl::rc([=, names_p5x = std::move(names_p5x), lx_p0xx = std::move(lx_p0xx), c_p2xx = std::move(c_p2xx), args_p3xx = std::move(args_p3xx), env_p1xx = std::move(env_p1xx)](std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto names_p5xy = names_p5x;
            auto lx_p0xxy = lx_p0xx;
            auto c_p2xxy = c_p2xx;
            auto args_p3xxy = args_p3xx;
            auto env_p1xxy = env_p1xx;
            (crate::prelude::entered(crate::prelude::once_job([=, names_p5xy = std::move(names_p5xy), lx_p0xxy = std::move(lx_p0xxy), c_p2xxy = std::move(c_p2xxy), args_p3xxy = std::move(args_p3xxy), env_p1xxy = std::move(env_p1xxy)]() {
            return ({
                auto [acc_p9, en_pa] = p0;
                auto i_pb = p1;
                ({
                auto nm_pc = crate::prelude::or_(crate::prelude::index(names_p5xy, i_pb), Text::lit(""));
                auto rs_pd = prism_rtl::cat(crate::lower::local_name_f(lx_p0xxy, nm_pc), "_", prism_rtl::deref(prism_rtl::deref(c_p2xxy).span_p).start_p);
                auto v_pe = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::lower::types::Vl> _v;
                    auto&& _m = crate::prelude::index(args_p3xxy, i_pb);
                    if (prism_rtl::is_some(_m)) {
                        auto&& a_pg = prism_rtl::some_of(_m);
                        _v.set(value_of_f(lx_p0xxy, env_p1xxy, prism_rtl::deref(a_pg).value_p));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto bt_pf = crate::lower::types::value_ty_f(v_pe);
                (prism_rtl::finished(std::tuple{crate::prelude::push(acc_p9, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{rs_pd}), crate::lower::types::own_f(v_pe)})), crate::lower::types::bind_f(en_pa, nm_pc, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs_pd}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt_pf}))}));
            });
            });
        })));
        });
    }));
    })), [=, t_p4x = std::move(t_p4x)](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> fold_28950) {
        return ({
            auto [dos_ph, env2_pi] = fold_28950;
            (crate::prelude::call_then(crate::lower::functions::start_fn_body_value_f(lx_p0x, env2_pi, prism_rtl::deref(c_p2x).body_p), [=](crate::lower::model::Ex fn_body_value_f_29396) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos_ph, prism_rtl::rc(fn_body_value_f_29396)}), t_p4x})); }));
        });
    }));
    });
}


/// `Start InlineLocalFn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_inline_local_fn_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::decls::FnClause c_p2, Array<crate::syntax::Arg> args_p3, crate::lower::model::OutTy t_p4) {
    return prism_rtl::make_rc<InlineLocalFn>(lx_p0, env_p1, c_p2, args_p3, t_p4);
}


/// Argument: unbounded fn Lx, Env, Expr -> Ex
crate::lower::model::Ex argument_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2) {
    auto&& _m = crate::prelude::get(env_p1.spans_p, crate::lower::place_key_f(lx_p0, e_p2.span_p));
    if (prism_rtl::is_some(_m)) {
        auto&& v_p3 = prism_rtl::some_of(_m);
        return crate::lower::types::ref_f(v_p3);
    }
    if (prism_rtl::is_none(_m)) {
        return argument_by_kind_f(lx_p0, env_p1, e_p2);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::model::Ex> Argument::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& e_p2 = this->e_p2;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(env_p1).spans_p, crate::lower::place_key_f(lx_p0, prism_rtl::deref(e_p2).span_p));
        prism_rtl::is_some(_m) ? ({
        auto&& v_p3 = prism_rtl::some_of(_m);
        prism_rtl::finished(crate::lower::types::ref_f(v_p3));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(ArgumentByKind(lx_p0, env_p1, e_p2)))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start Argument, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_argument_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2) {
    return prism_rtl::make_rc<Argument>(lx_p0, env_p1, e_p2);
}


/// ArgumentByKind: unbounded fn Lx, Env, Expr -> Ex
crate::lower::model::Ex argument_by_kind_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2) {
    auto&& _m = prism_rtl::deref(e_p2.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
        auto&& ps_o3 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
        auto&& body_p4 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
        return crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(lambda_arg_f(lx_p0, env_p1, crate::prelude::or_(ps_o3, Array<crate::syntax::Pattern_>{}), prism_rtl::deref(prism_rtl::deref(body_p4)), lambda_param_tys_f(lx_p0, e_p2, crate::prelude::len(crate::prelude::or_(ps_o3, Array<crate::syntax::Pattern_>{})))))});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p5 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return argument_f(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p5)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p6 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        auto t_p7 = crate::lower::type_at_f(lx_p0, e_p2.span_p);
        auto&& _m = crate::lower::types::peel_f(t_p7);
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CBound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0)) {
            auto local_o8 = crate::prelude::len(prism_rtl::deref(n_p6).path_p) == Nat(1u)
                ? crate::prelude::get(env_p1.names_p, crate::lower::types::name_key_at_f(lx_p0, env_p1, n_p6, e_p2.span_p))
                : std::optional<crate::lower::types::Bn>{};
            if (prism_rtl::is_some(local_o8)) {
                return closure_ref_f(value_of_f(lx_p0, env_p1, e_p2));
            }
            if (prism_rtl::is_none(local_o8)) {
                auto&& _qk_o9 = crate::check::env::names::resolve_value_f(lx_p0.g_p, lx_p0.home_p, n_p6);
                auto&& qk_o9 = std::get<0>(_qk_o9);
                if (prism_rtl::is_some(qk_o9)) {
                    auto&& qk_pa = prism_rtl::some_of(qk_o9);
                    return crate::check::env::has_key_f(prism_rtl::deref(lx_p0.g_p).ctors_p, qk_pa)
                        ? closure_ref_f(value_of_f(lx_p0, env_p1, e_p2))
                        : crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XPath{crate::lower::value_path_f(lx_p0, qk_pa)}))});
                }
                if (prism_rtl::is_none(qk_o9)) {
                    return crate::lower::types::ref_f(value_of_f(lx_p0, env_p1, e_p2));
                }
                prism_rtl::unreachable("no arm matched");
            }
            prism_rtl::unreachable("no arm matched");
        }
        {
            return crate::lower::types::ref_f(value_of_f(lx_p0, env_p1, e_p2));
        }
    }
    {
        return crate::lower::types::ref_f(value_of_f(lx_p0, env_p1, e_p2));
    }
}


prism_rtl::Turn<crate::lower::model::Ex> ArgumentByKind::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& e_p2 = this->e_p2;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p2).kind_p);
        prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) ? ({
        auto&& ps_o3 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
        auto&& body_p4 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
        ({
        auto ps_o3x = ps_o3;
        auto body_p4x = prism_rtl::deref(prism_rtl::deref(body_p4));
        auto e_p2x = e_p2;
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        (crate::prelude::call_then(start_lambda_param_tys_f(lx_p0x, e_p2x, crate::prelude::len(crate::prelude::or_(ps_o3x, Array<crate::syntax::Pattern_>{}))), [=, body_p4x = std::move(body_p4x), env_p1x = std::move(env_p1x)](Array<crate::lower::model::OutTy> lambda_param_tys_f_29834) { return crate::prelude::call_then(start_lambda_arg_f(lx_p0x, env_p1x, crate::prelude::or_(ps_o3x, Array<crate::syntax::Pattern_>{}), body_p4x, lambda_param_tys_f_29834), [=](crate::lower::model::Ex lambda_arg_f_29792) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(lambda_arg_f_29792)})); }); }));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x_p5 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(Argument(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p5)))));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n_p6 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        ({
        auto t_p7 = crate::lower::type_at_f(lx_p0, prism_rtl::deref(e_p2).span_p);
        ({
        auto&& _m = crate::lower::types::peel_f(t_p7);
        prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CBound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0) ? ({
        auto local_o8 = crate::prelude::len(prism_rtl::deref(n_p6).path_p) == Nat(1u)
            ? crate::prelude::get(prism_rtl::deref(env_p1).names_p, crate::lower::types::name_key_at_f(lx_p0, env_p1, n_p6, prism_rtl::deref(e_p2).span_p))
            : std::optional<crate::lower::types::Bn>{};
        ({
        prism_rtl::is_some(local_o8) ? ({
        auto e_p2x = e_p2;
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        (crate::prelude::call_then(start_value_of_f(lx_p0x, env_p1x, e_p2x), [=](crate::lower::types::Vl value_of_f_30196) { return prism_rtl::finished(closure_ref_f(value_of_f_30196)); }));
    })
        : prism_rtl::is_none(local_o8) ? ({
        auto&& _qk_o9 = crate::check::env::names::resolve_value_f(prism_rtl::deref(lx_p0).g_p, prism_rtl::deref(lx_p0).home_p, n_p6);
        auto&& qk_o9 = std::get<0>(_qk_o9);
        ({
        prism_rtl::is_some(qk_o9) ? ({
        auto&& qk_pa = prism_rtl::some_of(qk_o9);
        crate::check::env::has_key_f(prism_rtl::deref(prism_rtl::deref(lx_p0).g_p).ctors_p, qk_pa)
        ? ({
        auto e_p2x = e_p2;
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        (crate::prelude::call_then(start_value_of_f(lx_p0x, env_p1x, e_p2x), [=](crate::lower::types::Vl value_of_f_30424) { return prism_rtl::finished(closure_ref_f(value_of_f_30424)); }));
    })
        : prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XPath{crate::lower::value_path_f(lx_p0, qk_pa)}))}));
    })
        : prism_rtl::is_none(qk_o9) ? ({
        auto e_p2x = e_p2;
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        (crate::prelude::call_then(start_value_of_f(lx_p0x, env_p1x, e_p2x), [=](crate::lower::types::Vl value_of_f_30520) { return prism_rtl::finished(crate::lower::types::ref_f(value_of_f_30520)); }));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : ({
        auto e_p2x = e_p2;
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        (crate::prelude::call_then(start_value_of_f(lx_p0x, env_p1x, e_p2x), [=](crate::lower::types::Vl value_of_f_30568) { return prism_rtl::finished(crate::lower::types::ref_f(value_of_f_30568)); }));
    });
    });
    });
    })
        : ({
        auto e_p2x = e_p2;
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        (crate::prelude::call_then(start_value_of_f(lx_p0x, env_p1x, e_p2x), [=](crate::lower::types::Vl value_of_f_30608) { return prism_rtl::finished(crate::lower::types::ref_f(value_of_f_30608)); }));
    });
    });
}


/// `Start ArgumentByKind, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_argument_by_kind_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2) {
    return prism_rtl::make_rc<ArgumentByKind>(lx_p0, env_p1, e_p2);
}


/// ClosureRef: fn Vl -> Ex
crate::lower::model::Ex closure_ref_f(const crate::lower::types::Vl& vl0) {
    if (prism_rtl::is<crate::lower::types::Vl::VlPlace>(vl0) && prism_rtl::is<crate::lower::types::Holding::ByRef>(prism_rtl::as<crate::lower::types::Vl::VlPlace>(vl0).a1)) {
        auto&& x_p0 = prism_rtl::as<crate::lower::types::Vl::VlPlace>(vl0).a0;
        auto&& t_p1 = prism_rtl::as<crate::lower::types::Vl::VlPlace>(vl0).a2;
        return x_p0;
    }
    if (prism_rtl::is<crate::lower::types::Vl::VlPlace>(vl0)) {
        auto&& x_p2 = prism_rtl::as<crate::lower::types::Vl::VlPlace>(vl0).a0;
        auto&& t_p3 = prism_rtl::as<crate::lower::types::Vl::VlPlace>(vl0).a2;
        return crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(x_p2)}))});
    }
    if (prism_rtl::is<crate::lower::types::Vl::VlOwned>(vl0)) {
        auto&& x_p4 = prism_rtl::as<crate::lower::types::Vl::VlOwned>(vl0).a0;
        auto&& t_p5 = prism_rtl::as<crate::lower::types::Vl::VlOwned>(vl0).a1;
        return crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(x_p4)}))});
    }
    prism_rtl::unreachable("no arm matched");
}


/// TagValue: unbounded fn Lx, Env, TagInfo, [Arg] -> Vl
crate::lower::types::Vl tag_value_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::check::env::TagInfo& tg_p2, const Array<crate::syntax::Arg>& args_p3) {
    auto [variant_p5, struct_path_p6] = crate::lower::program::tag_paths_f(lx_p0, tg_p2);
    auto t_p4 = crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{crate::lower::program::kind_path_f(lx_p0, tg_p2.kind_p), Array<crate::lower::model::OutTy>{}});
    auto&& _m = tg_p2.kind_p;
    {
        auto&& m31359_0 = _m;
        if (m31359_0 == Text::lit("Element")) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(prism_rtl::cat("an element as a plain value (", tg_p2.name_p, "): a live element comes from its host")), t_p4});
        }
    }
    {
        auto&& m31359_1 = _m;
        if (m31359_1 == Text::lit("Prelude.Fault")) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(prism_rtl::cat("a fault kind applied (", tg_p2.name_p, ")")), t_p4});
        }
    }
    {
        auto named_p7 = crate::prelude::fold(args_p3, false, [&](const bool& f_p9, const crate::syntax::Arg& a_pa) { return prism_rtl::deref(f_p9) || is_named_arg_f(a_pa); });
        auto fields_p8 = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(tg_p2.fields_p)), ({
            auto tg_p2x = tg_p2;
            auto named_p7x = std::move(named_p7);
            auto args_p3x = args_p3;
            auto lx_p0x = lx_p0;
            auto env_p1x = env_p1;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::lower::model::Ex>>(Nat)>>(prism_rtl::rc([=, tg_p2x = std::move(tg_p2x), named_p7x = std::move(named_p7x), args_p3x = std::move(args_p3x), lx_p0x = std::move(lx_p0x), env_p1x = std::move(env_p1x)](Nat p0) {
            return ({
                auto tg_p2xy = tg_p2x;
                auto named_p7xy = named_p7x;
                auto args_p3xy = args_p3x;
                auto lx_p0xy = lx_p0x;
                auto env_p1xy = env_p1x;
                (crate::prelude::entered(crate::prelude::once_job([=, tg_p2xy = std::move(tg_p2xy), named_p7xy = std::move(named_p7xy), args_p3xy = std::move(args_p3xy), lx_p0xy = std::move(lx_p0xy), env_p1xy = std::move(env_p1xy)]() {
                return ({
                    auto i_pb = p0;
                    ({
                    auto [fname_pe, fty_pf] = crate::prelude::or_(crate::prelude::index(prism_rtl::deref(tg_p2xy).fields_p, i_pb), std::tuple{Text::lit(""), crate::check::types::Ty(crate::check::types::Ty::TyErr{})});
                    auto arg_oc = named_p7xy
                        ? crate::lower::node_::elements::tag_arg_o(args_p3xy, fname_pe)
                        : ({
                        __label__ _done;
                        prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                        auto&& _m = crate::prelude::index(args_p3xy, i_pb);
                        if (prism_rtl::is_some(_m)) {
                            auto&& a_pg = prism_rtl::some_of(_m);
                            _v.set(std::optional(prism_rtl::deref(a_pg).value_p));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(std::optional<crate::syntax::Expr>{});
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    auto v_pd = ({
                        __label__ _done;
                        prism_rtl::Slot<crate::lower::model::Ex> _v;
                        if (prism_rtl::is_some(arg_oc)) {
                            auto&& x_ph = prism_rtl::some_of(arg_oc);
                            _v.set(crate::lower::types::own_f(value_of_f(lx_p0xy, env_p1xy, x_ph)));
                            goto _done;
                        }
                        if (prism_rtl::is_none(arg_oc)) {
                            _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Default::default"), Array<crate::lower::model::Ex>{}}));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    (crate::prelude::call_then(crate::lower::start_field_spell_f(prism_rtl::deref(tg_p2xy).home_p, fname_pe, fty_pf), [=, v_pd = std::move(v_pd)](Text field_spell_f_32094) { return prism_rtl::finished(std::tuple{field_spell_f_32094, v_pd}); }));
                });
                });
            })));
            });
        }));
        })));
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant_p5, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRecord{struct_path_p6, fields_p8})})}), t_p4});
    }
}


prism_rtl::Turn<crate::lower::types::Vl> TagValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& tg_p2 = this->tg_p2;
    const auto& args_p3 = this->args_p3;
    auto [variant_p5, struct_path_p6] = crate::lower::program::tag_paths_f(lx_p0, tg_p2);
    auto t_p4 = crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{crate::lower::program::kind_path_f(lx_p0, prism_rtl::deref(tg_p2).kind_p), Array<crate::lower::model::OutTy>{}});
    return ({
        auto&& _m = prism_rtl::deref(tg_p2).kind_p;
        ({
        auto&& m31359_0 = _m;
        (m31359_0 == Text::lit("Element"));
    }) ? ({
        auto&& m31359_0 = _m;
        prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(prism_rtl::cat("an element as a plain value (", prism_rtl::deref(tg_p2).name_p, "): a live element comes from its host")), t_p4}));
    })
        : ({
        auto&& m31359_1 = _m;
        (m31359_1 == Text::lit("Prelude.Fault"));
    }) ? ({
        auto&& m31359_1 = _m;
        prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(prism_rtl::cat("a fault kind applied (", prism_rtl::deref(tg_p2).name_p, ")")), t_p4}));
    })
        : ({
        auto named_p7 = crate::prelude::fold(args_p3, false, [&](const bool& f_p9, const crate::syntax::Arg& a_pa) { return prism_rtl::deref(f_p9) || is_named_arg_f(a_pa); });
        auto args_p3x = args_p3;
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        auto tg_p2x = tg_p2;
        (crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(prism_rtl::deref(tg_p2x).fields_p)), ({
        auto tg_p2xx = tg_p2x;
        auto named_p7x = std::move(named_p7);
        auto args_p3xx = args_p3x;
        auto lx_p0xx = lx_p0x;
        auto env_p1xx = env_p1x;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::lower::model::Ex>>(Nat)>>(prism_rtl::rc([=, tg_p2xx = std::move(tg_p2xx), named_p7x = std::move(named_p7x), args_p3xx = std::move(args_p3xx), lx_p0xx = std::move(lx_p0xx), env_p1xx = std::move(env_p1xx)](Nat p0) {
        return ({
            auto tg_p2xxy = tg_p2xx;
            auto named_p7xy = named_p7x;
            auto args_p3xxy = args_p3xx;
            auto lx_p0xxy = lx_p0xx;
            auto env_p1xxy = env_p1xx;
            (crate::prelude::entered(crate::prelude::once_job([=, tg_p2xxy = std::move(tg_p2xxy), named_p7xy = std::move(named_p7xy), args_p3xxy = std::move(args_p3xxy), lx_p0xxy = std::move(lx_p0xxy), env_p1xxy = std::move(env_p1xxy)]() {
            return ({
                auto i_pb = p0;
                ({
                auto [fname_pe, fty_pf] = crate::prelude::or_(crate::prelude::index(prism_rtl::deref(tg_p2xxy).fields_p, i_pb), std::tuple{Text::lit(""), crate::check::types::Ty(crate::check::types::Ty::TyErr{})});
                auto arg_oc = named_p7xy
                    ? crate::lower::node_::elements::tag_arg_o(args_p3xxy, fname_pe)
                    : ({
                    __label__ _done;
                    prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                    auto&& _m = crate::prelude::index(args_p3xxy, i_pb);
                    if (prism_rtl::is_some(_m)) {
                        auto&& a_pg = prism_rtl::some_of(_m);
                        _v.set(std::optional(prism_rtl::deref(a_pg).value_p));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(std::optional<crate::syntax::Expr>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto v_pd = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::lower::model::Ex> _v;
                    if (prism_rtl::is_some(arg_oc)) {
                        auto&& x_ph = prism_rtl::some_of(arg_oc);
                        _v.set(crate::lower::types::own_f(value_of_f(lx_p0xxy, env_p1xxy, x_ph)));
                        goto _done;
                    }
                    if (prism_rtl::is_none(arg_oc)) {
                        _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Default::default"), Array<crate::lower::model::Ex>{}}));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                (crate::prelude::call_then(crate::lower::start_field_spell_f(prism_rtl::deref(tg_p2xxy).home_p, fname_pe, fty_pf), [=, v_pd = std::move(v_pd)](Text field_spell_f_32094) { return prism_rtl::finished(std::tuple{field_spell_f_32094, v_pd}); }));
            });
            });
        })));
        });
    }));
    })), [=](Array<std::tuple<Text, crate::lower::model::Ex>> each_31685) {
        return ({
            auto fields_p8 = each_31685;
            (prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant_p5, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRecord{struct_path_p6, fields_p8})})}), t_p4})));
        });
    }));
    });
    });
}


/// `Start TagValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_tag_value_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::check::env::TagInfo tg_p2, Array<crate::syntax::Arg> args_p3) {
    return prism_rtl::make_rc<TagValue>(lx_p0, env_p1, tg_p2, args_p3);
}


/// GlobalCall: unbounded fn Lx, Env, Text, [Arg], Range, OutTy -> Vl
crate::lower::types::Vl global_call_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Text& qk_p2, const Array<crate::syntax::Arg>& args_p3, const crate::syntax::Range& span_p4, const crate::lower::model::OutTy& t_p5) {
    auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g_p).ctors_p, qk_p2);
    if (prism_rtl::is_some(_m)) {
        auto&& c_p6 = prism_rtl::some_of(_m);
        return ctor_app_f(lx_p0, env_p1, c_p6, args_p3, span_p4);
    }
    if (prism_rtl::is_none(_m)) {
        auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g_p).vals_p, qk_p2);
        if (prism_rtl::is_some(_m)) {
            auto&& v_p7 = prism_rtl::some_of(_m);
            return prism_rtl::deref(v_p7).sort_p == Text::lit("method")
                ? method_call_f(lx_p0, env_p1, v_p7, args_p3, span_p4, t_p5)
                : prism_rtl::deref(v_p7).home_p == Text::lit("Prelude")
                ? prelude_call_f(lx_p0, env_p1, qk_p2, args_p3, span_p4, t_p5)
                : as_instance_f(crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::value_path_f(lx_p0, qk_p2), args_for_f(lx_p0, env_p1, v_p7, args_p3)}), result_repr_f(lx_p0, v_p7), t_p5);
        }
        if (prism_rtl::is_none(_m)) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(prism_rtl::cat("a call of ", qk_p2)), t_p5});
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::types::Vl> GlobalCall::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& qk_p2 = this->qk_p2;
    const auto& args_p3 = this->args_p3;
    const auto& span_p4 = this->span_p4;
    const auto& t_p5 = this->t_p5;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0).g_p).ctors_p, qk_p2);
        prism_rtl::is_some(_m) ? ({
        auto&& c_p6 = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(CtorApp(lx_p0, env_p1, c_p6, args_p3, span_p4)));
    })
        : prism_rtl::is_none(_m) ? ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0).g_p).vals_p, qk_p2);
        prism_rtl::is_some(_m) ? ({
        auto&& v_p7 = prism_rtl::some_of(_m);
        prism_rtl::deref(v_p7).sort_p == Text::lit("method")
        ? prism_rtl::more(prism_rtl::rc(MethodCall(lx_p0, env_p1, v_p7, args_p3, span_p4, t_p5)))
        : prism_rtl::deref(v_p7).home_p == Text::lit("Prelude")
        ? prism_rtl::more(prism_rtl::rc(PreludeCall(lx_p0, env_p1, qk_p2, args_p3, span_p4, t_p5)))
        : ({
        auto args_p3x = args_p3;
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        auto qk_p2x = qk_p2;
        auto t_p5x = t_p5;
        (crate::prelude::call_then(start_args_for_f(lx_p0x, env_p1x, v_p7, args_p3x), [=, qk_p2x = std::move(qk_p2x), t_p5x = std::move(t_p5x)](Array<crate::lower::model::Ex> args_for_f_32746) { return crate::prelude::call_then(start_result_repr_f(lx_p0x, v_p7), [=](crate::lower::model::OutTy result_repr_f_32775) { return prism_rtl::more(prism_rtl::rc(AsInstance(crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::value_path_f(lx_p0x, qk_p2x), args_for_f_32746}), result_repr_f_32775, t_p5x))); }); }));
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(prism_rtl::cat("a call of ", qk_p2)), t_p5}))
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start GlobalCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_global_call_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Text qk_p2, Array<crate::syntax::Arg> args_p3, crate::syntax::Range span_p4, crate::lower::model::OutTy t_p5) {
    return prism_rtl::make_rc<GlobalCall>(lx_p0, env_p1, qk_p2, args_p3, span_p4, t_p5);
}


/// ResultRepr: unbounded fn Lx, ValInfo -> OutTy
crate::lower::model::OutTy result_repr_f(const crate::lower::Lx& lx_p0, const crate::check::env::ValInfo& v_p1) {
    auto&& _m = prism_rtl::deref(v_p1.scheme_p).ty_p;
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
        auto&& r_p2 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
        return crate::lower::types::out_ty_of_f(lx_p0, crate::lower::types::peel_f(prism_rtl::deref(prism_rtl::deref(r_p2))));
    }
    {
        auto&& other_p3 = _m;
        return crate::lower::types::out_ty_of_f(lx_p0, crate::lower::types::peel_f(other_p3));
    }
}


prism_rtl::Turn<crate::lower::model::OutTy> ResultRepr::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& v_p1 = this->v_p1;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(v_p1).scheme_p).ty_p;
        prism_rtl::is<crate::check::types::Ty::TyFn>(_m) ? ({
        auto&& r_p2 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
        prism_rtl::more(prism_rtl::rc(crate::lower::types::OutTyOf(lx_p0, crate::lower::types::peel_f(prism_rtl::deref(prism_rtl::deref(r_p2))))));
    })
        : ({
        auto&& other_p3 = _m;
        prism_rtl::more(prism_rtl::rc(crate::lower::types::OutTyOf(lx_p0, crate::lower::types::peel_f(other_p3))));
    });
    });
}


/// `Start ResultRepr, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::OutTy> start_result_repr_f(crate::lower::Lx lx_p0, crate::check::env::ValInfo v_p1) {
    return prism_rtl::make_rc<ResultRepr>(lx_p0, v_p1);
}


/// AsInstance: unbounded fn Ex, OutTy, OutTy -> Vl
crate::lower::types::Vl as_instance_f(const crate::lower::model::Ex& call_p0, const crate::lower::model::OutTy& declared_p1, const crate::lower::model::OutTy& t_p2) {
    auto&& _m = std::tuple{declared_p1, t_p2};
    if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(std::get<0>(_m)) && prism_rtl::is<crate::lower::model::OutTy::OutFn>(std::get<1>(_m))) {
        auto&& pts_p3 = prism_rtl::as<crate::lower::model::OutTy::OutFn>(std::get<1>(_m)).a0;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{wrap_as_bounded_f(call_p0, pts_p3, t_p2), t_p2});
    }
    {
        return has_job_fn_f(declared_p1) && (!has_job_fn_f(t_p2))
            ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(Text::lit("a function value of its callee\'s own color inside the value a call returns, at a call that makes the color bounded")), t_p2})
            : crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{call_p0, t_p2});
    }
}


prism_rtl::Turn<crate::lower::types::Vl> AsInstance::cycle() const {
    const auto& call_p0 = this->call_p0;
    const auto& declared_p1 = this->declared_p1;
    const auto& t_p2 = this->t_p2;
    return ({
        auto&& _m = std::tuple{declared_p1, t_p2};
        prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(std::get<0>(_m)) && prism_rtl::is<crate::lower::model::OutTy::OutFn>(std::get<1>(_m)) ? ({
        auto&& pts_p3 = prism_rtl::as<crate::lower::model::OutTy::OutFn>(std::get<1>(_m)).a0;
        prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{wrap_as_bounded_f(call_p0, pts_p3, t_p2), t_p2}));
    })
        : ({
        auto call_p0x = call_p0;
        auto declared_p1x = declared_p1;
        auto t_p2x = t_p2;
        (crate::prelude::call_then(start_has_job_fn_f(declared_p1x), [=, call_p0x = std::move(call_p0x), t_p2x = std::move(t_p2x)](bool has_job_fn_f_33762) {
        return has_job_fn_f_33762 && (!has_job_fn_f(t_p2x))
            ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(Text::lit("a function value of its callee\'s own color inside the value a call returns, at a call that makes the color bounded")), t_p2x}))
            : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{call_p0x, t_p2x}));
    }));
    });
    });
}


/// `Start AsInstance, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_as_instance_f(crate::lower::model::Ex call_p0, crate::lower::model::OutTy declared_p1, crate::lower::model::OutTy t_p2) {
    return prism_rtl::make_rc<AsInstance>(call_p0, declared_p1, t_p2);
}


/// HasJobFn: unbounded fn OutTy -> Bool
bool has_job_fn_f(const crate::lower::model::OutTy& t_p0) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t_p0)) {
        auto&& i_p1 = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t_p0).a0;
        return has_job_fn_f(prism_rtl::deref(prism_rtl::deref(i_p1)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p0)) {
        auto&& i_p2 = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t_p0).a0;
        return has_job_fn_f(prism_rtl::deref(prism_rtl::deref(i_p2)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutArray>(t_p0)) {
        auto&& i_p3 = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t_p0).a0;
        return has_job_fn_f(prism_rtl::deref(prism_rtl::deref(i_p3)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(t_p0)) {
        auto&& k_p4 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p0).a0;
        auto&& v_p5 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p0).a1;
        return has_job_fn_f(prism_rtl::deref(prism_rtl::deref(k_p4))) || has_job_fn_f(prism_rtl::deref(prism_rtl::deref(v_p5)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p0)) {
        auto&& ts_p6 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p0).a0;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ts_p6, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto f_p7 = p0;
                    auto x_p8 = p1;
                    (prism_rtl::finished(std::move(f_p7) || has_job_fn_f(x_p8)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p0)) {
        auto&& ts_p9 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a1;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ts_p9, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto f_pa = p0;
                    auto x_pb = p1;
                    (prism_rtl::finished(std::move(f_pa) || has_job_fn_f(x_pb)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(t_p0)) {
        auto&& ps_pc = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p0).a0;
        auto&& r_pd = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p0).a1;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ps_pc, has_job_fn_f(prism_rtl::deref(prism_rtl::deref(r_pd))), static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto f_pe = p0;
                    auto x_pf = p1;
                    (prism_rtl::finished(std::move(f_pe) || has_job_fn_f(x_pf)));
                });
            }));
        }))));
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> HasJobFn::cycle() const {
    const auto& t_p0 = this->t_p0;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t_p0) ? prism_rtl::finished(true)
        : prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t_p0) ? ({
        auto&& i_p1 = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t_p0).a0;
        prism_rtl::more(prism_rtl::rc(HasJobFn(prism_rtl::deref(prism_rtl::deref(i_p1)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p0) ? ({
        auto&& i_p2 = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t_p0).a0;
        prism_rtl::more(prism_rtl::rc(HasJobFn(prism_rtl::deref(prism_rtl::deref(i_p2)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutArray>(t_p0) ? ({
        auto&& i_p3 = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t_p0).a0;
        prism_rtl::more(prism_rtl::rc(HasJobFn(prism_rtl::deref(prism_rtl::deref(i_p3)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutMap>(t_p0) ? ({
        auto&& k_p4 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p0).a0;
        auto&& v_p5 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p0).a1;
        ({
        auto k_p4x = prism_rtl::deref(prism_rtl::deref(k_p4));
        auto v_p5x = prism_rtl::deref(prism_rtl::deref(v_p5));
        (crate::prelude::call_then(start_has_job_fn_f(k_p4x), [=, v_p5x = std::move(v_p5x)](bool has_job_fn_f_34163) { return prism_rtl::finished(has_job_fn_f_34163 || has_job_fn_f(v_p5x)); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p0) ? ({
        auto&& ts_p6 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p0).a0;
        crate::prelude::fold_job(ts_p6, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto f_p7 = p0;
                auto x_p8 = p1;
                (prism_rtl::finished(std::move(f_p7) || has_job_fn_f(x_p8)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p0) ? ({
        auto&& ts_p9 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a1;
        crate::prelude::fold_job(ts_p9, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto f_pa = p0;
                auto x_pb = p1;
                (prism_rtl::finished(std::move(f_pa) || has_job_fn_f(x_pb)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutFn>(t_p0) ? ({
        auto&& ps_pc = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p0).a0;
        auto&& r_pd = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p0).a1;
        ({
        auto ps_pcx = ps_pc;
        auto r_pdx = prism_rtl::deref(prism_rtl::deref(r_pd));
        (crate::prelude::call_then(start_has_job_fn_f(r_pdx), [=, ps_pcx = std::move(ps_pcx)](bool has_job_fn_f_34338) {
        return crate::prelude::fold_job(ps_pcx, has_job_fn_f_34338, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto f_pe = p0;
                    auto x_pf = p1;
                    (prism_rtl::finished(std::move(f_pe) || has_job_fn_f(x_pf)));
                });
            }));
        })))->cycle();
    }));
    });
    })
        : prism_rtl::finished(false);
    });
}


/// `Start HasJobFn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_has_job_fn_f(crate::lower::model::OutTy t_p0) {
    return prism_rtl::make_rc<HasJobFn>(t_p0);
}


/// WrapAsBounded: fn Ex, [OutTy], OutTy -> Ex
crate::lower::model::Ex wrap_as_bounded_f(const crate::lower::model::Ex& f_p0, const Array<crate::lower::model::OutTy>& pts_p1, const crate::lower::model::OutTy& target_p2) {
    auto names_p3 = crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(pts_p1)), [&](const Nat& i_p7) { return prism_rtl::cat("a", i_p7); });
    auto pas_p4 = crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(pts_p1)), [&](const Nat& i_p8) { return crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{crate::prelude::or_(crate::prelude::index(names_p3, i_p8), Text::lit("a"))})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(crate::prelude::or_(crate::prelude::index(pts_p1, i_p8), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})))})}); });
    auto arg_p5 = crate::prelude::len(pts_p1) == Nat(1u)
        ? crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("a0")}))})
        : crate::lower::model::Ex(crate::lower::model::Ex::XTuple{crate::prelude::each(names_p3, [&](const Text& nm_p9) { return crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{nm_p9}))}); })});
    auto body_p6 = crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(Text::lit("run_to_end")), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XApply{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("job_fn")})), Array(std::vector{arg_p5})})})});
    return crate::lower::model::Ex(crate::lower::model::Ex::XBlock{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("job_fn")}), f_p0})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, pas_p4, prism_rtl::rc(body_p6)})})})), target_p2}))});
}


/// ArgsFor: unbounded fn Lx, Env, ValInfo, [Arg] -> [Ex]
Array<crate::lower::model::Ex> args_for_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::check::env::ValInfo& v_p2, const Array<crate::syntax::Arg>& args_p3) {
    auto ps_p4 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
        auto&& _m = prism_rtl::deref(v_p2.scheme_p).ty_p;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& xs_p5 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            _v.set(xs_p5);
            goto _done;
        }
        {
            _v.set(Array<crate::check::types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(args_p3)), ({
        auto args_p3x = args_p3;
        auto ps_p4x = ps_p4;
        auto lx_p0x = lx_p0;
        auto env_p1x = env_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Nat)>>(prism_rtl::rc([=, args_p3x = std::move(args_p3x), ps_p4x = std::move(ps_p4x), lx_p0x = std::move(lx_p0x), env_p1x = std::move(env_p1x)](Nat p0) {
        return ({
            auto args_p3xy = args_p3x;
            auto ps_p4xy = ps_p4x;
            auto lx_p0xy = lx_p0x;
            auto env_p1xy = env_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, args_p3xy = std::move(args_p3xy), ps_p4xy = std::move(ps_p4xy), lx_p0xy = std::move(lx_p0xy), env_p1xy = std::move(env_p1xy)]() {
            return ({
                auto i_p6 = p0;
                ({
                auto a_p7 = crate::prelude::or_(crate::prelude::index(args_p3xy, i_p6), crate::syntax::Arg{.name_o = std::optional<crate::syntax::Ident>{}, .value_p = dummy_expr_p(), .span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}});
                auto is_try_p8 = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = crate::lower::types::peel_f(crate::prelude::or_(crate::prelude::index(ps_p4xy, i_p6), crate::check::types::Ty(crate::check::types::Ty::TyErr{})));
                    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
                        auto&& m35511_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
                        if (m35511_0_0 == Text::lit("~")) {
                            _v.set(true);
                            goto _done;
                        }
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto is_error_p9 = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0xy, prism_rtl::deref(prism_rtl::deref(a_p7).value_p).span_p));
                    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
                        auto&& m35628_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
                        if (m35628_0_0 == Text::lit("Prelude.Error")) {
                            _v.set(true);
                            goto _done;
                        }
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto to_unbounded_pa = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = crate::lower::types::peel_f(crate::prelude::or_(crate::prelude::index(ps_p4xy, i_p6), crate::check::types::Ty(crate::check::types::Ty::TyErr{})));
                    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CBound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0)) {
                        _v.set(false);
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
                        _v.set(true);
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                (std::move(is_try_p8) && std::move(is_error_p9)
                ? crate::prelude::call_then(start_value_of_f(lx_p0xy, env_p1xy, prism_rtl::deref(a_p7).value_p), [=](crate::lower::types::Vl value_of_f_35977) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{crate::lower::types::own_f(value_of_f_35977)})}))})); })
                : std::move(to_unbounded_pa)
                ? crate::prelude::call_then(start_as_job_value_f(lx_p0xy, env_p1xy, prism_rtl::deref(a_p7).value_p), [=](crate::lower::model::Ex as_job_value_f_36042) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(as_job_value_f_36042)})); })
                : prism_rtl::more(prism_rtl::rc(Argument(lx_p0xy, env_p1xy, prism_rtl::deref(a_p7).value_p))));
            });
            });
        })));
        });
    })));
    })));
}


prism_rtl::Turn<Array<crate::lower::model::Ex>> ArgsFor::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& v_p2 = this->v_p2;
    const auto& args_p3 = this->args_p3;
    auto ps_p4 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(v_p2).scheme_p).ty_p;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& xs_p5 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            _v.set(xs_p5);
            goto _done;
        }
        {
            _v.set(Array<crate::check::types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(args_p3)), ({
        auto args_p3x = args_p3;
        auto ps_p4x = ps_p4;
        auto lx_p0x = lx_p0;
        auto env_p1x = env_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Nat)>>(prism_rtl::rc([=, args_p3x = std::move(args_p3x), ps_p4x = std::move(ps_p4x), lx_p0x = std::move(lx_p0x), env_p1x = std::move(env_p1x)](Nat p0) {
        return ({
            auto args_p3xy = args_p3x;
            auto ps_p4xy = ps_p4x;
            auto lx_p0xy = lx_p0x;
            auto env_p1xy = env_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, args_p3xy = std::move(args_p3xy), ps_p4xy = std::move(ps_p4xy), lx_p0xy = std::move(lx_p0xy), env_p1xy = std::move(env_p1xy)]() {
            return ({
                auto i_p6 = p0;
                ({
                auto a_p7 = crate::prelude::or_(crate::prelude::index(args_p3xy, i_p6), crate::syntax::Arg{.name_o = std::optional<crate::syntax::Ident>{}, .value_p = dummy_expr_p(), .span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}});
                auto is_try_p8 = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = crate::lower::types::peel_f(crate::prelude::or_(crate::prelude::index(ps_p4xy, i_p6), crate::check::types::Ty(crate::check::types::Ty::TyErr{})));
                    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
                        auto&& m35511_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
                        if (m35511_0_0 == Text::lit("~")) {
                            _v.set(true);
                            goto _done;
                        }
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto is_error_p9 = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0xy, prism_rtl::deref(prism_rtl::deref(a_p7).value_p).span_p));
                    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
                        auto&& m35628_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
                        if (m35628_0_0 == Text::lit("Prelude.Error")) {
                            _v.set(true);
                            goto _done;
                        }
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto to_unbounded_pa = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = crate::lower::types::peel_f(crate::prelude::or_(crate::prelude::index(ps_p4xy, i_p6), crate::check::types::Ty(crate::check::types::Ty::TyErr{})));
                    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CBound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0)) {
                        _v.set(false);
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
                        _v.set(true);
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                (std::move(is_try_p8) && std::move(is_error_p9)
                ? crate::prelude::call_then(start_value_of_f(lx_p0xy, env_p1xy, prism_rtl::deref(a_p7).value_p), [=](crate::lower::types::Vl value_of_f_35977) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{crate::lower::types::own_f(value_of_f_35977)})}))})); })
                : std::move(to_unbounded_pa)
                ? crate::prelude::call_then(start_as_job_value_f(lx_p0xy, env_p1xy, prism_rtl::deref(a_p7).value_p), [=](crate::lower::model::Ex as_job_value_f_36042) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(as_job_value_f_36042)})); })
                : prism_rtl::more(prism_rtl::rc(Argument(lx_p0xy, env_p1xy, prism_rtl::deref(a_p7).value_p))));
            });
            });
        })));
        });
    })));
    }))->cycle();
}

}  // namespace crate::lower::expr
