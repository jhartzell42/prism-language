// The module `Lower.Expr`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <lower/expr/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Lower.Expr`, from `target/bootstrap/cpp-src/prismc/lower/expr.prism`.
namespace crate::lower::expr {

/// Escape: fn Text -> Text
Text escape(const Text& t_p0) {
    return crate::syntax::lexer::chars::map_chars(t_p0, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Text)>>(prism_rtl::rc([=](Text p0) {
        return once_job([=]() {
            return ({
                auto c_p1 = p0;
                (prism_rtl::finished(char_escape(c_p1)));
            });
        });
    })));
}


/// CharEscape: fn Text -> Text
Text char_escape(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("\\")) {
            return Text::lit("\\\\");
        }
    }
    {
        auto&& c1_0 = text0;
        if (c1_0 == Text::lit("\"")) {
            return Text::lit("\\\"");
        }
    }
    {
        auto&& c2_0 = text0;
        if (c2_0 == Text::lit("\n")) {
            return Text::lit("\\n");
        }
    }
    {
        auto&& c3_0 = text0;
        if (c3_0 == Text::lit("\t")) {
            return Text::lit("\\t");
        }
    }
    {
        auto&& c4_0 = text0;
        if (c4_0 == Text::lit("\r")) {
            return Text::lit("\\r");
        }
    }
    {
        auto&& c5_0 = text0;
        if (c5_0 == Text::lit("\000"sv)) {
            return Text::lit("\\0");
        }
    }
    {
        auto&& c6_0 = text0;
        if (c6_0 == Text::lit("\'")) {
            return Text::lit("\\\'");
        }
    }
    {
        auto&& c_p0 = text0;
        return c_p0;
    }
}


/// Number: fn OutTy, Text, Bool -> Ex
crate::lower::model::Ex number(const crate::lower::model::OutTy& t_p0, const Text& digits_p1, const bool& neg_p2) {
    auto clean_p3 = decimal_digits(concat(split_on(digits_p1, Text::lit("_"))));
    auto signed_p4 = neg_p2 ? prism_rtl::cat("-", clean_p3) : clean_p3;
    if (prism_rtl::is<crate::lower::model::OutTy::OutNat>(t_p0)) {
        return crate::lower::model::Ex(crate::lower::model::Ex::XNat{clean_p3});
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutInt>(t_p0)) {
        return crate::lower::model::Ex(crate::lower::model::Ex::XInt{signed_p4});
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutU8>(t_p0)) {
        return crate::lower::model::Ex(crate::lower::model::Ex::XByte{clean_p3});
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutFloat>(t_p0)) {
        return crate::lower::model::Ex(crate::lower::model::Ex::XFloat{crate::syntax::lexer::chars::contains(clean_p3, Text::lit("."))
            ? signed_p4
            : prism_rtl::cat(signed_p4, ".0")});
    }
    {
        return crate::lower::model::Ex(crate::lower::model::Ex::XInt{signed_p4});
    }
}


/// DecimalDigits: fn Text -> Text
Text decimal_digits(const Text& d_p0) {
    auto r_p1 = crate::syntax::lexer::chars::head(d_p0) == Text::lit("0")
        ? crate::syntax::lexer::chars::head(crate::syntax::lexer::chars::after_first(d_p0))
        : Text::lit("");
    auto base_p2 = r_p1 == Text::lit("x")
        ? Nat(16u)
        : r_p1 == Text::lit("o")
        ? Nat(8u)
        : r_p1 == Text::lit("b") ? Nat(2u) : Nat(10u);
    auto ds_p3 = base_p2 == Nat(10u)
        ? d_p0
        : crate::syntax::lexer::chars::after_first(crate::syntax::lexer::chars::after_first(d_p0));
    return (crate::syntax::lexer::chars::contains(d_p0, Text::lit(".")) || (crate::syntax::lexer::chars::head(d_p0) != Text::lit("0"))) || (d_p0 == Text::lit("0"))
        ? d_p0
        : prism_rtl::cat(crate::syntax::lexer::chars::fold_chars(ds_p3, Nat(0u), ({
        auto base_p2_1 = base_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Nat>(std::tuple<Nat, Text>)>>(prism_rtl::rc([=, base_p2_1 = std::move(base_p2_1)](std::tuple<Nat, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto base_p2_1_2 = base_p2_1;
            once_job([=, base_p2_1_2 = std::move(base_p2_1_2)]() {
            return ({
                auto n_p4 = p0;
                auto c_p5 = p1;
                (prism_rtl::finished((n_p4 * base_p2_1_2) + crate::syntax::lexer::chars::hex_value(c_p5)));
            });
        });
        });
    })));
    })));
}


/// LiteralValue: unbounded fn Lx, Env, Literal, Range, Bool -> Vl
crate::lower::types::Vl literal_value(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Literal& l_p2, const crate::syntax::Range& span_p3, const bool& neg_p4) {
    auto t_p5 = crate::lower::types::out_ty_of(lx_p0, crate::lower::types::peel(crate::lower::type_at(lx_p0, span_p3)));
    auto&& _m = l_p2.kind;
    if (prism_rtl::is<crate::syntax::LitKind::LInt>(_m)) {
        auto&& d_p6 = prism_rtl::as<crate::syntax::LitKind::LInt>(_m).a0;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{number(t_p5, d_p6, neg_p4), t_p5});
    }
    if (prism_rtl::is<crate::syntax::LitKind::LFloat>(_m)) {
        auto&& d_p7 = prism_rtl::as<crate::syntax::LitKind::LFloat>(_m).a0;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XFloat{neg_p4 ? prism_rtl::cat("-", d_p7) : d_p7}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutFloat{})});
    }
    if (prism_rtl::is<crate::syntax::LitKind::LChar>(_m)) {
        auto&& c_p8 = prism_rtl::as<crate::syntax::LitKind::LChar>(_m).a0;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XChar{c_p8}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutChar{})});
    }
    if (prism_rtl::is<crate::syntax::LitKind::LDuration>(_m)) {
        auto&& d_p9 = prism_rtl::as<crate::syntax::LitKind::LDuration>(_m).a0;
        auto&& u_pa = prism_rtl::as<crate::syntax::LitKind::LDuration>(_m).a1;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(Text::lit("a Duration literal")), crate::lower::model::OutTy(crate::lower::model::OutTy::OutDuration{})});
    }
    if (prism_rtl::is<crate::syntax::LitKind::LText>(_m)) {
        auto&& segs_pb = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
        return text_value(lx_p0, env_p1, segs_pb);
    }
    if (prism_rtl::is<crate::syntax::LitKind::LRegex>(_m)) {
        auto&& r_pc = prism_rtl::as<crate::syntax::LitKind::LRegex>(_m).a0;
        auto&& _m = prism_rtl::deref(r_pc).replacement;
        if (prism_rtl::is_none(_m)) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XRegex{prism_rtl::deref(r_pc).pattern, prism_rtl::deref(r_pc).flags}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRegex{})});
        }
        if (prism_rtl::is_some(_m)) {
            auto&& t_pd = prism_rtl::some_of(_m);
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XReplacement{prism_rtl::deref(r_pc).pattern, t_pd, prism_rtl::deref(r_pc).flags}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutReplacement{})});
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::types::Vl> LiteralValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& l_p2 = this->l_p2;
    const auto& span_p3 = this->span_p3;
    const auto& neg_p4 = this->neg_p4;
    auto env_p1_1 = env_p1;
    auto l_p2_2 = l_p2;
    auto lx_p0_3 = lx_p0;
    auto neg_p4_4 = prism_rtl::deref(neg_p4);
    auto span_p3_5 = span_p3;
    return call_then(crate::lower::types::start_out_ty_of(lx_p0_3, crate::lower::types::peel(crate::lower::type_at(lx_p0_3, span_p3_5))), [=](crate::lower::model::OutTy out_ty_of_2743) {
        return ({
            auto t_p5 = out_ty_of_2743;
            ({
            auto&& _m = prism_rtl::deref(l_p2_2).kind;
            prism_rtl::is<crate::syntax::LitKind::LInt>(_m) ? ({
            auto&& d_p6 = prism_rtl::as<crate::syntax::LitKind::LInt>(_m).a0;
            prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{number(t_p5, d_p6, neg_p4_4), t_p5}));
        })
            : prism_rtl::is<crate::syntax::LitKind::LFloat>(_m) ? ({
            auto&& d_p7 = prism_rtl::as<crate::syntax::LitKind::LFloat>(_m).a0;
            prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XFloat{neg_p4_4 ? prism_rtl::cat("-", d_p7) : d_p7}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutFloat{})}));
        })
            : prism_rtl::is<crate::syntax::LitKind::LChar>(_m) ? ({
            auto&& c_p8 = prism_rtl::as<crate::syntax::LitKind::LChar>(_m).a0;
            prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XChar{c_p8}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutChar{})}));
        })
            : prism_rtl::is<crate::syntax::LitKind::LDuration>(_m) ? ({
            auto&& d_p9 = prism_rtl::as<crate::syntax::LitKind::LDuration>(_m).a0;
            auto&& u_pa = prism_rtl::as<crate::syntax::LitKind::LDuration>(_m).a1;
            prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(Text::lit("a Duration literal")), crate::lower::model::OutTy(crate::lower::model::OutTy::OutDuration{})}));
        })
            : prism_rtl::is<crate::syntax::LitKind::LText>(_m) ? ({
            auto&& segs_pb = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
            prism_rtl::more(prism_rtl::rc(TextValue(lx_p0_3, env_p1_1, segs_pb)));
        })
            : prism_rtl::is<crate::syntax::LitKind::LRegex>(_m) ? ({
            auto&& r_pc = prism_rtl::as<crate::syntax::LitKind::LRegex>(_m).a0;
            ({
            auto&& _m = prism_rtl::deref(r_pc).replacement;
            prism_rtl::is_none(_m) ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XRegex{prism_rtl::deref(r_pc).pattern, prism_rtl::deref(r_pc).flags}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRegex{})}))
            : prism_rtl::is_some(_m) ? ({
            auto&& t_pd = prism_rtl::some_of(_m);
            prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XReplacement{prism_rtl::deref(r_pc).pattern, t_pd, prism_rtl::deref(r_pc).flags}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutReplacement{})}));
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
}


/// `Start LiteralValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_literal_value(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Literal l_p2, crate::syntax::Range span_p3, bool neg_p4) {
    return prism_rtl::make_rc<LiteralValue>(lx_p0, env_p1, l_p2, span_p3, neg_p4);
}


/// TextValue: unbounded fn Lx, Env, [TextSeg] -> Vl
crate::lower::types::Vl text_value(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Array<crate::syntax::TextSeg>& segs_p2) {
    auto plain_p3 = fold(segs_p2, true, [&](const bool& ok_p4, const crate::syntax::TextSeg& s_p5) { return prism_rtl::deref(ok_p4) && is_plain_seg(s_p5); });
    return std::move(plain_p3)
        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XText{concat(each(segs_p2, [&](const crate::syntax::TextSeg& s_p6) { return plain_text(s_p6); }))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})})
        : crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XFormat{run_to_end(each_job(segs_p2, ({
        auto lx_p0_1 = lx_p0;
        auto env_p1_2 = env_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::TextSeg)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1), env_p1_2 = std::move(env_p1_2)](crate::syntax::TextSeg p0) {
        return ({
            auto lx_p0_1_3 = lx_p0_1;
            auto env_p1_2_3 = env_p1_2;
            entered(once_job([=, lx_p0_1_3 = std::move(lx_p0_1_3), env_p1_2_3 = std::move(env_p1_2_3)]() {
            return ({
                auto s_p7 = p0;
                (prism_rtl::more(prism_rtl::rc(SegEx(lx_p0_1_3, env_p1_2_3, s_p7))));
            });
        }));
        });
    })));
    })))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})});
}


prism_rtl::Turn<crate::lower::types::Vl> TextValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& segs_p2 = this->segs_p2;
    auto plain_p3 = fold(segs_p2, true, [&](const bool& ok_p4, const crate::syntax::TextSeg& s_p5) { return prism_rtl::deref(ok_p4) && is_plain_seg(s_p5); });
    return std::move(plain_p3)
        ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XText{concat(each(segs_p2, [&](const crate::syntax::TextSeg& s_p6) { return plain_text(s_p6); }))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})}))
        : ({
        auto env_p1_1 = env_p1;
        auto lx_p0_2 = lx_p0;
        auto segs_p2_3 = segs_p2;
        call_value(each_job(segs_p2_3, ({
        auto lx_p0_2_4 = lx_p0_2;
        auto env_p1_1_4 = env_p1_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::TextSeg)>>(prism_rtl::rc([=, lx_p0_2_4 = std::move(lx_p0_2_4), env_p1_1_4 = std::move(env_p1_1_4)](crate::syntax::TextSeg p0) {
        return ({
            auto lx_p0_2_4_4 = lx_p0_2_4;
            auto env_p1_1_4_4 = env_p1_1_4;
            entered(once_job([=, lx_p0_2_4_4 = std::move(lx_p0_2_4_4), env_p1_1_4_4 = std::move(env_p1_1_4_4)]() {
            return ({
                auto s_p7 = p0;
                (prism_rtl::more(prism_rtl::rc(SegEx(lx_p0_2_4_4, env_p1_1_4_4, s_p7))));
            });
        }));
        });
    })));
    })), [=](Array<crate::lower::model::Ex> each_3675) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XFormat{each_3675}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})})); });
    });
}


/// `Start TextValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_text_value(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Array<crate::syntax::TextSeg> segs_p2) {
    return prism_rtl::make_rc<TextValue>(lx_p0, env_p1, segs_p2);
}


/// IsPlainSeg: fn TextSeg -> Bool
bool is_plain_seg(const crate::syntax::TextSeg& text_seg0) {
    if (prism_rtl::is<crate::syntax::TextSeg::SegPlain>(text_seg0)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(text_seg0)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// PlainText: fn TextSeg -> Text
Text plain_text(const crate::syntax::TextSeg& text_seg0) {
    if (prism_rtl::is<crate::syntax::TextSeg::SegPlain>(text_seg0)) {
        auto&& t_p0 = prism_rtl::as<crate::syntax::TextSeg::SegPlain>(text_seg0).a0;
        return t_p0;
    }
    if (prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(text_seg0)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SegEx: unbounded fn Lx, Env, TextSeg -> Ex
crate::lower::model::Ex seg_ex(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::TextSeg& text_seg2) {
    if (prism_rtl::is<crate::syntax::TextSeg::SegPlain>(text_seg2)) {
        auto&& t_p2 = prism_rtl::as<crate::syntax::TextSeg::SegPlain>(text_seg2).a0;
        return crate::lower::model::Ex(crate::lower::model::Ex::XText{t_p2});
    }
    if (prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(text_seg2)) {
        auto&& e_p5 = prism_rtl::as<crate::syntax::TextSeg::SegPlaceholder>(text_seg2).a0;
        auto v_p6 = value_of(lx_p0, env_p1, e_p5);
        return shown_part(v_p6);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::model::Ex> SegEx::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& text_seg2 = this->text_seg2;
    return ({
        prism_rtl::is<crate::syntax::TextSeg::SegPlain>(text_seg2) ? ({
        auto&& t_p2 = prism_rtl::as<crate::syntax::TextSeg::SegPlain>(text_seg2).a0;
        prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XText{t_p2}));
    })
        : prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(text_seg2) ? ({
        auto&& e_p5 = prism_rtl::as<crate::syntax::TextSeg::SegPlaceholder>(text_seg2).a0;
        ({
        auto e_p5_1 = e_p5;
        auto env_p1_2 = env_p1;
        auto lx_p0_3 = lx_p0;
        call_then(start_value_of(lx_p0_3, env_p1_2, e_p5_1), [=](crate::lower::types::Vl value_of_4074) {
        return ({
            auto v_p6 = value_of_4074;
            (prism_rtl::finished(shown_part(v_p6)));
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SegEx, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_seg_ex(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::TextSeg text_seg2) {
    return prism_rtl::make_rc<SegEx>(lx_p0, env_p1, text_seg2);
}


/// ShownPart: fn Vl -> Ex
crate::lower::model::Ex shown_part(const crate::lower::types::Vl& v_p0) {
    auto&& _m = crate::lower::types::value_ty(v_p0);
    if (prism_rtl::is<crate::lower::model::OutTy::OutText>(_m)) {
        return crate::lower::types::ref_(v_p0);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutChar>(_m)) {
        return crate::lower::types::ref_(v_p0);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNat>(_m)) {
        return crate::lower::types::ref_(v_p0);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutInt>(_m)) {
        return crate::lower::types::ref_(v_p0);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutU8>(_m)) {
        return crate::lower::types::ref_(v_p0);
    }
    {
        return crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("show"), Array(std::vector{crate::lower::types::ref_(v_p0)})});
    }
}


/// Refusal: fn Text -> Ex
crate::lower::model::Ex refusal(const Text& what_p0) {
    return crate::lower::model::Ex(crate::lower::model::Ex::XRefusal{what_p0});
}


/// TryOf: fn Ex -> Ex
crate::lower::model::Ex try_of(const crate::lower::model::Ex& x_p0) {
    return is_named_place(x_p0)
        ? refusal(prism_rtl::cat("`?` of the place `", crate::lower::types::place_stem(x_p0), "`, which C++\'s TRY would move out of (only a temporary may be tried)"))
        : crate::lower::model::Ex(crate::lower::model::Ex::XTry{prism_rtl::rc(x_p0)});
}


/// IsNamedPlace: fn Ex -> Bool
bool is_named_place(const crate::lower::model::Ex& x_p0) {
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XPart>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTarget>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRef>(x_p0)) {
        auto&& y_p1 = prism_rtl::as<crate::lower::model::Ex::XRef>(x_p0).a0;
        return is_named_place(prism_rtl::deref(prism_rtl::deref(y_p1)));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XDeref>(x_p0)) {
        auto&& y_p2 = prism_rtl::as<crate::lower::model::Ex::XDeref>(x_p0).a0;
        return is_named_place(prism_rtl::deref(prism_rtl::deref(y_p2)));
    }
    {
        return false;
    }
}


/// let loweringRefusal
Text lowering_refusal() {
    return Text::lit("prismc does not lower ");
}


/// RefusalDo: fn Text -> Do
crate::lower::model::Do refusal_do(const Text& what_p0) {
    return crate::lower::model::Do(crate::lower::model::Do::DoExpr{refusal(what_p0)});
}


/// ValueOf: unbounded fn Lx, Env, Expr -> Vl
crate::lower::types::Vl value_of(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2) {
    auto&& _m = crate::prelude::get(env_p1.spans, crate::lower::place_key(lx_p0, e_p2.span));
    if (prism_rtl::is_some(_m)) {
        auto&& v_p3 = prism_rtl::some_of(_m);
        return v_p3;
    }
    if (prism_rtl::is_none(_m)) {
        return unbound_value_of(lx_p0, env_p1, e_p2);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::types::Vl> ValueOf::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& e_p2 = this->e_p2;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(env_p1).spans, crate::lower::place_key(lx_p0, prism_rtl::deref(e_p2).span));
        prism_rtl::is_some(_m) ? ({
        auto&& v_p3 = prism_rtl::some_of(_m);
        prism_rtl::finished(v_p3);
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(UnboundValueOf(lx_p0, env_p1, e_p2)))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ValueOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_value_of(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2) {
    return prism_rtl::make_rc<ValueOf>(lx_p0, env_p1, e_p2);
}


/// UnboundValueOf: unbounded fn Lx, Env, Expr -> Vl
crate::lower::types::Vl unbound_value_of(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2) {
    return is_event_value(lx_p0, env_p1, e_p2)
        ? event_value_of(lx_p0, env_p1, e_p2)
        : value_by_kind(lx_p0, env_p1, e_p2);
}


prism_rtl::Turn<crate::lower::types::Vl> UnboundValueOf::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& e_p2 = this->e_p2;
    auto e_p2_1 = e_p2;
    auto env_p1_2 = env_p1;
    auto lx_p0_3 = lx_p0;
    return call_then(start_is_event_value(lx_p0_3, env_p1_2, e_p2_1), [=](bool is_event_value_6176) {
        return is_event_value_6176
            ? prism_rtl::more(prism_rtl::rc(EventValueOf(lx_p0_3, env_p1_2, e_p2_1)))
            : prism_rtl::more(prism_rtl::rc(ValueByKind(lx_p0_3, env_p1_2, e_p2_1)));
    });
}


/// `Start UnboundValueOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_unbound_value_of(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2) {
    return prism_rtl::make_rc<UnboundValueOf>(lx_p0, env_p1, e_p2);
}


/// IsEventValue: unbounded fn Lx, Env, Expr -> Bool
bool is_event_value(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2) {
    auto&& _m = prism_rtl::deref(e_p2.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        return false;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        return false;
    }
    {
        return ((crate::lower::types::layer_of(crate::lower::type_at(lx_p0, e_p2.span)) == crate::lower::types::Layer(crate::lower::types::Layer::LyEv{})) && (!fold(crate::lower::node_::dynamics::operands(e_p2), false, [&](const bool& bound_p3, const crate::syntax::Expr& c_p4) { return prism_rtl::deref(bound_p3) || crate::check::env::has_key(env_p1.spans, crate::lower::place_key(lx_p0, prism_rtl::deref(c_p4).span)); }))) && has_event_source(lx_p0, env_p1, e_p2);
    }
}


prism_rtl::Turn<bool> IsEventValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& e_p2 = this->e_p2;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p2).kind);
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? prism_rtl::finished(false)
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? prism_rtl::finished(false)
        : prism_rtl::finished(((crate::lower::types::layer_of(crate::lower::type_at(lx_p0, prism_rtl::deref(e_p2).span)) == crate::lower::types::Layer(crate::lower::types::Layer::LyEv{})) && (!fold(crate::lower::node_::dynamics::operands(e_p2), false, [&](const bool& bound_p3, const crate::syntax::Expr& c_p4) { return prism_rtl::deref(bound_p3) || crate::check::env::has_key(prism_rtl::deref(env_p1).spans, crate::lower::place_key(lx_p0, prism_rtl::deref(c_p4).span)); }))) && has_event_source(lx_p0, env_p1, e_p2));
    });
}


/// `Start IsEventValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_event_value(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2) {
    return prism_rtl::make_rc<IsEventValue>(lx_p0, env_p1, e_p2);
}


/// HasEventSource: unbounded fn Lx, Env, Expr -> Bool
bool has_event_source(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2) {
    return run_to_end(fold_job(crate::lower::node_::dynamics::operands(e_p2), false, ({
        auto lx_p0_1 = lx_p0;
        auto env_p1_2 = env_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Expr>)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1), env_p1_2 = std::move(env_p1_2)](std::tuple<bool, crate::syntax::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0_1_3 = lx_p0_1;
            auto env_p1_2_3 = env_p1_2;
            entered(once_job([=, lx_p0_1_3 = std::move(lx_p0_1_3), env_p1_2_3 = std::move(env_p1_2_3)]() {
            return ({
                auto found_p3 = p0;
                auto c_p4 = p1;
                (prism_rtl::finished(std::move(found_p3) || is_event_source(lx_p0_1_3, env_p1_2_3, c_p4)));
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<bool> HasEventSource::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& e_p2 = this->e_p2;
    return fold_job(crate::lower::node_::dynamics::operands(e_p2), false, ({
        auto lx_p0_1 = lx_p0;
        auto env_p1_2 = env_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Expr>)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1), env_p1_2 = std::move(env_p1_2)](std::tuple<bool, crate::syntax::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0_1_3 = lx_p0_1;
            auto env_p1_2_3 = env_p1_2;
            entered(once_job([=, lx_p0_1_3 = std::move(lx_p0_1_3), env_p1_2_3 = std::move(env_p1_2_3)]() {
            return ({
                auto found_p3 = p0;
                auto c_p4 = p1;
                (prism_rtl::finished(std::move(found_p3) || is_event_source(lx_p0_1_3, env_p1_2_3, c_p4)));
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start HasEventSource, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_has_event_source(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2) {
    return prism_rtl::make_rc<HasEventSource>(lx_p0, env_p1, e_p2);
}


/// IsEventSource: unbounded fn Lx, Env, Expr -> Bool
bool is_event_source(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& c_p2) {
    return crate::lower::types::layer_of(crate::lower::type_at(lx_p0, c_p2.span)) != crate::lower::types::Layer(crate::lower::types::Layer::LyEv{})
        ? false
        : ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = prism_rtl::deref(c_p2.kind);
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n_p3 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = crate::prelude::get(env_p1.names, crate::check::env::sname_key(n_p3));
                if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)) && prism_rtl::is<crate::lower::model::OutTy::OutEvent>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2)) {
                    _v.set(true);
                    goto _done;
                }
                if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(_m))) {
                    _v.set(crate::check::env::has_key(env_p1.names, prism_rtl::cat(crate::check::env::sname_key(n_p3), "#port")));
                    goto _done;
                }
                {
                    _v.set(false);
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
            auto&& x_p4 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
            _v.set(is_event_source(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p4))));
            goto _done;
        }
        {
            _v.set(has_event_source(lx_p0, env_p1, c_p2));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<bool> IsEventSource::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& c_p2 = this->c_p2;
    return crate::lower::types::layer_of(crate::lower::type_at(lx_p0, prism_rtl::deref(c_p2).span)) != crate::lower::types::Layer(crate::lower::types::Layer::LyEv{})
        ? prism_rtl::finished(false)
        : ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(c_p2).kind);
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n_p3 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        ({
        auto&& _m = crate::prelude::get(env_p1->names, crate::check::env::sname_key(n_p3));
        prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)) && prism_rtl::is<crate::lower::model::OutTy::OutEvent>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2) ? prism_rtl::finished(true)
        : prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(_m)) ? prism_rtl::finished(crate::check::env::has_key(env_p1->names, prism_rtl::cat(crate::check::env::sname_key(n_p3), "#port")))
        : prism_rtl::finished(false);
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x_p4 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(IsEventSource(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p4)))));
    })
        : prism_rtl::more(prism_rtl::rc(HasEventSource(lx_p0, env_p1, c_p2)));
    });
}


/// `Start IsEventSource, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_event_source(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr c_p2) {
    return prism_rtl::make_rc<IsEventSource>(lx_p0, env_p1, c_p2);
}


/// EventValueOf: unbounded fn Lx, Env, Expr -> Vl
crate::lower::types::Vl event_value_of(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2) {
    auto t_p3 = crate::lower::types::out_ty_of(lx_p0, crate::lower::types::peel(crate::lower::type_at(lx_p0, e_p2.span)));
    auto et_p4 = crate::lower::model::OutTy(crate::lower::model::OutTy::OutEvent{prism_rtl::rc(t_p3)});
    auto filtered_o5 = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<crate::syntax::Arg>> _v;
        auto&& _m = prism_rtl::deref(e_p2.kind);
        if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
            auto&& c_p6 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
            auto&& args_p7 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
            _v.set(crate::lower::node_::dynamics::callee_key(lx_p0, prism_rtl::deref(prism_rtl::deref(c_p6))) == Text::lit("Prelude.!Filter")
                ? index(args_p7, Nat(0u))
                : std::optional<crate::syntax::Arg>{});
            goto _done;
        }
        {
            _v.set(std::optional<crate::syntax::Arg>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    if (prism_rtl::is_some(filtered_o5)) {
        auto&& a_p8 = prism_rtl::some_of(filtered_o5);
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::types::own(value_of(lx_p0, env_p1, a_p8->value))), Text::lit("filter_some"), Array<crate::lower::model::Ex>{}}), et_p4});
    }
    if (prism_rtl::is_none(filtered_o5)) {
        auto evs_p9 = filter(crate::lower::node_::dynamics::operands(e_p2), [&](const crate::syntax::Expr& x_pa) { return crate::lower::types::layer_of(crate::lower::type_at(lx_p0, prism_rtl::deref(x_pa).span)) == crate::lower::types::Layer(crate::lower::types::Layer::LyEv{}); });
        {
            auto&& m8243_0 = evs_p9;
            if (m8243_0.size() == 1u) {
                {
                    auto&& _c1 = index(m8243_0, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& one_pb = prism_rtl::some_of(_c1);
                        auto src_pc = crate::lower::types::own(value_of(lx_p0, env_p1, one_pb));
                        auto it_pd = crate::lower::types::out_ty_of(lx_p0, crate::lower::types::peel(crate::lower::type_at(lx_p0, prism_rtl::deref(one_pb).span)));
                        auto caps_pe = filter(crate::lower::types::with_instances(env_p1, read_names(crate::check::typed::print::exprs_in(e_p2))), [&](const Text& n_pi) {
                            return ({
                                __label__ _done;
                                prism_rtl::Slot<bool> _v;
                                auto&& _m = crate::prelude::get(env_p1.names, n_pi);
                                if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                                    _v.set(true);
                                    goto _done;
                                }
                                {
                                    _v.set(false);
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            });
                        });
                        auto [dos_pq, env1_pr] = fold(caps_pe, std::tuple{Array<crate::lower::model::Do>{}, env_p1}, [&](const std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>& _p0, const Text& n_pl) {
                            auto&& acc_pj = std::get<0>(_p0);
                            auto&& en_pk = std::get<1>(_p0);
                            return ({
                                __label__ _done;
                                prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
                                auto&& _m = crate::prelude::get(env_p1.names, n_pl);
                                if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                                    auto&& rs_pm = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                                    auto&& mode_pn = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                                    auto&& ct_po = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                                    _v.set(({
                                        auto local_pp = prism_rtl::cat(crate::lower::types::place_stem(rs_pm), "_c");
                                        std::tuple{crate::prelude::push(acc_pj, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{local_pp}), crate::lower::types::own(crate::lower::types::local_place(rs_pm, mode_pn, ct_po))})), crate::lower::types::bind(en_pk, n_pl, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{local_pp}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), ct_po}))};
                                    }));
                                    goto _done;
                                }
                                {
                                    _v.set(std::tuple{acc_pj, en_pk});
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            });
                        });
                        auto env2_pf = crate::lower::types::bind_span(env1_pr, crate::lower::place_key(lx_p0, prism_rtl::deref(one_pb).span), crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("y_ev")}), crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), it_pd}));
                        auto body_pg = crate::lower::types::own(value_by_kind(lx_p0, env2_pf, e_p2));
                        auto mapped_ph = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(src_pc), Text::lit("map"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("y_ev")})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(it_pd)})})}), prism_rtl::rc(body_pg)})})});
                        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{crate::prelude::push(dos_pq, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("src_ev")}), src_pc})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("src_ev")})), Text::lit("map"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("y_ev")})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(it_pd)})})}), prism_rtl::rc(body_pg)})})}))}), et_p4});
                    }
                }
            }
        }
        {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(Text::lit("an event value of several events")), et_p4});
        }
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::types::Vl> EventValueOf::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& e_p2 = this->e_p2;
    auto e_p2_1 = e_p2;
    auto env_p1_2 = env_p1;
    auto lx_p0_3 = lx_p0;
    return call_then(crate::lower::types::start_out_ty_of(lx_p0_3, crate::lower::types::peel(crate::lower::type_at(lx_p0_3, prism_rtl::deref(e_p2_1).span))), [=](crate::lower::model::OutTy out_ty_of_7802) {
        return ({
            auto t_p3 = out_ty_of_7802;
            auto et_p4 = crate::lower::model::OutTy(crate::lower::model::OutTy::OutEvent{prism_rtl::rc(t_p3)});
            auto filtered_o5 = ({
                __label__ _done;
                prism_rtl::Slot<std::optional<crate::syntax::Arg>> _v;
                auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p2_1).kind);
                if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
                    auto&& c_p6 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
                    auto&& args_p7 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
                    _v.set(crate::lower::node_::dynamics::callee_key(lx_p0_3, prism_rtl::deref(prism_rtl::deref(c_p6))) == Text::lit("Prelude.!Filter")
                        ? index(args_p7, Nat(0u))
                        : std::optional<crate::syntax::Arg>{});
                    goto _done;
                }
                {
                    _v.set(std::optional<crate::syntax::Arg>{});
                    goto _done;
                }
            _done:
                _v.take();
            });
            ({
            prism_rtl::is_some(filtered_o5) ? ({
            auto&& a_p8 = prism_rtl::some_of(filtered_o5);
            ({
            auto a_p8_4 = a_p8;
            call_then(start_value_of(lx_p0_3, env_p1_2, a_p8_4->value), [=](crate::lower::types::Vl value_of_8079) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::types::own(value_of_8079)), Text::lit("filter_some"), Array<crate::lower::model::Ex>{}}), et_p4})); });
        });
        })
            : prism_rtl::is_none(filtered_o5) ? ({
            auto evs_p9 = filter(crate::lower::node_::dynamics::operands(e_p2_1), [&](const crate::syntax::Expr& x_pa) { return crate::lower::types::layer_of(crate::lower::type_at(lx_p0_3, prism_rtl::deref(x_pa).span)) == crate::lower::types::Layer(crate::lower::types::Layer::LyEv{}); });
            ({
            ({
            auto&& m8243_0 = evs_p9;
            (m8243_0.size() == 1u) && ({
            auto&& _c1 = index(m8243_0, Nat(0u));
            prism_rtl::is_some(_c1);
        });
        }) ? ({
            auto&& m8243_0 = evs_p9;
            auto&& _c1 = index(m8243_0, Nat(0u));
            auto&& one_pb = prism_rtl::some_of(_c1);
            call_then(start_value_of(lx_p0_3, env_p1_2, one_pb), [=](crate::lower::types::Vl value_of_8314) {
            return ({
                auto src_pc = crate::lower::types::own(value_of_8314);
                call_then(crate::lower::types::start_out_ty_of(lx_p0_3, crate::lower::types::peel(crate::lower::type_at(lx_p0_3, prism_rtl::deref(one_pb).span))), [=, src_pc = std::move(src_pc)](crate::lower::model::OutTy out_ty_of_8365) {
                return ({
                    auto it_pd = out_ty_of_8365;
                    call_then(crate::check::typed::print::start_exprs_in(e_p2_1), [=, it_pd = std::move(it_pd)](Array<crate::syntax::Expr> exprs_in_8476) {
                    return call_then(start_read_names(exprs_in_8476), [=](Array<Text> read_names_8465) {
                        return ({
                            auto caps_pe = filter(crate::lower::types::with_instances(env_p1_2, read_names_8465), [&](const Text& n_pi) {
                                return ({
                                    __label__ _done;
                                    prism_rtl::Slot<bool> _v;
                                    auto&& _m = crate::prelude::get(env_p1_2->names, n_pi);
                                    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                                        _v.set(true);
                                        goto _done;
                                    }
                                    {
                                        _v.set(false);
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                });
                            });
                            auto [dos_pq, env1_pr] = fold(caps_pe, std::tuple{Array<crate::lower::model::Do>{}, env_p1_2}, [&](const std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>& _p0, const Text& n_pl) {
                                auto&& acc_pj = std::get<0>(_p0);
                                auto&& en_pk = std::get<1>(_p0);
                                return ({
                                    __label__ _done;
                                    prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
                                    auto&& _m = crate::prelude::get(env_p1_2->names, n_pl);
                                    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                                        auto&& rs_pm = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                                        auto&& mode_pn = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                                        auto&& ct_po = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                                        _v.set(({
                                            auto local_pp = prism_rtl::cat(crate::lower::types::place_stem(rs_pm), "_c");
                                            std::tuple{crate::prelude::push(acc_pj, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{local_pp}), crate::lower::types::own(crate::lower::types::local_place(rs_pm, mode_pn, ct_po))})), crate::lower::types::bind(en_pk, n_pl, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{local_pp}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), ct_po}))};
                                        }));
                                        goto _done;
                                    }
                                    {
                                        _v.set(std::tuple{acc_pj, en_pk});
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                });
                            });
                            auto env2_pf = crate::lower::types::bind_span(env1_pr, crate::lower::place_key(lx_p0_3, prism_rtl::deref(one_pb).span), crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("y_ev")}), crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), it_pd}));
                            call_then(start_value_by_kind(lx_p0_3, env2_pf, e_p2_1), [=](crate::lower::types::Vl value_by_kind_9172) {
                            return ({
                                auto body_pg = crate::lower::types::own(value_by_kind_9172);
                                auto mapped_ph = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(src_pc), Text::lit("map"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("y_ev")})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(it_pd)})})}), prism_rtl::rc(body_pg)})})});
                                (prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{crate::prelude::push(dos_pq, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("src_ev")}), src_pc})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("src_ev")})), Text::lit("map"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("y_ev")})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(it_pd)})})}), prism_rtl::rc(body_pg)})})}))}), et_p4})));
                            });
                        });
                        });
                    });
                });
                });
            });
            });
        });
        })
            : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(Text::lit("an event value of several events")), et_p4}));
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
}


/// `Start EventValueOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_event_value_of(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2) {
    return prism_rtl::make_rc<EventValueOf>(lx_p0, env_p1, e_p2);
}


/// ValueByKind: unbounded fn Lx, Env, Expr -> Vl
crate::lower::types::Vl value_by_kind(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2) {
    auto&& _m = crate::prelude::get(lx_p0.lifts, crate::lower::place_key(lx_p0, e_p2.span));
    if (prism_rtl::is_some(_m)) {
        auto&& ln_p3 = prism_rtl::some_of(_m);
        if (len(prism_rtl::deref(ln_p3).operands) > Nat(0u)) {
            return lifted_value(lx_p0, env_p1, e_p2, ln_p3);
        }
    }
    {
        return plain_value_by_kind(lx_p0, env_p1, e_p2);
    }
}


prism_rtl::Turn<crate::lower::types::Vl> ValueByKind::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& e_p2 = this->e_p2;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0).lifts, crate::lower::place_key(lx_p0, prism_rtl::deref(e_p2).span));
        prism_rtl::is_some(_m) && ({
        auto&& ln_p3 = prism_rtl::some_of(_m);
        (len(prism_rtl::deref(ln_p3).operands) > Nat(0u));
    }) ? ({
        auto&& ln_p3 = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(LiftedValue(lx_p0, env_p1, e_p2, ln_p3)));
    })
        : prism_rtl::more(prism_rtl::rc(PlainValueByKind(lx_p0, env_p1, e_p2)));
    });
}


/// `Start ValueByKind, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_value_by_kind(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2) {
    return prism_rtl::make_rc<ValueByKind>(lx_p0, env_p1, e_p2);
}


/// LiftedValue: unbounded fn Lx, Env, Expr, LiftNote -> Vl
crate::lower::types::Vl lifted_value(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2, const crate::check::typed::LiftNote& ln_p3) {
    auto at_p4 = crate::lower::place_key(lx_p0, e_p2.span);
    auto t_p5 = crate::lower::types::out_ty_of(lx_p0, crate::lower::types::peel(crate::lower::type_at(lx_p0, e_p2.span)));
    auto inner_p6 = crate::lower::patterns::inner_ty(crate::lower::type_at(lx_p0, e_p2.span));
    auto self_operand_p7 = fold(ln_p3.operands, false, [&](const bool& f_p9, const crate::syntax::Range& r_pa) { return prism_rtl::deref(f_p9) || (r_pa == e_p2.span); });
    auto missing_p8 = fold(ln_p3.operands, false, [&](const bool& f_pb, const crate::syntax::Range& r_pc) { return prism_rtl::deref(f_pb) || (operand_at(e_p2, r_pc) == std::optional<crate::syntax::Expr>{}); });
    return ((inner_p6 == crate::check::types::Ty(crate::check::types::Ty::TyErr{})) || std::move(self_operand_p7)) || std::move(missing_p8)
        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("a lift over `", ln_p3.sigil, "` at `", crate::lower::functions::src_text(lx_p0, lx_p0.file, e_p2.span), "` of ", kind_words(prism_rtl::deref(e_p2.kind)))), t_p5})
        : ({
        auto lx1_pd = ({
            crate::lower::Lx this_ = lx_p0;
            this_.tys = insert(this_.tys, at_p4, inner_p6);
            this_.lifts = insert(this_.lifts, at_p4, crate::check::typed::LiftNote{.at = ln_p3.at, .sigil = ln_p3.sigil, .operands = Array<crate::syntax::Range>{}});
            (std::move(this_));
        });
        auto lx2_pe = fold(ln_p3.operands, lx1_pd, [&](const crate::lower::Lx& l_pf, const crate::syntax::Range& r_pg) {
            return ({
                crate::lower::Lx this_ = l_pf;
                this_.tys = insert(this_.tys, crate::lower::place_key(lx_p0, r_pg), crate::lower::patterns::inner_ty(crate::lower::type_at(lx_p0, r_pg)));
                (std::move(this_));
            });
        });
        (crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{lift_operands(lx_p0, lx2_pe, env_p1, e_p2, ln_p3.sigil, ln_p3.operands, t_p5), t_p5}));
    });
}


prism_rtl::Turn<crate::lower::types::Vl> LiftedValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& e_p2 = this->e_p2;
    const auto& ln_p3 = this->ln_p3;
    auto at_p4 = crate::lower::place_key(lx_p0, prism_rtl::deref(e_p2).span);
    auto e_p2_1 = e_p2;
    auto env_p1_2 = env_p1;
    auto ln_p3_3 = ln_p3;
    auto lx_p0_4 = lx_p0;
    return call_then(crate::lower::types::start_out_ty_of(lx_p0_4, crate::lower::types::peel(crate::lower::type_at(lx_p0_4, prism_rtl::deref(e_p2_1).span))), [=](crate::lower::model::OutTy out_ty_of_10518) {
        return ({
            auto t_p5 = out_ty_of_10518;
            auto inner_p6 = crate::lower::patterns::inner_ty(crate::lower::type_at(lx_p0_4, prism_rtl::deref(e_p2_1).span));
            auto self_operand_p7 = fold(prism_rtl::deref(ln_p3_3).operands, false, [&](const bool& f_p9, const crate::syntax::Range& r_pa) { return prism_rtl::deref(f_p9) || (r_pa == prism_rtl::deref(e_p2_1).span); });
            auto missing_p8 = fold(prism_rtl::deref(ln_p3_3).operands, false, [&](const bool& f_pb, const crate::syntax::Range& r_pc) { return prism_rtl::deref(f_pb) || (operand_at(e_p2_1, r_pc) == std::optional<crate::syntax::Expr>{}); });
            ((inner_p6 == crate::check::types::Ty(crate::check::types::Ty::TyErr{})) || std::move(self_operand_p7)) || std::move(missing_p8)
            ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("a lift over `", prism_rtl::deref(ln_p3_3).sigil, "` at `", crate::lower::functions::src_text(lx_p0_4, lx_p0_4->file, prism_rtl::deref(e_p2_1).span), "` of ", kind_words(prism_rtl::deref(prism_rtl::deref(e_p2_1).kind)))), t_p5}))
            : ({
            auto lx1_pd = ({
                crate::lower::Lx this_ = lx_p0_4;
                this_.tys = insert(this_.tys, at_p4, inner_p6);
                this_.lifts = insert(this_.lifts, at_p4, crate::check::typed::LiftNote{.at = prism_rtl::deref(ln_p3_3).at, .sigil = prism_rtl::deref(ln_p3_3).sigil, .operands = Array<crate::syntax::Range>{}});
                (std::move(this_));
            });
            auto lx2_pe = fold(prism_rtl::deref(ln_p3_3).operands, lx1_pd, [&](const crate::lower::Lx& l_pf, const crate::syntax::Range& r_pg) {
                return ({
                    crate::lower::Lx this_ = l_pf;
                    this_.tys = insert(this_.tys, crate::lower::place_key(lx_p0_4, r_pg), crate::lower::patterns::inner_ty(crate::lower::type_at(lx_p0_4, r_pg)));
                    (std::move(this_));
                });
            });
            call_then(start_lift_operands(lx_p0_4, lx2_pe, env_p1_2, e_p2_1, prism_rtl::deref(ln_p3_3).sigil, prism_rtl::deref(ln_p3_3).operands, t_p5), [=](crate::lower::model::Ex lift_operands_11245) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{lift_operands_11245, t_p5})); });
        });
        });
    });
}


/// `Start LiftedValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_lifted_value(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2, crate::check::typed::LiftNote ln_p3) {
    return prism_rtl::make_rc<LiftedValue>(lx_p0, env_p1, e_p2, ln_p3);
}


/// LiftOperands: unbounded fn Lx, Lx, Env, Expr, Text, [Range], OutTy -> Ex
crate::lower::model::Ex lift_operands(const crate::lower::Lx& lx_p0, const crate::lower::Lx& lx_in_p1, const crate::lower::types::Env& env_p2, const crate::syntax::Expr& e_p3, const Text& sigil_p4, const Array<crate::syntax::Range>& operands_p5, const crate::lower::model::OutTy& t_p6) {
    {
        auto&& m11508_0 = operands_p5;
        if (m11508_0.size() == 0u) {
            return crate::lower::model::Ex(crate::lower::model::Ex::XCtor{sigil_p4 == Text::lit("~") ? Text::lit("Ok") : Text::lit("Some"), Array(std::vector{crate::lower::types::own(plain_value_by_kind(lx_in_p1, env_p2, e_p3))})});
        }
    }
    {
        auto r_p7 = or_(index(operands_p5, Nat(0u)), e_p3.span);
        auto sv_p8 = value_of(lx_p0, env_p2, or_(operand_at(e_p3, r_p7), dummy_expr()));
        auto it_p9 = crate::lower::types::out_ty_of(lx_p0, crate::lower::patterns::inner_ty(crate::lower::type_at(lx_p0, r_p7)));
        auto owned_pa = ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            if (prism_rtl::is<crate::lower::types::Vl::VlOwned>(sv_p8)) {
                _v.set(true);
                goto _done;
            }
            {
                _v.set(false);
                goto _done;
            }
        _done:
            _v.take();
        });
        auto mode_pb = std::move(owned_pa)
            ? crate::lower::types::Holding(crate::lower::types::Holding::Owned{})
            : crate::lower::types::Holding(crate::lower::types::Holding::ByRef{});
        auto x_pc = prism_rtl::cat("o", prism_rtl::deref(r_p7).start, "_", prism_rtl::deref(r_p7).end);
        auto env2_pd = crate::lower::types::bind_span(env_p2, crate::lower::place_key(lx_p0, r_p7), crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XVar{x_pc}), mode_pb, it_p9}));
        auto body_pe = lift_operands(lx_p0, lx_in_p1, env2_pd, e_p3, sigil_p4, drop(operands_p5, Nat(1u)), t_p6);
        auto fail_arm_pf = sigil_p4 == Text::lit("~")
            ? crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Err"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat(x_pc, "_e")})})}), .conds = Array<crate::lower::model::Cc>{}, .body = crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{crate::lower::types::own(crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat(x_pc, "_e")}), mode_pb, crate::lower::model::OutTy(crate::lower::model::OutTy::OutError{})}))})})}
            : crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{Text::lit("None")}), .conds = Array<crate::lower::model::Cc>{}, .body = crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XNone{})), t_p6})};
        auto arms_pg = Array(std::vector{crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{sigil_p4 == Text::lit("~") ? Text::lit("Ok") : Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{x_pc})})}), .conds = Array<crate::lower::model::Cc>{}, .body = body_pe}, fail_arm_pf});
        return crate::lower::model::Ex(crate::lower::model::Ex::XMatch{prism_rtl::rc(std::move(owned_pa)
            ? crate::lower::types::own(sv_p8)
            : crate::lower::types::ref_(sv_p8)), arms_pg, false, t_p6});
    }
}


prism_rtl::Turn<crate::lower::model::Ex> LiftOperands::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& lx_in_p1 = this->lx_in_p1;
    const auto& env_p2 = this->env_p2;
    const auto& e_p3 = this->e_p3;
    const auto& sigil_p4 = this->sigil_p4;
    const auto& operands_p5 = this->operands_p5;
    const auto& t_p6 = this->t_p6;
    return ({
        ({
        auto&& m11508_0 = operands_p5;
        (m11508_0.size() == 0u);
    }) ? ({
        auto&& m11508_0 = operands_p5;
        ({
        auto e_p3_1 = e_p3;
        auto env_p2_2 = env_p2;
        auto lx_in_p1_3 = lx_in_p1;
        auto sigil_p4_4 = sigil_p4;
        call_then(start_plain_value_by_kind(lx_in_p1_3, env_p2_2, e_p3_1), [=, sigil_p4_4 = std::move(sigil_p4_4)](crate::lower::types::Vl plain_value_by_kind_11585) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{sigil_p4_4 == Text::lit("~") ? Text::lit("Ok") : Text::lit("Some"), Array(std::vector{crate::lower::types::own(plain_value_by_kind_11585)})})); });
    });
    })
        : ({
        auto r_p7 = or_(index(operands_p5, Nat(0u)), prism_rtl::deref(e_p3).span);
        auto e_p3_1 = e_p3;
        auto env_p2_2 = env_p2;
        auto lx_p0_3 = lx_p0;
        auto lx_in_p1_4 = lx_in_p1;
        auto operands_p5_5 = operands_p5;
        auto sigil_p4_6 = sigil_p4;
        auto t_p6_7 = t_p6;
        call_then(start_value_of(lx_p0_3, env_p2_2, or_(operand_at(e_p3_1, r_p7), dummy_expr())), [=, lx_in_p1_4 = std::move(lx_in_p1_4), operands_p5_5 = std::move(operands_p5_5), sigil_p4_6 = std::move(sigil_p4_6), t_p6_7 = std::move(t_p6_7)](crate::lower::types::Vl value_of_11689) {
        return ({
            auto sv_p8 = value_of_11689;
            call_then(crate::lower::types::start_out_ty_of(lx_p0_3, crate::lower::patterns::inner_ty(crate::lower::type_at(lx_p0_3, r_p7))), [=, sv_p8 = std::move(sv_p8)](crate::lower::model::OutTy out_ty_of_11757) {
            return ({
                auto it_p9 = out_ty_of_11757;
                auto owned_pa = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    if (prism_rtl::is<crate::lower::types::Vl::VlOwned>(sv_p8)) {
                        _v.set(true);
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto mode_pb = std::move(owned_pa)
                    ? crate::lower::types::Holding(crate::lower::types::Holding::Owned{})
                    : crate::lower::types::Holding(crate::lower::types::Holding::ByRef{});
                auto x_pc = prism_rtl::cat("o", prism_rtl::deref(r_p7).start, "_", prism_rtl::deref(r_p7).end);
                auto env2_pd = crate::lower::types::bind_span(env_p2_2, crate::lower::place_key(lx_p0_3, r_p7), crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XVar{x_pc}), mode_pb, it_p9}));
                call_then(start_lift_operands(lx_p0_3, lx_in_p1_4, env2_pd, e_p3_1, sigil_p4_6, drop(operands_p5_5, Nat(1u)), t_p6_7), [=, owned_pa = std::move(owned_pa), mode_pb = std::move(mode_pb), x_pc = std::move(x_pc)](crate::lower::model::Ex lift_operands_12077) {
                return ({
                    auto body_pe = lift_operands_12077;
                    auto fail_arm_pf = sigil_p4_6 == Text::lit("~")
                        ? crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Err"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat(x_pc, "_e")})})}), .conds = Array<crate::lower::model::Cc>{}, .body = crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{crate::lower::types::own(crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat(x_pc, "_e")}), mode_pb, crate::lower::model::OutTy(crate::lower::model::OutTy::OutError{})}))})})}
                        : crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{Text::lit("None")}), .conds = Array<crate::lower::model::Cc>{}, .body = crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XNone{})), t_p6_7})};
                    auto arms_pg = Array(std::vector{crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{sigil_p4_6 == Text::lit("~") ? Text::lit("Ok") : Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{x_pc})})}), .conds = Array<crate::lower::model::Cc>{}, .body = body_pe}, fail_arm_pf});
                    (prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XMatch{prism_rtl::rc(owned_pa
                    ? crate::lower::types::own(sv_p8)
                    : crate::lower::types::ref_(sv_p8)), arms_pg, false, t_p6_7})));
                });
            });
            });
        });
        });
    });
    });
    });
}


/// `Start LiftOperands, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_lift_operands(crate::lower::Lx lx_p0, crate::lower::Lx lx_in_p1, crate::lower::types::Env env_p2, crate::syntax::Expr e_p3, Text sigil_p4, Array<crate::syntax::Range> operands_p5, crate::lower::model::OutTy t_p6) {
    return prism_rtl::make_rc<LiftOperands>(lx_p0, lx_in_p1, env_p2, e_p3, sigil_p4, operands_p5, t_p6);
}


/// IsLiftedAt: fn Lx, Range -> Bool
bool is_lifted_at(const crate::lower::Lx& lx_p0, const crate::syntax::Range& r_p1) {
    auto&& _m = crate::prelude::get(lx_p0.lifts, crate::lower::place_key(lx_p0, r_p1));
    if (prism_rtl::is_some(_m)) {
        auto&& ln_p2 = prism_rtl::some_of(_m);
        return len(prism_rtl::deref(ln_p2).operands) > Nat(0u);
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?OperandAt: fn Expr, Range -> ?Expr
std::optional<crate::syntax::Expr> operand_at(const crate::syntax::Expr& e_p0, const crate::syntax::Range& r_p1) {
    return fold(direct_operands(e_p0), std::optional<crate::syntax::Expr>{}, [&](const std::optional<crate::syntax::Expr>& found_o2, const crate::syntax::Expr& x_p3) {
        return (found_o2 == std::optional<crate::syntax::Expr>{}) && (prism_rtl::deref(x_p3).span == r_p1)
            ? std::optional(x_p3)
            : found_o2;
    });
}


/// DirectOperands: fn Expr -> [Expr]
Array<crate::syntax::Expr> direct_operands(const crate::syntax::Expr& e_p0) {
    auto&& _m = prism_rtl::deref(e_p0.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p1 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return direct_operands(prism_rtl::deref(prism_rtl::deref(x_p1)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& args_p2 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        return each(args_p2, [&](const crate::syntax::Arg& a_p3) { return a_p3->value; });
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m)) {
        auto&& r_p4 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
        auto&& args_p5 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
        return append(Array(std::vector{prism_rtl::deref(prism_rtl::deref(r_p4))}), each(args_p5, [&](const crate::syntax::Arg& a_p6) { return a_p6->value; }));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
        auto&& l_p7 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r_p8 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        return Array(std::vector{prism_rtl::deref(prism_rtl::deref(l_p7)), prism_rtl::deref(prism_rtl::deref(r_p8))});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m)) {
        auto&& x_p9 = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
        return Array(std::vector{prism_rtl::deref(prism_rtl::deref(x_p9))});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
        auto&& x_pa = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        return Array(std::vector{prism_rtl::deref(prism_rtl::deref(x_pa))});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        auto&& r_pb = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        return Array(std::vector{prism_rtl::deref(prism_rtl::deref(r_pb))});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r_pc = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& i_pd = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        return Array(std::vector{prism_rtl::deref(prism_rtl::deref(r_pc)), prism_rtl::deref(prism_rtl::deref(i_pd))});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMap>(_m)) {
        auto&& kvs_pe = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
        return fold(kvs_pe, Array<crate::syntax::Expr>{}, [&](const Array<crate::syntax::Expr>& acc_pf, const std::tuple<crate::syntax::Expr, crate::syntax::Expr>& _p1) {
            auto&& k_pg = std::get<0>(_p1);
            auto&& v_ph = std::get<1>(_p1);
            return append(acc_pf, Array(std::vector{k_pg, v_ph}));
        });
    }
    {
        return Array<crate::syntax::Expr>{};
    }
}


/// PlainValueByKind: unbounded fn Lx, Env, Expr -> Vl
crate::lower::types::Vl plain_value_by_kind(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2) {
    auto t_p3 = crate::lower::types::out_ty_of(lx_p0, crate::lower::types::peel(crate::lower::type_at(lx_p0, e_p2.span)));
    auto&& _m = prism_rtl::deref(e_p2.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p4 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return name_value(lx_p0, env_p1, n_p4, e_p2.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELit>(_m)) {
        auto&& l_p5 = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
        return literal_value(lx_p0, env_p1, l_p5, e_p2.span, false);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUnit>(_m)) {
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBound>(_m)) {
        auto&& b_p6 = prism_rtl::as<crate::syntax::ExprKind::EBound>(_m).a0;
        auto&& _m = crate::prelude::get(env_p1.names, b_p6);
        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
            auto&& rs_p7 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
            auto&& mode_p8 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
            auto&& bt_p9 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
            return crate::lower::types::local_place(rs_p7, mode_p8, bt_p9);
        }
        {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("`", b_p6, "` outside a `for`")), t_p3});
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ENil>(_m)) {
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XNone{})), t_p3}), t_p3});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m)) {
        auto&& es_pa = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XTuple{run_to_end(each_job(es_pa, ({
            auto lx_p0_1 = lx_p0;
            auto env_p1_2 = env_p1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Expr)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1), env_p1_2 = std::move(env_p1_2)](crate::syntax::Expr p0) {
            return ({
                auto lx_p0_1_3 = lx_p0_1;
                auto env_p1_2_3 = env_p1_2;
                entered(once_job([=, lx_p0_1_3 = std::move(lx_p0_1_3), env_p1_2_3 = std::move(env_p1_2_3)]() {
                return ({
                    auto x_pb = p0;
                    call_then(start_value_of(lx_p0_1_3, env_p1_2_3, x_pb), [=](crate::lower::types::Vl value_of_14019) { return prism_rtl::finished(crate::lower::types::own(value_of_14019)); });
                });
            }));
            });
        })));
        })))}), t_p3});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EArray>(_m)) {
        auto&& m13582_6_0 = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
        if (m13582_6_0.size() == 0u) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Array::new"), Array<crate::lower::model::Ex>{}})), t_p3}), t_p3});
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EArray>(_m)) {
        auto&& es_pc = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Array::from"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVec{run_to_end(each_job(es_pc, ({
            auto lx_p0_1 = lx_p0;
            auto env_p1_2 = env_p1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Expr)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1), env_p1_2 = std::move(env_p1_2)](crate::syntax::Expr p0) {
            return ({
                auto lx_p0_1_3 = lx_p0_1;
                auto env_p1_2_3 = env_p1_2;
                entered(once_job([=, lx_p0_1_3 = std::move(lx_p0_1_3), env_p1_2_3 = std::move(env_p1_2_3)]() {
                return ({
                    auto x_pd = p0;
                    call_then(start_value_of(lx_p0_1_3, env_p1_2_3, x_pd), [=](crate::lower::types::Vl value_of_14191) { return prism_rtl::finished(crate::lower::types::own(value_of_14191)); });
                });
            }));
            });
        })));
        })))})})}), t_p3});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMap>(_m)) {
        auto&& m13582_8_0 = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
        if (m13582_8_0.size() == 0u) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Map::new"), Array<crate::lower::model::Ex>{}})), t_p3}), t_p3});
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMap>(_m)) {
        auto&& kvs_pe = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("map_of"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVec{run_to_end(each_job(kvs_pe, ({
            auto lx_p0_1 = lx_p0;
            auto env_p1_2 = env_p1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::syntax::Expr, crate::syntax::Expr>)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1), env_p1_2 = std::move(env_p1_2)](std::tuple<crate::syntax::Expr, crate::syntax::Expr> p0) {
            return ({
                auto lx_p0_1_3 = lx_p0_1;
                auto env_p1_2_3 = env_p1_2;
                entered(once_job([=, lx_p0_1_3 = std::move(lx_p0_1_3), env_p1_2_3 = std::move(env_p1_2_3)]() {
                return ({
                    auto [k_pf, v_pg] = p0;
                    call_then(start_value_of(lx_p0_1_3, env_p1_2_3, k_pf), [=](crate::lower::types::Vl value_of_14372) { return call_then(start_value_of(lx_p0_1_3, env_p1_2_3, v_pg), [=](crate::lower::types::Vl value_of_14398) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XTuple{Array(std::vector{crate::lower::types::own(value_of_14372), crate::lower::types::own(value_of_14398)})})); }); });
                });
            }));
            });
        })));
        })))})})}), t_p3});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_ph = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return value_of(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_ph)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c_pi = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args_pj = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        return application(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(c_pi)), args_pj, e_p2.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m)) {
        auto&& r_pk = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
        auto&& m_pl = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a1;
        auto&& args_pm = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
        return application(lx_p0, env_p1, crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{m_pl})), .span = prism_rtl::deref(m_pl).span}, append(Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = prism_rtl::deref(prism_rtl::deref(r_pk)), .span = prism_rtl::deref(r_pk).span}}), args_pm), e_p2.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
        auto&& op_pn = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& l_po = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r_pp = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        return binary_value(lx_p0, env_p1, op_pn, prism_rtl::deref(prism_rtl::deref(l_po)), prism_rtl::deref(prism_rtl::deref(r_pp)), e_p2.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m)) {
        auto&& m13582_14_0 = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a0;
        auto&& x_pq = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
        if (m13582_14_0 == Text::lit("not")) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{Text::lit("!"), prism_rtl::rc(crate::lower::types::as_bool(value_of(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_pq)))))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})});
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m)) {
        auto&& m13582_15_0 = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a0;
        auto&& x_pr = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
        if (m13582_15_0 == Text::lit("neg")) {
            auto&& _m = prism_rtl::deref(prism_rtl::deref(x_pr).kind);
            if (prism_rtl::is<crate::syntax::ExprKind::ELit>(_m)) {
                auto&& l_ps = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
                return literal_value(lx_p0, env_p1, l_ps, prism_rtl::deref(x_pr).span, true);
            }
            {
                auto v_pt = value_of(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_pr)));
                return crate::lower::types::is_copy(t_p3)
                    ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{Text::lit("-"), prism_rtl::rc(crate::lower::types::copy(v_pt))}), t_p3})
                    : crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{Text::lit("-"), prism_rtl::rc(crate::lower::types::ref_(v_pt))}), t_p3});
            }
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m)) {
        auto&& x_pu = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
        return value_of(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_pu)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
        auto&& m13582_17_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        auto&& x_pv = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        if (m13582_17_0 == Text::lit("?")) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::types::own(value_of(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_pv))))})}), t_p3});
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
        auto&& m13582_18_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        auto&& x_p10 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        if (m13582_18_0 == Text::lit("~")) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Ok"), Array(std::vector{crate::lower::types::own(value_of(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p10))))})}), t_p3});
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
        auto&& m13582_19_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        auto&& x_p11 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        if (m13582_19_0 == Text::lit("@")) {
            return pure_blueprint(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p11)), t_p3);
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
        auto&& x_p12 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        return value_of(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p12)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        auto&& r_p13 = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        auto&& name_p14 = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a2;
        return field_value(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(r_p13)), prism_rtl::deref(name_p14).name);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r_p15 = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& i_p16 = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        return index_value(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(r_p15)), prism_rtl::deref(prism_rtl::deref(i_p16)), t_p3);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
        auto&& ps_o17 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
        auto&& body_p18 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
        return lambda_value(lx_p0, env_p1, e_p2, or_(ps_o17, Array<crate::syntax::Pattern_>{}), prism_rtl::deref(prism_rtl::deref(body_p18)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
        auto&& c_p19 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b_p1a = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b_o1b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        return if_value(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(c_p19)), then_b_p1a, else_b_o1b, t_p3);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
        auto&& s_p1c = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms_p1d = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        return match_value(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(s_p1c)), arms_p1d, t_p3, e_p2.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETemplate>(_m)) {
        auto&& tp_p1e = prism_rtl::as<crate::syntax::ExprKind::ETemplate>(_m).a0;
        return crate::lower::templates::template_value(lx_p0, env_p1, tp_p1e);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECast>(_m)) {
        auto&& x_p1f = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a0;
        return value_of(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p1f)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m)) {
        auto&& x_p1g = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
        return value_of(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p1g)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGiven>(_m)) {
        auto&& b_p1h = prism_rtl::as<crate::syntax::ExprKind::EGiven>(_m).a0;
        return crate::lower::templates::given_value(lx_p0, env_p1, b_p1h, t_p3, e_p2.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m)) {
        auto&& target_p1i = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
        auto&& b_p1j = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
        return crate::lower::templates::update_value(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(target_p1i)), b_p1j, t_p3, e_p2.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EAny>(_m)) {
        auto&& x_p1k = prism_rtl::as<crate::syntax::ExprKind::EAny>(_m).a0;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::types::own(value_of(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p1k))))})}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutShowAny{})});
    }
    {
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat(kind_words(prism_rtl::deref(e_p2.kind)), " as a value")), t_p3});
    }
}


prism_rtl::Turn<crate::lower::types::Vl> PlainValueByKind::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& e_p2 = this->e_p2;
    auto e_p2_1 = e_p2;
    auto env_p1_2 = env_p1;
    auto lx_p0_3 = lx_p0;
    return call_then(crate::lower::types::start_out_ty_of(lx_p0_3, crate::lower::types::peel(crate::lower::type_at(lx_p0_3, prism_rtl::deref(e_p2_1).span))), [=](crate::lower::model::OutTy out_ty_of_13539) {
        return ({
            auto t_p3 = out_ty_of_13539;
            ({
            auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p2_1).kind);
            prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
            auto&& n_p4 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            prism_rtl::more(prism_rtl::rc(NameValue(lx_p0_3, env_p1_2, n_p4, prism_rtl::deref(e_p2_1).span)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::ELit>(_m) ? ({
            auto&& l_p5 = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
            prism_rtl::more(prism_rtl::rc(LiteralValue(lx_p0_3, env_p1_2, l_p5, prism_rtl::deref(e_p2_1).span, false)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EUnit>(_m) ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}))
            : prism_rtl::is<crate::syntax::ExprKind::EBound>(_m) ? ({
            auto&& b_p6 = prism_rtl::as<crate::syntax::ExprKind::EBound>(_m).a0;
            ({
            auto&& _m = crate::prelude::get(env_p1_2->names, b_p6);
            prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)) ? ({
            auto&& rs_p7 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
            auto&& mode_p8 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
            auto&& bt_p9 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
            prism_rtl::finished(crate::lower::types::local_place(rs_p7, mode_p8, bt_p9));
        })
            : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("`", b_p6, "` outside a `for`")), t_p3}));
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::ENil>(_m) ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XNone{})), t_p3}), t_p3}))
            : prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m) ? ({
            auto&& es_pa = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
            ({
            auto es_pa_4 = es_pa;
            call_value(each_job(es_pa_4, ({
            auto lx_p0_3_5 = lx_p0_3;
            auto env_p1_2_5 = env_p1_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Expr)>>(prism_rtl::rc([=, lx_p0_3_5 = std::move(lx_p0_3_5), env_p1_2_5 = std::move(env_p1_2_5)](crate::syntax::Expr p0) {
            return ({
                auto lx_p0_3_5_5 = lx_p0_3_5;
                auto env_p1_2_5_5 = env_p1_2_5;
                entered(once_job([=, lx_p0_3_5_5 = std::move(lx_p0_3_5_5), env_p1_2_5_5 = std::move(env_p1_2_5_5)]() {
                return ({
                    auto x_pb = p0;
                    call_then(start_value_of(lx_p0_3_5_5, env_p1_2_5_5, x_pb), [=](crate::lower::types::Vl value_of_14019) { return prism_rtl::finished(crate::lower::types::own(value_of_14019)); });
                });
            }));
            });
        })));
        })), [=](Array<crate::lower::model::Ex> each_14000) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XTuple{each_14000}), t_p3})); });
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EArray>(_m) && ({
            auto&& m13582_6_0 = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
            (m13582_6_0.size() == 0u);
        }) ? ({
            auto&& m13582_6_0 = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
            prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Array::new"), Array<crate::lower::model::Ex>{}})), t_p3}), t_p3}));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EArray>(_m) ? ({
            auto&& es_pc = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
            ({
            auto es_pc_4 = es_pc;
            call_value(each_job(es_pc_4, ({
            auto lx_p0_3_5 = lx_p0_3;
            auto env_p1_2_5 = env_p1_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Expr)>>(prism_rtl::rc([=, lx_p0_3_5 = std::move(lx_p0_3_5), env_p1_2_5 = std::move(env_p1_2_5)](crate::syntax::Expr p0) {
            return ({
                auto lx_p0_3_5_5 = lx_p0_3_5;
                auto env_p1_2_5_5 = env_p1_2_5;
                entered(once_job([=, lx_p0_3_5_5 = std::move(lx_p0_3_5_5), env_p1_2_5_5 = std::move(env_p1_2_5_5)]() {
                return ({
                    auto x_pd = p0;
                    call_then(start_value_of(lx_p0_3_5_5, env_p1_2_5_5, x_pd), [=](crate::lower::types::Vl value_of_14191) { return prism_rtl::finished(crate::lower::types::own(value_of_14191)); });
                });
            }));
            });
        })));
        })), [=](Array<crate::lower::model::Ex> each_14172) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Array::from"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVec{each_14172})})}), t_p3})); });
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EMap>(_m) && ({
            auto&& m13582_8_0 = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
            (m13582_8_0.size() == 0u);
        }) ? ({
            auto&& m13582_8_0 = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
            prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Map::new"), Array<crate::lower::model::Ex>{}})), t_p3}), t_p3}));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EMap>(_m) ? ({
            auto&& kvs_pe = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
            ({
            auto kvs_pe_4 = kvs_pe;
            call_value(each_job(kvs_pe_4, ({
            auto lx_p0_3_5 = lx_p0_3;
            auto env_p1_2_5 = env_p1_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::syntax::Expr, crate::syntax::Expr>)>>(prism_rtl::rc([=, lx_p0_3_5 = std::move(lx_p0_3_5), env_p1_2_5 = std::move(env_p1_2_5)](std::tuple<crate::syntax::Expr, crate::syntax::Expr> p0) {
            return ({
                auto lx_p0_3_5_5 = lx_p0_3_5;
                auto env_p1_2_5_5 = env_p1_2_5;
                entered(once_job([=, lx_p0_3_5_5 = std::move(lx_p0_3_5_5), env_p1_2_5_5 = std::move(env_p1_2_5_5)]() {
                return ({
                    auto [k_pf, v_pg] = p0;
                    call_then(start_value_of(lx_p0_3_5_5, env_p1_2_5_5, k_pf), [=](crate::lower::types::Vl value_of_14372) { return call_then(start_value_of(lx_p0_3_5_5, env_p1_2_5_5, v_pg), [=](crate::lower::types::Vl value_of_14398) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XTuple{Array(std::vector{crate::lower::types::own(value_of_14372), crate::lower::types::own(value_of_14398)})})); }); });
                });
            }));
            });
        })));
        })), [=](Array<crate::lower::model::Ex> each_14336) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("map_of"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVec{each_14336})})}), t_p3})); });
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
            auto&& x_ph = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
            prism_rtl::more(prism_rtl::rc(ValueOf(lx_p0_3, env_p1_2, prism_rtl::deref(prism_rtl::deref(x_ph)))));
        })
            : prism_rtl::is<crate::syntax::ExprKind::ECall>(_m) ? ({
            auto&& c_pi = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
            auto&& args_pj = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
            prism_rtl::more(prism_rtl::rc(Application(lx_p0_3, env_p1_2, prism_rtl::deref(prism_rtl::deref(c_pi)), args_pj, prism_rtl::deref(e_p2_1).span)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m) ? ({
            auto&& r_pk = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
            auto&& m_pl = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a1;
            auto&& args_pm = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
            prism_rtl::more(prism_rtl::rc(Application(lx_p0_3, env_p1_2, crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{m_pl})), .span = prism_rtl::deref(m_pl).span}, append(Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = prism_rtl::deref(prism_rtl::deref(r_pk)), .span = prism_rtl::deref(r_pk).span}}), args_pm), prism_rtl::deref(e_p2_1).span)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m) ? ({
            auto&& op_pn = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
            auto&& l_po = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
            auto&& r_pp = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
            prism_rtl::more(prism_rtl::rc(BinaryValue(lx_p0_3, env_p1_2, op_pn, prism_rtl::deref(prism_rtl::deref(l_po)), prism_rtl::deref(prism_rtl::deref(r_pp)), prism_rtl::deref(e_p2_1).span)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m) && ({
            auto&& m13582_14_0 = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a0;
            auto&& x_pq = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
            (m13582_14_0 == Text::lit("not"));
        }) ? ({
            auto&& m13582_14_0 = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a0;
            auto&& x_pq = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
            ({
            auto x_pq_4 = prism_rtl::deref(prism_rtl::deref(x_pq));
            call_then(start_value_of(lx_p0_3, env_p1_2, x_pq_4), [=](crate::lower::types::Vl value_of_14808) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{Text::lit("!"), prism_rtl::rc(crate::lower::types::as_bool(value_of_14808))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})})); });
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m) && ({
            auto&& m13582_15_0 = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a0;
            auto&& x_pr = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
            (m13582_15_0 == Text::lit("neg"));
        }) ? ({
            auto&& m13582_15_0 = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a0;
            auto&& x_pr = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
            ({
            auto&& _m = prism_rtl::deref(prism_rtl::deref(x_pr).kind);
            prism_rtl::is<crate::syntax::ExprKind::ELit>(_m) ? ({
            auto&& l_ps = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
            prism_rtl::more(prism_rtl::rc(LiteralValue(lx_p0_3, env_p1_2, l_ps, prism_rtl::deref(x_pr).span, true)));
        })
            : ({
            auto x_pr_4 = prism_rtl::deref(prism_rtl::deref(x_pr));
            call_then(start_value_of(lx_p0_3, env_p1_2, x_pr_4), [=](crate::lower::types::Vl value_of_14983) {
            return ({
                auto v_pt = value_of_14983;
                (crate::lower::types::is_copy(t_p3)
                ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{Text::lit("-"), prism_rtl::rc(crate::lower::types::copy(v_pt))}), t_p3}))
                : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{Text::lit("-"), prism_rtl::rc(crate::lower::types::ref_(v_pt))}), t_p3})));
            });
        });
        });
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m) ? ({
            auto&& x_pu = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
            prism_rtl::more(prism_rtl::rc(ValueOf(lx_p0_3, env_p1_2, prism_rtl::deref(prism_rtl::deref(x_pu)))));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m) && ({
            auto&& m13582_17_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
            auto&& x_pv = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
            (m13582_17_0 == Text::lit("?"));
        }) ? ({
            auto&& m13582_17_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
            auto&& x_pv = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
            ({
            auto x_pv_4 = prism_rtl::deref(prism_rtl::deref(x_pv));
            call_then(start_value_of(lx_p0_3, env_p1_2, x_pv_4), [=](crate::lower::types::Vl value_of_15206) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::types::own(value_of_15206)})}), t_p3})); });
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m) && ({
            auto&& m13582_18_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
            auto&& x_p10 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
            (m13582_18_0 == Text::lit("~"));
        }) ? ({
            auto&& m13582_18_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
            auto&& x_p10 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
            ({
            auto x_p10_4 = prism_rtl::deref(prism_rtl::deref(x_p10));
            call_then(start_value_of(lx_p0_3, env_p1_2, x_p10_4), [=](crate::lower::types::Vl value_of_15287) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Ok"), Array(std::vector{crate::lower::types::own(value_of_15287)})}), t_p3})); });
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m) && ({
            auto&& m13582_19_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
            auto&& x_p11 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
            (m13582_19_0 == Text::lit("@"));
        }) ? ({
            auto&& m13582_19_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
            auto&& x_p11 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
            prism_rtl::more(prism_rtl::rc(PureBlueprint(lx_p0_3, env_p1_2, prism_rtl::deref(prism_rtl::deref(x_p11)), t_p3)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m) ? ({
            auto&& x_p12 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
            prism_rtl::more(prism_rtl::rc(ValueOf(lx_p0_3, env_p1_2, prism_rtl::deref(prism_rtl::deref(x_p12)))));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EField>(_m) ? ({
            auto&& r_p13 = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
            auto&& name_p14 = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a2;
            prism_rtl::more(prism_rtl::rc(FieldValue(lx_p0_3, env_p1_2, prism_rtl::deref(prism_rtl::deref(r_p13)), prism_rtl::deref(name_p14).name)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m) ? ({
            auto&& r_p15 = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
            auto&& i_p16 = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
            prism_rtl::more(prism_rtl::rc(IndexValue(lx_p0_3, env_p1_2, prism_rtl::deref(prism_rtl::deref(r_p15)), prism_rtl::deref(prism_rtl::deref(i_p16)), t_p3)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) ? ({
            auto&& ps_o17 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
            auto&& body_p18 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
            prism_rtl::more(prism_rtl::rc(LambdaValue(lx_p0_3, env_p1_2, e_p2_1, or_(ps_o17, Array<crate::syntax::Pattern_>{}), prism_rtl::deref(prism_rtl::deref(body_p18)))));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
            auto&& c_p19 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
            auto&& then_b_p1a = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
            auto&& else_b_o1b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
            prism_rtl::more(prism_rtl::rc(IfValue(lx_p0_3, env_p1_2, prism_rtl::deref(prism_rtl::deref(c_p19)), then_b_p1a, else_b_o1b, t_p3)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
            auto&& s_p1c = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
            auto&& arms_p1d = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
            prism_rtl::more(prism_rtl::rc(MatchValue(lx_p0_3, env_p1_2, prism_rtl::deref(prism_rtl::deref(s_p1c)), arms_p1d, t_p3, prism_rtl::deref(e_p2_1).span)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::ETemplate>(_m) ? ({
            auto&& tp_p1e = prism_rtl::as<crate::syntax::ExprKind::ETemplate>(_m).a0;
            prism_rtl::more(prism_rtl::rc(crate::lower::templates::TemplateValue(lx_p0_3, env_p1_2, tp_p1e)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::ECast>(_m) ? ({
            auto&& x_p1f = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a0;
            prism_rtl::more(prism_rtl::rc(ValueOf(lx_p0_3, env_p1_2, prism_rtl::deref(prism_rtl::deref(x_p1f)))));
        })
            : prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m) ? ({
            auto&& x_p1g = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
            prism_rtl::more(prism_rtl::rc(ValueOf(lx_p0_3, env_p1_2, prism_rtl::deref(prism_rtl::deref(x_p1g)))));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EGiven>(_m) ? ({
            auto&& b_p1h = prism_rtl::as<crate::syntax::ExprKind::EGiven>(_m).a0;
            prism_rtl::more(prism_rtl::rc(crate::lower::templates::GivenValue(lx_p0_3, env_p1_2, b_p1h, t_p3, prism_rtl::deref(e_p2_1).span)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m) ? ({
            auto&& target_p1i = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
            auto&& b_p1j = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
            prism_rtl::more(prism_rtl::rc(crate::lower::templates::UpdateValue(lx_p0_3, env_p1_2, prism_rtl::deref(prism_rtl::deref(target_p1i)), b_p1j, t_p3, prism_rtl::deref(e_p2_1).span)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EAny>(_m) ? ({
            auto&& x_p1k = prism_rtl::as<crate::syntax::ExprKind::EAny>(_m).a0;
            ({
            auto x_p1k_4 = prism_rtl::deref(prism_rtl::deref(x_p1k));
            call_then(start_value_of(lx_p0_3, env_p1_2, x_p1k_4), [=](crate::lower::types::Vl value_of_16050) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::types::own(value_of_16050)})}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutShowAny{})})); });
        });
        })
            : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat(kind_words(prism_rtl::deref(prism_rtl::deref(e_p2_1).kind)), " as a value")), t_p3}));
        });
        });
    });
}


/// `Start PlainValueByKind, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_plain_value_by_kind(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2) {
    return prism_rtl::make_rc<PlainValueByKind>(lx_p0, env_p1, e_p2);
}


/// PureBlueprint: unbounded fn Lx, Env, Expr, OutTy -> Vl
crate::lower::types::Vl pure_blueprint(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& x_p2, const crate::lower::model::OutTy& t_p3) {
    auto is_never_p4 = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = prism_rtl::deref(x_p2.kind);
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n_p5 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            _v.set(({
                auto&& _qk_o6 = crate::check::env::names::resolve_value(lx_p0.g, lx_p0.home, n_p5);
                auto&& qk_o6 = std::get<0>(_qk_o6);
                qk_o6 == std::optional(Text::lit("Prelude.never"));
            }));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    return std::move(is_never_p4)
        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::never_blueprint::<crate::Elem, crate::Answer>"), Array<crate::lower::model::Ex>{}}), t_p3})
        : ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::types::Vl> _v;
        auto&& _m = crate::prelude::get(env_p1.names, Text::lit("#tag"));
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("`@ ", crate::lower::functions::src_text(lx_p0, lx_p0.file, x_p2.span), "` as a supplier\'s answer outside a tag arm: which tag\'s output it answers cannot be known")), t_p3}));
            goto _done;
        }
        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)) && prism_rtl::is<crate::lower::model::Ex::XPath>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0)) {
            auto&& variant_p7 = prism_rtl::as<crate::lower::model::Ex::XPath>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<crate::lower::types::Vl> _v;
                auto&& _m = crate::lower::types::layer_of(crate::lower::type_at(lx_p0, x_p2.span));
                if (prism_rtl::is<crate::lower::types::Layer::LyEv>(_m)) {
                    _v.set(({
                        auto wrapped_p8 = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::types::own(value_of(lx_p0, env_p1, x_p2))), Text::lit("map"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("v")})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant_p7, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}))})})}))})})});
                        (crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::event_blueprint::<crate::Elem, _>"), Array(std::vector{wrapped_p8})}), t_p3}));
                    }));
                    goto _done;
                }
                if (prism_rtl::is<crate::lower::types::Layer::LyDyn>(_m)) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<crate::lower::types::Vl> _v;
                        auto&& _m = crate::lower::node_::static_::dynamic_answer(lx_p0, x_p2);
                        if (prism_rtl::is_none(_m)) {
                            _v.set(({
                                __label__ _done;
                                prism_rtl::Slot<crate::lower::types::Vl> _v;
                                auto&& _m = prism_rtl::deref(x_p2.kind);
                                if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
                                    auto&& m17752_0_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
                                    auto&& inner_p9 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
                                    if (m17752_0_0 == Text::lit("$")) {
                                        _v.set(plain_blueprint_(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(inner_p9)), variant_p7, t_p3));
                                        goto _done;
                                    }
                                }
                                {
                                    _v.set(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("`@ ", crate::lower::functions::src_text(lx_p0, lx_p0.file, x_p2.span), "`, a supplier\'s dynamic answer of no known form")), t_p3}));
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_some(_m)) {
                            auto&& d_pa = prism_rtl::some_of(_m);
                            _v.set(dynamic_blueprint_(lx_p0, env_p1, x_p2, d_pa, variant_p7, t_p3));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                {
                    _v.set(plain_blueprint_(lx_p0, env_p1, x_p2, variant_p7, t_p3));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(Text::lit("a supplier\'s answer under a tag the arm does not name")), t_p3}));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<crate::lower::types::Vl> PureBlueprint::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& x_p2 = this->x_p2;
    const auto& t_p3 = this->t_p3;
    auto is_never_p4 = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(x_p2).kind);
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n_p5 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            _v.set(({
                auto&& _qk_o6 = crate::check::env::names::resolve_value(prism_rtl::deref(lx_p0).g, prism_rtl::deref(lx_p0).home, n_p5);
                auto&& qk_o6 = std::get<0>(_qk_o6);
                qk_o6 == std::optional(Text::lit("Prelude.never"));
            }));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    return std::move(is_never_p4)
        ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::never_blueprint::<crate::Elem, crate::Answer>"), Array<crate::lower::model::Ex>{}}), t_p3}))
        : ({
        auto&& _m = crate::prelude::get(env_p1->names, Text::lit("#tag"));
        prism_rtl::is_none(_m) ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("`@ ", crate::lower::functions::src_text(lx_p0, lx_p0->file, prism_rtl::deref(x_p2).span), "` as a supplier\'s answer outside a tag arm: which tag\'s output it answers cannot be known")), t_p3}))
        : prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)) && prism_rtl::is<crate::lower::model::Ex::XPath>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0) ? ({
        auto&& variant_p7 = prism_rtl::as<crate::lower::model::Ex::XPath>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0).a0;
        ({
        auto&& _m = crate::lower::types::layer_of(crate::lower::type_at(lx_p0, prism_rtl::deref(x_p2).span));
        prism_rtl::is<crate::lower::types::Layer::LyEv>(_m) ? ({
        auto env_p1_1 = env_p1;
        auto lx_p0_2 = lx_p0;
        auto t_p3_3 = t_p3;
        auto x_p2_4 = x_p2;
        call_then(start_value_of(lx_p0_2, env_p1_1, x_p2_4), [=, t_p3_3 = std::move(t_p3_3)](crate::lower::types::Vl value_of_17481) {
        return ({
            auto wrapped_p8 = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::types::own(value_of_17481)), Text::lit("map"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("v")})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant_p7, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}))})})}))})})});
            (prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::event_blueprint::<crate::Elem, _>"), Array(std::vector{wrapped_p8})}), t_p3_3})));
        });
    });
    })
        : prism_rtl::is<crate::lower::types::Layer::LyDyn>(_m) ? ({
        auto&& _m = crate::lower::node_::static_::dynamic_answer(lx_p0, x_p2);
        prism_rtl::is_none(_m) ? ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(x_p2).kind);
        prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m) && ({
        auto&& m17752_0_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        auto&& inner_p9 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        (m17752_0_0 == Text::lit("$"));
    }) ? ({
        auto&& m17752_0_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        auto&& inner_p9 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        prism_rtl::more(prism_rtl::rc(PlainBlueprint(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(inner_p9)), variant_p7, t_p3)));
    })
        : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("`@ ", crate::lower::functions::src_text(lx_p0, lx_p0->file, prism_rtl::deref(x_p2).span), "`, a supplier\'s dynamic answer of no known form")), t_p3}));
    })
        : prism_rtl::is_some(_m) ? ({
        auto&& d_pa = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(DynamicBlueprint(lx_p0, env_p1, x_p2, d_pa, variant_p7, t_p3)));
    })
        : throw prism_rtl::Panic("no arm matched");
    })
        : prism_rtl::more(prism_rtl::rc(PlainBlueprint(lx_p0, env_p1, x_p2, variant_p7, t_p3)));
    });
    })
        : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(Text::lit("a supplier\'s answer under a tag the arm does not name")), t_p3}));
    });
}


/// `Start PureBlueprint, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_pure_blueprint(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr x_p2, crate::lower::model::OutTy t_p3) {
    return prism_rtl::make_rc<PureBlueprint>(lx_p0, env_p1, x_p2, t_p3);
}


/// PlainBlueprint: unbounded fn Lx, Env, Expr, Text, OutTy -> Vl
crate::lower::types::Vl plain_blueprint_(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& x_p2, const Text& variant_p3, const crate::lower::model::OutTy& t_p4) {
    return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::plain_blueprint::<crate::Elem, _>"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant_p3, Array(std::vector{crate::lower::types::own(value_of(lx_p0, env_p1, x_p2))})})})}), t_p4});
}


prism_rtl::Turn<crate::lower::types::Vl> PlainBlueprint::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& x_p2 = this->x_p2;
    const auto& variant_p3 = this->variant_p3;
    const auto& t_p4 = this->t_p4;
    auto env_p1_1 = env_p1;
    auto lx_p0_2 = lx_p0;
    auto t_p4_3 = t_p4;
    auto variant_p3_4 = variant_p3;
    auto x_p2_5 = x_p2;
    return call_then(start_value_of(lx_p0_2, env_p1_1, x_p2_5), [=](crate::lower::types::Vl value_of_18400) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::plain_blueprint::<crate::Elem, _>"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant_p3_4, Array(std::vector{crate::lower::types::own(value_of_18400)})})})}), t_p4_3})); });
}


/// `Start PlainBlueprint, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_plain_blueprint_(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr x_p2, Text variant_p3, crate::lower::model::OutTy t_p4) {
    return prism_rtl::make_rc<PlainBlueprint>(lx_p0, env_p1, x_p2, variant_p3, t_p4);
}


/// DynamicBlueprint: unbounded fn Lx, Env, Expr, Expr, Text, OutTy -> Vl
crate::lower::types::Vl dynamic_blueprint_(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& x_p2, const crate::syntax::Expr& d_p3, const Text& variant_p4, const crate::lower::model::OutTy& t_p5) {
    auto&& _m = std::tuple{crate::prelude::get(env_p1.names, prism_rtl::cat("#dyn", crate::lower::node_::static_::dyn_key(x_p2))), crate::prelude::get(env_p1.names, Text::lit("#owner"))};
    if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(std::get<0>(_m))) && prism_rtl::is<crate::lower::model::Ex::XVar>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(std::get<0>(_m))).a0) && prism_rtl::is_some(std::get<1>(_m)) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(std::get<1>(_m))) && prism_rtl::is<crate::lower::model::Ex::XVar>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(std::get<1>(_m))).a0)) {
        auto&& getter_p6 = prism_rtl::as<crate::lower::model::Ex::XVar>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(std::get<0>(_m))).a0).a0;
        auto&& dt_p7 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(std::get<0>(_m))).a2;
        auto&& owner_p8 = prism_rtl::as<crate::lower::model::Ex::XVar>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(std::get<1>(_m))).a0).a0;
        auto at_build_p9 = crate::lower::types::own(value_of(lx_p0, crate::lower::node_::def::init_env(env_p1), d_p3));
        auto arms_pa = Array(std::vector{crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("owner")})})}), .conds = Array<crate::lower::model::Cc>{}, .body = crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant_p4, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("owner")})), getter_p6, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})})}, crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{Text::lit("None")}), .conds = Array<crate::lower::model::Cc>{}, .body = crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant_p4, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("at_build")}))})})})}});
        auto read_pb = crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("cx")})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Cx"), Array<crate::lower::model::OutTy>{}}))})})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMatch{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("link")})), Text::lit("owner"), Array<crate::lower::model::Ex>{}})), arms_pa, false, crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("crate::Answer"), Array<crate::lower::model::OutTy>{}})}))});
        auto dynamic_pc = crate::lower::model::Ex(crate::lower::model::Ex::XBlock{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("link")}), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{owner_p8}))})}), crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("at_build")}), at_build_p9})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::Dynamic::of"), Array(std::vector{read_pb, crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat(getter_p6, "_port")}))})})}))});
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::dynamic_blueprint::<crate::Elem, _>"), Array(std::vector{dynamic_pc})}), t_p5});
    }
    {
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("`@ ", crate::lower::functions::src_text(lx_p0, lx_p0.file, x_p2.span), "`, a supplier\'s dynamic answer that reads what has no value at the owner\'s build (a pushed place, a structural dynamic, or a `let` after the host\'s line)")), t_p5});
    }
}


prism_rtl::Turn<crate::lower::types::Vl> DynamicBlueprint::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& x_p2 = this->x_p2;
    const auto& d_p3 = this->d_p3;
    const auto& variant_p4 = this->variant_p4;
    const auto& t_p5 = this->t_p5;
    return ({
        auto&& _m = std::tuple{crate::prelude::get(env_p1->names, prism_rtl::cat("#dyn", crate::lower::node_::static_::dyn_key(x_p2))), crate::prelude::get(env_p1->names, Text::lit("#owner"))};
        prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(std::get<0>(_m))) && prism_rtl::is<crate::lower::model::Ex::XVar>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(std::get<0>(_m))).a0) && prism_rtl::is_some(std::get<1>(_m)) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(std::get<1>(_m))) && prism_rtl::is<crate::lower::model::Ex::XVar>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(std::get<1>(_m))).a0) ? ({
        auto&& getter_p6 = prism_rtl::as<crate::lower::model::Ex::XVar>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(std::get<0>(_m))).a0).a0;
        auto&& dt_p7 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(std::get<0>(_m))).a2;
        auto&& owner_p8 = prism_rtl::as<crate::lower::model::Ex::XVar>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(std::get<1>(_m))).a0).a0;
        ({
        auto d_p3_1 = d_p3;
        auto env_p1_2 = env_p1;
        auto lx_p0_3 = lx_p0;
        auto t_p5_4 = t_p5;
        auto variant_p4_5 = variant_p4;
        call_then(start_value_of(lx_p0_3, crate::lower::node_::def::init_env(env_p1_2), d_p3_1), [=, t_p5_4 = std::move(t_p5_4), variant_p4_5 = std::move(variant_p4_5)](crate::lower::types::Vl value_of_19212) {
        return ({
            auto at_build_p9 = crate::lower::types::own(value_of_19212);
            auto arms_pa = Array(std::vector{crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("owner")})})}), .conds = Array<crate::lower::model::Cc>{}, .body = crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant_p4_5, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("owner")})), getter_p6, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})})}, crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{Text::lit("None")}), .conds = Array<crate::lower::model::Cc>{}, .body = crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant_p4_5, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("at_build")}))})})})}});
            auto read_pb = crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("cx")})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Cx"), Array<crate::lower::model::OutTy>{}}))})})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMatch{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("link")})), Text::lit("owner"), Array<crate::lower::model::Ex>{}})), arms_pa, false, crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("crate::Answer"), Array<crate::lower::model::OutTy>{}})}))});
            auto dynamic_pc = crate::lower::model::Ex(crate::lower::model::Ex::XBlock{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("link")}), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{owner_p8}))})}), crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("at_build")}), at_build_p9})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::Dynamic::of"), Array(std::vector{read_pb, crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat(getter_p6, "_port")}))})})}))});
            (prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::dynamic_blueprint::<crate::Elem, _>"), Array(std::vector{dynamic_pc})}), t_p5_4})));
        });
    });
    });
    })
        : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("`@ ", crate::lower::functions::src_text(lx_p0, lx_p0->file, prism_rtl::deref(x_p2).span), "`, a supplier\'s dynamic answer that reads what has no value at the owner\'s build (a pushed place, a structural dynamic, or a `let` after the host\'s line)")), t_p5}));
    });
}


/// `Start DynamicBlueprint, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_dynamic_blueprint_(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr x_p2, crate::syntax::Expr d_p3, Text variant_p4, crate::lower::model::OutTy t_p5) {
    return prism_rtl::make_rc<DynamicBlueprint>(lx_p0, env_p1, x_p2, d_p3, variant_p4, t_p5);
}


/// ElementBlueprint: unbounded fn Lx, Env, [Arg], OutTy -> Vl
crate::lower::types::Vl element_blueprint_(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Array<crate::syntax::Arg>& args_p2, const crate::lower::model::OutTy& t_p3) {
    auto&& _m = index(args_p2, Nat(0u));
    if (prism_rtl::is_some(_m)) {
        auto&& a_p4 = prism_rtl::some_of(_m);
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::element_blueprint::<crate::Elem, crate::Answer>"), Array(std::vector{crate::lower::types::ref_(value_of(lx_p0, env_p1, a_p4->value))})}), t_p3});
    }
    if (prism_rtl::is_none(_m)) {
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(Text::lit("`@Element` without its element")), t_p3});
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::types::Vl> ElementBlueprint::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& args_p2 = this->args_p2;
    const auto& t_p3 = this->t_p3;
    return ({
        auto&& _m = index(args_p2, Nat(0u));
        prism_rtl::is_some(_m) ? ({
        auto&& a_p4 = prism_rtl::some_of(_m);
        ({
        auto env_p1_1 = env_p1;
        auto lx_p0_2 = lx_p0;
        auto t_p3_3 = t_p3;
        call_then(start_value_of(lx_p0_2, env_p1_1, a_p4->value), [=, t_p3_3 = std::move(t_p3_3)](crate::lower::types::Vl value_of_20495) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::element_blueprint::<crate::Elem, crate::Answer>"), Array(std::vector{crate::lower::types::ref_(value_of_20495)})}), t_p3_3})); });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(Text::lit("`@Element` without its element")), t_p3}))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ElementBlueprint, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_element_blueprint_(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Array<crate::syntax::Arg> args_p2, crate::lower::model::OutTy t_p3) {
    return prism_rtl::make_rc<ElementBlueprint>(lx_p0, env_p1, args_p2, t_p3);
}


/// KindWords: fn ExprKind -> Text
Text kind_words(const crate::syntax::ExprKind& k_p0) {
    if (prism_rtl::is<crate::syntax::ExprKind::ESuffixed>(k_p0)) {
        auto&& op_p1 = prism_rtl::as<crate::syntax::ExprKind::ESuffixed>(k_p0).a0;
        return prism_rtl::cat("a suffixed `", op_p1, "`");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(k_p0)) {
        auto&& sg_p2 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(k_p0).a0;
        return prism_rtl::cat("a free `", sg_p2, "`");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETopicField>(k_p0)) {
        return Text::lit("a topic field (`&_.f` outside an `update`)");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETopicIndex>(k_p0)) {
        return Text::lit("a topic index");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ENonEmpty>(k_p0)) {
        return Text::lit("a non-empty literal");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EAbsent>(k_p0)) {
        return Text::lit("an absent value");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ERest>(k_p0)) {
        return Text::lit("a `..` rest");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(k_p0)) {
        return Text::lit("a lambda");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ERebuild>(k_p0)) {
        return Text::lit("a `rebuild` outside a widget block");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFor>(k_p0)) {
        return Text::lit("a `for` outside a widget block");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(k_p0)) {
        return Text::lit("a widget block");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMonad>(k_p0)) {
        return Text::lit("a monadic block");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELens>(k_p0)) {
        return Text::lit("a lens");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EError>(k_p0)) {
        return Text::lit("an expression the parser could not read");
    }
    {
        return Text::lit("an expression");
    }
}


/// NameValue: unbounded fn Lx, Env, SName, Range -> Vl
crate::lower::types::Vl name_value(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::SName& n_p2, const crate::syntax::Range& span_p3) {
    auto nkey_p4 = crate::lower::types::name_key_at(lx_p0, env_p1, n_p2, span_p3);
    auto t_p5 = crate::lower::types::out_ty_of(lx_p0, crate::lower::types::peel(crate::lower::type_at(lx_p0, span_p3)));
    auto local_o6 = len(n_p2.path_) == Nat(1u)
        ? crate::prelude::get(env_p1.names, nkey_p4)
        : std::optional<crate::lower::types::Bn>{};
    if (prism_rtl::is_some(local_o6) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(local_o6))) {
        auto&& rs_p7 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(local_o6)).a0;
        auto&& mode_p8 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(local_o6)).a1;
        auto&& lt_p9 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(local_o6)).a2;
        return crate::lower::types::local_place(rs_p7, mode_p8, lt_p9);
    }
    if (prism_rtl::is_some(local_o6) && prism_rtl::is<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(local_o6))) {
        auto&& f_pa = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(local_o6)).a0;
        auto&& ht_pb = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(local_o6)).a1;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f_pa)})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), ht_pb});
    }
    if (prism_rtl::is_some(local_o6) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(local_o6))) {
        auto&& x_pc = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(local_o6)).a0;
        auto&& dt_pd = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(local_o6)).a2;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{x_pc, dt_pd});
    }
    if (prism_rtl::is_some(local_o6) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(local_o6))) {
        auto&& et_pe = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(local_o6)).a1;
        auto&& _m = crate::prelude::get(env_p1.names, prism_rtl::cat(nkey_p4, "#port"));
        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
            auto&& pf_pf = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::Event::of"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(pf_pf)})})}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutEvent{prism_rtl::rc(crate::lower::types::out_ty_of(lx_p0, crate::lower::types::peel(crate::lower::types::peel(crate::lower::type_at(lx_p0, span_p3)))))})});
        }
        {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(Text::lit("an event read as a value")), et_pe});
        }
    }
    if (prism_rtl::is_some(local_o6) && prism_rtl::is<crate::lower::types::Bn::BnParts>(prism_rtl::some_of(local_o6))) {
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(Text::lit("a tuple pattern\'s binding as a value")), t_p5});
    }
    if (prism_rtl::is_some(local_o6) && prism_rtl::is<crate::lower::types::Bn::BnWidget>(prism_rtl::some_of(local_o6))) {
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(Text::lit("a widget parameter read as a plain value")), t_p5});
    }
    if (prism_rtl::is_some(local_o6) && prism_rtl::is<crate::lower::types::Bn::BnLocalFn>(prism_rtl::some_of(local_o6))) {
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(Text::lit("a local function as a value")), t_p5});
    }
    if (prism_rtl::is_none(local_o6)) {
        auto [qk_og, why_ph] = crate::check::env::names::resolve_value(lx_p0.g, lx_p0.home, n_p2);
        if (prism_rtl::is_some(qk_og)) {
            auto&& m22571_0 = prism_rtl::some_of(qk_og);
            if (m22571_0 == Text::lit("True")) {
                return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBool{true}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})});
            }
        }
        if (prism_rtl::is_some(qk_og)) {
            auto&& m22571_1 = prism_rtl::some_of(qk_og);
            if (m22571_1 == Text::lit("False")) {
                return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBool{false}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})});
            }
        }
        if (prism_rtl::is_some(qk_og)) {
            auto&& m22571_2 = prism_rtl::some_of(qk_og);
            if (m22571_2 == Text::lit("Prelude.never")) {
                return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Event::never"), Array<crate::lower::model::Ex>{}}), t_p5});
            }
        }
        if (prism_rtl::is_some(qk_og)) {
            auto&& qk_pi = prism_rtl::some_of(qk_og);
            auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g).tags, qk_pi);
            if (prism_rtl::is_some(_m)) {
                auto&& tg_pj = prism_rtl::some_of(_m);
                if ((prism_rtl::deref(tg_pj).kind != Text::lit("Prelude.Fault")) && (why_ph == Text::lit("tag"))) {
                    return tag_value(lx_p0, env_p1, tg_pj, Array<crate::syntax::Arg>{});
                }
            }
            {
                return global_value(lx_p0, qk_pi, span_p3, t_p5);
            }
        }
        if (prism_rtl::is_none(qk_og)) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("the name ", nkey_p4, ", which nothing declares")), t_p5});
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::types::Vl> NameValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& n_p2 = this->n_p2;
    const auto& span_p3 = this->span_p3;
    auto nkey_p4 = crate::lower::types::name_key_at(lx_p0, env_p1, n_p2, span_p3);
    auto env_p1_1 = env_p1;
    auto lx_p0_2 = lx_p0;
    auto n_p2_3 = n_p2;
    auto span_p3_4 = span_p3;
    return call_then(crate::lower::types::start_out_ty_of(lx_p0_2, crate::lower::types::peel(crate::lower::type_at(lx_p0_2, span_p3_4))), [=](crate::lower::model::OutTy out_ty_of_21601) {
        return ({
            auto t_p5 = out_ty_of_21601;
            auto local_o6 = len(n_p2_3->path_) == Nat(1u)
                ? crate::prelude::get(env_p1_1->names, nkey_p4)
                : std::optional<crate::lower::types::Bn>{};
            ({
            prism_rtl::is_some(local_o6) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(local_o6)) ? ({
            auto&& rs_p7 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(local_o6)).a0;
            auto&& mode_p8 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(local_o6)).a1;
            auto&& lt_p9 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(local_o6)).a2;
            prism_rtl::finished(crate::lower::types::local_place(rs_p7, mode_p8, lt_p9));
        })
            : prism_rtl::is_some(local_o6) && prism_rtl::is<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(local_o6)) ? ({
            auto&& f_pa = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(local_o6)).a0;
            auto&& ht_pb = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(local_o6)).a1;
            prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f_pa)})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), ht_pb}));
        })
            : prism_rtl::is_some(local_o6) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(local_o6)) ? ({
            auto&& x_pc = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(local_o6)).a0;
            auto&& dt_pd = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(local_o6)).a2;
            prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{x_pc, dt_pd}));
        })
            : prism_rtl::is_some(local_o6) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(local_o6)) ? ({
            auto&& et_pe = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(local_o6)).a1;
            ({
            auto&& _m = crate::prelude::get(env_p1_1->names, prism_rtl::cat(nkey_p4, "#port"));
            prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)) ? ({
            auto&& pf_pf = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
            call_then(crate::lower::types::start_out_ty_of(lx_p0_2, crate::lower::types::peel(crate::lower::types::peel(crate::lower::type_at(lx_p0_2, span_p3_4)))), [=](crate::lower::model::OutTy out_ty_of_22081) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::Event::of"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(pf_pf)})})}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutEvent{prism_rtl::rc(out_ty_of_22081)})})); });
        })
            : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(Text::lit("an event read as a value")), et_pe}));
        });
        })
            : prism_rtl::is_some(local_o6) && prism_rtl::is<crate::lower::types::Bn::BnParts>(prism_rtl::some_of(local_o6)) ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(Text::lit("a tuple pattern\'s binding as a value")), t_p5}))
            : prism_rtl::is_some(local_o6) && prism_rtl::is<crate::lower::types::Bn::BnWidget>(prism_rtl::some_of(local_o6)) ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(Text::lit("a widget parameter read as a plain value")), t_p5}))
            : prism_rtl::is_some(local_o6) && prism_rtl::is<crate::lower::types::Bn::BnLocalFn>(prism_rtl::some_of(local_o6)) ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(Text::lit("a local function as a value")), t_p5}))
            : prism_rtl::is_none(local_o6) ? ({
            auto [qk_og, why_ph] = crate::check::env::names::resolve_value(prism_rtl::deref(lx_p0_2).g, prism_rtl::deref(lx_p0_2).home, n_p2_3);
            ({
            prism_rtl::is_some(qk_og) && ({
            auto&& m22571_0 = prism_rtl::some_of(qk_og);
            (m22571_0 == Text::lit("True"));
        }) ? ({
            auto&& m22571_0 = prism_rtl::some_of(qk_og);
            prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBool{true}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})}));
        })
            : prism_rtl::is_some(qk_og) && ({
            auto&& m22571_1 = prism_rtl::some_of(qk_og);
            (m22571_1 == Text::lit("False"));
        }) ? ({
            auto&& m22571_1 = prism_rtl::some_of(qk_og);
            prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBool{false}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})}));
        })
            : prism_rtl::is_some(qk_og) && ({
            auto&& m22571_2 = prism_rtl::some_of(qk_og);
            (m22571_2 == Text::lit("Prelude.never"));
        }) ? ({
            auto&& m22571_2 = prism_rtl::some_of(qk_og);
            prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Event::never"), Array<crate::lower::model::Ex>{}}), t_p5}));
        })
            : prism_rtl::is_some(qk_og) ? ({
            auto&& qk_pi = prism_rtl::some_of(qk_og);
            ({
            auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0_2).g).tags, qk_pi);
            prism_rtl::is_some(_m) && ({
            auto&& tg_pj = prism_rtl::some_of(_m);
            ((prism_rtl::deref(tg_pj).kind != Text::lit("Prelude.Fault")) && (why_ph == Text::lit("tag")));
        }) ? ({
            auto&& tg_pj = prism_rtl::some_of(_m);
            prism_rtl::more(prism_rtl::rc(TagValue(lx_p0_2, env_p1_1, tg_pj, Array<crate::syntax::Arg>{})));
        })
            : prism_rtl::more(prism_rtl::rc(GlobalValue(lx_p0_2, qk_pi, span_p3_4, t_p5)));
        });
        })
            : prism_rtl::is_none(qk_og) ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("the name ", nkey_p4, ", which nothing declares")), t_p5}))
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
}


/// `Start NameValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_name_value(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::SName n_p2, crate::syntax::Range span_p3) {
    return prism_rtl::make_rc<NameValue>(lx_p0, env_p1, n_p2, span_p3);
}


/// GlobalValue: unbounded fn Lx, Text, Range, OutTy -> Vl
crate::lower::types::Vl global_value(const crate::lower::Lx& lx_p0, const Text& qk_p1, const crate::syntax::Range& span_p2, const crate::lower::model::OutTy& t_p3) {
    auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g).ctors, qk_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& c_p4 = prism_rtl::some_of(_m);
        auto arity_p5 = len(prism_rtl::deref(c_p4).fields) > Nat(0u)
            ? len(prism_rtl::deref(c_p4).fields)
            : len(c_p4->args);
        if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(t_p3)) {
            auto&& pts_p6 = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p3).a0;
            return arity_p5 > Nat(0u)
                ? ctor_fn(lx_p0, c_p4, pts_p6, span_p2, t_p3, false)
                : ctor_app(lx_p0, crate::lower::types::empty_env(), c_p4, Array<crate::syntax::Arg>{}, span_p2);
        }
        if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t_p3)) {
            auto&& a_p7 = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t_p3).a0;
            auto pts_p8 = ({
                __label__ _done;
                prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
                auto&& _m = prism_rtl::deref(prism_rtl::deref(a_p7));
                if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(_m)) {
                    auto&& ts_p9 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(_m).a0;
                    _v.set(arity_p5 == Nat(1u)
                        ? Array(std::vector{prism_rtl::deref(prism_rtl::deref(a_p7))})
                        : ts_p9);
                    goto _done;
                }
                {
                    _v.set(Array(std::vector{prism_rtl::deref(prism_rtl::deref(a_p7))}));
                    goto _done;
                }
            _done:
                _v.take();
            });
            return arity_p5 > Nat(0u)
                ? ctor_fn(lx_p0, c_p4, pts_p8, span_p2, t_p3, true)
                : ctor_app(lx_p0, crate::lower::types::empty_env(), c_p4, Array<crate::syntax::Arg>{}, span_p2);
        }
        {
            return ctor_app(lx_p0, crate::lower::types::empty_env(), c_p4, Array<crate::syntax::Arg>{}, span_p2);
        }
    }
    if (prism_rtl::is_none(_m)) {
        auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g).tags, qk_p1);
        if (prism_rtl::is_some(_m)) {
            auto&& tg_pa = prism_rtl::some_of(_m);
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XStr{prism_rtl::deref(tg_pa).name}), t_p3});
        }
        if (prism_rtl::is_none(_m)) {
            return fold(prism_rtl::deref(lx_p0.g).defs, false, [&](const bool& f_pb, const crate::check::env::Def& d_pc) { return prism_rtl::deref(f_pb) || ((prism_rtl::deref(d_pc).qk == qk_p1) && is_let_def(d_pc)); })
                ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::value_path(lx_p0, qk_p1), Array<crate::lower::model::Ex>{}}), t_p3})
                : ({
                __label__ _done;
                prism_rtl::Slot<crate::lower::types::Vl> _v;
                auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g).vals, qk_p1);
                if (prism_rtl::is_some(_m)) {
                    auto&& v_pd = prism_rtl::some_of(_m);
                    _v.set(({
                        auto is_let_pe = fold(prism_rtl::deref(lx_p0.g).defs, false, [&](const bool& f_pf, const crate::check::env::Def& d_pg) { return prism_rtl::deref(f_pf) || ((prism_rtl::deref(d_pg).qk == qk_p1) && is_let_def(d_pg)); });
                        (std::move(is_let_pe)
                        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::value_path(lx_p0, qk_p1), Array<crate::lower::model::Ex>{}}), t_p3})
                        : ({
                        __label__ _done;
                        prism_rtl::Slot<crate::lower::types::Vl> _v;
                        if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t_p3)) {
                            auto&& a_ph = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t_p3).a0;
                            _v.set(({
                                auto [ps_pl, ignore2_pm] = crate::lower::jobs::scheme_parts(lx_p0, qk_p1);
                                auto names_pi = each(crate::check::errors::range0(len(ps_pl)), [&](const Nat& i_pn) { return prism_rtl::cat("a", i_pn); });
                                auto pa_pj = len(ps_pl) == Nat(1u)
                                    ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("a0")})), prism_rtl::deref(prism_rtl::deref(a_ph))})
                                    : crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(names_pi, [&](const Text& nm_po) { return crate::lower::model::Pa(crate::lower::model::Pa::PaBind{nm_po}); })})), prism_rtl::deref(prism_rtl::deref(a_ph))});
                                auto f_pk = crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{pa_pj}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("entered"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{start_path(lx_p0, qk_p1), each(names_pi, [&](const Text& nm_pp) { return crate::lower::model::Ex(crate::lower::model::Ex::XVar{nm_pp}); })})})}))});
                                (crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{f_pk})})), t_p3}), t_p3}));
                            }));
                            goto _done;
                        }
                        {
                            _v.set(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XPath{crate::lower::value_path(lx_p0, qk_p1)})})}), t_p3}));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("the global ", qk_p1)), t_p3}));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::types::Vl> GlobalValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& qk_p1 = this->qk_p1;
    const auto& span_p2 = this->span_p2;
    const auto& t_p3 = this->t_p3;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0).g).ctors, qk_p1);
        prism_rtl::is_some(_m) ? ({
        auto&& c_p4 = prism_rtl::some_of(_m);
        ({
        auto arity_p5 = len(prism_rtl::deref(c_p4).fields) > Nat(0u)
            ? len(prism_rtl::deref(c_p4).fields)
            : len(c_p4->args);
        ({
        prism_rtl::is<crate::lower::model::OutTy::OutFn>(t_p3) ? ({
        auto&& pts_p6 = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p3).a0;
        arity_p5 > Nat(0u)
        ? prism_rtl::more(prism_rtl::rc(CtorFn(lx_p0, c_p4, pts_p6, span_p2, t_p3, false)))
        : prism_rtl::more(prism_rtl::rc(CtorApp(lx_p0, crate::lower::types::empty_env(), c_p4, Array<crate::syntax::Arg>{}, span_p2)));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t_p3) ? ({
        auto&& a_p7 = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t_p3).a0;
        ({
        auto pts_p8 = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(a_p7));
            if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(_m)) {
                auto&& ts_p9 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(_m).a0;
                _v.set(arity_p5 == Nat(1u)
                    ? Array(std::vector{prism_rtl::deref(prism_rtl::deref(a_p7))})
                    : ts_p9);
                goto _done;
            }
            {
                _v.set(Array(std::vector{prism_rtl::deref(prism_rtl::deref(a_p7))}));
                goto _done;
            }
        _done:
            _v.take();
        });
        arity_p5 > Nat(0u)
        ? prism_rtl::more(prism_rtl::rc(CtorFn(lx_p0, c_p4, pts_p8, span_p2, t_p3, true)))
        : prism_rtl::more(prism_rtl::rc(CtorApp(lx_p0, crate::lower::types::empty_env(), c_p4, Array<crate::syntax::Arg>{}, span_p2)));
    });
    })
        : prism_rtl::more(prism_rtl::rc(CtorApp(lx_p0, crate::lower::types::empty_env(), c_p4, Array<crate::syntax::Arg>{}, span_p2)));
    });
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0).g).tags, qk_p1);
        prism_rtl::is_some(_m) ? ({
        auto&& tg_pa = prism_rtl::some_of(_m);
        prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XStr{prism_rtl::deref(tg_pa).name}), t_p3}));
    })
        : prism_rtl::is_none(_m) ? fold(prism_rtl::deref(prism_rtl::deref(lx_p0).g).defs, false, [&](const bool& f_pb, const crate::check::env::Def& d_pc) { return prism_rtl::deref(f_pb) || ((prism_rtl::deref(d_pc).qk == qk_p1) && is_let_def(d_pc)); })
        ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::value_path(lx_p0, qk_p1), Array<crate::lower::model::Ex>{}}), t_p3}))
        : ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0).g).vals, qk_p1);
        prism_rtl::is_some(_m) ? ({
        auto&& v_pd = prism_rtl::some_of(_m);
        ({
        auto is_let_pe = fold(prism_rtl::deref(prism_rtl::deref(lx_p0).g).defs, false, [&](const bool& f_pf, const crate::check::env::Def& d_pg) { return prism_rtl::deref(f_pf) || ((prism_rtl::deref(d_pg).qk == qk_p1) && is_let_def(d_pg)); });
        (std::move(is_let_pe)
        ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::value_path(lx_p0, qk_p1), Array<crate::lower::model::Ex>{}}), t_p3}))
        : ({
        prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t_p3) ? ({
        auto&& a_ph = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t_p3).a0;
        ({
        auto [ps_pl, ignore2_pm] = crate::lower::jobs::scheme_parts(lx_p0, qk_p1);
        auto names_pi = each(crate::check::errors::range0(len(ps_pl)), [&](const Nat& i_pn) { return prism_rtl::cat("a", i_pn); });
        auto pa_pj = len(ps_pl) == Nat(1u)
            ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("a0")})), prism_rtl::deref(prism_rtl::deref(a_ph))})
            : crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(names_pi, [&](const Text& nm_po) { return crate::lower::model::Pa(crate::lower::model::Pa::PaBind{nm_po}); })})), prism_rtl::deref(prism_rtl::deref(a_ph))});
        auto f_pk = crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{pa_pj}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("entered"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{start_path(lx_p0, qk_p1), each(names_pi, [&](const Text& nm_pp) { return crate::lower::model::Ex(crate::lower::model::Ex::XVar{nm_pp}); })})})}))});
        (prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{f_pk})})), t_p3}), t_p3})));
    });
    })
        : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XPath{crate::lower::value_path(lx_p0, qk_p1)})})}), t_p3}));
    }));
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("the global ", qk_p1)), t_p3}))
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start GlobalValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_global_value(crate::lower::Lx lx_p0, Text qk_p1, crate::syntax::Range span_p2, crate::lower::model::OutTy t_p3) {
    return prism_rtl::make_rc<GlobalValue>(lx_p0, qk_p1, span_p2, t_p3);
}


/// IsLetDef: fn Def -> Bool
bool is_let_def(const crate::check::env::Def& d_p0) {
    auto&& _m = d_p0.body;
    if (prism_rtl::is<crate::check::env::DefBody::DbLet>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// StartPath: fn Lx, Text -> Text
Text start_path(const crate::lower::Lx& lx_p0, const Text& qk_p1) {
    auto owner_p2 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g).vals, qk_p1);
        if (prism_rtl::is_some(_m)) {
            auto&& v_p3 = prism_rtl::some_of(_m);
            _v.set(prism_rtl::deref(v_p3).home);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::lower::owner_of(qk_p1));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return crate::lower::path_in(lx_p0, owner_p2, prism_rtl::cat("start_", or_(crate::prelude::get(lx_p0.rs_names, qk_p1), crate::lower::snake(crate::check::types::bare_name(qk_p1)))));
}


/// Application: unbounded fn Lx, Env, Expr, [Arg], Range -> Vl
crate::lower::types::Vl application(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& callee_p2, const Array<crate::syntax::Arg>& args_p3, const crate::syntax::Range& span_p4) {
    auto t_p5 = crate::lower::types::out_ty_of(lx_p0, crate::lower::types::peel(crate::lower::type_at(lx_p0, span_p4)));
    auto&& _m = prism_rtl::deref(callee_p2.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p6 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        auto nkey_p7 = crate::lower::types::name_key_at(lx_p0, env_p1, n_p6, callee_p2.span);
        auto local_o8 = len(n_p6->path_) == Nat(1u)
            ? crate::prelude::get(env_p1.names, nkey_p7)
            : std::optional<crate::lower::types::Bn>{};
        if (prism_rtl::is_some(local_o8) && prism_rtl::is<crate::lower::types::Bn::BnLocalFn>(prism_rtl::some_of(local_o8))) {
            auto&& c_p9 = prism_rtl::as<crate::lower::types::Bn::BnLocalFn>(prism_rtl::some_of(local_o8)).a0;
            return inline_local_fn(lx_p0, env_p1, c_p9, args_p3, t_p5);
        }
        if (prism_rtl::is_some(local_o8)) {
            auto&& b_pa = prism_rtl::some_of(local_o8);
            auto f_pb = name_value(lx_p0, env_p1, n_p6, callee_p2.span);
            auto&& _m = crate::lower::types::value_ty(f_pb);
            if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m)) {
                return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("run_to_end"), Array(std::vector{crate::lower::jobs::start_call(f_pb, start_args(lx_p0, env_p1, f_pb, args_p3))})}), t_p5});
            }
            {
                return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XApply{prism_rtl::rc(crate::lower::types::ref_(f_pb)), run_to_end(each_job(args_p3, ({
                    auto lx_p0_1 = lx_p0;
                    auto env_p1_2 = env_p1;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1), env_p1_2 = std::move(env_p1_2)](crate::syntax::Arg p0) {
                    return ({
                        auto lx_p0_1_3 = lx_p0_1;
                        auto env_p1_2_3 = env_p1_2;
                        entered(once_job([=, lx_p0_1_3 = std::move(lx_p0_1_3), env_p1_2_3 = std::move(env_p1_2_3)]() {
                        return ({
                            auto a_pc = p0;
                            (prism_rtl::more(prism_rtl::rc(Argument(lx_p0_1_3, env_p1_2_3, a_pc->value))));
                        });
                    }));
                    });
                })));
                })))}), t_p5});
            }
        }
        if (prism_rtl::is_none(local_o8)) {
            auto [qk_od, why_pe] = crate::check::env::names::resolve_value(lx_p0.g, lx_p0.home, n_p6);
            if (prism_rtl::is_some(qk_od)) {
                auto&& qk_pf = prism_rtl::some_of(qk_od);
                auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g).tags, qk_pf);
                if (prism_rtl::is_some(_m)) {
                    auto&& tg_pg = prism_rtl::some_of(_m);
                    if (why_pe == Text::lit("tag")) {
                        return tag_value(lx_p0, env_p1, tg_pg, args_p3);
                    }
                }
                {
                    return qk_pf == Text::lit("Prelude.@Element")
                        ? element_blueprint_(lx_p0, env_p1, args_p3, t_p5)
                        : global_call(lx_p0, env_p1, qk_pf, args_p3, span_p4, t_p5);
                }
            }
            if (prism_rtl::is_none(qk_od)) {
                return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("a call of ", nkey_p7, ", which nothing declares")), t_p5});
            }
            prism_rtl::unreachable("no arm matched");
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_ph = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return application(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_ph)), args_p3, span_p4);
    }
    {
        auto f_pi = value_of(lx_p0, env_p1, callee_p2);
        auto&& _m = crate::lower::types::value_ty(f_pi);
        if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m)) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("run_to_end"), Array(std::vector{crate::lower::jobs::start_call(f_pi, start_args(lx_p0, env_p1, f_pi, args_p3))})}), t_p5});
        }
        {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XApply{prism_rtl::rc(crate::lower::types::ref_(f_pi)), run_to_end(each_job(args_p3, ({
                auto lx_p0_1 = lx_p0;
                auto env_p1_2 = env_p1;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1), env_p1_2 = std::move(env_p1_2)](crate::syntax::Arg p0) {
                return ({
                    auto lx_p0_1_3 = lx_p0_1;
                    auto env_p1_2_3 = env_p1_2;
                    entered(once_job([=, lx_p0_1_3 = std::move(lx_p0_1_3), env_p1_2_3 = std::move(env_p1_2_3)]() {
                    return ({
                        auto a_pj = p0;
                        (prism_rtl::more(prism_rtl::rc(Argument(lx_p0_1_3, env_p1_2_3, a_pj->value))));
                    });
                }));
                });
            })));
            })))}), t_p5});
        }
    }
}


prism_rtl::Turn<crate::lower::types::Vl> Application::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& callee_p2 = this->callee_p2;
    const auto& args_p3 = this->args_p3;
    const auto& span_p4 = this->span_p4;
    auto args_p3_1 = args_p3;
    auto callee_p2_2 = callee_p2;
    auto env_p1_3 = env_p1;
    auto lx_p0_4 = lx_p0;
    auto span_p4_5 = span_p4;
    return call_then(crate::lower::types::start_out_ty_of(lx_p0_4, crate::lower::types::peel(crate::lower::type_at(lx_p0_4, span_p4_5))), [=](crate::lower::model::OutTy out_ty_of_25472) {
        return ({
            auto t_p5 = out_ty_of_25472;
            ({
            auto&& _m = prism_rtl::deref(prism_rtl::deref(callee_p2_2).kind);
            prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
            auto&& n_p6 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            ({
            auto nkey_p7 = crate::lower::types::name_key_at(lx_p0_4, env_p1_3, n_p6, prism_rtl::deref(callee_p2_2).span);
            auto local_o8 = len(n_p6->path_) == Nat(1u)
                ? crate::prelude::get(env_p1_3->names, nkey_p7)
                : std::optional<crate::lower::types::Bn>{};
            ({
            prism_rtl::is_some(local_o8) && prism_rtl::is<crate::lower::types::Bn::BnLocalFn>(prism_rtl::some_of(local_o8)) ? ({
            auto&& c_p9 = prism_rtl::as<crate::lower::types::Bn::BnLocalFn>(prism_rtl::some_of(local_o8)).a0;
            prism_rtl::more(prism_rtl::rc(InlineLocalFn(lx_p0_4, env_p1_3, c_p9, args_p3_1, t_p5)));
        })
            : prism_rtl::is_some(local_o8) ? ({
            auto&& b_pa = prism_rtl::some_of(local_o8);
            ({
            auto n_p6_6 = n_p6;
            call_then(start_name_value(lx_p0_4, env_p1_3, n_p6_6, prism_rtl::deref(callee_p2_2).span), [=](crate::lower::types::Vl name_value_25821) {
            return ({
                auto f_pb = name_value_25821;
                ({
                auto&& _m = crate::lower::types::value_ty(f_pb);
                prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m) ? call_then(start_start_args(lx_p0_4, env_p1_3, f_pb, args_p3_1), [=](Array<crate::lower::model::Ex> start_args_26015) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("run_to_end"), Array(std::vector{crate::lower::jobs::start_call(f_pb, start_args_26015)})}), t_p5})); })
                : call_value(each_job(args_p3_1, ({
                auto lx_p0_4_7 = lx_p0_4;
                auto env_p1_3_7 = env_p1_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=, lx_p0_4_7 = std::move(lx_p0_4_7), env_p1_3_7 = std::move(env_p1_3_7)](crate::syntax::Arg p0) {
                return ({
                    auto lx_p0_4_7_7 = lx_p0_4_7;
                    auto env_p1_3_7_7 = env_p1_3_7;
                    entered(once_job([=, lx_p0_4_7_7 = std::move(lx_p0_4_7_7), env_p1_3_7_7 = std::move(env_p1_3_7_7)]() {
                    return ({
                        auto a_pc = p0;
                        (prism_rtl::more(prism_rtl::rc(Argument(lx_p0_4_7_7, env_p1_3_7_7, a_pc->value))));
                    });
                }));
                });
            })));
            })), [=](Array<crate::lower::model::Ex> each_26111) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XApply{prism_rtl::rc(crate::lower::types::ref_(f_pb)), each_26111}), t_p5})); });
            });
            });
        });
        });
        })
            : prism_rtl::is_none(local_o8) ? ({
            auto [qk_od, why_pe] = crate::check::env::names::resolve_value(prism_rtl::deref(lx_p0_4).g, prism_rtl::deref(lx_p0_4).home, n_p6);
            ({
            prism_rtl::is_some(qk_od) ? ({
            auto&& qk_pf = prism_rtl::some_of(qk_od);
            ({
            auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0_4).g).tags, qk_pf);
            prism_rtl::is_some(_m) && ({
            auto&& tg_pg = prism_rtl::some_of(_m);
            (why_pe == Text::lit("tag"));
        }) ? ({
            auto&& tg_pg = prism_rtl::some_of(_m);
            prism_rtl::more(prism_rtl::rc(TagValue(lx_p0_4, env_p1_3, tg_pg, args_p3_1)));
        })
            : qk_pf == Text::lit("Prelude.@Element")
            ? prism_rtl::more(prism_rtl::rc(ElementBlueprint(lx_p0_4, env_p1_3, args_p3_1, t_p5)))
            : prism_rtl::more(prism_rtl::rc(GlobalCall(lx_p0_4, env_p1_3, qk_pf, args_p3_1, span_p4_5, t_p5)));
        });
        })
            : prism_rtl::is_none(qk_od) ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("a call of ", nkey_p7, ", which nothing declares")), t_p5}))
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
            auto&& x_ph = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
            prism_rtl::more(prism_rtl::rc(Application(lx_p0_4, env_p1_3, prism_rtl::deref(prism_rtl::deref(x_ph)), args_p3_1, span_p4_5)));
        })
            : call_then(start_value_of(lx_p0_4, env_p1_3, callee_p2_2), [=](crate::lower::types::Vl value_of_26934) {
            return ({
                auto f_pi = value_of_26934;
                ({
                auto&& _m = crate::lower::types::value_ty(f_pi);
                prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m) ? call_then(start_start_args(lx_p0_4, env_p1_3, f_pi, args_p3_1), [=](Array<crate::lower::model::Ex> start_args_27074) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("run_to_end"), Array(std::vector{crate::lower::jobs::start_call(f_pi, start_args_27074)})}), t_p5})); })
                : call_value(each_job(args_p3_1, ({
                auto lx_p0_4_6 = lx_p0_4;
                auto env_p1_3_6 = env_p1_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=, lx_p0_4_6 = std::move(lx_p0_4_6), env_p1_3_6 = std::move(env_p1_3_6)](crate::syntax::Arg p0) {
                return ({
                    auto lx_p0_4_6_6 = lx_p0_4_6;
                    auto env_p1_3_6_6 = env_p1_3_6;
                    entered(once_job([=, lx_p0_4_6_6 = std::move(lx_p0_4_6_6), env_p1_3_6_6 = std::move(env_p1_3_6_6)]() {
                    return ({
                        auto a_pj = p0;
                        (prism_rtl::more(prism_rtl::rc(Argument(lx_p0_4_6_6, env_p1_3_6_6, a_pj->value))));
                    });
                }));
                });
            })));
            })), [=](Array<crate::lower::model::Ex> each_27162) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XApply{prism_rtl::rc(crate::lower::types::ref_(f_pi)), each_27162}), t_p5})); });
            });
            });
        });
        });
        });
    });
}


/// `Start Application, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_application(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr callee_p2, Array<crate::syntax::Arg> args_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<Application>(lx_p0, env_p1, callee_p2, args_p3, span_p4);
}


/// InlineLocalFn: unbounded fn Lx, Env, FnClause, [Arg], OutTy -> Vl
crate::lower::types::Vl inline_local_fn(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::decls::FnClause& c_p2, const Array<crate::syntax::Arg>& args_p3, const crate::lower::model::OutTy& t_p4) {
    auto names_p5 = each(c_p2.params, [&](const crate::syntax::Pattern_& p_p6) { return crate::lower::functions::plain_binder(lx_p0, p_p6); });
    return fold(names_p5, false, [&](const bool& bad_p7, const Text& nm_p8) { return prism_rtl::deref(bad_p7) || (nm_p8 == Text::lit("")); })
        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(Text::lit("a local function whose parameters are not names")), t_p4})
        : ({
        auto [dos_ph, env2_pi] = run_to_end(fold_job(crate::check::errors::range0(len(names_p5)), std::tuple{Array<crate::lower::model::Do>{}, env_p1}, ({
            auto names_p5_1 = names_p5;
            auto lx_p0_2 = lx_p0;
            auto c_p2_3 = c_p2;
            auto args_p3_4 = args_p3;
            auto env_p1_5 = env_p1;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>>(std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>, Nat>)>>(prism_rtl::rc([=, names_p5_1 = std::move(names_p5_1), lx_p0_2 = std::move(lx_p0_2), c_p2_3 = std::move(c_p2_3), args_p3_4 = std::move(args_p3_4), env_p1_5 = std::move(env_p1_5)](std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto names_p5_1_6 = names_p5_1;
                auto lx_p0_2_6 = lx_p0_2;
                auto c_p2_3_6 = c_p2_3;
                auto args_p3_4_6 = args_p3_4;
                auto env_p1_5_6 = env_p1_5;
                entered(once_job([=, names_p5_1_6 = std::move(names_p5_1_6), lx_p0_2_6 = std::move(lx_p0_2_6), c_p2_3_6 = std::move(c_p2_3_6), args_p3_4_6 = std::move(args_p3_4_6), env_p1_5_6 = std::move(env_p1_5_6)]() {
                return ({
                    auto [acc_p9, en_pa] = p0;
                    auto i_pb = p1;
                    ({
                    auto nm_pc = or_(index(names_p5_1_6, i_pb), Text::lit(""));
                    auto rs_pd = prism_rtl::cat(crate::lower::local_name(lx_p0_2_6, nm_pc), "_", prism_rtl::deref(c_p2_3_6.span).start);
                    auto v_pe = ({
                        __label__ _done;
                        prism_rtl::Slot<crate::lower::types::Vl> _v;
                        auto&& _m = index(args_p3_4_6, i_pb);
                        if (prism_rtl::is_some(_m)) {
                            auto&& a_pg = prism_rtl::some_of(_m);
                            _v.set(value_of(lx_p0_2_6, env_p1_5_6, a_pg->value));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    auto bt_pf = crate::lower::types::value_ty(v_pe);
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc_p9, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{rs_pd}), crate::lower::types::own(v_pe)})), crate::lower::types::bind(en_pa, nm_pc, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs_pd}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt_pf}))}));
                });
                });
            }));
            });
        }));
        })));
        (crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos_ph, prism_rtl::rc(crate::lower::functions::fn_body_value(lx_p0, env2_pi, c_p2.body))}), t_p4}));
    });
}


prism_rtl::Turn<crate::lower::types::Vl> InlineLocalFn::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& c_p2 = this->c_p2;
    const auto& args_p3 = this->args_p3;
    const auto& t_p4 = this->t_p4;
    auto names_p5 = each(prism_rtl::deref(c_p2).params, [&](const crate::syntax::Pattern_& p_p6) { return crate::lower::functions::plain_binder(lx_p0, p_p6); });
    return fold(names_p5, false, [&](const bool& bad_p7, const Text& nm_p8) { return prism_rtl::deref(bad_p7) || (nm_p8 == Text::lit("")); })
        ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(Text::lit("a local function whose parameters are not names")), t_p4}))
        : ({
        auto args_p3_1 = args_p3;
        auto c_p2_2 = c_p2;
        auto env_p1_3 = env_p1;
        auto lx_p0_4 = lx_p0;
        auto t_p4_5 = t_p4;
        call_value(fold_job(crate::check::errors::range0(len(names_p5)), std::tuple{Array<crate::lower::model::Do>{}, env_p1_3}, ({
        auto names_p5_6 = names_p5;
        auto lx_p0_4_7 = lx_p0_4;
        auto c_p2_2_7 = c_p2_2;
        auto args_p3_1_7 = args_p3_1;
        auto env_p1_3_7 = env_p1_3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>>(std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>, Nat>)>>(prism_rtl::rc([=, names_p5_6 = std::move(names_p5_6), lx_p0_4_7 = std::move(lx_p0_4_7), c_p2_2_7 = std::move(c_p2_2_7), args_p3_1_7 = std::move(args_p3_1_7), env_p1_3_7 = std::move(env_p1_3_7)](std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto names_p5_6_7 = names_p5_6;
            auto lx_p0_4_7_7 = lx_p0_4_7;
            auto c_p2_2_7_7 = c_p2_2_7;
            auto args_p3_1_7_7 = args_p3_1_7;
            auto env_p1_3_7_7 = env_p1_3_7;
            entered(once_job([=, names_p5_6_7 = std::move(names_p5_6_7), lx_p0_4_7_7 = std::move(lx_p0_4_7_7), c_p2_2_7_7 = std::move(c_p2_2_7_7), args_p3_1_7_7 = std::move(args_p3_1_7_7), env_p1_3_7_7 = std::move(env_p1_3_7_7)]() {
            return ({
                auto [acc_p9, en_pa] = p0;
                auto i_pb = p1;
                ({
                auto nm_pc = or_(index(names_p5_6_7, i_pb), Text::lit(""));
                auto rs_pd = prism_rtl::cat(crate::lower::local_name(lx_p0_4_7_7, nm_pc), "_", prism_rtl::deref(prism_rtl::deref(c_p2_2_7_7).span).start);
                auto v_pe = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::lower::types::Vl> _v;
                    auto&& _m = index(args_p3_1_7_7, i_pb);
                    if (prism_rtl::is_some(_m)) {
                        auto&& a_pg = prism_rtl::some_of(_m);
                        _v.set(value_of(lx_p0_4_7_7, env_p1_3_7_7, a_pg->value));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto bt_pf = crate::lower::types::value_ty(v_pe);
                (prism_rtl::finished(std::tuple{crate::prelude::push(acc_p9, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{rs_pd}), crate::lower::types::own(v_pe)})), crate::lower::types::bind(en_pa, nm_pc, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs_pd}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt_pf}))}));
            });
            });
        }));
        });
    }));
    })), [=, t_p4_5 = std::move(t_p4_5)](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> fold_27748) {
        return ({
            auto [dos_ph, env2_pi] = fold_27748;
            call_then(crate::lower::functions::start_fn_body_value(lx_p0_4, env2_pi, prism_rtl::deref(c_p2_2).body), [=](crate::lower::model::Ex fn_body_value_28194) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos_ph, prism_rtl::rc(fn_body_value_28194)}), t_p4_5})); });
        });
    });
    });
}


/// `Start InlineLocalFn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_inline_local_fn(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::decls::FnClause c_p2, Array<crate::syntax::Arg> args_p3, crate::lower::model::OutTy t_p4) {
    return prism_rtl::make_rc<InlineLocalFn>(lx_p0, env_p1, c_p2, args_p3, t_p4);
}


/// Argument: unbounded fn Lx, Env, Expr -> Ex
crate::lower::model::Ex argument(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2) {
    auto&& _m = crate::prelude::get(env_p1.spans, crate::lower::place_key(lx_p0, e_p2.span));
    if (prism_rtl::is_some(_m)) {
        auto&& v_p3 = prism_rtl::some_of(_m);
        return crate::lower::types::ref_(v_p3);
    }
    if (prism_rtl::is_none(_m)) {
        return argument_by_kind(lx_p0, env_p1, e_p2);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::model::Ex> Argument::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& e_p2 = this->e_p2;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(env_p1).spans, crate::lower::place_key(lx_p0, prism_rtl::deref(e_p2).span));
        prism_rtl::is_some(_m) ? ({
        auto&& v_p3 = prism_rtl::some_of(_m);
        prism_rtl::finished(crate::lower::types::ref_(v_p3));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(ArgumentByKind(lx_p0, env_p1, e_p2)))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start Argument, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_argument(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2) {
    return prism_rtl::make_rc<Argument>(lx_p0, env_p1, e_p2);
}


/// ArgumentByKind: unbounded fn Lx, Env, Expr -> Ex
crate::lower::model::Ex argument_by_kind(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2) {
    auto&& _m = prism_rtl::deref(e_p2.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
        auto&& ps_o3 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
        auto&& body_p4 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
        return crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(lambda_arg(lx_p0, env_p1, or_(ps_o3, Array<crate::syntax::Pattern_>{}), prism_rtl::deref(prism_rtl::deref(body_p4)), lambda_param_tys(lx_p0, e_p2, len(or_(ps_o3, Array<crate::syntax::Pattern_>{})))))});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p5 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return argument(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p5)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p6 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        auto t_p7 = crate::lower::type_at(lx_p0, e_p2.span);
        auto&& _m = crate::lower::types::peel(t_p7);
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CBound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0)) {
            auto local_o8 = len(n_p6->path_) == Nat(1u)
                ? crate::prelude::get(env_p1.names, crate::lower::types::name_key_at(lx_p0, env_p1, n_p6, e_p2.span))
                : std::optional<crate::lower::types::Bn>{};
            if (prism_rtl::is_some(local_o8)) {
                return closure_ref(value_of(lx_p0, env_p1, e_p2));
            }
            if (prism_rtl::is_none(local_o8)) {
                auto&& _qk_o9 = crate::check::env::names::resolve_value(lx_p0.g, lx_p0.home, n_p6);
                auto&& qk_o9 = std::get<0>(_qk_o9);
                if (prism_rtl::is_some(qk_o9)) {
                    auto&& qk_pa = prism_rtl::some_of(qk_o9);
                    return crate::check::env::has_key(prism_rtl::deref(lx_p0.g).ctors, qk_pa)
                        ? closure_ref(value_of(lx_p0, env_p1, e_p2))
                        : crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XPath{crate::lower::value_path(lx_p0, qk_pa)}))});
                }
                if (prism_rtl::is_none(qk_o9)) {
                    return crate::lower::types::ref_(value_of(lx_p0, env_p1, e_p2));
                }
                prism_rtl::unreachable("no arm matched");
            }
            prism_rtl::unreachable("no arm matched");
        }
        {
            return crate::lower::types::ref_(value_of(lx_p0, env_p1, e_p2));
        }
    }
    {
        return crate::lower::types::ref_(value_of(lx_p0, env_p1, e_p2));
    }
}


prism_rtl::Turn<crate::lower::model::Ex> ArgumentByKind::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& e_p2 = this->e_p2;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p2).kind);
        prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) ? ({
        auto&& ps_o3 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
        auto&& body_p4 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
        ({
        auto ps_o3_1 = ps_o3;
        auto body_p4_2 = prism_rtl::deref(prism_rtl::deref(body_p4));
        auto e_p2_3 = e_p2;
        auto env_p1_4 = env_p1;
        auto lx_p0_5 = lx_p0;
        call_then(start_lambda_param_tys(lx_p0_5, e_p2_3, len(or_(ps_o3_1, Array<crate::syntax::Pattern_>{}))), [=, body_p4_2 = std::move(body_p4_2), env_p1_4 = std::move(env_p1_4)](Array<crate::lower::model::OutTy> lambda_param_tys_28632) { return call_then(start_lambda_arg(lx_p0_5, env_p1_4, or_(ps_o3_1, Array<crate::syntax::Pattern_>{}), body_p4_2, lambda_param_tys_28632), [=](crate::lower::model::Ex lambda_arg_28590) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(lambda_arg_28590)})); }); });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x_p5 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(Argument(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p5)))));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n_p6 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        ({
        auto t_p7 = crate::lower::type_at(lx_p0, prism_rtl::deref(e_p2).span);
        ({
        auto&& _m = crate::lower::types::peel(t_p7);
        prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CBound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0) ? ({
        auto local_o8 = len(n_p6->path_) == Nat(1u)
            ? crate::prelude::get(env_p1->names, crate::lower::types::name_key_at(lx_p0, env_p1, n_p6, prism_rtl::deref(e_p2).span))
            : std::optional<crate::lower::types::Bn>{};
        ({
        prism_rtl::is_some(local_o8) ? ({
        auto e_p2_1 = e_p2;
        auto env_p1_2 = env_p1;
        auto lx_p0_3 = lx_p0;
        call_then(start_value_of(lx_p0_3, env_p1_2, e_p2_1), [=](crate::lower::types::Vl value_of_28994) { return prism_rtl::finished(closure_ref(value_of_28994)); });
    })
        : prism_rtl::is_none(local_o8) ? ({
        auto&& _qk_o9 = crate::check::env::names::resolve_value(prism_rtl::deref(lx_p0).g, prism_rtl::deref(lx_p0).home, n_p6);
        auto&& qk_o9 = std::get<0>(_qk_o9);
        ({
        prism_rtl::is_some(qk_o9) ? ({
        auto&& qk_pa = prism_rtl::some_of(qk_o9);
        crate::check::env::has_key(prism_rtl::deref(prism_rtl::deref(lx_p0).g).ctors, qk_pa)
        ? ({
        auto e_p2_1 = e_p2;
        auto env_p1_2 = env_p1;
        auto lx_p0_3 = lx_p0;
        call_then(start_value_of(lx_p0_3, env_p1_2, e_p2_1), [=](crate::lower::types::Vl value_of_29222) { return prism_rtl::finished(closure_ref(value_of_29222)); });
    })
        : prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XPath{crate::lower::value_path(lx_p0, qk_pa)}))}));
    })
        : prism_rtl::is_none(qk_o9) ? ({
        auto e_p2_1 = e_p2;
        auto env_p1_2 = env_p1;
        auto lx_p0_3 = lx_p0;
        call_then(start_value_of(lx_p0_3, env_p1_2, e_p2_1), [=](crate::lower::types::Vl value_of_29318) { return prism_rtl::finished(crate::lower::types::ref_(value_of_29318)); });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : ({
        auto e_p2_1 = e_p2;
        auto env_p1_2 = env_p1;
        auto lx_p0_3 = lx_p0;
        call_then(start_value_of(lx_p0_3, env_p1_2, e_p2_1), [=](crate::lower::types::Vl value_of_29366) { return prism_rtl::finished(crate::lower::types::ref_(value_of_29366)); });
    });
    });
    });
    })
        : ({
        auto e_p2_1 = e_p2;
        auto env_p1_2 = env_p1;
        auto lx_p0_3 = lx_p0;
        call_then(start_value_of(lx_p0_3, env_p1_2, e_p2_1), [=](crate::lower::types::Vl value_of_29406) { return prism_rtl::finished(crate::lower::types::ref_(value_of_29406)); });
    });
    });
}


/// `Start ArgumentByKind, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_argument_by_kind(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2) {
    return prism_rtl::make_rc<ArgumentByKind>(lx_p0, env_p1, e_p2);
}


/// ClosureRef: fn Vl -> Ex
crate::lower::model::Ex closure_ref(const crate::lower::types::Vl& vl0) {
    if (prism_rtl::is<crate::lower::types::Vl::VlPlace>(vl0) && prism_rtl::is<crate::lower::types::Holding::ByRef>(prism_rtl::as<crate::lower::types::Vl::VlPlace>(vl0).a1)) {
        auto&& x_p0 = prism_rtl::as<crate::lower::types::Vl::VlPlace>(vl0).a0;
        auto&& t_p1 = prism_rtl::as<crate::lower::types::Vl::VlPlace>(vl0).a2;
        return x_p0;
    }
    if (prism_rtl::is<crate::lower::types::Vl::VlPlace>(vl0)) {
        auto&& x_p2 = prism_rtl::as<crate::lower::types::Vl::VlPlace>(vl0).a0;
        auto&& t_p3 = prism_rtl::as<crate::lower::types::Vl::VlPlace>(vl0).a2;
        return crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(x_p2)}))});
    }
    if (prism_rtl::is<crate::lower::types::Vl::VlOwned>(vl0)) {
        auto&& x_p4 = prism_rtl::as<crate::lower::types::Vl::VlOwned>(vl0).a0;
        auto&& t_p5 = prism_rtl::as<crate::lower::types::Vl::VlOwned>(vl0).a1;
        return crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(x_p4)}))});
    }
    prism_rtl::unreachable("no arm matched");
}


/// TagValue: unbounded fn Lx, Env, TagInfo, [Arg] -> Vl
crate::lower::types::Vl tag_value(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::check::env::TagInfo& tg_p2, const Array<crate::syntax::Arg>& args_p3) {
    auto [variant_p5, struct_path_p6] = crate::lower::program::tag_paths(lx_p0, tg_p2);
    auto t_p4 = crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{crate::lower::program::kind_path(lx_p0, tg_p2.kind), Array<crate::lower::model::OutTy>{}});
    auto&& _m = tg_p2.kind;
    {
        auto&& m30157_0 = _m;
        if (m30157_0 == Text::lit("Element")) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("an element as a plain value (", tg_p2.name, "): a live element comes from its host")), t_p4});
        }
    }
    {
        auto&& m30157_1 = _m;
        if (m30157_1 == Text::lit("Prelude.Fault")) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("a fault kind applied (", tg_p2.name, ")")), t_p4});
        }
    }
    {
        auto named_p7 = fold(args_p3, false, [&](const bool& f_p9, const crate::syntax::Arg& a_pa) { return prism_rtl::deref(f_p9) || is_named_arg(a_pa); });
        auto fields_p8 = run_to_end(each_job(crate::check::errors::range0(len(tg_p2.fields)), ({
            auto tg_p2_1 = tg_p2;
            auto named_p7_2 = std::move(named_p7);
            auto args_p3_3 = args_p3;
            auto lx_p0_4 = lx_p0;
            auto env_p1_5 = env_p1;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::lower::model::Ex>>(Nat)>>(prism_rtl::rc([=, tg_p2_1 = std::move(tg_p2_1), named_p7_2 = std::move(named_p7_2), args_p3_3 = std::move(args_p3_3), lx_p0_4 = std::move(lx_p0_4), env_p1_5 = std::move(env_p1_5)](Nat p0) {
            return ({
                auto tg_p2_1_6 = tg_p2_1;
                auto named_p7_2_6 = named_p7_2;
                auto args_p3_3_6 = args_p3_3;
                auto lx_p0_4_6 = lx_p0_4;
                auto env_p1_5_6 = env_p1_5;
                entered(once_job([=, tg_p2_1_6 = std::move(tg_p2_1_6), named_p7_2_6 = std::move(named_p7_2_6), args_p3_3_6 = std::move(args_p3_3_6), lx_p0_4_6 = std::move(lx_p0_4_6), env_p1_5_6 = std::move(env_p1_5_6)]() {
                return ({
                    auto i_pb = p0;
                    ({
                    auto&& _fname_pe = or_(index(tg_p2_1_6.fields, i_pb), std::tuple{Text::lit(""), crate::check::types::Ty(crate::check::types::Ty::TyErr{})});
                    auto&& fname_pe = std::get<0>(_fname_pe);
                    auto arg_oc = named_p7_2_6
                        ? crate::lower::node_::elements::tag_arg(args_p3_3_6, fname_pe)
                        : ({
                        __label__ _done;
                        prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                        auto&& _m = index(args_p3_3_6, i_pb);
                        if (prism_rtl::is_some(_m)) {
                            auto&& a_pf = prism_rtl::some_of(_m);
                            _v.set(std::optional(a_pf->value));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(std::optional<crate::syntax::Expr>{});
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    auto v_pd = ({
                        __label__ _done;
                        prism_rtl::Slot<crate::lower::model::Ex> _v;
                        if (prism_rtl::is_some(arg_oc)) {
                            auto&& x_pg = prism_rtl::some_of(arg_oc);
                            _v.set(crate::lower::types::own(value_of(lx_p0_4_6, env_p1_5_6, x_pg)));
                            goto _done;
                        }
                        if (prism_rtl::is_none(arg_oc)) {
                            _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Default::default"), Array<crate::lower::model::Ex>{}}));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    (prism_rtl::finished(std::tuple{crate::lower::snake(fname_pe), v_pd}));
                });
                });
            }));
            });
        }));
        })));
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant_p5, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRecord{struct_path_p6, fields_p8})})}), t_p4});
    }
}


prism_rtl::Turn<crate::lower::types::Vl> TagValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& tg_p2 = this->tg_p2;
    const auto& args_p3 = this->args_p3;
    auto [variant_p5, struct_path_p6] = crate::lower::program::tag_paths(lx_p0, tg_p2);
    auto t_p4 = crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{crate::lower::program::kind_path(lx_p0, prism_rtl::deref(tg_p2).kind), Array<crate::lower::model::OutTy>{}});
    return ({
        auto&& _m = prism_rtl::deref(tg_p2).kind;
        ({
        auto&& m30157_0 = _m;
        (m30157_0 == Text::lit("Element"));
    }) ? ({
        auto&& m30157_0 = _m;
        prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("an element as a plain value (", prism_rtl::deref(tg_p2).name, "): a live element comes from its host")), t_p4}));
    })
        : ({
        auto&& m30157_1 = _m;
        (m30157_1 == Text::lit("Prelude.Fault"));
    }) ? ({
        auto&& m30157_1 = _m;
        prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("a fault kind applied (", prism_rtl::deref(tg_p2).name, ")")), t_p4}));
    })
        : ({
        auto named_p7 = fold(args_p3, false, [&](const bool& f_p9, const crate::syntax::Arg& a_pa) { return prism_rtl::deref(f_p9) || is_named_arg(a_pa); });
        auto args_p3_1 = args_p3;
        auto env_p1_2 = env_p1;
        auto lx_p0_3 = lx_p0;
        auto tg_p2_4 = tg_p2;
        call_value(each_job(crate::check::errors::range0(len(prism_rtl::deref(tg_p2_4).fields)), ({
        auto tg_p2_4_5 = tg_p2_4;
        auto named_p7_5 = std::move(named_p7);
        auto args_p3_1_6 = args_p3_1;
        auto lx_p0_3_6 = lx_p0_3;
        auto env_p1_2_6 = env_p1_2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::lower::model::Ex>>(Nat)>>(prism_rtl::rc([=, tg_p2_4_5 = std::move(tg_p2_4_5), named_p7_5 = std::move(named_p7_5), args_p3_1_6 = std::move(args_p3_1_6), lx_p0_3_6 = std::move(lx_p0_3_6), env_p1_2_6 = std::move(env_p1_2_6)](Nat p0) {
        return ({
            auto tg_p2_4_5_6 = tg_p2_4_5;
            auto named_p7_5_6 = named_p7_5;
            auto args_p3_1_6_6 = args_p3_1_6;
            auto lx_p0_3_6_6 = lx_p0_3_6;
            auto env_p1_2_6_6 = env_p1_2_6;
            entered(once_job([=, tg_p2_4_5_6 = std::move(tg_p2_4_5_6), named_p7_5_6 = std::move(named_p7_5_6), args_p3_1_6_6 = std::move(args_p3_1_6_6), lx_p0_3_6_6 = std::move(lx_p0_3_6_6), env_p1_2_6_6 = std::move(env_p1_2_6_6)]() {
            return ({
                auto i_pb = p0;
                ({
                auto&& _fname_pe = or_(index(prism_rtl::deref(tg_p2_4_5_6).fields, i_pb), std::tuple{Text::lit(""), crate::check::types::Ty(crate::check::types::Ty::TyErr{})});
                auto&& fname_pe = std::get<0>(_fname_pe);
                auto arg_oc = named_p7_5_6
                    ? crate::lower::node_::elements::tag_arg(args_p3_1_6_6, fname_pe)
                    : ({
                    __label__ _done;
                    prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                    auto&& _m = index(args_p3_1_6_6, i_pb);
                    if (prism_rtl::is_some(_m)) {
                        auto&& a_pf = prism_rtl::some_of(_m);
                        _v.set(std::optional(a_pf->value));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(std::optional<crate::syntax::Expr>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto v_pd = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::lower::model::Ex> _v;
                    if (prism_rtl::is_some(arg_oc)) {
                        auto&& x_pg = prism_rtl::some_of(arg_oc);
                        _v.set(crate::lower::types::own(value_of(lx_p0_3_6_6, env_p1_2_6_6, x_pg)));
                        goto _done;
                    }
                    if (prism_rtl::is_none(arg_oc)) {
                        _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Default::default"), Array<crate::lower::model::Ex>{}}));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                (prism_rtl::finished(std::tuple{crate::lower::snake(fname_pe), v_pd}));
            });
            });
        }));
        });
    }));
    })), [=](Array<std::tuple<Text, crate::lower::model::Ex>> each_30483) {
        return ({
            auto fields_p8 = each_30483;
            (prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant_p5, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRecord{struct_path_p6, fields_p8})})}), t_p4})));
        });
    });
    });
    });
}


/// `Start TagValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_tag_value(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::check::env::TagInfo tg_p2, Array<crate::syntax::Arg> args_p3) {
    return prism_rtl::make_rc<TagValue>(lx_p0, env_p1, tg_p2, args_p3);
}


/// GlobalCall: unbounded fn Lx, Env, Text, [Arg], Range, OutTy -> Vl
crate::lower::types::Vl global_call(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Text& qk_p2, const Array<crate::syntax::Arg>& args_p3, const crate::syntax::Range& span_p4, const crate::lower::model::OutTy& t_p5) {
    auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g).ctors, qk_p2);
    if (prism_rtl::is_some(_m)) {
        auto&& c_p6 = prism_rtl::some_of(_m);
        return ctor_app(lx_p0, env_p1, c_p6, args_p3, span_p4);
    }
    if (prism_rtl::is_none(_m)) {
        auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g).vals, qk_p2);
        if (prism_rtl::is_some(_m)) {
            auto&& v_p7 = prism_rtl::some_of(_m);
            return prism_rtl::deref(v_p7).sort == Text::lit("method")
                ? method_call(lx_p0, env_p1, v_p7, args_p3, span_p4, t_p5)
                : prism_rtl::deref(v_p7).home == Text::lit("Prelude")
                ? prelude_call(lx_p0, env_p1, qk_p2, args_p3, span_p4, t_p5)
                : as_instance(crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::value_path(lx_p0, qk_p2), args_for(lx_p0, env_p1, v_p7, args_p3)}), result_repr(lx_p0, v_p7), t_p5);
        }
        if (prism_rtl::is_none(_m)) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("a call of ", qk_p2)), t_p5});
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::types::Vl> GlobalCall::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& qk_p2 = this->qk_p2;
    const auto& args_p3 = this->args_p3;
    const auto& span_p4 = this->span_p4;
    const auto& t_p5 = this->t_p5;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0).g).ctors, qk_p2);
        prism_rtl::is_some(_m) ? ({
        auto&& c_p6 = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(CtorApp(lx_p0, env_p1, c_p6, args_p3, span_p4)));
    })
        : prism_rtl::is_none(_m) ? ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0).g).vals, qk_p2);
        prism_rtl::is_some(_m) ? ({
        auto&& v_p7 = prism_rtl::some_of(_m);
        prism_rtl::deref(v_p7).sort == Text::lit("method")
        ? prism_rtl::more(prism_rtl::rc(MethodCall(lx_p0, env_p1, v_p7, args_p3, span_p4, t_p5)))
        : prism_rtl::deref(v_p7).home == Text::lit("Prelude")
        ? prism_rtl::more(prism_rtl::rc(PreludeCall(lx_p0, env_p1, qk_p2, args_p3, span_p4, t_p5)))
        : ({
        auto args_p3_1 = args_p3;
        auto env_p1_2 = env_p1;
        auto lx_p0_3 = lx_p0;
        auto qk_p2_4 = qk_p2;
        auto t_p5_5 = t_p5;
        call_then(start_args_for(lx_p0_3, env_p1_2, v_p7, args_p3_1), [=, qk_p2_4 = std::move(qk_p2_4), t_p5_5 = std::move(t_p5_5)](Array<crate::lower::model::Ex> args_for_31526) { return call_then(start_result_repr(lx_p0_3, v_p7), [=](crate::lower::model::OutTy result_repr_31555) { return prism_rtl::more(prism_rtl::rc(AsInstance(crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::value_path(lx_p0_3, qk_p2_4), args_for_31526}), result_repr_31555, t_p5_5))); }); });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("a call of ", qk_p2)), t_p5}))
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start GlobalCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_global_call(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Text qk_p2, Array<crate::syntax::Arg> args_p3, crate::syntax::Range span_p4, crate::lower::model::OutTy t_p5) {
    return prism_rtl::make_rc<GlobalCall>(lx_p0, env_p1, qk_p2, args_p3, span_p4, t_p5);
}


/// ResultRepr: unbounded fn Lx, ValInfo -> OutTy
crate::lower::model::OutTy result_repr(const crate::lower::Lx& lx_p0, const crate::check::env::ValInfo& v_p1) {
    auto&& _m = prism_rtl::deref(v_p1.scheme).ty;
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
        auto&& r_p2 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
        return crate::lower::types::out_ty_of(lx_p0, crate::lower::types::peel(prism_rtl::deref(prism_rtl::deref(r_p2))));
    }
    {
        auto&& other_p3 = _m;
        return crate::lower::types::out_ty_of(lx_p0, crate::lower::types::peel(other_p3));
    }
}


prism_rtl::Turn<crate::lower::model::OutTy> ResultRepr::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& v_p1 = this->v_p1;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(v_p1).scheme).ty;
        prism_rtl::is<crate::check::types::Ty::TyFn>(_m) ? ({
        auto&& r_p2 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
        prism_rtl::more(prism_rtl::rc(crate::lower::types::OutTyOf(lx_p0, crate::lower::types::peel(prism_rtl::deref(prism_rtl::deref(r_p2))))));
    })
        : ({
        auto&& other_p3 = _m;
        prism_rtl::more(prism_rtl::rc(crate::lower::types::OutTyOf(lx_p0, crate::lower::types::peel(other_p3))));
    });
    });
}


/// `Start ResultRepr, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::OutTy> start_result_repr(crate::lower::Lx lx_p0, crate::check::env::ValInfo v_p1) {
    return prism_rtl::make_rc<ResultRepr>(lx_p0, v_p1);
}


/// AsInstance: unbounded fn Ex, OutTy, OutTy -> Vl
crate::lower::types::Vl as_instance(const crate::lower::model::Ex& call_p0, const crate::lower::model::OutTy& declared_p1, const crate::lower::model::OutTy& t_p2) {
    auto&& _m = std::tuple{declared_p1, t_p2};
    if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(std::get<0>(_m)) && prism_rtl::is<crate::lower::model::OutTy::OutFn>(std::get<1>(_m))) {
        auto&& pts_p3 = prism_rtl::as<crate::lower::model::OutTy::OutFn>(std::get<1>(_m)).a0;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{wrap_as_bounded(call_p0, pts_p3, t_p2), t_p2});
    }
    {
        return has_job_fn(declared_p1) && (!has_job_fn(t_p2))
            ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(Text::lit("a function value of its callee\'s own color inside the value a call returns, at a call that makes the color bounded")), t_p2})
            : crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{call_p0, t_p2});
    }
}


prism_rtl::Turn<crate::lower::types::Vl> AsInstance::cycle() const {
    const auto& call_p0 = this->call_p0;
    const auto& declared_p1 = this->declared_p1;
    const auto& t_p2 = this->t_p2;
    return ({
        auto&& _m = std::tuple{declared_p1, t_p2};
        prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(std::get<0>(_m)) && prism_rtl::is<crate::lower::model::OutTy::OutFn>(std::get<1>(_m)) ? ({
        auto&& pts_p3 = prism_rtl::as<crate::lower::model::OutTy::OutFn>(std::get<1>(_m)).a0;
        prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{wrap_as_bounded(call_p0, pts_p3, t_p2), t_p2}));
    })
        : ({
        auto call_p0_1 = call_p0;
        auto declared_p1_2 = declared_p1;
        auto t_p2_3 = t_p2;
        call_then(start_has_job_fn(declared_p1_2), [=, call_p0_1 = std::move(call_p0_1), t_p2_3 = std::move(t_p2_3)](bool has_job_fn_32542) {
        return has_job_fn_32542 && (!has_job_fn(t_p2_3))
            ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(Text::lit("a function value of its callee\'s own color inside the value a call returns, at a call that makes the color bounded")), t_p2_3}))
            : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{call_p0_1, t_p2_3}));
    });
    });
    });
}


/// `Start AsInstance, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_as_instance(crate::lower::model::Ex call_p0, crate::lower::model::OutTy declared_p1, crate::lower::model::OutTy t_p2) {
    return prism_rtl::make_rc<AsInstance>(call_p0, declared_p1, t_p2);
}


/// HasJobFn: unbounded fn OutTy -> Bool
bool has_job_fn(const crate::lower::model::OutTy& t_p0) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t_p0)) {
        auto&& i_p1 = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t_p0).a0;
        return has_job_fn(prism_rtl::deref(prism_rtl::deref(i_p1)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p0)) {
        auto&& i_p2 = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t_p0).a0;
        return has_job_fn(prism_rtl::deref(prism_rtl::deref(i_p2)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutArray>(t_p0)) {
        auto&& i_p3 = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t_p0).a0;
        return has_job_fn(prism_rtl::deref(prism_rtl::deref(i_p3)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(t_p0)) {
        auto&& k_p4 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p0).a0;
        auto&& v_p5 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p0).a1;
        return has_job_fn(prism_rtl::deref(prism_rtl::deref(k_p4))) || has_job_fn(prism_rtl::deref(prism_rtl::deref(v_p5)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p0)) {
        auto&& ts_p6 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p0).a0;
        return run_to_end(fold_job(ts_p6, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto f_p7 = p0;
                    auto x_p8 = p1;
                    (prism_rtl::finished(std::move(f_p7) || has_job_fn(x_p8)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p0)) {
        auto&& ts_p9 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a1;
        return run_to_end(fold_job(ts_p9, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto f_pa = p0;
                    auto x_pb = p1;
                    (prism_rtl::finished(std::move(f_pa) || has_job_fn(x_pb)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(t_p0)) {
        auto&& ps_pc = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p0).a0;
        auto&& r_pd = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p0).a1;
        return run_to_end(fold_job(ps_pc, has_job_fn(prism_rtl::deref(prism_rtl::deref(r_pd))), static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto f_pe = p0;
                    auto x_pf = p1;
                    (prism_rtl::finished(std::move(f_pe) || has_job_fn(x_pf)));
                });
            }));
        }))));
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> HasJobFn::cycle() const {
    const auto& t_p0 = this->t_p0;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t_p0) ? prism_rtl::finished(true)
        : prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t_p0) ? ({
        auto&& i_p1 = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t_p0).a0;
        prism_rtl::more(prism_rtl::rc(HasJobFn(prism_rtl::deref(prism_rtl::deref(i_p1)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p0) ? ({
        auto&& i_p2 = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t_p0).a0;
        prism_rtl::more(prism_rtl::rc(HasJobFn(prism_rtl::deref(prism_rtl::deref(i_p2)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutArray>(t_p0) ? ({
        auto&& i_p3 = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t_p0).a0;
        prism_rtl::more(prism_rtl::rc(HasJobFn(prism_rtl::deref(prism_rtl::deref(i_p3)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutMap>(t_p0) ? ({
        auto&& k_p4 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p0).a0;
        auto&& v_p5 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p0).a1;
        ({
        auto k_p4_1 = prism_rtl::deref(prism_rtl::deref(k_p4));
        auto v_p5_2 = prism_rtl::deref(prism_rtl::deref(v_p5));
        call_then(start_has_job_fn(k_p4_1), [=, v_p5_2 = std::move(v_p5_2)](bool has_job_fn_32943) { return prism_rtl::finished(has_job_fn_32943 || has_job_fn(v_p5_2)); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p0) ? ({
        auto&& ts_p6 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p0).a0;
        fold_job(ts_p6, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto f_p7 = p0;
                auto x_p8 = p1;
                (prism_rtl::finished(std::move(f_p7) || has_job_fn(x_p8)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p0) ? ({
        auto&& ts_p9 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a1;
        fold_job(ts_p9, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto f_pa = p0;
                auto x_pb = p1;
                (prism_rtl::finished(std::move(f_pa) || has_job_fn(x_pb)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutFn>(t_p0) ? ({
        auto&& ps_pc = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p0).a0;
        auto&& r_pd = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p0).a1;
        ({
        auto ps_pc_1 = ps_pc;
        auto r_pd_2 = prism_rtl::deref(prism_rtl::deref(r_pd));
        call_then(start_has_job_fn(r_pd_2), [=, ps_pc_1 = std::move(ps_pc_1)](bool has_job_fn_33118) {
        return fold_job(ps_pc_1, has_job_fn_33118, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto f_pe = p0;
                    auto x_pf = p1;
                    (prism_rtl::finished(std::move(f_pe) || has_job_fn(x_pf)));
                });
            }));
        })))->cycle();
    });
    });
    })
        : prism_rtl::finished(false);
    });
}


/// `Start HasJobFn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_has_job_fn(crate::lower::model::OutTy t_p0) {
    return prism_rtl::make_rc<HasJobFn>(t_p0);
}


/// WrapAsBounded: fn Ex, [OutTy], OutTy -> Ex
crate::lower::model::Ex wrap_as_bounded(const crate::lower::model::Ex& f_p0, const Array<crate::lower::model::OutTy>& pts_p1, const crate::lower::model::OutTy& target_p2) {
    auto names_p3 = each(crate::check::errors::range0(len(pts_p1)), [&](const Nat& i_p7) { return prism_rtl::cat("a", i_p7); });
    auto pas_p4 = each(crate::check::errors::range0(len(pts_p1)), [&](const Nat& i_p8) { return crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{or_(index(names_p3, i_p8), Text::lit("a"))})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(or_(index(pts_p1, i_p8), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})))})}); });
    auto arg_p5 = len(pts_p1) == Nat(1u)
        ? crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("a0")}))})
        : crate::lower::model::Ex(crate::lower::model::Ex::XTuple{each(names_p3, [&](const Text& nm_p9) { return crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{nm_p9}))}); })});
    auto body_p6 = crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("run_to_end"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XApply{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("job_fn")})), Array(std::vector{arg_p5})})})});
    return crate::lower::model::Ex(crate::lower::model::Ex::XBlock{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("job_fn")}), f_p0})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, pas_p4, prism_rtl::rc(body_p6)})})})), target_p2}))});
}


/// ArgsFor: unbounded fn Lx, Env, ValInfo, [Arg] -> [Ex]
Array<crate::lower::model::Ex> args_for(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::check::env::ValInfo& v_p2, const Array<crate::syntax::Arg>& args_p3) {
    auto ps_p4 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
        auto&& _m = prism_rtl::deref(v_p2.scheme).ty;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& xs_p5 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            _v.set(xs_p5);
            goto _done;
        }
        {
            _v.set(Array<crate::check::types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return run_to_end(each_job(crate::check::errors::range0(len(args_p3)), ({
        auto args_p3_1 = args_p3;
        auto ps_p4_2 = ps_p4;
        auto lx_p0_3 = lx_p0;
        auto env_p1_4 = env_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Nat)>>(prism_rtl::rc([=, args_p3_1 = std::move(args_p3_1), ps_p4_2 = std::move(ps_p4_2), lx_p0_3 = std::move(lx_p0_3), env_p1_4 = std::move(env_p1_4)](Nat p0) {
        return ({
            auto args_p3_1_5 = args_p3_1;
            auto ps_p4_2_5 = ps_p4_2;
            auto lx_p0_3_5 = lx_p0_3;
            auto env_p1_4_5 = env_p1_4;
            entered(once_job([=, args_p3_1_5 = std::move(args_p3_1_5), ps_p4_2_5 = std::move(ps_p4_2_5), lx_p0_3_5 = std::move(lx_p0_3_5), env_p1_4_5 = std::move(env_p1_4_5)]() {
            return ({
                auto i_p6 = p0;
                ({
                auto a_p7 = or_(index(args_p3_1_5, i_p6), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = dummy_expr(), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}});
                auto is_try_p8 = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = crate::lower::types::peel(or_(index(ps_p4_2_5, i_p6), crate::check::types::Ty(crate::check::types::Ty::TyErr{})));
                    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
                        auto&& m34282_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
                        if (m34282_0_0 == Text::lit("~")) {
                            _v.set(true);
                            goto _done;
                        }
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto is_error_p9 = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = crate::lower::types::peel(crate::lower::type_at(lx_p0_3_5, prism_rtl::deref(a_p7->value).span));
                    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
                        auto&& m34399_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
                        if (m34399_0_0 == Text::lit("Prelude.Error")) {
                            _v.set(true);
                            goto _done;
                        }
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto to_unbounded_pa = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = crate::lower::types::peel(or_(index(ps_p4_2_5, i_p6), crate::check::types::Ty(crate::check::types::Ty::TyErr{})));
                    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CBound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0)) {
                        _v.set(false);
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
                        _v.set(true);
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                (std::move(is_try_p8) && std::move(is_error_p9)
                ? call_then(start_value_of(lx_p0_3_5, env_p1_4_5, a_p7->value), [=](crate::lower::types::Vl value_of_34748) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{crate::lower::types::own(value_of_34748)})}))})); })
                : std::move(to_unbounded_pa)
                ? call_then(start_as_job_value(lx_p0_3_5, env_p1_4_5, a_p7->value), [=](crate::lower::model::Ex as_job_value_34813) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(as_job_value_34813)})); })
                : prism_rtl::more(prism_rtl::rc(Argument(lx_p0_3_5, env_p1_4_5, a_p7->value))));
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<crate::lower::model::Ex>> ArgsFor::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& v_p2 = this->v_p2;
    const auto& args_p3 = this->args_p3;
    auto ps_p4 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(v_p2).scheme).ty;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& xs_p5 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            _v.set(xs_p5);
            goto _done;
        }
        {
            _v.set(Array<crate::check::types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return each_job(crate::check::errors::range0(len(args_p3)), ({
        auto args_p3_1 = args_p3;
        auto ps_p4_2 = ps_p4;
        auto lx_p0_3 = lx_p0;
        auto env_p1_4 = env_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Nat)>>(prism_rtl::rc([=, args_p3_1 = std::move(args_p3_1), ps_p4_2 = std::move(ps_p4_2), lx_p0_3 = std::move(lx_p0_3), env_p1_4 = std::move(env_p1_4)](Nat p0) {
        return ({
            auto args_p3_1_5 = args_p3_1;
            auto ps_p4_2_5 = ps_p4_2;
            auto lx_p0_3_5 = lx_p0_3;
            auto env_p1_4_5 = env_p1_4;
            entered(once_job([=, args_p3_1_5 = std::move(args_p3_1_5), ps_p4_2_5 = std::move(ps_p4_2_5), lx_p0_3_5 = std::move(lx_p0_3_5), env_p1_4_5 = std::move(env_p1_4_5)]() {
            return ({
                auto i_p6 = p0;
                ({
                auto a_p7 = or_(index(args_p3_1_5, i_p6), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = dummy_expr(), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}});
                auto is_try_p8 = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = crate::lower::types::peel(or_(index(ps_p4_2_5, i_p6), crate::check::types::Ty(crate::check::types::Ty::TyErr{})));
                    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
                        auto&& m34282_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
                        if (m34282_0_0 == Text::lit("~")) {
                            _v.set(true);
                            goto _done;
                        }
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto is_error_p9 = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = crate::lower::types::peel(crate::lower::type_at(lx_p0_3_5, prism_rtl::deref(a_p7->value).span));
                    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
                        auto&& m34399_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
                        if (m34399_0_0 == Text::lit("Prelude.Error")) {
                            _v.set(true);
                            goto _done;
                        }
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto to_unbounded_pa = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = crate::lower::types::peel(or_(index(ps_p4_2_5, i_p6), crate::check::types::Ty(crate::check::types::Ty::TyErr{})));
                    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CBound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0)) {
                        _v.set(false);
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
                        _v.set(true);
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                (std::move(is_try_p8) && std::move(is_error_p9)
                ? call_then(start_value_of(lx_p0_3_5, env_p1_4_5, a_p7->value), [=](crate::lower::types::Vl value_of_34748) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{crate::lower::types::own(value_of_34748)})}))})); })
                : std::move(to_unbounded_pa)
                ? call_then(start_as_job_value(lx_p0_3_5, env_p1_4_5, a_p7->value), [=](crate::lower::model::Ex as_job_value_34813) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(as_job_value_34813)})); })
                : prism_rtl::more(prism_rtl::rc(Argument(lx_p0_3_5, env_p1_4_5, a_p7->value))));
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start ArgsFor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::Ex>> start_args_for(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::check::env::ValInfo v_p2, Array<crate::syntax::Arg> args_p3) {
    return prism_rtl::make_rc<ArgsFor>(lx_p0, env_p1, v_p2, args_p3);
}


/// let dummyExpr
crate::syntax::Expr dummy_expr() {
    return crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// CtorApp: unbounded fn Lx, Env, CtorInfo, [Arg], Range -> Vl
crate::lower::types::Vl ctor_app(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::check::env::CtorInfo& c_p2, const Array<crate::syntax::Arg>& args_p3, const crate::syntax::Range& span_p4) {
    auto t_p5 = crate::lower::types::out_ty_of(lx_p0, crate::lower::types::peel(crate::lower::type_at(lx_p0, span_p4)));
    auto owner_p6 = or_(crate::prelude::get(prism_rtl::deref(lx_p0.g).types, c_p2.owner), crate::check::env::names::dummy_ty_info());
    auto ty_path_p7 = crate::lower::path_in(lx_p0, prism_rtl::deref(owner_p6).home, crate::lower::camel(crate::check::types::bare_name(c_p2.owner)));
    auto vals_p8 = ctor_args(lx_p0, env_p1, c_p2, args_p3);
    auto&& _m = c_p2.owner;
    {
        auto&& m35430_0 = _m;
        if (m35430_0 == Text::lit("Bool")) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBool{c_p2.name == Text::lit("True")}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})});
        }
    }
    {
        auto&& m35430_1 = _m;
        if (m35430_1 == Text::lit("Prelude.Error")) {
            auto kind_p9 = or_(index(vals_p8, Nat(0u)), crate::lower::model::Ex(crate::lower::model::Ex::XStr{Text::lit("")}));
            auto msg_pa = or_(index(vals_p8, Nat(1u)), crate::lower::model::Ex(crate::lower::model::Ex::XText{Text::lit("")}));
            auto made_pb = crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Error::new"), Array(std::vector{kind_p9, msg_pa})});
            if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p5)) {
                return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{made_pb})}), t_p5});
            }
            {
                return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{made_pb, crate::lower::model::OutTy(crate::lower::model::OutTy::OutError{})});
            }
        }
    }
    {
        auto&& _m = prism_rtl::deref(owner_p6).body;
        if (prism_rtl::is<crate::check::env::TyBody::BRecord>(_m)) {
            auto&& fs_pc = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
            return len(c_p2.fields) == Nat(0u)
                ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XPath{ty_path_p7}), t_p5})
                : crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XRecord{ty_path_p7, each(crate::check::errors::range0(len(c_p2.fields)), [&](const Nat& i_pd) { return std::tuple{crate::lower::snake(or_(index(c_p2.fields, i_pd), Text::lit(""))), or_(index(vals_p8, i_pd), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Default::default"), Array<crate::lower::model::Ex>{}}))}; })}), t_p5});
        }
        if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
            auto&& cases_pe = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
            auto is_unit_type_pf = ((len(cases_pe) == Nat(1u)) && (len(c_p2.args) == Nat(0u))) && crate::check::env::is_lower_text(crate::check::types::bare_name(c_p2.name));
            auto is_newtype_pg = (len(cases_pe) == Nat(1u)) && (crate::check::types::bare_name(c_p2.name) == crate::check::types::bare_name(c_p2.owner));
            auto path_ph = std::move(is_unit_type_pf) || std::move(is_newtype_pg)
                ? ty_path_p7
                : prism_rtl::cat(ty_path_p7, "::", crate::lower::camel(crate::check::types::bare_name(c_p2.name)));
            auto made_pi = len(c_p2.args) == Nat(0u)
                ? crate::lower::model::Ex(crate::lower::model::Ex::XPath{path_ph})
                : crate::lower::model::Ex(crate::lower::model::Ex::XCtor{path_ph, vals_p8});
            return ((len(prism_rtl::deref(owner_p6).params) > Nat(0u)) && (!std::move(is_unit_type_pf))) && (!std::move(is_newtype_pg))
                ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(made_pi), built_ty(t_p5)}), t_p5})
                : crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{made_pi, t_p5});
        }
        {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("a constructor of ", c_p2.owner)), t_p5});
        }
    }
}


prism_rtl::Turn<crate::lower::types::Vl> CtorApp::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& c_p2 = this->c_p2;
    const auto& args_p3 = this->args_p3;
    const auto& span_p4 = this->span_p4;
    auto args_p3_1 = args_p3;
    auto c_p2_2 = c_p2;
    auto env_p1_3 = env_p1;
    auto lx_p0_4 = lx_p0;
    auto span_p4_5 = span_p4;
    return call_then(crate::lower::types::start_out_ty_of(lx_p0_4, crate::lower::types::peel(crate::lower::type_at(lx_p0_4, span_p4_5))), [=](crate::lower::model::OutTy out_ty_of_35229) {
        return ({
            auto t_p5 = out_ty_of_35229;
            auto owner_p6 = or_(crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0_4).g).types, prism_rtl::deref(c_p2_2).owner), crate::check::env::names::dummy_ty_info());
            auto ty_path_p7 = crate::lower::path_in(lx_p0_4, prism_rtl::deref(owner_p6).home, crate::lower::camel(crate::check::types::bare_name(prism_rtl::deref(c_p2_2).owner)));
            call_then(start_ctor_args(lx_p0_4, env_p1_3, c_p2_2, args_p3_1), [=, t_p5 = std::move(t_p5), owner_p6 = std::move(owner_p6), ty_path_p7 = std::move(ty_path_p7)](Array<crate::lower::model::Ex> ctor_args_35400) {
            return ({
                auto vals_p8 = ctor_args_35400;
                ({
                auto&& _m = prism_rtl::deref(c_p2_2).owner;
                ({
                auto&& m35430_0 = _m;
                (m35430_0 == Text::lit("Bool"));
            }) ? ({
                auto&& m35430_0 = _m;
                prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBool{prism_rtl::deref(c_p2_2).name == Text::lit("True")}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})}));
            })
                : ({
                auto&& m35430_1 = _m;
                (m35430_1 == Text::lit("Prelude.Error"));
            }) ? ({
                auto&& m35430_1 = _m;
                ({
                auto kind_p9 = or_(index(vals_p8, Nat(0u)), crate::lower::model::Ex(crate::lower::model::Ex::XStr{Text::lit("")}));
                auto msg_pa = or_(index(vals_p8, Nat(1u)), crate::lower::model::Ex(crate::lower::model::Ex::XText{Text::lit("")}));
                auto made_pb = crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Error::new"), Array(std::vector{kind_p9, msg_pa})});
                ({
                prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p5) ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{made_pb})}), t_p5}))
                : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{made_pb, crate::lower::model::OutTy(crate::lower::model::OutTy::OutError{})}));
            });
            });
            })
                : ({
                auto&& _m = prism_rtl::deref(owner_p6).body;
                prism_rtl::is<crate::check::env::TyBody::BRecord>(_m) ? ({
                auto&& fs_pc = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
                len(prism_rtl::deref(c_p2_2).fields) == Nat(0u)
                ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XPath{ty_path_p7}), t_p5}))
                : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XRecord{ty_path_p7, each(crate::check::errors::range0(len(prism_rtl::deref(c_p2_2).fields)), [&](const Nat& i_pd) { return std::tuple{crate::lower::snake(or_(index(prism_rtl::deref(c_p2_2).fields, i_pd), Text::lit(""))), or_(index(vals_p8, i_pd), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Default::default"), Array<crate::lower::model::Ex>{}}))}; })}), t_p5}));
            })
                : prism_rtl::is<crate::check::env::TyBody::BChoice>(_m) ? ({
                auto&& cases_pe = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
                ({
                auto is_unit_type_pf = ((len(cases_pe) == Nat(1u)) && (len(c_p2_2->args) == Nat(0u))) && crate::check::env::is_lower_text(crate::check::types::bare_name(prism_rtl::deref(c_p2_2).name));
                auto is_newtype_pg = (len(cases_pe) == Nat(1u)) && (crate::check::types::bare_name(prism_rtl::deref(c_p2_2).name) == crate::check::types::bare_name(prism_rtl::deref(c_p2_2).owner));
                auto path_ph = std::move(is_unit_type_pf) || std::move(is_newtype_pg)
                    ? ty_path_p7
                    : prism_rtl::cat(ty_path_p7, "::", crate::lower::camel(crate::check::types::bare_name(prism_rtl::deref(c_p2_2).name)));
                auto made_pi = len(c_p2_2->args) == Nat(0u)
                    ? crate::lower::model::Ex(crate::lower::model::Ex::XPath{path_ph})
                    : crate::lower::model::Ex(crate::lower::model::Ex::XCtor{path_ph, vals_p8});
                ((len(prism_rtl::deref(owner_p6).params) > Nat(0u)) && (!std::move(is_unit_type_pf))) && (!std::move(is_newtype_pg))
                ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(made_pi), built_ty(t_p5)}), t_p5}))
                : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{made_pi, t_p5}));
            });
            })
                : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal(prism_rtl::cat("a constructor of ", prism_rtl::deref(c_p2_2).owner)), t_p5}));
            });
            });
            });
        });
        });
    });
}


/// `Start CtorApp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_ctor_app(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::check::env::CtorInfo c_p2, Array<crate::syntax::Arg> args_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<CtorApp>(lx_p0, env_p1, c_p2, args_p3, span_p4);
}


/// BuiltTy: fn OutTy -> OutTy
crate::lower::model::OutTy built_ty(const crate::lower::model::OutTy& t_p0) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(t_p0)) {
        auto&& r_p1 = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p0).a1;
        return prism_rtl::deref(prism_rtl::deref(r_p1));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t_p0)) {
        auto&& r_p2 = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t_p0).a1;
        return prism_rtl::deref(prism_rtl::deref(r_p2));
    }
    {
        return t_p0;
    }
}


/// CtorFn: unbounded fn Lx, CtorInfo, [OutTy], Range, OutTy, Bool -> Vl
crate::lower::types::Vl ctor_fn(const crate::lower::Lx& lx_p0, const crate::check::env::CtorInfo& c_p1, const Array<crate::lower::model::OutTy>& pts_p2, const crate::syntax::Range& span_p3, const crate::lower::model::OutTy& t_p4, const bool& job_p5) {
    auto names_p6 = each(crate::check::errors::range0(len(pts_p2)), [&](const Nat& i_pa) { return prism_rtl::cat("a", i_pa); });
    auto fakes_p7 = each(crate::check::errors::range0(len(pts_p2)), [&](const Nat& i_pb) { return crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EAbsent{})), .span = crate::syntax::Range{.start = *Nat::from_int(Int(4000000000ll)) + i_pb, .end = *Nat::from_int(Int(4000000000ll)) + i_pb}}, .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}}; });
    auto env_p8 = fold(crate::check::errors::range0(len(pts_p2)), crate::lower::types::empty_env(), [&](const crate::lower::types::Env& en_pc, const Nat& i_pd) {
        return crate::lower::types::bind_span(en_pc, crate::lower::place_key(lx_p0, crate::syntax::Range{.start = *Nat::from_int(Int(4000000000ll)) + i_pd, .end = *Nat::from_int(Int(4000000000ll)) + i_pd}), crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XVar{or_(index(names_p6, i_pd), Text::lit("a"))}), job_p5
            ? crate::lower::types::Holding(crate::lower::types::Holding::Owned{})
            : crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), or_(index(pts_p2, i_pd), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))}));
    });
    auto made_p9 = crate::lower::types::own(ctor_app(lx_p0, env_p8, c_p1, fakes_p7, span_p3));
    return job_p5
        ? ({
        auto a_pe = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::OutTy> _v;
            if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t_p4)) {
                auto&& x_pg = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t_p4).a0;
                _v.set(prism_rtl::deref(prism_rtl::deref(x_pg)));
                goto _done;
            }
            {
                _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto pa_pf = len(pts_p2) == Nat(1u)
            ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("a0")})), a_pe})
            : crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(names_p6, [&](const Text& nm_ph) { return crate::lower::model::Pa(crate::lower::model::Pa::PaBind{nm_ph}); })})), a_pe});
        (crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{pa_pf}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("once_job"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array<crate::lower::model::Pa>{}, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{made_p9})}))})})}))})})})), t_p4}), t_p4}));
    })
        : ({
        auto pas_pi = each(crate::check::errors::range0(len(pts_p2)), [&](const Nat& i_pj) { return crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{or_(index(names_p6, i_pj), Text::lit("a"))})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(or_(index(pts_p2, i_pj), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})))})}); });
        (crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, pas_pi, prism_rtl::rc(made_p9)})})}), t_p4}));
    });
}

}  // namespace crate::lower::expr
