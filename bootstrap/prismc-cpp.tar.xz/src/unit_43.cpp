// The module `Lower.Node.Def`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <lower/node_/def/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Lower.Node.Def`, from `target/bootstrap/cpp-src/prismc/lower/node/def.prism`.
namespace crate::lower::node_::def {

void HowBound::show(Printer& p) const {
    if (auto c = std::get_if<AsHold>(&cases())) p.choice("AsHold", {});
    else if (auto c = std::get_if<AsBind>(&cases())) p.choice("AsBind", {});
    else if (auto c = std::get_if<AsLet>(&cases())) p.choice("AsLet", {});
    else if (auto c = std::get_if<AsResult>(&cases())) p.choice("AsResult", {});
}

Pod HowBound::to_pod() const {
    return std::holds_alternative<AsHold>(cases()) ? Pod::choice("AsHold", {})
        : std::holds_alternative<AsBind>(cases()) ? Pod::choice("AsBind", {})
        : std::holds_alternative<AsLet>(cases()) ? Pod::choice("AsLet", {})
        : std::holds_alternative<AsResult>(cases()) ? Pod::choice("AsResult", {})
        : Pod();
}

Result<HowBound> HowBound::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "AsHold" && c->args.size() == 0) return HowBound(AsHold{});
        if (c->ctor == "AsBind" && c->args.size() == 0) return HowBound(AsBind{});
        if (c->ctor == "AsLet" && c->args.size() == 0) return HowBound(AsLet{});
        if (c->ctor == "AsResult" && c->args.size() == 0) return HowBound(AsResult{});
    }
    return mismatch<HowBound>("a HowBound", p);
}


/// NodeDefOf: unbounded fn Lx, Text, [Pattern], Block, Scheme, Bool -> NodeDef
crate::lower::model::NodeDef node_def_of(const crate::lower::Lx& lx, const Text& qk, const Array<crate::syntax::Pattern_>& params, const crate::syntax::Block& body, const crate::check::types::Scheme& sc, const bool& is_root) {
    auto name = crate::lower::camel(crate::check::types::bare_name(qk));
    auto ptys = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
        auto&& _m = sc.ty;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            _v.set(ps);
            goto _done;
        }
        {
            _v.set(Array<crate::check::types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto wx0 = crate::lower::node_::new_wx(lx, name, Array<std::tuple<Text, crate::lower::model::OutTy, Text>>{}, Array<std::tuple<Text, crate::lower::model::Ex>>{}, Array<std::tuple<Text, crate::lower::model::Ex>>{}, Array<crate::lower::model::MethDef>{}, Map<Text, Array<crate::lower::node_::Read>>{}, crate::lower::node_::node_hooks(), Array<Text>{}, std::optional<Text>{});
    auto [ps, wx1, benv, menv] = run_to_end(fold_job(crate::check::errors::range0(len(params)), std::tuple{Array<std::tuple<Text, crate::lower::model::OutTy>>{}, wx0, crate::lower::types::empty_env(), crate::lower::types::empty_env()}, ({
        auto params_1 = params;
        auto lx_2 = lx;
        auto ptys_3 = ptys;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::lower::model::OutTy>>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::lower::model::OutTy>>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<Text, crate::lower::model::OutTy>>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto params_1_4 = params_1;
            auto lx_2_4 = lx_2;
            auto ptys_3_4 = ptys_3;
            entered(once_job([=]() {
            return ({
                auto [acc, w, be, me] = p0;
                auto i = p1;
                ({
                auto p_ = or_(index(params_1_4, i), crate::lower::patterns::dummy_pat());
                auto nkey = crate::lower::functions::plain_binder(lx_2_4, p_);
                auto base = nkey == Text::lit("")
                    ? prism_rtl::cat("arg", i)
                    : crate::lower::snake(nkey);
                auto [rs, w2] = crate::lower::node_::fresh_name(w, base);
                call_then(crate::lower::types::start_out_ty_of(lx_2_4, crate::lower::types::peel(or_(index(ptys_3_4, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})))), [=](crate::lower::model::OutTy out_ty_of_1975) {
                return ({
                    auto t = out_ty_of_1975;
                    auto w3 = ({
                        crate::lower::node_::Wx this_ = w2;
                        this_.fields = crate::prelude::push(this_.fields, std::tuple{rs, t, Text::lit("a parameter")});
                        this_.inits = crate::prelude::push(this_.inits, std::tuple{rs, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs}))})});
                        this_;
                    });
                    auto [be2, me2] = crate::lower::node_::bind_plain(be, me, nkey, rs, t);
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc, std::tuple{rs, t}), w3, be2, me2}));
                });
            });
            });
            });
        }));
        });
    }));
    })));
    auto wx2 = block_into(wx1, benv, menv, body);
    auto wx3 = is_root ? root_result(wx2) : wx2;
    return crate::lower::node_::finish::finish_node(wx3, qk, ps, false);
}


prism_rtl::Turn<crate::lower::model::NodeDef> NodeDefOf::cycle() const {
    const auto& lx = this->lx;
    const auto& qk = this->qk;
    const auto& params = this->params;
    const auto& body = this->body;
    const auto& sc = this->sc;
    const auto& is_root = this->is_root;
    auto name = crate::lower::camel(crate::check::types::bare_name(qk));
    auto ptys = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
        auto&& _m = sc.ty;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            _v.set(ps);
            goto _done;
        }
        {
            _v.set(Array<crate::check::types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto wx0 = crate::lower::node_::new_wx(lx, name, Array<std::tuple<Text, crate::lower::model::OutTy, Text>>{}, Array<std::tuple<Text, crate::lower::model::Ex>>{}, Array<std::tuple<Text, crate::lower::model::Ex>>{}, Array<crate::lower::model::MethDef>{}, Map<Text, Array<crate::lower::node_::Read>>{}, crate::lower::node_::node_hooks(), Array<Text>{}, std::optional<Text>{});
    auto body_1 = body;
    auto is_root_2 = is_root;
    auto lx_3 = lx;
    auto params_4 = params;
    auto qk_5 = qk;
    return call_value(fold_job(crate::check::errors::range0(len(params_4)), std::tuple{Array<std::tuple<Text, crate::lower::model::OutTy>>{}, wx0, crate::lower::types::empty_env(), crate::lower::types::empty_env()}, ({
        auto params_4_6 = params_4;
        auto lx_3_6 = lx_3;
        auto ptys_6 = ptys;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::lower::model::OutTy>>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::lower::model::OutTy>>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<Text, crate::lower::model::OutTy>>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto params_4_6_7 = params_4_6;
            auto lx_3_6_7 = lx_3_6;
            auto ptys_6_7 = ptys_6;
            entered(once_job([=]() {
            return ({
                auto [acc, w, be, me] = p0;
                auto i = p1;
                ({
                auto p_ = or_(index(params_4_6_7, i), crate::lower::patterns::dummy_pat());
                auto nkey = crate::lower::functions::plain_binder(lx_3_6_7, p_);
                auto base = nkey == Text::lit("")
                    ? prism_rtl::cat("arg", i)
                    : crate::lower::snake(nkey);
                auto [rs, w2] = crate::lower::node_::fresh_name(w, base);
                call_then(crate::lower::types::start_out_ty_of(lx_3_6_7, crate::lower::types::peel(or_(index(ptys_6_7, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})))), [=](crate::lower::model::OutTy out_ty_of_1975) {
                return ({
                    auto t = out_ty_of_1975;
                    auto w3 = ({
                        crate::lower::node_::Wx this_ = w2;
                        this_.fields = crate::prelude::push(this_.fields, std::tuple{rs, t, Text::lit("a parameter")});
                        this_.inits = crate::prelude::push(this_.inits, std::tuple{rs, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs}))})});
                        this_;
                    });
                    auto [be2, me2] = crate::lower::node_::bind_plain(be, me, nkey, rs, t);
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc, std::tuple{rs, t}), w3, be2, me2}));
                });
            });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<std::tuple<Text, crate::lower::model::OutTy>>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env> fold_1692) {
        return ({
            auto [ps, wx1, benv, menv] = fold_1692;
            call_then(start_block_into(wx1, benv, menv, body_1), [=](crate::lower::node_::Wx block_into_2293) {
            return ({
                auto wx2 = block_into_2293;
                auto wx3 = is_root_2 ? root_result(wx2) : wx2;
                (prism_rtl::more(prism_rtl::rc(crate::lower::node_::finish::FinishNode(wx3, qk_5, ps, false))));
            });
        });
        });
    });
}


/// `Start NodeDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::NodeDef> start_node_def_of(crate::lower::Lx lx, Text qk, Array<crate::syntax::Pattern_> params, crate::syntax::Block body, crate::check::types::Scheme sc, bool is_root) {
    return prism_rtl::make_rc<NodeDefOf>(lx, qk, params, body, sc, is_root);
}


/// RootResult: fn Wx -> Wx
crate::lower::node_::Wx root_result(const crate::lower::node_::Wx& wx) {
    auto&& _m = wx->result;
    if (prism_rtl::is<crate::lower::node_::Wres::WrEv>(_m)) {
        auto&& r = prism_rtl::as<crate::lower::node_::Wres::WrEv>(_m).a0;
        return crate::lower::node_::connect(wx, r, crate::lower::node_::Sk(crate::lower::node_::Sk::SkResult{}));
    }
    if (prism_rtl::is<crate::lower::node_::Wres::WrDyn>(_m)) {
        auto&& x = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(_m).a0;
        auto&& rds = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(_m).a1;
        auto&& t = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(_m).a2;
        crate::lower::node_::Wx this_ = wx;
        this_.root_dyn = std::optional(std::tuple{x, rds, t});
        this_.getters = crate::prelude::push(this_.getters, crate::lower::model::MethDef{.name = Text::lit("result_value"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutPod{}), .body = Array<crate::lower::model::Do>{}, .tail = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(x), Text::lit("to_pod"), Array<crate::lower::model::Ex>{}}), .doc = Text::lit("The root\'s dynamic result, pulled after the tick.")});
        this_.fields = crate::prelude::push(this_.fields, std::tuple{Text::lit("result_last"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutCell{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutPod{}))}))}), Text::lit("the result the World last heard")});
        this_.moves = crate::prelude::push(this_.moves, std::tuple{Text::lit("result_last"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("RefCell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XNone{})})})});
        this_.build = crate::prelude::push(this_.build, crate::lower::model::Do(crate::lower::model::Do::DoScope{crate::lower::node_::finish::result_told(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")}))}));
        return this_;
    }
    if (prism_rtl::is<crate::lower::node_::Wres::WrPlain>(_m)) {
        auto&& x = prism_rtl::as<crate::lower::node_::Wres::WrPlain>(_m).a0;
        crate::lower::node_::Wx this_ = wx;
        this_.build = crate::prelude::push(this_.build, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("result"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Outcome::Value"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(x), Text::lit("to_pod"), Array<crate::lower::model::Ex>{}})})})})})}));
        return this_;
    }
    if (prism_rtl::is<crate::lower::node_::Wres::WrParts>(_m)) {
        crate::lower::node_::Wx this_ = wx;
        this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("a bundle as the root\'s result: a World hears a plain value, a dynamic or an event")));
        return this_;
    }
    {
        return wx;
    }
}


/// BlockInto: unbounded fn Wx, Env, Env, Block -> Wx
crate::lower::node_::Wx block_into(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const crate::syntax::Block& b) {
    auto [wx1, be1, me1] = run_to_end(fold_job(b.stmts, std::tuple{wx, benv, menv}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>>(std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [w, be, me] = p0;
                auto s = p1;
                (prism_rtl::more(prism_rtl::rc(PreBind(w, be, me, s))));
            });
        }));
    }))));
    auto n = len(b.stmts);
    auto&& _wx2 = run_to_end(fold_job(crate::check::errors::range0(n), std::tuple{wx1, be1, me1}, ({
        auto b_1 = b;
        auto n_2 = n;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>>(std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto b_1_3 = b_1;
            auto n_2_3 = n_2;
            entered(once_job([=]() {
            return ({
                auto [w, be, me] = p0;
                auto i = p1;
                (prism_rtl::more(prism_rtl::rc(WidgetStmt(w, be, me, or_(index(b_1_3.stmts, i), crate::lower::expr::dummy_stmt_l()), (i + Nat(1u)) == n_2_3))));
            });
        }));
        });
    }));
    })));
    auto&& wx2 = std::get<0>(_wx2);
    return wx2;
}


prism_rtl::Turn<crate::lower::node_::Wx> BlockInto::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& b = this->b;
    auto b_1 = b;
    auto benv_2 = benv;
    auto menv_3 = menv;
    auto wx_4 = wx;
    return call_value(fold_job(b_1.stmts, std::tuple{wx_4, benv_2, menv_3}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>>(std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [w, be, me] = p0;
                auto s = p1;
                (prism_rtl::more(prism_rtl::rc(PreBind(w, be, me, s))));
            });
        }));
    }))), [=](std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env> fold_3778) {
        return ({
            auto [wx1, be1, me1] = fold_3778;
            auto n = len(b_1.stmts);
            call_value(fold_job(crate::check::errors::range0(n), std::tuple{wx1, be1, me1}, ({
            auto b_1_5 = b_1;
            auto n_5 = n;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>>(std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto b_1_5_6 = b_1_5;
                auto n_5_6 = n_5;
                entered(once_job([=]() {
                return ({
                    auto [w, be, me] = p0;
                    auto i = p1;
                    (prism_rtl::more(prism_rtl::rc(WidgetStmt(w, be, me, or_(index(b_1_5_6.stmts, i), crate::lower::expr::dummy_stmt_l()), (i + Nat(1u)) == n_5_6))));
                });
            }));
            });
        }));
        })), [=](std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env> fold_3911) {
            return ({
                auto&& _wx2 = fold_3911;
                auto&& wx2 = std::get<0>(_wx2);
                (prism_rtl::finished(wx2));
            });
        });
        });
    });
}


/// `Start BlockInto, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::node_::Wx> start_block_into(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, crate::syntax::Block b) {
    return prism_rtl::make_rc<BlockInto>(wx, benv, menv, b);
}


/// PreBind: unbounded fn Wx, Env, Env, Stmt -> ((Wx, Env, Env))
std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env> pre_bind(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const crate::syntax::Stmt& s) {
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& init = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        auto&& step_opt = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2;
        auto how = (step_opt == std::optional<crate::syntax::Expr>{}) && gives_result(wx.lx, menv, init)
            ? HowBound(HowBound::AsResult{})
            : how_bound(step_opt);
        auto&& _m = p_.kind;
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            return pre_bind_name(wx, benv, menv, n, how);
        }
        if (prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m)) {
            auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
            return run_to_end(fold_job(ps, std::tuple{wx, benv, menv}, ({
                auto how_1 = how;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>>(std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, crate::syntax::Pattern_> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto how_1_2 = how_1;
                    entered(once_job([=]() {
                    return ({
                        auto [w, be, me] = p0;
                        auto q = p1;
                        ({
                        auto&& _m = q.kind;
                        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
                        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                        prism_rtl::more(prism_rtl::rc(PreBindName(w, be, me, n, how_1_2)));
                    })
                        : prism_rtl::finished(std::tuple{w, be, me});
                    });
                    });
                }));
                });
            }));
            })));
        }
        {
            return std::tuple{wx, benv, menv};
        }
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& _m = p_.kind;
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            return pre_bind_name(wx, benv, menv, n, HowBound(HowBound::AsLet{}));
        }
        {
            return std::tuple{wx, benv, menv};
        }
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        auto fname = crate::check::env::def_name_text(c.name);
        return std::tuple{wx, crate::lower::types::bind(benv, fname, crate::lower::types::Bn(crate::lower::types::Bn::BnLocalFn{c})), crate::lower::types::bind(menv, fname, crate::lower::types::Bn(crate::lower::types::Bn::BnLocalFn{c}))};
    }
    {
        return std::tuple{wx, benv, menv};
    }
}


prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> PreBind::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& s = this->s;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& init = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        auto&& step_opt = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2;
        ({
        auto how = (step_opt == std::optional<crate::syntax::Expr>{}) && gives_result(wx.lx, menv, init)
            ? HowBound(HowBound::AsResult{})
            : how_bound(step_opt);
        ({
        auto&& _m = p_.kind;
        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        prism_rtl::more(prism_rtl::rc(PreBindName(wx, benv, menv, n, how)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m) ? ({
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        fold_job(ps, std::tuple{wx, benv, menv}, ({
        auto how_1 = how;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>>(std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto how_1_2 = how_1;
            entered(once_job([=]() {
            return ({
                auto [w, be, me] = p0;
                auto q = p1;
                ({
                auto&& _m = q.kind;
                prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
                auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                prism_rtl::more(prism_rtl::rc(PreBindName(w, be, me, n, how_1_2)));
            })
                : prism_rtl::finished(std::tuple{w, be, me});
            });
            });
        }));
        });
    }));
    }))->cycle();
    })
        : prism_rtl::finished(std::tuple{wx, benv, menv});
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        ({
        auto&& _m = p_.kind;
        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        prism_rtl::more(prism_rtl::rc(PreBindName(wx, benv, menv, n, HowBound(HowBound::AsLet{}))));
    })
        : prism_rtl::finished(std::tuple{wx, benv, menv});
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        ({
        auto fname = crate::check::env::def_name_text(c.name);
        (prism_rtl::finished(std::tuple{wx, crate::lower::types::bind(benv, fname, crate::lower::types::Bn(crate::lower::types::Bn::BnLocalFn{c})), crate::lower::types::bind(menv, fname, crate::lower::types::Bn(crate::lower::types::Bn::BnLocalFn{c}))}));
    });
    })
        : prism_rtl::finished(std::tuple{wx, benv, menv});
    });
}


/// `Start PreBind, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> start_pre_bind(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, crate::syntax::Stmt s) {
    return prism_rtl::make_rc<PreBind>(wx, benv, menv, s);
}


/// GivesResult: unbounded fn Lx, Env, Expr -> Bool
bool gives_result(const crate::lower::Lx& lx, const crate::lower::types::Env& menv, const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return gives_result(lx, menv, x);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m)) {
        return true;
    }
    {
        auto callee = ({
            __label__ _done;
            prism_rtl::Slot<crate::syntax::Expr> _v;
            auto&& _m = e.kind;
            if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
                auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
                _v.set(c);
                goto _done;
            }
            {
                _v.set(e);
                goto _done;
            }
        _done:
            _v.take();
        });
        auto&& _m = callee.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            auto&& _m = crate::prelude::get(menv->names, crate::check::env::sname_key(n));
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnWidget>(prism_rtl::some_of(_m))) {
                return true;
            }
            {
                auto&& _q_opt = crate::check::env::names::resolve_value(lx.g, lx.home, n);
                auto&& q_opt = std::get<0>(_q_opt);
                if (prism_rtl::is_some(q_opt)) {
                    auto&& q = prism_rtl::some_of(q_opt);
                    return ((!is_prelude_name(q)) && (crate::prelude::get(lx.g.vals, q) != std::optional<crate::check::env::ValInfo>{})) && is_widget_ty(crate::lower::types::peel(crate::lower::type_at(lx, e.span)));
                }
                if (prism_rtl::is_none(q_opt)) {
                    return false;
                }
                prism_rtl::unreachable("no arm matched");
            }
        }
        {
            return false;
        }
    }
}


prism_rtl::Turn<bool> GivesResult::cycle() const {
    const auto& lx = this->lx;
    const auto& menv = this->menv;
    const auto& e = this->e;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(GivesResult(lx, menv, x)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m) ? prism_rtl::finished(true)
        : ({
        auto callee = ({
            __label__ _done;
            prism_rtl::Slot<crate::syntax::Expr> _v;
            auto&& _m = e.kind;
            if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
                auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
                _v.set(c);
                goto _done;
            }
            {
                _v.set(e);
                goto _done;
            }
        _done:
            _v.take();
        });
        ({
        auto&& _m = callee.kind;
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        ({
        auto&& _m = crate::prelude::get(menv->names, crate::check::env::sname_key(n));
        prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnWidget>(prism_rtl::some_of(_m)) ? prism_rtl::finished(true)
        : ({
        auto&& _q_opt = crate::check::env::names::resolve_value(lx.g, lx.home, n);
        auto&& q_opt = std::get<0>(_q_opt);
        ({
        prism_rtl::is_some(q_opt) ? ({
        auto&& q = prism_rtl::some_of(q_opt);
        prism_rtl::finished(((!is_prelude_name(q)) && (crate::prelude::get(lx.g.vals, q) != std::optional<crate::check::env::ValInfo>{})) && is_widget_ty(crate::lower::types::peel(crate::lower::type_at(lx, e.span))));
    })
        : prism_rtl::is_none(q_opt) ? prism_rtl::finished(false)
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    });
    })
        : prism_rtl::finished(false);
    });
    });
    });
}


/// `Start GivesResult, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_gives_result(crate::lower::Lx lx, crate::lower::types::Env menv, crate::syntax::Expr e) {
    return prism_rtl::make_rc<GivesResult>(lx, menv, e);
}


/// IsPreludeName: fn Text -> Bool
bool is_prelude_name(const Text& q) {
    return crate::prelude::find(([]() -> const Regex& { static const Regex r = Regex::lit("^Prelude\\.", ""); return r; }()), q) != std::optional<Match>{};
}


/// IsWidgetTy: fn Ty -> Bool
bool is_widget_ty(const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t)) {
        return true;
    }
    {
        return false;
    }
}


/// HowBound: fn ?Expr -> HowBound
HowBound how_bound(const std::optional<crate::syntax::Expr>& opt0) {
    if (prism_rtl::is_some(opt0)) {
        return HowBound(HowBound::AsHold{});
    }
    if (prism_rtl::is_none(opt0)) {
        return HowBound(HowBound::AsBind{});
    }
    prism_rtl::unreachable("no arm matched");
}


/// PreBindName: unbounded fn Wx, Env, Env, SName, HowBound -> ((Wx, Env, Env))
std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env> pre_bind_name(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const crate::syntax::SName& n, const HowBound& how) {
    auto lx = crate::lower::expr::widget_let_lx(wx.lx, n.span);
    auto nkey = crate::check::env::sname_key(n);
    auto full = crate::lower::binder_ty(lx, n.span);
    auto layer = crate::lower::types::layer_of(full);
    auto t = crate::lower::types::out_ty_of(lx, crate::lower::types::peel(full));
    auto [rs, wx1] = crate::lower::node_::fresh_name(wx, crate::lower::snake(nkey));
    return ((how == HowBound(HowBound::AsBind{})) || (how == HowBound(HowBound::AsResult{}))) && crate::lower::types::is_bundle(full)
        ? std::tuple{wx, benv, menv}
        : (layer == crate::lower::types::Layer(crate::lower::types::Layer::LyEv{})) || is_switched(full)
        ? ({
        auto et = crate::lower::types::out_ty_of(lx, crate::lower::types::peel(crate::lower::types::peel(full)));
        auto [id, wx2] = crate::lower::node_::add_gn(wx1, rs, et, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnNamed{}), Nat(0u));
        auto b = crate::lower::types::Bn(crate::lower::types::Bn::BnEv{crate::lower::node_::ev_ref_of(wx2, id), t});
        auto pf = prism_rtl::cat(rs, "_v_port");
        auto pt = crate::lower::model::OutTy(crate::lower::model::OutTy::OutRc{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutPort{prism_rtl::rc(et)}))});
        auto wx3 = ({
            crate::lower::node_::Wx this_ = crate::lower::node_::connect(wx2, crate::lower::node_::ev_ref_of(wx2, id), crate::lower::node_::Sk(crate::lower::node_::Sk::SkPort{prism_rtl::cat(rs, "_v")}));
            this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{pf})), pt}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Port::new"), Array<crate::lower::model::Ex>{}})})})}));
            this_.fields = crate::prelude::push(this_.fields, std::tuple{pf, pt, prism_rtl::cat("`", nkey, "` as a value: the port it fires")});
            this_.moves = crate::prelude::push(this_.moves, std::tuple{pf, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{pf}))})});
            this_;
        });
        auto be = crate::lower::types::bind(crate::lower::types::bind(benv, nkey, b), prism_rtl::cat(nkey, "#port"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{pf}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), pt}));
        auto me = crate::lower::types::bind(crate::lower::types::bind(menv, nkey, b), prism_rtl::cat(nkey, "#port"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), pf}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), pt}));
        std::tuple{wx3, be, me};
    })
        : ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> _v;
        auto&& _m = std::tuple{layer, how};
        if (prism_rtl::is<crate::lower::types::Layer::LyDyn>(std::get<0>(_m)) && prism_rtl::is<HowBound::AsLet>(std::get<1>(_m))) {
            _v.set(({
                auto b = crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), rs, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{rs})}), t});
                std::tuple{wx1, crate::lower::types::bind(benv, nkey, b), crate::lower::types::bind(menv, nkey, b)};
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::types::Layer::LyDyn>(std::get<0>(_m)) && prism_rtl::is<HowBound::AsResult>(std::get<1>(_m))) {
            _v.set(({
                auto b = crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), rs, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{rs})}), t});
                std::tuple{wx1, crate::lower::types::bind(benv, nkey, b), crate::lower::types::bind(menv, nkey, b)};
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::types::Layer::LyDyn>(std::get<0>(_m))) {
            _v.set(({
                auto b = crate::lower::types::Bn(crate::lower::types::Bn::BnHold{rs, t});
                std::tuple{wx1, crate::lower::types::bind(benv, nkey, b), crate::lower::types::bind(menv, nkey, b)};
            }));
            goto _done;
        }
        {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> _v;
                auto&& _m = many_instances(wx.lx, n.span);
                if (prism_rtl::is_some(_m)) {
                    auto&& insts = prism_rtl::some_of(_m);
                    _v.set(run_to_end(fold_job(crate::check::errors::range0(len(insts)), std::tuple{wx1, benv, menv}, ({
                        auto insts_1 = insts;
                        auto wx_2 = wx;
                        auto n_3 = n;
                        auto rs_4 = rs;
                        auto nkey_5 = nkey;
                        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>>(std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, Nat> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto insts_1_6 = insts_1;
                            auto wx_2_6 = wx_2;
                            auto n_3_6 = n_3;
                            auto rs_4_6 = rs_4;
                            auto nkey_5_6 = nkey_5;
                            entered(once_job([=]() {
                            return ({
                                auto [w, be, me] = p0;
                                auto k = p1;
                                ({
                                auto inst = or_(index(insts_1_6, k), std::tuple{Array<std::tuple<Text, crate::check::types::Ty>>{}, Array<std::tuple<Text, crate::check::types::Col>>{}});
                                auto lxk = crate::lower::expr::at_instance(wx_2_6.lx, inst);
                                call_then(crate::lower::types::start_out_ty_of(lxk, crate::lower::types::peel(crate::lower::binder_ty(lxk, n_3_6.span))), [=](crate::lower::model::OutTy out_ty_of_9227) {
                                return ({
                                    auto tk = out_ty_of_9227;
                                    auto [rk, w2] = k == Nat(0u)
                                        ? std::tuple{rs_4_6, w}
                                        : crate::lower::node_::fresh_name(w, prism_rtl::cat(rs_4_6, "_", k));
                                    auto bkey = k == Nat(0u) ? nkey_5_6 : prism_rtl::cat(nkey_5_6, "#inst", k);
                                    auto [be2, me2] = crate::lower::node_::bind_plain(be, me, bkey, rk, tk);
                                    auto ukey = prism_rtl::cat(nkey_5_6, "#", show_text(inst));
                                    (prism_rtl::finished(std::tuple{w2, with_use(be2, ukey, bkey), with_use(me2, ukey, bkey)}));
                                });
                            });
                            });
                            });
                        }));
                        });
                    }));
                    }))));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(({
                        auto [be, me] = crate::lower::node_::bind_plain(benv, menv, nkey, rs, t);
                        std::tuple{wx1, be, me};
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> PreBindName::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& n = this->n;
    const auto& how = this->how;
    auto benv_1 = benv;
    auto how_2 = how;
    auto menv_3 = menv;
    auto n_4 = n;
    auto wx_5 = wx;
    return call_then(crate::lower::expr::start_widget_let_lx(wx_5.lx, n_4.span), [=](crate::lower::Lx widget_let_lx_6816) {
        return ({
            auto lx = widget_let_lx_6816;
            auto nkey = crate::check::env::sname_key(n_4);
            auto full = crate::lower::binder_ty(lx, n_4.span);
            auto layer = crate::lower::types::layer_of(full);
            call_then(crate::lower::types::start_out_ty_of(lx, crate::lower::types::peel(full)), [=](crate::lower::model::OutTy out_ty_of_6944) {
            return ({
                auto t = out_ty_of_6944;
                auto [rs, wx1] = crate::lower::node_::fresh_name(wx_5, crate::lower::snake(nkey));
                ((how_2 == HowBound(HowBound::AsBind{})) || (how_2 == HowBound(HowBound::AsResult{}))) && crate::lower::types::is_bundle(full)
                ? prism_rtl::finished(std::tuple{wx_5, benv_1, menv_3})
                : (layer == crate::lower::types::Layer(crate::lower::types::Layer::LyEv{})) || is_switched(full)
                ? call_then(crate::lower::types::start_out_ty_of(lx, crate::lower::types::peel(crate::lower::types::peel(full))), [=](crate::lower::model::OutTy out_ty_of_7302) {
                return ({
                    auto et = out_ty_of_7302;
                    auto [id, wx2] = crate::lower::node_::add_gn(wx1, rs, et, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnNamed{}), Nat(0u));
                    auto b = crate::lower::types::Bn(crate::lower::types::Bn::BnEv{crate::lower::node_::ev_ref_of(wx2, id), t});
                    auto pf = prism_rtl::cat(rs, "_v_port");
                    auto pt = crate::lower::model::OutTy(crate::lower::model::OutTy::OutRc{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutPort{prism_rtl::rc(et)}))});
                    auto wx3 = ({
                        crate::lower::node_::Wx this_ = crate::lower::node_::connect(wx2, crate::lower::node_::ev_ref_of(wx2, id), crate::lower::node_::Sk(crate::lower::node_::Sk::SkPort{prism_rtl::cat(rs, "_v")}));
                        this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{pf})), pt}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Port::new"), Array<crate::lower::model::Ex>{}})})})}));
                        this_.fields = crate::prelude::push(this_.fields, std::tuple{pf, pt, prism_rtl::cat("`", nkey, "` as a value: the port it fires")});
                        this_.moves = crate::prelude::push(this_.moves, std::tuple{pf, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{pf}))})});
                        this_;
                    });
                    auto be = crate::lower::types::bind(crate::lower::types::bind(benv_1, nkey, b), prism_rtl::cat(nkey, "#port"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{pf}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), pt}));
                    auto me = crate::lower::types::bind(crate::lower::types::bind(menv_3, nkey, b), prism_rtl::cat(nkey, "#port"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), pf}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), pt}));
                    (prism_rtl::finished(std::tuple{wx3, be, me}));
                });
            })
                : ({
                auto&& _m = std::tuple{layer, how_2};
                prism_rtl::is<crate::lower::types::Layer::LyDyn>(std::get<0>(_m)) && prism_rtl::is<HowBound::AsLet>(std::get<1>(_m)) ? ({
                auto b = crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), rs, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{rs})}), t});
                (prism_rtl::finished(std::tuple{wx1, crate::lower::types::bind(benv_1, nkey, b), crate::lower::types::bind(menv_3, nkey, b)}));
            })
                : prism_rtl::is<crate::lower::types::Layer::LyDyn>(std::get<0>(_m)) && prism_rtl::is<HowBound::AsResult>(std::get<1>(_m)) ? ({
                auto b = crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), rs, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{rs})}), t});
                (prism_rtl::finished(std::tuple{wx1, crate::lower::types::bind(benv_1, nkey, b), crate::lower::types::bind(menv_3, nkey, b)}));
            })
                : prism_rtl::is<crate::lower::types::Layer::LyDyn>(std::get<0>(_m)) ? ({
                auto b = crate::lower::types::Bn(crate::lower::types::Bn::BnHold{rs, t});
                (prism_rtl::finished(std::tuple{wx1, crate::lower::types::bind(benv_1, nkey, b), crate::lower::types::bind(menv_3, nkey, b)}));
            })
                : call_then(start_many_instances(wx_5.lx, n_4.span), [=](std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> many_instances_8759) {
                return ({
                    prism_rtl::is_some(many_instances_8759) ? ({
                    auto&& insts = prism_rtl::some_of(many_instances_8759);
                    fold_job(crate::check::errors::range0(len(insts)), std::tuple{wx1, benv_1, menv_3}, ({
                    auto insts_6 = insts;
                    auto wx_5_7 = wx_5;
                    auto n_4_7 = n_4;
                    auto rs_7 = rs;
                    auto nkey_8 = nkey;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>>(std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto insts_6_9 = insts_6;
                        auto wx_5_7_9 = wx_5_7;
                        auto n_4_7_9 = n_4_7;
                        auto rs_7_9 = rs_7;
                        auto nkey_8_9 = nkey_8;
                        entered(once_job([=]() {
                        return ({
                            auto [w, be, me] = p0;
                            auto k = p1;
                            ({
                            auto inst = or_(index(insts_6_9, k), std::tuple{Array<std::tuple<Text, crate::check::types::Ty>>{}, Array<std::tuple<Text, crate::check::types::Col>>{}});
                            auto lxk = crate::lower::expr::at_instance(wx_5_7_9.lx, inst);
                            call_then(crate::lower::types::start_out_ty_of(lxk, crate::lower::types::peel(crate::lower::binder_ty(lxk, n_4_7_9.span))), [=](crate::lower::model::OutTy out_ty_of_9227) {
                            return ({
                                auto tk = out_ty_of_9227;
                                auto [rk, w2] = k == Nat(0u)
                                    ? std::tuple{rs_7_9, w}
                                    : crate::lower::node_::fresh_name(w, prism_rtl::cat(rs_7_9, "_", k));
                                auto bkey = k == Nat(0u) ? nkey_8_9 : prism_rtl::cat(nkey_8_9, "#inst", k);
                                auto [be2, me2] = crate::lower::node_::bind_plain(be, me, bkey, rk, tk);
                                auto ukey = prism_rtl::cat(nkey_8_9, "#", show_text(inst));
                                (prism_rtl::finished(std::tuple{w2, with_use(be2, ukey, bkey), with_use(me2, ukey, bkey)}));
                            });
                        });
                        });
                        });
                    }));
                    });
                }));
                }))->cycle();
                })
                    : prism_rtl::is_none(many_instances_8759) ? ({
                    auto [be, me] = crate::lower::node_::bind_plain(benv_1, menv_3, nkey, rs, t);
                    (prism_rtl::finished(std::tuple{wx1, be, me}));
                })
                    : throw prism_rtl::Panic("no arm matched");
                });
            });
            });
            });
        });
        });
    });
}


/// `Start PreBindName, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> start_pre_bind_name(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, crate::syntax::SName n, HowBound how) {
    return prism_rtl::make_rc<PreBindName>(wx, benv, menv, n, how);
}


/// WithUse: fn Env, Text, Text -> Env
crate::lower::types::Env with_use(const crate::lower::types::Env& env, const Text& ukey, const Text& bkey) {
    crate::lower::types::Env this_ = env;
    this_.uses = insert(this_.uses, ukey, bkey);
    return this_;
}


/// ?ManyInstances: unbounded fn Lx, Range -> ?[(([((Text, Ty))], [((Text, Col))]))]
std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> many_instances(const crate::lower::Lx& lx, const crate::syntax::Range& span) {
    auto&& _m = crate::prelude::get(lx.gens, crate::lower::place_key(lx, span));
    if (prism_rtl::is_some(_m)) {
        auto&& gn = prism_rtl::some_of(_m);
        auto insts = crate::lower::expr::instantiations(lx, gn);
        return len(insts) > Nat(1u)
            ? std::optional(insts)
            : std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>{};
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>> ManyInstances::cycle() const {
    const auto& lx = this->lx;
    const auto& span = this->span;
    return ({
        auto&& _m = crate::prelude::get(lx.gens, crate::lower::place_key(lx, span));
        prism_rtl::is_some(_m) ? ({
        auto&& gn = prism_rtl::some_of(_m);
        ({
        auto lx_1 = lx;
        call_then(crate::lower::expr::start_instantiations(lx_1, gn), [=](Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> instantiations_10104) {
        return ({
            auto insts = instantiations_10104;
            len(insts) > Nat(1u)
            ? prism_rtl::finished(std::optional(insts))
            : prism_rtl::finished(std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>{});
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ManyInstances, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>> start_many_instances(crate::lower::Lx lx, crate::syntax::Range span) {
    return prism_rtl::make_rc<ManyInstances>(lx, span);
}


/// IsSwitched: fn Ty -> Bool
bool is_switched(const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& m10421_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& m10421_0_1 = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        if (m10421_0_0 == Text::lit("$")) {
            if (prism_rtl::is<crate::check::types::Ty::TySig>(m10421_0_1)) {
                auto&& m10421_0_1_r_0 = prism_rtl::as<crate::check::types::Ty::TySig>(m10421_0_1).a0;
                if (m10421_0_1_r_0 == Text::lit("!")) {
                    return true;
                }
            }
        }
    }
    {
        return false;
    }
}


/// ?BindingOf: fn Env, Pattern -> ?Bn
std::optional<crate::lower::types::Bn> binding_of(const crate::lower::types::Env& env, const crate::syntax::Pattern_& p_) {
    auto&& _m = p_.kind;
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        return crate::prelude::get(env->names, crate::check::env::sname_key(n));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m)) {
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        return std::optional(crate::lower::types::Bn(crate::lower::types::Bn::BnParts{each(ps, [&](const crate::syntax::Pattern_& q) { return binding_of_name(env, q); })}));
    }
    {
        return std::optional<crate::lower::types::Bn>{};
    }
}


/// ?BindingOfName: fn Env, Pattern -> ?Bn
std::optional<crate::lower::types::Bn> binding_of_name(const crate::lower::types::Env& env, const crate::syntax::Pattern_& p_) {
    auto&& _m = p_.kind;
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        return crate::prelude::get(env->names, crate::check::env::sname_key(n));
    }
    {
        return std::optional<crate::lower::types::Bn>{};
    }
}


/// WidgetStmt: unbounded fn Wx, Env, Env, Stmt, Bool -> ((Wx, Env, Env))
std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env> widget_stmt(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const crate::syntax::Stmt& s, const bool& last) {
    auto lx = wx.lx;
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        auto [wx2, res] = build_line(wx, benv, menv, e, binding_of(menv, p_));
        auto wx3 = bind_res(wx2, menv, p_, res);
        auto&& _m = std::tuple{res, p_.kind};
        if (prism_rtl::is<crate::lower::node_::Wres::WrDyn>(std::get<0>(_m)) && prism_rtl::is<crate::syntax::PatternKind::PName>(std::get<1>(_m))) {
            auto&& ex = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(std::get<0>(_m)).a0;
            auto&& rds = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(std::get<0>(_m)).a1;
            auto&& t = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(std::get<0>(_m)).a2;
            auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(std::get<1>(_m)).a0;
            auto b = crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{ex, rds, t});
            return result_getter(wx3, menv, n, ex, rds, t, crate::lower::types::bind(benv, crate::check::env::sname_key(n), b), crate::lower::types::bind(menv, crate::check::env::sname_key(n), b));
        }
        if (prism_rtl::is<crate::lower::node_::Wres::WrHosted>(std::get<0>(_m)) && prism_rtl::is<crate::syntax::PatternKind::PTuple>(std::get<1>(_m))) {
            auto&& inner = prism_rtl::as<crate::lower::node_::Wres::WrHosted>(std::get<0>(_m)).a0;
            auto&& doc = prism_rtl::as<crate::lower::node_::Wres::WrHosted>(std::get<0>(_m)).a1;
            auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PTuple>(std::get<1>(_m)).a0;
            return bind_hosted(wx3, benv, menv, inner, doc, ps);
        }
        if (prism_rtl::is<crate::lower::node_::Wres::WrParts>(std::get<0>(_m)) && prism_rtl::is<crate::syntax::PatternKind::PTuple>(std::get<1>(_m))) {
            auto&& parts = prism_rtl::as<crate::lower::node_::Wres::WrParts>(std::get<0>(_m)).a0;
            auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PTuple>(std::get<1>(_m)).a0;
            return bind_parts(wx2, benv, menv, parts, ps);
        }
        if (prism_rtl::is<crate::lower::node_::Wres::WrParts>(std::get<0>(_m)) && prism_rtl::is<crate::syntax::PatternKind::PName>(std::get<1>(_m))) {
            auto&& parts = prism_rtl::as<crate::lower::node_::Wres::WrParts>(std::get<0>(_m)).a0;
            auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(std::get<1>(_m)).a0;
            auto b = bundle_bn(res);
            return std::tuple{wx3, crate::lower::types::bind(benv, crate::check::env::sname_key(n), b), crate::lower::types::bind(menv, crate::check::env::sname_key(n), b)};
        }
        {
            return std::tuple{wx3, benv, menv};
        }
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& init = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        auto&& step_ = prism_rtl::some_of(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2);
        auto [wx2, be2] = hold_line(wx, benv, menv, p_, init, step_);
        return std::tuple{wx2, be2, menv};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SIgnore>(_m)) {
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SIgnore>(_m).a0;
        auto&& _wx2 = build_line(wx, benv, menv, e, std::optional<crate::lower::types::Bn>{});
        auto&& wx2 = std::get<0>(_wx2);
        return std::tuple{wx2, benv, menv};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        auto [wx2, be2] = let_line(wx, benv, menv, p_, e);
        return std::tuple{wx2, be2, menv};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        auto&& _m = e.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
            auto&& m12228_0_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
            if (m12228_0_0 == Text::lit("@")) {
                auto [res, wx2] = result_of(wx, benv, menv, x);
                auto wx3 = ({
                    crate::lower::node_::Wx this_ = wx2;
                    this_.result = res;
                    this_;
                });
                return std::tuple{wx3, benv, menv};
            }
        }
        {
            auto [wx2, res] = build_line(wx, benv, menv, e, std::optional<crate::lower::types::Bn>{});
            auto wx3 = last ? set_result(wx2, res) : wx2;
            return std::tuple{wx3, benv, menv};
        }
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SEmit>(_m)) {
        return std::tuple{wx, benv, menv};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m)) {
        return std::tuple{wx, benv, menv};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        return std::tuple{wx, benv, menv};
    }
    {
        auto wx2 = ({
            crate::lower::node_::Wx this_ = wx;
            this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("a statement this back end does not lower yet")));
            this_;
        });
        return std::tuple{wx2, benv, menv};
    }
}


prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> WidgetStmt::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& s = this->s;
    const auto& last = this->last;
    auto lx = wx.lx;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        ({
        auto benv_1 = benv;
        auto e_2 = e;
        auto menv_3 = menv;
        auto p__4 = p_;
        auto wx_5 = wx;
        call_then(start_build_line(wx_5, benv_1, menv_3, e_2, binding_of(menv_3, p__4)), [=](std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> build_line_11092) {
        return ({
            auto [wx2, res] = build_line_11092;
            auto wx3 = bind_res(wx2, menv_3, p__4, res);
            ({
            auto&& _m = std::tuple{res, p__4.kind};
            prism_rtl::is<crate::lower::node_::Wres::WrDyn>(std::get<0>(_m)) && prism_rtl::is<crate::syntax::PatternKind::PName>(std::get<1>(_m)) ? ({
            auto&& ex = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(std::get<0>(_m)).a0;
            auto&& rds = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(std::get<0>(_m)).a1;
            auto&& t = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(std::get<0>(_m)).a2;
            auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(std::get<1>(_m)).a0;
            ({
            auto b = crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{ex, rds, t});
            (prism_rtl::finished(result_getter(wx3, menv_3, n, ex, rds, t, crate::lower::types::bind(benv_1, crate::check::env::sname_key(n), b), crate::lower::types::bind(menv_3, crate::check::env::sname_key(n), b))));
        });
        })
            : prism_rtl::is<crate::lower::node_::Wres::WrHosted>(std::get<0>(_m)) && prism_rtl::is<crate::syntax::PatternKind::PTuple>(std::get<1>(_m)) ? ({
            auto&& inner = prism_rtl::as<crate::lower::node_::Wres::WrHosted>(std::get<0>(_m)).a0;
            auto&& doc = prism_rtl::as<crate::lower::node_::Wres::WrHosted>(std::get<0>(_m)).a1;
            auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PTuple>(std::get<1>(_m)).a0;
            prism_rtl::finished(bind_hosted(wx3, benv_1, menv_3, inner, doc, ps));
        })
            : prism_rtl::is<crate::lower::node_::Wres::WrParts>(std::get<0>(_m)) && prism_rtl::is<crate::syntax::PatternKind::PTuple>(std::get<1>(_m)) ? ({
            auto&& parts = prism_rtl::as<crate::lower::node_::Wres::WrParts>(std::get<0>(_m)).a0;
            auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PTuple>(std::get<1>(_m)).a0;
            prism_rtl::more(prism_rtl::rc(BindParts(wx2, benv_1, menv_3, parts, ps)));
        })
            : prism_rtl::is<crate::lower::node_::Wres::WrParts>(std::get<0>(_m)) && prism_rtl::is<crate::syntax::PatternKind::PName>(std::get<1>(_m)) ? ({
            auto&& parts = prism_rtl::as<crate::lower::node_::Wres::WrParts>(std::get<0>(_m)).a0;
            auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(std::get<1>(_m)).a0;
            ({
            auto b = bundle_bn(res);
            (prism_rtl::finished(std::tuple{wx3, crate::lower::types::bind(benv_1, crate::check::env::sname_key(n), b), crate::lower::types::bind(menv_3, crate::check::env::sname_key(n), b)}));
        });
        })
            : prism_rtl::finished(std::tuple{wx3, benv_1, menv_3});
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& init = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        auto&& step_ = prism_rtl::some_of(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2);
        ({
        auto benv_1 = benv;
        auto init_2 = init;
        auto menv_3 = menv;
        auto p__4 = p_;
        auto step__5 = step_;
        auto wx_6 = wx;
        call_then(start_hold_line(wx_6, benv_1, menv_3, p__4, init_2, step__5), [=](std::tuple<crate::lower::node_::Wx, crate::lower::types::Env> hold_line_11905) {
        return ({
            auto [wx2, be2] = hold_line_11905;
            (prism_rtl::finished(std::tuple{wx2, be2, menv_3}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SIgnore>(_m) ? ({
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SIgnore>(_m).a0;
        ({
        auto benv_1 = benv;
        auto e_2 = e;
        auto menv_3 = menv;
        auto wx_4 = wx;
        call_then(start_build_line(wx_4, benv_1, menv_3, e_2, std::optional<crate::lower::types::Bn>{}), [=](std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> build_line_12028) {
        return ({
            auto&& _wx2 = build_line_12028;
            auto&& wx2 = std::get<0>(_wx2);
            (prism_rtl::finished(std::tuple{wx2, benv_1, menv_3}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        ({
        auto benv_1 = benv;
        auto e_2 = e;
        auto menv_3 = menv;
        auto p__4 = p_;
        auto wx_5 = wx;
        call_then(start_let_line(wx_5, benv_1, menv_3, p__4, e_2), [=](std::tuple<crate::lower::node_::Wx, crate::lower::types::Env> let_line_12151) {
        return ({
            auto [wx2, be2] = let_line_12151;
            (prism_rtl::finished(std::tuple{wx2, be2, menv_3}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m) && ({
        auto&& m12228_0_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        (m12228_0_0 == Text::lit("@"));
    }) ? ({
        auto&& m12228_0_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        ({
        auto benv_1 = benv;
        auto menv_2 = menv;
        auto wx_3 = wx;
        auto x_4 = x;
        call_then(start_result_of(wx_3, benv_1, menv_2, x_4), [=](std::tuple<crate::lower::node_::Wres, crate::lower::node_::Wx> result_of_12308) {
        return ({
            auto [res, wx2] = result_of_12308;
            auto wx3 = ({
                crate::lower::node_::Wx this_ = wx2;
                this_.result = res;
                this_;
            });
            (prism_rtl::finished(std::tuple{wx3, benv_1, menv_2}));
        });
    });
    });
    })
        : ({
        auto benv_1 = benv;
        auto e_2 = e;
        auto last_3 = last;
        auto menv_4 = menv;
        auto wx_5 = wx;
        call_then(start_build_line(wx_5, benv_1, menv_4, e_2, std::optional<crate::lower::types::Bn>{}), [=](std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> build_line_12504) {
        return ({
            auto [wx2, res] = build_line_12504;
            auto wx3 = last_3 ? set_result(wx2, res) : wx2;
            (prism_rtl::finished(std::tuple{wx3, benv_1, menv_4}));
        });
    });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SEmit>(_m) ? prism_rtl::finished(std::tuple{wx, benv, menv})
        : prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m) ? prism_rtl::finished(std::tuple{wx, benv, menv})
        : prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        prism_rtl::finished(std::tuple{wx, benv, menv});
    })
        : ({
        auto wx2 = ({
            crate::lower::node_::Wx this_ = wx;
            this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("a statement this back end does not lower yet")));
            this_;
        });
        (prism_rtl::finished(std::tuple{wx2, benv, menv}));
    });
    });
}


/// `Start WidgetStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> start_widget_stmt(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, crate::syntax::Stmt s, bool last) {
    return prism_rtl::make_rc<WidgetStmt>(wx, benv, menv, s, last);
}


/// BindHosted: fn Wx, Env, Env, Wres, Bn, [Pattern] -> ((Wx, Env, Env))
std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env> bind_hosted(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const crate::lower::node_::Wres& res, const crate::lower::types::Bn& doc, const Array<crate::syntax::Pattern_>& ps) {
    auto r_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<crate::lower::types::Bn>> _v;
        if (prism_rtl::is<crate::lower::node_::Wres::WrEv>(res)) {
            auto&& r = prism_rtl::as<crate::lower::node_::Wres::WrEv>(res).a0;
            _v.set(std::optional(crate::lower::types::Bn(crate::lower::types::Bn::BnEv{r, crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})})));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::node_::Wres::WrDyn>(res)) {
            auto&& ex = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(res).a0;
            auto&& rds = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(res).a1;
            auto&& t = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(res).a2;
            _v.set(std::optional(crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{ex, rds, t})));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::node_::Wres::WrParts>(res)) {
            _v.set(std::optional(bundle_bn(res)));
            goto _done;
        }
        {
            _v.set(std::optional<crate::lower::types::Bn>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [be1, me1] = bind_part(benv, menv, index(ps, Nat(0u)), r_opt);
    return bind_part2(wx, be1, me1, index(ps, Nat(1u)), std::optional(doc));
}


/// BindPart: fn Env, Env, ?Pattern, ?Bn -> ((Env, Env))
std::tuple<crate::lower::types::Env, crate::lower::types::Env> bind_part(const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const std::optional<crate::syntax::Pattern_>& p__opt, const std::optional<crate::lower::types::Bn>& b_opt) {
    auto&& _m = std::tuple{p__opt, b_opt};
    if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
        auto&& p_ = prism_rtl::some_of(std::get<0>(_m));
        auto&& b = prism_rtl::some_of(std::get<1>(_m));
        auto&& _m = p_.kind;
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            return std::tuple{crate::lower::types::bind(benv, crate::check::env::sname_key(n), b), crate::lower::types::bind(menv, crate::check::env::sname_key(n), b)};
        }
        {
            return std::tuple{benv, menv};
        }
    }
    {
        return std::tuple{benv, menv};
    }
}


/// BindPart2: fn Wx, Env, Env, ?Pattern, ?Bn -> ((Wx, Env, Env))
std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env> bind_part2(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const std::optional<crate::syntax::Pattern_>& p__opt, const std::optional<crate::lower::types::Bn>& b_opt) {
    auto [be, me] = bind_part(benv, menv, p__opt, b_opt);
    return std::tuple{wx, be, me};
}


/// BindParts: unbounded fn Wx, Env, Env, [Wres], [Pattern] -> ((Wx, Env, Env))
std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env> bind_parts(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const Array<crate::lower::node_::Wres>& parts, const Array<crate::syntax::Pattern_>& ps) {
    return run_to_end(fold_job(crate::check::errors::range0(len(ps)), std::tuple{wx, benv, menv}, ({
        auto ps_1 = ps;
        auto parts_2 = parts;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>>(std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto ps_1_3 = ps_1;
            auto parts_2_3 = parts_2;
            entered(once_job([=]() {
            return ({
                auto [w, be, me] = p0;
                auto i = p1;
                ({
                auto&& _m = std::tuple{index(ps_1_3, i), index(parts_2_3, i)};
                prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m)) ? ({
                auto&& p_ = prism_rtl::some_of(std::get<0>(_m));
                auto&& part = prism_rtl::some_of(std::get<1>(_m));
                ({
                auto&& _m = std::tuple{part, p_.kind};
                prism_rtl::is<crate::lower::node_::Wres::WrEv>(std::get<0>(_m)) && prism_rtl::is<crate::syntax::PatternKind::PName>(std::get<1>(_m)) ? ({
                auto&& r = prism_rtl::as<crate::lower::node_::Wres::WrEv>(std::get<0>(_m)).a0;
                prism_rtl::finished(std::tuple{bind_res(w, me, p_, part), be, me});
            })
                : prism_rtl::is<crate::lower::node_::Wres::WrParts>(std::get<0>(_m)) && prism_rtl::is<crate::syntax::PatternKind::PTuple>(std::get<1>(_m)) ? ({
                auto&& inner = prism_rtl::as<crate::lower::node_::Wres::WrParts>(std::get<0>(_m)).a0;
                auto&& qs = prism_rtl::as<crate::syntax::PatternKind::PTuple>(std::get<1>(_m)).a0;
                prism_rtl::more(prism_rtl::rc(BindParts(w, be, me, inner, qs)));
            })
                : prism_rtl::is<crate::syntax::PatternKind::PName>(std::get<1>(_m)) ? ({
                auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(std::get<1>(_m)).a0;
                ({
                prism_rtl::is<crate::lower::node_::Wres::WrUnit>(part) ? prism_rtl::finished(std::tuple{w, be, me})
                : prism_rtl::is<crate::lower::node_::Wres::WrDyn>(part) ? ({
                auto&& ex = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(part).a0;
                auto&& rds = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(part).a1;
                auto&& t = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(part).a2;
                ({
                auto b = crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{ex, rds, t});
                (prism_rtl::finished(result_getter(w, me, n, ex, rds, t, crate::lower::types::bind(be, crate::check::env::sname_key(n), b), crate::lower::types::bind(me, crate::check::env::sname_key(n), b))));
            });
            })
                : ({
                auto b = bundle_bn(part);
                (prism_rtl::finished(std::tuple{w, crate::lower::types::bind(be, crate::check::env::sname_key(n), b), crate::lower::types::bind(me, crate::check::env::sname_key(n), b)}));
            });
            });
            })
                : prism_rtl::finished(std::tuple{w, be, me});
            });
            })
                : prism_rtl::finished(std::tuple{w, be, me});
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> BindParts::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& parts = this->parts;
    const auto& ps = this->ps;
    return fold_job(crate::check::errors::range0(len(ps)), std::tuple{wx, benv, menv}, ({
        auto ps_1 = ps;
        auto parts_2 = parts;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>>(std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto ps_1_3 = ps_1;
            auto parts_2_3 = parts_2;
            entered(once_job([=]() {
            return ({
                auto [w, be, me] = p0;
                auto i = p1;
                ({
                auto&& _m = std::tuple{index(ps_1_3, i), index(parts_2_3, i)};
                prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m)) ? ({
                auto&& p_ = prism_rtl::some_of(std::get<0>(_m));
                auto&& part = prism_rtl::some_of(std::get<1>(_m));
                ({
                auto&& _m = std::tuple{part, p_.kind};
                prism_rtl::is<crate::lower::node_::Wres::WrEv>(std::get<0>(_m)) && prism_rtl::is<crate::syntax::PatternKind::PName>(std::get<1>(_m)) ? ({
                auto&& r = prism_rtl::as<crate::lower::node_::Wres::WrEv>(std::get<0>(_m)).a0;
                prism_rtl::finished(std::tuple{bind_res(w, me, p_, part), be, me});
            })
                : prism_rtl::is<crate::lower::node_::Wres::WrParts>(std::get<0>(_m)) && prism_rtl::is<crate::syntax::PatternKind::PTuple>(std::get<1>(_m)) ? ({
                auto&& inner = prism_rtl::as<crate::lower::node_::Wres::WrParts>(std::get<0>(_m)).a0;
                auto&& qs = prism_rtl::as<crate::syntax::PatternKind::PTuple>(std::get<1>(_m)).a0;
                prism_rtl::more(prism_rtl::rc(BindParts(w, be, me, inner, qs)));
            })
                : prism_rtl::is<crate::syntax::PatternKind::PName>(std::get<1>(_m)) ? ({
                auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(std::get<1>(_m)).a0;
                ({
                prism_rtl::is<crate::lower::node_::Wres::WrUnit>(part) ? prism_rtl::finished(std::tuple{w, be, me})
                : prism_rtl::is<crate::lower::node_::Wres::WrDyn>(part) ? ({
                auto&& ex = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(part).a0;
                auto&& rds = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(part).a1;
                auto&& t = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(part).a2;
                ({
                auto b = crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{ex, rds, t});
                (prism_rtl::finished(result_getter(w, me, n, ex, rds, t, crate::lower::types::bind(be, crate::check::env::sname_key(n), b), crate::lower::types::bind(me, crate::check::env::sname_key(n), b))));
            });
            })
                : ({
                auto b = bundle_bn(part);
                (prism_rtl::finished(std::tuple{w, crate::lower::types::bind(be, crate::check::env::sname_key(n), b), crate::lower::types::bind(me, crate::check::env::sname_key(n), b)}));
            });
            });
            })
                : prism_rtl::finished(std::tuple{w, be, me});
            });
            })
                : prism_rtl::finished(std::tuple{w, be, me});
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start BindParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> start_bind_parts(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, Array<crate::lower::node_::Wres> parts, Array<crate::syntax::Pattern_> ps) {
    return prism_rtl::make_rc<BindParts>(wx, benv, menv, parts, ps);
}


/// ResultGetter: fn Wx, Env, SName, Ex, [Read], OutTy, Env, Env -> ((Wx, Env, Env))
std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env> result_getter(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& menv, const crate::syntax::SName& n, const crate::lower::model::Ex& ex, const Array<crate::lower::node_::Read>& rds, const crate::lower::model::OutTy& t, const crate::lower::types::Env& benv2, const crate::lower::types::Env& menv2) {
    auto&& _m = crate::prelude::get(menv->names, crate::check::env::sname_key(n));
    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)) && prism_rtl::is<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0)) {
        auto&& m15540_0_0_0 = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a0;
        auto&& rs = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a1;
        auto&& m15540_0_1 = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a1;
        if (prism_rtl::is<crate::lower::model::Ex::XSelf>(m15540_0_0_0)) {
            if (m15540_0_1.size() == 1u) {
                {
                    auto&& _c2 = index(m15540_0_1, Nat(0u));
                    if (prism_rtl::is_some(_c2) && prism_rtl::is<crate::lower::node_::Read::OwnRead>(prism_rtl::some_of(_c2))) {
                        auto&& r0 = prism_rtl::as<crate::lower::node_::Read::OwnRead>(prism_rtl::some_of(_c2)).a0;
                        if ((r0 == rs) && (!crate::check::types::has_text(keys(wx.dyn_reads), rs))) {
                            auto getter = crate::lower::model::MethDef{.name = rs, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = t, .body = Array<crate::lower::model::Do>{}, .tail = ex, .doc = prism_rtl::cat("`", crate::check::env::sname_key(n), "`, a widget\'s result")};
                            auto wx2 = ({
                                crate::lower::node_::Wx this_ = wx;
                                this_.getters = crate::prelude::push(this_.getters, getter);
                                this_.dyn_reads = insert(this_.dyn_reads, rs, rds);
                                this_;
                            });
                            return std::tuple{wx2, benv2, menv2};
                        }
                    }
                }
            }
        }
    }
    {
        return std::tuple{wx, benv2, menv2};
    }
}


/// BundleBn: fn Wres -> Bn
crate::lower::types::Bn bundle_bn(const crate::lower::node_::Wres& res) {
    if (prism_rtl::is<crate::lower::node_::Wres::WrEv>(res)) {
        auto&& r = prism_rtl::as<crate::lower::node_::Wres::WrEv>(res).a0;
        return crate::lower::types::Bn(crate::lower::types::Bn::BnEv{r, crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})});
    }
    if (prism_rtl::is<crate::lower::node_::Wres::WrDyn>(res)) {
        auto&& ex = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(res).a0;
        auto&& rds = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(res).a1;
        auto&& t = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(res).a2;
        return crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{ex, rds, t});
    }
    if (prism_rtl::is<crate::lower::node_::Wres::WrPlain>(res)) {
        auto&& ex = prism_rtl::as<crate::lower::node_::Wres::WrPlain>(res).a0;
        auto&& t = prism_rtl::as<crate::lower::node_::Wres::WrPlain>(res).a1;
        return crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{ex, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t});
    }
    if (prism_rtl::is<crate::lower::node_::Wres::WrParts>(res)) {
        auto&& parts = prism_rtl::as<crate::lower::node_::Wres::WrParts>(res).a0;
        return crate::lower::types::Bn(crate::lower::types::Bn::BnParts{each(parts, [&](const crate::lower::node_::Wres& q) { return std::optional(bundle_bn(q)); })});
    }
    if (prism_rtl::is<crate::lower::node_::Wres::WrHosted>(res)) {
        auto&& inner = prism_rtl::as<crate::lower::node_::Wres::WrHosted>(res).a0;
        return bundle_bn(inner);
    }
    if (prism_rtl::is<crate::lower::node_::Wres::WrUnit>(res)) {
        return crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})});
    }
    prism_rtl::unreachable("no arm matched");
}


/// BnRes: fn Bn -> Wres
crate::lower::node_::Wres bn_res(const crate::lower::types::Bn& b) {
    if (prism_rtl::is<crate::lower::types::Bn::BnEv>(b)) {
        auto&& r = prism_rtl::as<crate::lower::types::Bn::BnEv>(b).a0;
        return crate::lower::node_::Wres(crate::lower::node_::Wres::WrEv{r});
    }
    if (prism_rtl::is<crate::lower::types::Bn::BnDyn>(b)) {
        auto&& ex = prism_rtl::as<crate::lower::types::Bn::BnDyn>(b).a0;
        auto&& rds = prism_rtl::as<crate::lower::types::Bn::BnDyn>(b).a1;
        auto&& t = prism_rtl::as<crate::lower::types::Bn::BnDyn>(b).a2;
        return crate::lower::node_::Wres(crate::lower::node_::Wres::WrDyn{ex, rds, t});
    }
    if (prism_rtl::is<crate::lower::types::Bn::BnLocal>(b)) {
        auto&& ex = prism_rtl::as<crate::lower::types::Bn::BnLocal>(b).a0;
        auto&& t = prism_rtl::as<crate::lower::types::Bn::BnLocal>(b).a2;
        return t == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})
            ? crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})
            : crate::lower::node_::Wres(crate::lower::node_::Wres::WrPlain{ex, t});
    }
    if (prism_rtl::is<crate::lower::types::Bn::BnParts>(b)) {
        auto&& bs = prism_rtl::as<crate::lower::types::Bn::BnParts>(b).a0;
        return crate::lower::node_::Wres(crate::lower::node_::Wres::WrParts{each(bs, part_res)});
    }
    {
        return crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{});
    }
}


/// PartRes: fn ?Bn -> Wres
crate::lower::node_::Wres part_res(const std::optional<crate::lower::types::Bn>& b_opt) {
    if (prism_rtl::is_some(b_opt)) {
        auto&& b = prism_rtl::some_of(b_opt);
        return bn_res(b);
    }
    if (prism_rtl::is_none(b_opt)) {
        return crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{});
    }
    prism_rtl::unreachable("no arm matched");
}


/// SetResult: fn Wx, Wres -> Wx
crate::lower::node_::Wx set_result(const crate::lower::node_::Wx& wx, const crate::lower::node_::Wres& res) {
    crate::lower::node_::Wx this_ = wx;
    this_.result = res;
    return this_;
}


/// ResultOf: unbounded fn Wx, Env, Env, Expr -> ((Wres, Wx))
std::tuple<crate::lower::node_::Wres, crate::lower::node_::Wx> result_of(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const crate::syntax::Expr& x) {
    auto lx = wx.lx;
    auto full = crate::lower::type_at(lx, x.span);
    auto t = crate::lower::types::out_ty_of(lx, crate::lower::types::peel(full));
    auto bound_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<crate::lower::types::Bn>> _v;
        auto&& _m = x.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            _v.set(len(n->path_) == Nat(1u)
                ? crate::prelude::get(menv->names, crate::check::env::sname_key(n))
                : std::optional<crate::lower::types::Bn>{});
            goto _done;
        }
        {
            _v.set(std::optional<crate::lower::types::Bn>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    if (prism_rtl::is_some(bound_opt) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_opt))) {
        auto&& r = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_opt)).a0;
        return std::tuple{crate::lower::node_::Wres(crate::lower::node_::Wres::WrEv{r}), wx};
    }
    if (prism_rtl::is_some(bound_opt) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_opt))) {
        auto&& ex = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_opt)).a0;
        auto&& rds = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_opt)).a1;
        auto&& bt = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_opt)).a2;
        return std::tuple{crate::lower::node_::Wres(crate::lower::node_::Wres::WrDyn{ex, rds, bt}), wx};
    }
    if (prism_rtl::is_some(bound_opt) && prism_rtl::is<crate::lower::types::Bn::BnParts>(prism_rtl::some_of(bound_opt))) {
        auto&& bs = prism_rtl::as<crate::lower::types::Bn::BnParts>(prism_rtl::some_of(bound_opt)).a0;
        return std::tuple{bn_res(crate::lower::types::Bn(crate::lower::types::Bn::BnParts{bs})), wx};
    }
    {
        auto&& _m = x.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m)) {
            auto&& xs = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
            if (crate::lower::types::is_bundle(full)) {
                auto [parts, wx2] = run_to_end(fold_job(xs, std::tuple{Array<crate::lower::node_::Wres>{}, wx}, ({
                    auto benv_1 = benv;
                    auto menv_2 = menv;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::node_::Wres>, crate::lower::node_::Wx>>(std::tuple<std::tuple<Array<crate::lower::node_::Wres>, crate::lower::node_::Wx>, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::lower::node_::Wres>, crate::lower::node_::Wx>, crate::syntax::Expr> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto benv_1_3 = benv_1;
                        auto menv_2_3 = menv_2;
                        entered(once_job([=]() {
                        return ({
                            auto [acc, w] = p0;
                            auto y = p1;
                            call_then(start_result_of(w, benv_1_3, menv_2_3, y), [=](std::tuple<crate::lower::node_::Wres, crate::lower::node_::Wx> result_of_17677) {
                            return ({
                                auto [r, w2] = result_of_17677;
                                (prism_rtl::finished(std::tuple{crate::prelude::push(acc, r), w2}));
                            });
                        });
                        });
                    }));
                    });
                }));
                })));
                return std::tuple{crate::lower::node_::Wres(crate::lower::node_::Wres::WrParts{parts}), wx2};
            }
        }
        {
            return result_of_typed(wx, benv, menv, x, full, t);
        }
    }
}


prism_rtl::Turn<std::tuple<crate::lower::node_::Wres, crate::lower::node_::Wx>> ResultOf::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& x = this->x;
    auto lx = wx.lx;
    auto full = crate::lower::type_at(lx, x.span);
    auto benv_1 = benv;
    auto menv_2 = menv;
    auto wx_3 = wx;
    auto x_4 = x;
    return call_then(crate::lower::types::start_out_ty_of(lx, crate::lower::types::peel(full)), [=](crate::lower::model::OutTy out_ty_of_17086) {
        return ({
            auto t = out_ty_of_17086;
            auto bound_opt = ({
                __label__ _done;
                prism_rtl::Slot<std::optional<crate::lower::types::Bn>> _v;
                auto&& _m = x_4.kind;
                if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                    auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                    _v.set(len(n->path_) == Nat(1u)
                        ? crate::prelude::get(menv_2->names, crate::check::env::sname_key(n))
                        : std::optional<crate::lower::types::Bn>{});
                    goto _done;
                }
                {
                    _v.set(std::optional<crate::lower::types::Bn>{});
                    goto _done;
                }
            _done:
                _v.take();
            });
            ({
            prism_rtl::is_some(bound_opt) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_opt)) ? ({
            auto&& r = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_opt)).a0;
            prism_rtl::finished(std::tuple{crate::lower::node_::Wres(crate::lower::node_::Wres::WrEv{r}), wx_3});
        })
            : prism_rtl::is_some(bound_opt) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_opt)) ? ({
            auto&& ex = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_opt)).a0;
            auto&& rds = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_opt)).a1;
            auto&& bt = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_opt)).a2;
            prism_rtl::finished(std::tuple{crate::lower::node_::Wres(crate::lower::node_::Wres::WrDyn{ex, rds, bt}), wx_3});
        })
            : prism_rtl::is_some(bound_opt) && prism_rtl::is<crate::lower::types::Bn::BnParts>(prism_rtl::some_of(bound_opt)) ? ({
            auto&& bs = prism_rtl::as<crate::lower::types::Bn::BnParts>(prism_rtl::some_of(bound_opt)).a0;
            prism_rtl::finished(std::tuple{bn_res(crate::lower::types::Bn(crate::lower::types::Bn::BnParts{bs})), wx_3});
        })
            : ({
            auto&& _m = x_4.kind;
            prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m) && ({
            auto&& xs = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
            crate::lower::types::is_bundle(full);
        }) ? ({
            auto&& xs = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
            ({
            auto xs_5 = xs;
            call_value(fold_job(xs_5, std::tuple{Array<crate::lower::node_::Wres>{}, wx_3}, ({
            auto benv_1_6 = benv_1;
            auto menv_2_6 = menv_2;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::node_::Wres>, crate::lower::node_::Wx>>(std::tuple<std::tuple<Array<crate::lower::node_::Wres>, crate::lower::node_::Wx>, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::lower::node_::Wres>, crate::lower::node_::Wx>, crate::syntax::Expr> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto benv_1_6_6 = benv_1_6;
                auto menv_2_6_6 = menv_2_6;
                entered(once_job([=]() {
                return ({
                    auto [acc, w] = p0;
                    auto y = p1;
                    call_then(start_result_of(w, benv_1_6_6, menv_2_6_6, y), [=](std::tuple<crate::lower::node_::Wres, crate::lower::node_::Wx> result_of_17677) {
                    return ({
                        auto [r, w2] = result_of_17677;
                        (prism_rtl::finished(std::tuple{crate::prelude::push(acc, r), w2}));
                    });
                });
                });
            }));
            });
        }));
        })), [=](std::tuple<Array<crate::lower::node_::Wres>, crate::lower::node_::Wx> fold_17601) {
            return ({
                auto [parts, wx2] = fold_17601;
                (prism_rtl::finished(std::tuple{crate::lower::node_::Wres(crate::lower::node_::Wres::WrParts{parts}), wx2}));
            });
        });
        });
        })
            : prism_rtl::more(prism_rtl::rc(ResultOfTyped(wx_3, benv_1, menv_2, x_4, full, t)));
        });
        });
        });
    });
}


/// `Start ResultOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::node_::Wres, crate::lower::node_::Wx>> start_result_of(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, crate::syntax::Expr x) {
    return prism_rtl::make_rc<ResultOf>(wx, benv, menv, x);
}


/// ResultOfTyped: unbounded fn Wx, Env, Env, Expr, Ty, OutTy -> ((Wres, Wx))
std::tuple<crate::lower::node_::Wres, crate::lower::node_::Wx> result_of_typed(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const crate::syntax::Expr& x, const crate::check::types::Ty& full, const crate::lower::model::OutTy& t) {
    auto lx = wx.lx;
    auto&& _m = crate::lower::types::layer_of(full);
    if (prism_rtl::is<crate::lower::types::Layer::LyEv>(_m)) {
        auto [r, wx2] = crate::lower::node_::dynamics::event_ref(wx, menv, x);
        return std::tuple{crate::lower::node_::Wres(crate::lower::node_::Wres::WrEv{r}), wx2};
    }
    if (prism_rtl::is<crate::lower::types::Layer::LyDyn>(_m)) {
        auto [ex, reads] = crate::lower::node_::dynamics::dynamic_expr(wx, menv, x);
        return std::tuple{crate::lower::node_::Wres(crate::lower::node_::Wres::WrDyn{ex, reads, t}), wx};
    }
    {
        return t == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})
            ? std::tuple{crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{}), wx}
            : std::tuple{crate::lower::node_::Wres(crate::lower::node_::Wres::WrPlain{crate::lower::types::own(crate::lower::expr::value_of(lx, benv, x)), t}), wx};
    }
}


prism_rtl::Turn<std::tuple<crate::lower::node_::Wres, crate::lower::node_::Wx>> ResultOfTyped::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& x = this->x;
    const auto& full = this->full;
    const auto& t = this->t;
    auto lx = wx.lx;
    return ({
        auto&& _m = crate::lower::types::layer_of(full);
        prism_rtl::is<crate::lower::types::Layer::LyEv>(_m) ? ({
        auto menv_1 = menv;
        auto wx_2 = wx;
        auto x_3 = x;
        call_then(crate::lower::node_::dynamics::start_event_ref(wx_2, menv_1, x_3), [=](std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> event_ref_18054) {
        return ({
            auto [r, wx2] = event_ref_18054;
            (prism_rtl::finished(std::tuple{crate::lower::node_::Wres(crate::lower::node_::Wres::WrEv{r}), wx2}));
        });
    });
    })
        : prism_rtl::is<crate::lower::types::Layer::LyDyn>(_m) ? ({
        auto menv_1 = menv;
        auto t_2 = t;
        auto wx_3 = wx;
        auto x_4 = x;
        call_then(crate::lower::node_::dynamics::start_dynamic_expr(wx_3, menv_1, x_4), [=](std::tuple<crate::lower::model::Ex, Array<crate::lower::node_::Read>> dynamic_expr_18150) {
        return ({
            auto [ex, reads] = dynamic_expr_18150;
            (prism_rtl::finished(std::tuple{crate::lower::node_::Wres(crate::lower::node_::Wres::WrDyn{ex, reads, t_2}), wx_3}));
        });
    });
    })
        : t == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})
        ? prism_rtl::finished(std::tuple{crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{}), wx})
        : ({
        auto benv_1 = benv;
        auto t_2 = t;
        auto wx_3 = wx;
        auto x_4 = x;
        call_then(crate::lower::expr::start_value_of(lx, benv_1, x_4), [=](crate::lower::types::Vl value_of_18313) { return prism_rtl::finished(std::tuple{crate::lower::node_::Wres(crate::lower::node_::Wres::WrPlain{crate::lower::types::own(value_of_18313), t_2}), wx_3}); });
    });
    });
}


/// `Start ResultOfTyped, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::node_::Wres, crate::lower::node_::Wx>> start_result_of_typed(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, crate::syntax::Expr x, crate::check::types::Ty full, crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<ResultOfTyped>(wx, benv, menv, x, full, t);
}


/// HoldLine: unbounded fn Wx, Env, Env, Pattern, Expr, Expr -> ((Wx, Env))
std::tuple<crate::lower::node_::Wx, crate::lower::types::Env> hold_line(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const crate::syntax::Pattern_& p_, const crate::syntax::Expr& init, const crate::syntax::Expr& step_) {
    auto lx = wx.lx;
    auto&& _m = binding_of(menv, p_);
    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(_m))) {
        auto&& f = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(_m)).a0;
        auto&& t = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(_m)).a1;
        auto iv = crate::lower::types::own(crate::lower::expr::value_of(lx, benv, init));
        auto wx1 = crate::lower::node_::add_field(wx, f, crate::lower::model::OutTy(crate::lower::model::OutTy::OutHold{prism_rtl::rc(t)}), prism_rtl::cat("`", pat_text(p_), "`"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Hold::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat(f, "_init")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}));
        auto [r, wx2] = crate::lower::node_::dynamics::event_ref(wx1, menv, step_);
        auto wx3 = ({
            crate::lower::node_::Wx this_ = crate::lower::node_::connect(wx2, r, crate::lower::node_::Sk(crate::lower::node_::Sk::SkHold{f}));
            this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat(f, "_init")})), t}), iv}));
            this_.inited = crate::prelude::push(this_.inited, f);
            this_;
        });
        return std::tuple{wx3, crate::lower::types::bind(benv, prism_rtl::cat(pat_text(p_), "#init"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat(f, "_init")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t}))};
    }
    {
        return std::tuple{wx, benv};
    }
}


prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env>> HoldLine::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& p_ = this->p_;
    const auto& init = this->init;
    const auto& step_ = this->step_;
    auto lx = wx.lx;
    return ({
        auto&& _m = binding_of(menv, p_);
        prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(_m)) ? ({
        auto&& f = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(_m)).a0;
        auto&& t = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(_m)).a1;
        ({
        auto benv_1 = benv;
        auto init_2 = init;
        auto menv_3 = menv;
        auto p__4 = p_;
        auto step__5 = step_;
        auto wx_6 = wx;
        call_then(crate::lower::expr::start_value_of(lx, benv_1, init_2), [=](crate::lower::types::Vl value_of_18868) {
        return ({
            auto iv = crate::lower::types::own(value_of_18868);
            auto wx1 = crate::lower::node_::add_field(wx_6, f, crate::lower::model::OutTy(crate::lower::model::OutTy::OutHold{prism_rtl::rc(t)}), prism_rtl::cat("`", pat_text(p__4), "`"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Hold::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat(f, "_init")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}));
            call_then(crate::lower::node_::dynamics::start_event_ref(wx1, menv_3, step__5), [=](std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> event_ref_19046) {
            return ({
                auto [r, wx2] = event_ref_19046;
                auto wx3 = ({
                    crate::lower::node_::Wx this_ = crate::lower::node_::connect(wx2, r, crate::lower::node_::Sk(crate::lower::node_::Sk::SkHold{f}));
                    this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat(f, "_init")})), t}), iv}));
                    this_.inited = crate::prelude::push(this_.inited, f);
                    this_;
                });
                (prism_rtl::finished(std::tuple{wx3, crate::lower::types::bind(benv_1, prism_rtl::cat(pat_text(p__4), "#init"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat(f, "_init")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t}))}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::finished(std::tuple{wx, benv});
    });
}


/// `Start HoldLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env>> start_hold_line(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, crate::syntax::Pattern_ p_, crate::syntax::Expr init, crate::syntax::Expr step_) {
    return prism_rtl::make_rc<HoldLine>(wx, benv, menv, p_, init, step_);
}


/// InitEnv: fn Env -> Env
crate::lower::types::Env init_env(const crate::lower::types::Env& env) {
    return fold(keys(env->names), env, [&](const crate::lower::types::Env& en, const Text& k) {
        return ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::types::Env> _v;
            auto&& _m = std::tuple{crate::syntax::lexer::chars::before_suffix(k, Text::lit("#init")), crate::prelude::get(env->names, k)};
            if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                auto&& name = prism_rtl::some_of(std::get<0>(_m));
                auto&& b = prism_rtl::some_of(std::get<1>(_m));
                _v.set(crate::lower::types::bind(en, name, b));
                goto _done;
            }
            {
                _v.set(en);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// AllInited: fn Wx, [Read] -> Bool
bool all_inited(const crate::lower::node_::Wx& wx, const Array<crate::lower::node_::Read>& reads) {
    return fold(crate::lower::node_::finish::reads_closed(wx.dyn_reads, reads), true, [&](const bool& ok_, const crate::lower::node_::Read& r) {
        return ok_ && ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            if (prism_rtl::is<crate::lower::node_::Read::OwnRead>(r)) {
                auto&& f = prism_rtl::as<crate::lower::node_::Read::OwnRead>(r).a0;
                _v.set(crate::check::types::has_text(wx.inited, f));
                goto _done;
            }
            if (prism_rtl::is<crate::lower::node_::Read::ParentRead>(r)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// NamesInited: unbounded fn Env, Expr -> Bool
bool names_inited(const crate::lower::types::Env& env, const crate::syntax::Expr& e) {
    return fold(crate::lower::expr::read_names(crate::check::typed::print::exprs_in(e)), true, [&](const bool& ok_, const Text& n) {
        return ok_ && ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = crate::prelude::get(env->names, n);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m))) {
                _v.set(crate::check::env::has_key(env->names, prism_rtl::cat(n, "#init")));
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(_m))) {
                _v.set(crate::check::env::has_key(env->names, prism_rtl::cat(n, "#init")));
                goto _done;
            }
            {
                _v.set(true);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<bool> NamesInited::cycle() const {
    const auto& env = this->env;
    const auto& e = this->e;
    auto e_1 = e;
    auto env_2 = env;
    return call_then(crate::check::typed::print::start_exprs_in(e_1), [=](Array<crate::syntax::Expr> exprs_in_20565) {
        return call_then(crate::lower::expr::start_read_names(exprs_in_20565), [=](Array<Text> read_names_20554) {
            return prism_rtl::finished(fold(read_names_20554, true, [&](const bool& ok_, const Text& n) {
                return ok_ && ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = crate::prelude::get(env_2->names, n);
                    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m))) {
                        _v.set(crate::check::env::has_key(env_2->names, prism_rtl::cat(n, "#init")));
                        goto _done;
                    }
                    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(_m))) {
                        _v.set(crate::check::env::has_key(env_2->names, prism_rtl::cat(n, "#init")));
                        goto _done;
                    }
                    {
                        _v.set(true);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            }));
        });
    });
}


/// `Start NamesInited, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_names_inited(crate::lower::types::Env env, crate::syntax::Expr e) {
    return prism_rtl::make_rc<NamesInited>(env, e);
}


/// PatText: fn Pattern -> Text
Text pat_text(const crate::syntax::Pattern_& p_) {
    auto&& _m = p_.kind;
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        return crate::check::env::sname_key(n);
    }
    {
        return Text::lit("_");
    }
}


/// LetLine: unbounded fn Wx, Env, Env, Pattern, Expr -> ((Wx, Env))
std::tuple<crate::lower::node_::Wx, crate::lower::types::Env> let_line(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const crate::syntax::Pattern_& p_, const crate::syntax::Expr& e) {
    auto lx = wx.lx;
    auto&& _m = binding_of(menv, p_);
    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(_m))) {
        auto&& er = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(_m)).a0;
        auto&& t = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(_m)).a1;
        auto [r, wx2] = crate::lower::node_::dynamics::event_ref(wx, menv, e);
        auto fed = crate::lower::types::out_ty_of(lx, crate::lower::types::peel(crate::lower::types::peel(crate::lower::type_at(lx, e.span))));
        auto r2 = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::node_::EvRef> _v;
            if (prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t)) {
                auto&& m21441_0_0 = prism_rtl::as<crate::lower::model::OutTy::OutEvent>(t).a0;
                if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(m21441_0_0)) {
                    _v.set(fed == crate::lower::model::OutTy(crate::lower::model::OutTy::OutError{})
                        ? err_pipe(r)
                        : r);
                    goto _done;
                }
            }
            if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t)) {
                _v.set(fed == crate::lower::model::OutTy(crate::lower::model::OutTy::OutError{})
                    ? err_pipe(r)
                    : r);
                goto _done;
            }
            {
                _v.set(r);
                goto _done;
            }
        _done:
            _v.take();
        });
        return std::tuple{crate::lower::node_::connect(wx2, r2, crate::lower::node_::Sk(crate::lower::node_::Sk::SkNode{er.node_})), benv};
    }
    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m))) {
        auto&& t = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a2;
        auto rs = crate::lower::snake(pat_text(p_));
        auto [ex, reads] = crate::lower::node_::dynamics::dynamic_expr(wx, menv, e);
        auto cached = (len(reads) > Nat(0u)) && fold(crate::lower::node_::finish::reads_all(wx.dyn_reads, reads), true, [&](const bool& ok_, const crate::lower::node_::Read& r) { return ok_ && crate::lower::node_::finish::is_own_read(r); });
        auto tail = cached
            ? crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(rs, "_cache")})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array<crate::lower::model::Pa>{}, prism_rtl::rc(ex)})})})
            : ex;
        auto getter = crate::lower::model::MethDef{.name = rs, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = t, .body = Array<crate::lower::model::Do>{}, .tail = tail, .doc = prism_rtl::cat("`", pat_text(p_), "`")};
        auto wx1 = cached
            ? ({
            crate::lower::node_::Wx this_ = crate::lower::node_::add_field(wx, prism_rtl::cat(rs, "_cache"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Cache"), Array(std::vector{t})}), prism_rtl::cat("`", pat_text(p_), "`, cached"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Cache::new"), Array<crate::lower::model::Ex>{}}));
            this_.let_caches = crate::prelude::push(this_.let_caches, rs);
            this_.taken = crate::prelude::push(this_.taken, prism_rtl::cat(rs, "_cache"));
            this_;
        })
            : wx;
        auto wx2 = ({
            crate::lower::node_::Wx this_ = wx1;
            this_.getters = crate::prelude::push(this_.getters, getter);
            this_.dyn_reads = insert(this_.dyn_reads, rs, reads);
            this_;
        });
        return all_inited(wx2, reads) && names_inited(benv, e)
            ? ({
            auto wx3 = ({
                crate::lower::node_::Wx this_ = wx2;
                this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat(rs, "_init")})), t}), crate::lower::types::own(crate::lower::expr::value_of(lx, init_env(benv), e))}));
                this_.inited = crate::prelude::push(this_.inited, rs);
                this_;
            });
            std::tuple{wx3, crate::lower::types::bind(benv, prism_rtl::cat(pat_text(p_), "#init"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat(rs, "_init")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t}))};
        })
            : std::tuple{wx2, benv};
    }
    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
        auto&& rs = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
        auto&& t = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
        auto insts_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>> _v;
            auto&& _m = p_.kind;
            if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                _v.set(many_instances(lx, n.span));
                goto _done;
            }
            {
                _v.set(std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        if (prism_rtl::is_some(insts_opt)) {
            auto&& insts = prism_rtl::some_of(insts_opt);
            auto&& _m = p_.kind;
            if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                auto nkey = crate::check::env::sname_key(n);
                auto wxn = run_to_end(fold_job(crate::check::errors::range0(len(insts)), wx, ({
                    auto lx_1 = lx;
                    auto insts_2 = insts;
                    auto nkey_3 = nkey;
                    auto menv_4 = menv;
                    auto benv_5 = benv;
                    auto e_6 = e;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::node_::Wx>(std::tuple<crate::lower::node_::Wx, Nat>)>>(prism_rtl::rc([=](std::tuple<crate::lower::node_::Wx, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto lx_1_7 = lx_1;
                        auto insts_2_7 = insts_2;
                        auto nkey_3_7 = nkey_3;
                        auto menv_4_7 = menv_4;
                        auto benv_5_7 = benv_5;
                        auto e_6_7 = e_6;
                        entered(once_job([=]() {
                        return ({
                            auto w = p0;
                            auto k = p1;
                            ({
                            auto lxk = crate::lower::expr::at_instance(lx_1_7, or_(index(insts_2_7, k), std::tuple{Array<std::tuple<Text, crate::check::types::Ty>>{}, Array<std::tuple<Text, crate::check::types::Col>>{}}));
                            auto bkey = k == Nat(0u) ? nkey_3_7 : prism_rtl::cat(nkey_3_7, "#inst", k);
                            ({
                            auto&& _m = crate::prelude::get(menv_4_7->names, bkey);
                            prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)) ? ({
                            auto&& rk = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                            auto&& tk = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                            call_then(crate::lower::expr::start_value_of(lxk, benv_5_7, e_6_7), [=](crate::lower::types::Vl value_of_24102) { return prism_rtl::finished(widget_let_field(w, crate::lower::types::place_stem(rk), tk, crate::lower::types::own(value_of_24102), prism_rtl::cat("`", nkey_3_7, "` at its instantiation ", k))); });
                        })
                            : prism_rtl::finished(({
                            crate::lower::node_::Wx this_ = w;
                            this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(prism_rtl::cat("`", nkey_3_7, "` at its instantiation ", k, ", which has no binding")));
                            this_;
                        }));
                        });
                        });
                        });
                    }));
                    });
                })));
                })));
                return std::tuple{wxn, benv};
            }
            {
                return std::tuple{wx, benv};
            }
        }
        if (prism_rtl::is_none(insts_opt)) {
            auto lxw = ({
                __label__ _done;
                prism_rtl::Slot<crate::lower::Lx> _v;
                auto&& _m = p_.kind;
                if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                    auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                    _v.set(crate::lower::expr::widget_let_lx(lx, n.span));
                    goto _done;
                }
                {
                    _v.set(lx);
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto v_ = crate::lower::types::own(crate::lower::expr::value_of(lxw, benv, e));
            return std::tuple{widget_let_field(wx, crate::lower::types::place_stem(rs), t, v_, prism_rtl::cat("`", pat_text(p_), "`")), benv};
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        return std::tuple{wx, benv};
    }
}


prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env>> LetLine::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& p_ = this->p_;
    const auto& e = this->e;
    auto lx = wx.lx;
    return ({
        auto&& _m = binding_of(menv, p_);
        prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(_m)) ? ({
        auto&& er = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(_m)).a0;
        auto&& t = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(_m)).a1;
        ({
        auto benv_1 = benv;
        auto e_2 = e;
        auto menv_3 = menv;
        auto wx_4 = wx;
        call_then(crate::lower::node_::dynamics::start_event_ref(wx_4, menv_3, e_2), [=](std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> event_ref_21331) {
        return ({
            auto [r, wx2] = event_ref_21331;
            call_then(crate::lower::types::start_out_ty_of(lx, crate::lower::types::peel(crate::lower::types::peel(crate::lower::type_at(lx, e_2.span)))), [=](crate::lower::model::OutTy out_ty_of_21374) {
            return ({
                auto fed = out_ty_of_21374;
                auto r2 = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::lower::node_::EvRef> _v;
                    if (prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t)) {
                        auto&& m21441_0_0 = prism_rtl::as<crate::lower::model::OutTy::OutEvent>(t).a0;
                        if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(m21441_0_0)) {
                            _v.set(fed == crate::lower::model::OutTy(crate::lower::model::OutTy::OutError{})
                                ? err_pipe(r)
                                : r);
                            goto _done;
                        }
                    }
                    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t)) {
                        _v.set(fed == crate::lower::model::OutTy(crate::lower::model::OutTy::OutError{})
                            ? err_pipe(r)
                            : r);
                        goto _done;
                    }
                    {
                        _v.set(r);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                (prism_rtl::finished(std::tuple{crate::lower::node_::connect(wx2, r2, crate::lower::node_::Sk(crate::lower::node_::Sk::SkNode{er.node_})), benv_1}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)) ? ({
        auto&& t = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a2;
        ({
        auto rs = crate::lower::snake(pat_text(p_));
        auto benv_1 = benv;
        auto e_2 = e;
        auto menv_3 = menv;
        auto p__4 = p_;
        auto wx_5 = wx;
        call_then(crate::lower::node_::dynamics::start_dynamic_expr(wx_5, menv_3, e_2), [=](std::tuple<crate::lower::model::Ex, Array<crate::lower::node_::Read>> dynamic_expr_21794) {
        return ({
            auto [ex, reads] = dynamic_expr_21794;
            auto cached = (len(reads) > Nat(0u)) && fold(crate::lower::node_::finish::reads_all(wx_5.dyn_reads, reads), true, [&](const bool& ok_, const crate::lower::node_::Read& r) { return ok_ && crate::lower::node_::finish::is_own_read(r); });
            auto tail = cached
                ? crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(rs, "_cache")})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array<crate::lower::model::Pa>{}, prism_rtl::rc(ex)})})})
                : ex;
            auto getter = crate::lower::model::MethDef{.name = rs, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = t, .body = Array<crate::lower::model::Do>{}, .tail = tail, .doc = prism_rtl::cat("`", pat_text(p__4), "`")};
            auto wx1 = cached
                ? ({
                crate::lower::node_::Wx this_ = crate::lower::node_::add_field(wx_5, prism_rtl::cat(rs, "_cache"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Cache"), Array(std::vector{t})}), prism_rtl::cat("`", pat_text(p__4), "`, cached"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Cache::new"), Array<crate::lower::model::Ex>{}}));
                this_.let_caches = crate::prelude::push(this_.let_caches, rs);
                this_.taken = crate::prelude::push(this_.taken, prism_rtl::cat(rs, "_cache"));
                this_;
            })
                : wx_5;
            auto wx2 = ({
                crate::lower::node_::Wx this_ = wx1;
                this_.getters = crate::prelude::push(this_.getters, getter);
                this_.dyn_reads = insert(this_.dyn_reads, rs, reads);
                this_;
            });
            all_inited(wx2, reads) && names_inited(benv_1, e_2)
            ? ({
            auto wx3 = ({
                crate::lower::node_::Wx this_ = wx2;
                this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat(rs, "_init")})), t}), crate::lower::types::own(crate::lower::expr::value_of(lx, init_env(benv_1), e_2))}));
                this_.inited = crate::prelude::push(this_.inited, rs);
                this_;
            });
            (prism_rtl::finished(std::tuple{wx3, crate::lower::types::bind(benv_1, prism_rtl::cat(pat_text(p__4), "#init"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat(rs, "_init")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t}))}));
        })
            : prism_rtl::finished(std::tuple{wx2, benv_1});
        });
    });
    });
    })
        : prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)) ? ({
        auto&& rs = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
        auto&& t = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
        ({
        auto insts_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>> _v;
            auto&& _m = p_.kind;
            if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                _v.set(many_instances(lx, n.span));
                goto _done;
            }
            {
                _v.set(std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        ({
        prism_rtl::is_some(insts_opt) ? ({
        auto&& insts = prism_rtl::some_of(insts_opt);
        ({
        auto&& _m = p_.kind;
        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        ({
        auto nkey = crate::check::env::sname_key(n);
        auto benv_1 = benv;
        auto e_2 = e;
        auto insts_3 = insts;
        auto menv_4 = menv;
        auto wx_5 = wx;
        call_value(fold_job(crate::check::errors::range0(len(insts_3)), wx_5, ({
        auto lx_6 = lx;
        auto insts_3_7 = insts_3;
        auto nkey_7 = nkey;
        auto menv_4_8 = menv_4;
        auto benv_1_8 = benv_1;
        auto e_2_8 = e_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::node_::Wx>(std::tuple<crate::lower::node_::Wx, Nat>)>>(prism_rtl::rc([=](std::tuple<crate::lower::node_::Wx, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_6_8 = lx_6;
            auto insts_3_7_8 = insts_3_7;
            auto nkey_7_8 = nkey_7;
            auto menv_4_8_8 = menv_4_8;
            auto benv_1_8_8 = benv_1_8;
            auto e_2_8_8 = e_2_8;
            entered(once_job([=]() {
            return ({
                auto w = p0;
                auto k = p1;
                ({
                auto lxk = crate::lower::expr::at_instance(lx_6_8, or_(index(insts_3_7_8, k), std::tuple{Array<std::tuple<Text, crate::check::types::Ty>>{}, Array<std::tuple<Text, crate::check::types::Col>>{}}));
                auto bkey = k == Nat(0u) ? nkey_7_8 : prism_rtl::cat(nkey_7_8, "#inst", k);
                ({
                auto&& _m = crate::prelude::get(menv_4_8_8->names, bkey);
                prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)) ? ({
                auto&& rk = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& tk = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                call_then(crate::lower::expr::start_value_of(lxk, benv_1_8_8, e_2_8_8), [=](crate::lower::types::Vl value_of_24102) { return prism_rtl::finished(widget_let_field(w, crate::lower::types::place_stem(rk), tk, crate::lower::types::own(value_of_24102), prism_rtl::cat("`", nkey_7_8, "` at its instantiation ", k))); });
            })
                : prism_rtl::finished(({
                crate::lower::node_::Wx this_ = w;
                this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(prism_rtl::cat("`", nkey_7_8, "` at its instantiation ", k, ", which has no binding")));
                this_;
            }));
            });
            });
            });
        }));
        });
    })));
    })), [=](crate::lower::node_::Wx fold_23746) {
        return ({
            auto wxn = fold_23746;
            (prism_rtl::finished(std::tuple{wxn, benv_1}));
        });
    });
    });
    })
        : prism_rtl::finished(std::tuple{wx, benv});
    });
    })
        : prism_rtl::is_none(insts_opt) ? ({
        auto lxw = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::Lx> _v;
            auto&& _m = p_.kind;
            if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                _v.set(crate::lower::expr::widget_let_lx(lx, n.span));
                goto _done;
            }
            {
                _v.set(lx);
                goto _done;
            }
        _done:
            _v.take();
        });
        auto benv_1 = benv;
        auto e_2 = e;
        auto p__3 = p_;
        auto wx_4 = wx;
        call_then(crate::lower::expr::start_value_of(lxw, benv_1, e_2), [=](crate::lower::types::Vl value_of_24622) {
        return ({
            auto v_ = crate::lower::types::own(value_of_24622);
            (prism_rtl::finished(std::tuple{widget_let_field(wx_4, crate::lower::types::place_stem(rs), t, v_, prism_rtl::cat("`", pat_text(p__3), "`")), benv_1}));
        });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : prism_rtl::finished(std::tuple{wx, benv});
    });
}


/// `Start LetLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env>> start_let_line(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, crate::syntax::Pattern_ p_, crate::syntax::Expr e) {
    return prism_rtl::make_rc<LetLine>(wx, benv, menv, p_, e);
}


/// WidgetLetField: fn Wx, Text, OutTy, Ex, Text -> Wx
crate::lower::node_::Wx widget_let_field(const crate::lower::node_::Wx& wx, const Text& f, const crate::lower::model::OutTy& t, const crate::lower::model::Ex& v_, const Text& doc) {
    crate::lower::node_::Wx this_ = wx;
    this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{f}), v_}));
    this_.fields = crate::prelude::push(this_.fields, std::tuple{f, t, doc});
    this_.inits = crate::prelude::push(this_.inits, std::tuple{f, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{f}))})});
    return this_;
}


/// ErrPipe: fn EvRef -> EvRef
crate::lower::node_::EvRef err_pipe(const crate::lower::node_::EvRef& r) {
    return crate::lower::node_::EvRef{.node_ = r.node_, .owner = r.owner, .pipe = ({
        auto r_1 = r;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>)>>(prism_rtl::rc([=](std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto r_1_2 = r_1;
            entered(once_job([=]() {
            return ({
                auto x = p0;
                auto k_fn = p1;
                r_1_2.pipe(std::tuple{x, ({
                auto k_fn_2 = k_fn;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>(prism_rtl::rc([=](crate::lower::model::Ex p0) {
                return ({
                    auto k_fn_2_3 = k_fn_2;
                    entered(once_job([=]() {
                    return ({
                        auto y = p0;
                        k_fn_2_3(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{y})}))->cycle();
                    });
                }));
                });
            })));
            })})->cycle();
            });
        }));
        });
    })));
    })};
}


/// OwnAs: fn OutTy, Vl -> Ex
crate::lower::model::Ex own_as(const crate::lower::model::OutTy& t, const crate::lower::types::Vl& v_) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t)) {
        return crate::lower::types::value_ty(v_) == crate::lower::model::OutTy(crate::lower::model::OutTy::OutError{})
            ? crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{crate::lower::types::own(v_)})})
            : crate::lower::types::own(v_);
    }
    {
        return crate::lower::types::own(v_);
    }
}


/// BindRes: fn Wx, Env, Pattern, Wres -> Wx
crate::lower::node_::Wx bind_res(const crate::lower::node_::Wx& wx2, const crate::lower::types::Env& menv, const crate::syntax::Pattern_& p_, const crate::lower::node_::Wres& res) {
    auto&& _m = binding_of(menv, p_);
    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(_m))) {
        auto&& er = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(_m)).a0;
        if (prism_rtl::is<crate::lower::node_::Wres::WrEv>(res)) {
            auto&& r = prism_rtl::as<crate::lower::node_::Wres::WrEv>(res).a0;
            return er.owner != wx2.node_
                ? crate::lower::node_::crossed(wx2, prism_rtl::cat("the bound event of node `", er.owner, "` (its graph node ", er.node_, ")"))
                : r.node_ == er.node_
                ? wx2
                : crate::lower::node_::connect(wx2, r, crate::lower::node_::Sk(crate::lower::node_::Sk::SkNode{er.node_}));
        }
        {
            return wx2;
        }
    }
    {
        return wx2;
    }
}


/// BuildLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> build_line(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const crate::syntax::Expr& e, const std::optional<crate::lower::types::Bn>& bound_opt) {
    auto lx = wx.lx;
    auto full = crate::lower::type_at(lx, e.span);
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return build_line(wx, benv, menv, x, bound_opt);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m)) {
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EWidgetBlock>(_m).a0;
        return crate::lower::node_::static_::inline_block(wx, benv, menv, b, lx);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFor>(_m)) {
        auto&& binders_opt = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
        auto&& source = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
        return crate::lower::node_::keyed::for_line(wx, benv, menv, binders_opt, source, body, e, bound_opt);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ERebuild>(_m)) {
        auto&& scrut = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a0;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a1;
        return crate::lower::node_::switch_::rebuild_line(wx, benv, menv, scrut, body, e, bound_opt);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2)) {
        auto&& m26399_4_0 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
        if (prism_rtl::is<crate::syntax::Cond::CondExpr>(m26399_4_0)) {
            auto&& c = prism_rtl::as<crate::syntax::Cond::CondExpr>(m26399_4_0).a0;
            return crate::lower::functions::if_gen_line(wx, menv, c, then_b, else_b, e);
        }
    }
    {
        auto&& _m = crate::lower::types::peel(full);
        if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
            return crate::lower::node_::elements::element_line(wx, benv, menv, e, bound_opt);
        }
        if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
            return crate::lower::node_::static_::widget_line(wx, benv, menv, e, bound_opt);
        }
        {
            auto wx2 = ({
                crate::lower::node_::Wx this_ = wx;
                this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("a building line this back end does not lower yet")));
                this_;
            });
            return std::tuple{wx2, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
        }
    }
}


prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> BuildLine::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& e = this->e;
    const auto& bound_opt = this->bound_opt;
    auto lx = wx.lx;
    auto full = crate::lower::type_at(lx, e.span);
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(BuildLine(wx, benv, menv, x, bound_opt)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m) ? ({
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EWidgetBlock>(_m).a0;
        prism_rtl::more(prism_rtl::rc(crate::lower::node_::static_::InlineBlock(wx, benv, menv, b, lx)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EFor>(_m) ? ({
        auto&& binders_opt = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
        auto&& source = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
        prism_rtl::more(prism_rtl::rc(crate::lower::node_::keyed::ForLine(wx, benv, menv, binders_opt, source, body, e, bound_opt)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ERebuild>(_m) ? ({
        auto&& scrut = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a0;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a1;
        prism_rtl::more(prism_rtl::rc(crate::lower::node_::switch_::RebuildLine(wx, benv, menv, scrut, body, e, bound_opt)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2) && ({
        auto&& m26399_4_0 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
        prism_rtl::is<crate::syntax::Cond::CondExpr>(m26399_4_0);
    }) ? ({
        auto&& m26399_4_0 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
        auto&& c = prism_rtl::as<crate::syntax::Cond::CondExpr>(m26399_4_0).a0;
        prism_rtl::more(prism_rtl::rc(crate::lower::functions::IfGenLine(wx, menv, c, then_b, else_b, e)));
    })
        : ({
        auto&& _m = crate::lower::types::peel(full);
        prism_rtl::is<crate::check::types::Ty::TyElem>(_m) ? prism_rtl::more(prism_rtl::rc(crate::lower::node_::elements::ElementLine(wx, benv, menv, e, bound_opt)))
        : prism_rtl::is<crate::check::types::Ty::TyAt>(_m) ? prism_rtl::more(prism_rtl::rc(crate::lower::node_::static_::WidgetLine(wx, benv, menv, e, bound_opt)))
        : ({
        auto wx2 = ({
            crate::lower::node_::Wx this_ = wx;
            this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("a building line this back end does not lower yet")));
            this_;
        });
        (prism_rtl::finished(std::tuple{wx2, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})}));
    });
    });
    });
}


/// `Start BuildLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> start_build_line(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, crate::syntax::Expr e, std::optional<crate::lower::types::Bn> bound_opt) {
    return prism_rtl::make_rc<BuildLine>(wx, benv, menv, e, bound_opt);
}

}  // namespace crate::lower::node_::def
