// The module `CheckPasses`, from `target/bootstrap/cpp-src/prismc/check-passes.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include <check_passes/module.hpp>
#include <ast/module.hpp>
#include <check_env/module.hpp>
#include <typed/module.hpp>
#include <check_blocks/module.hpp>
#include <check_errors/module.hpp>
#include <check_expr/module.hpp>
#include <check_types/module.hpp>
#include <lexer/module.hpp>
#include <check_env/generic.hpp>
#include <lexer/generic.hpp>

namespace crate::check_passes {

prism_rtl::Turn<Array<Kid>> CallKids::cycle() const {
    const auto& c = this->c;
    const auto& args = this->args;
    const auto& m = this->m;
    auto callee = ({
        __label__ _done;
        prism_rtl::Slot<Array<Kid>> _v;
        auto&& _m = callee_name(c);
        if (prism_rtl::is_some(_m)) {
            _v.set(Array<Kid>{});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array(std::vector{Kid(Kid::KidExpr{c, m})}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ({
        auto&& _m = traversal_of(m, c, args);
        prism_rtl::is_none(_m) ? ({
        auto&& _m = acc_callee(m, c, args);
        prism_rtl::is_some(_m) ? ({
        auto&& cn = prism_rtl::some_of(_m);
        ({
        auto args_1 = args;
        auto m_2 = m;
        call_value(fold_job(crate::check_errors::range0(len(args_1)), Array<Kid>{}, ({
        auto m_2_3 = m_2;
        auto cn_3 = cn;
        auto args_1_4 = args_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Kid>>(std::tuple<Array<Kid>, Nat>)>>(prism_rtl::rc([=](std::tuple<Array<Kid>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_2_3_4 = m_2_3;
            auto cn_3_4 = cn_3;
            auto args_1_4_4 = args_1_4;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto i = p1;
                call_then(start_acc_kids(m_2_3_4, cn_3_4, args_1_4_4, i), [=](Array<Kid> acc_kids_88105) { return prism_rtl::finished(append(acc, acc_kids_88105)); });
            });
        }));
        });
    })));
    })), [=](Array<Kid> fold_88050) { return prism_rtl::finished(append(callee, fold_88050)); });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(append(callee, exprs_kids(each(args, [&](const crate::ast::Arg& a) { return a->value; }), m)))
        : throw prism_rtl::Panic("no arm matched");
    })
        : prism_rtl::is_some(_m) ? ({
        auto&& coll = std::get<0>(prism_rtl::some_of(_m));
        auto&& step_ = std::get<1>(prism_rtl::some_of(_m));
        auto&& at_ = std::get<2>(prism_rtl::some_of(_m));
        ({
        auto others = fold(crate::check_errors::range0(len(args)), callee, [&](const Array<Kid>& acc, const Nat& i) {
            return i == (at_ + Nat(1u))
                ? acc
                : ({
                __label__ _done;
                prism_rtl::Slot<Array<Kid>> _v;
                auto&& _m = index(args, i);
                if (prism_rtl::is_some(_m)) {
                    auto&& a = prism_rtl::some_of(_m);
                    _v.set(prelude::push(acc, Kid(Kid::KidExpr{a->value, m})));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(acc);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        });
        ({
        auto&& _m = step_.kind;
        prism_rtl::is<crate::ast::ExprKind::ELambda>(_m) && prism_rtl::is_some(prism_rtl::as<crate::ast::ExprKind::ELambda>(_m).a0) ? ({
        auto&& ps = prism_rtl::some_of(prism_rtl::as<crate::ast::ExprKind::ELambda>(_m).a0);
        auto&& body = prism_rtl::as<crate::ast::ExprKind::ELambda>(_m).a1;
        ({
        auto body_1 = body;
        auto m_2 = m;
        auto ps_3 = ps;
        call_then(start_step_rels(m_2, coll, ps_3, at_), [=](Map<Text, Rel> step_rels_88518) { return prism_rtl::finished(prelude::push(others, lambda_kid(body_1, step_rels_88518))); });
    });
    })
        : prism_rtl::is<crate::ast::ExprKind::EName>(_m) ? prism_rtl::finished(others)
        : prism_rtl::finished(prelude::push(others, Kid(Kid::KidExpr{step_, m})));
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CallKids, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Kid>> start_call_kids(crate::ast::Expr c, Array<crate::ast::Arg> args, Map<Text, Rel> m) {
    return prism_rtl::make_rc<CallKids>(c, args, m);
}


/// Later: fn (Text ==> Rel) -> (Text ==> Rel)
Map<Text, Rel> later(const Map<Text, Rel>& m) {
    return insert(m, Text::lit("lam:"), no_rel());
}


/// ?AccCallee: fn (Text ==> Rel), Expr, [Arg] -> ?Text
std::optional<Text> acc_callee(const Map<Text, Rel>& m, const crate::ast::Expr& c, const Array<crate::ast::Arg>& args) {
    auto&& _m = callee_name(c);
    if (prism_rtl::is_some(_m)) {
        auto&& cn = prism_rtl::some_of(_m);
        return is_local(m, cn)
            ? std::optional<Text>{}
            : !fold(args, true, [&](const bool& ok, const crate::ast::Arg& a) { return ok && (a.name == std::optional<crate::ast::Ident>{}); })
            ? std::optional<Text>{}
            : fold(crate::check_errors::range0(len(args)), false, [&](const bool& seen, const Nat& i) { return seen || crate::check_env::has_key(m, prism_rtl::cat("acc:", cn, ":", i)); })
            ? std::optional(cn)
            : std::optional<Text>{};
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// AccKids: unbounded fn (Text ==> Rel), Text, [Arg], Nat -> [Kid]
Array<Kid> acc_kids(const Map<Text, Rel>& m, const Text& cn, const Array<crate::ast::Arg>& args, const Nat& i) {
    auto a = or_(index(args, i), dummy_arg());
    return !crate::check_env::has_key(m, prism_rtl::cat("acc:", cn, ":", i))
        ? Array(std::vector{Kid(Kid::KidExpr{a->value, m})})
        : ({
        __label__ _done;
        prism_rtl::Slot<Array<Kid>> _v;
        auto&& _m = a->value.kind;
        if (prism_rtl::is<crate::ast::ExprKind::ELambda>(_m)) {
            auto&& ps_opt = prism_rtl::as<crate::ast::ExprKind::ELambda>(_m).a0;
            auto&& body = prism_rtl::as<crate::ast::ExprKind::ELambda>(_m).a1;
            _v.set(Array(std::vector{lambda_kid(body, acc_lambda_rels(m, cn, i, or_(ps_opt, Array<crate::ast::Pattern_>{}), args))}));
            goto _done;
        }
        if (prism_rtl::is<crate::ast::ExprKind::EName>(_m)) {
            _v.set(Array<Kid>{});
            goto _done;
        }
        {
            _v.set(Array(std::vector{Kid(Kid::KidExpr{a->value, m})}));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Array<Kid>> AccKids::cycle() const {
    const auto& m = this->m;
    const auto& cn = this->cn;
    const auto& args = this->args;
    const auto& i = this->i;
    auto a = or_(index(args, i), dummy_arg());
    return !crate::check_env::has_key(m, prism_rtl::cat("acc:", cn, ":", i))
        ? prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{a->value, m})}))
        : ({
        auto&& _m = a->value.kind;
        prism_rtl::is<crate::ast::ExprKind::ELambda>(_m) ? ({
        auto&& ps_opt = prism_rtl::as<crate::ast::ExprKind::ELambda>(_m).a0;
        auto&& body = prism_rtl::as<crate::ast::ExprKind::ELambda>(_m).a1;
        prism_rtl::finished(Array(std::vector{lambda_kid(body, acc_lambda_rels(m, cn, i, or_(ps_opt, Array<crate::ast::Pattern_>{}), args))}));
    })
        : prism_rtl::is<crate::ast::ExprKind::EName>(_m) ? prism_rtl::finished(Array<Kid>{})
        : prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{a->value, m})}));
    });
}


/// `Start AccKids, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Kid>> start_acc_kids(Map<Text, Rel> m, Text cn, Array<crate::ast::Arg> args, Nat i) {
    return prism_rtl::make_rc<AccKids>(m, cn, args, i);
}


/// AccLambdaRels: unbounded fn (Text ==> Rel), Text, Nat, [Pattern], [Arg] -> (Text ==> Rel)
Map<Text, Rel> acc_lambda_rels(const Map<Text, Rel>& m, const Text& cn, const Nat& j, const Array<crate::ast::Pattern_>& ps, const Array<crate::ast::Arg>& args) {
    auto h = hide(m, patterns_names(ps));
    return run_to_end(fold_job(crate::check_errors::range0(len(ps)), h, ({
        auto m_1 = m;
        auto cn_2 = cn;
        auto j_3 = j;
        auto ps_4 = ps;
        auto args_5 = args;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Rel>>(std::tuple<Map<Text, Rel>, Nat>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Rel>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_1_6 = m_1;
            auto cn_2_6 = cn_2;
            auto j_3_6 = j_3;
            auto ps_4_6 = ps_4;
            auto args_5_6 = args_5;
            entered(once_job([=]() {
            return ({
                auto m2 = p0;
                auto q = p1;
                ({
                auto&& _m = std::tuple{prelude::get(m_1_6, prism_rtl::cat("sum:", cn_2_6, ":", j_3_6, ":", q)), index(ps_4_6, q)};
                prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m)) ? ({
                auto&& s = prism_rtl::some_of(std::get<0>(_m));
                auto&& p_ = prism_rtl::some_of(std::get<1>(_m));
                s.param == top_param()
                ? prism_rtl::finished(m2)
                : ({
                auto&& _m = index(args_5_6, s.param);
                prism_rtl::is_some(_m) ? ({
                auto&& a = prism_rtl::some_of(_m);
                call_then(start_rel_of(m_1_6, a->value), [=](std::optional<Rel> rel_of_90506) {
                return ({
                    prism_rtl::is_some(rel_of_90506) ? ({
                    auto&& r = prism_rtl::some_of(rel_of_90506);
                    ({
                    auto&& _m = p_.kind;
                    prism_rtl::is<crate::ast::PatternKind::PName>(_m) ? ({
                    auto&& n = prism_rtl::as<crate::ast::PatternKind::PName>(_m).a0;
                    prism_rtl::finished(insert(m2, crate::check_env::sname_key(n), Rel{.param = r.param, .strict = r.strict || s.strict}));
                })
                    : call_then(crate::check_env::start_pattern_names(p_), [=](Array<Text> pattern_names_90701) { return prism_rtl::finished(fold(pattern_names_90701, m2, [&](const Map<Text, Rel>& m3, const Text& n) { return insert(m3, n, Rel{.param = r.param, .strict = true}); })); });
                });
                })
                    : prism_rtl::is_none(rel_of_90506) ? prism_rtl::finished(m2)
                    : throw prism_rtl::Panic("no arm matched");
                });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(m2)
                : throw prism_rtl::Panic("no arm matched");
            });
            })
                : prism_rtl::finished(m2);
            });
            });
        }));
        });
    }));
    })));
}


/// let topParam
Nat top_param() {
    return Nat(9999u);
}


/// TemplateKids: unbounded fn [TemplatePart], (Text ==> Rel) -> [Kid]
Array<Kid> template_kids(const Array<crate::ast::TemplatePart>& parts, const Map<Text, Rel>& m) {
    return fold(parts, Array<Kid>{}, [&](const Array<Kid>& acc, const crate::ast::TemplatePart& p_) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Kid>> _v;
            if (prism_rtl::is<crate::ast::TemplatePart::TpPlaceholder>(p_)) {
                auto&& x = prism_rtl::as<crate::ast::TemplatePart::TpPlaceholder>(p_).a0;
                _v.set(prelude::push(acc, Kid(Kid::KidExpr{x, m})));
                goto _done;
            }
            if (prism_rtl::is<crate::ast::TemplatePart::TpBlock>(p_)) {
                auto&& b = prism_rtl::as<crate::ast::TemplatePart::TpBlock>(p_).a0;
                _v.set(prelude::push(acc, Kid(Kid::KidStmts{b.stmts, m})));
                goto _done;
            }
            if (prism_rtl::is<crate::ast::TemplatePart::TpCall>(p_)) {
                auto&& n = prism_rtl::as<crate::ast::TemplatePart::TpCall>(p_).a0;
                auto&& args = prism_rtl::as<crate::ast::TemplatePart::TpCall>(p_).a1;
                auto&& ps_opt = prism_rtl::as<crate::ast::TemplatePart::TpCall>(p_).a2;
                auto&& span = prism_rtl::as<crate::ast::TemplatePart::TpCall>(p_).a3;
                _v.set(prelude::push(acc, Kid(Kid::KidExpr{template_call_expr(n, args, ps_opt, span), m})));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Array<Kid>> TemplateKids::cycle() const {
    const auto& parts = this->parts;
    const auto& m = this->m;
    return prism_rtl::finished(fold(parts, Array<Kid>{}, [&](const Array<Kid>& acc, const crate::ast::TemplatePart& p_) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Kid>> _v;
            if (prism_rtl::is<crate::ast::TemplatePart::TpPlaceholder>(p_)) {
                auto&& x = prism_rtl::as<crate::ast::TemplatePart::TpPlaceholder>(p_).a0;
                _v.set(prelude::push(acc, Kid(Kid::KidExpr{x, m})));
                goto _done;
            }
            if (prism_rtl::is<crate::ast::TemplatePart::TpBlock>(p_)) {
                auto&& b = prism_rtl::as<crate::ast::TemplatePart::TpBlock>(p_).a0;
                _v.set(prelude::push(acc, Kid(Kid::KidStmts{b.stmts, m})));
                goto _done;
            }
            if (prism_rtl::is<crate::ast::TemplatePart::TpCall>(p_)) {
                auto&& n = prism_rtl::as<crate::ast::TemplatePart::TpCall>(p_).a0;
                auto&& args = prism_rtl::as<crate::ast::TemplatePart::TpCall>(p_).a1;
                auto&& ps_opt = prism_rtl::as<crate::ast::TemplatePart::TpCall>(p_).a2;
                auto&& span = prism_rtl::as<crate::ast::TemplatePart::TpCall>(p_).a3;
                _v.set(prelude::push(acc, Kid(Kid::KidExpr{template_call_expr(n, args, ps_opt, span), m})));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    }));
}


/// `Start TemplateKids, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Kid>> start_template_kids(Array<crate::ast::TemplatePart> parts, Map<Text, Rel> m) {
    return prism_rtl::make_rc<TemplateKids>(parts, m);
}


/// TemplateCallExpr: fn SName, [Arg], ?[TemplatePart], Range -> Expr
crate::ast::Expr template_call_expr(const crate::ast::SName& n, const Array<crate::ast::Arg>& args, const std::optional<Array<crate::ast::TemplatePart>>& ps_opt, const crate::ast::Range& span) {
    auto body_1 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::ast::Arg>> _v;
        if (prism_rtl::is_some(ps_opt)) {
            auto&& ps = prism_rtl::some_of(ps_opt);
            _v.set(Array(std::vector{crate::ast::Arg{.name = std::optional(crate::ast::Ident{.name = Text::lit("#body"), .span = span}), .value = crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ETemplate{crate::ast::Template{.keyword = Text::lit("InlineText"), .lang = Text::lit(""), .delims = Text::lit("double"), .parts = ps, .span = span}})), .span = span}, .span = span}}));
            goto _done;
        }
        if (prism_rtl::is_none(ps_opt)) {
            _v.set(Array<crate::ast::Arg>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ECall{prism_rtl::rc(crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EName{n})), .span = n.span}), append(args, body_1), false, false})), .span = span};
}


/// ArgOf: fn Expr -> Arg
crate::ast::Arg arg_of(const crate::ast::Expr& x) {
    return crate::ast::Arg{.name = std::optional<crate::ast::Ident>{}, .value = x, .span = x.span};
}


/// ExprsKids: fn [Expr], (Text ==> Rel) -> [Kid]
Array<Kid> exprs_kids(const Array<crate::ast::Expr>& xs, const Map<Text, Rel>& m) {
    return each(xs, [&](const crate::ast::Expr& x) { return Kid(Kid::KidExpr{x, m}); });
}


/// OptKids: fn ?Expr, (Text ==> Rel) -> [Kid]
Array<Kid> opt_kids(const std::optional<crate::ast::Expr>& opt0, const Map<Text, Rel>& map1) {
    auto&& _m = std::tuple{opt0, map1};
    if (prism_rtl::is_some(std::get<0>(_m))) {
        auto&& x = prism_rtl::some_of(std::get<0>(_m));
        auto&& m = std::get<1>(_m);
        return Array(std::vector{Kid(Kid::KidExpr{x, m})});
    }
    if (prism_rtl::is_none(std::get<0>(_m))) {
        return Array<Kid>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// LambdaKid: fn LambdaBody, (Text ==> Rel) -> Kid
Kid lambda_kid(const crate::ast::LambdaBody& lambda_body0, const Map<Text, Rel>& m) {
    if (prism_rtl::is<crate::ast::LambdaBody::LbExpr>(lambda_body0)) {
        auto&& x = prism_rtl::as<crate::ast::LambdaBody::LbExpr>(lambda_body0).a0;
        return Kid(Kid::KidExpr{x, m});
    }
    if (prism_rtl::is<crate::ast::LambdaBody::LbBlock>(lambda_body0)) {
        auto&& b = prism_rtl::as<crate::ast::LambdaBody::LbBlock>(lambda_body0).a0;
        return Kid(Kid::KidStmts{b.stmts, m});
    }
    prism_rtl::unreachable("no arm matched");
}


/// BodyKid: fn FnBody, (Text ==> Rel) -> Kid
Kid body_kid(const crate::ast::FnBody& fn_body0, const Map<Text, Rel>& m) {
    if (prism_rtl::is<crate::ast::FnBody::BodyExpr>(fn_body0)) {
        auto&& x = prism_rtl::as<crate::ast::FnBody::BodyExpr>(fn_body0).a0;
        return Kid(Kid::KidExpr{x, m});
    }
    if (prism_rtl::is<crate::ast::FnBody::BodyBlock>(fn_body0)) {
        auto&& b = prism_rtl::as<crate::ast::FnBody::BodyBlock>(fn_body0).a0;
        return Kid(Kid::KidStmts{b.stmts, m});
    }
    prism_rtl::unreachable("no arm matched");
}


/// PatternsNames: unbounded fn [Pattern] -> [Text]
Array<Text> patterns_names(const Array<crate::ast::Pattern_>& ps) {
    return run_to_end(fold_job(ps, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::ast::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::ast::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto a = p0;
                auto p_ = p1;
                call_then(crate::check_env::start_pattern_names(p_), [=](Array<Text> pattern_names_92660) { return prism_rtl::finished(crate::check_types::union_texts(a, pattern_names_92660)); });
            });
        }));
    }))));
}


prism_rtl::Turn<Array<Text>> PatternsNames::cycle() const {
    const auto& ps = this->ps;
    return fold_job(ps, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::ast::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::ast::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto a = p0;
                auto p_ = p1;
                call_then(crate::check_env::start_pattern_names(p_), [=](Array<Text> pattern_names_92660) { return prism_rtl::finished(crate::check_types::union_texts(a, pattern_names_92660)); });
            });
        }));
    })))->cycle();
}


/// `Start PatternsNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_patterns_names(Array<crate::ast::Pattern_> ps) {
    return prism_rtl::make_rc<PatternsNames>(ps);
}


/// ?CalleeName: fn Expr -> ?Text
std::optional<Text> callee_name(const crate::ast::Expr& c) {
    auto&& _m = c.kind;
    if (prism_rtl::is<crate::ast::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::ast::ExprKind::EName>(_m).a0;
        return std::optional(crate::check_env::sname_key(n));
    }
    if (prism_rtl::is<crate::ast::ExprKind::ETypeArgs>(_m)) {
        auto&& t = prism_rtl::as<crate::ast::ExprKind::ETypeArgs>(_m).a0;
        auto&& _m = t.kind;
        if (prism_rtl::is<crate::ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<crate::ast::ExprKind::EName>(_m).a0;
            return std::optional(crate::check_env::sname_key(n));
        }
        {
            return std::optional<Text>{};
        }
    }
    {
        return std::optional<Text>{};
    }
}


/// MethodCallee: fn SName -> Expr
crate::ast::Expr method_callee(const crate::ast::SName& n) {
    return crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EName{n})), .span = n.span};
}


/// MethodArgs: fn Expr, [Arg] -> [Arg]
Array<crate::ast::Arg> method_args(const crate::ast::Expr& r, const Array<crate::ast::Arg>& args) {
    return append(Array(std::vector{crate::ast::Arg{.name = std::optional<crate::ast::Ident>{}, .value = r, .span = r.span}}), args);
}


/// BodySites: unbounded fn FnBody, (Text ==> Rel) -> [Site]
Array<Site> body_sites(const crate::ast::FnBody& body, const Map<Text, Rel>& m) {
    return run_to_end(fold_job(body_spots(body, m), Array<Site>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Site>>(std::tuple<Array<Site>, Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Site>, Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto sp = p1;
                call_then(start_spot_sites(sp), [=](Array<Site> spot_sites_93617) { return prism_rtl::finished(append(acc, spot_sites_93617)); });
            });
        }));
    }))));
}


prism_rtl::Turn<Array<Site>> BodySites::cycle() const {
    const auto& body = this->body;
    const auto& m = this->m;
    auto body_1 = body;
    auto m_2 = m;
    return call_then(start_body_spots(body_1, m_2), [=](Array<Spot> body_spots_93567) {
        return fold_job(body_spots_93567, Array<Site>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Site>>(std::tuple<Array<Site>, Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Site>, Spot> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto sp = p1;
                    call_then(start_spot_sites(sp), [=](Array<Site> spot_sites_93617) { return prism_rtl::finished(append(acc, spot_sites_93617)); });
                });
            }));
        })))->cycle();
    });
}


/// `Start BodySites, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Site>> start_body_sites(crate::ast::FnBody body, Map<Text, Rel> m) {
    return prism_rtl::make_rc<BodySites>(body, m);
}


/// SpotSites: unbounded fn Spot -> [Site]
Array<Site> spot_sites(const Spot& spot0) {
    if (prism_rtl::is<Spot::SpotStmt>(spot0)) {
        return Array<Site>{};
    }
    if (prism_rtl::is<Spot::SpotExpr>(spot0)) {
        auto&& e = prism_rtl::as<Spot::SpotExpr>(spot0).a0;
        auto&& m = prism_rtl::as<Spot::SpotExpr>(spot0).a1;
        auto&& _m = e.kind;
        if (prism_rtl::is<crate::ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<crate::ast::ExprKind::EName>(_m).a0;
            return Array(std::vector{Site{.callee = crate::check_env::sname_key(n), .args = Array<crate::ast::Arg>{}, .span = e.span, .rels = m}});
        }
        if (prism_rtl::is<crate::ast::ExprKind::ECall>(_m)) {
            auto&& c = prism_rtl::as<crate::ast::ExprKind::ECall>(_m).a0;
            auto&& args = prism_rtl::as<crate::ast::ExprKind::ECall>(_m).a1;
            return call_sites(c, args, e.span, m);
        }
        if (prism_rtl::is<crate::ast::ExprKind::EMethod>(_m)) {
            auto&& r = prism_rtl::as<crate::ast::ExprKind::EMethod>(_m).a0;
            auto&& n = prism_rtl::as<crate::ast::ExprKind::EMethod>(_m).a1;
            auto&& args = prism_rtl::as<crate::ast::ExprKind::EMethod>(_m).a2;
            return call_sites(method_callee(n), method_args(r, args), e.span, m);
        }
        if (prism_rtl::is<crate::ast::ExprKind::EBinary>(_m)) {
            auto&& op = prism_rtl::as<crate::ast::ExprKind::EBinary>(_m).a0;
            auto&& l = prism_rtl::as<crate::ast::ExprKind::EBinary>(_m).a1;
            auto&& r = prism_rtl::as<crate::ast::ExprKind::EBinary>(_m).a2;
            return is_called_op(op)
                ? Array(std::vector{Site{.callee = op, .args = Array(std::vector{arg_of(l), arg_of(r)}), .span = e.span, .rels = m}})
                : Array<Site>{};
        }
        {
            return Array<Site>{};
        }
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Site>> SpotSites::cycle() const {
    const auto& spot0 = this->spot0;
    return ({
        prism_rtl::is<Spot::SpotStmt>(spot0) ? prism_rtl::finished(Array<Site>{})
        : prism_rtl::is<Spot::SpotExpr>(spot0) ? ({
        auto&& e = prism_rtl::as<Spot::SpotExpr>(spot0).a0;
        auto&& m = prism_rtl::as<Spot::SpotExpr>(spot0).a1;
        ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::ast::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::ast::ExprKind::EName>(_m).a0;
        prism_rtl::finished(Array(std::vector{Site{.callee = crate::check_env::sname_key(n), .args = Array<crate::ast::Arg>{}, .span = e.span, .rels = m}}));
    })
        : prism_rtl::is<crate::ast::ExprKind::ECall>(_m) ? ({
        auto&& c = prism_rtl::as<crate::ast::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<crate::ast::ExprKind::ECall>(_m).a1;
        prism_rtl::more(prism_rtl::rc(CallSites(c, args, e.span, m)));
    })
        : prism_rtl::is<crate::ast::ExprKind::EMethod>(_m) ? ({
        auto&& r = prism_rtl::as<crate::ast::ExprKind::EMethod>(_m).a0;
        auto&& n = prism_rtl::as<crate::ast::ExprKind::EMethod>(_m).a1;
        auto&& args = prism_rtl::as<crate::ast::ExprKind::EMethod>(_m).a2;
        prism_rtl::more(prism_rtl::rc(CallSites(method_callee(n), method_args(r, args), e.span, m)));
    })
        : prism_rtl::is<crate::ast::ExprKind::EBinary>(_m) ? ({
        auto&& op = prism_rtl::as<crate::ast::ExprKind::EBinary>(_m).a0;
        auto&& l = prism_rtl::as<crate::ast::ExprKind::EBinary>(_m).a1;
        auto&& r = prism_rtl::as<crate::ast::ExprKind::EBinary>(_m).a2;
        is_called_op(op)
        ? prism_rtl::finished(Array(std::vector{Site{.callee = op, .args = Array(std::vector{arg_of(l), arg_of(r)}), .span = e.span, .rels = m}}))
        : prism_rtl::finished(Array<Site>{});
    })
        : prism_rtl::finished(Array<Site>{});
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SpotSites, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Site>> start_spot_sites(Spot spot0) {
    return prism_rtl::make_rc<SpotSites>(spot0);
}


/// IsCalledOp: fn Text -> Bool
bool is_called_op(const Text& op) {
    return !crate::check_types::has_text(Array(std::vector{Text::lit("and"), Text::lit("or"), Text::lit("on"), Text::lit("<|"), Text::lit("mod")}), op);
}


/// CallSites: unbounded fn Expr, [Arg], Range, (Text ==> Rel) -> [Site]
Array<Site> call_sites(const crate::ast::Expr& c, const Array<crate::ast::Arg>& args, const crate::ast::Range& span, const Map<Text, Rel>& m) {
    auto direct = ({
        __label__ _done;
        prism_rtl::Slot<Array<Site>> _v;
        auto&& _m = callee_name(c);
        if (prism_rtl::is_some(_m)) {
            auto&& n = prism_rtl::some_of(_m);
            _v.set(Array(std::vector{Site{.callee = n, .args = args, .span = span, .rels = m}}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<Site>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& _m = traversal_of(m, c, args);
    if (prism_rtl::is_some(_m)) {
        auto&& coll = std::get<0>(prism_rtl::some_of(_m));
        auto&& step_ = std::get<1>(prism_rtl::some_of(_m));
        auto&& at_ = std::get<2>(prism_rtl::some_of(_m));
        auto&& _m = step_.kind;
        if (prism_rtl::is<crate::ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<crate::ast::ExprKind::EName>(_m).a0;
            auto call_args = at_ == Nat(1u)
                ? Array(std::vector{or_(index(args, Nat(1u)), dummy_arg()), arg_of(part_of(coll))})
                : Array(std::vector{arg_of(part_of(coll))});
            return prelude::push(direct, Site{.callee = crate::check_env::sname_key(n), .args = call_args, .span = step_.span, .rels = m});
        }
        {
            return direct;
        }
    }
    if (prism_rtl::is_none(_m)) {
        auto&& _m = acc_callee(m, c, args);
        if (prism_rtl::is_some(_m)) {
            auto&& cn = prism_rtl::some_of(_m);
            return append(direct, acc_sites(m, cn, args));
        }
        if (prism_rtl::is_none(_m)) {
            return direct;
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Site>> CallSites::cycle() const {
    const auto& c = this->c;
    const auto& args = this->args;
    const auto& span = this->span;
    const auto& m = this->m;
    auto direct = ({
        __label__ _done;
        prism_rtl::Slot<Array<Site>> _v;
        auto&& _m = callee_name(c);
        if (prism_rtl::is_some(_m)) {
            auto&& n = prism_rtl::some_of(_m);
            _v.set(Array(std::vector{Site{.callee = n, .args = args, .span = span, .rels = m}}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<Site>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ({
        auto&& _m = traversal_of(m, c, args);
        prism_rtl::is_some(_m) ? ({
        auto&& coll = std::get<0>(prism_rtl::some_of(_m));
        auto&& step_ = std::get<1>(prism_rtl::some_of(_m));
        auto&& at_ = std::get<2>(prism_rtl::some_of(_m));
        ({
        auto&& _m = step_.kind;
        prism_rtl::is<crate::ast::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::ast::ExprKind::EName>(_m).a0;
        ({
        auto call_args = at_ == Nat(1u)
            ? Array(std::vector{or_(index(args, Nat(1u)), dummy_arg()), arg_of(part_of(coll))})
            : Array(std::vector{arg_of(part_of(coll))});
        (prism_rtl::finished(prelude::push(direct, Site{.callee = crate::check_env::sname_key(n), .args = call_args, .span = step_.span, .rels = m})));
    });
    })
        : prism_rtl::finished(direct);
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto&& _m = acc_callee(m, c, args);
        prism_rtl::is_some(_m) ? ({
        auto&& cn = prism_rtl::some_of(_m);
        prism_rtl::finished(append(direct, acc_sites(m, cn, args)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(direct)
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CallSites, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Site>> start_call_sites(crate::ast::Expr c, Array<crate::ast::Arg> args, crate::ast::Range span, Map<Text, Rel> m) {
    return prism_rtl::make_rc<CallSites>(c, args, span, m);
}


/// PartOf: fn Expr -> Expr
crate::ast::Expr part_of(const crate::ast::Expr& x) {
    return crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EField{prism_rtl::rc(x), Text::lit(""), crate::ast::Ident{.name = Text::lit("element"), .span = x.span}})), .span = x.span};
}


/// AccSites: fn (Text ==> Rel), Text, [Arg] -> [Site]
Array<Site> acc_sites(const Map<Text, Rel>& m, const Text& cn, const Array<crate::ast::Arg>& args) {
    return fold(crate::check_errors::range0(len(args)), Array<Site>{}, [&](const Array<Site>& acc, const Nat& j) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Site>> _v;
            auto&& _m = std::tuple{prelude::get(m, prism_rtl::cat("acc:", cn, ":", j)), index(args, j)};
            if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                auto&& ar = prism_rtl::some_of(std::get<0>(_m));
                auto&& a = prism_rtl::some_of(std::get<1>(_m));
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<Site>> _v;
                    auto&& _m = a->value.kind;
                    if (prism_rtl::is<crate::ast::ExprKind::EName>(_m)) {
                        auto&& f = prism_rtl::as<crate::ast::ExprKind::EName>(_m).a0;
                        _v.set(prelude::push(acc, Site{.callee = crate::check_env::sname_key(f), .args = each(crate::check_errors::range0(ar.param), [&](const Nat& q) { return acc_arg(m, cn, j, q, args); }), .span = a->value.span, .rels = m}));
                        goto _done;
                    }
                    {
                        _v.set(acc);
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// AccArg: fn (Text ==> Rel), Text, Nat, Nat, [Arg] -> Arg
crate::ast::Arg acc_arg(const Map<Text, Rel>& m, const Text& cn, const Nat& j, const Nat& q, const Array<crate::ast::Arg>& args) {
    auto&& _m = prelude::get(m, prism_rtl::cat("sum:", cn, ":", j, ":", q));
    if (prism_rtl::is_some(_m)) {
        auto&& s = prism_rtl::some_of(_m);
        return s.param == top_param()
            ? arg_of(top_expr())
            : ({
            __label__ _done;
            prism_rtl::Slot<crate::ast::Arg> _v;
            auto&& _m = index(args, s.param);
            if (prism_rtl::is_some(_m)) {
                auto&& a = prism_rtl::some_of(_m);
                _v.set(arg_of(s.strict ? part_of(a->value) : a->value));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(dummy_arg());
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_none(_m)) {
        return dummy_arg();
    }
    prism_rtl::unreachable("no arm matched");
}


/// let topExpr
crate::ast::Expr top_expr() {
    return crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EName{crate::ast::SName{.sigils = Text::lit(""), .path_ = Array(std::vector{Text::lit("⊤")}), .span = crate::ast::Range{.start = Nat(0u), .end = Nat(0u)}}})), .span = crate::ast::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// SpotsNames: unbounded fn [Spot] -> [Text]
Array<Text> spots_names(const Array<Spot>& spots) {
    return run_to_end(fold_job(spots, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto sp = p1;
                call_then(start_spot_names(sp), [=](Array<Text> spot_names_96958) { return prism_rtl::finished(crate::check_types::union_texts(acc, spot_names_96958)); });
            });
        }));
    }))));
}


prism_rtl::Turn<Array<Text>> SpotsNames::cycle() const {
    const auto& spots = this->spots;
    return fold_job(spots, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto sp = p1;
                call_then(start_spot_names(sp), [=](Array<Text> spot_names_96958) { return prism_rtl::finished(crate::check_types::union_texts(acc, spot_names_96958)); });
            });
        }));
    })))->cycle();
}


/// `Start SpotsNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_spots_names(Array<Spot> spots) {
    return prism_rtl::make_rc<SpotsNames>(spots);
}


/// SpotNames: unbounded fn Spot -> [Text]
Array<Text> spot_names(const Spot& sp) {
    auto called = each(spot_sites(sp), [&](const Site& s) { return s.callee; });
    if (prism_rtl::is<Spot::SpotExpr>(sp)) {
        return called;
    }
    if (prism_rtl::is<Spot::SpotStmt>(sp)) {
        auto&& s = prism_rtl::as<Spot::SpotStmt>(sp).a0;
        auto&& _m = s.kind;
        if (prism_rtl::is<crate::ast::StmtKind::SWidget>(_m)) {
            auto&& w = prism_rtl::as<crate::ast::StmtKind::SWidget>(_m).a0;
            return crate::check_types::add_text(called, crate::check_env::sname_key(w.name));
        }
        {
            return called;
        }
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> SpotNames::cycle() const {
    const auto& sp = this->sp;
    auto sp_1 = sp;
    return call_then(start_spot_sites(sp_1), [=](Array<Site> spot_sites_97052) {
        return ({
            auto called = each(spot_sites_97052, [&](const Site& s) { return s.callee; });
            ({
            prism_rtl::is<Spot::SpotExpr>(sp_1) ? prism_rtl::finished(called)
            : prism_rtl::is<Spot::SpotStmt>(sp_1) ? ({
            auto&& s = prism_rtl::as<Spot::SpotStmt>(sp_1).a0;
            ({
            auto&& _m = s.kind;
            prism_rtl::is<crate::ast::StmtKind::SWidget>(_m) ? ({
            auto&& w = prism_rtl::as<crate::ast::StmtKind::SWidget>(_m).a0;
            prism_rtl::finished(crate::check_types::add_text(called, crate::check_env::sname_key(w.name)));
        })
            : prism_rtl::finished(called);
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
}


/// `Start SpotNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_spot_names(Spot sp) {
    return prism_rtl::make_rc<SpotNames>(sp);
}


/// ?TraversalOf: fn (Text ==> Rel), Expr, [Arg] -> ?((Expr, Expr, Nat))
std::optional<std::tuple<crate::ast::Expr, crate::ast::Expr, Nat>> traversal_of(const Map<Text, Rel>& m, const crate::ast::Expr& c, const Array<crate::ast::Arg>& args) {
    auto&& _m = c.kind;
    if (prism_rtl::is<crate::ast::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::ast::ExprKind::EName>(_m).a0;
        auto name = crate::check_env::sname_key(n);
        return pre_is(m, name, Text::lit("Fold")) && (len(args) == Nat(3u))
            ? ({
            __label__ _done;
            prism_rtl::Slot<std::optional<std::tuple<crate::ast::Expr, crate::ast::Expr, Nat>>> _v;
            auto&& _m = std::tuple{index(args, Nat(0u)), index(args, Nat(2u))};
            if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                auto&& a = prism_rtl::some_of(std::get<0>(_m));
                auto&& s = prism_rtl::some_of(std::get<1>(_m));
                _v.set(std::optional(std::tuple{a->value, s->value, Nat(1u)}));
                goto _done;
            }
            {
                _v.set(std::optional<std::tuple<crate::ast::Expr, crate::ast::Expr, Nat>>{});
                goto _done;
            }
        _done:
            _v.take();
        })
            : (pre_is(m, name, Text::lit("Each")) || pre_is(m, name, Text::lit("Filter"))) && (len(args) == Nat(2u))
            ? ({
            __label__ _done;
            prism_rtl::Slot<std::optional<std::tuple<crate::ast::Expr, crate::ast::Expr, Nat>>> _v;
            auto&& _m = std::tuple{index(args, Nat(0u)), index(args, Nat(1u))};
            if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                auto&& a = prism_rtl::some_of(std::get<0>(_m));
                auto&& s = prism_rtl::some_of(std::get<1>(_m));
                _v.set(std::optional(std::tuple{a->value, s->value, Nat(0u)}));
                goto _done;
            }
            {
                _v.set(std::optional<std::tuple<crate::ast::Expr, crate::ast::Expr, Nat>>{});
                goto _done;
            }
        _done:
            _v.take();
        })
            : std::optional<std::tuple<crate::ast::Expr, crate::ast::Expr, Nat>>{};
    }
    {
        return std::optional<std::tuple<crate::ast::Expr, crate::ast::Expr, Nat>>{};
    }
}


/// ?LastExpr: fn Block -> ?Expr
std::optional<crate::ast::Expr> last_expr(const crate::ast::Block& b) {
    auto&& _m = crate::lexer::last(b.stmts);
    if (prism_rtl::is_some(_m)) {
        auto&& s = prism_rtl::some_of(_m);
        auto&& _m = s.kind;
        if (prism_rtl::is<crate::ast::StmtKind::SExpr>(_m)) {
            auto&& x = prism_rtl::as<crate::ast::StmtKind::SExpr>(_m).a0;
            return std::optional(x);
        }
        {
            return std::optional<crate::ast::Expr>{};
        }
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<crate::ast::Expr>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?RelOf: unbounded fn (Text ==> Rel), Expr -> ?Rel
std::optional<Rel> rel_of(const Map<Text, Rel>& m, const crate::ast::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::ast::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::ast::ExprKind::EName>(_m).a0;
        return prelude::get(m, crate::check_env::sname_key(n));
    }
    if (prism_rtl::is<crate::ast::ExprKind::EField>(_m)) {
        auto&& r = prism_rtl::as<crate::ast::ExprKind::EField>(_m).a0;
        auto&& _m = rel_of(m, r);
        if (prism_rtl::is_some(_m)) {
            auto&& x = prism_rtl::some_of(_m);
            return std::optional(Rel{.param = x.param, .strict = true});
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional<Rel>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::ast::ExprKind::EIndex>(_m)) {
        auto&& r = prism_rtl::as<crate::ast::ExprKind::EIndex>(_m).a0;
        return rel_of(m, r);
    }
    if (prism_rtl::is<crate::ast::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::ast::ExprKind::EGroup>(_m).a0;
        return rel_of(m, x);
    }
    {
        auto&& _m = call_of(e);
        if (prism_rtl::is_some(_m)) {
            auto&& c = std::get<0>(prism_rtl::some_of(_m));
            auto&& args = std::get<1>(prism_rtl::some_of(_m));
            return is_non_nat_min(m, e, c) ? std::optional<Rel>{} : rel_of_call(m, c, args);
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional<Rel>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<std::optional<Rel>> RelOf::cycle() const {
    const auto& m = this->m;
    const auto& e = this->e;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::ast::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::ast::ExprKind::EName>(_m).a0;
        prism_rtl::finished(prelude::get(m, crate::check_env::sname_key(n)));
    })
        : prism_rtl::is<crate::ast::ExprKind::EField>(_m) ? ({
        auto&& r = prism_rtl::as<crate::ast::ExprKind::EField>(_m).a0;
        ({
        auto m_1 = m;
        auto r_2 = r;
        call_then(start_rel_of(m_1, r_2), [=](std::optional<Rel> rel_of_99168) {
        return ({
            prism_rtl::is_some(rel_of_99168) ? ({
            auto&& x = prism_rtl::some_of(rel_of_99168);
            prism_rtl::finished(std::optional(Rel{.param = x.param, .strict = true}));
        })
            : prism_rtl::is_none(rel_of_99168) ? prism_rtl::finished(std::optional<Rel>{})
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    });
    })
        : prism_rtl::is<crate::ast::ExprKind::EIndex>(_m) ? ({
        auto&& r = prism_rtl::as<crate::ast::ExprKind::EIndex>(_m).a0;
        prism_rtl::more(prism_rtl::rc(RelOf(m, r)));
    })
        : prism_rtl::is<crate::ast::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::ast::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(RelOf(m, x)));
    })
        : ({
        auto&& _m = call_of(e);
        prism_rtl::is_some(_m) ? ({
        auto&& c = std::get<0>(prism_rtl::some_of(_m));
        auto&& args = std::get<1>(prism_rtl::some_of(_m));
        is_non_nat_min(m, e, c)
        ? prism_rtl::finished(std::optional<Rel>{})
        : prism_rtl::more(prism_rtl::rc(RelOfCall(m, c, args)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<Rel>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    });
}


/// `Start RelOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Rel>> start_rel_of(Map<Text, Rel> m, crate::ast::Expr e) {
    return prism_rtl::make_rc<RelOf>(m, e);
}


/// IsNonNatMin: fn (Text ==> Rel), Expr, Expr -> Bool
bool is_non_nat_min(const Map<Text, Rel>& m, const crate::ast::Expr& e, const crate::ast::Expr& c) {
    auto&& _m = callee_name(c);
    if (prism_rtl::is_some(_m)) {
        auto&& n = prism_rtl::some_of(_m);
        return pre_is(m, n, Text::lit("Min")) ? !is_nat_at(m, e) : false;
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// IsNatAt: fn (Text ==> Rel), Expr -> Bool
bool is_nat_at(const Map<Text, Rel>& m, const crate::ast::Expr& e) {
    auto&& _m = prelude::get(m, Text::lit("file:"));
    if (prism_rtl::is_some(_m)) {
        auto&& f = prism_rtl::some_of(_m);
        return crate::check_env::has_key(m, prism_rtl::cat("nat:", f.param, ":", e.span.start, ":", e.span.end));
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?RelOfCall: unbounded fn (Text ==> Rel), Expr, [Arg] -> ?Rel
std::optional<Rel> rel_of_call(const Map<Text, Rel>& m, const crate::ast::Expr& c, const Array<crate::ast::Arg>& args) {
    auto&& _m = c.kind;
    if (prism_rtl::is<crate::ast::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::ast::ExprKind::EName>(_m).a0;
        auto name = crate::check_env::sname_key(n);
        return (pre_is(m, name, Text::lit("Drop")) && (len(args) == Nat(2u))) && is_positive_lit(or_(index(args, Nat(1u)), dummy_arg())->value)
            ? ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Rel>> _v;
            auto&& _m = index(args, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& a = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<std::optional<Rel>> _v;
                    auto&& _m = rel_of(m, a->value);
                    if (prism_rtl::is_some(_m)) {
                        auto&& x = prism_rtl::some_of(_m);
                        _v.set(std::optional(Rel{.param = x.param, .strict = x.strict || known_non_empty(m, a->value)}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(std::optional<Rel>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(std::optional<Rel>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        })
            : (pre_is(m, name, Text::lit("Values")) || pre_is(m, name, Text::lit("Keys"))) && (len(args) == Nat(1u))
            ? rel_of(m, or_(index(args, Nat(0u)), dummy_arg())->value)
            : ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Rel>> _v;
            auto&& _m = no_larger_arg(m, c, args);
            if (prism_rtl::is_some(_m)) {
                auto&& a = prism_rtl::some_of(_m);
                _v.set(rel_of(m, a));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(std::optional<Rel>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    {
        return std::optional<Rel>{};
    }
}


prism_rtl::Turn<std::optional<Rel>> RelOfCall::cycle() const {
    const auto& m = this->m;
    const auto& c = this->c;
    const auto& args = this->args;
    return ({
        auto&& _m = c.kind;
        prism_rtl::is<crate::ast::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::ast::ExprKind::EName>(_m).a0;
        ({
        auto name = crate::check_env::sname_key(n);
        (pre_is(m, name, Text::lit("Drop")) && (len(args) == Nat(2u))) && is_positive_lit(or_(index(args, Nat(1u)), dummy_arg())->value)
        ? ({
        auto&& _m = index(args, Nat(0u));
        prism_rtl::is_some(_m) ? ({
        auto&& a = prism_rtl::some_of(_m);
        ({
        auto m_1 = m;
        call_then(start_rel_of(m_1, a->value), [=](std::optional<Rel> rel_of_100325) {
        return ({
            prism_rtl::is_some(rel_of_100325) ? ({
            auto&& x = prism_rtl::some_of(rel_of_100325);
            prism_rtl::finished(std::optional(Rel{.param = x.param, .strict = x.strict || known_non_empty(m_1, a->value)}));
        })
            : prism_rtl::is_none(rel_of_100325) ? prism_rtl::finished(std::optional<Rel>{})
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<Rel>{})
        : throw prism_rtl::Panic("no arm matched");
    })
        : (pre_is(m, name, Text::lit("Values")) || pre_is(m, name, Text::lit("Keys"))) && (len(args) == Nat(1u))
        ? prism_rtl::more(prism_rtl::rc(RelOf(m, or_(index(args, Nat(0u)), dummy_arg())->value)))
        : ({
        auto&& _m = no_larger_arg(m, c, args);
        prism_rtl::is_some(_m) ? ({
        auto&& a = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(RelOf(m, a)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<Rel>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : prism_rtl::finished(std::optional<Rel>{});
    });
}


/// `Start RelOfCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Rel>> start_rel_of_call(Map<Text, Rel> m, crate::ast::Expr c, Array<crate::ast::Arg> args) {
    return prism_rtl::make_rc<RelOfCall>(m, c, args);
}


/// KnownNonEmpty: fn (Text ==> Rel), Expr -> Bool
bool known_non_empty(const Map<Text, Rel>& m, const crate::ast::Expr& e) {
    auto&& _m = name_of(e);
    if (prism_rtl::is_some(_m)) {
        auto&& n = prism_rtl::some_of(_m);
        return crate::check_env::has_key(m, prism_rtl::cat("ne:", n));
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?CallOf: fn Expr -> ?((Expr, [Arg]))
std::optional<std::tuple<crate::ast::Expr, Array<crate::ast::Arg>>> call_of(const crate::ast::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::ast::ExprKind::ECall>(_m)) {
        auto&& c = prism_rtl::as<crate::ast::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<crate::ast::ExprKind::ECall>(_m).a1;
        return std::optional(std::tuple{c, args});
    }
    if (prism_rtl::is<crate::ast::ExprKind::EMethod>(_m)) {
        auto&& r = prism_rtl::as<crate::ast::ExprKind::EMethod>(_m).a0;
        auto&& n = prism_rtl::as<crate::ast::ExprKind::EMethod>(_m).a1;
        auto&& args = prism_rtl::as<crate::ast::ExprKind::EMethod>(_m).a2;
        return std::optional(std::tuple{method_callee(n), method_args(r, args)});
    }
    {
        return std::optional<std::tuple<crate::ast::Expr, Array<crate::ast::Arg>>>{};
    }
}


/// ?NoLargerArg: fn (Text ==> Rel), Expr, [Arg] -> ?Expr
std::optional<crate::ast::Expr> no_larger_arg(const Map<Text, Rel>& m, const crate::ast::Expr& c, const Array<crate::ast::Arg>& args) {
    auto&& _m = callee_name(c);
    if (prism_rtl::is_some(_m)) {
        auto&& n = prism_rtl::some_of(_m);
        return is_local(m, n)
            ? std::optional<crate::ast::Expr>{}
            : ({
            __label__ _done;
            prism_rtl::Slot<std::optional<crate::ast::Expr>> _v;
            auto&& _m = prelude::get(m, prism_rtl::cat("fn:", n));
            if (prism_rtl::is_some(_m)) {
                auto&& s = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<std::optional<crate::ast::Expr>> _v;
                    auto&& _m = index(args, s.param);
                    if (prism_rtl::is_some(_m)) {
                        auto&& a = prism_rtl::some_of(_m);
                        _v.set(std::optional(a->value));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(std::optional<crate::ast::Expr>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(std::optional<crate::ast::Expr>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<crate::ast::Expr>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// IsNoLargerPrelude: fn G, Text -> Bool
bool is_no_larger_prelude(const crate::check_env::G& g, const Text& k) {
    return crate::check_types::has_text(Array(std::vector{Text::lit("Prelude.Take"), Text::lit("Prelude.Drop"), Text::lit("Prelude.Filter"), Text::lit("Prelude.Remove"), Text::lit("Prelude.Min")}), k) && is_prelude_key(g, k);
}


/// PartsSummaries: unbounded fn Shrink, [Def] -> (Text ==> Nat)
Map<Text, Nat> parts_summaries(const Shrink& sk, const Array<crate::check_env::Def>& fns) {
    return run_to_end(fold_job(fns, Map<Text, Nat>{}, ({
        auto sk_1 = sk;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Nat>>(std::tuple<Map<Text, Nat>, crate::check_env::Def>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Nat>, crate::check_env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_1_2 = sk_1;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                auto d = p1;
                ({
                auto&& _m = d.body;
                prism_rtl::is<crate::check_env::DefBody::DbFn>(_m) ? ({
                auto&& clauses = prism_rtl::as<crate::check_env::DefBody::DbFn>(_m).a0;
                ({
                auto n = ({
                    __label__ _done;
                    prism_rtl::Slot<Nat> _v;
                    auto&& _m = index(clauses, Nat(0u));
                    if (prism_rtl::is_some(_m)) {
                        auto&& c0 = prism_rtl::some_of(_m);
                        _v.set(len(c0.params));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Nat(0u));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto clauses_2 = clauses;
                call_value(filter_job(crate::check_errors::range0(n), ({
                auto clauses_2_3 = clauses_2;
                auto sk_1_2_3 = sk_1_2;
                auto d_3 = d;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                return ({
                    auto clauses_2_3_4 = clauses_2_3;
                    auto sk_1_2_3_4 = sk_1_2_3;
                    auto d_3_4 = d_3;
                    entered(once_job([=]() {
                    return ({
                        auto i = p0;
                        fold_job(clauses_2_3_4, true, ({
                        auto sk_1_2_3_4_4 = sk_1_2_3_4;
                        auto d_3_4_4 = d_3_4;
                        auto i_4 = i;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<bool, crate::ast::FnClause> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto sk_1_2_3_4_4_5 = sk_1_2_3_4_4;
                            auto d_3_4_4_5 = d_3_4_4;
                            auto i_4_5 = i_4;
                            entered(once_job([=]() {
                            return ({
                                auto okc = p0;
                                auto c = p1;
                                (prism_rtl::finished(okc && clause_within(clause_base(sk_1_2_3_4_4_5, d_3_4_4_5, c), c, i_4_5)));
                            });
                        }));
                        });
                    })));
                    }))->cycle();
                    });
                }));
                });
            })));
            })), [=](Array<Nat> filter_102984) {
                return ({
                    auto ok = filter_102984;
                    ({
                    auto&& _m = index(ok, Nat(0u));
                    prism_rtl::is_some(_m) ? ({
                    auto&& i = prism_rtl::some_of(_m);
                    prism_rtl::finished(insert(m, d.qk, i));
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(m)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            });
            });
            })
                : prism_rtl::finished(m);
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<Map<Text, Nat>> PartsSummaries::cycle() const {
    const auto& sk = this->sk;
    const auto& fns = this->fns;
    return fold_job(fns, Map<Text, Nat>{}, ({
        auto sk_1 = sk;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Nat>>(std::tuple<Map<Text, Nat>, crate::check_env::Def>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Nat>, crate::check_env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_1_2 = sk_1;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                auto d = p1;
                ({
                auto&& _m = d.body;
                prism_rtl::is<crate::check_env::DefBody::DbFn>(_m) ? ({
                auto&& clauses = prism_rtl::as<crate::check_env::DefBody::DbFn>(_m).a0;
                ({
                auto n = ({
                    __label__ _done;
                    prism_rtl::Slot<Nat> _v;
                    auto&& _m = index(clauses, Nat(0u));
                    if (prism_rtl::is_some(_m)) {
                        auto&& c0 = prism_rtl::some_of(_m);
                        _v.set(len(c0.params));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Nat(0u));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto clauses_2 = clauses;
                call_value(filter_job(crate::check_errors::range0(n), ({
                auto clauses_2_3 = clauses_2;
                auto sk_1_2_3 = sk_1_2;
                auto d_3 = d;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                return ({
                    auto clauses_2_3_4 = clauses_2_3;
                    auto sk_1_2_3_4 = sk_1_2_3;
                    auto d_3_4 = d_3;
                    entered(once_job([=]() {
                    return ({
                        auto i = p0;
                        fold_job(clauses_2_3_4, true, ({
                        auto sk_1_2_3_4_4 = sk_1_2_3_4;
                        auto d_3_4_4 = d_3_4;
                        auto i_4 = i;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<bool, crate::ast::FnClause> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto sk_1_2_3_4_4_5 = sk_1_2_3_4_4;
                            auto d_3_4_4_5 = d_3_4_4;
                            auto i_4_5 = i_4;
                            entered(once_job([=]() {
                            return ({
                                auto okc = p0;
                                auto c = p1;
                                (prism_rtl::finished(okc && clause_within(clause_base(sk_1_2_3_4_4_5, d_3_4_4_5, c), c, i_4_5)));
                            });
                        }));
                        });
                    })));
                    }))->cycle();
                    });
                }));
                });
            })));
            })), [=](Array<Nat> filter_102984) {
                return ({
                    auto ok = filter_102984;
                    ({
                    auto&& _m = index(ok, Nat(0u));
                    prism_rtl::is_some(_m) ? ({
                    auto&& i = prism_rtl::some_of(_m);
                    prism_rtl::finished(insert(m, d.qk, i));
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(m)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            });
            });
            })
                : prism_rtl::finished(m);
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start PartsSummaries, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Nat>> start_parts_summaries(Shrink sk, Array<crate::check_env::Def> fns) {
    return prism_rtl::make_rc<PartsSummaries>(sk, fns);
}


/// ClauseWithin: unbounded fn (Text ==> Rel), FnClause, Nat -> Bool
bool clause_within(const Map<Text, Rel>& base, const crate::ast::FnClause& c, const Nat& i) {
    auto&& _m = c.body;
    if (prism_rtl::is<crate::ast::FnBody::BodyExpr>(_m)) {
        auto&& e = prism_rtl::as<crate::ast::FnBody::BodyExpr>(_m).a0;
        return within(base, i, e);
    }
    if (prism_rtl::is<crate::ast::FnBody::BodyBlock>(_m)) {
        auto&& b = prism_rtl::as<crate::ast::FnBody::BodyBlock>(_m).a0;
        return within_block(base, i, b);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> ClauseWithin::cycle() const {
    const auto& base = this->base;
    const auto& c = this->c;
    const auto& i = this->i;
    return ({
        auto&& _m = c.body;
        prism_rtl::is<crate::ast::FnBody::BodyExpr>(_m) ? ({
        auto&& e = prism_rtl::as<crate::ast::FnBody::BodyExpr>(_m).a0;
        prism_rtl::more(prism_rtl::rc(Within(base, i, e)));
    })
        : prism_rtl::is<crate::ast::FnBody::BodyBlock>(_m) ? ({
        auto&& b = prism_rtl::as<crate::ast::FnBody::BodyBlock>(_m).a0;
        prism_rtl::more(prism_rtl::rc(WithinBlock(base, i, b)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ClauseWithin, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_clause_within(Map<Text, Rel> base, crate::ast::FnClause c, Nat i) {
    return prism_rtl::make_rc<ClauseWithin>(base, c, i);
}


/// Within: unbounded fn (Text ==> Rel), Nat, Expr -> Bool
bool within(const Map<Text, Rel>& m, const Nat& i, const crate::ast::Expr& e) {
    auto&& _m = rel_of(m, e);
    if (prism_rtl::is_some(_m)) {
        auto&& r = prism_rtl::some_of(_m);
        return r.param == i;
    }
    if (prism_rtl::is_none(_m)) {
        auto&& _m = e.kind;
        if (prism_rtl::is<crate::ast::ExprKind::EArray>(_m)) {
            auto&& es = prism_rtl::as<crate::ast::ExprKind::EArray>(_m).a0;
            return run_to_end(fold_job(es, true, ({
                auto m_1 = m;
                auto i_2 = i;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::ast::Expr>)>>(prism_rtl::rc([=](std::tuple<bool, crate::ast::Expr> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto m_1_3 = m_1;
                    auto i_2_3 = i_2;
                    entered(once_job([=]() {
                    return ({
                        auto ok = p0;
                        auto x = p1;
                        (prism_rtl::finished(ok && part(m_1_3, i_2_3, x)));
                    });
                }));
                });
            })));
            })));
        }
        if (prism_rtl::is<crate::ast::ExprKind::EMap>(_m)) {
            auto&& kvs = prism_rtl::as<crate::ast::ExprKind::EMap>(_m).a0;
            return run_to_end(fold_job(kvs, true, ({
                auto m_1 = m;
                auto i_2 = i;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<crate::ast::Expr, crate::ast::Expr>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<crate::ast::Expr, crate::ast::Expr>> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto m_1_3 = m_1;
                    auto i_2_3 = i_2;
                    entered(once_job([=]() {
                    return ({
                        auto ok = p0;
                        auto [k, v_] = p1;
                        (prism_rtl::finished((ok && part(m_1_3, i_2_3, k)) && part(m_1_3, i_2_3, v_)));
                    });
                }));
                });
            })));
            })));
        }
        if (prism_rtl::is<crate::ast::ExprKind::EGroup>(_m)) {
            auto&& x = prism_rtl::as<crate::ast::ExprKind::EGroup>(_m).a0;
            return within(m, i, x);
        }
        if (prism_rtl::is<crate::ast::ExprKind::EMatch>(_m)) {
            auto&& s = prism_rtl::as<crate::ast::ExprKind::EMatch>(_m).a0;
            auto&& arms = prism_rtl::as<crate::ast::ExprKind::EMatch>(_m).a1;
            return run_to_end(fold_job(arms, true, ({
                auto s_1 = s;
                auto m_2 = m;
                auto i_3 = i;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::ast::Arm>)>>(prism_rtl::rc([=](std::tuple<bool, crate::ast::Arm> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto s_1_4 = s_1;
                    auto m_2_4 = m_2;
                    auto i_3_4 = i_3;
                    entered(once_job([=]() {
                    return ({
                        auto ok = p0;
                        auto a = p1;
                        (prism_rtl::finished(ok && within_block(arm_pat_rels(s_1_4, a, m_2_4), i_3_4, a.body)));
                    });
                }));
                });
            })));
            })));
        }
        if (prism_rtl::is<crate::ast::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<crate::ast::ExprKind::EIf>(_m).a2)) {
            auto&& c = prism_rtl::as<crate::ast::ExprKind::EIf>(_m).a0;
            auto&& t = prism_rtl::as<crate::ast::ExprKind::EIf>(_m).a1;
            auto&& el = prism_rtl::some_of(prism_rtl::as<crate::ast::ExprKind::EIf>(_m).a2);
            return within_block(cond_rels(c, m), i, t) && within_block(m, i, el);
        }
        if (prism_rtl::is<crate::ast::ExprKind::EUpdate>(_m)) {
            auto&& start = prism_rtl::as<crate::ast::ExprKind::EUpdate>(_m).a0;
            auto&& b = prism_rtl::as<crate::ast::ExprKind::EUpdate>(_m).a1;
            return within(m, i, start) && update_within(insert(m, Text::lit("&_"), Rel{.param = i, .strict = false}), i, b);
        }
        {
            auto&& _m = call_of(e);
            if (prism_rtl::is_some(_m)) {
                auto&& c = std::get<0>(prism_rtl::some_of(_m));
                auto&& args = std::get<1>(prism_rtl::some_of(_m));
                auto&& _m = traversal_of(m, c, args);
                if (prism_rtl::is_some(_m)) {
                    auto&& coll = std::get<0>(prism_rtl::some_of(_m));
                    auto&& step_ = std::get<1>(prism_rtl::some_of(_m));
                    auto&& at_ = std::get<2>(prism_rtl::some_of(_m));
                    return within(m, i, coll) && step_within(m, i, expr_name(c), coll, step_, at_, or_(index(args, Nat(1u)), dummy_arg())->value);
                }
                if (prism_rtl::is_none(_m)) {
                    return false;
                }
                prism_rtl::unreachable("no arm matched");
            }
            if (prism_rtl::is_none(_m)) {
                return false;
            }
            prism_rtl::unreachable("no arm matched");
        }
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> Within::cycle() const {
    const auto& m = this->m;
    const auto& i = this->i;
    const auto& e = this->e;
    auto e_1 = e;
    auto i_2 = i;
    auto m_3 = m;
    return call_then(start_rel_of(m_3, e_1), [=](std::optional<Rel> rel_of_103444) {
        return ({
            prism_rtl::is_some(rel_of_103444) ? ({
            auto&& r = prism_rtl::some_of(rel_of_103444);
            prism_rtl::finished(r.param == i_2);
        })
            : prism_rtl::is_none(rel_of_103444) ? ({
            auto&& _m = e_1.kind;
            prism_rtl::is<crate::ast::ExprKind::EArray>(_m) ? ({
            auto&& es = prism_rtl::as<crate::ast::ExprKind::EArray>(_m).a0;
            fold_job(es, true, ({
            auto m_3_4 = m_3;
            auto i_2_4 = i_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::ast::Expr>)>>(prism_rtl::rc([=](std::tuple<bool, crate::ast::Expr> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto m_3_4_4 = m_3_4;
                auto i_2_4_4 = i_2_4;
                entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto x = p1;
                    (prism_rtl::finished(ok && part(m_3_4_4, i_2_4_4, x)));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::ast::ExprKind::EMap>(_m) ? ({
            auto&& kvs = prism_rtl::as<crate::ast::ExprKind::EMap>(_m).a0;
            fold_job(kvs, true, ({
            auto m_3_4 = m_3;
            auto i_2_4 = i_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<crate::ast::Expr, crate::ast::Expr>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<crate::ast::Expr, crate::ast::Expr>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto m_3_4_4 = m_3_4;
                auto i_2_4_4 = i_2_4;
                entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto [k, v_] = p1;
                    (prism_rtl::finished((ok && part(m_3_4_4, i_2_4_4, k)) && part(m_3_4_4, i_2_4_4, v_)));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::ast::ExprKind::EGroup>(_m) ? ({
            auto&& x = prism_rtl::as<crate::ast::ExprKind::EGroup>(_m).a0;
            prism_rtl::more(prism_rtl::rc(Within(m_3, i_2, x)));
        })
            : prism_rtl::is<crate::ast::ExprKind::EMatch>(_m) ? ({
            auto&& s = prism_rtl::as<crate::ast::ExprKind::EMatch>(_m).a0;
            auto&& arms = prism_rtl::as<crate::ast::ExprKind::EMatch>(_m).a1;
            fold_job(arms, true, ({
            auto s_4 = s;
            auto m_3_5 = m_3;
            auto i_2_5 = i_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::ast::Arm>)>>(prism_rtl::rc([=](std::tuple<bool, crate::ast::Arm> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto s_4_5 = s_4;
                auto m_3_5_5 = m_3_5;
                auto i_2_5_5 = i_2_5;
                entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto a = p1;
                    (prism_rtl::finished(ok && within_block(arm_pat_rels(s_4_5, a, m_3_5_5), i_2_5_5, a.body)));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::ast::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<crate::ast::ExprKind::EIf>(_m).a2) ? ({
            auto&& c = prism_rtl::as<crate::ast::ExprKind::EIf>(_m).a0;
            auto&& t = prism_rtl::as<crate::ast::ExprKind::EIf>(_m).a1;
            auto&& el = prism_rtl::some_of(prism_rtl::as<crate::ast::ExprKind::EIf>(_m).a2);
            ({
            auto c_4 = c;
            auto el_5 = el;
            auto t_6 = t;
            call_then(start_cond_rels(c_4, m_3), [=](Map<Text, Rel> cond_rels_103828) { return call_then(start_within_block(cond_rels_103828, i_2, t_6), [=](bool within_block_103815) { return prism_rtl::finished(within_block_103815 && within_block(m_3, i_2, el_5)); }); });
        });
        })
            : prism_rtl::is<crate::ast::ExprKind::EUpdate>(_m) ? ({
            auto&& start = prism_rtl::as<crate::ast::ExprKind::EUpdate>(_m).a0;
            auto&& b = prism_rtl::as<crate::ast::ExprKind::EUpdate>(_m).a1;
            ({
            auto b_4 = b;
            auto start_5 = start;
            call_then(start_within(m_3, i_2, start_5), [=](bool within_103902) { return prism_rtl::finished(within_103902 && update_within(insert(m_3, Text::lit("&_"), Rel{.param = i_2, .strict = false}), i_2, b_4)); });
        });
        })
            : ({
            auto&& _m = call_of(e_1);
            prism_rtl::is_some(_m) ? ({
            auto&& c = std::get<0>(prism_rtl::some_of(_m));
            auto&& args = std::get<1>(prism_rtl::some_of(_m));
            ({
            auto&& _m = traversal_of(m_3, c, args);
            prism_rtl::is_some(_m) ? ({
            auto&& coll = std::get<0>(prism_rtl::some_of(_m));
            auto&& step_ = std::get<1>(prism_rtl::some_of(_m));
            auto&& at_ = std::get<2>(prism_rtl::some_of(_m));
            call_then(start_within(m_3, i_2, coll), [=](bool within_104123) { return prism_rtl::finished(within_104123 && step_within(m_3, i_2, expr_name(c), coll, step_, at_, or_(index(args, Nat(1u)), dummy_arg())->value)); });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
    });
}


/// `Start Within, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_within(Map<Text, Rel> m, Nat i, crate::ast::Expr e) {
    return prism_rtl::make_rc<Within>(m, i, e);
}


/// UpdateWithin: unbounded fn (Text ==> Rel), Nat, Block -> Bool
bool update_within(const Map<Text, Rel>& m, const Nat& i, const crate::ast::Block& b) {
    return run_to_end(fold_job(stmts_spots(b.stmts, m), true, ({
        auto i_1 = i;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Spot>)>>(prism_rtl::rc([=](std::tuple<bool, Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto i_1_2 = i_1;
            entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto sp = p1;
                (prism_rtl::finished(ok && spot_keeps_within(sp, i_1_2)));
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<bool> UpdateWithin::cycle() const {
    const auto& m = this->m;
    const auto& i = this->i;
    const auto& b = this->b;
    auto b_1 = b;
    auto i_2 = i;
    auto m_3 = m;
    return call_then(start_stmts_spots(b_1.stmts, m_3), [=](Array<Spot> stmts_spots_104585) {
        return fold_job(stmts_spots_104585, true, ({
            auto i_2_4 = i_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Spot>)>>(prism_rtl::rc([=](std::tuple<bool, Spot> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto i_2_4_4 = i_2_4;
                entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto sp = p1;
                    (prism_rtl::finished(ok && spot_keeps_within(sp, i_2_4_4)));
                });
            }));
            });
        })));
        }))->cycle();
    });
}


/// `Start UpdateWithin, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_update_within(Map<Text, Rel> m, Nat i, crate::ast::Block b) {
    return prism_rtl::make_rc<UpdateWithin>(m, i, b);
}


/// SpotKeepsWithin: unbounded fn Spot, Nat -> Bool
bool spot_keeps_within(const Spot& spot0, const Nat& n1) {
    auto&& _m = std::tuple{spot0, n1};
    if (prism_rtl::is<Spot::SpotStmt>(std::get<0>(_m))) {
        auto&& s = prism_rtl::as<Spot::SpotStmt>(std::get<0>(_m)).a0;
        auto&& m = prism_rtl::as<Spot::SpotStmt>(std::get<0>(_m)).a1;
        auto&& i = std::get<1>(_m);
        auto&& _m = s.kind;
        if (prism_rtl::is<crate::ast::StmtKind::SSet>(_m)) {
            auto&& t = prism_rtl::as<crate::ast::StmtKind::SSet>(_m).a0;
            auto&& value = prism_rtl::as<crate::ast::StmtKind::SSet>(_m).a1;
            return take(ref_path(t), Nat(1u)) != Array(std::vector{Text::lit("&_")})
                ? true
                : (ref_path(t) == Array(std::vector{Text::lit("&_")})) && within(m, i, value);
        }
        if (prism_rtl::is<crate::ast::StmtKind::SAccum>(_m)) {
            auto&& t = prism_rtl::as<crate::ast::StmtKind::SAccum>(_m).a0;
            return take(ref_path(t), Nat(1u)) != Array(std::vector{Text::lit("&_")});
        }
        {
            return true;
        }
    }
    if (prism_rtl::is<Spot::SpotExpr>(std::get<0>(_m))) {
        return true;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> SpotKeepsWithin::cycle() const {
    const auto& spot0 = this->spot0;
    const auto& n1 = this->n1;
    return ({
        auto&& _m = std::tuple{spot0, n1};
        prism_rtl::is<Spot::SpotStmt>(std::get<0>(_m)) ? ({
        auto&& s = prism_rtl::as<Spot::SpotStmt>(std::get<0>(_m)).a0;
        auto&& m = prism_rtl::as<Spot::SpotStmt>(std::get<0>(_m)).a1;
        auto&& i = std::get<1>(_m);
        ({
        auto&& _m = s.kind;
        prism_rtl::is<crate::ast::StmtKind::SSet>(_m) ? ({
        auto&& t = prism_rtl::as<crate::ast::StmtKind::SSet>(_m).a0;
        auto&& value = prism_rtl::as<crate::ast::StmtKind::SSet>(_m).a1;
        ({
        auto i_1 = i;
        auto m_2 = m;
        auto t_3 = t;
        auto value_4 = value;
        call_then(start_ref_path(t_3), [=](Array<Text> ref_path_104794) {
        return take(ref_path_104794, Nat(1u)) != Array(std::vector{Text::lit("&_")})
            ? prism_rtl::finished(true)
            : call_then(start_ref_path(t_3), [=](Array<Text> ref_path_104842) { return prism_rtl::finished((ref_path_104842 == Array(std::vector{Text::lit("&_")})) && within(m_2, i_1, value_4)); });
    });
    });
    })
        : prism_rtl::is<crate::ast::StmtKind::SAccum>(_m) ? ({
        auto&& t = prism_rtl::as<crate::ast::StmtKind::SAccum>(_m).a0;
        ({
        auto t_1 = t;
        call_then(start_ref_path(t_1), [=](Array<Text> ref_path_104925) { return prism_rtl::finished(take(ref_path_104925, Nat(1u)) != Array(std::vector{Text::lit("&_")})); });
    });
    })
        : prism_rtl::finished(true);
    });
    })
        : prism_rtl::is<Spot::SpotExpr>(std::get<0>(_m)) ? prism_rtl::finished(true)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SpotKeepsWithin, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_spot_keeps_within(Spot spot0, Nat n1) {
    return prism_rtl::make_rc<SpotKeepsWithin>(spot0, n1);
}


/// WithinBlock: unbounded fn (Text ==> Rel), Nat, Block -> Bool
bool within_block(const Map<Text, Rel>& m, const Nat& i, const crate::ast::Block& b) {
    return within(block_rels(b.stmts, m), i, last_or(b));
}


prism_rtl::Turn<bool> WithinBlock::cycle() const {
    const auto& m = this->m;
    const auto& i = this->i;
    const auto& b = this->b;
    auto b_1 = b;
    auto i_2 = i;
    auto m_3 = m;
    return call_then(start_block_rels(b_1.stmts, m_3), [=](Map<Text, Rel> block_rels_105189) { return prism_rtl::more(prism_rtl::rc(Within(block_rels_105189, i_2, last_or(b_1)))); });
}


/// `Start WithinBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_within_block(Map<Text, Rel> m, Nat i, crate::ast::Block b) {
    return prism_rtl::make_rc<WithinBlock>(m, i, b);
}


/// StepWithin: unbounded fn (Text ==> Rel), Nat, Text, Expr, Expr, Nat, Expr -> Bool
bool step_within(const Map<Text, Rel>& m, const Nat& i, const Text& f, const crate::ast::Expr& coll, const crate::ast::Expr& step_, const Nat& at_, const crate::ast::Expr& z) {
    return pre_is(m, f, Text::lit("Filter"))
        ? true
        : ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = step_.kind;
        if (prism_rtl::is<crate::ast::ExprKind::ELambda>(_m) && prism_rtl::is_some(prism_rtl::as<crate::ast::ExprKind::ELambda>(_m).a0)) {
            auto&& ps = prism_rtl::some_of(prism_rtl::as<crate::ast::ExprKind::ELambda>(_m).a0);
            auto&& body = prism_rtl::as<crate::ast::ExprKind::ELambda>(_m).a1;
            _v.set(({
                auto sm = step_rels(m, coll, ps, at_);
                auto [bm, x] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<Map<Text, Rel>, crate::ast::Expr>> _v;
                    auto&& _m = body;
                    if (prism_rtl::is<crate::ast::LambdaBody::LbExpr>(_m)) {
                        auto&& y = prism_rtl::as<crate::ast::LambdaBody::LbExpr>(_m).a0;
                        _v.set(std::tuple{sm, y});
                        goto _done;
                    }
                    if (prism_rtl::is<crate::ast::LambdaBody::LbBlock>(_m)) {
                        auto&& b = prism_rtl::as<crate::ast::LambdaBody::LbBlock>(_m).a0;
                        _v.set(std::tuple{block_rels(b.stmts, sm), last_or(b)});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                pre_is(m, f, Text::lit("Each"))
                ? part(bm, i, x)
                : ({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = index(ps, Nat(0u));
                if (prism_rtl::is_some(_m)) {
                    auto&& acc = prism_rtl::some_of(_m);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<bool> _v;
                        auto&& _m = acc.kind;
                        if (prism_rtl::is<crate::ast::PatternKind::PName>(_m)) {
                            auto&& n = prism_rtl::as<crate::ast::PatternKind::PName>(_m).a0;
                            _v.set(within(m, i, z) && builds_on(bm, i, crate::check_env::sname_key(n), x));
                            goto _done;
                        }
                        {
                            _v.set(false);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(false);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<bool> StepWithin::cycle() const {
    const auto& m = this->m;
    const auto& i = this->i;
    const auto& f = this->f;
    const auto& coll = this->coll;
    const auto& step_ = this->step_;
    const auto& at_ = this->at_;
    const auto& z = this->z;
    return pre_is(m, f, Text::lit("Filter"))
        ? prism_rtl::finished(true)
        : ({
        auto&& _m = step_.kind;
        prism_rtl::is<crate::ast::ExprKind::ELambda>(_m) && prism_rtl::is_some(prism_rtl::as<crate::ast::ExprKind::ELambda>(_m).a0) ? ({
        auto&& ps = prism_rtl::some_of(prism_rtl::as<crate::ast::ExprKind::ELambda>(_m).a0);
        auto&& body = prism_rtl::as<crate::ast::ExprKind::ELambda>(_m).a1;
        ({
        auto at__1 = at_;
        auto body_2 = body;
        auto coll_3 = coll;
        auto f_4 = f;
        auto i_5 = i;
        auto m_6 = m;
        auto ps_7 = ps;
        auto z_8 = z;
        call_then(start_step_rels(m_6, coll_3, ps_7, at__1), [=](Map<Text, Rel> step_rels_105619) {
        return ({
            auto sm = step_rels_105619;
            auto [bm, x] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Map<Text, Rel>, crate::ast::Expr>> _v;
                if (prism_rtl::is<crate::ast::LambdaBody::LbExpr>(body)) {
                    auto&& y = prism_rtl::as<crate::ast::LambdaBody::LbExpr>(body).a0;
                    _v.set(std::tuple{sm, y});
                    goto _done;
                }
                if (prism_rtl::is<crate::ast::LambdaBody::LbBlock>(body)) {
                    auto&& b = prism_rtl::as<crate::ast::LambdaBody::LbBlock>(body).a0;
                    _v.set(std::tuple{block_rels(b.stmts, sm), last_or(b)});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            pre_is(m_6, f_4, Text::lit("Each"))
            ? prism_rtl::more(prism_rtl::rc(Part(bm, i_5, x)))
            : ({
            auto&& _m = index(ps_7, Nat(0u));
            prism_rtl::is_some(_m) ? ({
            auto&& acc = prism_rtl::some_of(_m);
            ({
            auto&& _m = acc.kind;
            prism_rtl::is<crate::ast::PatternKind::PName>(_m) ? ({
            auto&& n = prism_rtl::as<crate::ast::PatternKind::PName>(_m).a0;
            ({
            auto n_9 = n;
            call_then(start_within(m_6, i_5, z_8), [=](bool within_105936) { return prism_rtl::finished(within_105936 && builds_on(bm, i_5, crate::check_env::sname_key(n_9), x)); });
        });
        })
            : prism_rtl::finished(false);
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
    });
    })
        : prism_rtl::finished(false);
    });
}


/// `Start StepWithin, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_step_within(Map<Text, Rel> m, Nat i, Text f, crate::ast::Expr coll, crate::ast::Expr step_, Nat at_, crate::ast::Expr z) {
    return prism_rtl::make_rc<StepWithin>(m, i, f, coll, step_, at_, z);
}


/// LastOr: fn Block -> Expr
crate::ast::Expr last_or(const crate::ast::Block& b) {
    return or_(last_expr(b), dummy_arg()->value);
}


/// BuildsOn: unbounded fn (Text ==> Rel), Nat, Text, Expr -> Bool
bool builds_on(const Map<Text, Rel>& m, const Nat& i, const Text& acc, const crate::ast::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::ast::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::ast::ExprKind::EName>(_m).a0;
        return crate::check_env::sname_key(n) == acc;
    }
    if (prism_rtl::is<crate::ast::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::ast::ExprKind::EGroup>(_m).a0;
        return builds_on(m, i, acc, x);
    }
    if (prism_rtl::is<crate::ast::ExprKind::EMatch>(_m)) {
        auto&& s = prism_rtl::as<crate::ast::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<crate::ast::ExprKind::EMatch>(_m).a1;
        return run_to_end(fold_job(arms, true, ({
            auto acc_1 = acc;
            auto s_2 = s;
            auto m_3 = m;
            auto i_4 = i;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::ast::Arm>)>>(prism_rtl::rc([=](std::tuple<bool, crate::ast::Arm> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto acc_1_5 = acc_1;
                auto s_2_5 = s_2;
                auto m_3_5 = m_3;
                auto i_4_5 = i_4;
                entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto a = p1;
                    (prism_rtl::finished((ok && (!crate::check_types::has_text(opt_names(a.pattern), acc_1_5))) && builds_on_block(arm_pat_rels(s_2_5, a, m_3_5), i_4_5, acc_1_5, a.body)));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::ast::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<crate::ast::ExprKind::EIf>(_m).a2)) {
        auto&& c = prism_rtl::as<crate::ast::ExprKind::EIf>(_m).a0;
        auto&& t = prism_rtl::as<crate::ast::ExprKind::EIf>(_m).a1;
        auto&& el = prism_rtl::some_of(prism_rtl::as<crate::ast::ExprKind::EIf>(_m).a2);
        return ((!crate::check_types::has_text(cond_names(c), acc)) && builds_on_block(cond_rels(c, m), i, acc, t)) && builds_on_block(m, i, acc, el);
    }
    {
        auto&& _m = call_of(e);
        if (prism_rtl::is_some(_m)) {
            auto&& c = std::get<0>(prism_rtl::some_of(_m));
            auto&& args = std::get<1>(prism_rtl::some_of(_m));
            return builds_on_call(m, i, acc, c, args);
        }
        if (prism_rtl::is_none(_m)) {
            return false;
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<bool> BuildsOn::cycle() const {
    const auto& m = this->m;
    const auto& i = this->i;
    const auto& acc = this->acc;
    const auto& e = this->e;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::ast::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::ast::ExprKind::EName>(_m).a0;
        prism_rtl::finished(crate::check_env::sname_key(n) == acc);
    })
        : prism_rtl::is<crate::ast::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::ast::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(BuildsOn(m, i, acc, x)));
    })
        : prism_rtl::is<crate::ast::ExprKind::EMatch>(_m) ? ({
        auto&& s = prism_rtl::as<crate::ast::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<crate::ast::ExprKind::EMatch>(_m).a1;
        fold_job(arms, true, ({
        auto acc_1 = acc;
        auto s_2 = s;
        auto m_3 = m;
        auto i_4 = i;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::ast::Arm>)>>(prism_rtl::rc([=](std::tuple<bool, crate::ast::Arm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto acc_1_5 = acc_1;
            auto s_2_5 = s_2;
            auto m_3_5 = m_3;
            auto i_4_5 = i_4;
            entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto a = p1;
                (prism_rtl::finished((ok && (!crate::check_types::has_text(opt_names(a.pattern), acc_1_5))) && builds_on_block(arm_pat_rels(s_2_5, a, m_3_5), i_4_5, acc_1_5, a.body)));
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::ast::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<crate::ast::ExprKind::EIf>(_m).a2) ? ({
        auto&& c = prism_rtl::as<crate::ast::ExprKind::EIf>(_m).a0;
        auto&& t = prism_rtl::as<crate::ast::ExprKind::EIf>(_m).a1;
        auto&& el = prism_rtl::some_of(prism_rtl::as<crate::ast::ExprKind::EIf>(_m).a2);
        ({
        auto acc_1 = acc;
        auto c_2 = c;
        auto el_3 = el;
        auto i_4 = i;
        auto m_5 = m;
        auto t_6 = t;
        call_then(start_cond_names(c_2), [=](Array<Text> cond_names_106650) { return prism_rtl::finished(((!crate::check_types::has_text(cond_names_106650, acc_1)) && builds_on_block(cond_rels(c_2, m_5), i_4, acc_1, t_6)) && builds_on_block(m_5, i_4, acc_1, el_3)); });
    });
    })
        : ({
        auto&& _m = call_of(e);
        prism_rtl::is_some(_m) ? ({
        auto&& c = std::get<0>(prism_rtl::some_of(_m));
        auto&& args = std::get<1>(prism_rtl::some_of(_m));
        prism_rtl::more(prism_rtl::rc(BuildsOnCall(m, i, acc, c, args)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
        : throw prism_rtl::Panic("no arm matched");
    });
    });
}


/// `Start BuildsOn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_builds_on(Map<Text, Rel> m, Nat i, Text acc, crate::ast::Expr e) {
    return prism_rtl::make_rc<BuildsOn>(m, i, acc, e);
}


/// BuildsOnCall: unbounded fn (Text ==> Rel), Nat, Text, Expr, [Arg] -> Bool
bool builds_on_call(const Map<Text, Rel>& m, const Nat& i, const Text& acc, const crate::ast::Expr& c, const Array<crate::ast::Arg>& args) {
    auto f = expr_name(c);
    auto on_acc = builds_on(m, i, acc, or_(index(args, Nat(0u)), dummy_arg())->value);
    auto rest = each(drop(args, Nat(1u)), [&](const crate::ast::Arg& a) { return a->value; });
    auto parts = run_to_end(fold_job(rest, true, ({
        auto m_1 = m;
        auto i_2 = i;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::ast::Expr>)>>(prism_rtl::rc([=](std::tuple<bool, crate::ast::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_1_3 = m_1;
            auto i_2_3 = i_2;
            entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto x = p1;
                (prism_rtl::finished(ok && part(m_1_3, i_2_3, x)));
            });
        }));
        });
    })));
    })));
    return !on_acc
        ? false
        : pre_is(m, f, Text::lit("Push")) && (len(rest) == Nat(1u))
        ? parts
        : pre_is(m, f, Text::lit("Insert")) && (len(rest) == Nat(2u))
        ? parts
        : pre_is(m, f, Text::lit("Append")) && (len(rest) == Nat(1u))
        ? within(m, i, or_(index(rest, Nat(0u)), dummy_arg()->value))
        : false;
}


prism_rtl::Turn<bool> BuildsOnCall::cycle() const {
    const auto& m = this->m;
    const auto& i = this->i;
    const auto& acc = this->acc;
    const auto& c = this->c;
    const auto& args = this->args;
    auto f = expr_name(c);
    auto acc_1 = acc;
    auto args_2 = args;
    auto i_3 = i;
    auto m_4 = m;
    return call_then(start_builds_on(m_4, i_3, acc_1, or_(index(args_2, Nat(0u)), dummy_arg())->value), [=](bool builds_on_107080) {
        return ({
            auto on_acc = builds_on_107080;
            auto rest = each(drop(args_2, Nat(1u)), [&](const crate::ast::Arg& a) { return a->value; });
            call_value(fold_job(rest, true, ({
            auto m_4_5 = m_4;
            auto i_3_5 = i_3;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::ast::Expr>)>>(prism_rtl::rc([=](std::tuple<bool, crate::ast::Expr> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto m_4_5_5 = m_4_5;
                auto i_3_5_5 = i_3_5;
                entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto x = p1;
                    (prism_rtl::finished(ok && part(m_4_5_5, i_3_5_5, x)));
                });
            }));
            });
        })));
        })), [=](bool fold_107194) {
            return ({
                auto parts = fold_107194;
                !on_acc
                ? prism_rtl::finished(false)
                : pre_is(m_4, f, Text::lit("Push")) && (len(rest) == Nat(1u))
                ? prism_rtl::finished(parts)
                : pre_is(m_4, f, Text::lit("Insert")) && (len(rest) == Nat(2u))
                ? prism_rtl::finished(parts)
                : pre_is(m_4, f, Text::lit("Append")) && (len(rest) == Nat(1u))
                ? prism_rtl::more(prism_rtl::rc(Within(m_4, i_3, or_(index(rest, Nat(0u)), dummy_arg()->value))))
                : prism_rtl::finished(false);
            });
        });
        });
    });
}


/// `Start BuildsOnCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_builds_on_call(Map<Text, Rel> m, Nat i, Text acc, crate::ast::Expr c, Array<crate::ast::Arg> args) {
    return prism_rtl::make_rc<BuildsOnCall>(m, i, acc, c, args);
}


/// BuildsOnBlock: unbounded fn (Text ==> Rel), Nat, Text, Block -> Bool
bool builds_on_block(const Map<Text, Rel>& m, const Nat& i, const Text& acc, const crate::ast::Block& b) {
    return (!crate::check_types::has_text(stmts_binders(b.stmts), acc)) && builds_on(block_rels(b.stmts, m), i, acc, last_or(b));
}


prism_rtl::Turn<bool> BuildsOnBlock::cycle() const {
    const auto& m = this->m;
    const auto& i = this->i;
    const auto& acc = this->acc;
    const auto& b = this->b;
    auto acc_1 = acc;
    auto b_2 = b;
    auto i_3 = i;
    auto m_4 = m;
    return call_then(start_stmts_binders(b_2.stmts), [=](Array<Text> stmts_binders_107754) { return prism_rtl::finished((!crate::check_types::has_text(stmts_binders_107754, acc_1)) && builds_on(block_rels(b_2.stmts, m_4), i_3, acc_1, last_or(b_2))); });
}


/// `Start BuildsOnBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_builds_on_block(Map<Text, Rel> m, Nat i, Text acc, crate::ast::Block b) {
    return prism_rtl::make_rc<BuildsOnBlock>(m, i, acc, b);
}


/// CondNames: unbounded fn Cond -> [Text]
Array<Text> cond_names(const crate::ast::Cond& cond0) {
    if (prism_rtl::is<crate::ast::Cond::CondBind>(cond0)) {
        auto&& p_ = prism_rtl::as<crate::ast::Cond::CondBind>(cond0).a0;
        return crate::check_env::pattern_names(p_);
    }
    if (prism_rtl::is<crate::ast::Cond::CondExpr>(cond0)) {
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> CondNames::cycle() const {
    const auto& cond0 = this->cond0;
    return ({
        prism_rtl::is<crate::ast::Cond::CondBind>(cond0) ? ({
        auto&& p_ = prism_rtl::as<crate::ast::Cond::CondBind>(cond0).a0;
        prism_rtl::more(prism_rtl::rc(crate::check_env::PatternNames(p_)));
    })
        : prism_rtl::is<crate::ast::Cond::CondExpr>(cond0) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CondNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_cond_names(crate::ast::Cond cond0) {
    return prism_rtl::make_rc<CondNames>(cond0);
}


/// Part: unbounded fn (Text ==> Rel), Nat, Expr -> Bool
bool part(const Map<Text, Rel>& m, const Nat& i, const crate::ast::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::ast::ExprKind::ETuple>(_m)) {
        auto&& es = prism_rtl::as<crate::ast::ExprKind::ETuple>(_m).a0;
        return run_to_end(fold_job(es, true, ({
            auto m_1 = m;
            auto i_2 = i;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::ast::Expr>)>>(prism_rtl::rc([=](std::tuple<bool, crate::ast::Expr> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto m_1_3 = m_1;
                auto i_2_3 = i_2;
                entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto x = p1;
                    (prism_rtl::finished(ok && part(m_1_3, i_2_3, x)));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::ast::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::ast::ExprKind::EGroup>(_m).a0;
        return part(m, i, x);
    }
    {
        auto&& _m = rel_of(m, e);
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            return (r.param == i) && r.strict;
        }
        if (prism_rtl::is_none(_m)) {
            return false;
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<bool> Part::cycle() const {
    const auto& m = this->m;
    const auto& i = this->i;
    const auto& e = this->e;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::ast::ExprKind::ETuple>(_m) ? ({
        auto&& es = prism_rtl::as<crate::ast::ExprKind::ETuple>(_m).a0;
        fold_job(es, true, ({
        auto m_1 = m;
        auto i_2 = i;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::ast::Expr>)>>(prism_rtl::rc([=](std::tuple<bool, crate::ast::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_1_3 = m_1;
            auto i_2_3 = i_2;
            entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto x = p1;
                (prism_rtl::finished(ok && part(m_1_3, i_2_3, x)));
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::ast::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::ast::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(Part(m, i, x)));
    })
        : ({
        auto e_1 = e;
        auto i_2 = i;
        auto m_3 = m;
        call_then(start_rel_of(m_3, e_1), [=](std::optional<Rel> rel_of_108169) {
        return ({
            prism_rtl::is_some(rel_of_108169) ? ({
            auto&& r = prism_rtl::some_of(rel_of_108169);
            prism_rtl::finished((r.param == i_2) && r.strict);
        })
            : prism_rtl::is_none(rel_of_108169) ? prism_rtl::finished(false)
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    });
    });
}


/// `Start Part, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_part(Map<Text, Rel> m, Nat i, crate::ast::Expr e) {
    return prism_rtl::make_rc<Part>(m, i, e);
}


/// SummarySeeds: unbounded fn Shrink, Def, [Spot], (Text ==> Rel) -> (Text ==> Rel)
Map<Text, Rel> summary_seeds(const Shrink& sk, const crate::check_env::Def& d, const Array<Spot>& spots, const Map<Text, Rel>& rels) {
    return fold(run_to_end(fold_job(spots, Array<Site>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Site>>(std::tuple<Array<Site>, Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Site>, Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto sp = p1;
                call_then(start_spot_sites(sp), [=](Array<Site> spot_sites_108845) { return prism_rtl::finished(append(acc, spot_sites_108845)); });
            });
        }));
    })))), rels, [&](const Map<Text, Rel>& m, const Site& site) {
        return is_local(site.rels, site.callee)
            ? m
            : ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, Rel>> _v;
            auto&& _m = resolve_callee(sk.g, d.home, site.callee);
            if (prism_rtl::is_some(_m)) {
                auto&& k = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Map<Text, Rel>> _v;
                    auto&& _m = prelude::get(sk.sums, k);
                    if (prism_rtl::is_some(_m)) {
                        auto&& i = prism_rtl::some_of(_m);
                        _v.set(insert(m, prism_rtl::cat("fn:", site.callee), Rel{.param = i, .strict = false}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(is_no_larger_prelude(sk.g, k)
                            ? insert(m, prism_rtl::cat("fn:", site.callee), Rel{.param = Nat(0u), .strict = false})
                            : m);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(m);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Map<Text, Rel>> SummarySeeds::cycle() const {
    const auto& sk = this->sk;
    const auto& d = this->d;
    const auto& spots = this->spots;
    const auto& rels = this->rels;
    auto d_1 = d;
    auto rels_2 = rels;
    auto sk_3 = sk;
    auto spots_4 = spots;
    return call_value(fold_job(spots_4, Array<Site>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Site>>(std::tuple<Array<Site>, Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Site>, Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto sp = p1;
                call_then(start_spot_sites(sp), [=](Array<Site> spot_sites_108845) { return prism_rtl::finished(append(acc, spot_sites_108845)); });
            });
        }));
    }))), [=](Array<Site> fold_108803) {
        return prism_rtl::finished(fold(fold_108803, rels_2, [&](const Map<Text, Rel>& m, const Site& site) {
            return is_local(site.rels, site.callee)
                ? m
                : ({
                __label__ _done;
                prism_rtl::Slot<Map<Text, Rel>> _v;
                auto&& _m = resolve_callee(sk_3.g, d_1.home, site.callee);
                if (prism_rtl::is_some(_m)) {
                    auto&& k = prism_rtl::some_of(_m);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Map<Text, Rel>> _v;
                        auto&& _m = prelude::get(sk_3.sums, k);
                        if (prism_rtl::is_some(_m)) {
                            auto&& i = prism_rtl::some_of(_m);
                            _v.set(insert(m, prism_rtl::cat("fn:", site.callee), Rel{.param = i, .strict = false}));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(is_no_larger_prelude(sk_3.g, k)
                                ? insert(m, prism_rtl::cat("fn:", site.callee), Rel{.param = Nat(0u), .strict = false})
                                : m);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(m);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        }));
    });
}


/// `Start SummarySeeds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Rel>> start_summary_seeds(Shrink sk, crate::check_env::Def d, Array<Spot> spots, Map<Text, Rel> rels) {
    return prism_rtl::make_rc<SummarySeeds>(sk, d, spots, rels);
}


/// OptNames: unbounded fn ?Pattern -> [Text]
Array<Text> opt_names(const std::optional<crate::ast::Pattern_>& opt0) {
    if (prism_rtl::is_some(opt0)) {
        auto&& p_ = prism_rtl::some_of(opt0);
        return crate::check_env::pattern_names(p_);
    }
    if (prism_rtl::is_none(opt0)) {
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> OptNames::cycle() const {
    const auto& opt0 = this->opt0;
    return ({
        prism_rtl::is_some(opt0) ? ({
        auto&& p_ = prism_rtl::some_of(opt0);
        prism_rtl::more(prism_rtl::rc(crate::check_env::PatternNames(p_)));
    })
        : prism_rtl::is_none(opt0) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start OptNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_opt_names(std::optional<crate::ast::Pattern_> opt0) {
    return prism_rtl::make_rc<OptNames>(opt0);
}


/// let dummyArg
crate::ast::Arg dummy_arg() {
    return crate::ast::Arg{.name = std::optional<crate::ast::Ident>{}, .value = crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EError{})), .span = crate::ast::Range{.start = Nat(0u), .end = Nat(0u)}}, .span = crate::ast::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// ?DecrementOf: unbounded fn (Text ==> Rel), Expr -> ?Rel
std::optional<Rel> decrement_of(const Map<Text, Rel>& m, const crate::ast::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::ast::ExprKind::EBinary>(_m)) {
        auto&& m109653_0_0 = prism_rtl::as<crate::ast::ExprKind::EBinary>(_m).a0;
        auto&& l = prism_rtl::as<crate::ast::ExprKind::EBinary>(_m).a1;
        auto&& r = prism_rtl::as<crate::ast::ExprKind::EBinary>(_m).a2;
        if (m109653_0_0 == Text::lit("-?")) {
            return is_positive_lit(r) && is_nat_minus(m, e)
                ? smaller(m, l)
                : std::optional<Rel>{};
        }
    }
    if (prism_rtl::is<crate::ast::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::ast::ExprKind::EGroup>(_m).a0;
        return decrement_of(m, x);
    }
    {
        auto&& _m = call_of(e);
        if (prism_rtl::is_some(_m)) {
            auto&& c = std::get<0>(prism_rtl::some_of(_m));
            auto&& args = std::get<1>(prism_rtl::some_of(_m));
            auto&& _m = callee_name(c);
            if (prism_rtl::is_some(_m)) {
                auto&& n = prism_rtl::some_of(_m);
                return pre_is(m, n, Text::lit("?Step"))
                    ? smaller(m, or_(index(args, Nat(0u)), dummy_arg())->value)
                    : std::optional<Rel>{};
            }
            if (prism_rtl::is_none(_m)) {
                return std::optional<Rel>{};
            }
            prism_rtl::unreachable("no arm matched");
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional<Rel>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<std::optional<Rel>> DecrementOf::cycle() const {
    const auto& m = this->m;
    const auto& e = this->e;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::ast::ExprKind::EBinary>(_m) && ({
        auto&& m109653_0_0 = prism_rtl::as<crate::ast::ExprKind::EBinary>(_m).a0;
        auto&& l = prism_rtl::as<crate::ast::ExprKind::EBinary>(_m).a1;
        auto&& r = prism_rtl::as<crate::ast::ExprKind::EBinary>(_m).a2;
        (m109653_0_0 == Text::lit("-?"));
    }) ? ({
        auto&& m109653_0_0 = prism_rtl::as<crate::ast::ExprKind::EBinary>(_m).a0;
        auto&& l = prism_rtl::as<crate::ast::ExprKind::EBinary>(_m).a1;
        auto&& r = prism_rtl::as<crate::ast::ExprKind::EBinary>(_m).a2;
        is_positive_lit(r) && is_nat_minus(m, e)
        ? prism_rtl::finished(smaller(m, l))
        : prism_rtl::finished(std::optional<Rel>{});
    })
        : prism_rtl::is<crate::ast::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::ast::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(DecrementOf(m, x)));
    })
        : ({
        auto&& _m = call_of(e);
        prism_rtl::is_some(_m) ? ({
        auto&& c = std::get<0>(prism_rtl::some_of(_m));
        auto&& args = std::get<1>(prism_rtl::some_of(_m));
        ({
        auto&& _m = callee_name(c);
        prism_rtl::is_some(_m) ? ({
        auto&& n = prism_rtl::some_of(_m);
        pre_is(m, n, Text::lit("?Step"))
        ? prism_rtl::finished(smaller(m, or_(index(args, Nat(0u)), dummy_arg())->value))
        : prism_rtl::finished(std::optional<Rel>{});
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<Rel>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<Rel>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    });
}


/// `Start DecrementOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Rel>> start_decrement_of(Map<Text, Rel> m, crate::ast::Expr e) {
    return prism_rtl::make_rc<DecrementOf>(m, e);
}


/// IsNatMinus: fn (Text ==> Rel), Expr -> Bool
bool is_nat_minus(const Map<Text, Rel>& m, const crate::ast::Expr& e) {
    return pre_is(m, Text::lit("-?"), Text::lit("-?")) && is_nat_at(m, e);
}


/// ?Smaller: unbounded fn (Text ==> Rel), Expr -> ?Rel
std::optional<Rel> smaller(const Map<Text, Rel>& m, const crate::ast::Expr& x) {
    auto&& _m = rel_of(m, x);
    if (prism_rtl::is_some(_m)) {
        auto&& r = prism_rtl::some_of(_m);
        return std::optional(Rel{.param = r.param, .strict = true});
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<Rel>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// IsPositiveLit: fn Expr -> Bool
bool is_positive_lit(const crate::ast::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::ast::ExprKind::ELit>(_m)) {
        auto&& l = prism_rtl::as<crate::ast::ExprKind::ELit>(_m).a0;
        auto&& _m = l.kind;
        if (prism_rtl::is<crate::ast::LitKind::LInt>(_m)) {
            auto&& d = prism_rtl::as<crate::ast::LitKind::LInt>(_m).a0;
            return d != Text::lit("0");
        }
        {
            return false;
        }
    }
    if (prism_rtl::is<crate::ast::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::ast::ExprKind::EGroup>(_m).a0;
        return is_positive_lit(x);
    }
    {
        return false;
    }
}


/// Closure: unbounded fn [Sc] -> [Sc]
Array<Sc> closure(const Array<Sc>& graphs) {
    return closure_from(graphs, dedup(graphs), dedup(graphs));
}


prism_rtl::Turn<Array<Sc>> Closure::cycle() const {
    const auto& graphs = this->graphs;
    return prism_rtl::more(prism_rtl::rc(ClosureFrom(graphs, dedup(graphs), dedup(graphs))));
}


/// `Start Closure, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Sc>> start_closure(Array<Sc> graphs) {
    return prism_rtl::make_rc<Closure>(graphs);
}


/// Dedup: fn [Sc] -> [Sc]
Array<Sc> dedup(const Array<Sc>& gs) {
    return fold(gs, Array<Sc>{}, [&](const Array<Sc>& acc, const Sc& g) { return has_sc(acc, g) ? acc : prelude::push(acc, g); });
}


/// ClosureFrom: unbounded fn [Sc], [Sc], [Sc] -> [Sc]
Array<Sc> closure_from(const Array<Sc>& base, const Array<Sc>& acc, const Array<Sc>& frontier) {
    auto fresh = fold(frontier, Array<Sc>{}, [&](const Array<Sc>& out, const Sc& a) { return fold(base, out, [&](const Array<Sc>& out2, const Sc& b) { return add_composed(acc, out2, a, b); }); });
    return len(fresh) == Nat(0u) ? acc : closure_from(base, append(acc, fresh), fresh);
}


prism_rtl::Turn<Array<Sc>> ClosureFrom::cycle() const {
    const auto& base = this->base;
    const auto& acc = this->acc;
    const auto& frontier = this->frontier;
    auto fresh = fold(frontier, Array<Sc>{}, [&](const Array<Sc>& out, const Sc& a) { return fold(base, out, [&](const Array<Sc>& out2, const Sc& b) { return add_composed(acc, out2, a, b); }); });
    return len(fresh) == Nat(0u)
        ? prism_rtl::finished(acc)
        : prism_rtl::more(prism_rtl::rc(ClosureFrom(base, append(acc, fresh), fresh)));
}


/// `Start ClosureFrom, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Sc>> start_closure_from(Array<Sc> base, Array<Sc> acc, Array<Sc> frontier) {
    return prism_rtl::make_rc<ClosureFrom>(base, acc, frontier);
}


/// AddComposed: fn [Sc], [Sc], Sc, Sc -> [Sc]
Array<Sc> add_composed(const Array<Sc>& acc, const Array<Sc>& out, const Sc& a, const Sc& b) {
    return a.callee != b.caller
        ? out
        : ({
        auto c = compose(a, b);
        has_sc(acc, c) || has_sc(out, c) ? out : prelude::push(out, c);
    });
}


/// HasSc: fn [Sc], Sc -> Bool
bool has_sc(const Array<Sc>& xs, const Sc& c) {
    return fold(xs, false, [&](const bool& seen, const Sc& x) { return seen || (((x.caller == c.caller) && (x.callee == c.callee)) && (x->edges == c->edges)); });
}


/// Compose: fn Sc, Sc -> Sc
Sc compose(const Sc& a, const Sc& b) {
    auto pairs = fold(a->edges, Array<std::tuple<Nat, Nat, bool>>{}, [&](const Array<std::tuple<Nat, Nat, bool>>& acc, const std::tuple<Nat, Nat, bool>& _p1) {
        auto&& x = std::get<0>(_p1);
        auto&& y = std::get<1>(_p1);
        auto&& s1 = std::get<2>(_p1);
        return fold(b->edges, acc, [&](const Array<std::tuple<Nat, Nat, bool>>& acc2, const std::tuple<Nat, Nat, bool>& _p1) {
            auto&& y2 = std::get<0>(_p1);
            auto&& z = std::get<1>(_p1);
            auto&& s2 = std::get<2>(_p1);
            return y == y2 ? add_edge(acc2, x, z, s1 || s2) : acc2;
        });
    });
    return Sc{.caller = a.caller, .callee = b.callee, .edges = sort_edges(pairs), .span = a.span, .file = a->file, .arg = a.arg};
}


/// AddEdge: fn [((Nat, Nat, Bool))], Nat, Nat, Bool -> [((Nat, Nat, Bool))]
Array<std::tuple<Nat, Nat, bool>> add_edge(const Array<std::tuple<Nat, Nat, bool>>& es, const Nat& x, const Nat& z, const bool& s) {
    auto others = filter(es, [&](const std::tuple<Nat, Nat, bool>& _p0) {
        auto&& a = std::get<0>(_p0);
        auto&& b = std::get<1>(_p0);
        return !((a == x) && (b == z));
    });
    auto had = fold(es, false, [&](const bool& seen, const std::tuple<Nat, Nat, bool>& _p1) {
        auto&& a = std::get<0>(_p1);
        auto&& b = std::get<1>(_p1);
        auto&& t = std::get<2>(_p1);
        return seen || (((a == x) && (b == z)) && t);
    });
    return prelude::push(others, std::tuple{x, z, s || had});
}


/// SortEdges: fn [((Nat, Nat, Bool))] -> [((Nat, Nat, Bool))]
Array<std::tuple<Nat, Nat, bool>> sort_edges(const Array<std::tuple<Nat, Nat, bool>>& es) {
    return fold(es, Array<std::tuple<Nat, Nat, bool>>{}, [&](const Array<std::tuple<Nat, Nat, bool>>& acc, const std::tuple<Nat, Nat, bool>& e) { return append(prelude::push(filter(acc, [&](const std::tuple<Nat, Nat, bool>& x) { return edge_before(x, e); }), e), filter(acc, [&](const std::tuple<Nat, Nat, bool>& x) { return !edge_before(x, e); })); });
}


/// EdgeBefore: fn ((Nat, Nat, Bool)), ((Nat, Nat, Bool)) -> Bool
bool edge_before(const std::tuple<Nat, Nat, bool>& arg0, const std::tuple<Nat, Nat, bool>& arg1) {
    auto&& _m = std::tuple{arg0, arg1};
    {
        auto&& a1 = std::get<0>(std::get<0>(_m));
        auto&& b1 = std::get<1>(std::get<0>(_m));
        auto&& a2 = std::get<0>(std::get<1>(_m));
        auto&& b2 = std::get<1>(std::get<1>(_m));
        return (a1 < a2) || ((a1 == a2) && (b1 < b2));
    }
    prism_rtl::unreachable("no arm matched");
}


/// LoopsOf: unbounded fn Shrink, St, Def -> St
crate::check_types::St loops_of(const Shrink& sk, const crate::check_types::St& st, const crate::check_env::Def& d) {
    auto unb = is_unbounded_key(sk.g, sig_key_of(sk, d.qk));
    return unb && (!st.recording)
        ? st
        : ({
        auto s0 = ({
            crate::check_types::St this_ = st;
            this_.file = d->file;
            this_;
        });
        auto s1 = run_to_end(fold_job(def_clauses(d), s0, ({
            auto sk_1 = sk;
            auto d_2 = d;
            auto unb_3 = unb;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check_types::St>(std::tuple<crate::check_types::St, crate::ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<crate::check_types::St, crate::ast::FnClause> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto sk_1_4 = sk_1;
                auto d_2_4 = d_2;
                auto unb_3_4 = unb_3;
                entered(once_job([=]() {
                return ({
                    auto s = p0;
                    auto c = p1;
                    (prism_rtl::more(prism_rtl::rc(ClauseLoops(sk_1_4, s, d_2_4, c, unb_3_4))));
                });
            }));
            });
        })));
        })));
        ({
        crate::check_types::St this_ = s1;
        this_.file = st->file;
        this_;
    });
    });
}


prism_rtl::Turn<crate::check_types::St> LoopsOf::cycle() const {
    const auto& sk = this->sk;
    const auto& st = this->st;
    const auto& d = this->d;
    auto unb = is_unbounded_key(sk.g, sig_key_of(sk, d.qk));
    return unb && (!st.recording)
        ? prism_rtl::finished(st)
        : ({
        auto s0 = ({
            crate::check_types::St this_ = st;
            this_.file = d->file;
            this_;
        });
        auto d_1 = d;
        auto sk_2 = sk;
        auto st_3 = st;
        call_value(fold_job(def_clauses(d_1), s0, ({
        auto sk_2_4 = sk_2;
        auto d_1_4 = d_1;
        auto unb_4 = unb;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check_types::St>(std::tuple<crate::check_types::St, crate::ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<crate::check_types::St, crate::ast::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_2_4_5 = sk_2_4;
            auto d_1_4_5 = d_1_4;
            auto unb_4_5 = unb_4;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto c = p1;
                (prism_rtl::more(prism_rtl::rc(ClauseLoops(sk_2_4_5, s, d_1_4_5, c, unb_4_5))));
            });
        }));
        });
    })));
    })), [=](crate::check_types::St fold_113624) {
        return ({
            auto s1 = fold_113624;
            (prism_rtl::finished(({
            crate::check_types::St this_ = s1;
            this_.file = st_3->file;
            this_;
        })));
        });
    });
    });
}


/// `Start LoopsOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check_types::St> start_loops_of(Shrink sk, crate::check_types::St st, crate::check_env::Def d) {
    return prism_rtl::make_rc<LoopsOf>(sk, st, d);
}


/// ClauseLoops: unbounded fn Shrink, St, Def, FnClause, Bool -> St
crate::check_types::St clause_loops(const Shrink& sk, const crate::check_types::St& st, const crate::check_env::Def& d, const crate::ast::FnClause& c, const bool& unb) {
    auto base = clause_base(sk, d, c);
    auto spots0 = body_spots(c.body, base);
    return !fold(spots0, false, [&](const bool& seen, const Spot& sp) { return seen || is_while_spot(sp); })
        ? st
        : ({
        auto spots = body_spots(c.body, summary_seeds(sk, d, spots0, base));
        run_to_end(fold_job(filter(spots, [&](const Spot& sp) { return is_while_spot(sp); }), st, ({
        auto d_1 = d;
        auto unb_2 = unb;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check_types::St>(std::tuple<crate::check_types::St, Spot>)>>(prism_rtl::rc([=](std::tuple<crate::check_types::St, Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto d_1_3 = d_1;
            auto unb_2_3 = unb_2;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto sp = p1;
                ({
                prism_rtl::is<Spot::SpotStmt>(sp) ? ({
                auto&& w = prism_rtl::as<Spot::SpotStmt>(sp).a0;
                auto&& m = prism_rtl::as<Spot::SpotStmt>(sp).a1;
                ({
                auto&& _m = w.kind;
                prism_rtl::is<crate::ast::StmtKind::SWhile>(_m) ? ({
                auto&& cond = prism_rtl::as<crate::ast::StmtKind::SWhile>(_m).a0;
                auto&& body = prism_rtl::as<crate::ast::StmtKind::SWhile>(_m).a1;
                prism_rtl::more(prism_rtl::rc(CheckWhile(s, cond, body, w.span, d_1_3.name, marks(m), unb_2_3)));
            })
                : prism_rtl::finished(s);
            });
            })
                : prism_rtl::finished(s);
            });
            });
        }));
        });
    })));
    })));
    });
}


prism_rtl::Turn<crate::check_types::St> ClauseLoops::cycle() const {
    const auto& sk = this->sk;
    const auto& st = this->st;
    const auto& d = this->d;
    const auto& c = this->c;
    const auto& unb = this->unb;
    auto c_1 = c;
    auto d_2 = d;
    auto sk_3 = sk;
    auto st_4 = st;
    auto unb_5 = unb;
    return call_then(start_clause_base(sk_3, d_2, c_1), [=](Map<Text, Rel> clause_base_113850) {
        return ({
            auto base = clause_base_113850;
            call_then(start_body_spots(c_1.body, base), [=](Array<Spot> body_spots_113887) {
            return ({
                auto spots0 = body_spots_113887;
                !fold(spots0, false, [&](const bool& seen, const Spot& sp) { return seen || is_while_spot(sp); })
                ? prism_rtl::finished(st_4)
                : call_then(start_summary_seeds(sk_3, d_2, spots0, base), [=](Map<Text, Rel> summary_seeds_114031) {
                return call_then(start_body_spots(c_1.body, summary_seeds_114031), [=](Array<Spot> body_spots_114012) {
                    return ({
                        auto spots = body_spots_114012;
                        fold_job(filter(spots, [&](const Spot& sp) { return is_while_spot(sp); }), st_4, ({
                        auto d_2_6 = d_2;
                        auto unb_5_6 = unb_5;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check_types::St>(std::tuple<crate::check_types::St, Spot>)>>(prism_rtl::rc([=](std::tuple<crate::check_types::St, Spot> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto d_2_6_6 = d_2_6;
                            auto unb_5_6_6 = unb_5_6;
                            entered(once_job([=]() {
                            return ({
                                auto s = p0;
                                auto sp = p1;
                                ({
                                prism_rtl::is<Spot::SpotStmt>(sp) ? ({
                                auto&& w = prism_rtl::as<Spot::SpotStmt>(sp).a0;
                                auto&& m = prism_rtl::as<Spot::SpotStmt>(sp).a1;
                                ({
                                auto&& _m = w.kind;
                                prism_rtl::is<crate::ast::StmtKind::SWhile>(_m) ? ({
                                auto&& cond = prism_rtl::as<crate::ast::StmtKind::SWhile>(_m).a0;
                                auto&& body = prism_rtl::as<crate::ast::StmtKind::SWhile>(_m).a1;
                                prism_rtl::more(prism_rtl::rc(CheckWhile(s, cond, body, w.span, d_2_6_6.name, marks(m), unb_5_6_6)));
                            })
                                : prism_rtl::finished(s);
                            });
                            })
                                : prism_rtl::finished(s);
                            });
                            });
                        }));
                        });
                    })));
                    }))->cycle();
                    });
                });
            });
            });
        });
        });
    });
}


/// `Start ClauseLoops, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check_types::St> start_clause_loops(Shrink sk, crate::check_types::St st, crate::check_env::Def d, crate::ast::FnClause c, bool unb) {
    return prism_rtl::make_rc<ClauseLoops>(sk, st, d, c, unb);
}


/// Marks: fn (Text ==> Rel) -> (Text ==> Rel)
Map<Text, Rel> marks(const Map<Text, Rel>& m) {
    return fold(keys(m), m, [&](const Map<Text, Rel>& m2, const Text& k) { return crate::lexer::contains(k, Text::lit(":")) ? m2 : prelude::remove(m2, k); });
}


/// IsWhileSpot: fn Spot -> Bool
bool is_while_spot(const Spot& spot0) {
    if (prism_rtl::is<Spot::SpotStmt>(spot0)) {
        auto&& s = prism_rtl::as<Spot::SpotStmt>(spot0).a0;
        auto&& _m = s.kind;
        if (prism_rtl::is<crate::ast::StmtKind::SWhile>(_m)) {
            return true;
        }
        {
            return false;
        }
    }
    if (prism_rtl::is<Spot::SpotExpr>(spot0)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// CheckWhile: unbounded fn St, Cond, Block, Range, Text, (Text ==> Rel), Bool -> St
crate::check_types::St check_while(const crate::check_types::St& st, const crate::ast::Cond& c, const crate::ast::Block& body, const crate::ast::Range& span, const Text& name, const Map<Text, Rel>& seeds, const bool& unb) {
    auto vars = set_targets(body.stmts);
    auto base = fold(crate::check_errors::range0(len(vars)), seeds, [&](const Map<Text, Rel>& m, const Nat& i) { return insert(m, or_(index(vars, i), Text::lit("")), Rel{.param = i, .strict = false}); });
    auto rels = cond_rels(c, base);
    auto ok = run_to_end(fold_job(crate::check_errors::range0(len(vars)), false, ({
        auto body_1 = body;
        auto vars_2 = vars;
        auto rels_3 = rels;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Nat>)>>(prism_rtl::rc([=](std::tuple<bool, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto body_1_4 = body_1;
            auto vars_2_4 = vars_2;
            auto rels_3_4 = rels_3;
            entered(once_job([=]() {
            return ({
                auto seen = p0;
                auto i = p1;
                (prism_rtl::finished(seen || all_paths_strict(body_1_4.stmts, or_(index(vars_2_4, i), Text::lit("")), i, rels_3_4)));
            });
        }));
        });
    })));
    })));
    return ok
        ? st
        : unb
        ? note_unshrunk(st, span)
        : crate::check_types::err_fix(st, Text::lit("may-not-end"), span, prism_rtl::cat("this loop in `", name, "` may not end: nothing it sets gets smaller on every turn"), prism_rtl::cat("set a local from `&x -? 1` through a pattern, as `while ? left <- &fuel -? 1:`, or mark `", name, "` `unbounded fn`"));
}


prism_rtl::Turn<crate::check_types::St> CheckWhile::cycle() const {
    const auto& st = this->st;
    const auto& c = this->c;
    const auto& body = this->body;
    const auto& span = this->span;
    const auto& name = this->name;
    const auto& seeds = this->seeds;
    const auto& unb = this->unb;
    auto body_1 = body;
    auto c_2 = c;
    auto name_3 = name;
    auto seeds_4 = seeds;
    auto span_5 = span;
    auto st_6 = st;
    auto unb_7 = unb;
    return call_then(start_set_targets(body_1.stmts), [=](Array<Text> set_targets_115138) {
        return ({
            auto vars = set_targets_115138;
            auto base = fold(crate::check_errors::range0(len(vars)), seeds_4, [&](const Map<Text, Rel>& m, const Nat& i) { return insert(m, or_(index(vars, i), Text::lit("")), Rel{.param = i, .strict = false}); });
            call_then(start_cond_rels(c_2, base), [=](Map<Text, Rel> cond_rels_115452) {
            return ({
                auto rels = cond_rels_115452;
                call_value(fold_job(crate::check_errors::range0(len(vars)), false, ({
                auto body_1_8 = body_1;
                auto vars_8 = vars;
                auto rels_9 = rels;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Nat>)>>(prism_rtl::rc([=](std::tuple<bool, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto body_1_8_10 = body_1_8;
                    auto vars_8_10 = vars_8;
                    auto rels_9_10 = rels_9;
                    entered(once_job([=]() {
                    return ({
                        auto seen = p0;
                        auto i = p1;
                        (prism_rtl::finished(seen || all_paths_strict(body_1_8_10.stmts, or_(index(vars_8_10, i), Text::lit("")), i, rels_9_10)));
                    });
                }));
                });
            })));
            })), [=](bool fold_115482) {
                return ({
                    auto ok = fold_115482;
                    ok
                    ? prism_rtl::finished(st_6)
                    : unb_7
                    ? prism_rtl::finished(note_unshrunk(st_6, span_5))
                    : prism_rtl::finished(crate::check_types::err_fix(st_6, Text::lit("may-not-end"), span_5, prism_rtl::cat("this loop in `", name_3, "` may not end: nothing it sets gets smaller on every turn"), prism_rtl::cat("set a local from `&x -? 1` through a pattern, as `while ? left <- &fuel -? 1:`, or mark `", name_3, "` `unbounded fn`")));
                });
            });
            });
        });
        });
    });
}


/// `Start CheckWhile, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check_types::St> start_check_while(crate::check_types::St st, crate::ast::Cond c, crate::ast::Block body, crate::ast::Range span, Text name, Map<Text, Rel> seeds, bool unb) {
    return prism_rtl::make_rc<CheckWhile>(st, c, body, span, name, seeds, unb);
}


/// NoteUnshrunk: fn St, Range -> St
crate::check_types::St note_unshrunk(const crate::check_types::St& st, const crate::ast::Range& span) {
    crate::check_types::St this_ = st;
    this_.typed.unshrunk = prelude::push(this_.typed.unshrunk, crate::check_types::at_here(st, span));
    return this_;
}


/// SetTargets: unbounded fn [Stmt] -> [Text]
Array<Text> set_targets(const Array<crate::ast::Stmt>& stmts) {
    return run_to_end(fold_job(stmts_spots(stmts, Map<Text, Rel>{}), Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto sp = p1;
                call_then(start_spot_set_root(sp), [=](Array<Text> spot_set_root_116348) { return prism_rtl::finished(crate::check_types::union_texts(acc, spot_set_root_116348)); });
            });
        }));
    }))));
}


prism_rtl::Turn<Array<Text>> SetTargets::cycle() const {
    const auto& stmts = this->stmts;
    auto stmts_1 = stmts;
    return call_then(start_stmts_spots(stmts_1, Map<Text, Rel>{}), [=](Array<Spot> stmts_spots_116291) {
        return fold_job(stmts_spots_116291, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Spot> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto sp = p1;
                    call_then(start_spot_set_root(sp), [=](Array<Text> spot_set_root_116348) { return prism_rtl::finished(crate::check_types::union_texts(acc, spot_set_root_116348)); });
                });
            }));
        })))->cycle();
    });
}


/// `Start SetTargets, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_set_targets(Array<crate::ast::Stmt> stmts) {
    return prism_rtl::make_rc<SetTargets>(stmts);
}


/// SpotSetRoot: unbounded fn Spot -> [Text]
Array<Text> spot_set_root(const Spot& spot0) {
    if (prism_rtl::is<Spot::SpotStmt>(spot0)) {
        auto&& s = prism_rtl::as<Spot::SpotStmt>(spot0).a0;
        auto&& _m = s.kind;
        if (prism_rtl::is<crate::ast::StmtKind::SSet>(_m)) {
            auto&& t = prism_rtl::as<crate::ast::StmtKind::SSet>(_m).a0;
            return take(ref_path(t), Nat(1u));
        }
        if (prism_rtl::is<crate::ast::StmtKind::SAccum>(_m)) {
            auto&& t = prism_rtl::as<crate::ast::StmtKind::SAccum>(_m).a0;
            return take(ref_path(t), Nat(1u));
        }
        {
            return Array<Text>{};
        }
    }
    if (prism_rtl::is<Spot::SpotExpr>(spot0)) {
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> SpotSetRoot::cycle() const {
    const auto& spot0 = this->spot0;
    return ({
        prism_rtl::is<Spot::SpotStmt>(spot0) ? ({
        auto&& s = prism_rtl::as<Spot::SpotStmt>(spot0).a0;
        ({
        auto&& _m = s.kind;
        prism_rtl::is<crate::ast::StmtKind::SSet>(_m) ? ({
        auto&& t = prism_rtl::as<crate::ast::StmtKind::SSet>(_m).a0;
        ({
        auto t_1 = t;
        call_then(start_ref_path(t_1), [=](Array<Text> ref_path_116484) { return prism_rtl::finished(take(ref_path_116484, Nat(1u))); });
    });
    })
        : prism_rtl::is<crate::ast::StmtKind::SAccum>(_m) ? ({
        auto&& t = prism_rtl::as<crate::ast::StmtKind::SAccum>(_m).a0;
        ({
        auto t_1 = t;
        call_then(start_ref_path(t_1), [=](Array<Text> ref_path_116534) { return prism_rtl::finished(take(ref_path_116534, Nat(1u))); });
    });
    })
        : prism_rtl::finished(Array<Text>{});
    });
    })
        : prism_rtl::is<Spot::SpotExpr>(spot0) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SpotSetRoot, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_spot_set_root(Spot spot0) {
    return prism_rtl::make_rc<SpotSetRoot>(spot0);
}


/// AllPathsStrict: unbounded fn [Stmt], Text, Nat, (Text ==> Rel) -> Bool
bool all_paths_strict(const Array<crate::ast::Stmt>& stmts, const Text& v_, const Nat& vi, const Map<Text, Rel>& outer) {
    auto rels = block_rels(stmts, outer);
    return run_to_end(fold_job(stmts, false, ({
        auto v__1 = v_;
        auto vi_2 = vi;
        auto rels_3 = rels;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::ast::Stmt>)>>(prism_rtl::rc([=](std::tuple<bool, crate::ast::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto v__1_4 = v__1;
            auto vi_2_4 = vi_2;
            auto rels_3_4 = rels_3;
            entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto s = p1;
                ({
                auto&& _m = s.kind;
                prism_rtl::is<crate::ast::StmtKind::SSet>(_m) ? ({
                auto&& t = prism_rtl::as<crate::ast::StmtKind::SSet>(_m).a0;
                auto&& value = prism_rtl::as<crate::ast::StmtKind::SSet>(_m).a1;
                ({
                auto t_4 = t;
                auto value_5 = value;
                call_then(start_ref_path(t_4), [=](Array<Text> ref_path_117219) {
                return ref_path_117219 == Array(std::vector{v__1_4})
                    ? is_zero_lit(value_5)
                    ? prism_rtl::finished(ok)
                    : prism_rtl::more(prism_rtl::rc(SetsStrict(value_5, v__1_4, vi_2_4, rels_3_4)))
                    : prism_rtl::finished(ok && (!stmt_sets_weak(s, v__1_4, vi_2_4, rels_3_4)));
            });
            });
            })
                : prism_rtl::is<crate::ast::StmtKind::SExpr>(_m) ? ({
                auto&& e = prism_rtl::as<crate::ast::StmtKind::SExpr>(_m).a0;
                ({
                auto&& _m = e.kind;
                prism_rtl::is<crate::ast::ExprKind::EIf>(_m) ? ({
                auto&& c = prism_rtl::as<crate::ast::ExprKind::EIf>(_m).a0;
                auto&& tb = prism_rtl::as<crate::ast::ExprKind::EIf>(_m).a1;
                auto&& eb_opt = prism_rtl::as<crate::ast::ExprKind::EIf>(_m).a2;
                ({
                auto eb_opt_4 = eb_opt;
                auto c_5 = c;
                auto tb_6 = tb;
                call_then(start_cond_rels(c_5, rels_3_4), [=](Map<Text, Rel> cond_rels_117444) {
                return ({
                    auto tr = cond_rels_117444;
                    ({
                    prism_rtl::is_some(eb_opt_4) ? ({
                    auto&& b = prism_rtl::some_of(eb_opt_4);
                    ({
                    auto b_7 = b;
                    call_then(start_all_paths_strict(tb_6.stmts, v__1_4, vi_2_4, tr), [=](bool all_paths_strict_117517) {
                    return all_paths_strict_117517 && all_paths_strict(b_7.stmts, v__1_4, vi_2_4, rels_3_4)
                        ? prism_rtl::finished(true)
                        : prism_rtl::finished((ok && (!sets_weak(tb_6.stmts, v__1_4, vi_2_4, tr))) && (!sets_weak(b_7.stmts, v__1_4, vi_2_4, rels_3_4)));
                });
                });
                })
                    : prism_rtl::is_none(eb_opt_4) ? prism_rtl::finished(ok && (!sets_weak(tb_6.stmts, v__1_4, vi_2_4, tr)))
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            });
            });
            })
                : prism_rtl::is<crate::ast::ExprKind::EMatch>(_m) ? ({
                auto&& subj = prism_rtl::as<crate::ast::ExprKind::EMatch>(_m).a0;
                auto&& arms = prism_rtl::as<crate::ast::ExprKind::EMatch>(_m).a1;
                ({
                auto arms_4 = arms;
                auto subj_5 = subj;
                call_value(fold_job(arms_4, true, ({
                auto v__1_4_6 = v__1_4;
                auto vi_2_4_6 = vi_2_4;
                auto subj_5_6 = subj_5;
                auto rels_3_4_6 = rels_3_4;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::ast::Arm>)>>(prism_rtl::rc([=](std::tuple<bool, crate::ast::Arm> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto v__1_4_6_6 = v__1_4_6;
                    auto vi_2_4_6_6 = vi_2_4_6;
                    auto subj_5_6_6 = subj_5_6;
                    auto rels_3_4_6_6 = rels_3_4_6;
                    entered(once_job([=]() {
                    return ({
                        auto all_arms = p0;
                        auto a = p1;
                        (prism_rtl::finished(all_arms && all_paths_strict(a.body.stmts, v__1_4_6_6, vi_2_4_6_6, arm_pat_rels(subj_5_6_6, a, rels_3_4_6_6))));
                    });
                }));
                });
            })));
            })), [=](bool fold_117806) {
                return fold_117806
                    ? prism_rtl::finished(true)
                    : prism_rtl::finished(ok && (!run_to_end(fold_job(arms_4, false, ({
                    auto v__1_4_6 = v__1_4;
                    auto vi_2_4_6 = vi_2_4;
                    auto subj_5_6 = subj_5;
                    auto rels_3_4_6 = rels_3_4;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::ast::Arm>)>>(prism_rtl::rc([=](std::tuple<bool, crate::ast::Arm> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto v__1_4_6_6 = v__1_4_6;
                        auto vi_2_4_6_6 = vi_2_4_6;
                        auto subj_5_6_6 = subj_5_6;
                        auto rels_3_4_6_6 = rels_3_4_6;
                        entered(once_job([=]() {
                        return ({
                            auto any_arm = p0;
                            auto a = p1;
                            (prism_rtl::finished(any_arm || sets_weak(a.body.stmts, v__1_4_6_6, vi_2_4_6_6, arm_pat_rels(subj_5_6_6, a, rels_3_4_6_6))));
                        });
                    }));
                    });
                })));
                })))));
            });
            });
            })
                : prism_rtl::finished(ok && (!stmt_sets_weak(s, v__1_4, vi_2_4, rels_3_4)));
            });
            })
                : prism_rtl::finished(ok && (!stmt_sets_weak(s, v__1_4, vi_2_4, rels_3_4)));
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<bool> AllPathsStrict::cycle() const {
    const auto& stmts = this->stmts;
    const auto& v_ = this->v_;
    const auto& vi = this->vi;
    const auto& outer = this->outer;
    auto outer_1 = outer;
    auto stmts_2 = stmts;
    auto v__3 = v_;
    auto vi_4 = vi;
    return call_then(start_block_rels(stmts_2, outer_1), [=](Map<Text, Rel> block_rels_117111) {
        return ({
            auto rels = block_rels_117111;
            fold_job(stmts_2, false, ({
            auto v__3_5 = v__3;
            auto vi_4_5 = vi_4;
            auto rels_5 = rels;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::ast::Stmt>)>>(prism_rtl::rc([=](std::tuple<bool, crate::ast::Stmt> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto v__3_5_6 = v__3_5;
                auto vi_4_5_6 = vi_4_5;
                auto rels_5_6 = rels_5;
                entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto s = p1;
                    ({
                    auto&& _m = s.kind;
                    prism_rtl::is<crate::ast::StmtKind::SSet>(_m) ? ({
                    auto&& t = prism_rtl::as<crate::ast::StmtKind::SSet>(_m).a0;
                    auto&& value = prism_rtl::as<crate::ast::StmtKind::SSet>(_m).a1;
                    ({
                    auto t_6 = t;
                    auto value_7 = value;
                    call_then(start_ref_path(t_6), [=](Array<Text> ref_path_117219) {
                    return ref_path_117219 == Array(std::vector{v__3_5_6})
                        ? is_zero_lit(value_7)
                        ? prism_rtl::finished(ok)
                        : prism_rtl::more(prism_rtl::rc(SetsStrict(value_7, v__3_5_6, vi_4_5_6, rels_5_6)))
                        : prism_rtl::finished(ok && (!stmt_sets_weak(s, v__3_5_6, vi_4_5_6, rels_5_6)));
                });
                });
                })
                    : prism_rtl::is<crate::ast::StmtKind::SExpr>(_m) ? ({
                    auto&& e = prism_rtl::as<crate::ast::StmtKind::SExpr>(_m).a0;
                    ({
                    auto&& _m = e.kind;
                    prism_rtl::is<crate::ast::ExprKind::EIf>(_m) ? ({
                    auto&& c = prism_rtl::as<crate::ast::ExprKind::EIf>(_m).a0;
                    auto&& tb = prism_rtl::as<crate::ast::ExprKind::EIf>(_m).a1;
                    auto&& eb_opt = prism_rtl::as<crate::ast::ExprKind::EIf>(_m).a2;
                    ({
                    auto eb_opt_6 = eb_opt;
                    auto c_7 = c;
                    auto tb_8 = tb;
                    call_then(start_cond_rels(c_7, rels_5_6), [=](Map<Text, Rel> cond_rels_117444) {
                    return ({
                        auto tr = cond_rels_117444;
                        ({
                        prism_rtl::is_some(eb_opt_6) ? ({
                        auto&& b = prism_rtl::some_of(eb_opt_6);
                        ({
                        auto b_9 = b;
                        call_then(start_all_paths_strict(tb_8.stmts, v__3_5_6, vi_4_5_6, tr), [=](bool all_paths_strict_117517) {
                        return all_paths_strict_117517 && all_paths_strict(b_9.stmts, v__3_5_6, vi_4_5_6, rels_5_6)
                            ? prism_rtl::finished(true)
                            : prism_rtl::finished((ok && (!sets_weak(tb_8.stmts, v__3_5_6, vi_4_5_6, tr))) && (!sets_weak(b_9.stmts, v__3_5_6, vi_4_5_6, rels_5_6)));
                    });
                    });
                    })
                        : prism_rtl::is_none(eb_opt_6) ? prism_rtl::finished(ok && (!sets_weak(tb_8.stmts, v__3_5_6, vi_4_5_6, tr)))
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                });
                });
                })
                    : prism_rtl::is<crate::ast::ExprKind::EMatch>(_m) ? ({
                    auto&& subj = prism_rtl::as<crate::ast::ExprKind::EMatch>(_m).a0;
                    auto&& arms = prism_rtl::as<crate::ast::ExprKind::EMatch>(_m).a1;
                    ({
                    auto arms_6 = arms;
                    auto subj_7 = subj;
                    call_value(fold_job(arms_6, true, ({
                    auto v__3_5_6_8 = v__3_5_6;
                    auto vi_4_5_6_8 = vi_4_5_6;
                    auto subj_7_8 = subj_7;
                    auto rels_5_6_8 = rels_5_6;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::ast::Arm>)>>(prism_rtl::rc([=](std::tuple<bool, crate::ast::Arm> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto v__3_5_6_8_8 = v__3_5_6_8;
                        auto vi_4_5_6_8_8 = vi_4_5_6_8;
                        auto subj_7_8_8 = subj_7_8;
                        auto rels_5_6_8_8 = rels_5_6_8;
                        entered(once_job([=]() {
                        return ({
                            auto all_arms = p0;
                            auto a = p1;
                            (prism_rtl::finished(all_arms && all_paths_strict(a.body.stmts, v__3_5_6_8_8, vi_4_5_6_8_8, arm_pat_rels(subj_7_8_8, a, rels_5_6_8_8))));
                        });
                    }));
                    });
                })));
                })), [=](bool fold_117806) {
                    return fold_117806
                        ? prism_rtl::finished(true)
                        : prism_rtl::finished(ok && (!run_to_end(fold_job(arms_6, false, ({
                        auto v__3_5_6_8 = v__3_5_6;
                        auto vi_4_5_6_8 = vi_4_5_6;
                        auto subj_7_8 = subj_7;
                        auto rels_5_6_8 = rels_5_6;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::ast::Arm>)>>(prism_rtl::rc([=](std::tuple<bool, crate::ast::Arm> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto v__3_5_6_8_8 = v__3_5_6_8;
                            auto vi_4_5_6_8_8 = vi_4_5_6_8;
                            auto subj_7_8_8 = subj_7_8;
                            auto rels_5_6_8_8 = rels_5_6_8;
                            entered(once_job([=]() {
                            return ({
                                auto any_arm = p0;
                                auto a = p1;
                                (prism_rtl::finished(any_arm || sets_weak(a.body.stmts, v__3_5_6_8_8, vi_4_5_6_8_8, arm_pat_rels(subj_7_8_8, a, rels_5_6_8_8))));
                            });
                        }));
                        });
                    })));
                    })))));
                });
                });
                })
                    : prism_rtl::finished(ok && (!stmt_sets_weak(s, v__3_5_6, vi_4_5_6, rels_5_6)));
                });
                })
                    : prism_rtl::finished(ok && (!stmt_sets_weak(s, v__3_5_6, vi_4_5_6, rels_5_6)));
                });
                });
            }));
            });
        })));
        }))->cycle();
        });
    });
}


/// `Start AllPathsStrict, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_all_paths_strict(Array<crate::ast::Stmt> stmts, Text v_, Nat vi, Map<Text, Rel> outer) {
    return prism_rtl::make_rc<AllPathsStrict>(stmts, v_, vi, outer);
}


/// SetsWeak: unbounded fn [Stmt], Text, Nat, (Text ==> Rel) -> Bool
bool sets_weak(const Array<crate::ast::Stmt>& stmts, const Text& v_, const Nat& vi, const Map<Text, Rel>& outer) {
    return run_to_end(fold_job(stmts_spots(stmts, outer), false, ({
        auto v__1 = v_;
        auto vi_2 = vi;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Spot>)>>(prism_rtl::rc([=](std::tuple<bool, Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto v__1_3 = v__1;
            auto vi_2_3 = vi_2;
            entered(once_job([=]() {
            return ({
                auto seen = p0;
                auto sp = p1;
                (prism_rtl::finished(seen || spot_sets_weak(sp, v__1_3, vi_2_3)));
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<bool> SetsWeak::cycle() const {
    const auto& stmts = this->stmts;
    const auto& v_ = this->v_;
    const auto& vi = this->vi;
    const auto& outer = this->outer;
    auto outer_1 = outer;
    auto stmts_2 = stmts;
    auto v__3 = v_;
    auto vi_4 = vi;
    return call_then(start_stmts_spots(stmts_2, outer_1), [=](Array<Spot> stmts_spots_118453) {
        return fold_job(stmts_spots_118453, false, ({
            auto v__3_5 = v__3;
            auto vi_4_5 = vi_4;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Spot>)>>(prism_rtl::rc([=](std::tuple<bool, Spot> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto v__3_5_5 = v__3_5;
                auto vi_4_5_5 = vi_4_5;
                entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto sp = p1;
                    (prism_rtl::finished(seen || spot_sets_weak(sp, v__3_5_5, vi_4_5_5)));
                });
            }));
            });
        })));
        }))->cycle();
    });
}


/// `Start SetsWeak, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_sets_weak(Array<crate::ast::Stmt> stmts, Text v_, Nat vi, Map<Text, Rel> outer) {
    return prism_rtl::make_rc<SetsWeak>(stmts, v_, vi, outer);
}


/// StmtSetsWeak: unbounded fn Stmt, Text, Nat, (Text ==> Rel) -> Bool
bool stmt_sets_weak(const crate::ast::Stmt& s, const Text& v_, const Nat& vi, const Map<Text, Rel>& rels) {
    return run_to_end(fold_job(stmt_spots(s, rels), false, ({
        auto v__1 = v_;
        auto vi_2 = vi;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Spot>)>>(prism_rtl::rc([=](std::tuple<bool, Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto v__1_3 = v__1;
            auto vi_2_3 = vi_2;
            entered(once_job([=]() {
            return ({
                auto seen = p0;
                auto sp = p1;
                (prism_rtl::finished(seen || spot_sets_weak(sp, v__1_3, vi_2_3)));
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<bool> StmtSetsWeak::cycle() const {
    const auto& s = this->s;
    const auto& v_ = this->v_;
    const auto& vi = this->vi;
    const auto& rels = this->rels;
    auto rels_1 = rels;
    auto s_2 = s;
    auto v__3 = v_;
    auto vi_4 = vi;
    return call_then(start_stmt_spots(s_2, rels_1), [=](Array<Spot> stmt_spots_118636) {
        return fold_job(stmt_spots_118636, false, ({
            auto v__3_5 = v__3;
            auto vi_4_5 = vi_4;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Spot>)>>(prism_rtl::rc([=](std::tuple<bool, Spot> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto v__3_5_5 = v__3_5;
                auto vi_4_5_5 = vi_4_5;
                entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto sp = p1;
                    (prism_rtl::finished(seen || spot_sets_weak(sp, v__3_5_5, vi_4_5_5)));
                });
            }));
            });
        })));
        }))->cycle();
    });
}


/// `Start StmtSetsWeak, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_stmt_sets_weak(crate::ast::Stmt s, Text v_, Nat vi, Map<Text, Rel> rels) {
    return prism_rtl::make_rc<StmtSetsWeak>(s, v_, vi, rels);
}


/// SpotSetsWeak: unbounded fn Spot, Text, Nat -> Bool
bool spot_sets_weak(const Spot& spot0, const Text& text1, const Nat& n2) {
    auto&& _m = std::tuple{spot0, text1, n2};
    if (prism_rtl::is<Spot::SpotStmt>(std::get<0>(_m))) {
        auto&& s = prism_rtl::as<Spot::SpotStmt>(std::get<0>(_m)).a0;
        auto&& m = prism_rtl::as<Spot::SpotStmt>(std::get<0>(_m)).a1;
        auto&& v_ = std::get<1>(_m);
        auto&& vi = std::get<2>(_m);
        auto&& _m = s.kind;
        if (prism_rtl::is<crate::ast::StmtKind::SSet>(_m)) {
            auto&& t = prism_rtl::as<crate::ast::StmtKind::SSet>(_m).a0;
            auto&& value = prism_rtl::as<crate::ast::StmtKind::SSet>(_m).a1;
            return ((take(ref_path(t), Nat(1u)) == Array(std::vector{v_})) && (!sets_strict(value, v_, vi, m))) && (!((ref_path(t) == Array(std::vector{v_})) && is_zero_lit(value)));
        }
        if (prism_rtl::is<crate::ast::StmtKind::SAccum>(_m)) {
            auto&& t = prism_rtl::as<crate::ast::StmtKind::SAccum>(_m).a0;
            return take(ref_path(t), Nat(1u)) == Array(std::vector{v_});
        }
        {
            return false;
        }
    }
    if (prism_rtl::is<Spot::SpotExpr>(std::get<0>(_m))) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> SpotSetsWeak::cycle() const {
    const auto& spot0 = this->spot0;
    const auto& text1 = this->text1;
    const auto& n2 = this->n2;
    return ({
        auto&& _m = std::tuple{spot0, text1, n2};
        prism_rtl::is<Spot::SpotStmt>(std::get<0>(_m)) ? ({
        auto&& s = prism_rtl::as<Spot::SpotStmt>(std::get<0>(_m)).a0;
        auto&& m = prism_rtl::as<Spot::SpotStmt>(std::get<0>(_m)).a1;
        auto&& v_ = std::get<1>(_m);
        auto&& vi = std::get<2>(_m);
        ({
        auto&& _m = s.kind;
        prism_rtl::is<crate::ast::StmtKind::SSet>(_m) ? ({
        auto&& t = prism_rtl::as<crate::ast::StmtKind::SSet>(_m).a0;
        auto&& value = prism_rtl::as<crate::ast::StmtKind::SSet>(_m).a1;
        ({
        auto m_1 = m;
        auto t_2 = t;
        auto v__3 = v_;
        auto value_4 = value;
        auto vi_5 = vi;
        call_then(start_ref_path(t_2), [=](Array<Text> ref_path_118839) { return prism_rtl::finished(((take(ref_path_118839, Nat(1u)) == Array(std::vector{v__3})) && (!sets_strict(value_4, v__3, vi_5, m_1))) && (!((ref_path(t_2) == Array(std::vector{v__3})) && is_zero_lit(value_4)))); });
    });
    })
        : prism_rtl::is<crate::ast::StmtKind::SAccum>(_m) ? ({
        auto&& t = prism_rtl::as<crate::ast::StmtKind::SAccum>(_m).a0;
        ({
        auto t_1 = t;
        auto v__2 = v_;
        call_then(start_ref_path(t_1), [=](Array<Text> ref_path_118988) { return prism_rtl::finished(take(ref_path_118988, Nat(1u)) == Array(std::vector{v__2})); });
    });
    })
        : prism_rtl::finished(false);
    });
    })
        : prism_rtl::is<Spot::SpotExpr>(std::get<0>(_m)) ? prism_rtl::finished(false)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SpotSetsWeak, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_spot_sets_weak(Spot spot0, Text text1, Nat n2) {
    return prism_rtl::make_rc<SpotSetsWeak>(spot0, text1, n2);
}


/// IsZeroLit: fn Expr -> Bool
bool is_zero_lit(const crate::ast::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::ast::ExprKind::ELit>(_m)) {
        auto&& l = prism_rtl::as<crate::ast::ExprKind::ELit>(_m).a0;
        auto&& _m = l.kind;
        if (prism_rtl::is<crate::ast::LitKind::LInt>(_m)) {
            auto&& d = prism_rtl::as<crate::ast::LitKind::LInt>(_m).a0;
            return d == Text::lit("0");
        }
        {
            return false;
        }
    }
    if (prism_rtl::is<crate::ast::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::ast::ExprKind::EGroup>(_m).a0;
        return is_zero_lit(x);
    }
    {
        return false;
    }
}


/// SetsStrict: unbounded fn Expr, Text, Nat, (Text ==> Rel) -> Bool
bool sets_strict(const crate::ast::Expr& e, const Text& v_, const Nat& vi, const Map<Text, Rel>& rels) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::ast::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::ast::ExprKind::EGroup>(_m).a0;
        return sets_strict(x, v_, vi, rels);
    }
    if (prism_rtl::is<crate::ast::ExprKind::EBinary>(_m)) {
        auto&& m120365_1_0 = prism_rtl::as<crate::ast::ExprKind::EBinary>(_m).a0;
        auto&& l = prism_rtl::as<crate::ast::ExprKind::EBinary>(_m).a1;
        if (m120365_1_0 == Text::lit("-?")) {
            return is_nat_minus(rels, e) && sets_strict(l, v_, vi, rels);
        }
    }
    {
        return rel_strict(rels, e, vi) || call_strict(e, v_, vi, rels);
    }
}


prism_rtl::Turn<bool> SetsStrict::cycle() const {
    const auto& e = this->e;
    const auto& v_ = this->v_;
    const auto& vi = this->vi;
    const auto& rels = this->rels;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::ast::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::ast::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(SetsStrict(x, v_, vi, rels)));
    })
        : prism_rtl::is<crate::ast::ExprKind::EBinary>(_m) && ({
        auto&& m120365_1_0 = prism_rtl::as<crate::ast::ExprKind::EBinary>(_m).a0;
        auto&& l = prism_rtl::as<crate::ast::ExprKind::EBinary>(_m).a1;
        (m120365_1_0 == Text::lit("-?"));
    }) ? ({
        auto&& m120365_1_0 = prism_rtl::as<crate::ast::ExprKind::EBinary>(_m).a0;
        auto&& l = prism_rtl::as<crate::ast::ExprKind::EBinary>(_m).a1;
        prism_rtl::finished(is_nat_minus(rels, e) && sets_strict(l, v_, vi, rels));
    })
        : ({
        auto e_1 = e;
        auto rels_2 = rels;
        auto v__3 = v_;
        auto vi_4 = vi;
        call_then(start_rel_strict(rels_2, e_1, vi_4), [=](bool rel_strict_120515) { return prism_rtl::finished(rel_strict_120515 || call_strict(e_1, v__3, vi_4, rels_2)); });
    });
    });
}


/// `Start SetsStrict, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_sets_strict(crate::ast::Expr e, Text v_, Nat vi, Map<Text, Rel> rels) {
    return prism_rtl::make_rc<SetsStrict>(e, v_, vi, rels);
}


/// RelStrict: unbounded fn (Text ==> Rel), Expr, Nat -> Bool
bool rel_strict(const Map<Text, Rel>& rels, const crate::ast::Expr& e, const Nat& vi) {
    auto&& _m = rel_of(rels, e);
    if (prism_rtl::is_some(_m)) {
        auto&& r = prism_rtl::some_of(_m);
        return r.strict && (r.param == vi);
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> RelStrict::cycle() const {
    const auto& rels = this->rels;
    const auto& e = this->e;
    const auto& vi = this->vi;
    auto e_1 = e;
    auto rels_2 = rels;
    auto vi_3 = vi;
    return call_then(start_rel_of(rels_2, e_1), [=](std::optional<Rel> rel_of_120661) {
        return ({
            prism_rtl::is_some(rel_of_120661) ? ({
            auto&& r = prism_rtl::some_of(rel_of_120661);
            prism_rtl::finished(r.strict && (r.param == vi_3));
        })
            : prism_rtl::is_none(rel_of_120661) ? prism_rtl::finished(false)
            : throw prism_rtl::Panic("no arm matched");
        });
    });
}


/// `Start RelStrict, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_rel_strict(Map<Text, Rel> rels, crate::ast::Expr e, Nat vi) {
    return prism_rtl::make_rc<RelStrict>(rels, e, vi);
}


/// CallStrict: unbounded fn Expr, Text, Nat, (Text ==> Rel) -> Bool
bool call_strict(const crate::ast::Expr& e, const Text& v_, const Nat& vi, const Map<Text, Rel>& rels) {
    auto&& _m = call_of(e);
    if (prism_rtl::is_some(_m)) {
        auto&& c = std::get<0>(prism_rtl::some_of(_m));
        auto&& args = std::get<1>(prism_rtl::some_of(_m));
        return is_non_nat_min(rels, e, c)
            ? false
            : ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = no_larger_arg(rels, c, args);
            if (prism_rtl::is_some(_m)) {
                auto&& a = prism_rtl::some_of(_m);
                _v.set(sets_strict(a, v_, vi, rels));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> CallStrict::cycle() const {
    const auto& e = this->e;
    const auto& v_ = this->v_;
    const auto& vi = this->vi;
    const auto& rels = this->rels;
    return ({
        auto&& _m = call_of(e);
        prism_rtl::is_some(_m) ? ({
        auto&& c = std::get<0>(prism_rtl::some_of(_m));
        auto&& args = std::get<1>(prism_rtl::some_of(_m));
        is_non_nat_min(rels, e, c)
        ? prism_rtl::finished(false)
        : ({
        auto&& _m = no_larger_arg(rels, c, args);
        prism_rtl::is_some(_m) ? ({
        auto&& a = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(SetsStrict(a, v_, vi, rels)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CallStrict, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_call_strict(crate::ast::Expr e, Text v_, Nat vi, Map<Text, Rel> rels) {
    return prism_rtl::make_rc<CallStrict>(e, v_, vi, rels);
}


/// DischargeIncls: unbounded fn G, St, Nat -> St
crate::check_types::St discharge_incls(const crate::check_env::G& g, const crate::check_types::St& st, const Nat& from) {
    auto batch = drop(st.incls, from);
    return run_to_end(fold_job(batch, st, ({
        auto g_1 = g;
        auto batch_2 = batch;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check_types::St>(std::tuple<crate::check_types::St, crate::check_types::Incl>)>>(prism_rtl::rc([=](std::tuple<crate::check_types::St, crate::check_types::Incl> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_3 = g_1;
            auto batch_2_3 = batch_2;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto inc = p1;
                call_then(start_through(s, inc, batch_2_3), [=](crate::check_types::Incl through_121688) { return prism_rtl::more(prism_rtl::rc(DischargeOne(g_1_3, s, through_121688))); });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<crate::check_types::St> DischargeIncls::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& from = this->from;
    auto batch = drop(st.incls, from);
    return fold_job(batch, st, ({
        auto g_1 = g;
        auto batch_2 = batch;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check_types::St>(std::tuple<crate::check_types::St, crate::check_types::Incl>)>>(prism_rtl::rc([=](std::tuple<crate::check_types::St, crate::check_types::Incl> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_3 = g_1;
            auto batch_2_3 = batch_2;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto inc = p1;
                call_then(start_through(s, inc, batch_2_3), [=](crate::check_types::Incl through_121688) { return prism_rtl::more(prism_rtl::rc(DischargeOne(g_1_3, s, through_121688))); });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start DischargeIncls, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check_types::St> start_discharge_incls(crate::check_env::G g, crate::check_types::St st, Nat from) {
    return prism_rtl::make_rc<DischargeIncls>(g, st, from);
}


/// Through: unbounded fn St, Incl, [Incl] -> Incl
crate::check_types::Incl through(const crate::check_types::St& st, const crate::check_types::Incl& inc, const Array<crate::check_types::Incl>& batch) {
    auto sup = crate::check_types::walk_row(st, inc.sup);
    auto&& _m = sup.tail;
    if (prism_rtl::is<crate::check_types::Tail::TlFlex>(_m)) {
        auto&& n = prism_rtl::as<crate::check_types::Tail::TlFlex>(_m).a0;
        return len(sup.fams) > Nat(0u)
            ? inc
            : run_to_end(fold_job(batch, inc, ({
            auto st_1 = st;
            auto n_2 = n;
            auto inc_3 = inc;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check_types::Incl>(std::tuple<crate::check_types::Incl, crate::check_types::Incl>)>>(prism_rtl::rc([=](std::tuple<crate::check_types::Incl, crate::check_types::Incl> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_1_4 = st_1;
                auto n_2_4 = n_2;
                auto inc_3_4 = inc_3;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto other = p1;
                    call_then(crate::check_types::start_walk_row(st_1_4, other.sub), [=](crate::check_types::Rw walk_row_122202) {
                    return ({
                        auto sub = walk_row_122202;
                        ((len(sub.fams) == Nat(0u)) && (sub.tail == crate::check_types::Tail(crate::check_types::Tail::TlFlex{n_2_4}))) && (other != inc_3_4)
                        ? prism_rtl::finished(({
                        crate::check_types::Incl this_ = acc;
                        this_.sup = other.sup;
                        this_;
                    }))
                        : prism_rtl::finished(acc);
                    });
                });
                });
            }));
            });
        })));
        })));
    }
    {
        return inc;
    }
}


prism_rtl::Turn<crate::check_types::Incl> Through::cycle() const {
    const auto& st = this->st;
    const auto& inc = this->inc;
    const auto& batch = this->batch;
    auto batch_1 = batch;
    auto inc_2 = inc;
    auto st_3 = st;
    return call_then(crate::check_types::start_walk_row(st_3, inc_2.sup), [=](crate::check_types::Rw walk_row_122030) {
        return ({
            auto sup = walk_row_122030;
            ({
            auto&& _m = sup.tail;
            prism_rtl::is<crate::check_types::Tail::TlFlex>(_m) ? ({
            auto&& n = prism_rtl::as<crate::check_types::Tail::TlFlex>(_m).a0;
            len(sup.fams) > Nat(0u)
            ? prism_rtl::finished(inc_2)
            : fold_job(batch_1, inc_2, ({
            auto st_3_4 = st_3;
            auto n_4 = n;
            auto inc_2_5 = inc_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check_types::Incl>(std::tuple<crate::check_types::Incl, crate::check_types::Incl>)>>(prism_rtl::rc([=](std::tuple<crate::check_types::Incl, crate::check_types::Incl> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_3_4_5 = st_3_4;
                auto n_4_5 = n_4;
                auto inc_2_5_5 = inc_2_5;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto other = p1;
                    call_then(crate::check_types::start_walk_row(st_3_4_5, other.sub), [=](crate::check_types::Rw walk_row_122202) {
                    return ({
                        auto sub = walk_row_122202;
                        ((len(sub.fams) == Nat(0u)) && (sub.tail == crate::check_types::Tail(crate::check_types::Tail::TlFlex{n_4_5}))) && (other != inc_2_5_5)
                        ? prism_rtl::finished(({
                        crate::check_types::Incl this_ = acc;
                        this_.sup = other.sup;
                        this_;
                    }))
                        : prism_rtl::finished(acc);
                    });
                });
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::finished(inc_2);
        });
        });
    });
}


/// `Start Through, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check_types::Incl> start_through(crate::check_types::St st, crate::check_types::Incl inc, Array<crate::check_types::Incl> batch) {
    return prism_rtl::make_rc<Through>(st, inc, batch);
}


/// DischargeOne: unbounded fn G, St, Incl -> St
crate::check_types::St discharge_one(const crate::check_env::G& g, const crate::check_types::St& st, const crate::check_types::Incl& inc) {
    auto sub = crate::check_types::walk_row(st, inc.sub);
    auto sup = crate::check_types::walk_row(st, inc.sup);
    auto st1 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check_types::St> _v;
        auto&& _m = sub.tail;
        if (prism_rtl::is<crate::check_types::Tail::TlFlex>(_m)) {
            auto&& n = prism_rtl::as<crate::check_types::Tail::TlFlex>(_m).a0;
            _v.set(close_tail(st, n));
            goto _done;
        }
        {
            _v.set(st);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto sub2 = crate::check_types::walk_row(st1, inc.sub);
    auto left = filter(sub2.fams, [&](const Text& f) { return (!crate::check_types::has_text(sup.fams, f)) && (len(tags_left(g, f, sub2.minus)) > Nat(0u)); });
    auto tail_bad = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = std::tuple{sub2.tail, sup.tail};
        if (prism_rtl::is<crate::check_types::Tail::TlRigid>(std::get<0>(_m)) && prism_rtl::is<crate::check_types::Tail::TlRigid>(std::get<1>(_m))) {
            auto&& a = prism_rtl::as<crate::check_types::Tail::TlRigid>(std::get<0>(_m)).a0;
            auto&& b = prism_rtl::as<crate::check_types::Tail::TlRigid>(std::get<1>(_m)).a0;
            _v.set(a != b);
            goto _done;
        }
        if (prism_rtl::is<crate::check_types::Tail::TlRigid>(std::get<0>(_m))) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    return (len(left) == Nat(0u)) && (!tail_bad)
        ? st1
        : ({
        auto s0 = ({
            crate::check_types::St this_ = st1;
            this_.file = inc->file;
            this_;
        });
        auto tags = fold(left, Array<Text>{}, [&](const Array<Text>& acc, const Text& f) { return append(acc, tags_left(g, f, sub2.minus)); });
        auto s1 = inc.forward
            ? crate::check_types::err_fix(s0, Text::lit("forwarding"), inc.span, prism_rtl::cat("forwarding ", crate::lexer::join(tags, Text::lit(", ")), " from a scope that emits ", crate::check_types::show_row(sup)), prism_rtl::cat("answer ", len(tags) == Nat(1u) ? Text::lit("it") : Text::lit("them"), " above this arm, for example `", or_(index(tags, Nat(0u)), Text::lit("")), "(..): @ never`"))
            : crate::check_types::err_fix(s0, Text::lit("row-outside"), inc.span, prism_rtl::cat("a child that emits `", crate::check_types::show_row(sub2), "` in a scope that emits `", crate::check_types::show_row(sup), "`"), Text::lit("widen the scope's `emit` row, or host the child with `@HostDocument`"));
        ({
        crate::check_types::St this_ = s1;
        this_.file = st1->file;
        this_;
    });
    });
}


prism_rtl::Turn<crate::check_types::St> DischargeOne::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& inc = this->inc;
    auto g_1 = g;
    auto inc_2 = inc;
    auto st_3 = st;
    return call_then(crate::check_types::start_walk_row(st_3, inc_2.sub), [=](crate::check_types::Rw walk_row_122521) {
        return ({
            auto sub = walk_row_122521;
            call_then(crate::check_types::start_walk_row(st_3, inc_2.sup), [=](crate::check_types::Rw walk_row_122555) {
            return ({
                auto sup = walk_row_122555;
                auto st1 = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::check_types::St> _v;
                    auto&& _m = sub.tail;
                    if (prism_rtl::is<crate::check_types::Tail::TlFlex>(_m)) {
                        auto&& n = prism_rtl::as<crate::check_types::Tail::TlFlex>(_m).a0;
                        _v.set(close_tail(st_3, n));
                        goto _done;
                    }
                    {
                        _v.set(st_3);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                call_then(crate::check_types::start_walk_row(st1, inc_2.sub), [=](crate::check_types::Rw walk_row_122676) {
                return ({
                    auto sub2 = walk_row_122676;
                    auto left = filter(sub2.fams, [&](const Text& f) { return (!crate::check_types::has_text(sup.fams, f)) && (len(tags_left(g_1, f, sub2.minus)) > Nat(0u)); });
                    auto tail_bad = ({
                        __label__ _done;
                        prism_rtl::Slot<bool> _v;
                        auto&& _m = std::tuple{sub2.tail, sup.tail};
                        if (prism_rtl::is<crate::check_types::Tail::TlRigid>(std::get<0>(_m)) && prism_rtl::is<crate::check_types::Tail::TlRigid>(std::get<1>(_m))) {
                            auto&& a = prism_rtl::as<crate::check_types::Tail::TlRigid>(std::get<0>(_m)).a0;
                            auto&& b = prism_rtl::as<crate::check_types::Tail::TlRigid>(std::get<1>(_m)).a0;
                            _v.set(a != b);
                            goto _done;
                        }
                        if (prism_rtl::is<crate::check_types::Tail::TlRigid>(std::get<0>(_m))) {
                            _v.set(true);
                            goto _done;
                        }
                        {
                            _v.set(false);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    (len(left) == Nat(0u)) && (!tail_bad)
                    ? prism_rtl::finished(st1)
                    : ({
                    auto s0 = ({
                        crate::check_types::St this_ = st1;
                        this_.file = inc_2->file;
                        this_;
                    });
                    auto tags = fold(left, Array<Text>{}, [&](const Array<Text>& acc, const Text& f) { return append(acc, tags_left(g_1, f, sub2.minus)); });
                    auto s1 = inc_2.forward
                        ? crate::check_types::err_fix(s0, Text::lit("forwarding"), inc_2.span, prism_rtl::cat("forwarding ", crate::lexer::join(tags, Text::lit(", ")), " from a scope that emits ", crate::check_types::show_row(sup)), prism_rtl::cat("answer ", len(tags) == Nat(1u) ? Text::lit("it") : Text::lit("them"), " above this arm, for example `", or_(index(tags, Nat(0u)), Text::lit("")), "(..): @ never`"))
                        : crate::check_types::err_fix(s0, Text::lit("row-outside"), inc_2.span, prism_rtl::cat("a child that emits `", crate::check_types::show_row(sub2), "` in a scope that emits `", crate::check_types::show_row(sup), "`"), Text::lit("widen the scope's `emit` row, or host the child with `@HostDocument`"));
                    (prism_rtl::finished(({
                    crate::check_types::St this_ = s1;
                    this_.file = st1->file;
                    this_;
                })));
                });
                });
            });
            });
        });
        });
    });
}


/// `Start DischargeOne, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check_types::St> start_discharge_one(crate::check_env::G g, crate::check_types::St st, crate::check_types::Incl inc) {
    return prism_rtl::make_rc<DischargeOne>(g, st, inc);
}


/// TagsLeft: fn G, Text, [Text] -> [Text]
Array<Text> tags_left(const crate::check_env::G& g, const Text& fam, const Array<Text>& minus) {
    return filter(or_(prelude::get(g.families, fam), Array<Text>{}), [&](const Text& t) { return (!crate::check_types::has_text(minus, t)) && is_element_tag(g, t); });
}


/// IsElementTag: fn G, Text -> Bool
bool is_element_tag(const crate::check_env::G& g, const Text& t) {
    auto&& _m = prelude::get(g.tags, t);
    if (prism_rtl::is_some(_m)) {
        auto&& tg = prism_rtl::some_of(_m);
        return tg.kind == Text::lit("Element");
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// CloseTail: fn St, Nat -> St
crate::check_types::St close_tail(const crate::check_types::St& st, const Nat& n) {
    crate::check_types::St this_ = st;
    this_.rows = insert(this_.rows, n, crate::check_types::empty_row());
    return this_;
}


/// CheckProgram: unbounded fn [Src], [Module], [Text], Nat, Bool, Bool, [CDiag] -> Report
Report_ check_program(const Array<crate::check_errors::Src>& srcs, const Array<crate::ast::Module>& trees, const Array<Text>& world, const Nat& shown, const bool& recording, const bool& unused, const Array<crate::check_errors::CDiag>& pre) {
    auto [g0a, stb] = crate::check_env::build_g(srcs, trees);
    auto g0 = ({
        crate::check_env::G this_ = g0a;
        this_.prelude_from = shown;
        this_;
    });
    auto st0 = ({
        crate::check_types::St this_ = stb;
        this_.recording = recording;
        this_;
    });
    auto [g1, st1] = top_lets(g0, st0);
    auto [failed, st2] = run_to_end(fold_job(g1.defs, std::tuple{Array<Text>{}, st1}, ({
        auto g1_1 = g1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, crate::check_types::St>>(std::tuple<std::tuple<Array<Text>, crate::check_types::St>, crate::check_env::Def>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Text>, crate::check_types::St>, crate::check_env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g1_1_2 = g1_1;
            entered(once_job([=]() {
            return ({
                auto [bad, s] = p0;
                auto d = p1;
                ({
                auto before_ = len(s.diags);
                call_then(start_check_def(g1_1_2, s, d), [=](crate::check_types::St check_def_125348) {
                return ({
                    auto s2 = check_def_125348;
                    auto bad2 = len(s2.diags) > before_ ? prelude::push(bad, own_key(d).qk) : bad;
                    (prism_rtl::finished(std::tuple{bad2, s2}));
                });
            });
            });
            });
        }));
        });
    }));
    })));
    auto st2b = ({
        crate::check_types::St this_ = st2;
        this_.level = Nat(0u);
        this_;
    });
    auto st3 = crate::check_env::default_wants(g1, st2b, Array<std::tuple<Text, Text>>{});
    auto good = filter(g1.defs, [&](const crate::check_env::Def& d) { return !crate::check_types::has_text(failed, own_key(d).qk); });
    auto [st4, refs] = shrink_check(g1, st3, good);
    auto [root_row_, st5] = root_row(g1, st4, world);
    auto warnings = unused
        ? unused_defs(good, refs, shown)
        : Array<crate::check_errors::CDiag>{};
    auto reached = test_only_reached(srcs, g1.defs, refs);
    auto diags = crate::check_errors::sort_diags(append(append(append(filter(st5.diags, [&](const crate::check_errors::CDiag& d) { return d->file < shown; }), warnings), pre), reached));
    auto text = concat(each(diags, [&](const crate::check_errors::CDiag& d) { return crate::check_errors::render_cdiag(srcs, d); }));
    auto typed_1 = recording ? typed_of(g1, st5, shown) : crate::typed::empty_typed();
    return Report_{.text = text, .errors = len(filter(diags, [&](const crate::check_errors::CDiag& d) { return !crate::check_errors::is_warning(d); })), .root_row = root_row_, .typed = typed_1};
}


prism_rtl::Turn<Report_> CheckProgram::cycle() const {
    const auto& srcs = this->srcs;
    const auto& trees = this->trees;
    const auto& world = this->world;
    const auto& shown = this->shown;
    const auto& recording = this->recording;
    const auto& unused = this->unused;
    const auto& pre = this->pre;
    auto pre_1 = pre;
    auto recording_2 = recording;
    auto shown_3 = shown;
    auto srcs_4 = srcs;
    auto trees_5 = trees;
    auto unused_6 = unused;
    auto world_7 = world;
    return call_then(crate::check_env::start_build_g(srcs_4, trees_5), [=](std::tuple<crate::check_env::G, crate::check_types::St> build_g_124907) {
        return ({
            auto [g0a, stb] = build_g_124907;
            auto g0 = ({
                crate::check_env::G this_ = g0a;
                this_.prelude_from = shown_3;
                this_;
            });
            auto st0 = ({
                crate::check_types::St this_ = stb;
                this_.recording = recording_2;
                this_;
            });
            call_then(start_top_lets(g0, st0), [=](std::tuple<crate::check_env::G, crate::check_types::St> top_lets_125210) {
            return ({
                auto [g1, st1] = top_lets_125210;
                call_value(fold_job(g1.defs, std::tuple{Array<Text>{}, st1}, ({
                auto g1_8 = g1;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, crate::check_types::St>>(std::tuple<std::tuple<Array<Text>, crate::check_types::St>, crate::check_env::Def>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Text>, crate::check_types::St>, crate::check_env::Def> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto g1_8_9 = g1_8;
                    entered(once_job([=]() {
                    return ({
                        auto [bad, s] = p0;
                        auto d = p1;
                        ({
                        auto before_ = len(s.diags);
                        call_then(start_check_def(g1_8_9, s, d), [=](crate::check_types::St check_def_125348) {
                        return ({
                            auto s2 = check_def_125348;
                            auto bad2 = len(s2.diags) > before_ ? prelude::push(bad, own_key(d).qk) : bad;
                            (prism_rtl::finished(std::tuple{bad2, s2}));
                        });
                    });
                    });
                    });
                }));
                });
            }));
            })), [=](std::tuple<Array<Text>, crate::check_types::St> fold_125252) {
                return ({
                    auto [failed, st2] = fold_125252;
                    auto st2b = ({
                        crate::check_types::St this_ = st2;
                        this_.level = Nat(0u);
                        this_;
                    });
                    call_then(crate::check_env::start_default_wants(g1, st2b, Array<std::tuple<Text, Text>>{}), [=](crate::check_types::St default_wants_125531) {
                    return ({
                        auto st3 = default_wants_125531;
                        auto good = filter(g1.defs, [&](const crate::check_env::Def& d) { return !crate::check_types::has_text(failed, own_key(d).qk); });
                        call_then(start_shrink_check(g1, st3, good), [=](std::tuple<crate::check_types::St, Array<std::tuple<Text, Array<Text>>>> shrink_check_125802) {
                        return ({
                            auto [st4, refs] = shrink_check_125802;
                            call_then(start_root_row(g1, st4, world_7), [=](std::tuple<Text, crate::check_types::St> root_row_125855) {
                            return ({
                                auto [root_row_, st5] = root_row_125855;
                                auto warnings = unused_6
                                    ? unused_defs(good, refs, shown_3)
                                    : Array<crate::check_errors::CDiag>{};
                                auto reached = test_only_reached(srcs_4, g1.defs, refs);
                                auto diags = crate::check_errors::sort_diags(append(append(append(filter(st5.diags, [&](const crate::check_errors::CDiag& d) { return d->file < shown_3; }), warnings), pre_1), reached));
                                auto text = concat(each(diags, [&](const crate::check_errors::CDiag& d) { return crate::check_errors::render_cdiag(srcs_4, d); }));
                                auto typed_8 = recording_2 ? typed_of(g1, st5, shown_3) : crate::typed::empty_typed();
                                (prism_rtl::finished(Report_{.text = text, .errors = len(filter(diags, [&](const crate::check_errors::CDiag& d) { return !crate::check_errors::is_warning(d); })), .root_row = root_row_, .typed = typed_8}));
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start CheckProgram, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Report_> start_check_program(Array<crate::check_errors::Src> srcs, Array<crate::ast::Module> trees, Array<Text> world, Nat shown, bool recording, bool unused, Array<crate::check_errors::CDiag> pre) {
    return prism_rtl::make_rc<CheckProgram>(srcs, trees, world, shown, recording, unused, pre);
}


/// TypedOf: unbounded fn G, St, Nat -> TProgram
crate::typed::TProgram typed_of(const crate::check_env::G& g, const crate::check_types::St& st, const Nat& shown) {
    auto z = crate::check_types::zonk_typed(st);
    auto vals = filter(values(g.vals), [&](const crate::check_env::ValInfo& v_) { return ((v_->file < shown) && (v_.sort != Text::lit("builtin"))) && (or_(prelude::get(g.mods, v_.home), crate::check_env::dummy_mod())->file == v_->file); });
    crate::typed::TProgram this_ = z;
    this_.defs = run_to_end(each_job(vals, ({
        auto st_1 = st;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::typed::DefNote>(crate::check_env::ValInfo)>>(prism_rtl::rc([=](crate::check_env::ValInfo p0) {
        return ({
            auto st_1_2 = st_1;
            entered(once_job([=]() {
            return ({
                auto v_ = p0;
                call_then(start_zonk_scheme(st_1_2, v_.scheme), [=](crate::check_types::Scheme zonk_scheme_126831) { return prism_rtl::finished(crate::typed::DefNote{.at = crate::typed::SrcAt{.file = v_->file, .span = v_.span}, .name = v_.qk, .scheme = zonk_scheme_126831}); });
            });
        }));
        });
    })));
    })));
    return this_;
}


prism_rtl::Turn<crate::typed::TProgram> TypedOf::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& shown = this->shown;
    auto g_1 = g;
    auto shown_2 = shown;
    auto st_3 = st;
    return call_then(crate::check_types::start_zonk_typed(st_3), [=](crate::typed::TProgram zonk_typed_126574) {
        return ({
            auto z = zonk_typed_126574;
            auto vals = filter(values(g_1.vals), [&](const crate::check_env::ValInfo& v_) { return ((v_->file < shown_2) && (v_.sort != Text::lit("builtin"))) && (or_(prelude::get(g_1.mods, v_.home), crate::check_env::dummy_mod())->file == v_->file); });
            (prism_rtl::finished(({
            crate::typed::TProgram this_ = z;
            this_.defs = run_to_end(each_job(vals, ({
                auto st_3_4 = st_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::typed::DefNote>(crate::check_env::ValInfo)>>(prism_rtl::rc([=](crate::check_env::ValInfo p0) {
                return ({
                    auto st_3_4_4 = st_3_4;
                    entered(once_job([=]() {
                    return ({
                        auto v_ = p0;
                        call_then(start_zonk_scheme(st_3_4_4, v_.scheme), [=](crate::check_types::Scheme zonk_scheme_126831) { return prism_rtl::finished(crate::typed::DefNote{.at = crate::typed::SrcAt{.file = v_->file, .span = v_.span}, .name = v_.qk, .scheme = zonk_scheme_126831}); });
                    });
                }));
                });
            })));
            })));
            this_;
        })));
        });
    });
}


/// `Start TypedOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::typed::TProgram> start_typed_of(crate::check_env::G g, crate::check_types::St st, Nat shown) {
    return prism_rtl::make_rc<TypedOf>(g, st, shown);
}


/// ZonkScheme: unbounded fn St, Scheme -> Scheme
crate::check_types::Scheme zonk_scheme(const crate::check_types::St& st, const crate::check_types::Scheme& sc) {
    crate::check_types::Scheme this_ = sc;
    this_.ty = crate::check_types::zonk(st, this_.ty);
    return this_;
}


prism_rtl::Turn<crate::check_types::Scheme> ZonkScheme::cycle() const {
    const auto& st = this->st;
    const auto& sc = this->sc;
    return prism_rtl::finished(({
        crate::check_types::Scheme this_ = sc;
        this_.ty = crate::check_types::zonk(st, this_.ty);
        this_;
    }));
}


/// `Start ZonkScheme, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check_types::Scheme> start_zonk_scheme(crate::check_types::St st, crate::check_types::Scheme sc) {
    return prism_rtl::make_rc<ZonkScheme>(st, sc);
}


/// TopLets: unbounded fn G, St -> ((G, St))
std::tuple<crate::check_env::G, crate::check_types::St> top_lets(const crate::check_env::G& g, const crate::check_types::St& st) {
    auto unsigned_ = filter(g.defs, [&](const crate::check_env::Def& d) { return is_let_def(d) && (!crate::check_env::has_key(g.vals, d.qk)); });
    auto [g1, st1] = fold(unsigned_, std::tuple{g, st}, [&](const std::tuple<crate::check_env::G, crate::check_types::St>& _p0, const crate::check_env::Def& d) {
        auto&& gg = std::get<0>(_p0);
        auto&& s = std::get<1>(_p0);
        return ({
            auto [v_, s2] = crate::check_types::fresh_var(s, false, d.name);
            auto gg2 = ({
                crate::check_env::G this_ = gg;
                this_.vals = insert(this_.vals, d.qk, crate::check_env::ValInfo{.qk = d.qk, .scheme = crate::check_types::mono(v_), .sort = Text::lit("let"), .has_sig = false, .home = d.home, .file = d->file, .span = d.span});
                this_;
            });
            std::tuple{gg2, s2};
        });
    });
    return run_to_end(fold_job(unsigned_, std::tuple{g1, st1}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check_env::G, crate::check_types::St>>(std::tuple<std::tuple<crate::check_env::G, crate::check_types::St>, crate::check_env::Def>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check_env::G, crate::check_types::St>, crate::check_env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [gg, s] = p0;
                auto d = p1;
                ({
                auto&& _m = d.body;
                prism_rtl::is<crate::check_env::DefBody::DbLet>(_m) ? ({
                auto&& l = prism_rtl::as<crate::check_env::DefBody::DbLet>(_m).a0;
                ({
                auto env = def_env(gg, d);
                auto s0 = ({
                    crate::check_types::St this_ = s;
                    this_.file = d->file;
                    this_.level = Nat(1u);
                    this_;
                });
                auto pre = or_(prelude::get(gg.vals, d.qk), dummy_val()).scheme.ty;
                auto l_1 = l;
                call_then(crate::check_expr::start_check(env, s0, l_1->value, pre), [=](crate::check_types::St check_127926) {
                return ({
                    auto s1 = check_127926;
                    call_then(crate::check_env::start_solve_wants(gg, s1, Array<std::tuple<Text, Text>>{}, false), [=](crate::check_types::St solve_wants_127975) {
                    return ({
                        auto s2 = solve_wants_127975;
                        auto s3 = ({
                            crate::check_types::St this_ = s2;
                            this_.level = Nat(0u);
                            this_;
                        });
                        call_then(crate::check_types::start_zonk(s3, pre), [=](crate::check_types::Ty zonk_128088) {
                        return ({
                            auto t = zonk_128088;
                            call_then(crate::check_expr::start_wants_above(s3, t, crate::check_expr::is_lambda(l_1->value)), [=](std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, crate::check_types::St> wants_above_128140) {
                            return ({
                                auto [keep, bounds, s4] = wants_above_128140;
                                call_then(crate::check_types::start_holds_node(s4, t), [=](bool holds_node_128209) {
                                return ({
                                    auto [sc, s5] = holds_node_128209
                                        ? std::tuple{crate::check_types::mono(t), s4}
                                        : crate::check_types::generalize(s4, t, keep, bounds);
                                    auto gg2 = ({
                                        crate::check_env::G this_ = gg;
                                        this_.vals = insert(this_.vals, d.qk, crate::check_env::ValInfo{.qk = d.qk, .scheme = sc, .sort = Text::lit("let"), .has_sig = false, .home = d.home, .file = d->file, .span = d.span});
                                        this_;
                                    });
                                    call_then(crate::check_types::start_check_colors(s5), [=](crate::check_types::St check_colors_128528) { return call_then(crate::check_env::start_resolve_fields(gg, check_colors_128528, true), [=](crate::check_types::St resolve_fields_128509) { return call_then(crate::check_types::start_layer_questions(resolve_fields_128509), [=](crate::check_types::St layer_questions_128493) { return call_then(start_discharge_incls(gg, layer_questions_128493, Nat(0u)), [=](crate::check_types::St discharge_incls_128473) { return prism_rtl::finished(std::tuple{gg2, discharge_incls_128473}); }); }); }); });
                                });
                            });
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
            })
                : prism_rtl::finished(std::tuple{gg, s});
            });
            });
        }));
    }))));
}


prism_rtl::Turn<std::tuple<crate::check_env::G, crate::check_types::St>> TopLets::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    auto unsigned_ = filter(g.defs, [&](const crate::check_env::Def& d) { return is_let_def(d) && (!crate::check_env::has_key(g.vals, d.qk)); });
    auto [g1, st1] = fold(unsigned_, std::tuple{g, st}, [&](const std::tuple<crate::check_env::G, crate::check_types::St>& _p0, const crate::check_env::Def& d) {
        auto&& gg = std::get<0>(_p0);
        auto&& s = std::get<1>(_p0);
        return ({
            auto [v_, s2] = crate::check_types::fresh_var(s, false, d.name);
            auto gg2 = ({
                crate::check_env::G this_ = gg;
                this_.vals = insert(this_.vals, d.qk, crate::check_env::ValInfo{.qk = d.qk, .scheme = crate::check_types::mono(v_), .sort = Text::lit("let"), .has_sig = false, .home = d.home, .file = d->file, .span = d.span});
                this_;
            });
            std::tuple{gg2, s2};
        });
    });
    return fold_job(unsigned_, std::tuple{g1, st1}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check_env::G, crate::check_types::St>>(std::tuple<std::tuple<crate::check_env::G, crate::check_types::St>, crate::check_env::Def>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check_env::G, crate::check_types::St>, crate::check_env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [gg, s] = p0;
                auto d = p1;
                ({
                auto&& _m = d.body;
                prism_rtl::is<crate::check_env::DefBody::DbLet>(_m) ? ({
                auto&& l = prism_rtl::as<crate::check_env::DefBody::DbLet>(_m).a0;
                ({
                auto env = def_env(gg, d);
                auto s0 = ({
                    crate::check_types::St this_ = s;
                    this_.file = d->file;
                    this_.level = Nat(1u);
                    this_;
                });
                auto pre = or_(prelude::get(gg.vals, d.qk), dummy_val()).scheme.ty;
                auto l_1 = l;
                call_then(crate::check_expr::start_check(env, s0, l_1->value, pre), [=](crate::check_types::St check_127926) {
                return ({
                    auto s1 = check_127926;
                    call_then(crate::check_env::start_solve_wants(gg, s1, Array<std::tuple<Text, Text>>{}, false), [=](crate::check_types::St solve_wants_127975) {
                    return ({
                        auto s2 = solve_wants_127975;
                        auto s3 = ({
                            crate::check_types::St this_ = s2;
                            this_.level = Nat(0u);
                            this_;
                        });
                        call_then(crate::check_types::start_zonk(s3, pre), [=](crate::check_types::Ty zonk_128088) {
                        return ({
                            auto t = zonk_128088;
                            call_then(crate::check_expr::start_wants_above(s3, t, crate::check_expr::is_lambda(l_1->value)), [=](std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, crate::check_types::St> wants_above_128140) {
                            return ({
                                auto [keep, bounds, s4] = wants_above_128140;
                                call_then(crate::check_types::start_holds_node(s4, t), [=](bool holds_node_128209) {
                                return ({
                                    auto [sc, s5] = holds_node_128209
                                        ? std::tuple{crate::check_types::mono(t), s4}
                                        : crate::check_types::generalize(s4, t, keep, bounds);
                                    auto gg2 = ({
                                        crate::check_env::G this_ = gg;
                                        this_.vals = insert(this_.vals, d.qk, crate::check_env::ValInfo{.qk = d.qk, .scheme = sc, .sort = Text::lit("let"), .has_sig = false, .home = d.home, .file = d->file, .span = d.span});
                                        this_;
                                    });
                                    call_then(crate::check_types::start_check_colors(s5), [=](crate::check_types::St check_colors_128528) { return call_then(crate::check_env::start_resolve_fields(gg, check_colors_128528, true), [=](crate::check_types::St resolve_fields_128509) { return call_then(crate::check_types::start_layer_questions(resolve_fields_128509), [=](crate::check_types::St layer_questions_128493) { return call_then(start_discharge_incls(gg, layer_questions_128493, Nat(0u)), [=](crate::check_types::St discharge_incls_128473) { return prism_rtl::finished(std::tuple{gg2, discharge_incls_128473}); }); }); }); });
                                });
                            });
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
            })
                : prism_rtl::finished(std::tuple{gg, s});
            });
            });
        }));
    })))->cycle();
}


/// `Start TopLets, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check_env::G, crate::check_types::St>> start_top_lets(crate::check_env::G g, crate::check_types::St st) {
    return prism_rtl::make_rc<TopLets>(g, st);
}


/// let dummyVal
crate::check_env::ValInfo dummy_val() {
    return crate::check_env::ValInfo{.qk = Text::lit(""), .scheme = crate::check_types::mono(crate::check_types::Ty(crate::check_types::Ty::TyErr{})), .sort = Text::lit(""), .has_sig = false, .home = Text::lit(""), .file = Nat(0u), .span = crate::ast::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// IsLetDef: fn Def -> Bool
bool is_let_def(const crate::check_env::Def& d) {
    auto&& _m = d.body;
    if (prism_rtl::is<crate::check_env::DefBody::DbLet>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// DefEnv: fn G, Def -> Env
crate::check_expr::Env def_env(const crate::check_env::G& g, const crate::check_env::Def& d) {
    auto info = or_(prelude::get(g.mods, d.home), crate::check_env::dummy_mod());
    auto scope = ({
        __label__ _done;
        prism_rtl::Slot<crate::check_types::Rw> _v;
        auto&& _m = info.emit_rw.tail;
        if (prism_rtl::is<crate::check_types::Tail::TlQ>(_m)) {
            auto&& v_ = prism_rtl::as<crate::check_types::Tail::TlQ>(_m).a0;
            _v.set(crate::check_types::Rw{.fams = info.emit_rw.fams, .minus = Array<Text>{}, .tail = crate::check_types::Tail(crate::check_types::Tail::TlRigid{v_})});
            goto _done;
        }
        {
            _v.set(info.emit_rw);
            goto _done;
        }
    _done:
        _v.take();
    });
    return crate::check_expr::Env{.g = g, .home = d.home, .file = d->file, .src = or_(index(g.srcs, d->file), crate::check_errors::mk_src(Text::lit(""), Text::lit(""))), .locals = Map<Text, crate::check_types::Scheme>{}, .scope = scope, .givens = Array<std::tuple<Text, Text>>{}, .mark = Text::lit(""), .in_update = false, .def_name = d.name, .refine = Map<Text, crate::check_types::Ty>{}, .pending = Array<Text>{}};
}


/// CheckDef: unbounded fn G, St, Def -> St
crate::check_types::St check_def(const crate::check_env::G& g, const crate::check_types::St& st, const crate::check_env::Def& d) {
    auto env = def_env(g, d);
    auto incls_before = len(st.incls);
    auto s0 = ({
        crate::check_types::St this_ = st;
        this_.file = d->file;
        this_.level = Nat(1u);
        this_.color = crate::check_types::Col(crate::check_types::Col::CBound{});
        this_.color_why = Text::lit("");
        this_.color_flex = Array<std::tuple<crate::check_types::Col, Text, crate::ast::Range>>{};
        this_.cleqs = Array<crate::check_types::CLeq>{};
        this_;
    });
    auto s1 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check_types::St> _v;
        auto&& _m = d.body;
        if (prism_rtl::is<crate::check_env::DefBody::DbFn>(_m)) {
            auto&& clauses = prism_rtl::as<crate::check_env::DefBody::DbFn>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<crate::check_types::St> _v;
                auto&& _m = prelude::get(g.vals, d.qk);
                if (prism_rtl::is_some(_m)) {
                    auto&& v_ = prism_rtl::some_of(_m);
                    _v.set(crate::check_expr::check_clauses(env, s0, d.name, clauses, v_.scheme, d.span));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(s0);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::check_env::DefBody::DbWidget>(_m)) {
            auto&& w = prism_rtl::as<crate::check_env::DefBody::DbWidget>(_m).a0;
            _v.set(check_widget_def(env, s0, d, w));
            goto _done;
        }
        if (prism_rtl::is<crate::check_env::DefBody::DbLet>(_m)) {
            auto&& l = prism_rtl::as<crate::check_env::DefBody::DbLet>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<crate::check_types::St> _v;
                auto&& _m = prelude::get(g.vals, d.qk);
                if (prism_rtl::is_some(_m)) {
                    auto&& v_ = prism_rtl::some_of(_m);
                    _v.set(v_.has_sig
                        ? crate::check_expr::check(env, s0, l->value, crate::check_types::skolemize(v_.scheme))
                        : s0);
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(s0);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::check_env::DefBody::DbMethod>(_m)) {
            auto&& clauses = prism_rtl::as<crate::check_env::DefBody::DbMethod>(_m).a0;
            auto&& cls = prism_rtl::as<crate::check_env::DefBody::DbMethod>(_m).a1;
            auto&& im = prism_rtl::as<crate::check_env::DefBody::DbMethod>(_m).a2;
            _v.set(check_method(env, s0, d, clauses, cls, im));
            goto _done;
        }
        if (prism_rtl::is<crate::check_env::DefBody::DbDefault>(_m)) {
            auto&& clauses = prism_rtl::as<crate::check_env::DefBody::DbDefault>(_m).a0;
            auto&& cls = prism_rtl::as<crate::check_env::DefBody::DbDefault>(_m).a1;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<crate::check_types::St> _v;
                auto&& _m = method_key(g, cls, d.name);
                if (prism_rtl::is_some(_m)) {
                    auto&& mk = prism_rtl::some_of(_m);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<crate::check_types::St> _v;
                        auto&& _m = prelude::get(g.vals, mk);
                        if (prism_rtl::is_some(_m)) {
                            auto&& v_ = prism_rtl::some_of(_m);
                            _v.set(crate::check_expr::check_clauses(env, s0, d.name, clauses, v_.scheme, d.span));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(s0);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(s0);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::check_env::DefBody::DbCheck>(_m)) {
            auto&& c = prism_rtl::as<crate::check_env::DefBody::DbCheck>(_m).a0;
            _v.set(run_to_end(fold_job(c.lines, s0, ({
                auto env_1 = env;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check_types::St>(std::tuple<crate::check_types::St, crate::ast::CheckLine>)>>(prism_rtl::rc([=](std::tuple<crate::check_types::St, crate::ast::CheckLine> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto env_1_2 = env_1;
                    entered(once_job([=]() {
                    return ({
                        auto s = p0;
                        auto line = p1;
                        call_then(crate::check_expr::start_infer(env_1_2, s, line.expr), [=](std::tuple<crate::check_types::Ty, crate::check_types::St> infer_130542) {
                        return ({
                            auto [t, s2] = infer_130542;
                            ({
                            auto&& _m = line.pattern;
                            prism_rtl::is_some(_m) ? ({
                            auto&& p_ = prism_rtl::some_of(_m);
                            ({
                            auto p__2 = p_;
                            call_then(crate::check_expr::start_bind_pattern(env_1_2, s2, p__2, t, true), [=](std::tuple<crate::check_expr::Env, crate::check_types::St> bind_pattern_130661) {
                            return ({
                                auto&& _s3 = bind_pattern_130661;
                                auto&& s3 = std::get<1>(_s3);
                                (prism_rtl::finished(s3));
                            });
                        });
                        });
                        })
                            : prism_rtl::is_none(_m) ? prism_rtl::finished(s2)
                            : throw prism_rtl::Panic("no arm matched");
                        });
                        });
                    });
                    });
                }));
                });
            })));
            }))));
            goto _done;
        }
        if (prism_rtl::is<crate::check_env::DefBody::DbTest>(_m)) {
            auto&& t = prism_rtl::as<crate::check_env::DefBody::DbTest>(_m).a0;
            _v.set(({
                auto [bt, s2] = crate::check_expr::infer(env, s0, t.blueprint);
                ({
                __label__ _done;
                prism_rtl::Slot<crate::check_types::St> _v;
                auto&& _m = crate::check_types::walk(s2, bt);
                if (prism_rtl::is<crate::check_types::Ty::TyAt>(_m)) {
                    _v.set(s2);
                    goto _done;
                }
                if (prism_rtl::is<crate::check_types::Ty::TyErr>(_m)) {
                    _v.set(s2);
                    goto _done;
                }
                {
                    auto&& other = _m;
                    _v.set(crate::check_types::err(s2, Text::lit("mismatch"), t.blueprint.span, prism_rtl::cat("a test builds a blueprint; this is `", crate::check_types::show_ty(s2, other), "`")));
                    goto _done;
                }
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto solved = crate::check_types::check_colors(crate::check_env::solve_wants(g, s1, env.givens, false));
    auto defaulted = crate::check_types::layer_questions(crate::check_env::resolve_fields(g, default_def(g, solved), true));
    auto discharged = discharge_incls(g, defaulted, incls_before);
    crate::check_types::St this_ = discharged;
    this_.level = Nat(0u);
    return this_;
}


prism_rtl::Turn<crate::check_types::St> CheckDef::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& d = this->d;
    auto env = def_env(g, d);
    auto incls_before = len(st.incls);
    auto s0 = ({
        crate::check_types::St this_ = st;
        this_.file = d->file;
        this_.level = Nat(1u);
        this_.color = crate::check_types::Col(crate::check_types::Col::CBound{});
        this_.color_why = Text::lit("");
        this_.color_flex = Array<std::tuple<crate::check_types::Col, Text, crate::ast::Range>>{};
        this_.cleqs = Array<crate::check_types::CLeq>{};
        this_;
    });
    auto s1 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check_types::St> _v;
        auto&& _m = d.body;
        if (prism_rtl::is<crate::check_env::DefBody::DbFn>(_m)) {
            auto&& clauses = prism_rtl::as<crate::check_env::DefBody::DbFn>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<crate::check_types::St> _v;
                auto&& _m = prelude::get(g.vals, d.qk);
                if (prism_rtl::is_some(_m)) {
                    auto&& v_ = prism_rtl::some_of(_m);
                    _v.set(crate::check_expr::check_clauses(env, s0, d.name, clauses, v_.scheme, d.span));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(s0);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::check_env::DefBody::DbWidget>(_m)) {
            auto&& w = prism_rtl::as<crate::check_env::DefBody::DbWidget>(_m).a0;
            _v.set(check_widget_def(env, s0, d, w));
            goto _done;
        }
        if (prism_rtl::is<crate::check_env::DefBody::DbLet>(_m)) {
            auto&& l = prism_rtl::as<crate::check_env::DefBody::DbLet>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<crate::check_types::St> _v;
                auto&& _m = prelude::get(g.vals, d.qk);
                if (prism_rtl::is_some(_m)) {
                    auto&& v_ = prism_rtl::some_of(_m);
                    _v.set(v_.has_sig
                        ? crate::check_expr::check(env, s0, l->value, crate::check_types::skolemize(v_.scheme))
                        : s0);
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(s0);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::check_env::DefBody::DbMethod>(_m)) {
            auto&& clauses = prism_rtl::as<crate::check_env::DefBody::DbMethod>(_m).a0;
            auto&& cls = prism_rtl::as<crate::check_env::DefBody::DbMethod>(_m).a1;
            auto&& im = prism_rtl::as<crate::check_env::DefBody::DbMethod>(_m).a2;
            _v.set(check_method(env, s0, d, clauses, cls, im));
            goto _done;
        }
        if (prism_rtl::is<crate::check_env::DefBody::DbDefault>(_m)) {
            auto&& clauses = prism_rtl::as<crate::check_env::DefBody::DbDefault>(_m).a0;
            auto&& cls = prism_rtl::as<crate::check_env::DefBody::DbDefault>(_m).a1;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<crate::check_types::St> _v;
                auto&& _m = method_key(g, cls, d.name);
                if (prism_rtl::is_some(_m)) {
                    auto&& mk = prism_rtl::some_of(_m);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<crate::check_types::St> _v;
                        auto&& _m = prelude::get(g.vals, mk);
                        if (prism_rtl::is_some(_m)) {
                            auto&& v_ = prism_rtl::some_of(_m);
                            _v.set(crate::check_expr::check_clauses(env, s0, d.name, clauses, v_.scheme, d.span));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(s0);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(s0);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::check_env::DefBody::DbCheck>(_m)) {
            auto&& c = prism_rtl::as<crate::check_env::DefBody::DbCheck>(_m).a0;
            _v.set(run_to_end(fold_job(c.lines, s0, ({
                auto env_1 = env;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check_types::St>(std::tuple<crate::check_types::St, crate::ast::CheckLine>)>>(prism_rtl::rc([=](std::tuple<crate::check_types::St, crate::ast::CheckLine> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto env_1_2 = env_1;
                    entered(once_job([=]() {
                    return ({
                        auto s = p0;
                        auto line = p1;
                        call_then(crate::check_expr::start_infer(env_1_2, s, line.expr), [=](std::tuple<crate::check_types::Ty, crate::check_types::St> infer_130542) {
                        return ({
                            auto [t, s2] = infer_130542;
                            ({
                            auto&& _m = line.pattern;
                            prism_rtl::is_some(_m) ? ({
                            auto&& p_ = prism_rtl::some_of(_m);
                            ({
                            auto p__2 = p_;
                            call_then(crate::check_expr::start_bind_pattern(env_1_2, s2, p__2, t, true), [=](std::tuple<crate::check_expr::Env, crate::check_types::St> bind_pattern_130661) {
                            return ({
                                auto&& _s3 = bind_pattern_130661;
                                auto&& s3 = std::get<1>(_s3);
                                (prism_rtl::finished(s3));
                            });
                        });
                        });
                        })
                            : prism_rtl::is_none(_m) ? prism_rtl::finished(s2)
                            : throw prism_rtl::Panic("no arm matched");
                        });
                        });
                    });
                    });
                }));
                });
            })));
            }))));
            goto _done;
        }
        if (prism_rtl::is<crate::check_env::DefBody::DbTest>(_m)) {
            auto&& t = prism_rtl::as<crate::check_env::DefBody::DbTest>(_m).a0;
            _v.set(({
                auto [bt, s2] = crate::check_expr::infer(env, s0, t.blueprint);
                ({
                __label__ _done;
                prism_rtl::Slot<crate::check_types::St> _v;
                auto&& _m = crate::check_types::walk(s2, bt);
                if (prism_rtl::is<crate::check_types::Ty::TyAt>(_m)) {
                    _v.set(s2);
                    goto _done;
                }
                if (prism_rtl::is<crate::check_types::Ty::TyErr>(_m)) {
                    _v.set(s2);
                    goto _done;
                }
                {
                    auto&& other = _m;
                    _v.set(crate::check_types::err(s2, Text::lit("mismatch"), t.blueprint.span, prism_rtl::cat("a test builds a blueprint; this is `", crate::check_types::show_ty(s2, other), "`")));
                    goto _done;
                }
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto g_1 = g;
    return call_then(crate::check_env::start_solve_wants(g_1, s1, env.givens, false), [=](crate::check_types::St solve_wants_131060) {
        return call_then(crate::check_types::start_check_colors(solve_wants_131060), [=](crate::check_types::St check_colors_131047) {
            return ({
                auto solved = check_colors_131047;
                call_then(start_default_def(g_1, solved), [=](crate::check_types::St default_def_131151) {
                return call_then(crate::check_env::start_resolve_fields(g_1, default_def_131151, true), [=](crate::check_types::St resolve_fields_131133) {
                    return call_then(crate::check_types::start_layer_questions(resolve_fields_131133), [=](crate::check_types::St layer_questions_131117) {
                        return ({
                            auto defaulted = layer_questions_131117;
                            call_then(start_discharge_incls(g_1, defaulted, incls_before), [=](crate::check_types::St discharge_incls_131201) {
                            return ({
                                auto discharged = discharge_incls_131201;
                                (prism_rtl::finished(({
                                crate::check_types::St this_ = discharged;
                                this_.level = Nat(0u);
                                this_;
                            })));
                            });
                        });
                        });
                    });
                });
            });
            });
        });
    });
}


/// `Start CheckDef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check_types::St> start_check_def(crate::check_env::G g, crate::check_types::St st, crate::check_env::Def d) {
    return prism_rtl::make_rc<CheckDef>(g, st, d);
}


/// DefaultDef: unbounded fn G, St -> St
crate::check_types::St default_def(const crate::check_env::G& g, const crate::check_types::St& st) {
    auto mine = run_to_end(filter_job(st.wants, ({
        auto st_1 = st;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check_types::Want)>>(prism_rtl::rc([=](crate::check_types::Want p0) {
        return ({
            auto st_1_2 = st_1;
            entered(once_job([=]() {
            return ({
                auto w = p0;
                call_then(crate::check_types::start_walk(st_1_2, w.ty), [=](crate::check_types::Ty walk_131523) {
                return ({
                    prism_rtl::is<crate::check_types::Ty::TyFlex>(walk_131523) ? ({
                    auto&& n = prism_rtl::as<crate::check_types::Ty::TyFlex>(walk_131523).a0;
                    prism_rtl::finished(crate::check_types::info_of(st_1_2, n).level >= Nat(1u));
                })
                    : prism_rtl::finished(true);
                });
            });
            });
        }));
        });
    })));
    })));
    auto theirs = run_to_end(filter_job(st.wants, ({
        auto st_1 = st;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check_types::Want)>>(prism_rtl::rc([=](crate::check_types::Want p0) {
        return ({
            auto st_1_2 = st_1;
            entered(once_job([=]() {
            return ({
                auto w = p0;
                call_then(crate::check_types::start_walk(st_1_2, w.ty), [=](crate::check_types::Ty walk_131651) {
                return ({
                    prism_rtl::is<crate::check_types::Ty::TyFlex>(walk_131651) ? ({
                    auto&& n = prism_rtl::as<crate::check_types::Ty::TyFlex>(walk_131651).a0;
                    prism_rtl::finished(crate::check_types::info_of(st_1_2, n).level < Nat(1u));
                })
                    : prism_rtl::finished(false);
                });
            });
            });
        }));
        });
    })));
    })));
    auto st1 = ({
        crate::check_types::St this_ = st;
        this_.wants = mine;
        this_;
    });
    auto s2 = crate::check_env::default_wants(g, st1, Array<std::tuple<Text, Text>>{});
    crate::check_types::St this_ = s2;
    this_.wants = append(theirs, this_.wants);
    return this_;
}


prism_rtl::Turn<crate::check_types::St> DefaultDef::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    auto g_1 = g;
    auto st_2 = st;
    return call_value(filter_job(st_2.wants, ({
        auto st_2_3 = st_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check_types::Want)>>(prism_rtl::rc([=](crate::check_types::Want p0) {
        return ({
            auto st_2_3_3 = st_2_3;
            entered(once_job([=]() {
            return ({
                auto w = p0;
                call_then(crate::check_types::start_walk(st_2_3_3, w.ty), [=](crate::check_types::Ty walk_131523) {
                return ({
                    prism_rtl::is<crate::check_types::Ty::TyFlex>(walk_131523) ? ({
                    auto&& n = prism_rtl::as<crate::check_types::Ty::TyFlex>(walk_131523).a0;
                    prism_rtl::finished(crate::check_types::info_of(st_2_3_3, n).level >= Nat(1u));
                })
                    : prism_rtl::finished(true);
                });
            });
            });
        }));
        });
    })));
    })), [=](Array<crate::check_types::Want> filter_131495) {
        return ({
            auto mine = filter_131495;
            call_value(filter_job(st_2.wants, ({
            auto st_2_3 = st_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check_types::Want)>>(prism_rtl::rc([=](crate::check_types::Want p0) {
            return ({
                auto st_2_3_3 = st_2_3;
                entered(once_job([=]() {
                return ({
                    auto w = p0;
                    call_then(crate::check_types::start_walk(st_2_3_3, w.ty), [=](crate::check_types::Ty walk_131651) {
                    return ({
                        prism_rtl::is<crate::check_types::Ty::TyFlex>(walk_131651) ? ({
                        auto&& n = prism_rtl::as<crate::check_types::Ty::TyFlex>(walk_131651).a0;
                        prism_rtl::finished(crate::check_types::info_of(st_2_3_3, n).level < Nat(1u));
                    })
                        : prism_rtl::finished(false);
                    });
                });
                });
            }));
            });
        })));
        })), [=](Array<crate::check_types::Want> filter_131623) {
            return ({
                auto theirs = filter_131623;
                auto st1 = ({
                    crate::check_types::St this_ = st_2;
                    this_.wants = mine;
                    this_;
                });
                call_then(crate::check_env::start_default_wants(g_1, st1, Array<std::tuple<Text, Text>>{}), [=](crate::check_types::St default_wants_131797) {
                return ({
                    auto s2 = default_wants_131797;
                    (prism_rtl::finished(({
                    crate::check_types::St this_ = s2;
                    this_.wants = append(theirs, this_.wants);
                    this_;
                })));
                });
            });
            });
        });
        });
    });
}


/// `Start DefaultDef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check_types::St> start_default_def(crate::check_env::G g, crate::check_types::St st) {
    return prism_rtl::make_rc<DefaultDef>(g, st);
}


/// CheckWidgetDef: unbounded fn Env, St, Def, WidgetDecl -> St
crate::check_types::St check_widget_def(const crate::check_expr::Env& env, const crate::check_types::St& st, const crate::check_env::Def& d, const crate::ast::WidgetDecl& w) {
    auto&& _m = prelude::get(env.g.vals, d.qk);
    if (prism_rtl::is_some(_m)) {
        auto&& v_ = prism_rtl::some_of(_m);
        auto&& _m = crate::check_types::skolemize(v_.scheme);
        if (prism_rtl::is<crate::check_types::Ty::TyAt>(_m)) {
            auto&& inner = prism_rtl::as<crate::check_types::Ty::TyAt>(_m).a0;
            auto&& rw = prism_rtl::as<crate::check_types::Ty::TyAt>(_m).a1;
            auto env2 = ({
                crate::check_expr::Env this_ = env;
                this_.scope = rw;
                this_.mark = Text::lit("@");
                this_;
            });
            auto [t, st2] = crate::check_blocks::infer_widget_block(env2, st, w.body);
            return crate::check_types::note_fn(crate::check_types::unify(st2, inner, t, w.span), w.span, d.name, crate::check_types::Col(crate::check_types::Col::CBound{}), st2.color);
        }
        {
            auto&& other = _m;
            return crate::check_types::err(st, Text::lit("mismatch"), w.span, prism_rtl::cat("`", d.name, "` is declared `", crate::check_types::show_ty(st, other), "`; a widget block builds a blueprint"));
        }
    }
    if (prism_rtl::is_none(_m)) {
        auto [t, st2] = crate::check_blocks::infer_widget_block(env, st, w.body);
        return crate::check_types::note_fn(st2, w.span, d.name, crate::check_types::Col(crate::check_types::Col::CBound{}), st2.color);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::check_types::St> CheckWidgetDef::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& d = this->d;
    const auto& w = this->w;
    return ({
        auto&& _m = prelude::get(env.g.vals, d.qk);
        prism_rtl::is_some(_m) ? ({
        auto&& v_ = prism_rtl::some_of(_m);
        ({
        auto d_1 = d;
        auto env_2 = env;
        auto st_3 = st;
        auto w_4 = w;
        call_then(crate::check_types::start_skolemize(v_.scheme), [=](crate::check_types::Ty skolemize_132103) {
        return ({
            prism_rtl::is<crate::check_types::Ty::TyAt>(skolemize_132103) ? ({
            auto&& inner = prism_rtl::as<crate::check_types::Ty::TyAt>(skolemize_132103).a0;
            auto&& rw = prism_rtl::as<crate::check_types::Ty::TyAt>(skolemize_132103).a1;
            ({
            auto env2 = ({
                crate::check_expr::Env this_ = env_2;
                this_.scope = rw;
                this_.mark = Text::lit("@");
                this_;
            });
            call_then(crate::check_blocks::start_infer_widget_block(env2, st_3, w_4.body), [=](std::tuple<crate::check_types::Ty, crate::check_types::St> infer_widget_block_132273) {
            return ({
                auto [t, st2] = infer_widget_block_132273;
                call_then(crate::check_types::start_unify(st2, inner, t, w_4.span), [=](crate::check_types::St unify_132327) { return prism_rtl::finished(crate::check_types::note_fn(unify_132327, w_4.span, d_1.name, crate::check_types::Col(crate::check_types::Col::CBound{}), st2.color)); });
            });
        });
        });
        })
            : ({
            auto&& other = skolemize_132103;
            call_then(crate::check_types::start_show_ty(st_3, other), [=](Text show_ty_132460) { return prism_rtl::finished(crate::check_types::err(st_3, Text::lit("mismatch"), w_4.span, prism_rtl::cat("`", d_1.name, "` is declared `", show_ty_132460, "`; a widget block builds a blueprint"))); });
        });
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto d_1 = d;
        auto env_2 = env;
        auto st_3 = st;
        auto w_4 = w;
        call_then(crate::check_blocks::start_infer_widget_block(env_2, st_3, w_4.body), [=](std::tuple<crate::check_types::Ty, crate::check_types::St> infer_widget_block_132549) {
        return ({
            auto [t, st2] = infer_widget_block_132549;
            (prism_rtl::finished(crate::check_types::note_fn(st2, w_4.span, d_1.name, crate::check_types::Col(crate::check_types::Col::CBound{}), st2.color)));
        });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CheckWidgetDef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check_types::St> start_check_widget_def(crate::check_expr::Env env, crate::check_types::St st, crate::check_env::Def d, crate::ast::WidgetDecl w) {
    return prism_rtl::make_rc<CheckWidgetDef>(env, st, d, w);
}


/// ?MethodKey: fn G, Text, Text -> ?Text
std::optional<Text> method_key(const crate::check_env::G& g, const Text& cls, const Text& name) {
    return fold(or_(prelude::get(g.traits, cls), crate::check_env::dummy_trait()).methods, std::optional<Text>{}, [&](const std::optional<Text>& found_opt, const Text& k) {
        return ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Text>> _v;
            if (prism_rtl::is_some(found_opt)) {
                auto&& f = prism_rtl::some_of(found_opt);
                _v.set(std::optional(f));
                goto _done;
            }
            if (prism_rtl::is_none(found_opt)) {
                _v.set((crate::check_types::bare_name(k) == name) || (crate::lexer::drop_prefix(k, prism_rtl::cat(or_(prelude::get(g.traits, cls), crate::check_env::dummy_trait()).home, ".")) == name)
                    ? std::optional(k)
                    : std::optional<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// CheckMethod: unbounded fn Env, St, Def, [FnClause], Text, ImplInfo -> St
crate::check_types::St check_method(const crate::check_expr::Env& env, const crate::check_types::St& st, const crate::check_env::Def& d, const Array<crate::ast::FnClause>& clauses, const Text& cls, const crate::check_env::ImplInfo& im) {
    auto&& _m = method_key(env.g, cls, d.name);
    if (prism_rtl::is_none(_m)) {
        return crate::check_types::err(st, Text::lit("mismatch"), d.span, prism_rtl::cat("`^", crate::check_types::bare_name(cls), "` has no method `", d.name, "`"));
    }
    if (prism_rtl::is_some(_m)) {
        auto&& mk = prism_rtl::some_of(_m);
        auto&& _m = prelude::get(env.g.vals, mk);
        if (prism_rtl::is_none(_m)) {
            return st;
        }
        if (prism_rtl::is_some(_m)) {
            auto&& v_ = prism_rtl::some_of(_m);
            auto ti = or_(prelude::get(env.g.traits, cls), crate::check_env::dummy_trait());
            auto head = crate::check_types::subst_q(crate::check_types::Inst{.tys = fold(im.qs, Map<Text, crate::check_types::Ty>{}, [&](const Map<Text, crate::check_types::Ty>& m, const Text& q) { return insert(m, q, crate::check_types::Ty(crate::check_types::Ty::TyRigid{q})); }), .rows = Map<Text, crate::check_types::Tail>{}, .cols = Map<Text, crate::check_types::Col>{}}, im.head);
            auto ty = crate::check_types::subst_q(crate::check_types::Inst{.tys = map_of(std::vector{std::tuple{ti.param, head}}), .rows = Map<Text, crate::check_types::Tail>{}, .cols = Map<Text, crate::check_types::Col>{}}, v_.scheme.ty);
            auto sc = crate::check_types::Scheme{.qs = filter(v_.scheme.qs, [&](const Text& q) { return q != ti.param; }), .plain_qs = Array<Text>{}, .rqs = v_.scheme.rqs, .cqs = v_.scheme.cqs, .cjoins = v_.scheme.cjoins, .bounds = filter(v_.scheme.bounds, [&](const std::tuple<Text, Text>& _p0) {
                auto&& q = std::get<0>(_p0);
                return q != ti.param;
            }), .ty = ty};
            auto env2 = ({
                crate::check_expr::Env this_ = env;
                this_.givens = im.bounds;
                this_;
            });
            return crate::check_expr::check_clauses(env2, st, d.name, clauses, sc, d.span);
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::check_types::St> CheckMethod::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& d = this->d;
    const auto& clauses = this->clauses;
    const auto& cls = this->cls;
    const auto& im = this->im;
    return ({
        auto&& _m = method_key(env.g, cls, d.name);
        prism_rtl::is_none(_m) ? prism_rtl::finished(crate::check_types::err(st, Text::lit("mismatch"), d.span, prism_rtl::cat("`^", crate::check_types::bare_name(cls), "` has no method `", d.name, "`")))
        : prism_rtl::is_some(_m) ? ({
        auto&& mk = prism_rtl::some_of(_m);
        ({
        auto&& _m = prelude::get(env.g.vals, mk);
        prism_rtl::is_none(_m) ? prism_rtl::finished(st)
        : prism_rtl::is_some(_m) ? ({
        auto&& v_ = prism_rtl::some_of(_m);
        ({
        auto ti = or_(prelude::get(env.g.traits, cls), crate::check_env::dummy_trait());
        auto clauses_1 = clauses;
        auto d_2 = d;
        auto env_3 = env;
        auto im_4 = im;
        auto st_5 = st;
        call_then(crate::check_types::start_subst_q(crate::check_types::Inst{.tys = fold(im_4.qs, Map<Text, crate::check_types::Ty>{}, [&](const Map<Text, crate::check_types::Ty>& m, const Text& q) { return insert(m, q, crate::check_types::Ty(crate::check_types::Ty::TyRigid{q})); }), .rows = Map<Text, crate::check_types::Tail>{}, .cols = Map<Text, crate::check_types::Col>{}}, im_4.head), [=](crate::check_types::Ty subst_q_133420) {
        return ({
            auto head = subst_q_133420;
            call_then(crate::check_types::start_subst_q(crate::check_types::Inst{.tys = map_of(std::vector{std::tuple{ti.param, head}}), .rows = Map<Text, crate::check_types::Tail>{}, .cols = Map<Text, crate::check_types::Col>{}}, v_.scheme.ty), [=](crate::check_types::Ty subst_q_133538) {
            return ({
                auto ty = subst_q_133538;
                auto sc = crate::check_types::Scheme{.qs = filter(v_.scheme.qs, [&](const Text& q) { return q != ti.param; }), .plain_qs = Array<Text>{}, .rqs = v_.scheme.rqs, .cqs = v_.scheme.cqs, .cjoins = v_.scheme.cjoins, .bounds = filter(v_.scheme.bounds, [&](const std::tuple<Text, Text>& _p0) {
                    auto&& q = std::get<0>(_p0);
                    return q != ti.param;
                }), .ty = ty};
                auto env2 = ({
                    crate::check_expr::Env this_ = env_3;
                    this_.givens = im_4.bounds;
                    this_;
                });
                (prism_rtl::more(prism_rtl::rc(crate::check_expr::CheckClauses(env2, st_5, d_2.name, clauses_1, sc, d_2.span))));
            });
        });
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CheckMethod, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check_types::St> start_check_method(crate::check_expr::Env env, crate::check_types::St st, crate::check_env::Def d, Array<crate::ast::FnClause> clauses, Text cls, crate::check_env::ImplInfo im) {
    return prism_rtl::make_rc<CheckMethod>(env, st, d, clauses, cls, im);
}


/// RootRow: unbounded fn G, St, [Text] -> ((Text, St))
std::tuple<Text, crate::check_types::St> root_row(const crate::check_env::G& g, const crate::check_types::St& st, const Array<Text>& world) {
    auto&& _m = prelude::get(g.mods, Text::lit(""));
    if (prism_rtl::is_none(_m)) {
        return std::tuple{Text::lit(""), st};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& info = prism_rtl::some_of(_m);
        auto shown = crate::check_types::show_row(info.emit_rw);
        return len(world) == Nat(0u)
            ? std::tuple{shown, st}
            : ({
            auto missing = filter(info.emit_rw.fams, [&](const Text& f) { return !crate::check_types::has_text(world, f); });
            len(missing) == Nat(0u)
            ? std::tuple{shown, st}
            : ({
            auto s0 = ({
                crate::check_types::St this_ = st;
                this_.file = info->file;
                this_;
            });
            std::tuple{shown, crate::check_types::err_fix(s0, Text::lit("world-row"), info.tree.span, prism_rtl::cat("the program emits ", crate::lexer::join(each(missing, [&](const Text& f) { return prism_rtl::cat("`", f, ".*`"); }), Text::lit(", ")), ", which this World does not answer"), Text::lit("host the tags it cannot answer, or run under a World that answers them"))};
        });
        });
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<Text, crate::check_types::St>> RootRow::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& world = this->world;
    return ({
        auto&& _m = prelude::get(g.mods, Text::lit(""));
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{Text::lit(""), st})
        : prism_rtl::is_some(_m) ? ({
        auto&& info = prism_rtl::some_of(_m);
        ({
        auto shown = crate::check_types::show_row(info.emit_rw);
        len(world) == Nat(0u)
        ? prism_rtl::finished(std::tuple{shown, st})
        : ({
        auto missing = filter(info.emit_rw.fams, [&](const Text& f) { return !crate::check_types::has_text(world, f); });
        len(missing) == Nat(0u)
        ? prism_rtl::finished(std::tuple{shown, st})
        : ({
        auto s0 = ({
            crate::check_types::St this_ = st;
            this_.file = info->file;
            this_;
        });
        (prism_rtl::finished(std::tuple{shown, crate::check_types::err_fix(s0, Text::lit("world-row"), info.tree.span, prism_rtl::cat("the program emits ", crate::lexer::join(each(missing, [&](const Text& f) { return prism_rtl::cat("`", f, ".*`"); }), Text::lit(", ")), ", which this World does not answer"), Text::lit("host the tags it cannot answer, or run under a World that answers them"))}));
    });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start RootRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::check_types::St>> start_root_row(crate::check_env::G g, crate::check_types::St st, Array<Text> world) {
    return prism_rtl::make_rc<RootRow>(g, st, world);
}

}  // namespace crate::check_passes
