// The module `CheckPasses`, from `target/bootstrap/cpp-src/prismc/check-passes.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include <check_passes/module.hpp>
#include <ast/module.hpp>
#include <check_env/module.hpp>
#include <typed/module.hpp>
#include <check_blocks/module.hpp>
#include <check_errors/module.hpp>
#include <check_expr/module.hpp>
#include <check_types/module.hpp>
#include <lexer/module.hpp>
#include <check_env/generic.hpp>
#include <lexer/generic.hpp>

namespace crate::check_passes {

prism_rtl::Turn<Map<Text, bool>> ArrowyFrom::cycle() const {
    const auto& names = this->names;
    const auto& got = this->got;
    auto next = fold(keys(names), got, [&](const Map<Text, bool>& m, const Text& n) {
        return crate::check_env::has_key(m, n)
            ? m
            : fold(or_(prelude::get(names, n), Array<Text>{}), false, [&](const bool& seen, const Text& r) { return seen || crate::check_env::has_key(got, r); })
            ? insert(m, n, true)
            : m;
    });
    return len(keys(next)) == len(keys(got))
        ? prism_rtl::finished(got)
        : prism_rtl::more(prism_rtl::rc(ArrowyFrom(names, next)));
}


/// `Start ArrowyFrom, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, bool>> start_arrowy_from(Map<Text, Array<Text>> names, Map<Text, bool> got) {
    return prism_rtl::make_rc<ArrowyFrom>(names, got);
}


/// TyNamesIn: unbounded fn Ty -> [Text]
Array<Text> ty_names_in(const crate::check_types::Ty& t) {
    if (prism_rtl::is<crate::check_types::Ty::TyCon>(t)) {
        auto&& c = prism_rtl::as<crate::check_types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check_types::Ty::TyCon>(t).a1;
        return run_to_end(fold_job(args, Array(std::vector{c}), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check_types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_ty_names_in(a), [=](Array<Text> ty_names_in_43634) { return prism_rtl::finished(crate::check_types::union_texts(acc, ty_names_in_43634)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::check_types::Ty::TyFn>(t)) {
        auto&& ps = prism_rtl::as<crate::check_types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<crate::check_types::Ty::TyFn>(t).a2;
        return run_to_end(fold_job(ps, ty_names_in(res), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check_types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_ty_names_in(a), [=](Array<Text> ty_names_in_43726) { return prism_rtl::finished(crate::check_types::union_texts(acc, ty_names_in_43726)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::check_types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::check_types::Ty::TyTuple>(t).a0;
        return run_to_end(fold_job(ts, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check_types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_ty_names_in(a), [=](Array<Text> ty_names_in_43797) { return prism_rtl::finished(crate::check_types::union_texts(acc, ty_names_in_43797)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::check_types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<crate::check_types::Ty::TyArray>(t).a0;
        return ty_names_in(e);
    }
    if (prism_rtl::is<crate::check_types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<crate::check_types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check_types::Ty::TyMap>(t).a1;
        return crate::check_types::union_texts(ty_names_in(k), ty_names_in(v_));
    }
    if (prism_rtl::is<crate::check_types::Ty::TySig>(t)) {
        auto&& i = prism_rtl::as<crate::check_types::Ty::TySig>(t).a1;
        return ty_names_in(i);
    }
    if (prism_rtl::is<crate::check_types::Ty::TyAt>(t)) {
        auto&& i = prism_rtl::as<crate::check_types::Ty::TyAt>(t).a0;
        return ty_names_in(i);
    }
    if (prism_rtl::is<crate::check_types::Ty::TyElem>(t)) {
        auto&& i = prism_rtl::as<crate::check_types::Ty::TyElem>(t).a1;
        return ty_names_in(i);
    }
    if (prism_rtl::is<crate::check_types::Ty::TyAssoc>(t)) {
        auto&& i = prism_rtl::as<crate::check_types::Ty::TyAssoc>(t).a1;
        return ty_names_in(i);
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> TyNamesIn::cycle() const {
    const auto& t = this->t;
    return ({
        prism_rtl::is<crate::check_types::Ty::TyCon>(t) ? ({
        auto&& c = prism_rtl::as<crate::check_types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check_types::Ty::TyCon>(t).a1;
        fold_job(args, Array(std::vector{c}), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check_types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto a = p1;
                call_then(start_ty_names_in(a), [=](Array<Text> ty_names_in_43634) { return prism_rtl::finished(crate::check_types::union_texts(acc, ty_names_in_43634)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::check_types::Ty::TyFn>(t) ? ({
        auto&& ps = prism_rtl::as<crate::check_types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<crate::check_types::Ty::TyFn>(t).a2;
        ({
        auto ps_1 = ps;
        auto res_2 = res;
        call_then(start_ty_names_in(res_2), [=](Array<Text> ty_names_in_43683) {
        return fold_job(ps_1, ty_names_in_43683, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check_types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_ty_names_in(a), [=](Array<Text> ty_names_in_43726) { return prism_rtl::finished(crate::check_types::union_texts(acc, ty_names_in_43726)); });
                });
            }));
        })))->cycle();
    });
    });
    })
        : prism_rtl::is<crate::check_types::Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<crate::check_types::Ty::TyTuple>(t).a0;
        fold_job(ts, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check_types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto a = p1;
                call_then(start_ty_names_in(a), [=](Array<Text> ty_names_in_43797) { return prism_rtl::finished(crate::check_types::union_texts(acc, ty_names_in_43797)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::check_types::Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<crate::check_types::Ty::TyArray>(t).a0;
        prism_rtl::more(prism_rtl::rc(TyNamesIn(e)));
    })
        : prism_rtl::is<crate::check_types::Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<crate::check_types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check_types::Ty::TyMap>(t).a1;
        ({
        auto k_1 = k;
        auto v__2 = v_;
        call_then(start_ty_names_in(k_1), [=](Array<Text> ty_names_in_43865) { return call_then(start_ty_names_in(v__2), [=](Array<Text> ty_names_in_43880) { return prism_rtl::finished(crate::check_types::union_texts(ty_names_in_43865, ty_names_in_43880)); }); });
    });
    })
        : prism_rtl::is<crate::check_types::Ty::TySig>(t) ? ({
        auto&& i = prism_rtl::as<crate::check_types::Ty::TySig>(t).a1;
        prism_rtl::more(prism_rtl::rc(TyNamesIn(i)));
    })
        : prism_rtl::is<crate::check_types::Ty::TyAt>(t) ? ({
        auto&& i = prism_rtl::as<crate::check_types::Ty::TyAt>(t).a0;
        prism_rtl::more(prism_rtl::rc(TyNamesIn(i)));
    })
        : prism_rtl::is<crate::check_types::Ty::TyElem>(t) ? ({
        auto&& i = prism_rtl::as<crate::check_types::Ty::TyElem>(t).a1;
        prism_rtl::more(prism_rtl::rc(TyNamesIn(i)));
    })
        : prism_rtl::is<crate::check_types::Ty::TyAssoc>(t) ? ({
        auto&& i = prism_rtl::as<crate::check_types::Ty::TyAssoc>(t).a1;
        prism_rtl::more(prism_rtl::rc(TyNamesIn(i)));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start TyNamesIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_ty_names_in(crate::check_types::Ty t) {
    return prism_rtl::make_rc<TyNamesIn>(t);
}


/// HasArrow: unbounded fn Ty -> Bool
bool has_arrow(const crate::check_types::Ty& t) {
    if (prism_rtl::is<crate::check_types::Ty::TyFn>(t)) {
        return true;
    }
    if (prism_rtl::is<crate::check_types::Ty::TyCon>(t)) {
        auto&& args = prism_rtl::as<crate::check_types::Ty::TyCon>(t).a1;
        return run_to_end(fold_job(args, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check_types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto a = p1;
                    (prism_rtl::finished(seen || has_arrow(a)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::check_types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::check_types::Ty::TyTuple>(t).a0;
        return run_to_end(fold_job(ts, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check_types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto a = p1;
                    (prism_rtl::finished(seen || has_arrow(a)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::check_types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<crate::check_types::Ty::TyArray>(t).a0;
        return has_arrow(e);
    }
    if (prism_rtl::is<crate::check_types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<crate::check_types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check_types::Ty::TyMap>(t).a1;
        return has_arrow(k) || has_arrow(v_);
    }
    if (prism_rtl::is<crate::check_types::Ty::TySig>(t)) {
        auto&& i = prism_rtl::as<crate::check_types::Ty::TySig>(t).a1;
        return has_arrow(i);
    }
    if (prism_rtl::is<crate::check_types::Ty::TyAt>(t)) {
        auto&& i = prism_rtl::as<crate::check_types::Ty::TyAt>(t).a0;
        return has_arrow(i);
    }
    if (prism_rtl::is<crate::check_types::Ty::TyElem>(t)) {
        auto&& i = prism_rtl::as<crate::check_types::Ty::TyElem>(t).a1;
        return has_arrow(i);
    }
    if (prism_rtl::is<crate::check_types::Ty::TyAssoc>(t)) {
        auto&& i = prism_rtl::as<crate::check_types::Ty::TyAssoc>(t).a1;
        return has_arrow(i);
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> HasArrow::cycle() const {
    const auto& t = this->t;
    return ({
        prism_rtl::is<crate::check_types::Ty::TyFn>(t) ? prism_rtl::finished(true)
        : prism_rtl::is<crate::check_types::Ty::TyCon>(t) ? ({
        auto&& args = prism_rtl::as<crate::check_types::Ty::TyCon>(t).a1;
        fold_job(args, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check_types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto seen = p0;
                auto a = p1;
                (prism_rtl::finished(seen || has_arrow(a)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::check_types::Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<crate::check_types::Ty::TyTuple>(t).a0;
        fold_job(ts, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check_types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto seen = p0;
                auto a = p1;
                (prism_rtl::finished(seen || has_arrow(a)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::check_types::Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<crate::check_types::Ty::TyArray>(t).a0;
        prism_rtl::more(prism_rtl::rc(HasArrow(e)));
    })
        : prism_rtl::is<crate::check_types::Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<crate::check_types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check_types::Ty::TyMap>(t).a1;
        ({
        auto k_1 = k;
        auto v__2 = v_;
        call_then(start_has_arrow(k_1), [=](bool has_arrow_44322) { return prism_rtl::finished(has_arrow_44322 || has_arrow(v__2)); });
    });
    })
        : prism_rtl::is<crate::check_types::Ty::TySig>(t) ? ({
        auto&& i = prism_rtl::as<crate::check_types::Ty::TySig>(t).a1;
        prism_rtl::more(prism_rtl::rc(HasArrow(i)));
    })
        : prism_rtl::is<crate::check_types::Ty::TyAt>(t) ? ({
        auto&& i = prism_rtl::as<crate::check_types::Ty::TyAt>(t).a0;
        prism_rtl::more(prism_rtl::rc(HasArrow(i)));
    })
        : prism_rtl::is<crate::check_types::Ty::TyElem>(t) ? ({
        auto&& i = prism_rtl::as<crate::check_types::Ty::TyElem>(t).a1;
        prism_rtl::more(prism_rtl::rc(HasArrow(i)));
    })
        : prism_rtl::is<crate::check_types::Ty::TyAssoc>(t) ? ({
        auto&& i = prism_rtl::as<crate::check_types::Ty::TyAssoc>(t).a1;
        prism_rtl::more(prism_rtl::rc(HasArrow(i)));
    })
        : prism_rtl::finished(false);
    });
}


/// `Start HasArrow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_has_arrow(crate::check_types::Ty t) {
    return prism_rtl::make_rc<HasArrow>(t);
}


/// BodyTys: fn TyInfo -> [Ty]
Array<crate::check_types::Ty> body_tys(const crate::check_env::TyInfo& ti) {
    auto&& _m = ti.body;
    if (prism_rtl::is<crate::check_env::TyBody::BRecord>(_m)) {
        auto&& fields = prism_rtl::as<crate::check_env::TyBody::BRecord>(_m).a0;
        return each(fields, [&](const std::tuple<Text, crate::check_types::Ty>& _p0) {
            auto&& t = std::get<1>(_p0);
            return t;
        });
    }
    if (prism_rtl::is<crate::check_env::TyBody::BChoice>(_m)) {
        auto&& cases = prism_rtl::as<crate::check_env::TyBody::BChoice>(_m).a0;
        return fold(cases, Array<crate::check_types::Ty>{}, [&](const Array<crate::check_types::Ty>& acc, const std::tuple<Text, Array<crate::check_types::Ty>>& _p1) {
            auto&& args = std::get<1>(_p1);
            return append(acc, args);
        });
    }
    if (prism_rtl::is<crate::check_env::TyBody::BAlias>(_m)) {
        auto&& t = prism_rtl::as<crate::check_env::TyBody::BAlias>(_m).a0;
        return Array(std::vector{t});
    }
    {
        return Array<crate::check_types::Ty>{};
    }
}


/// NegWalk: unbounded fn G, Text, Ty, Bool, (Text ==> Bool) -> ((Bool, (Text ==> Bool)))
std::tuple<bool, Map<Text, bool>> neg_walk(const crate::check_env::G& g, const Text& target, const crate::check_types::Ty& t, const bool& b, const Map<Text, bool>& seen) {
    if (prism_rtl::is<crate::check_types::Ty::TyCon>(t)) {
        auto&& c = prism_rtl::as<crate::check_types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check_types::Ty::TyCon>(t).a1;
        return c == target
            ? std::tuple{b, seen}
            : ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<bool, Map<Text, bool>>> _v;
            auto&& _m = prelude::get(g.types, c);
            if (prism_rtl::is_some(_m)) {
                auto&& ti = prism_rtl::some_of(_m);
                _v.set(({
                    auto sk = prism_rtl::cat(b ? Text::lit("-") : Text::lit("+"), crate::check_types::show_ty(crate::check_types::new_st(Nat(0u)), t));
                    (crate::check_env::has_key(seen, sk)
                    ? std::tuple{false, seen}
                    : len(keys(seen)) > Nat(400u)
                    ? std::tuple{true, seen}
                    : neg_walks(g, target, run_to_end(each_job(body_tys(ti), ({
                    auto ti_1 = ti;
                    auto args_2 = args;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check_types::Ty>(crate::check_types::Ty)>>(prism_rtl::rc([=](crate::check_types::Ty p0) {
                    return ({
                        auto ti_1_3 = ti_1;
                        auto args_2_3 = args_2;
                        entered(once_job([=]() {
                        return ({
                            auto bt = p0;
                            (prism_rtl::more(prism_rtl::rc(crate::check_types::SubstQ(crate::check_env::param_inst(ti_1_3.params, args_2_3), bt))));
                        });
                    }));
                    });
                })));
                }))), b, insert(seen, sk, true)));
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(neg_walks(g, target, args, b, seen));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is<crate::check_types::Ty::TyFn>(t)) {
        auto&& col = prism_rtl::as<crate::check_types::Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<crate::check_types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<crate::check_types::Ty::TyFn>(t).a2;
        auto [bad, seen2] = neg_walks(g, target, ps, b || (col != crate::check_types::Col(crate::check_types::Col::CUnbound{})), seen);
        return bad ? std::tuple{true, seen2} : neg_walk(g, target, res, b, seen2);
    }
    if (prism_rtl::is<crate::check_types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::check_types::Ty::TyTuple>(t).a0;
        return neg_walks(g, target, ts, b, seen);
    }
    if (prism_rtl::is<crate::check_types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<crate::check_types::Ty::TyArray>(t).a0;
        return neg_walk(g, target, e, b, seen);
    }
    if (prism_rtl::is<crate::check_types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<crate::check_types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check_types::Ty::TyMap>(t).a1;
        return neg_walks(g, target, Array(std::vector{k, v_}), b, seen);
    }
    if (prism_rtl::is<crate::check_types::Ty::TySig>(t)) {
        auto&& i = prism_rtl::as<crate::check_types::Ty::TySig>(t).a1;
        return neg_walk(g, target, i, b, seen);
    }
    if (prism_rtl::is<crate::check_types::Ty::TyAt>(t)) {
        auto&& i = prism_rtl::as<crate::check_types::Ty::TyAt>(t).a0;
        return neg_walk(g, target, i, b, seen);
    }
    if (prism_rtl::is<crate::check_types::Ty::TyElem>(t)) {
        auto&& i = prism_rtl::as<crate::check_types::Ty::TyElem>(t).a1;
        return neg_walk(g, target, i, b, seen);
    }
    if (prism_rtl::is<crate::check_types::Ty::TyAssoc>(t)) {
        auto&& i = prism_rtl::as<crate::check_types::Ty::TyAssoc>(t).a1;
        return neg_walk(g, target, i, b, seen);
    }
    {
        return std::tuple{false, seen};
    }
}


prism_rtl::Turn<std::tuple<bool, Map<Text, bool>>> NegWalk::cycle() const {
    const auto& g = this->g;
    const auto& target = this->target;
    const auto& t = this->t;
    const auto& b = this->b;
    const auto& seen = this->seen;
    return ({
        prism_rtl::is<crate::check_types::Ty::TyCon>(t) ? ({
        auto&& c = prism_rtl::as<crate::check_types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check_types::Ty::TyCon>(t).a1;
        c == target
        ? prism_rtl::finished(std::tuple{b, seen})
        : ({
        auto&& _m = prelude::get(g.types, c);
        prism_rtl::is_some(_m) ? ({
        auto&& ti = prism_rtl::some_of(_m);
        ({
        auto args_1 = args;
        auto b_2 = b;
        auto g_3 = g;
        auto seen_4 = seen;
        auto t_5 = t;
        auto target_6 = target;
        call_then(crate::check_types::start_show_ty(crate::check_types::new_st(Nat(0u)), t_5), [=](Text show_ty_45459) {
        return ({
            auto sk = prism_rtl::cat(b_2 ? Text::lit("-") : Text::lit("+"), show_ty_45459);
            (crate::check_env::has_key(seen_4, sk)
            ? prism_rtl::finished(std::tuple{false, seen_4})
            : len(keys(seen_4)) > Nat(400u)
            ? prism_rtl::finished(std::tuple{true, seen_4})
            : call_value(each_job(body_tys(ti), ({
            auto ti_7 = ti;
            auto args_1_8 = args_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check_types::Ty>(crate::check_types::Ty)>>(prism_rtl::rc([=](crate::check_types::Ty p0) {
            return ({
                auto ti_7_8 = ti_7;
                auto args_1_8_8 = args_1_8;
                entered(once_job([=]() {
                return ({
                    auto bt = p0;
                    (prism_rtl::more(prism_rtl::rc(crate::check_types::SubstQ(crate::check_env::param_inst(ti_7_8.params, args_1_8_8), bt))));
                });
            }));
            });
        })));
        })), [=](Array<crate::check_types::Ty> each_45641) { return prism_rtl::more(prism_rtl::rc(NegWalks(g_3, target_6, each_45641, b_2, insert(seen_4, sk, true)))); }));
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(NegWalks(g, target, args, b, seen)))
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is<crate::check_types::Ty::TyFn>(t) ? ({
        auto&& col = prism_rtl::as<crate::check_types::Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<crate::check_types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<crate::check_types::Ty::TyFn>(t).a2;
        ({
        auto b_1 = b;
        auto col_2 = col;
        auto g_3 = g;
        auto ps_4 = ps;
        auto res_5 = res;
        auto seen_6 = seen;
        auto target_7 = target;
        call_then(start_neg_walks(g_3, target_7, ps_4, b_1 || (col_2 != crate::check_types::Col(crate::check_types::Col::CUnbound{})), seen_6), [=](std::tuple<bool, Map<Text, bool>> neg_walks_45837) {
        return ({
            auto [bad, seen2] = neg_walks_45837;
            bad
            ? prism_rtl::finished(std::tuple{true, seen2})
            : prism_rtl::more(prism_rtl::rc(NegWalk(g_3, target_7, res_5, b_1, seen2)));
        });
    });
    });
    })
        : prism_rtl::is<crate::check_types::Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<crate::check_types::Ty::TyTuple>(t).a0;
        prism_rtl::more(prism_rtl::rc(NegWalks(g, target, ts, b, seen)));
    })
        : prism_rtl::is<crate::check_types::Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<crate::check_types::Ty::TyArray>(t).a0;
        prism_rtl::more(prism_rtl::rc(NegWalk(g, target, e, b, seen)));
    })
        : prism_rtl::is<crate::check_types::Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<crate::check_types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check_types::Ty::TyMap>(t).a1;
        prism_rtl::more(prism_rtl::rc(NegWalks(g, target, Array(std::vector{k, v_}), b, seen)));
    })
        : prism_rtl::is<crate::check_types::Ty::TySig>(t) ? ({
        auto&& i = prism_rtl::as<crate::check_types::Ty::TySig>(t).a1;
        prism_rtl::more(prism_rtl::rc(NegWalk(g, target, i, b, seen)));
    })
        : prism_rtl::is<crate::check_types::Ty::TyAt>(t) ? ({
        auto&& i = prism_rtl::as<crate::check_types::Ty::TyAt>(t).a0;
        prism_rtl::more(prism_rtl::rc(NegWalk(g, target, i, b, seen)));
    })
        : prism_rtl::is<crate::check_types::Ty::TyElem>(t) ? ({
        auto&& i = prism_rtl::as<crate::check_types::Ty::TyElem>(t).a1;
        prism_rtl::more(prism_rtl::rc(NegWalk(g, target, i, b, seen)));
    })
        : prism_rtl::is<crate::check_types::Ty::TyAssoc>(t) ? ({
        auto&& i = prism_rtl::as<crate::check_types::Ty::TyAssoc>(t).a1;
        prism_rtl::more(prism_rtl::rc(NegWalk(g, target, i, b, seen)));
    })
        : prism_rtl::finished(std::tuple{false, seen});
    });
}


/// `Start NegWalk, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<bool, Map<Text, bool>>> start_neg_walk(crate::check_env::G g, Text target, crate::check_types::Ty t, bool b, Map<Text, bool> seen) {
    return prism_rtl::make_rc<NegWalk>(g, target, t, b, seen);
}


/// NegWalks: unbounded fn G, Text, [Ty], Bool, (Text ==> Bool) -> ((Bool, (Text ==> Bool)))
std::tuple<bool, Map<Text, bool>> neg_walks(const crate::check_env::G& g, const Text& target, const Array<crate::check_types::Ty>& ts, const bool& b, const Map<Text, bool>& seen) {
    return run_to_end(fold_job(ts, std::tuple{false, seen}, ({
        auto g_1 = g;
        auto target_2 = target;
        auto b_3 = b;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<bool, Map<Text, bool>>>(std::tuple<std::tuple<bool, Map<Text, bool>>, crate::check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<std::tuple<bool, Map<Text, bool>>, crate::check_types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_4 = g_1;
            auto target_2_4 = target_2;
            auto b_3_4 = b_3;
            entered(once_job([=]() {
            return ({
                auto [bad, sn] = p0;
                auto t = p1;
                bad
                ? prism_rtl::finished(std::tuple{true, sn})
                : prism_rtl::more(prism_rtl::rc(NegWalk(g_1_4, target_2_4, t, b_3_4, sn)));
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<bool, Map<Text, bool>>> NegWalks::cycle() const {
    const auto& g = this->g;
    const auto& target = this->target;
    const auto& ts = this->ts;
    const auto& b = this->b;
    const auto& seen = this->seen;
    return fold_job(ts, std::tuple{false, seen}, ({
        auto g_1 = g;
        auto target_2 = target;
        auto b_3 = b;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<bool, Map<Text, bool>>>(std::tuple<std::tuple<bool, Map<Text, bool>>, crate::check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<std::tuple<bool, Map<Text, bool>>, crate::check_types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_4 = g_1;
            auto target_2_4 = target_2;
            auto b_3_4 = b_3;
            entered(once_job([=]() {
            return ({
                auto [bad, sn] = p0;
                auto t = p1;
                bad
                ? prism_rtl::finished(std::tuple{true, sn})
                : prism_rtl::more(prism_rtl::rc(NegWalk(g_1_4, target_2_4, t, b_3_4, sn)));
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start NegWalks, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<bool, Map<Text, bool>>> start_neg_walks(crate::check_env::G g, Text target, Array<crate::check_types::Ty> ts, bool b, Map<Text, bool> seen) {
    return prism_rtl::make_rc<NegWalks>(g, target, ts, b, seen);
}


/// NatMinusSeeds: unbounded fn St -> (Text ==> Rel)
Map<Text, Rel> nat_minus_seeds(const crate::check_types::St& st) {
    return run_to_end(fold_job(keys(st.size_tys), Map<Text, Rel>{}, ({
        auto st_1 = st;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Rel>>(std::tuple<Map<Text, Rel>, Text>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Rel>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto st_1_2 = st_1;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                auto k = p1;
                ({
                auto&& _m = prelude::get(st_1_2.size_tys, k);
                prism_rtl::is_some(_m) ? ({
                auto&& t = prism_rtl::some_of(_m);
                call_then(crate::check_types::start_zonk(st_1_2, t), [=](crate::check_types::Ty zonk_46800) {
                return zonk_46800 == crate::check_types::t_nat()
                    ? prism_rtl::finished(insert(m, prism_rtl::cat("nat:", k), no_rel()))
                    : prism_rtl::finished(m);
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(m)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<Map<Text, Rel>> NatMinusSeeds::cycle() const {
    const auto& st = this->st;
    return fold_job(keys(st.size_tys), Map<Text, Rel>{}, ({
        auto st_1 = st;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Rel>>(std::tuple<Map<Text, Rel>, Text>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Rel>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto st_1_2 = st_1;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                auto k = p1;
                ({
                auto&& _m = prelude::get(st_1_2.size_tys, k);
                prism_rtl::is_some(_m) ? ({
                auto&& t = prism_rtl::some_of(_m);
                call_then(crate::check_types::start_zonk(st_1_2, t), [=](crate::check_types::Ty zonk_46800) {
                return zonk_46800 == crate::check_types::t_nat()
                    ? prism_rtl::finished(insert(m, prism_rtl::cat("nat:", k), no_rel()))
                    : prism_rtl::finished(m);
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(m)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start NatMinusSeeds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Rel>> start_nat_minus_seeds(crate::check_types::St st) {
    return prism_rtl::make_rc<NatMinusSeeds>(st);
}


/// DefClauses: fn Def -> [FnClause]
Array<crate::ast::FnClause> def_clauses(const crate::check_env::Def& d) {
    auto&& _m = d.body;
    if (prism_rtl::is<crate::check_env::DefBody::DbFn>(_m)) {
        auto&& clauses = prism_rtl::as<crate::check_env::DefBody::DbFn>(_m).a0;
        return clauses;
    }
    if (prism_rtl::is<crate::check_env::DefBody::DbMethod>(_m)) {
        auto&& clauses = prism_rtl::as<crate::check_env::DefBody::DbMethod>(_m).a0;
        return clauses;
    }
    if (prism_rtl::is<crate::check_env::DefBody::DbDefault>(_m)) {
        auto&& clauses = prism_rtl::as<crate::check_env::DefBody::DbDefault>(_m).a0;
        return clauses;
    }
    if (prism_rtl::is<crate::check_env::DefBody::DbWidget>(_m)) {
        auto&& w = prism_rtl::as<crate::check_env::DefBody::DbWidget>(_m).a0;
        return Array(std::vector{crate::ast::FnClause{.name = crate::ast::DefName(crate::ast::DefName::DefSName{w.name}), .params = Array<crate::ast::Pattern_>{}, .body = crate::ast::FnBody(crate::ast::FnBody::BodyBlock{w.body}), .span = w.span}});
    }
    if (prism_rtl::is<crate::check_env::DefBody::DbLet>(_m)) {
        auto&& l = prism_rtl::as<crate::check_env::DefBody::DbLet>(_m).a0;
        return Array(std::vector{crate::ast::FnClause{.name = crate::ast::DefName(crate::ast::DefName::DefOp{d.name, l.span}), .params = Array<crate::ast::Pattern_>{}, .body = crate::ast::FnBody(crate::ast::FnBody::BodyExpr{l->value}), .span = l.span}});
    }
    {
        return Array<crate::ast::FnClause>{};
    }
}


/// OwnKey: fn Def -> Def
crate::check_env::Def own_key(const crate::check_env::Def& d) {
    auto&& _m = d.body;
    if (prism_rtl::is<crate::check_env::DefBody::DbMethod>(_m)) {
        auto&& im = prism_rtl::as<crate::check_env::DefBody::DbMethod>(_m).a2;
        crate::check_env::Def this_ = d;
        this_.qk = prism_rtl::cat(d.qk, " #", im->file, ".", im.span.start);
        return this_;
    }
    {
        return d;
    }
}


/// ?MethodOf: fn G, Def -> ?Text
std::optional<Text> method_of(const crate::check_env::G& g, const crate::check_env::Def& d) {
    auto&& _m = d.body;
    if (prism_rtl::is<crate::check_env::DefBody::DbMethod>(_m)) {
        auto&& cls = prism_rtl::as<crate::check_env::DefBody::DbMethod>(_m).a1;
        return method_key(g, cls, d.name);
    }
    if (prism_rtl::is<crate::check_env::DefBody::DbDefault>(_m)) {
        auto&& cls = prism_rtl::as<crate::check_env::DefBody::DbDefault>(_m).a1;
        return method_key(g, cls, d.name);
    }
    {
        return std::optional<Text>{};
    }
}


/// MethodTargets: fn G, [Def] -> (Text ==> [Text])
Map<Text, Array<Text>> method_targets(const crate::check_env::G& g, const Array<crate::check_env::Def>& fns) {
    return fold(fns, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& m, const crate::check_env::Def& d) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, Array<Text>>> _v;
            auto&& _m = method_of(g, d);
            if (prism_rtl::is_some(_m)) {
                auto&& mk = prism_rtl::some_of(_m);
                _v.set(insert(m, mk, crate::check_types::add_text(or_(prelude::get(m, mk), Array<Text>{}), d.qk)));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(m);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// ImplDefs: fn G, [Def] -> (Text ==> Text)
Map<Text, Text> impl_defs(const crate::check_env::G& g, const Array<crate::check_env::Def>& fns) {
    return fold(fns, Map<Text, Text>{}, [&](const Map<Text, Text>& m, const crate::check_env::Def& d) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, Text>> _v;
            auto&& _m = d.body;
            if (prism_rtl::is<crate::check_env::DefBody::DbMethod>(_m)) {
                auto&& im = prism_rtl::as<crate::check_env::DefBody::DbMethod>(_m).a2;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Map<Text, Text>> _v;
                    auto&& _m = method_of(g, d);
                    if (prism_rtl::is_some(_m)) {
                        auto&& mk = prism_rtl::some_of(_m);
                        _v.set(insert(m, prism_rtl::cat(mk, "|", im->file, ".", im.span.start), d.qk));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(m);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(m);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// ?MethodClass: fn G, Text -> ?Text
std::optional<Text> method_class(const crate::check_env::G& g, const Text& k) {
    auto&& _m = prelude::get(g.vals, k);
    if (prism_rtl::is_some(_m)) {
        auto&& v_ = prism_rtl::some_of(_m);
        return v_.sort != Text::lit("method")
            ? std::optional<Text>{}
            : ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Text>> _v;
            auto&& _m = index(v_.scheme.bounds, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& cls = std::get<1>(prism_rtl::some_of(_m));
                _v.set(std::optional(cls));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(std::optional<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// DispatchTargets: unbounded fn Shrink, Def, Site, Text -> [Text]
Array<Text> dispatch_targets(const Shrink& sk, const crate::check_env::Def& d, const Site& site, const Text& k) {
    auto all = targets_of(sk, k);
    auto&& _m = method_class(sk.g, k);
    if (prism_rtl::is_none(_m)) {
        return all;
    }
    if (prism_rtl::is_some(_m)) {
        auto&& cls = prism_rtl::some_of(_m);
        auto ck = crate::check_types::choice_key(d->file, site.span, cls);
        auto&& _m = prelude::get(sk.choices, ck);
        if (prism_rtl::is_none(_m)) {
            return all;
        }
        if (prism_rtl::is_some(_m)) {
            auto&& cs = prism_rtl::some_of(_m);
            return run_to_end(fold_job(cs, Array<Text>{}, ({
                auto sk_1 = sk;
                auto k_2 = k;
                auto cls_3 = cls;
                auto all_4 = all;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto sk_1_5 = sk_1;
                    auto k_2_5 = k_2;
                    auto cls_3_5 = cls_3;
                    auto all_4_5 = all_4;
                    entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto ch = p1;
                        call_then(start_choice_targets(sk_1_5, k_2_5, cls_3_5, all_4_5, ch, Array<Text>{}), [=](Array<Text> choice_targets_50193) { return prism_rtl::finished(crate::check_types::union_texts(acc, choice_targets_50193)); });
                    });
                }));
                });
            })));
            })));
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> DispatchTargets::cycle() const {
    const auto& sk = this->sk;
    const auto& d = this->d;
    const auto& site = this->site;
    const auto& k = this->k;
    auto all = targets_of(sk, k);
    return ({
        auto&& _m = method_class(sk.g, k);
        prism_rtl::is_none(_m) ? prism_rtl::finished(all)
        : prism_rtl::is_some(_m) ? ({
        auto&& cls = prism_rtl::some_of(_m);
        ({
        auto ck = crate::check_types::choice_key(d->file, site.span, cls);
        ({
        auto&& _m = prelude::get(sk.choices, ck);
        prism_rtl::is_none(_m) ? prism_rtl::finished(all)
        : prism_rtl::is_some(_m) ? ({
        auto&& cs = prism_rtl::some_of(_m);
        fold_job(cs, Array<Text>{}, ({
        auto sk_1 = sk;
        auto k_2 = k;
        auto cls_3 = cls;
        auto all_4 = all;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_1_5 = sk_1;
            auto k_2_5 = k_2;
            auto cls_3_5 = cls_3;
            auto all_4_5 = all_4;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto ch = p1;
                call_then(start_choice_targets(sk_1_5, k_2_5, cls_3_5, all_4_5, ch, Array<Text>{}), [=](Array<Text> choice_targets_50193) { return prism_rtl::finished(crate::check_types::union_texts(acc, choice_targets_50193)); });
            });
        }));
        });
    })));
    }))->cycle();
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start DispatchTargets, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_dispatch_targets(Shrink sk, crate::check_env::Def d, Site site, Text k) {
    return prism_rtl::make_rc<DispatchTargets>(sk, d, site, k);
}


/// ChoiceTargets: unbounded fn Shrink, Text, Text, [Text], Text, [Text] -> [Text]
Array<Text> choice_targets(const Shrink& sk, const Text& k, const Text& cls, const Array<Text>& all, const Text& ch, const Array<Text>& seen) {
    return ch == Text::lit("none")
        ? Array<Text>{}
        : crate::lexer::has_prefix(ch, Text::lit("impl:"))
        ? ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = prelude::get(sk.impl_defs, prism_rtl::cat(k, "|", crate::lexer::drop_prefix(ch, Text::lit("impl:"))));
        if (prism_rtl::is_some(_m)) {
            auto&& q = prism_rtl::some_of(_m);
            _v.set(Array(std::vector{q}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(filter(all, [&](const Text& q) { return q == k; }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    })
        : crate::lexer::has_prefix(ch, Text::lit("derived:"))
        ? derived_targets(sk, k, cls, all, crate::lexer::drop_prefix(ch, Text::lit("derived:")), seen)
        : all;
}


prism_rtl::Turn<Array<Text>> ChoiceTargets::cycle() const {
    const auto& sk = this->sk;
    const auto& k = this->k;
    const auto& cls = this->cls;
    const auto& all = this->all;
    const auto& ch = this->ch;
    const auto& seen = this->seen;
    return ch == Text::lit("none")
        ? prism_rtl::finished(Array<Text>{})
        : crate::lexer::has_prefix(ch, Text::lit("impl:"))
        ? ({
        auto&& _m = prelude::get(sk.impl_defs, prism_rtl::cat(k, "|", crate::lexer::drop_prefix(ch, Text::lit("impl:"))));
        prism_rtl::is_some(_m) ? ({
        auto&& q = prism_rtl::some_of(_m);
        prism_rtl::finished(Array(std::vector{q}));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(filter(all, [&](const Text& q) { return q == k; }))
        : throw prism_rtl::Panic("no arm matched");
    })
        : crate::lexer::has_prefix(ch, Text::lit("derived:"))
        ? prism_rtl::more(prism_rtl::rc(DerivedTargets(sk, k, cls, all, crate::lexer::drop_prefix(ch, Text::lit("derived:")), seen)))
        : prism_rtl::finished(all);
}


/// `Start ChoiceTargets, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_choice_targets(Shrink sk, Text k, Text cls, Array<Text> all, Text ch, Array<Text> seen) {
    return prism_rtl::make_rc<ChoiceTargets>(sk, k, cls, all, ch, seen);
}


/// DerivedTargets: unbounded fn Shrink, Text, Text, [Text], Text, [Text] -> [Text]
Array<Text> derived_targets(const Shrink& sk, const Text& k, const Text& cls, const Array<Text>& all, const Text& n, const Array<Text>& seen) {
    return crate::check_types::has_text(seen, n)
        ? Array<Text>{}
        : ({
        auto tys = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check_types::Ty>> _v;
            auto&& _m = prelude::get(sk.g.types, n);
            if (prism_rtl::is_some(_m)) {
                auto&& ti = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::check_types::Ty>> _v;
                    auto&& _m = ti.body;
                    if (prism_rtl::is<crate::check_env::TyBody::BRecord>(_m)) {
                        auto&& fields = prism_rtl::as<crate::check_env::TyBody::BRecord>(_m).a0;
                        _v.set(each(fields, [&](const std::tuple<Text, crate::check_types::Ty>& _p0) {
                            auto&& t = std::get<1>(_p0);
                            return t;
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check_env::TyBody::BChoice>(_m)) {
                        auto&& cases = prism_rtl::as<crate::check_env::TyBody::BChoice>(_m).a0;
                        _v.set(fold(cases, Array<crate::check_types::Ty>{}, [&](const Array<crate::check_types::Ty>& acc, const std::tuple<Text, Array<crate::check_types::Ty>>& _p1) {
                            auto&& args = std::get<1>(_p1);
                            return append(acc, args);
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check_env::TyBody::BAlias>(_m)) {
                        auto&& t = prism_rtl::as<crate::check_env::TyBody::BAlias>(_m).a0;
                        _v.set(Array(std::vector{t}));
                        goto _done;
                    }
                    {
                        _v.set(Array<crate::check_types::Ty>{});
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<crate::check_types::Ty>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto heads = fold(tys, Array<Text>{}, [&](const Array<Text>& acc, const crate::check_types::Ty& t) { return crate::check_types::union_texts(acc, ty_heads(t)); });
        run_to_end(fold_job(heads, Array<Text>{}, ({
        auto sk_1 = sk;
        auto k_2 = k;
        auto cls_3 = cls;
        auto all_4 = all;
        auto seen_5 = seen;
        auto n_6 = n;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_1_7 = sk_1;
            auto k_2_7 = k_2;
            auto cls_3_7 = cls_3;
            auto all_4_7 = all_4;
            auto seen_5_7 = seen_5;
            auto n_6_7 = n_6;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto h = p1;
                (prism_rtl::finished(crate::check_types::union_texts(acc, head_targets(sk_1_7, k_2_7, cls_3_7, all_4_7, h, prelude::push(seen_5_7, n_6_7)))));
            });
        }));
        });
    })));
    })));
    });
}


prism_rtl::Turn<Array<Text>> DerivedTargets::cycle() const {
    const auto& sk = this->sk;
    const auto& k = this->k;
    const auto& cls = this->cls;
    const auto& all = this->all;
    const auto& n = this->n;
    const auto& seen = this->seen;
    return crate::check_types::has_text(seen, n)
        ? prism_rtl::finished(Array<Text>{})
        : ({
        auto tys = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check_types::Ty>> _v;
            auto&& _m = prelude::get(sk.g.types, n);
            if (prism_rtl::is_some(_m)) {
                auto&& ti = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::check_types::Ty>> _v;
                    auto&& _m = ti.body;
                    if (prism_rtl::is<crate::check_env::TyBody::BRecord>(_m)) {
                        auto&& fields = prism_rtl::as<crate::check_env::TyBody::BRecord>(_m).a0;
                        _v.set(each(fields, [&](const std::tuple<Text, crate::check_types::Ty>& _p0) {
                            auto&& t = std::get<1>(_p0);
                            return t;
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check_env::TyBody::BChoice>(_m)) {
                        auto&& cases = prism_rtl::as<crate::check_env::TyBody::BChoice>(_m).a0;
                        _v.set(fold(cases, Array<crate::check_types::Ty>{}, [&](const Array<crate::check_types::Ty>& acc, const std::tuple<Text, Array<crate::check_types::Ty>>& _p1) {
                            auto&& args = std::get<1>(_p1);
                            return append(acc, args);
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check_env::TyBody::BAlias>(_m)) {
                        auto&& t = prism_rtl::as<crate::check_env::TyBody::BAlias>(_m).a0;
                        _v.set(Array(std::vector{t}));
                        goto _done;
                    }
                    {
                        _v.set(Array<crate::check_types::Ty>{});
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<crate::check_types::Ty>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto heads = fold(tys, Array<Text>{}, [&](const Array<Text>& acc, const crate::check_types::Ty& t) { return crate::check_types::union_texts(acc, ty_heads(t)); });
        fold_job(heads, Array<Text>{}, ({
        auto sk_1 = sk;
        auto k_2 = k;
        auto cls_3 = cls;
        auto all_4 = all;
        auto seen_5 = seen;
        auto n_6 = n;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_1_7 = sk_1;
            auto k_2_7 = k_2;
            auto cls_3_7 = cls_3;
            auto all_4_7 = all_4;
            auto seen_5_7 = seen_5;
            auto n_6_7 = n_6;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto h = p1;
                (prism_rtl::finished(crate::check_types::union_texts(acc, head_targets(sk_1_7, k_2_7, cls_3_7, all_4_7, h, prelude::push(seen_5_7, n_6_7)))));
            });
        }));
        });
    })));
    }))->cycle();
    });
}


/// `Start DerivedTargets, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_derived_targets(Shrink sk, Text k, Text cls, Array<Text> all, Text n, Array<Text> seen) {
    return prism_rtl::make_rc<DerivedTargets>(sk, k, cls, all, n, seen);
}


/// TyHeads: fn Ty -> [Text]
Array<Text> ty_heads(const crate::check_types::Ty& t) {
    if (prism_rtl::is<crate::check_types::Ty::TyCon>(t)) {
        auto&& n = prism_rtl::as<crate::check_types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check_types::Ty::TyCon>(t).a1;
        return fold(args, Array(std::vector{n}), [&](const Array<Text>& acc, const crate::check_types::Ty& a) { return crate::check_types::union_texts(acc, ty_heads(a)); });
    }
    if (prism_rtl::is<crate::check_types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::check_types::Ty::TyTuple>(t).a0;
        return fold(ts, Array<Text>{}, [&](const Array<Text>& acc, const crate::check_types::Ty& a) { return crate::check_types::union_texts(acc, ty_heads(a)); });
    }
    if (prism_rtl::is<crate::check_types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<crate::check_types::Ty::TyArray>(t).a0;
        return ty_heads(e);
    }
    if (prism_rtl::is<crate::check_types::Ty::TyMap>(t)) {
        auto&& a = prism_rtl::as<crate::check_types::Ty::TyMap>(t).a0;
        auto&& b = prism_rtl::as<crate::check_types::Ty::TyMap>(t).a1;
        return crate::check_types::union_texts(ty_heads(a), ty_heads(b));
    }
    if (prism_rtl::is<crate::check_types::Ty::TySig>(t)) {
        auto&& i = prism_rtl::as<crate::check_types::Ty::TySig>(t).a1;
        return ty_heads(i);
    }
    if (prism_rtl::is<crate::check_types::Ty::TyQ>(t)) {
        return Array<Text>{};
    }
    if (prism_rtl::is<crate::check_types::Ty::TyRigid>(t)) {
        return Array<Text>{};
    }
    if (prism_rtl::is<crate::check_types::Ty::TyFn>(t)) {
        return Array<Text>{};
    }
    if (prism_rtl::is<crate::check_types::Ty::TyElem>(t)) {
        return Array<Text>{};
    }
    if (prism_rtl::is<crate::check_types::Ty::TyElemAny>(t)) {
        return Array<Text>{};
    }
    {
        return Array(std::vector{Text::lit("?")});
    }
}


/// HeadTargets: unbounded fn Shrink, Text, Text, [Text], Text, [Text] -> [Text]
Array<Text> head_targets(const Shrink& sk, const Text& k, const Text& cls, const Array<Text>& all, const Text& h, const Array<Text>& seen) {
    return h == Text::lit("?")
        ? all
        : crate::check_env::builtin_has(cls, h) || crate::check_env::is_prim_type(h)
        ? Array<Text>{}
        : ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = index(filter(or_(prelude::get(sk.g.impls, cls), Array<crate::check_env::ImplInfo>{}), [&](const crate::check_env::ImplInfo& im) { return head_key(im.head) == std::optional(h); }), Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& im = prism_rtl::some_of(_m);
            _v.set(choice_targets(sk, k, cls, all, crate::check_env::impl_choice(im), seen));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(all);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// ?HeadKey: fn Ty -> ?Text
std::optional<Text> head_key(const crate::check_types::Ty& ty0) {
    if (prism_rtl::is<crate::check_types::Ty::TyCon>(ty0)) {
        auto&& n = prism_rtl::as<crate::check_types::Ty::TyCon>(ty0).a0;
        return std::optional(n);
    }
    {
        return std::optional<Text>{};
    }
}


/// TargetsOf: fn Shrink, Text -> [Text]
Array<Text> targets_of(const Shrink& sk, const Text& k) {
    return or_(prelude::get(sk.targets, k), Array(std::vector{k}));
}


/// SigKeyOf: fn Shrink, Text -> Text
Text sig_key_of(const Shrink& sk, const Text& k) {
    auto&& _m = prelude::get(sk.by_key, k);
    if (prism_rtl::is_some(_m)) {
        auto&& d = prism_rtl::some_of(_m);
        return or_(method_of(sk.g, d), k);
    }
    if (prism_rtl::is_none(_m)) {
        return k;
    }
    prism_rtl::unreachable("no arm matched");
}


/// ShownKey: fn Text -> Text
Text shown_key(const Text& k) {
    return crate::check_types::bare_name(or_(index(split(or_(crate::lexer::last(split(k, Text::lit(" impl "))), k), Text::lit(" #")), Nat(0u)), k));
}


/// IsUnboundedKey: fn G, Text -> Bool
bool is_unbounded_key(const crate::check_env::G& g, const Text& k) {
    auto&& _m = prelude::get(g.vals, k);
    if (prism_rtl::is_some(_m)) {
        auto&& v_ = prism_rtl::some_of(_m);
        auto&& _m = v_.scheme.ty;
        if (prism_rtl::is<crate::check_types::Ty::TyFn>(_m) && prism_rtl::is<crate::check_types::Col::CUnbound>(prism_rtl::as<crate::check_types::Ty::TyFn>(_m).a0)) {
            return true;
        }
        {
            return false;
        }
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// HofSeeds: unbounded fn Shrink, [Text] -> (Text ==> (Text ==> Rel))
Map<Text, Map<Text, Rel>> hof_seeds(const Shrink& sk, const Array<Text>& homes) {
    auto cands = hof_candidates(sk);
    auto cleared = clear_slots(sk, homes, cands, Nat(0u));
    auto sums = slot_sums(sk, homes, cleared, top_sums(cleared), Nat(0u));
    return fold(homes, Map<Text, Map<Text, Rel>>{}, [&](const Map<Text, Map<Text, Rel>>& m, const Text& h) { return insert(m, h, slot_seeds(sk, h, cleared, sums, false)); });
}


prism_rtl::Turn<Map<Text, Map<Text, Rel>>> HofSeeds::cycle() const {
    const auto& sk = this->sk;
    const auto& homes = this->homes;
    auto cands = hof_candidates(sk);
    auto homes_1 = homes;
    auto sk_2 = sk;
    return call_then(start_clear_slots(sk_2, homes_1, cands, Nat(0u)), [=](Array<Slot_> clear_slots_54795) {
        return ({
            auto cleared = clear_slots_54795;
            call_then(start_slot_sums(sk_2, homes_1, cleared, top_sums(cleared), Nat(0u)), [=](Map<Text, Rel> slot_sums_54841) {
            return ({
                auto sums = slot_sums_54841;
                (prism_rtl::finished(fold(homes_1, Map<Text, Map<Text, Rel>>{}, [&](const Map<Text, Map<Text, Rel>>& m, const Text& h) { return insert(m, h, slot_seeds(sk_2, h, cleared, sums, false)); })));
            });
        });
        });
    });
}


/// `Start HofSeeds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Map<Text, Rel>>> start_hof_seeds(Shrink sk, Array<Text> homes) {
    return prism_rtl::make_rc<HofSeeds>(sk, homes);
}


/// HofCandidates: fn Shrink -> [Slot]
Array<Slot_> hof_candidates(const Shrink& sk) {
    return fold(sk.fns, Array<Slot_>{}, [&](const Array<Slot_>& acc, const crate::check_env::Def& d) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Slot_>> _v;
            auto&& _m = d.body;
            if (prism_rtl::is<crate::check_env::DefBody::DbFn>(_m)) {
                auto&& clauses = prism_rtl::as<crate::check_env::DefBody::DbFn>(_m).a0;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<Slot_>> _v;
                    auto&& _m = prelude::get(sk.g.vals, d.qk);
                    if (prism_rtl::is_some(_m)) {
                        auto&& v_ = prism_rtl::some_of(_m);
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Array<Slot_>> _v;
                            auto&& _m = v_.scheme.ty;
                            if (prism_rtl::is<crate::check_types::Ty::TyFn>(_m)) {
                                auto&& ps = prism_rtl::as<crate::check_types::Ty::TyFn>(_m).a1;
                                _v.set(fold(crate::check_errors::range0(len(ps)), acc, [&](const Array<Slot_>& a2, const Nat& j) {
                                    return ({
                                        __label__ _done;
                                        prism_rtl::Slot<Array<Slot_>> _v;
                                        auto&& _m = index(ps, j);
                                        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::check_types::Ty::TyFn>(prism_rtl::some_of(_m))) {
                                            auto&& fps = prism_rtl::as<crate::check_types::Ty::TyFn>(prism_rtl::some_of(_m)).a1;
                                            _v.set(fold(clauses, true, [&](const bool& ok, const crate::ast::FnClause& c) { return ok && slot_named(c, j); })
                                                ? prelude::push(a2, Slot_{.owner = d.qk, .at = j, .arity = len(fps)})
                                                : a2);
                                            goto _done;
                                        }
                                        {
                                            _v.set(a2);
                                            goto _done;
                                        }
                                    _done:
                                        _v.take();
                                    });
                                }));
                                goto _done;
                            }
                            {
                                _v.set(acc);
                                goto _done;
                            }
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// SlotNamed: fn FnClause, Nat -> Bool
bool slot_named(const crate::ast::FnClause& c, const Nat& j) {
    auto&& _m = index(c.params, j);
    if (prism_rtl::is_some(_m)) {
        auto&& p_ = prism_rtl::some_of(_m);
        auto&& _m = p_.kind;
        if (prism_rtl::is<crate::ast::PatternKind::PName>(_m)) {
            return true;
        }
        if (prism_rtl::is<crate::ast::PatternKind::PIgnore>(_m)) {
            return true;
        }
        {
            return false;
        }
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// SlotName: fn FnClause, Nat -> Text
Text slot_name(const crate::ast::FnClause& c, const Nat& j) {
    auto&& _m = index(c.params, j);
    if (prism_rtl::is_some(_m)) {
        auto&& p_ = prism_rtl::some_of(_m);
        auto&& _m = p_.kind;
        if (prism_rtl::is<crate::ast::PatternKind::PName>(_m)) {
            auto&& n = prism_rtl::as<crate::ast::PatternKind::PName>(_m).a0;
            return crate::check_env::sname_key(n);
        }
        {
            return Text::lit("");
        }
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SlotSeeds: fn Shrink, Text, [Slot], (Text ==> Rel), Bool -> (Text ==> Rel)
Map<Text, Rel> slot_seeds(const Shrink& sk, const Text& h, const Array<Slot_>& slots, const Map<Text, Rel>& sums, const bool& with_top) {
    auto pre = or_(prelude::get(sk.seeds, h), Map<Text, Rel>{});
    auto start = with_top
        ? insert(pre, Text::lit("⊤"), Rel{.param = top_param(), .strict = false})
        : pre;
    return fold(slots, start, [&](const Map<Text, Rel>& m, const Slot_& sl) {
        return fold(spellings(sk.g, h, sl.owner), m, [&](const Map<Text, Rel>& m2, const Text& sp) {
            return ({
                auto m3 = insert(m2, prism_rtl::cat("acc:", sp, ":", sl.at), Rel{.param = sl.arity, .strict = false});
                fold(crate::check_errors::range0(sl.arity), m3, [&](const Map<Text, Rel>& m4, const Nat& q) {
                return ({
                    __label__ _done;
                    prism_rtl::Slot<Map<Text, Rel>> _v;
                    auto&& _m = prelude::get(sums, prism_rtl::cat(sl.owner, ":", sl.at, ":", q));
                    if (prism_rtl::is_some(_m)) {
                        auto&& r = prism_rtl::some_of(_m);
                        _v.set((r.param == top_param()) && (!with_top)
                            ? m4
                            : insert(m4, prism_rtl::cat("sum:", sp, ":", sl.at, ":", q), r));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(m4);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
            });
            });
        });
    });
}


/// Spellings: fn G, Text, Text -> [Text]
Array<Text> spellings(const crate::check_env::G& g, const Text& h, const Text& k) {
    return filter(crate::check_types::add_text(Array(std::vector{crate::check_types::bare_name(k)}), k), [&](const Text& sp) { return resolve_name(g, h, sp) == std::optional(k); });
}


/// ClearSlots: unbounded fn Shrink, [Text], [Slot], Nat -> [Slot]
Array<Slot_> clear_slots(const Shrink& sk, const Array<Text>& homes, const Array<Slot_>& slots, const Nat& round) {
    auto sks = seeds_for(sk, homes, slots, Map<Text, Rel>{}, false);
    auto kept = run_to_end(filter_job(slots, ({
        auto sks_1 = sks;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Slot_)>>(prism_rtl::rc([=](Slot_ p0) {
        return ({
            auto sks_1_2 = sks_1;
            entered(once_job([=]() {
            return ({
                auto sl = p0;
                call_then(start_slot_escapes(sks_1_2, sl), [=](bool slot_escapes_57267) { return prism_rtl::finished(!slot_escapes_57267); });
            });
        }));
        });
    })));
    })));
    return len(kept) == len(slots)
        ? kept
        : round > Nat(20u)
        ? Array<Slot_>{}
        : clear_slots(sk, homes, kept, round + Nat(1u));
}


prism_rtl::Turn<Array<Slot_>> ClearSlots::cycle() const {
    const auto& sk = this->sk;
    const auto& homes = this->homes;
    const auto& slots = this->slots;
    const auto& round = this->round;
    auto sks = seeds_for(sk, homes, slots, Map<Text, Rel>{}, false);
    auto homes_1 = homes;
    auto round_2 = round;
    auto sk_3 = sk;
    auto slots_4 = slots;
    return call_value(filter_job(slots_4, ({
        auto sks_5 = sks;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Slot_)>>(prism_rtl::rc([=](Slot_ p0) {
        return ({
            auto sks_5_6 = sks_5;
            entered(once_job([=]() {
            return ({
                auto sl = p0;
                call_then(start_slot_escapes(sks_5_6, sl), [=](bool slot_escapes_57267) { return prism_rtl::finished(!slot_escapes_57267); });
            });
        }));
        });
    })));
    })), [=](Array<Slot_> filter_57242) {
        return ({
            auto kept = filter_57242;
            len(kept) == len(slots_4)
            ? prism_rtl::finished(kept)
            : round_2 > Nat(20u)
            ? prism_rtl::finished(Array<Slot_>{})
            : prism_rtl::more(prism_rtl::rc(ClearSlots(sk_3, homes_1, kept, round_2 + Nat(1u))));
        });
    });
}


/// `Start ClearSlots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Slot_>> start_clear_slots(Shrink sk, Array<Text> homes, Array<Slot_> slots, Nat round) {
    return prism_rtl::make_rc<ClearSlots>(sk, homes, slots, round);
}


/// SeedsFor: fn Shrink, [Text], [Slot], (Text ==> Rel), Bool -> Shrink
Shrink seeds_for(const Shrink& sk, const Array<Text>& homes, const Array<Slot_>& slots, const Map<Text, Rel>& sums, const bool& with_top) {
    Shrink this_ = sk;
    this_.seeds = fold(homes, Map<Text, Map<Text, Rel>>{}, [&](const Map<Text, Map<Text, Rel>>& m, const Text& h) { return insert(m, h, slot_seeds(sk, h, slots, sums, with_top)); });
    return this_;
}


/// SlotEscapes: unbounded fn Shrink, Slot -> Bool
bool slot_escapes(const Shrink& sk, const Slot_& sl) {
    auto&& _m = prelude::get(sk.by_key, sl.owner);
    if (prism_rtl::is_some(_m)) {
        auto&& d = prism_rtl::some_of(_m);
        return run_to_end(fold_job(def_clauses(d), false, ({
            auto sl_1 = sl;
            auto sk_2 = sk;
            auto d_3 = d;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<bool, crate::ast::FnClause> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto sl_1_4 = sl_1;
                auto sk_2_4 = sk_2;
                auto d_3_4 = d_3;
                entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto c = p1;
                    ({
                    auto n = slot_name(c, sl_1_4.at);
                    seen || (n == Text::lit(""))
                    ? prism_rtl::finished(seen)
                    : call_then(start_clause_base(sk_2_4, d_3_4, c), [=](Map<Text, Rel> clause_base_58068) {
                    return call_then(start_body_spots(c.body, clause_base_58068), [=](Array<Spot> body_spots_58049) {
                        return fold_job(body_spots_58049, false, ({
                            auto n_4 = n;
                            auto sl_1_4_5 = sl_1_4;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Spot>)>>(prism_rtl::rc([=](std::tuple<bool, Spot> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto n_4_5 = n_4;
                                auto sl_1_4_5_5 = sl_1_4_5;
                                entered(once_job([=]() {
                                return ({
                                    auto esc = p0;
                                    auto sp = p1;
                                    (prism_rtl::finished(esc || spot_escapes(sp, n_4_5, sl_1_4_5_5.at)));
                                });
                            }));
                            });
                        })));
                        }))->cycle();
                    });
                });
                });
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is_none(_m)) {
        return true;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> SlotEscapes::cycle() const {
    const auto& sk = this->sk;
    const auto& sl = this->sl;
    return ({
        auto&& _m = prelude::get(sk.by_key, sl.owner);
        prism_rtl::is_some(_m) ? ({
        auto&& d = prism_rtl::some_of(_m);
        fold_job(def_clauses(d), false, ({
        auto sl_1 = sl;
        auto sk_2 = sk;
        auto d_3 = d;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<bool, crate::ast::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sl_1_4 = sl_1;
            auto sk_2_4 = sk_2;
            auto d_3_4 = d_3;
            entered(once_job([=]() {
            return ({
                auto seen = p0;
                auto c = p1;
                ({
                auto n = slot_name(c, sl_1_4.at);
                seen || (n == Text::lit(""))
                ? prism_rtl::finished(seen)
                : call_then(start_clause_base(sk_2_4, d_3_4, c), [=](Map<Text, Rel> clause_base_58068) {
                return call_then(start_body_spots(c.body, clause_base_58068), [=](Array<Spot> body_spots_58049) {
                    return fold_job(body_spots_58049, false, ({
                        auto n_4 = n;
                        auto sl_1_4_5 = sl_1_4;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Spot>)>>(prism_rtl::rc([=](std::tuple<bool, Spot> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto n_4_5 = n_4;
                            auto sl_1_4_5_5 = sl_1_4_5;
                            entered(once_job([=]() {
                            return ({
                                auto esc = p0;
                                auto sp = p1;
                                (prism_rtl::finished(esc || spot_escapes(sp, n_4_5, sl_1_4_5_5.at)));
                            });
                        }));
                        });
                    })));
                    }))->cycle();
                });
            });
            });
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(true)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SlotEscapes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_slot_escapes(Shrink sk, Slot_ sl) {
    return prism_rtl::make_rc<SlotEscapes>(sk, sl);
}


/// SpotEscapes: unbounded fn Spot, Text, Nat -> Bool
bool spot_escapes(const Spot& sp, const Text& n, const Nat& j) {
    if (prism_rtl::is<Spot::SpotExpr>(sp)) {
        auto&& e = prism_rtl::as<Spot::SpotExpr>(sp).a0;
        auto&& m = prism_rtl::as<Spot::SpotExpr>(sp).a1;
        auto&& _m = e.kind;
        if (prism_rtl::is<crate::ast::ExprKind::EName>(_m)) {
            auto&& x = prism_rtl::as<crate::ast::ExprKind::EName>(_m).a0;
            return (crate::check_env::sname_key(x) == n) && is_slot_param(m, n, j);
        }
        {
            return fold(spot_sites(sp), false, [&](const bool& seen, const Site& site) { return seen || (((site.callee == n) && is_slot_param(site.rels, n, j)) && crate::check_env::has_key(site.rels, Text::lit("lam:"))); });
        }
    }
    if (prism_rtl::is<Spot::SpotStmt>(sp)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> SpotEscapes::cycle() const {
    const auto& sp = this->sp;
    const auto& n = this->n;
    const auto& j = this->j;
    return ({
        prism_rtl::is<Spot::SpotExpr>(sp) ? ({
        auto&& e = prism_rtl::as<Spot::SpotExpr>(sp).a0;
        auto&& m = prism_rtl::as<Spot::SpotExpr>(sp).a1;
        ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::ast::ExprKind::EName>(_m) ? ({
        auto&& x = prism_rtl::as<crate::ast::ExprKind::EName>(_m).a0;
        prism_rtl::finished((crate::check_env::sname_key(x) == n) && is_slot_param(m, n, j));
    })
        : ({
        auto j_1 = j;
        auto n_2 = n;
        auto sp_3 = sp;
        call_then(start_spot_sites(sp_3), [=](Array<Site> spot_sites_58359) { return prism_rtl::finished(fold(spot_sites_58359, false, [&](const bool& seen, const Site& site) { return seen || (((site.callee == n_2) && is_slot_param(site.rels, n_2, j_1)) && crate::check_env::has_key(site.rels, Text::lit("lam:"))); })); });
    });
    });
    })
        : prism_rtl::is<Spot::SpotStmt>(sp) ? prism_rtl::finished(false)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SpotEscapes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_spot_escapes(Spot sp, Text n, Nat j) {
    return prism_rtl::make_rc<SpotEscapes>(sp, n, j);
}


/// IsSlotParam: fn (Text ==> Rel), Text, Nat -> Bool
bool is_slot_param(const Map<Text, Rel>& m, const Text& n, const Nat& j) {
    return prelude::get(m, n) == std::optional(Rel{.param = j, .strict = false});
}


/// TopSums: fn [Slot] -> (Text ==> Rel)
Map<Text, Rel> top_sums(const Array<Slot_>& slots) {
    return fold(slots, Map<Text, Rel>{}, [&](const Map<Text, Rel>& m, const Slot_& sl) { return fold(crate::check_errors::range0(sl.arity), m, [&](const Map<Text, Rel>& m2, const Nat& q) { return insert(m2, prism_rtl::cat(sl.owner, ":", sl.at, ":", q), Rel{.param = top_param(), .strict = false}); }); });
}


/// SlotSums: unbounded fn Shrink, [Text], [Slot], (Text ==> Rel), Nat -> (Text ==> Rel)
Map<Text, Rel> slot_sums(const Shrink& sk, const Array<Text>& homes, const Array<Slot_>& slots, const Map<Text, Rel>& sums, const Nat& round) {
    auto sks = seeds_for(sk, homes, slots, sums, true);
    auto next = run_to_end(fold_job(slots, Map<Text, Rel>{}, ({
        auto sks_1 = sks;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Rel>>(std::tuple<Map<Text, Rel>, Slot_>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Rel>, Slot_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sks_1_2 = sks_1;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                auto sl = p1;
                call_then(start_slot_calls(sks_1_2, sl), [=](Array<Site> slot_calls_59504) {
                return ({
                    auto calls = slot_calls_59504;
                    fold_job(crate::check_errors::range0(sl.arity), m, ({
                    auto calls_2 = calls;
                    auto sl_3 = sl;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Rel>>(std::tuple<Map<Text, Rel>, Nat>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Rel>, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto calls_2_4 = calls_2;
                        auto sl_3_4 = sl_3;
                        entered(once_job([=]() {
                        return ({
                            auto m2 = p0;
                            auto q = p1;
                            call_then(start_meet_args(calls_2_4, q), [=](std::optional<Rel> meet_args_59572) {
                            return ({
                                prism_rtl::is_some(meet_args_59572) ? ({
                                auto&& r = prism_rtl::some_of(meet_args_59572);
                                prism_rtl::finished(insert(m2, prism_rtl::cat(sl_3_4.owner, ":", sl_3_4.at, ":", q), r));
                            })
                                : prism_rtl::is_none(meet_args_59572) ? prism_rtl::finished(m2)
                                : throw prism_rtl::Panic("no arm matched");
                            });
                        });
                        });
                    }));
                    });
                }));
                }))->cycle();
                });
            });
            });
        }));
        });
    }));
    })));
    return next == sums
        ? next
        : round > Nat(12u)
        ? Map<Text, Rel>{}
        : slot_sums(sk, homes, slots, next, round + Nat(1u));
}


prism_rtl::Turn<Map<Text, Rel>> SlotSums::cycle() const {
    const auto& sk = this->sk;
    const auto& homes = this->homes;
    const auto& slots = this->slots;
    const auto& sums = this->sums;
    const auto& round = this->round;
    auto sks = seeds_for(sk, homes, slots, sums, true);
    auto homes_1 = homes;
    auto round_2 = round;
    auto sk_3 = sk;
    auto slots_4 = slots;
    auto sums_5 = sums;
    return call_value(fold_job(slots_4, Map<Text, Rel>{}, ({
        auto sks_6 = sks;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Rel>>(std::tuple<Map<Text, Rel>, Slot_>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Rel>, Slot_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sks_6_7 = sks_6;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                auto sl = p1;
                call_then(start_slot_calls(sks_6_7, sl), [=](Array<Site> slot_calls_59504) {
                return ({
                    auto calls = slot_calls_59504;
                    fold_job(crate::check_errors::range0(sl.arity), m, ({
                    auto calls_7 = calls;
                    auto sl_8 = sl;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Rel>>(std::tuple<Map<Text, Rel>, Nat>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Rel>, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto calls_7_9 = calls_7;
                        auto sl_8_9 = sl_8;
                        entered(once_job([=]() {
                        return ({
                            auto m2 = p0;
                            auto q = p1;
                            call_then(start_meet_args(calls_7_9, q), [=](std::optional<Rel> meet_args_59572) {
                            return ({
                                prism_rtl::is_some(meet_args_59572) ? ({
                                auto&& r = prism_rtl::some_of(meet_args_59572);
                                prism_rtl::finished(insert(m2, prism_rtl::cat(sl_8_9.owner, ":", sl_8_9.at, ":", q), r));
                            })
                                : prism_rtl::is_none(meet_args_59572) ? prism_rtl::finished(m2)
                                : throw prism_rtl::Panic("no arm matched");
                            });
                        });
                        });
                    }));
                    });
                }));
                }))->cycle();
                });
            });
            });
        }));
        });
    }));
    })), [=](Map<Text, Rel> fold_59459) {
        return ({
            auto next = fold_59459;
            next == sums_5
            ? prism_rtl::finished(next)
            : round_2 > Nat(12u)
            ? prism_rtl::finished(Map<Text, Rel>{})
            : prism_rtl::more(prism_rtl::rc(SlotSums(sk_3, homes_1, slots_4, next, round_2 + Nat(1u))));
        });
    });
}


/// `Start SlotSums, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Rel>> start_slot_sums(Shrink sk, Array<Text> homes, Array<Slot_> slots, Map<Text, Rel> sums, Nat round) {
    return prism_rtl::make_rc<SlotSums>(sk, homes, slots, sums, round);
}


/// SlotCalls: unbounded fn Shrink, Slot -> [Site]
Array<Site> slot_calls(const Shrink& sk, const Slot_& sl) {
    auto&& _m = prelude::get(sk.by_key, sl.owner);
    if (prism_rtl::is_some(_m)) {
        auto&& d = prism_rtl::some_of(_m);
        return run_to_end(fold_job(def_clauses(d), Array<Site>{}, ({
            auto sl_1 = sl;
            auto sk_2 = sk;
            auto d_3 = d;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Site>>(std::tuple<Array<Site>, crate::ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<Site>, crate::ast::FnClause> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto sl_1_4 = sl_1;
                auto sk_2_4 = sk_2;
                auto d_3_4 = d_3;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto c = p1;
                    ({
                    auto n = slot_name(c, sl_1_4.at);
                    n == Text::lit("")
                    ? prism_rtl::finished(acc)
                    : call_then(start_clause_base(sk_2_4, d_3_4, c), [=](Map<Text, Rel> clause_base_60097) {
                    return ({
                        auto base = clause_base_60097;
                        call_then(start_body_spots(c.body, base), [=](Array<Spot> body_spots_60161) {
                        return call_then(start_summary_seeds(sk_2_4, d_3_4, body_spots_60161, base), [=](Map<Text, Rel> summary_seeds_60140) {
                            return ({
                                auto rels = summary_seeds_60140;
                                call_then(start_body_spots(c.body, rels), [=](Array<Spot> body_spots_60209) {
                                return fold_job(body_spots_60209, acc, ({
                                    auto n_4 = n;
                                    auto sl_1_4_5 = sl_1_4;
                                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Site>>(std::tuple<Array<Site>, Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Site>, Spot> _p0) {
                                    auto&& p0 = std::get<0>(_p0);
                                    auto&& p1 = std::get<1>(_p0);
                                    return ({
                                        auto n_4_5 = n_4;
                                        auto sl_1_4_5_5 = sl_1_4_5;
                                        entered(once_job([=]() {
                                        return ({
                                            auto a2 = p0;
                                            auto sp = p1;
                                            ({
                                            prism_rtl::is<Spot::SpotExpr>(sp) ? ({
                                            auto&& e = prism_rtl::as<Spot::SpotExpr>(sp).a0;
                                            ({
                                            auto&& _m = e.kind;
                                            prism_rtl::is<crate::ast::ExprKind::EName>(_m) ? prism_rtl::finished(a2)
                                            : call_then(start_spot_sites(sp), [=](Array<Site> spot_sites_60397) { return prism_rtl::finished(append(a2, filter(spot_sites_60397, [&](const Site& site) { return (site.callee == n_4_5) && is_slot_param(site.rels, n_4_5, sl_1_4_5_5.at); }))); });
                                        });
                                        })
                                            : prism_rtl::finished(a2);
                                        });
                                        });
                                    }));
                                    });
                                })));
                                }))->cycle();
                            });
                            });
                        });
                    });
                    });
                });
                });
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is_none(_m)) {
        return Array<Site>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Site>> SlotCalls::cycle() const {
    const auto& sk = this->sk;
    const auto& sl = this->sl;
    return ({
        auto&& _m = prelude::get(sk.by_key, sl.owner);
        prism_rtl::is_some(_m) ? ({
        auto&& d = prism_rtl::some_of(_m);
        fold_job(def_clauses(d), Array<Site>{}, ({
        auto sl_1 = sl;
        auto sk_2 = sk;
        auto d_3 = d;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Site>>(std::tuple<Array<Site>, crate::ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<Site>, crate::ast::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sl_1_4 = sl_1;
            auto sk_2_4 = sk_2;
            auto d_3_4 = d_3;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                ({
                auto n = slot_name(c, sl_1_4.at);
                n == Text::lit("")
                ? prism_rtl::finished(acc)
                : call_then(start_clause_base(sk_2_4, d_3_4, c), [=](Map<Text, Rel> clause_base_60097) {
                return ({
                    auto base = clause_base_60097;
                    call_then(start_body_spots(c.body, base), [=](Array<Spot> body_spots_60161) {
                    return call_then(start_summary_seeds(sk_2_4, d_3_4, body_spots_60161, base), [=](Map<Text, Rel> summary_seeds_60140) {
                        return ({
                            auto rels = summary_seeds_60140;
                            call_then(start_body_spots(c.body, rels), [=](Array<Spot> body_spots_60209) {
                            return fold_job(body_spots_60209, acc, ({
                                auto n_4 = n;
                                auto sl_1_4_5 = sl_1_4;
                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Site>>(std::tuple<Array<Site>, Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Site>, Spot> _p0) {
                                auto&& p0 = std::get<0>(_p0);
                                auto&& p1 = std::get<1>(_p0);
                                return ({
                                    auto n_4_5 = n_4;
                                    auto sl_1_4_5_5 = sl_1_4_5;
                                    entered(once_job([=]() {
                                    return ({
                                        auto a2 = p0;
                                        auto sp = p1;
                                        ({
                                        prism_rtl::is<Spot::SpotExpr>(sp) ? ({
                                        auto&& e = prism_rtl::as<Spot::SpotExpr>(sp).a0;
                                        ({
                                        auto&& _m = e.kind;
                                        prism_rtl::is<crate::ast::ExprKind::EName>(_m) ? prism_rtl::finished(a2)
                                        : call_then(start_spot_sites(sp), [=](Array<Site> spot_sites_60397) { return prism_rtl::finished(append(a2, filter(spot_sites_60397, [&](const Site& site) { return (site.callee == n_4_5) && is_slot_param(site.rels, n_4_5, sl_1_4_5_5.at); }))); });
                                    });
                                    })
                                        : prism_rtl::finished(a2);
                                    });
                                    });
                                }));
                                });
                            })));
                            }))->cycle();
                        });
                        });
                    });
                });
                });
            });
            });
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(Array<Site>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SlotCalls, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Site>> start_slot_calls(Shrink sk, Slot_ sl) {
    return prism_rtl::make_rc<SlotCalls>(sk, sl);
}


/// ?MeetArgs: unbounded fn [Site], Nat -> ?Rel
std::optional<Rel> meet_args(const Array<Site>& calls, const Nat& q) {
    return run_to_end(fold_job(calls, std::optional(Rel{.param = top_param(), .strict = false}), ({
        auto q_1 = q;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<Rel>>(std::tuple<std::optional<Rel>, Site>)>>(prism_rtl::rc([=](std::tuple<std::optional<Rel>, Site> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto q_1_2 = q_1;
            entered(once_job([=]() {
            return ({
                auto acc_opt = p0;
                auto site = p1;
                ({
                prism_rtl::is_none(acc_opt) ? prism_rtl::finished(std::optional<Rel>{})
                : prism_rtl::is_some(acc_opt) ? ({
                auto&& acc = prism_rtl::some_of(acc_opt);
                ({
                auto&& _m = index(site->args, q_1_2);
                prism_rtl::is_some(_m) ? ({
                auto&& a = prism_rtl::some_of(_m);
                a.name != std::optional<crate::ast::Ident>{}
                ? prism_rtl::finished(std::optional<Rel>{})
                : ({
                auto acc_2 = acc;
                call_then(start_rel_of(site.rels, a->value), [=](std::optional<Rel> rel_of_60974) {
                return ({
                    prism_rtl::is_some(rel_of_60974) ? ({
                    auto&& r = prism_rtl::some_of(rel_of_60974);
                    r.param == top_param()
                    ? prism_rtl::finished(std::optional(acc_2))
                    : acc_2.param == top_param()
                    ? prism_rtl::finished(std::optional(r))
                    : acc_2.param == r.param
                    ? prism_rtl::finished(std::optional(Rel{.param = r.param, .strict = acc_2.strict && r.strict}))
                    : prism_rtl::finished(std::optional<Rel>{});
                })
                    : prism_rtl::is_none(rel_of_60974) ? prism_rtl::finished(std::optional<Rel>{})
                    : throw prism_rtl::Panic("no arm matched");
                });
            });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<Rel>{})
                : throw prism_rtl::Panic("no arm matched");
            });
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<std::optional<Rel>> MeetArgs::cycle() const {
    const auto& calls = this->calls;
    const auto& q = this->q;
    return fold_job(calls, std::optional(Rel{.param = top_param(), .strict = false}), ({
        auto q_1 = q;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<Rel>>(std::tuple<std::optional<Rel>, Site>)>>(prism_rtl::rc([=](std::tuple<std::optional<Rel>, Site> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto q_1_2 = q_1;
            entered(once_job([=]() {
            return ({
                auto acc_opt = p0;
                auto site = p1;
                ({
                prism_rtl::is_none(acc_opt) ? prism_rtl::finished(std::optional<Rel>{})
                : prism_rtl::is_some(acc_opt) ? ({
                auto&& acc = prism_rtl::some_of(acc_opt);
                ({
                auto&& _m = index(site->args, q_1_2);
                prism_rtl::is_some(_m) ? ({
                auto&& a = prism_rtl::some_of(_m);
                a.name != std::optional<crate::ast::Ident>{}
                ? prism_rtl::finished(std::optional<Rel>{})
                : ({
                auto acc_2 = acc;
                call_then(start_rel_of(site.rels, a->value), [=](std::optional<Rel> rel_of_60974) {
                return ({
                    prism_rtl::is_some(rel_of_60974) ? ({
                    auto&& r = prism_rtl::some_of(rel_of_60974);
                    r.param == top_param()
                    ? prism_rtl::finished(std::optional(acc_2))
                    : acc_2.param == top_param()
                    ? prism_rtl::finished(std::optional(r))
                    : acc_2.param == r.param
                    ? prism_rtl::finished(std::optional(Rel{.param = r.param, .strict = acc_2.strict && r.strict}))
                    : prism_rtl::finished(std::optional<Rel>{});
                })
                    : prism_rtl::is_none(rel_of_60974) ? prism_rtl::finished(std::optional<Rel>{})
                    : throw prism_rtl::Panic("no arm matched");
                });
            });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<Rel>{})
                : throw prism_rtl::Panic("no arm matched");
            });
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start MeetArgs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Rel>> start_meet_args(Array<Site> calls, Nat q) {
    return prism_rtl::make_rc<MeetArgs>(calls, q);
}


/// DefRefs: unbounded fn Shrink, Def -> [Text]
Array<Text> def_refs(const Shrink& sk, const crate::check_env::Def& d) {
    return run_to_end(fold_job(def_clauses(d), Array<Text>{}, ({
        auto sk_1 = sk;
        auto d_2 = d;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::ast::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_1_3 = sk_1;
            auto d_2_3 = d_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                call_then(start_clause_base(sk_1_3, d_2_3, c), [=](Map<Text, Rel> clause_base_61511) { return call_then(start_body_spots(c.body, clause_base_61511), [=](Array<Spot> body_spots_61492) { return prism_rtl::more(prism_rtl::rc(SpotsRefs(sk_1_3, d_2_3, body_spots_61492, acc))); }); });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Text>> DefRefs::cycle() const {
    const auto& sk = this->sk;
    const auto& d = this->d;
    return fold_job(def_clauses(d), Array<Text>{}, ({
        auto sk_1 = sk;
        auto d_2 = d;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::ast::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_1_3 = sk_1;
            auto d_2_3 = d_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                call_then(start_clause_base(sk_1_3, d_2_3, c), [=](Map<Text, Rel> clause_base_61511) { return call_then(start_body_spots(c.body, clause_base_61511), [=](Array<Spot> body_spots_61492) { return prism_rtl::more(prism_rtl::rc(SpotsRefs(sk_1_3, d_2_3, body_spots_61492, acc))); }); });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start DefRefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_def_refs(Shrink sk, crate::check_env::Def d) {
    return prism_rtl::make_rc<DefRefs>(sk, d);
}


/// SpotsRefs: unbounded fn Shrink, Def, [Spot], [Text] -> [Text]
Array<Text> spots_refs(const Shrink& sk, const crate::check_env::Def& d, const Array<Spot>& spots, const Array<Text>& acc) {
    return run_to_end(fold_job(spots, acc, ({
        auto sk_1 = sk;
        auto d_2 = d;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_1_3 = sk_1;
            auto d_2_3 = d_2;
            entered(once_job([=]() {
            return ({
                auto a1 = p0;
                auto sp = p1;
                call_then(start_spot_sites(sp), [=](Array<Site> spot_sites_61667) {
                return prism_rtl::finished(fold(spot_sites_61667, a1, [&](const Array<Text>& a2, const Site& site) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Text>> _v;
                        auto&& _m = local_target(sk_1_3, d_2_3, site);
                        if (prism_rtl::is_some(_m)) {
                            auto&& t = prism_rtl::some_of(_m);
                            _v.set(crate::check_types::add_text(a2, t));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(is_local(site.rels, site.callee) || crate::check_env::has_key(sk_1_3.local_of, d_2_3.qk)
                                ? a2
                                : ({
                                __label__ _done;
                                prism_rtl::Slot<Array<Text>> _v;
                                auto&& _m = resolve_callee(sk_1_3.g, d_2_3.home, site.callee);
                                if (prism_rtl::is_some(_m)) {
                                    auto&& k = prism_rtl::some_of(_m);
                                    _v.set(fold(targets_of(sk_1_3, k), a2, [&](const Array<Text>& a3, const Text& t) {
                                        return crate::check_env::has_key(sk_1_3.by_key, t)
                                            ? crate::check_types::add_text(a3, t)
                                            : a3;
                                    }));
                                    goto _done;
                                }
                                if (prism_rtl::is_none(_m)) {
                                    _v.set(a2);
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                }));
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Text>> SpotsRefs::cycle() const {
    const auto& sk = this->sk;
    const auto& d = this->d;
    const auto& spots = this->spots;
    const auto& acc = this->acc;
    return fold_job(spots, acc, ({
        auto sk_1 = sk;
        auto d_2 = d;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_1_3 = sk_1;
            auto d_2_3 = d_2;
            entered(once_job([=]() {
            return ({
                auto a1 = p0;
                auto sp = p1;
                call_then(start_spot_sites(sp), [=](Array<Site> spot_sites_61667) {
                return prism_rtl::finished(fold(spot_sites_61667, a1, [&](const Array<Text>& a2, const Site& site) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Text>> _v;
                        auto&& _m = local_target(sk_1_3, d_2_3, site);
                        if (prism_rtl::is_some(_m)) {
                            auto&& t = prism_rtl::some_of(_m);
                            _v.set(crate::check_types::add_text(a2, t));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(is_local(site.rels, site.callee) || crate::check_env::has_key(sk_1_3.local_of, d_2_3.qk)
                                ? a2
                                : ({
                                __label__ _done;
                                prism_rtl::Slot<Array<Text>> _v;
                                auto&& _m = resolve_callee(sk_1_3.g, d_2_3.home, site.callee);
                                if (prism_rtl::is_some(_m)) {
                                    auto&& k = prism_rtl::some_of(_m);
                                    _v.set(fold(targets_of(sk_1_3, k), a2, [&](const Array<Text>& a3, const Text& t) {
                                        return crate::check_env::has_key(sk_1_3.by_key, t)
                                            ? crate::check_types::add_text(a3, t)
                                            : a3;
                                    }));
                                    goto _done;
                                }
                                if (prism_rtl::is_none(_m)) {
                                    _v.set(a2);
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                }));
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start SpotsRefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_spots_refs(Shrink sk, crate::check_env::Def d, Array<Spot> spots, Array<Text> acc) {
    return prism_rtl::make_rc<SpotsRefs>(sk, d, spots, acc);
}


/// WithLocals: unbounded fn Shrink, [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))] -> Shrink
Shrink with_locals(const Shrink& sk, const Array<std::tuple<crate::check_env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::ast::FnClause>, std::optional<crate::ast::WidgetDecl>>>& found) {
    auto [bases, owners, clauses, wdecls] = fold(found, std::tuple{Map<Text, Map<Text, Rel>>{}, Map<Text, Text>{}, Map<Text, Array<crate::ast::FnClause>>{}, Map<Text, std::tuple<crate::check_env::Def, crate::ast::WidgetDecl>>{}}, [&](const std::tuple<Map<Text, Map<Text, Rel>>, Map<Text, Text>, Map<Text, Array<crate::ast::FnClause>>, Map<Text, std::tuple<crate::check_env::Def, crate::ast::WidgetDecl>>>& _p0, const std::tuple<crate::check_env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::ast::FnClause>, std::optional<crate::ast::WidgetDecl>>& _p1) {
        auto&& bs = std::get<0>(_p0);
        auto&& os = std::get<1>(_p0);
        auto&& cs = std::get<2>(_p0);
        auto&& ws = std::get<3>(_p0);
        auto&& d = std::get<0>(_p1);
        auto&& gk = std::get<1>(_p1);
        auto&& n = std::get<2>(_p1);
        auto&& m = std::get<3>(_p1);
        auto&& c_opt = std::get<4>(_p1);
        auto&& w_opt = std::get<5>(_p1);
        return ({
            auto qk = local_key(n, d.qk, gk);
            auto bs2 = crate::check_env::has_key(bs, qk) ? bs : insert(bs, qk, marks(m));
            auto os2 = insert(os, qk, d.qk);
            auto cs2 = ({
                __label__ _done;
                prism_rtl::Slot<Map<Text, Array<crate::ast::FnClause>>> _v;
                if (prism_rtl::is_some(c_opt)) {
                    auto&& c = prism_rtl::some_of(c_opt);
                    _v.set(insert(cs, qk, prelude::push(or_(prelude::get(cs, qk), Array<crate::ast::FnClause>{}), c)));
                    goto _done;
                }
                if (prism_rtl::is_none(c_opt)) {
                    _v.set(cs);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto ws2 = ({
                __label__ _done;
                prism_rtl::Slot<Map<Text, std::tuple<crate::check_env::Def, crate::ast::WidgetDecl>>> _v;
                if (prism_rtl::is_some(w_opt)) {
                    auto&& w = prism_rtl::some_of(w_opt);
                    _v.set(insert(ws, qk, std::tuple{d, w}));
                    goto _done;
                }
                if (prism_rtl::is_none(w_opt)) {
                    _v.set(ws);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            std::tuple{bs2, os2, cs2, ws2};
        });
    });
    auto fn_defs = fold(keys(clauses), Array<crate::check_env::Def>{}, [&](const Array<crate::check_env::Def>& acc, const Text& qk) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check_env::Def>> _v;
            auto&& _m = std::tuple{prelude::get(owners, qk), prelude::get(clauses, qk)};
            if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                auto&& oq = prism_rtl::some_of(std::get<0>(_m));
                auto&& cl = prism_rtl::some_of(std::get<1>(_m));
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::check_env::Def>> _v;
                    auto&& _m = prelude::get(sk.by_key, oq);
                    if (prism_rtl::is_some(_m)) {
                        auto&& d = prism_rtl::some_of(_m);
                        _v.set(prelude::push(acc, crate::check_env::Def{.qk = qk, .name = or_(index(split(qk, Text::lit(" #")), Nat(0u)), qk), .home = d.home, .file = d->file, .span = d.span, .body = crate::check_env::DefBody(crate::check_env::DefBody::DbFn{cl})}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto w_defs = fold(keys(wdecls), Array<crate::check_env::Def>{}, [&](const Array<crate::check_env::Def>& acc, const Text& qk) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check_env::Def>> _v;
            auto&& _m = prelude::get(wdecls, qk);
            if (prism_rtl::is_some(_m)) {
                auto&& d = std::get<0>(prism_rtl::some_of(_m));
                auto&& w = std::get<1>(prism_rtl::some_of(_m));
                _v.set(prelude::push(acc, crate::check_env::Def{.qk = qk, .name = crate::check_env::sname_key(w.name), .home = d.home, .file = d->file, .span = w.span, .body = crate::check_env::DefBody(crate::check_env::DefBody::DbWidget{w})}));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(acc);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    auto locals = append(fn_defs, w_defs);
    Shrink this_ = sk;
    this_.fns = append(this_.fns, locals);
    this_.by_key = fold(locals, this_.by_key, [&](const Map<Text, crate::check_env::Def>& m, const crate::check_env::Def& d) { return insert(m, d.qk, d); });
    this_.local_of = owners;
    this_.local_base = bases;
    return this_;
}


prism_rtl::Turn<Shrink> WithLocals::cycle() const {
    const auto& sk = this->sk;
    const auto& found = this->found;
    auto [bases, owners, clauses, wdecls] = fold(found, std::tuple{Map<Text, Map<Text, Rel>>{}, Map<Text, Text>{}, Map<Text, Array<crate::ast::FnClause>>{}, Map<Text, std::tuple<crate::check_env::Def, crate::ast::WidgetDecl>>{}}, [&](const std::tuple<Map<Text, Map<Text, Rel>>, Map<Text, Text>, Map<Text, Array<crate::ast::FnClause>>, Map<Text, std::tuple<crate::check_env::Def, crate::ast::WidgetDecl>>>& _p0, const std::tuple<crate::check_env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::ast::FnClause>, std::optional<crate::ast::WidgetDecl>>& _p1) {
        auto&& bs = std::get<0>(_p0);
        auto&& os = std::get<1>(_p0);
        auto&& cs = std::get<2>(_p0);
        auto&& ws = std::get<3>(_p0);
        auto&& d = std::get<0>(_p1);
        auto&& gk = std::get<1>(_p1);
        auto&& n = std::get<2>(_p1);
        auto&& m = std::get<3>(_p1);
        auto&& c_opt = std::get<4>(_p1);
        auto&& w_opt = std::get<5>(_p1);
        return ({
            auto qk = local_key(n, d.qk, gk);
            auto bs2 = crate::check_env::has_key(bs, qk) ? bs : insert(bs, qk, marks(m));
            auto os2 = insert(os, qk, d.qk);
            auto cs2 = ({
                __label__ _done;
                prism_rtl::Slot<Map<Text, Array<crate::ast::FnClause>>> _v;
                if (prism_rtl::is_some(c_opt)) {
                    auto&& c = prism_rtl::some_of(c_opt);
                    _v.set(insert(cs, qk, prelude::push(or_(prelude::get(cs, qk), Array<crate::ast::FnClause>{}), c)));
                    goto _done;
                }
                if (prism_rtl::is_none(c_opt)) {
                    _v.set(cs);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto ws2 = ({
                __label__ _done;
                prism_rtl::Slot<Map<Text, std::tuple<crate::check_env::Def, crate::ast::WidgetDecl>>> _v;
                if (prism_rtl::is_some(w_opt)) {
                    auto&& w = prism_rtl::some_of(w_opt);
                    _v.set(insert(ws, qk, std::tuple{d, w}));
                    goto _done;
                }
                if (prism_rtl::is_none(w_opt)) {
                    _v.set(ws);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            std::tuple{bs2, os2, cs2, ws2};
        });
    });
    auto fn_defs = fold(keys(clauses), Array<crate::check_env::Def>{}, [&](const Array<crate::check_env::Def>& acc, const Text& qk) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check_env::Def>> _v;
            auto&& _m = std::tuple{prelude::get(owners, qk), prelude::get(clauses, qk)};
            if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                auto&& oq = prism_rtl::some_of(std::get<0>(_m));
                auto&& cl = prism_rtl::some_of(std::get<1>(_m));
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::check_env::Def>> _v;
                    auto&& _m = prelude::get(sk.by_key, oq);
                    if (prism_rtl::is_some(_m)) {
                        auto&& d = prism_rtl::some_of(_m);
                        _v.set(prelude::push(acc, crate::check_env::Def{.qk = qk, .name = or_(index(split(qk, Text::lit(" #")), Nat(0u)), qk), .home = d.home, .file = d->file, .span = d.span, .body = crate::check_env::DefBody(crate::check_env::DefBody::DbFn{cl})}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto w_defs = fold(keys(wdecls), Array<crate::check_env::Def>{}, [&](const Array<crate::check_env::Def>& acc, const Text& qk) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check_env::Def>> _v;
            auto&& _m = prelude::get(wdecls, qk);
            if (prism_rtl::is_some(_m)) {
                auto&& d = std::get<0>(prism_rtl::some_of(_m));
                auto&& w = std::get<1>(prism_rtl::some_of(_m));
                _v.set(prelude::push(acc, crate::check_env::Def{.qk = qk, .name = crate::check_env::sname_key(w.name), .home = d.home, .file = d->file, .span = w.span, .body = crate::check_env::DefBody(crate::check_env::DefBody::DbWidget{w})}));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(acc);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    auto locals = append(fn_defs, w_defs);
    return prism_rtl::finished(({
        Shrink this_ = sk;
        this_.fns = append(this_.fns, locals);
        this_.by_key = fold(locals, this_.by_key, [&](const Map<Text, crate::check_env::Def>& m, const crate::check_env::Def& d) { return insert(m, d.qk, d); });
        this_.local_of = owners;
        this_.local_base = bases;
        this_;
    }));
}


/// `Start WithLocals, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Shrink> start_with_locals(Shrink sk, Array<std::tuple<crate::check_env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::ast::FnClause>, std::optional<crate::ast::WidgetDecl>>> found) {
    return prism_rtl::make_rc<WithLocals>(sk, found);
}


/// LocalKey: fn Text, Text, Text -> Text
Text local_key(const Text& n, const Text& owner, const Text& gk) {
    return prism_rtl::cat(n, " #local ", owner, " ", gk);
}


/// DefWalk: unbounded fn Shrink, Def -> ((Text, [Text], [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))]))
std::tuple<Text, Array<Text>, Array<std::tuple<crate::check_env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::ast::FnClause>, std::optional<crate::ast::WidgetDecl>>>> def_walk(const Shrink& sk, const crate::check_env::Def& d) {
    auto [refs, locals] = run_to_end(fold_job(def_clauses(d), std::tuple{Array<Text>{}, Array<std::tuple<crate::check_env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::ast::FnClause>, std::optional<crate::ast::WidgetDecl>>>{}}, ({
        auto sk_1 = sk;
        auto d_2 = d;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Array<std::tuple<crate::check_env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::ast::FnClause>, std::optional<crate::ast::WidgetDecl>>>>>(std::tuple<std::tuple<Array<Text>, Array<std::tuple<crate::check_env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::ast::FnClause>, std::optional<crate::ast::WidgetDecl>>>>, crate::ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Text>, Array<std::tuple<crate::check_env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::ast::FnClause>, std::optional<crate::ast::WidgetDecl>>>>, crate::ast::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_1_3 = sk_1;
            auto d_2_3 = d_2;
            entered(once_job([=]() {
            return ({
                auto [rs, ls] = p0;
                auto c = p1;
                call_then(start_clause_base(sk_1_3, d_2_3, c), [=](Map<Text, Rel> clause_base_65175) {
                return call_then(start_body_spots(c.body, clause_base_65175), [=](Array<Spot> body_spots_65156) {
                    return ({
                        auto spots = body_spots_65156;
                        call_then(start_spots_refs(sk_1_3, d_2_3, spots, rs), [=](Array<Text> spots_refs_65207) { return prism_rtl::finished(std::tuple{spots_refs_65207, fold(spots, ls, [&](const Array<std::tuple<crate::check_env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::ast::FnClause>, std::optional<crate::ast::WidgetDecl>>>& a2, const Spot& sp) { return append(a2, spot_local(d_2_3, sp)); })}); });
                    });
                });
            });
            });
        }));
        });
    }));
    })));
    return std::tuple{d.qk, refs, locals};
}


prism_rtl::Turn<std::tuple<Text, Array<Text>, Array<std::tuple<crate::check_env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::ast::FnClause>, std::optional<crate::ast::WidgetDecl>>>>> DefWalk::cycle() const {
    const auto& sk = this->sk;
    const auto& d = this->d;
    auto d_1 = d;
    auto sk_2 = sk;
    return call_value(fold_job(def_clauses(d_1), std::tuple{Array<Text>{}, Array<std::tuple<crate::check_env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::ast::FnClause>, std::optional<crate::ast::WidgetDecl>>>{}}, ({
        auto sk_2_3 = sk_2;
        auto d_1_3 = d_1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Array<std::tuple<crate::check_env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::ast::FnClause>, std::optional<crate::ast::WidgetDecl>>>>>(std::tuple<std::tuple<Array<Text>, Array<std::tuple<crate::check_env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::ast::FnClause>, std::optional<crate::ast::WidgetDecl>>>>, crate::ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Text>, Array<std::tuple<crate::check_env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::ast::FnClause>, std::optional<crate::ast::WidgetDecl>>>>, crate::ast::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_2_3_3 = sk_2_3;
            auto d_1_3_3 = d_1_3;
            entered(once_job([=]() {
            return ({
                auto [rs, ls] = p0;
                auto c = p1;
                call_then(start_clause_base(sk_2_3_3, d_1_3_3, c), [=](Map<Text, Rel> clause_base_65175) {
                return call_then(start_body_spots(c.body, clause_base_65175), [=](Array<Spot> body_spots_65156) {
                    return ({
                        auto spots = body_spots_65156;
                        call_then(start_spots_refs(sk_2_3_3, d_1_3_3, spots, rs), [=](Array<Text> spots_refs_65207) { return prism_rtl::finished(std::tuple{spots_refs_65207, fold(spots, ls, [&](const Array<std::tuple<crate::check_env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::ast::FnClause>, std::optional<crate::ast::WidgetDecl>>>& a2, const Spot& sp) { return append(a2, spot_local(d_1_3_3, sp)); })}); });
                    });
                });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<Text>, Array<std::tuple<crate::check_env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::ast::FnClause>, std::optional<crate::ast::WidgetDecl>>>> fold_65082) {
        return ({
            auto [refs, locals] = fold_65082;
            (prism_rtl::finished(std::tuple{d_1.qk, refs, locals}));
        });
    });
}


/// `Start DefWalk, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, Array<Text>, Array<std::tuple<crate::check_env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::ast::FnClause>, std::optional<crate::ast::WidgetDecl>>>>> start_def_walk(Shrink sk, crate::check_env::Def d) {
    return prism_rtl::make_rc<DefWalk>(sk, d);
}


/// SpotLocal: fn Def, Spot -> [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))]
Array<std::tuple<crate::check_env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::ast::FnClause>, std::optional<crate::ast::WidgetDecl>>> spot_local(const crate::check_env::Def& d, const Spot& sp) {
    if (prism_rtl::is<Spot::SpotStmt>(sp)) {
        auto&& s = prism_rtl::as<Spot::SpotStmt>(sp).a0;
        auto&& m = prism_rtl::as<Spot::SpotStmt>(sp).a1;
        auto&& _m = s.kind;
        if (prism_rtl::is<crate::ast::StmtKind::SFn>(_m)) {
            auto&& f = prism_rtl::as<crate::ast::StmtKind::SFn>(_m).a0;
            auto n = crate::check_env::def_name_text(f.name);
            auto&& _m = prelude::get(m, prism_rtl::cat("lfn:", n));
            if (prism_rtl::is_some(_m)) {
                auto&& r = prism_rtl::some_of(_m);
                return Array(std::vector{std::tuple{d, prism_rtl::cat(d->file, ".", r.param), n, m, std::optional(f), std::optional<crate::ast::WidgetDecl>{}}});
            }
            if (prism_rtl::is_none(_m)) {
                return Array<std::tuple<crate::check_env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::ast::FnClause>, std::optional<crate::ast::WidgetDecl>>>{};
            }
            prism_rtl::unreachable("no arm matched");
        }
        if (prism_rtl::is<crate::ast::StmtKind::SWidget>(_m)) {
            auto&& w = prism_rtl::as<crate::ast::StmtKind::SWidget>(_m).a0;
            auto n = crate::check_env::sname_key(w.name);
            auto&& _m = prelude::get(m, prism_rtl::cat("lfn:", n));
            if (prism_rtl::is_some(_m)) {
                auto&& r = prism_rtl::some_of(_m);
                return Array(std::vector{std::tuple{d, prism_rtl::cat(d->file, ".", r.param), n, m, std::optional<crate::ast::FnClause>{}, std::optional(w)}});
            }
            if (prism_rtl::is_none(_m)) {
                return Array<std::tuple<crate::check_env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::ast::FnClause>, std::optional<crate::ast::WidgetDecl>>>{};
            }
            prism_rtl::unreachable("no arm matched");
        }
        {
            return Array<std::tuple<crate::check_env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::ast::FnClause>, std::optional<crate::ast::WidgetDecl>>>{};
        }
    }
    {
        return Array<std::tuple<crate::check_env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::ast::FnClause>, std::optional<crate::ast::WidgetDecl>>>{};
    }
}


/// ?LocalTarget: fn Shrink, Def, Site -> ?Text
std::optional<Text> local_target(const Shrink& sk, const crate::check_env::Def& d, const Site& site) {
    auto&& _m = prelude::get(site.rels, prism_rtl::cat("lfn:", site.callee));
    if (prism_rtl::is_some(_m)) {
        auto&& r = prism_rtl::some_of(_m);
        return std::optional(local_key(site.callee, or_(prelude::get(sk.local_of, d.qk), d.qk), prism_rtl::cat(d->file, ".", r.param)));
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// ClauseBase: unbounded fn Shrink, Def, FnClause -> (Text ==> Rel)
Map<Text, Rel> clause_base(const Shrink& sk, const crate::check_env::Def& d, const crate::ast::FnClause& c) {
    auto&& _m = prelude::get(sk.local_base, d.qk);
    if (prism_rtl::is_some(_m)) {
        auto&& b = prism_rtl::some_of(_m);
        return param_rels_on(b, c.params);
    }
    if (prism_rtl::is_none(_m)) {
        return param_rels_on(insert(or_(prelude::get(sk.seeds, d.home), Map<Text, Rel>{}), Text::lit("file:"), Rel{.param = d->file, .strict = false}), c.params);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Map<Text, Rel>> ClauseBase::cycle() const {
    const auto& sk = this->sk;
    const auto& d = this->d;
    const auto& c = this->c;
    return ({
        auto&& _m = prelude::get(sk.local_base, d.qk);
        prism_rtl::is_some(_m) ? ({
        auto&& b = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(ParamRelsOn(b, c.params)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(ParamRelsOn(insert(or_(prelude::get(sk.seeds, d.home), Map<Text, Rel>{}), Text::lit("file:"), Rel{.param = d->file, .strict = false}), c.params)))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ClauseBase, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Rel>> start_clause_base(Shrink sk, crate::check_env::Def d, crate::ast::FnClause c) {
    return prism_rtl::make_rc<ClauseBase>(sk, d, c);
}


/// ?ResolveCallee: fn G, Text, Text -> ?Text
std::optional<Text> resolve_callee(const crate::check_env::G& g, const Text& m, const Text& n) {
    return is_op_text(n)
        ? resolve_op(g, m, n)
        : ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Text>> _v;
        auto&& _m = resolve_name(g, m, n);
        if (prism_rtl::is_some(_m)) {
            auto&& k = prism_rtl::some_of(_m);
            _v.set(std::optional(k));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::lexer::has_prefix(n, Text::lit("@"))
                ? resolve_name(g, m, crate::lexer::after_first(n))
                : std::optional<Text>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// ?ResolveOp: fn G, Text, Text -> ?Text
std::optional<Text> resolve_op(const crate::check_env::G& g, const Text& m, const Text& op) {
    auto&& _k_opt = crate::check_env::resolve_value(g, m, crate::ast::SName{.sigils = Text::lit(""), .path_ = Array(std::vector{op}), .span = crate::ast::Range{.start = Nat(0u), .end = Nat(0u)}});
    auto&& k_opt = std::get<0>(_k_opt);
    return k_opt;
}


/// IsOpText: fn Text -> Bool
bool is_op_text(const Text& n) {
    return (len_text(n) > Nat(0u)) && (!crate::lexer::fold_chars(n, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Text>)>>(prism_rtl::rc([=](std::tuple<bool, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return once_job([=]() {
            return ({
                auto seen = p0;
                auto ch = p1;
                (prism_rtl::finished(((seen || crate::lexer::is_upper(ch)) || crate::lexer::is_lower(ch)) || (ch == Text::lit("_"))));
            });
        });
    }))));
}


/// ?ResolveName: fn G, Text, Text -> ?Text
std::optional<Text> resolve_name(const crate::check_env::G& g, const Text& m, const Text& n) {
    auto marks_ = crate::check_types::marks_of(n);
    auto path_ = split(crate::lexer::drop_prefix(n, marks_), Text::lit("."));
    auto&& _k_opt = crate::check_env::resolve_value(g, m, crate::ast::SName{.sigils = marks_, .path_ = path_, .span = crate::ast::Range{.start = Nat(0u), .end = Nat(0u)}});
    auto&& k_opt = std::get<0>(_k_opt);
    return k_opt;
}


/// NamesInStmt: unbounded fn Stmt -> [Text]
Array<Text> names_in_stmt(const crate::ast::Stmt& s) {
    return spots_names(stmt_spots(s, Map<Text, Rel>{}));
}


prism_rtl::Turn<Array<Text>> NamesInStmt::cycle() const {
    const auto& s = this->s;
    auto s_1 = s;
    return call_then(start_stmt_spots(s_1, Map<Text, Rel>{}), [=](Array<Spot> stmt_spots_67678) { return prism_rtl::more(prism_rtl::rc(SpotsNames(stmt_spots_67678))); });
}


/// `Start NamesInStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_names_in_stmt(crate::ast::Stmt s) {
    return prism_rtl::make_rc<NamesInStmt>(s);
}


/// Sccs: unbounded fn [Text], [((Text, [Text]))] -> [ [Text] ]
Array<Array<Text>> sccs(const Array<Text>& keys_, const Array<std::tuple<Text, Array<Text>>>& refs) {
    auto adj = fold(refs, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& m, const std::tuple<Text, Array<Text>>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        return insert(m, k, rs);
    });
    auto rev = fold(refs, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& m, const std::tuple<Text, Array<Text>>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        return fold(rs, m, [&](const Map<Text, Array<Text>>& m2, const Text& r) { return insert(m2, r, prelude::push(or_(prelude::get(m2, r), Array<Text>{}), k)); });
    });
    auto&& _post = run_to_end(fold_job(keys_, std::tuple{Map<Text, bool>{}, Array<Text>{}}, ({
        auto adj_1 = adj;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Text>>>(std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto adj_1_2 = adj_1;
            entered(once_job([=]() {
            return ({
                auto [seen, out] = p0;
                auto k = p1;
                (prism_rtl::more(prism_rtl::rc(PostVisit(adj_1_2, seen, out, k))));
            });
        }));
        });
    }));
    })));
    auto&& post = std::get<1>(_post);
    auto [ignore2, comps] = run_to_end(fold_job(crate::check_types::reverse2(post), std::tuple{Map<Text, bool>{}, Array<Array<Text>>{}}, ({
        auto rev_1 = rev;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Array<Text>>>>(std::tuple<std::tuple<Map<Text, bool>, Array<Array<Text>>>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Map<Text, bool>, Array<Array<Text>>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto rev_1_2 = rev_1;
            entered(once_job([=]() {
            return ({
                auto [seen, acc] = p0;
                auto k = p1;
                (crate::check_env::has_key(seen, k)
                ? prism_rtl::finished(std::tuple{seen, acc})
                : call_then(start_collect(rev_1_2, seen, Array<Text>{}, k), [=](std::tuple<Map<Text, bool>, Array<Text>> collect_68520) {
                return ({
                    auto [seen2, comp] = collect_68520;
                    (prism_rtl::finished(std::tuple{seen2, prelude::push(acc, comp)}));
                });
            }));
            });
        }));
        });
    }));
    })));
    return filter(comps, [&](const Array<Text>& c) { return (len(c) > Nat(1u)) || fold(c, false, [&](const bool& self_, const Text& k) { return self_ || crate::check_types::has_text(or_(prelude::get(adj, k), Array<Text>{}), k); }); });
}


prism_rtl::Turn<Array<Array<Text>>> Sccs::cycle() const {
    const auto& keys_ = this->keys_;
    const auto& refs = this->refs;
    auto adj = fold(refs, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& m, const std::tuple<Text, Array<Text>>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        return insert(m, k, rs);
    });
    auto rev = fold(refs, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& m, const std::tuple<Text, Array<Text>>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        return fold(rs, m, [&](const Map<Text, Array<Text>>& m2, const Text& r) { return insert(m2, r, prelude::push(or_(prelude::get(m2, r), Array<Text>{}), k)); });
    });
    auto keys__1 = keys_;
    return call_value(fold_job(keys__1, std::tuple{Map<Text, bool>{}, Array<Text>{}}, ({
        auto adj_2 = adj;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Text>>>(std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto adj_2_3 = adj_2;
            entered(once_job([=]() {
            return ({
                auto [seen, out] = p0;
                auto k = p1;
                (prism_rtl::more(prism_rtl::rc(PostVisit(adj_2_3, seen, out, k))));
            });
        }));
        });
    }));
    })), [=](std::tuple<Map<Text, bool>, Array<Text>> fold_68273) {
        return ({
            auto&& _post = fold_68273;
            auto&& post = std::get<1>(_post);
            call_value(fold_job(crate::check_types::reverse2(post), std::tuple{Map<Text, bool>{}, Array<Array<Text>>{}}, ({
            auto rev_2 = rev;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Array<Text>>>>(std::tuple<std::tuple<Map<Text, bool>, Array<Array<Text>>>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Map<Text, bool>, Array<Array<Text>>>, Text> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto rev_2_3 = rev_2;
                entered(once_job([=]() {
                return ({
                    auto [seen, acc] = p0;
                    auto k = p1;
                    (crate::check_env::has_key(seen, k)
                    ? prism_rtl::finished(std::tuple{seen, acc})
                    : call_then(start_collect(rev_2_3, seen, Array<Text>{}, k), [=](std::tuple<Map<Text, bool>, Array<Text>> collect_68520) {
                    return ({
                        auto [seen2, comp] = collect_68520;
                        (prism_rtl::finished(std::tuple{seen2, prelude::push(acc, comp)}));
                    });
                }));
                });
            }));
            });
        }));
        })), [=](std::tuple<Map<Text, bool>, Array<Array<Text>>> fold_68375) {
            return ({
                auto [ignore2, comps] = fold_68375;
                (prism_rtl::finished(filter(comps, [&](const Array<Text>& c) { return (len(c) > Nat(1u)) || fold(c, false, [&](const bool& self_, const Text& k) { return self_ || crate::check_types::has_text(or_(prelude::get(adj, k), Array<Text>{}), k); }); })));
            });
        });
        });
    });
}


/// `Start Sccs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Array<Text>>> start_sccs(Array<Text> keys_, Array<std::tuple<Text, Array<Text>>> refs) {
    return prism_rtl::make_rc<Sccs>(keys_, refs);
}


/// PostVisit: unbounded fn (Text ==> [Text]), (Text ==> Bool), [Text], Text -> (((Text ==> Bool), [Text]))
std::tuple<Map<Text, bool>, Array<Text>> post_visit(const Map<Text, Array<Text>>& adj, const Map<Text, bool>& seen, const Array<Text>& out, const Text& k) {
    return crate::check_env::has_key(seen, k)
        ? std::tuple{seen, out}
        : ({
        auto [seen2, out2] = run_to_end(fold_job(or_(prelude::get(adj, k), Array<Text>{}), std::tuple{insert(seen, k, true), out}, ({
            auto adj_1 = adj;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Text>>>(std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto adj_1_2 = adj_1;
                entered(once_job([=]() {
                return ({
                    auto [s, o] = p0;
                    auto n = p1;
                    (prism_rtl::more(prism_rtl::rc(PostVisit(adj_1_2, s, o, n))));
                });
            }));
            });
        }));
        })));
        std::tuple{seen2, prelude::push(out2, k)};
    });
}


prism_rtl::Turn<std::tuple<Map<Text, bool>, Array<Text>>> PostVisit::cycle() const {
    const auto& adj = this->adj;
    const auto& seen = this->seen;
    const auto& out = this->out;
    const auto& k = this->k;
    return crate::check_env::has_key(seen, k)
        ? prism_rtl::finished(std::tuple{seen, out})
        : ({
        auto adj_1 = adj;
        auto k_2 = k;
        auto out_3 = out;
        auto seen_4 = seen;
        call_value(fold_job(or_(prelude::get(adj_1, k_2), Array<Text>{}), std::tuple{insert(seen_4, k_2, true), out_3}, ({
        auto adj_1_5 = adj_1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Text>>>(std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto adj_1_5_5 = adj_1_5;
            entered(once_job([=]() {
            return ({
                auto [s, o] = p0;
                auto n = p1;
                (prism_rtl::more(prism_rtl::rc(PostVisit(adj_1_5_5, s, o, n))));
            });
        }));
        });
    }));
    })), [=](std::tuple<Map<Text, bool>, Array<Text>> fold_68904) {
        return ({
            auto [seen2, out2] = fold_68904;
            (prism_rtl::finished(std::tuple{seen2, prelude::push(out2, k_2)}));
        });
    });
    });
}


/// `Start PostVisit, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Text>>> start_post_visit(Map<Text, Array<Text>> adj, Map<Text, bool> seen, Array<Text> out, Text k) {
    return prism_rtl::make_rc<PostVisit>(adj, seen, out, k);
}


/// Collect: unbounded fn (Text ==> [Text]), (Text ==> Bool), [Text], Text -> (((Text ==> Bool), [Text]))
std::tuple<Map<Text, bool>, Array<Text>> collect(const Map<Text, Array<Text>>& rev, const Map<Text, bool>& seen, const Array<Text>& comp, const Text& k) {
    return crate::check_env::has_key(seen, k)
        ? std::tuple{seen, comp}
        : run_to_end(fold_job(or_(prelude::get(rev, k), Array<Text>{}), std::tuple{insert(seen, k, true), prelude::push(comp, k)}, ({
        auto rev_1 = rev;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Text>>>(std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto rev_1_2 = rev_1;
            entered(once_job([=]() {
            return ({
                auto [s, c] = p0;
                auto n = p1;
                (prism_rtl::more(prism_rtl::rc(Collect(rev_1_2, s, c, n))));
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Map<Text, bool>, Array<Text>>> Collect::cycle() const {
    const auto& rev = this->rev;
    const auto& seen = this->seen;
    const auto& comp = this->comp;
    const auto& k = this->k;
    return crate::check_env::has_key(seen, k)
        ? prism_rtl::finished(std::tuple{seen, comp})
        : fold_job(or_(prelude::get(rev, k), Array<Text>{}), std::tuple{insert(seen, k, true), prelude::push(comp, k)}, ({
        auto rev_1 = rev;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Text>>>(std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto rev_1_2 = rev_1;
            entered(once_job([=]() {
            return ({
                auto [s, c] = p0;
                auto n = p1;
                (prism_rtl::more(prism_rtl::rc(Collect(rev_1_2, s, c, n))));
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start Collect, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Text>>> start_collect(Map<Text, Array<Text>> rev, Map<Text, bool> seen, Array<Text> comp, Text k) {
    return prism_rtl::make_rc<Collect>(rev, seen, comp, k);
}


/// ShrinkComponent: unbounded fn Shrink, St, [Text] -> St
crate::check_types::St shrink_component(const Shrink& sk, const crate::check_types::St& st, const Array<Text>& comp) {
    return fold(comp, true, [&](const bool& ok, const Text& k) { return ok && is_unbounded_key(sk.g, sig_key_of(sk, or_(prelude::get(sk.local_of, k), k))); })
        ? st
        : ({
        auto graphs = run_to_end(fold_job(sk.fns, Array<Sc>{}, ({
            auto comp_1 = comp;
            auto sk_2 = sk;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Sc>>(std::tuple<Array<Sc>, crate::check_env::Def>)>>(prism_rtl::rc([=](std::tuple<Array<Sc>, crate::check_env::Def> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto comp_1_3 = comp_1;
                auto sk_2_3 = sk_2;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto d = p1;
                    (crate::check_types::has_text(comp_1_3, d.qk)
                    ? call_then(start_call_graphs(sk_2_3, d, comp_1_3), [=](Array<Sc> call_graphs_69819) { return prism_rtl::finished(append(acc, call_graphs_69819)); })
                    : prism_rtl::finished(acc));
                });
            }));
            });
        })));
        })));
        auto closure_ = closure(graphs);
        auto bad = filter(closure_, [&](const Sc& sc) {
            return ((sc.caller == sc.callee) && (compose(sc, sc)->edges == sc->edges)) && (!fold(sc->edges, false, [&](const bool& seen, const std::tuple<Nat, Nat, bool>& _p1) {
                auto&& a = std::get<0>(_p1);
                auto&& b = std::get<1>(_p1);
                auto&& s = std::get<2>(_p1);
                return seen || ((a == b) && s);
            }));
        });
        ({
        __label__ _done;
        prism_rtl::Slot<crate::check_types::St> _v;
        auto&& _m = index(bad, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& sc = prism_rtl::some_of(_m);
            _v.set(({
                auto s2 = ({
                    crate::check_types::St this_ = st;
                    this_.file = sc->file;
                    this_;
                });
                auto what = sc.arg == Text::lit("")
                    ? Text::lit("")
                    : prism_rtl::cat(" on `", sc.arg, "`");
                auto st3 = crate::check_types::err_fix(s2, Text::lit("may-not-end"), sc.span, prism_rtl::cat("`", shown_key(sc.caller), "` calls ", sc.caller == sc.callee
                    ? Text::lit("itself")
                    : prism_rtl::cat("`", shown_key(sc.callee), "`"), what, ", not smaller than what it was given"), Text::lit("make an argument shrink (a part taken apart by `match`, or the `? m` of `match n -? 1`), or mark the cycle's functions `unbounded fn`"));
                ({
                crate::check_types::St this_ = st3;
                this_.file = st->file;
                this_;
            });
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(st);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    });
}


prism_rtl::Turn<crate::check_types::St> ShrinkComponent::cycle() const {
    const auto& sk = this->sk;
    const auto& st = this->st;
    const auto& comp = this->comp;
    return fold(comp, true, [&](const bool& ok, const Text& k) { return ok && is_unbounded_key(sk.g, sig_key_of(sk, or_(prelude::get(sk.local_of, k), k))); })
        ? prism_rtl::finished(st)
        : ({
        auto comp_1 = comp;
        auto sk_2 = sk;
        auto st_3 = st;
        call_value(fold_job(sk_2.fns, Array<Sc>{}, ({
        auto comp_1_4 = comp_1;
        auto sk_2_4 = sk_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Sc>>(std::tuple<Array<Sc>, crate::check_env::Def>)>>(prism_rtl::rc([=](std::tuple<Array<Sc>, crate::check_env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto comp_1_4_4 = comp_1_4;
            auto sk_2_4_4 = sk_2_4;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto d = p1;
                (crate::check_types::has_text(comp_1_4_4, d.qk)
                ? call_then(start_call_graphs(sk_2_4_4, d, comp_1_4_4), [=](Array<Sc> call_graphs_69819) { return prism_rtl::finished(append(acc, call_graphs_69819)); })
                : prism_rtl::finished(acc));
            });
        }));
        });
    })));
    })), [=](Array<Sc> fold_69754) {
        return ({
            auto graphs = fold_69754;
            call_then(start_closure(graphs), [=](Array<Sc> closure_69875) {
            return ({
                auto closure_ = closure_69875;
                auto bad = filter(closure_, [&](const Sc& sc) {
                    return ((sc.caller == sc.callee) && (compose(sc, sc)->edges == sc->edges)) && (!fold(sc->edges, false, [&](const bool& seen, const std::tuple<Nat, Nat, bool>& _p1) {
                        auto&& a = std::get<0>(_p1);
                        auto&& b = std::get<1>(_p1);
                        auto&& s = std::get<2>(_p1);
                        return seen || ((a == b) && s);
                    }));
                });
                ({
                auto&& _m = index(bad, Nat(0u));
                prism_rtl::is_some(_m) ? ({
                auto&& sc = prism_rtl::some_of(_m);
                ({
                auto s2 = ({
                    crate::check_types::St this_ = st_3;
                    this_.file = sc->file;
                    this_;
                });
                auto what = sc.arg == Text::lit("")
                    ? Text::lit("")
                    : prism_rtl::cat(" on `", sc.arg, "`");
                auto st3 = crate::check_types::err_fix(s2, Text::lit("may-not-end"), sc.span, prism_rtl::cat("`", shown_key(sc.caller), "` calls ", sc.caller == sc.callee
                    ? Text::lit("itself")
                    : prism_rtl::cat("`", shown_key(sc.callee), "`"), what, ", not smaller than what it was given"), Text::lit("make an argument shrink (a part taken apart by `match`, or the `? m` of `match n -? 1`), or mark the cycle's functions `unbounded fn`"));
                (prism_rtl::finished(({
                crate::check_types::St this_ = st3;
                this_.file = st_3->file;
                this_;
            })));
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(st_3)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        });
        });
    });
    });
}


/// `Start ShrinkComponent, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check_types::St> start_shrink_component(Shrink sk, crate::check_types::St st, Array<Text> comp) {
    return prism_rtl::make_rc<ShrinkComponent>(sk, st, comp);
}


/// CallGraphs: unbounded fn Shrink, Def, [Text] -> [Sc]
Array<Sc> call_graphs(const Shrink& sk, const crate::check_env::Def& d, const Array<Text>& comp) {
    return run_to_end(fold_job(def_clauses(d), Array<Sc>{}, ({
        auto sk_1 = sk;
        auto d_2 = d;
        auto comp_3 = comp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Sc>>(std::tuple<Array<Sc>, crate::ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<Sc>, crate::ast::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_1_4 = sk_1;
            auto d_2_4 = d_2;
            auto comp_3_4 = comp_3;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                call_then(start_clause_graphs(sk_1_4, d_2_4, c, comp_3_4), [=](Array<Sc> clause_graphs_70937) { return prism_rtl::finished(append(acc, clause_graphs_70937)); });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Sc>> CallGraphs::cycle() const {
    const auto& sk = this->sk;
    const auto& d = this->d;
    const auto& comp = this->comp;
    return fold_job(def_clauses(d), Array<Sc>{}, ({
        auto sk_1 = sk;
        auto d_2 = d;
        auto comp_3 = comp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Sc>>(std::tuple<Array<Sc>, crate::ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<Sc>, crate::ast::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_1_4 = sk_1;
            auto d_2_4 = d_2;
            auto comp_3_4 = comp_3;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                call_then(start_clause_graphs(sk_1_4, d_2_4, c, comp_3_4), [=](Array<Sc> clause_graphs_70937) { return prism_rtl::finished(append(acc, clause_graphs_70937)); });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start CallGraphs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Sc>> start_call_graphs(Shrink sk, crate::check_env::Def d, Array<Text> comp) {
    return prism_rtl::make_rc<CallGraphs>(sk, d, comp);
}


/// ClauseGraphs: unbounded fn Shrink, Def, FnClause, [Text] -> [Sc]
Array<Sc> clause_graphs(const Shrink& sk, const crate::check_env::Def& d, const crate::ast::FnClause& c, const Array<Text>& comp) {
    auto base = clause_base(sk, d, c);
    auto rels = summary_seeds(sk, d, body_spots(c.body, base), base);
    return run_to_end(fold_job(body_sites(c.body, rels), Array<Sc>{}, ({
        auto sk_1 = sk;
        auto d_2 = d;
        auto comp_3 = comp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Sc>>(std::tuple<Array<Sc>, Site>)>>(prism_rtl::rc([=](std::tuple<Array<Sc>, Site> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_1_4 = sk_1;
            auto d_2_4 = d_2;
            auto comp_3_4 = comp_3;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto site = p1;
                ({
                auto&& _m = local_target(sk_1_4, d_2_4, site);
                prism_rtl::is_some(_m) ? ({
                auto&& t = prism_rtl::some_of(_m);
                crate::check_types::has_text(comp_3_4, t)
                ? call_then(start_site_graph(sk_1_4, d_2_4, site, t), [=](Sc site_graph_71295) { return prism_rtl::finished(prelude::push(acc, site_graph_71295)); })
                : prism_rtl::finished(acc);
            })
                : prism_rtl::is_none(_m) ? is_local(site.rels, site.callee) || crate::check_env::has_key(sk_1_4.local_of, d_2_4.qk)
                ? prism_rtl::finished(acc)
                : ({
                auto&& _m = resolve_callee(sk_1_4.g, d_2_4.home, site.callee);
                prism_rtl::is_some(_m) ? ({
                auto&& k = prism_rtl::some_of(_m);
                call_then(start_dispatch_targets(sk_1_4, d_2_4, site, k), [=](Array<Text> dispatch_targets_71517) {
                return fold_job(dispatch_targets_71517, acc, ({
                    auto comp_3_4_4 = comp_3_4;
                    auto sk_1_4_4 = sk_1_4;
                    auto d_2_4_4 = d_2_4;
                    auto site_4 = site;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Sc>>(std::tuple<Array<Sc>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Sc>, Text> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto comp_3_4_4_5 = comp_3_4_4;
                        auto sk_1_4_4_5 = sk_1_4_4;
                        auto d_2_4_4_5 = d_2_4_4;
                        auto site_4_5 = site_4;
                        entered(once_job([=]() {
                        return ({
                            auto acc2 = p0;
                            auto t = p1;
                            (crate::check_types::has_text(comp_3_4_4_5, t)
                            ? call_then(start_site_graph(sk_1_4_4_5, d_2_4_4_5, site_4_5, t), [=](Sc site_graph_71598) { return prism_rtl::finished(prelude::push(acc2, site_graph_71598)); })
                            : prism_rtl::finished(acc2));
                        });
                    }));
                    });
                })));
                }))->cycle();
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(acc)
                : throw prism_rtl::Panic("no arm matched");
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Sc>> ClauseGraphs::cycle() const {
    const auto& sk = this->sk;
    const auto& d = this->d;
    const auto& c = this->c;
    const auto& comp = this->comp;
    auto c_1 = c;
    auto comp_2 = comp;
    auto d_3 = d;
    auto sk_4 = sk;
    return call_then(start_clause_base(sk_4, d_3, c_1), [=](Map<Text, Rel> clause_base_71079) {
        return ({
            auto base = clause_base_71079;
            call_then(start_body_spots(c_1.body, base), [=](Array<Spot> body_spots_71135) {
            return call_then(start_summary_seeds(sk_4, d_3, body_spots_71135, base), [=](Map<Text, Rel> summary_seeds_71114) {
                return ({
                    auto rels = summary_seeds_71114;
                    call_then(start_body_sites(c_1.body, rels), [=](Array<Site> body_sites_71175) {
                    return fold_job(body_sites_71175, Array<Sc>{}, ({
                        auto sk_4_5 = sk_4;
                        auto d_3_5 = d_3;
                        auto comp_2_5 = comp_2;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Sc>>(std::tuple<Array<Sc>, Site>)>>(prism_rtl::rc([=](std::tuple<Array<Sc>, Site> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto sk_4_5_5 = sk_4_5;
                            auto d_3_5_5 = d_3_5;
                            auto comp_2_5_5 = comp_2_5;
                            entered(once_job([=]() {
                            return ({
                                auto acc = p0;
                                auto site = p1;
                                ({
                                auto&& _m = local_target(sk_4_5_5, d_3_5_5, site);
                                prism_rtl::is_some(_m) ? ({
                                auto&& t = prism_rtl::some_of(_m);
                                crate::check_types::has_text(comp_2_5_5, t)
                                ? call_then(start_site_graph(sk_4_5_5, d_3_5_5, site, t), [=](Sc site_graph_71295) { return prism_rtl::finished(prelude::push(acc, site_graph_71295)); })
                                : prism_rtl::finished(acc);
                            })
                                : prism_rtl::is_none(_m) ? is_local(site.rels, site.callee) || crate::check_env::has_key(sk_4_5_5.local_of, d_3_5_5.qk)
                                ? prism_rtl::finished(acc)
                                : ({
                                auto&& _m = resolve_callee(sk_4_5_5.g, d_3_5_5.home, site.callee);
                                prism_rtl::is_some(_m) ? ({
                                auto&& k = prism_rtl::some_of(_m);
                                call_then(start_dispatch_targets(sk_4_5_5, d_3_5_5, site, k), [=](Array<Text> dispatch_targets_71517) {
                                return fold_job(dispatch_targets_71517, acc, ({
                                    auto comp_2_5_5_5 = comp_2_5_5;
                                    auto sk_4_5_5_5 = sk_4_5_5;
                                    auto d_3_5_5_5 = d_3_5_5;
                                    auto site_5 = site;
                                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Sc>>(std::tuple<Array<Sc>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Sc>, Text> _p0) {
                                    auto&& p0 = std::get<0>(_p0);
                                    auto&& p1 = std::get<1>(_p0);
                                    return ({
                                        auto comp_2_5_5_5_6 = comp_2_5_5_5;
                                        auto sk_4_5_5_5_6 = sk_4_5_5_5;
                                        auto d_3_5_5_5_6 = d_3_5_5_5;
                                        auto site_5_6 = site_5;
                                        entered(once_job([=]() {
                                        return ({
                                            auto acc2 = p0;
                                            auto t = p1;
                                            (crate::check_types::has_text(comp_2_5_5_5_6, t)
                                            ? call_then(start_site_graph(sk_4_5_5_5_6, d_3_5_5_5_6, site_5_6, t), [=](Sc site_graph_71598) { return prism_rtl::finished(prelude::push(acc2, site_graph_71598)); })
                                            : prism_rtl::finished(acc2));
                                        });
                                    }));
                                    });
                                })));
                                }))->cycle();
                            });
                            })
                                : prism_rtl::is_none(_m) ? prism_rtl::finished(acc)
                                : throw prism_rtl::Panic("no arm matched");
                            })
                                : throw prism_rtl::Panic("no arm matched");
                            });
                            });
                        }));
                        });
                    })));
                    }))->cycle();
                });
                });
            });
        });
        });
    });
}


/// `Start ClauseGraphs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Sc>> start_clause_graphs(Shrink sk, crate::check_env::Def d, crate::ast::FnClause c, Array<Text> comp) {
    return prism_rtl::make_rc<ClauseGraphs>(sk, d, c, comp);
}


/// SiteGraph: unbounded fn Shrink, Def, Site, Text -> Sc
Sc site_graph(const Shrink& sk, const crate::check_env::Def& d, const Site& site, const Text& k) {
    auto edges_ = run_to_end(fold_job(arg_slots(sk, site->args, k), Array<std::tuple<Nat, Nat, bool>>{}, ({
        auto site_1 = site;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Nat, Nat, bool>>>(std::tuple<Array<std::tuple<Nat, Nat, bool>>, std::tuple<Nat, crate::ast::Arg>>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Nat, Nat, bool>>, std::tuple<Nat, crate::ast::Arg>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto site_1_2 = site_1;
            entered(once_job([=]() {
            return ({
                auto es = p0;
                auto [j, a] = p1;
                call_then(start_rel_of(site_1_2.rels, a->value), [=](std::optional<Rel> rel_of_71936) {
                return ({
                    prism_rtl::is_some(rel_of_71936) ? ({
                    auto&& r = prism_rtl::some_of(rel_of_71936);
                    prism_rtl::finished(prelude::push(es, std::tuple{r.param, j, r.strict}));
                })
                    : prism_rtl::is_none(rel_of_71936) ? prism_rtl::finished(es)
                    : throw prism_rtl::Panic("no arm matched");
                });
            });
            });
        }));
        });
    }));
    })));
    auto arg_text = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(site->args, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& a = prism_rtl::some_of(_m);
            _v.set(expr_name(a->value));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return Sc{.caller = d.qk, .callee = k, .edges = edges_, .span = site.span, .file = d->file, .arg = arg_text};
}


prism_rtl::Turn<Sc> SiteGraph::cycle() const {
    const auto& sk = this->sk;
    const auto& d = this->d;
    const auto& site = this->site;
    const auto& k = this->k;
    auto d_1 = d;
    auto k_2 = k;
    auto site_3 = site;
    auto sk_4 = sk;
    return call_then(start_arg_slots(sk_4, site_3->args, k_2), [=](Array<std::tuple<Nat, crate::ast::Arg>> arg_slots_71880) {
        return call_value(fold_job(arg_slots_71880, Array<std::tuple<Nat, Nat, bool>>{}, ({
            auto site_3_5 = site_3;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Nat, Nat, bool>>>(std::tuple<Array<std::tuple<Nat, Nat, bool>>, std::tuple<Nat, crate::ast::Arg>>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Nat, Nat, bool>>, std::tuple<Nat, crate::ast::Arg>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto site_3_5_5 = site_3_5;
                entered(once_job([=]() {
                return ({
                    auto es = p0;
                    auto [j, a] = p1;
                    call_then(start_rel_of(site_3_5_5.rels, a->value), [=](std::optional<Rel> rel_of_71936) {
                    return ({
                        prism_rtl::is_some(rel_of_71936) ? ({
                        auto&& r = prism_rtl::some_of(rel_of_71936);
                        prism_rtl::finished(prelude::push(es, std::tuple{r.param, j, r.strict}));
                    })
                        : prism_rtl::is_none(rel_of_71936) ? prism_rtl::finished(es)
                        : throw prism_rtl::Panic("no arm matched");
                    });
                });
                });
            }));
            });
        }));
        })), [=](Array<std::tuple<Nat, Nat, bool>> fold_71874) {
            return ({
                auto edges_ = fold_71874;
                auto arg_text = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = index(site_3->args, Nat(0u));
                    if (prism_rtl::is_some(_m)) {
                        auto&& a = prism_rtl::some_of(_m);
                        _v.set(expr_name(a->value));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Text::lit(""));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                (prism_rtl::finished(Sc{.caller = d_1.qk, .callee = k_2, .edges = edges_, .span = site_3.span, .file = d_1->file, .arg = arg_text}));
            });
        });
    });
}


/// `Start SiteGraph, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Sc> start_site_graph(Shrink sk, crate::check_env::Def d, Site site, Text k) {
    return prism_rtl::make_rc<SiteGraph>(sk, d, site, k);
}


/// ArgSlots: unbounded fn Shrink, [Arg], Text -> [((Nat, Arg))]
Array<std::tuple<Nat, crate::ast::Arg>> arg_slots(const Shrink& sk, const Array<crate::ast::Arg>& args, const Text& k) {
    auto&& _out = run_to_end(fold_job(args, std::tuple{Nat(0u), Array<std::tuple<Nat, crate::ast::Arg>>{}}, ({
        auto sk_1 = sk;
        auto k_2 = k;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Nat, Array<std::tuple<Nat, crate::ast::Arg>>>>(std::tuple<std::tuple<Nat, Array<std::tuple<Nat, crate::ast::Arg>>>, crate::ast::Arg>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Nat, Array<std::tuple<Nat, crate::ast::Arg>>>, crate::ast::Arg> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_1_3 = sk_1;
            auto k_2_3 = k_2;
            entered(once_job([=]() {
            return ({
                auto [pos, acc] = p0;
                auto a = p1;
                ({
                auto&& _m = a.name;
                prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{pos + Nat(1u), prelude::push(acc, std::tuple{pos, a})})
                : prism_rtl::is_some(_m) ? ({
                auto&& id = prism_rtl::some_of(_m);
                ({
                auto id_3 = id;
                call_then(start_param_named(sk_1_3, k_2_3, id_3.name), [=](std::optional<Nat> param_named_72750) {
                return ({
                    prism_rtl::is_some(param_named_72750) ? ({
                    auto&& j = prism_rtl::some_of(param_named_72750);
                    prism_rtl::finished(std::tuple{pos, prelude::push(acc, std::tuple{j, a})});
                })
                    : prism_rtl::is_none(param_named_72750) ? prism_rtl::finished(std::tuple{pos, acc})
                    : throw prism_rtl::Panic("no arm matched");
                });
            });
            });
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })));
    auto&& out = std::get<1>(_out);
    return out;
}


prism_rtl::Turn<Array<std::tuple<Nat, crate::ast::Arg>>> ArgSlots::cycle() const {
    const auto& sk = this->sk;
    const auto& args = this->args;
    const auto& k = this->k;
    auto args_1 = args;
    auto k_2 = k;
    auto sk_3 = sk;
    return call_value(fold_job(args_1, std::tuple{Nat(0u), Array<std::tuple<Nat, crate::ast::Arg>>{}}, ({
        auto sk_3_4 = sk_3;
        auto k_2_4 = k_2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Nat, Array<std::tuple<Nat, crate::ast::Arg>>>>(std::tuple<std::tuple<Nat, Array<std::tuple<Nat, crate::ast::Arg>>>, crate::ast::Arg>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Nat, Array<std::tuple<Nat, crate::ast::Arg>>>, crate::ast::Arg> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_3_4_4 = sk_3_4;
            auto k_2_4_4 = k_2_4;
            entered(once_job([=]() {
            return ({
                auto [pos, acc] = p0;
                auto a = p1;
                ({
                auto&& _m = a.name;
                prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{pos + Nat(1u), prelude::push(acc, std::tuple{pos, a})})
                : prism_rtl::is_some(_m) ? ({
                auto&& id = prism_rtl::some_of(_m);
                ({
                auto id_4 = id;
                call_then(start_param_named(sk_3_4_4, k_2_4_4, id_4.name), [=](std::optional<Nat> param_named_72750) {
                return ({
                    prism_rtl::is_some(param_named_72750) ? ({
                    auto&& j = prism_rtl::some_of(param_named_72750);
                    prism_rtl::finished(std::tuple{pos, prelude::push(acc, std::tuple{j, a})});
                })
                    : prism_rtl::is_none(param_named_72750) ? prism_rtl::finished(std::tuple{pos, acc})
                    : throw prism_rtl::Panic("no arm matched");
                });
            });
            });
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Nat, Array<std::tuple<Nat, crate::ast::Arg>>> fold_72623) {
        return ({
            auto&& _out = fold_72623;
            auto&& out = std::get<1>(_out);
            (prism_rtl::finished(out));
        });
    });
}


/// `Start ArgSlots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Nat, crate::ast::Arg>>> start_arg_slots(Shrink sk, Array<crate::ast::Arg> args, Text k) {
    return prism_rtl::make_rc<ArgSlots>(sk, args, k);
}


/// ?ParamNamed: unbounded fn Shrink, Text, Text -> ?Nat
std::optional<Nat> param_named(const Shrink& sk, const Text& k, const Text& name) {
    auto clauses = def_clauses(or_(prelude::get(sk.by_key, k), crate::check_env::dummy_def()));
    return name == Text::lit("#body")
        ? ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Nat>> _v;
        auto&& _m = index(clauses, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& c = prism_rtl::some_of(_m);
            _v.set(len(c.params) > Nat(0u)
                ? std::optional(crate::lexer::dec(len(c.params)))
                : std::optional<Nat>{});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::optional<Nat>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    })
        : param_named_in(clauses, name);
}


prism_rtl::Turn<std::optional<Nat>> ParamNamed::cycle() const {
    const auto& sk = this->sk;
    const auto& k = this->k;
    const auto& name = this->name;
    auto clauses = def_clauses(or_(prelude::get(sk.by_key, k), crate::check_env::dummy_def()));
    return name == Text::lit("#body")
        ? ({
        auto&& _m = index(clauses, Nat(0u));
        prism_rtl::is_some(_m) ? ({
        auto&& c = prism_rtl::some_of(_m);
        len(c.params) > Nat(0u)
        ? prism_rtl::finished(std::optional(crate::lexer::dec(len(c.params))))
        : prism_rtl::finished(std::optional<Nat>{});
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<Nat>{})
        : throw prism_rtl::Panic("no arm matched");
    })
        : prism_rtl::finished(param_named_in(clauses, name));
}


/// `Start ParamNamed, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Nat>> start_param_named(Shrink sk, Text k, Text name) {
    return prism_rtl::make_rc<ParamNamed>(sk, k, name);
}


/// ?ParamNamedIn: unbounded fn [FnClause], Text -> ?Nat
std::optional<Nat> param_named_in(const Array<crate::ast::FnClause>& clauses, const Text& name) {
    auto found = run_to_end(fold_job(clauses, Array<Nat>{}, ({
        auto name_1 = name;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, crate::ast::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto name_1_2 = name_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                fold_job(crate::check_errors::range0(len(c.params)), acc, ({
                auto c_2 = c;
                auto name_1_2_3 = name_1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, Nat>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto c_2_3 = c_2;
                    auto name_1_2_3_3 = name_1_2_3;
                    entered(once_job([=]() {
                    return ({
                        auto a2 = p0;
                        auto i = p1;
                        ({
                        auto&& _m = index(c_2_3.params, i);
                        prism_rtl::is_some(_m) ? ({
                        auto&& p_ = prism_rtl::some_of(_m);
                        (param_name_of(p_) == name_1_2_3_3) && (!crate::check_types::has_nat(a2, i))
                        ? prism_rtl::finished(prelude::push(a2, i))
                        : prism_rtl::finished(a2);
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(a2)
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                }));
                });
            })));
            }))->cycle();
            });
        }));
        });
    })));
    })));
    return len(found) == Nat(1u) ? index(found, Nat(0u)) : std::optional<Nat>{};
}


/// ParamNameOf: unbounded fn Pattern -> Text
Text param_name_of(const crate::ast::Pattern_& p_) {
    auto&& _m = p_.kind;
    if (prism_rtl::is<crate::ast::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<crate::ast::PatternKind::PName>(_m).a0;
        auto text = crate::check_env::sname_key(n);
        return crate::lexer::drop_prefix(text, crate::check_types::marks_of(text));
    }
    if (prism_rtl::is<crate::ast::PatternKind::PGroup>(_m)) {
        auto&& q = prism_rtl::as<crate::ast::PatternKind::PGroup>(_m).a0;
        return param_name_of(q);
    }
    {
        return Text::lit("");
    }
}


/// ExprName: fn Expr -> Text
Text expr_name(const crate::ast::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::ast::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::ast::ExprKind::EName>(_m).a0;
        return crate::check_env::sname_key(n);
    }
    if (prism_rtl::is<crate::ast::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::ast::ExprKind::EGroup>(_m).a0;
        return expr_name(x);
    }
    {
        return Text::lit("");
    }
}


/// ParamRelsOn: unbounded fn (Text ==> Rel), [Pattern] -> (Text ==> Rel)
Map<Text, Rel> param_rels_on(const Map<Text, Rel>& base, const Array<crate::ast::Pattern_>& ps) {
    return run_to_end(fold_job(crate::check_errors::range0(len(ps)), hide(base, patterns_names(ps)), ({
        auto ps_1 = ps;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Rel>>(std::tuple<Map<Text, Rel>, Nat>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Rel>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto ps_1_2 = ps_1;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                auto i = p1;
                ({
                auto&& _m = index(ps_1_2, i);
                prism_rtl::is_some(_m) ? ({
                auto&& p_ = prism_rtl::some_of(_m);
                ({
                auto&& _m = p_.kind;
                prism_rtl::is<crate::ast::PatternKind::PName>(_m) ? ({
                auto&& n = prism_rtl::as<crate::ast::PatternKind::PName>(_m).a0;
                prism_rtl::finished(insert(m, crate::check_env::sname_key(n), Rel{.param = i, .strict = false}));
            })
                : call_then(crate::check_env::start_pattern_names(p_), [=](Array<Text> pattern_names_74523) { return prism_rtl::finished(fold(pattern_names_74523, m, [&](const Map<Text, Rel>& m2, const Text& n) { return insert(m2, n, Rel{.param = i, .strict = true}); })); });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(m)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<Map<Text, Rel>> ParamRelsOn::cycle() const {
    const auto& base = this->base;
    const auto& ps = this->ps;
    auto base_1 = base;
    auto ps_2 = ps;
    return call_then(start_patterns_names(ps_2), [=](Array<Text> patterns_names_74366) {
        return fold_job(crate::check_errors::range0(len(ps_2)), hide(base_1, patterns_names_74366), ({
            auto ps_2_3 = ps_2;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Rel>>(std::tuple<Map<Text, Rel>, Nat>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Rel>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto ps_2_3_3 = ps_2_3;
                entered(once_job([=]() {
                return ({
                    auto m = p0;
                    auto i = p1;
                    ({
                    auto&& _m = index(ps_2_3_3, i);
                    prism_rtl::is_some(_m) ? ({
                    auto&& p_ = prism_rtl::some_of(_m);
                    ({
                    auto&& _m = p_.kind;
                    prism_rtl::is<crate::ast::PatternKind::PName>(_m) ? ({
                    auto&& n = prism_rtl::as<crate::ast::PatternKind::PName>(_m).a0;
                    prism_rtl::finished(insert(m, crate::check_env::sname_key(n), Rel{.param = i, .strict = false}));
                })
                    : call_then(crate::check_env::start_pattern_names(p_), [=](Array<Text> pattern_names_74523) { return prism_rtl::finished(fold(pattern_names_74523, m, [&](const Map<Text, Rel>& m2, const Text& n) { return insert(m2, n, Rel{.param = i, .strict = true}); })); });
                });
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(m)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        }));
        }))->cycle();
    });
}


/// `Start ParamRelsOn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Rel>> start_param_rels_on(Map<Text, Rel> base, Array<crate::ast::Pattern_> ps) {
    return prism_rtl::make_rc<ParamRelsOn>(base, ps);
}


/// Hide: fn (Text ==> Rel), [Text] -> (Text ==> Rel)
Map<Text, Rel> hide(const Map<Text, Rel>& m, const Array<Text>& names) {
    return fold(names, m, [&](const Map<Text, Rel>& m2, const Text& n) { return insert(prelude::remove(prelude::remove(prelude::remove(prelude::remove(m2, n), prism_rtl::cat("ne:", n)), prism_rtl::cat("lamlet:", n)), prism_rtl::cat("lfn:", n)), prism_rtl::cat("local:", n), no_rel()); });
}


/// let noRel
Rel no_rel() {
    return Rel{.param = Nat(0u), .strict = false};
}


/// IsLocal: fn (Text ==> Rel), Text -> Bool
bool is_local(const Map<Text, Rel>& m, const Text& n) {
    return crate::check_env::has_key(m, prism_rtl::cat("local:", n));
}


/// PreIs: fn (Text ==> Rel), Text, Text -> Bool
bool pre_is(const Map<Text, Rel>& m, const Text& n, const Text& bare) {
    return (((n == bare) || (n == prism_rtl::cat("Prelude.", bare))) && crate::check_env::has_key(m, prism_rtl::cat("pre:", n))) && (!is_local(m, n));
}


/// let preludeNames
Array<Text> prelude_names() {
    return Array(std::vector{Text::lit("Drop"), Text::lit("Take"), Text::lit("Filter"), Text::lit("Remove"), Text::lit("Min"), Text::lit("Values"), Text::lit("Keys"), Text::lit("?Step"), Text::lit("Fold"), Text::lit("Each"), Text::lit("Push"), Text::lit("Insert"), Text::lit("Append"), Text::lit("Freeze"), Text::lit("-?"), Text::lit("@Defer"), Text::lit("@Later"), Text::lit("@Run"), Text::lit("@Machine"), Text::lit("@started")});
}


/// PreludeSeeds: fn G, Text -> (Text ==> Rel)
Map<Text, Rel> prelude_seeds(const crate::check_env::G& g, const Text& h) {
    return fold(prelude_names(), Map<Text, Rel>{}, [&](const Map<Text, Rel>& m, const Text& n) {
        return ({
            auto q = prism_rtl::cat("Prelude.", n);
            !is_prelude_key(g, q)
            ? m
            : fold(Array(std::vector{n, q}), m, [&](const Map<Text, Rel>& m2, const Text& sp) {
            return resolve_callee(g, h, sp) == std::optional(q)
                ? insert(m2, prism_rtl::cat("pre:", sp), no_rel())
                : m2;
        });
        });
    });
}


/// IsPreludeKey: fn G, Text -> Bool
bool is_prelude_key(const crate::check_env::G& g, const Text& q) {
    auto&& _m = prelude::get(g.vals, q);
    if (prism_rtl::is_some(_m)) {
        auto&& v_ = prism_rtl::some_of(_m);
        return (crate::lexer::has_prefix(q, Text::lit("Prelude.")) && (v_.home == Text::lit("Prelude"))) && (v_->file >= g.prelude_from);
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// BlockRels: unbounded fn [Stmt], (Text ==> Rel) -> (Text ==> Rel)
Map<Text, Rel> block_rels(const Array<crate::ast::Stmt>& stmts, const Map<Text, Rel>& m) {
    return run_to_end(fold_job(stmts, local_fn_marks(stmts, hide(m, stmts_binders(stmts))), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Rel>>(std::tuple<Map<Text, Rel>, crate::ast::Stmt>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Rel>, crate::ast::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto m2 = p0;
                auto s = p1;
                call_then(start_stmt_rels(s, m2), [=](Map<Text, Rel> stmt_rels_77961) { return prism_rtl::finished(lam_let_rels(s, stmt_rels_77961)); });
            });
        }));
    }))));
}


prism_rtl::Turn<Map<Text, Rel>> BlockRels::cycle() const {
    const auto& stmts = this->stmts;
    const auto& m = this->m;
    auto m_1 = m;
    auto stmts_2 = stmts;
    return call_then(start_stmts_binders(stmts_2), [=](Array<Text> stmts_binders_77914) {
        return fold_job(stmts_2, local_fn_marks(stmts_2, hide(m_1, stmts_binders_77914)), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Rel>>(std::tuple<Map<Text, Rel>, crate::ast::Stmt>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Rel>, crate::ast::Stmt> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto m2 = p0;
                    auto s = p1;
                    call_then(start_stmt_rels(s, m2), [=](Map<Text, Rel> stmt_rels_77961) { return prism_rtl::finished(lam_let_rels(s, stmt_rels_77961)); });
                });
            }));
        })))->cycle();
    });
}


/// `Start BlockRels, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Rel>> start_block_rels(Array<crate::ast::Stmt> stmts, Map<Text, Rel> m) {
    return prism_rtl::make_rc<BlockRels>(stmts, m);
}


/// LocalFnMarks: fn [Stmt], (Text ==> Rel) -> (Text ==> Rel)
Map<Text, Rel> local_fn_marks(const Array<crate::ast::Stmt>& stmts, const Map<Text, Rel>& m) {
    return fold(stmts, m, [&](const Map<Text, Rel>& m2, const crate::ast::Stmt& s) {
        return ({
            auto n_opt = ({
                __label__ _done;
                prism_rtl::Slot<std::optional<Text>> _v;
                auto&& _m = s.kind;
                if (prism_rtl::is<crate::ast::StmtKind::SFn>(_m)) {
                    auto&& f = prism_rtl::as<crate::ast::StmtKind::SFn>(_m).a0;
                    _v.set(std::optional(crate::check_env::def_name_text(f.name)));
                    goto _done;
                }
                if (prism_rtl::is<crate::ast::StmtKind::SWidget>(_m)) {
                    auto&& w = prism_rtl::as<crate::ast::StmtKind::SWidget>(_m).a0;
                    _v.set(std::optional(crate::check_env::sname_key(w.name)));
                    goto _done;
                }
                {
                    _v.set(std::optional<Text>{});
                    goto _done;
                }
            _done:
                _v.take();
            });
            ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, Rel>> _v;
            if (prism_rtl::is_some(n_opt)) {
                auto&& n = prism_rtl::some_of(n_opt);
                _v.set(crate::check_env::has_key(m2, prism_rtl::cat("lfn:", n))
                    ? m2
                    : insert(m2, prism_rtl::cat("lfn:", n), Rel{.param = s.span.start, .strict = false}));
                goto _done;
            }
            if (prism_rtl::is_none(n_opt)) {
                _v.set(m2);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        });
    });
}


/// StmtsBinders: unbounded fn [Stmt] -> [Text]
Array<Text> stmts_binders(const Array<crate::ast::Stmt>& stmts) {
    return run_to_end(fold_job(stmts, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::ast::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::ast::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto s = p1;
                ({
                auto&& _m = s.kind;
                prism_rtl::is<crate::ast::StmtKind::SLet>(_m) ? ({
                auto&& p_ = prism_rtl::as<crate::ast::StmtKind::SLet>(_m).a0;
                ({
                auto p__1 = p_;
                call_then(crate::check_env::start_pattern_names(p__1), [=](Array<Text> pattern_names_78635) { return prism_rtl::finished(crate::check_types::union_texts(acc, pattern_names_78635)); });
            });
            })
                : prism_rtl::is<crate::ast::StmtKind::SBind>(_m) ? ({
                auto&& p_ = prism_rtl::as<crate::ast::StmtKind::SBind>(_m).a0;
                ({
                auto p__1 = p_;
                call_then(crate::check_env::start_pattern_names(p__1), [=](Array<Text> pattern_names_78697) { return prism_rtl::finished(crate::check_types::union_texts(acc, pattern_names_78697)); });
            });
            })
                : prism_rtl::is<crate::ast::StmtKind::SFn>(_m) ? ({
                auto&& f = prism_rtl::as<crate::ast::StmtKind::SFn>(_m).a0;
                prism_rtl::finished(crate::check_types::add_text(acc, crate::check_env::def_name_text(f.name)));
            })
                : prism_rtl::is<crate::ast::StmtKind::SWidget>(_m) ? ({
                auto&& w = prism_rtl::as<crate::ast::StmtKind::SWidget>(_m).a0;
                prism_rtl::finished(crate::check_types::add_text(acc, crate::check_env::sname_key(w.name)));
            })
                : prism_rtl::finished(acc);
            });
            });
        }));
    }))));
}


prism_rtl::Turn<Array<Text>> StmtsBinders::cycle() const {
    const auto& stmts = this->stmts;
    return fold_job(stmts, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::ast::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::ast::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto s = p1;
                ({
                auto&& _m = s.kind;
                prism_rtl::is<crate::ast::StmtKind::SLet>(_m) ? ({
                auto&& p_ = prism_rtl::as<crate::ast::StmtKind::SLet>(_m).a0;
                ({
                auto p__1 = p_;
                call_then(crate::check_env::start_pattern_names(p__1), [=](Array<Text> pattern_names_78635) { return prism_rtl::finished(crate::check_types::union_texts(acc, pattern_names_78635)); });
            });
            })
                : prism_rtl::is<crate::ast::StmtKind::SBind>(_m) ? ({
                auto&& p_ = prism_rtl::as<crate::ast::StmtKind::SBind>(_m).a0;
                ({
                auto p__1 = p_;
                call_then(crate::check_env::start_pattern_names(p__1), [=](Array<Text> pattern_names_78697) { return prism_rtl::finished(crate::check_types::union_texts(acc, pattern_names_78697)); });
            });
            })
                : prism_rtl::is<crate::ast::StmtKind::SFn>(_m) ? ({
                auto&& f = prism_rtl::as<crate::ast::StmtKind::SFn>(_m).a0;
                prism_rtl::finished(crate::check_types::add_text(acc, crate::check_env::def_name_text(f.name)));
            })
                : prism_rtl::is<crate::ast::StmtKind::SWidget>(_m) ? ({
                auto&& w = prism_rtl::as<crate::ast::StmtKind::SWidget>(_m).a0;
                prism_rtl::finished(crate::check_types::add_text(acc, crate::check_env::sname_key(w.name)));
            })
                : prism_rtl::finished(acc);
            });
            });
        }));
    })))->cycle();
}


/// `Start StmtsBinders, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_stmts_binders(Array<crate::ast::Stmt> stmts) {
    return prism_rtl::make_rc<StmtsBinders>(stmts);
}


/// StmtRels: unbounded fn Stmt, (Text ==> Rel) -> (Text ==> Rel)
Map<Text, Rel> stmt_rels(const crate::ast::Stmt& s, const Map<Text, Rel>& m) {
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::ast::StmtKind::SLet>(_m)) {
        auto&& p_ = prism_rtl::as<crate::ast::StmtKind::SLet>(_m).a0;
        auto&& e = prism_rtl::as<crate::ast::StmtKind::SLet>(_m).a2;
        return bind_rels(p_, e, m, false);
    }
    if (prism_rtl::is<crate::ast::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::ast::StmtKind::SBind>(_m).a2)) {
        auto&& p_ = prism_rtl::as<crate::ast::StmtKind::SBind>(_m).a0;
        auto&& e = prism_rtl::as<crate::ast::StmtKind::SBind>(_m).a1;
        return bind_rels(p_, e, m, true);
    }
    {
        return m;
    }
}


prism_rtl::Turn<Map<Text, Rel>> StmtRels::cycle() const {
    const auto& s = this->s;
    const auto& m = this->m;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<crate::ast::StmtKind::SLet>(_m) ? ({
        auto&& p_ = prism_rtl::as<crate::ast::StmtKind::SLet>(_m).a0;
        auto&& e = prism_rtl::as<crate::ast::StmtKind::SLet>(_m).a2;
        prism_rtl::more(prism_rtl::rc(BindRels(p_, e, m, false)));
    })
        : prism_rtl::is<crate::ast::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::ast::StmtKind::SBind>(_m).a2) ? ({
        auto&& p_ = prism_rtl::as<crate::ast::StmtKind::SBind>(_m).a0;
        auto&& e = prism_rtl::as<crate::ast::StmtKind::SBind>(_m).a1;
        prism_rtl::more(prism_rtl::rc(BindRels(p_, e, m, true)));
    })
        : prism_rtl::finished(m);
    });
}


/// `Start StmtRels, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Rel>> start_stmt_rels(crate::ast::Stmt s, Map<Text, Rel> m) {
    return prism_rtl::make_rc<StmtRels>(s, m);
}


/// BindRels: unbounded fn Pattern, Expr, (Text ==> Rel), Bool -> (Text ==> Rel)
Map<Text, Rel> bind_rels(const crate::ast::Pattern_& p_, const crate::ast::Expr& e, const Map<Text, Rel>& m, const bool& refutable) {
    auto base_opt = rel_of(m, e);
    auto dec_opt = decrement_of(m, e);
    auto h = non_empty_rels(hide(m, crate::check_env::pattern_names(p_)), p_, e, refutable);
    auto&& _m = p_.kind;
    if (prism_rtl::is<crate::ast::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<crate::ast::PatternKind::PName>(_m).a0;
        if (prism_rtl::is_some(base_opt)) {
            auto&& r = prism_rtl::some_of(base_opt);
            return insert(h, crate::check_env::sname_key(n), r);
        }
        if (prism_rtl::is_none(base_opt)) {
            if (prism_rtl::is_some(dec_opt)) {
                auto&& r = prism_rtl::some_of(dec_opt);
                return refutable ? insert(h, crate::check_env::sname_key(n), r) : h;
            }
            if (prism_rtl::is_none(dec_opt)) {
                return h;
            }
            prism_rtl::unreachable("no arm matched");
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::ast::PatternKind::PSigil>(_m)) {
        auto&& m79461_1_0 = prism_rtl::as<crate::ast::PatternKind::PSigil>(_m).a0;
        auto&& inner = prism_rtl::as<crate::ast::PatternKind::PSigil>(_m).a1;
        if (m79461_1_0 == Text::lit("?")) {
            if (prism_rtl::is_some(dec_opt)) {
                auto&& r = prism_rtl::some_of(dec_opt);
                return fold(crate::check_env::pattern_names(inner), h, [&](const Map<Text, Rel>& m2, const Text& n) { return insert(m2, n, r); });
            }
            if (prism_rtl::is_none(dec_opt)) {
                if (prism_rtl::is_some(base_opt)) {
                    auto&& r = prism_rtl::some_of(base_opt);
                    return fold(crate::check_env::pattern_names(inner), h, [&](const Map<Text, Rel>& m2, const Text& n) { return insert(m2, n, Rel{.param = r.param, .strict = true}); });
                }
                if (prism_rtl::is_none(base_opt)) {
                    return h;
                }
                prism_rtl::unreachable("no arm matched");
            }
            prism_rtl::unreachable("no arm matched");
        }
    }
    {
        if (prism_rtl::is_some(base_opt)) {
            auto&& r = prism_rtl::some_of(base_opt);
            return fold(crate::check_env::pattern_names(p_), h, [&](const Map<Text, Rel>& m2, const Text& n) { return insert(m2, n, Rel{.param = r.param, .strict = true}); });
        }
        if (prism_rtl::is_none(base_opt)) {
            return h;
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<Map<Text, Rel>> BindRels::cycle() const {
    const auto& p_ = this->p_;
    const auto& e = this->e;
    const auto& m = this->m;
    const auto& refutable = this->refutable;
    auto e_1 = e;
    auto m_2 = m;
    auto p__3 = p_;
    auto refutable_4 = refutable;
    return call_then(start_rel_of(m_2, e_1), [=](std::optional<Rel> rel_of_79343) {
        return ({
            auto base_opt = rel_of_79343;
            call_then(start_decrement_of(m_2, e_1), [=](std::optional<Rel> decrement_of_79370) {
            return ({
                auto dec_opt = decrement_of_79370;
                call_then(crate::check_env::start_pattern_names(p__3), [=](Array<Text> pattern_names_79423) {
                return call_then(start_non_empty_rels(hide(m_2, pattern_names_79423), p__3, e_1, refutable_4), [=](Map<Text, Rel> non_empty_rels_79400) {
                    return ({
                        auto h = non_empty_rels_79400;
                        ({
                        auto&& _m = p__3.kind;
                        prism_rtl::is<crate::ast::PatternKind::PName>(_m) ? ({
                        auto&& n = prism_rtl::as<crate::ast::PatternKind::PName>(_m).a0;
                        ({
                        prism_rtl::is_some(base_opt) ? ({
                        auto&& r = prism_rtl::some_of(base_opt);
                        prism_rtl::finished(insert(h, crate::check_env::sname_key(n), r));
                    })
                        : prism_rtl::is_none(base_opt) ? ({
                        prism_rtl::is_some(dec_opt) ? ({
                        auto&& r = prism_rtl::some_of(dec_opt);
                        refutable_4
                        ? prism_rtl::finished(insert(h, crate::check_env::sname_key(n), r))
                        : prism_rtl::finished(h);
                    })
                        : prism_rtl::is_none(dec_opt) ? prism_rtl::finished(h)
                        : throw prism_rtl::Panic("no arm matched");
                    })
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    })
                        : prism_rtl::is<crate::ast::PatternKind::PSigil>(_m) && ({
                        auto&& m79461_1_0 = prism_rtl::as<crate::ast::PatternKind::PSigil>(_m).a0;
                        auto&& inner = prism_rtl::as<crate::ast::PatternKind::PSigil>(_m).a1;
                        (m79461_1_0 == Text::lit("?"));
                    }) ? ({
                        auto&& m79461_1_0 = prism_rtl::as<crate::ast::PatternKind::PSigil>(_m).a0;
                        auto&& inner = prism_rtl::as<crate::ast::PatternKind::PSigil>(_m).a1;
                        ({
                        prism_rtl::is_some(dec_opt) ? ({
                        auto&& r = prism_rtl::some_of(dec_opt);
                        ({
                        auto inner_5 = inner;
                        auto r_6 = r;
                        call_then(crate::check_env::start_pattern_names(inner_5), [=](Array<Text> pattern_names_79731) { return prism_rtl::finished(fold(pattern_names_79731, h, [&](const Map<Text, Rel>& m2, const Text& n) { return insert(m2, n, r_6); })); });
                    });
                    })
                        : prism_rtl::is_none(dec_opt) ? ({
                        prism_rtl::is_some(base_opt) ? ({
                        auto&& r = prism_rtl::some_of(base_opt);
                        ({
                        auto inner_5 = inner;
                        auto r_6 = r;
                        call_then(crate::check_env::start_pattern_names(inner_5), [=](Array<Text> pattern_names_79837) { return prism_rtl::finished(fold(pattern_names_79837, h, [&](const Map<Text, Rel>& m2, const Text& n) { return insert(m2, n, Rel{.param = r_6.param, .strict = true}); })); });
                    });
                    })
                        : prism_rtl::is_none(base_opt) ? prism_rtl::finished(h)
                        : throw prism_rtl::Panic("no arm matched");
                    })
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    })
                        : ({
                        prism_rtl::is_some(base_opt) ? ({
                        auto&& r = prism_rtl::some_of(base_opt);
                        ({
                        auto r_5 = r;
                        call_then(crate::check_env::start_pattern_names(p__3), [=](Array<Text> pattern_names_79994) { return prism_rtl::finished(fold(pattern_names_79994, h, [&](const Map<Text, Rel>& m2, const Text& n) { return insert(m2, n, Rel{.param = r_5.param, .strict = true}); })); });
                    });
                    })
                        : prism_rtl::is_none(base_opt) ? prism_rtl::finished(h)
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                    });
                });
            });
            });
        });
        });
    });
}


/// `Start BindRels, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Rel>> start_bind_rels(crate::ast::Pattern_ p_, crate::ast::Expr e, Map<Text, Rel> m, bool refutable) {
    return prism_rtl::make_rc<BindRels>(p_, e, m, refutable);
}


/// NonEmptyRels: unbounded fn (Text ==> Rel), Pattern, Expr, Bool -> (Text ==> Rel)
Map<Text, Rel> non_empty_rels(const Map<Text, Rel>& m, const crate::ast::Pattern_& p_, const crate::ast::Expr& e, const bool& refutable) {
    return !refutable
        ? m
        : ({
        __label__ _done;
        prism_rtl::Slot<Map<Text, Rel>> _v;
        auto&& _m = non_empty_name(p_, e);
        if (prism_rtl::is_some(_m)) {
            auto&& n = prism_rtl::some_of(_m);
            _v.set(crate::check_types::has_text(crate::check_env::pattern_names(p_), n)
                ? m
                : insert(m, prism_rtl::cat("ne:", n), no_rel()));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(m);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Map<Text, Rel>> NonEmptyRels::cycle() const {
    const auto& m = this->m;
    const auto& p_ = this->p_;
    const auto& e = this->e;
    const auto& refutable = this->refutable;
    return !refutable
        ? prism_rtl::finished(m)
        : ({
        auto&& _m = non_empty_name(p_, e);
        prism_rtl::is_some(_m) ? ({
        auto&& n = prism_rtl::some_of(_m);
        ({
        auto m_1 = m;
        auto p__2 = p_;
        call_then(crate::check_env::start_pattern_names(p__2), [=](Array<Text> pattern_names_80530) {
        return crate::check_types::has_text(pattern_names_80530, n)
            ? prism_rtl::finished(m_1)
            : prism_rtl::finished(insert(m_1, prism_rtl::cat("ne:", n), no_rel()));
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(m)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start NonEmptyRels, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Rel>> start_non_empty_rels(Map<Text, Rel> m, crate::ast::Pattern_ p_, crate::ast::Expr e, bool refutable) {
    return prism_rtl::make_rc<NonEmptyRels>(m, p_, e, refutable);
}


/// ?NonEmptyName: fn Pattern, Expr -> ?Text
std::optional<Text> non_empty_name(const crate::ast::Pattern_& p_, const crate::ast::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::ast::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::ast::ExprKind::EGroup>(_m).a0;
        return non_empty_name(p_, x);
    }
    if (prism_rtl::is<crate::ast::ExprKind::EIndex>(_m)) {
        auto&& r = prism_rtl::as<crate::ast::ExprKind::EIndex>(_m).a0;
        auto&& _m = p_.kind;
        if (prism_rtl::is<crate::ast::PatternKind::PSigil>(_m)) {
            auto&& m80730_0_0 = prism_rtl::as<crate::ast::PatternKind::PSigil>(_m).a0;
            if (m80730_0_0 == Text::lit("?")) {
                return name_of(r);
            }
        }
        if (prism_rtl::is<crate::ast::PatternKind::PGroup>(_m)) {
            auto&& q = prism_rtl::as<crate::ast::PatternKind::PGroup>(_m).a0;
            return non_empty_name(q, e);
        }
        {
            return std::optional<Text>{};
        }
    }
    if (prism_rtl::is<crate::ast::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::ast::ExprKind::EName>(_m).a0;
        auto&& _m = p_.kind;
        if (prism_rtl::is<crate::ast::PatternKind::PArray>(_m)) {
            auto&& ps = prism_rtl::as<crate::ast::PatternKind::PArray>(_m).a0;
            return len(ps) > Nat(0u)
                ? std::optional(crate::check_env::sname_key(n))
                : std::optional<Text>{};
        }
        if (prism_rtl::is<crate::ast::PatternKind::PGroup>(_m)) {
            auto&& q = prism_rtl::as<crate::ast::PatternKind::PGroup>(_m).a0;
            return non_empty_name(q, e);
        }
        {
            return std::optional<Text>{};
        }
    }
    {
        return std::optional<Text>{};
    }
}


/// ?NameOf: fn Expr -> ?Text
std::optional<Text> name_of(const crate::ast::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::ast::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::ast::ExprKind::EName>(_m).a0;
        return std::optional(crate::check_env::sname_key(n));
    }
    if (prism_rtl::is<crate::ast::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::ast::ExprKind::EGroup>(_m).a0;
        return name_of(x);
    }
    {
        return std::optional<Text>{};
    }
}


/// ArmPatRels: unbounded fn Expr, Arm, (Text ==> Rel) -> (Text ==> Rel)
Map<Text, Rel> arm_pat_rels(const crate::ast::Expr& s, const crate::ast::Arm& a, const Map<Text, Rel>& m) {
    auto&& _m = a.pattern;
    if (prism_rtl::is_some(_m)) {
        auto&& p_ = prism_rtl::some_of(_m);
        return bind_rels(p_, s, m, true);
    }
    if (prism_rtl::is_none(_m)) {
        return m;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Map<Text, Rel>> ArmPatRels::cycle() const {
    const auto& s = this->s;
    const auto& a = this->a;
    const auto& m = this->m;
    return ({
        auto&& _m = a.pattern;
        prism_rtl::is_some(_m) ? ({
        auto&& p_ = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(BindRels(p_, s, m, true)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(m)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ArmPatRels, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Rel>> start_arm_pat_rels(crate::ast::Expr s, crate::ast::Arm a, Map<Text, Rel> m) {
    return prism_rtl::make_rc<ArmPatRels>(s, a, m);
}


/// CondRels: unbounded fn Cond, (Text ==> Rel) -> (Text ==> Rel)
Map<Text, Rel> cond_rels(const crate::ast::Cond& c, const Map<Text, Rel>& m) {
    if (prism_rtl::is<crate::ast::Cond::CondBind>(c)) {
        auto&& p_ = prism_rtl::as<crate::ast::Cond::CondBind>(c).a0;
        auto&& x = prism_rtl::as<crate::ast::Cond::CondBind>(c).a1;
        return bind_rels(p_, x, m, true);
    }
    if (prism_rtl::is<crate::ast::Cond::CondExpr>(c)) {
        return m;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Map<Text, Rel>> CondRels::cycle() const {
    const auto& c = this->c;
    const auto& m = this->m;
    return ({
        prism_rtl::is<crate::ast::Cond::CondBind>(c) ? ({
        auto&& p_ = prism_rtl::as<crate::ast::Cond::CondBind>(c).a0;
        auto&& x = prism_rtl::as<crate::ast::Cond::CondBind>(c).a1;
        prism_rtl::more(prism_rtl::rc(BindRels(p_, x, m, true)));
    })
        : prism_rtl::is<crate::ast::Cond::CondExpr>(c) ? prism_rtl::finished(m)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CondRels, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Rel>> start_cond_rels(crate::ast::Cond c, Map<Text, Rel> m) {
    return prism_rtl::make_rc<CondRels>(c, m);
}


/// StepRels: unbounded fn (Text ==> Rel), Expr, [Pattern], Nat -> (Text ==> Rel)
Map<Text, Rel> step_rels(const Map<Text, Rel>& m, const crate::ast::Expr& coll, const Array<crate::ast::Pattern_>& ps, const Nat& at_) {
    auto h = hide(m, run_to_end(fold_job(ps, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::ast::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::ast::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto a = p0;
                auto p_ = p1;
                call_then(crate::check_env::start_pattern_names(p_), [=](Array<Text> pattern_names_82219) { return prism_rtl::finished(crate::check_types::union_texts(a, pattern_names_82219)); });
            });
        }));
    })))));
    auto&& _m = rel_of(m, coll);
    if (prism_rtl::is_some(_m)) {
        auto&& r = prism_rtl::some_of(_m);
        return run_to_end(fold_job(drop(ps, at_), h, ({
            auto r_1 = r;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Rel>>(std::tuple<Map<Text, Rel>, crate::ast::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Rel>, crate::ast::Pattern_> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto r_1_2 = r_1;
                entered(once_job([=]() {
                return ({
                    auto m2 = p0;
                    auto p_ = p1;
                    call_then(crate::check_env::start_pattern_names(p_), [=](Array<Text> pattern_names_82313) { return prism_rtl::finished(fold(pattern_names_82313, m2, [&](const Map<Text, Rel>& m3, const Text& n) { return insert(m3, n, Rel{.param = r_1_2.param, .strict = true}); })); });
                });
            }));
            });
        }));
        })));
    }
    if (prism_rtl::is_none(_m)) {
        return h;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Map<Text, Rel>> StepRels::cycle() const {
    const auto& m = this->m;
    const auto& coll = this->coll;
    const auto& ps = this->ps;
    const auto& at_ = this->at_;
    auto at__1 = at_;
    auto coll_2 = coll;
    auto m_3 = m;
    auto ps_4 = ps;
    return call_value(fold_job(ps_4, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::ast::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::ast::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto a = p0;
                auto p_ = p1;
                call_then(crate::check_env::start_pattern_names(p_), [=](Array<Text> pattern_names_82219) { return prism_rtl::finished(crate::check_types::union_texts(a, pattern_names_82219)); });
            });
        }));
    }))), [=](Array<Text> fold_82181) {
        return ({
            auto h = hide(m_3, fold_82181);
            call_then(start_rel_of(m_3, coll_2), [=](std::optional<Rel> rel_of_82246) {
            return ({
                prism_rtl::is_some(rel_of_82246) ? ({
                auto&& r = prism_rtl::some_of(rel_of_82246);
                fold_job(drop(ps_4, at__1), h, ({
                auto r_5 = r;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Rel>>(std::tuple<Map<Text, Rel>, crate::ast::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Rel>, crate::ast::Pattern_> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto r_5_6 = r_5;
                    entered(once_job([=]() {
                    return ({
                        auto m2 = p0;
                        auto p_ = p1;
                        call_then(crate::check_env::start_pattern_names(p_), [=](Array<Text> pattern_names_82313) { return prism_rtl::finished(fold(pattern_names_82313, m2, [&](const Map<Text, Rel>& m3, const Text& n) { return insert(m3, n, Rel{.param = r_5_6.param, .strict = true}); })); });
                    });
                }));
                });
            }));
            }))->cycle();
            })
                : prism_rtl::is_none(rel_of_82246) ? prism_rtl::finished(h)
                : throw prism_rtl::Panic("no arm matched");
            });
        });
        });
    });
}


/// `Start StepRels, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Rel>> start_step_rels(Map<Text, Rel> m, crate::ast::Expr coll, Array<crate::ast::Pattern_> ps, Nat at_) {
    return prism_rtl::make_rc<StepRels>(m, coll, ps, at_);
}


/// ExprSpots: unbounded fn Expr, (Text ==> Rel) -> [Spot]
Array<Spot> expr_spots(const crate::ast::Expr& e, const Map<Text, Rel>& m) {
    return run_to_end(fold_job(expr_kids(e, m), Array(std::vector{Spot(Spot::SpotExpr{e, m})}), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Spot>>(std::tuple<Array<Spot>, Kid>)>>(prism_rtl::rc([=](std::tuple<Array<Spot>, Kid> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto k = p1;
                call_then(start_kid_spots(k), [=](Array<Spot> kid_spots_83490) { return prism_rtl::finished(append(acc, kid_spots_83490)); });
            });
        }));
    }))));
}


prism_rtl::Turn<Array<Spot>> ExprSpots::cycle() const {
    const auto& e = this->e;
    const auto& m = this->m;
    auto e_1 = e;
    auto m_2 = m;
    return call_then(start_expr_kids(e_1, m_2), [=](Array<Kid> expr_kids_83430) {
        return fold_job(expr_kids_83430, Array(std::vector{Spot(Spot::SpotExpr{e_1, m_2})}), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Spot>>(std::tuple<Array<Spot>, Kid>)>>(prism_rtl::rc([=](std::tuple<Array<Spot>, Kid> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto k = p1;
                    call_then(start_kid_spots(k), [=](Array<Spot> kid_spots_83490) { return prism_rtl::finished(append(acc, kid_spots_83490)); });
                });
            }));
        })))->cycle();
    });
}


/// `Start ExprSpots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Spot>> start_expr_spots(crate::ast::Expr e, Map<Text, Rel> m) {
    return prism_rtl::make_rc<ExprSpots>(e, m);
}


/// KidSpots: unbounded fn Kid -> [Spot]
Array<Spot> kid_spots(const Kid& kid0) {
    if (prism_rtl::is<Kid::KidExpr>(kid0)) {
        auto&& x = prism_rtl::as<Kid::KidExpr>(kid0).a0;
        auto&& m = prism_rtl::as<Kid::KidExpr>(kid0).a1;
        return expr_spots(x, m);
    }
    if (prism_rtl::is<Kid::KidStmts>(kid0)) {
        auto&& ss = prism_rtl::as<Kid::KidStmts>(kid0).a0;
        auto&& m = prism_rtl::as<Kid::KidStmts>(kid0).a1;
        return stmts_spots(ss, m);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Spot>> KidSpots::cycle() const {
    const auto& kid0 = this->kid0;
    return ({
        prism_rtl::is<Kid::KidExpr>(kid0) ? ({
        auto&& x = prism_rtl::as<Kid::KidExpr>(kid0).a0;
        auto&& m = prism_rtl::as<Kid::KidExpr>(kid0).a1;
        prism_rtl::more(prism_rtl::rc(ExprSpots(x, m)));
    })
        : prism_rtl::is<Kid::KidStmts>(kid0) ? ({
        auto&& ss = prism_rtl::as<Kid::KidStmts>(kid0).a0;
        auto&& m = prism_rtl::as<Kid::KidStmts>(kid0).a1;
        prism_rtl::more(prism_rtl::rc(StmtsSpots(ss, m)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start KidSpots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Spot>> start_kid_spots(Kid kid0) {
    return prism_rtl::make_rc<KidSpots>(kid0);
}


/// StmtsSpots: unbounded fn [Stmt], (Text ==> Rel) -> [Spot]
Array<Spot> stmts_spots(const Array<crate::ast::Stmt>& stmts, const Map<Text, Rel>& m) {
    auto bm = block_rels(stmts, m);
    return run_to_end(fold_job(stmts, Array<Spot>{}, ({
        auto bm_1 = bm;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Spot>>(std::tuple<Array<Spot>, crate::ast::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<Spot>, crate::ast::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto bm_1_2 = bm_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto s = p1;
                call_then(start_stmt_spots(s, bm_1_2), [=](Array<Spot> stmt_spots_83877) { return prism_rtl::finished(append(acc, stmt_spots_83877)); });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Spot>> StmtsSpots::cycle() const {
    const auto& stmts = this->stmts;
    const auto& m = this->m;
    auto m_1 = m;
    auto stmts_2 = stmts;
    return call_then(start_block_rels(stmts_2, m_1), [=](Map<Text, Rel> block_rels_83813) {
        return ({
            auto bm = block_rels_83813;
            fold_job(stmts_2, Array<Spot>{}, ({
            auto bm_3 = bm;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Spot>>(std::tuple<Array<Spot>, crate::ast::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<Spot>, crate::ast::Stmt> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto bm_3_4 = bm_3;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto s = p1;
                    call_then(start_stmt_spots(s, bm_3_4), [=](Array<Spot> stmt_spots_83877) { return prism_rtl::finished(append(acc, stmt_spots_83877)); });
                });
            }));
            });
        })));
        }))->cycle();
        });
    });
}


/// `Start StmtsSpots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Spot>> start_stmts_spots(Array<crate::ast::Stmt> stmts, Map<Text, Rel> m) {
    return prism_rtl::make_rc<StmtsSpots>(stmts, m);
}


/// StmtSpots: unbounded fn Stmt, (Text ==> Rel) -> [Spot]
Array<Spot> stmt_spots(const crate::ast::Stmt& s, const Map<Text, Rel>& m) {
    return run_to_end(fold_job(stmt_kids(s, m), Array(std::vector{Spot(Spot::SpotStmt{s, m})}), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Spot>>(std::tuple<Array<Spot>, Kid>)>>(prism_rtl::rc([=](std::tuple<Array<Spot>, Kid> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto k = p1;
                call_then(start_kid_spots(k), [=](Array<Spot> kid_spots_84036) { return prism_rtl::finished(append(acc, kid_spots_84036)); });
            });
        }));
    }))));
}


prism_rtl::Turn<Array<Spot>> StmtSpots::cycle() const {
    const auto& s = this->s;
    const auto& m = this->m;
    auto m_1 = m;
    auto s_2 = s;
    return call_then(start_stmt_kids(s_2, m_1), [=](Array<Kid> stmt_kids_83976) {
        return fold_job(stmt_kids_83976, Array(std::vector{Spot(Spot::SpotStmt{s_2, m_1})}), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Spot>>(std::tuple<Array<Spot>, Kid>)>>(prism_rtl::rc([=](std::tuple<Array<Spot>, Kid> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto k = p1;
                    call_then(start_kid_spots(k), [=](Array<Spot> kid_spots_84036) { return prism_rtl::finished(append(acc, kid_spots_84036)); });
                });
            }));
        })))->cycle();
    });
}


/// `Start StmtSpots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Spot>> start_stmt_spots(crate::ast::Stmt s, Map<Text, Rel> m) {
    return prism_rtl::make_rc<StmtSpots>(s, m);
}


/// BodySpots: unbounded fn FnBody, (Text ==> Rel) -> [Spot]
Array<Spot> body_spots(const crate::ast::FnBody& fn_body0, const Map<Text, Rel>& m) {
    if (prism_rtl::is<crate::ast::FnBody::BodyExpr>(fn_body0)) {
        auto&& e = prism_rtl::as<crate::ast::FnBody::BodyExpr>(fn_body0).a0;
        return expr_spots(e, m);
    }
    if (prism_rtl::is<crate::ast::FnBody::BodyBlock>(fn_body0)) {
        auto&& b = prism_rtl::as<crate::ast::FnBody::BodyBlock>(fn_body0).a0;
        return stmts_spots(b.stmts, m);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Spot>> BodySpots::cycle() const {
    const auto& fn_body0 = this->fn_body0;
    const auto& m = this->m;
    return ({
        prism_rtl::is<crate::ast::FnBody::BodyExpr>(fn_body0) ? ({
        auto&& e = prism_rtl::as<crate::ast::FnBody::BodyExpr>(fn_body0).a0;
        prism_rtl::more(prism_rtl::rc(ExprSpots(e, m)));
    })
        : prism_rtl::is<crate::ast::FnBody::BodyBlock>(fn_body0) ? ({
        auto&& b = prism_rtl::as<crate::ast::FnBody::BodyBlock>(fn_body0).a0;
        prism_rtl::more(prism_rtl::rc(StmtsSpots(b.stmts, m)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start BodySpots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Spot>> start_body_spots(crate::ast::FnBody fn_body0, Map<Text, Rel> m) {
    return prism_rtl::make_rc<BodySpots>(fn_body0, m);
}


/// ExprKids: unbounded fn Expr, (Text ==> Rel) -> [Kid]
Array<Kid> expr_kids(const crate::ast::Expr& e, const Map<Text, Rel>& m) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::ast::ExprKind::ECall>(_m)) {
        auto&& c = prism_rtl::as<crate::ast::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<crate::ast::ExprKind::ECall>(_m).a1;
        return call_kids(c, args, m);
    }
    if (prism_rtl::is<crate::ast::ExprKind::EMethod>(_m)) {
        auto&& r = prism_rtl::as<crate::ast::ExprKind::EMethod>(_m).a0;
        auto&& n = prism_rtl::as<crate::ast::ExprKind::EMethod>(_m).a1;
        auto&& args = prism_rtl::as<crate::ast::ExprKind::EMethod>(_m).a2;
        return call_kids(method_callee(n), method_args(r, args), m);
    }
    if (prism_rtl::is<crate::ast::ExprKind::EBinary>(_m)) {
        auto&& l = prism_rtl::as<crate::ast::ExprKind::EBinary>(_m).a1;
        auto&& r = prism_rtl::as<crate::ast::ExprKind::EBinary>(_m).a2;
        return exprs_kids(Array(std::vector{l, r}), m);
    }
    if (prism_rtl::is<crate::ast::ExprKind::ESuffixed>(_m)) {
        auto&& l = prism_rtl::as<crate::ast::ExprKind::ESuffixed>(_m).a2;
        auto&& r = prism_rtl::as<crate::ast::ExprKind::ESuffixed>(_m).a3;
        return exprs_kids(Array(std::vector{l, r}), m);
    }
    if (prism_rtl::is<crate::ast::ExprKind::EIndex>(_m)) {
        auto&& r = prism_rtl::as<crate::ast::ExprKind::EIndex>(_m).a0;
        auto&& i = prism_rtl::as<crate::ast::ExprKind::EIndex>(_m).a1;
        return exprs_kids(Array(std::vector{r, i}), m);
    }
    if (prism_rtl::is<crate::ast::ExprKind::EUnary>(_m)) {
        auto&& x = prism_rtl::as<crate::ast::ExprKind::EUnary>(_m).a1;
        return Array(std::vector{Kid(Kid::KidExpr{x, m})});
    }
    if (prism_rtl::is<crate::ast::ExprKind::EFreeSigil>(_m)) {
        auto&& x = prism_rtl::as<crate::ast::ExprKind::EFreeSigil>(_m).a1;
        return Array(std::vector{Kid(Kid::KidExpr{x, m})});
    }
    if (prism_rtl::is<crate::ast::ExprKind::EField>(_m)) {
        auto&& r = prism_rtl::as<crate::ast::ExprKind::EField>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{r, m})});
    }
    if (prism_rtl::is<crate::ast::ExprKind::ETopicIndex>(_m)) {
        auto&& x = prism_rtl::as<crate::ast::ExprKind::ETopicIndex>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{x, m})});
    }
    if (prism_rtl::is<crate::ast::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::ast::ExprKind::EGroup>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{x, m})});
    }
    if (prism_rtl::is<crate::ast::ExprKind::ETypeArgs>(_m)) {
        auto&& x = prism_rtl::as<crate::ast::ExprKind::ETypeArgs>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{x, m})});
    }
    if (prism_rtl::is<crate::ast::ExprKind::ECast>(_m)) {
        auto&& x = prism_rtl::as<crate::ast::ExprKind::ECast>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{x, m})});
    }
    if (prism_rtl::is<crate::ast::ExprKind::ENonEmpty>(_m)) {
        auto&& x = prism_rtl::as<crate::ast::ExprKind::ENonEmpty>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{x, m})});
    }
    if (prism_rtl::is<crate::ast::ExprKind::EAny>(_m)) {
        auto&& x = prism_rtl::as<crate::ast::ExprKind::EAny>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{x, m})});
    }
    if (prism_rtl::is<crate::ast::ExprKind::ETuple>(_m)) {
        auto&& es = prism_rtl::as<crate::ast::ExprKind::ETuple>(_m).a0;
        return exprs_kids(es, m);
    }
    if (prism_rtl::is<crate::ast::ExprKind::EArray>(_m)) {
        auto&& es = prism_rtl::as<crate::ast::ExprKind::EArray>(_m).a0;
        return exprs_kids(es, m);
    }
    if (prism_rtl::is<crate::ast::ExprKind::EMap>(_m)) {
        auto&& kvs = prism_rtl::as<crate::ast::ExprKind::EMap>(_m).a0;
        return fold(kvs, Array<Kid>{}, [&](const Array<Kid>& acc, const std::tuple<crate::ast::Expr, crate::ast::Expr>& _p1) {
            auto&& k = std::get<0>(_p1);
            auto&& v_ = std::get<1>(_p1);
            return append(acc, exprs_kids(Array(std::vector{k, v_}), m));
        });
    }
    if (prism_rtl::is<crate::ast::ExprKind::ELit>(_m)) {
        auto&& l = prism_rtl::as<crate::ast::ExprKind::ELit>(_m).a0;
        auto&& _m = l.kind;
        if (prism_rtl::is<crate::ast::LitKind::LText>(_m)) {
            auto&& segs = prism_rtl::as<crate::ast::LitKind::LText>(_m).a0;
            return fold(segs, Array<Kid>{}, [&](const Array<Kid>& acc, const crate::ast::TextSeg& sg) {
                return ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Kid>> _v;
                    if (prism_rtl::is<crate::ast::TextSeg::SegPlaceholder>(sg)) {
                        auto&& x = prism_rtl::as<crate::ast::TextSeg::SegPlaceholder>(sg).a0;
                        _v.set(prelude::push(acc, Kid(Kid::KidExpr{x, m})));
                        goto _done;
                    }
                    {
                        _v.set(acc);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            });
        }
        {
            return Array<Kid>{};
        }
    }
    if (prism_rtl::is<crate::ast::ExprKind::ELambda>(_m)) {
        auto&& ps_opt = prism_rtl::as<crate::ast::ExprKind::ELambda>(_m).a0;
        auto&& body = prism_rtl::as<crate::ast::ExprKind::ELambda>(_m).a1;
        return Array(std::vector{lambda_kid(body, later(hide(m, patterns_names(or_(ps_opt, Array<crate::ast::Pattern_>{})))))});
    }
    if (prism_rtl::is<crate::ast::ExprKind::EIf>(_m)) {
        auto&& c = prism_rtl::as<crate::ast::ExprKind::EIf>(_m).a0;
        auto&& t = prism_rtl::as<crate::ast::ExprKind::EIf>(_m).a1;
        auto&& el_opt = prism_rtl::as<crate::ast::ExprKind::EIf>(_m).a2;
        auto with_then = prelude::push(cond_kids(c, m), Kid(Kid::KidStmts{t.stmts, cond_rels(c, m)}));
        if (prism_rtl::is_some(el_opt)) {
            auto&& b = prism_rtl::some_of(el_opt);
            return prelude::push(with_then, Kid(Kid::KidStmts{b.stmts, m}));
        }
        if (prism_rtl::is_none(el_opt)) {
            return with_then;
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::ast::ExprKind::EMatch>(_m)) {
        auto&& s = prism_rtl::as<crate::ast::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<crate::ast::ExprKind::EMatch>(_m).a1;
        return run_to_end(fold_job(arms, Array(std::vector{Kid(Kid::KidExpr{s, m})}), ({
            auto s_1 = s;
            auto m_2 = m;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Kid>>(std::tuple<Array<Kid>, crate::ast::Arm>)>>(prism_rtl::rc([=](std::tuple<Array<Kid>, crate::ast::Arm> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto s_1_3 = s_1;
                auto m_2_3 = m_2;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_arm_pat_rels(s_1_3, a, m_2_3), [=](Map<Text, Rel> arm_pat_rels_85639) {
                    return ({
                        auto am = arm_pat_rels_85639;
                        (prism_rtl::finished(prelude::push(append(acc, opt_kids(a.guard, am)), Kid(Kid::KidStmts{a.body.stmts, am}))));
                    });
                });
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::ast::ExprKind::ERebuild>(_m)) {
        auto&& s = prism_rtl::as<crate::ast::ExprKind::ERebuild>(_m).a0;
        auto&& b = prism_rtl::as<crate::ast::ExprKind::ERebuild>(_m).a1;
        return Array(std::vector{Kid(Kid::KidExpr{s, m}), Kid(Kid::KidStmts{b.stmts, later(m)})});
    }
    if (prism_rtl::is<crate::ast::ExprKind::EUpdate>(_m)) {
        auto&& s = prism_rtl::as<crate::ast::ExprKind::EUpdate>(_m).a0;
        auto&& b = prism_rtl::as<crate::ast::ExprKind::EUpdate>(_m).a1;
        return Array(std::vector{Kid(Kid::KidExpr{s, m}), Kid(Kid::KidStmts{b.stmts, m})});
    }
    if (prism_rtl::is<crate::ast::ExprKind::EMonad>(_m)) {
        auto&& s = prism_rtl::as<crate::ast::ExprKind::EMonad>(_m).a0;
        auto&& b = prism_rtl::as<crate::ast::ExprKind::EMonad>(_m).a1;
        return Array(std::vector{Kid(Kid::KidExpr{s, m}), Kid(Kid::KidStmts{b.stmts, m})});
    }
    if (prism_rtl::is<crate::ast::ExprKind::EFor>(_m)) {
        auto&& fb_opt = prism_rtl::as<crate::ast::ExprKind::EFor>(_m).a0;
        auto&& s = prism_rtl::as<crate::ast::ExprKind::EFor>(_m).a1;
        auto&& b = prism_rtl::as<crate::ast::ExprKind::EFor>(_m).a2;
        auto names = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            if (prism_rtl::is_some(fb_opt)) {
                auto&& fb = prism_rtl::some_of(fb_opt);
                _v.set(crate::check_types::union_texts(crate::check_env::pattern_names(fb.first), opt_names(fb.second)));
                goto _done;
            }
            if (prism_rtl::is_none(fb_opt)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return Array(std::vector{Kid(Kid::KidExpr{s, m}), Kid(Kid::KidStmts{b.stmts, hide(m, names)})});
    }
    if (prism_rtl::is<crate::ast::ExprKind::EGiven>(_m)) {
        auto&& b = prism_rtl::as<crate::ast::ExprKind::EGiven>(_m).a0;
        return Array(std::vector{Kid(Kid::KidStmts{b.stmts, m})});
    }
    if (prism_rtl::is<crate::ast::ExprKind::EWidgetBlock>(_m)) {
        auto&& b = prism_rtl::as<crate::ast::ExprKind::EWidgetBlock>(_m).a0;
        return Array(std::vector{Kid(Kid::KidStmts{b.stmts, later(m)})});
    }
    if (prism_rtl::is<crate::ast::ExprKind::ETemplate>(_m)) {
        auto&& t = prism_rtl::as<crate::ast::ExprKind::ETemplate>(_m).a0;
        return template_kids(t.parts, m);
    }
    {
        return Array<Kid>{};
    }
}


prism_rtl::Turn<Array<Kid>> ExprKids::cycle() const {
    const auto& e = this->e;
    const auto& m = this->m;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::ast::ExprKind::ECall>(_m) ? ({
        auto&& c = prism_rtl::as<crate::ast::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<crate::ast::ExprKind::ECall>(_m).a1;
        prism_rtl::more(prism_rtl::rc(CallKids(c, args, m)));
    })
        : prism_rtl::is<crate::ast::ExprKind::EMethod>(_m) ? ({
        auto&& r = prism_rtl::as<crate::ast::ExprKind::EMethod>(_m).a0;
        auto&& n = prism_rtl::as<crate::ast::ExprKind::EMethod>(_m).a1;
        auto&& args = prism_rtl::as<crate::ast::ExprKind::EMethod>(_m).a2;
        prism_rtl::more(prism_rtl::rc(CallKids(method_callee(n), method_args(r, args), m)));
    })
        : prism_rtl::is<crate::ast::ExprKind::EBinary>(_m) ? ({
        auto&& l = prism_rtl::as<crate::ast::ExprKind::EBinary>(_m).a1;
        auto&& r = prism_rtl::as<crate::ast::ExprKind::EBinary>(_m).a2;
        prism_rtl::finished(exprs_kids(Array(std::vector{l, r}), m));
    })
        : prism_rtl::is<crate::ast::ExprKind::ESuffixed>(_m) ? ({
        auto&& l = prism_rtl::as<crate::ast::ExprKind::ESuffixed>(_m).a2;
        auto&& r = prism_rtl::as<crate::ast::ExprKind::ESuffixed>(_m).a3;
        prism_rtl::finished(exprs_kids(Array(std::vector{l, r}), m));
    })
        : prism_rtl::is<crate::ast::ExprKind::EIndex>(_m) ? ({
        auto&& r = prism_rtl::as<crate::ast::ExprKind::EIndex>(_m).a0;
        auto&& i = prism_rtl::as<crate::ast::ExprKind::EIndex>(_m).a1;
        prism_rtl::finished(exprs_kids(Array(std::vector{r, i}), m));
    })
        : prism_rtl::is<crate::ast::ExprKind::EUnary>(_m) ? ({
        auto&& x = prism_rtl::as<crate::ast::ExprKind::EUnary>(_m).a1;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{x, m})}));
    })
        : prism_rtl::is<crate::ast::ExprKind::EFreeSigil>(_m) ? ({
        auto&& x = prism_rtl::as<crate::ast::ExprKind::EFreeSigil>(_m).a1;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{x, m})}));
    })
        : prism_rtl::is<crate::ast::ExprKind::EField>(_m) ? ({
        auto&& r = prism_rtl::as<crate::ast::ExprKind::EField>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{r, m})}));
    })
        : prism_rtl::is<crate::ast::ExprKind::ETopicIndex>(_m) ? ({
        auto&& x = prism_rtl::as<crate::ast::ExprKind::ETopicIndex>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{x, m})}));
    })
        : prism_rtl::is<crate::ast::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::ast::ExprKind::EGroup>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{x, m})}));
    })
        : prism_rtl::is<crate::ast::ExprKind::ETypeArgs>(_m) ? ({
        auto&& x = prism_rtl::as<crate::ast::ExprKind::ETypeArgs>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{x, m})}));
    })
        : prism_rtl::is<crate::ast::ExprKind::ECast>(_m) ? ({
        auto&& x = prism_rtl::as<crate::ast::ExprKind::ECast>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{x, m})}));
    })
        : prism_rtl::is<crate::ast::ExprKind::ENonEmpty>(_m) ? ({
        auto&& x = prism_rtl::as<crate::ast::ExprKind::ENonEmpty>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{x, m})}));
    })
        : prism_rtl::is<crate::ast::ExprKind::EAny>(_m) ? ({
        auto&& x = prism_rtl::as<crate::ast::ExprKind::EAny>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{x, m})}));
    })
        : prism_rtl::is<crate::ast::ExprKind::ETuple>(_m) ? ({
        auto&& es = prism_rtl::as<crate::ast::ExprKind::ETuple>(_m).a0;
        prism_rtl::finished(exprs_kids(es, m));
    })
        : prism_rtl::is<crate::ast::ExprKind::EArray>(_m) ? ({
        auto&& es = prism_rtl::as<crate::ast::ExprKind::EArray>(_m).a0;
        prism_rtl::finished(exprs_kids(es, m));
    })
        : prism_rtl::is<crate::ast::ExprKind::EMap>(_m) ? ({
        auto&& kvs = prism_rtl::as<crate::ast::ExprKind::EMap>(_m).a0;
        prism_rtl::finished(fold(kvs, Array<Kid>{}, [&](const Array<Kid>& acc, const std::tuple<crate::ast::Expr, crate::ast::Expr>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& v_ = std::get<1>(_p1);
        return append(acc, exprs_kids(Array(std::vector{k, v_}), m));
    }));
    })
        : prism_rtl::is<crate::ast::ExprKind::ELit>(_m) ? ({
        auto&& l = prism_rtl::as<crate::ast::ExprKind::ELit>(_m).a0;
        ({
        auto&& _m = l.kind;
        prism_rtl::is<crate::ast::LitKind::LText>(_m) ? ({
        auto&& segs = prism_rtl::as<crate::ast::LitKind::LText>(_m).a0;
        prism_rtl::finished(fold(segs, Array<Kid>{}, [&](const Array<Kid>& acc, const crate::ast::TextSeg& sg) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Kid>> _v;
            if (prism_rtl::is<crate::ast::TextSeg::SegPlaceholder>(sg)) {
                auto&& x = prism_rtl::as<crate::ast::TextSeg::SegPlaceholder>(sg).a0;
                _v.set(prelude::push(acc, Kid(Kid::KidExpr{x, m})));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    }));
    })
        : prism_rtl::finished(Array<Kid>{});
    });
    })
        : prism_rtl::is<crate::ast::ExprKind::ELambda>(_m) ? ({
        auto&& ps_opt = prism_rtl::as<crate::ast::ExprKind::ELambda>(_m).a0;
        auto&& body = prism_rtl::as<crate::ast::ExprKind::ELambda>(_m).a1;
        ({
        auto ps_opt_1 = ps_opt;
        auto body_2 = body;
        auto m_3 = m;
        call_then(start_patterns_names(or_(ps_opt_1, Array<crate::ast::Pattern_>{})), [=](Array<Text> patterns_names_85327) { return prism_rtl::finished(Array(std::vector{lambda_kid(body_2, later(hide(m_3, patterns_names_85327)))})); });
    });
    })
        : prism_rtl::is<crate::ast::ExprKind::EIf>(_m) ? ({
        auto&& c = prism_rtl::as<crate::ast::ExprKind::EIf>(_m).a0;
        auto&& t = prism_rtl::as<crate::ast::ExprKind::EIf>(_m).a1;
        auto&& el_opt = prism_rtl::as<crate::ast::ExprKind::EIf>(_m).a2;
        ({
        auto el_opt_1 = el_opt;
        auto c_2 = c;
        auto m_3 = m;
        auto t_4 = t;
        call_then(start_cond_kids(c_2, m_3), [=](Array<Kid> cond_kids_85410) {
        return call_then(start_cond_rels(c_2, m_3), [=](Map<Text, Rel> cond_rels_85446) {
            return ({
                auto with_then = prelude::push(cond_kids_85410, Kid(Kid::KidStmts{t_4.stmts, cond_rels_85446}));
                ({
                prism_rtl::is_some(el_opt_1) ? ({
                auto&& b = prism_rtl::some_of(el_opt_1);
                prism_rtl::finished(prelude::push(with_then, Kid(Kid::KidStmts{b.stmts, m_3})));
            })
                : prism_rtl::is_none(el_opt_1) ? prism_rtl::finished(with_then)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        });
    });
    });
    })
        : prism_rtl::is<crate::ast::ExprKind::EMatch>(_m) ? ({
        auto&& s = prism_rtl::as<crate::ast::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<crate::ast::ExprKind::EMatch>(_m).a1;
        fold_job(arms, Array(std::vector{Kid(Kid::KidExpr{s, m})}), ({
        auto s_1 = s;
        auto m_2 = m;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Kid>>(std::tuple<Array<Kid>, crate::ast::Arm>)>>(prism_rtl::rc([=](std::tuple<Array<Kid>, crate::ast::Arm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto s_1_3 = s_1;
            auto m_2_3 = m_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto a = p1;
                call_then(start_arm_pat_rels(s_1_3, a, m_2_3), [=](Map<Text, Rel> arm_pat_rels_85639) {
                return ({
                    auto am = arm_pat_rels_85639;
                    (prism_rtl::finished(prelude::push(append(acc, opt_kids(a.guard, am)), Kid(Kid::KidStmts{a.body.stmts, am}))));
                });
            });
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::ast::ExprKind::ERebuild>(_m) ? ({
        auto&& s = prism_rtl::as<crate::ast::ExprKind::ERebuild>(_m).a0;
        auto&& b = prism_rtl::as<crate::ast::ExprKind::ERebuild>(_m).a1;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{s, m}), Kid(Kid::KidStmts{b.stmts, later(m)})}));
    })
        : prism_rtl::is<crate::ast::ExprKind::EUpdate>(_m) ? ({
        auto&& s = prism_rtl::as<crate::ast::ExprKind::EUpdate>(_m).a0;
        auto&& b = prism_rtl::as<crate::ast::ExprKind::EUpdate>(_m).a1;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{s, m}), Kid(Kid::KidStmts{b.stmts, m})}));
    })
        : prism_rtl::is<crate::ast::ExprKind::EMonad>(_m) ? ({
        auto&& s = prism_rtl::as<crate::ast::ExprKind::EMonad>(_m).a0;
        auto&& b = prism_rtl::as<crate::ast::ExprKind::EMonad>(_m).a1;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{s, m}), Kid(Kid::KidStmts{b.stmts, m})}));
    })
        : prism_rtl::is<crate::ast::ExprKind::EFor>(_m) ? ({
        auto&& fb_opt = prism_rtl::as<crate::ast::ExprKind::EFor>(_m).a0;
        auto&& s = prism_rtl::as<crate::ast::ExprKind::EFor>(_m).a1;
        auto&& b = prism_rtl::as<crate::ast::ExprKind::EFor>(_m).a2;
        ({
        auto names = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            if (prism_rtl::is_some(fb_opt)) {
                auto&& fb = prism_rtl::some_of(fb_opt);
                _v.set(crate::check_types::union_texts(crate::check_env::pattern_names(fb.first), opt_names(fb.second)));
                goto _done;
            }
            if (prism_rtl::is_none(fb_opt)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        (prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{s, m}), Kid(Kid::KidStmts{b.stmts, hide(m, names)})})));
    });
    })
        : prism_rtl::is<crate::ast::ExprKind::EGiven>(_m) ? ({
        auto&& b = prism_rtl::as<crate::ast::ExprKind::EGiven>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidStmts{b.stmts, m})}));
    })
        : prism_rtl::is<crate::ast::ExprKind::EWidgetBlock>(_m) ? ({
        auto&& b = prism_rtl::as<crate::ast::ExprKind::EWidgetBlock>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidStmts{b.stmts, later(m)})}));
    })
        : prism_rtl::is<crate::ast::ExprKind::ETemplate>(_m) ? ({
        auto&& t = prism_rtl::as<crate::ast::ExprKind::ETemplate>(_m).a0;
        prism_rtl::more(prism_rtl::rc(TemplateKids(t.parts, m)));
    })
        : prism_rtl::finished(Array<Kid>{});
    });
}


/// `Start ExprKids, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Kid>> start_expr_kids(crate::ast::Expr e, Map<Text, Rel> m) {
    return prism_rtl::make_rc<ExprKids>(e, m);
}


/// StmtKids: unbounded fn Stmt, (Text ==> Rel) -> [Kid]
Array<Kid> stmt_kids(const crate::ast::Stmt& s, const Map<Text, Rel>& m) {
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::ast::StmtKind::SBind>(_m)) {
        auto&& e = prism_rtl::as<crate::ast::StmtKind::SBind>(_m).a1;
        auto&& t_opt = prism_rtl::as<crate::ast::StmtKind::SBind>(_m).a2;
        return append(Array(std::vector{Kid(Kid::KidExpr{e, m})}), opt_kids(t_opt, m));
    }
    if (prism_rtl::is<crate::ast::StmtKind::SIgnore>(_m)) {
        auto&& e = prism_rtl::as<crate::ast::StmtKind::SIgnore>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{e, m})});
    }
    if (prism_rtl::is<crate::ast::StmtKind::SLet>(_m)) {
        auto&& e = prism_rtl::as<crate::ast::StmtKind::SLet>(_m).a2;
        return Array(std::vector{Kid(Kid::KidExpr{e, m})});
    }
    if (prism_rtl::is<crate::ast::StmtKind::SFn>(_m)) {
        auto&& f = prism_rtl::as<crate::ast::StmtKind::SFn>(_m).a0;
        return Array(std::vector{body_kid(f.body, later(hide(m, patterns_names(f.params))))});
    }
    if (prism_rtl::is<crate::ast::StmtKind::SWidget>(_m)) {
        auto&& w = prism_rtl::as<crate::ast::StmtKind::SWidget>(_m).a0;
        return Array(std::vector{Kid(Kid::KidStmts{w.body.stmts, later(m)})});
    }
    if (prism_rtl::is<crate::ast::StmtKind::SSet>(_m)) {
        auto&& t = prism_rtl::as<crate::ast::StmtKind::SSet>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::ast::StmtKind::SSet>(_m).a1;
        return exprs_kids(Array(std::vector{t, v_}), m);
    }
    if (prism_rtl::is<crate::ast::StmtKind::SAccum>(_m)) {
        auto&& t = prism_rtl::as<crate::ast::StmtKind::SAccum>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::ast::StmtKind::SAccum>(_m).a2;
        return exprs_kids(Array(std::vector{t, v_}), m);
    }
    if (prism_rtl::is<crate::ast::StmtKind::SRequire>(_m)) {
        auto&& c = prism_rtl::as<crate::ast::StmtKind::SRequire>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{c, m})});
    }
    if (prism_rtl::is<crate::ast::StmtKind::SForbid>(_m)) {
        auto&& c = prism_rtl::as<crate::ast::StmtKind::SForbid>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{c, m})});
    }
    if (prism_rtl::is<crate::ast::StmtKind::SReturn>(_m)) {
        auto&& e = prism_rtl::as<crate::ast::StmtKind::SReturn>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{e, m})});
    }
    if (prism_rtl::is<crate::ast::StmtKind::SWhile>(_m)) {
        auto&& c = prism_rtl::as<crate::ast::StmtKind::SWhile>(_m).a0;
        auto&& b = prism_rtl::as<crate::ast::StmtKind::SWhile>(_m).a1;
        return prelude::push(cond_kids(c, m), Kid(Kid::KidStmts{b.stmts, cond_rels(c, m)}));
    }
    if (prism_rtl::is<crate::ast::StmtKind::SExpr>(_m)) {
        auto&& e = prism_rtl::as<crate::ast::StmtKind::SExpr>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{e, m})});
    }
    {
        return Array<Kid>{};
    }
}


prism_rtl::Turn<Array<Kid>> StmtKids::cycle() const {
    const auto& s = this->s;
    const auto& m = this->m;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<crate::ast::StmtKind::SBind>(_m) ? ({
        auto&& e = prism_rtl::as<crate::ast::StmtKind::SBind>(_m).a1;
        auto&& t_opt = prism_rtl::as<crate::ast::StmtKind::SBind>(_m).a2;
        prism_rtl::finished(append(Array(std::vector{Kid(Kid::KidExpr{e, m})}), opt_kids(t_opt, m)));
    })
        : prism_rtl::is<crate::ast::StmtKind::SIgnore>(_m) ? ({
        auto&& e = prism_rtl::as<crate::ast::StmtKind::SIgnore>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{e, m})}));
    })
        : prism_rtl::is<crate::ast::StmtKind::SLet>(_m) ? ({
        auto&& e = prism_rtl::as<crate::ast::StmtKind::SLet>(_m).a2;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{e, m})}));
    })
        : prism_rtl::is<crate::ast::StmtKind::SFn>(_m) ? ({
        auto&& f = prism_rtl::as<crate::ast::StmtKind::SFn>(_m).a0;
        ({
        auto f_1 = f;
        auto m_2 = m;
        call_then(start_patterns_names(f_1.params), [=](Array<Text> patterns_names_86576) { return prism_rtl::finished(Array(std::vector{body_kid(f_1.body, later(hide(m_2, patterns_names_86576)))})); });
    });
    })
        : prism_rtl::is<crate::ast::StmtKind::SWidget>(_m) ? ({
        auto&& w = prism_rtl::as<crate::ast::StmtKind::SWidget>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidStmts{w.body.stmts, later(m)})}));
    })
        : prism_rtl::is<crate::ast::StmtKind::SSet>(_m) ? ({
        auto&& t = prism_rtl::as<crate::ast::StmtKind::SSet>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::ast::StmtKind::SSet>(_m).a1;
        prism_rtl::finished(exprs_kids(Array(std::vector{t, v_}), m));
    })
        : prism_rtl::is<crate::ast::StmtKind::SAccum>(_m) ? ({
        auto&& t = prism_rtl::as<crate::ast::StmtKind::SAccum>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::ast::StmtKind::SAccum>(_m).a2;
        prism_rtl::finished(exprs_kids(Array(std::vector{t, v_}), m));
    })
        : prism_rtl::is<crate::ast::StmtKind::SRequire>(_m) ? ({
        auto&& c = prism_rtl::as<crate::ast::StmtKind::SRequire>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{c, m})}));
    })
        : prism_rtl::is<crate::ast::StmtKind::SForbid>(_m) ? ({
        auto&& c = prism_rtl::as<crate::ast::StmtKind::SForbid>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{c, m})}));
    })
        : prism_rtl::is<crate::ast::StmtKind::SReturn>(_m) ? ({
        auto&& e = prism_rtl::as<crate::ast::StmtKind::SReturn>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{e, m})}));
    })
        : prism_rtl::is<crate::ast::StmtKind::SWhile>(_m) ? ({
        auto&& c = prism_rtl::as<crate::ast::StmtKind::SWhile>(_m).a0;
        auto&& b = prism_rtl::as<crate::ast::StmtKind::SWhile>(_m).a1;
        ({
        auto b_1 = b;
        auto c_2 = c;
        auto m_3 = m;
        call_then(start_cond_kids(c_2, m_3), [=](Array<Kid> cond_kids_86869) { return call_then(start_cond_rels(c_2, m_3), [=](Map<Text, Rel> cond_rels_86905) { return prism_rtl::finished(prelude::push(cond_kids_86869, Kid(Kid::KidStmts{b_1.stmts, cond_rels_86905}))); }); });
    });
    })
        : prism_rtl::is<crate::ast::StmtKind::SExpr>(_m) ? ({
        auto&& e = prism_rtl::as<crate::ast::StmtKind::SExpr>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{e, m})}));
    })
        : prism_rtl::finished(Array<Kid>{});
    });
}


/// `Start StmtKids, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Kid>> start_stmt_kids(crate::ast::Stmt s, Map<Text, Rel> m) {
    return prism_rtl::make_rc<StmtKids>(s, m);
}


/// CondKids: unbounded fn Cond, (Text ==> Rel) -> [Kid]
Array<Kid> cond_kids(const crate::ast::Cond& c, const Map<Text, Rel>& m) {
    if (prism_rtl::is<crate::ast::Cond::CondExpr>(c)) {
        auto&& x = prism_rtl::as<crate::ast::Cond::CondExpr>(c).a0;
        return Array(std::vector{Kid(Kid::KidExpr{x, m})});
    }
    if (prism_rtl::is<crate::ast::Cond::CondBind>(c)) {
        auto&& x = prism_rtl::as<crate::ast::Cond::CondBind>(c).a1;
        auto&& g_opt = prism_rtl::as<crate::ast::Cond::CondBind>(c).a2;
        return append(Array(std::vector{Kid(Kid::KidExpr{x, m})}), opt_kids(g_opt, cond_rels(c, m)));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Kid>> CondKids::cycle() const {
    const auto& c = this->c;
    const auto& m = this->m;
    return ({
        prism_rtl::is<crate::ast::Cond::CondExpr>(c) ? ({
        auto&& x = prism_rtl::as<crate::ast::Cond::CondExpr>(c).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{x, m})}));
    })
        : prism_rtl::is<crate::ast::Cond::CondBind>(c) ? ({
        auto&& x = prism_rtl::as<crate::ast::Cond::CondBind>(c).a1;
        auto&& g_opt = prism_rtl::as<crate::ast::Cond::CondBind>(c).a2;
        ({
        auto g_opt_1 = g_opt;
        auto c_2 = c;
        auto m_3 = m;
        auto x_4 = x;
        call_then(start_cond_rels(c_2, m_3), [=](Map<Text, Rel> cond_rels_87245) { return prism_rtl::finished(append(Array(std::vector{Kid(Kid::KidExpr{x_4, m_3})}), opt_kids(g_opt_1, cond_rels_87245))); });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CondKids, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Kid>> start_cond_kids(crate::ast::Cond c, Map<Text, Rel> m) {
    return prism_rtl::make_rc<CondKids>(c, m);
}


/// CallKids: unbounded fn Expr, [Arg], (Text ==> Rel) -> [Kid]
Array<Kid> call_kids(const crate::ast::Expr& c, const Array<crate::ast::Arg>& args, const Map<Text, Rel>& m) {
    auto callee = ({
        __label__ _done;
        prism_rtl::Slot<Array<Kid>> _v;
        auto&& _m = callee_name(c);
        if (prism_rtl::is_some(_m)) {
            _v.set(Array<Kid>{});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array(std::vector{Kid(Kid::KidExpr{c, m})}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& _m = traversal_of(m, c, args);
    if (prism_rtl::is_none(_m)) {
        auto&& _m = acc_callee(m, c, args);
        if (prism_rtl::is_some(_m)) {
            auto&& cn = prism_rtl::some_of(_m);
            return append(callee, run_to_end(fold_job(crate::check_errors::range0(len(args)), Array<Kid>{}, ({
                auto m_1 = m;
                auto cn_2 = cn;
                auto args_3 = args;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Kid>>(std::tuple<Array<Kid>, Nat>)>>(prism_rtl::rc([=](std::tuple<Array<Kid>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto m_1_4 = m_1;
                    auto cn_2_4 = cn_2;
                    auto args_3_4 = args_3;
                    entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto i = p1;
                        call_then(start_acc_kids(m_1_4, cn_2_4, args_3_4, i), [=](Array<Kid> acc_kids_88105) { return prism_rtl::finished(append(acc, acc_kids_88105)); });
                    });
                }));
                });
            })));
            }))));
        }
        if (prism_rtl::is_none(_m)) {
            return append(callee, exprs_kids(each(args, [&](const crate::ast::Arg& a) { return a->value; }), m));
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_some(_m)) {
        auto&& coll = std::get<0>(prism_rtl::some_of(_m));
        auto&& step_ = std::get<1>(prism_rtl::some_of(_m));
        auto&& at_ = std::get<2>(prism_rtl::some_of(_m));
        auto others = fold(crate::check_errors::range0(len(args)), callee, [&](const Array<Kid>& acc, const Nat& i) {
            return i == (at_ + Nat(1u))
                ? acc
                : ({
                __label__ _done;
                prism_rtl::Slot<Array<Kid>> _v;
                auto&& _m = index(args, i);
                if (prism_rtl::is_some(_m)) {
                    auto&& a = prism_rtl::some_of(_m);
                    _v.set(prelude::push(acc, Kid(Kid::KidExpr{a->value, m})));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(acc);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        });
        auto&& _m = step_.kind;
        if (prism_rtl::is<crate::ast::ExprKind::ELambda>(_m) && prism_rtl::is_some(prism_rtl::as<crate::ast::ExprKind::ELambda>(_m).a0)) {
            auto&& ps = prism_rtl::some_of(prism_rtl::as<crate::ast::ExprKind::ELambda>(_m).a0);
            auto&& body = prism_rtl::as<crate::ast::ExprKind::ELambda>(_m).a1;
            return prelude::push(others, lambda_kid(body, step_rels(m, coll, ps, at_)));
        }
        if (prism_rtl::is<crate::ast::ExprKind::EName>(_m)) {
            return others;
        }
        {
            return prelude::push(others, Kid(Kid::KidExpr{step_, m}));
        }
    }
    prism_rtl::unreachable("no arm matched");
}

}  // namespace crate::check_passes
