// The module `CheckPasses`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check_passes/types.hpp>
#include "elem.types.hpp"
#include <ast/types.hpp>
#include <check_env/types.hpp>
#include <typed/types.hpp>
#include <check_blocks/types.hpp>
#include <check_errors/types.hpp>
#include <check_expr/types.hpp>
#include <check_types/types.hpp>
#include <lexer/types.hpp>

namespace crate {

using namespace prelude;

namespace check_passes {

std::optional<Array<Ctor>> ctors_of(const crate::check_expr::Env& env, const crate::check_types::St& st, const crate::check_types::Ty& t);

prism_rtl::JobRef<std::optional<Array<Ctor>>> start_ctors_of(crate::check_expr::Env env, crate::check_types::St st, crate::check_types::Ty t);

Ctor ctor_of_case(const crate::check_env::TyInfo& ti, const Text& cn, const Array<crate::check_types::Ty>& cargs, const Array<crate::check_types::Ty>& args);

prism_rtl::JobRef<Ctor> start_ctor_of_case(crate::check_env::TyInfo ti, Text cn, Array<crate::check_types::Ty> cargs, Array<crate::check_types::Ty> args);

Ctor tag_ctor(const crate::check_env::TagInfo& tg);

bool is_root_module(const crate::check_expr::Env& env);

Array<crate::check_env::TagInfo> tags_of_kind(const crate::check_expr::Env& env, const Text& kind);

Array<crate::check_env::TagInfo> tags_of_row(const crate::check_expr::Env& env, const crate::check_types::Rw& w);

Pat to_pat(const crate::check_expr::Env& env, const crate::ast::Pattern_& p_);

prism_rtl::JobRef<Pat> start_to_pat(crate::check_expr::Env env, crate::ast::Pattern_ p_);

Text lit_text(const crate::ast::Literal& l);

Text lit_seg_text(const crate::ast::TextSeg& text_seg0);

Text ctor_key(const crate::check_expr::Env& env, const crate::ast::SName& n);

Pat record_pat(const crate::check_expr::Env& env, const crate::ast::SName& n, const Array<crate::ast::FieldPat>& fields);

prism_rtl::JobRef<Pat> start_record_pat(crate::check_expr::Env env, crate::ast::SName n, Array<crate::ast::FieldPat> fields);

crate::check_env::CtorInfo dummy_ctor();

Pat field_pat_for(const crate::check_expr::Env& env, const Array<crate::ast::FieldPat>& fields, const Array<Text>& names, const Text& f);

prism_rtl::JobRef<Pat> start_field_pat_for(crate::check_expr::Env env, Array<crate::ast::FieldPat> fields, Array<Text> names, Text f);

bool useful(const crate::check_expr::Env& env, const crate::check_types::St& st, const Array<Array<Pat>>& rows, const Array<Pat>& q, const Array<crate::check_types::Ty>& tys);

prism_rtl::JobRef<bool> start_useful(crate::check_expr::Env env, crate::check_types::St st, Array<Array<Pat>> rows, Array<Pat> q, Array<crate::check_types::Ty> tys);

Text ctor_family(const Ctor& c);

Array<Pat> wilds(const Nat& n);

Ctor ctor_named(const crate::check_expr::Env& env, const crate::check_types::St& st, const crate::check_types::Ty& t, const Text& c, const Nat& arity);

prism_rtl::JobRef<Ctor> start_ctor_named(crate::check_expr::Env env, crate::check_types::St st, crate::check_types::Ty t, Text c, Nat arity);

std::optional<Ctor> find_ctor(const Array<Ctor>& cs, const Text& c);

Array<Array<Pat>> specialize(const Array<Array<Pat>>& rows, const Ctor& c);

Array<Pat> pad(const Array<Pat>& args, const Nat& n);

Array<Array<Pat>> specialize_lit(const Array<Array<Pat>>& rows, const Text& l);

Array<Array<Pat>> default_rows(const Array<Array<Pat>>& rows);

Array<Text> head_names(const Array<Array<Pat>>& rows);

bool complete(const Array<Ctor>& cs, const Array<Text>& heads, const Array<Array<Pat>>& rows);

std::optional<Array<Text>> witness(const crate::check_expr::Env& env, const crate::check_types::St& st, const Array<Array<Pat>>& rows, const Array<crate::check_types::Ty>& tys);

prism_rtl::JobRef<std::optional<Array<Text>>> start_witness(crate::check_expr::Env env, crate::check_types::St st, Array<Array<Pat>> rows, Array<crate::check_types::Ty> tys);

Text show_witness(const Ctor& c, const Array<Text>& args);

crate::check_types::St match_coverage(const crate::check_expr::Env& env, const crate::check_types::St& st, const crate::check_types::Ty& t, const Array<crate::ast::Arm>& arms, const crate::ast::Range& span);

prism_rtl::JobRef<crate::check_types::St> start_match_coverage(crate::check_expr::Env env, crate::check_types::St st, crate::check_types::Ty t, Array<crate::ast::Arm> arms, crate::ast::Range span);

crate::ast::Range arm_span(const crate::ast::Arm& a);

bool is_open_row(const crate::check_expr::Env& env, const crate::check_types::St& st, const crate::check_types::Ty& t);

prism_rtl::JobRef<bool> start_is_open_row(crate::check_expr::Env env, crate::check_types::St st, crate::check_types::Ty t);

bool owns_row(const crate::check_expr::Env& env, const crate::check_types::St& st, const crate::check_types::Ty& t);

prism_rtl::JobRef<bool> start_owns_row(crate::check_expr::Env env, crate::check_types::St st, crate::check_types::Ty t);

crate::check_types::St clause_coverage(const crate::check_expr::Env& env, const crate::check_types::St& st, const Array<crate::ast::FnClause>& clauses, const Array<crate::check_types::Ty>& params, const crate::ast::Range& span);

prism_rtl::JobRef<crate::check_types::St> start_clause_coverage(crate::check_expr::Env env, crate::check_types::St st, Array<crate::ast::FnClause> clauses, Array<crate::check_types::Ty> params, crate::ast::Range span);

bool is_delayed_widget(const Text& n);

crate::check_types::St block_prompt_cycles(const crate::check_expr::Env& env, const crate::check_types::St& st, const crate::ast::Block& b);

prism_rtl::JobRef<crate::check_types::St> start_block_prompt_cycles(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Block b);

Array<Text> stmt_defs(const crate::ast::Stmt& s);

prism_rtl::JobRef<Array<Text>> start_stmt_defs(crate::ast::Stmt s);

Array<std::tuple<Text, Text>> prompt_edges(const crate::check_expr::Env& env, const crate::check_types::St& st, const PCx& cx_, const crate::ast::Stmt& s, const Array<Text>& defs);

prism_rtl::JobRef<Array<std::tuple<Text, Text>>> start_prompt_edges(crate::check_expr::Env env, crate::check_types::St st, PCx cx_, crate::ast::Stmt s, Array<Text> defs);

Array<std::tuple<Text, Text>> edges(const Array<Text>& froms, const Array<Text>& tos);

bool read_is_prompt(const crate::check_expr::Env& env, const crate::check_types::St& st, const Text& n, const Text& layer);

prism_rtl::JobRef<bool> start_read_is_prompt(crate::check_expr::Env env, crate::check_types::St st, Text n, Text layer);

Map<Text, Rel> prompt_base(const crate::check_expr::Env& env, const Array<crate::ast::Stmt>& stmts);

prism_rtl::JobRef<Map<Text, Rel>> start_prompt_base(crate::check_expr::Env env, Array<crate::ast::Stmt> stmts);

Map<Text, Rel> lam_let_rels(const crate::ast::Stmt& s, const Map<Text, Rel>& m);

std::optional<crate::ast::Expr> lambda_of(const crate::ast::Expr& e);

Map<Nat, crate::ast::Expr> let_lambdas(const Array<crate::ast::Stmt>& stmts);

prism_rtl::JobRef<Map<Nat, crate::ast::Expr>> start_let_lambdas(Array<crate::ast::Stmt> stmts);

Array<Text> prompt_reads(const PCx& cx_, const crate::ast::Expr& e, const Array<Text>& defs);

prism_rtl::JobRef<Array<Text>> start_prompt_reads(PCx cx_, crate::ast::Expr e, Array<Text> defs);

Array<Spot> prompt_spots(const PCx& cx_, const crate::ast::Expr& e, const Map<Text, Rel>& m);

prism_rtl::JobRef<Array<Spot>> start_prompt_spots(PCx cx_, crate::ast::Expr e, Map<Text, Rel> m);

Array<Kid> prompt_kids(const PCx& cx_, const crate::ast::Expr& e, const Map<Text, Rel>& m);

Array<Kid> row_kids(const crate::ast::Block& body, const Map<Text, Rel>& m, const Array<Text>& binders);

Array<Text> for_binder_names(const std::optional<crate::ast::ForBinders>& binders_opt);

Array<Kid> prompt_call_kids(const PCx& cx_, const crate::ast::Expr& e, const std::optional<Text>& n_opt, const Map<Text, Rel>& m);

Array<Kid> open_lambdas(const PCx& cx_, const Array<Kid>& kids);

Array<Kid> follow_lam_let(const PCx& cx_, const Text& n, const Map<Text, Rel>& m);

Array<Spot> prompt_kid_spots(const PCx& cx_, const Kid& k);

Array<Spot> prompt_stmt_spots(const PCx& cx_, const crate::ast::Stmt& s, const Map<Text, Rel>& m);

Array<Text> find_cycle(const Array<Text>& defs, const Array<std::tuple<Text, Text>>& edges_);

prism_rtl::JobRef<Array<Text>> start_find_cycle(Array<Text> defs, Array<std::tuple<Text, Text>> edges_);

Array<Text> cycle_through(const Array<Text>& defs, const Array<std::tuple<Text, Text>>& edges_, const Text& d);

prism_rtl::JobRef<Array<Text>> start_cycle_through(Array<Text> defs, Array<std::tuple<Text, Text>> edges_, Text d);

Array<Text> reach_from(const Array<std::tuple<Text, Text>>& edges_, const Text& d);

prism_rtl::JobRef<Array<Text>> start_reach_from(Array<std::tuple<Text, Text>> edges_, Text d);

Array<Text> reach(const Array<std::tuple<Text, Text>>& edges_, const Array<Text>& frontier, const Array<Text>& seen);

bool is_local_type(const crate::check_types::St& st, const crate::check_types::Ty& t);

prism_rtl::JobRef<bool> start_is_local_type(crate::check_types::St st, crate::check_types::Ty t);

crate::check_types::St and_block_checks(const crate::check_expr::Env& env, const crate::check_types::St& st, const crate::ast::Block& b, const crate::check_types::Ty& t);

prism_rtl::JobRef<crate::check_types::St> start_and_block_checks(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Block b, crate::check_types::Ty t);

Text block_local_name(const crate::check_types::St& st, const crate::check_types::Ty& t);

prism_rtl::JobRef<Text> start_block_local_name(crate::check_types::St st, crate::check_types::Ty t);

crate::check_types::St escape_stmts(const crate::check_expr::Env& env, const crate::check_types::St& st, const Array<crate::ast::Stmt>& stmts);

prism_rtl::JobRef<crate::check_types::St> start_escape_stmts(crate::check_expr::Env env, crate::check_types::St st, Array<crate::ast::Stmt> stmts);

bool calls_local_maker(const crate::check_expr::Env& env, const crate::ast::Expr& e);

std::optional<Text> maker_of(const crate::check_expr::Env& env, const crate::ast::Expr& c);

std::tuple<Map<Text, Nat>, crate::check_types::St> frozen_stmts(const crate::check_expr::Env& env, const crate::check_types::St& st, const Array<crate::ast::Stmt>& stmts, const Map<Text, Nat>& frozen);

prism_rtl::JobRef<std::tuple<Map<Text, Nat>, crate::check_types::St>> start_frozen_stmts(crate::check_expr::Env env, crate::check_types::St st, Array<crate::ast::Stmt> stmts, Map<Text, Nat> frozen);

Array<std::tuple<Text, crate::ast::Range>> spot_refs(const Spot& spot0);

Array<Text> spot_freezes(const Spot& spot0);

prism_rtl::JobRef<Array<Text>> start_spot_freezes(Spot spot0);

Array<std::tuple<Text, crate::ast::Range>> refs_in(const crate::ast::Expr& e);

crate::check_types::St borrow_stmts(const crate::check_expr::Env& env, const crate::check_types::St& st, const Array<crate::ast::Stmt>& stmts, const Array<Array<Text>>& lent);

prism_rtl::JobRef<crate::check_types::St> start_borrow_stmts(crate::check_expr::Env env, crate::check_types::St st, Array<crate::ast::Stmt> stmts, Array<Array<Text>> lent);

crate::check_types::St check_lent(const crate::check_expr::Env& env, const crate::check_types::St& st, const crate::ast::Expr& t, const Array<Array<Text>>& lent);

prism_rtl::JobRef<crate::check_types::St> start_check_lent(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Expr t, Array<Array<Text>> lent);

bool is_prefix(const Array<Text>& a, const Array<Text>& b);

Array<Text> ref_path(const crate::ast::Expr& e);

prism_rtl::JobRef<Array<Text>> start_ref_path(crate::ast::Expr e);

std::tuple<crate::check_types::St, Array<std::tuple<Text, Array<Text>>>> shrink_check(const crate::check_env::G& g, const crate::check_types::St& st, const Array<crate::check_env::Def>& defs);

prism_rtl::JobRef<std::tuple<crate::check_types::St, Array<std::tuple<Text, Array<Text>>>>> start_shrink_check(crate::check_env::G g, crate::check_types::St st, Array<crate::check_env::Def> defs);

Array<crate::check_errors::CDiag> unused_defs(const Array<crate::check_env::Def>& defs, const Array<std::tuple<Text, Array<Text>>>& refs, const Nat& shown);

Array<crate::check_errors::CDiag> test_only_reached(const Array<crate::check_errors::Src>& srcs, const Array<crate::check_env::Def>& defs, const Array<std::tuple<Text, Array<Text>>>& refs);

Text def_role(const Array<crate::check_errors::Src>& srcs, const crate::check_env::Def& d);

Text last_path_part(const Text& p_);

bool is_method_def(const crate::check_env::Def& d);

crate::check_types::St negative_types(const crate::check_env::G& g, const crate::check_types::St& st);

prism_rtl::JobRef<crate::check_types::St> start_negative_types(crate::check_env::G g, crate::check_types::St st);

crate::check_types::St negative_type(const crate::check_env::G& g, const crate::check_types::St& s, const Map<Text, bool>& arrowy, const Text& n);

prism_rtl::JobRef<crate::check_types::St> start_negative_type(crate::check_env::G g, crate::check_types::St s, Map<Text, bool> arrowy, Text n);

Map<Text, bool> arrowy_types(const crate::check_env::G& g);

prism_rtl::JobRef<Map<Text, bool>> start_arrowy_types(crate::check_env::G g);

Map<Text, bool> arrowy_from(const Map<Text, Array<Text>>& names, const Map<Text, bool>& got);

prism_rtl::JobRef<Map<Text, bool>> start_arrowy_from(Map<Text, Array<Text>> names, Map<Text, bool> got);

Array<Text> ty_names_in(const crate::check_types::Ty& t);

prism_rtl::JobRef<Array<Text>> start_ty_names_in(crate::check_types::Ty t);

bool has_arrow(const crate::check_types::Ty& t);

prism_rtl::JobRef<bool> start_has_arrow(crate::check_types::Ty t);

Array<crate::check_types::Ty> body_tys(const crate::check_env::TyInfo& ti);

std::tuple<bool, Map<Text, bool>> neg_walk(const crate::check_env::G& g, const Text& target, const crate::check_types::Ty& t, const bool& b, const Map<Text, bool>& seen);

prism_rtl::JobRef<std::tuple<bool, Map<Text, bool>>> start_neg_walk(crate::check_env::G g, Text target, crate::check_types::Ty t, bool b, Map<Text, bool> seen);

std::tuple<bool, Map<Text, bool>> neg_walks(const crate::check_env::G& g, const Text& target, const Array<crate::check_types::Ty>& ts, const bool& b, const Map<Text, bool>& seen);

prism_rtl::JobRef<std::tuple<bool, Map<Text, bool>>> start_neg_walks(crate::check_env::G g, Text target, Array<crate::check_types::Ty> ts, bool b, Map<Text, bool> seen);

Map<Text, Rel> nat_minus_seeds(const crate::check_types::St& st);

prism_rtl::JobRef<Map<Text, Rel>> start_nat_minus_seeds(crate::check_types::St st);

Array<crate::ast::FnClause> def_clauses(const crate::check_env::Def& d);

crate::check_env::Def own_key(const crate::check_env::Def& d);

std::optional<Text> method_of(const crate::check_env::G& g, const crate::check_env::Def& d);

Map<Text, Array<Text>> method_targets(const crate::check_env::G& g, const Array<crate::check_env::Def>& fns);

Map<Text, Text> impl_defs(const crate::check_env::G& g, const Array<crate::check_env::Def>& fns);

std::optional<Text> method_class(const crate::check_env::G& g, const Text& k);

Array<Text> dispatch_targets(const Shrink& sk, const crate::check_env::Def& d, const Site& site, const Text& k);

prism_rtl::JobRef<Array<Text>> start_dispatch_targets(Shrink sk, crate::check_env::Def d, Site site, Text k);

Array<Text> choice_targets(const Shrink& sk, const Text& k, const Text& cls, const Array<Text>& all, const Text& ch, const Array<Text>& seen);

prism_rtl::JobRef<Array<Text>> start_choice_targets(Shrink sk, Text k, Text cls, Array<Text> all, Text ch, Array<Text> seen);

Array<Text> derived_targets(const Shrink& sk, const Text& k, const Text& cls, const Array<Text>& all, const Text& n, const Array<Text>& seen);

prism_rtl::JobRef<Array<Text>> start_derived_targets(Shrink sk, Text k, Text cls, Array<Text> all, Text n, Array<Text> seen);

Array<Text> ty_heads(const crate::check_types::Ty& t);

Array<Text> head_targets(const Shrink& sk, const Text& k, const Text& cls, const Array<Text>& all, const Text& h, const Array<Text>& seen);

std::optional<Text> head_key(const crate::check_types::Ty& ty0);

Array<Text> targets_of(const Shrink& sk, const Text& k);

Text sig_key_of(const Shrink& sk, const Text& k);

Text shown_key(const Text& k);

bool is_unbounded_key(const crate::check_env::G& g, const Text& k);

Map<Text, Map<Text, Rel>> hof_seeds(const Shrink& sk, const Array<Text>& homes);

prism_rtl::JobRef<Map<Text, Map<Text, Rel>>> start_hof_seeds(Shrink sk, Array<Text> homes);

Array<Slot_> hof_candidates(const Shrink& sk);

bool slot_named(const crate::ast::FnClause& c, const Nat& j);

Text slot_name(const crate::ast::FnClause& c, const Nat& j);

Map<Text, Rel> slot_seeds(const Shrink& sk, const Text& h, const Array<Slot_>& slots, const Map<Text, Rel>& sums, const bool& with_top);

Array<Text> spellings(const crate::check_env::G& g, const Text& h, const Text& k);

Array<Slot_> clear_slots(const Shrink& sk, const Array<Text>& homes, const Array<Slot_>& slots, const Nat& round);

prism_rtl::JobRef<Array<Slot_>> start_clear_slots(Shrink sk, Array<Text> homes, Array<Slot_> slots, Nat round);

Shrink seeds_for(const Shrink& sk, const Array<Text>& homes, const Array<Slot_>& slots, const Map<Text, Rel>& sums, const bool& with_top);

bool slot_escapes(const Shrink& sk, const Slot_& sl);

prism_rtl::JobRef<bool> start_slot_escapes(Shrink sk, Slot_ sl);

bool spot_escapes(const Spot& sp, const Text& n, const Nat& j);

prism_rtl::JobRef<bool> start_spot_escapes(Spot sp, Text n, Nat j);

bool is_slot_param(const Map<Text, Rel>& m, const Text& n, const Nat& j);

Map<Text, Rel> top_sums(const Array<Slot_>& slots);

Map<Text, Rel> slot_sums(const Shrink& sk, const Array<Text>& homes, const Array<Slot_>& slots, const Map<Text, Rel>& sums, const Nat& round);

prism_rtl::JobRef<Map<Text, Rel>> start_slot_sums(Shrink sk, Array<Text> homes, Array<Slot_> slots, Map<Text, Rel> sums, Nat round);

Array<Site> slot_calls(const Shrink& sk, const Slot_& sl);

prism_rtl::JobRef<Array<Site>> start_slot_calls(Shrink sk, Slot_ sl);

std::optional<Rel> meet_args(const Array<Site>& calls, const Nat& q);

prism_rtl::JobRef<std::optional<Rel>> start_meet_args(Array<Site> calls, Nat q);

Array<Text> def_refs(const Shrink& sk, const crate::check_env::Def& d);

prism_rtl::JobRef<Array<Text>> start_def_refs(Shrink sk, crate::check_env::Def d);

Array<Text> spots_refs(const Shrink& sk, const crate::check_env::Def& d, const Array<Spot>& spots, const Array<Text>& acc);

prism_rtl::JobRef<Array<Text>> start_spots_refs(Shrink sk, crate::check_env::Def d, Array<Spot> spots, Array<Text> acc);

Shrink with_locals(const Shrink& sk, const Array<std::tuple<crate::check_env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::ast::FnClause>, std::optional<crate::ast::WidgetDecl>>>& found);

prism_rtl::JobRef<Shrink> start_with_locals(Shrink sk, Array<std::tuple<crate::check_env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::ast::FnClause>, std::optional<crate::ast::WidgetDecl>>> found);

Text local_key(const Text& n, const Text& owner, const Text& gk);

std::tuple<Text, Array<Text>, Array<std::tuple<crate::check_env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::ast::FnClause>, std::optional<crate::ast::WidgetDecl>>>> def_walk(const Shrink& sk, const crate::check_env::Def& d);

prism_rtl::JobRef<std::tuple<Text, Array<Text>, Array<std::tuple<crate::check_env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::ast::FnClause>, std::optional<crate::ast::WidgetDecl>>>>> start_def_walk(Shrink sk, crate::check_env::Def d);

Array<std::tuple<crate::check_env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::ast::FnClause>, std::optional<crate::ast::WidgetDecl>>> spot_local(const crate::check_env::Def& d, const Spot& sp);

std::optional<Text> local_target(const Shrink& sk, const crate::check_env::Def& d, const Site& site);

Map<Text, Rel> clause_base(const Shrink& sk, const crate::check_env::Def& d, const crate::ast::FnClause& c);

prism_rtl::JobRef<Map<Text, Rel>> start_clause_base(Shrink sk, crate::check_env::Def d, crate::ast::FnClause c);

std::optional<Text> resolve_callee(const crate::check_env::G& g, const Text& m, const Text& n);

std::optional<Text> resolve_op(const crate::check_env::G& g, const Text& m, const Text& op);

bool is_op_text(const Text& n);

std::optional<Text> resolve_name(const crate::check_env::G& g, const Text& m, const Text& n);

Array<Text> names_in_stmt(const crate::ast::Stmt& s);

prism_rtl::JobRef<Array<Text>> start_names_in_stmt(crate::ast::Stmt s);

Array<Array<Text>> sccs(const Array<Text>& keys_, const Array<std::tuple<Text, Array<Text>>>& refs);

prism_rtl::JobRef<Array<Array<Text>>> start_sccs(Array<Text> keys_, Array<std::tuple<Text, Array<Text>>> refs);

std::tuple<Map<Text, bool>, Array<Text>> post_visit(const Map<Text, Array<Text>>& adj, const Map<Text, bool>& seen, const Array<Text>& out, const Text& k);

prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Text>>> start_post_visit(Map<Text, Array<Text>> adj, Map<Text, bool> seen, Array<Text> out, Text k);

std::tuple<Map<Text, bool>, Array<Text>> collect(const Map<Text, Array<Text>>& rev, const Map<Text, bool>& seen, const Array<Text>& comp, const Text& k);

prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Text>>> start_collect(Map<Text, Array<Text>> rev, Map<Text, bool> seen, Array<Text> comp, Text k);

crate::check_types::St shrink_component(const Shrink& sk, const crate::check_types::St& st, const Array<Text>& comp);

prism_rtl::JobRef<crate::check_types::St> start_shrink_component(Shrink sk, crate::check_types::St st, Array<Text> comp);

Array<Sc> call_graphs(const Shrink& sk, const crate::check_env::Def& d, const Array<Text>& comp);

prism_rtl::JobRef<Array<Sc>> start_call_graphs(Shrink sk, crate::check_env::Def d, Array<Text> comp);

Array<Sc> clause_graphs(const Shrink& sk, const crate::check_env::Def& d, const crate::ast::FnClause& c, const Array<Text>& comp);

prism_rtl::JobRef<Array<Sc>> start_clause_graphs(Shrink sk, crate::check_env::Def d, crate::ast::FnClause c, Array<Text> comp);

Sc site_graph(const Shrink& sk, const crate::check_env::Def& d, const Site& site, const Text& k);

prism_rtl::JobRef<Sc> start_site_graph(Shrink sk, crate::check_env::Def d, Site site, Text k);

Array<std::tuple<Nat, crate::ast::Arg>> arg_slots(const Shrink& sk, const Array<crate::ast::Arg>& args, const Text& k);

prism_rtl::JobRef<Array<std::tuple<Nat, crate::ast::Arg>>> start_arg_slots(Shrink sk, Array<crate::ast::Arg> args, Text k);

std::optional<Nat> param_named(const Shrink& sk, const Text& k, const Text& name);

prism_rtl::JobRef<std::optional<Nat>> start_param_named(Shrink sk, Text k, Text name);

std::optional<Nat> param_named_in(const Array<crate::ast::FnClause>& clauses, const Text& name);

Text param_name_of(const crate::ast::Pattern_& p_);

Text expr_name(const crate::ast::Expr& e);

Map<Text, Rel> param_rels_on(const Map<Text, Rel>& base, const Array<crate::ast::Pattern_>& ps);

prism_rtl::JobRef<Map<Text, Rel>> start_param_rels_on(Map<Text, Rel> base, Array<crate::ast::Pattern_> ps);

Map<Text, Rel> hide(const Map<Text, Rel>& m, const Array<Text>& names);

Rel no_rel();

bool is_local(const Map<Text, Rel>& m, const Text& n);

bool pre_is(const Map<Text, Rel>& m, const Text& n, const Text& bare);

Array<Text> prelude_names();

Map<Text, Rel> prelude_seeds(const crate::check_env::G& g, const Text& h);

bool is_prelude_key(const crate::check_env::G& g, const Text& q);

Map<Text, Rel> block_rels(const Array<crate::ast::Stmt>& stmts, const Map<Text, Rel>& m);

prism_rtl::JobRef<Map<Text, Rel>> start_block_rels(Array<crate::ast::Stmt> stmts, Map<Text, Rel> m);

Map<Text, Rel> local_fn_marks(const Array<crate::ast::Stmt>& stmts, const Map<Text, Rel>& m);

Array<Text> stmts_binders(const Array<crate::ast::Stmt>& stmts);

prism_rtl::JobRef<Array<Text>> start_stmts_binders(Array<crate::ast::Stmt> stmts);

Map<Text, Rel> stmt_rels(const crate::ast::Stmt& s, const Map<Text, Rel>& m);

prism_rtl::JobRef<Map<Text, Rel>> start_stmt_rels(crate::ast::Stmt s, Map<Text, Rel> m);

Map<Text, Rel> bind_rels(const crate::ast::Pattern_& p_, const crate::ast::Expr& e, const Map<Text, Rel>& m, const bool& refutable);

prism_rtl::JobRef<Map<Text, Rel>> start_bind_rels(crate::ast::Pattern_ p_, crate::ast::Expr e, Map<Text, Rel> m, bool refutable);

Map<Text, Rel> non_empty_rels(const Map<Text, Rel>& m, const crate::ast::Pattern_& p_, const crate::ast::Expr& e, const bool& refutable);

prism_rtl::JobRef<Map<Text, Rel>> start_non_empty_rels(Map<Text, Rel> m, crate::ast::Pattern_ p_, crate::ast::Expr e, bool refutable);

std::optional<Text> non_empty_name(const crate::ast::Pattern_& p_, const crate::ast::Expr& e);

std::optional<Text> name_of(const crate::ast::Expr& e);

Map<Text, Rel> arm_pat_rels(const crate::ast::Expr& s, const crate::ast::Arm& a, const Map<Text, Rel>& m);

prism_rtl::JobRef<Map<Text, Rel>> start_arm_pat_rels(crate::ast::Expr s, crate::ast::Arm a, Map<Text, Rel> m);

Map<Text, Rel> cond_rels(const crate::ast::Cond& c, const Map<Text, Rel>& m);

prism_rtl::JobRef<Map<Text, Rel>> start_cond_rels(crate::ast::Cond c, Map<Text, Rel> m);

Map<Text, Rel> step_rels(const Map<Text, Rel>& m, const crate::ast::Expr& coll, const Array<crate::ast::Pattern_>& ps, const Nat& at_);

prism_rtl::JobRef<Map<Text, Rel>> start_step_rels(Map<Text, Rel> m, crate::ast::Expr coll, Array<crate::ast::Pattern_> ps, Nat at_);

Array<Spot> expr_spots(const crate::ast::Expr& e, const Map<Text, Rel>& m);

prism_rtl::JobRef<Array<Spot>> start_expr_spots(crate::ast::Expr e, Map<Text, Rel> m);

Array<Spot> kid_spots(const Kid& kid0);

prism_rtl::JobRef<Array<Spot>> start_kid_spots(Kid kid0);

Array<Spot> stmts_spots(const Array<crate::ast::Stmt>& stmts, const Map<Text, Rel>& m);

prism_rtl::JobRef<Array<Spot>> start_stmts_spots(Array<crate::ast::Stmt> stmts, Map<Text, Rel> m);

Array<Spot> stmt_spots(const crate::ast::Stmt& s, const Map<Text, Rel>& m);

prism_rtl::JobRef<Array<Spot>> start_stmt_spots(crate::ast::Stmt s, Map<Text, Rel> m);

Array<Spot> body_spots(const crate::ast::FnBody& fn_body0, const Map<Text, Rel>& m);

prism_rtl::JobRef<Array<Spot>> start_body_spots(crate::ast::FnBody fn_body0, Map<Text, Rel> m);

Array<Kid> expr_kids(const crate::ast::Expr& e, const Map<Text, Rel>& m);

prism_rtl::JobRef<Array<Kid>> start_expr_kids(crate::ast::Expr e, Map<Text, Rel> m);

Array<Kid> stmt_kids(const crate::ast::Stmt& s, const Map<Text, Rel>& m);

prism_rtl::JobRef<Array<Kid>> start_stmt_kids(crate::ast::Stmt s, Map<Text, Rel> m);

Array<Kid> cond_kids(const crate::ast::Cond& c, const Map<Text, Rel>& m);

prism_rtl::JobRef<Array<Kid>> start_cond_kids(crate::ast::Cond c, Map<Text, Rel> m);

Array<Kid> call_kids(const crate::ast::Expr& c, const Array<crate::ast::Arg>& args, const Map<Text, Rel>& m);

prism_rtl::JobRef<Array<Kid>> start_call_kids(crate::ast::Expr c, Array<crate::ast::Arg> args, Map<Text, Rel> m);

Map<Text, Rel> later(const Map<Text, Rel>& m);

std::optional<Text> acc_callee(const Map<Text, Rel>& m, const crate::ast::Expr& c, const Array<crate::ast::Arg>& args);

Array<Kid> acc_kids(const Map<Text, Rel>& m, const Text& cn, const Array<crate::ast::Arg>& args, const Nat& i);

prism_rtl::JobRef<Array<Kid>> start_acc_kids(Map<Text, Rel> m, Text cn, Array<crate::ast::Arg> args, Nat i);

Map<Text, Rel> acc_lambda_rels(const Map<Text, Rel>& m, const Text& cn, const Nat& j, const Array<crate::ast::Pattern_>& ps, const Array<crate::ast::Arg>& args);

Nat top_param();

Array<Kid> template_kids(const Array<crate::ast::TemplatePart>& parts, const Map<Text, Rel>& m);

prism_rtl::JobRef<Array<Kid>> start_template_kids(Array<crate::ast::TemplatePart> parts, Map<Text, Rel> m);

crate::ast::Expr template_call_expr(const crate::ast::SName& n, const Array<crate::ast::Arg>& args, const std::optional<Array<crate::ast::TemplatePart>>& ps_opt, const crate::ast::Range& span);

crate::ast::Arg arg_of(const crate::ast::Expr& x);

Array<Kid> exprs_kids(const Array<crate::ast::Expr>& xs, const Map<Text, Rel>& m);

Array<Kid> opt_kids(const std::optional<crate::ast::Expr>& opt0, const Map<Text, Rel>& map1);

Kid lambda_kid(const crate::ast::LambdaBody& lambda_body0, const Map<Text, Rel>& m);

Kid body_kid(const crate::ast::FnBody& fn_body0, const Map<Text, Rel>& m);

Array<Text> patterns_names(const Array<crate::ast::Pattern_>& ps);

prism_rtl::JobRef<Array<Text>> start_patterns_names(Array<crate::ast::Pattern_> ps);

std::optional<Text> callee_name(const crate::ast::Expr& c);

crate::ast::Expr method_callee(const crate::ast::SName& n);

Array<crate::ast::Arg> method_args(const crate::ast::Expr& r, const Array<crate::ast::Arg>& args);

Array<Site> body_sites(const crate::ast::FnBody& body, const Map<Text, Rel>& m);

prism_rtl::JobRef<Array<Site>> start_body_sites(crate::ast::FnBody body, Map<Text, Rel> m);

Array<Site> spot_sites(const Spot& spot0);

prism_rtl::JobRef<Array<Site>> start_spot_sites(Spot spot0);

bool is_called_op(const Text& op);

Array<Site> call_sites(const crate::ast::Expr& c, const Array<crate::ast::Arg>& args, const crate::ast::Range& span, const Map<Text, Rel>& m);

prism_rtl::JobRef<Array<Site>> start_call_sites(crate::ast::Expr c, Array<crate::ast::Arg> args, crate::ast::Range span, Map<Text, Rel> m);

crate::ast::Expr part_of(const crate::ast::Expr& x);

Array<Site> acc_sites(const Map<Text, Rel>& m, const Text& cn, const Array<crate::ast::Arg>& args);

crate::ast::Arg acc_arg(const Map<Text, Rel>& m, const Text& cn, const Nat& j, const Nat& q, const Array<crate::ast::Arg>& args);

crate::ast::Expr top_expr();

Array<Text> spots_names(const Array<Spot>& spots);

prism_rtl::JobRef<Array<Text>> start_spots_names(Array<Spot> spots);

Array<Text> spot_names(const Spot& sp);

prism_rtl::JobRef<Array<Text>> start_spot_names(Spot sp);

std::optional<std::tuple<crate::ast::Expr, crate::ast::Expr, Nat>> traversal_of(const Map<Text, Rel>& m, const crate::ast::Expr& c, const Array<crate::ast::Arg>& args);

std::optional<crate::ast::Expr> last_expr(const crate::ast::Block& b);

std::optional<Rel> rel_of(const Map<Text, Rel>& m, const crate::ast::Expr& e);

prism_rtl::JobRef<std::optional<Rel>> start_rel_of(Map<Text, Rel> m, crate::ast::Expr e);

bool is_non_nat_min(const Map<Text, Rel>& m, const crate::ast::Expr& e, const crate::ast::Expr& c);

bool is_nat_at(const Map<Text, Rel>& m, const crate::ast::Expr& e);

std::optional<Rel> rel_of_call(const Map<Text, Rel>& m, const crate::ast::Expr& c, const Array<crate::ast::Arg>& args);

prism_rtl::JobRef<std::optional<Rel>> start_rel_of_call(Map<Text, Rel> m, crate::ast::Expr c, Array<crate::ast::Arg> args);

bool known_non_empty(const Map<Text, Rel>& m, const crate::ast::Expr& e);

std::optional<std::tuple<crate::ast::Expr, Array<crate::ast::Arg>>> call_of(const crate::ast::Expr& e);

std::optional<crate::ast::Expr> no_larger_arg(const Map<Text, Rel>& m, const crate::ast::Expr& c, const Array<crate::ast::Arg>& args);

bool is_no_larger_prelude(const crate::check_env::G& g, const Text& k);

Map<Text, Nat> parts_summaries(const Shrink& sk, const Array<crate::check_env::Def>& fns);

prism_rtl::JobRef<Map<Text, Nat>> start_parts_summaries(Shrink sk, Array<crate::check_env::Def> fns);

bool clause_within(const Map<Text, Rel>& base, const crate::ast::FnClause& c, const Nat& i);

prism_rtl::JobRef<bool> start_clause_within(Map<Text, Rel> base, crate::ast::FnClause c, Nat i);

bool within(const Map<Text, Rel>& m, const Nat& i, const crate::ast::Expr& e);

prism_rtl::JobRef<bool> start_within(Map<Text, Rel> m, Nat i, crate::ast::Expr e);

bool update_within(const Map<Text, Rel>& m, const Nat& i, const crate::ast::Block& b);

prism_rtl::JobRef<bool> start_update_within(Map<Text, Rel> m, Nat i, crate::ast::Block b);

bool spot_keeps_within(const Spot& spot0, const Nat& n1);

prism_rtl::JobRef<bool> start_spot_keeps_within(Spot spot0, Nat n1);

bool within_block(const Map<Text, Rel>& m, const Nat& i, const crate::ast::Block& b);

prism_rtl::JobRef<bool> start_within_block(Map<Text, Rel> m, Nat i, crate::ast::Block b);

bool step_within(const Map<Text, Rel>& m, const Nat& i, const Text& f, const crate::ast::Expr& coll, const crate::ast::Expr& step_, const Nat& at_, const crate::ast::Expr& z);

prism_rtl::JobRef<bool> start_step_within(Map<Text, Rel> m, Nat i, Text f, crate::ast::Expr coll, crate::ast::Expr step_, Nat at_, crate::ast::Expr z);

crate::ast::Expr last_or(const crate::ast::Block& b);

bool builds_on(const Map<Text, Rel>& m, const Nat& i, const Text& acc, const crate::ast::Expr& e);

prism_rtl::JobRef<bool> start_builds_on(Map<Text, Rel> m, Nat i, Text acc, crate::ast::Expr e);

bool builds_on_call(const Map<Text, Rel>& m, const Nat& i, const Text& acc, const crate::ast::Expr& c, const Array<crate::ast::Arg>& args);

prism_rtl::JobRef<bool> start_builds_on_call(Map<Text, Rel> m, Nat i, Text acc, crate::ast::Expr c, Array<crate::ast::Arg> args);

bool builds_on_block(const Map<Text, Rel>& m, const Nat& i, const Text& acc, const crate::ast::Block& b);

prism_rtl::JobRef<bool> start_builds_on_block(Map<Text, Rel> m, Nat i, Text acc, crate::ast::Block b);

Array<Text> cond_names(const crate::ast::Cond& cond0);

prism_rtl::JobRef<Array<Text>> start_cond_names(crate::ast::Cond cond0);

bool part(const Map<Text, Rel>& m, const Nat& i, const crate::ast::Expr& e);

prism_rtl::JobRef<bool> start_part(Map<Text, Rel> m, Nat i, crate::ast::Expr e);

Map<Text, Rel> summary_seeds(const Shrink& sk, const crate::check_env::Def& d, const Array<Spot>& spots, const Map<Text, Rel>& rels);

prism_rtl::JobRef<Map<Text, Rel>> start_summary_seeds(Shrink sk, crate::check_env::Def d, Array<Spot> spots, Map<Text, Rel> rels);

Array<Text> opt_names(const std::optional<crate::ast::Pattern_>& opt0);

prism_rtl::JobRef<Array<Text>> start_opt_names(std::optional<crate::ast::Pattern_> opt0);

crate::ast::Arg dummy_arg();

std::optional<Rel> decrement_of(const Map<Text, Rel>& m, const crate::ast::Expr& e);

prism_rtl::JobRef<std::optional<Rel>> start_decrement_of(Map<Text, Rel> m, crate::ast::Expr e);

bool is_nat_minus(const Map<Text, Rel>& m, const crate::ast::Expr& e);

std::optional<Rel> smaller(const Map<Text, Rel>& m, const crate::ast::Expr& x);

bool is_positive_lit(const crate::ast::Expr& e);

Array<Sc> closure(const Array<Sc>& graphs);

prism_rtl::JobRef<Array<Sc>> start_closure(Array<Sc> graphs);

Array<Sc> dedup(const Array<Sc>& gs);

Array<Sc> closure_from(const Array<Sc>& base, const Array<Sc>& acc, const Array<Sc>& frontier);

prism_rtl::JobRef<Array<Sc>> start_closure_from(Array<Sc> base, Array<Sc> acc, Array<Sc> frontier);

Array<Sc> add_composed(const Array<Sc>& acc, const Array<Sc>& out, const Sc& a, const Sc& b);

bool has_sc(const Array<Sc>& xs, const Sc& c);

Sc compose(const Sc& a, const Sc& b);

Array<std::tuple<Nat, Nat, bool>> add_edge(const Array<std::tuple<Nat, Nat, bool>>& es, const Nat& x, const Nat& z, const bool& s);

Array<std::tuple<Nat, Nat, bool>> sort_edges(const Array<std::tuple<Nat, Nat, bool>>& es);

bool edge_before(const std::tuple<Nat, Nat, bool>& arg0, const std::tuple<Nat, Nat, bool>& arg1);

crate::check_types::St loops_of(const Shrink& sk, const crate::check_types::St& st, const crate::check_env::Def& d);

prism_rtl::JobRef<crate::check_types::St> start_loops_of(Shrink sk, crate::check_types::St st, crate::check_env::Def d);

crate::check_types::St clause_loops(const Shrink& sk, const crate::check_types::St& st, const crate::check_env::Def& d, const crate::ast::FnClause& c, const bool& unb);

prism_rtl::JobRef<crate::check_types::St> start_clause_loops(Shrink sk, crate::check_types::St st, crate::check_env::Def d, crate::ast::FnClause c, bool unb);

Map<Text, Rel> marks(const Map<Text, Rel>& m);

bool is_while_spot(const Spot& spot0);

crate::check_types::St check_while(const crate::check_types::St& st, const crate::ast::Cond& c, const crate::ast::Block& body, const crate::ast::Range& span, const Text& name, const Map<Text, Rel>& seeds, const bool& unb);

prism_rtl::JobRef<crate::check_types::St> start_check_while(crate::check_types::St st, crate::ast::Cond c, crate::ast::Block body, crate::ast::Range span, Text name, Map<Text, Rel> seeds, bool unb);

crate::check_types::St note_unshrunk(const crate::check_types::St& st, const crate::ast::Range& span);

Array<Text> set_targets(const Array<crate::ast::Stmt>& stmts);

prism_rtl::JobRef<Array<Text>> start_set_targets(Array<crate::ast::Stmt> stmts);

Array<Text> spot_set_root(const Spot& spot0);

prism_rtl::JobRef<Array<Text>> start_spot_set_root(Spot spot0);

bool all_paths_strict(const Array<crate::ast::Stmt>& stmts, const Text& v_, const Nat& vi, const Map<Text, Rel>& outer);

prism_rtl::JobRef<bool> start_all_paths_strict(Array<crate::ast::Stmt> stmts, Text v_, Nat vi, Map<Text, Rel> outer);

bool sets_weak(const Array<crate::ast::Stmt>& stmts, const Text& v_, const Nat& vi, const Map<Text, Rel>& outer);

prism_rtl::JobRef<bool> start_sets_weak(Array<crate::ast::Stmt> stmts, Text v_, Nat vi, Map<Text, Rel> outer);

bool stmt_sets_weak(const crate::ast::Stmt& s, const Text& v_, const Nat& vi, const Map<Text, Rel>& rels);

prism_rtl::JobRef<bool> start_stmt_sets_weak(crate::ast::Stmt s, Text v_, Nat vi, Map<Text, Rel> rels);

bool spot_sets_weak(const Spot& spot0, const Text& text1, const Nat& n2);

prism_rtl::JobRef<bool> start_spot_sets_weak(Spot spot0, Text text1, Nat n2);

bool is_zero_lit(const crate::ast::Expr& e);

bool sets_strict(const crate::ast::Expr& e, const Text& v_, const Nat& vi, const Map<Text, Rel>& rels);

prism_rtl::JobRef<bool> start_sets_strict(crate::ast::Expr e, Text v_, Nat vi, Map<Text, Rel> rels);

bool rel_strict(const Map<Text, Rel>& rels, const crate::ast::Expr& e, const Nat& vi);

prism_rtl::JobRef<bool> start_rel_strict(Map<Text, Rel> rels, crate::ast::Expr e, Nat vi);

bool call_strict(const crate::ast::Expr& e, const Text& v_, const Nat& vi, const Map<Text, Rel>& rels);

prism_rtl::JobRef<bool> start_call_strict(crate::ast::Expr e, Text v_, Nat vi, Map<Text, Rel> rels);

crate::check_types::St discharge_incls(const crate::check_env::G& g, const crate::check_types::St& st, const Nat& from);

prism_rtl::JobRef<crate::check_types::St> start_discharge_incls(crate::check_env::G g, crate::check_types::St st, Nat from);

crate::check_types::Incl through(const crate::check_types::St& st, const crate::check_types::Incl& inc, const Array<crate::check_types::Incl>& batch);

prism_rtl::JobRef<crate::check_types::Incl> start_through(crate::check_types::St st, crate::check_types::Incl inc, Array<crate::check_types::Incl> batch);

crate::check_types::St discharge_one(const crate::check_env::G& g, const crate::check_types::St& st, const crate::check_types::Incl& inc);

prism_rtl::JobRef<crate::check_types::St> start_discharge_one(crate::check_env::G g, crate::check_types::St st, crate::check_types::Incl inc);

Array<Text> tags_left(const crate::check_env::G& g, const Text& fam, const Array<Text>& minus);

bool is_element_tag(const crate::check_env::G& g, const Text& t);

crate::check_types::St close_tail(const crate::check_types::St& st, const Nat& n);

Report_ check_program(const Array<crate::check_errors::Src>& srcs, const Array<crate::ast::Module>& trees, const Array<Text>& world, const Nat& shown, const bool& recording, const bool& unused, const Array<crate::check_errors::CDiag>& pre);

prism_rtl::JobRef<Report_> start_check_program(Array<crate::check_errors::Src> srcs, Array<crate::ast::Module> trees, Array<Text> world, Nat shown, bool recording, bool unused, Array<crate::check_errors::CDiag> pre);

crate::typed::TProgram typed_of(const crate::check_env::G& g, const crate::check_types::St& st, const Nat& shown);

prism_rtl::JobRef<crate::typed::TProgram> start_typed_of(crate::check_env::G g, crate::check_types::St st, Nat shown);

crate::check_types::Scheme zonk_scheme(const crate::check_types::St& st, const crate::check_types::Scheme& sc);

prism_rtl::JobRef<crate::check_types::Scheme> start_zonk_scheme(crate::check_types::St st, crate::check_types::Scheme sc);

std::tuple<crate::check_env::G, crate::check_types::St> top_lets(const crate::check_env::G& g, const crate::check_types::St& st);

prism_rtl::JobRef<std::tuple<crate::check_env::G, crate::check_types::St>> start_top_lets(crate::check_env::G g, crate::check_types::St st);

crate::check_env::ValInfo dummy_val();

bool is_let_def(const crate::check_env::Def& d);

crate::check_expr::Env def_env(const crate::check_env::G& g, const crate::check_env::Def& d);

crate::check_types::St check_def(const crate::check_env::G& g, const crate::check_types::St& st, const crate::check_env::Def& d);

prism_rtl::JobRef<crate::check_types::St> start_check_def(crate::check_env::G g, crate::check_types::St st, crate::check_env::Def d);

crate::check_types::St default_def(const crate::check_env::G& g, const crate::check_types::St& st);

prism_rtl::JobRef<crate::check_types::St> start_default_def(crate::check_env::G g, crate::check_types::St st);

crate::check_types::St check_widget_def(const crate::check_expr::Env& env, const crate::check_types::St& st, const crate::check_env::Def& d, const crate::ast::WidgetDecl& w);

prism_rtl::JobRef<crate::check_types::St> start_check_widget_def(crate::check_expr::Env env, crate::check_types::St st, crate::check_env::Def d, crate::ast::WidgetDecl w);

std::optional<Text> method_key(const crate::check_env::G& g, const Text& cls, const Text& name);

crate::check_types::St check_method(const crate::check_expr::Env& env, const crate::check_types::St& st, const crate::check_env::Def& d, const Array<crate::ast::FnClause>& clauses, const Text& cls, const crate::check_env::ImplInfo& im);

prism_rtl::JobRef<crate::check_types::St> start_check_method(crate::check_expr::Env env, crate::check_types::St st, crate::check_env::Def d, Array<crate::ast::FnClause> clauses, Text cls, crate::check_env::ImplInfo im);

std::tuple<Text, crate::check_types::St> root_row(const crate::check_env::G& g, const crate::check_types::St& st, const Array<Text>& world);

prism_rtl::JobRef<std::tuple<Text, crate::check_types::St>> start_root_row(crate::check_env::G g, crate::check_types::St st, Array<Text> world);

}  // namespace check_passes


namespace check_passes {

/// The step machine of `CtorsOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?CtorsOf: unbounded fn Env, St, Ty -> ?[Ctor]
struct CtorsOf : prism_rtl::Job<std::optional<Array<Ctor>>> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    crate::check_types::Ty t;
    CtorsOf(crate::check_expr::Env env, crate::check_types::St st, crate::check_types::Ty t) : env(std::move(env)), st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<std::optional<Array<Ctor>>> cycle() const override;
};


/// The step machine of `CtorOfCase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CtorOfCase: unbounded fn TyInfo, Text, [Ty], [Ty] -> Ctor
struct CtorOfCase : prism_rtl::Job<Ctor> {
    crate::check_env::TyInfo ti;
    Text cn;
    Array<crate::check_types::Ty> cargs;
    Array<crate::check_types::Ty> args;
    CtorOfCase(crate::check_env::TyInfo ti, Text cn, Array<crate::check_types::Ty> cargs, Array<crate::check_types::Ty> args) : ti(std::move(ti)), cn(std::move(cn)), cargs(std::move(cargs)), args(std::move(args)) {}
    prism_rtl::Turn<Ctor> cycle() const override;
};


/// The step machine of `ToPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ToPat: unbounded fn Env, Pattern -> Pat
struct ToPat : prism_rtl::Job<Pat> {
    crate::check_expr::Env env;
    crate::ast::Pattern_ p_;
    ToPat(crate::check_expr::Env env, crate::ast::Pattern_ p_) : env(std::move(env)), p_(std::move(p_)) {}
    prism_rtl::Turn<Pat> cycle() const override;
};


/// The step machine of `RecordPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RecordPat: unbounded fn Env, SName, [FieldPat] -> Pat
struct RecordPat : prism_rtl::Job<Pat> {
    crate::check_expr::Env env;
    crate::ast::SName n;
    Array<crate::ast::FieldPat> fields;
    RecordPat(crate::check_expr::Env env, crate::ast::SName n, Array<crate::ast::FieldPat> fields) : env(std::move(env)), n(std::move(n)), fields(std::move(fields)) {}
    prism_rtl::Turn<Pat> cycle() const override;
};


/// The step machine of `FieldPatFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FieldPatFor: unbounded fn Env, [FieldPat], [Text], Text -> Pat
struct FieldPatFor : prism_rtl::Job<Pat> {
    crate::check_expr::Env env;
    Array<crate::ast::FieldPat> fields;
    Array<Text> names;
    Text f;
    FieldPatFor(crate::check_expr::Env env, Array<crate::ast::FieldPat> fields, Array<Text> names, Text f) : env(std::move(env)), fields(std::move(fields)), names(std::move(names)), f(std::move(f)) {}
    prism_rtl::Turn<Pat> cycle() const override;
};


/// The step machine of `Useful`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Useful: unbounded fn Env, St, [ [Pat] ], [Pat], [Ty] -> Bool
struct Useful : prism_rtl::Job<bool> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    Array<Array<Pat>> rows;
    Array<Pat> q;
    Array<crate::check_types::Ty> tys;
    Useful(crate::check_expr::Env env, crate::check_types::St st, Array<Array<Pat>> rows, Array<Pat> q, Array<crate::check_types::Ty> tys) : env(std::move(env)), st(std::move(st)), rows(std::move(rows)), q(std::move(q)), tys(std::move(tys)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `CtorNamed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CtorNamed: unbounded fn Env, St, Ty, Text, Nat -> Ctor
struct CtorNamed : prism_rtl::Job<Ctor> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    crate::check_types::Ty t;
    Text c;
    Nat arity;
    CtorNamed(crate::check_expr::Env env, crate::check_types::St st, crate::check_types::Ty t, Text c, Nat arity) : env(std::move(env)), st(std::move(st)), t(std::move(t)), c(std::move(c)), arity(std::move(arity)) {}
    prism_rtl::Turn<Ctor> cycle() const override;
};


/// The step machine of `Witness`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?Witness: unbounded fn Env, St, [ [Pat] ], [Ty] -> ?[Text]
struct Witness : prism_rtl::Job<std::optional<Array<Text>>> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    Array<Array<Pat>> rows;
    Array<crate::check_types::Ty> tys;
    Witness(crate::check_expr::Env env, crate::check_types::St st, Array<Array<Pat>> rows, Array<crate::check_types::Ty> tys) : env(std::move(env)), st(std::move(st)), rows(std::move(rows)), tys(std::move(tys)) {}
    prism_rtl::Turn<std::optional<Array<Text>>> cycle() const override;
};


/// The step machine of `MatchCoverage`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MatchCoverage: unbounded fn Env, St, Ty, [Arm], Range -> St
struct MatchCoverage : prism_rtl::Job<crate::check_types::St> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    crate::check_types::Ty t;
    Array<crate::ast::Arm> arms;
    crate::ast::Range span;
    MatchCoverage(crate::check_expr::Env env, crate::check_types::St st, crate::check_types::Ty t, Array<crate::ast::Arm> arms, crate::ast::Range span) : env(std::move(env)), st(std::move(st)), t(std::move(t)), arms(std::move(arms)), span(std::move(span)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `IsOpenRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IsOpenRow: unbounded fn Env, St, Ty -> Bool
struct IsOpenRow : prism_rtl::Job<bool> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    crate::check_types::Ty t;
    IsOpenRow(crate::check_expr::Env env, crate::check_types::St st, crate::check_types::Ty t) : env(std::move(env)), st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `OwnsRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OwnsRow: unbounded fn Env, St, Ty -> Bool
struct OwnsRow : prism_rtl::Job<bool> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    crate::check_types::Ty t;
    OwnsRow(crate::check_expr::Env env, crate::check_types::St st, crate::check_types::Ty t) : env(std::move(env)), st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `ClauseCoverage`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClauseCoverage: unbounded fn Env, St, [FnClause], [Ty], Range -> St
struct ClauseCoverage : prism_rtl::Job<crate::check_types::St> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    Array<crate::ast::FnClause> clauses;
    Array<crate::check_types::Ty> params;
    crate::ast::Range span;
    ClauseCoverage(crate::check_expr::Env env, crate::check_types::St st, Array<crate::ast::FnClause> clauses, Array<crate::check_types::Ty> params, crate::ast::Range span) : env(std::move(env)), st(std::move(st)), clauses(std::move(clauses)), params(std::move(params)), span(std::move(span)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `BlockPromptCycles`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BlockPromptCycles: unbounded fn Env, St, Block -> St
struct BlockPromptCycles : prism_rtl::Job<crate::check_types::St> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    crate::ast::Block b;
    BlockPromptCycles(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Block b) : env(std::move(env)), st(std::move(st)), b(std::move(b)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `StmtDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StmtDefs: unbounded fn Stmt -> [Text]
struct StmtDefs : prism_rtl::Job<Array<Text>> {
    crate::ast::Stmt s;
    StmtDefs(crate::ast::Stmt s) : s(std::move(s)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `PromptEdges`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PromptEdges: unbounded fn Env, St, PCx, Stmt, [Text] -> [((Text, Text))]
struct PromptEdges : prism_rtl::Job<Array<std::tuple<Text, Text>>> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    PCx cx_;
    crate::ast::Stmt s;
    Array<Text> defs;
    PromptEdges(crate::check_expr::Env env, crate::check_types::St st, PCx cx_, crate::ast::Stmt s, Array<Text> defs) : env(std::move(env)), st(std::move(st)), cx_(std::move(cx_)), s(std::move(s)), defs(std::move(defs)) {}
    prism_rtl::Turn<Array<std::tuple<Text, Text>>> cycle() const override;
};


/// The step machine of `ReadIsPrompt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ReadIsPrompt: unbounded fn Env, St, Text, Text -> Bool
struct ReadIsPrompt : prism_rtl::Job<bool> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    Text n;
    Text layer;
    ReadIsPrompt(crate::check_expr::Env env, crate::check_types::St st, Text n, Text layer) : env(std::move(env)), st(std::move(st)), n(std::move(n)), layer(std::move(layer)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `PromptBase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PromptBase: unbounded fn Env, [Stmt] -> (Text ==> Rel)
struct PromptBase : prism_rtl::Job<Map<Text, Rel>> {
    crate::check_expr::Env env;
    Array<crate::ast::Stmt> stmts;
    PromptBase(crate::check_expr::Env env, Array<crate::ast::Stmt> stmts) : env(std::move(env)), stmts(std::move(stmts)) {}
    prism_rtl::Turn<Map<Text, Rel>> cycle() const override;
};


/// The step machine of `LetLambdas`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LetLambdas: unbounded fn [Stmt] -> (Nat ==> Expr)
struct LetLambdas : prism_rtl::Job<Map<Nat, crate::ast::Expr>> {
    Array<crate::ast::Stmt> stmts;
    LetLambdas(Array<crate::ast::Stmt> stmts) : stmts(std::move(stmts)) {}
    prism_rtl::Turn<Map<Nat, crate::ast::Expr>> cycle() const override;
};


/// The step machine of `PromptReads`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PromptReads: unbounded fn PCx, Expr, [Text] -> [Text]
struct PromptReads : prism_rtl::Job<Array<Text>> {
    PCx cx_;
    crate::ast::Expr e;
    Array<Text> defs;
    PromptReads(PCx cx_, crate::ast::Expr e, Array<Text> defs) : cx_(std::move(cx_)), e(std::move(e)), defs(std::move(defs)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `PromptSpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PromptSpots: unbounded fn PCx, Expr, (Text ==> Rel) -> [Spot]
struct PromptSpots : prism_rtl::Job<Array<Spot>> {
    PCx cx_;
    crate::ast::Expr e;
    Map<Text, Rel> m;
    PromptSpots(PCx cx_, crate::ast::Expr e, Map<Text, Rel> m) : cx_(std::move(cx_)), e(std::move(e)), m(std::move(m)) {}
    prism_rtl::Turn<Array<Spot>> cycle() const override;
};


/// The step machine of `FindCycle`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FindCycle: unbounded fn [Text], [((Text, Text))] -> [Text]
struct FindCycle : prism_rtl::Job<Array<Text>> {
    Array<Text> defs;
    Array<std::tuple<Text, Text>> edges_;
    FindCycle(Array<Text> defs, Array<std::tuple<Text, Text>> edges_) : defs(std::move(defs)), edges_(std::move(edges_)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `CycleThrough`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CycleThrough: unbounded fn [Text], [((Text, Text))], Text -> [Text]
struct CycleThrough : prism_rtl::Job<Array<Text>> {
    Array<Text> defs;
    Array<std::tuple<Text, Text>> edges_;
    Text d;
    CycleThrough(Array<Text> defs, Array<std::tuple<Text, Text>> edges_, Text d) : defs(std::move(defs)), edges_(std::move(edges_)), d(std::move(d)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `ReachFrom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ReachFrom: unbounded fn [((Text, Text))], Text -> [Text]
struct ReachFrom : prism_rtl::Job<Array<Text>> {
    Array<std::tuple<Text, Text>> edges_;
    Text d;
    ReachFrom(Array<std::tuple<Text, Text>> edges_, Text d) : edges_(std::move(edges_)), d(std::move(d)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `IsLocalType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IsLocalType: unbounded fn St, Ty -> Bool
struct IsLocalType : prism_rtl::Job<bool> {
    crate::check_types::St st;
    crate::check_types::Ty t;
    IsLocalType(crate::check_types::St st, crate::check_types::Ty t) : st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `AndBlockChecks`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AndBlockChecks: unbounded fn Env, St, Block, Ty -> St
struct AndBlockChecks : prism_rtl::Job<crate::check_types::St> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    crate::ast::Block b;
    crate::check_types::Ty t;
    AndBlockChecks(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Block b, crate::check_types::Ty t) : env(std::move(env)), st(std::move(st)), b(std::move(b)), t(std::move(t)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `BlockLocalName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BlockLocalName: unbounded fn St, Ty -> Text
struct BlockLocalName : prism_rtl::Job<Text> {
    crate::check_types::St st;
    crate::check_types::Ty t;
    BlockLocalName(crate::check_types::St st, crate::check_types::Ty t) : st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `EscapeStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// EscapeStmts: unbounded fn Env, St, [Stmt] -> St
struct EscapeStmts : prism_rtl::Job<crate::check_types::St> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    Array<crate::ast::Stmt> stmts;
    EscapeStmts(crate::check_expr::Env env, crate::check_types::St st, Array<crate::ast::Stmt> stmts) : env(std::move(env)), st(std::move(st)), stmts(std::move(stmts)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `FrozenStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FrozenStmts: unbounded fn Env, St, [Stmt], (Text ==> Nat) -> (((Text ==> Nat), St))
struct FrozenStmts : prism_rtl::Job<std::tuple<Map<Text, Nat>, crate::check_types::St>> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    Array<crate::ast::Stmt> stmts;
    Map<Text, Nat> frozen;
    FrozenStmts(crate::check_expr::Env env, crate::check_types::St st, Array<crate::ast::Stmt> stmts, Map<Text, Nat> frozen) : env(std::move(env)), st(std::move(st)), stmts(std::move(stmts)), frozen(std::move(frozen)) {}
    prism_rtl::Turn<std::tuple<Map<Text, Nat>, crate::check_types::St>> cycle() const override;
};


/// The step machine of `SpotFreezes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SpotFreezes: unbounded fn Spot -> [Text]
struct SpotFreezes : prism_rtl::Job<Array<Text>> {
    Spot spot0;
    SpotFreezes(Spot spot0) : spot0(std::move(spot0)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `BorrowStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BorrowStmts: unbounded fn Env, St, [Stmt], [ [Text] ] -> St
struct BorrowStmts : prism_rtl::Job<crate::check_types::St> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    Array<crate::ast::Stmt> stmts;
    Array<Array<Text>> lent;
    BorrowStmts(crate::check_expr::Env env, crate::check_types::St st, Array<crate::ast::Stmt> stmts, Array<Array<Text>> lent) : env(std::move(env)), st(std::move(st)), stmts(std::move(stmts)), lent(std::move(lent)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `CheckLent`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckLent: unbounded fn Env, St, Expr, [ [Text] ] -> St
struct CheckLent : prism_rtl::Job<crate::check_types::St> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    crate::ast::Expr t;
    Array<Array<Text>> lent;
    CheckLent(crate::check_expr::Env env, crate::check_types::St st, crate::ast::Expr t, Array<Array<Text>> lent) : env(std::move(env)), st(std::move(st)), t(std::move(t)), lent(std::move(lent)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `RefPath`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RefPath: unbounded fn Expr -> [Text]
struct RefPath : prism_rtl::Job<Array<Text>> {
    crate::ast::Expr e;
    RefPath(crate::ast::Expr e) : e(std::move(e)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `ShrinkCheck`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ShrinkCheck: unbounded fn G, St, [Def] -> ((St, [((Text, [Text]))]))
struct ShrinkCheck : prism_rtl::Job<std::tuple<crate::check_types::St, Array<std::tuple<Text, Array<Text>>>>> {
    crate::check_env::G g;
    crate::check_types::St st;
    Array<crate::check_env::Def> defs;
    ShrinkCheck(crate::check_env::G g, crate::check_types::St st, Array<crate::check_env::Def> defs) : g(std::move(g)), st(std::move(st)), defs(std::move(defs)) {}
    prism_rtl::Turn<std::tuple<crate::check_types::St, Array<std::tuple<Text, Array<Text>>>>> cycle() const override;
};


/// The step machine of `NegativeTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NegativeTypes: unbounded fn G, St -> St
struct NegativeTypes : prism_rtl::Job<crate::check_types::St> {
    crate::check_env::G g;
    crate::check_types::St st;
    NegativeTypes(crate::check_env::G g, crate::check_types::St st) : g(std::move(g)), st(std::move(st)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `NegativeType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NegativeType: unbounded fn G, St, (Text ==> Bool), Text -> St
struct NegativeType : prism_rtl::Job<crate::check_types::St> {
    crate::check_env::G g;
    crate::check_types::St s;
    Map<Text, bool> arrowy;
    Text n;
    NegativeType(crate::check_env::G g, crate::check_types::St s, Map<Text, bool> arrowy, Text n) : g(std::move(g)), s(std::move(s)), arrowy(std::move(arrowy)), n(std::move(n)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `ArrowyTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ArrowyTypes: unbounded fn G -> (Text ==> Bool)
struct ArrowyTypes : prism_rtl::Job<Map<Text, bool>> {
    crate::check_env::G g;
    ArrowyTypes(crate::check_env::G g) : g(std::move(g)) {}
    prism_rtl::Turn<Map<Text, bool>> cycle() const override;
};


/// The step machine of `ArrowyFrom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ArrowyFrom: unbounded fn (Text ==> [Text]), (Text ==> Bool) -> (Text ==> Bool)
struct ArrowyFrom : prism_rtl::Job<Map<Text, bool>> {
    Map<Text, Array<Text>> names;
    Map<Text, bool> got;
    ArrowyFrom(Map<Text, Array<Text>> names, Map<Text, bool> got) : names(std::move(names)), got(std::move(got)) {}
    prism_rtl::Turn<Map<Text, bool>> cycle() const override;
};


/// The step machine of `TyNamesIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TyNamesIn: unbounded fn Ty -> [Text]
struct TyNamesIn : prism_rtl::Job<Array<Text>> {
    crate::check_types::Ty t;
    TyNamesIn(crate::check_types::Ty t) : t(std::move(t)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `HasArrow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// HasArrow: unbounded fn Ty -> Bool
struct HasArrow : prism_rtl::Job<bool> {
    crate::check_types::Ty t;
    HasArrow(crate::check_types::Ty t) : t(std::move(t)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `NegWalk`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NegWalk: unbounded fn G, Text, Ty, Bool, (Text ==> Bool) -> ((Bool, (Text ==> Bool)))
struct NegWalk : prism_rtl::Job<std::tuple<bool, Map<Text, bool>>> {
    crate::check_env::G g;
    Text target;
    crate::check_types::Ty t;
    bool b;
    Map<Text, bool> seen;
    NegWalk(crate::check_env::G g, Text target, crate::check_types::Ty t, bool b, Map<Text, bool> seen) : g(std::move(g)), target(std::move(target)), t(std::move(t)), b(std::move(b)), seen(std::move(seen)) {}
    prism_rtl::Turn<std::tuple<bool, Map<Text, bool>>> cycle() const override;
};


/// The step machine of `NegWalks`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NegWalks: unbounded fn G, Text, [Ty], Bool, (Text ==> Bool) -> ((Bool, (Text ==> Bool)))
struct NegWalks : prism_rtl::Job<std::tuple<bool, Map<Text, bool>>> {
    crate::check_env::G g;
    Text target;
    Array<crate::check_types::Ty> ts;
    bool b;
    Map<Text, bool> seen;
    NegWalks(crate::check_env::G g, Text target, Array<crate::check_types::Ty> ts, bool b, Map<Text, bool> seen) : g(std::move(g)), target(std::move(target)), ts(std::move(ts)), b(std::move(b)), seen(std::move(seen)) {}
    prism_rtl::Turn<std::tuple<bool, Map<Text, bool>>> cycle() const override;
};


/// The step machine of `NatMinusSeeds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NatMinusSeeds: unbounded fn St -> (Text ==> Rel)
struct NatMinusSeeds : prism_rtl::Job<Map<Text, Rel>> {
    crate::check_types::St st;
    NatMinusSeeds(crate::check_types::St st) : st(std::move(st)) {}
    prism_rtl::Turn<Map<Text, Rel>> cycle() const override;
};


/// The step machine of `DispatchTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DispatchTargets: unbounded fn Shrink, Def, Site, Text -> [Text]
struct DispatchTargets : prism_rtl::Job<Array<Text>> {
    Shrink sk;
    crate::check_env::Def d;
    Site site;
    Text k;
    DispatchTargets(Shrink sk, crate::check_env::Def d, Site site, Text k) : sk(std::move(sk)), d(std::move(d)), site(std::move(site)), k(std::move(k)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `ChoiceTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ChoiceTargets: unbounded fn Shrink, Text, Text, [Text], Text, [Text] -> [Text]
struct ChoiceTargets : prism_rtl::Job<Array<Text>> {
    Shrink sk;
    Text k;
    Text cls;
    Array<Text> all;
    Text ch;
    Array<Text> seen;
    ChoiceTargets(Shrink sk, Text k, Text cls, Array<Text> all, Text ch, Array<Text> seen) : sk(std::move(sk)), k(std::move(k)), cls(std::move(cls)), all(std::move(all)), ch(std::move(ch)), seen(std::move(seen)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `DerivedTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DerivedTargets: unbounded fn Shrink, Text, Text, [Text], Text, [Text] -> [Text]
struct DerivedTargets : prism_rtl::Job<Array<Text>> {
    Shrink sk;
    Text k;
    Text cls;
    Array<Text> all;
    Text n;
    Array<Text> seen;
    DerivedTargets(Shrink sk, Text k, Text cls, Array<Text> all, Text n, Array<Text> seen) : sk(std::move(sk)), k(std::move(k)), cls(std::move(cls)), all(std::move(all)), n(std::move(n)), seen(std::move(seen)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `HofSeeds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// HofSeeds: unbounded fn Shrink, [Text] -> (Text ==> (Text ==> Rel))
struct HofSeeds : prism_rtl::Job<Map<Text, Map<Text, Rel>>> {
    Shrink sk;
    Array<Text> homes;
    HofSeeds(Shrink sk, Array<Text> homes) : sk(std::move(sk)), homes(std::move(homes)) {}
    prism_rtl::Turn<Map<Text, Map<Text, Rel>>> cycle() const override;
};


/// The step machine of `ClearSlots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClearSlots: unbounded fn Shrink, [Text], [Slot], Nat -> [Slot]
struct ClearSlots : prism_rtl::Job<Array<Slot_>> {
    Shrink sk;
    Array<Text> homes;
    Array<Slot_> slots;
    Nat round;
    ClearSlots(Shrink sk, Array<Text> homes, Array<Slot_> slots, Nat round) : sk(std::move(sk)), homes(std::move(homes)), slots(std::move(slots)), round(std::move(round)) {}
    prism_rtl::Turn<Array<Slot_>> cycle() const override;
};


/// The step machine of `SlotEscapes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SlotEscapes: unbounded fn Shrink, Slot -> Bool
struct SlotEscapes : prism_rtl::Job<bool> {
    Shrink sk;
    Slot_ sl;
    SlotEscapes(Shrink sk, Slot_ sl) : sk(std::move(sk)), sl(std::move(sl)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `SpotEscapes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SpotEscapes: unbounded fn Spot, Text, Nat -> Bool
struct SpotEscapes : prism_rtl::Job<bool> {
    Spot sp;
    Text n;
    Nat j;
    SpotEscapes(Spot sp, Text n, Nat j) : sp(std::move(sp)), n(std::move(n)), j(std::move(j)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `SlotSums`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SlotSums: unbounded fn Shrink, [Text], [Slot], (Text ==> Rel), Nat -> (Text ==> Rel)
struct SlotSums : prism_rtl::Job<Map<Text, Rel>> {
    Shrink sk;
    Array<Text> homes;
    Array<Slot_> slots;
    Map<Text, Rel> sums;
    Nat round;
    SlotSums(Shrink sk, Array<Text> homes, Array<Slot_> slots, Map<Text, Rel> sums, Nat round) : sk(std::move(sk)), homes(std::move(homes)), slots(std::move(slots)), sums(std::move(sums)), round(std::move(round)) {}
    prism_rtl::Turn<Map<Text, Rel>> cycle() const override;
};


/// The step machine of `SlotCalls`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SlotCalls: unbounded fn Shrink, Slot -> [Site]
struct SlotCalls : prism_rtl::Job<Array<Site>> {
    Shrink sk;
    Slot_ sl;
    SlotCalls(Shrink sk, Slot_ sl) : sk(std::move(sk)), sl(std::move(sl)) {}
    prism_rtl::Turn<Array<Site>> cycle() const override;
};


/// The step machine of `MeetArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?MeetArgs: unbounded fn [Site], Nat -> ?Rel
struct MeetArgs : prism_rtl::Job<std::optional<Rel>> {
    Array<Site> calls;
    Nat q;
    MeetArgs(Array<Site> calls, Nat q) : calls(std::move(calls)), q(std::move(q)) {}
    prism_rtl::Turn<std::optional<Rel>> cycle() const override;
};


/// The step machine of `DefRefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DefRefs: unbounded fn Shrink, Def -> [Text]
struct DefRefs : prism_rtl::Job<Array<Text>> {
    Shrink sk;
    crate::check_env::Def d;
    DefRefs(Shrink sk, crate::check_env::Def d) : sk(std::move(sk)), d(std::move(d)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `SpotsRefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SpotsRefs: unbounded fn Shrink, Def, [Spot], [Text] -> [Text]
struct SpotsRefs : prism_rtl::Job<Array<Text>> {
    Shrink sk;
    crate::check_env::Def d;
    Array<Spot> spots;
    Array<Text> acc;
    SpotsRefs(Shrink sk, crate::check_env::Def d, Array<Spot> spots, Array<Text> acc) : sk(std::move(sk)), d(std::move(d)), spots(std::move(spots)), acc(std::move(acc)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `WithLocals`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WithLocals: unbounded fn Shrink, [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))] -> Shrink
struct WithLocals : prism_rtl::Job<Shrink> {
    Shrink sk;
    Array<std::tuple<crate::check_env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::ast::FnClause>, std::optional<crate::ast::WidgetDecl>>> found;
    WithLocals(Shrink sk, Array<std::tuple<crate::check_env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::ast::FnClause>, std::optional<crate::ast::WidgetDecl>>> found) : sk(std::move(sk)), found(std::move(found)) {}
    prism_rtl::Turn<Shrink> cycle() const override;
};


/// The step machine of `DefWalk`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DefWalk: unbounded fn Shrink, Def -> ((Text, [Text], [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))]))
struct DefWalk : prism_rtl::Job<std::tuple<Text, Array<Text>, Array<std::tuple<crate::check_env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::ast::FnClause>, std::optional<crate::ast::WidgetDecl>>>>> {
    Shrink sk;
    crate::check_env::Def d;
    DefWalk(Shrink sk, crate::check_env::Def d) : sk(std::move(sk)), d(std::move(d)) {}
    prism_rtl::Turn<std::tuple<Text, Array<Text>, Array<std::tuple<crate::check_env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::ast::FnClause>, std::optional<crate::ast::WidgetDecl>>>>> cycle() const override;
};


/// The step machine of `ClauseBase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClauseBase: unbounded fn Shrink, Def, FnClause -> (Text ==> Rel)
struct ClauseBase : prism_rtl::Job<Map<Text, Rel>> {
    Shrink sk;
    crate::check_env::Def d;
    crate::ast::FnClause c;
    ClauseBase(Shrink sk, crate::check_env::Def d, crate::ast::FnClause c) : sk(std::move(sk)), d(std::move(d)), c(std::move(c)) {}
    prism_rtl::Turn<Map<Text, Rel>> cycle() const override;
};


/// The step machine of `NamesInStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NamesInStmt: unbounded fn Stmt -> [Text]
struct NamesInStmt : prism_rtl::Job<Array<Text>> {
    crate::ast::Stmt s;
    NamesInStmt(crate::ast::Stmt s) : s(std::move(s)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `Sccs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Sccs: unbounded fn [Text], [((Text, [Text]))] -> [ [Text] ]
struct Sccs : prism_rtl::Job<Array<Array<Text>>> {
    Array<Text> keys_;
    Array<std::tuple<Text, Array<Text>>> refs;
    Sccs(Array<Text> keys_, Array<std::tuple<Text, Array<Text>>> refs) : keys_(std::move(keys_)), refs(std::move(refs)) {}
    prism_rtl::Turn<Array<Array<Text>>> cycle() const override;
};


/// The step machine of `PostVisit`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PostVisit: unbounded fn (Text ==> [Text]), (Text ==> Bool), [Text], Text -> (((Text ==> Bool), [Text]))
struct PostVisit : prism_rtl::Job<std::tuple<Map<Text, bool>, Array<Text>>> {
    Map<Text, Array<Text>> adj;
    Map<Text, bool> seen;
    Array<Text> out;
    Text k;
    PostVisit(Map<Text, Array<Text>> adj, Map<Text, bool> seen, Array<Text> out, Text k) : adj(std::move(adj)), seen(std::move(seen)), out(std::move(out)), k(std::move(k)) {}
    prism_rtl::Turn<std::tuple<Map<Text, bool>, Array<Text>>> cycle() const override;
};


/// The step machine of `Collect`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Collect: unbounded fn (Text ==> [Text]), (Text ==> Bool), [Text], Text -> (((Text ==> Bool), [Text]))
struct Collect : prism_rtl::Job<std::tuple<Map<Text, bool>, Array<Text>>> {
    Map<Text, Array<Text>> rev;
    Map<Text, bool> seen;
    Array<Text> comp;
    Text k;
    Collect(Map<Text, Array<Text>> rev, Map<Text, bool> seen, Array<Text> comp, Text k) : rev(std::move(rev)), seen(std::move(seen)), comp(std::move(comp)), k(std::move(k)) {}
    prism_rtl::Turn<std::tuple<Map<Text, bool>, Array<Text>>> cycle() const override;
};


/// The step machine of `ShrinkComponent`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ShrinkComponent: unbounded fn Shrink, St, [Text] -> St
struct ShrinkComponent : prism_rtl::Job<crate::check_types::St> {
    Shrink sk;
    crate::check_types::St st;
    Array<Text> comp;
    ShrinkComponent(Shrink sk, crate::check_types::St st, Array<Text> comp) : sk(std::move(sk)), st(std::move(st)), comp(std::move(comp)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `CallGraphs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CallGraphs: unbounded fn Shrink, Def, [Text] -> [Sc]
struct CallGraphs : prism_rtl::Job<Array<Sc>> {
    Shrink sk;
    crate::check_env::Def d;
    Array<Text> comp;
    CallGraphs(Shrink sk, crate::check_env::Def d, Array<Text> comp) : sk(std::move(sk)), d(std::move(d)), comp(std::move(comp)) {}
    prism_rtl::Turn<Array<Sc>> cycle() const override;
};


/// The step machine of `ClauseGraphs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClauseGraphs: unbounded fn Shrink, Def, FnClause, [Text] -> [Sc]
struct ClauseGraphs : prism_rtl::Job<Array<Sc>> {
    Shrink sk;
    crate::check_env::Def d;
    crate::ast::FnClause c;
    Array<Text> comp;
    ClauseGraphs(Shrink sk, crate::check_env::Def d, crate::ast::FnClause c, Array<Text> comp) : sk(std::move(sk)), d(std::move(d)), c(std::move(c)), comp(std::move(comp)) {}
    prism_rtl::Turn<Array<Sc>> cycle() const override;
};


/// The step machine of `SiteGraph`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SiteGraph: unbounded fn Shrink, Def, Site, Text -> Sc
struct SiteGraph : prism_rtl::Job<Sc> {
    Shrink sk;
    crate::check_env::Def d;
    Site site;
    Text k;
    SiteGraph(Shrink sk, crate::check_env::Def d, Site site, Text k) : sk(std::move(sk)), d(std::move(d)), site(std::move(site)), k(std::move(k)) {}
    prism_rtl::Turn<Sc> cycle() const override;
};


/// The step machine of `ArgSlots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ArgSlots: unbounded fn Shrink, [Arg], Text -> [((Nat, Arg))]
struct ArgSlots : prism_rtl::Job<Array<std::tuple<Nat, crate::ast::Arg>>> {
    Shrink sk;
    Array<crate::ast::Arg> args;
    Text k;
    ArgSlots(Shrink sk, Array<crate::ast::Arg> args, Text k) : sk(std::move(sk)), args(std::move(args)), k(std::move(k)) {}
    prism_rtl::Turn<Array<std::tuple<Nat, crate::ast::Arg>>> cycle() const override;
};


/// The step machine of `ParamNamed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?ParamNamed: unbounded fn Shrink, Text, Text -> ?Nat
struct ParamNamed : prism_rtl::Job<std::optional<Nat>> {
    Shrink sk;
    Text k;
    Text name;
    ParamNamed(Shrink sk, Text k, Text name) : sk(std::move(sk)), k(std::move(k)), name(std::move(name)) {}
    prism_rtl::Turn<std::optional<Nat>> cycle() const override;
};


/// The step machine of `ParamRelsOn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParamRelsOn: unbounded fn (Text ==> Rel), [Pattern] -> (Text ==> Rel)
struct ParamRelsOn : prism_rtl::Job<Map<Text, Rel>> {
    Map<Text, Rel> base;
    Array<crate::ast::Pattern_> ps;
    ParamRelsOn(Map<Text, Rel> base, Array<crate::ast::Pattern_> ps) : base(std::move(base)), ps(std::move(ps)) {}
    prism_rtl::Turn<Map<Text, Rel>> cycle() const override;
};


/// The step machine of `BlockRels`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BlockRels: unbounded fn [Stmt], (Text ==> Rel) -> (Text ==> Rel)
struct BlockRels : prism_rtl::Job<Map<Text, Rel>> {
    Array<crate::ast::Stmt> stmts;
    Map<Text, Rel> m;
    BlockRels(Array<crate::ast::Stmt> stmts, Map<Text, Rel> m) : stmts(std::move(stmts)), m(std::move(m)) {}
    prism_rtl::Turn<Map<Text, Rel>> cycle() const override;
};


/// The step machine of `StmtsBinders`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StmtsBinders: unbounded fn [Stmt] -> [Text]
struct StmtsBinders : prism_rtl::Job<Array<Text>> {
    Array<crate::ast::Stmt> stmts;
    StmtsBinders(Array<crate::ast::Stmt> stmts) : stmts(std::move(stmts)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `StmtRels`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StmtRels: unbounded fn Stmt, (Text ==> Rel) -> (Text ==> Rel)
struct StmtRels : prism_rtl::Job<Map<Text, Rel>> {
    crate::ast::Stmt s;
    Map<Text, Rel> m;
    StmtRels(crate::ast::Stmt s, Map<Text, Rel> m) : s(std::move(s)), m(std::move(m)) {}
    prism_rtl::Turn<Map<Text, Rel>> cycle() const override;
};


/// The step machine of `BindRels`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindRels: unbounded fn Pattern, Expr, (Text ==> Rel), Bool -> (Text ==> Rel)
struct BindRels : prism_rtl::Job<Map<Text, Rel>> {
    crate::ast::Pattern_ p_;
    crate::ast::Expr e;
    Map<Text, Rel> m;
    bool refutable;
    BindRels(crate::ast::Pattern_ p_, crate::ast::Expr e, Map<Text, Rel> m, bool refutable) : p_(std::move(p_)), e(std::move(e)), m(std::move(m)), refutable(std::move(refutable)) {}
    prism_rtl::Turn<Map<Text, Rel>> cycle() const override;
};


/// The step machine of `NonEmptyRels`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NonEmptyRels: unbounded fn (Text ==> Rel), Pattern, Expr, Bool -> (Text ==> Rel)
struct NonEmptyRels : prism_rtl::Job<Map<Text, Rel>> {
    Map<Text, Rel> m;
    crate::ast::Pattern_ p_;
    crate::ast::Expr e;
    bool refutable;
    NonEmptyRels(Map<Text, Rel> m, crate::ast::Pattern_ p_, crate::ast::Expr e, bool refutable) : m(std::move(m)), p_(std::move(p_)), e(std::move(e)), refutable(std::move(refutable)) {}
    prism_rtl::Turn<Map<Text, Rel>> cycle() const override;
};


/// The step machine of `ArmPatRels`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ArmPatRels: unbounded fn Expr, Arm, (Text ==> Rel) -> (Text ==> Rel)
struct ArmPatRels : prism_rtl::Job<Map<Text, Rel>> {
    crate::ast::Expr s;
    crate::ast::Arm a;
    Map<Text, Rel> m;
    ArmPatRels(crate::ast::Expr s, crate::ast::Arm a, Map<Text, Rel> m) : s(std::move(s)), a(std::move(a)), m(std::move(m)) {}
    prism_rtl::Turn<Map<Text, Rel>> cycle() const override;
};


/// The step machine of `CondRels`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CondRels: unbounded fn Cond, (Text ==> Rel) -> (Text ==> Rel)
struct CondRels : prism_rtl::Job<Map<Text, Rel>> {
    crate::ast::Cond c;
    Map<Text, Rel> m;
    CondRels(crate::ast::Cond c, Map<Text, Rel> m) : c(std::move(c)), m(std::move(m)) {}
    prism_rtl::Turn<Map<Text, Rel>> cycle() const override;
};


/// The step machine of `StepRels`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StepRels: unbounded fn (Text ==> Rel), Expr, [Pattern], Nat -> (Text ==> Rel)
struct StepRels : prism_rtl::Job<Map<Text, Rel>> {
    Map<Text, Rel> m;
    crate::ast::Expr coll;
    Array<crate::ast::Pattern_> ps;
    Nat at_;
    StepRels(Map<Text, Rel> m, crate::ast::Expr coll, Array<crate::ast::Pattern_> ps, Nat at_) : m(std::move(m)), coll(std::move(coll)), ps(std::move(ps)), at_(std::move(at_)) {}
    prism_rtl::Turn<Map<Text, Rel>> cycle() const override;
};


/// The step machine of `ExprSpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ExprSpots: unbounded fn Expr, (Text ==> Rel) -> [Spot]
struct ExprSpots : prism_rtl::Job<Array<Spot>> {
    crate::ast::Expr e;
    Map<Text, Rel> m;
    ExprSpots(crate::ast::Expr e, Map<Text, Rel> m) : e(std::move(e)), m(std::move(m)) {}
    prism_rtl::Turn<Array<Spot>> cycle() const override;
};


/// The step machine of `KidSpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// KidSpots: unbounded fn Kid -> [Spot]
struct KidSpots : prism_rtl::Job<Array<Spot>> {
    Kid kid0;
    KidSpots(Kid kid0) : kid0(std::move(kid0)) {}
    prism_rtl::Turn<Array<Spot>> cycle() const override;
};


/// The step machine of `StmtsSpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StmtsSpots: unbounded fn [Stmt], (Text ==> Rel) -> [Spot]
struct StmtsSpots : prism_rtl::Job<Array<Spot>> {
    Array<crate::ast::Stmt> stmts;
    Map<Text, Rel> m;
    StmtsSpots(Array<crate::ast::Stmt> stmts, Map<Text, Rel> m) : stmts(std::move(stmts)), m(std::move(m)) {}
    prism_rtl::Turn<Array<Spot>> cycle() const override;
};


/// The step machine of `StmtSpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StmtSpots: unbounded fn Stmt, (Text ==> Rel) -> [Spot]
struct StmtSpots : prism_rtl::Job<Array<Spot>> {
    crate::ast::Stmt s;
    Map<Text, Rel> m;
    StmtSpots(crate::ast::Stmt s, Map<Text, Rel> m) : s(std::move(s)), m(std::move(m)) {}
    prism_rtl::Turn<Array<Spot>> cycle() const override;
};


/// The step machine of `BodySpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BodySpots: unbounded fn FnBody, (Text ==> Rel) -> [Spot]
struct BodySpots : prism_rtl::Job<Array<Spot>> {
    crate::ast::FnBody fn_body0;
    Map<Text, Rel> m;
    BodySpots(crate::ast::FnBody fn_body0, Map<Text, Rel> m) : fn_body0(std::move(fn_body0)), m(std::move(m)) {}
    prism_rtl::Turn<Array<Spot>> cycle() const override;
};


/// The step machine of `ExprKids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ExprKids: unbounded fn Expr, (Text ==> Rel) -> [Kid]
struct ExprKids : prism_rtl::Job<Array<Kid>> {
    crate::ast::Expr e;
    Map<Text, Rel> m;
    ExprKids(crate::ast::Expr e, Map<Text, Rel> m) : e(std::move(e)), m(std::move(m)) {}
    prism_rtl::Turn<Array<Kid>> cycle() const override;
};


/// The step machine of `StmtKids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StmtKids: unbounded fn Stmt, (Text ==> Rel) -> [Kid]
struct StmtKids : prism_rtl::Job<Array<Kid>> {
    crate::ast::Stmt s;
    Map<Text, Rel> m;
    StmtKids(crate::ast::Stmt s, Map<Text, Rel> m) : s(std::move(s)), m(std::move(m)) {}
    prism_rtl::Turn<Array<Kid>> cycle() const override;
};


/// The step machine of `CondKids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CondKids: unbounded fn Cond, (Text ==> Rel) -> [Kid]
struct CondKids : prism_rtl::Job<Array<Kid>> {
    crate::ast::Cond c;
    Map<Text, Rel> m;
    CondKids(crate::ast::Cond c, Map<Text, Rel> m) : c(std::move(c)), m(std::move(m)) {}
    prism_rtl::Turn<Array<Kid>> cycle() const override;
};


/// The step machine of `CallKids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CallKids: unbounded fn Expr, [Arg], (Text ==> Rel) -> [Kid]
struct CallKids : prism_rtl::Job<Array<Kid>> {
    crate::ast::Expr c;
    Array<crate::ast::Arg> args;
    Map<Text, Rel> m;
    CallKids(crate::ast::Expr c, Array<crate::ast::Arg> args, Map<Text, Rel> m) : c(std::move(c)), args(std::move(args)), m(std::move(m)) {}
    prism_rtl::Turn<Array<Kid>> cycle() const override;
};


/// The step machine of `AccKids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AccKids: unbounded fn (Text ==> Rel), Text, [Arg], Nat -> [Kid]
struct AccKids : prism_rtl::Job<Array<Kid>> {
    Map<Text, Rel> m;
    Text cn;
    Array<crate::ast::Arg> args;
    Nat i;
    AccKids(Map<Text, Rel> m, Text cn, Array<crate::ast::Arg> args, Nat i) : m(std::move(m)), cn(std::move(cn)), args(std::move(args)), i(std::move(i)) {}
    prism_rtl::Turn<Array<Kid>> cycle() const override;
};


/// The step machine of `TemplateKids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplateKids: unbounded fn [TemplatePart], (Text ==> Rel) -> [Kid]
struct TemplateKids : prism_rtl::Job<Array<Kid>> {
    Array<crate::ast::TemplatePart> parts;
    Map<Text, Rel> m;
    TemplateKids(Array<crate::ast::TemplatePart> parts, Map<Text, Rel> m) : parts(std::move(parts)), m(std::move(m)) {}
    prism_rtl::Turn<Array<Kid>> cycle() const override;
};


/// The step machine of `PatternsNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PatternsNames: unbounded fn [Pattern] -> [Text]
struct PatternsNames : prism_rtl::Job<Array<Text>> {
    Array<crate::ast::Pattern_> ps;
    PatternsNames(Array<crate::ast::Pattern_> ps) : ps(std::move(ps)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `BodySites`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BodySites: unbounded fn FnBody, (Text ==> Rel) -> [Site]
struct BodySites : prism_rtl::Job<Array<Site>> {
    crate::ast::FnBody body;
    Map<Text, Rel> m;
    BodySites(crate::ast::FnBody body, Map<Text, Rel> m) : body(std::move(body)), m(std::move(m)) {}
    prism_rtl::Turn<Array<Site>> cycle() const override;
};


/// The step machine of `SpotSites`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SpotSites: unbounded fn Spot -> [Site]
struct SpotSites : prism_rtl::Job<Array<Site>> {
    Spot spot0;
    SpotSites(Spot spot0) : spot0(std::move(spot0)) {}
    prism_rtl::Turn<Array<Site>> cycle() const override;
};


/// The step machine of `CallSites`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CallSites: unbounded fn Expr, [Arg], Range, (Text ==> Rel) -> [Site]
struct CallSites : prism_rtl::Job<Array<Site>> {
    crate::ast::Expr c;
    Array<crate::ast::Arg> args;
    crate::ast::Range span;
    Map<Text, Rel> m;
    CallSites(crate::ast::Expr c, Array<crate::ast::Arg> args, crate::ast::Range span, Map<Text, Rel> m) : c(std::move(c)), args(std::move(args)), span(std::move(span)), m(std::move(m)) {}
    prism_rtl::Turn<Array<Site>> cycle() const override;
};


/// The step machine of `SpotsNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SpotsNames: unbounded fn [Spot] -> [Text]
struct SpotsNames : prism_rtl::Job<Array<Text>> {
    Array<Spot> spots;
    SpotsNames(Array<Spot> spots) : spots(std::move(spots)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `SpotNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SpotNames: unbounded fn Spot -> [Text]
struct SpotNames : prism_rtl::Job<Array<Text>> {
    Spot sp;
    SpotNames(Spot sp) : sp(std::move(sp)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `RelOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?RelOf: unbounded fn (Text ==> Rel), Expr -> ?Rel
struct RelOf : prism_rtl::Job<std::optional<Rel>> {
    Map<Text, Rel> m;
    crate::ast::Expr e;
    RelOf(Map<Text, Rel> m, crate::ast::Expr e) : m(std::move(m)), e(std::move(e)) {}
    prism_rtl::Turn<std::optional<Rel>> cycle() const override;
};


/// The step machine of `RelOfCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?RelOfCall: unbounded fn (Text ==> Rel), Expr, [Arg] -> ?Rel
struct RelOfCall : prism_rtl::Job<std::optional<Rel>> {
    Map<Text, Rel> m;
    crate::ast::Expr c;
    Array<crate::ast::Arg> args;
    RelOfCall(Map<Text, Rel> m, crate::ast::Expr c, Array<crate::ast::Arg> args) : m(std::move(m)), c(std::move(c)), args(std::move(args)) {}
    prism_rtl::Turn<std::optional<Rel>> cycle() const override;
};


/// The step machine of `PartsSummaries`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PartsSummaries: unbounded fn Shrink, [Def] -> (Text ==> Nat)
struct PartsSummaries : prism_rtl::Job<Map<Text, Nat>> {
    Shrink sk;
    Array<crate::check_env::Def> fns;
    PartsSummaries(Shrink sk, Array<crate::check_env::Def> fns) : sk(std::move(sk)), fns(std::move(fns)) {}
    prism_rtl::Turn<Map<Text, Nat>> cycle() const override;
};


/// The step machine of `ClauseWithin`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClauseWithin: unbounded fn (Text ==> Rel), FnClause, Nat -> Bool
struct ClauseWithin : prism_rtl::Job<bool> {
    Map<Text, Rel> base;
    crate::ast::FnClause c;
    Nat i;
    ClauseWithin(Map<Text, Rel> base, crate::ast::FnClause c, Nat i) : base(std::move(base)), c(std::move(c)), i(std::move(i)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `Within`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Within: unbounded fn (Text ==> Rel), Nat, Expr -> Bool
struct Within : prism_rtl::Job<bool> {
    Map<Text, Rel> m;
    Nat i;
    crate::ast::Expr e;
    Within(Map<Text, Rel> m, Nat i, crate::ast::Expr e) : m(std::move(m)), i(std::move(i)), e(std::move(e)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `UpdateWithin`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdateWithin: unbounded fn (Text ==> Rel), Nat, Block -> Bool
struct UpdateWithin : prism_rtl::Job<bool> {
    Map<Text, Rel> m;
    Nat i;
    crate::ast::Block b;
    UpdateWithin(Map<Text, Rel> m, Nat i, crate::ast::Block b) : m(std::move(m)), i(std::move(i)), b(std::move(b)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `SpotKeepsWithin`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SpotKeepsWithin: unbounded fn Spot, Nat -> Bool
struct SpotKeepsWithin : prism_rtl::Job<bool> {
    Spot spot0;
    Nat n1;
    SpotKeepsWithin(Spot spot0, Nat n1) : spot0(std::move(spot0)), n1(std::move(n1)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `WithinBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WithinBlock: unbounded fn (Text ==> Rel), Nat, Block -> Bool
struct WithinBlock : prism_rtl::Job<bool> {
    Map<Text, Rel> m;
    Nat i;
    crate::ast::Block b;
    WithinBlock(Map<Text, Rel> m, Nat i, crate::ast::Block b) : m(std::move(m)), i(std::move(i)), b(std::move(b)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `StepWithin`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StepWithin: unbounded fn (Text ==> Rel), Nat, Text, Expr, Expr, Nat, Expr -> Bool
struct StepWithin : prism_rtl::Job<bool> {
    Map<Text, Rel> m;
    Nat i;
    Text f;
    crate::ast::Expr coll;
    crate::ast::Expr step_;
    Nat at_;
    crate::ast::Expr z;
    StepWithin(Map<Text, Rel> m, Nat i, Text f, crate::ast::Expr coll, crate::ast::Expr step_, Nat at_, crate::ast::Expr z) : m(std::move(m)), i(std::move(i)), f(std::move(f)), coll(std::move(coll)), step_(std::move(step_)), at_(std::move(at_)), z(std::move(z)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `BuildsOn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BuildsOn: unbounded fn (Text ==> Rel), Nat, Text, Expr -> Bool
struct BuildsOn : prism_rtl::Job<bool> {
    Map<Text, Rel> m;
    Nat i;
    Text acc;
    crate::ast::Expr e;
    BuildsOn(Map<Text, Rel> m, Nat i, Text acc, crate::ast::Expr e) : m(std::move(m)), i(std::move(i)), acc(std::move(acc)), e(std::move(e)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `BuildsOnCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BuildsOnCall: unbounded fn (Text ==> Rel), Nat, Text, Expr, [Arg] -> Bool
struct BuildsOnCall : prism_rtl::Job<bool> {
    Map<Text, Rel> m;
    Nat i;
    Text acc;
    crate::ast::Expr c;
    Array<crate::ast::Arg> args;
    BuildsOnCall(Map<Text, Rel> m, Nat i, Text acc, crate::ast::Expr c, Array<crate::ast::Arg> args) : m(std::move(m)), i(std::move(i)), acc(std::move(acc)), c(std::move(c)), args(std::move(args)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `BuildsOnBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BuildsOnBlock: unbounded fn (Text ==> Rel), Nat, Text, Block -> Bool
struct BuildsOnBlock : prism_rtl::Job<bool> {
    Map<Text, Rel> m;
    Nat i;
    Text acc;
    crate::ast::Block b;
    BuildsOnBlock(Map<Text, Rel> m, Nat i, Text acc, crate::ast::Block b) : m(std::move(m)), i(std::move(i)), acc(std::move(acc)), b(std::move(b)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `CondNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CondNames: unbounded fn Cond -> [Text]
struct CondNames : prism_rtl::Job<Array<Text>> {
    crate::ast::Cond cond0;
    CondNames(crate::ast::Cond cond0) : cond0(std::move(cond0)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `Part`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Part: unbounded fn (Text ==> Rel), Nat, Expr -> Bool
struct Part : prism_rtl::Job<bool> {
    Map<Text, Rel> m;
    Nat i;
    crate::ast::Expr e;
    Part(Map<Text, Rel> m, Nat i, crate::ast::Expr e) : m(std::move(m)), i(std::move(i)), e(std::move(e)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `SummarySeeds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SummarySeeds: unbounded fn Shrink, Def, [Spot], (Text ==> Rel) -> (Text ==> Rel)
struct SummarySeeds : prism_rtl::Job<Map<Text, Rel>> {
    Shrink sk;
    crate::check_env::Def d;
    Array<Spot> spots;
    Map<Text, Rel> rels;
    SummarySeeds(Shrink sk, crate::check_env::Def d, Array<Spot> spots, Map<Text, Rel> rels) : sk(std::move(sk)), d(std::move(d)), spots(std::move(spots)), rels(std::move(rels)) {}
    prism_rtl::Turn<Map<Text, Rel>> cycle() const override;
};


/// The step machine of `OptNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OptNames: unbounded fn ?Pattern -> [Text]
struct OptNames : prism_rtl::Job<Array<Text>> {
    std::optional<crate::ast::Pattern_> opt0;
    OptNames(std::optional<crate::ast::Pattern_> opt0) : opt0(std::move(opt0)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `DecrementOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?DecrementOf: unbounded fn (Text ==> Rel), Expr -> ?Rel
struct DecrementOf : prism_rtl::Job<std::optional<Rel>> {
    Map<Text, Rel> m;
    crate::ast::Expr e;
    DecrementOf(Map<Text, Rel> m, crate::ast::Expr e) : m(std::move(m)), e(std::move(e)) {}
    prism_rtl::Turn<std::optional<Rel>> cycle() const override;
};


/// The step machine of `Closure`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Closure: unbounded fn [Sc] -> [Sc]
struct Closure : prism_rtl::Job<Array<Sc>> {
    Array<Sc> graphs;
    Closure(Array<Sc> graphs) : graphs(std::move(graphs)) {}
    prism_rtl::Turn<Array<Sc>> cycle() const override;
};


/// The step machine of `ClosureFrom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClosureFrom: unbounded fn [Sc], [Sc], [Sc] -> [Sc]
struct ClosureFrom : prism_rtl::Job<Array<Sc>> {
    Array<Sc> base;
    Array<Sc> acc;
    Array<Sc> frontier;
    ClosureFrom(Array<Sc> base, Array<Sc> acc, Array<Sc> frontier) : base(std::move(base)), acc(std::move(acc)), frontier(std::move(frontier)) {}
    prism_rtl::Turn<Array<Sc>> cycle() const override;
};


/// The step machine of `LoopsOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LoopsOf: unbounded fn Shrink, St, Def -> St
struct LoopsOf : prism_rtl::Job<crate::check_types::St> {
    Shrink sk;
    crate::check_types::St st;
    crate::check_env::Def d;
    LoopsOf(Shrink sk, crate::check_types::St st, crate::check_env::Def d) : sk(std::move(sk)), st(std::move(st)), d(std::move(d)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `ClauseLoops`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClauseLoops: unbounded fn Shrink, St, Def, FnClause, Bool -> St
struct ClauseLoops : prism_rtl::Job<crate::check_types::St> {
    Shrink sk;
    crate::check_types::St st;
    crate::check_env::Def d;
    crate::ast::FnClause c;
    bool unb;
    ClauseLoops(Shrink sk, crate::check_types::St st, crate::check_env::Def d, crate::ast::FnClause c, bool unb) : sk(std::move(sk)), st(std::move(st)), d(std::move(d)), c(std::move(c)), unb(std::move(unb)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `CheckWhile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckWhile: unbounded fn St, Cond, Block, Range, Text, (Text ==> Rel), Bool -> St
struct CheckWhile : prism_rtl::Job<crate::check_types::St> {
    crate::check_types::St st;
    crate::ast::Cond c;
    crate::ast::Block body;
    crate::ast::Range span;
    Text name;
    Map<Text, Rel> seeds;
    bool unb;
    CheckWhile(crate::check_types::St st, crate::ast::Cond c, crate::ast::Block body, crate::ast::Range span, Text name, Map<Text, Rel> seeds, bool unb) : st(std::move(st)), c(std::move(c)), body(std::move(body)), span(std::move(span)), name(std::move(name)), seeds(std::move(seeds)), unb(std::move(unb)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `SetTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SetTargets: unbounded fn [Stmt] -> [Text]
struct SetTargets : prism_rtl::Job<Array<Text>> {
    Array<crate::ast::Stmt> stmts;
    SetTargets(Array<crate::ast::Stmt> stmts) : stmts(std::move(stmts)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `SpotSetRoot`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SpotSetRoot: unbounded fn Spot -> [Text]
struct SpotSetRoot : prism_rtl::Job<Array<Text>> {
    Spot spot0;
    SpotSetRoot(Spot spot0) : spot0(std::move(spot0)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `AllPathsStrict`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AllPathsStrict: unbounded fn [Stmt], Text, Nat, (Text ==> Rel) -> Bool
struct AllPathsStrict : prism_rtl::Job<bool> {
    Array<crate::ast::Stmt> stmts;
    Text v_;
    Nat vi;
    Map<Text, Rel> outer;
    AllPathsStrict(Array<crate::ast::Stmt> stmts, Text v_, Nat vi, Map<Text, Rel> outer) : stmts(std::move(stmts)), v_(std::move(v_)), vi(std::move(vi)), outer(std::move(outer)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `SetsWeak`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SetsWeak: unbounded fn [Stmt], Text, Nat, (Text ==> Rel) -> Bool
struct SetsWeak : prism_rtl::Job<bool> {
    Array<crate::ast::Stmt> stmts;
    Text v_;
    Nat vi;
    Map<Text, Rel> outer;
    SetsWeak(Array<crate::ast::Stmt> stmts, Text v_, Nat vi, Map<Text, Rel> outer) : stmts(std::move(stmts)), v_(std::move(v_)), vi(std::move(vi)), outer(std::move(outer)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `StmtSetsWeak`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StmtSetsWeak: unbounded fn Stmt, Text, Nat, (Text ==> Rel) -> Bool
struct StmtSetsWeak : prism_rtl::Job<bool> {
    crate::ast::Stmt s;
    Text v_;
    Nat vi;
    Map<Text, Rel> rels;
    StmtSetsWeak(crate::ast::Stmt s, Text v_, Nat vi, Map<Text, Rel> rels) : s(std::move(s)), v_(std::move(v_)), vi(std::move(vi)), rels(std::move(rels)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `SpotSetsWeak`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SpotSetsWeak: unbounded fn Spot, Text, Nat -> Bool
struct SpotSetsWeak : prism_rtl::Job<bool> {
    Spot spot0;
    Text text1;
    Nat n2;
    SpotSetsWeak(Spot spot0, Text text1, Nat n2) : spot0(std::move(spot0)), text1(std::move(text1)), n2(std::move(n2)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `SetsStrict`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SetsStrict: unbounded fn Expr, Text, Nat, (Text ==> Rel) -> Bool
struct SetsStrict : prism_rtl::Job<bool> {
    crate::ast::Expr e;
    Text v_;
    Nat vi;
    Map<Text, Rel> rels;
    SetsStrict(crate::ast::Expr e, Text v_, Nat vi, Map<Text, Rel> rels) : e(std::move(e)), v_(std::move(v_)), vi(std::move(vi)), rels(std::move(rels)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `RelStrict`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RelStrict: unbounded fn (Text ==> Rel), Expr, Nat -> Bool
struct RelStrict : prism_rtl::Job<bool> {
    Map<Text, Rel> rels;
    crate::ast::Expr e;
    Nat vi;
    RelStrict(Map<Text, Rel> rels, crate::ast::Expr e, Nat vi) : rels(std::move(rels)), e(std::move(e)), vi(std::move(vi)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `CallStrict`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CallStrict: unbounded fn Expr, Text, Nat, (Text ==> Rel) -> Bool
struct CallStrict : prism_rtl::Job<bool> {
    crate::ast::Expr e;
    Text v_;
    Nat vi;
    Map<Text, Rel> rels;
    CallStrict(crate::ast::Expr e, Text v_, Nat vi, Map<Text, Rel> rels) : e(std::move(e)), v_(std::move(v_)), vi(std::move(vi)), rels(std::move(rels)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `DischargeIncls`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DischargeIncls: unbounded fn G, St, Nat -> St
struct DischargeIncls : prism_rtl::Job<crate::check_types::St> {
    crate::check_env::G g;
    crate::check_types::St st;
    Nat from;
    DischargeIncls(crate::check_env::G g, crate::check_types::St st, Nat from) : g(std::move(g)), st(std::move(st)), from(std::move(from)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `Through`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Through: unbounded fn St, Incl, [Incl] -> Incl
struct Through : prism_rtl::Job<crate::check_types::Incl> {
    crate::check_types::St st;
    crate::check_types::Incl inc;
    Array<crate::check_types::Incl> batch;
    Through(crate::check_types::St st, crate::check_types::Incl inc, Array<crate::check_types::Incl> batch) : st(std::move(st)), inc(std::move(inc)), batch(std::move(batch)) {}
    prism_rtl::Turn<crate::check_types::Incl> cycle() const override;
};


/// The step machine of `DischargeOne`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DischargeOne: unbounded fn G, St, Incl -> St
struct DischargeOne : prism_rtl::Job<crate::check_types::St> {
    crate::check_env::G g;
    crate::check_types::St st;
    crate::check_types::Incl inc;
    DischargeOne(crate::check_env::G g, crate::check_types::St st, crate::check_types::Incl inc) : g(std::move(g)), st(std::move(st)), inc(std::move(inc)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `CheckProgram`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckProgram: unbounded fn [Src], [Module], [Text], Nat, Bool, Bool, [CDiag] -> Report
struct CheckProgram : prism_rtl::Job<Report_> {
    Array<crate::check_errors::Src> srcs;
    Array<crate::ast::Module> trees;
    Array<Text> world;
    Nat shown;
    bool recording;
    bool unused;
    Array<crate::check_errors::CDiag> pre;
    CheckProgram(Array<crate::check_errors::Src> srcs, Array<crate::ast::Module> trees, Array<Text> world, Nat shown, bool recording, bool unused, Array<crate::check_errors::CDiag> pre) : srcs(std::move(srcs)), trees(std::move(trees)), world(std::move(world)), shown(std::move(shown)), recording(std::move(recording)), unused(std::move(unused)), pre(std::move(pre)) {}
    prism_rtl::Turn<Report_> cycle() const override;
};


/// The step machine of `TypedOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TypedOf: unbounded fn G, St, Nat -> TProgram
struct TypedOf : prism_rtl::Job<crate::typed::TProgram> {
    crate::check_env::G g;
    crate::check_types::St st;
    Nat shown;
    TypedOf(crate::check_env::G g, crate::check_types::St st, Nat shown) : g(std::move(g)), st(std::move(st)), shown(std::move(shown)) {}
    prism_rtl::Turn<crate::typed::TProgram> cycle() const override;
};


/// The step machine of `ZonkScheme`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ZonkScheme: unbounded fn St, Scheme -> Scheme
struct ZonkScheme : prism_rtl::Job<crate::check_types::Scheme> {
    crate::check_types::St st;
    crate::check_types::Scheme sc;
    ZonkScheme(crate::check_types::St st, crate::check_types::Scheme sc) : st(std::move(st)), sc(std::move(sc)) {}
    prism_rtl::Turn<crate::check_types::Scheme> cycle() const override;
};


/// The step machine of `TopLets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TopLets: unbounded fn G, St -> ((G, St))
struct TopLets : prism_rtl::Job<std::tuple<crate::check_env::G, crate::check_types::St>> {
    crate::check_env::G g;
    crate::check_types::St st;
    TopLets(crate::check_env::G g, crate::check_types::St st) : g(std::move(g)), st(std::move(st)) {}
    prism_rtl::Turn<std::tuple<crate::check_env::G, crate::check_types::St>> cycle() const override;
};


/// The step machine of `CheckDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckDef: unbounded fn G, St, Def -> St
struct CheckDef : prism_rtl::Job<crate::check_types::St> {
    crate::check_env::G g;
    crate::check_types::St st;
    crate::check_env::Def d;
    CheckDef(crate::check_env::G g, crate::check_types::St st, crate::check_env::Def d) : g(std::move(g)), st(std::move(st)), d(std::move(d)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `DefaultDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DefaultDef: unbounded fn G, St -> St
struct DefaultDef : prism_rtl::Job<crate::check_types::St> {
    crate::check_env::G g;
    crate::check_types::St st;
    DefaultDef(crate::check_env::G g, crate::check_types::St st) : g(std::move(g)), st(std::move(st)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `CheckWidgetDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckWidgetDef: unbounded fn Env, St, Def, WidgetDecl -> St
struct CheckWidgetDef : prism_rtl::Job<crate::check_types::St> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    crate::check_env::Def d;
    crate::ast::WidgetDecl w;
    CheckWidgetDef(crate::check_expr::Env env, crate::check_types::St st, crate::check_env::Def d, crate::ast::WidgetDecl w) : env(std::move(env)), st(std::move(st)), d(std::move(d)), w(std::move(w)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `CheckMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckMethod: unbounded fn Env, St, Def, [FnClause], Text, ImplInfo -> St
struct CheckMethod : prism_rtl::Job<crate::check_types::St> {
    crate::check_expr::Env env;
    crate::check_types::St st;
    crate::check_env::Def d;
    Array<crate::ast::FnClause> clauses;
    Text cls;
    crate::check_env::ImplInfo im;
    CheckMethod(crate::check_expr::Env env, crate::check_types::St st, crate::check_env::Def d, Array<crate::ast::FnClause> clauses, Text cls, crate::check_env::ImplInfo im) : env(std::move(env)), st(std::move(st)), d(std::move(d)), clauses(std::move(clauses)), cls(std::move(cls)), im(std::move(im)) {}
    prism_rtl::Turn<crate::check_types::St> cycle() const override;
};


/// The step machine of `RootRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RootRow: unbounded fn G, St, [Text] -> ((Text, St))
struct RootRow : prism_rtl::Job<std::tuple<Text, crate::check_types::St>> {
    crate::check_env::G g;
    crate::check_types::St st;
    Array<Text> world;
    RootRow(crate::check_env::G g, crate::check_types::St st, Array<Text> world) : g(std::move(g)), st(std::move(st)), world(std::move(world)) {}
    prism_rtl::Turn<std::tuple<Text, crate::check_types::St>> cycle() const override;
};


}  // namespace check_passes

}  // namespace crate
