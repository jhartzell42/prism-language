// The module `Sexp`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "sexp.types.hpp"
#include "elem.types.hpp"
#include "ast.types.hpp"
#include "lexer.types.hpp"

namespace crate {

using namespace prelude;

namespace sexp {

Text nl(const Nat& d);

Text indent(const Nat& d);

template <class A>
Text spaced(const Array<A>& xs, const prism_rtl::Fn<prism_rtl::JobRef<Text>(A)>& f_fn);

Text path_(const Array<Text>& p_);

Text sname_text(const ast::SName& n);

Text sexp_module(const ast::Module& m);

Text sexp_row(const ast::Row_& r);

Text sexp_row_term(const ast::RowTerm& row_term0);

Text sexp_decl(const ast::Decl& d, const Nat& depth);

Text opt_type(const std::optional<ast::Type>& opt0);

Text check_pattern(const std::optional<ast::Pattern_>& opt0, const Nat& n1);

Text sexp_type_body(const std::optional<ast::TypeBody>& opt0, const Nat& n1);

Text sexp_signature(const ast::Signature& s);

Text sexp_def_name(const ast::DefName& def_name0);

Text sexp_bounds(const Array<ast::Bound>& bs);

Text sexp_fn(const ast::FnClause& f, const Nat& depth);

Text sexp_fields(const Array<ast::Field>& fs, const Nat& depth);

Text sexp_case(const ast::Case_& c);

Text sexp_items(const Array<ast::TraitItem>& items, const Nat& depth);

Text sexp_item(const ast::TraitItem& trait_item0, const Nat& n1);

Text sexp_test(const ast::TestDecl& t, const Nat& depth);

Text sexp_step(const ast::TestStep& s, const Nat& d);

Text sexp_action(const ast::StepAction& step_action0, const Nat& n1);

Text sexp_delivery(const ast::Delivery& x, const Nat& d);

Text sexp_target(const ast::Target& target0, const Nat& d);

Text sexp_path(const Text& word, const ast::TestPath& p_, const Nat& d);

Text sexp_path_seg(const ast::PathSeg& path_seg0, const Nat& n1);

Text sexp_check(const ast::TestCheck& c, const Nat& d);

Text sexp_block(const ast::Block& b, const Nat& d);

Text sexp_stmt(const ast::Stmt& s, const Nat& d);

Text sexp_cond(const ast::Cond& cond0, const Nat& d);

Text sexp_guard(const std::optional<ast::Expr>& opt0, const Nat& n1);

Text sexp_literal(const ast::Literal& l, const Nat& d);

bool all_plain_segs(const Array<ast::TextSeg>& segs);

bool is_plain_text_seg(const ast::TextSeg& text_seg0);

Text plain_seg_text(const ast::TextSeg& text_seg0);

Text sexp_seg(const ast::TextSeg& text_seg0, const Nat& n1);

Text sexp_args(const Array<ast::Arg>& args, const Nat& d);

Text arg_name(const std::optional<ast::Ident>& opt0);

Text sexp_exprs(const Array<ast::Expr>& es, const Nat& d);

Text sexp_expr(const ast::Expr& e, const Nat& d);

Text sexp_lambda_params(const std::optional<Array<ast::Pattern_>>& opt0, const Nat& n1);

Text sexp_lambda_body(const ast::LambdaBody& lambda_body0, const Nat& d);

Text sexp_else(const std::optional<ast::Block>& opt0, const Nat& n1);

Text sexp_arm(const ast::Arm& a, const Nat& d);

Text sexp_binders(const std::optional<ast::ForBinders>& opt0, const Nat& n1);

Text sexp_template(const ast::Template& t, const Nat& d);

Text sexp_parts(const Array<ast::TemplatePart>& parts, const Nat& d);

Text sexp_part(const ast::TemplatePart& template_part0, const Nat& n1);

Text column_text(const std::optional<Nat>& opt0);

Text call_parts(const std::optional<Array<ast::TemplatePart>>& opt0, const Nat& n1);

Text sexp_pattern(const ast::Pattern_& p_, const Nat& d);

Text sexp_type(const ast::Type& t);

Text color_text(const ast::Color& color0);

}  // namespace sexp



}  // namespace crate
