// The module `Process`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include <process/types.hpp>
#include "elem.types.hpp"

namespace crate {

using namespace prelude;




}  // namespace crate
