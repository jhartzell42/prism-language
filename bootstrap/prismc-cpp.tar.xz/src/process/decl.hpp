// The module `Process`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace process {

struct ProcessArgs;

struct ProcessEnv;

struct ProcessExit;

}  // namespace process

}  // namespace crate
