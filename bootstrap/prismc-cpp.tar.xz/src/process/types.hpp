// The module `Process`: its records, tags and newtypes (each after the types it holds) and its
// choices' cases, emitted by prismc (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include <process/decl.hpp>
#include "elem.decl.hpp"

namespace crate {

using namespace prelude;

namespace process {

/// The `Level` of `Process.Args`:
///
/// ```prism
/// tag Process.Args of Element [Text]
/// ```
struct ProcessArgs {
    using prism_value = void;
    /// The tag's qualified name, as its `Pod` carries it.
    static constexpr const char* TAG = "Process.Args";
    const ProcessArgs* operator->() const { return this; }
    ProcessArgs* operator->() { return this; }
    Pod to_pod() const;
    void show(Printer& p) const;
    bool operator==(const ProcessArgs&) const = default;
    static Result<ProcessArgs> from_pod(const Pod& p);
};


}  // namespace process

namespace process {

/// The `Level` of `Process.Exit`:
///
/// ```prism
/// tag Process.Exit of Element:
/// ```
struct ProcessExit {
    using prism_value = void;
    /// The tag's qualified name, as its `Pod` carries it.
    static constexpr const char* TAG = "Process.Exit";
    const ProcessExit* operator->() const { return this; }
    ProcessExit* operator->() { return this; }
    Pod to_pod() const;
    void show(Printer& p) const;
    bool operator==(const ProcessExit&) const = default;
    static Result<ProcessExit> from_pod(const Pod& p);
};


}  // namespace process


}  // namespace crate
