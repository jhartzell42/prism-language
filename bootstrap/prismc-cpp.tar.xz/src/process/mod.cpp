// The module `Process`, from `target/bootstrap/cpp-src/prelude/process/mod.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include <process/module.hpp>

namespace crate::process {

Pod ProcessArgs::to_pod() const {
    return Pod::element(TAG, {});
}


void ProcessArgs::show(Printer& p) const {
    prism_rtl::to_pod(*this).structure();
    Show<Pod>::show(prism_rtl::to_pod(*this), p);
}


Result<ProcessArgs> ProcessArgs::from_pod(const Pod& p) {
    if (auto t = p.tag(); t && *t == TAG) return ProcessArgs{};
    return mismatch<ProcessArgs>("a Process.Args", p);
}


Pod ProcessExit::to_pod() const {
    return Pod::element(TAG, {});
}


void ProcessExit::show(Printer& p) const {
    prism_rtl::to_pod(*this).structure();
    Show<Pod>::show(prism_rtl::to_pod(*this), p);
}


Result<ProcessExit> ProcessExit::from_pod(const Pod& p) {
    if (auto t = p.tag(); t && *t == TAG) return ProcessExit{};
    return mismatch<ProcessExit>("a Process.Exit", p);
}

}  // namespace crate::process
