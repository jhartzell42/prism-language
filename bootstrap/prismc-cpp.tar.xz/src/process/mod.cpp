// The module `Process`, from `target/bootstrap/cpp-src/prelude/process.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <process/module.hpp>

namespace crate::process {

Pod ProcessArgs::to_pod() const {
    return Pod::element(TAG, {});
}


void ProcessArgs::show(Printer& p) const {
    prism_rtl::to_pod(*this).structure();
    Show<Pod>::show(prism_rtl::to_pod(*this), p);
}


Result<ProcessArgs> ProcessArgs::from_pod(const Pod& p) {
    if (auto t = p.tag(); t && *t == TAG) return ProcessArgs{};
    return mismatch<ProcessArgs>("a Process.Args", p);
}


Pod ProcessEnv::to_pod() const {
    return Pod::element(TAG, {{"name", prism_rtl::to_pod(name)}});
}


void ProcessEnv::show(Printer& p) const {
    prism_rtl::to_pod(*this).structure();
    Show<Pod>::show(prism_rtl::to_pod(*this), p);
}


Result<ProcessEnv> ProcessEnv::from_pod(const Pod& p) {
    if (auto t = p.tag(); t && *t == TAG) return ProcessEnv{.name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(p, "name"))))};
    return mismatch<ProcessEnv>("a Process.Env", p);
}


Pod ProcessExit::to_pod() const {
    return Pod::element(TAG, {});
}


void ProcessExit::show(Printer& p) const {
    prism_rtl::to_pod(*this).structure();
    Show<Pod>::show(prism_rtl::to_pod(*this), p);
}


Result<ProcessExit> ProcessExit::from_pod(const Pod& p) {
    if (auto t = p.tag(); t && *t == TAG) return ProcessExit{};
    return mismatch<ProcessExit>("a Process.Exit", p);
}

}  // namespace crate::process
