// The module `Check.Env.Reading`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/env/reading/module.hpp>
#include <check/env/module.hpp>
#include <check/types/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Check.Env.Reading`, from `target/bootstrap/cpp-src/prismc/check/env/reading.prism`.
namespace crate::check::env::reading {

void Cx_::show(Printer& p) const {
    p.record("Cx", {{"g", g_p}, {"home", home_p}, {"scope", scope_p}, {"rowVars", row_vars_p}, {"unwritten", unwritten_p}});
}

Pod Cx_::to_pod() const {
    return Pod::record("Cx", {{"g", prism_rtl::to_pod(g_p)}, {"home", prism_rtl::to_pod(home_p)}, {"scope", prism_rtl::to_pod(scope_p)}, {"rowVars", prism_rtl::to_pod(row_vars_p)}, {"unwritten", prism_rtl::to_pod(unwritten_p)}});
}

Result<Cx_> Cx_::from_pod(const Pod& whole) {
    return Cx_{.g_p = TRY(prism_rtl::from_pod<crate::check::env::G>(TRY(crate::prelude::field(whole, "g")))), .home_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "home")))), .scope_p = TRY(prism_rtl::from_pod<crate::check::types::Rw>(TRY(crate::prelude::field(whole, "scope")))), .row_vars_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "rowVars")))), .unwritten_p = TRY(prism_rtl::from_pod<crate::check::types::Col>(TRY(crate::prelude::field(whole, "unwritten"))))};
}


/// CxOf: fn G, Text -> Cx
Cx_ cx_of_f(const crate::check::env::G& g_p0, const Text& m_p1) {
    auto info_p2 = crate::prelude::or_(crate::prelude::get(g_p0.mods_p, m_p1), crate::prelude::or_(crate::prelude::get(g_p0.mods_p, Text::lit("")), dummy_mod_p()));
    return Cx_{.g_p = g_p0, .home_p = m_p1, .scope_p = prism_rtl::deref(info_p2).emit_rw_p, .row_vars_p = prism_rtl::deref(info_p2).row_var_p == Text::lit("")
        ? Array<Text>{}
        : Array(std::vector{prism_rtl::deref(info_p2).row_var_p}), .unwritten_p = crate::check::types::Col(crate::check::types::Col::CBound{})};
}


/// let dummyMod
crate::check::env::ModInfo dummy_mod_p() {
    return crate::check::env::ModInfo{.name_p = Text::lit(""), .file_p = Nat(0u), .emit_rw_p = crate::check::types::empty_row_p(), .row_var_p = Text::lit(""), .uses_p = Array<std::tuple<Text, bool>>{}, .root_p = false, .tree_p = crate::check::env::empty_module_p()};
}


/// ConvType: unbounded fn Cx, St, Type -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_f(const Cx_& cx_p0, const crate::check::types::St& st_p1, const crate::syntax::Type& t_p2) {
    auto&& _m = prism_rtl::deref(t_p2.kind_p);
    if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
        auto&& n_p3 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& args_p4 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        auto [base_p5, st2_p6] = conv_named_f(cx_p0, st_p1, n_p3, args_p4, t_p2.span_p);
        return std::tuple{crate::check::types::with_marks_f(prism_rtl::deref(n_p3).sigils_p, base_p5, cx_p0.scope_p), st2_p6};
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m)) {
        auto&& sigils_p7 = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a0;
        auto&& inner_p8 = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a1;
        auto [i_p9, st2_pa] = conv_type_f(cx_p0, st_p1, prism_rtl::deref(prism_rtl::deref(inner_p8)));
        return std::tuple{crate::check::types::with_marks_f(sigils_p7, i_p9, cx_p0.scope_p), st2_pa};
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TArray>(_m)) {
        auto&& e_pb = prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a0;
        auto [i_pc, st2_pd] = conv_type_f(cx_p0, st_p1, prism_rtl::deref(prism_rtl::deref(e_pb)));
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(i_pc)}), st2_pd};
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TTuple>(_m)) {
        auto&& ts_pe = prism_rtl::as<crate::syntax::TypeKind::TTuple>(_m).a0;
        auto [xs_pf, st2_pg] = conv_types_f(cx_p0, st_p1, ts_pe);
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyTuple{xs_pf}), st2_pg};
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m)) {
        auto&& x_ph = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        return conv_type_f(cx_p0, st_p1, prism_rtl::deref(prism_rtl::deref(x_ph)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TMap>(_m)) {
        auto&& k_pi = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a0;
        auto&& v_pj = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a1;
        auto [kk_pk, st2_pl] = conv_type_f(cx_p0, st_p1, prism_rtl::deref(prism_rtl::deref(k_pi)));
        auto [vv_pm, st3_pn] = conv_type_f(cx_p0, st2_pl, prism_rtl::deref(prism_rtl::deref(v_pj)));
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(kk_pk), prism_rtl::rc(vv_pm)}), st3_pn};
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TFn>(_m)) {
        auto&& color_po = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a0;
        auto&& ps_pp = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res_pq = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        auto [xs_ps, st2_pt] = conv_types_f(cx_p0, st_p1, ps_pp);
        auto [r_pu, st3_pv] = conv_type_f(cx_p0, st2_pt, prism_rtl::deref(prism_rtl::deref(res_pq)));
        auto c_pr = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::Col> _v;
            if (prism_rtl::is<crate::syntax::Color::Bounded>(color_po)) {
                _v.set(cx_p0.unwritten_p);
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::Color::Unbounded>(color_po)) {
                _v.set(crate::check::types::Col(crate::check::types::Col::CUnbound{}));
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::Color::ColorVar>(color_po)) {
                auto&& v_p10 = prism_rtl::as<crate::syntax::Color::ColorVar>(color_po).a0;
                _v.set(prism_rtl::deref(v_p10).name_p == Text::lit("bounded")
                    ? crate::check::types::Col(crate::check::types::Col::CBound{})
                    : crate::check::types::Col(crate::check::types::Col::CQ{prism_rtl::deref(v_p10).name_p}));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyFn{c_pr, xs_ps, prism_rtl::rc(r_pu)}), st3_pv};
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TEmit>(_m)) {
        auto&& ty_p11 = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a0;
        auto&& row_t_p12 = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a1;
        auto [rw_p14, st2_p15] = conv_row_f(cx_p0, st_p1, prism_rtl::deref(prism_rtl::deref(row_t_p12)));
        auto inner_p13 = ({
            Cx_ this_ = cx_p0;
            this_.scope_p = rw_p14;
            (std::move(this_));
        });
        return conv_type_f(inner_p13, st2_p15, prism_rtl::deref(prism_rtl::deref(ty_p11)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TUnit>(_m)) {
        auto&& sigils_p16 = prism_rtl::as<crate::syntax::TypeKind::TUnit>(_m).a0;
        return std::tuple{crate::check::types::with_marks_f(sigils_p16, crate::check::types::t_unit_p(), cx_p0.scope_p), st_p1};
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TAny>(_m)) {
        auto&& tr_p17 = prism_rtl::as<crate::syntax::TypeKind::TAny>(_m).a0;
        auto&& _m = crate::check::env::names::resolve_trait_o(cx_p0.g_p, cx_p0.home_p, prism_rtl::deref(tr_p17).path_p);
        if (prism_rtl::is_some(_m)) {
            auto&& k_p18 = prism_rtl::some_of(_m);
            return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyAny{Array(std::vector{k_p18})}), st_p1};
        }
        if (prism_rtl::is_none(_m)) {
            return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("unknown-name"), prism_rtl::deref(tr_p17).span_p, prism_rtl::cat("no trait `^", crate::check::env::dotted_f(prism_rtl::deref(tr_p17).path_p), "`"))};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TAbsent>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("unsupported"), t_p2.span_p, Text::lit("this checker does not implement sparse tuples"))};
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TNonEmpty>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("unsupported"), t_p2.span_p, Text::lit("this checker does not implement non-empty arrays"))};
    }
    if (prism_rtl::is<crate::syntax::TypeKind::THole>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("unsupported"), t_p2.span_p, Text::lit("this checker does not implement higher-kinded traits"))};
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TFamily>(_m)) {
        auto&& q_p19 = prism_rtl::as<crate::syntax::TypeKind::TFamily>(_m).a0;
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("kind"), t_p2.span_p, prism_rtl::cat("`", crate::check::env::dotted_f(prism_rtl::deref(q_p19).path_p), ".*` is a row, not a type"))};
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TRowUnion>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("kind"), t_p2.span_p, Text::lit("a row is not a type"))};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> ConvType::cycle() const {
    const auto& cx_p0 = this->cx_p0;
    const auto& st_p1 = this->st_p1;
    const auto& t_p2 = this->t_p2;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(t_p2).kind_p);
        prism_rtl::is<crate::syntax::TypeKind::TName>(_m) ? ({
        auto&& n_p3 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& args_p4 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        ({
        auto args_p4x = args_p4;
        auto cx_p0x = cx_p0;
        auto n_p3x = n_p3;
        auto st_p1x = st_p1;
        auto t_p2x = t_p2;
        (crate::prelude::call_then(start_conv_named_f(cx_p0x, st_p1x, n_p3x, args_p4x, prism_rtl::deref(t_p2x).span_p), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_named_f_1482) {
        return ({
            auto [base_p5, st2_p6] = conv_named_f_1482;
            (prism_rtl::finished(std::tuple{crate::check::types::with_marks_f(prism_rtl::deref(n_p3x).sigils_p, base_p5, prism_rtl::deref(cx_p0x).scope_p), st2_p6}));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m) ? ({
        auto&& sigils_p7 = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a0;
        auto&& inner_p8 = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a1;
        ({
        auto cx_p0x = cx_p0;
        auto inner_p8x = prism_rtl::deref(prism_rtl::deref(inner_p8));
        auto sigils_p7x = sigils_p7;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(start_conv_type_f(cx_p0x, st_p1x, inner_p8x), [=, sigils_p7x = std::move(sigils_p7x)](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_f_1623) {
        return ({
            auto [i_p9, st2_pa] = conv_type_f_1623;
            (prism_rtl::finished(std::tuple{crate::check::types::with_marks_f(sigils_p7x, i_p9, prism_rtl::deref(cx_p0x).scope_p), st2_pa}));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TArray>(_m) ? ({
        auto&& e_pb = prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a0;
        ({
        auto cx_p0x = cx_p0;
        auto e_pbx = prism_rtl::deref(prism_rtl::deref(e_pb));
        auto st_p1x = st_p1;
        (crate::prelude::call_then(start_conv_type_f(cx_p0x, st_p1x, e_pbx), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_f_1742) {
        return ({
            auto [i_pc, st2_pd] = conv_type_f_1742;
            (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(i_pc)}), st2_pd}));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TTuple>(_m) ? ({
        auto&& ts_pe = prism_rtl::as<crate::syntax::TypeKind::TTuple>(_m).a0;
        ({
        auto cx_p0x = cx_p0;
        auto st_p1x = st_p1;
        auto ts_pex = ts_pe;
        (crate::prelude::call_then(start_conv_types_f(cx_p0x, st_p1x, ts_pex), [=](std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> conv_types_f_1829) {
        return ({
            auto [xs_pf, st2_pg] = conv_types_f_1829;
            (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyTuple{xs_pf}), st2_pg}));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m) ? ({
        auto&& x_ph = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ConvType(cx_p0, st_p1, prism_rtl::deref(prism_rtl::deref(x_ph)))));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TMap>(_m) ? ({
        auto&& k_pi = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a0;
        auto&& v_pj = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a1;
        ({
        auto cx_p0x = cx_p0;
        auto k_pix = prism_rtl::deref(prism_rtl::deref(k_pi));
        auto st_p1x = st_p1;
        auto v_pjx = prism_rtl::deref(prism_rtl::deref(v_pj));
        (crate::prelude::call_then(start_conv_type_f(cx_p0x, st_p1x, k_pix), [=, v_pjx = std::move(v_pjx)](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_f_1952) {
        return ({
            auto [kk_pk, st2_pl] = conv_type_f_1952;
            (crate::prelude::call_then(start_conv_type_f(cx_p0x, st2_pl, v_pjx), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_f_1997) {
            return ({
                auto [vv_pm, st3_pn] = conv_type_f_1997;
                (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(kk_pk), prism_rtl::rc(vv_pm)}), st3_pn}));
            });
        }));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TFn>(_m) ? ({
        auto&& color_po = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a0;
        auto&& ps_pp = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res_pq = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        ({
        auto color_pox = color_po;
        auto cx_p0x = cx_p0;
        auto ps_ppx = ps_pp;
        auto res_pqx = prism_rtl::deref(prism_rtl::deref(res_pq));
        auto st_p1x = st_p1;
        (crate::prelude::call_then(start_conv_types_f(cx_p0x, st_p1x, ps_ppx), [=, color_pox = std::move(color_pox), res_pqx = std::move(res_pqx)](std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> conv_types_f_2099) {
        return ({
            auto [xs_ps, st2_pt] = conv_types_f_2099;
            (crate::prelude::call_then(start_conv_type_f(cx_p0x, st2_pt, res_pqx), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_f_2145) {
            return ({
                auto [r_pu, st3_pv] = conv_type_f_2145;
                auto c_pr = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::check::types::Col> _v;
                    if (prism_rtl::is<crate::syntax::Color::Bounded>(color_pox)) {
                        _v.set(prism_rtl::deref(cx_p0x).unwritten_p);
                        goto _done;
                    }
                    if (prism_rtl::is<crate::syntax::Color::Unbounded>(color_pox)) {
                        _v.set(crate::check::types::Col(crate::check::types::Col::CUnbound{}));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::syntax::Color::ColorVar>(color_pox)) {
                        auto&& v_p10 = prism_rtl::as<crate::syntax::Color::ColorVar>(color_pox).a0;
                        _v.set(prism_rtl::deref(v_p10).name_p == Text::lit("bounded")
                            ? crate::check::types::Col(crate::check::types::Col::CBound{})
                            : crate::check::types::Col(crate::check::types::Col::CQ{prism_rtl::deref(v_p10).name_p}));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyFn{c_pr, xs_ps, prism_rtl::rc(r_pu)}), st3_pv}));
            });
        }));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TEmit>(_m) ? ({
        auto&& ty_p11 = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a0;
        auto&& row_t_p12 = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a1;
        ({
        auto cx_p0x = cx_p0;
        auto row_t_p12x = prism_rtl::deref(prism_rtl::deref(row_t_p12));
        auto st_p1x = st_p1;
        auto ty_p11x = prism_rtl::deref(prism_rtl::deref(ty_p11));
        (crate::prelude::call_then(start_conv_row_f(cx_p0x, st_p1x, row_t_p12x), [=, ty_p11x = std::move(ty_p11x)](std::tuple<crate::check::types::Rw, crate::check::types::St> conv_row_f_2412) {
        return ({
            auto [rw_p14, st2_p15] = conv_row_f_2412;
            auto inner_p13 = ({
                Cx_ this_ = cx_p0x;
                this_.scope_p = rw_p14;
                (std::move(this_));
            });
            (prism_rtl::more(prism_rtl::rc(ConvType(inner_p13, st2_p15, ty_p11x))));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TUnit>(_m) ? ({
        auto&& sigils_p16 = prism_rtl::as<crate::syntax::TypeKind::TUnit>(_m).a0;
        prism_rtl::finished(std::tuple{crate::check::types::with_marks_f(sigils_p16, crate::check::types::t_unit_p(), prism_rtl::deref(cx_p0).scope_p), st_p1});
    })
        : prism_rtl::is<crate::syntax::TypeKind::TAny>(_m) ? ({
        auto&& tr_p17 = prism_rtl::as<crate::syntax::TypeKind::TAny>(_m).a0;
        ({
        auto&& _m = crate::check::env::names::resolve_trait_o(prism_rtl::deref(cx_p0).g_p, prism_rtl::deref(cx_p0).home_p, prism_rtl::deref(tr_p17).path_p);
        prism_rtl::is_some(_m) ? ({
        auto&& k_p18 = prism_rtl::some_of(_m);
        prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyAny{Array(std::vector{k_p18})}), st_p1});
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("unknown-name"), prism_rtl::deref(tr_p17).span_p, prism_rtl::cat("no trait `^", crate::check::env::dotted_f(prism_rtl::deref(tr_p17).path_p), "`"))})
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TAbsent>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("unsupported"), prism_rtl::deref(t_p2).span_p, Text::lit("this checker does not implement sparse tuples"))})
        : prism_rtl::is<crate::syntax::TypeKind::TNonEmpty>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("unsupported"), prism_rtl::deref(t_p2).span_p, Text::lit("this checker does not implement non-empty arrays"))})
        : prism_rtl::is<crate::syntax::TypeKind::THole>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("unsupported"), prism_rtl::deref(t_p2).span_p, Text::lit("this checker does not implement higher-kinded traits"))})
        : prism_rtl::is<crate::syntax::TypeKind::TFamily>(_m) ? ({
        auto&& q_p19 = prism_rtl::as<crate::syntax::TypeKind::TFamily>(_m).a0;
        prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("kind"), prism_rtl::deref(t_p2).span_p, prism_rtl::cat("`", crate::check::env::dotted_f(prism_rtl::deref(q_p19).path_p), ".*` is a row, not a type"))});
    })
        : prism_rtl::is<crate::syntax::TypeKind::TRowUnion>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("kind"), prism_rtl::deref(t_p2).span_p, Text::lit("a row is not a type"))})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ConvType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_conv_type_f(Cx_ cx_p0, crate::check::types::St st_p1, crate::syntax::Type t_p2) {
    return prism_rtl::make_rc<ConvType>(cx_p0, st_p1, t_p2);
}


/// ConvTypes: unbounded fn Cx, St, [Type] -> (([Ty], St))
std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> conv_types_f(const Cx_& cx_p0, const crate::check::types::St& st_p1, const Array<crate::syntax::Type>& ts_p2) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(ts_p2, std::tuple{Array<crate::check::types::Ty>{}, st_p1}, ({
        auto cx_p0x = cx_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, crate::syntax::Type>)>>(prism_rtl::rc([=, cx_p0x = std::move(cx_p0x)](std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx_p0xy = cx_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, cx_p0xy = std::move(cx_p0xy)]() {
            return ({
                auto [acc_p3, s_p4] = p0;
                auto x_p5 = p1;
                (crate::prelude::call_then(start_conv_type_f(cx_p0xy, s_p4, x_p5), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_f_3422) {
                return ({
                    auto [y_p6, s2_p7] = conv_type_f_3422;
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc_p3, y_p6), s2_p7}));
                });
            }));
            });
        })));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>> ConvTypes::cycle() const {
    const auto& cx_p0 = this->cx_p0;
    const auto& st_p1 = this->st_p1;
    const auto& ts_p2 = this->ts_p2;
    return crate::prelude::fold_job(ts_p2, std::tuple{Array<crate::check::types::Ty>{}, st_p1}, ({
        auto cx_p0x = cx_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, crate::syntax::Type>)>>(prism_rtl::rc([=, cx_p0x = std::move(cx_p0x)](std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx_p0xy = cx_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, cx_p0xy = std::move(cx_p0xy)]() {
            return ({
                auto [acc_p3, s_p4] = p0;
                auto x_p5 = p1;
                (crate::prelude::call_then(start_conv_type_f(cx_p0xy, s_p4, x_p5), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_f_3422) {
                return ({
                    auto [y_p6, s2_p7] = conv_type_f_3422;
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc_p3, y_p6), s2_p7}));
                });
            }));
            });
        })));
        });
    }));
    }))->cycle();
}


/// `Start ConvTypes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>> start_conv_types_f(Cx_ cx_p0, crate::check::types::St st_p1, Array<crate::syntax::Type> ts_p2) {
    return prism_rtl::make_rc<ConvTypes>(cx_p0, st_p1, ts_p2);
}


/// ConvNamed: unbounded fn Cx, St, SName, [Type], Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> conv_named_f(const Cx_& cx_p0, const crate::check::types::St& st_p1, const crate::syntax::SName& n_p2, const Array<crate::syntax::Type>& args_p3, const crate::syntax::Range& span_p4) {
    auto name_p5 = crate::check::env::dotted_f(n_p2.path_p);
    return (crate::prelude::len(n_p2.path_p) == Nat(1u)) && crate::check::env::is_lower_text_f(name_p5)
        ? crate::prelude::len(args_p3) > Nat(0u)
        ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("unsupported"), span_p4, Text::lit("this checker does not implement higher-kinded traits"))}
        : std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyQ{name_p5}), st_p1}
        : (name_p5 == Text::lit("Element")) || (name_p5 == Text::lit("Prelude.Element"))
        ? ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
        auto&& _m = crate::prelude::len(args_p3);
        {
            auto&& m4019_0 = _m;
            if (m4019_0 == Nat(0u)) {
                _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyElem{cx_p0.scope_p, prism_rtl::rc(crate::check::types::t_unit_p())}), st_p1});
                goto _done;
            }
        }
        {
            auto&& m4019_1 = _m;
            if (m4019_1 == Nat(1u)) {
                _v.set(({
                    auto [o_p6, st2_p7] = conv_type_f(cx_p0, st_p1, crate::prelude::or_(crate::prelude::index(args_p3, Nat(0u)), dummy_type_p()));
                    std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyElem{cx_p0.scope_p, prism_rtl::rc(o_p6)}), st2_p7};
                }));
                goto _done;
            }
        }
        {
            auto&& m4019_2 = _m;
            if (m4019_2 == Nat(2u)) {
                _v.set(({
                    auto [rw_p8, st2_p9] = conv_row_f(cx_p0, st_p1, crate::prelude::or_(crate::prelude::index(args_p3, Nat(0u)), dummy_type_p()));
                    auto [o_pa, st3_pb] = conv_type_f(cx_p0, st2_p9, crate::prelude::or_(crate::prelude::index(args_p3, Nat(1u)), dummy_type_p()));
                    std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyElem{rw_p8, prism_rtl::rc(o_pa)}), st3_pb};
                }));
                goto _done;
            }
        }
        {
            _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("kind"), span_p4, prism_rtl::cat("`Element` takes a row and a type; here it has ", crate::check::errors::count_word_f(crate::prelude::len(args_p3))))});
            goto _done;
        }
    _done:
        _v.take();
    })
        : name_p5 == Text::lit("Elem")
        ? ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
        auto&& _m = crate::prelude::len(args_p3);
        {
            auto&& m4588_0 = _m;
            if (m4588_0 == Nat(0u)) {
                _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyElemAny{cx_p0.scope_p}), st_p1});
                goto _done;
            }
        }
        {
            auto&& m4588_1 = _m;
            if (m4588_1 == Nat(1u)) {
                _v.set(({
                    auto [rw_pc, st2_pd] = conv_row_f(cx_p0, st_p1, crate::prelude::or_(crate::prelude::index(args_p3, Nat(0u)), dummy_type_p()));
                    std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyElemAny{rw_pc}), st2_pd};
                }));
                goto _done;
            }
        }
        {
            _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("kind"), span_p4, prism_rtl::cat("`Elem` takes a row; here it has ", crate::check::errors::count_word_f(crate::prelude::len(args_p3))))});
            goto _done;
        }
    _done:
        _v.take();
    })
        : (name_p5 == Text::lit("Answer")) || (name_p5 == Text::lit("Wired"))
        ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{name_p5, Array<crate::check::types::Ty>{}}), st_p1}
        : name_p5 == Text::lit("Instant")
        ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("unsupported"), span_p4, Text::lit("this checker does not implement `Instant`"))}
        : crate::check::types::has_text_f(Array(std::vector{Text::lit("U16"), Text::lit("U32"), Text::lit("U64"), Text::lit("U128"), Text::lit("I8"), Text::lit("I16"), Text::lit("I32"), Text::lit("I64"), Text::lit("I128")}), name_p5)
        ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("unsupported"), span_p4, Text::lit("this checker does not implement sized integers other than `U8`"))}
        : crate::check::env::is_prim_type_f(name_p5)
        ? crate::prelude::len(args_p3) == Nat(0u)
        ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{name_p5, Array<crate::check::types::Ty>{}}), st_p1}
        : std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("kind"), span_p4, prism_rtl::cat("`", name_p5, "` takes no type; here it has ", crate::check::errors::count_word_f(crate::prelude::len(args_p3))))}
        : (name_p5 == Text::lit("Buffer")) || (name_p5 == Text::lit("Table"))
        ? ({
        auto want_pe = name_p5 == Text::lit("Buffer") ? Nat(1u) : Nat(2u);
        auto [xs_pf, st2_pg] = conv_types_f(cx_p0, st_p1, args_p3);
        crate::prelude::len(args_p3) == want_pe
        ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{name_p5, xs_pf}), st2_pg}
        : std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st2_pg, Text::lit("kind"), span_p4, prism_rtl::cat("`", name_p5, "` takes ", crate::check::errors::count_word_f(want_pe), " types; here it has ", crate::check::errors::count_word_f(crate::prelude::len(args_p3))))};
    })
        : ({
        auto [key_oh, why_pi] = crate::check::env::names::resolve_type_f(cx_p0.g_p, cx_p0.home_p, n_p2.path_p);
        ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
        if (prism_rtl::is_none(key_oh)) {
            _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("unknown-name"), span_p4, prism_rtl::cat("no type `", name_p5, "`"))});
            goto _done;
        }
        if (prism_rtl::is_some(key_oh)) {
            auto&& qk_pj = prism_rtl::some_of(key_oh);
            _v.set(({
                auto ti_pk = crate::prelude::or_(crate::prelude::get(prism_rtl::deref(cx_p0.g_p).types_p, qk_pj), crate::check::env::names::dummy_ty_info_p());
                auto st1_pl = why_pi == Text::lit("collision")
                    ? crate::check::types::recording::err_fix_f(st_p1, Text::lit("collision"), span_p4, prism_rtl::cat("`", name_p5, "` is declared by two modules this file reaches by a bare name"), prism_rtl::cat("write it qualified, `", qk_pj, "`, or rename this file\'s own"))
                    : st_p1;
                auto [xs_pm, st2_pn] = conv_types_f(cx_p0, st1_pl, args_p3);
                (crate::prelude::len(xs_pm) != crate::prelude::len(prism_rtl::deref(ti_pk).params_p)
                ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st2_pn, Text::lit("kind"), span_p4, prism_rtl::cat("`", name_p5, "` takes ", crate::check::errors::count_word_f(crate::prelude::len(prism_rtl::deref(ti_pk).params_p)), " type", crate::prelude::len(prism_rtl::deref(ti_pk).params_p) == Nat(1u)
                ? Text::lit("")
                : Text::lit("s"), "; here it has ", crate::check::errors::count_word_f(crate::prelude::len(xs_pm))))}
                : ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                auto&& _m = prism_rtl::deref(ti_pk).body_p;
                if (prism_rtl::is<crate::check::env::TyBody::BAlias>(_m)) {
                    auto&& body_po = prism_rtl::as<crate::check::env::TyBody::BAlias>(_m).a0;
                    _v.set(std::tuple{crate::check::types::schemes::subst_q_f(param_inst_f(prism_rtl::deref(ti_pk).params_p, xs_pm), body_po), st2_pn});
                    goto _done;
                }
                if (prism_rtl::is<crate::check::env::TyBody::BRowKind>(_m)) {
                    _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{qk_pj, xs_pm}), st2_pn});
                    goto _done;
                }
                {
                    _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{qk_pj, xs_pm}), st2_pn});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    });
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> ConvNamed::cycle() const {
    const auto& cx_p0 = this->cx_p0;
    const auto& st_p1 = this->st_p1;
    const auto& n_p2 = this->n_p2;
    const auto& args_p3 = this->args_p3;
    const auto& span_p4 = this->span_p4;
    auto name_p5 = crate::check::env::dotted_f(prism_rtl::deref(n_p2).path_p);
    return (crate::prelude::len(prism_rtl::deref(n_p2).path_p) == Nat(1u)) && crate::check::env::is_lower_text_f(name_p5)
        ? crate::prelude::len(args_p3) > Nat(0u)
        ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("unsupported"), span_p4, Text::lit("this checker does not implement higher-kinded traits"))})
        : prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyQ{name_p5}), st_p1})
        : (name_p5 == Text::lit("Element")) || (name_p5 == Text::lit("Prelude.Element"))
        ? ({
        auto&& _m = crate::prelude::len(args_p3);
        ({
        auto&& m4019_0 = _m;
        (m4019_0 == Nat(0u));
    }) ? ({
        auto&& m4019_0 = _m;
        prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyElem{prism_rtl::deref(cx_p0).scope_p, prism_rtl::rc(crate::check::types::t_unit_p())}), st_p1});
    })
        : ({
        auto&& m4019_1 = _m;
        (m4019_1 == Nat(1u));
    }) ? ({
        auto&& m4019_1 = _m;
        ({
        auto args_p3x = args_p3;
        auto cx_p0x = cx_p0;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(start_conv_type_f(cx_p0x, st_p1x, crate::prelude::or_(crate::prelude::index(args_p3x, Nat(0u)), dummy_type_p())), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_f_4131) {
        return ({
            auto [o_p6, st2_p7] = conv_type_f_4131;
            (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyElem{prism_rtl::deref(cx_p0x).scope_p, prism_rtl::rc(o_p6)}), st2_p7}));
        });
    }));
    });
    })
        : ({
        auto&& m4019_2 = _m;
        (m4019_2 == Nat(2u));
    }) ? ({
        auto&& m4019_2 = _m;
        ({
        auto args_p3x = args_p3;
        auto cx_p0x = cx_p0;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(start_conv_row_f(cx_p0x, st_p1x, crate::prelude::or_(crate::prelude::index(args_p3x, Nat(0u)), dummy_type_p())), [=](std::tuple<crate::check::types::Rw, crate::check::types::St> conv_row_f_4267) {
        return ({
            auto [rw_p8, st2_p9] = conv_row_f_4267;
            (crate::prelude::call_then(start_conv_type_f(cx_p0x, st2_p9, crate::prelude::or_(crate::prelude::index(args_p3x, Nat(1u)), dummy_type_p())), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_f_4340) {
            return ({
                auto [o_pa, st3_pb] = conv_type_f_4340;
                (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyElem{rw_p8, prism_rtl::rc(o_pa)}), st3_pb}));
            });
        }));
        });
    }));
    });
    })
        : prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("kind"), span_p4, prism_rtl::cat("`Element` takes a row and a type; here it has ", crate::check::errors::count_word_f(crate::prelude::len(args_p3))))});
    })
        : name_p5 == Text::lit("Elem")
        ? ({
        auto&& _m = crate::prelude::len(args_p3);
        ({
        auto&& m4588_0 = _m;
        (m4588_0 == Nat(0u));
    }) ? ({
        auto&& m4588_0 = _m;
        prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyElemAny{prism_rtl::deref(cx_p0).scope_p}), st_p1});
    })
        : ({
        auto&& m4588_1 = _m;
        (m4588_1 == Nat(1u));
    }) ? ({
        auto&& m4588_1 = _m;
        ({
        auto args_p3x = args_p3;
        auto cx_p0x = cx_p0;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(start_conv_row_f(cx_p0x, st_p1x, crate::prelude::or_(crate::prelude::index(args_p3x, Nat(0u)), dummy_type_p())), [=](std::tuple<crate::check::types::Rw, crate::check::types::St> conv_row_f_4695) {
        return ({
            auto [rw_pc, st2_pd] = conv_row_f_4695;
            (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyElemAny{rw_pc}), st2_pd}));
        });
    }));
    });
    })
        : prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("kind"), span_p4, prism_rtl::cat("`Elem` takes a row; here it has ", crate::check::errors::count_word_f(crate::prelude::len(args_p3))))});
    })
        : (name_p5 == Text::lit("Answer")) || (name_p5 == Text::lit("Wired"))
        ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{name_p5, Array<crate::check::types::Ty>{}}), st_p1})
        : name_p5 == Text::lit("Instant")
        ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("unsupported"), span_p4, Text::lit("this checker does not implement `Instant`"))})
        : crate::check::types::has_text_f(Array(std::vector{Text::lit("U16"), Text::lit("U32"), Text::lit("U64"), Text::lit("U128"), Text::lit("I8"), Text::lit("I16"), Text::lit("I32"), Text::lit("I64"), Text::lit("I128")}), name_p5)
        ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("unsupported"), span_p4, Text::lit("this checker does not implement sized integers other than `U8`"))})
        : crate::check::env::is_prim_type_f(name_p5)
        ? crate::prelude::len(args_p3) == Nat(0u)
        ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{name_p5, Array<crate::check::types::Ty>{}}), st_p1})
        : prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("kind"), span_p4, prism_rtl::cat("`", name_p5, "` takes no type; here it has ", crate::check::errors::count_word_f(crate::prelude::len(args_p3))))})
        : (name_p5 == Text::lit("Buffer")) || (name_p5 == Text::lit("Table"))
        ? ({
        auto want_pe = name_p5 == Text::lit("Buffer") ? Nat(1u) : Nat(2u);
        auto args_p3x = args_p3;
        auto cx_p0x = cx_p0;
        auto span_p4x = span_p4;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(start_conv_types_f(cx_p0x, st_p1x, args_p3x), [=, want_pe = std::move(want_pe), span_p4x = std::move(span_p4x)](std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> conv_types_f_5630) {
        return ({
            auto [xs_pf, st2_pg] = conv_types_f_5630;
            (crate::prelude::len(args_p3x) == want_pe
            ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{name_p5, xs_pf}), st2_pg})
            : prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st2_pg, Text::lit("kind"), span_p4x, prism_rtl::cat("`", name_p5, "` takes ", crate::check::errors::count_word_f(want_pe), " types; here it has ", crate::check::errors::count_word_f(crate::prelude::len(args_p3x))))}));
        });
    }));
    })
        : ({
        auto [key_oh, why_pi] = crate::check::env::names::resolve_type_f(prism_rtl::deref(cx_p0).g_p, prism_rtl::deref(cx_p0).home_p, prism_rtl::deref(n_p2).path_p);
        ({
        prism_rtl::is_none(key_oh) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("unknown-name"), span_p4, prism_rtl::cat("no type `", name_p5, "`"))})
        : prism_rtl::is_some(key_oh) ? ({
        auto&& qk_pj = prism_rtl::some_of(key_oh);
        ({
        auto ti_pk = crate::prelude::or_(crate::prelude::get(prism_rtl::deref(prism_rtl::deref(cx_p0).g_p).types_p, qk_pj), crate::check::env::names::dummy_ty_info_p());
        auto st1_pl = why_pi == Text::lit("collision")
            ? crate::check::types::recording::err_fix_f(st_p1, Text::lit("collision"), span_p4, prism_rtl::cat("`", name_p5, "` is declared by two modules this file reaches by a bare name"), prism_rtl::cat("write it qualified, `", qk_pj, "`, or rename this file\'s own"))
            : st_p1;
        auto args_p3x = args_p3;
        auto cx_p0x = cx_p0;
        auto qk_pjx = qk_pj;
        auto span_p4x = span_p4;
        (crate::prelude::call_then(start_conv_types_f(cx_p0x, st1_pl, args_p3x), [=, ti_pk = std::move(ti_pk), qk_pjx = std::move(qk_pjx), span_p4x = std::move(span_p4x)](std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> conv_types_f_6331) {
        return ({
            auto [xs_pm, st2_pn] = conv_types_f_6331;
            (crate::prelude::len(xs_pm) != crate::prelude::len(prism_rtl::deref(ti_pk).params_p)
            ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st2_pn, Text::lit("kind"), span_p4x, prism_rtl::cat("`", name_p5, "` takes ", crate::check::errors::count_word_f(crate::prelude::len(prism_rtl::deref(ti_pk).params_p)), " type", crate::prelude::len(prism_rtl::deref(ti_pk).params_p) == Nat(1u)
            ? Text::lit("")
            : Text::lit("s"), "; here it has ", crate::check::errors::count_word_f(crate::prelude::len(xs_pm))))})
            : ({
            auto&& _m = prism_rtl::deref(ti_pk).body_p;
            prism_rtl::is<crate::check::env::TyBody::BAlias>(_m) ? ({
            auto&& body_po = prism_rtl::as<crate::check::env::TyBody::BAlias>(_m).a0;
            ({
            auto body_pox = body_po;
            (crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(param_inst_f(prism_rtl::deref(ti_pk).params_p, xs_pm), body_pox), [=](crate::check::types::Ty subst_q_f_6655) { return prism_rtl::finished(std::tuple{subst_q_f_6655, st2_pn}); }));
        });
        })
            : prism_rtl::is<crate::check::env::TyBody::BRowKind>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{qk_pjx, xs_pm}), st2_pn})
            : prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{qk_pjx, xs_pm}), st2_pn});
        }));
        });
    }));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    });
}


/// `Start ConvNamed, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_conv_named_f(Cx_ cx_p0, crate::check::types::St st_p1, crate::syntax::SName n_p2, Array<crate::syntax::Type> args_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<ConvNamed>(cx_p0, st_p1, n_p2, args_p3, span_p4);
}


/// let dummyType
crate::syntax::Type dummy_type_p() {
    return crate::syntax::Type{.kind_p = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TAbsent{})), .span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}};
}


/// ParamInst: fn [Text], [Ty] -> Inst
crate::check::types::schemes::Inst param_inst_f(const Array<Text>& ps_p0, const Array<crate::check::types::Ty>& xs_p1) {
    return crate::check::types::schemes::Inst{.tys_p = crate::prelude::fold(crate::check::errors::range0_f(crate::prelude::len(ps_p0)), Map<Text, crate::check::types::Ty>{}, [&](const Map<Text, crate::check::types::Ty>& m_p2, const Nat& i_p3) { return crate::prelude::insert(m_p2, crate::prelude::or_(crate::prelude::index(ps_p0, i_p3), Text::lit("")), crate::prelude::or_(crate::prelude::index(xs_p1, i_p3), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))); }), .rows_p = Map<Text, crate::check::types::Tail>{}, .cols_p = Map<Text, crate::check::types::Col>{}};
}


/// ConvRow: unbounded fn Cx, St, Type -> ((Rw, St))
std::tuple<crate::check::types::Rw, crate::check::types::St> conv_row_f(const Cx_& cx_p0, const crate::check::types::St& st_p1, const crate::syntax::Type& t_p2) {
    auto [fams_p5, vars_p6, st2_p7] = row_parts_f(cx_p0, st_p1, t_p2);
    auto st3_p3 = crate::prelude::len(vars_p6) > Nat(1u)
        ? crate::check::types::recording::err_fix_f(st2_p7, Text::lit("row-two-tails"), t_p2.span_p, prism_rtl::cat("a row has one variable; `", crate::syntax::lexer::chars::join_f(vars_p6, Text::lit(" | ")), "` names two"), Text::lit("keep one variable"))
        : st2_p7;
    auto tail_p4 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::Tail> _v;
        auto&& _m = crate::prelude::index(vars_p6, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& v_p8 = prism_rtl::some_of(_m);
            _v.set(crate::check::types::Tail(crate::check::types::Tail::TlQ{v_p8}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::check::types::Tail(crate::check::types::Tail::TlClosed{}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return std::tuple{crate::check::types::Rw{.fams_p = crate::check::types::sort_texts_f(fams_p5), .minus_p = Array<Text>{}, .tail_p = tail_p4}, st3_p3};
}


prism_rtl::Turn<std::tuple<crate::check::types::Rw, crate::check::types::St>> ConvRow::cycle() const {
    const auto& cx_p0 = this->cx_p0;
    const auto& st_p1 = this->st_p1;
    const auto& t_p2 = this->t_p2;
    auto cx_p0x = cx_p0;
    auto st_p1x = st_p1;
    auto t_p2x = t_p2;
    return crate::prelude::call_then(start_row_parts_f(cx_p0x, st_p1x, t_p2x), [=](std::tuple<Array<Text>, Array<Text>, crate::check::types::St> row_parts_f_7214) {
        return ({
            auto [fams_p5, vars_p6, st2_p7] = row_parts_f_7214;
            auto st3_p3 = crate::prelude::len(vars_p6) > Nat(1u)
                ? crate::check::types::recording::err_fix_f(st2_p7, Text::lit("row-two-tails"), prism_rtl::deref(t_p2x).span_p, prism_rtl::cat("a row has one variable; `", crate::syntax::lexer::chars::join_f(vars_p6, Text::lit(" | ")), "` names two"), Text::lit("keep one variable"))
                : st2_p7;
            auto tail_p4 = ({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::Tail> _v;
                auto&& _m = crate::prelude::index(vars_p6, Nat(0u));
                if (prism_rtl::is_some(_m)) {
                    auto&& v_p8 = prism_rtl::some_of(_m);
                    _v.set(crate::check::types::Tail(crate::check::types::Tail::TlQ{v_p8}));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(crate::check::types::Tail(crate::check::types::Tail::TlClosed{}));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (prism_rtl::finished(std::tuple{crate::check::types::Rw{.fams_p = crate::check::types::sort_texts_f(fams_p5), .minus_p = Array<Text>{}, .tail_p = tail_p4}, st3_p3}));
        });
    });
}


/// `Start ConvRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Rw, crate::check::types::St>> start_conv_row_f(Cx_ cx_p0, crate::check::types::St st_p1, crate::syntax::Type t_p2) {
    return prism_rtl::make_rc<ConvRow>(cx_p0, st_p1, t_p2);
}


/// RowParts: unbounded fn Cx, St, Type -> (([Text], [Text], St))
std::tuple<Array<Text>, Array<Text>, crate::check::types::St> row_parts_f(const Cx_& cx_p0, const crate::check::types::St& st_p1, const crate::syntax::Type& t_p2) {
    auto&& _m = prism_rtl::deref(t_p2.kind_p);
    if (prism_rtl::is<crate::syntax::TypeKind::TRowUnion>(_m)) {
        auto&& ts_p3 = prism_rtl::as<crate::syntax::TypeKind::TRowUnion>(_m).a0;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ts_p3, std::tuple{Array<Text>{}, Array<Text>{}, st_p1}, ({
            auto cx_p0x = cx_p0;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Array<Text>, crate::check::types::St>>(std::tuple<std::tuple<Array<Text>, Array<Text>, crate::check::types::St>, crate::syntax::Type>)>>(prism_rtl::rc([=, cx_p0x = std::move(cx_p0x)](std::tuple<std::tuple<Array<Text>, Array<Text>, crate::check::types::St>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cx_p0xy = cx_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, cx_p0xy = std::move(cx_p0xy)]() {
                return ({
                    auto [fs_p4, vs_p5, s_p6] = p0;
                    auto x_p7 = p1;
                    (crate::prelude::call_then(start_row_parts_f(cx_p0xy, s_p6, x_p7), [=](std::tuple<Array<Text>, Array<Text>, crate::check::types::St> row_parts_f_7721) {
                    return ({
                        auto [f2_p8, v2_p9, s2_pa] = row_parts_f_7721;
                        (prism_rtl::finished(std::tuple{crate::prelude::append(fs_p4, f2_p8), crate::prelude::append(vs_p5, v2_p9), s2_pa}));
                    });
                }));
                });
            })));
            });
        }));
        })));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m)) {
        auto&& x_pb = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        return row_parts_f(cx_p0, st_p1, prism_rtl::deref(prism_rtl::deref(x_pb)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TFamily>(_m)) {
        auto&& q_pc = prism_rtl::as<crate::syntax::TypeKind::TFamily>(_m).a0;
        return std::tuple{Array(std::vector{crate::check::env::dotted_f(prism_rtl::deref(q_pc).path_p)}), Array<Text>{}, crate::check::env::names::check_family_f(cx_p0.g_p, st_p1, crate::check::env::dotted_f(prism_rtl::deref(q_pc).path_p), prism_rtl::deref(q_pc).span_p)};
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
        auto&& n_pd = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& m7611_3_1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        if (m7611_3_1.size() == 0u) {
            auto name_pe = crate::check::env::dotted_f(prism_rtl::deref(n_pd).path_p);
            return (crate::prelude::len(prism_rtl::deref(n_pd).path_p) == Nat(1u)) && crate::check::env::is_lower_text_f(name_pe)
                ? std::tuple{Array<Text>{}, Array(std::vector{name_pe}), st_p1}
                : name_pe == Text::lit("Element")
                ? std::tuple{prism_rtl::deref(cx_p0.scope_p).fams_p, tail_names_f(prism_rtl::deref(cx_p0.scope_p).tail_p), st_p1}
                : std::tuple{Array<Text>{}, Array<Text>{}, crate::check::types::recording::err_fix_f(st_p1, Text::lit("row-single-tag"), t_p2.span_p, prism_rtl::cat("a row names families, not tags: `", name_pe, "`"), prism_rtl::cat("write `", crate::check::env::dotted_f(crate::prelude::take(prism_rtl::deref(n_pd).path_p, crate::syntax::lexer::chars::dec_f(crate::prelude::len(prism_rtl::deref(n_pd).path_p)))), ".*`"))};
        }
    }
    {
        return std::tuple{Array<Text>{}, Array<Text>{}, crate::check::types::recording::err_f(st_p1, Text::lit("kind"), t_p2.span_p, Text::lit("this is not a row"))};
    }
}


prism_rtl::Turn<std::tuple<Array<Text>, Array<Text>, crate::check::types::St>> RowParts::cycle() const {
    const auto& cx_p0 = this->cx_p0;
    const auto& st_p1 = this->st_p1;
    const auto& t_p2 = this->t_p2;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(t_p2).kind_p);
        prism_rtl::is<crate::syntax::TypeKind::TRowUnion>(_m) ? ({
        auto&& ts_p3 = prism_rtl::as<crate::syntax::TypeKind::TRowUnion>(_m).a0;
        crate::prelude::fold_job(ts_p3, std::tuple{Array<Text>{}, Array<Text>{}, st_p1}, ({
        auto cx_p0x = cx_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Array<Text>, crate::check::types::St>>(std::tuple<std::tuple<Array<Text>, Array<Text>, crate::check::types::St>, crate::syntax::Type>)>>(prism_rtl::rc([=, cx_p0x = std::move(cx_p0x)](std::tuple<std::tuple<Array<Text>, Array<Text>, crate::check::types::St>, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx_p0xy = cx_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, cx_p0xy = std::move(cx_p0xy)]() {
            return ({
                auto [fs_p4, vs_p5, s_p6] = p0;
                auto x_p7 = p1;
                (crate::prelude::call_then(start_row_parts_f(cx_p0xy, s_p6, x_p7), [=](std::tuple<Array<Text>, Array<Text>, crate::check::types::St> row_parts_f_7721) {
                return ({
                    auto [f2_p8, v2_p9, s2_pa] = row_parts_f_7721;
                    (prism_rtl::finished(std::tuple{crate::prelude::append(fs_p4, f2_p8), crate::prelude::append(vs_p5, v2_p9), s2_pa}));
                });
            }));
            });
        })));
        });
    }));
    }))->cycle();
    })
        : prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m) ? ({
        auto&& x_pb = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(RowParts(cx_p0, st_p1, prism_rtl::deref(prism_rtl::deref(x_pb)))));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TFamily>(_m) ? ({
        auto&& q_pc = prism_rtl::as<crate::syntax::TypeKind::TFamily>(_m).a0;
        prism_rtl::finished(std::tuple{Array(std::vector{crate::check::env::dotted_f(prism_rtl::deref(q_pc).path_p)}), Array<Text>{}, crate::check::env::names::check_family_f(prism_rtl::deref(cx_p0).g_p, st_p1, crate::check::env::dotted_f(prism_rtl::deref(q_pc).path_p), prism_rtl::deref(q_pc).span_p)});
    })
        : prism_rtl::is<crate::syntax::TypeKind::TName>(_m) && ({
        auto&& n_pd = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& m7611_3_1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        (m7611_3_1.size() == 0u);
    }) ? ({
        auto&& n_pd = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& m7611_3_1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        ({
        auto name_pe = crate::check::env::dotted_f(prism_rtl::deref(n_pd).path_p);
        (crate::prelude::len(prism_rtl::deref(n_pd).path_p) == Nat(1u)) && crate::check::env::is_lower_text_f(name_pe)
        ? prism_rtl::finished(std::tuple{Array<Text>{}, Array(std::vector{name_pe}), st_p1})
        : name_pe == Text::lit("Element")
        ? prism_rtl::finished(std::tuple{prism_rtl::deref(prism_rtl::deref(cx_p0).scope_p).fams_p, tail_names_f(prism_rtl::deref(prism_rtl::deref(cx_p0).scope_p).tail_p), st_p1})
        : prism_rtl::finished(std::tuple{Array<Text>{}, Array<Text>{}, crate::check::types::recording::err_fix_f(st_p1, Text::lit("row-single-tag"), prism_rtl::deref(t_p2).span_p, prism_rtl::cat("a row names families, not tags: `", name_pe, "`"), prism_rtl::cat("write `", crate::check::env::dotted_f(crate::prelude::take(prism_rtl::deref(n_pd).path_p, crate::syntax::lexer::chars::dec_f(crate::prelude::len(prism_rtl::deref(n_pd).path_p)))), ".*`"))});
    });
    })
        : prism_rtl::finished(std::tuple{Array<Text>{}, Array<Text>{}, crate::check::types::recording::err_f(st_p1, Text::lit("kind"), prism_rtl::deref(t_p2).span_p, Text::lit("this is not a row"))});
    });
}


/// `Start RowParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<Text>, Array<Text>, crate::check::types::St>> start_row_parts_f(Cx_ cx_p0, crate::check::types::St st_p1, crate::syntax::Type t_p2) {
    return prism_rtl::make_rc<RowParts>(cx_p0, st_p1, t_p2);
}


/// TailNames: fn Tail -> [Text]
Array<Text> tail_names_f(const crate::check::types::Tail& tail0) {
    if (prism_rtl::is<crate::check::types::Tail::TlQ>(tail0)) {
        auto&& v_p0 = prism_rtl::as<crate::check::types::Tail::TlQ>(tail0).a0;
        return Array(std::vector{v_p0});
    }
    if (prism_rtl::is<crate::check::types::Tail::TlRigid>(tail0)) {
        auto&& v_p1 = prism_rtl::as<crate::check::types::Tail::TlRigid>(tail0).a0;
        return Array(std::vector{v_p1});
    }
    {
        return Array<Text>{};
    }
}


/// SigScheme: unbounded fn Cx, St, Type, [Bound] -> ((Scheme, St))
std::tuple<crate::check::types::Scheme, crate::check::types::St> sig_scheme_f(const Cx_& cx_p0, const crate::check::types::St& st_p1, const crate::syntax::Type& t_p2, const Array<crate::syntax::decls::Bound>& bounds_p3) {
    auto row_vars_p4 = crate::check::types::union_texts_f(cx_p0.row_vars_p, row_vars_of_type_f(t_p2));
    auto cx2_p5 = ({
        Cx_ this_ = cx_p0;
        this_.row_vars_p = row_vars_p4;
        this_.unwritten_p = crate::check::types::Col(crate::check::types::Col::CBound{});
        (std::move(this_));
    });
    auto written_p6 = color_vars_of_type_f(t_p2);
    auto [ty_pa, defaults_pb, joins_pc, st2_pd] = sig_type_f(cx2_p5, st_p1, t_p2, written_p6);
    auto tvs_p7 = crate::prelude::filter(type_vars_of_type_f(t_p2), [&](const Text& v_pe) { return !crate::check::types::has_text_f(row_vars_p4, v_pe); });
    auto cqs_p8 = crate::prelude::fold(defaults_pb, written_p6, [&](const Array<Text>& acc_pf, const Text& v_pg) { return crate::check::types::add_text_f(acc_pf, v_pg); });
    auto [bs_ph, st3_pi] = conv_bounds_f(cx_p0, st2_pd, bounds_p3);
    auto rows_used_p9 = crate::prelude::run_to_end(crate::prelude::filter_job(row_vars_p4, ({
        auto t_p2x = t_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, t_p2x = std::move(t_p2x)](Text p0) {
        return ({
            auto t_p2xy = t_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, t_p2xy = std::move(t_p2xy)]() {
            return ({
                auto v_pj = p0;
                (crate::prelude::call_then(start_row_vars_of_type_f(t_p2xy), [=, v_pj = std::move(v_pj)](Array<Text> row_vars_of_type_f_9242) { return prism_rtl::finished(crate::check::types::has_text_f(row_vars_of_type_f_9242, v_pj) || uses_scope_f(t_p2xy)); }));
            });
        })));
        });
    })));
    })));
    return std::tuple{crate::check::types::Scheme{.qs_p = tvs_p7, .plain_qs_p = Array<Text>{}, .rqs_p = rows_used_p9, .cqs_p = cqs_p8, .cjoins_p = joins_pc, .bounds_p = bs_ph, .ty_p = ty_pa}, st3_pi};
}


prism_rtl::Turn<std::tuple<crate::check::types::Scheme, crate::check::types::St>> SigScheme::cycle() const {
    const auto& cx_p0 = this->cx_p0;
    const auto& st_p1 = this->st_p1;
    const auto& t_p2 = this->t_p2;
    const auto& bounds_p3 = this->bounds_p3;
    auto bounds_p3x = bounds_p3;
    auto cx_p0x = cx_p0;
    auto st_p1x = st_p1;
    auto t_p2x = t_p2;
    return crate::prelude::call_then(start_row_vars_of_type_f(t_p2x), [=](Array<Text> row_vars_of_type_f_8803) {
        return ({
            auto row_vars_p4 = crate::check::types::union_texts_f(prism_rtl::deref(cx_p0x).row_vars_p, row_vars_of_type_f_8803);
            auto cx2_p5 = ({
                Cx_ this_ = cx_p0x;
                this_.row_vars_p = row_vars_p4;
                this_.unwritten_p = crate::check::types::Col(crate::check::types::Col::CBound{});
                (std::move(this_));
            });
            (crate::prelude::call_then(start_color_vars_of_type_f(t_p2x), [=, row_vars_p4 = std::move(row_vars_p4), cx2_p5 = std::move(cx2_p5)](Array<Text> color_vars_of_type_f_8924) {
            return ({
                auto written_p6 = color_vars_of_type_f_8924;
                (crate::prelude::call_then(start_sig_type_f(cx2_p5, st_p1x, t_p2x, written_p6), [=](std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St> sig_type_f_8981) {
                return ({
                    auto [ty_pa, defaults_pb, joins_pc, st2_pd] = sig_type_f_8981;
                    (crate::prelude::call_then(start_type_vars_of_type_f(t_p2x), [=](Array<Text> type_vars_of_type_f_9031) {
                    return ({
                        auto tvs_p7 = crate::prelude::filter(type_vars_of_type_f_9031, [&](const Text& v_pe) { return !crate::check::types::has_text_f(row_vars_p4, v_pe); });
                        auto cqs_p8 = crate::prelude::fold(defaults_pb, written_p6, [&](const Array<Text>& acc_pf, const Text& v_pg) { return crate::check::types::add_text_f(acc_pf, v_pg); });
                        auto [bs_ph, st3_pi] = conv_bounds_f(cx_p0x, st2_pd, bounds_p3x);
                        (crate::prelude::call_value(crate::prelude::filter_job(row_vars_p4, ({
                        auto t_p2xx = t_p2x;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, t_p2xx = std::move(t_p2xx)](Text p0) {
                        return ({
                            auto t_p2xxy = t_p2xx;
                            (crate::prelude::entered(crate::prelude::once_job([=, t_p2xxy = std::move(t_p2xxy)]() {
                            return ({
                                auto v_pj = p0;
                                (crate::prelude::call_then(start_row_vars_of_type_f(t_p2xxy), [=, v_pj = std::move(v_pj)](Array<Text> row_vars_of_type_f_9242) { return prism_rtl::finished(crate::check::types::has_text_f(row_vars_of_type_f_9242, v_pj) || uses_scope_f(t_p2xxy)); }));
                            });
                        })));
                        });
                    })));
                    })), [=, tvs_p7 = std::move(tvs_p7), cqs_p8 = std::move(cqs_p8)](Array<Text> filter_9211) {
                        return ({
                            auto rows_used_p9 = filter_9211;
                            (prism_rtl::finished(std::tuple{crate::check::types::Scheme{.qs_p = tvs_p7, .plain_qs_p = Array<Text>{}, .rqs_p = rows_used_p9, .cqs_p = cqs_p8, .cjoins_p = joins_pc, .bounds_p = bs_ph, .ty_p = ty_pa}, st3_pi}));
                        });
                    }));
                    });
                }));
                });
            }));
            });
        }));
        });
    });
}


/// `Start SigScheme, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Scheme, crate::check::types::St>> start_sig_scheme_f(Cx_ cx_p0, crate::check::types::St st_p1, crate::syntax::Type t_p2, Array<crate::syntax::decls::Bound> bounds_p3) {
    return prism_rtl::make_rc<SigScheme>(cx_p0, st_p1, t_p2, bounds_p3);
}


/// SigType: unbounded fn Cx, St, Type, [Text] -> ((Ty, [Text], [((Text, Text))], St))
std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St> sig_type_f(const Cx_& cx_p0, const crate::check::types::St& st_p1, const crate::syntax::Type& t_p2, const Array<Text>& written_p3) {
    auto&& _m = prism_rtl::deref(t_p2.kind_p);
    if (prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m)) {
        auto&& x_p4 = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        return sig_type_f(cx_p0, st_p1, prism_rtl::deref(prism_rtl::deref(x_p4)), written_p3);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TFn>(_m)) {
        auto&& color_p5 = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a0;
        auto&& ps_p6 = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res_p7 = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        return mentions_time_f(t_p2) || (!takes_closure_f(t_p2))
            ? bounded_sig_f(cx_p0, st_p1, t_p2)
            : closure_sig_f(cx_p0, st_p1, color_p5, ps_p6, prism_rtl::deref(prism_rtl::deref(res_p7)), written_p3);
    }
    {
        return bounded_sig_f(cx_p0, st_p1, t_p2);
    }
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> SigType::cycle() const {
    const auto& cx_p0 = this->cx_p0;
    const auto& st_p1 = this->st_p1;
    const auto& t_p2 = this->t_p2;
    const auto& written_p3 = this->written_p3;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(t_p2).kind_p);
        prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m) ? ({
        auto&& x_p4 = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(SigType(cx_p0, st_p1, prism_rtl::deref(prism_rtl::deref(x_p4)), written_p3)));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TFn>(_m) ? ({
        auto&& color_p5 = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a0;
        auto&& ps_p6 = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res_p7 = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        ({
        auto color_p5x = color_p5;
        auto cx_p0x = cx_p0;
        auto ps_p6x = ps_p6;
        auto res_p7x = prism_rtl::deref(prism_rtl::deref(res_p7));
        auto st_p1x = st_p1;
        auto t_p2x = t_p2;
        auto written_p3x = written_p3;
        (crate::prelude::call_then(start_mentions_time_f(t_p2x), [=, color_p5x = std::move(color_p5x), cx_p0x = std::move(cx_p0x), ps_p6x = std::move(ps_p6x), res_p7x = std::move(res_p7x), st_p1x = std::move(st_p1x), written_p3x = std::move(written_p3x)](bool mentions_time_f_10384) {
        return mentions_time_f_10384 || (!takes_closure_f(t_p2x))
            ? prism_rtl::more(prism_rtl::rc(BoundedSig(cx_p0x, st_p1x, t_p2x)))
            : prism_rtl::more(prism_rtl::rc(ClosureSig(cx_p0x, st_p1x, color_p5x, ps_p6x, res_p7x, written_p3x)));
    }));
    });
    })
        : prism_rtl::more(prism_rtl::rc(BoundedSig(cx_p0, st_p1, t_p2)));
    });
}


/// `Start SigType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> start_sig_type_f(Cx_ cx_p0, crate::check::types::St st_p1, crate::syntax::Type t_p2, Array<Text> written_p3) {
    return prism_rtl::make_rc<SigType>(cx_p0, st_p1, t_p2, written_p3);
}


/// BoundedSig: unbounded fn Cx, St, Type -> ((Ty, [Text], [((Text, Text))], St))
std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St> bounded_sig_f(const Cx_& cx_p0, const crate::check::types::St& st_p1, const crate::syntax::Type& t_p2) {
    auto [ty_p3, st2_p4] = conv_type_f(cx_p0, st_p1, t_p2);
    return std::tuple{ty_p3, Array<Text>{}, Array<std::tuple<Text, Text>>{}, st2_p4};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> BoundedSig::cycle() const {
    const auto& cx_p0 = this->cx_p0;
    const auto& st_p1 = this->st_p1;
    const auto& t_p2 = this->t_p2;
    auto cx_p0x = cx_p0;
    auto st_p1x = st_p1;
    auto t_p2x = t_p2;
    return crate::prelude::call_then(start_conv_type_f(cx_p0x, st_p1x, t_p2x), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_f_10665) {
        return ({
            auto [ty_p3, st2_p4] = conv_type_f_10665;
            (prism_rtl::finished(std::tuple{ty_p3, Array<Text>{}, Array<std::tuple<Text, Text>>{}, st2_p4}));
        });
    });
}


/// `Start BoundedSig, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> start_bounded_sig_f(Cx_ cx_p0, crate::check::types::St st_p1, crate::syntax::Type t_p2) {
    return prism_rtl::make_rc<BoundedSig>(cx_p0, st_p1, t_p2);
}


/// ClosureSig: unbounded fn Cx, St, Color, [Type], Type, [Text] -> ((Ty, [Text], [((Text, Text))], St))
std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St> closure_sig_f(const Cx_& cx_p0, const crate::check::types::St& st_p1, const crate::syntax::Color& color_p2, const Array<crate::syntax::Type>& ps_p3, const crate::syntax::Type& res_p4, const Array<Text>& written_p5) {
    auto [outer_set_ph, outer_w_pi] = written_col_f(color_p2);
    auto bounded_outer_p6 = outer_set_ph && (outer_w_pi == crate::check::types::Col(crate::check::types::Col::CBound{}));
    auto n_default_p7 = crate::prelude::len(crate::prelude::run_to_end(crate::prelude::filter_job(ps_p3, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::syntax::Type)>>(prism_rtl::rc([=](crate::syntax::Type p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto p_pj = p0;
                (crate::prelude::call_then(start_is_fn_type_f(p_pj), [=](bool is_fn_type_f_11003) { return prism_rtl::finished(is_fn_type_f_11003 && (!writes_col_f(top_color_f(p_pj)))); }));
            });
        }));
    })))));
    auto names_p8 = fresh_col_names_f(written_p5, std::move(bounded_outer_p6) ? Nat(0u) : n_default_p7);
    auto&& _pcols_pp = crate::prelude::run_to_end(crate::prelude::fold_job(ps_p3, std::tuple{Array<std::tuple<bool, crate::check::types::Col>>{}, Nat(0u)}, ({
        auto bounded_outer_p6x = std::move(bounded_outer_p6);
        auto names_p8x = names_p8;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<bool, crate::check::types::Col>>, Nat>>(std::tuple<std::tuple<Array<std::tuple<bool, crate::check::types::Col>>, Nat>, crate::syntax::Type>)>>(prism_rtl::rc([=, bounded_outer_p6x = std::move(bounded_outer_p6x), names_p8x = std::move(names_p8x)](std::tuple<std::tuple<Array<std::tuple<bool, crate::check::types::Col>>, Nat>, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto bounded_outer_p6xy = bounded_outer_p6x;
            auto names_p8xy = names_p8x;
            (crate::prelude::entered(crate::prelude::once_job([=, bounded_outer_p6xy = std::move(bounded_outer_p6xy), names_p8xy = std::move(names_p8xy)]() {
            return ({
                auto [acc_pk, k_pl] = p0;
                auto p_pm = p1;
                (crate::prelude::call_then(start_is_fn_type_f(p_pm), [=](bool is_fn_type_f_11280) {
                return !is_fn_type_f_11280
                    ? prism_rtl::finished(std::tuple{crate::prelude::push(acc_pk, std::tuple{false, crate::check::types::Col(crate::check::types::Col::CBound{})}), k_pl})
                    : crate::prelude::call_then(start_top_color_f(p_pm), [=](crate::syntax::Color top_color_f_11385) {
                    return ({
                        auto [set_pn, c_po] = written_col_f(top_color_f_11385);
                        set_pn
                        ? prism_rtl::finished(std::tuple{crate::prelude::push(acc_pk, std::tuple{true, c_po}), k_pl})
                        : bounded_outer_p6xy
                        ? prism_rtl::finished(std::tuple{crate::prelude::push(acc_pk, std::tuple{true, crate::check::types::Col(crate::check::types::Col::CBound{})}), k_pl})
                        : prism_rtl::finished(std::tuple{crate::prelude::push(acc_pk, std::tuple{true, crate::check::types::Col(crate::check::types::Col::CQ{crate::prelude::or_(crate::prelude::index(names_p8xy, k_pl), Text::lit("u"))})}), k_pl + Nat(1u)});
                    });
                });
            }));
            });
        })));
        });
    }));
    })));
    auto&& pcols_pp = std::get<0>(_pcols_pp);
    auto vars_p9 = crate::prelude::fold(pcols_pp, Array<Text>{}, [&](const Array<Text>& acc_pq, const std::tuple<bool, crate::check::types::Col>& _p1) {
        auto&& c_pr = std::get<1>(_p1);
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            if (prism_rtl::is<crate::check::types::Col::CQ>(c_pr)) {
                auto&& v_ps = prism_rtl::as<crate::check::types::Col::CQ>(c_pr).a0;
                _v.set(crate::check::types::add_text_f(acc_pq, v_ps));
                goto _done;
            }
            {
                _v.set(acc_pq);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto any_unbounded_pa = crate::prelude::fold(pcols_pp, false, [&](const bool& seen_pt, const std::tuple<bool, crate::check::types::Col>& _p1) {
        auto&& c_pu = std::get<1>(_p1);
        return prism_rtl::deref(seen_pt) || (c_pu == crate::check::types::Col(crate::check::types::Col::CUnbound{}));
    });
    auto spare_pb = fresh_col_names_f(crate::prelude::append(written_p5, names_p8), Nat(1u));
    auto outer_name_pc = (outer_set_ph || std::move(any_unbounded_pa)) || (crate::prelude::len(vars_p9) < Nat(2u))
        ? Text::lit("")
        : crate::prelude::or_(crate::prelude::index(spare_pb, Nat(0u)), Text::lit("u"));
    auto outer_pd = outer_set_ph
        ? outer_w_pi
        : std::move(any_unbounded_pa)
        ? crate::check::types::Col(crate::check::types::Col::CUnbound{})
        : crate::prelude::len(vars_p9) == Nat(0u)
        ? crate::check::types::Col(crate::check::types::Col::CBound{})
        : crate::prelude::len(vars_p9) == Nat(1u)
        ? crate::check::types::Col(crate::check::types::Col::CQ{crate::prelude::or_(crate::prelude::index(vars_p9, Nat(0u)), Text::lit("u"))})
        : crate::check::types::Col(crate::check::types::Col::CQ{outer_name_pc});
    auto joins_pe = ({
        __label__ _done;
        prism_rtl::Slot<Array<std::tuple<Text, Text>>> _v;
        if (prism_rtl::is<crate::check::types::Col::CQ>(outer_pd)) {
            auto&& hi_pv = prism_rtl::as<crate::check::types::Col::CQ>(outer_pd).a0;
            _v.set(crate::prelude::each(crate::prelude::filter(vars_p9, [&](const Text& v_p10) { return v_p10 != hi_pv; }), [&](const Text& v_p11) { return std::tuple{v_p11, hi_pv}; }));
            goto _done;
        }
        {
            _v.set(Array<std::tuple<Text, Text>>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto cx_outer_pf = with_unwritten_f(cx_p0, outer_pd);
    auto [xs_p1b, st2_p1c] = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(ps_p3)), std::tuple{Array<crate::check::types::Ty>{}, st_p1}, ({
        auto ps_p3x = ps_p3;
        auto res_p4x = res_p4;
        auto pcols_ppx = pcols_pp;
        auto cx_p0x = cx_p0;
        auto cx_outer_pfx = cx_outer_pf;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, ps_p3x = std::move(ps_p3x), res_p4x = std::move(res_p4x), pcols_ppx = std::move(pcols_ppx), cx_p0x = std::move(cx_p0x), cx_outer_pfx = std::move(cx_outer_pfx)](std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto ps_p3xy = ps_p3x;
            auto res_p4xy = res_p4x;
            auto pcols_ppxy = pcols_ppx;
            auto cx_p0xy = cx_p0x;
            auto cx_outer_pfxy = cx_outer_pfx;
            (crate::prelude::entered(crate::prelude::once_job([=, ps_p3xy = std::move(ps_p3xy), res_p4xy = std::move(res_p4xy), pcols_ppxy = std::move(pcols_ppxy), cx_p0xy = std::move(cx_p0xy), cx_outer_pfxy = std::move(cx_outer_pfxy)]() {
            return ({
                auto [acc_p12, s_p13] = p0;
                auto i_p14 = p1;
                ({
                auto p_p15 = crate::prelude::or_(crate::prelude::index(ps_p3xy, i_p14), res_p4xy);
                auto [is_fn_p17, c_p18] = crate::prelude::or_(crate::prelude::index(pcols_ppxy, i_p14), std::tuple{false, crate::check::types::Col(crate::check::types::Col::CBound{})});
                auto pcx_p16 = is_fn_p17 ? with_unwritten_f(cx_p0xy, c_p18) : cx_outer_pfxy;
                (crate::prelude::call_then(start_conv_type_f(pcx_p16, s_p13, p_p15), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_f_12554) {
                return ({
                    auto [y_p19, s2_p1a] = conv_type_f_12554;
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc_p12, y_p19), s2_p1a}));
                });
            }));
            });
            });
        })));
        });
    }));
    })));
    auto [r_p1d, st3_p1e] = conv_type_f(cx_outer_pf, st2_p1c, res_p4);
    auto added_pg = outer_name_pc == Text::lit("")
        ? names_p8
        : crate::prelude::push(names_p8, outer_name_pc);
    return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyFn{outer_pd, xs_p1b, prism_rtl::rc(r_p1d)}), added_pg, joins_pe, st3_p1e};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> ClosureSig::cycle() const {
    const auto& cx_p0 = this->cx_p0;
    const auto& st_p1 = this->st_p1;
    const auto& color_p2 = this->color_p2;
    const auto& ps_p3 = this->ps_p3;
    const auto& res_p4 = this->res_p4;
    const auto& written_p5 = this->written_p5;
    auto [outer_set_ph, outer_w_pi] = written_col_f(color_p2);
    auto bounded_outer_p6 = outer_set_ph && (outer_w_pi == crate::check::types::Col(crate::check::types::Col::CBound{}));
    auto color_p2x = color_p2;
    auto cx_p0x = cx_p0;
    auto ps_p3x = ps_p3;
    auto res_p4x = res_p4;
    auto st_p1x = st_p1;
    auto written_p5x = written_p5;
    return crate::prelude::call_value(crate::prelude::filter_job(ps_p3x, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::syntax::Type)>>(prism_rtl::rc([=](crate::syntax::Type p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto p_pj = p0;
                (crate::prelude::call_then(start_is_fn_type_f(p_pj), [=](bool is_fn_type_f_11003) { return prism_rtl::finished(is_fn_type_f_11003 && (!writes_col_f(top_color_f(p_pj)))); }));
            });
        }));
    }))), [=](Array<crate::syntax::Type> filter_10986) {
        return ({
            auto n_default_p7 = crate::prelude::len(filter_10986);
            (crate::prelude::call_then(start_fresh_col_names_f(written_p5x, bounded_outer_p6 ? Nat(0u) : n_default_p7), [=](Array<Text> fresh_col_names_f_11065) {
            return ({
                auto names_p8 = fresh_col_names_f_11065;
                (crate::prelude::call_value(crate::prelude::fold_job(ps_p3x, std::tuple{Array<std::tuple<bool, crate::check::types::Col>>{}, Nat(0u)}, ({
                auto bounded_outer_p6x = bounded_outer_p6;
                auto names_p8x = names_p8;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<bool, crate::check::types::Col>>, Nat>>(std::tuple<std::tuple<Array<std::tuple<bool, crate::check::types::Col>>, Nat>, crate::syntax::Type>)>>(prism_rtl::rc([=, bounded_outer_p6x = std::move(bounded_outer_p6x), names_p8x = std::move(names_p8x)](std::tuple<std::tuple<Array<std::tuple<bool, crate::check::types::Col>>, Nat>, crate::syntax::Type> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto bounded_outer_p6xy = bounded_outer_p6x;
                    auto names_p8xy = names_p8x;
                    (crate::prelude::entered(crate::prelude::once_job([=, bounded_outer_p6xy = std::move(bounded_outer_p6xy), names_p8xy = std::move(names_p8xy)]() {
                    return ({
                        auto [acc_pk, k_pl] = p0;
                        auto p_pm = p1;
                        (crate::prelude::call_then(start_is_fn_type_f(p_pm), [=](bool is_fn_type_f_11280) {
                        return !is_fn_type_f_11280
                            ? prism_rtl::finished(std::tuple{crate::prelude::push(acc_pk, std::tuple{false, crate::check::types::Col(crate::check::types::Col::CBound{})}), k_pl})
                            : crate::prelude::call_then(start_top_color_f(p_pm), [=](crate::syntax::Color top_color_f_11385) {
                            return ({
                                auto [set_pn, c_po] = written_col_f(top_color_f_11385);
                                set_pn
                                ? prism_rtl::finished(std::tuple{crate::prelude::push(acc_pk, std::tuple{true, c_po}), k_pl})
                                : bounded_outer_p6xy
                                ? prism_rtl::finished(std::tuple{crate::prelude::push(acc_pk, std::tuple{true, crate::check::types::Col(crate::check::types::Col::CBound{})}), k_pl})
                                : prism_rtl::finished(std::tuple{crate::prelude::push(acc_pk, std::tuple{true, crate::check::types::Col(crate::check::types::Col::CQ{crate::prelude::or_(crate::prelude::index(names_p8xy, k_pl), Text::lit("u"))})}), k_pl + Nat(1u)});
                            });
                        });
                    }));
                    });
                })));
                });
            }));
            })), [=](std::tuple<Array<std::tuple<bool, crate::check::types::Col>>, Nat> fold_11225) {
                return ({
                    auto&& _pcols_pp = fold_11225;
                    auto&& pcols_pp = std::get<0>(_pcols_pp);
                    auto vars_p9 = crate::prelude::fold(pcols_pp, Array<Text>{}, [&](const Array<Text>& acc_pq, const std::tuple<bool, crate::check::types::Col>& _p1) {
                        auto&& c_pr = std::get<1>(_p1);
                        return ({
                            __label__ _done;
                            prism_rtl::Slot<Array<Text>> _v;
                            if (prism_rtl::is<crate::check::types::Col::CQ>(c_pr)) {
                                auto&& v_ps = prism_rtl::as<crate::check::types::Col::CQ>(c_pr).a0;
                                _v.set(crate::check::types::add_text_f(acc_pq, v_ps));
                                goto _done;
                            }
                            {
                                _v.set(acc_pq);
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                    });
                    auto any_unbounded_pa = crate::prelude::fold(pcols_pp, false, [&](const bool& seen_pt, const std::tuple<bool, crate::check::types::Col>& _p1) {
                        auto&& c_pu = std::get<1>(_p1);
                        return prism_rtl::deref(seen_pt) || (c_pu == crate::check::types::Col(crate::check::types::Col::CUnbound{}));
                    });
                    (crate::prelude::call_then(start_fresh_col_names_f(crate::prelude::append(written_p5x, names_p8), Nat(1u)), [=, vars_p9 = std::move(vars_p9), any_unbounded_pa = std::move(any_unbounded_pa)](Array<Text> fresh_col_names_f_11813) {
                    return ({
                        auto spare_pb = fresh_col_names_f_11813;
                        auto outer_name_pc = (outer_set_ph || any_unbounded_pa) || (crate::prelude::len(vars_p9) < Nat(2u))
                            ? Text::lit("")
                            : crate::prelude::or_(crate::prelude::index(spare_pb, Nat(0u)), Text::lit("u"));
                        auto outer_pd = outer_set_ph
                            ? outer_w_pi
                            : any_unbounded_pa
                            ? crate::check::types::Col(crate::check::types::Col::CUnbound{})
                            : crate::prelude::len(vars_p9) == Nat(0u)
                            ? crate::check::types::Col(crate::check::types::Col::CBound{})
                            : crate::prelude::len(vars_p9) == Nat(1u)
                            ? crate::check::types::Col(crate::check::types::Col::CQ{crate::prelude::or_(crate::prelude::index(vars_p9, Nat(0u)), Text::lit("u"))})
                            : crate::check::types::Col(crate::check::types::Col::CQ{outer_name_pc});
                        auto joins_pe = ({
                            __label__ _done;
                            prism_rtl::Slot<Array<std::tuple<Text, Text>>> _v;
                            if (prism_rtl::is<crate::check::types::Col::CQ>(outer_pd)) {
                                auto&& hi_pv = prism_rtl::as<crate::check::types::Col::CQ>(outer_pd).a0;
                                _v.set(crate::prelude::each(crate::prelude::filter(vars_p9, [&](const Text& v_p10) { return v_p10 != hi_pv; }), [&](const Text& v_p11) { return std::tuple{v_p11, hi_pv}; }));
                                goto _done;
                            }
                            {
                                _v.set(Array<std::tuple<Text, Text>>{});
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                        auto cx_outer_pf = with_unwritten_f(cx_p0x, outer_pd);
                        (crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(ps_p3x)), std::tuple{Array<crate::check::types::Ty>{}, st_p1x}, ({
                        auto ps_p3xx = ps_p3x;
                        auto res_p4xx = res_p4x;
                        auto pcols_ppx = pcols_pp;
                        auto cx_p0xx = cx_p0x;
                        auto cx_outer_pfx = cx_outer_pf;
                        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, ps_p3xx = std::move(ps_p3xx), res_p4xx = std::move(res_p4xx), pcols_ppx = std::move(pcols_ppx), cx_p0xx = std::move(cx_p0xx), cx_outer_pfx = std::move(cx_outer_pfx)](std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, Nat> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto ps_p3xxy = ps_p3xx;
                            auto res_p4xxy = res_p4xx;
                            auto pcols_ppxy = pcols_ppx;
                            auto cx_p0xxy = cx_p0xx;
                            auto cx_outer_pfxy = cx_outer_pfx;
                            (crate::prelude::entered(crate::prelude::once_job([=, ps_p3xxy = std::move(ps_p3xxy), res_p4xxy = std::move(res_p4xxy), pcols_ppxy = std::move(pcols_ppxy), cx_p0xxy = std::move(cx_p0xxy), cx_outer_pfxy = std::move(cx_outer_pfxy)]() {
                            return ({
                                auto [acc_p12, s_p13] = p0;
                                auto i_p14 = p1;
                                ({
                                auto p_p15 = crate::prelude::or_(crate::prelude::index(ps_p3xxy, i_p14), res_p4xxy);
                                auto [is_fn_p17, c_p18] = crate::prelude::or_(crate::prelude::index(pcols_ppxy, i_p14), std::tuple{false, crate::check::types::Col(crate::check::types::Col::CBound{})});
                                auto pcx_p16 = is_fn_p17 ? with_unwritten_f(cx_p0xxy, c_p18) : cx_outer_pfxy;
                                (crate::prelude::call_then(start_conv_type_f(pcx_p16, s_p13, p_p15), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_f_12554) {
                                return ({
                                    auto [y_p19, s2_p1a] = conv_type_f_12554;
                                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc_p12, y_p19), s2_p1a}));
                                });
                            }));
                            });
                            });
                        })));
                        });
                    }));
                    })), [=, outer_name_pc = std::move(outer_name_pc), outer_pd = std::move(outer_pd), joins_pe = std::move(joins_pe)](std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> fold_12327) {
                        return ({
                            auto [xs_p1b, st2_p1c] = fold_12327;
                            (crate::prelude::call_then(start_conv_type_f(cx_outer_pf, st2_p1c, res_p4x), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_f_12624) {
                            return ({
                                auto [r_p1d, st3_p1e] = conv_type_f_12624;
                                auto added_pg = outer_name_pc == Text::lit("")
                                    ? names_p8
                                    : crate::prelude::push(names_p8, outer_name_pc);
                                (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyFn{outer_pd, xs_p1b, prism_rtl::rc(r_p1d)}), added_pg, joins_pe, st3_p1e}));
                            });
                        }));
                        });
                    }));
                    });
                }));
                });
            }));
            });
        }));
        });
    });
}


/// `Start ClosureSig, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> start_closure_sig_f(Cx_ cx_p0, crate::check::types::St st_p1, crate::syntax::Color color_p2, Array<crate::syntax::Type> ps_p3, crate::syntax::Type res_p4, Array<Text> written_p5) {
    return prism_rtl::make_rc<ClosureSig>(cx_p0, st_p1, color_p2, ps_p3, res_p4, written_p5);
}


/// WrittenCol: fn Color -> ((Bool, Col))
std::tuple<bool, crate::check::types::Col> written_col_f(const crate::syntax::Color& color0) {
    if (prism_rtl::is<crate::syntax::Color::Bounded>(color0)) {
        return std::tuple{false, crate::check::types::Col(crate::check::types::Col::CBound{})};
    }
    if (prism_rtl::is<crate::syntax::Color::Unbounded>(color0)) {
        return std::tuple{true, crate::check::types::Col(crate::check::types::Col::CUnbound{})};
    }
    if (prism_rtl::is<crate::syntax::Color::ColorVar>(color0)) {
        auto&& v_p0 = prism_rtl::as<crate::syntax::Color::ColorVar>(color0).a0;
        return prism_rtl::deref(v_p0).name_p == Text::lit("bounded")
            ? std::tuple{true, crate::check::types::Col(crate::check::types::Col::CBound{})}
            : std::tuple{true, crate::check::types::Col(crate::check::types::Col::CQ{prism_rtl::deref(v_p0).name_p})};
    }
    prism_rtl::unreachable("no arm matched");
}


/// WithUnwritten: fn Cx, Col -> Cx
Cx_ with_unwritten_f(const Cx_& cx_p0, const crate::check::types::Col& c_p1) {
    Cx_ this_ = cx_p0;
    this_.unwritten_p = c_p1;
    return this_;
}


/// WritesCol: fn Color -> Bool
bool writes_col_f(const crate::syntax::Color& color0) {
    if (prism_rtl::is<crate::syntax::Color::Bounded>(color0)) {
        return false;
    }
    {
        return true;
    }
}


/// TopColor: unbounded fn Type -> Color
crate::syntax::Color top_color_f(const crate::syntax::Type& t_p0) {
    auto&& _m = prism_rtl::deref(t_p0.kind_p);
    if (prism_rtl::is<crate::syntax::TypeKind::TFn>(_m)) {
        auto&& c_p1 = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a0;
        return c_p1;
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m)) {
        auto&& x_p2 = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        return top_color_f(prism_rtl::deref(prism_rtl::deref(x_p2)));
    }
    {
        return crate::syntax::Color(crate::syntax::Color::Bounded{});
    }
}


prism_rtl::Turn<crate::syntax::Color> TopColor::cycle() const {
    const auto& t_p0 = this->t_p0;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(t_p0).kind_p);
        prism_rtl::is<crate::syntax::TypeKind::TFn>(_m) ? ({
        auto&& c_p1 = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a0;
        prism_rtl::finished(c_p1);
    })
        : prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m) ? ({
        auto&& x_p2 = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(TopColor(prism_rtl::deref(prism_rtl::deref(x_p2)))));
    })
        : prism_rtl::finished(crate::syntax::Color(crate::syntax::Color::Bounded{}));
    });
}


/// `Start TopColor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::Color> start_top_color_f(crate::syntax::Type t_p0) {
    return prism_rtl::make_rc<TopColor>(t_p0);
}


/// FreshColNames: unbounded fn [Text], Nat -> [Text]
Array<Text> fresh_col_names_f(const Array<Text>& taken_p0, const Nat& n_p1) {
    auto&& _names_p5 = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(n_p1), std::tuple{Array<Text>{}, Nat(1u)}, ({
        auto taken_p0x = taken_p0;
        auto n_p1x = n_p1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Nat>>(std::tuple<std::tuple<Array<Text>, Nat>, Nat>)>>(prism_rtl::rc([=, taken_p0x = std::move(taken_p0x), n_p1x = std::move(n_p1x)](std::tuple<std::tuple<Array<Text>, Nat>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto taken_p0xy = taken_p0x;
            auto n_p1xy = n_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, taken_p0xy = std::move(taken_p0xy), n_p1xy = std::move(n_p1xy)]() {
            return ({
                auto [acc_p2, k_p3] = p0;
                static_cast<void>(p1);
                ({
                auto k2_p4 = next_free_col_f(crate::prelude::append(taken_p0xy, acc_p2), n_p1xy == Nat(1u) ? Nat(0u) : k_p3);
                (prism_rtl::finished(std::tuple{crate::prelude::push(acc_p2, sig_col_name_f(k2_p4)), k2_p4 + Nat(1u)}));
            });
            });
        })));
        });
    }));
    })));
    auto&& names_p5 = std::get<0>(_names_p5);
    return names_p5;
}


prism_rtl::Turn<Array<Text>> FreshColNames::cycle() const {
    const auto& taken_p0 = this->taken_p0;
    const auto& n_p1 = this->n_p1;
    auto n_p1x = n_p1;
    auto taken_p0x = taken_p0;
    return crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(n_p1x), std::tuple{Array<Text>{}, Nat(1u)}, ({
        auto taken_p0xx = taken_p0x;
        auto n_p1xx = n_p1x;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Nat>>(std::tuple<std::tuple<Array<Text>, Nat>, Nat>)>>(prism_rtl::rc([=, taken_p0xx = std::move(taken_p0xx), n_p1xx = std::move(n_p1xx)](std::tuple<std::tuple<Array<Text>, Nat>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto taken_p0xxy = taken_p0xx;
            auto n_p1xxy = n_p1xx;
            (crate::prelude::entered(crate::prelude::once_job([=, taken_p0xxy = std::move(taken_p0xxy), n_p1xxy = std::move(n_p1xxy)]() {
            return ({
                auto [acc_p2, k_p3] = p0;
                static_cast<void>(p1);
                ({
                auto k2_p4 = next_free_col_f(crate::prelude::append(taken_p0xxy, acc_p2), n_p1xxy == Nat(1u) ? Nat(0u) : k_p3);
                (prism_rtl::finished(std::tuple{crate::prelude::push(acc_p2, sig_col_name_f(k2_p4)), k2_p4 + Nat(1u)}));
            });
            });
        })));
        });
    }));
    })), [=](std::tuple<Array<Text>, Nat> fold_13692) {
        return ({
            auto&& _names_p5 = fold_13692;
            auto&& names_p5 = std::get<0>(_names_p5);
            (prism_rtl::finished(names_p5));
        });
    });
}


/// `Start FreshColNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_fresh_col_names_f(Array<Text> taken_p0, Nat n_p1) {
    return prism_rtl::make_rc<FreshColNames>(taken_p0, n_p1);
}


/// NextFreeCol: unbounded fn [Text], Nat -> Nat
Nat next_free_col_f(const Array<Text>& taken_p0, const Nat& k_p1) {
    return crate::check::types::has_text_f(taken_p0, sig_col_name_f(k_p1))
        ? next_free_col_f(taken_p0, k_p1 + Nat(1u))
        : k_p1;
}


/// SigColName: fn Nat -> Text
Text sig_col_name_f(const Nat& n0) {
    {
        auto&& c0_0 = n0;
        if (c0_0 == Nat(0u)) {
            return Text::lit("u");
        }
    }
    {
        auto&& k_p0 = n0;
        return prism_rtl::cat("u", k_p0);
    }
}


/// ConvBounds: fn Cx, St, [Bound] -> (([((Text, Text))], St))
std::tuple<Array<std::tuple<Text, Text>>, crate::check::types::St> conv_bounds_f(const Cx_& cx_p0, const crate::check::types::St& st_p1, const Array<crate::syntax::decls::Bound>& bounds_p2) {
    return crate::prelude::fold(bounds_p2, std::tuple{Array<std::tuple<Text, Text>>{}, st_p1}, [&](const std::tuple<Array<std::tuple<Text, Text>>, crate::check::types::St>& _p0, const crate::syntax::decls::Bound& b_p5) {
        auto&& acc_p3 = std::get<0>(_p0);
        auto&& s_p4 = std::get<1>(_p0);
        return crate::prelude::fold(prism_rtl::deref(b_p5).traits_p, std::tuple{acc_p3, s_p4}, [&](const std::tuple<Array<std::tuple<Text, Text>>, crate::check::types::St>& _p0, const crate::syntax::TraitRef& tr_p8) {
            auto&& a2_p6 = std::get<0>(_p0);
            auto&& s2_p7 = std::get<1>(_p0);
            return ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<std::tuple<Text, Text>>, crate::check::types::St>> _v;
                auto&& _m = crate::check::env::names::resolve_trait_o(cx_p0.g_p, cx_p0.home_p, prism_rtl::deref(tr_p8).path_p);
                if (prism_rtl::is_some(_m)) {
                    auto&& k_p9 = prism_rtl::some_of(_m);
                    _v.set(std::tuple{crate::prelude::push(a2_p6, std::tuple{prism_rtl::deref(prism_rtl::deref(b_p5).var_p).name_p, k_p9}), s2_p7});
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::tuple{a2_p6, crate::check::types::recording::err_f(s2_p7, Text::lit("unknown-name"), prism_rtl::deref(tr_p8).span_p, prism_rtl::cat("no trait `^", crate::check::env::dotted_f(prism_rtl::deref(tr_p8).path_p), "`"))});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        });
    });
}


/// MentionsTime: unbounded fn Type -> Bool
bool mentions_time_f(const crate::syntax::Type& t_p0) {
    auto&& _m = prism_rtl::deref(t_p0.kind_p);
    if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& args_p2 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        return ((crate::syntax::lexer::chars::contains_f(prism_rtl::deref(n_p1).sigils_p, Text::lit("$")) || crate::syntax::lexer::chars::contains_f(prism_rtl::deref(n_p1).sigils_p, Text::lit("!"))) || crate::syntax::lexer::chars::contains_f(prism_rtl::deref(n_p1).sigils_p, Text::lit("@"))) || crate::prelude::run_to_end(crate::prelude::fold_job(args_p2, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto seen_p3 = p0;
                    auto a_p4 = p1;
                    (prism_rtl::finished(std::move(seen_p3) || mentions_time_f(a_p4)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m)) {
        auto&& s_p5 = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a0;
        auto&& i_p6 = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a1;
        return ((crate::syntax::lexer::chars::contains_f(s_p5, Text::lit("$")) || crate::syntax::lexer::chars::contains_f(s_p5, Text::lit("!"))) || crate::syntax::lexer::chars::contains_f(s_p5, Text::lit("@"))) || mentions_time_f(prism_rtl::deref(prism_rtl::deref(i_p6)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TUnit>(_m)) {
        auto&& s_p7 = prism_rtl::as<crate::syntax::TypeKind::TUnit>(_m).a0;
        return (crate::syntax::lexer::chars::contains_f(s_p7, Text::lit("$")) || crate::syntax::lexer::chars::contains_f(s_p7, Text::lit("!"))) || crate::syntax::lexer::chars::contains_f(s_p7, Text::lit("@"));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TArray>(_m)) {
        auto&& e_p8 = prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a0;
        return mentions_time_f(prism_rtl::deref(prism_rtl::deref(e_p8)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TTuple>(_m)) {
        auto&& ts_p9 = prism_rtl::as<crate::syntax::TypeKind::TTuple>(_m).a0;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ts_p9, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto seen_pa = p0;
                    auto a_pb = p1;
                    (prism_rtl::finished(std::move(seen_pa) || mentions_time_f(a_pb)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m)) {
        auto&& x_pc = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        return mentions_time_f(prism_rtl::deref(prism_rtl::deref(x_pc)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TMap>(_m)) {
        auto&& k_pd = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a0;
        auto&& v_pe = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a1;
        return mentions_time_f(prism_rtl::deref(prism_rtl::deref(k_pd))) || mentions_time_f(prism_rtl::deref(prism_rtl::deref(v_pe)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TFn>(_m)) {
        auto&& ps_pf = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res_pg = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ps_pf, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto seen_ph = p0;
                    auto a_pi = p1;
                    (prism_rtl::finished(std::move(seen_ph) || mentions_time_f(a_pi)));
                });
            }));
        })))) || mentions_time_f(prism_rtl::deref(prism_rtl::deref(res_pg)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TEmit>(_m)) {
        auto&& ty_pj = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a0;
        return true;
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> MentionsTime::cycle() const {
    const auto& t_p0 = this->t_p0;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(t_p0).kind_p);
        prism_rtl::is<crate::syntax::TypeKind::TName>(_m) ? ({
        auto&& n_p1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& args_p2 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        prism_rtl::finished(((crate::syntax::lexer::chars::contains_f(prism_rtl::deref(n_p1).sigils_p, Text::lit("$")) || crate::syntax::lexer::chars::contains_f(prism_rtl::deref(n_p1).sigils_p, Text::lit("!"))) || crate::syntax::lexer::chars::contains_f(prism_rtl::deref(n_p1).sigils_p, Text::lit("@"))) || crate::prelude::run_to_end(crate::prelude::fold_job(args_p2, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto seen_p3 = p0;
                auto a_p4 = p1;
                (prism_rtl::finished(std::move(seen_p3) || mentions_time_f(a_p4)));
            });
        }));
    })))));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m) ? ({
        auto&& s_p5 = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a0;
        auto&& i_p6 = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a1;
        prism_rtl::finished(((crate::syntax::lexer::chars::contains_f(s_p5, Text::lit("$")) || crate::syntax::lexer::chars::contains_f(s_p5, Text::lit("!"))) || crate::syntax::lexer::chars::contains_f(s_p5, Text::lit("@"))) || mentions_time_f(prism_rtl::deref(prism_rtl::deref(i_p6))));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TUnit>(_m) ? ({
        auto&& s_p7 = prism_rtl::as<crate::syntax::TypeKind::TUnit>(_m).a0;
        prism_rtl::finished((crate::syntax::lexer::chars::contains_f(s_p7, Text::lit("$")) || crate::syntax::lexer::chars::contains_f(s_p7, Text::lit("!"))) || crate::syntax::lexer::chars::contains_f(s_p7, Text::lit("@")));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TArray>(_m) ? ({
        auto&& e_p8 = prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a0;
        prism_rtl::more(prism_rtl::rc(MentionsTime(prism_rtl::deref(prism_rtl::deref(e_p8)))));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TTuple>(_m) ? ({
        auto&& ts_p9 = prism_rtl::as<crate::syntax::TypeKind::TTuple>(_m).a0;
        crate::prelude::fold_job(ts_p9, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto seen_pa = p0;
                auto a_pb = p1;
                (prism_rtl::finished(std::move(seen_pa) || mentions_time_f(a_pb)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m) ? ({
        auto&& x_pc = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(MentionsTime(prism_rtl::deref(prism_rtl::deref(x_pc)))));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TMap>(_m) ? ({
        auto&& k_pd = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a0;
        auto&& v_pe = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a1;
        ({
        auto k_pdx = prism_rtl::deref(prism_rtl::deref(k_pd));
        auto v_pex = prism_rtl::deref(prism_rtl::deref(v_pe));
        (crate::prelude::call_then(start_mentions_time_f(k_pdx), [=, v_pex = std::move(v_pex)](bool mentions_time_f_15072) { return prism_rtl::finished(mentions_time_f_15072 || mentions_time_f(v_pex)); }));
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TFn>(_m) ? ({
        auto&& ps_pf = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res_pg = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        ({
        auto ps_pfx = ps_pf;
        auto res_pgx = prism_rtl::deref(prism_rtl::deref(res_pg));
        (crate::prelude::call_value(crate::prelude::fold_job(ps_pfx, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto seen_ph = p0;
                auto a_pi = p1;
                (prism_rtl::finished(std::move(seen_ph) || mentions_time_f(a_pi)));
            });
        }));
    }))), [=, res_pgx = std::move(res_pgx)](bool fold_15132) { return prism_rtl::finished(fold_15132 || mentions_time_f(res_pgx)); }));
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TEmit>(_m) ? ({
        auto&& ty_pj = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a0;
        prism_rtl::finished(true);
    })
        : prism_rtl::finished(false);
    });
}


/// `Start MentionsTime, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_mentions_time_f(crate::syntax::Type t_p0) {
    return prism_rtl::make_rc<MentionsTime>(t_p0);
}


/// TakesClosure: unbounded fn Type -> Bool
bool takes_closure_f(const crate::syntax::Type& t_p0) {
    auto&& _m = prism_rtl::deref(t_p0.kind_p);
    if (prism_rtl::is<crate::syntax::TypeKind::TFn>(_m)) {
        auto&& ps_p1 = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ps_p1, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto seen_p2 = p0;
                    auto p_p3 = p1;
                    (prism_rtl::finished(std::move(seen_p2) || is_fn_type_f(p_p3)));
                });
            }));
        }))));
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> TakesClosure::cycle() const {
    const auto& t_p0 = this->t_p0;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(t_p0).kind_p);
        prism_rtl::is<crate::syntax::TypeKind::TFn>(_m) ? ({
        auto&& ps_p1 = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        crate::prelude::fold_job(ps_p1, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto seen_p2 = p0;
                auto p_p3 = p1;
                (prism_rtl::finished(std::move(seen_p2) || is_fn_type_f(p_p3)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::finished(false);
    });
}


/// `Start TakesClosure, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_takes_closure_f(crate::syntax::Type t_p0) {
    return prism_rtl::make_rc<TakesClosure>(t_p0);
}


/// IsFnType: unbounded fn Type -> Bool
bool is_fn_type_f(const crate::syntax::Type& t_p0) {
    auto&& _m = prism_rtl::deref(t_p0.kind_p);
    if (prism_rtl::is<crate::syntax::TypeKind::TFn>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m)) {
        auto&& x_p1 = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        return is_fn_type_f(prism_rtl::deref(prism_rtl::deref(x_p1)));
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> IsFnType::cycle() const {
    const auto& t_p0 = this->t_p0;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(t_p0).kind_p);
        prism_rtl::is<crate::syntax::TypeKind::TFn>(_m) ? prism_rtl::finished(true)
        : prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m) ? ({
        auto&& x_p1 = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(IsFnType(prism_rtl::deref(prism_rtl::deref(x_p1)))));
    })
        : prism_rtl::finished(false);
    });
}


/// `Start IsFnType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_fn_type_f(crate::syntax::Type t_p0) {
    return prism_rtl::make_rc<IsFnType>(t_p0);
}


/// UsesScope: unbounded fn Type -> Bool
bool uses_scope_f(const crate::syntax::Type& t_p0) {
    auto&& _m = prism_rtl::deref(t_p0.kind_p);
    if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& args_p2 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        return ((crate::syntax::lexer::chars::contains_f(prism_rtl::deref(n_p1).sigils_p, Text::lit("@")) || ((crate::check::env::dotted_f(prism_rtl::deref(n_p1).path_p) == Text::lit("Element")) && (crate::prelude::len(args_p2) < Nat(2u)))) || ((crate::check::env::dotted_f(prism_rtl::deref(n_p1).path_p) == Text::lit("Elem")) && (crate::prelude::len(args_p2) == Nat(0u)))) || crate::prelude::run_to_end(crate::prelude::fold_job(args_p2, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto seen_p3 = p0;
                    auto a_p4 = p1;
                    (prism_rtl::finished(std::move(seen_p3) || uses_scope_f(a_p4)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m)) {
        auto&& s_p5 = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a0;
        auto&& i_p6 = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a1;
        return crate::syntax::lexer::chars::contains_f(s_p5, Text::lit("@")) || uses_scope_f(prism_rtl::deref(prism_rtl::deref(i_p6)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TUnit>(_m)) {
        auto&& s_p7 = prism_rtl::as<crate::syntax::TypeKind::TUnit>(_m).a0;
        return crate::syntax::lexer::chars::contains_f(s_p7, Text::lit("@"));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TArray>(_m)) {
        auto&& e_p8 = prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a0;
        return uses_scope_f(prism_rtl::deref(prism_rtl::deref(e_p8)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TTuple>(_m)) {
        auto&& ts_p9 = prism_rtl::as<crate::syntax::TypeKind::TTuple>(_m).a0;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ts_p9, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto seen_pa = p0;
                    auto a_pb = p1;
                    (prism_rtl::finished(std::move(seen_pa) || uses_scope_f(a_pb)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m)) {
        auto&& x_pc = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        return uses_scope_f(prism_rtl::deref(prism_rtl::deref(x_pc)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TMap>(_m)) {
        auto&& k_pd = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a0;
        auto&& v_pe = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a1;
        return uses_scope_f(prism_rtl::deref(prism_rtl::deref(k_pd))) || uses_scope_f(prism_rtl::deref(prism_rtl::deref(v_pe)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TFn>(_m)) {
        auto&& ps_pf = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res_pg = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ps_pf, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto seen_ph = p0;
                    auto a_pi = p1;
                    (prism_rtl::finished(std::move(seen_ph) || uses_scope_f(a_pi)));
                });
            }));
        })))) || uses_scope_f(prism_rtl::deref(prism_rtl::deref(res_pg)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TEmit>(_m)) {
        auto&& ty_pj = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a0;
        auto&& row_t_pk = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a1;
        return uses_scope_f(prism_rtl::deref(prism_rtl::deref(row_t_pk)));
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> UsesScope::cycle() const {
    const auto& t_p0 = this->t_p0;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(t_p0).kind_p);
        prism_rtl::is<crate::syntax::TypeKind::TName>(_m) ? ({
        auto&& n_p1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& args_p2 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        prism_rtl::finished(((crate::syntax::lexer::chars::contains_f(prism_rtl::deref(n_p1).sigils_p, Text::lit("@")) || ((crate::check::env::dotted_f(prism_rtl::deref(n_p1).path_p) == Text::lit("Element")) && (crate::prelude::len(args_p2) < Nat(2u)))) || ((crate::check::env::dotted_f(prism_rtl::deref(n_p1).path_p) == Text::lit("Elem")) && (crate::prelude::len(args_p2) == Nat(0u)))) || crate::prelude::run_to_end(crate::prelude::fold_job(args_p2, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto seen_p3 = p0;
                auto a_p4 = p1;
                (prism_rtl::finished(std::move(seen_p3) || uses_scope_f(a_p4)));
            });
        }));
    })))));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m) ? ({
        auto&& s_p5 = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a0;
        auto&& i_p6 = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a1;
        prism_rtl::finished(crate::syntax::lexer::chars::contains_f(s_p5, Text::lit("@")) || uses_scope_f(prism_rtl::deref(prism_rtl::deref(i_p6))));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TUnit>(_m) ? ({
        auto&& s_p7 = prism_rtl::as<crate::syntax::TypeKind::TUnit>(_m).a0;
        prism_rtl::finished(crate::syntax::lexer::chars::contains_f(s_p7, Text::lit("@")));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TArray>(_m) ? ({
        auto&& e_p8 = prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a0;
        prism_rtl::more(prism_rtl::rc(UsesScope(prism_rtl::deref(prism_rtl::deref(e_p8)))));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TTuple>(_m) ? ({
        auto&& ts_p9 = prism_rtl::as<crate::syntax::TypeKind::TTuple>(_m).a0;
        crate::prelude::fold_job(ts_p9, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto seen_pa = p0;
                auto a_pb = p1;
                (prism_rtl::finished(std::move(seen_pa) || uses_scope_f(a_pb)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m) ? ({
        auto&& x_pc = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(UsesScope(prism_rtl::deref(prism_rtl::deref(x_pc)))));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TMap>(_m) ? ({
        auto&& k_pd = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a0;
        auto&& v_pe = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a1;
        ({
        auto k_pdx = prism_rtl::deref(prism_rtl::deref(k_pd));
        auto v_pex = prism_rtl::deref(prism_rtl::deref(v_pe));
        (crate::prelude::call_then(start_uses_scope_f(k_pdx), [=, v_pex = std::move(v_pex)](bool uses_scope_f_16139) { return prism_rtl::finished(uses_scope_f_16139 || uses_scope_f(v_pex)); }));
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TFn>(_m) ? ({
        auto&& ps_pf = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res_pg = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        ({
        auto ps_pfx = ps_pf;
        auto res_pgx = prism_rtl::deref(prism_rtl::deref(res_pg));
        (crate::prelude::call_value(crate::prelude::fold_job(ps_pfx, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto seen_ph = p0;
                auto a_pi = p1;
                (prism_rtl::finished(std::move(seen_ph) || uses_scope_f(a_pi)));
            });
        }));
    }))), [=, res_pgx = std::move(res_pgx)](bool fold_16193) { return prism_rtl::finished(fold_16193 || uses_scope_f(res_pgx)); }));
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TEmit>(_m) ? ({
        auto&& ty_pj = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a0;
        auto&& row_t_pk = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a1;
        prism_rtl::more(prism_rtl::rc(UsesScope(prism_rtl::deref(prism_rtl::deref(row_t_pk)))));
    })
        : prism_rtl::finished(false);
    });
}


/// `Start UsesScope, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_uses_scope_f(crate::syntax::Type t_p0) {
    return prism_rtl::make_rc<UsesScope>(t_p0);
}


/// RowVarsOfType: unbounded fn Type -> [Text]
Array<Text> row_vars_of_type_f(const crate::syntax::Type& t_p0) {
    auto&& _m = prism_rtl::deref(t_p0.kind_p);
    if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& args_p2 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        auto name_p3 = crate::check::env::dotted_f(prism_rtl::deref(n_p1).path_p);
        auto own_p4 = ((name_p3 == Text::lit("Element")) && (crate::prelude::len(args_p2) == Nat(2u))) || ((name_p3 == Text::lit("Elem")) && (crate::prelude::len(args_p2) == Nat(1u)))
            ? row_names_in_f(crate::prelude::or_(crate::prelude::index(args_p2, Nat(0u)), dummy_type_p()))
            : Array<Text>{};
        auto rest_p5 = (name_p3 == Text::lit("Element")) && (crate::prelude::len(args_p2) == Nat(2u))
            ? crate::prelude::drop(args_p2, Nat(1u))
            : name_p3 == Text::lit("Elem") ? Array<crate::syntax::Type>{} : args_p2;
        return crate::prelude::run_to_end(crate::prelude::fold_job(rest_p5, own_p4, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_p6 = p0;
                    auto a_p7 = p1;
                    (crate::prelude::call_then(start_row_vars_of_type_f(a_p7), [=, acc_p6 = std::move(acc_p6)](Array<Text> row_vars_of_type_f_16813) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_p6, row_vars_of_type_f_16813)); }));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m)) {
        auto&& i_p8 = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a1;
        return row_vars_of_type_f(prism_rtl::deref(prism_rtl::deref(i_p8)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TArray>(_m)) {
        auto&& e_p9 = prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a0;
        return row_vars_of_type_f(prism_rtl::deref(prism_rtl::deref(e_p9)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TTuple>(_m)) {
        auto&& ts_pa = prism_rtl::as<crate::syntax::TypeKind::TTuple>(_m).a0;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ts_pa, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_pb = p0;
                    auto a_pc = p1;
                    (crate::prelude::call_then(start_row_vars_of_type_f(a_pc), [=, acc_pb = std::move(acc_pb)](Array<Text> row_vars_of_type_f_16965) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_pb, row_vars_of_type_f_16965)); }));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m)) {
        auto&& x_pd = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        return row_vars_of_type_f(prism_rtl::deref(prism_rtl::deref(x_pd)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TMap>(_m)) {
        auto&& k_pe = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a0;
        auto&& v_pf = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a1;
        return crate::check::types::union_texts_f(row_vars_of_type_f(prism_rtl::deref(prism_rtl::deref(k_pe))), row_vars_of_type_f(prism_rtl::deref(prism_rtl::deref(v_pf))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TFn>(_m)) {
        auto&& ps_pg = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res_ph = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ps_pg, row_vars_of_type_f(prism_rtl::deref(prism_rtl::deref(res_ph))), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_pi = p0;
                    auto a_pj = p1;
                    (crate::prelude::call_then(start_row_vars_of_type_f(a_pj), [=, acc_pi = std::move(acc_pi)](Array<Text> row_vars_of_type_f_17157) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_pi, row_vars_of_type_f_17157)); }));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TEmit>(_m)) {
        auto&& ty_pk = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a0;
        auto&& row_t_pl = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a1;
        return crate::check::types::union_texts_f(row_vars_of_type_f(prism_rtl::deref(prism_rtl::deref(ty_pk))), row_names_in_f(prism_rtl::deref(prism_rtl::deref(row_t_pl))));
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> RowVarsOfType::cycle() const {
    const auto& t_p0 = this->t_p0;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(t_p0).kind_p);
        prism_rtl::is<crate::syntax::TypeKind::TName>(_m) ? ({
        auto&& n_p1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& args_p2 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        ({
        auto name_p3 = crate::check::env::dotted_f(prism_rtl::deref(n_p1).path_p);
        auto own_p4 = ((name_p3 == Text::lit("Element")) && (crate::prelude::len(args_p2) == Nat(2u))) || ((name_p3 == Text::lit("Elem")) && (crate::prelude::len(args_p2) == Nat(1u)))
            ? row_names_in_f(crate::prelude::or_(crate::prelude::index(args_p2, Nat(0u)), dummy_type_p()))
            : Array<Text>{};
        auto rest_p5 = (name_p3 == Text::lit("Element")) && (crate::prelude::len(args_p2) == Nat(2u))
            ? crate::prelude::drop(args_p2, Nat(1u))
            : name_p3 == Text::lit("Elem") ? Array<crate::syntax::Type>{} : args_p2;
        (crate::prelude::fold_job(rest_p5, own_p4, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_p6 = p0;
                auto a_p7 = p1;
                (crate::prelude::call_then(start_row_vars_of_type_f(a_p7), [=, acc_p6 = std::move(acc_p6)](Array<Text> row_vars_of_type_f_16813) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_p6, row_vars_of_type_f_16813)); }));
            });
        }));
    })))->cycle());
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m) ? ({
        auto&& i_p8 = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a1;
        prism_rtl::more(prism_rtl::rc(RowVarsOfType(prism_rtl::deref(prism_rtl::deref(i_p8)))));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TArray>(_m) ? ({
        auto&& e_p9 = prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a0;
        prism_rtl::more(prism_rtl::rc(RowVarsOfType(prism_rtl::deref(prism_rtl::deref(e_p9)))));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TTuple>(_m) ? ({
        auto&& ts_pa = prism_rtl::as<crate::syntax::TypeKind::TTuple>(_m).a0;
        crate::prelude::fold_job(ts_pa, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_pb = p0;
                auto a_pc = p1;
                (crate::prelude::call_then(start_row_vars_of_type_f(a_pc), [=, acc_pb = std::move(acc_pb)](Array<Text> row_vars_of_type_f_16965) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_pb, row_vars_of_type_f_16965)); }));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m) ? ({
        auto&& x_pd = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(RowVarsOfType(prism_rtl::deref(prism_rtl::deref(x_pd)))));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TMap>(_m) ? ({
        auto&& k_pe = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a0;
        auto&& v_pf = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a1;
        ({
        auto k_pex = prism_rtl::deref(prism_rtl::deref(k_pe));
        auto v_pfx = prism_rtl::deref(prism_rtl::deref(v_pf));
        (crate::prelude::call_then(start_row_vars_of_type_f(k_pex), [=, v_pfx = std::move(v_pfx)](Array<Text> row_vars_of_type_f_17039) { return crate::prelude::call_then(start_row_vars_of_type_f(v_pfx), [=](Array<Text> row_vars_of_type_f_17058) { return prism_rtl::finished(crate::check::types::union_texts_f(row_vars_of_type_f_17039, row_vars_of_type_f_17058)); }); }));
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TFn>(_m) ? ({
        auto&& ps_pg = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res_ph = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        ({
        auto ps_pgx = ps_pg;
        auto res_phx = prism_rtl::deref(prism_rtl::deref(res_ph));
        (crate::prelude::call_then(start_row_vars_of_type_f(res_phx), [=, ps_pgx = std::move(ps_pgx)](Array<Text> row_vars_of_type_f_17110) {
        return crate::prelude::fold_job(ps_pgx, row_vars_of_type_f_17110, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_pi = p0;
                    auto a_pj = p1;
                    (crate::prelude::call_then(start_row_vars_of_type_f(a_pj), [=, acc_pi = std::move(acc_pi)](Array<Text> row_vars_of_type_f_17157) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_pi, row_vars_of_type_f_17157)); }));
                });
            }));
        })))->cycle();
    }));
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TEmit>(_m) ? ({
        auto&& ty_pk = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a0;
        auto&& row_t_pl = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a1;
        ({
        auto row_t_plx = prism_rtl::deref(prism_rtl::deref(row_t_pl));
        auto ty_pkx = prism_rtl::deref(prism_rtl::deref(ty_pk));
        (crate::prelude::call_then(start_row_vars_of_type_f(ty_pkx), [=, row_t_plx = std::move(row_t_plx)](Array<Text> row_vars_of_type_f_17206) { return crate::prelude::call_then(start_row_names_in_f(row_t_plx), [=](Array<Text> row_names_in_f_17226) { return prism_rtl::finished(crate::check::types::union_texts_f(row_vars_of_type_f_17206, row_names_in_f_17226)); }); }));
    });
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start RowVarsOfType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_row_vars_of_type_f(crate::syntax::Type t_p0) {
    return prism_rtl::make_rc<RowVarsOfType>(t_p0);
}


/// RowNamesIn: unbounded fn Type -> [Text]
Array<Text> row_names_in_f(const crate::syntax::Type& t_p0) {
    auto&& _m = prism_rtl::deref(t_p0.kind_p);
    if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& m17322_0_1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        if (m17322_0_1.size() == 0u) {
            return (crate::prelude::len(prism_rtl::deref(n_p1).path_p) == Nat(1u)) && crate::check::env::is_lower_text_f(crate::check::env::dotted_f(prism_rtl::deref(n_p1).path_p))
                ? Array(std::vector{crate::check::env::dotted_f(prism_rtl::deref(n_p1).path_p)})
                : Array<Text>{};
        }
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TRowUnion>(_m)) {
        auto&& ts_p2 = prism_rtl::as<crate::syntax::TypeKind::TRowUnion>(_m).a0;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ts_p2, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_p3 = p0;
                    auto a_p4 = p1;
                    (crate::prelude::call_then(start_row_names_in_f(a_p4), [=, acc_p3 = std::move(acc_p3)](Array<Text> row_names_in_f_17500) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_p3, row_names_in_f_17500)); }));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m)) {
        auto&& x_p5 = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        return row_names_in_f(prism_rtl::deref(prism_rtl::deref(x_p5)));
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> RowNamesIn::cycle() const {
    const auto& t_p0 = this->t_p0;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(t_p0).kind_p);
        prism_rtl::is<crate::syntax::TypeKind::TName>(_m) && ({
        auto&& n_p1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& m17322_0_1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        (m17322_0_1.size() == 0u);
    }) ? ({
        auto&& n_p1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& m17322_0_1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        (crate::prelude::len(prism_rtl::deref(n_p1).path_p) == Nat(1u)) && crate::check::env::is_lower_text_f(crate::check::env::dotted_f(prism_rtl::deref(n_p1).path_p))
        ? prism_rtl::finished(Array(std::vector{crate::check::env::dotted_f(prism_rtl::deref(n_p1).path_p)}))
        : prism_rtl::finished(Array<Text>{});
    })
        : prism_rtl::is<crate::syntax::TypeKind::TRowUnion>(_m) ? ({
        auto&& ts_p2 = prism_rtl::as<crate::syntax::TypeKind::TRowUnion>(_m).a0;
        crate::prelude::fold_job(ts_p2, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_p3 = p0;
                auto a_p4 = p1;
                (crate::prelude::call_then(start_row_names_in_f(a_p4), [=, acc_p3 = std::move(acc_p3)](Array<Text> row_names_in_f_17500) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_p3, row_names_in_f_17500)); }));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m) ? ({
        auto&& x_p5 = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(RowNamesIn(prism_rtl::deref(prism_rtl::deref(x_p5)))));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start RowNamesIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_row_names_in_f(crate::syntax::Type t_p0) {
    return prism_rtl::make_rc<RowNamesIn>(t_p0);
}


/// TypeVarsOfType: unbounded fn Type -> [Text]
Array<Text> type_vars_of_type_f(const crate::syntax::Type& t_p0) {
    return type_vars_into_f(Array<Text>{}, t_p0);
}


prism_rtl::Turn<Array<Text>> TypeVarsOfType::cycle() const {
    const auto& t_p0 = this->t_p0;
    return prism_rtl::more(prism_rtl::rc(TypeVarsInto(Array<Text>{}, t_p0)));
}


/// `Start TypeVarsOfType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_type_vars_of_type_f(crate::syntax::Type t_p0) {
    return prism_rtl::make_rc<TypeVarsOfType>(t_p0);
}


/// TypeVarsInto: unbounded fn [Text], Type -> [Text]
Array<Text> type_vars_into_f(const Array<Text>& acc_p0, const crate::syntax::Type& t_p1) {
    auto&& _m = prism_rtl::deref(t_p1.kind_p);
    if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
        auto&& n_p2 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& args_p3 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        auto name_p4 = crate::check::env::dotted_f(prism_rtl::deref(n_p2).path_p);
        auto here_p5 = ((crate::prelude::len(prism_rtl::deref(n_p2).path_p) == Nat(1u)) && crate::check::env::is_lower_text_f(name_p4)) && (crate::prelude::len(args_p3) == Nat(0u))
            ? crate::check::types::add_text_f(acc_p0, name_p4)
            : acc_p0;
        auto rest_p6 = (name_p4 == Text::lit("Element")) && (crate::prelude::len(args_p3) == Nat(2u))
            ? crate::prelude::drop(args_p3, Nat(1u))
            : name_p4 == Text::lit("Elem") ? Array<crate::syntax::Type>{} : args_p3;
        return crate::prelude::run_to_end(crate::prelude::fold_job(rest_p6, here_p5, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto a_p7 = p0;
                    auto x_p8 = p1;
                    (prism_rtl::more(prism_rtl::rc(TypeVarsInto(a_p7, x_p8))));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m)) {
        auto&& i_p9 = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a1;
        return type_vars_into_f(acc_p0, prism_rtl::deref(prism_rtl::deref(i_p9)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TArray>(_m)) {
        auto&& e_pa = prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a0;
        return type_vars_into_f(acc_p0, prism_rtl::deref(prism_rtl::deref(e_pa)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TTuple>(_m)) {
        auto&& ts_pb = prism_rtl::as<crate::syntax::TypeKind::TTuple>(_m).a0;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ts_pb, acc_p0, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto a_pc = p0;
                    auto x_pd = p1;
                    (prism_rtl::more(prism_rtl::rc(TypeVarsInto(a_pc, x_pd))));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m)) {
        auto&& x_pe = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        return type_vars_into_f(acc_p0, prism_rtl::deref(prism_rtl::deref(x_pe)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TMap>(_m)) {
        auto&& k_pf = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a0;
        auto&& v_pg = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a1;
        return type_vars_into_f(type_vars_into_f(acc_p0, prism_rtl::deref(prism_rtl::deref(k_pf))), prism_rtl::deref(prism_rtl::deref(v_pg)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TFn>(_m)) {
        auto&& ps_ph = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res_pi = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        return type_vars_into_f(crate::prelude::run_to_end(crate::prelude::fold_job(ps_ph, acc_p0, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto a_pj = p0;
                    auto x_pk = p1;
                    (prism_rtl::more(prism_rtl::rc(TypeVarsInto(a_pj, x_pk))));
                });
            }));
        })))), prism_rtl::deref(prism_rtl::deref(res_pi)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TEmit>(_m)) {
        auto&& ty_pl = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a0;
        return type_vars_into_f(acc_p0, prism_rtl::deref(prism_rtl::deref(ty_pl)));
    }
    {
        return acc_p0;
    }
}


prism_rtl::Turn<Array<Text>> TypeVarsInto::cycle() const {
    const auto& acc_p0 = this->acc_p0;
    const auto& t_p1 = this->t_p1;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(t_p1).kind_p);
        prism_rtl::is<crate::syntax::TypeKind::TName>(_m) ? ({
        auto&& n_p2 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& args_p3 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        ({
        auto name_p4 = crate::check::env::dotted_f(prism_rtl::deref(n_p2).path_p);
        auto here_p5 = ((crate::prelude::len(prism_rtl::deref(n_p2).path_p) == Nat(1u)) && crate::check::env::is_lower_text_f(name_p4)) && (crate::prelude::len(args_p3) == Nat(0u))
            ? crate::check::types::add_text_f(acc_p0, name_p4)
            : acc_p0;
        auto rest_p6 = (name_p4 == Text::lit("Element")) && (crate::prelude::len(args_p3) == Nat(2u))
            ? crate::prelude::drop(args_p3, Nat(1u))
            : name_p4 == Text::lit("Elem") ? Array<crate::syntax::Type>{} : args_p3;
        (crate::prelude::fold_job(rest_p6, here_p5, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto a_p7 = p0;
                auto x_p8 = p1;
                (prism_rtl::more(prism_rtl::rc(TypeVarsInto(a_p7, x_p8))));
            });
        }));
    })))->cycle());
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m) ? ({
        auto&& i_p9 = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a1;
        prism_rtl::more(prism_rtl::rc(TypeVarsInto(acc_p0, prism_rtl::deref(prism_rtl::deref(i_p9)))));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TArray>(_m) ? ({
        auto&& e_pa = prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a0;
        prism_rtl::more(prism_rtl::rc(TypeVarsInto(acc_p0, prism_rtl::deref(prism_rtl::deref(e_pa)))));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TTuple>(_m) ? ({
        auto&& ts_pb = prism_rtl::as<crate::syntax::TypeKind::TTuple>(_m).a0;
        crate::prelude::fold_job(ts_pb, acc_p0, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto a_pc = p0;
                auto x_pd = p1;
                (prism_rtl::more(prism_rtl::rc(TypeVarsInto(a_pc, x_pd))));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m) ? ({
        auto&& x_pe = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(TypeVarsInto(acc_p0, prism_rtl::deref(prism_rtl::deref(x_pe)))));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TMap>(_m) ? ({
        auto&& k_pf = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a0;
        auto&& v_pg = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a1;
        ({
        auto acc_p0x = acc_p0;
        auto k_pfx = prism_rtl::deref(prism_rtl::deref(k_pf));
        auto v_pgx = prism_rtl::deref(prism_rtl::deref(v_pg));
        (crate::prelude::call_then(start_type_vars_into_f(acc_p0x, k_pfx), [=, v_pgx = std::move(v_pgx)](Array<Text> type_vars_into_f_18357) { return prism_rtl::more(prism_rtl::rc(TypeVarsInto(type_vars_into_f_18357, v_pgx))); }));
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TFn>(_m) ? ({
        auto&& ps_ph = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res_pi = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        ({
        auto acc_p0x = acc_p0;
        auto ps_phx = ps_ph;
        auto res_pix = prism_rtl::deref(prism_rtl::deref(res_pi));
        (crate::prelude::call_value(crate::prelude::fold_job(ps_phx, acc_p0x, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto a_pj = p0;
                auto x_pk = p1;
                (prism_rtl::more(prism_rtl::rc(TypeVarsInto(a_pj, x_pk))));
            });
        }));
    }))), [=, res_pix = std::move(res_pix)](Array<Text> fold_18420) { return prism_rtl::more(prism_rtl::rc(TypeVarsInto(fold_18420, res_pix))); }));
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TEmit>(_m) ? ({
        auto&& ty_pl = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a0;
        prism_rtl::more(prism_rtl::rc(TypeVarsInto(acc_p0, prism_rtl::deref(prism_rtl::deref(ty_pl)))));
    })
        : prism_rtl::finished(acc_p0);
    });
}


/// `Start TypeVarsInto, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_type_vars_into_f(Array<Text> acc_p0, crate::syntax::Type t_p1) {
    return prism_rtl::make_rc<TypeVarsInto>(acc_p0, t_p1);
}


/// ColorVarsOfType: unbounded fn Type -> [Text]
Array<Text> color_vars_of_type_f(const crate::syntax::Type& t_p0) {
    auto&& _m = prism_rtl::deref(t_p0.kind_p);
    if (prism_rtl::is<crate::syntax::TypeKind::TFn>(_m) && prism_rtl::is<crate::syntax::Color::ColorVar>(prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a0)) {
        auto&& v_p1 = prism_rtl::as<crate::syntax::Color::ColorVar>(prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a0).a0;
        auto&& ps_p2 = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res_p3 = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        auto inner_p4 = crate::prelude::run_to_end(crate::prelude::fold_job(ps_p2, color_vars_of_type_f(prism_rtl::deref(prism_rtl::deref(res_p3))), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_p5 = p0;
                    auto a_p6 = p1;
                    (crate::prelude::call_then(start_color_vars_of_type_f(a_p6), [=, acc_p5 = std::move(acc_p5)](Array<Text> color_vars_of_type_f_18721) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_p5, color_vars_of_type_f_18721)); }));
                });
            }));
        }))));
        return prism_rtl::deref(v_p1).name_p == Text::lit("bounded")
            ? inner_p4
            : crate::check::types::add_text_f(inner_p4, prism_rtl::deref(v_p1).name_p);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TFn>(_m)) {
        auto&& ps_p7 = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res_p8 = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ps_p7, color_vars_of_type_f(prism_rtl::deref(prism_rtl::deref(res_p8))), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_p9 = p0;
                    auto a_pa = p1;
                    (crate::prelude::call_then(start_color_vars_of_type_f(a_pa), [=, acc_p9 = std::move(acc_p9)](Array<Text> color_vars_of_type_f_18890) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_p9, color_vars_of_type_f_18890)); }));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
        auto&& args_pb = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        return crate::prelude::run_to_end(crate::prelude::fold_job(args_pb, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_pc = p0;
                    auto a_pd = p1;
                    (crate::prelude::call_then(start_color_vars_of_type_f(a_pd), [=, acc_pc = std::move(acc_pc)](Array<Text> color_vars_of_type_f_18977) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_pc, color_vars_of_type_f_18977)); }));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m)) {
        auto&& i_pe = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a1;
        return color_vars_of_type_f(prism_rtl::deref(prism_rtl::deref(i_pe)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TArray>(_m)) {
        auto&& e_pf = prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a0;
        return color_vars_of_type_f(prism_rtl::deref(prism_rtl::deref(e_pf)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TTuple>(_m)) {
        auto&& ts_pg = prism_rtl::as<crate::syntax::TypeKind::TTuple>(_m).a0;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ts_pg, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_ph = p0;
                    auto a_pi = p1;
                    (crate::prelude::call_then(start_color_vars_of_type_f(a_pi), [=, acc_ph = std::move(acc_ph)](Array<Text> color_vars_of_type_f_19135) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_ph, color_vars_of_type_f_19135)); }));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m)) {
        auto&& x_pj = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        return color_vars_of_type_f(prism_rtl::deref(prism_rtl::deref(x_pj)));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TMap>(_m)) {
        auto&& k_pk = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a0;
        auto&& v_pl = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a1;
        return crate::check::types::union_texts_f(color_vars_of_type_f(prism_rtl::deref(prism_rtl::deref(k_pk))), color_vars_of_type_f(prism_rtl::deref(prism_rtl::deref(v_pl))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TEmit>(_m)) {
        auto&& ty_pm = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a0;
        return color_vars_of_type_f(prism_rtl::deref(prism_rtl::deref(ty_pm)));
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> ColorVarsOfType::cycle() const {
    const auto& t_p0 = this->t_p0;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(t_p0).kind_p);
        prism_rtl::is<crate::syntax::TypeKind::TFn>(_m) && prism_rtl::is<crate::syntax::Color::ColorVar>(prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a0) ? ({
        auto&& v_p1 = prism_rtl::as<crate::syntax::Color::ColorVar>(prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a0).a0;
        auto&& ps_p2 = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res_p3 = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        ({
        auto ps_p2x = ps_p2;
        auto res_p3x = prism_rtl::deref(prism_rtl::deref(res_p3));
        auto v_p1x = v_p1;
        (crate::prelude::call_then(start_color_vars_of_type_f(res_p3x), [=, ps_p2x = std::move(ps_p2x), v_p1x = std::move(v_p1x)](Array<Text> color_vars_of_type_f_18672) {
        return crate::prelude::call_value(crate::prelude::fold_job(ps_p2x, color_vars_of_type_f_18672, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_p5 = p0;
                    auto a_p6 = p1;
                    (crate::prelude::call_then(start_color_vars_of_type_f(a_p6), [=, acc_p5 = std::move(acc_p5)](Array<Text> color_vars_of_type_f_18721) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_p5, color_vars_of_type_f_18721)); }));
                });
            }));
        }))), [=](Array<Text> fold_18662) {
            return ({
                auto inner_p4 = fold_18662;
                (prism_rtl::deref(v_p1x).name_p == Text::lit("bounded")
                ? prism_rtl::finished(inner_p4)
                : prism_rtl::finished(crate::check::types::add_text_f(inner_p4, prism_rtl::deref(v_p1x).name_p)));
            });
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TFn>(_m) ? ({
        auto&& ps_p7 = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res_p8 = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        ({
        auto ps_p7x = ps_p7;
        auto res_p8x = prism_rtl::deref(prism_rtl::deref(res_p8));
        (crate::prelude::call_then(start_color_vars_of_type_f(res_p8x), [=, ps_p7x = std::move(ps_p7x)](Array<Text> color_vars_of_type_f_18841) {
        return crate::prelude::fold_job(ps_p7x, color_vars_of_type_f_18841, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_p9 = p0;
                    auto a_pa = p1;
                    (crate::prelude::call_then(start_color_vars_of_type_f(a_pa), [=, acc_p9 = std::move(acc_p9)](Array<Text> color_vars_of_type_f_18890) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_p9, color_vars_of_type_f_18890)); }));
                });
            }));
        })))->cycle();
    }));
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TName>(_m) ? ({
        auto&& args_pb = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        crate::prelude::fold_job(args_pb, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_pc = p0;
                auto a_pd = p1;
                (crate::prelude::call_then(start_color_vars_of_type_f(a_pd), [=, acc_pc = std::move(acc_pc)](Array<Text> color_vars_of_type_f_18977) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_pc, color_vars_of_type_f_18977)); }));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m) ? ({
        auto&& i_pe = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a1;
        prism_rtl::more(prism_rtl::rc(ColorVarsOfType(prism_rtl::deref(prism_rtl::deref(i_pe)))));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TArray>(_m) ? ({
        auto&& e_pf = prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ColorVarsOfType(prism_rtl::deref(prism_rtl::deref(e_pf)))));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TTuple>(_m) ? ({
        auto&& ts_pg = prism_rtl::as<crate::syntax::TypeKind::TTuple>(_m).a0;
        crate::prelude::fold_job(ts_pg, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_ph = p0;
                auto a_pi = p1;
                (crate::prelude::call_then(start_color_vars_of_type_f(a_pi), [=, acc_ph = std::move(acc_ph)](Array<Text> color_vars_of_type_f_19135) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_ph, color_vars_of_type_f_19135)); }));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m) ? ({
        auto&& x_pj = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ColorVarsOfType(prism_rtl::deref(prism_rtl::deref(x_pj)))));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TMap>(_m) ? ({
        auto&& k_pk = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a0;
        auto&& v_pl = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a1;
        ({
        auto k_pkx = prism_rtl::deref(prism_rtl::deref(k_pk));
        auto v_plx = prism_rtl::deref(prism_rtl::deref(v_pl));
        (crate::prelude::call_then(start_color_vars_of_type_f(k_pkx), [=, v_plx = std::move(v_plx)](Array<Text> color_vars_of_type_f_19213) { return crate::prelude::call_then(start_color_vars_of_type_f(v_plx), [=](Array<Text> color_vars_of_type_f_19234) { return prism_rtl::finished(crate::check::types::union_texts_f(color_vars_of_type_f_19213, color_vars_of_type_f_19234)); }); }));
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TEmit>(_m) ? ({
        auto&& ty_pm = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ColorVarsOfType(prism_rtl::deref(prism_rtl::deref(ty_pm)))));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start ColorVarsOfType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_color_vars_of_type_f(crate::syntax::Type t_p0) {
    return prism_rtl::make_rc<ColorVarsOfType>(t_p0);
}

}  // namespace crate::check::env::reading
